package it.ccg.tcejb.server.util;

import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.exception.BackEndException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

import org.apache.log4j.Logger;

public class CSVReader {
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	private BufferedReader bR;
	
	public CSVReader(Reader r){
		bR = new BufferedReader(r);
	}
	
	public String[][] parse() throws BackEndException{
	
		logger.debug(new StandardLogMessage("in CSVReader.parse"));
		ArrayList<String[]> appoArray = new ArrayList<String[]>();
		try {
			String appo;
			while((appo =  bR.readLine())!=null){
				appoArray.add(appo.split(";"));
			}
			
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		}
		logger.debug(new StandardLogMessage("appo "+appoArray.size()));
		String[][] toReturn = new String[appoArray.size()][((String[])appoArray.get(0)).length];
		for (int i = 0 ;i<appoArray.size();i++){
			toReturn[i]=appoArray.get(i);
		}
		return toReturn;
	}
}
