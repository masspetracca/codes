package it.ccg.tcejb.server.logengine;


import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class Log4jSetup {
	
	private static Logger logger;
	
	
	public static void loadLog4JProperties() throws Exception {
		
		//URL log4jPropertiesURL = Thread.currentThread().getContextClassLoader().getResource("log4j.isc.config.xml");
		final String LOG_FILE_ABS_PATH = System.getProperty("user.install.root") + 
										 System.getProperty("file.separator") +"properties" + 
										 System.getProperty("file.separator") +"tc"+
										 System.getProperty("file.separator") +"log4j.xml";
		
		//URL log4jPropertiesURL = new URL(PROPERTIES_SYSTEM_FILE_ABS_PATH);
		DOMConfigurator.configure(LOG_FILE_ABS_PATH);
		//DOMConfigurator.configure(log4jPropertiesURL);
		//PropertyConfigurator.configure(LOG_FILE_ABS_PATH);
		//DOMConfigurator.configure(LOG_FILE_ABS_PATH);
		
		logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
		
		logger.debug(new StandardLogMessage("Terrorism control system Log4J properties successfully loaded from " + LOG_FILE_ABS_PATH/*log4jPropertiesURL*/));
		
	}
	
	
}
