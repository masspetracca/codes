package it.ccg.tcejb.server.find.business;

import it.ccg.tcejb.server.bean.eao.TctClientEntityEAO;
import it.ccg.tcejb.server.bean.eao.bitclub.VwAdminLegalCcgEntityEAO;
import it.ccg.tcejb.server.bean.entity.TctClientEntity;
import it.ccg.tcejb.server.bean.entity.TctClientEntityPK;
import it.ccg.tcejb.server.bean.entity.TctCompanyEntity;
import it.ccg.tcejb.server.bean.entity.bitclub.VwAdminLegalCcgEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;

/**
 * Session Bean implementation class CCGClientsAligner
 */
@Stateless
@LocalBean
public class ClientsAligner {
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	@EJB
	private VwAdminLegalCcgEntityEAO vwAdminLegalCcgEntityEAO;
	
	@EJB
	private TctClientEntityEAO tctClientEAO;
	@Resource
	private SessionContext sessionContext;
    /**
     * Default constructor. 
     */
    public ClientsAligner() {
        // TODO Auto-generated constructor stub
    }
    
    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public List<TctClientEntity> readCCGDataFromExternal(TctCompanyEntity company) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in List<TctClientEntity> readCCGDataFromExternal(TctCompanyEntity company)"));
    	List<TctClientEntity> clients = new ArrayList<TctClientEntity>();
    	try {
			List<VwAdminLegalCcgEntity> extClients = vwAdminLegalCcgEntityEAO.retrieveClient();
			
			for (VwAdminLegalCcgEntity c : extClients){
				ejbLogger.debug(new StandardLogMessage("client: "+c.getClientName()));
				TctClientEntity client = new TctClientEntity();
				TctClientEntityPK pk = new TctClientEntityPK();
				pk.setClntId(c.getIdSoc());
				pk.setCmpnId(company.getCmpnId());
				
				client.setId(pk);
				client.setAbiCode(c.getAbiCode());
				client.setAdminName(c.getAdminName());
				client.setAdminSurn(c.getAdminSurname());
				client.setClntName(c.getClientName());
				client.setCountry(c.getCountry());
				client.setGroup(c.getGroup());
				client.setIdAdmin(c.getIdAdmin());
				client.setIdLegalRap(c.getIdLegalRappr());
				client.setLegalName(c.getLegalName());
				client.setLegalSurna(c.getLegalSurname());
				
				clients.add(client);
			}
			ejbLogger.debug(new StandardLogMessage("read "+clients.size()+" clients"));
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardLogMessage("error in readCCGDataFromExternal: "+e.getMessage()));
			throw e;
		}
    	ejbLogger.debug(new StandardLogMessage("return"));
    	return clients;
    }
    
    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public void writeCCGDataToInternal(List<TctClientEntity> clients) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in void writeCCGDataToInternal(List<TctClientEntity> clients)"));
    	for (TctClientEntity c : clients){
    		TctClientEntity appoClinet = tctClientEAO.retrieveClientsByClientIdAndCompanyId(c.getId().getCmpnId(), c.getId().getClntId());
    		if (appoClinet!=null){
    			c.setIsNew("N");
    			appoClinet.setAbiCode(c.getAbiCode());
    			appoClinet.setAdminName(c.getAdminName());
    			appoClinet.setAdminSurn(c.getAdminSurn());
    			appoClinet.setClntName(c.getClntName());
    			appoClinet.setCountry(c.getCountry());
    			appoClinet.setGroup(c.getGroup());
    			appoClinet.setIdAdmin(c.getIdAdmin());
    			appoClinet.setIdLegalRap(c.getIdLegalRap());
    			appoClinet.setIsNew(c.getIsNew());
    			appoClinet.setLegalName(c.getLegalName());
    			appoClinet.setLegalSurna(c.getLegalSurna());
    			appoClinet.setUpdType("U");
    			appoClinet.setUpdDate(new Timestamp(new Date().getTime()));
    			appoClinet.setUpdUser(sessionContext.getCallerPrincipal().getName());
    			
    			tctClientEAO.updateEntity(appoClinet);
    		}else{
    			c.setIsNew("Y");
    			tctClientEAO.insertEntity(c);
    		}
    	}
    }

}
