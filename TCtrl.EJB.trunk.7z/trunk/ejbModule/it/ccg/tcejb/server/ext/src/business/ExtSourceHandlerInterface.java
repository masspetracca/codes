package it.ccg.tcejb.server.ext.src.business;

import it.ccg.tcejb.server.bean.entity.TctSrcUpDtEntity;
import it.ccg.tcejb.server.exception.BackEndException;

import java.util.concurrent.Future;

public interface ExtSourceHandlerInterface {

	public boolean checkIsNewList() throws BackEndException;
	public void downloadSourceFile() throws BackEndException;
	public void storeListData(String user) throws BackEndException;
	public Future<TctSrcUpDtEntity> getData(String user,int downloadID) throws BackEndException;
}
