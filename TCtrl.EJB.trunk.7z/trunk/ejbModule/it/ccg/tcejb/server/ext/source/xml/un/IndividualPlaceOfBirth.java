package it.ccg.tcejb.server.ext.source.xml.un;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{}CITY" minOccurs="0"/>
 *         &lt;element ref="{}STATE_PROVINCE" minOccurs="0"/>
 *         &lt;element ref="{}COUNTRY" minOccurs="0"/>
 *         &lt;element ref="{}NOTE" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "city",
    "stateprovince",
    "country",
    "note"
})
@XmlRootElement(name = "INDIVIDUAL_PLACE_OF_BIRTH")
public class IndividualPlaceOfBirth {

    @XmlElement(name = "CITY")
    protected String city;
    @XmlElement(name = "STATE_PROVINCE")
    protected String stateprovince;
    @XmlElement(name = "COUNTRY")
    protected String country;
    @XmlElement(name = "NOTE")
    protected String note;

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCITY() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCITY(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the stateprovince property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTATEPROVINCE() {
        return stateprovince;
    }

    /**
     * Sets the value of the stateprovince property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTATEPROVINCE(String value) {
        this.stateprovince = value;
    }

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOUNTRY() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOUNTRY(String value) {
        this.country = value;
    }

    /**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNOTE() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNOTE(String value) {
        this.note = value;
    }

}
