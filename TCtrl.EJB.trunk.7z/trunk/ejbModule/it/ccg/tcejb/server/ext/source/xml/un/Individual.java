package it.ccg.tcejb.server.ext.source.xml.un;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{}DATAID"/>
 *         &lt;element ref="{}VERSIONNUM"/>
 *         &lt;element ref="{}FIRST_NAME"/>
 *         &lt;element ref="{}SECOND_NAME" minOccurs="0"/>
 *         &lt;element ref="{}THIRD_NAME" minOccurs="0"/>
 *         &lt;element ref="{}FOURTH_NAME" minOccurs="0"/>
 *         &lt;element ref="{}UN_LIST_TYPE"/>
 *         &lt;element ref="{}REFERENCE_NUMBER"/>
 *         &lt;element ref="{}LISTED_ON"/>
 *         &lt;element ref="{}GENDER" minOccurs="0"/>
 *         &lt;element ref="{}SUBMITTED_BY" minOccurs="0"/>
 *         &lt;element ref="{}NAME_ORIGINAL_SCRIPT" minOccurs="0"/>
 *         &lt;element ref="{}COMMENTS1"/>
 *         &lt;element ref="{}NATIONALITY2" minOccurs="0"/>
 *         &lt;element ref="{}TITLE" minOccurs="0"/>
 *         &lt;element ref="{}DESIGNATION" minOccurs="0"/>
 *         &lt;element ref="{}NATIONALITY" minOccurs="0"/>
 *         &lt;element ref="{}LIST_TYPE"/>
 *         &lt;element ref="{}LAST_DAY_UPDATED" minOccurs="0"/>
 *         &lt;element ref="{}INDIVIDUAL_ALIAS" maxOccurs="unbounded"/>
 *         &lt;element ref="{}INDIVIDUAL_ADDRESS" maxOccurs="unbounded"/>
 *         &lt;element ref="{}INDIVIDUAL_DATE_OF_BIRTH" maxOccurs="unbounded"/>
 *         &lt;element ref="{}INDIVIDUAL_PLACE_OF_BIRTH" maxOccurs="unbounded"/>
 *         &lt;element ref="{}INDIVIDUAL_DOCUMENT" maxOccurs="unbounded"/>
 *         &lt;element ref="{}SORT_KEY"/>
 *         &lt;element ref="{}SORT_KEY_LAST_MOD"/>
 *         &lt;element ref="{}DELISTED_ON" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "dataid",
    "versionnum",
    "firstname",
    "secondname",
    "thirdname",
    "fourthname",
    "unlisttype",
    "referencenumber",
    "listedon",
    "gender",
    "submittedby",
    "nameoriginalscript",
    "comments1",
    "nationality2",
    "title",
    "designation",
    "nationality",
    "listtype",
    "lastdayupdated",
    "individualalias",
    "individualaddress",
    "individualdateofbirth",
    "individualplaceofbirth",
    "individualdocument",
    "sortkey",
    "sortkeylastmod",
    "delistedon"
})
@XmlRootElement(name = "INDIVIDUAL")
public class Individual {

    @XmlElement(name = "DATAID", required = true, defaultValue = "000000")
    protected BigInteger dataid;
    @XmlElement(name = "VERSIONNUM", required = true, defaultValue = "1")
    protected BigInteger versionnum;
    @XmlElement(name = "FIRST_NAME", required = true)
    protected String firstname;
    @XmlElement(name = "SECOND_NAME", defaultValue = "na")
    protected String secondname;
    @XmlElement(name = "THIRD_NAME", defaultValue = "na")
    protected String thirdname;
    @XmlElement(name = "FOURTH_NAME", defaultValue = "na")
    protected String fourthname;
    @XmlElement(name = "UN_LIST_TYPE", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String unlisttype;
    @XmlElement(name = "REFERENCE_NUMBER", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String referencenumber;
    @XmlElement(name = "LISTED_ON", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar listedon;
    @XmlElement(name = "GENDER")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String gender;
    @XmlElement(name = "SUBMITTED_BY")
    protected String submittedby;
    @XmlElement(name = "NAME_ORIGINAL_SCRIPT")
    protected String nameoriginalscript;
    @XmlElement(name = "COMMENTS1", required = true)
    protected String comments1;
    @XmlElement(name = "NATIONALITY2")
    protected String nationality2;
    @XmlElement(name = "TITLE")
    protected Title title;
    @XmlElement(name = "DESIGNATION")
    protected Designation designation;
    @XmlElement(name = "NATIONALITY")
    protected Nationality nationality;
    @XmlElement(name = "LIST_TYPE", required = true)
    protected ListType listtype;
    @XmlElement(name = "LAST_DAY_UPDATED")
    protected LastDayUpdated lastdayupdated;
    @XmlElement(name = "INDIVIDUAL_ALIAS", required = true)
    protected List<IndividualAlias> individualalias;
    @XmlElement(name = "INDIVIDUAL_ADDRESS", required = true)
    protected List<IndividualAddress> individualaddress;
    @XmlElement(name = "INDIVIDUAL_DATE_OF_BIRTH", required = true)
    protected List<IndividualDateOfBirth> individualdateofbirth;
    @XmlElement(name = "INDIVIDUAL_PLACE_OF_BIRTH", required = true)
    protected List<IndividualPlaceOfBirth> individualplaceofbirth;
    @XmlElement(name = "INDIVIDUAL_DOCUMENT", required = true)
    protected List<IndividualDocument> individualdocument;
    @XmlElement(name = "SORT_KEY", required = true)
    protected String sortkey;
    @XmlElement(name = "SORT_KEY_LAST_MOD", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sortkeylastmod;
    @XmlElement(name = "DELISTED_ON")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar delistedon;

    /**
     * Gets the value of the dataid property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDATAID() {
        return dataid;
    }

    /**
     * Sets the value of the dataid property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDATAID(BigInteger value) {
        this.dataid = value;
    }

    /**
     * Gets the value of the versionnum property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getVERSIONNUM() {
        return versionnum;
    }

    /**
     * Sets the value of the versionnum property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setVERSIONNUM(BigInteger value) {
        this.versionnum = value;
    }

    /**
     * Gets the value of the firstname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFIRSTNAME() {
        return firstname;
    }

    /**
     * Sets the value of the firstname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFIRSTNAME(String value) {
        this.firstname = value;
    }

    /**
     * Gets the value of the secondname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSECONDNAME() {
        return secondname;
    }

    /**
     * Sets the value of the secondname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSECONDNAME(String value) {
        this.secondname = value;
    }

    /**
     * Gets the value of the thirdname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTHIRDNAME() {
        return thirdname;
    }

    /**
     * Sets the value of the thirdname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTHIRDNAME(String value) {
        this.thirdname = value;
    }

    /**
     * Gets the value of the fourthname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFOURTHNAME() {
        return fourthname;
    }

    /**
     * Sets the value of the fourthname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFOURTHNAME(String value) {
        this.fourthname = value;
    }

    /**
     * Gets the value of the unlisttype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUNLISTTYPE() {
        return unlisttype;
    }

    /**
     * Sets the value of the unlisttype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUNLISTTYPE(String value) {
        this.unlisttype = value;
    }

    /**
     * Gets the value of the referencenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREFERENCENUMBER() {
        return referencenumber;
    }

    /**
     * Sets the value of the referencenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREFERENCENUMBER(String value) {
        this.referencenumber = value;
    }

    /**
     * Gets the value of the listedon property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLISTEDON() {
        return listedon;
    }

    /**
     * Sets the value of the listedon property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLISTEDON(XMLGregorianCalendar value) {
        this.listedon = value;
    }

    /**
     * Gets the value of the gender property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGENDER() {
        return gender;
    }

    /**
     * Sets the value of the gender property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGENDER(String value) {
        this.gender = value;
    }

    /**
     * Gets the value of the submittedby property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSUBMITTEDBY() {
        return submittedby;
    }

    /**
     * Sets the value of the submittedby property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSUBMITTEDBY(String value) {
        this.submittedby = value;
    }

    /**
     * Gets the value of the nameoriginalscript property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNAMEORIGINALSCRIPT() {
        return nameoriginalscript;
    }

    /**
     * Sets the value of the nameoriginalscript property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNAMEORIGINALSCRIPT(String value) {
        this.nameoriginalscript = value;
    }

    /**
     * Gets the value of the comments1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMMENTS1() {
        return comments1;
    }

    /**
     * Sets the value of the comments1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMMENTS1(String value) {
        this.comments1 = value;
    }

    /**
     * Gets the value of the nationality2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNATIONALITY2() {
        return nationality2;
    }

    /**
     * Sets the value of the nationality2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNATIONALITY2(String value) {
        this.nationality2 = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link TITLE }
     *     
     */
    public Title getTITLE() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link TITLE }
     *     
     */
    public void setTITLE(Title value) {
        this.title = value;
    }

    /**
     * Gets the value of the designation property.
     * 
     * @return
     *     possible object is
     *     {@link DESIGNATION }
     *     
     */
    public Designation getDESIGNATION() {
        return designation;
    }

    /**
     * Sets the value of the designation property.
     * 
     * @param value
     *     allowed object is
     *     {@link DESIGNATION }
     *     
     */
    public void setDESIGNATION(Designation value) {
        this.designation = value;
    }

    /**
     * Gets the value of the nationality property.
     * 
     * @return
     *     possible object is
     *     {@link NATIONALITY }
     *     
     */
    public Nationality getNATIONALITY() {
        return nationality;
    }

    /**
     * Sets the value of the nationality property.
     * 
     * @param value
     *     allowed object is
     *     {@link NATIONALITY }
     *     
     */
    public void setNATIONALITY(Nationality value) {
        this.nationality = value;
    }

    /**
     * Gets the value of the listtype property.
     * 
     * @return
     *     possible object is
     *     {@link LISTTYPE }
     *     
     */
    public ListType getLISTTYPE() {
        return listtype;
    }

    /**
     * Sets the value of the listtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link LISTTYPE }
     *     
     */
    public void setLISTTYPE(ListType value) {
        this.listtype = value;
    }

    /**
     * Gets the value of the lastdayupdated property.
     * 
     * @return
     *     possible object is
     *     {@link LASTDAYUPDATED }
     *     
     */
    public LastDayUpdated getLASTDAYUPDATED() {
        return lastdayupdated;
    }

    /**
     * Sets the value of the lastdayupdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link LASTDAYUPDATED }
     *     
     */
    public void setLASTDAYUPDATED(LastDayUpdated value) {
        this.lastdayupdated = value;
    }

    /**
     * Gets the value of the individualalias property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the individualalias property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getINDIVIDUALALIAS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link INDIVIDUALALIAS }
     * 
     * 
     */
    public List<IndividualAlias> getINDIVIDUALALIAS() {
        if (individualalias == null) {
            individualalias = new ArrayList<IndividualAlias>();
        }
        return this.individualalias;
    }

    /**
     * Gets the value of the individualaddress property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the individualaddress property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getINDIVIDUALADDRESS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link INDIVIDUALADDRESS }
     * 
     * 
     */
    public List<IndividualAddress> getINDIVIDUALADDRESS() {
        if (individualaddress == null) {
            individualaddress = new ArrayList<IndividualAddress>();
        }
        return this.individualaddress;
    }

    /**
     * Gets the value of the individualdateofbirth property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the individualdateofbirth property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getINDIVIDUALDATEOFBIRTH().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link INDIVIDUALDATEOFBIRTH }
     * 
     * 
     */
    public List<IndividualDateOfBirth> getINDIVIDUALDATEOFBIRTH() {
        if (individualdateofbirth == null) {
            individualdateofbirth = new ArrayList<IndividualDateOfBirth>();
        }
        return this.individualdateofbirth;
    }

    /**
     * Gets the value of the individualplaceofbirth property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the individualplaceofbirth property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getINDIVIDUALPLACEOFBIRTH().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link INDIVIDUALPLACEOFBIRTH }
     * 
     * 
     */
    public List<IndividualPlaceOfBirth> getINDIVIDUALPLACEOFBIRTH() {
        if (individualplaceofbirth == null) {
            individualplaceofbirth = new ArrayList<IndividualPlaceOfBirth>();
        }
        return this.individualplaceofbirth;
    }

    /**
     * Gets the value of the individualdocument property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the individualdocument property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getINDIVIDUALDOCUMENT().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link INDIVIDUALDOCUMENT }
     * 
     * 
     */
    public List<IndividualDocument> getINDIVIDUALDOCUMENT() {
        if (individualdocument == null) {
            individualdocument = new ArrayList<IndividualDocument>();
        }
        return this.individualdocument;
    }

    /**
     * Gets the value of the sortkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSORTKEY() {
        return sortkey;
    }

    /**
     * Sets the value of the sortkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSORTKEY(String value) {
        this.sortkey = value;
    }

    /**
     * Gets the value of the sortkeylastmod property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSORTKEYLASTMOD() {
        return sortkeylastmod;
    }

    /**
     * Sets the value of the sortkeylastmod property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSORTKEYLASTMOD(XMLGregorianCalendar value) {
        this.sortkeylastmod = value;
    }

    /**
     * Gets the value of the delistedon property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDELISTEDON() {
        return delistedon;
    }

    /**
     * Sets the value of the delistedon property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDELISTEDON(XMLGregorianCalendar value) {
        this.delistedon = value;
    }

}
