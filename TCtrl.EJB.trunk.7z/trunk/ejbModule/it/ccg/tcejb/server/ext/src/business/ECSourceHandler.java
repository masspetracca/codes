package it.ccg.tcejb.server.ext.src.business;

import it.ccg.tcejb.server.bean.DownloadManagerLocal;
import it.ccg.tcejb.server.bean.eao.ec.TctEcEntityEAO;
import it.ccg.tcejb.server.bean.entity.TctSrcUpDtEntity;
import it.ccg.tcejb.server.bean.entity.ec.TctEcAddrdEntity;
import it.ccg.tcejb.server.bean.entity.ec.TctEcAddrdEntityPK;
import it.ccg.tcejb.server.bean.entity.ec.TctEcBirthEntity;
import it.ccg.tcejb.server.bean.entity.ec.TctEcBirthEntityPK;
import it.ccg.tcejb.server.bean.entity.ec.TctEcCitizEntity;
import it.ccg.tcejb.server.bean.entity.ec.TctEcCitizEntityPK;
import it.ccg.tcejb.server.bean.entity.ec.TctEcENameEntity;
import it.ccg.tcejb.server.bean.entity.ec.TctEcENameEntityPK;
import it.ccg.tcejb.server.bean.entity.ec.TctEcEntitEntity;
import it.ccg.tcejb.server.bean.entity.ec.TctEcPssPtEntity;
import it.ccg.tcejb.server.bean.entity.ec.TctEcPssPtEntityPK;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.ext.source.xml.ec.ADDRESS;
import it.ccg.tcejb.server.ext.source.xml.ec.BIRTH;
import it.ccg.tcejb.server.ext.source.xml.ec.CITIZEN;
import it.ccg.tcejb.server.ext.source.xml.ec.ENTITY;
import it.ccg.tcejb.server.ext.source.xml.ec.NAME;
import it.ccg.tcejb.server.ext.source.xml.ec.PASSPORT;
import it.ccg.tcejb.server.ext.source.xml.ec.WHOLE;
import it.ccg.tcejb.server.ext.source.xml.engine.XmlEngineCommunity;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardCheckPointMessage;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Future;

import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

@Stateless
@Local(ExtSourceHandlerInterface.class)
@LocalBean
@ConcurrencyManagement(ConcurrencyManagementType.CONTAINER)
@TransactionManagement(TransactionManagementType.CONTAINER)
public class ECSourceHandler implements ExtSourceHandlerInterface {
	
	private static final Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private static final Logger sysLogger = Logger.getLogger(LoggerFactory.SYS_LOG);
	/*@EJB
	private SessionManager sessionManager;*/
	@EJB
	private DownloadManagerLocal downLoadManager;
	@EJB
	private TctEcEntityEAO tctEcEntity;
	//@EJB
	//private TctSrcUpDtEntityEAO tctSrcUpDtEntityEAO;
	private WHOLE ecObj;
	public ECSourceHandler(){
		
		try {
			Context context = new InitialContext();
			this.downLoadManager = (DownloadManagerLocal) context.lookup("ejblocal:it.ccg.tcejb.server.bean.DownloadManagerLocal");
		} catch (NamingException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
		}
	}
	@Override
	public boolean checkIsNewList() throws BackEndException {
		ejbLogger.debug("in ECSourceHandler.checkIsNewList");
		try {
    		GregorianCalendar srcGCalendar = null;
    		Date srcLastDate = tctEcEntity.getLatestsrcListDate();
	    	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	    	
	    	if (srcLastDate !=null){
	    		srcGCalendar = new GregorianCalendar();
		    	srcGCalendar.setTime(srcLastDate);
	    	}else{
	    		return true;
	    	}
	    	GregorianCalendar listDate = new GregorianCalendar();
			listDate.setTime(formatter.parse(this.ecObj.getDate()));
			
			return listDate.after(srcGCalendar);
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}

	@Override
	public void downloadSourceFile() throws BackEndException {
		ejbLogger.debug("in ECSourceHandler.downloadSourceFile");
		this.downLoadManager.downloadECList();
		XmlEngineCommunity xmlEngine = new XmlEngineCommunity();
		try {
			ecObj = xmlEngine.read(SystemProperties.getSystemProperty("ec.file.name"));
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}

	@Override
	@Asynchronous
	public Future<TctSrcUpDtEntity> getData(String user,int downloadID) throws BackEndException {
		ejbLogger.info(new StandardCheckPointMessage("Start EC getData "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
		ejbLogger.debug(new StandardLogMessage("Ec thread "+Thread.currentThread().getName()));
		TctSrcUpDtEntity srcUpd = null;
		try {
			this.downloadSourceFile();
				
			boolean isNew = this.checkIsNewList();
			if (isNew){
			this.storeListData(user);
			srcUpd = new TctSrcUpDtEntity();
			srcUpd.setSrcList("EC");
			srcUpd.setListDate(new SimpleDateFormat("dd/MM/yyyy").parse(this.ecObj.getDate()));
			srcUpd.setDownloadid(downloadID);
			srcUpd.setUpdDate(new Timestamp(new Date().getTime()));
			srcUpd.setUpdType("C");
			srcUpd.setUpdUser(user);
			}else{ 
			ejbLogger.info(new StandardCheckPointMessage("Completed EC getData without new record "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
			return new AsyncResult<TctSrcUpDtEntity>(srcUpd);
			}
			ejbLogger.info(new StandardCheckPointMessage("Completed EC getData "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
			return new AsyncResult<TctSrcUpDtEntity>(srcUpd);
		} catch (BackEndException e) {
			/*
			 * TN_CCG17047
			 * raffaele de lauri	
			 * 08/05/2015
			 * cambio per gestione errore su singolo source
			 * originale
			 *
			 ejbLogger.info(new StandardCheckPointMessage("EC getData complited with error "+e.getMessage()));
			 ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			 throw new BackEndException(e);
			 */
			ejbLogger.info(new StandardCheckPointMessage("EC getData complited with error "+e.getMessage()));
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3EC getData complited with ERROR "+e.getMessage());
			return new AsyncResult<TctSrcUpDtEntity>(srcUpd);
		} catch (ParseException e) {
			/*
			 * TN_CCG17047
			 * raffaele de lauri	
			 * 08/05/2015
			 * cambio per gestione errore su singolo source
			 * originale
			 *
			 ejbLogger.info(new StandardCheckPointMessage("EC getData complited with error "+e.getMessage()));
			 ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			 throw new BackEndException(e);
			 */
			ejbLogger.info(new StandardCheckPointMessage("EC getData complited with error "+e.getMessage()));
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3EC getData complited with error "+e.getMessage());
			return new AsyncResult<TctSrcUpDtEntity>(srcUpd);
	   }
	}
	
	@Override
	public void storeListData(String user) throws BackEndException {
		ejbLogger.debug("in ECSourceHandler.storeListData");
		// TODO Auto-generated method stub downloadid
		this.tctEcEntity.deleteEveryEntity();
		List<ENTITY> entities = this.ecObj.getENTITY();
		List<TctEcEntitEntity> ecEntities = new ArrayList<TctEcEntitEntity>();
		ejbLogger.debug(new StandardLogMessage("Entities"));
		Date insertDate = new Date();
		try {
			for(ENTITY ecEn : entities){
				TctEcEntitEntity ent = new TctEcEntitEntity();
				ejbLogger.debug(new StandardLogMessage("entity "+ecEn.getId()) );
				ent.setEntityId(Integer.parseInt(ecEn.getId()));
				ent.setLegalBasis(ecEn.getLegalBasis().trim());
				ent.setPdfLink(ecEn.getPdfLink().trim());
				ent.setRegDate(new SimpleDateFormat("yyyy-MM-dd").parse(ecEn.getRegDate()));
				ent.setType(ecEn.getType().trim());					
				ent.setSrcListDate(new SimpleDateFormat("dd/MM/yyyy").parse(this.ecObj.getDate()));

				ent.setUpdDate(new Timestamp(new Date().getTime()));
				Set<TctEcCitizEntity> citized = new HashSet<TctEcCitizEntity>();
				for(CITIZEN cit: ecEn.getCITIZEN()){
					ejbLogger.debug(new StandardLogMessage("Citizen "+cit.getId()));
					TctEcCitizEntity ctz = new TctEcCitizEntity();
					TctEcCitizEntityPK pk = new TctEcCitizEntityPK();
					pk.setCityId(Integer.parseInt(cit.getId()));
					pk.setEntityid(Integer.parseInt(cit.getEntityId()));
					ctz.setId(pk);
					ctz.setCountry(cit.getCOUNTRY().trim().replaceAll(",", ""));
					ctz.setLegalBasis(cit.getLegalBasis().trim());
					ctz.setPdfLink(cit.getPdfLink().trim());
					if(cit.getRegDate()!=null && !cit.getRegDate().equalsIgnoreCase("")) 
						ctz.setRegDate(new SimpleDateFormat("yyyy-MM-dd").parse(cit.getRegDate()));
					
					ctz.setTctecentit(ent);
					citized.add(ctz);
				}
				ent.setTcteccitizs(citized);
				Set<TctEcAddrdEntity> addres = new HashSet<TctEcAddrdEntity>();
				for(ADDRESS adr : ecEn.getADDRESS()){
					ejbLogger.debug(new StandardLogMessage("Address "+adr.getId()));
					TctEcAddrdEntity adrs = new TctEcAddrdEntity();
					TctEcAddrdEntityPK pk = new TctEcAddrdEntityPK();
					pk.setAddressId(Integer.parseInt(adr.getId()));
					pk.setEntityid(Integer.parseInt(adr.getEntityId()));
					
					adrs.setId(pk);
					adrs.setCity(adr.getCITY().trim().replaceAll(",", ""));
					adrs.setCountry(adr.getCOUNTRY().trim().replaceAll(",", ""));
					adrs.setLegalBasis(adr.getLegalBasis().trim());
					adrs.setNumber(adr.getNUMBER().trim().replaceAll(",", ""));
					adrs.setOther(adr.getOTHER().trim().replaceAll(",", ""));
					adrs.setPdfLink(adr.getPdfLink().trim());
					if(adr.getRegDate()!=null && !adr.getRegDate().equalsIgnoreCase("")) 
						adrs.setRegDate(new SimpleDateFormat("yyyy-MM-dd").parse(adr.getRegDate()));
					
					adrs.setStreet(adr.getSTREET().trim().replaceAll(",", ""));
					adrs.setZipCode(adr.getZIPCODE().trim().replaceAll(",", ""));
					
					adrs.setTctecentit(ent);
					
					addres.add(adrs);
				}
				ent.setTctecaddrds(addres);
				Set<TctEcBirthEntity> births = new HashSet<TctEcBirthEntity>();
				for (BIRTH bt: ecEn.getBIRTH()){
					ejbLogger.debug(new StandardLogMessage("Birth "+bt.getId()));
					TctEcBirthEntity birth = new TctEcBirthEntity();
					TctEcBirthEntityPK pk = new TctEcBirthEntityPK();
					pk.setBirthId(Integer.parseInt(bt.getId()));
					pk.setEntityid(Integer.parseInt(bt.getEntityId()));
					birth.setId(pk);
					birth.setCountry(bt.getCOUNTRY().trim().replaceAll(",", ""));
					birth.setDate(bt.getDATE().trim().replaceAll(",", ""));
					birth.setLegalBasis(bt.getLegalBasis().trim());
					birth.setPdfLink(bt.getPdfLink());
					birth.setPlace(bt.getPLACE().trim().replaceAll(",", ""));
					if(bt.getRegDate()!=null && !bt.getRegDate().equalsIgnoreCase(""))
						birth.setRegDate(new SimpleDateFormat("yyyy-MM-dd").parse(bt.getRegDate()));
					
					birth.setTctecentit(ent);
					
					births.add(birth);
				}
				ent.setTctecbirths(births);
				Set<TctEcPssPtEntity> psspts = new HashSet<TctEcPssPtEntity>();
				for(PASSPORT pss: ecEn.getPASSPORT()){
					ejbLogger.debug(new StandardLogMessage("Passport "+pss.getId()));
					TctEcPssPtEntity pssPt = new TctEcPssPtEntity();
					TctEcPssPtEntityPK pk = new TctEcPssPtEntityPK();
					pk.setPssPrtId(Integer.parseInt(pss.getId()));
					pk.setEntityid(Integer.parseInt(pss.getEntityId()));
					
					pssPt.setId(pk);
					pssPt.setCountry(pss.getCOUNTRY().trim().replaceAll(",", ""));
					pssPt.setLegalBasis(pss.getLegalBasis().trim());
					pssPt.setNumber(pss.getNUMBER().trim().replaceAll(",", ""));
					pssPt.setPdfLink(pss.getPdfLink().trim());
					if(pss.getRegDate()!=null && !pss.getRegDate().equalsIgnoreCase(""))
						pssPt.setRegDate(new SimpleDateFormat("yyyy-MM-dd").parse(pss.getRegDate()));
					
					pssPt.setTctecentit(ent);
					
					psspts.add(pssPt);
				}
				ent.setTctecpsspts(psspts);
				Set<TctEcENameEntity> names = new HashSet<TctEcENameEntity>();
				for (NAME n :ecEn.getNAME()){
					ejbLogger.debug(new StandardLogMessage("Name "+n.getId()));
					TctEcENameEntity nam = new TctEcENameEntity();
					TctEcENameEntityPK pk = new TctEcENameEntityPK();
					pk.setNameId(Integer.parseInt(n.getId()));
					pk.setEntityid(Integer.parseInt(n.getEntityId()));
					
					nam.setId(pk);
					nam.setFirstName(n.getFIRSTNAME().trim().replaceAll(",", ""));
					nam.setFunction(n.getFUNCTION().trim().replaceAll(",", ""));
					nam.setGender(n.getGENDER().trim().replaceAll(",", ""));
					nam.setLanguage(n.getLANGUAGE().trim().replaceAll(",", ""));
					nam.setLastName(n.getLASTNAME().trim().replaceAll(",", ""));
					nam.setLegalBasis(n.getLegalBasis().trim());
					nam.setMiddleName(n.getMIDDLENAME().trim().replaceAll(",", ""));
					nam.setPdfLink(n.getPdfLink().trim());
					if(n.getRegDate()!=null && !n.getRegDate().equalsIgnoreCase(""))
						nam.setRegDate(new SimpleDateFormat("yyyy-MM-dd").parse(n.getRegDate()));
					
					nam.setTitle(n.getTITLE().trim().replaceAll(",", ""));
					nam.setWholeName(n.getWHOLENAME().trim().replaceAll(",", ""));
					nam.setTctecentit(ent);
					
					names.add(nam);
				}
				ent.setTctecenames(names);
				ent.setUpdDate(new Timestamp(insertDate.getTime()));
				ent.setUpdType("C");
				ent.setUpdUser(user);
				
				ecEntities.add(ent);
			}
			
			tctEcEntity.insertEntity(ecEntities);
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}
}
