package it.ccg.tcejb.server.ext.source.xml.ofac;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="firstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lastName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="title" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sdnType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="remarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="programList">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="program" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="idList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="id" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                             &lt;element name="idType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="idNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="idCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="issueDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="expirationDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="akaList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="aka" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                             &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="category" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="lastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="firstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="addressList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="address" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                             &lt;element name="address1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="address3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="city" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="stateOrProvince" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="postalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="nationalityList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="nationality" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                             &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="citizenshipList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="citizenship" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                             &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="dateOfBirthList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="dateOfBirthItem" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                             &lt;element name="dateOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="placeOfBirthList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="placeOfBirthItem" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                             &lt;element name="placeOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="vesselInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="callSign" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="vesselType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="vesselFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="vesselOwner" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="tonnage" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                   &lt;element name="grossRegisteredTonnage" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "uid",
    "firstName",
    "lastName",
    "title",
    "sdnType",
    "remarks",
    "programList",
    "idList",
    "akaList",
    "addressList",
    "nationalityList",
    "citizenshipList",
    "dateOfBirthList",
    "placeOfBirthList",
    "vesselInfo"
})
public class SdnEntry {

	@XmlElement(namespace = "http://tempuri.org/sdnList.xsd")
    protected int uid;
	@XmlElement(namespace = "http://tempuri.org/sdnList.xsd")
    protected String firstName;
    @XmlElement(required = true,namespace = "http://tempuri.org/sdnList.xsd")
    protected String lastName;
    @XmlElement(namespace = "http://tempuri.org/sdnList.xsd")
    protected String title;
    @XmlElement(required = true,namespace = "http://tempuri.org/sdnList.xsd")
    protected String sdnType;
    @XmlElement(namespace = "http://tempuri.org/sdnList.xsd")
    protected String remarks;
    @XmlElement(required = true,namespace = "http://tempuri.org/sdnList.xsd")
    protected ProgramList programList;
    @XmlElement(namespace = "http://tempuri.org/sdnList.xsd")
    protected IdList idList;
    @XmlElement(namespace = "http://tempuri.org/sdnList.xsd")
    protected AkaList akaList;
    @XmlElement(namespace = "http://tempuri.org/sdnList.xsd")
    protected AddressList addressList;
    @XmlElement(namespace = "http://tempuri.org/sdnList.xsd")
    protected NationalityList nationalityList;
    @XmlElement(namespace = "http://tempuri.org/sdnList.xsd")
    protected CitizenshipList citizenshipList;
    @XmlElement(namespace = "http://tempuri.org/sdnList.xsd")
    protected DateOfBirthList dateOfBirthList;
    @XmlElement(namespace = "http://tempuri.org/sdnList.xsd")
    protected PlaceOfBirthList placeOfBirthList;
    @XmlElement(namespace = "http://tempuri.org/sdnList.xsd")
    protected VesselInfo vesselInfo;

    /**
     * Gets the value of the uid property.
     * 
     */
    public int getUid() {
        return uid;
    }

    /**
     * Sets the value of the uid property.
     * 
     */
    public void setUid(int value) {
        this.uid = value;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
     * Gets the value of the sdnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSdnType() {
        return sdnType;
    }

    /**
     * Sets the value of the sdnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSdnType(String value) {
        this.sdnType = value;
    }

    /**
     * Gets the value of the remarks property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * Sets the value of the remarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemarks(String value) {
        this.remarks = value;
    }

    /**
     * Gets the value of the programList property.
     * 
     * @return
     *     possible object is
     *     {@link SdnList.SdnEntry.ProgramList }
     *     
     */
    public ProgramList getProgramList() {
        return programList;
    }

    /**
     * Sets the value of the programList property.
     * 
     * @param value
     *     allowed object is
     *     {@link SdnList.SdnEntry.ProgramList }
     *     
     */
    public void setProgramList(ProgramList value) {
        this.programList = value;
    }

    /**
     * Gets the value of the idList property.
     * 
     * @return
     *     possible object is
     *     {@link SdnList.SdnEntry.IdList }
     *     
     */
    public IdList getIdList() {
        return idList;
    }

    /**
     * Sets the value of the idList property.
     * 
     * @param value
     *     allowed object is
     *     {@link SdnList.SdnEntry.IdList }
     *     
     */
    public void setIdList(IdList value) {
        this.idList = value;
    }

    /**
     * Gets the value of the akaList property.
     * 
     * @return
     *     possible object is
     *     {@link SdnList.SdnEntry.AkaList }
     *     
     */
    public AkaList getAkaList() {
        return akaList;
    }

    /**
     * Sets the value of the akaList property.
     * 
     * @param value
     *     allowed object is
     *     {@link SdnList.SdnEntry.AkaList }
     *     
     */
    public void setAkaList(AkaList value) {
        this.akaList = value;
    }

    /**
     * Gets the value of the addressList property.
     * 
     * @return
     *     possible object is
     *     {@link SdnList.SdnEntry.AddressList }
     *     
     */
    public AddressList getAddressList() {
        return addressList;
    }

    /**
     * Sets the value of the addressList property.
     * 
     * @param value
     *     allowed object is
     *     {@link SdnList.SdnEntry.AddressList }
     *     
     */
    public void setAddressList(AddressList value) {
        this.addressList = value;
    }

    /**
     * Gets the value of the nationalityList property.
     * 
     * @return
     *     possible object is
     *     {@link SdnList.SdnEntry.NationalityList }
     *     
     */
    public NationalityList getNationalityList() {
        return nationalityList;
    }

    /**
     * Sets the value of the nationalityList property.
     * 
     * @param value
     *     allowed object is
     *     {@link SdnList.SdnEntry.NationalityList }
     *     
     */
    public void setNationalityList(NationalityList value) {
        this.nationalityList = value;
    }

    /**
     * Gets the value of the citizenshipList property.
     * 
     * @return
     *     possible object is
     *     {@link SdnList.SdnEntry.CitizenshipList }
     *     
     */
    public CitizenshipList getCitizenshipList() {
        return citizenshipList;
    }

    /**
     * Sets the value of the citizenshipList property.
     * 
     * @param value
     *     allowed object is
     *     {@link SdnList.SdnEntry.CitizenshipList }
     *     
     */
    public void setCitizenshipList(CitizenshipList value) {
        this.citizenshipList = value;
    }

    /**
     * Gets the value of the dateOfBirthList property.
     * 
     * @return
     *     possible object is
     *     {@link SdnList.SdnEntry.DateOfBirthList }
     *     
     */
    public DateOfBirthList getDateOfBirthList() {
        return dateOfBirthList;
    }

    /**
     * Sets the value of the dateOfBirthList property.
     * 
     * @param value
     *     allowed object is
     *     {@link SdnList.SdnEntry.DateOfBirthList }
     *     
     */
    public void setDateOfBirthList(DateOfBirthList value) {
        this.dateOfBirthList = value;
    }

    /**
     * Gets the value of the placeOfBirthList property.
     * 
     * @return
     *     possible object is
     *     {@link SdnList.SdnEntry.PlaceOfBirthList }
     *     
     */
    public PlaceOfBirthList getPlaceOfBirthList() {
        return placeOfBirthList;
    }

    /**
     * Sets the value of the placeOfBirthList property.
     * 
     * @param value
     *     allowed object is
     *     {@link SdnList.SdnEntry.PlaceOfBirthList }
     *     
     */
    public void setPlaceOfBirthList(PlaceOfBirthList value) {
        this.placeOfBirthList = value;
    }

    /**
     * Gets the value of the vesselInfo property.
     * 
     * @return
     *     possible object is
     *     {@link SdnList.SdnEntry.VesselInfo }
     *     
     */
    public VesselInfo getVesselInfo() {
        return vesselInfo;
    }

    /**
     * Sets the value of the vesselInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link SdnList.SdnEntry.VesselInfo }
     *     
     */
    public void setVesselInfo(VesselInfo value) {
        this.vesselInfo = value;
    }


    

}
