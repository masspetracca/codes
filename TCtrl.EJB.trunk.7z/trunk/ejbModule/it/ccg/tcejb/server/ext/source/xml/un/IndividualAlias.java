package it.ccg.tcejb.server.ext.source.xml.un;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{}QUALITY"/>
 *         &lt;element ref="{}ALIAS_NAME"/>
 *         &lt;element ref="{}DATE_OF_BIRTH" minOccurs="0"/>
 *         &lt;element ref="{}CITY_OF_BIRTH" minOccurs="0"/>
 *         &lt;element ref="{}COUNTRY_OF_BIRTH" minOccurs="0"/>
 *         &lt;element ref="{}NOTE" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "quality",
    "aliasname",
    "dateofbirth",
    "cityofbirth",
    "countryofbirth",
    "note"
})
@XmlRootElement(name = "INDIVIDUAL_ALIAS")
public class IndividualAlias {

    @XmlElement(name = "QUALITY", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String quality;
    @XmlElement(name = "ALIAS_NAME", required = true)
    protected String aliasname;
    @XmlElement(name = "DATE_OF_BIRTH")
    protected String dateofbirth;
    @XmlElement(name = "CITY_OF_BIRTH")
    protected String cityofbirth;
    @XmlElement(name = "COUNTRY_OF_BIRTH")
    protected String countryofbirth;
    @XmlElement(name = "NOTE")
    protected String note;

    /**
     * Gets the value of the quality property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQUALITY() {
        return quality;
    }

    /**
     * Sets the value of the quality property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQUALITY(String value) {
        this.quality = value;
    }

    /**
     * Gets the value of the aliasname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getALIASNAME() {
        return aliasname;
    }

    /**
     * Sets the value of the aliasname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setALIASNAME(String value) {
        this.aliasname = value;
    }

    /**
     * Gets the value of the dateofbirth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDATEOFBIRTH() {
        return dateofbirth;
    }

    /**
     * Sets the value of the dateofbirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDATEOFBIRTH(String value) {
        this.dateofbirth = value;
    }

    /**
     * Gets the value of the cityofbirth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCITYOFBIRTH() {
        return cityofbirth;
    }

    /**
     * Sets the value of the cityofbirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCITYOFBIRTH(String value) {
        this.cityofbirth = value;
    }

    /**
     * Gets the value of the countryofbirth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOUNTRYOFBIRTH() {
        return countryofbirth;
    }

    /**
     * Sets the value of the countryofbirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOUNTRYOFBIRTH(String value) {
        this.countryofbirth = value;
    }

    /**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNOTE() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNOTE(String value) {
        this.note = value;
    }

}