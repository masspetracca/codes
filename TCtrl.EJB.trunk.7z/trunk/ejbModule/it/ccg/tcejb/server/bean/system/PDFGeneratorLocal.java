package it.ccg.tcejb.server.bean.system;

import it.ccg.tcejb.server.bean.entity.TctCorrLstEntity;
import it.ccg.tcejb.server.bean.entity.TctCorrisp;
import it.ccg.tcejb.server.bean.entity.TctCorrispEntity;
import it.ccg.tcejb.server.bean.entity.TctRunRegEntity;
import it.ccg.tcejb.server.exception.BackEndException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Map;

import javax.ejb.Local;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;

@Local
public interface PDFGeneratorLocal {

		public Document generatePdf(List<TctCorrisp> corrispList,TctRunRegEntity runregList/*,int companyId,String runId*/,String path)  throws  MalformedURLException, BadElementException,IOException, DocumentException, BackEndException;
		public Document generateRunregPdf(TctRunRegEntity runregList,/*int companyId,String runId,*/String path)  throws  MalformedURLException, BadElementException,IOException, DocumentException, BackEndException;
		public Document generateCorrLstPdf(List<TctCorrLstEntity> corrList,/*int companyId,*/ String userName,String path, String clientName)  throws  MalformedURLException, BadElementException,IOException, DocumentException, BackEndException;
			
}
