package it.ccg.tcejb.server.bean.entity.ofac;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTOFVSINF database table.
 * 
 */
@Entity
@Table(name="TCTOFVSINF")
@NamedQueries({
	@NamedQuery(name="deleteOfVssinfEveryEntity", query="DELETE FROM TctOfVsInfEntity"),
	@NamedQuery(name="getOfVssInfEntitiesById", query="SELECT entity FROM TctOfVsInfEntity entity WHERE entity.id.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctOfVsInfEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@EmbeddedId
	private TctOfVsInfEntityPK id;

	@Column(length=100)
	private String callSign;

	private int gregTonn;

	private int tonnage;

	@Column(length=100)
	private String vesselFlag;

	@Column(length=100)
	private String vesselOwne;

	@Column(length=100)
	private String vesselType;

	//bi-directional many-to-one association to TctOfEntitEntity
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	private TctOfEntitEntity tctofentit;

    public TctOfVsInfEntity() {
    }

	public TctOfVsInfEntityPK getId() {
		return this.id;
	}

	public void setId(TctOfVsInfEntityPK id) {
		this.id = id;
	}
	
	public String getCallSign() {
		return this.callSign;
	}

	public void setCallSign(String callSign) {
		if (callSign != null && callSign.length()>100){
			ejbLogger.debug(callSign+" >100 than truncate");
			this.callSign = callSign.substring(0, 99);
		}else{
			this.callSign = callSign;
		}
	}

	public int getGregTonn() {
		return this.gregTonn;
	}

	public void setGregTonn(int gregTonn) {
		this.gregTonn = gregTonn;
	}

	public int getTonnage() {
		return this.tonnage;
	}

	public void setTonnage(int tonnage) {
		this.tonnage = tonnage;
	}

	public String getVesselFlag() {
		return this.vesselFlag;
	}

	public void setVesselFlag(String vesselFlag) {
		if (vesselFlag != null && vesselFlag.length()>100){
			ejbLogger.debug(vesselFlag+" >100 than truncate");
			this.vesselFlag = vesselFlag.substring(0, 99);
		}else{
			this.vesselFlag = vesselFlag;
		}
	}

	public String getVesselOwne() {
		return this.vesselOwne;
	}

	public void setVesselOwne(String vesselOwne) {
		if (vesselOwne != null && vesselOwne.length()>100){
			ejbLogger.debug(vesselOwne+" >100 than truncate");
			this.vesselOwne = vesselOwne.substring(0, 99);
		}else{
			this.vesselOwne = vesselOwne;
		}
	}

	public String getVesselType() {
		return this.vesselType;
	}

	public void setVesselType(String vesselType) {
		if (vesselType != null && vesselType.length()>100){
			ejbLogger.debug(vesselType+" >100 than truncate");
			this.vesselType = vesselType.substring(0, 99);
		}else{
			this.vesselType = vesselType;
		}
	}

	public TctOfEntitEntity getTctofentit() {
		return this.tctofentit;
	}

	public void setTctofentit(TctOfEntitEntity tctofentit) {
		this.tctofentit = tctofentit;
	}
	
}