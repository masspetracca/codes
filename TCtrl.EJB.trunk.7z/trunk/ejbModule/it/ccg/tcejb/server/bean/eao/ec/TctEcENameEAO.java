package it.ccg.tcejb.server.bean.eao.ec;

import it.ccg.tcejb.server.bean.entity.ec.TctEcENameEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctECEName
 */
@Stateless
@LocalBean
public class TctEcENameEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctEcENameEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctEcENameEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in nsertEntity(TctEcENameEntity entity)"));
	    	ejbLogger.info(new StandardLogMessage("TctEcENameEntity identification data: EC Entity code = "+entity.getId().getEntityid() +" , name id = "+entity.getId().getNameId()));
    		ejbLogger.debug(new StandardLogMessage(entity.getId().getEntityid() +"  "+entity.getId().getNameId()+"  "+entity.getFirstName()+"  "+entity.getFunction()+"  "+entity.getGender()+"  "+entity.getLanguage()+"  "+entity.getLastName()
    				+"  "+entity.getLegalBasis()+"  "+entity.getMiddleName()+"  "+entity.getPdfLink()+"  "+entity.getTitle()+"  "+entity.getWholeName()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public void insertEntity(Set<TctEcENameEntity> entities) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("insertEntity(Set<TctEcENameEntity> entities)"));
	    	for (TctEcENameEntity entity : entities){
	    		ejbLogger.info(new StandardLogMessage("TctEcENameEntity identification data: EC Entity code = "+entity.getId().getEntityid() +" , name id = "+entity.getId().getNameId()));
	    		ejbLogger.debug(new StandardLogMessage("id "+entity.getId().getEntityid() +" entity id "+entity.getId().getNameId()+" first name "+entity.getFirstName()+" function "+entity.getFunction()+" gender "+entity.getGender()+" Language "+entity.getLanguage()+" last name "+entity.getLastName()
	    				+" legalbasis "+entity.getLegalBasis()+" middlename "+entity.getMiddleName()+" pdf link "+entity.getPdfLink()+" title "+entity.getTitle()+" wholename "+entity.getWholeName()));
		    	
		    	this.manager.persist(entity);
	    	}
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	this.manager.flush();
	    	
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
  	public void deleteEntity(TctEcENameEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctEcENameEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcENameEntity identification data: EC Entity code = "+entity.getId().getEntityid() +" , name id = "+entity.getId().getNameId()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void deleteEveryEntity() throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteEcNamePtEveryEntity");
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	this.manager.flush();
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctEcENameEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctEcENameEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcENameEntity identification data: EC Entity code = "+entity.getId().getEntityid() +" , citizen id = "+entity.getId().getNameId()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	@SuppressWarnings("unchecked")
	public  List<TctEcENameEntity> retrieveEntityNameByEntId(int entityId) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<TctEcENameEntity> retrieveEntityNameByEntId(int entityId)"));
	    	ejbLogger.debug(new StandardLogMessage("ecEntityId "+entityId));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getEcNamePtEntitiesById");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("entityId", entityId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	List<TctEcENameEntity> ecNameEntities = (List<TctEcENameEntity>) q.getResultList();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return ecNameEntities;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
}
