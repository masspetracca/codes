package it.ccg.tcejb.server.bean.entity.un;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;


/**
 * The persistent class for the TCTUNLSTUP database table.
 * 
 */
@Entity
@Table(name="TCTUNLSTUP")
@NamedQueries({
	@NamedQuery(name="deleteUnLtUpEveryEntity", query="DELETE FROM TctUnLstUp"),
	@NamedQuery(name="getUnLtUpEntitiesById", query="SELECT entity FROM TctUnLstUp entity WHERE entity.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctUnLstUp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LSTDTUDPID")
	private int lstDtUdpId;

	@Column(nullable=false)
	private int entityid;
	
    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date value;

	//bi-directional many-to-one association to TctUnEntit
    @ManyToOne
	@JoinColumn(name="ENTITYID", insertable=false, updatable=false)
    //@Transient
	private TctUnEntit tctunentit;

	//bi-directional many-to-one association to TctUnIndiv
    @ManyToOne
	@JoinColumn(name="ENTITYID", insertable=false, updatable=false)
    //@Transient
	private TctUnIndiv tctunindiv;

    public TctUnLstUp() {
    }
    
	/**
	 * @return the lstDtUdpId
	 */
	public int getLstDtUdpId() {
		return lstDtUdpId;
	}

	/**
	 * @param lstDtUdpId the lstDtUdpId to set
	 */
	public void setLstDtUdpId(int lstDtUdpId) {
		this.lstDtUdpId = lstDtUdpId;
	}

	/**
	 * @return the entityid
	 */
	public int getEntityid() {
		return entityid;
	}

	/**
	 * @param entityid the entityid to set
	 */
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}
	
	/**
	 * 
	 * @return
	 */
	public Date getValue() {
		return this.value;
	}

	/**
	 * 
	 * @param value
	 */
	public void setValue(Date value) {
		this.value = value;
	}

	/**
	 * 
	 * @return
	 */
	public TctUnEntit getTctunentit() {
		return this.tctunentit;
	}

	/**
	 * 
	 * @param tctunentit
	 */
	public void setTctunentit(TctUnEntit tctunentit) {
		this.tctunentit = tctunentit;
	}
	
	/**
	 * 
	 * @return
	 */
	public TctUnIndiv getTctunindiv() {
		return this.tctunindiv;
	}

	/**
	 * 
	 * @param tctunindiv
	 */
	public void setTctunindiv(TctUnIndiv tctunindiv) {
		this.tctunindiv = tctunindiv;
	}
	
}