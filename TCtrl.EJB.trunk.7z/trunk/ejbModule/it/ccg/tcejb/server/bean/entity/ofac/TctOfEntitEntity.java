package it.ccg.tcejb.server.bean.entity.ofac;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TCTOFENTIT database table.
 * 
 */
@Entity
@Table(name="TCTOFENTIT")
@NamedQueries({
	@NamedQuery(name="getOfEntitiesById", query="SELECT entity FROM TctOfEntitEntity entity WHERE entity.entityId = :entityId ORDER BY entity.lastName ASC"),
	@NamedQuery(name="getOfEntities", query="SELECT entity FROM TctOfEntitEntity entity ORDER BY entity.lastName ASC"),
	@NamedQuery(name="getOfEntitiesBySrcListDate", query="SELECT entity " +
			   "										 FROM TctOfEntitEntity entity " +
			   "										WHERE entity.srcListDate = :srcListDate " +
			   "										  AND entity.sdnType = 'Entity'" +
			   " 										ORDER BY entity.lastName ASC"),
    @NamedQuery(name="getOfPeopleBySrcListDate", query="SELECT entity " +
		       "										 FROM TctOfEntitEntity entity " +
		       "										WHERE entity.srcListDate = :srcListDate " +
		       "										  AND entity.sdnType = 'Individual'" +
		       " 										ORDER BY entity.lastName ASC"),
    @NamedQuery(name="getOfLatestSrcListDate",    query="SELECT MAX(entity.srcListDate) " +
	           "										 FROM TctOfEntitEntity entity"),
	/*
	 * raffaele de lauri
	 * TN_CCG15298
	 */
    @NamedQuery(name="getOfLatestEntities", query="SELECT entity " +
		       "								   FROM TctOfEntitEntity entity " +
		       "								  WHERE entity.sdnType = 'Entity' " +
		       "									AND entity.srcListDate = (SELECT MAX(entity2.srcListDate) " +
	           "										 						FROM TctOfEntitEntity entity2" +
	           "															   WHERE entity2.sdnType = 'Entity')" +
		       " 								  ORDER BY entity.lastName ASC"),
	@NamedQuery(name="getOfLatestPeople",   query="SELECT entity " +
               "								   FROM TctOfEntitEntity entity " +
               "								  WHERE entity.sdnType = 'Individual' " +
               "								    AND entity.srcListDate = (SELECT MAX(entity2.srcListDate) " +
               "								 							    FROM TctOfEntitEntity entity2" +
               "															   WHERE entity2.sdnType = 'Individual'" +
               "															     AND entity2.entityId = entity.entityId)" +
 		       "								  ORDER BY entity.lastName ASC"),
    @NamedQuery(name="deleteOfEveryEntity", query="DELETE FROM TctOfEntitEntity"),
})
public class TctOfEntitEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@Id
	@Column(unique=true, nullable=false)
	private int entityId;

	@Column(length=250)
	private String firstName;

	@Column(nullable=false, length=250)
	private String lastName;

	@Column(length=31000)
	private String remarks;

	@Column(nullable=false, length=30)
	private String sdnType;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date srcListDate;

	@Column(length=250)
	private String title;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	//bi-directional many-to-one association to TctOfAddrEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctofentit")
	private Set<TctOfAddrEntity> tctofaddrs;

	//bi-directional many-to-one association to TctOfAkaAliasEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctofentit")
	private Set<TctOfAkaAliasEntity> tctofakaals;

	//bi-directional many-to-one association to TctOfBirthEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctofentit")
	private Set<TctOfBirthEntity> tctofbirths;

	//bi-directional many-to-one association to TctOfCitzEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctofentit")
	private Set<TctOfCitzEntity> tctofcitzs;

	//bi-directional many-to-one association to TctOfDtBirEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctofentit")
	private Set<TctOfDtBirEntity> tctofdtbirs;

	//bi-directional many-to-one association to TctOfIdLstEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctofentit")
	private Set<TctOfIdLstEntity> tctofidlsts;

	//bi-directional many-to-one association to TctOfNatnEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctofentit")
	private Set<TctOfNatnEntity> tctofnatns;

	//bi-directional many-to-one association to TctOfPrglEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctofentit")
	private Set<TctOfPrglEntity> tctofprgls;

	//bi-directional many-to-one association to TctOfVsInfEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctofentit")
	private Set<TctOfVsInfEntity> tctofvsinfs;

    public TctOfEntitEntity() {
    }

	public int getEntityId() {
		return this.entityId;
	}

	public void setEntityId(int entityId) {
		this.entityId = entityId;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		if (firstName != null && firstName.length()>250){
			ejbLogger.debug(firstName+" >250 than truncate");
			this.firstName = firstName.substring(0, 249);
		}else{
			this.firstName = firstName;
		}
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		if (lastName != null && lastName.length()>250){
			ejbLogger.debug(lastName+" >250 than truncate");
			this.lastName = lastName.substring(0, 249);
		}else{
			this.lastName = lastName;
		}
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		if (remarks != null && remarks.length()>31000){
			ejbLogger.debug(remarks+" >31000 than truncate");
			this.remarks = remarks.substring(0, 30999);
		}else{
			this.remarks = remarks;
		}
	}

	public String getSdnType() {
		return this.sdnType;
	}

	public void setSdnType(String sdnType) {
		if (sdnType != null && sdnType.length()>30){
			ejbLogger.debug(sdnType+" >30 than truncate");
			this.sdnType = sdnType.substring(0, 29);
		}else{
			this.sdnType = sdnType;
		}
	}

	public Date getSrcListDate() {
		return this.srcListDate;
	}

	public void setSrcListDate(Date srcListDate) {
		this.srcListDate = srcListDate;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		if (title != null && title.length()>250){
			ejbLogger.debug(title+" >250 than truncate");
			this.title = title.substring(0, 249);
		}else{
			this.title = title;
		}
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public Set<TctOfAddrEntity> getTctofaddrs() {
		return this.tctofaddrs;
	}

	public void setTctofaddrs(Set<TctOfAddrEntity> tctofaddrs) {
		this.tctofaddrs = tctofaddrs;
	}
	
	public Set<TctOfAkaAliasEntity> getTctofakaals() {
		return this.tctofakaals;
	}

	public void setTctofakaals(Set<TctOfAkaAliasEntity> tctofakaals) {
		this.tctofakaals = tctofakaals;
	}
	
	public Set<TctOfBirthEntity> getTctofbirths() {
		return this.tctofbirths;
	}

	public void setTctofbirths(Set<TctOfBirthEntity> tctofbirths) {
		this.tctofbirths = tctofbirths;
	}
	
	public Set<TctOfCitzEntity> getTctofcitzs() {
		return this.tctofcitzs;
	}

	public void setTctofcitzs(Set<TctOfCitzEntity> tctofcitzs) {
		this.tctofcitzs = tctofcitzs;
	}
	
	public Set<TctOfDtBirEntity> getTctofdtbirs() {
		return this.tctofdtbirs;
	}

	public void setTctofdtbirs(Set<TctOfDtBirEntity> tctofdtbirs) {
		this.tctofdtbirs = tctofdtbirs;
	}
	
	public Set<TctOfIdLstEntity> getTctofidlsts() {
		return this.tctofidlsts;
	}

	public void setTctofidlsts(Set<TctOfIdLstEntity> tctofidlsts) {
		this.tctofidlsts = tctofidlsts;
	}
	
	public Set<TctOfNatnEntity> getTctofnatns() {
		return this.tctofnatns;
	}

	public void setTctofnatns(Set<TctOfNatnEntity> tctofnatns) {
		this.tctofnatns = tctofnatns;
	}
	
	public Set<TctOfPrglEntity> getTctofprgls() {
		return this.tctofprgls;
	}

	public void setTctofprgls(Set<TctOfPrglEntity> tctofprgls) {
		this.tctofprgls = tctofprgls;
	}
	
	public Set<TctOfVsInfEntity> getTctofvsinfs() {
		return this.tctofvsinfs;
	}

	public void setTctofvsinfs(Set<TctOfVsInfEntity> tctofvsinfs) {
		this.tctofvsinfs = tctofvsinfs;
	}
	
}