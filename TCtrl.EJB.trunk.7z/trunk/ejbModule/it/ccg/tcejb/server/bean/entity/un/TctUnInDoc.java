package it.ccg.tcejb.server.bean.entity.un;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTUNINDOC database table.
 * 
 */
@Entity
@Table(name="TCTUNINDOC")
@NamedQueries({
	@NamedQuery(name="deleteUnIndDocEveryEntity", query="DELETE FROM TctUnInDoc"),
	@NamedQuery(name="getUnIndDocEntitiesById", query="SELECT entity FROM TctUnInDoc entity WHERE entity.entityid = :entityId ORDER BY entity.addressId ASC")
})
public class TctUnInDoc implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private int documentId;

	@Column(nullable=false)
	private int entityId;
	
	@Column(length=255)
	private String cityIss;

	@Column(length=255)
	private String countryIss;

    @Temporal( TemporalType.DATE)
	private Date dateIss;

	@Column(length=255)
	private String issCountry;

	@Column(length=1000)
	private String note;

	@Column(length=255)
	private String number;

	@Column(length=255)
	private String typeOfDoc;

	@Column(length=255)
	private String typeOfDoc2;
	
	@ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	//@Transient
	private TctUnIndiv tctunindiv;
	
    public TctUnInDoc() {
    }

    /**
     * 
     * @return
     */
	public int getDocumentId() {
		return this.documentId;
	}

	/**
	 * 
	 * @param documentId
	 */
	public void setDocumentId(int documentId) {
		this.documentId = documentId;
	}

	public int getEntityId() {
		return this.entityId;
	}

	public void setEntityId(int entityId) {
		this.entityId = entityId;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getCityIss() {
		return this.cityIss;
	}

	/**
	 * 
	 * @param cityIss
	 */
	public void setCityIss(String cityIss) {
		if (cityIss !=null && cityIss.length()>255){
			ejbLogger.debug(cityIss+" >255 than truncate");
			this.cityIss = cityIss.substring(0, 254);
		}else{
			this.cityIss = cityIss;
		}
	}
	
	/**
	 * 
	 * @return
	 */
	public String getCountryIss() {
		return this.countryIss;
	}

	/**
	 * 
	 * @param countryIss
	 */
	public void setCountryIss(String countryIss) {
		if (countryIss !=null && countryIss.length()>255){
			ejbLogger.debug(countryIss+" >255 than truncate");
			this.countryIss = countryIss.substring(0, 254);
		}else{
			this.countryIss = countryIss;
		}
	}
	
	/**
	 * 
	 * @return
	 */
	public Date getDateIss() {
		return this.dateIss;
	}

	/**
	 * 
	 * @param dateIss
	 */
	public void setDateIss(Date dateIss) {
		this.dateIss = dateIss;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getIssCountry() {
		return this.issCountry;
	}

	/**
	 * 
	 * @param issCountry
	 */
	public void setIssCountry(String issCountry) {
		if (issCountry !=null && issCountry.length()>255){
			ejbLogger.debug(issCountry+" >255 than truncate");
			this.issCountry = issCountry.substring(0, 254);
		}else{
			this.issCountry = issCountry;
		}
	}
	
	/**
	 * 
	 * @return
	 */
	public String getNumber() {
		return this.number;
	}

	/**
	 * 
	 * @param number
	 */
	public void setNumber(String number) {
		if (number !=null && number.length()>255){
			ejbLogger.debug(number+" >255 than truncate");
			this.number = number.substring(0, 254);
		}else{
			this.number = number;
		}
	}

	/**
	 * 
	 * @return
	 */
	public String getTypeOfDoc() {
		return this.typeOfDoc;
	}

	/**
	 * 
	 * @param typeOfDoc
	 */
	public void setTypeOfDoc(String typeOfDoc) {
		if (typeOfDoc !=null && typeOfDoc.length()>255){
			ejbLogger.debug(number+" >255 than truncate");
			this.typeOfDoc = typeOfDoc.substring(0, 254);
		}else{
			this.typeOfDoc = typeOfDoc;
		}
	}

	/**
	 * 
	 * @return
	 */
	public String getTypeOfDoc2() {
		return this.typeOfDoc2;
	}

	/**
	 * 
	 * @param typeOfDoc2
	 */
	public void setTypeOfDoc2(String typeOfDoc2) {
		if (typeOfDoc2 !=null && typeOfDoc2.length()>255){
			ejbLogger.debug(typeOfDoc2+" >255 than truncate");
			this.typeOfDoc2 = typeOfDoc2.substring(0, 254);
		}else{
			this.typeOfDoc2 = typeOfDoc2;
		}
	}
	/**
	 * @return the tctunindiv
	 */
	public TctUnIndiv getTctunindiv() {
		return tctunindiv;
	}

	/**
	 * @param tctunindiv the tctunindiv to set
	 */
	public void setTctunindiv(TctUnIndiv tctunindiv) {
		this.tctunindiv = tctunindiv;
	}

	/**
	 * @return the note
	 */
	public String getNote() {
		return note;
	}

	/**
	 * @param note the note to set
	 */
	public void setNote(String note) {
		if (note !=null && note.length()>1000){
			ejbLogger.debug(number+" >1000 than truncate");
			this.note = note.substring(0, 999);
		}else{
			this.note = note;
		}
	}
	
}