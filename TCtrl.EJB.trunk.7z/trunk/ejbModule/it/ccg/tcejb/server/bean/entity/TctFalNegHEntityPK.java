package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTFALNEGH database table.
 * 
 */
@Embeddable
public class TctFalNegHEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int runid;

	@Column(unique=true, nullable=false)
	private int clntid;

	@Column(unique=true, nullable=false, length=16)
	private String aggrid;

	@Column(unique=true, nullable=false)
	private int compnid;

	@Column(unique=true, nullable=false)
	private int downloadid;
	
    public TctFalNegHEntityPK() {
    }
	public int getRunid() {
		return this.runid;
	}
	public void setRunid(int runid) {
		this.runid = runid;
	}
	public int getClntid() {
		return this.clntid;
	}
	public void setClntid(int clntid) {
		this.clntid = clntid;
	}
	public String getAggrid() {
		return this.aggrid;
	}
	public void setAggrid(String aggrid) {
		this.aggrid = aggrid;
	}
	public int getCompnid() {
		return this.compnid;
	}
	public void setCompnid(int compnid) {
		this.compnid = compnid;
	}

	/**
	 * @return the downloadid
	 */
	public int getDownloadid() {
		return downloadid;
	}
	/**
	 * @param downloadid the downloadid to set
	 */
	public void setDownloadid(int downloadid) {
		this.downloadid = downloadid;
	}
	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctFalNegHEntityPK)) {
			return false;
		}
		TctFalNegHEntityPK castOther = (TctFalNegHEntityPK)other;
		return 
			(this.runid == castOther.runid)
			&& (this.clntid == castOther.clntid)
			&& this.aggrid.equals(castOther.aggrid)
			&& (this.compnid == castOther.compnid)
			&& (this.downloadid == castOther.downloadid);
	
    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.runid;
		hash = hash * prime + this.clntid;
		hash = hash * prime + this.aggrid.hashCode();
		hash = hash * prime + this.compnid;
		hash = hash * prime + this.downloadid;
		return hash;
    }
}