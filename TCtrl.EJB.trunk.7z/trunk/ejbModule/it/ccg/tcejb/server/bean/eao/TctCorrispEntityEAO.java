package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctCorrisp;
import it.ccg.tcejb.server.bean.entity.TctCorrispEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.TreeSet;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctCorrispEntityEAO
 */
@Stateless
@LocalBean
public class TctCorrispEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;

	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	/**
	 * Default constructor. 
	 */
	public TctCorrispEntityEAO() {
		// TODO Auto-generated constructor stub
	}

	public void insertEntity(TctCorrispEntity entity) throws BackEndException{
		try{
			ejbLogger.debug(new StandardLogMessage("in insertEntity(TctCorrispEntity entity)"));
			ejbLogger.debug(new StandardLogMessage("TctCorrispEntity identification data: client id = "+entity.getId().getClntid() +" , company id = "+entity.getId().getCmpnid()+" , aggregated id= "+entity.getId().getAggrId()+" , run id= "+entity.getId().getRunId()));
			ejbLogger.debug(new StandardLogMessage("insert"));
			entity.setUpdDate(new Timestamp(new Date().getTime()));
			entity.setUpdType("C");
			entity.setUpdUser(sessionContext.getCallerPrincipal().getName());

			this.manager.persist(entity);
			this.manager.flush();
		}catch(Exception e){
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
		ejbLogger.debug(new StandardLogMessage("inserted"));	
	}

	public void insertEntity(List<TctCorrispEntity> entities) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in insertEntity(List<TctCorrispEntity> entities)"));
		int idxToFlush = 0;
		for (TctCorrispEntity entity :entities){
			ejbLogger.debug(new StandardLogMessage("TctCorrispEntity identification data: client id = "+entity.getId().getClntid() +" , company id = "+entity.getId().getCmpnid()+" , aggregated id= "+entity.getId().getAggrId()+" , run id= "+entity.getId().getRunId()));
			ejbLogger.debug(new StandardLogMessage("insert"));
			entity.setUpdDate(new Timestamp(new Date().getTime()));
			entity.setUpdType("C");
			entity.setUpdUser(sessionContext.getCallerPrincipal().getName());

			this.manager.persist(entity);
			idxToFlush++;
			if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
				ejbLogger.debug(new StandardLogMessage("insert"));
				this.manager.flush();
			}
		}
		ejbLogger.debug(new StandardLogMessage("last insert"));
		this.manager.flush();
	}

	public void deleteEntity(TctCorrispEntity entity) throws BackEndException{
		try{
			ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctCorrispEntity entity)"));
			ejbLogger.debug(new StandardLogMessage("TctCorrispEntity identification data: client id = "+entity.getId().getClntid() +" , company id = "+entity.getId().getCmpnid()+" , aggregated id= "+entity.getId().getAggrId()+" , run id= "+entity.getId().getRunId()));
			ejbLogger.debug(new StandardLogMessage("delete"));
			this.manager.remove(entity);
			ejbLogger.debug(new StandardLogMessage("deleted"));
		}catch(Exception e){
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}

	public void updateEntity(TctCorrispEntity entity) throws BackEndException{
		try{
			ejbLogger.debug(new StandardLogMessage("in updateEntity(TctClientEntity entity)"));
			ejbLogger.debug(new StandardLogMessage("TctCorrispEntity identification data: client id = "+entity.getId().getClntid() +" , company id = "+entity.getId().getCmpnid()+" , aggregated id= "+entity.getId().getAggrId()+" , run id= "+entity.getId().getRunId()));
			ejbLogger.debug(new StandardLogMessage("update"));
			entity.setUpdDate(new Timestamp(new Date().getTime()));
			entity.setUpdType("U");
			entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
			this.manager.merge(entity);
			ejbLogger.debug(new StandardLogMessage("updated"));
		}catch(Exception e){
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}

	@SuppressWarnings("unchecked")
	public TreeSet<String> retrieveFPositiveByCompanyID(int companyId) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in TreeSet<String> retrieveFPositiveByCompanyID(int companyId)"));
		ejbLogger.debug(new StandardLogMessage("Company id "+companyId));
		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
		Query q = this.manager.createNamedQuery("getFPositiveByCmpnId");
		ejbLogger.debug(new StandardLogMessage("populate named query"));
		q.setParameter("cmpnId", companyId);

		ejbLogger.debug(new StandardLogMessage("getResultList"));
		List<TctCorrispEntity> corrisps = (List<TctCorrispEntity>) q.getResultList();
		TreeSet<String> result = new TreeSet<String>();
		for (TctCorrispEntity c : corrisps){
			result.add(c.getClntName()+"-"+c.getEntityName());
		}

		ejbLogger.debug(new StandardLogMessage("return"));
		return result;

	}
	//********************AGGIUNTA*****************
	/*public List<TctCorrispEntity> retrieveByRunIdAndCmpnId(int runId,int companyId) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in retrieveByRunId(int runId,int companyId)"));
	//ejbLogger.debug(new StandardLogMessage("Run date "+df.format(new Date(entity.getRunDate().getTime()))));
	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	Query q = this.manager.createNamedQuery("getByRunId");
	ejbLogger.debug(new StandardLogMessage("populate named query"));
	q.setParameter("runId", runId);
	q.setParameter("cmpnId", companyId);

	ejbLogger.debug(new StandardLogMessage("getResultList"));
	List<TctCorrispEntity> run = (List<TctCorrispEntity>) q.getResultList();
	ejbLogger.debug(new StandardLogMessage("return"));
	return run;
	}*/

	public List<TctCorrisp> retrieveByRunIdAndCmpnId(int runId,int companyId) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("createNativeQuery"));

		Query query = null;

		String sqlString =  "SELECT corr.*,aggr.ENTITYID, aggr.SRCLIST, run.UPDUSER as USER, run.SUBDATE, run.RUNDATE " +
				" FROM TCTCORRISP corr" +
				" INNER JOIN TCTAGGRENT aggr" +
				" ON corr.AGGRID=aggr.AGGREGID AND corr.DOWNLOADID=aggr.DOWNLOADID" +
				" INNER JOIN TCTRUNREG as run" +
				" ON corr.CMPNID=run.CMPNID AND corr.RUNID=run.RUNID" +
				" WHERE corr.RUNID  = "+ runId +
				" AND corr.cmpnid  = " + companyId +
				" AND corr.STATUS <> 'D' ORDER BY CORR.STATUS DESC";

		ejbLogger.debug(new StandardLogMessage(sqlString));
		query =  this.manager.createNativeQuery(sqlString,TctCorrisp.class);
		ejbLogger.debug(new StandardLogMessage("getResultList"));
		List<TctCorrisp> run = (List<TctCorrisp>) query.getResultList();
		ejbLogger.debug(new StandardLogMessage("return"));
		
		return run;
	}
	/*Query query = null;

		String date = GenericTools.shortDateFormatShifter(lastDate, 0, 1);

		String libraryName = this.getLibraryName(date);

		String equityCompart = "'NET', 'DER', 'MTA', 'IDEM'";
		String from = "FROM "+libraryName+"CMPMRG00F WHERE CMDATRIF = '"+date+"' ";

		String sqlString =  "SELECT 'E' AS SEGMENT, SUM(CMINTM) AS TOTALMARGIN "+
							from+
							"AND CMSTLGID IN ("+equityCompart+") "+
							"UNION "+
							"SELECT "+
							"CASE WHEN CMSTLGID='BOND' THEN 'O' ELSE "+
							"CASE WHEN CMSTLGID='IDEX' THEN 'L' ELSE "+
							"CASE WHEN CMSTLGID='AGRX' THEN 'W' "+
							"END "+
							"END "+
							"END AS SEGMENT, SUM(CMINTM) AS TOTALMARGIN "+
							from+
							"AND CMSTLGID NOT IN ("+equityCompart+",'MIC') "+
							"GROUP BY CMSTLGID ";

		querylog.debug(sqlString);

		try {
			query =  em.createNativeQuery(sqlString,IntracsMargins.class);
			List<IntracsMargins> intracsMarginList = query.getResultList();
			return intracsMarginList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}*/
}
