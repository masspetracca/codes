package it.ccg.tcejb.server.bean.entity.ofac;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTOFBIRTH database table.
 * 
 */
@Entity
@Table(name="TCTOFBIRTH")
@NamedQueries({
	@NamedQuery(name="deleteOfBirthPlcEveryEntity", query="DELETE FROM TctOfBirthEntity"),
	@NamedQuery(name="getOfBirthPlcEntitiesById", query="SELECT entity FROM TctOfBirthEntity entity WHERE entity.id.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctOfBirthEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@EmbeddedId
	private TctOfBirthEntityPK id;

	@Column(length=50)
	private String mainEntry;

	@Column(name="PLACEBIRRTH", nullable=false, length=255)
	private String placeBirth;

	//bi-directional many-to-one association to TctOfEntitEntity
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	private TctOfEntitEntity tctofentit;

    public TctOfBirthEntity() {
    }

	public TctOfBirthEntityPK getId() {
		return this.id;
	}

	public void setId(TctOfBirthEntityPK id) {
		this.id = id;
	}
	
	public String getMainEntry() {
		return this.mainEntry;
	}

	public void setMainEntry(String mainEntry) {
		if (mainEntry != null && mainEntry.length()>50){
			ejbLogger.debug(mainEntry+" >50 than truncate");
			this.mainEntry = mainEntry.substring(0, 49);
		}else{
			this.mainEntry = mainEntry;
		}
	}

	public String getPlaceBirth() {
		return this.placeBirth;
	}

	public void setPlaceBirth(String placeBirth) {
		if (placeBirth != null && placeBirth.length()>255){
			ejbLogger.debug(placeBirth+" >255 than truncate");
			this.placeBirth = placeBirth.substring(0, 254);
		}else{
			this.placeBirth = placeBirth;
		}
	}

	public TctOfEntitEntity getTctofentit() {
		return this.tctofentit;
	}

	public void setTctofentit(TctOfEntitEntity tctofentit) {
		this.tctofentit = tctofentit;
	}
	
}