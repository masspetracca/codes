package it.ccg.tcejb.server.bean.entity.ofac;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTOFIDLST database table.
 * 
 */
@Entity
@Table(name="TCTOFIDLST")
@NamedQueries({
	@NamedQuery(name="deleteOfIdListEveryEntity", query="DELETE FROM TctOfIdLstEntity"),
	@NamedQuery(name="getOfIdListEntitiesById", query="SELECT entity FROM TctOfIdLstEntity entity WHERE entity.id.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctOfIdLstEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@EmbeddedId
	private TctOfIdLstEntityPK id;

	@Column(length=100)
	private String expirDate;

	@Column(length=100)
	private String idCountry;

	@Column(length=100)
	private String idNumber;

	@Column(length=100)
	private String idType;

	@Column(length=100)
	private String issueDate;

	//bi-directional many-to-one association to TctOfEntitEntity
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	private TctOfEntitEntity tctofentit;

    public TctOfIdLstEntity() {
    }

	public TctOfIdLstEntityPK getId() {
		return this.id;
	}

	public void setId(TctOfIdLstEntityPK id) {
		this.id = id;
	}
	
	public String getExpirDate() {
		return this.expirDate;
	}

	public void setExpirDate(String expirDate) {
		if (expirDate != null && expirDate.length()>100){
			ejbLogger.debug(expirDate+" >100 than truncate");
			this.expirDate = expirDate.substring(0, 99);
		}else{
			this.expirDate = expirDate;
		}
	}

	public String getIdCountry() {
		return this.idCountry;
	}

	public void setIdCountry(String idCountry) {
		if (idCountry != null && idCountry.length()>100){
			ejbLogger.debug(idCountry+" >100 than truncate");
			this.idCountry = idCountry.substring(0, 99);
		}else{
			this.idCountry = idCountry;
		}
	}

	public String getIdNumber() {
		return this.idNumber;
	}

	public void setIdNumber(String idNumber) {
		if (idNumber != null && idNumber.length()>100){
			ejbLogger.debug(idNumber+" >100 than truncate");
			this.idNumber = idNumber.substring(0, 99);
		}else{
			this.idNumber = idNumber;
		}
	}

	public String getIdType() {
		return this.idType;
	}

	public void setIdType(String idType) {
		if (idType != null && idType.length()>100){
			ejbLogger.debug(idType+" >100 than truncate");
			this.idType = idType.substring(0, 99);
		}else{
			this.idType = idType;
		}
	}

	public String getIssueDate() {
		return this.issueDate;
	}

	public void setIssueDate(String issueDate) {
		if (issueDate != null && issueDate.length()>100){
			ejbLogger.debug(issueDate+" >100 than truncate");
			this.issueDate = issueDate.substring(0, 99);
		}else{
			this.issueDate = issueDate;
		}
	}

	public TctOfEntitEntity getTctofentit() {
		return this.tctofentit;
	}

	public void setTctofentit(TctOfEntitEntity tctofentit) {
		this.tctofentit = tctofentit;
	}
	
}