package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctOptimizEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctOptimizEntityEAO
 */
@Stateless
@LocalBean
public class TctOptimizEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctOptimizEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctOptimizEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctOptimizEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctOptimizEntity identification data: iteration id = "+entity.getId().getItId() +" , jaroWinkler Thrshld = "+entity.getJwThrshld()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	ejbLogger.debug(new StandardLogMessage("flush"));
	    	this.manager.flush();
	    	ejbLogger.debug(new StandardLogMessage("flushed"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));	
    }
        
    public void insertEntity(List<TctOptimizEntity> entities) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in insertEntity(List<TctOptimizEntity> entities)"));
    	int idxToFlush = 0;
    	for (TctOptimizEntity entity :entities){
    		ejbLogger.debug(new StandardLogMessage("TctOptimizEntity identification data: iteration id = "+entity.getId().getItId() +" , jaroWinkler Thrshld = "+entity.getJwThrshld()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	idxToFlush++;
	    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
	    		ejbLogger.debug(new StandardLogMessage("flush "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
		    	this.manager.flush();
		    	ejbLogger.debug(new StandardLogMessage("flushed"));
	    	}
    	}
    	ejbLogger.debug(new StandardLogMessage("flush "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	this.manager.flush();
    	ejbLogger.debug(new StandardLogMessage("flushed"));
    }
    
  	public void deleteEntity(TctOptimizEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctOptimizEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctOptimizEntity identification data: iteration id = "+entity.getId().getItId() +" , jaroWinkler Thrshld = "+entity.getJwThrshld()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctOptimizEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctOptimizEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctOptimizEntity identification data: iteration id = "+entity.getId().getItId() +" , jaroWinkler Thrshld = "+entity.getJwThrshld()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("U");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void deleteEveryEntity() throws BackEndException{
  		try{
  			//cancello i dati anche sulle tabello che fanno rifermento alla Entity    	
	    	ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteEveryOptimization");
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	
	    	this.manager.flush();
	    	this.manager.clear();
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
}
