package it.ccg.tcejb.server.bean.entity.un;


import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TCTUNTITLE database table.
 * 
 */
@Entity
@Table(name="TCTUNTITLE")
@NamedQueries({
	@NamedQuery(name="deleteUnTitleEveryEntity", query="DELETE FROM TctUnTitle")//,
	//@NamedQuery(name="getUnTitleEntitiesById", query="SELECT entity FROM TctUnTitle entity WHERE entity.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctUnTitle implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="TITLEID")
	private int titleId;

	@Column(nullable=false)
	private int entityid;
	
	@Column(length=255)
	private String value;

	//bi-directional many-to-one association to TctUnIndivEntity
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false)
	private TctUnIndiv tctunindiv;

    public TctUnTitle() {
    }

	public int getTitleId() {
		return this.titleId;
	}

	public void setTitleId(int titleId) {
		this.titleId = titleId;
	}

	/**
	 * @return the entityid
	 */
	public int getEntityid() {
		return entityid;
	}

	/**
	 * @param entityid the entityid to set
	 */
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}
	
	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public TctUnIndiv getTctunindiv() {
		return this.tctunindiv;
	}

	public void setTctunindiv(TctUnIndiv tctunindiv) {
		this.tctunindiv = tctunindiv;
	}
	
}