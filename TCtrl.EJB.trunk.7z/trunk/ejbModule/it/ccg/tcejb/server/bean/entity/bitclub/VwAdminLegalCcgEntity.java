package it.ccg.tcejb.server.bean.entity.bitclub;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;

/**
 * Entity implementation class for Entity: VwAdminLegalCcgEntity
 *
 */
@Entity
@NamedNativeQueries({
	@NamedNativeQuery(name="retrieveLegalCcg", query="SELECT ID_SOC," +
					"										 ABI," +
					"										 RAGIONE_SOCIALE," +
					"										 GRUPPO," +
					"										 NAZIONE," +
					"										 ID_RAPPR_LEGAL," +
					"										 LEGAL_NOME," +
					"										 LEGAL_COGN," +
					"										 ID_ADMIN," +
					"										 ADMIN_NOME," +
					"										 ADMIN_COGNOME" +
					"									FROM vw_admin_legal_ccg")
})
public class VwAdminLegalCcgEntity implements Serializable {

	@Id
	@Column(name="ID_SOC")
	private int idSoc;
	
	@Column(name="ABI")
	private String abiCode;
	
	@Column(name="RAGIONE_SOCIALE")
	private String clientName;
	
	@Column(name="GRUPPO")
	private String group;
	
	@Column(name="NAZIONE")
	private String country;
	
	@Column(name="ID_RAPPR_LEGAL")
	private int idLegalRappr;
	
	@Column(name="LEGAL_NOME")
	private String legalName;
	
	@Column(name="LEGAL_COGN")
	private String legalSurname;
	
	@Column(name="ID_ADMIN")
	private int idAdmin;
	
	@Column(name="ADMIN_NOME")
	private String adminName;
	
	@Column(name="ADMIN_COGNOME")
	private String adminSurname;
	
	private static final long serialVersionUID = 1L;

	public VwAdminLegalCcgEntity() {
		super();
	}   
	public int getIdSoc() {
		return this.idSoc;
	}

	public void setIdSoc(int idSoc) {
		this.idSoc = idSoc;
	}   
	public String getAbiCode() {
		return this.abiCode;
	}

	public void setAbiCode(String abiCode) {
		this.abiCode = abiCode;
	}   
	public String getClientName() {
		return this.clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}   
	public String getGroup() {
		return this.group;
	}

	public void setGroup(String group) {
		this.group = group;
	}   
	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}   
	public int getIdLegalRappr() {
		return this.idLegalRappr;
	}

	public void setIdLegalRappr(int idLegalRappr) {
		this.idLegalRappr = idLegalRappr;
	}   
	public String getLegalName() {
		return this.legalName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}   
	public String getLegalSurname() {
		return this.legalSurname;
	}

	public void setLegalSurname(String legalSurname) {
		this.legalSurname = legalSurname;
	}   
	public int getIdAdmin() {
		return this.idAdmin;
	}

	public void setIdAdmin(int idAdmin) {
		this.idAdmin = idAdmin;
	}   
	public String getAdminName() {
		return this.adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}   
	public String getAdminSurname() {
		return this.adminSurname;
	}

	public void setAdminSurname(String adminSurname) {
		this.adminSurname = adminSurname;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "idSoc "+this.idSoc+" abiCode "+this.abiCode+" clientName "+clientName+" group "+group+" country "+country+" idLegalRappr "+idLegalRappr+" legalName "+legalName+" legalSurname "+legalSurname+" idAdmin "+idAdmin+" adminName "+adminName+" adminSurname "+adminSurname;
	}
	
	
}
