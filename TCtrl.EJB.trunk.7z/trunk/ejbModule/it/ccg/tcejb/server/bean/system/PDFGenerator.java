package it.ccg.tcejb.server.bean.system;

import it.ccg.tcejb.server.bean.entity.TctCorrLstEntity;
import it.ccg.tcejb.server.bean.entity.TctCorrispEntity;
import it.ccg.tcejb.server.bean.entity.TctRunRegEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.itextpdf.text.Element;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import it.ccg.tcejb.server.bean.entity.TctCorrisp;
@Stateless
public class PDFGenerator implements PDFGeneratorLocal {

	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);

	private static Color ccgColor = new Color(0, 85, 150);
	private static Font titleFont = new Font(Font.HELVETICA,20, Font.BOLD,ccgColor);
	private static Font subTitleFont = new Font(Font.HELVETICA,18, Font.BOLD,ccgColor);
	private static Font subTitleColoredFont = new Font(Font.HELVETICA,11, Font.BOLD,ccgColor);
	private static Font tabTitleFont = new Font(Font.HELVETICA,11, Font.BOLD);
	private static Font contentFont = new Font(Font.HELVETICA,10);
	private static Font footerFont = new Font(Font.HELVETICA,8, Font.ITALIC);
	private Document doc;
	private PdfWriter writer;

	public PDFGenerator() {

	}

	public Document generatePdf(List<TctCorrisp> corrispList,TctRunRegEntity runregList,/*String companyId,String runId,*/ String path) throws MalformedURLException,BadElementException,IOException, DocumentException, BackEndException {


		//this.doc = new Document(PageSize.A4,20, 20, 40, 30);//Verticale
		this.doc = new Document(PageSize.A4.rotate(),20, 20, 40, 30);//Orizzontale

		logger.debug(new StandardLogMessage("instantiation PdfWriter"));
		//System.out.println("instantiation PdfWriter");

		this.writer = PdfWriter.getInstance(this.doc, new FileOutputStream(SystemProperties.getSystemProperty("user.install.root")+ "/TcReport/"+path));


		this.doc.open();
		logger.debug(new StandardLogMessage("Documento aperto"));
		/*
		 * footer
		 */
		logger.debug(new StandardLogMessage("instantiating footer"));
		//System.out.println("instantiating footer");
		Image logo = Image.getInstance(IOUtils.toByteArray((this.getClass().getClassLoader().getResourceAsStream("/images/PdfLogo.png"))));
		logo.scalePercent(50);
		logo.setAlignment(Element.ALIGN_RIGHT);

		Chunk imageChunk = new Chunk(logo, 0, 0);

		//System.out.println("instantiating header");
		HeaderFooter header = new HeaderFooter(new Phrase(imageChunk),false);
		header.setAlignment(Element.ALIGN_RIGHT);
		header.setBorder(Rectangle.NO_BORDER);

		this.doc.setHeader(header);


		/*
		 * header
		 */
		logger.debug(new StandardLogMessage("instantiating header"));


		logger.debug(new StandardLogMessage("opening document and writer"));


		Image titleLogo = Image.getInstance(IOUtils.toByteArray(this.getClass().getClassLoader().getResourceAsStream("/images/PdfLogo.png")));
		titleLogo.scalePercent(100);
		titleLogo.setAlignment(Element.ALIGN_RIGHT);
		header.setBorder(Rectangle.NO_BORDER);

		this.doc.add(titleLogo);

		//if(corrispList.size()>0){

		PdfPTable table = new PdfPTable(7);
		//size singole colonne
		table.setWidths(new int[]{100,100,110,200,200,130,120});
		logger.debug(new StandardLogMessage("creating header cells"));

		PdfPCell headerCell = new PdfPCell(new Phrase("Run ID",tabTitleFont));
		Color c = new Color(189,210,226);

		headerCell.setBorderColor(Color.GRAY);
		headerCell.setBackgroundColor(c);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);

		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Client ID",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Terrorist ID",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Client Name",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		table.addCell(headerCell);

		/*headerCell = new PdfPCell(new Phrase("Terrorist Name ID",tabTitleFont));
			headerCell.setBackgroundColor(c);
			headerCell.setBorderColor(Color.GRAY);
			headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(headerCell);*/

		headerCell = new PdfPCell(new Phrase("Terrorist Name",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Sanctioned by",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Status",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);

		Paragraph analysisDate = null;
		Paragraph submitterUser = null;
		Paragraph approvingUser = null;
		Paragraph validatingDate = null;
		HeaderFooter footer = null;

		//System.out.println("SIZE: "+corrispList.size());
		if(corrispList.size()>0){
			logger.debug(new StandardLogMessage("creating content cells"));
			for(int i=0;i<corrispList.size();i++){

				analysisDate = new Paragraph("Batch execution date: "+runregList.getRunDate().toString().substring(0, 16),subTitleColoredFont);
				analysisDate.setAlignment(Element.ALIGN_CENTER);

				submitterUser = new Paragraph("Form submitted by: "+runregList.getSubmitter(),subTitleColoredFont);
				submitterUser.setAlignment(Element.ALIGN_CENTER);
				
				if(corrispList.get(i).getSubDate()!=null){
					validatingDate = new Paragraph("Form submission date: "+corrispList.get(i).getSubDate().toString().substring(0, 16),subTitleColoredFont);
					validatingDate.setAlignment(Element.ALIGN_CENTER);

					//Pi� di pagina
					footer = new HeaderFooter(new Phrase("Terrorist control: analysis report - Form submitted by: "+runregList.getSubmitter()+" - Form submission date: "+corrispList.get(i).getSubDate().toString().substring(0, 16)+" - Page ",footerFont),true);
					footer.setAlignment(Element.ALIGN_RIGHT);
					footer.setBorder(Rectangle.NO_BORDER);
					this.doc.setFooter(footer);

				}else{
					validatingDate = new Paragraph("Form submission date: N/A",subTitleColoredFont);
					validatingDate.setAlignment(Element.ALIGN_CENTER);

					//Pi� di pagina
					footer = new HeaderFooter(new Phrase("Terrorist control: analysis report - Form submitted by: N/A - Form submission date: N/A - Page ",footerFont),true);
					footer.setAlignment(Element.ALIGN_RIGHT);
					footer.setBorder(Rectangle.NO_BORDER);
					this.doc.setFooter(footer);

				}


				PdfPCell runidCell = new PdfPCell(new Phrase(corrispList.get(i).getRunId()+"" ,contentFont));
				System.out.println("RUNID: "+corrispList.get(i).getRunId());
				runidCell.setBorderColor(Color.GRAY);
				runidCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				runidCell.setVerticalAlignment(Element.ALIGN_CENTER);
				runidCell.setFixedHeight(25);

				PdfPCell clnidCell = new PdfPCell(new Phrase(corrispList.get(i).getClntid()+"" ,contentFont));
				System.out.println("CLIENTID: "+corrispList.get(i).getClntid());
				clnidCell.setBorderColor(Color.GRAY);
				clnidCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				clnidCell.setVerticalAlignment(Element.ALIGN_CENTER);
				clnidCell.setFixedHeight(25);

				PdfPCell clnnameCell = new PdfPCell(new Phrase(corrispList.get(i).getClntName() ,contentFont));
				clnnameCell.setBorderColor(Color.GRAY);
				clnnameCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				clnnameCell.setVerticalAlignment(Element.ALIGN_CENTER);
				clnnameCell.setFixedHeight(25);

				PdfPCell terrIDCell = new PdfPCell(new Phrase(corrispList.get(i).getEntityId()+"" ,contentFont));
				terrIDCell.setBorderColor(Color.GRAY);
				terrIDCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				terrIDCell.setVerticalAlignment(Element.ALIGN_CENTER);
				terrIDCell.setFixedHeight(25);

				/*PdfPCell nameIDCell = new PdfPCell(new Phrase(corrispList.get(i).getTctaggrent().getNameid()+"" ,contentFont));
				nameIDCell.setBorderColor(Color.GRAY);
				nameIDCell.setHorizontalAlignment(Element.ALIGN_CENTER);*/

				PdfPCell entityNameCell = new PdfPCell(new Phrase(corrispList.get(i).getEntityName() ,contentFont));
				entityNameCell.setBorderColor(Color.GRAY);
				entityNameCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				entityNameCell.setVerticalAlignment(Element.ALIGN_CENTER);
				entityNameCell.setFixedHeight(25);

				PdfPCell srcCodeCell = new PdfPCell(new Phrase(corrispList.get(i).getSrclist() ,contentFont));
				srcCodeCell.setBorderColor(Color.GRAY);
				srcCodeCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				srcCodeCell.setVerticalAlignment(Element.ALIGN_CENTER);
				srcCodeCell.setFixedHeight(25);

				PdfPCell statusCell = null;
				if(corrispList.get(i).getStatus().toString().equalsIgnoreCase("F")){
					statusCell = new PdfPCell(new Phrase("False Positive" ,contentFont));
					statusCell.setBorderColor(Color.GRAY);
					statusCell.setHorizontalAlignment(Element.ALIGN_CENTER);
					statusCell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(runidCell);
					table.addCell(clnidCell);
					table.addCell(terrIDCell);
					table.addCell(clnnameCell);
					//table.addCell(nameIDCell);
					table.addCell(entityNameCell);
					table.addCell(srcCodeCell);
					table.addCell(statusCell);

				}else if(corrispList.get(i).getStatus().toString().equalsIgnoreCase("P")){
					statusCell = new PdfPCell(new Phrase("Positive Match" ,contentFont));
					statusCell.setBorderColor(Color.GRAY);
					statusCell.setHorizontalAlignment(Element.ALIGN_CENTER);
					statusCell.setVerticalAlignment(Element.ALIGN_CENTER);

					Color cn = new Color(249,200,192);
					runidCell.setBackgroundColor(cn);
					clnidCell.setBackgroundColor(cn);
					clnnameCell.setBackgroundColor(cn);
					terrIDCell.setBackgroundColor(cn);
					//nameIDCell.setBackgroundColor(cn);
					entityNameCell.setBackgroundColor(cn);
					srcCodeCell.setBackgroundColor(cn);
					statusCell.setBackgroundColor(cn);

					table.addCell(runidCell);
					table.addCell(clnidCell);
					table.addCell(terrIDCell);
					table.addCell(clnnameCell);
					//table.addCell(nameIDCell);
					table.addCell(entityNameCell);
					table.addCell(srcCodeCell);
					table.addCell(statusCell);

				}else if(corrispList.get(i).getStatus().toString().equalsIgnoreCase("N")){
					statusCell = new PdfPCell(new Phrase("Forced Positive Match" ,contentFont));
					statusCell.setBorderColor(Color.GRAY);
					statusCell.setHorizontalAlignment(Element.ALIGN_CENTER);
					statusCell.setVerticalAlignment(Element.ALIGN_CENTER);

					Color cn = new Color(249,200,192);
					runidCell.setBackgroundColor(cn);
					clnidCell.setBackgroundColor(cn);
					clnnameCell.setBackgroundColor(cn);
					terrIDCell.setBackgroundColor(cn);
					//nameIDCell.setBackgroundColor(cn);
					entityNameCell.setBackgroundColor(cn);
					srcCodeCell.setBackgroundColor(cn);
					statusCell.setBackgroundColor(cn);

					table.addCell(runidCell);
					table.addCell(clnidCell);
					table.addCell(terrIDCell);
					table.addCell(clnnameCell);
					//table.addCell(nameIDCell);
					table.addCell(entityNameCell);
					table.addCell(srcCodeCell);
					table.addCell(statusCell);
				}

				logger.debug(new StandardLogMessage("adding cells to table"));

			}

			logger.debug(new StandardLogMessage("adding table to document"));

			logger.debug(new StandardLogMessage("creating paragraphs"));
			Paragraph tableTitle1row = new Paragraph("Terrorist control: analysis report",titleFont);
			tableTitle1row.setAlignment(Element.ALIGN_CENTER);
			//Paragraph tableTitle2row = new Paragraph("Terrorism Control",titleFont);
			//tableTitle2row.setAlignment(Element.ALIGN_CENTER);

			logger.debug(new StandardLogMessage("paragraphs created"));
			logger.debug(new StandardLogMessage("adding element to document"));

			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(tableTitle1row);
			//this.doc.add(tableTitle2row);
			logger.debug(new StandardLogMessage("creating date paragraph"));


			//updatedDate.setAlignment(Element.ALIGN_CENTER);
			logger.debug(new StandardLogMessage("data paragraph created"));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));

			this.doc.add(analysisDate);
			this.doc.add(submitterUser);
			if(runregList.getApproved().equalsIgnoreCase("T")){
				approvingUser = new Paragraph("Form approved by: "+ runregList.getApprover(),subTitleColoredFont);//+runregList.getApproved(),subTitleColoredFont);
				approvingUser.setAlignment(Element.ALIGN_CENTER);
				this.doc.add(approvingUser);
			}
			
			this.doc.add(validatingDate);


			this.doc.newPage();
			this.doc.add(new Paragraph());
			this.doc.add(table);
			this.doc.add(Chunk.NEWLINE);
			this.doc.add(new Paragraph());

		}
		//System.out.println("Sto chiudendo....");
		this.doc.close();
		logger.debug(new StandardLogMessage("document closed"));
		//System.out.println("doc chiuso");

		return this.doc;
	}

	public Document generateRunregPdf(TctRunRegEntity runregList/*,String companyId,String runId*/,String path)  throws  MalformedURLException, BadElementException,IOException, DocumentException, BackEndException {


		//this.doc = new Document(PageSize.A4,20, 20, 40, 30);//Verticale
		this.doc = new Document(PageSize.A4.rotate(),20, 20, 40, 30);//Orizzontale

		logger.debug(new StandardLogMessage("instantiation PdfWriter"));
		//System.out.println("instantiation PdfWriter");

		this.writer = PdfWriter.getInstance(this.doc, new FileOutputStream(SystemProperties.getSystemProperty("user.install.root")+ "/TcReport/"+path));


		this.doc.open();
		logger.debug(new StandardLogMessage("Documento aperto"));
		/*
		 * footer
		 */
		logger.debug(new StandardLogMessage("instantiating footer"));
		//System.out.println("instantiating footer");
		Image logo = Image.getInstance(IOUtils.toByteArray((this.getClass().getClassLoader().getResourceAsStream("/images/PdfLogo.png"))));
		logo.scalePercent(50);
		logo.setAlignment(Element.ALIGN_RIGHT);

		Chunk imageChunk = new Chunk(logo, 0, 0);

		//System.out.println("instantiating header");
		HeaderFooter header = new HeaderFooter(new Phrase(imageChunk),false);
		header.setAlignment(Element.ALIGN_RIGHT);
		header.setBorder(Rectangle.NO_BORDER);

		this.doc.setHeader(header);


		/*
		 * header
		 */
		logger.debug(new StandardLogMessage("instantiating header"));


		logger.debug(new StandardLogMessage("opening document and writer"));


		Image titleLogo = Image.getInstance(IOUtils.toByteArray(this.getClass().getClassLoader().getResourceAsStream("/images/PdfLogo.png")));
		titleLogo.scalePercent(100);
		titleLogo.setAlignment(Element.ALIGN_RIGHT);
		header.setBorder(Rectangle.NO_BORDER);

		this.doc.add(titleLogo);

		PdfPTable table = new PdfPTable(7);
		//size singole colonne
		table.setWidths(new int[]{100,100,110,200,200,130,120});
		logger.debug(new StandardLogMessage("creating header cells"));

		PdfPCell headerCell = new PdfPCell(new Phrase("Run ID",tabTitleFont));
		Color c = new Color(189,210,226);

		headerCell.setBorderColor(Color.GRAY);
		headerCell.setBackgroundColor(c);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);

		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Client ID",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Terrorist ID",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Client Name",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		table.addCell(headerCell);


		headerCell = new PdfPCell(new Phrase("Terrorist Name",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Sanctioned by",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Status",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);

		Paragraph analysisDate = null;
		Paragraph submitterUser = null;
		Paragraph approvingUser = null;
		Paragraph validatingDate = null;
		HeaderFooter footer = null;

		logger.debug(new StandardLogMessage("creating paragraphs"));
		Paragraph tableTitle1row = new Paragraph("Terrorist control: analysis report",titleFont);
		tableTitle1row.setAlignment(Element.ALIGN_CENTER);

		analysisDate = new Paragraph("Batch execution date: "+runregList.getRunDate().toString().substring(0, 16),subTitleColoredFont);
		analysisDate.setAlignment(Element.ALIGN_CENTER);

		submitterUser = new Paragraph("Form submitted by: "+runregList.getSubmitter(),subTitleColoredFont);//runregList.getUpdUser(),subTitleColoredFont);
		submitterUser.setAlignment(Element.ALIGN_CENTER);
		
		
		if(runregList.getSubDate()!=null){
			validatingDate = new Paragraph("Form submission date: "+runregList.getSubDate().toString().substring(0, 16),subTitleColoredFont);
			validatingDate.setAlignment(Element.ALIGN_CENTER);

			//Pi� di pagina
			footer = new HeaderFooter(new Phrase("Terrorist control: analysis report - Form submitted by: "+runregList.getSubmitter()+" - Form submission date: "+runregList.getSubDate().toString().substring(0, 16)+" - Page ",footerFont),true);
			footer.setAlignment(Element.ALIGN_RIGHT);
			footer.setBorder(Rectangle.NO_BORDER);
			this.doc.setFooter(footer);

		}else{
			validatingDate = new Paragraph("Analysis date: N/A",subTitleColoredFont);
			validatingDate.setAlignment(Element.ALIGN_CENTER);

			//Pi� di pagina
			footer = new HeaderFooter(new Phrase("Terrorist control: analysis report - Form submitted by: N/A - Form submission date: N/A - Page ",footerFont),true);
			footer.setAlignment(Element.ALIGN_RIGHT);
			footer.setBorder(Rectangle.NO_BORDER);
			this.doc.setFooter(footer);

		}

		logger.debug(new StandardLogMessage("paragraphs created"));
		logger.debug(new StandardLogMessage("adding element to document"));

		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(tableTitle1row);
		logger.debug(new StandardLogMessage("creating date paragraph"));


		logger.debug(new StandardLogMessage("creating date paragraph"));


		//updatedDate.setAlignment(Element.ALIGN_CENTER);
		logger.debug(new StandardLogMessage("data paragraph created"));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));

		this.doc.add(analysisDate);
		this.doc.add(submitterUser);
		if(runregList.getApproved().equalsIgnoreCase("T")){
			approvingUser = new Paragraph("Form approved by: "+runregList.getApprover(),subTitleColoredFont);//+runregList.getApproved(),subTitleColoredFont);
			approvingUser.setAlignment(Element.ALIGN_CENTER);
			this.doc.add(approvingUser);
		}
		
		this.doc.add(validatingDate);

		this.doc.newPage();
		this.doc.add(new Paragraph());
		this.doc.add(table);
		this.doc.add(Chunk.NEWLINE);
		this.doc.add(new Paragraph());
		Paragraph tableTitle2row = new Paragraph("                            No matches found");
		tableTitle2row.setAlignment(Element.ALIGN_LEFT);
		this.doc.add(tableTitle2row);
		this.doc.add(new Paragraph());


		//System.out.println("Sto chiudendo....");
		this.doc.close();
		//System.out.println("doc chiuso");

		return this.doc;
	}

	public Document generateCorrLstPdf(List<TctCorrLstEntity> corrList/*,String companyId*/, String userName, String path, String clientName)  throws  MalformedURLException, BadElementException,IOException, DocumentException, BackEndException{

		this.doc = new Document(PageSize.A4.rotate(),20, 20, 40, 30);//Orizzontale

		logger.debug(new StandardLogMessage("instantiation PdfWriter"));
		//System.out.println("instantiation PdfWriter");

		this.writer = PdfWriter.getInstance(this.doc, new FileOutputStream(SystemProperties.getSystemProperty("user.install.root")+ "/TcReport/"+path));


		this.doc.open();
		//System.out.println("Documento aperto");
		//System.out.println("SIZE: "+corrList.size());

		//* footer

		logger.debug(new StandardLogMessage("instantiating footer"));
		//System.out.println("instantiating footer");
		HeaderFooter footer = new HeaderFooter(new Phrase("Page ",footerFont),true);
		footer.setAlignment(Element.ALIGN_RIGHT);
		footer.setBorder(Rectangle.NO_BORDER);
		Image logo = Image.getInstance(IOUtils.toByteArray((this.getClass().getClassLoader().getResourceAsStream("/images/PdfLogo.png"))));
		logo.scalePercent(50);
		logo.setAlignment(Element.ALIGN_RIGHT);

		Chunk imageChunk = new Chunk(logo, 0, 0);

		System.out.println("instantiating header");
		HeaderFooter header = new HeaderFooter(new Phrase(imageChunk),false);
		header.setAlignment(Element.ALIGN_RIGHT);
		header.setBorder(Rectangle.NO_BORDER);

		this.doc.setHeader(header);



		// * header

		logger.debug(new StandardLogMessage("instantiating header"));


		logger.debug(new StandardLogMessage("opening document and writer"));


		//this.doc.setFooter(footer);


		Image titleLogo = Image.getInstance(IOUtils.toByteArray(this.getClass().getClassLoader().getResourceAsStream("/images/PdfLogo.png")));
		titleLogo.scalePercent(100);
		titleLogo.setAlignment(Element.ALIGN_RIGHT);
		header.setBorder(Rectangle.NO_BORDER);

		this.doc.add(titleLogo);

		PdfPTable table = new PdfPTable(5);
		//size singole colonne
		table.setWidths(new int[]{300,250,180,160,150});
		logger.debug(new StandardLogMessage("creating header cells"));

		PdfPCell headerCell = new PdfPCell(new Phrase("Client Name (or Alias)",tabTitleFont));
		Color c = new Color(189,210,226);

		headerCell.setBorderColor(Color.GRAY);
		headerCell.setBackgroundColor(c);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);

		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Terrorist ID",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Terrorist Name",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Sanctioned by",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);

		headerCell = new PdfPCell(new Phrase("Status",tabTitleFont));
		headerCell.setBackgroundColor(c);
		headerCell.setBorderColor(Color.GRAY);
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setVerticalAlignment(Element.ALIGN_CENTER);
		headerCell.setFixedHeight(25);
		table.addCell(headerCell);




		//Pi� di pagina
		SimpleDateFormat formatterNew = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		HeaderFooter footer1 = new HeaderFooter(new Phrase("Terrorist control: admission control report - Produced by: " +userName+ " - Analysis date: "+formatterNew.format(new Date())+" - Page ",footerFont),true);
		footer1.setAlignment(Element.ALIGN_RIGHT);
		footer1.setBorder(Rectangle.NO_BORDER);
		this.doc.setFooter(footer1);

		logger.debug(new StandardLogMessage("creating content cells"));

		if(corrList.size()>0){
			for(int i=0;i<corrList.size();i++){

				PdfPCell clientaliasCell = new PdfPCell(new Phrase(corrList.get(i).getClntName()+"" ,contentFont));
				clientaliasCell.setBorderColor(Color.GRAY);
				clientaliasCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				clientaliasCell.setVerticalAlignment(Element.ALIGN_CENTER);
				clientaliasCell.setFixedHeight(25);

				PdfPCell terridCell = new PdfPCell(new Phrase(corrList.get(i).getTctaggrent().getId().getAggregId()+"" ,contentFont));
				terridCell.setBorderColor(Color.GRAY);
				terridCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				terridCell.setVerticalAlignment(Element.ALIGN_CENTER);
				terridCell.setFixedHeight(25);

				PdfPCell terrnameCell = new PdfPCell(new Phrase(corrList.get(i).getEntityName()+"" ,contentFont));
				terrnameCell.setBorderColor(Color.GRAY);
				terrnameCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				terrnameCell.setVerticalAlignment(Element.ALIGN_CENTER);
				terrnameCell.setFixedHeight(25);

				PdfPCell srcListCell = new PdfPCell(new Phrase(corrList.get(i).getTctaggrent().getSrcList()+"" ,contentFont));
				srcListCell.setBorderColor(Color.GRAY);
				srcListCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				srcListCell.setVerticalAlignment(Element.ALIGN_CENTER);
				srcListCell.setFixedHeight(25);

				PdfPCell statusCell = null;
				if(corrList.get(i).getStatus().toString().equalsIgnoreCase("F")){
					statusCell = new PdfPCell(new Phrase("False Positive" ,contentFont));
					statusCell.setBorderColor(Color.GRAY);
					statusCell.setHorizontalAlignment(Element.ALIGN_CENTER);
					statusCell.setVerticalAlignment(Element.ALIGN_CENTER);

					table.addCell(clientaliasCell);
					table.addCell(terridCell);
					table.addCell(terrnameCell);
					table.addCell(srcListCell);
					table.addCell(statusCell);


				}else if(corrList.get(i).getStatus().toString().equalsIgnoreCase("P")){
					statusCell = new PdfPCell(new Phrase("Positive Match" ,contentFont));
					statusCell.setBorderColor(Color.GRAY);
					statusCell.setHorizontalAlignment(Element.ALIGN_CENTER);
					statusCell.setVerticalAlignment(Element.ALIGN_CENTER);

					Color cn = new Color(249,200,192);
					clientaliasCell.setBackgroundColor(cn);
					terrnameCell.setBackgroundColor(cn);
					srcListCell.setBackgroundColor(cn);
					statusCell.setBackgroundColor(cn);
					terridCell.setBackgroundColor(cn);				

					table.addCell(clientaliasCell);
					table.addCell(terridCell);
					table.addCell(terrnameCell);
					table.addCell(srcListCell);
					table.addCell(statusCell);


				}else if(corrList.get(i).getStatus().toString().equalsIgnoreCase("O")){
					statusCell = new PdfPCell(new Phrase("Outstanding" ,contentFont));
					statusCell.setBorderColor(Color.GRAY);
					statusCell.setHorizontalAlignment(Element.ALIGN_CENTER);
					statusCell.setVerticalAlignment(Element.ALIGN_CENTER);

					table.addCell(clientaliasCell);
					table.addCell(terridCell);
					table.addCell(terrnameCell);
					table.addCell(srcListCell);
					table.addCell(statusCell);				

				}/*else if(corrList.get(i).getStatus().toString().equalsIgnoreCase("N")){
				statusCell = new PdfPCell(new Phrase("Forced Positive Match" ,contentFont));
				statusCell.setBorderColor(Color.GRAY);
				statusCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				statusCell.setVerticalAlignment(Element.ALIGN_CENTER);

				Color cn = new Color(249,200,192);
				clientaliasCell.setBackgroundColor(cn);
				terrnameCell.setBackgroundColor(cn);
				srcListCell.setBackgroundColor(cn);
				statusCell.setBackgroundColor(cn);
				terridCell.setBackgroundColor(cn);

				table.addCell(clientaliasCell);
				table.addCell(terridCell);
				table.addCell(terrnameCell);
				table.addCell(srcListCell);
				table.addCell(statusCell);


			}*/

				logger.debug(new StandardLogMessage("adding cells to table"));

			}

		logger.debug(new StandardLogMessage("adding table to document"));

		logger.debug(new StandardLogMessage("creating paragraphs"));
		Paragraph tableTitle1row = new Paragraph("Terrorist control: admission report",titleFont);
		tableTitle1row.setAlignment(Element.ALIGN_CENTER);

		logger.debug(new StandardLogMessage("paragraphs created"));
		logger.debug(new StandardLogMessage("adding element to document"));

		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(tableTitle1row);
		logger.debug(new StandardLogMessage("creating date paragraph"));


		//updatedDate.setAlignment(Element.ALIGN_CENTER);
		logger.debug(new StandardLogMessage("data paragraph created"));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));
		this.doc.add(new Paragraph(" "));

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Paragraph analysisDate = new Paragraph("Analysis date: "+formatter.format(new Date()),subTitleColoredFont);
		analysisDate.setAlignment(Element.ALIGN_CENTER);


		Paragraph validatingUser = new Paragraph("Produced by: "+userName,subTitleColoredFont);
		validatingUser.setAlignment(Element.ALIGN_CENTER);

		this.doc.add(analysisDate);
		this.doc.add(validatingUser);		

		this.doc.newPage();
		this.doc.add(new Paragraph());
		this.doc.add(table);
		this.doc.add(Chunk.NEWLINE);
		this.doc.add(new Paragraph());

		//System.out.println("Sto chiudendo....");
		this.doc.close();
		logger.debug(new StandardLogMessage("document closed"));
		//System.out.println("doc chiuso");
		}else{

			logger.debug(new StandardLogMessage("creating paragraphs"));
			Paragraph tableTitle1row = new Paragraph("Terrorist control: admission report",titleFont);
			tableTitle1row.setAlignment(Element.ALIGN_CENTER);

			logger.debug(new StandardLogMessage("paragraphs created"));
			logger.debug(new StandardLogMessage("adding element to document"));

			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(tableTitle1row);
			logger.debug(new StandardLogMessage("creating date paragraph"));


			//updatedDate.setAlignment(Element.ALIGN_CENTER);
			logger.debug(new StandardLogMessage("data paragraph created"));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));
			this.doc.add(new Paragraph(" "));

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Paragraph analysisDate = new Paragraph("Analysis date: "+formatter.format(new Date()),subTitleColoredFont);
			analysisDate.setAlignment(Element.ALIGN_CENTER);


			Paragraph validatingUser = new Paragraph("Produced by: "+userName,subTitleColoredFont);
			validatingUser.setAlignment(Element.ALIGN_CENTER);

			this.doc.add(analysisDate);
			this.doc.add(validatingUser);		

			this.doc.newPage();
			this.doc.add(new Paragraph());
			this.doc.add(table);
			this.doc.add(Chunk.NEWLINE);
			this.doc.add(new Paragraph());
			Paragraph tableTitle2row = new Paragraph("                            No matches found for the following search keys: \" "+clientName+" \"");
			tableTitle2row.setAlignment(Element.ALIGN_LEFT);
			this.doc.add(tableTitle2row);
			this.doc.add(new Paragraph());
			
			this.doc.close();
			logger.debug(new StandardLogMessage("document closed"));


		}
		return this.doc;

	}
}
