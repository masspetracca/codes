package it.ccg.tcejb.server.bean.entity.un;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TCTUNINDIV database table.
 * 
 */
@Entity
@Table(name="TCTUNINDIV")
@NamedQueries({
	@NamedQuery(name="getUnIndividualsById", query="SELECT entity FROM TctUnIndiv entity WHERE entity.dataId = :dataId ORDER BY entity.dataId ASC"),
	@NamedQuery(name="getUnIndividuals", query="SELECT entity FROM TctUnIndiv entity ORDER BY entity.dataId ASC"),
	@NamedQuery(name="getUnIndividualsBySrcListDate", query="SELECT entity " +
			   "										 FROM TctUnIndiv entity " +
			   "										WHERE entity.dateGenerated = :srcListDate " +
			   "										ORDER BY entity.dataId ASC"),
    @NamedQuery(name="getUnIndLatestSrcListDate",    query="SELECT MAX(entity.dateGenerated) " +
	           "										   FROM TctUnIndiv entity"),
	/*
	 * raffaele de lauri
	 * TN_CCG15298
	 */
    @NamedQuery(name="getUnLatestIndividuals", query="SELECT entity " +
               "								     FROM TctUnIndiv entity " +
               "								    WHERE entity.releasedDt = (SELECT MAX(entity2.releasedDt) " +
               "								 							  FROM TctUnIndiv entity2" +
               "															 WHERE entity2.dataId = entity.dataId)" +
    		   "								    ORDER BY entity.dataId ASC"),
    @NamedQuery(name="deleteUnEveryIndividuals", query="DELETE FROM TctUnIndiv")
})
public class TctUnIndiv implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Id
	@Column(unique=true, nullable=false)
	private int dataId;

	@Column(length=1000)
	private String comments1;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date dateGenerated;

    @Temporal( TemporalType.DATE)
	private Date delistOnDt;

	@Column(nullable=false, length=255)
	private String firstName;

	@Column(length=255)
	private String fourthName;

	@Column(length=255)
	private String gender;

	@Column(nullable=false)
	private Timestamp listedOn;

	@Column(length=50)
	private String listTp;

	@Column(length=255)
	private String national2;

	@Column(length=255)
	private String nOrgScript;

	@Column(nullable=false, length=255)
	private String refNumber;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date releasedDt;

	@Column(length=255)
	private String secondName;

	@Column(length=255)
	private String sortKey;

	private Timestamp sortKeyLsMod;

	@Column(length=255)
	private String submitedBy;

	@Column(length=255)
	private String thirdName;

	@Column(nullable=false, length=50)
	private String unListTp;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=10)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	private int versionNum;

	//bi-directional many-to-one association to TctUnAlia
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnAlia> tctunalias;

	//bi-directional many-to-one association to TctUnBrtDt
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnBrtDt> tctunbrtdts;

	//bi-directional many-to-one association to TctUnBtPlc
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnBtPlc> tctunbtplcs;

	//bi-directional many-to-one association to TctUnLstUp
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnLstUp> tctunlstups;

	//bi-directional many-to-one association to TctUnNat
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnNat> tctunnats;

	//bi-directional many-to-one association to TctUnNat
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnInDoc> tctunindoc;
	
	//bi-directional many-to-one association to TctUnAddr
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnAddr> tctunaddrs;
	
	//bi-directional many-to-one association to TctUnTitle
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	private Set<TctUnTitle> tctuntitles;
	
	//bi-directional many-to-one association to TctUnDesig
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	private Set<TctUnDesig> tctundesigs;
		
    public TctUnIndiv() {
    }

    /**
     * 
     * @return
     */
	public int getDataId() {
		return this.dataId;
	}

	/**
	 * 
	 * @param dataId
	 */
	public void setDataId(int dataId) {
		this.dataId = dataId;
	}

	/**
	 * 
	 * @return
	 */
	public String getComments1() {
		return this.comments1;
	}

	/**
	 * 
	 * @param comments1
	 */
	public void setComments1(String comments1) {
		if (comments1 != null && comments1.length()>1000){
			ejbLogger.debug(comments1+" >1000 than truncate");
			this.comments1 = comments1.substring(0, 999);
		}else{
			this.comments1 = comments1;
		}
	}

	/**
	 * 
	 * @return
	 */
	public Date getDateGenerated() {
		return this.dateGenerated;
	}

	/**
	 * 
	 * @param dateGenerated
	 */
	public void setDateGenerated(Date dateGenerated) {
		this.dateGenerated = dateGenerated;
	}

	/**
	 * 
	 * @return
	 */
	public Date getDelistOnDt() {
		return this.delistOnDt;
	}

	/**
	 * 
	 * @param delistOnDt
	 */
	public void setDelistOnDt(Date delistOnDt) {
		this.delistOnDt = delistOnDt;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * 
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		if (firstName !=null && firstName.length()>255){
			ejbLogger.debug(firstName+" >255 than truncate");
			this.firstName = firstName.substring(0, 254);
		}else{
			this.firstName = firstName;
		}
	}
	
	/**
	 * 
	 * @return
	 */
	public String getFourthName() {
		return this.fourthName;
	}

	/**
	 * 
	 * @param fourthName
	 */
	public void setFourthName(String fourthName) {
		if (fourthName !=null && fourthName.length()>255){
			ejbLogger.debug(fourthName+" >255 than truncate");
			this.fourthName = fourthName.substring(0, 254);
		}else{
			this.fourthName = fourthName;
		}
	}

	/**
	 * 
	 * @return
	 */
	public String getGender() {
		return this.gender;
	}

	/**
	 * 
	 * @param gender
	 */
	public void setGender(String gender) {
		if (gender !=null && gender.length()>255){
			ejbLogger.debug(gender+" >255 than truncate");
			this.gender = gender.substring(0, 254);
		}else{
			this.gender = gender;
		}
	}
	
	/**
	 * 
	 * @return
	 */
	public Timestamp getListedOn() {
		return this.listedOn;
	}

	/**
	 * 
	 * @param listedOn
	 */
	public void setListedOn(Timestamp listedOn) {
		this.listedOn = listedOn;
	}

	/**
	 * 
	 * @return
	 */
	public String getListTp() {
		return this.listTp;
	}

	/**
	 * 
	 * @param listTp
	 */
	public void setListTp(String listTp) {
		if (listTp!=null && listTp.length()>50){
			ejbLogger.debug(listTp+" >50 than truncate");
			this.listTp = listTp.substring(0, 49);
		}else{
			this.listTp = listTp;
		}
	}
	
	/**
	 * 
	 * @return
	 */
	public String getNational2() {
		return this.national2;
	}

	/**
	 * 
	 * @param national2
	 */
	public void setNational2(String national2) {
		if (national2!=null && national2.length()>255){
			ejbLogger.debug(national2+" >255 than truncate");
			this.national2 = national2.substring(0, 254);
		}else{
			this.national2 = national2;
		}
	}
	
	/**
	 * 
	 * @return
	 */
	public String getNOrgScript() {
		return this.nOrgScript;
	}

	/**
	 * 
	 * @param nOrgScript
	 */
	public void setNOrgScript(String nOrgScript) {
		if (nOrgScript!=null && nOrgScript.length()>255){
			ejbLogger.debug(nOrgScript+" >255 than truncate");
			this.nOrgScript = nOrgScript.substring(0, 254);
		}else{
			this.nOrgScript = nOrgScript;
		}
	}

	/**
	 * 
	 * @return
	 */
	public String getRefNumber() {
		return this.refNumber;
	}

	/**
	 * 
	 * @param refNumber
	 */
	public void setRefNumber(String refNumber) {
		if (refNumber != null && refNumber.length()>50){
			ejbLogger.debug(refNumber+" >50 than truncate");
			this.refNumber = refNumber.substring(0, 49);
		}else{
			this.refNumber = refNumber;
		}
	}

	/**
	 * 
	 * @return
	 */
	public Date getReleasedDt() {
		return this.releasedDt;
	}

	/**
	 * 
	 * @param releasedDt
	 */
	public void setReleasedDt(Date releasedDt) {
		this.releasedDt = releasedDt;
	}

	/**
	 * 
	 * @return
	 */
	public String getSecondName() {
		return this.secondName;
	}

	/**
	 * 
	 * @param secondName
	 */
	public void setSecondName(String secondName) {
		/*
		 * raffale de lauri
		 * TN_CCG15247
		 */
		if (secondName!=null && secondName.length()>255){
			ejbLogger.debug(secondName+" >255 than truncate");
			this.secondName = secondName.substring(0, 254);
		}else{
			this.secondName = secondName;
		}
	}

	/**
	 * 
	 * @return
	 */
	public String getSortKey() {
		return this.sortKey;
	}

	/**
	 * 
	 * @param sortKey
	 */
	public void setSortKey(String sortKey) {
		if (sortKey != null && sortKey.length()>255){
			ejbLogger.debug(sortKey+" >255 than truncate");
			this.sortKey = sortKey.substring(0, 254);
		}else{
			this.sortKey = sortKey;
		}
	}

	/**
	 * 
	 * @return
	 */
	public Timestamp getSortKeyLsMod() {
		return this.sortKeyLsMod;
	}

	/**
	 * 
	 * @param sortKeyLsMod
	 */
	public void setSortKeyLsMod(Timestamp sortKeyLsMod) {
		this.sortKeyLsMod = sortKeyLsMod;
	}

	/**
	 * 
	 * @return
	 */
	public String getSubmitedBy() {
		return this.submitedBy;
	}

	/**
	 * 
	 * @param submitedBy
	 */
	public void setSubmitedBy(String submitedBy) {
		this.submitedBy = submitedBy;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getThirdName() {
		return this.thirdName;
	}

	/**
	 * 
	 * @param thirdName
	 */
	public void setThirdName(String thirdName) {
		/*
		 * raffale de lauri
		 * TN_CCG15247
		 */
		if (thirdName!=null && thirdName.length()>255){
			ejbLogger.debug(thirdName+" >255 than truncate");
			this.thirdName = thirdName.substring(0, 254);
		}else{
			this.thirdName = thirdName;
		}
	}

	/**
	 * 
	 * @return
	 */
	public String getUnListTp() {
		return this.unListTp;
	}

	/**
	 * 
	 * @param unListTp
	 */
	public void setUnListTp(String unListTp) {
		if (unListTp != null && unListTp.length()>50){
			ejbLogger.debug(unListTp+" >50 than truncate");
			this.unListTp = unListTp.substring(0, 49);
		}else{
			this.unListTp = unListTp;
		}
	}

	/**
	 * 
	 * @return
	 */
	public Timestamp getUpdDate() {
		return this.updDate;
	}

	/**
	 * 
	 * @param updDate
	 */
	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	/**
	 * 
	 * @return
	 */
	public String getUpdType() {
		return this.updType;
	}

	/**
	 * 
	 * @param updType
	 */
	public void setUpdType(String updType) {
		this.updType = updType;
	}

	/**
	 * 
	 * @return
	 */
	public String getUpdUser() {
		return this.updUser;
	}

	/**
	 * 
	 * @param updUser
	 */
	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	/**
	 * 
	 * @return
	 */
	public int getVersionNum() {
		return this.versionNum;
	}

	/**
	 * 
	 * @param versionNum
	 */
	public void setVersionNum(int versionNum) {
		this.versionNum = versionNum;
	}
	
	/**
	 * 
	 * @return
	 */
	public Set<TctUnAlia> getTctunalias() {
		return this.tctunalias;
	}

	/**
	 * 
	 * @param tctunalias
	 */
	public void setTctunalias(Set<TctUnAlia> tctunalias) {
		this.tctunalias = tctunalias;
	}
	
	/**
	 * 
	 * @return
	 */
	public Set<TctUnBrtDt> getTctunbrtdts() {
		return this.tctunbrtdts;
	}

	/**
	 * 
	 * @param tctunbrtdts
	 */
	public void setTctunbrtdts(Set<TctUnBrtDt> tctunbrtdts) {
		this.tctunbrtdts = tctunbrtdts;
	}
	
	/**
	 * 
	 * @return
	 */
	public Set<TctUnBtPlc> getTctunbtplcs() {
		return this.tctunbtplcs;
	}

	/**
	 * 
	 * @param tctunbtplcs
	 */
	public void setTctunbtplcs(Set<TctUnBtPlc> tctunbtplcs) {
		this.tctunbtplcs = tctunbtplcs;
	}
	
	/**
	 * 
	 * @return
	 */
	public Set<TctUnLstUp> getTctunlstups() {
		return this.tctunlstups;
	}

	/**
	 * 
	 * @param tctunlstups
	 */
	public void setTctunlstups(Set<TctUnLstUp> tctunlstups) {
		this.tctunlstups = tctunlstups;
	}
	
	/**
	 * 
	 * @return
	 */
	public Set<TctUnNat> getTctunnats() {
		return this.tctunnats;
	}

	/**
	 * 
	 * @param tctunnats
	 */
	public void setTctunnats(Set<TctUnNat> tctunnats) {
		this.tctunnats = tctunnats;
	}

	/**
	 * @return the tctunindoc
	 */
	public Set<TctUnInDoc> getTctunindoc() {
		return tctunindoc;
	}

	/**
	 * @param tctunindoc the tctunindoc to set
	 */
	public void setTctunindoc(Set<TctUnInDoc> tctunindoc) {
		this.tctunindoc = tctunindoc;
	}

	/**
	 * @return the tctunaddrs
	 */
	public Set<TctUnAddr> getTctunaddrs() {
		return tctunaddrs;
	}

	/**
	 * @param tctunaddrs the tctunaddrs to set
	 */
	public void setTctunaddrs(Set<TctUnAddr> tctunaddrs) {
		this.tctunaddrs = tctunaddrs;
	}
	
	/**
	 * 
	 * @return
	 */
	public Set<TctUnDesig> getTctundesigs() {
		return this.tctundesigs;
	}

	/**
	 * 
	 * @param tctundesigs
	 */
	public void setTctundesigs(Set<TctUnDesig> tctundesigs) {
		this.tctundesigs = tctundesigs;
	}
	
	/**
	 * 
	 * @return
	 */
	public Set<TctUnTitle> getTctuntitles() {
		return this.tctuntitles;
	}

	/**
	 * 
	 * @param tctuntitles
	 */
	public void setTctuntitles(Set<TctUnTitle> tctuntitles) {
		this.tctuntitles = tctuntitles;
	}
}