package it.ccg.tcejb.server.bean.entity;


import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the TCTCORRLST database table.
 * 
 */
/*
 * ticket 14899
 */
@Entity
@Table(name="TCTCORRLST")
@NamedQueries({
    @NamedQuery(name="deleteEveryCorrLst", query="DELETE FROM TctCorrLstEntity entity WHERE entity.id.cmpnid = :cmpnid "),
    
    @NamedQuery(name="getByCmpnId",   query="SELECT entity " +
            "								FROM TctCorrLstEntity entity " +
            "								LEFT JOIN FETCH entity.tctaggrent" +
            "								WHERE entity.status <> 'D'" +
            "								AND entity.id.cmpnid  = :cmpnId")  
})
public class TctCorrLstEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TctCorrLstEntityPK id;

	@Column(nullable=false, length=100)
	private String clntName;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal corrIndex;

	@Column(nullable=false, length=255)
	private String entityName;

	@Column(nullable=false, length=1)
	private String isFPositiv;

	@Column(nullable=false, length=1)
	private String status;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	//bi-directional many-to-one association to TctAggrEntEntity
    @ManyToOne(cascade={CascadeType.DETACH})
	@JoinColumns({
		@JoinColumn(name="AGGREGID", referencedColumnName="AGGREGID", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="DOWNLOADID", referencedColumnName="DOWNLOADID", nullable=false, insertable=false, updatable=false)
		})
	private TctAggrEntEntity tctaggrent;

	//bi-directional many-to-one association to TctCompanyEntity
    @ManyToOne(cascade={CascadeType.DETACH})
	@JoinColumn(name="CMPNID", nullable=false, insertable=false, updatable=false)
	private TctCompanyEntity tctcompany;

    public TctCorrLstEntity() {
    }

	public TctCorrLstEntityPK getId() {
		return this.id;
	}

	public void setId(TctCorrLstEntityPK id) {
		this.id = id;
	}
	
	public String getClntName() {
		return this.clntName;
	}

	public void setClntName(String clntName) {
		this.clntName = clntName;
	}

	public BigDecimal getCorrIndex() {
		return this.corrIndex;
	}

	public void setCorrIndex(BigDecimal corrIndex) {
		this.corrIndex = corrIndex;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getIsFPositiv() {
		return this.isFPositiv;
	}

	public void setIsFPositiv(String isFPositiv) {
		this.isFPositiv = isFPositiv;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public TctAggrEntEntity getTctaggrent() {
		return this.tctaggrent;
	}

	public void setTctaggrent(TctAggrEntEntity tctaggrent) {
		this.tctaggrent = tctaggrent;
	}
	
	public TctCompanyEntity getTctcompany() {
		return this.tctcompany;
	}

	public void setTctcompany(TctCompanyEntity tctcompany) {
		this.tctcompany = tctcompany;
	}
	
}