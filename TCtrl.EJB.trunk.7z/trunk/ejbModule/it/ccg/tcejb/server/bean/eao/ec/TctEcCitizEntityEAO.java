package it.ccg.tcejb.server.bean.eao.ec;

import it.ccg.tcejb.server.bean.entity.ec.TctEcCitizEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctEcCitizEntityEAO
 */
@Stateless
@LocalBean
public class TctEcCitizEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctEcCitizEntityEAO() {
        // TODO Auto-generated constructor stub
    }
    
    public void insertEntity(TctEcCitizEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctEcCitizEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcCitizEntity identification data: EC Entity code = "+entity.getId().getEntityid() +" , citizen id = "+entity.getId().getCityId()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public void insertEntity(Set<TctEcCitizEntity> entities) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(Set<TctEcCitizEntity> entities)"));
	    	for (TctEcCitizEntity entity : entities){
	    		ejbLogger.debug(new StandardLogMessage("TctEcCitizEntity identification data: EC Entity code = "+entity.getId().getEntityid() +" , citizen id = "+entity.getId().getCityId()));
		    	
		    	this.manager.persist(entity);
	    	}
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	this.manager.flush();
	    	
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
  	public void deleteEntity(TctEcCitizEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctEcCitizEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcCitizEntity identification data: EC Entity code = "+entity.getId().getEntityid() +" , citizen id = "+entity.getId().getCityId()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void deleteEveryEntity() throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteEcCitizEveryEntity");
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	this.manager.flush();
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctEcCitizEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctEcCitizEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcCitizEntity identification data: EC Entity code = "+entity.getId().getEntityid() +" , citizen id = "+entity.getId().getCityId()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	@SuppressWarnings("unchecked")
	public  List<TctEcCitizEntity> retrieveEntityCitizByEntId(int entityId) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<TctEcCitizEntity> retrieveEntityAddrByEntId(int entityId)"));
	    	ejbLogger.debug(new StandardLogMessage("ecEntityId "+entityId));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getEcCitizEntitiesById");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("entityId", entityId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	List<TctEcCitizEntity> ecCitEntities = (List<TctEcCitizEntity>) q.getResultList();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return ecCitEntities;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
}
