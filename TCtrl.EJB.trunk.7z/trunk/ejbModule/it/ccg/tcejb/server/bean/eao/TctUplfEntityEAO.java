package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctCorrisp;
import it.ccg.tcejb.server.bean.entity.TctSrcFlHEntity;
import it.ccg.tcejb.server.bean.entity.TctUplfEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.StandardLogMessage;

import java.util.List;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

/**
 * Session Bean implementation class TctUplfEntityEAO
 */
@Stateless
@LocalBean
public class TctUplfEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;

    /**
     * Default constructor. 
     */
    public TctUplfEntityEAO() {
        // TODO Auto-generated constructor stub
    }
    
    public TctUplfEntity retrieveByRunIdAndUplId(int runId,int uplId) throws BackEndException{
		//ejbLogger.debug(new StandardLogMessage("createNativeQuery"));

//		String queryString =  "SELECT UPLFILE FROM TCTUPLF " +
//					"WHERE RUNID = ? AND UPLID = ?";
    	
    	Query query = this.manager.createNamedQuery("getUplfEntByRunIDAndUplfID");
		//ejbLogger.debug(new StandardLogMessage(sqlString));
		//Query query = this.manager.createNativeQuery(queryString, TctUplfEntity.class);
		query.setParameter("runId", runId);
		query.setParameter("uplId", uplId);
		//ejbLogger.debug(new StandardLogMessage("getResultList"));
		TctUplfEntity entity = (TctUplfEntity)query.getSingleResult();
		
		return entity;
		//ejbLogger.debug(new StandardLogMessage("return"));
		
	}

}
