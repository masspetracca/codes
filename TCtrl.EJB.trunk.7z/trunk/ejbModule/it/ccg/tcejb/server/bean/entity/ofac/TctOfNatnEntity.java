package it.ccg.tcejb.server.bean.entity.ofac;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTOFNATN database table.
 * 
 */
@Entity
@Table(name="TCTOFNATN")
@NamedQueries({
	@NamedQuery(name="deleteOfNatnEveryEntity", query="DELETE FROM TctOfNatnEntity"),
	@NamedQuery(name="getOfNatnEntitiesById", query="SELECT entity FROM TctOfNatnEntity entity WHERE entity.id.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctOfNatnEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@EmbeddedId
	private TctOfNatnEntityPK id;

	@Column(nullable=false, length=50)
	private String country;

	@Column(length=50)
	private String mainEntry;

	//bi-directional many-to-one association to TctOfEntitEntity
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	private TctOfEntitEntity tctofentit;

    public TctOfNatnEntity() {
    }

	public TctOfNatnEntityPK getId() {
		return this.id;
	}

	public void setId(TctOfNatnEntityPK id) {
		this.id = id;
	}
	
	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		if (country != null && country.length()>50){
			ejbLogger.debug(country+" >50 than truncate");
			this.country = country.substring(0, 49);
		}else{
			this.country = country;
		}
	}

	public String getMainEntry() {
		return this.mainEntry;
	}

	public void setMainEntry(String mainEntry) {
		if (mainEntry != null && mainEntry.length()>50){
			ejbLogger.debug(mainEntry+" >50 than truncate");
			this.mainEntry = mainEntry.substring(0, 49);
		}else{
			this.mainEntry = mainEntry;
		}
	}

	public TctOfEntitEntity getTctofentit() {
		return this.tctofentit;
	}

	public void setTctofentit(TctOfEntitEntity tctofentit) {
		this.tctofentit = tctofentit;
	}
	
}