package it.ccg.tcejb.server.bean.entity.un;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTUNNAT database table.
 * 
 */
@Entity
@Table(name="TCTUNNAT")
@NamedQueries({
	@NamedQuery(name="deleteUnNatEveryEntity", query="DELETE FROM TctUnNat"),
	@NamedQuery(name="getUnNatEntitiesById", query="SELECT entity FROM TctUnNat entity WHERE entity.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctUnNat implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="NATIONALID")
	private int nationalId;

	@Column(nullable=false)
	private int entityid;
	
	@Column(nullable=false, length=30)
	private String value;

	//bi-directional many-to-one association to TctUnIndiv
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	//@Transient
	private TctUnIndiv tctunindiv;

    public TctUnNat() {
    }
    
	/**
	 * @return the nationalId
	 */
	public int getNationalId() {
		return nationalId;
	}

	/**
	 * @param nationalId the nationalId to set
	 */
	public void setNationalId(int nationalId) {
		this.nationalId = nationalId;
	}

	/**
	 * @return the entityid
	 */
	public int getEntityid() {
		return entityid;
	}

	/**
	 * @param entityid the entityid to set
	 */
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getValue() {
		return this.value;
	}

	/**
	 * 
	 * @param value
	 */
	public void setValue(String value) {
		if (value != null && value.length()>30){
			ejbLogger.debug(value+" >30 than truncate");
			this.value = value.substring(0, 29);
		}else{
			this.value = value;
		}
	}

	/**
	 * 
	 * @return
	 */
	public TctUnIndiv getTctunindiv() {
		return this.tctunindiv;
	}

	/**
	 * 
	 * @param tctunindiv
	 */
	public void setTctunindiv(TctUnIndiv tctunindiv) {
		this.tctunindiv = tctunindiv;
	}
	
}