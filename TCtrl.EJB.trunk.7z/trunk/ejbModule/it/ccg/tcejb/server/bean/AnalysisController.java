package it.ccg.tcejb.server.bean;

import java.util.Date;
import java.util.concurrent.Future;

import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardCheckPointMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class OptimizationController
 */
@Stateless
@LocalBean
@ConcurrencyManagement(ConcurrencyManagementType.CONTAINER)
@TransactionManagement(TransactionManagementType.CONTAINER)
public class AnalysisController {
	private static int finishedAnalysis=0,analysisNumber=0;
	private static Date lastIncrement=null;
	private static final Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public AnalysisController() {
        // TODO Auto-generated constructor stub
    }
    @Asynchronous
    public Future<Boolean> checkStatus(int analysisNum){
    	int finalCheckPoint = ((analysisNum*90)/100);
    	double currentCheckPoint = 0;
    	try {
	    	while ((finishedAnalysis<finalCheckPoint) || ((new Date().getTime()-lastIncrement.getTime())<1800000)){
	    		if (finishedAnalysis!=0){
	    			currentCheckPoint = (100*finishedAnalysis)/analysisNum;
	    		}else{
	    			currentCheckPoint = 0;
	    		}
	    		ejbLogger.info(new StandardCheckPointMessage(currentCheckPoint+"% current: "+finishedAnalysis));
	    		/*
	    		 * check every 5 minutes
	    		 */
	    		if (finishedAnalysis!=analysisNum){
	    			Thread.currentThread().sleep(60000);
	    		}else{
	    			break;
	    		}
	    	}
	    	finishedAnalysis=0;
	    	analysisNumber=0;
	    	return new AsyncResult<Boolean>(true);
    	} catch (InterruptedException e) {
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardCheckPointMessage("Error in	OptimizationController.checkStatus: "+e.getMessage()));
			return new AsyncResult<Boolean>(false);
		}
    }
    
    public void incrementFinishedOptim(){
    	this.finishedAnalysis++;
    	this.lastIncrement = new Date();
    }
}
