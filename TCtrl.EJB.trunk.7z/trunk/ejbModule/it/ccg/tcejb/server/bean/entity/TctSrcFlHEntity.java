package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the TCTSRCFLH database table.
 * 
 */
@Entity
@Table(name="TCTSRCFLH")
public class TctSrcFlHEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false)
	private int downloadid;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date downloadDt;

    @Lob()
	@Column(nullable=false)
	private byte[] ecFile;

    @Lob()
	@Column(nullable=false)
	private byte[] ofacFile;

    @Lob()
	@Column(nullable=false)
	private byte[] unFile;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=30)
	private String updUser;

	//bi-directional one-to-one association to TctDownRegEntity
	@OneToOne
	@JoinColumn(name="DOWNLOADID", nullable=false, insertable=false, updatable=false)
	private TctDownRegEntity tctdownreg;

/*	//bi-directional many-to-one association to TctSrcUpDtEntity
	@OneToMany(mappedBy="tctsrcflh", cascade={CascadeType.ALL})*/
	//private Set<TctSrcUpDtEntity> tctsrcupdts;
		
    public TctSrcFlHEntity() {
    }

	public int getDownloadid() {
		return this.downloadid;
	}

	public void setDownloadid(int downloadid) {
		this.downloadid = downloadid;
	}

	public Date getDownloadDt() {
		return this.downloadDt;
	}

	public void setDownloadDt(Date downloadDt) {
		this.downloadDt = downloadDt;
	}

	public byte[] getEcFile() {
		return this.ecFile;
	}

	public void setEcFile(byte[] ecFile) {
		this.ecFile = ecFile;
	}

	public byte[] getOfacFile() {
		return this.ofacFile;
	}

	public void setOfacFile(byte[] ofacFile) {
		this.ofacFile = ofacFile;
	}

	public byte[] getUnFile() {
		return this.unFile;
	}

	public void setUnFile(byte[] unFile) {
		this.unFile = unFile;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public TctDownRegEntity getTctdownreg() {
		return this.tctdownreg;
	}

	public void setTctdownreg(TctDownRegEntity tctdownreg) {
		this.tctdownreg = tctdownreg;
	}

	/**
	 * @return the tctsrcupdts
	 *//*
	public Set<TctSrcUpDtEntity> getTctsrcupdts() {
		return tctsrcupdts;
	}

	*//**
	 * @param tctsrcupdts the tctsrcupdts to set
	 *//*
	public void setTctsrcupdts(Set<TctSrcUpDtEntity> tctsrcupdts) {
		this.tctsrcupdts = tctsrcupdts;
	}*/
	
	
}