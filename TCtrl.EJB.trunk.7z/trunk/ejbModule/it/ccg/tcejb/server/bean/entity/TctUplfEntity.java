package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the TCTUPLF database table.
 * 
 */
@Entity
@Table(name="TCTUPLF")
@NamedQueries({
	@NamedQuery(name="getUplfEntByRunIDAndUplfID",   query="SELECT entity " +
            "								            FROM TctUplfEntity entity " +
            "								            WHERE entity.id.uplid  = :uplId" +
            "											AND entity.id.runid = :runId"
            )
	
})
public class TctUplfEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TctUplfEntityPK id;

	private String note;

	private Timestamp upddate;

	private String updtype;

	private String updusr;

	@Lob
	private byte[] uplfile;

	@Column(name="UPLFILE_DATE_CREATED")
	private Timestamp uplfileDateCreated;

	@Column(name="UPLFILE_FILENAME")
	private String uplfileFilename;

	@Column(name="UPLFILE_FILESIZE")
	private int uplfileFilesize;

	public TctUplfEntity() {
	}

	public TctUplfEntityPK getId() {
		return this.id;
	}

	public void setId(TctUplfEntityPK id) {
		this.id = id;
	}

	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

	public byte[] getUplfile() {
		return this.uplfile;
	}

	public void setUplfile(byte[] uplfile) {
		this.uplfile = uplfile;
	}

	public Timestamp getUplfileDateCreated() {
		return this.uplfileDateCreated;
	}

	public void setUplfileDateCreated(Timestamp uplfileDateCreated) {
		this.uplfileDateCreated = uplfileDateCreated;
	}

	public String getUplfileFilename() {
		return this.uplfileFilename;
	}

	public void setUplfileFilename(String uplfileFilename) {
		this.uplfileFilename = uplfileFilename;
	}

	public int getUplfileFilesize() {
		return this.uplfileFilesize;
	}

	public void setUplfileFilesize(int uplfileFilesize) {
		this.uplfileFilesize = uplfileFilesize;
	}

}