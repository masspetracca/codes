package it.ccg.tcejb.server.bean.entity.ec;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTECPSSPT database table.
 * 
 */
@Embeddable
public class TctEcPssPtEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int pssPrtId;

	@Column(unique=true, nullable=false)
	private int entityid;

    public TctEcPssPtEntityPK() {
    }
	public int getPssPrtId() {
		return this.pssPrtId;
	}
	public void setPssPrtId(int pssPrtId) {
		this.pssPrtId = pssPrtId;
	}
	public int getEntityid() {
		return this.entityid;
	}
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctEcPssPtEntityPK)) {
			return false;
		}
		TctEcPssPtEntityPK castOther = (TctEcPssPtEntityPK)other;
		return 
			(this.pssPrtId == castOther.pssPrtId)
			&& (this.entityid == castOther.entityid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.pssPrtId;
		hash = hash * prime + this.entityid;
		
		return hash;
    }
}