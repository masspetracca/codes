package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTRUNREG database table.
 * 
 */
//@Embeddable
public class TctRunRegEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int runId;

	@Column(unique=true, nullable=false)
	private int cmpnid;

    public TctRunRegEntityPK() {
    }
	public int getRunId() {
		return this.runId;
	}
	public void setRunId(int runId) {
		this.runId = runId;
	}
	public int getCmpnid() {
		return this.cmpnid;
	}
	public void setCmpnid(int cmpnid) {
		this.cmpnid = cmpnid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctRunRegEntityPK)) {
			return false;
		}
		TctRunRegEntityPK castOther = (TctRunRegEntityPK)other;
		return 
			(this.runId == castOther.runId)
			&& (this.cmpnid == castOther.cmpnid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.runId;
		hash = hash * prime + this.cmpnid;
		
		return hash;
    }
}