package it.ccg.tcejb.server.bean;

import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardCheckPointMessage;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;
import it.ccg.tcejb.server.util.ListSourceDownloader;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class DownloadManager
 */
@Stateless
@Local(DownloadManagerLocal.class)
@LocalBean
public class DownloadManager implements DownloadManagerLocal {
	private static final Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public DownloadManager() {
        // TODO Auto-generated constructor stub
    }
    
    public void downloadECList(){
    	ejbLogger.debug(new StandardLogMessage("in downloadECList"));
    	ListSourceDownloader downloader = new ListSourceDownloader();
    	try {
    		ejbLogger.debug(new StandardCheckPointMessage("Start download EC LIST"));
			downloader.readFile(ListSourceDownloader.Source.EC);
			ejbLogger.debug(new StandardCheckPointMessage("EC LIST download completed"));
		} catch (MalformedURLException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.debug(new StandardCheckPointMessage("EC LIST download not completed, message "+e.getMessage()));
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.debug(new StandardCheckPointMessage("EC LIST download not completed, message "+e.getMessage()));
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.debug(new StandardCheckPointMessage("EC LIST download not completed, message "+e.getMessage()));
		}
    }

    public void downloadUNList(){
    	ejbLogger.debug(new StandardLogMessage("in downloadUNList"));
    	ListSourceDownloader downloader = new ListSourceDownloader();
    	try {
    		ejbLogger.info(new StandardCheckPointMessage("Start download UN LIST"));
			downloader.readFile(ListSourceDownloader.Source.UN);
			ejbLogger.info(new StandardCheckPointMessage("UN LIST download completed"));
		} catch (MalformedURLException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("UN LIST download not completed, message "+e.getMessage()));
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("UN LIST download not completed, message "+e.getMessage()));
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("UN LIST download not completed, message "+e.getMessage()));
		}
    }
    
    public void downloadOFACList(){
    	ejbLogger.debug(new StandardLogMessage("in downloadOFACList"));
    	ListSourceDownloader downloader = new ListSourceDownloader();
    	try {
    		ejbLogger.info(new StandardCheckPointMessage("Start download OFAC LIST"));
			downloader.readFile(ListSourceDownloader.Source.OFAC);
			ejbLogger.info(new StandardCheckPointMessage("OFAC LIST download completed"));
		} catch (MalformedURLException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("OFAC LIST download not completed, message "+e.getMessage()));
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("OFAC LIST download not completed, message "+e.getMessage()));
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("OFAC LIST download not completed, message "+e.getMessage()));
		}
    }
    
    public void deleteDownloadedList(){
    	ejbLogger.debug(new StandardLogMessage("in deleteDownloadedList"));
    	try {
    		ejbLogger.info(new StandardCheckPointMessage("Delete downloaded lists start"));
			Path ecPath = Paths.get(SystemProperties.getSystemProperty("ec.file.name"));
			Path unPath = Paths.get(SystemProperties.getSystemProperty("un.file.name"));
			Path ofacPath = Paths.get(SystemProperties.getSystemProperty("ofac.file.name"));
			
			
			Files.deleteIfExists(ecPath);
			Files.deleteIfExists(unPath);
			Files.deleteIfExists(ofacPath);
			ejbLogger.info(new StandardCheckPointMessage("Delete downloaded lists completed"));
	    } catch (BackEndException e) {
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Delete downloaded not completed, message "+e.getMessage()));
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Delete downloaded not completed, message "+e.getMessage()));
		}
    }
}
