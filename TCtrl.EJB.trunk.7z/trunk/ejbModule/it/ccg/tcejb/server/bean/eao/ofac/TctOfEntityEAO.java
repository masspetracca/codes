package it.ccg.tcejb.server.bean.eao.ofac;

import it.ccg.tcejb.server.bean.entity.ofac.TctOfEntitEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctOfEntityEAO
 */
@Stateless
@LocalBean
public class TctOfEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	/*@Resource
	private SessionContext sessionContext;*/
	
	private EntityManager manager;
	@EJB
	private TctOfAddrEAO addressEAO;
	@EJB
	private TctOfAkaAlEAO akaALiasEAO;
	@EJB
	private TctOfBirthEAO birthEAO;
	@EJB
	private TctOfCitzEAO citzEAO;
	@EJB
	private TctOfDtBirEAO dtBirtEAO;
	@EJB
	private TctOfIdLstEAO idListEAO;
	@EJB
	private TctOfNatnEAO natnEAO;
	@EJB
	private TctOfPrglEAO prgListEAO;
	@EJB
	private TctOfVsInfEAO vssInfEAO;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
    /**
     * Default constructor. 
     */
    public TctOfEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctOfEntitEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in TctOfEntitEntity(TctOfEntit entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctOfEntitEntity identification data: OFAC identity code = "+entity.getEntityId()+", sdn type= "+entity.getSdnType()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser("System");
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
	    	
	    	/*if (entity.getTctofaddrs()!=null && entity.getTctofaddrs().size()>0){
    			this.addressEAO.insertEntity(entity.getTctofaddrs());
    		}
    		if(entity.getTctofakaals()!=null && entity.getTctofakaals().size()>0){
    			this.akaALiasEAO.insertEntity(entity.getTctofakaals());
    		}
    		if(entity.getTctofbirths()!=null && entity.getTctofbirths().size()>0){
    			this.birthEAO.insertEntity(entity.getTctofbirths());
    		}
    		if(entity.getTctofcitzs()!=null && entity.getTctofcitzs().size()>0){
    			this.citzEAO.insertEntity(entity.getTctofcitzs());
    		}
    		if(entity.getTctofdtbirs()!=null && entity.getTctofdtbirs().size()>0){
    			this.dtBirtEAO.insertEntity(entity.getTctofdtbirs());
    		}
    		if(entity.getTctofidlsts()!=null && entity.getTctofidlsts().size()>0){
    			this.idListEAO.insertEntity(entity.getTctofidlsts());
    		}
    		if(entity.getTctofnatns()!=null && entity.getTctofnatns().size()>0){
    			this.natnEAO.insertEntity(entity.getTctofnatns());
    		}
    		if(entity.getTctofprgls()!=null && entity.getTctofprgls().size()>0){
    			this.prgListEAO.insertEntity(entity.getTctofprgls());
    		}if(entity.getTctofvsinfs()!=null && entity.getTctofvsinfs().size()>0){
    			this.vssInfEAO.insertEntity(entity.getTctofvsinfs());
    		}*/
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public void insertEntity(List<TctOfEntitEntity> entitie) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(List<TctOfEntitEntity> entitie)"));
	    	int idxToFlush = 0;
	    	for (TctOfEntitEntity entity :entitie){
		    	ejbLogger.debug(new StandardLogMessage("TctOfEntit identification data: OFAC identity code = "+entity.getEntityId()+", sdn type= "+entity.getSdnType()));
		    	ejbLogger.debug(new StandardLogMessage("insert"));
		    			    	
		    	this.manager.persist(entity);
		    	idxToFlush++;
		    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
		    		ejbLogger.debug(new StandardLogMessage("insert"));
			    	this.manager.flush();
		    	}
	    	}
	    	ejbLogger.debug(new StandardLogMessage("last insert"));
	    	this.manager.flush();

	    /*	for (TctOfEntit entity :entitie){
	    		if (entity.getTctofaddrs()!=null && entity.getTctofaddrs().size()>0){
	    			this.addressEAO.insertEntity(entity.getTctofaddrs());
	    		}
	    		if(entity.getTctofakaals()!=null && entity.getTctofakaals().size()>0){
	    			this.akaALiasEAO.insertEntity(entity.getTctofakaals());
	    		}
	    		if(entity.getTctofbirths()!=null && entity.getTctofbirths().size()>0){
	    			this.birthEAO.insertEntity(entity.getTctofbirths());
	    		}
	    		if(entity.getTctofcitzs()!=null && entity.getTctofcitzs().size()>0){
	    			this.citzEAO.insertEntity(entity.getTctofcitzs());
	    		}
	    		if(entity.getTctofdtbirs()!=null && entity.getTctofdtbirs().size()>0){
	    			this.dtBirtEAO.insertEntity(entity.getTctofdtbirs());
	    		}
	    		if(entity.getTctofidlsts()!=null && entity.getTctofidlsts().size()>0){
	    			this.idListEAO.insertEntity(entity.getTctofidlsts());
	    		}
	    		if(entity.getTctofnatns()!=null && entity.getTctofnatns().size()>0){
	    			this.natnEAO.insertEntity(entity.getTctofnatns());
	    		}
	    		if(entity.getTctofprgls()!=null && entity.getTctofprgls().size()>0){
	    			this.prgListEAO.insertEntity(entity.getTctofprgls());
	    		}if(entity.getTctofvsinfs()!=null && entity.getTctofvsinfs().size()>0){
	    			this.vssInfEAO.insertEntity(entity.getTctofvsinfs());
	    		}
	    	}*/
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
            
  	public void deleteEntity(TctOfEntitEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctOfEntitEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctOfEntitEntity identification data: OFAC identity code = "+entity.getEntityId()+", sdn type= "+entity.getSdnType()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void deleteEveryEntity() throws BackEndException{
  		try{
	    	
	    	this.addressEAO.deleteEveryEntity();
	    	this.akaALiasEAO.deleteEveryEntity();
	    	this.birthEAO.deleteEveryEntity();
	    	this.citzEAO.deleteEveryEntity();
	    	this.dtBirtEAO.deleteEveryEntity();
	    	this.idListEAO.deleteEveryEntity();
	    	this.natnEAO.deleteEveryEntity();
	    	this.prgListEAO.deleteEveryEntity();
	    	this.vssInfEAO.deleteEveryEntity();
  			
	    	ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteOfEveryEntity");
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctOfEntitEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctOfEntitEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctOfEntitEntity identification data: OFAC identity code = "+entity.getEntityId()+", sdn type= "+entity.getSdnType()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	@SuppressWarnings("unchecked")
	public List<TctOfEntitEntity> retrieveEntityById(int entityId) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<TctOfEntitEntity> retrieveEntityById(int entityId)"));
	    	ejbLogger.debug(new StandardLogMessage("ofEntityId "+entityId));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getOfEntitiesById");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("entityId", entityId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<TctOfEntitEntity> ofEntities = (List<TctOfEntitEntity>) q.getResultList();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return ofEntities;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  		
  	}
  	
  	@SuppressWarnings("unchecked")
	public List<TctOfEntitEntity> retrieveEntityBySrcListDate(String srcLstDate) throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in List<TctOfEntitEntity> retrieveEntityBySrcListDate(String srcLstDate)"));
       	ejbLogger.debug(new StandardLogMessage("srcLstDate : "+srcLstDate));
       	List<TctOfEntitEntity> tctOfEntities = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getOfEntitiesBySrcListDate");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			q.setParameter("srcListDate", df.parse(srcLstDate));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			tctOfEntities = (List<TctOfEntitEntity>) q.getResultList();
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return tctOfEntities; 	
  	}
  	
  	@SuppressWarnings("unchecked")
	public List<TctOfEntitEntity> retrievePeopleBySrcListDate(String srcLstDate) throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in List<TctOfEntitEntity> retrievePeopleBySrcListDate(String srcLstDate)"));
       	ejbLogger.debug(new StandardLogMessage("srcLstDate : "+srcLstDate));
       	List<TctOfEntitEntity> tctOfEntities = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getOfPeopleBySrcListDate");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			q.setParameter("srcListDate", df.parse(srcLstDate));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			tctOfEntities = (List<TctOfEntitEntity>) q.getResultList();
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return tctOfEntities;
  	}
  	
  	public Date getLatestSrcListDate() throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in Date getLatestSrcListDate()"));
  		Date maxSrcListDate= null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getOfLatestSrcListDate");
			ejbLogger.debug(new StandardLogMessage("getSingleResult"));
			maxSrcListDate = (Date) q.getSingleResult();
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return maxSrcListDate;
  		
  	}
  	
  	@SuppressWarnings("unchecked")
	public List<TctOfEntitEntity> retrieveLatestEntities() throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in List<TctOfEntitEntity> retrieveLatestEntities()"));
       	List<TctOfEntitEntity> tctOfEntities = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getOfLatestEntities");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			tctOfEntities = (List<TctOfEntitEntity>) q.getResultList();
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return tctOfEntities;
  	}
  	
  	@SuppressWarnings("unchecked")
	public List<TctOfEntitEntity> retrieveLatestPeople() throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in List<TctOfEntitEntity> retrieveLatestPeople()"));
       	List<TctOfEntitEntity> tctOfEntities = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getOfLatestPeople");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			tctOfEntities = (List<TctOfEntitEntity>) q.getResultList();
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return tctOfEntities;
  	}
  	
  	@SuppressWarnings("unchecked")
	public List<TctOfEntitEntity> retrieveAllEntities() throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<TctOfEntitEntity> retrieveAllEntities()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getOfEntities");
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<TctOfEntitEntity> ofEntities = (List<TctOfEntitEntity>) q.getResultList();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return ofEntities;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}   		
  	}
}
