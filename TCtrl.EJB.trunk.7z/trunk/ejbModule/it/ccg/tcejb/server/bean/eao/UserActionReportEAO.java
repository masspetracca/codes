package it.ccg.tcejb.server.bean.eao;

import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.HashMap;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;

import it.ccg.tcejb.server.bean.eao.view.UserActionReportEAOLocal;
import it.ccg.tcejb.server.bean.eao.view.UserActionReportEAORemote;
import it.ccg.tcejb.server.util.UserActionDto;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class UserActionReportEAO
 */
@Stateless
@Local(UserActionReportEAOLocal.class)
@Remote(UserActionReportEAORemote.class)
@LocalBean
public class UserActionReportEAO implements UserActionReportEAORemote, UserActionReportEAOLocal {

	private static HashMap<String, UserActionDto> actions = new HashMap<String, UserActionDto>();
    /**
     * Default constructor. 
     */
    public UserActionReportEAO() {
        // TODO Auto-generated constructor stub
    }

    @SuppressWarnings("static-access")
	public void addAction(String user, String action){
    	 UserActionDto dto = new UserActionDto();
    	 dto.setAction(action);
    	 dto.setUser(user);
    	 dto.setActionDate(new GregorianCalendar());
    	 SimpleDateFormat dataFormatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    	 dto.setStringActionDate(dataFormatter.format(dto.getActionDate().getTime()));
    	 this.actions.put(dto.getUser()+" "+dto.getAction(), dto);
    	 
     }
     
     @SuppressWarnings("static-access")
	public HashMap<String, UserActionDto> getActionReport() {
    	 return this.actions;
    }
}
