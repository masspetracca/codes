package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;


/**
 * The persistent class for the TCTCORRISP database table.
 * 
 */
@Entity
@Table(name="TCTCORRISP")
@NamedQueries({
	@NamedQuery(name="getFPositiveByCmpnId",   query="SELECT entity " +
            "								          FROM TctCorrispEntity entity " +
            "								         WHERE entity.id.cmpnid  = :cmpnId" +
            "										   AND entity.status = 'F'") /* ,
          @NamedQuery(name="getByRunId",   query="SELECT entity " +
                    "								FROM TctCorrispEntity entity " +
                    "								WHERE entity.id.runId  = :runId" ) */
           /* @NamedQuery(name="getByRunId",   query="SELECT entity " +
                    "								FROM TctCorrispEntity entity " +
                    "								LEFT JOIN FETCH entity.tctaggrent" +
                    "								LEFT JOIN FETCH entity.tctrunreg" +
                    "								WHERE entity.id.runId  = :runId " +
                    "								AND entity.id.cmpnid  = :cmpnId" +
                    "								AND entity.status <> 'D'" +
                    "								ORDER BY entity.status DESC")  */

})
public class TctCorrispEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TctCorrispEntityPK id;

	@Column(nullable=false, length=100)
	private String clntName;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal corrIndex;

	@Column(nullable=false, length=255)
	private String entityName;

	@Column(nullable=false, length=1)
	private String status;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;
	
	@Column(nullable=false, length=50)
	private String updUser;
	
	

	//bi-directional many-to-one association to TctAggrEntEntity
	/*@ManyToOne(cascade={CascadeType.DETACH})
	@JoinColumns({
		@JoinColumn(name="AGGRID", referencedColumnName="AGGREGID", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="DOWNLOADID", referencedColumnName="DOWNLOADID", nullable=false, insertable=false, updatable=false)
		})*/
	@Transient
	private TctAggrEntEntity tctaggrent;

	//bi-directional many-to-one association to TctClientEntity
    @ManyToOne
	@JoinColumns({
		@JoinColumn(name="CLNTID", referencedColumnName="CLNTID", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="CMPNID", referencedColumnName="CMPNID", nullable=false, insertable=false, updatable=false)
		})
	private TctClientEntity tctclient;

	//bi-directional many-to-one association to TctRunRegEntity
    @ManyToOne
	@JoinColumns({
		@JoinColumn(name="CMPNID", referencedColumnName="CMPNID", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="RUNID", referencedColumnName="RUNID", nullable=false, insertable=false, updatable=false)
		})
	private TctRunRegEntity tctrunreg;

    public TctCorrispEntity() {
    }

	public TctCorrispEntityPK getId() {
		return this.id;
	}

	public void setId(TctCorrispEntityPK id) {
		this.id = id;
	}
	
	public String getClntName() {
		return this.clntName;
	}

	public void setClntName(String clntName) {
		this.clntName = clntName;
	}

	public BigDecimal getCorrIndex() {
		return this.corrIndex;
	}

	public void setCorrIndex(BigDecimal corrIndex) {
		this.corrIndex = corrIndex;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public TctAggrEntEntity getTctaggrent() {
		return this.tctaggrent;
	}

	public void setTctaggrent(TctAggrEntEntity tctaggrent) {
		this.tctaggrent = tctaggrent;
	}
	
	public TctClientEntity getTctclient() {
		return this.tctclient;
	}

	public void setTctclient(TctClientEntity tctclient) {
		this.tctclient = tctclient;
	}
	
	public TctRunRegEntity getTctrunreg() {
		return this.tctrunreg;
	}

	public void setTctrunreg(TctRunRegEntity tctrunreg) {
		this.tctrunreg = tctrunreg;
	}
	
}