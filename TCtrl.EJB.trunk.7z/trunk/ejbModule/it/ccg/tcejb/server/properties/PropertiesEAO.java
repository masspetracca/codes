package it.ccg.tcejb.server.properties;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

import it.ccg.tcejb.server.exception.DataNotValidException;
import it.ccg.tcejb.server.exception.PropertyException;
import it.ccg.tcejb.server.properties.view.PropertiesEAOLocal;
import javax.ejb.Local;

/**
 * Session Bean implementation class PropertiesEAO
 */
@Stateless
@Local(PropertiesEAOLocal.class)
public class PropertiesEAO implements PropertiesEAOLocal {

	final String propertyPath = System.getProperty("user.install.root")+"/properties/terrorismcontrol.properties";
	
	static HashMap<String,String> propertyMap = new HashMap<String,String>();
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public HashMap<String,String> getPropertyMap() throws PropertyException {
		if (propertyMap==null||propertyMap.size()==0) {
			this.loadProperties();
			return propertyMap;
		} else {
			return propertyMap;
		}
	}
	
	public HashMap<String,String> refreshPropertyMap() throws PropertyException {
		this.loadProperties();
		return propertyMap;
	}
	
		
	public void loadProperties() throws PropertyException {
		Properties props = new Properties();
		
		String fileNotFound = "Property file not found in path: "+propertyPath;
		
		String strPassword = "password";
		
		String ioError = "Error occurred loading the Property file";
		
		try {
			
			//System.out.println("Loading System properties from "+propertyPath);
			
			// load all properties from file
			props.load(new FileInputStream(propertyPath));
			
			// get the set of property name
			Set<Object> propertyNameSet = props.keySet();
			
			// for each property name found, get the related property value and put it into the property map
			for (Object propertyName:propertyNameSet) {
				propertyMap.put(propertyName.toString(), props.getProperty(propertyName.toString()));
				if (propertyName.toString().indexOf(strPassword)==-1) {
					//System.out.println("Loaded property "+propertyName.toString()+": "+props.getProperty(propertyName.toString()));
				}
			}
			
			log.info("System properties loading successed");
			
		} catch (FileNotFoundException e) {
			//System.out.println(fileNotFound);
			throw new PropertyException(fileNotFound, e.getStackTrace().toString());
		} catch (IOException e) {
			//System.out.println(ioError+" - "+e.getMessage());
			throw new PropertyException(ioError, e.getStackTrace().toString());
		}
	}
    

}
