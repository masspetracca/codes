package it.ccg.tcejb.server.security.view;



public interface PwdManagerLocal {

	public boolean changeUserPassword(String user, String oldPassword, String newPassword) throws Exception;
	public boolean disableUserAccount(String user) throws Exception;
	
}
