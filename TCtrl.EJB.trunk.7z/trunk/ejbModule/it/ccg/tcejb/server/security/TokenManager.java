package it.ccg.tcejb.server.security;


import java.util.Hashtable;

import javax.ejb.Stateless;

import org.apache.log4j.Logger;

import it.ccg.tcejb.server.exception.DataNotAvailableException;
import it.ccg.tcejb.server.exception.DataNotValidException;
import it.ccg.tcejb.server.security.view.TokenManagerLocal;
import javax.ejb.Local;
import javax.ejb.LocalBean;

/**
 * Session Bean implementation class TokenManager
 */
@Stateless
@Local(TokenManagerLocal.class)
@LocalBean
public class TokenManager implements TokenManagerLocal{
	

	private static final Hashtable<String, String> tokenTable = new Hashtable<String, String>();  
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
		
	
	public String fetchToken(String user) throws DataNotValidException {
		
		return tokenTable.get(user);
		
	}

	
	public void add(String user, String token) throws DataNotAvailableException,DataNotValidException {
		
		tokenTable.put(user, token);
		
	}

	public void upsert(String user, String token) throws DataNotValidException {
		
		tokenTable.put(user, token);
		
	}
	


	
}


