package it.ccg.infoprovider.smartgwt.server.dmi;



import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.util.StandardLogMessage;
import it.ccg.infoprovider.smartgwt.server.util.CriteriaJpqlOperatorMap;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.isomorphic.criteria.AdvancedCriteria;
import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;



/**
 * Session Bean implementation class HisPrDmiCmtEAO
 */
@Stateless
public class HisPrDmiEAO implements HisPrDmiEAOLocal {
	
	@PersistenceContext(name="HisPrEM", unitName="InfoProviderEJB")
	private EntityManager em;
	
	
	private CriteriaJpqlOperatorMap criteriaSqlOperatorMap = new CriteriaJpqlOperatorMap();
	
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
	

    /**
     * Default constructor. 
     */
    public HisPrDmiEAO() {
    	this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    

	@SuppressWarnings("unchecked")
	@Override
	public DSResponse fetchInfo(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		
		String selectClause = "SELECT new HisPrInfo(hisPr.id.instrumentId, hisPr.instr.instrumentName, MIN(hisPr.id.priceDate), MAX(hisPr.id.priceDate), COUNT(hisPr.id.priceDate))";
		String fromClause = "FROM HistoricalPricesEntity hisPr JOIN FETCH hisPr.instr";
		String whereClause = "WHERE 1=1";
		String groupByClause = "GROUP BY hisPr.id.instrumentId, hisPr.instr.instrumentName";
		String havingClause = "HAVING 1=1";
		String orderByClause = new String();
		
		
		Map<String, Object> jpaQueryParams = new HashMap<String, Object>();
		
		// Where  ******************************************
    	AdvancedCriteria advancedCriteria = dsRequest.getAdvancedCriteria();
		Map<String, Object> criteriaStructure = advancedCriteria.getCriteriaAsMap();
		List<Map<String, Object>> criteriaList = (List<Map<String, Object>>)criteriaStructure.get("criteria");

		if((criteriaList.size() > 0) && (criteriaList.get(0).get("criteria") !=  null)) {
			criteriaList = (List<Map<String, Object>>)criteriaList.get(0).get("criteria");
		}
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "criteriaList: " + criteriaList));
			
		for(Map<String, Object> criteria : criteriaList) {
    		
    		if(criteria.isEmpty()) {
    			break;
    		}
    		
    		
    		// fieldName, operator, value
    		
    		String fieldName = (String)criteria.get("fieldName");
    		String operator = (String)criteria.get("operator");
    		
    		
    		if(fieldName.equalsIgnoreCase("instrumentId")) {
    			
    			whereClause += " AND " + criteriaSqlOperatorMap.convertToJPQL("hisPr.id.instrumentId", operator, (String)criteria.get("value"));
    		}
    		else if(fieldName.equalsIgnoreCase("instrumentName")) {
    			
    			whereClause += " AND " + criteriaSqlOperatorMap.convertToJPQL("hisPr.instr.instrumentName", operator, (String)criteria.get("value"));
    		}
    		else if(fieldName.equalsIgnoreCase("minPriceDate")) {
    			
    			Date date = (Date)criteria.get("value");
    			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    			String value = sdf.format(date);
    			
    			havingClause += " AND " + criteriaSqlOperatorMap.convertToJPQL("MIN(hisPr.id.priceDate)", operator, value);
    		}
			else if(fieldName.equalsIgnoreCase("maxPriceDate")) {
				
				Date date = (Date)criteria.get("value");
    			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    			String value = sdf.format(date);
				
				havingClause += " AND " + criteriaSqlOperatorMap.convertToJPQL("MAX(hisPr.id.priceDate)", operator, value);
			}
			else if(fieldName.equalsIgnoreCase("count")) {
				
				havingClause += " AND " + criteriaSqlOperatorMap.convertToJPQL("COUNT(hisPr.id.priceDate)", operator, (String)criteria.get("value"));
			}
			else {
				
			}
    		
    	}
		// Where  ******************************************
    	
    	// Order by ****************************************
    	List<String> sortByFieldsList = dsRequest.getSortByFields();
    	
    	if(sortByFieldsList.size() > 0) {
    		orderByClause = "ORDER BY" + " ";
    		
    		for(String sortByField : sortByFieldsList) {
        		if(sortByField.charAt(0) == '-') {
        			String fieldName = sortByField.substring(1);
        			
        			if(fieldName.equalsIgnoreCase("instrumentId")) {
        				orderByClause += "hisPr.id.instrumentId desc" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("instrumentName")) {
            			orderByClause += "hisPr.instr.instrumentName desc" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("minPriceDate")) {
            			orderByClause += "MIN(hisPr.id.priceDate) desc" + ",";
            		}
        			else if(fieldName.equalsIgnoreCase("maxPriceDate")) {
        				orderByClause += "MAX(hisPr.id.priceDate) desc" + ",";
        			}
        			else if(fieldName.equalsIgnoreCase("count")) {
        				orderByClause += "COUNT(hisPr.id.priceDate) desc" + ",";
        			}
        			else {
        				
        			}
        			
        		}
        		else {
        			String fieldName = sortByField;
        			
        			if(fieldName.equalsIgnoreCase("instrumentId")) {
        				orderByClause += "hisPr.id.instrumentId" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("instrumentName")) {
            			orderByClause += "hisPr.instr.instrumentName" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("minPriceDate")) {
            			orderByClause += "MIN(hisPr.id.priceDate)" + ",";
            		}
        			else if(fieldName.equalsIgnoreCase("maxPriceDate")) {
        				orderByClause += "MAX(hisPr.id.priceDate)" + ",";
        			}
        			else if(fieldName.equalsIgnoreCase("count")) {
        				orderByClause += "COUNT(hisPr.id.priceDate)" + ",";
        			}
        			else {
        				
        			}
        		}
        		
        	}
        	
        	orderByClause = orderByClause.substring(0, orderByClause.length() - 1);
    	}
    	else {
    		orderByClause = "ORDER BY hisPr.id.instrumentId";
    	}
    	// Order by ****************************************
    	
    	
    	String jpaQueryString = selectClause + " " +
								fromClause + " " +
								whereClause + " " +
								groupByClause + " " +
								havingClause + " " +
								orderByClause;
    	
    	
    	defaultLogger.debug(new StandardLogMessage(this.currentUser, "jpaQueryString: " + jpaQueryString));
    	
    	
		return executeQuery(jpaQueryString, jpaQueryParams, dsRequest);
	}


	@SuppressWarnings("unchecked")
	@Override
	public DSResponse fetchInstrHis(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		
		String selectClause = "SELECT new HisPrInstrHis(hisPr.id.priceDate, hisPr.closingPrice)";
		String fromClause = "FROM HistoricalPricesEntity hisPr";
		String whereClause = "WHERE hisPr.id.instrumentId = :instrId";
		String groupByClause = "";
		String havingClause = "";
		String orderByClause = new String();
		
		
		// Fixed Criteria to JPA Query Parameters  ******************************************
    	Map<String, String> criteria = dsRequest.getCriteria();
    	
		Map<String, Object> jpaQueryParams = new HashMap<String, Object>();
		jpaQueryParams.put("instrId", Integer.parseInt(criteria.get("instrId")));
		// Fixed Criteria to JPA Query Parameters  ******************************************
		
		
		// Where  ******************************************
    	AdvancedCriteria advancedCriteria = dsRequest.getAdvancedCriteria();
		Map<String, Object> criteriaStructure = advancedCriteria.getCriteriaAsMap();
		List<Map<String, Object>> criteriaList = (List<Map<String, Object>>)criteriaStructure.get("criteria");

		if((criteriaList.size() > 0) && (criteriaList.get(0).get("criteria") !=  null)) {
			criteriaList = (List<Map<String, Object>>)criteriaList.get(0).get("criteria");
		}
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "criteriaList: " + criteriaList));
			
		for(Map<String, Object> crit : criteriaList) {
    		
    		if(crit.isEmpty()) {
    			break;
    		}
    		
    		
    		// fieldName, operator, value
    		
    		String fieldName = (String)crit.get("fieldName");
    		String operator = (String)crit.get("operator");
    		
    		
    		if(fieldName.equalsIgnoreCase("priceDate")) {
    			
    			Date date = (Date)crit.get("value");
    			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    			String value = sdf.format(date);
    			
    			whereClause += " AND " + criteriaSqlOperatorMap.convertToJPQL("hisPr.id.priceDate", operator, value);
    		}

    		else if(fieldName.equalsIgnoreCase("closingPrice")) {
    			
    			whereClause += " AND " + criteriaSqlOperatorMap.convertToJPQL("hisPr.closingPrice", operator, (String)crit.get("value"));
    		}
			else {
				
			}
    		
    	}
		// Where  ******************************************
		
		// Order by ****************************************
    	List<String> sortByFieldsList = dsRequest.getSortByFields();
    	
    	if(sortByFieldsList.size() > 0) {
    		orderByClause = "ORDER BY" + " ";
    		
    		for(String sortByField : sortByFieldsList) {
        		if(sortByField.charAt(0) == '-') {
        			String fieldName = sortByField.substring(1);
        			
        			if(fieldName.equalsIgnoreCase("priceDate")) {
        				orderByClause += "hisPr.id.priceDate desc" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("closingPrice")) {
            			orderByClause += "hisPr.closingPrice desc" + ",";
            		}
        			else {
        				
        			}
        			
        		}
        		else {
        			String fieldName = sortByField;
        			
        			if(fieldName.equalsIgnoreCase("priceDate")) {
        				orderByClause += "hisPr.id.priceDate" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("closingPrice")) {
            			orderByClause += "hisPr.closingPrice" + ",";
            		}
        			else {
        				
        			}
        		}
        		
        	}
        	
        	orderByClause = orderByClause.substring(0, orderByClause.length() - 1);
    	}
    	else {
    		orderByClause = "ORDER BY hisPr.id.priceDate";
    	}
    	// Order by ****************************************
    	
    	
    	
		
    	String jpaQueryString = selectClause + " " +
								fromClause + " " +
								whereClause + " " +
								groupByClause + " " +
								havingClause + " " +
								orderByClause;


    	defaultLogger.debug(new StandardLogMessage(this.currentUser, "jpaQueryString: " + jpaQueryString));
		
		
		return executeQuery(jpaQueryString, jpaQueryParams, dsRequest);
	}

	
	
	
	
	
	private long getTotalRows(Query query) {
		@SuppressWarnings("rawtypes")
		List list = query.getResultList();
    	
    	return list.size();
    }
	
	
	private DSResponse executeQuery(String jpaQueryString, Map<String, Object> jpaQueryParams, DSRequest dsRequest) {
		DSResponse dsResponse = new DSResponse();
		
		
		// Creo la query da eseguire
		Query query = this.createJpaQuery(jpaQueryString, jpaQueryParams);
    	
    	// Paging - DataSource protocol: get requested row range  
		long totalRows = this.getTotalRows(query);
        long startRow = (int)dsRequest.getStartRow();  
        long endRow = (int)dsRequest.getEndRow();
        endRow = Math.min(endRow, totalRows);
        long firstResult = startRow;
        long maxResults = endRow - startRow;
        
		// Settaggi per il paging
        query.setFirstResult((int)firstResult);
    	query.setMaxResults((int)maxResults);
		
		// Eseguo la query
		@SuppressWarnings("rawtypes")
		List dataList = query.getResultList();
		
		// Inserisco i dati della dsResponse
		dsResponse.setData(dataList);
		
		// Tell client what rows are being returned, and what's available  
        dsResponse.setStartRow(startRow);  
        dsResponse.setEndRow(endRow);  
        dsResponse.setTotalRows(totalRows);
		
        
        return dsResponse;
	}
	
	
	private Query createJpaQuery(String jpaQueryString, Map<String, Object> jpaQueryParams) {
		Query query = em.createQuery(jpaQueryString);
		
		if(jpaQueryParams != null) {
			Set<String> keySet = jpaQueryParams.keySet();
			for(String param : keySet) {
				if(jpaQueryParams.get(param) instanceof Long) {
					query.setParameter(param, ((Long)jpaQueryParams.get(param)).intValue());
				}
				else {
					query.setParameter(param, jpaQueryParams.get(param));
				}
			}
		}
		
		return query;
	}
	

}
