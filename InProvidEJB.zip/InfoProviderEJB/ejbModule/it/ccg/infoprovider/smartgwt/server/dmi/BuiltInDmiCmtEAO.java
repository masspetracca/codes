package it.ccg.infoprovider.smartgwt.server.dmi;



import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.util.StandardLogMessage;


import javax.ejb.Stateless;

import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;



/**
 * Session Bean implementation class BuiltInDmiCmtEAO
 */
@Stateless
public class BuiltInDmiCmtEAO implements BuiltInDmiCmtEAOLocal {
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;

    /**
     * Default constructor. 
     */
    public BuiltInDmiCmtEAO() {
    	this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    

	@Override
	public DSResponse fetch(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		return dsRequest.execute();
	}
	
	
	@Override
	public DSResponse add(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		return dsRequest.execute();
	}
	
	
	@Override
	public DSResponse update(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		return dsRequest.execute();
	}
	

	@Override
	public DSResponse remove(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		return dsRequest.execute();
	}

}
