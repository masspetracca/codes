package it.ccg.infoprovider.smartgwt.server.dmi;

import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.service.system.SystemProperties;
import it.ccg.infoprovider.server.util.LogLine;
import it.ccg.infoprovider.server.util.LogReader;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;

import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;

/**
 * Session Bean implementation class LogDmiDAO
 */
@Stateless
public class LogDmiDAO implements LogDmiDAOLocal {
	
	private static final String WS_INSTALL_DIR = System.getProperty("user.install.root");
	private static final String PATH_SEPARATOR = System.getProperty("file.separator");
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	

    /**
     * Default constructor. 
     */
    public LogDmiDAO() {
    	this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    

	@Override
	public DSResponse fetch(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		DSResponse dsResponse = new DSResponse();
		
		String logFileName = dsRequest.getHttpServletRequest().getParameter("logFileName");
		
		LogReader logReader = new LogReader(logFileName);
		List<LogLine> log = logReader.getLog();
		
		
		dsResponse.setData(log);
		
		
		
		
		return dsResponse;
	}
	
	@Override
	public DSResponse fetchLogNames(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		DSResponse dsResponse = new DSResponse();
		
		
		// leggi la directory dei log e ritorna la lista dei nomi
		List<Map<String, String>> list = new ArrayList<Map<String,String>>();
		String logAbsolutePath = WS_INSTALL_DIR + PATH_SEPARATOR + SystemProperties.getProperties().getProperty("ws_log_relative_path");
		File file = new File(logAbsolutePath);
		
		String[] fileArray = file.list();
		for(String fileName : fileArray) {
			Map<String, String> map = new HashMap<String, String>();
			map.put("logFileName", fileName);
			
			list.add(map);
		}
		
		
		dsResponse.setData(list);
		
		
		
		
		return dsResponse;
	}



}
