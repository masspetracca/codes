package it.ccg.infoprovider.smartgwt.server.dmi;


import javax.ejb.Local;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;

@Local
public interface HisPrDmiEAOLocal {
	
	public DSResponse fetchInfo(DSRequest dsRequest) throws Exception;
	public DSResponse fetchInstrHis(DSRequest dsRequest) throws Exception;
	
}
