package it.ccg.infoprovider.smartgwt.server.dmi;

import it.ccg.infoprovider.server.service.system.LocalBeanLookup;

import org.apache.log4j.Logger;

public class InstrDmiEAOFactory {
	
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	
	public InstrDmiEAOFactory() {
		
	}
	
	
	
	public InstrDmiEAOLocal create() {

		InstrDmiEAOLocal instrDmiEAOLocal = (InstrDmiEAOLocal)LocalBeanLookup.lookup(InstrDmiEAOLocal.class.getName());
		
		return instrDmiEAOLocal;
	}

}
