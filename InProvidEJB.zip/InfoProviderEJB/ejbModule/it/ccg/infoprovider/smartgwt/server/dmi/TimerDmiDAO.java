package it.ccg.infoprovider.smartgwt.server.dmi;

import it.ccg.infoprovider.server.bean.business.BloombergBatchBeanLocal;
import it.ccg.infoprovider.server.bean.business.ReutersBatchBeanLocal;
import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.bean.timer.BloombergTimerBeanLocal;
import it.ccg.infoprovider.server.bean.timer.ReutersTimerBeanLocal;
import it.ccg.infoprovider.server.data.TimerData;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;


import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;
import com.isomorphic.util.ErrorMessage;



/**
 * Session Bean implementation class TimerManagerEAO
 */
@Stateless
public class TimerDmiDAO implements TimerDmiDAOLocal {
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
	@EJB
	private BloombergTimerBeanLocal bloombergTimerBeanLocal;
	
	@EJB
	private ReutersTimerBeanLocal reutersTimerBeanLocal;
	
	@EJB
	private BloombergBatchBeanLocal bloombergBatchBeanLocal;
	
	@EJB
	private ReutersBatchBeanLocal reutersBatchBeanLocal;

    /**
     * Default constructor. 
     */
    public TimerDmiDAO() {
    	this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	@Override
	public DSResponse fetch(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		DSResponse dsResponse = new DSResponse();
		
		List<TimerData> timerList =  new ArrayList<TimerData>();
		
		List<TimerData> bloombergTimerList = bloombergTimerBeanLocal.getAllTimers();
		List<TimerData> reutersTimerList = reutersTimerBeanLocal.getAllTimers();
		
		timerList.addAll(bloombergTimerList);
		timerList.addAll(reutersTimerList);
		
		dsResponse.setData(timerList);
		
		
		return dsResponse;
	}

	@Override
	public Object add(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		
		Object resultObject = null;
		
		@SuppressWarnings("unchecked")
		Map<String, Object> valueMap = dsRequest.getValues();
		
		TimerData temp = null;
		
		if(((String)valueMap.get("provider")).equalsIgnoreCase("Bloomberg")) {
			if((Boolean)valueMap.get("isSingle")) {
				TimerData timerData = new TimerData((String)valueMap.get("name"), (Boolean)valueMap.get("isSingle"), (Date)valueMap.get("startDateTime"), (String)valueMap.get("provider"), (String)valueMap.get("batchName"));
				
				temp = bloombergTimerBeanLocal.createSingleActionTimer(timerData);
			}
			else {
				TimerData timerData = new TimerData((String)valueMap.get("name"), (Boolean)valueMap.get("isSingle"), (Date)valueMap.get("startDateTime"), (Long)valueMap.get("interval"), (String)valueMap.get("provider"), (String)valueMap.get("batchName"));
				
				temp = bloombergTimerBeanLocal.createTimer(timerData);
			}
		}
		else if(((String)valueMap.get("provider")).equalsIgnoreCase("Reuters")) {
			if((Boolean)valueMap.get("isSingle")) {
				TimerData timerData = new TimerData((String)valueMap.get("name"), (Boolean)valueMap.get("isSingle"), (Date)valueMap.get("startDateTime"), (String)valueMap.get("provider"), (String)valueMap.get("batchName"));
				
				temp = reutersTimerBeanLocal.createSingleActionTimer(timerData);
			}
			else {
				TimerData timerData = new TimerData((String)valueMap.get("name"), (Boolean)valueMap.get("isSingle"), (Date)valueMap.get("startDateTime"), (Long)valueMap.get("interval"), (String)valueMap.get("provider"), (String)valueMap.get("batchName"));
				
				temp = reutersTimerBeanLocal.createTimer(timerData);
			}
		}
		else {
			
		}
		
		
		if(temp == null) {
			DSResponse dsResponse = new DSResponse();
			dsResponse.addError("name", new ErrorMessage("Timer \'" + (String)valueMap.get("name") + "\' already exists."));
			
			resultObject = dsResponse;
		}
		else {
			resultObject = temp;
		}
		
		return resultObject;
	}

	@Override
	public Object update(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		
		
		return null;
	}

	@Override
	public Object remove(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		@SuppressWarnings("unchecked")
		Map<String, Object> valueMap = dsRequest.getOldValues();
		
		String timerName = (String)valueMap.get("name");
		
		if(((String)valueMap.get("provider")).equalsIgnoreCase("Bloomberg")) {
			bloombergTimerBeanLocal.deleteTimer(timerName);
		}
		else if(((String)valueMap.get("provider")).equalsIgnoreCase("Reuters")) {
			reutersTimerBeanLocal.deleteTimer(timerName);
		}
		else {
			
		}
		
		TimerData removedTimerData = new TimerData();
		removedTimerData.setName(timerName);
		
		return removedTimerData;
	}
	
	@Override
	public Object removeAll(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		DSResponse dsResponse = new DSResponse();
		
		@SuppressWarnings("unchecked")
		Map<String, Object> valueMap = dsRequest.getOldValues();
		
		if(((String)valueMap.get("provider")).equalsIgnoreCase("Bloomberg")) {
			bloombergTimerBeanLocal.deleteAllTimers();
		}
		else if(((String)valueMap.get("provider")).equalsIgnoreCase("Reuters")) {
			reutersTimerBeanLocal.deleteAllTimers();
		}
		else {
			
		}
		
		// return removed timers for client-side updating cache
		// TODO
		
		
		return dsResponse;
	}
	

	@Override
	public DSResponse fetchTimerProviders(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		DSResponse dsResponse = new DSResponse();
		
		
		return dsResponse;
	}

	@Override
	public DSResponse fetchBatches(DSRequest dsRequest) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		DSResponse dsResponse = new DSResponse();
		
		String timerProvider = dsRequest.getHttpServletRequest().getParameter("provider");
		
		List<TimerData> batchList = new ArrayList<TimerData>();
		
		if(timerProvider.equalsIgnoreCase("Bloomberg")) {
			batchList = this.bloombergBatchBeanLocal.getBatches();
		}
		else if(timerProvider.equalsIgnoreCase("Reuters")) {
			batchList = this.reutersBatchBeanLocal.getBatches();
		}
		else {
			
		}
		
		dsResponse.setData(batchList);
		
		
		return dsResponse;
	}
	
	
	


}
