package it.ccg.infoprovider.server.service.file.factory;

import it.ccg.infoprovider.server.bean.entity.InstrumentsEntity;

import java.io.File;
import java.util.List;

public interface RequestFactory {
	
	public File createRequestFile(List<InstrumentsEntity> instrList);
	public File addInstrument(InstrumentsEntity instrEntity);
	public File removeInstrument(InstrumentsEntity instrEntity);

}
