package it.ccg.infoprovider.server.service.ftp;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.commons.net.ftp.FTPFile;

public interface FTPServiceInterface {
	
	public FTPFile getResponseFileInfo(String fileName) throws Exception;
	public FTPFile[] getResponseFilesInfo() throws Exception;
	
	public void downloadResponseFile(String fileName, FileOutputStream fileOutputStream) throws Exception;
	public void downloadRequestFile(String fileName, FileOutputStream fileOutputStream) throws Exception;
	
	public void uploadRequestFile(String fileName, FileInputStream fileInputStream)throws Exception;
	
	public boolean responseFileIsPresent(String fileName) throws Exception;
	public boolean requestFileIsPresent(String fileName) throws Exception;

}
