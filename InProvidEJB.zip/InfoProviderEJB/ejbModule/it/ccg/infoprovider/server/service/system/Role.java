package it.ccg.infoprovider.server.service.system;

public class Role {
	
	public static final String USER = "user";
	public static final String ADMIN = "admin";

}
