package it.ccg.infoprovider.server.bean.timer;
import it.ccg.infoprovider.server.data.TimerData;

import java.util.List;

import javax.ejb.Local;

@Local
public interface SystemTimerBeanLocal {
	
	public TimerData createTimer(TimerData timerData) throws Exception;
	public TimerData createSingleActionTimer(TimerData timerData) throws Exception;
	
	public void deleteTimer(String name) throws Exception;
	public void deleteAllTimers() throws Exception;
	
	public TimerData getTimer(String name) throws Exception;
	public List<TimerData> getAllTimers() throws Exception;

}
