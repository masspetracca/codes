package it.ccg.infoprovider.server.bean.providermanager;


import javax.ejb.Local;

@Local
public interface ReutersManagerBeanLocal {
	
	public void checkInstrumentsAlignment() throws Exception;
	public void updateReutersRequest() throws Exception;

}
