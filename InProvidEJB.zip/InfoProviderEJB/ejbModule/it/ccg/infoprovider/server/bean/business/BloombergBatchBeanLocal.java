package it.ccg.infoprovider.server.bean.business;
import it.ccg.infoprovider.server.data.TimerData;

import java.util.List;

import javax.ejb.Local;

@Local
public interface BloombergBatchBeanLocal {
	
	public void currencyDataDownload();
	public void bondRatingDataDownload();
	
	public List<TimerData> getBatches() throws Exception;

}
