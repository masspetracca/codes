package it.ccg.infoprovider.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;

/**
 * The persistent class for the PMPTUSER database table.
 * 
 */
@Entity
@Table(name = "PMPTUSER")
@NamedQueries({
		@NamedQuery(name = "fetchAll", query = "SELECT u FROM User u"),
		@NamedQuery(name = "fetchByUsername", query = "SELECT u FROM User u "
													+ "WHERE u.username = :userName")
})
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique = true, nullable = false, length = 30)
	private String username;

	@Column(nullable = false, length = 50)
	private String email;

	@Column(length = 50)
	private String name;

	@Column(nullable = false, length = 1)
	private String notify;

	@Column(length = 50)
	private String phonenumb;

	@Column(length = 50)
	private String surname;

	@Column(nullable = false)
	private Timestamp upddate;

	@Column(nullable = false, length = 1)
	private String updtype;

	@Column(nullable = false, length = 30)
	private String updusr;

	@Column(length = 100)
	private String userdesc;

	public User() {
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNotify() {
		return this.notify;
	}

	public void setNotify(String notify) {
		this.notify = notify;
	}

	public String getPhonenumb() {
		return this.phonenumb;
	}

	public void setPhonenumb(String phonenumb) {
		this.phonenumb = phonenumb;
	}

	public String getSurname() {
		return this.surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

	public String getUserdesc() {
		return this.userdesc;
	}

	public void setUserdesc(String userdesc) {
		this.userdesc = userdesc;
	}

}