package it.ccg.infoprovider.server.bean.eao;


import it.ccg.infoprovider.server.bean.entity.HistoricalPricesEntity;
import it.ccg.infoprovider.server.bean.entity.HistoricalPricesEntityPK;
import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class HistoricalPricesEAO
 */
@SuppressWarnings("unchecked")
@Stateless(mappedName = "HistoricalPricesEAO")
public class HistoricalPricesEAO implements HistoricalPricesEAOLocal {

	@PersistenceContext(unitName="InfoProviderEJB", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
	
	private String tableName = ((Table)(HistoricalPricesEntity.class.getAnnotation(Table.class))).name();
	
    /**
     * Default constructor. 
     */
    public HistoricalPricesEAO() {
    	this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	@Override
	public List<HistoricalPricesEntity> fetch() throws Exception {
		
		Query query = em.createNamedQuery("getAllHistoricalPrices");
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
		
		return (List<HistoricalPricesEntity>)query.getResultList();
	}

	@Override
	public HistoricalPricesEntity findByPrimaryKey(HistoricalPricesEntityPK pK) throws Exception {
		
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
		
		return (HistoricalPricesEntity)em.find(HistoricalPricesEntity.class, pK);
	}

	@Override
	public void add(HistoricalPricesEntity hpe) throws Exception {
		
		em.persist(hpe);
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Persisted data into \'" + this.tableName + "\'."));
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Data: " + hpe));
		
	}

	
	@Override
	public void update(HistoricalPricesEntity hpe) throws Exception {
		
		// TODO
	}

	@Override
	public void remove(HistoricalPricesEntity hpe) throws Exception {
		
		HistoricalPricesEntity temp = findByPrimaryKey(hpe.getId());
		
		em.remove(temp);
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Deleted data into \'" + this.tableName + "\'."));
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Data: " + temp));
		
	}
	

}
