package it.ccg.infoprovider.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;
import java.math.BigDecimal;


/**
 * The persistent class for the IFPTHISPR database table.
 * 
 */
@Entity
@Table(name="IFPTHISPR")
@NamedQueries({
	@NamedQuery(name="getAllHistoricalPrices", query="SELECT price FROM HistoricalPricesEntity price ORDER BY price.id.priceDate DESC"),
	@NamedQuery(name="getAllHistoricalPricesFromLastBatch", query="SELECT price FROM HistoricalPricesEntity price " +
			"WHERE price.parentFileId = " +
			"(SELECT ftpFile.fileId from FTPFileEntity ftpFile " +
			"WHERE ftpFile.parentBatchId = " +
			"(SELECT MAX(batch.batchId) from BatchEntity batch))"),
	@NamedQuery(name="getPriceDateByInstr", query="SELECT price.id.priceDate, price.closingPrice FROM HistoricalPricesEntity price WHERE price.id.instrumentId =?1 ")
})
public class HistoricalPricesEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;
	//***********************************************
	// Manually created foreign keys
	//***********************************************
	// uni-directional many-to-one association to Instr
	@ManyToOne
	@JoinColumn(name="INSTR_ID")
	private InstrumentsEntity instr;
	//***********************************************

	@EmbeddedId
	private HistoricalPricesEntityPK id;

	@Column(name="CLOSEPR", nullable=false, precision=16, scale=5)
	private BigDecimal closingPrice;

	@Column(name="P_FILE_ID", nullable=false)
	private int parentFileId = -1;

	@Column(nullable=false, length=1)
	private String status;

	@Column(name="UPDDATE", nullable=false)
	private Timestamp updateDate = new Timestamp(new Date().getTime());

	@Column(name="UPDTYPE", nullable=false, length=1)
	private String updateType = "C";

	@Column(name="UPDUSR", nullable=false, length=30)
	private String updatingUser = "SYSTEM";
	
	
    public HistoricalPricesEntity() {
    	
    }
    

	public HistoricalPricesEntityPK getId() {
		return this.id;
	}

	public void setId(HistoricalPricesEntityPK id) {
		this.id = id;
	}
	
	public BigDecimal getClosingPrice() {
		return this.closingPrice;
	}

	public void setClosingPrice(BigDecimal closingPrice) {
		this.closingPrice = closingPrice;
	}

	public int getParentFileId() {
		return this.parentFileId;
	}

	public void setParentFileId(int parentFileId) {
		this.parentFileId = parentFileId;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateType() {
		return this.updateType;
	}

	public void setUpdateType(String updateType) {
		this.updateType = updateType;
	}

	public String getUpdatingUser() {
		return this.updatingUser;
	}

	public void setUpdatingUser(String updatingUser) {
		this.updatingUser = updatingUser;
	}


	public InstrumentsEntity getInstr() {
		return instr;
	}


	public void setInstr(InstrumentsEntity instr) {
		this.instr = instr;
	}


}