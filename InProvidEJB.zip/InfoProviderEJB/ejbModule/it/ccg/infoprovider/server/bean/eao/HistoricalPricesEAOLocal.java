package it.ccg.infoprovider.server.bean.eao;
import it.ccg.infoprovider.server.bean.entity.HistoricalPricesEntity;
import it.ccg.infoprovider.server.bean.entity.HistoricalPricesEntityPK;

import java.util.List;

import javax.ejb.Local;

@Local
public interface HistoricalPricesEAOLocal {

	public List<HistoricalPricesEntity> fetch() throws Exception;
	public HistoricalPricesEntity findByPrimaryKey(HistoricalPricesEntityPK pK) throws Exception;
	public void add(HistoricalPricesEntity ie) throws Exception;
	public void update(HistoricalPricesEntity ie) throws Exception;
	public void remove(HistoricalPricesEntity ie) throws Exception;
	
}
