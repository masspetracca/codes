package it.ccg.infoprovider.server.bean.eao;


import it.ccg.infoprovider.server.bean.entity.InstrumentsEntity;

import java.util.List;

import javax.ejb.Local;

@Local
public interface InstrumentsEAOLocal {

	public List<InstrumentsEntity> fetch() throws Exception;
	public List<InstrumentsEntity> fetchEnabled(String provider) throws Exception;
	public List<InstrumentsEntity> fetchOneShot(String provider) throws Exception;
	public InstrumentsEntity findByPrimaryKey(int instrumentID) throws Exception;
	public InstrumentsEntity findByRICCode(String ricCode) throws Exception;
	public InstrumentsEntity findByBloombergCode(String bbgCode) throws Exception;
	public InstrumentsEntity add(InstrumentsEntity ie) throws Exception;
	public void update(InstrumentsEntity ie) throws Exception;
	public void remove(InstrumentsEntity ie) throws Exception;
	
}
