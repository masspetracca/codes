package it.ccg.infoprovider.server.bean.eao;


import it.ccg.infoprovider.server.bean.entity.BatchEntity;


import java.util.List;

import javax.ejb.Local;

@Local
public interface BatchEAOLocal {

	public List<BatchEntity>  fetch() throws Exception;
	public BatchEntity findByPrimaryKey(int instrumentID) throws Exception;
	public BatchEntity add(BatchEntity ie) throws Exception;
	public void update(BatchEntity ie) throws Exception;
	public void remove(BatchEntity ie) throws Exception;
	
}
