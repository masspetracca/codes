package it.ccg.infoprovider.server.bean.providermanager;
import javax.ejb.Local;

@Local
public interface BloombergManagerBeanLocal {
	
	public void checkInstrumentsAlignment() throws Exception;
	public void updateBloombergRequest() throws Exception;

}
