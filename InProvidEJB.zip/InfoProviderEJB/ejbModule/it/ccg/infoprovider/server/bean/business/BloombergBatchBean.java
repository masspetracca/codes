package it.ccg.infoprovider.server.bean.business;

import it.ccg.infoprovider.server.annotation.Batch;
import it.ccg.infoprovider.server.bean.eao.BatchEAOLocal;
import it.ccg.infoprovider.server.bean.eao.FTPFileEAOLocal;
import it.ccg.infoprovider.server.bean.eao.HistoricalPricesEAOLocal;
import it.ccg.infoprovider.server.bean.eao.InstrumentsEAOLocal;
import it.ccg.infoprovider.server.bean.entity.BatchEntity;
import it.ccg.infoprovider.server.bean.entity.FTPFileEntity;
import it.ccg.infoprovider.server.bean.entity.HistoricalPricesEntity;
import it.ccg.infoprovider.server.bean.entity.HistoricalPricesEntityPK;
import it.ccg.infoprovider.server.bean.entity.InstrumentsEntity;
import it.ccg.infoprovider.server.bean.providermanager.ReutersManagerBeanLocal;
import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.data.TimerData;
import it.ccg.infoprovider.server.service.file.parser.BloombergResponseParser;
import it.ccg.infoprovider.server.service.file.template.BloombergResponseFileMapping;
import it.ccg.infoprovider.server.service.ftp.FTPFactory;
import it.ccg.infoprovider.server.service.ftp.FTPServiceInterface;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.commons.net.ftp.FTPFile;
import org.apache.log4j.Logger;

import com.bloomberg.datalic.api.BBDES;

/**
 * Session Bean implementation class BloombergBatchBean
 */
@Stateless
public class BloombergBatchBean implements BloombergBatchBeanLocal {
	
	private static final String WS_INSTALL_DIR = System.getProperty("user.install.root");
	private static final String PATH_SEPARATOR = System.getProperty("file.separator");
	
	private static final String TEMP_ENC_FILE_NAME = "bbg_curr.out.temp";
	private static final String TEMP_DEC_FILE_NAME = "bbg_curr.out.temp.dec";
	private static final String TEMP_ENC_FILE_ABSOLUTE_PATH = WS_INSTALL_DIR + "/temp/infoprovider_temp" + PATH_SEPARATOR + TEMP_ENC_FILE_NAME;
	private static final String TEMP_DEC_FILE_ABSOLUTE_PATH = WS_INSTALL_DIR + "/temp/infoprovider_temp" + PATH_SEPARATOR + TEMP_DEC_FILE_NAME;
	
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	private static final Logger monitorLogger = Logger.getLogger("it.ccg.infoprovider.server.monitorLogger");
	
	
	private FTPServiceInterface ftpServiceInterface;
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
	
	@EJB
	private InstrumentsEAOLocal instrEAOLocal;
	
	@EJB
	private HistoricalPricesEAOLocal historicalPricesEAOLocal;
	
	@EJB
	private FTPFileEAOLocal ftpFileEAOLocal;
	
	@EJB
	private BatchEAOLocal batchEAOLocal;
	
	@EJB
	private ReutersManagerBeanLocal reutersManagerBeanLocal;
	
	

    /**
     * Default constructor. 
     */
    public BloombergBatchBean() {
    	this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
    
    @Override
	public List<TimerData> getBatches() throws Exception {
		List<TimerData> list = new ArrayList<TimerData>();
		
		Class<?> timerClass = BloombergBatchBean.class;
		
		Method[] methods = timerClass.getMethods();
		
		List<String> batchList = new ArrayList<String>();
		for(Method method : methods) {
			if(method.getAnnotation(Batch.class) != null) {
				batchList.add(method.getName());
			}
		}
		
		for(String batch : batchList) {
			TimerData timerData = new TimerData();
			timerData.setBatchName(batch);
			list.add(timerData);
		}
		
		
		return list;
	}
    
    
    
    @Override
	@Batch
    public void currencyDataDownload() {
    	
    	
		try {
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Batch \'currencyDataDownload\' started."));
			monitorLogger.debug(new StandardLogMessage(this.currentUser, "Batch \'currencyDataDownload\' started."));
			
			
			// initialize ftpService
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.BLOOMBERG_SERVICE);
			
			/*// calculate file name to download
			Date today = new Date(new Date().getTime() - 24*60*60*1000);
			SimpleDateFormat financeDateFormat = new SimpleDateFormat("yyyyMMdd");
			String financeFormatDateTodayString = financeDateFormat.format(today);*/
			FTPFile[] fileArray = this.ftpServiceInterface.getResponseFilesInfo();
			String fileName = this.getCurrLastFileInfo(fileArray).getName();
			
			// controllo file gi� scaricato / dati gi� scaricati
			if(this.ftpFileEAOLocal.findByName(fileName) != null) {
				
				defaultLogger.warn(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' already downloaded. New data not available."));
				monitorLogger.warn(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' already downloaded. New data not available."));
				
				return;
			}
	    	
			// download file
			FileOutputStream fileOutputStream = new FileOutputStream(new File(TEMP_ENC_FILE_ABSOLUTE_PATH));
			this.ftpServiceInterface.downloadResponseFile(fileName, fileOutputStream);
			
			// decript file
			BBDES bbDes = new BBDES("K/09[L1o");
			bbDes.setuseCAPoption(true);
			bbDes.setuuencode(true);
			bbDes.decryptDES(TEMP_ENC_FILE_ABSOLUTE_PATH, TEMP_DEC_FILE_ABSOLUTE_PATH);
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Decripting successfully completed."));
			
			// parse file
			BloombergResponseParser bloombergResponseParser = new BloombergResponseParser(new File(TEMP_DEC_FILE_ABSOLUTE_PATH));
			BloombergResponseFileMapping bloombergResponseFileMapping = bloombergResponseParser.parse();
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Parsing successfully completed."));
			List<HistoricalPricesEntity> hisPrEntityList = this.convertCurrencyData(bloombergResponseFileMapping);
			
			// persist data
			for(HistoricalPricesEntity hisPrEntity : hisPrEntityList) {
				
				this.historicalPricesEAOLocal.add(hisPrEntity);
			}
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Persisting data successfully completed."));
			
			// save information about executed batch
			BatchEntity batchEntity = new BatchEntity("Bloomberg", "Currency data download");
			batchEntity = this.batchEAOLocal.add(batchEntity);
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Batch info successfully stored."));
			
			// save information about downloaded file
			File file = new File(TEMP_DEC_FILE_ABSOLUTE_PATH);
			String fileContent = this.getFileContent(file);
			FTPFileEntity fileEntity = new FTPFileEntity(fileName, fileContent, batchEntity.getBatchId());
			fileEntity = this.ftpFileEAOLocal.add(fileEntity);
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "File info successfully stored."));
			
			// update persisted data
			for(HistoricalPricesEntity hisPrEntity : hisPrEntityList) {
				// set p_file_id for each HistoricalPricesEntity
				hisPrEntity.setParentFileId(fileEntity.getParentBatchId());
				
				this.historicalPricesEAOLocal.update(hisPrEntity);
			}
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Updating prices history with batch and data source file info successfully completed."));
			
			// change status from oneShot to disable for each ex-oneShot reuters instrument
			for(HistoricalPricesEntity hisPrEntity : hisPrEntityList) {
				int instrId = hisPrEntity.getId().getInstrumentId();
				InstrumentsEntity instrEntity = this.instrEAOLocal.findByPrimaryKey(instrId);
				
				if(instrEntity.getStatus().equalsIgnoreCase("O")) {
					instrEntity.setStatus("D");
				}
				
				this.historicalPricesEAOLocal.update(hisPrEntity);
			}
			this.reutersManagerBeanLocal.updateReutersRequest();
			
			
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Batch \'currencyDataDownload\' correctly executed."));
			monitorLogger.debug(new StandardLogMessage(this.currentUser, "Batch \'currencyDataDownload\' correctly executed."));
		}
		catch(Exception e) {
			defaultLogger.error(new StandardLogMessage(this.currentUser, e.toString()));
			defaultLogger.error(new StandardLogMessage(this.currentUser, e.getMessage()));
			
			monitorLogger.error(new StandardLogMessage(this.currentUser, e.toString()));
			monitorLogger.error(new StandardLogMessage(this.currentUser, e.getMessage()));
			
			StackTraceElement[] stackTraceElements = e.getStackTrace();
			for(StackTraceElement element : stackTraceElements) {
				defaultLogger.error(new StandardLogMessage(this.currentUser, element.toString()));
				monitorLogger.error(new StandardLogMessage(this.currentUser, element.toString()));
			}
			
			defaultLogger.error(new StandardLogMessage(this.currentUser, "Computation failed."));
			monitorLogger.error(new StandardLogMessage(this.currentUser, "Computation failed."));
		}
		
    }
	
	
	@Override
	@Batch
    public void bondRatingDataDownload() {
		try {
			
			defaultLogger.warn(new StandardLogMessage(this.currentUser, "Batch \'bondRatingDataDownload\' not implemented."));
		
		}
		catch(Exception e) {
			defaultLogger.error(new StandardLogMessage(this.currentUser, e.toString()));
			defaultLogger.error(new StandardLogMessage(this.currentUser, e.getMessage()));
			defaultLogger.error(new StandardLogMessage(this.currentUser, "Computation failed."));
			
			
			
			return;
		}
		
		
    }
	
	
	
	
	
	
	
	// input: BloombergResponseFileMapping
	// output: List<HistoricalPricesEntity>
	/*private List<HistoricalPricesEntity> convertData(BloombergResponseFileMapping bloombergResponseFileMapping) {
		List<String> fieldsList = bloombergResponseFileMapping.getFields();
		List<Object[]> dataMatrix = bloombergResponseFileMapping.getData();
		
		BbgFieldMapper bbgFieldMapper = new BbgFieldMapper();
		
		List<HistoricalPricesEntity> list = new ArrayList<HistoricalPricesEntity>();
		for(String field : fieldsList) {
			
		}
		
		
		
		return list;
	}*/
	private List<HistoricalPricesEntity> convertCurrencyData(BloombergResponseFileMapping bloombergResponseFileMapping) {
		List<Object[]> dataMatrix = bloombergResponseFileMapping.getData();
		
		List<HistoricalPricesEntity> list = new ArrayList<HistoricalPricesEntity>();
		
		for(Object[] record : dataMatrix) {
			HistoricalPricesEntity hisPrEntity = new HistoricalPricesEntity();
			HistoricalPricesEntityPK hisPrEntityPK = new HistoricalPricesEntityPK();
			
			try {
				int instrumentId = (instrEAOLocal.findByBloombergCode((String)record[0])).getInstrumentId();
				hisPrEntityPK.setInstrumentId(instrumentId);
				hisPrEntityPK.setPriceDate(Integer.parseInt((String)record[4]));
				hisPrEntity.setId(hisPrEntityPK);
				hisPrEntity.setClosingPrice(new BigDecimal((String)record[3]));
				
				list.add(hisPrEntity);
			} catch (Exception e) {
				e.printStackTrace();
				
				defaultLogger.error("Cannot convert from raw data to HistoricalPricesEntity.");
			}
			
			
		}
		
		
		return list;
	}
	
/*	private List<HistoricalPricesEntity> convertBondRatingData(BloombergResponseFileMapping bloombergResponseFileMapping) {
		List<Object[]> dataMatrix = bloombergResponseFileMapping.getData();
		
		List<HistoricalPricesEntity> list = new ArrayList<HistoricalPricesEntity>();
		
		for(Object[] record : dataMatrix) {
			HistoricalPricesEntity hisPrEntity = new HistoricalPricesEntity();
			HistoricalPricesEntityPK hisPrEntityPK = new HistoricalPricesEntityPK();
			
			try {
				int instrumentId = (instrEAOLocal.findByBloombergCode((String)record[0])).getInstrumentId();
				hisPrEntityPK.setInstrumentId(instrumentId);
				hisPrEntityPK.setPriceDate(Integer.parseInt((String)record[4]));
				hisPrEntity.setId(hisPrEntityPK);
				hisPrEntity.setClosingPrice(new BigDecimal((String)record[3]));
				
				list.add(hisPrEntity);
			}
			catch (Exception e) {
				e.printStackTrace();
				
				logger.error("Cannot convert from raw data to HistoricalPricesEntity.");
			}
			
			
		}
		
		
		return list;
	}*/
	
	
	private String getFileContent(File file) throws Exception {
		BufferedReader br = new BufferedReader(new FileReader(file));
		String fileContent = new String();
		
		String line = br.readLine();
		while(line != null) {
			fileContent += line + "\n";
			
			line = br.readLine();
		}
		
		return fileContent;
	}
	
	
	private FTPFile getCurrLastFileInfo(FTPFile[] fileArray) throws Exception {
		
		List<FTPFile> fileList = new ArrayList<FTPFile>();
		String fileName;
		String[] fileNameComponent;
		
		
		for(FTPFile file : fileArray) {
			fileName = file.getName();
			if(fileName.indexOf("bbg_curr.out.") != -1) {
				fileList.add(file);
			}
		}
		
		if(fileList.size() < 1) {
			
			throw new Exception("Data not available.");
		}
		
		
		// file name pattern:  bbg_curr.out.yyyymmdd(.n)
		int yyyymmddMAX = -1;
		int nMAX = -1;
		for(FTPFile file : fileList) {
			fileName = file.getName();
			
			fileNameComponent = fileName.split("\\.");
			
			int yyyymmddTEMP = Integer.parseInt(fileNameComponent[2]);
			if(yyyymmddTEMP > yyyymmddMAX) {
				yyyymmddMAX = yyyymmddTEMP;
			}
			
			// gestione caso bbg_curr.out.20120927.n
			if(fileNameComponent.length == 4) {
				int nTEMP = Integer.parseInt(fileNameComponent[3]);
				if(nTEMP > nMAX) {
					nMAX = nTEMP;
				}
			}
		}
		
		fileName = "bbg_curr.out." + Integer.toString(yyyymmddMAX);
		if(nMAX > -1) {
			fileName += fileName + "." + Integer.toString(nMAX);
		}
		
		FTPFile file = new FTPFile();
		file.setName(fileName);
		
		return file;
	}
	

/*	private FTPFile getBondRatingLastFileInfo(FTPFile[] fileArray) throws Exception {
		
		List<FTPFile> fileList = new ArrayList<FTPFile>();
		for(FTPFile file : fileArray) {
			String fileName = file.getName();
			if(fileName.indexOf("bbg_bond.out") != -1) {
				fileList.add(file);
			}
		}
		
		if(fileList.size() < 1) {
			
			throw new Exception("Data not available.");
		}
		
		String fileName = fileList.get(0).getName();
		int maxFileDate = Integer.parseInt(fileName.substring(fileName.length() - 8, fileName.length()));
		for(FTPFile file : fileList) {
			fileName = file.getName();
			int fileDate = Integer.parseInt(fileName.substring(fileName.length() - 8, fileName.length()));
			if(fileDate > maxFileDate) {
				maxFileDate = fileDate;
			}
		}
		
		FTPFile file = new FTPFile();
		file.setName("bbg_bond.out." + Integer.toString(maxFileDate));
		
		return file;
	}*/
    
    
    

}
