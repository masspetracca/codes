package it.ccg.infoprovider.server.bean.timer;


import it.ccg.infoprovider.server.bean.business.ReutersBatchBeanLocal;
import it.ccg.infoprovider.server.bean.providermanager.ReutersManagerBeanLocal;
import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.data.TimerData;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;

import org.apache.log4j.Logger;


/**
 * Session Bean implementation class ProcessManager
 */
@Stateless(mappedName = "ReutersTimerBean")
public class ReutersTimerBean implements ReutersTimerBeanLocal {
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
	@Resource
	TimerService timerService;
	
	@EJB
	private ReutersBatchBeanLocal reutersBatchBeanLocal;
	
	@EJB
	private ReutersManagerBeanLocal reutersManagerBeanLocal;
	
	
	public ReutersTimerBean() {
		this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@Override
	public TimerData createTimer(TimerData timerData) throws Exception {
		
		TimerData result = null;
		
		if(this.getTimer(timerData.getName()) != null) {
			defaultLogger.error("Duplicate timer name.");
			
			return null;
		}
		
		result = (TimerData)(this.timerService.createTimer(timerData.getStartDateTime(), timerData.getInterval(), timerData)).getInfo();
		
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Timer \'" + timerData.getName() + "\' created."));
		
		
		return result;
	}
	
	
	@Override
	public TimerData createSingleActionTimer(TimerData timerData) throws Exception {
		
		TimerData result = null;
		
		if(this.getTimer(timerData.getName()) != null) {
			defaultLogger.error("Duplicate timer name.");
			
			return null;
		}
		
		result = (TimerData)(timerService.createTimer(timerData.getStartDateTime(), timerData)).getInfo();
		
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Timer \'" + timerData.getName() + "\' created."));
		
		
		return result;
	}
	
	
	@Override
	public void deleteTimer(String timerName) throws Exception {
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = timerService.getTimers();
    	for(Timer timer : collection) {
    		if(((String)((TimerData)timer.getInfo()).getName()).equals(timerName)) {
    			
    			timer.cancel();
    			
    			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Timer \'" + timerName + "\' deleted."));
    		}
    	}
	}
	
	
	@Override
	public void deleteAllTimers() throws Exception {
		
		while(timerService.getTimers().iterator().hasNext()) {
			
			Timer timer = (Timer)timerService.getTimers().iterator().next();
			
			timer.cancel();
    		
    		String timerName = ((TimerData)timer.getInfo()).getName();
    		
    		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Timer \'" + timerName + "\' deleted."));
    	}
		
	}
    
	
	@Override
	public TimerData getTimer(String timerName) throws Exception {
		
		TimerData timerData = null;
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = timerService.getTimers();
    	
    	for(Timer timer : collection) {
    		if(((String)((TimerData)timer.getInfo()).getName()).equals(timerName)) {
    			timerData = (TimerData)timer.getInfo();
    			
    			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetching timer \'" + timerName + "\' info."));
    		}
    	}
		
    	
    	
		return timerData;
	}
	
	
	@Override
	public List<TimerData> getAllTimers() throws Exception {
		
		List<TimerData> list = new ArrayList<TimerData>();
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = timerService.getTimers();
    	
    	for(Timer timer : collection) {
    		
    		TimerData timerData = (TimerData)timer.getInfo();
    		
    		list.add(timerData);
    		
    		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetching timer \'" + timerData.getName() + "\' info."));
    	}
		
    	
		return list;
	}
	

	@Timeout
	public void timeout(Timer timer) {

		TimerData timerData = (TimerData)timer.getInfo();
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Timer \'" + timerData.getName() + "\' expired."));
		
		
		String batchName = timerData.getBatchName();
		
		if(batchName.equalsIgnoreCase("bondInterestRatesBatch")) {
			this.reutersBatchBeanLocal.bondInterestRatesBatch();
		}
		else if(batchName.equalsIgnoreCase("updateReutersRequest")) {
			try {
				this.reutersManagerBeanLocal.updateReutersRequest();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			
		}
	}
	
	


}
