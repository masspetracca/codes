package it.ccg.infoprovider.server.bean.eao;



import it.ccg.infoprovider.server.bean.entity.User;

import java.util.List;

import javax.ejb.Local;

@Local
public interface UserEAOLocal {
	
	public List<User> fetchByUserName(String userName) throws Exception;

}
