package it.ccg.infoprovider.server.bean.providermanager;

import it.ccg.infoprovider.server.bean.eao.InstrumentsEAOLocal;
import it.ccg.infoprovider.server.bean.entity.InstrumentsEntity;
import it.ccg.infoprovider.server.service.file.factory.BloombergCurr_ASCIIRequestFactory;
import it.ccg.infoprovider.server.service.ftp.FTPFactory;
import it.ccg.infoprovider.server.service.ftp.FTPServiceInterface;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BloombergManagerBean
 */
@Stateless
public class BloombergManagerBean implements BloombergManagerBeanLocal {
	
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	
	private FTPServiceInterface ftpServiceInterface;
	
	
	@EJB
	private InstrumentsEAOLocal instrumentsEAOLocal;
	

    /**
     * Default constructor. 
     */
    public BloombergManagerBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public void checkInstrumentsAlignment() throws Exception {
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBloombergRequest() throws Exception {
		
		defaultLogger.debug(new StandardLogMessage("SYSTEM", "Updating Bloomberg request.."));
		
		
		List<InstrumentsEntity> enabledInstrList = this.instrumentsEAOLocal.fetchEnabled("Bloomberg");
		List<InstrumentsEntity> oneShotInstrList = this.instrumentsEAOLocal.fetchOneShot("Bloomberg");
		List<InstrumentsEntity> instrList = new ArrayList<InstrumentsEntity>();
		instrList.addAll(enabledInstrList);
		instrList.addAll(oneShotInstrList);
		
		
		defaultLogger.debug(new StandardLogMessage("SYSTEM", "Instrument list size: " + instrList.size()));
		defaultLogger.debug(new StandardLogMessage("SYSTEM", "Instrument list details: " + instrList));
		
		
		BloombergCurr_ASCIIRequestFactory bloombergASCIIRequestFactory = new BloombergCurr_ASCIIRequestFactory();
		File file = bloombergASCIIRequestFactory.createRequestFile(instrList);
		
		this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.BLOOMBERG_SERVICE);
		
		this.ftpServiceInterface.uploadRequestFile(file.getName(), new FileInputStream(file));
		
		
		defaultLogger.debug(new StandardLogMessage("SYSTEM", "Bloomberg request successfully updated."));
		
	}

}
