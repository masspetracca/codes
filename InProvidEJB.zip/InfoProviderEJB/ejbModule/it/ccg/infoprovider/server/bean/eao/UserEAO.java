package it.ccg.infoprovider.server.bean.eao;


import it.ccg.infoprovider.server.bean.entity.User;
import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.util.StandardLogMessage;


import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class UserEAO
 */
@Stateless
public class UserEAO implements UserEAOLocal {
	
	@PersistenceContext(unitName="InfoProviderEJB-PAMPUSE", type = PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
	
	private String tableName = ((Table)(User.class.getAnnotation(Table.class))).name();
	
	

    /**
     * Default constructor. 
     */
    public UserEAO() {
    	this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<User> fetchByUserName(String userName) throws Exception {
		
		
		Query query = em.createNamedQuery("fetchByUsername");
		query.setParameter("userName", userName);
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
		
		return (List<User>)query.getResultList();
	}
	

}
