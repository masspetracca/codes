package it.ccg.infoprovider.server.data;

import java.io.Serializable;
import java.util.Date;



public class TimerData implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	private String name;
	private boolean isSingle;
	private Date startDateTime;
	private long interval;
	private String provider;
	private String batchName;
	
	
	public TimerData() {
		
	}
	
	public TimerData(String name, boolean isSingle, Date startDateTime, long interval, String provider, String batchName) {
		this.name = name;
		this.isSingle = isSingle;
		this.startDateTime = startDateTime;
		this.interval = interval;
		this.provider = provider;
		this.batchName = batchName;
	}
	
	public TimerData(String name, boolean isSingle, Date startDateTime, String provider, String batchName) {
		this.name = name;
		this.isSingle = isSingle;
		this.startDateTime = startDateTime;
		this.provider = provider;
		this.batchName = batchName;
	}
	
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public long getInterval() {
		return interval;
	}


	public void setInterval(long interval) {
		this.interval = interval;
	}


	public String getBatchName() {
		return batchName;
	}


	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}

	
	public String getProvider() {
		return provider;
	}


	public void setProvider(String provider) {
		this.provider = provider;
	}

	public Date getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(Date startDateTime) {
		this.startDateTime = startDateTime;
	}

	public boolean getIsSingle() {
		return isSingle;
	}

	public void setIsSingle(boolean isSingle) {
		this.isSingle = isSingle;
	}

}
