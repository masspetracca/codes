
public class Array_exception {
	public static void main(String[] args) {
		System.out.println("Begin");
		try {
			int i[] = new int[4];
			i[5] = 100;
			System.out.println("Array-OK#");
		} catch (Exception e) {	
			System.out.println("Array Error#");	
			System.out.println(e.getMessage());	
			e.printStackTrace();	
		}
		System.out.println("End");
	}
}
