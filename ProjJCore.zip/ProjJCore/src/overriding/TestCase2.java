package overriding;

public class TestCase2 extends Base {
	
	String browserName="firefox";

	public static void main(String[] args) {

		TestCase2 tc = new TestCase2();
		tc.initBrowser();

	}
	
	public void initBrowser(){
		
		WebDriver driver = getBrowserInstance(browserName);
		driver.click();
		driver.sendKeys();
		driver.getTitle();
		
	}

}
