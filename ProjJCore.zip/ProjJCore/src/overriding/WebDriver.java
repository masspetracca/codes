package overriding;

public class WebDriver {
	
	
	public void click(){
		System.out.println("Performing click - WebDriver()");
		
	}
	
	
	public void sendKeys(){
		System.out.println("Typing in an Element - WebDriver()");
	}
	
	
	public void getTitle(){
		System.out.println("Getting the title - WebDriver()");
	}

}
