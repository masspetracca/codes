package inherbank;

public class AnagraficaCliente extends Bank {
	
	int anaCli;
	
	public int getAnaCli() {
		return anaCli;
	}

	public void setAnaCli(int anaCli) {
		this.anaCli = anaCli;
	}

	public static void main(String[] args) {
		
		AnagraficaCliente obj = new AnagraficaCliente();
		obj.setAnaCli(1);
		int anacc=obj.getAnaCli();
		obj.generateIDAnagraficaCliente(anacc);
		
		
	}

}
