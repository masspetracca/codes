package inherbank;

public class TestBanks {
	public static void main(String[] args) {
		AnagraficaCliente acli = new AnagraficaCliente();
		acli.generateIDAnagraficaCliente(1);
		
		ContoCorrente ccor = new ContoCorrente();
		ccor.generateIDRapportoContoCorrente(10);
		
		Finanziamento fin = new Finanziamento();
		fin.generateIDFinanziamento(100);
	}
}
