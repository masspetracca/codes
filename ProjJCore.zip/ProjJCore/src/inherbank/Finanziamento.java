package inherbank;

public class Finanziamento extends Bank {
	
	int numFin;
	
	public int getNumFin() {
		return numFin;
	}

	public void setNumFin(int numFin) {
		this.numFin = numFin;
	}

	public static void main(String[] args) {
		
		Finanziamento obj = new Finanziamento();
		
		obj.setNumFin(100);
		int nfin=obj.getNumFin();
		obj.generateIDFinanziamento(nfin);

		
		
	}


}
