package inherbank;

public class Bank {
	
	public void generateIDAnagraficaCliente(int anacc){
		System.out.println("Generate anagrafica cliente: "+anacc);
		
	}
	
	public void generateIDRapportoContoCorrente(int ncc){
		System.out.println("Generate rapporto conto corrente: "+ncc);
		
	}
	
	public void generateIDFinanziamento(int nfin){
		System.out.println("Generate pratica finanziamento: "+nfin);
		
	}

}
