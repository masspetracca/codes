package inherbank;

public class ContoCorrente extends Bank {
	
	int numCC;
	
	public int getNumCC() {
		return numCC;
	}

	public void setNumCC(int numCC) {
		this.numCC = numCC;
	}

	public static void main(String[] args) {
		
		ContoCorrente obj = new ContoCorrente();
		obj.setNumCC(10);
		int ncc=obj.getNumCC();
		obj.generateIDRapportoContoCorrente(ncc);		
	}

}
