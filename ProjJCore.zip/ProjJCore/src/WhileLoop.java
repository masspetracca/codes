
public class WhileLoop {
	
	public static void main(String[] args) {
		int iMAX = 10;
		int i = 0;
		int fi = 0;

		while (i<iMAX || i<=0 ) {
			i++;
			System.out.println("i:#"+i);
		}
		System.out.println("Fine loop");
		for (fi=1;fi<=iMAX;fi++) {
			System.out.println("for:#"+fi);
			if (fi<=5) {
				System.out.println("continue#"+fi);
				continue;
			}
			if (fi>=iMAX) {
				System.out.println("break#"+fi);
				break;
			}

		}
		System.out.println("Fine for-cycle#"+fi);
	}
}
