
public class Test {
	public char[] privateVariable;

	//public static void main(String[] args) {
	public Test () {
		System.out.println("Begin");
		try {
			int divide = 10/0;
			System.out.println("Division-OK#"+divide);	
		} catch (Exception e) {	
			System.out.println("Division Error#");	
			System.out.println(e.getMessage());	
			e.printStackTrace();	
		} finally {
			System.out.println("End");
		}
	}


}
