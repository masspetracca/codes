
public class SampleTest extends Test {
	public static void main(String[] args) {

		Test obj = new Test();
		System.out.println(obj.privateVariable);
	}
}
