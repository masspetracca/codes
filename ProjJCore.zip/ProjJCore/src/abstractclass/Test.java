package abstractclass;

public class Test {
	
	public static void main(String[] args) {
		
		WebDriver c = new ChildFirefox();
		c.captureScreenshot();
		
	
		
		
	}

}
