package abstractclass;

public abstract class WebDriver {
	
	
	public abstract void click();
	
	
	public abstract void sendKeys();
	
	
	public abstract void getTitle();
	
	public void captureScreenshot(){
		
		
		
	}




}
