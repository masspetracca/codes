
public class IFElseStatements {

	public static void main(String[] args) {


		int num = (int)(Math.random()*25);
		System.out.println(num);
		
		System.out.println("FASE-A");
		if(num>10){
			System.out.println(num+" is Greater than 10");
		}
		else if(num<=10 && num>=5){
			System.out.println(num+"  between 10 and 5");
		}
			else{
			System.out.println(num+" is Less than 10");
			}
		
		System.out.println("FASE-B");
		if(num>10){
		System.out.println(num+" is Greater than 10");
		}
	    if(num<=10 && num>=5){
		System.out.println(num+"  between 10 and 5");
	    }
	    if(num<10){
		System.out.println(num+" is Less than 10");
		}
		
		

	}

}
