
public class CaughtException {
	public static void main(String[] args) throws InterruptedException {
		
		int i[] = new int[4];
		
		i[5] = 100;
		try {
			Thread.sleep(1000);
			System.out.println("CaughtException-OK");	
			
		} catch (InterruptedException ie) {
			System.out.println("InterruptedException-Error#1");	
			System.out.println(ie.getMessage());	
			ie.printStackTrace();	
	
		}
		try {
			Thread.sleep(1000);	
		} catch (InterruptedException ie) {
			System.out.println("InterruptedException-Error#2");	
			System.out.println(ie.getMessage());	
			ie.printStackTrace();	
			
		}
		Thread.sleep(1000);
	}
}
