package SingletonTest;

public class SingletOnTest {
	
	private static SingletOnTest instance = new SingletOnTest();
	
	private SingletOnTest() {
		System.out.println("Creating Object");	
	}
	public static SingletOnTest getInstance() {
		return instance;		
	}
}
