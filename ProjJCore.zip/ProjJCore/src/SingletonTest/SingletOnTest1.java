package SingletonTest;

public class SingletOnTest1 {
	private static SingletOnTest1 instance = new SingletOnTest1();

	private SingletOnTest1() {
		System.out.println("Creating Object1");	
	}
	public static SingletOnTest1 getInstance1() {
		return instance;		
	}
}
