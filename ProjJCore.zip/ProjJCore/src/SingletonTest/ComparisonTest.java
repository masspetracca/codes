package SingletonTest;

public class ComparisonTest {
	public static void main(String[] args) {
		String name1 = "Way2Automation";
		String name2 = "Way2Automation";
		
		String name_1 = new String("Way2Automation");
		String name_2 = new String("Way2Automation");

		int x = 100;
		int y = 100;
		
		System.out.println("nameString=: "+name1==name2); 
		System.out.println("nameStringEQ: "+name1.equals(name2));
		System.out.println("nameStringEQ_: "+name_1.equals(name_2));
		
		System.out.println("nameInt: "+(x==y));
		
		System.out.println("name_1: "+name_1);
		System.out.println("name_2: "+name_2);

		System.out.println("name1: "+name1);
		System.out.println("name2: "+name2);

		System.out.println("x: "+x);
		System.out.println("y: "+y);
		
		SingletOnTest st1 = SingletOnTest.getInstance();
		SingletOnTest st2 = SingletOnTest.getInstance();
		
		System.out.println("st1: "+st1);
		System.out.println("st2: "+st2);

		System.out.println("SingletOnTest: "+(st1==st2));

		SingletOnTest1 st11 = SingletOnTest1.getInstance1();
		SingletOnTest1 st22 = SingletOnTest1.getInstance1();
		
		System.out.println("st11: "+st11);
		System.out.println("st22: "+st22);

		System.out.println("SingletOnTest: "+(st11==st22));
		
	}
}
