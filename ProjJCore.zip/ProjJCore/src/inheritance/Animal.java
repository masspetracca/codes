package inheritance;

public class Animal {
	
	
	
	public void sound(){
		
		System.out.println("Generate sound");
		
	}

}
