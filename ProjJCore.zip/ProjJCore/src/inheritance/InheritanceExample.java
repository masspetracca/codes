package inheritance;

public class InheritanceExample {
	
	/*
	 * Type of Inheritance:-
	 * 
	 *  Single
	 *  Multiple
	 *  Multilevel
	 *  Hybrid
	 *  Hierarchical
	 *  
	 *  Class --> class / interface --> interface --> extends
	 *  Class --> interface --> implements
	 *  
	 *  Single
	 *  MultiLevel
	 *  Hierarchical
	 *  
	 *  
	 *  Interface
	 * 
	 * 
	 *  Single
	 *  MultiLevel
	 *  Hierarchical
	 *  Multiple
	 */

}
