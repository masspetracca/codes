package inheritance;

public class Dog extends Animal{
	
	
	public static void main(String[] args) {
		
		Dog obj = new Dog();
		obj.sound();
		
		
	}
	

	/*public void sound(){
		
		System.out.println("whow whow");
	}*/

}
