package polymorpism;

public class AMEX extends RBI {

}
