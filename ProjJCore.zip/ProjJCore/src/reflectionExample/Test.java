package reflectionExample;

public class Test {

	
	
	public Test(){
		
		
	}
	
	
	
	public Test(int a){
		
		
	}
	
	public void show(){
		
		
	}
	
	
	public int add(int a,int b){
		
		return 10;
	}
	
	
	public double print(){
		
		return 10.25;
		
	}

}
