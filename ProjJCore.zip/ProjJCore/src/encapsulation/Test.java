package encapsulation;

public class Test {

	
	/*
	 * Encapsulation - data binding / wrapping data and methods in single unit
	 * data hiding - hiding the data from outside world so that they are not directly accessible
	 * abstraction - force calling those variables using methods
	 * 
	 * 
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
