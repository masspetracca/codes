package POIExcel;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WritingExcel {
	public static void main(String[] args) throws IOException {
		
		
		
		XSSFWorkbook workbook = new XSSFWorkbook();
		
		XSSFSheet sheet0 = workbook.createSheet("FSheet");
		
		int rownum = 0;
		int colindex = 0;
		
		
		colindex = 0;
		for (rownum=0;rownum<10; rownum++) {			
			Row row0 = sheet0.createRow(rownum);
			for (colindex=0; colindex<10; colindex++) {
				if (rownum==0) {
					Cell cellA = row0.createCell(colindex);
					if (colindex==0) {
						cellA.setCellValue("1^ cell");
					}
					if (colindex==1) {
						cellA.setCellValue("2^ cell");
					}
					if (colindex==2) {
						cellA.setCellValue("3^ cell");
					}
					if (colindex==3) {
						cellA.setCellValue("4^ cell");
					}
					if (colindex==4) {
						cellA.setCellValue("5^ cell");
					}
					if (colindex==5) {
						cellA.setCellValue("6^ cell");
					}
					if (colindex==6) {
						cellA.setCellValue("7^ cell");
					}
					if (colindex==7) {
						cellA.setCellValue("8^ cell");
					}
					if (colindex==8) {
						cellA.setCellValue("9^ cell");
					}
					if (colindex==9) {
						cellA.setCellValue("10^ cell");
					}
					if (colindex==10) {
						cellA.setCellValue("11^ cell");
					}
				}
				if (rownum>0) {
					Cell cell = row0.createCell(colindex);
					cell.setCellValue((int)(Math.random()*25));		
				}
			}
		}
		
		File f = new File("test.xlsx");
		FileOutputStream fo = new FileOutputStream(f);
		
		
		workbook.write(fo);
		
		fo.close();

		System.out.println("File Created !!!!");
		
	}
}
