package pckg1;

public class ClassB {
	
	
	public void show(){
		
		
	}

}
