
public class RandomNumbers {

	public static void main(String[] args) {

		//type cast -->

		int num = (int)(Math.random()*5);
		System.out.println(num);


		double num1 = (double)(Math.random()*100);
		System.out.println(num1);


		double num2 = (int)(Math.random()*100);
		System.out.println(num2);
	}

}
