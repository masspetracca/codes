package interfaceexamples;

public interface Parent2 {

	public void show();

}
