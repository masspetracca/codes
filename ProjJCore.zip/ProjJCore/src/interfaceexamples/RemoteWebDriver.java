package interfaceexamples;

public interface RemoteWebDriver extends WebDriver{
	
	
	public void windowMaximize();

}
