package interfaceexamples;

public class FirefoxDriver implements WebDriver {

	@Override
	public void click() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sendKeys() {
		// TODO Auto-generated method stub
		
	}

}
