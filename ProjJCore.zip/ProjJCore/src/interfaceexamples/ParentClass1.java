package interfaceexamples;

public class ParentClass1 {
	
	
	public void show(){
		
		System.out.println("Parent show()");
	}

}
