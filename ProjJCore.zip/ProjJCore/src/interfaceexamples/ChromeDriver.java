package interfaceexamples;

public class ChromeDriver implements RemoteWebDriver {

	@Override
	public void click() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sendKeys() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowMaximize() {
		// TODO Auto-generated method stub
		
	}

}
