package Log4J;

import org.apache.log4j.Logger;

import POIExcel.WritingExcel;

public class TestLog4J {

	
	static Logger log = Logger.getLogger(WritingExcel.class);
	
	public static void main(String[] args) {


		log.debug("This is a Debug Log");
		log.info("This is a Info Log");
		log.error("Error in a Project");
	}

}
