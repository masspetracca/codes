package Log4J;

import org.apache.log4j.Logger;

public class Log4J {
	static Logger LOGGER = Logger.getLogger(Log4J.class);
	
	public static void main(String[] args) {
		LOGGER.debug("Logger Debug");
		LOGGER.info("Logger Info");
		LOGGER.error("Logger Error");
	}
}
