package it.ccg.test.collaudo.server.bus;



import java.io.IOException;
import java.sql.SQLException;





/**
 * Main Batch
 */
  
public class MainBatch {
 public static void main(String[] args) throws Exception {
	 int returnCode = 0;

	 //Main Batch
	  System.out.println("Inizio <MainBatch>");	
	  //General Batch
	   GeneralBatchGIROFO(returnCode);
  
	  if (returnCode != 0) {
		  System.out.println("Errore nella fase  <MainBatch> - verificare !");
	  }
	   GeneralBatchLIME(returnCode);
	   
	  if (returnCode != 0) {
		  System.out.println("Errore nella fase  <MainBatch> - verificare !");
	  }
	    ResultDb2GIROFO(returnCode);
	    if (returnCode != 0) {
		  System.out.println("Errore nella fase  <ResultDb2GIROFO> - verificare !");
	   }
	    ResultDb2LIME(returnCode);
	    if (returnCode != 0) {
		  System.out.println("Errore nella fase  <ResultDb2LIME> - verificare !");
	   }
	    ResultDb2CHECK(returnCode);
	    if (returnCode != 0) {
		  System.out.println("Errore nella fase  <ResultDb2CHECK> - verificare !");
	   }
	    ResultDb2tXML(returnCode);
	    if (returnCode != 0) {
		  System.out.println("Errore nella fase  <ResultDb2tXML> - verificare !");
	   }

	  System.out.println("Fine esecuzione <MainBatch>");
  }




	private static void ResultDb2tXML(int returnCode) throws IOException {
		ResultDb2tXML chk = new ResultDb2tXML(returnCode);
	
}




	private static void ResultDb2CHECK(int returnCode) throws IOException {
		ResultDb2CHECK chk = new ResultDb2CHECK(returnCode);
	
}




	private static void ResultDb2LIME(int returnCode) throws IOException {
		ResultDb2LIME rdb2 = new ResultDb2LIME(returnCode);
	
}




	private static void GeneralBatchLIME(int returnCode) throws IllegalAccessException, InstantiationException, ClassNotFoundException, IOException, SQLException {
		GeneralBatchLIME gbl = new GeneralBatchLIME(returnCode);
	
}




	private static void GeneralBatchGIROFO(int returnCode) throws IOException, SQLException, ClassNotFoundException, IllegalAccessException, InstantiationException {
		GeneralBatchGIROFO gb = new GeneralBatchGIROFO(returnCode);
}

	private static void ResultDb2GIROFO(int returnCode) throws IOException {
		ResultDb2GIROFO rdb2 = new ResultDb2GIROFO(returnCode);
	}

}


