
	package it.ccg.test.collaudo.server.bus;


	import java.io.BufferedReader;
	import java.io.File;
	import java.io.FileReader;
	import java.io.FileWriter;
	import java.io.IOException;
	import java.io.OutputStreamWriter;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.Properties;

	public class ResultDb2tXML {

			private static Object rs;
			private static PreparedStatement st;
			private static Object conn;
			private static String currdate;

			private static String sdate =null;
			private static String sTime ="";
			private static String sDate = "";
			static DateUtils day = new DateUtils();
		

			
		
			private static int imax =10000;
			
			private String tableNameLIME;
			private String tableNameGIROFO;
//			public static void main(String[] args) throws IOException {
			ResultDb2tXML(int returnCode) throws IOException{ 
				System.out.println("Inizio esecuzione <ResultDb2tXML>");
				
				sdate = day.now();
				 
				 String sdateaaaa = sdate.substring(0, 4);
				 String sdatemm =   sdate.substring(5, 7);
				 String sdategg = sdate.substring(8, 10);
				
			 	 String stimehh = sdate.substring(11, 13);
				 String stimemm = sdate.substring(14, 16);
				 String stimess = sdate.substring(17, 19);
				
				 sDate = (sdateaaaa+sdatemm+sdategg);
				 sTime = (stimehh+stimemm+stimess);
				 System.out.println("date:"+sDate);
				 System.out.println("time:"+sTime);
				 currdate = sDate+sTime;

				GetProperties();  
				ReadOutValues();			
				try {
					try {
						//Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
						Class.forName(PropertyFiles.getDbDriverTest()).newInstance();
					} catch (InstantiationException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IllegalAccessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}	
					//String url = "jdbc:db2://127.0.0.1:50000/db2";
					String url = PropertyFiles.getDbConnStringTest();
					Properties props = new Properties();
					//props.setProperty("user"; "db2admin");
					props.setProperty("user", PropertyFiles.getDbUserTest());
					//props.setProperty("password"; "main");
					props.setProperty("password", PropertyFiles.getDbPasswordTest());
					try {
						Connection conn = DriverManager.getConnection(url, props);
							
						System.out.println("Inizio scansione JDBC");
						tableNameLIME = PropertyFiles.getTabName1();
						tableNameGIROFO = PropertyFiles.getTabName2();

						String stconn =
						"SELECT  "
						+ "UATLIME_DT "
						+ " , UATLIME_ID_LIME"
						+ " , UATLIME_GFDESC"
						+ " , sum(UATGIF_AMOUNT) as GIROFO_AMT"
						+ " , sum(UATLIME_AMOUNT) as LIME_AMT "
						+ " , (sum(UATGIF_AMOUNT)- sum(UATLIME_AMOUnT)) as DELTA_AMT"
						+ " FROM " + tableNameLIME +", "+tableNameGIROFO 
						+ " WHERE UATLIME_DT=uatgif_dt"
						+ " AND uatlime_ID_GIF=UATGIF_ID"  
						+ " AND uatgif_amount!=uatlime_amount"
						+ " group by UATLIME_DT, UATLIME_ID_LIME, UATLIME_GFDESC"
						+ " ORDER BY  1 desc, 2 asc"
						;
						System.out.println("stringa- test:"+stconn);
						st = conn
						.prepareStatement (
								"SELECT  "
										+ "UATLIME_DT "
										+ " , UATLIME_ID_LIME"
										+ " , UATLIME_GFDESC"
										+ " , sum(UATGIF_AMOUNT) as GIROFO_AMT"
										+ " , sum(UATLIME_AMOUNT) as LIME_AMT "
										+ " , (sum(UATGIF_AMOUNT)- sum(UATLIME_AMOUnT)) as DELTA_AMT"
										+ " FROM " + tableNameLIME +", "+tableNameGIROFO 
										+ " WHERE UATLIME_DT=uatgif_dt"
										+ " AND uatlime_ID_GIF=UATGIF_ID"  
										+ " AND uatgif_amount!=uatlime_amount"
										+ " group by UATLIME_DT, UATLIME_ID_LIME, UATLIME_GFDESC"
										+ " ORDER BY  1 desc, 2 asc"
						); 
						

						//TABLENAME
						rs = st.executeQuery();
					    //File outputFile = new File("dati/outDb2.txt");
						File outputFile = new File(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTDB2_FILE_OUTPUT()+"CHECK.al"+currdate+".xml");
					    // System.out.println(outputFile.getAbsolutePath());
					    FileWriter writer = null;
					    
					    try {								
					    	boolean deleted = false;							
					    	if (outputFile.exists()) {							
					    		deleted = outputFile.delete();						
					    	}							
					    	System.out.println("rimosso file da: " + outputFile.getAbsolutePath() + "; " + deleted);							
					    	writer = new FileWriter(outputFile, false);							
						    } catch (IOException e1) {								
					    	System.out.println(e1.getMessage());							
					    	e1.printStackTrace();							
					    }	

					    int ind = 0;
						int i = 0;
						System.out.println(((ResultSet) rs).getRow());
						String oLine="<UAT_CHECK>";
						writer.write(oLine+"\n");
						
						while (((ResultSet) rs).next()) {
							i++;
							oLine= " ";
							System.out.println("Leggo: rec#" + i 
									+ ":   " 
									+ ((ResultSet) rs).getInt(1) 
									+ " " + ((ResultSet) rs).getString(2)
									+ " " + ((ResultSet) rs).getString(3)
									+ " " + ((ResultSet) rs).getString(4)
									+ " " + ((ResultSet) rs).getString(5)
									+ " " + ((ResultSet) rs).getString(6)
									);
							oLine = 
									(	
											  "<UATLIME_DT>"+ ((ResultSet) rs).getString(1) +"</UATLIME_DT>"  
											+ " <UATLIME_ID_LIME> "+ ((ResultSet) rs).getString(2)  +"</UATLIME_ID_LIME>"
											+ " <UATLIME_GFDESC>  "+ ((ResultSet) rs).getString(3)  +"</UATLIME_GFDESC>"
											+ " <SUM_UATGIF_AMOUNT>  " + ((ResultSet) rs).getString(4)  +"</SUM_UATGIF_AMOUNT>"
											+ " <SUM_UATLIME_AMOUNT>  "+ ((ResultSet) rs).getString(5)  +"</SUM_UATLIME_AMOUNT>"
											+ " <DELTA_AMOUNT>  "+ ((ResultSet) rs).getString(6)  +"</DELTA_AMOUNT>"									
									);
									writer.write(oLine+"\n");
							}
							try {
								oLine="</UAT_CHECK>";
								writer.write(oLine+"\n");
								writer.flush();
								writer.close();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							System.out.println("Fine scansione - righe lette: " + ind);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						finally {
							try {
								//if(rs != null) ((OutputStreamWriter) rs).close();
								if(st != null)st.close();
								if(conn != null) ((OutputStreamWriter) conn).close();
							} catch (SQLException e) {
								
							}
							
							
						}

					} catch (ClassNotFoundException e) {
						System.out.println("Driver non trovato !");
						e.printStackTrace();
					}
				}


			private static void ReadOutValues() throws IOException {
				BufferedReader in = new BufferedReader
	  			//(new FileReader("dati/"+"FTPValues.txt"));
				(new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTVALUES_FILE_OUTPUT()));
				
				 String line = null;
					
				  //ciclo lettura 
				  while ((line = in.readLine()) != null) {
					  //System.out.println("riga trovata : " + line);
						  //currdate = line.substring(20, 32);
						  //PropertyFiles.setCURRDATE(currdate);
						  //System.out.println("testo trovato currdate: " + currdate);
				  }
				  in.close();
			}

			private static void GetProperties() throws IOException {
				PropertyFiles pf = new PropertyFiles();
			}


	}
