		package it.ccg.test.collaudo.server.bus;


		import java.io.BufferedReader;
		import java.io.File;
		import java.io.FileReader;
		import java.io.FileWriter;
		import java.io.IOException;
		import java.io.OutputStreamWriter;
		import java.sql.Connection;
		import java.sql.DriverManager;
		import java.sql.PreparedStatement;
		import java.sql.ResultSet;
		import java.sql.SQLException;
		import java.util.Properties;

		public class ResultDb2LIME  {

				private static Object rs;
				private static PreparedStatement st;
				private static Object conn;
				private static String currdate;

				private static String sdate =null;
				private static String sTime ="";
				private static String sDate = "";
				static DateUtils day = new DateUtils();
			
				static String tableName = null;

				
				private static String Tab_col0 = "UATLIME_DT";
				private static String Tab_col1 = "UATLIME_ID_LIME";
				private static String Tab_col2 = "UATLIME_ID_GIF";
				private static String Tab_col3 = "UATLIME_GFDESC";
				private static String Tab_col4 = "UATLIME_AMOUNT";
				private String TableName = PropertyFiles.getTabName1();
				
				
				private static int imax =10000;
//				public static void main(String[] args) throws IOException {
				ResultDb2LIME(int returnCode) throws IOException{ 
					System.out.println("Inizio esecuzione <ResultDb2LIME>");
					
					sdate = day.now();
					 
					 String sdateaaaa = sdate.substring(0, 4);
					 String sdatemm =   sdate.substring(5, 7);
					 String sdategg = sdate.substring(8, 10);
					
				 	 String stimehh = sdate.substring(11, 13);
					 String stimemm = sdate.substring(14, 16);
					 String stimess = sdate.substring(17, 19);
					
					 sDate = (sdateaaaa+sdatemm+sdategg);
					 sTime = (stimehh+stimemm+stimess);
					 System.out.println("date:"+sDate);
					 System.out.println("time:"+sTime);
					 currdate = sDate+sTime;

					GetProperties();  
					ReadOutValues();			
					try {
						try {
							//Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
							Class.forName(PropertyFiles.getDbDriverTest()).newInstance();
						} catch (InstantiationException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IllegalAccessException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}	
						//String url = "jdbc:db2://127.0.0.1:50000/db2";
						String url = PropertyFiles.getDbConnStringTest();
						Properties props = new Properties();
						//props.setProperty("user"; "db2admin");
						props.setProperty("user", PropertyFiles.getDbUserTest());
						//props.setProperty("password"; "main");
						props.setProperty("password", PropertyFiles.getDbPasswordTest());
						try {
							Connection conn = DriverManager.getConnection(url, props);
								
							System.out.println("Inizio scansione JDBC");
							tableName = PropertyFiles.getTabName1();

							String stconn =
							"SELECT *  FROM " + tableName 
										//+ " WHERE " + tab_1 
									//+ " AND "+tab_1+" = (SELECT MAX(M."+tab_1+") FROM  " + tableName+" AS M)"
									+ " ORDER BY " + Tab_col0+","+Tab_col1+","+Tab_col2
							;
							System.out.println("stringa- test:"+stconn);
							st = conn
							.prepareStatement ("SELECT *  FROM " + tableName 
									//+ " WHERE " + tab_1 
									//+ " AND "+tab_1+" = (SELECT MAX(M."+tab_1+") FROM  " + tableName+" AS M)"
									+ " ORDER BY " + Tab_col0+","+Tab_col1+","+Tab_col1
							); 

							//TABLENAME
							rs = st.executeQuery();
						    //File outputFile = new File("dati/outDb2.txt");
							File outputFile = new File(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTDB2_FILE_OUTPUT()+".LIME.al"+currdate+".csv");
						    // System.out.println(outputFile.getAbsolutePath());
						    FileWriter writer = null;
						    
						    try {								
						    	boolean deleted = false;							
						    	if (outputFile.exists()) {							
						    		deleted = outputFile.delete();						
						    	}							
						    	System.out.println("rimosso file da: " + outputFile.getAbsolutePath() + "; " + deleted);							
						    	writer = new FileWriter(outputFile, false);							
							    } catch (IOException e1) {								
						    	System.out.println(e1.getMessage());							
						    	e1.printStackTrace();							
						    }	

						    int ind = 0;
							int i = 0;
							System.out.println(((ResultSet) rs).getRow());

							while (((ResultSet) rs).next()) {
								i++;
								String oLine= " ";
								System.out.println("Leggo: rec#" + i 
										+ ":   " 
										+ ((ResultSet) rs).getInt(1) 
										+ " " + ((ResultSet) rs).getString(2)
										+ " " + ((ResultSet) rs).getString(3)
										+ " " + ((ResultSet) rs).getString(4)
										+ " " + ((ResultSet) rs).getString(5)
										);
								oLine = 
										(
										 ((ResultSet) rs).getInt(1) 
										+ ";" + ((ResultSet) rs).getString(2)
										+ ";" + ((ResultSet) rs).getString(3)
										+ ";" + ((ResultSet) rs).getString(4)
										+ ";" + ((ResultSet) rs).getString(5)
										);
										writer.write(oLine+"\n");
								}
								try {
									writer.flush();
									writer.close();
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								System.out.println("Fine scansione - righe lette: " + ind);
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							finally {
								try {
									//if(rs != null) ((OutputStreamWriter) rs).close();
									if(st != null)st.close();
									if(conn != null) ((OutputStreamWriter) conn).close();
								} catch (SQLException e) {
									
								}
								
								
							}

						} catch (ClassNotFoundException e) {
							System.out.println("Driver non trovato !");
							e.printStackTrace();
						}
					}


				private static void ReadOutValues() throws IOException {
					BufferedReader in = new BufferedReader
		  			//(new FileReader("dati/"+"FTPValues.txt"));
					(new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTVALUES_FILE_OUTPUT()));
					
					 String line = null;
						
					  //ciclo lettura 
					  while ((line = in.readLine()) != null) {
						  //System.out.println("riga trovata : " + line);
							  //currdate = line.substring(20, 32);
							  //PropertyFiles.setCURRDATE(currdate);
							  //System.out.println("testo trovato currdate: " + currdate);
					  }
					  in.close();
				}

				private static void GetProperties() throws IOException {
					PropertyFiles pf = new PropertyFiles();
				}


		}
