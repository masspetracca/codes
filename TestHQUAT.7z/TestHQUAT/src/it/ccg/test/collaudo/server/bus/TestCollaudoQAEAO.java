package it.ccg.test.collaudo.server.bus;

public class TestCollaudoQAEAO {

	public TestCollaudoQAEAO(int returnCode) {
		// TODO Auto-generated constructor stub
	}
	public TestCollaudoQAEAO() {
		// TODO Auto-generated constructor stub
	}


	public String getkGifID() {
		return kGifID;
	}
	public void setkGifID(String kGifID) {
		this.kGifID = kGifID;
	}
	public String getkIDGifData() {
		return kIDGifData;
	}
	public void setkIDGifData(String kIDGifData) {
		this.kIDGifData = kIDGifData;
	}


	String kGifID;
	String kIDGifData;
	


}
