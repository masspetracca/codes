package it.ccg.liste.freader.batch;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class UrlRetrieveCOM implements Job {

   
//	public static void main(String args[]) throws IOException  {
	private int ctr;
	private int ctrRead;

    private String line;
    private String all;
	private String stream;
	private URL myUrlONU;
	private URL myUrlCOM;


	public void execute(JobExecutionContext context)
	throws JobExecutionException {
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date datei = new Date();
		
        //files
        FileReader reader = null;
        FileWriter writer = null;
       
        line = "";
        all = "";
        ctr=0;
	    try {
			myUrlCOM= new URL("http://ec.europa.eu/external_relations/cfsp/sanctions/list/version4/global/global.xml");
		} catch (MalformedURLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Date datesk = new Date();
	    URL myUrl = myUrlCOM;
    	System.out.println("Inizio <UrlRetrieveCOM> ");
		System.out.println("1#URL name              : "+myUrl);
		System.out.println("2#URL retrieving-Inizio : "+dateFormat.format(datei));

		//Vengono prelevati gli attributi del progetto
		try {
			GetProperties();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		stream = myUrl.toString();
		String date=dateFormat.format(datei);
		date=date.substring(11,13)+date.substring(14,16);
        File outputFile = new File(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTFPM_FILE_INPUT()+"_COM_"+date+".xml");
		//elaborazione dello stream 
		BufferedReader in = null;
		try {
		    in = new BufferedReader(new InputStreamReader(myUrlCOM.openStream()));

		    //imposta il writer per il file di output
		    writer = new FileWriter(outputFile);
		    //itera sulla lista di file
		        System.out.println("Sto elaborando il file: " + outputFile.getName());
		        int ictr = 0;
		        ctrRead = 0;
		        
				writer.write(in.readLine()+"\r\n");
		        while (in.readLine() != null) {
		        	ctr++;
		            line=in.readLine();
					writer.write(line+"\n");
	                System.out.println("write: "+line);
		    	} // end EOF
		        
		        System.out.println("Ho finito di elaborare il file: " + outputFile.getName());
				writer.close();
		    } catch (IOException e) {}
		    finally{
		        if(writer!= null)
					try {
						writer.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		    }
}
	private static void GetProperties() throws IOException {
		PropertyFiles pf = new PropertyFiles();
		
	}
}
