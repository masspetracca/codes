package it.ccg.liste.freader.batch;

import java.text.ParseException;

import org.quartz.CronScheduleBuilder;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class Skeduler {
	public Skeduler() throws ParseException, SchedulerException {
	    //public static void main( String[] args ) throws Exception {
	    	
	    	JobDetail jobONU = JobBuilder.newJob(UrlRetrieveONU.class)
					.withIdentity("AnterrRetONU", "group1").build();

	    	Trigger trigONU = TriggerBuilder
					.newTrigger()
					.withIdentity("AnterrRetONU", "group1")
					.withSchedule(
							CronScheduleBuilder.cronSchedule("0/90 * * * * ?"))
					.build();

	    	JobDetail jobCOM = JobBuilder.newJob(UrlRetrieveCOM.class)
			.withIdentity("AnterrRetCOM", "group2").build();

	    	Trigger trigCOM = TriggerBuilder
			.newTrigger()
			.withIdentity("AnterrRetCOM", "group2")
			.withSchedule(
					CronScheduleBuilder.cronSchedule("0/90 * * * * ?"))
			.build();
	    	
	    	//schedule it ONU
	    	Scheduler schedONU = new StdSchedulerFactory().getScheduler();    	
	    	schedONU.start();	    	
	    	schedONU.scheduleJob(jobONU, trigONU);
	    	
	    	//schedule it COM
	    	Scheduler schedCOM = new StdSchedulerFactory().getScheduler();    	
	    	schedCOM.start();
	    	schedCOM.scheduleJob(jobCOM, trigCOM);
	    
	    }
}