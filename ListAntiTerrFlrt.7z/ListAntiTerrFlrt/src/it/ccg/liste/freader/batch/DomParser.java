package it.ccg.liste.freader.batch;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;


public class DomParser {
	private String wOUT;
	private String c;
	String keyIdWhDate;
	String keyIdName;
	String keyIdEntity;

	String lastName;
	String firstName;
	String middleName;
	String wholeName;
	String gender;
	String title;
	String function;
	String language;

	private int swWPOST;
	private String wLLINE;
	private int idx;
	private String wVUOTO;
	private String wLINE;

	//public static void main(String[] args) throws IOException {
	DomParser() throws DocumentException, IOException { 
	System.out.println("Inizio <DomParser>");		
    
    wOUT= "";
	c="\n";

	File outValues = 
			  //new File("datiTRR/"+"Selenium_testOUT.xml");
			  (new File(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTVALUES_FILE_OUTPUT())); 

	  FileWriter writerValues = null;
	  
	  try {
		  
		  boolean deleted = false;							
	      if (outValues.exists()) {							
	    	  deleted = outValues.delete();						
	      }
	      else {
	    	  System.out.println("rimosso file da: " + outValues.getAbsolutePath() + ", " + deleted);							
	    	  writerValues = new FileWriter(outValues, false);
	      }
	  } catch  (IOException e) {e.printStackTrace();}


	    //read File
 	    BufferedReader in = new BufferedReader
	    	// (new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTFIELDS_FILE_OUTPUT()));
 	    	(new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTFIELDS_FILE_OUTPUT()));
		SAXReader reader = new SAXReader();
		Document document = reader.read(in);
		Element root = document.getRootElement();
		System.out.println("Root Element: "+root.getName());

  	  	wVUOTO=" ";
  	  	idx=1;
	  	
	    keyIdWhDate= " ";
 	    keyIdName= " ";
 	    keyIdEntity= " ";

 	    lastName= " ";
 	    firstName= " ";
 	    middleName= " ";
 	    wholeName= " ";
 	    gender= " ";
 		title= " ";
 		function= " ";
 		language= " ";

		
	    for ( Iterator i = root.elementIterator(); i.hasNext(); ) {
            Element row = (Element) i.next();

            //<WHOLE> 
            Iterator itr = row.elementIterator();
            while(itr.hasNext()){

             	Element child = (Element) itr.next();
  
                  //navigazione nodi 
                  System.out.println("Element Name:"+child.getQualifiedName() );
                  System.out.println("Element Value:"+child.getText());
                  
                  //WHOLE Date= check 
                  if (child.getQualifiedName().contains("WHOLE") == true) {
                	  System.out.println("<WHOLE>"+child.getQualifiedName() );
                	  keyIdWhDate=child.getText().substring(1, 15);
                  }
                  //ENTITY Id= check 
                  if (child.getQualifiedName().contains("ENTITY") == true) {
                	  System.out.println("<ENTITY Type='>"+child.getQualifiedName()+"'");
                	  keyIdEntity= (child.getText());
                   }
 

					  wLLINE=(keyIdWhDate+"|"+keyIdEntity);
					  writerValues.write(wLLINE+c);
 
					  System.out.println("<POST>"+child.getQualifiedName() );
                	  wLINE = ("Stato Base: Attende la risposta dall^oggetto ");
                      wOUT=wLINE;
                  


 
            }
		}
		writerValues.close();
		System.out.println("Fine esecuzione <DataFileCompleto> - estrazione : File Data");
	}



}