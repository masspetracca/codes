package it.ccg.liste.freader.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringTokenizer;

import it.ccg.liste.freader.batch.DateUtils;
import it.ccg.liste.freader.batch.PropertyFiles;

public class DataFileCompleto {
	 private static String ft;
	 private static String stl;
	 private static String wOUT;
	 private static String c;
	 private static String tok;
	 private static String is;
	 private static String s;
	 private static int swWAIT;
	 private static int swCLICK;

	 private static String sdate =null;
	 private static String sTime ="";
	 private static String sDate = "";
	 static DateUtils day = new DateUtils();
	private static String visK;
	private static String pre;
	private static String expr;
	private static String substitute;


	
	
	DataFileCompleto() throws IOException{ 			
	 /**
	 * Elaborazione file .xml 
	 */
		//public static void main(String[] args) throws Exception {
		
		sdate = day.now();
		 
		 String sdateaaaa = sdate.substring(0, 4);
		 String sdatemm =   sdate.substring(5, 7);
		 String sdategg = sdate.substring(8, 10);
		
	 	 String stimehh = sdate.substring(11, 13);
		 String stimemm = sdate.substring(14, 16);
		 String stimess = sdate.substring(17, 19);
		
		 sDate = (sdateaaaa+sdatemm+sdategg);
		 sTime = (stimehh+stimemm+stimess);
		 System.out.println("date:"+sDate);
		 System.out.println("time:"+sTime);
		 
		 GetProperties();
		 DataFile();

	  
	  }	
	  private static void GetProperties() throws IOException {
		PropertyFiles pf = new PropertyFiles();
	  }


	private static void DataFile() throws FileNotFoundException {
		System.out.println("Inizio esecuzione <DataFileCompleto>");

		//read File
		BufferedReader in = new BufferedReader
	  			//(new FileReader("datiTRR/"+"outFPM.txt"));
				(new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTFPM_FILE_INPUT()));
	  try {

		  File outValues = 
			  //new File("dati/"+"Selenium_tests.xml");
			  (new File(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTFIELDS_FILE_OUTPUT())); 
		  
		  FileWriter writerValues = null;
		  
		  try {
			  
			  boolean deleted = false;							
		      if (outValues.exists()) {							
		    	  deleted = outValues.delete();						
		      }
		      else {
		    	  System.out.println("rimosso file da: " + outValues.getAbsolutePath() + ", " + deleted);							
		    	  writerValues = new FileWriter(outValues, false);
		      }
		  } catch  (IOException e) {e.printStackTrace();}
	      
		  //main			
		    swWAIT=0;
		    swCLICK=0;
		    wOUT= "";
			c="\n";
			
			System.out.println("<?xml version='1.0' encoding='UTF-8'?>");
			wOUT= "<?xml version='1.0' encoding='UTF-8'?>";
			writerValues.write(wOUT);
			
			System.out.println("<TUPampQA>");
			wOUT= "<TUPampQA>";
			writerValues.write(c+wOUT);
	
			
		    //string tokenizer
			while ((stl = in.readLine()) != null){
			    swWAIT=0;
			    swCLICK=0;
			    is=" ";
			    s= " ";
            	
				StringTokenizer f=new StringTokenizer(stl, "|");
			    				
			    //while tokens
				while(f.hasMoreTokens()) {
				    tok = (String) f.nextElement();
				    
				    expr = "fs";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "%3A";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "%20";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "x07C";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%22";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);				    

				    expr = "%24";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);				    

				    expr = "%26";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    

				    expr = "%3A";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);


				    expr = "%3B";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "%3C";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "%3E";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%20";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
	
				    expr = "%26";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%27";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%3D";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%24";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%270";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);				    
				    
				    expr = "&quot;";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "nbsp;";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "span";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%img";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "nobr";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "&lt;";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "&gt;";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				     
					//#test: RF45-NUC03-Tnn: element
					if (tok.contains("info: Starting test") == true) {
						 System.out.println("<TUgroup>");
			     	     wOUT= "<TUgroup>";
					     writerValues.write(c+wOUT);
					     
						 wOUT= "";
						 System.out.println("<reqID>");
						 wOUT= "<reqID>";
						 writerValues.write(c+wOUT);

						 ft = tok;
			        	 System.out.println(ft.substring(43, ft.length()));
			        	 wOUT= ft.substring(43, ft.length());
						 writerValues.write(c+wOUT);
			      	
						 wOUT= "";
						 System.out.println("</reqID>");
						 wOUT= "</reqID>";
						 writerValues.write(wOUT);

						//date
						 wOUT= "";
						 System.out.println("<dateID>");
						 wOUT= "<dateID>";
						 writerValues.write(c+wOUT);

			        	 System.out.println(sDate+sTime);
			        	 wOUT= sDate+sTime;
			      		 writerValues.write(wOUT);
			      		 
						 wOUT= "";
						 System.out.println("</dateID>");
						 wOUT= "</dateID>";
						 writerValues.write(wOUT);
						 
					}
					if (tok.contains("INFO - Killing Firefox") == true) {	
						 System.out.println("<TUgroup>");
			     	     wOUT= "<TUgroup>";
					     writerValues.write(c+wOUT);
					     
						 wOUT= "";
						 System.out.println("<reqID>");
						 wOUT= "<reqID>";
						 writerValues.write(c+wOUT);
			      	
						 wOUT= "";
						 System.out.println("</reqID>");
						 wOUT= "</reqID>";
						 writerValues.write(wOUT);

						 System.out.println("</TUgroup>");
			     	     wOUT= "</TUgroup>";
					     writerValues.write(c+wOUT);

					}
					   //#end: element
					if (tok.contains("#end") == true)  {
						System.out.println("</TUgroup>");
				   	    wOUT= "</TUgroup>";
						 writerValues.write(c+wOUT);
					}

					//open url: element
					 if ((tok.contains("open")  == true) 
				     && (tok.contains("/open")  == false)) {
						 
					     wOUT= "";
						 System.out.println("<openURL>");
						 wOUT= "<openURL>";
						 writerValues.write(c+wOUT);
						 
						 //next element searching to write <openURL>url</openURL>
     					 tok = (String) f.nextElement();
						 
     					 //url
     					 ft = tok;
			        	 System.out.println(ft);
			        	 wOUT= ft;
			      		 writerValues.write(wOUT);
			      		 
						 wOUT= "";
						 System.out.println("</openURL>");
						 wOUT= "</openURL>";
						 writerValues.write(wOUT);
						 wOUT= "";
					}

					 
					is=" ";
					//object: meta content to analyse 
					if (tok.contains("ListGrid")  == true){
						 is = "ListGrid";				
					}
					if (tok.contains("DynamicForm")  == true){
						 is = "DynamicForm";				
					}
					if (tok.contains("IButton")  == true){
						 is = "Button";				
					}
					if (tok.contains("TreeGrid")  == true){
						 is = "TreeGrid";				
					}
					if (tok.contains("VStack")  == true){
						 is = "VStack";				
					}
					if (tok.contains("TabSet")  == true){
						 is = "TabSet";				
					}
					if (tok.contains("Window")  == true){
						 is = "Window";				
					}



	   			   //sw environments
					if (tok.contains("wait") == true) {
						swWAIT = 1;
						swCLICK = 0;
										}
					if (tok.contains("click") == true) {
						swWAIT = 0;
						swCLICK = 1;
					}

					if ((tok.contains("clickAndWait") == true) 
					&& (tok.contains("id=submitLabel") == true)) {
						swWAIT = 0;
						swCLICK = 0;
					}
					//clickAndWait: element
					if ((tok.contains("clickAndWait") == true) 
					&& (tok.contains("id=submitLabel") == true)) {
					     wOUT= "";
						 System.out.println("<clickAndWait>");
						 wOUT= "<clickAndWait>";
						 writerValues.write(c+wOUT);

						 //id=submitLabel (successivo clickAndWait)
						 wOUT= "";
						 ft=(String) f.nextElement();
			        	 System.out.println(ft);
			        	 wOUT= ft;
			      		 writerValues.write(wOUT);

						 wOUT= "";
						 System.out.println("</clickAndWait>");
						 wOUT= "</clickAndWait>";
						 writerValues.write(c+wOUT);
					 }

	   			   //waitForElementClickable: elements
					if (swWAIT == 1) {
						if ((tok.contains("wait") == true)  
//						|| (tok.contains("/row")  == true)
//						|| (tok.contains("/member")  == true)
						|| (tok.contains("=//")  == true)
					    || (tok.contains("Class=Button")  == true)
					    || (tok.contains("Class=IButton")  == true)
					    || ((tok.contains("Class=DynamicForm")  == true) 
					    && (tok.contains("classIndex=")  == true))
						|| (tok.contains("scRole=")  == true)
						|| (tok.contains("title=")  == true)
//						&& (tok.contains("UntitledButton")  == false))
						|| (tok.contains("#end:")  == true)
						|| (tok.contains("value=")  == true)
					    || (tok.contains("Class=DateItem")  == true)
					    || (tok.contains("Class=ComboBoxItem")  == true)
					    || (tok.contains("Class=CheckboxItem")  == true)
					    || (tok.contains("Class=TextAreaItem")  == true)
					    || (tok.contains("Class=SelectItem")  == true)
					    || (tok.contains("_TextAreaItem")  == true)
					    || (tok.contains("_CheckboxItem")  == true)
//					    || (tok.contains("/body/")  == true)
//					    || (tok.contains("/header/")  == true)
//					    || (tok.contains("/headerButton")  == true)
						|| (tok.contains("!--")  == true)
					    || (tok.contains("scLocator=//IButton")  == true)
//					    && (tok.contains("Button:CancelButton")  == true))
//					    || ((tok.contains("scLocator=//IButton")  == true)   		
//					    && (tok.contains("Button:InsertButton")  == true))
						|| (tok.contains("Class=RecordEditor")  == true)){
							waitELEM();
							writerValues.write(s);
							s="";
						}
					}
					
					  
				   //click: elements
					if (swCLICK == 1) {
						if ((tok.contains("click") == true)  
//								|| (tok.contains("/row")  == true)
//								|| (tok.contains("/member")  == true)
								|| (tok.contains("=//")  == true)
							    || (tok.contains("Class=Button")  == true)
							    || (tok.contains("Class=IButton")  == true)
							    || (tok.contains("Class=DynamicForm")  == true) 
							    && ((tok.contains("classIndex=")  == true))
								|| (tok.contains("scRole=")  == true)
								|| (tok.contains("title=")  == true)
//								&& (tok.contains("UntitledButton")  == false))
								|| (tok.contains("#end:")  == true)
								|| (tok.contains("value=")  == true)
							    || (tok.contains("Class=DateItem")  == true)
							    || (tok.contains("Class=ComboBoxItem")  == true)
							    || (tok.contains("Class=CheckboxItem")  == true)
							    || (tok.contains("Class=TextAreaItem")  == true)
							    || (tok.contains("Class=SelectItem")  == true)
							    || (tok.contains("_TextAreaItem")  == true)
							    || (tok.contains("_CheckboxItem")  == true)
//							    || (tok.contains("/body/")  == true)
//							    || (tok.contains("/header/")  == true)
//							    || (tok.contains("/headerButton")  == true)
								|| (tok.contains("!--")  == true)
							    || (tok.contains("scLocator=//IButton")  == true)
//							    && (tok.contains("Button:CancelButton")  == true))
//							    || ((tok.contains("scLocator=//IButton")  == true)   		
//							    && (tok.contains("Button:InsertButton")  == true))
								|| (tok.contains("Class=RecordEditor")  == true)){
							clickELEM();
							writerValues.write(s);
							s="";
						}
					}


				} //end while readDATA	
			} //closing
			
			System.out.println("</TUPampQA>");
	   	    wOUT= "</TUPampQA>";
	   	    writerValues.write(c+wOUT);

			in.close();
			writerValues.close();
			System.out.println("Fine esecuzione <DataFileCompleto> - estrazione : File Data");
			//end while read  
	  } catch (IOException e) { e.printStackTrace();}
	}
	
	private static void clickELEM() {
	   //click: element
		if (tok.contains("click") == true)  {
		   wOUT= "";
		   System.out.println("<response>click</response>");
		   wOUT= "<response>click</response>";
		   s   =  c+wOUT;
		}
		
		//node: <element>
	    if (tok.contains("=//")  == true){
		   wOUT= "";
		   System.out.println("<nodeName>"+is+"</nodeName>");
		   wOUT= "<nodeName>"+is+"</nodeName>";
		   s   +=  c+wOUT;
	 }

		
	    //node: title=
		if ((tok.contains("title=")  == true)
		&& (tok.contains("Untitled Button")  == true)){
			//continue
			;
		}
		  
	    //node: title=
		if ((tok.contains("title=")  == true) 
		&& (tok.contains("Untitled Button")  == false)
		&& (tok.contains("title=Month")  == false) 
		&& (tok.contains("title=Section")  == false)) {
		   wOUT= "";
		   System.out.println("<nodeType>"+tok.substring(6, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(6, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;
		}
		
		
	    //name: General=		
		if (tok.contains("name=General")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>General</childName>");
		   wOUT= "<childName>General</childName>";
		   s   +=  c+wOUT;		   
		}
		
		
	    //name: Comp.=		
		if (tok.contains("name=Comp.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Comp.</childName>");
		   wOUT= "<childName>Comp.</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Haircut=		
		if (tok.contains("name=Haircut")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Haircut</childName>");
		   wOUT= "<childName>Haircut</childName>";
		   s   +=  c+wOUT;		   
		}
		
		
	    //name: HC=		
		if (tok.contains("name=HC")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>HC</childName>");
		   wOUT= "<childName>HC</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Equities=		
		if (tok.contains("name=Equities")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Equities</childName>");
		   wOUT= "<childName>Equities</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Eq.=		
		if (tok.contains("name=Eq.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Eq.</childName>");
		   wOUT= "<childName>Eq.</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Back=		
		if (tok.contains("name=Back")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Back</childName>");
		   wOUT= "<childName>Back</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Equity=		
		if (tok.contains("name=Equity")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Equity</childName>");
		   wOUT= "<childName>Equity</childName>";
		   s   +=  c+wOUT;		   
		}

	    //name: Bond=		
		if (tok.contains("name=Bond")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Bond</childName>");
		   wOUT= "<childName>Bond</childName>";
		   s   +=  c+wOUT;		   
		}

	    //name: Bond=		
		if (tok.contains("name=iBond")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>iBond</childName>");
		   wOUT= "<childName>iBond</childName>";
		   s   +=  c+wOUT;		   
		}
//
//	    //name: scRole=		
//		if ((tok.contains("scRole=")  == true)  
//		&& (tok.contains("scRole=list"))  == false)  {
//		   wOUT= "";
//		   System.out.println("<nodeName>"+tok.substring(7, 13)+"</nodeName>");
//		   wOUT= "<nodeName>"+tok.substring(7, 13)+"</nodeName>";
//		   s   +=  c+wOUT;		   
//		}

	    //name: scRole=list	
		if (tok.contains("scRole=list")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeName>ListGrid</nodeName>");
		   wOUT= "<nodeName>ListGrid</nodeName>";
		   s   +=  c+wOUT;		   
		}

	    //name: Class=DynamicForm && classIndex=
		if (tok.contains("Class=DynamicForm")  == true) { 
//		&& (tok.contains("classIndex=")  == true))  {
		   wOUT= "";
		   System.out.println("<nodeName>DynamicForm</nodeName>");
		   wOUT= "<nodeName>DynamicForm</nodeName>";
		   s   +=  c+wOUT;		   
		}

		//name: Eq. Condifence parameters=		
		if (tok.contains("name=Eq. Condifence parameters")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Eq. Condifence parameters</childName>");
		   wOUT= "<childName>Eq. Condifence parameters</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Static=		
		if (tok.contains("name=Static")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Static</childName>");
		   wOUT= "<childName>Static</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: Stress=		
		if (tok.contains("name=Stress")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Stress</childName>");
		   wOUT= "<childName>Stress</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: S.T.=		
		if (tok.contains("name=S.T.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>S.T.</childName>");
		   wOUT= "<childName>S.T.</childName>";
		   s   +=  c+wOUT;		   
		}
		
		
	    //name: Ix.=		
		if (tok.contains("name=Ix.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Ix.</childName>");
		   wOUT= "<childName>Ix.</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Curr.=		
		if (tok.contains("name=Curr.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Curr.</childName>");
		   wOUT= "<childName>Curr.</childName>";
		   s   +=  c+wOUT;		   
		}

	    //name: Type=		
		if (tok.contains("name=Type")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Type</childName>");
		   wOUT= "<childName>Type</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Currency=		
		if (tok.contains("name=Currency")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Currency</childName>");
		   wOUT= "<childName>Currency</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Risk=		
		if (tok.contains("name=Risk")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Risk</childName>");
		   wOUT= "<childName>Risk</childName>";
		   s   +=  c+wOUT;		   
		}

	    //name: Indices=		
		if (tok.contains("name=Indices")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Indices</childName>");
		   wOUT= "<childName>Indices</childName>";
		   s   +=  c+wOUT;		   
		}

	    //name: Instr=		
		if (tok.contains("name=Instr.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Instr.</childName>");
		   wOUT= "<childName>Instr.</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: B.T.=		
		if (tok.contains("name=B.T.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>B.T.</childName>");
		   wOUT= "<childName>B.T.</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: Bankstaticdata		
		if (tok.contains("name=Bankstaticdata")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Bankstaticdata</childName>");
		   wOUT= "<childName>Bankstaticdata</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Bankbalancehistory		
		if (tok.contains("name=Bankbalancehistory")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Bankbalancehistory</childName>");
		   wOUT= "<childName>Bankbalancehistory</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Bankapprovedratinghistory		
		if (tok.contains("name=Bankapprovedratinghistory")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Bankapprovedratinghistory</childName>");
		   wOUT= "<childName>Bankapprovedratinghistory</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Ratingtranscode		
		if (tok.contains("name=Ratingtranscode")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Ratingtranscode</childName>");
		   wOUT= "<childName>Ratingtranscode</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Riskcommittee		
		if (tok.contains("name=Riskcommittee")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Riskcommittee</childName>");
		   wOUT= "<childName>Riskcommittee</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Parameterselection		
		if (tok.contains("name=Parameterselection")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Parameterselection</childName>");
		   wOUT= "<childName>Parameterselection</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Ratingsproposal		
		if (tok.contains("name=Ratingsproposal")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Ratingsproposal</childName>");
		   wOUT= "<childName>Ratingsproposal</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Linearregressionsettings		
		if (tok.contains("name=Linearregressionsettings")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Linearregressionsettings</childName>");
		   wOUT= "<childName>Linearregressionsettings</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Scheduler		
		if (tok.contains("name=Scheduler")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Scheduler</childName>");
		   wOUT= "<childName>Scheduler</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Logviewer		
		if (tok.contains("name=Logviewer")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Logviewer</childName>");
		   wOUT= "<childName>Logviewer</childName>";
		   s   +=  c+wOUT;		   
		}


	    //name: Comparables=		
		if (tok.contains("Comparables")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Comparables</childName>");
		   wOUT= "<childName>Comparables</childName>";
		   s   +=  c+wOUT;		   
		}

	    //name: Scheduler=		
		if (tok.contains("Scheduler")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Scheduler</childName>");
		   wOUT= "<childName>Scheduler</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: Reports=		
		if (tok.contains("name=Reports")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Reports</childName>");
		   wOUT= "<childName>Reports</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: Eq. Confidence parameters=		
		if (tok.contains("Eq. Confidence parameters")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Eq. Confidence parameters</childName>");
		   wOUT= "<childName>Eq. Confidence parameters</childName>";
		   s   +=  c+wOUT;		   
		}
 
		//name: EquityDerivatives=		
		if (tok.contains("EquityDerivatives")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>EquityDerivatives</childName>");
		   wOUT= "<childName>EquityDerivatives</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: Bond=		
		if (tok.contains("Bond")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Bond</childName>");
		   wOUT= "<childName>Bond</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: Bond=		
		if (tok.contains("Bond")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Bond</childName>");
		   wOUT= "<childName>Bond</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: iBond=		
		if (tok.contains("iBond")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>iBond</childName>");
		   wOUT= "<childName>iBond</childName>";
		   s   +=  c+wOUT;		   
		}
		
		//name: Indices=		
		if (tok.contains("Indices")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Indices</childName>");
		   wOUT= "<childName>Indices</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: Currency=		
		if (tok.contains("Currency")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Currency</childName>");
		   wOUT= "<childName>Currency</childName>";
		   s   +=  c+wOUT;		   
		}
 
		//name: RiskEngine=		
		if (tok.contains("RiskEngine")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>RiskEngine</childName>");
		   wOUT= "<childName>RiskEngine</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: StressTest=		
		if (tok.contains("StressTest")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>StressTest</childName>");
		   wOUT= "<childName>StressTest</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: RiskEngine=		
		if (tok.contains("RiskEngine")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>RiskEngine</childName>");
		   wOUT= "<childName>RiskEngine</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: BackTest=		
		if (tok.contains("BackTest")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>BackTest</childName>");
		   wOUT= "<childName>BackTest</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: Comparables=		
		if (tok.contains("Comparables")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Comparables</childName>");
		   wOUT= "<childName>Comparables</childName>";
		   s   +=  c+wOUT;		   
		}
		
		//name: General=		
		if (tok.contains("General")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>General</childName>");
		   wOUT= "<childName>General</childName>";
		   s   +=  c+wOUT;		   
		}

         
//	    //node: title=Month		
//		if (tok.contains("title=Month")  == true)  {
//		   wOUT= "";
//		   System.out.println("<childName>"+tok.substring(6, tok.length())+"</childName>");
//		   wOUT= "<childName>"+tok.substring(6, tok.length())+"</childName>";
//		   s   +=  c+wOUT;		   
//		}
//
//		
//	    //node: title=Section		
//		if (tok.contains("title=Section")  == true)  {
//		   wOUT= "";
//		   System.out.println("<childName>"+tok.substring(6, tok.length())+"</childName>");
//		   wOUT= "<childName>"+tok.substring(6, tok.length())+"</childName>";
//		   s   +=  c+wOUT;   
//		}

//	
//		//node: Class=RecordEditor
//		if (tok.contains("Class=RecordEditor")  == true){
//		   wOUT= "";
//		   System.out.println("<childName>RecordEditor</childName>");
//		   wOUT= "<childName>RecordEditor</childName>";
//		   s   +=  c+wOUT;
//		}

		//node: value=
		if (tok.contains("value=")  == true){
		   wOUT= "";
		   System.out.println("<nodeValue>"+tok.substring(6, tok.length())+"</nodeValue>");
		   wOUT= "<nodeValue>"+tok.substring(6, tok.length())+"</nodeValue>";
		   s   +=  c+wOUT;
		}

  
	    //node: Class=Button
		if (tok.contains("Class=Button")  == true){
		   wOUT= "";
		   System.out.println("<action>Button</action>");
		   wOUT= "<action>Button</action>";
		   s   +=  c+wOUT;
	
		}
		  
		  
	    //node: ID="Button:CancelButton"
		if ((tok.contains("scLocator=//IButton")  == true)
		&& (tok.contains("Button:CancelButton")  == true)) {
		   wOUT= "";
		   System.out.println("<action>Cancel:Button</action>");
		   wOUT= "<action>Cancel:Button</action>";
		   s   +=  c+wOUT;
		   

		}


		//node: ID="Button:InsertButton"
		if ((tok.contains("scLocator=//IButton")  == true)
		&& (tok.contains("Button:InsertButton")  == true)) {
		   wOUT= "";
		   System.out.println("<action>Insert:Button</action>");
		   wOUT= "<action>Insert:Button</action>";
		   s   +=  c+wOUT;
	

		}

		//node: TextAreaItem
		if (tok.contains("_TextAreaItem")  == true) {
		   wOUT= "";
		   System.out.println("<nodeType>TextAreaItem</nodeType>");
		   wOUT= "<nodeType>TextAreaItem</nodeType>";
		   s   +=  c+wOUT;
		   
		}

	    //node: CheckboxItem
		if (tok.contains("_CheckboxItem")  == true) {
		   wOUT= "";
		   System.out.println("<nodeType>CheckboxItem</nodeType>");
		   wOUT= "<nodeType>CheckboxItem</nodeType>";
		   s   +=  c+wOUT;

		}

	    //node: function
		if (tok.contains("!--")  == true) {
		   wOUT= "";
		   System.out.println("<nodeType>"+tok.substring(3, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(3, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;

		}





	    //node: [INSTRID=
		if (tok.contains("[INSTRID=")  == true)  {
		   wOUT= "";
		   String str = tok.valueOf(tok.substring(0, tok.length()));
		  
		   String[] set = str.split("INSTRID=");
		   pre = "INSTRID=";
		   for(int k=0;k<set.length;++k)
		   {
			visK  = set[k];
		   }
		   int iMAX = 5;
		   if (iMAX<5) {
			  iMAX=0; 
		   }
		   if (iMAX>=5) {
			   System.out.println("<nodeValue>"+pre+visK.substring(0, iMAX)+"</nodeValue>");
			   wOUT= "<nodeValue>"+pre+visK.substring(0, iMAX)+"</nodeValue>";
			   s   +=  c+wOUT;   
		   }
		}	

//	    //node: INSTRNAME=
//		if (tok.contains("INSTRNAME=")  == true)  {
//		   wOUT= "";
//		   String str = tok.valueOf(tok.substring(0, tok.length()));
//		  
//		   String[] set = str.split("INSTRNAME=");
//		   pre = "INSTRNAME=";
//		   for(int k=0;k<set.length;++k)
//		   {
//			visK  = set[k];
//		   }
//		   int iMAX = 25;
//		   if (iMAX<25) {
//			  iMAX=0; 
//		   }
//		   if (iMAX>=25) {
//			   System.out.println("<childName>"+pre+visK.substring(0, iMAX)+"</childName>");
//			   wOUT= "<childName>"+pre+visK.substring(0, iMAX)+"</childName>";
//			   s   +=  c+wOUT;   
//		   }
//		}	

	    //node: ISINCODE=
		if (tok.contains("ISINCODE=")  == true)  {
		   wOUT= "";
		   String str = tok.valueOf(tok.substring(0, tok.length()));
		  
		   String[] set = str.split("ISINCODE=");
		   pre = "ISINCODE=";
		   for(int k=0;k<set.length;++k)
		   {
			visK  = set[k];
		   }
		   int iMAX = 12;
		   if (iMAX<12) {
			  iMAX=0; 
		   }
		   if (iMAX>=12) {
			   System.out.println("<nodeType>"+pre+visK.substring(0, iMAX)+"</nodeType>");
			   wOUT= "<nodeType>"+pre+visK.substring(0, iMAX)+"</nodeType>";
			   s   +=  c+wOUT;   
		   }
		}	

		
	}
	
	private static void waitELEM() {
		if (tok.contains("wait") == true)  {
		    System.out.println("<response>post</response>");
		    wOUT= "<response>post</response>";
		    s   =  c+wOUT;
		}
	
		//node: <element>
	    if (tok.contains("=//")  == true){
		   wOUT= "";
		   System.out.println("<nodeName>"+is+"</nodeName>");
		   wOUT= "<nodeName>"+is+"</nodeName>";
		   s   +=  c+wOUT;
	 }
		  

	    //node: title=
		if ((tok.contains("title=")  == true)
		&& (tok.contains("Untitled Button")  == true)){
			//continue
			;
		}
	    //node: title=
		if ((tok.contains("title=")  == true) 
		&& (tok.contains("Untitled Button")  == false)
		&& (tok.contains("title=Month")  == false)
		&& (tok.contains("title=Section")  == false)) {
		   wOUT= "";
		   System.out.println("<nodeType>"+tok.substring(6, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(6, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;
		}
	
//	    //node: title=		
//		if (tok.contains("title=Month")  == true)  {
//		   wOUT= "";
//		   System.out.println("<childName>"+tok.substring(6, tok.length())+"</childName>");
//		   wOUT= "<childName>"+tok.substring(6, tok.length())+"</childName>";
//		   s   +=  c+wOUT;
//		   
//
//		}
		
		
	    //name: Comp.=		
		if (tok.contains("name=Comp.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Comp.</childName>");
		   wOUT= "<childName>Comp.</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Comparables=		
		if (tok.contains("Comparables")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Comparables</childName>");
		   wOUT= "<childName>Comparables</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Haircut=		
		if (tok.contains("name=Haircut")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Haircut</childName>");
		   wOUT= "<childName>Haircut</childName>";
		   s   +=  c+wOUT;		   
		}
		

		
	    //name: HC=		
		if (tok.contains("name=HC")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>HC</childName>");
		   wOUT= "<childName>HC</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Equities=		
		if (tok.contains("name=Equities")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Equities</childName>");
		   wOUT= "<childName>Equities</childName>";
		   s   +=  c+wOUT;		   
		}
	    //name: Eq.=		
		if (tok.contains("name=Eq.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Eq.</childName>");
		   wOUT= "<childName>Eq.</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Back=		
		if (tok.contains("name=Back")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Back</childName>");
		   wOUT= "<childName>Back</childName>";
		   s   +=  c+wOUT;		   
		}
	    //name: Equity=		
		if (tok.contains("name=Equity")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Equity</childName>");
		   wOUT= "<childName>Equity</childName>";
		   s   +=  c+wOUT;		   
		}

	    //name: Bond=		
		if (tok.contains("name=Bond")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Bond</childName>");
		   wOUT= "<childName>Bond</childName>";
		   s   +=  c+wOUT;		   
		}

	    //name: iBond=		
		if (tok.contains("name=iBond")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>iBond</childName>");
		   wOUT= "<childName>iBond</childName>";
		   s   +=  c+wOUT;		   
		}
		//
//	    //name: scRole=		
//		if ((tok.contains("scRole=")  == true)  
//		&& (tok.contains("scRole=list"))  == false)  {
//		   wOUT= "";
//		   System.out.println("<nodeName>"+tok.substring(7, 13)+"</nodeName>");
//		   wOUT= "<nodeName>"+tok.substring(7, 13)+"</nodeName>";
//		   s   +=  c+wOUT;		   
//		}

	    //name: Class=DynamicForm && classIndex=
		if (tok.contains("Class=DynamicForm")  == true) {  
//		&& (tok.contains("classIndex=")  == true))  {
		   wOUT= "";
		   System.out.println("<nodeName>DynamicForm</nodeName>");
		   wOUT= "<nodeName>DynamicForm</nodeName>";
		   s   +=  c+wOUT;		   
		}

	    //name: scRole=list	
		if (tok.contains("scRole=list")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeName>ListGrid</nodeName>");
		   wOUT= "<nodeName>ListGrid</nodeName>";
		   s   +=  c+wOUT;		   
		}


		//name: Eq. Condifence parameters=		
		if (tok.contains("name=Eq. Condifence parameters")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Eq. Condifence parameters</childName>");
		   wOUT= "<childName>Eq. Condifence parameters</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Static=		
		if (tok.contains("name=Static")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Static</childName>");
		   wOUT= "<childName>Static</childName>";
		   s   +=  c+wOUT;		   
		}

		
	    //name: Stress=		
		if (tok.contains("name=Stress")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Stress</childName>");
		   wOUT= "<childName>Stress</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: S.T.=		
		if (tok.contains("name=S.T.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>S.T.</childName>");
		   wOUT= "<childName>S.T.</childName>";
		   s   +=  c+wOUT;		   
		}
		
		
	    //name: Ix.=		
		if (tok.contains("name=Ix.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Ix.</childName>");
		   wOUT= "<childName>Ix.</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Curr.=		
		if (tok.contains("name=Curr.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Curr.</childName>");
		   wOUT= "<childName>Curr.</childName>";
		   s   +=  c+wOUT;		   
		}

	    //name: Type=		
		if (tok.contains("name=Type")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Type</childName>");
		   wOUT= "<childName>Type</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Currency=		
		if (tok.contains("name=Currency")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Currency</childName>");
		   wOUT= "<childName>Currency</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Risk=		
		if (tok.contains("name=Risk")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Risk</childName>");
		   wOUT= "<childName>Risk</childName>";
		   s   +=  c+wOUT;		   
		}

	    //name: Indices=		
		if (tok.contains("name=Indices")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Indices</childName>");
		   wOUT= "<childName>Indices</childName>";
		   s   +=  c+wOUT;		   
		}

	    //name: Instr=		
		if (tok.contains("name=Instr.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Instr.</childName>");
		   wOUT= "<childName>Instr.</childName>";
		   s   +=  c+wOUT;		   
		}

	    //name: B.T.=		
		if (tok.contains("name=B.T.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>B.T.</childName>");
		   wOUT= "<childName>B.T.</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: Bankstaticdata		
		if (tok.contains("name=Bankstaticdata")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Bankstaticdata</childName>");
		   wOUT= "<childName>Bankstaticdata</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Bankbalancehistory		
		if (tok.contains("name=Bankbalancehistory")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Bankbalancehistory</childName>");
		   wOUT= "<childName>Bankbalancehistory</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Bankapprovedratinghistory		
		if (tok.contains("name=Bankapprovedratinghistory")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Bankapprovedratinghistory</childName>");
		   wOUT= "<childName>Bankapprovedratinghistory</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Ratingtranscode		
		if (tok.contains("name=Ratingtranscode")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Ratingtranscode</childName>");
		   wOUT= "<childName>Ratingtranscode</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Riskcommittee		
		if (tok.contains("name=Riskcommittee")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Riskcommittee</childName>");
		   wOUT= "<childName>Riskcommittee</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Parameterselection		
		if (tok.contains("name=Parameterselection")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Parameterselection</childName>");
		   wOUT= "<childName>Parameterselection</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Ratingsproposal		
		if (tok.contains("name=Ratingsproposal")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Ratingsproposal</childName>");
		   wOUT= "<childName>Ratingsproposal</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Linearregressionsettings		
		if (tok.contains("name=Linearregressionsettings")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Linearregressionsettings</childName>");
		   wOUT= "<childName>Linearregressionsettings</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Scheduler		
		if (tok.contains("name=Scheduler")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Scheduler</childName>");
		   wOUT= "<childName>Scheduler</childName>";
		   s   +=  c+wOUT;		   
		}
		//name: Logviewer		
		if (tok.contains("name=Logviewer")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Logviewer</childName>");
		   wOUT= "<childName>Logviewer</childName>";
		   s   +=  c+wOUT;		   
		}
	    //name: General=		
		if (tok.contains("General")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>General</childName>");
		   wOUT= "<childName>General</childName>";
		   s   +=  c+wOUT;		   
		}

	    //name: Scheduler=		
		if (tok.contains("Scheduler")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Scheduler</childName>");
		   wOUT= "<childName>Scheduler</childName>";
		   s   +=  c+wOUT;		   
		}

	
	    //name: S.T.=		
		if (tok.contains("name=S.T.")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>S.T.</childName>");
		   wOUT= "<childName>S.T.</childName>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Reports=		
		if (tok.contains("name=Reports")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Reports</childName>");
		   wOUT= "<childName>Reports</childName>";
		   s   +=  c+wOUT;		   
		}


		//name: Eq. Confidence parameters=		
		if (tok.contains("Eq. Confidence parameters")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Eq. Confidence parameters</childName>");
		   wOUT= "<childName>Eq. Confidence parameters</childName>";
		   s   +=  c+wOUT;		   
		}
 
		//name: EquityDerivatives=		
		if (tok.contains("EquityDerivatives")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>EquityDerivatives</childName>");
		   wOUT= "<childName>EquityDerivatives</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: Bond=		
		if (tok.contains("Bond")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Bond</childName>");
		   wOUT= "<childName>Bond</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: Bond=		
		if (tok.contains("Bond")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Bond</childName>");
		   wOUT= "<childName>Bond</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: iBond=		
		if (tok.contains("iBond")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>iBond</childName>");
		   wOUT= "<childName>iBond</childName>";
		   s   +=  c+wOUT;		   
		}
		
		//name: Indices=		
		if (tok.contains("Indices")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Indices</childName>");
		   wOUT= "<childName>Indices</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: Currency=		
		if (tok.contains("Currency")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Currency</childName>");
		   wOUT= "<childName>Currency</childName>";
		   s   +=  c+wOUT;		   
		}
 
		//name: RiskEngine=		
		if (tok.contains("RiskEngine")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>RiskEngine</childName>");
		   wOUT= "<childName>RiskEngine</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: StressTest=		
		if (tok.contains("StressTest")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>StressTest</childName>");
		   wOUT= "<childName>StressTest</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: RiskEngine=		
		if (tok.contains("RiskEngine")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>RiskEngine</childName>");
		   wOUT= "<childName>RiskEngine</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: BackTest=		
		if (tok.contains("BackTest")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>BackTest</childName>");
		   wOUT= "<childName>BackTest</childName>";
		   s   +=  c+wOUT;		   
		}

		//name: Comparables=		
		if (tok.contains("Comparables")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>Comparables</childName>");
		   wOUT= "<childName>Comparables</childName>";
		   s   +=  c+wOUT;		   
		}
		
		//name: General=		
		if (tok.contains("General")  == true)  {
		   wOUT= "";
		   System.out.println("<childName>General</childName>");
		   wOUT= "<childName>General</childName>";
		   s   +=  c+wOUT;		   
		}
	
//	    //node: title=		
//		if (tok.contains("title=Section")  == true)  {
//		   wOUT= "";
//		   System.out.println("<childName>"+tok.substring(6, tok.length())+"</childName>");
//		   wOUT= "<childName>"+tok.substring(6, tok.length())+"</childName>";
//		   s   +=  c+wOUT;
//		}

		
		//node: Class=RecordEditor
		if (tok.contains("Class=RecordEditor")  == true){
		   wOUT= "";
		   System.out.println("<childName>RecordEditor</childName>");
		   wOUT= "<childName>RecordEditor</childName>";
		   s   +=  c+wOUT;
		}

		


		//node: value=
		if (tok.contains("value=")  == true){
		   wOUT= "";
		   System.out.println("<nodeValue>"+tok.substring(6, tok.length())+"</nodeValue>");
		   wOUT= "<nodeValue>"+tok.substring(6, tok.length())+"</nodeValue>";
		   s   +=  c+wOUT;
		}
		

	    //node: Class=Button
		if (tok.contains("Class=Button")  == true){
		   wOUT= "";
		   System.out.println("<action>Button</action>");
		   wOUT= "<action>Button</action>";
		   s   +=  c+wOUT;
	
		}

				
	    //node: ID="Button:CancelButton"
		if ((tok.contains("scLocator=//IButton")  == true)
		&& (tok.contains("Button:CancelButton")  == true)) {
		   wOUT= "";
		   System.out.println("<action>Cancel:Button</action>");
		   wOUT= "<action>Cancel:Button</action>";
		   s   +=  c+wOUT;

		}


				
		
	    //node: ID="Button:InsertButton"
		if ((tok.contains("scLocator=//IButton")  == true)
		&& (tok.contains("Button:InsertButton")  == true)) {
		   wOUT= "";
		   System.out.println("<action>Insert:Button</action>");
		   wOUT= "<action>Insert:Button</action>";
		   s   +=  c+wOUT;
	

		}

	    //node: TextAreaItem
		if (tok.contains("_TextAreaItem")  == true) {
		   wOUT= "";
		   System.out.println("<nodeType>TextAreaItem</nodeType>");
		   wOUT= "<nodeType>TextAreaItem</nodeType>";
		   s   +=  c+wOUT;
			

		}
	
	    //node: CheckboxItem
		if (tok.contains("_CheckboxItem")  == true) {
		   wOUT= "";
		   System.out.println("<nodeType>CheckboxItem</nodeType>");
		   wOUT= "<nodeType>CheckboxItem</nodeType>";
		   s   +=  c+wOUT;
		}

	    //node: [INSTRID=
		if (tok.contains("[INSTRID=")  == true)  {
		   wOUT= "";
		   String str = tok.valueOf(tok.substring(0, tok.length()));
		  
		   String[] set = str.split("INSTRID=");
		   pre = "INSTRID=";
		   for(int k=0;k<set.length;++k)
		   {
			visK  = set[k];
		   }
		   int iMAX = 5;
		   if (iMAX<5) {
			  iMAX=0; 
		   }
		   if (iMAX>=5) {
			   System.out.println("<nodeValue>"+pre+visK.substring(0, iMAX)+"</nodeValue>");
			   wOUT= "<nodeValue>"+pre+visK.substring(0, iMAX)+"</nodeValue>";
			   s   +=  c+wOUT;   
		   }
		}	

//	    //node: INSTRNAME=
//		if (tok.contains("INSTRNAME=")  == true)  {
//		   wOUT= "";
//		   String str = tok.valueOf(tok.substring(0, tok.length()));
//		  
//		   String[] set = str.split("INSTRNAME=");
//		   pre = "INSTRNAME=";
//		   for(int k=0;k<set.length;++k)
//		   {
//			visK  = set[k];
//		   }
//		   int iMAX = 25;
//		   if (iMAX<25) {
//			  iMAX=0; 
//		   }
//		   if (iMAX>=25) {
//			   System.out.println("<childName>"+pre+visK.substring(0, iMAX)+"</childName>");
//			   wOUT= "<childName>"+pre+visK.substring(0, iMAX)+"</childName>";
//			   s   +=  c+wOUT;   
//		   }
//		}	

	    //node: ISINCODE=
		if (tok.contains("ISINCODE=")  == true)  {
		   wOUT= "";
		   String str = tok.valueOf(tok.substring(0, tok.length()));
		  
		   String[] set = str.split("ISINCODE=");
		   pre = "ISINCODE=";
		   for(int k=0;k<set.length;++k)
		   {
			visK  = set[k];
		   }
		   int iMAX = 12;
		   if (iMAX<12) {
			  iMAX=0; 
		   }
		   if (iMAX>=12) {
			   System.out.println("<nodeType>"+pre+visK.substring(0, iMAX)+"</nodeType>");
			   wOUT= "<nodeType>"+pre+visK.substring(0, iMAX)+"</nodeType>";
			   s   +=  c+wOUT;   
		   }
		}	

	}

}
		 
		
		

 
	  
