import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('')

WebUI.navigateToUrl('https://10.0.10.230:10044/LiqPortalWEB/login.jsp')

WebUI.setText(findTestObject('Object Repository/Page_LiME/input_Username_j_username (1)'), 'mpetracc')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_LiME/input_Password_j_password (1)'), 'YaVcYVjucopeeJ1hpyWlvw==')

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Before 09102018_isc_23 (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/div_Select Date RangeSelect Da (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_To_isc_69 (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/td_Today (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_To_isc_5Q (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/div_OK (1)'))

WebUI.setText(findTestObject('Object Repository/Page_LiME/input_To_valueField (1)'), '')

WebUI.click(findTestObject('Object Repository/Page_LiME/td_To_isc_5R (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/span (1)'))

WebUI.doubleClick(findTestObject('Object Repository/Page_LiME/img_Settlement Cash Resources_ (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Settlement Cash Resources_ (1)'))

WebUI.doubleClick(findTestObject('Object Repository/Page_LiME/img_Settlement Cash Resources_ (1)'))

WebUI.doubleClick(findTestObject('Object Repository/Page_LiME/img_Settlement Cash Resources_ (1)'))

WebUI.doubleClick(findTestObject('Object Repository/Page_LiME/img_Settlement Cash Resources_ (1)'))

WebUI.doubleClick(findTestObject('Object Repository/Page_LiME/img_Settlement Cash Resources_ (1)'))

WebUI.doubleClick(findTestObject('Object Repository/Page_LiME/img_Settlement Cash Resources_ (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/div_Total Liquid ResourcesItem (1)'))

WebUI.doubleClick(findTestObject('Object Repository/Page_LiME/img_-_isc_4Wblank10 (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_-_isc_4Wblank10 (1)'))

WebUI.doubleClick(findTestObject('Object Repository/Page_LiME/img_-_isc_4Wblank10 (1)'))

WebUI.doubleClick(findTestObject('Object Repository/Page_LiME/img_-_isc_4Wblank10 (1)'))

WebUI.doubleClick(findTestObject('Object Repository/Page_LiME/img_-_isc_4Wblank10 (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Total Liquid Resources_isc (1)'))

WebUI.setText(findTestObject('Object Repository/Page_LiME/input_Before 09102018_TOTLIQRE (1)'), '<9570000')

WebUI.setText(findTestObject('Object Repository/Page_LiME/input_Before 09102018_HARDLIM1 (1)'), '>1100')

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Before 09102018_isc_2Iicon (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Before 09102018_isc_23 (1)'))

WebUI.doubleClick(findTestObject('Object Repository/Page_LiME/div_-67305137 (1)'))


WebUI.navigateToUrl('https://10.0.10.230:10044/LiqPortalWEB/index.html')

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Total Liquid Resources_isc (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/nobr_Group by Total Liquid Res'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Total Liquid Resources_isc (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/td_Ungroup'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Ref. date_isc_4Zicon'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Ref. date_isc_4Zicon'))

WebUI.click(findTestObject('Object Repository/Page_LiME/nobr_Ungroup'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Daily net unbalances_isc_4'))

WebUI.click(findTestObject('Object Repository/Page_LiME/nobr_Group by Daily net unbala'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Daily net unbalances_isc_4'))

WebUI.click(findTestObject('Object Repository/Page_LiME/nobr_Ungroup'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Hard limit_isc_4Zicon'))

WebUI.click(findTestObject('Object Repository/Page_LiME/nobr_Group by Hard limit'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Hard limit_isc_4Zicon'))

WebUI.click(findTestObject('Object Repository/Page_LiME/span_1 (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Hard limit_isc_4Zicon'))

WebUI.click(findTestObject('Object Repository/Page_LiME/nobr_Ungroup'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Soft limit_isc_4Zicon'))

WebUI.click(findTestObject('Object Repository/Page_LiME/td_Group by Soft limit'))

WebUI.click(findTestObject('Object Repository/Page_LiME/span_2 (1)'))

WebUI.click(findTestObject('Object Repository/Page_LiME/td'))

WebUI.click(findTestObject('Object Repository/Page_LiME/img_Soft limit_isc_4Zicon'))

WebUI.click(findTestObject('Object Repository/Page_LiME/nobr_Ungroup'))


WebUI.closeBrowser()
