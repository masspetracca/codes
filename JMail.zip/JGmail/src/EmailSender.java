import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
 
public class EmailSender {
 private String from = "massimo.petracca-ext@lseg.com";
 private String username = "massimo.petracca-ext@lseg.com";
 private String password = ".mpetrac006";
 
 public static void main(String[] args) throws AddressException, MessagingException {
   EmailSender es = new EmailSender();
   es.sendEmail(
     "massimo.petracca-ext@lseg.com",
     "Email di prova",
     "Eccomi!!!!!!!!!!!!!!! \n\n\nHo inviato l'email!");
 }
 
 public void sendEmail(String to, String subject, String text) throws AddressException, MessagingException {
   /***** creiamo un oggetto di tipo Properties che conterr� i parametri di configurazione per la connessione al mail server *****/
   Properties props = new Properties();
   props.put("mail.smtp.auth", "true");
   props.put("mail.smtp.starttls.enable", "true");
   props.put("mail.smtp.host", "smtp.gmail.com");
   props.put("mail.smtp.socketFactory.port", "465");
   props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
 
  /******* Creiamo una connessione al mail server ********/
  Session session = Session.getInstance(
     props,
     new javax.mail.Authenticator() {
       protected PasswordAuthentication getPasswordAuthentication() {
          return new PasswordAuthentication(username, password);
       }
    });
 
  /****** creiamo il messaggio impostando, destinatari, oggetto e contenuto del messaggio ******/
  Message message = new MimeMessage(session);
  message.setFrom(new InternetAddress(from));
  message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
  message.setSubject(subject);
  message.setText(text);
 
  /***** INVIAMO L'EMAIL! ******/
  Transport.send(message);
 }
}