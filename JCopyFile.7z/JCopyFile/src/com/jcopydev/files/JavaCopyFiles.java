
package com.jcopydev.files; 

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;

public class JavaCopyFiles {

	public static void main(String[] args) throws InterruptedException,
			IOException {

		
		//source = new File("H://Desktop//wspace//"); 
		final File tempFile;
		final File source = new File("confDOS/");
		//dest = new File("Z://Team//Petracca//workspace//");  
		final File dest = new File("datiDOS/");
		long start = System.nanoTime();

		//long end;

		// copy file using copy
		  
		copy(source, dest);
		System.out.println("Time taken by FileStreams Copy = "
				+ (System.nanoTime() - start));

		// copy file using FileChannel
		copyFileUsingFileChannel(source, dest);
		System.out.println("Time taken by FileStreams Copy = "
				+ (System.nanoTime() - start));

		// copy file using FileStreams
		copyFileUsingFileStreams(source, dest);
		System.out.println("Time taken by FileStreams Copy = "
				+ (System.nanoTime() - start));
	
	}


	private static void copyFileUsingFileStreams(File source, File dest)
			throws IOException {
		InputStream input = null;
		OutputStream output = null;
		try {
			input = new FileInputStream(source);
			output = new FileOutputStream(dest);
			byte[] buf = new byte[1024];
			int bytesRead;
			while ((bytesRead = input.read(buf)) > 0) {
				output.write(buf, 0, bytesRead);
			}
			if (input != null) input.close();
			if (output != null) output.close();
		} finally {
			input.close();
			output.close();
		}
	}

	private static void copyFileUsingFileChannel(File source, File dest)
	throws IOException {
		FileChannel input = null;
		FileChannel output = null;
		try {
			input = new FileInputStream(source).getChannel();
			output = new FileOutputStream(dest).getChannel();
			long size = input.size();
			int maxCount = (64*1025*1024) - (32- 1024);
			long position =0;
			while (position < size) {
				position += input.transferTo(position, maxCount, output); 
			}
			if (input != null) input.close();
			if (output != null) output.close();
		} finally {
			input.close();
			output.close();
		}


	}
	private static void copy(File source, File dest) throws IOException {
	    InputStream in = new FileInputStream(source);
	    OutputStream out = new FileOutputStream(dest);

	    // Transfer bytes from in to out
	    byte[] buf = new byte[1024];
	    int len;
	    while ((len = in.read(buf)) > 0) {
	        out.write(buf, 0, len);
	    }
	    in.close();
	    out.close();
	}





}
