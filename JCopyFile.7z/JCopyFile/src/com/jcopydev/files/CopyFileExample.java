package com.jcopydev.files;



 
public class CopyFileExample {
//    public static void main(String[] args) {	
 
//    	File source = new File("H:\\work-temp\\file");
//    	File dest = new File("H:\\work-temp\\file2");
//    	try {
//    	    File.copy(source, dest);
//    	} catch (IOException e) {
//    	    e.printStackTrace();
//    	}
//    }
}

