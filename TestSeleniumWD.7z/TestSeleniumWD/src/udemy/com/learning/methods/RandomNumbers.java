package udemy.com.learning.methods;

public class RandomNumbers {

	public static void main(String[] args) {

		//type cast -->

		int num = (int)(Math.random()*5);
		System.out.println(num);

	}

}
