package com.learning.methods;

public class IfElseStatements {
	public static void main(String[] args) {
		int num = (int) (Math.random()*20);
		System.out.println("Get number: "+num);
		
		if  (num>=10 && num<=15) {
			System.out.println(num+"  between 10 and 15 ");
		}
		if (num>=10 && num>=15) {
			System.out.println(num+" is Greater than 10");
		}
		if (num<10) { 
			System.out.println(num+" is Less than 10");
		}
	}
}

