package com.learning.methods;

public class TakeMoto extends Bike {

	public void tyreType() {
		System.out.println("Tubeless tyres");
	}
	public static void main(String[] args) {
		Bike b = new Bike();
		b.color="Black";
		b.startBike();
		
		TakeMoto m = new TakeMoto();
		m.color="Blue";
		m.startBike();
		
	}
}
