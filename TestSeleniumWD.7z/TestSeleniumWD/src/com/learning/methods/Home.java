package com.learning.methods;

public class Home {

	int i = 10;
	
	public void go() {
		i=356;
		int j =234;
	}
	public void show() {
		i=7438;
	}
}
