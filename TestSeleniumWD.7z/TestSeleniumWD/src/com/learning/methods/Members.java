package com.learning.methods;

public class Members {
	String add;
	String name;
	
	public void deposit() {
		System.out.println("Account deposit"+name+" "+add);
	}
	public void withdrawl() {
		
	}
	
}
