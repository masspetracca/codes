package com.learning.methods;

public class Bike {
	String color;
	
	public static void startBike() {
		System.out.println("Self start the bike");
	}
	public static void stopBike() {
		System.out.println("Self stop the bike");
	}
}
