package com.learning.methods;


public class LearningMethods {
	int i;
	private static int i2;
	private static int num1;
	private static int num2;

	public int display(int k, String a, char c, float f, boolean b) {
		i = 10;
		return i;
		//starts
//		String out = "Hello";
//		return out;
	}
	public void show() {
		int a;
		int b;
		String c;
		
		System.out.println("Inside Display Method: ");
		
	}
	public static void main(String[] arg) {
		Home h = new Home();
		h.i++;
		System.out.println(h.i);
		
		LearningMethods l = new LearningMethods();
		//l.display(k, a, c, f, b);
		l.show();
		
		System.out.println("Hi how are you ?");
		
		Calculator calc = new Calculator();
		num1=10;
		num2=4;
		//sum
		int s = calc.getSum(num1, num2);
		System.out.println("totale sum: "+s);
		//diff
		int ds = calc.getSub(num1, num2);
		System.out.println("totale diff: "+ds);
		//mult
		int m = calc.getMul(num1, num2);
		System.out.println("totale mult: "+m);
		//div
		int dv = calc.getDiv(num1, num2);
		System.out.println("totale div: "+dv);
	}
}
