package com.learning.methods;

import java.util.Scanner;

public class MethodCalling {
	
	private static int ind;
	private static Scanner input;
	public static void main(String[] args) {

		MethodCalling m = new MethodCalling();
		m.go();
		m.go1();
		m.go2();
		
		go3();
	}
	public void go() {
		System.out.println("Inside Go Method");
		int value = 10;
		boolean loop = 10 >= value;
		while (ind <= 10 && loop) {
			ind++;
			System.out.println("Loop-1:"+ind);
			if (ind == 5) {
				System.out.println("FORZATURA:"+ind);
				break;
			}
		}
		System.out.println("Loop-1[fine]:"+ind);
	}
	public void go1() {
		System.out.println("Inside Go1 Method");
		for (int ind=0;ind <5; ind++) {
			System.out.println("Loop-2:"+ind);
		}
	}
	public void go2() {
		System.out.println("Inside Go2 Method");
		int value = 4;
		if (4 == value) {
			System.out.println("Cond. true:"+value);
		}
		else {
			System.out.println("Cond. false:"+value);
		}
		System.out.println("Loop-3[fine]:"+ind);
	}
	public static void go3() {
		System.out.println("Inside Go3 Method");
		System.out.println("Enter number:");
		input = new Scanner(System.in);
		int value = input.nextInt();
		while (value <= 5) {
			System.out.println("enter number:"+value);
			value = input.nextInt();
		}
		System.out.println("Correctly entered>5:"+value);
		switch (value) {
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
			System.out.println("SWITCH using - enter number:"+value);
		case 99:
			System.out.println("fine-switch:"+value);
			break;
		default:
			System.out.println("number failed:"+value);
		}
	}

}
