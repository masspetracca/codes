package com.learning.methods;

public class TestBank {

	public static void main(String[] args) {
		Bank b1 = new Bank();
		b1.name = "HSBC";
		b1.accountbalance=1000;
		b1.interesgained(500);
		System.out.println("account:"+b1.accountbalance+" "+b1.name);

		Members m = new Members();
		m.name="Jack Frost";
		
		System.out.println(b1.meb.add);
		System.out.println(b1.meb.name);
		

		Bank b2 = new Bank();
		b2.name = "Barclays";
		b2.accountbalance=2000;
		b2.meb=new Members();

		Members m2 = b2.getBalance();
		m2.deposit();
		m2.withdrawl();
		
		b2.getBalance().deposit();
		b2.getBalance().withdrawl();
		
	}

}
