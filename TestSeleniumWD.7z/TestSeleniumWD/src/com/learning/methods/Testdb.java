package com.learning.methods;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public class Testdb {
static String url = "jdbc:db2:SAMPLE";
static String user = "mpetracc";
static String password = ".mpetrac12";
static Connection conn = null;

public static void main(String[] args) {
    // Load the DB2 JDBC Type 2 Driver with DriverManager
    Class.forName("COM.ibm.db2.jdbc.app.DB2Driver");
    //Driver d = new COM.ibm.db2.jcc.DB2Driver();
    //Driver d = new COM.ibm.db2.jdbc.app.DB2Driver();
    //if(!d.jdbcCompliant()) System.console().printf("jdbc driver is not ccompliant");
    //DriverManager.registerDriver(new COM.ibm.db2.jdbc.app.DB2Driver());
//    DriverManager.registerDriver(d);
//    if(!d.acceptsURL(url))
//        throw new SQLException("url \"" + url + "\" is not accepted by jdbc driver");
    conn = DriverManager.getConnection(url, user, password);
    conn.setAutoCommit(false);

    List <String> query = conn.getSQLQuery("select * from students where id = '102'");
	for (int i=0; i<query.size();i++) {
		System.out.println(query.get(i));
	}

    /* do some work */
    conn.commit();
    conn.close();
	}
}
