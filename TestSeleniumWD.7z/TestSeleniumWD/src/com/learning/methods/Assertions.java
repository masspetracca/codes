package com.learning.methods;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ErrorCollector;

import junit.framework.Assert;

public class Assertions {

	@Rule
	public ErrorCollector er = new ErrorCollector();
	
	@Test
	public void testTitle() {
		String actual_title = "Google.com"; //extract script
		String expected_title = "Google-com"; //compare this title
		System.out.println("Starting Text Comparisation");
		try {
			Assert.assertEquals(actual_title, expected_title);
		} catch (Throwable t) {
			System.out.println("Error Captured");
			er.addError(t);
		}
		System.out.println("Stop Text Comparisation");
//		if (actual_title == expected_title) {
//			System.out.println("Test Case Pass");
//		} else {
//			System.out.println("Test Case Fail");
//		}
	}
}
