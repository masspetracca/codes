package com.learning.methods;

public class SwapNumbers {

	int s;
	int p;
	
	
	public static void swap(int a, int b) {
		//pass by value
		int temp=a;
		a=b;
		b=temp;
	}
	
	public static void swap (SwapNumbers p) {
		int temp= p.s; //pass by ref
		p.s=p.p;
		p.p=temp;
		
	}
	public static void main(String[] args) {
		SwapNumbers swv = new SwapNumbers();
		swv.s = 50;
		swv.p = 100;
		
		swap(swv.s,swv.p); //pass by value
		
		System.out.println("Int - passing by values(s, p): "+swv.s+" - "+swv.p);

		SwapNumbers swr = new SwapNumbers();
		swr.s = 50;
		swr.p = 100;
		
		swap(swr); //pass by ref
		
		System.out.println("Int - passing by references(s, p): "+swr.s+" - "+swr.p);
	}

}
