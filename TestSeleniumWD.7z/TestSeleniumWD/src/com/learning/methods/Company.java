package com.learning.methods;

public class Company {
	public static void main(String[] args) {
		Department.nat_holiday();

		Department nd = new Department(); 
				
		nd.dept_id = 1;
		nd.dept_num = 10;
		nd.no_of_emp = 100;
		nd.name_ofcompany="Prova";
		
		String s1 = ("Departmnt. (id, num, name, employers):"+nd.dept_id+", "+nd.dept_num+", "+nd.name_ofcompany+", "+ nd.no_of_emp);
		
		nd.dept_id = 2;
		nd.dept_num = 10;
		nd.no_of_emp = 10000;
		nd.name_ofcompany="Telecom";

		String s2 = ("Departmnt. (id, num, name, employers):"+nd.dept_id+", "+nd.dept_num+", "+nd.name_ofcompany+", "+ nd.no_of_emp);
	
		String outDptmnt[] = {s1,s2};
		
		for (int i=0; i<outDptmnt.length;i++) {
			System.out.println(""+outDptmnt[i]);
		}
		
	}

}
