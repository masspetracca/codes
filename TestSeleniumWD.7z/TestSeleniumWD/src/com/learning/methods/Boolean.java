package com.learning.methods;

public class Boolean {
	public static void main(String[] args) {
		boolean bol=true;
		System.out.println(10<=20);
		
		int first_no=22;
		int sec_no=22;
		String abc = "Welcome to selenium tutorial ";
		String def = "Welcome to selenium tutorial";
		
		if (abc == def) {
			System.out.println("strings are equal: "+abc);
		}
		else {
			System.out.println("strings are not equal: "+abc+" "+def);
		}
		boolean result = first_no>sec_no;
		System.out.println(result);
		
		if (first_no>sec_no) {
			System.out.println("first number is greater:"+first_no);
		}
		if (first_no==sec_no) {
			System.out.println("first and second numbers are equal:"+first_no);
		}
		if (first_no<sec_no) {
			System.out.println("second number is greater:"+sec_no);
		}
	}
}
