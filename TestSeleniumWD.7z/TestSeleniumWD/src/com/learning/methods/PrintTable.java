package com.learning.methods;

public class PrintTable {
	private static int t;
	private int i;
	
	public static void main(String[] args) {
		t=10;
		table(10);
	}

	private static void table(int i) {
		for (i=1;i<=10;i++) {
			System.out.println(t*i);
		}
	}
}
