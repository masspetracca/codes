package com.learning.methods;

public class Calculator {

	public int getSum(int num1, int num2) {
		int result = num1+num2;
		return result;
	}
	public int getSub(int num1, int num2) {
		int result = num1-num2;
		return result;
	}
	public int getMul(int num1, int num2) {
		int result = num1*num2;
		return result;
	}
	public int getDiv(int num1, int num2) {
		int result = num1/num2;
		return result;
	}
}
