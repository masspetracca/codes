package com.learning.methods;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runners.Parameterized.Parameters;

public class TestParam {
	
	static String firstname;
	static String lastname;
	static String password;
	static int age;
	
	public TestParam(String firstname, String lastname, String password, int age) {
		this.firstname=firstname;
		this.lastname=lastname;
		this.password=password;
		this.age=age;
	}
	@Parameters
	public Collection<Object[]> getData(){
		Object[] [] data = new Object[2] [4];
		data [0] [0] = "Joy";
		data [0] [1] = "Smith";
		data [0] [2] = "Abcd";
		data [0] [3] = 18;
		
		data [1] [0] = "Tom";
		data [1] [1] = "Williams";
		data [1] [2] = "Abcdefg";
		data [1] [3] = 28;
	
		return Arrays.asList(data);
	}
	@Test
	public  void doLogin() {
		System.out.println(firstname+" - "+lastname+" - "+password+" - "+age);
		System.out.println(" "+Arrays.asList(getData()));
	}
}