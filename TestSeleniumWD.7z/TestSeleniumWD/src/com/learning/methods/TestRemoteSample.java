package com.learning.methods;

import java.net.MalformedURLException;
import java.net.URL;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class TestRemoteSample {
	private String browserName;
	private String url;

	@Test
	public void testLogin() throws MalformedURLException {
		DesiredCapabilities cap = DesiredCapabilities.firefox();
		browserName = "firefox";
		url="http://gmail.com";
		cap.setBrowserName(browserName);
		cap.setPlatform(Platform.ANY);
		
		RemoteWebDriver driver = new RemoteWebDriver(new URL("http://localhost:4444/wb/hub"),cap);
		driver.get(url);
		driver.findElement(By.id("Email")).sendKeys("masspetracca@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("ssssss");
	}
}
	
