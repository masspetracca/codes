package com.learning.methods;

public interface Employee {

	public void salary();
	public void hr_policy();
	
}
