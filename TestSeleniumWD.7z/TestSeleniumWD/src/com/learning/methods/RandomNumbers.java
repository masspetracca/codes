package com.learning.methods;

public class RandomNumbers {
	public static void main(String[] args) {
		double num = Math.random()*100;	
		int num1 = (int)(Math.random()*100);	
		System.out.println("num rnd:"+num);
		System.out.println("num1 rnd:"+num1);
	}
}
