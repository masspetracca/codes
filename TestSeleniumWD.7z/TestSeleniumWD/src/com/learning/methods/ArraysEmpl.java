package com.learning.methods;

import java.util.Collection;

public class ArraysEmpl {
	public static void main(String[] args) {
		int emp1 = 5000;
		int emp2 = 6000;
		int[]  salary;
		salary = new int[10];
		String month[] = {"Jan", "Feb", "Mar"};
		//System.out.println(month[0]);
		
		for(int i=0; i<month.length;i++) {
			System.out.println(month[i]);
		}
	}




	
	
}
