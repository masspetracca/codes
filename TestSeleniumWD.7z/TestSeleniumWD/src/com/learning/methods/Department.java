package com.learning.methods;

public class Department implements Employee {

	//non static  global variables
	public int dept_num;
	public int dept_id;
	public int no_of_emp;
	public String name_ofcompany;
	public int salary;

	public void add_dept() {
		System.out.println("Deptm. added");
	}
	
	public void chng_dept() {
		System.out.println("Deptm. changed");
	}
	public static void nat_holiday(){
		System.out.println("Nat. holiday");
	}
	public static void main(String[] args) {
		Employee em = new Department();
		em.salary();
	}
	public void salary() {
		System.out.println("Salary granted for this month");
		
	}
	public void  hr_policy() {
		System.out.println("HR Policies applied");		
	}

}
