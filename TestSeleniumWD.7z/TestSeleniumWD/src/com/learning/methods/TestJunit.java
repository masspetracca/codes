package com.learning.methods;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assume;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestJunit {
	public static boolean dbconnection() {
		return true;		
	}
	
	
	@BeforeClass
	public static void Seleniumsetup() {
		System.out.println("Initializing the Selenium Server");
		Assume.assumeTrue(dbconnection());
	}
	
	@After
	public void testClosebrowser() {
		System.out.println("Closing the firefox browser");
	}
	
	@AfterClass
	public static void Seleniumshutdown() {
		System.out.println("Shutting down Selenium Server");
	}
	
	@Test
	public void testlogin() {
		System.out.println("Enter login details");
	}
	
	@Test
	public void testNavigation() {
		System.out.println("Opening the website");
	}
}
