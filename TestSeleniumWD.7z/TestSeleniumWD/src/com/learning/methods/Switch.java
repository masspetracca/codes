package com.learning.methods;

public class Switch {
	public static void main(String[] args) {
		int month =1;
		
		switch (month) {
		case 1:
			System.out.println("Jan");
			break;
		case 2:
			System.out.println("Feb");
			break;
		case 3:
			System.out.println("Mar");
			break;
		case 4:
			System.out.println("Apr");
			break;
		case 5:
			System.out.println("Mag");
			break;
		case 6:
			System.out.println("Giu");
			break;
		case 7:
			System.out.println("Lug");
			break;
		case 8:
			System.out.println("Ago");
			break;
		case 9:
			System.out.println("Sep");
			break;
		case 10:
			System.out.println("Oct");
			break;
		case 11:
			System.out.println("Nov");
			break;
		case 12:
			System.out.println("Dic");
			break;
		default: 
			System.out.println("Others !");
			break;
	}
	
	}
}
