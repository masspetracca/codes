package com.learning.methods;

public class TestByke {

	public static void main(String[] args) {
		Bike b = new Bike();
		b.color="Black";
		b.startBike();

		TakeMoto m = new TakeMoto();
		m.color="Blue";
		m.startBike();
		m.tyreType();
		
		Bike b1= new TakeMoto();
		b1.startBike();
		b1.stopBike();
	}

}
