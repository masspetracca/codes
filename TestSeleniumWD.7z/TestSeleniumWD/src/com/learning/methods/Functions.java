package com.learning.methods;

public class Functions {
	public static void main(String[] args) {
		print();
		addNumbers();
		int res = addNumbers(30, 40);
		System.out.println(res);
	}

	private static int addNumbers(int a, int b) {
		int c = a+b;
		return c;			
	}

	private static void addNumbers() {
		
	}

	private static void print() {
		// TODO Auto-generated method stub
		
	}
}
