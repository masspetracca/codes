package com.learning.methods;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.logging.Logger;

import org.junit.Rule;
import org.junit.rules.ErrorCollector;
import org.openqa.selenium.server.SeleniumServer;

import com.thoughtworks.selenium.DefaultSelenium;

public class TestCore {

	public static DefaultSelenium selenium = null;
	public static Properties config = new Properties();
	public static Properties object = new Properties();
	public static Xls_Reader excel = null;
	public static Logger app_Logs = Logger.getLogger("devpinoyLogger");
	public static SeleniumServer server = null;
	
	@Rule
	public ErrorCollector ec = new ErrorCollector();
	
	public static void init() throws Exception{
		if (selenium == null) {
			SeleniumServer server = new SeleniumServer();
			server.boot();
			
			FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"//src//dd_propperties//config.properties");
			config.load(fis);
			System.out.println("Loading config properties file");
			fis = new FileInputStream(System.getProperty("user.dir")+"//src//dd_propperties//objects.properties");
			object.load(fis);
			excel = new Xls_Reader(System.getProperty("user.dir")+"//src//dd_propperties//testData.xlsx");
			selenium = new DefaultSelenium("localhost", 4444, config.getProperty("browser"),config.getProperty("testsite"));
			selenium.start();
			selenium.windowFocus();
			selenium.windowMaximize();
			
		}
	}
}
