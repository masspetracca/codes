package com.learning.methods;

public class WhileLoop {
	public static void main(String[] args) {
		int i=1;

		do {
			System.out.println(i);
			i++;
		}
		while(i<=10); {
			System.out.println(i);
			i++;
		}
		System.out.println("Ater loop: ");
		for (i=1;i<=12;i++) {
			System.out.println(i);
		}
		System.out.println("End for: ");
	}
}
