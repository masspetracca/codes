package com.learning.methods;

public interface TestEmployee {
	public void salary();
}
