package com.learning.methods;

public class staticandnostatic {
	
	public static int q=200;
	
	public static void function1() {
		int abc = 20;
	}
	public static void function2() {
		int xyz = 200;
	}
}
