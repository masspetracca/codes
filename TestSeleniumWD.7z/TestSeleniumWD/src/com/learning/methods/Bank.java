package com.learning.methods;

public class Bank {
	String name;
	int accountbalance;
	
	Members meb;
	
	public int interesgained(int increment) {
		accountbalance = accountbalance+increment;
		return accountbalance;
	}
	public Members getBalance() {
		return meb;
		
	}
	
}
