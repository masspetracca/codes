#@PydevCodeAnalysisIgnore


sys.path.append("C:/DeLauri/WorkSpaces/WorkSpaceCCG_RAD/CCGScript/WS-SetupUtilities/WAS8.5/")
from script_setup_parameters import *




print '\n*****Start script*****\n'

i = 0
for dataSourceName in dsList:       # imposto tutti i datasource che trovo nella dsList
    print '\n -' + dataSourceName + ' settings..'
    
    dataSource = AdminConfig.getid('/DataSource:' + dataSourceName + '/')       # salvo in una variabile l'id del datasource
    propertySet = AdminConfig.showAttribute(dataSource, 'propertySet')      # salvo in una variabile il riferimento all'attributo 'propertySet' del datasource
    pool=AdminConfig.showAttribute(dataSource,'connectionPool') 
   
    #impostazioni pool connessione
    print '\n   - connection pool settings..'

    AdminConfig.modify(''+pool+'', '[[connectionTimeout "' + connectionTimeout + '"] [maxConnections "' + maxConnections + '"] [unusedTimeout "' + unusedTimeout + '"] [minConnections "' + minConnections + '"] [agedTimeout "0"] [purgePolicy "EntirePool"] [reapTime "' + reapTime + '"]]')
       		       
    
    #impostazione libreria
    print '\n   - library settings..'
    
    # seleziono la libreria giusta
    library = dsLibraryList[i]
    
    # seleziono e imposto la propriet� 'libraries' all'interno della lista di propriet� propertySet
    propertyName = 'libraries'
    libraryProperty = [property for property in AdminConfig.list('J2EEResourceProperty', propertySet).split("\r\n") if AdminConfig.showAttribute(property, 'name') == propertyName]

    AdminConfig.modify(''+libraryProperty[0]+'', '[[name "libraries"] [type "java.lang.String"] [description "DataSource library."] [value "' + library + '"] [required "false"]]') 
    i = i + 1



#Salvataggio configurazione
AdminConfig.save()
print '\n\nConfiguration saved.'


# Print results
print '\n\n\nNew configurations:'

for dataSourceName in dsList:
    #dataSource = AdminConfig.getid('/DataSource:' + dataSourceName + '/')
    #sysout = AdminConfig.showall(dataSource)
    #print '\n\n  Datasource ' + dataSourceName + ':\n\n' + sysout
    
    print '\n\n -' + dataSourceName + ' settings:'
    
    print '\n  Connection pool settings:'
    print '      connectionTimeout = ' + connectionTimeout
    print '      maxConnections = ' + maxConnections
    print '      unusedTimeout = ' + unusedTimeout
    print '      minConnections = ' + minConnections
    print '      agedTimeout = ' + agedTimeout
    print '      reapTime = ' + reapTime
    
    dataSource = AdminConfig.getid('/DataSource:' + dataSourceName + '/')       # salvo in una variabile l'id del datasource
    propertySet = AdminConfig.showAttribute(dataSource, 'propertySet')      # salvo in una variabile il riferimento all'attributo 'propertySet' del datasource
    propertyName = 'libraries'
    libraryProperty = [property for property in AdminConfig.list('J2EEResourceProperty', propertySet).split("\r\n") if AdminConfig.showAttribute(property, 'name') == propertyName]
    library = AdminConfig.showAttribute(libraryProperty[0], 'value')
    print '\n  Library settings:'
    print '      libraries = ' + library




print '\n\n\n*****End script*****\n\n'