#@PydevCodeAnalysisIgnore


sys.path.append("C:/DeLauri/WorkSpaces/WorkSpaceCCG_RAD/CCGScript/WS-SetupUtilities/WAS8.5/")
from script_setup_parameters import *




print '\n*****Start script*****\n'


#Creazione del service integration bus
newsibus=AdminTask.createSIBus('[-bus ' + siBus + \
							   ' -busSecurity false -scriptCompatibility 6.1 ]')
print '\n- New SIBus created'


#creazione bus member
newbusmember=AdminTask.addSIBusMember(\
   								'[-bus ' + siBus + ' \
   								  -node ' + node + \
      							' -server ' + server + \
   	  				   			' -fileStore  \
     							  -logSize 20 \
     							  -minPermanentStoreSize 20 \
     							  -maxPermanentStoreSize 100 \
     							  -unlimitedPermanentStoreSize false \
     							  -minTemporaryStoreSize 20 \
     							  -maxTemporaryStoreSize 100 \
     							  -unlimitedTemporaryStoreSize false ]')
   
print '\n- New SIBus member created'


#creazione queue
sibJMSQueue=AdminTask.createSIBJMSQueue(node + '(cells/' + cell + '/nodes/' + node + '|node.xml)', \
      							'[-name ' + queueName +\
   	  				   			' -jndiName jms/' + queueName +\
      	  				 		' -description  \
 								  -deliveryMode Application \
 								  -readAhead AsConnection \
 								  -busName ' + siBus + ' \
 								  -queueName ' + queueName +\
  								' -scopeToLocalQP false \
 								  -producerBind false \
 								  -producerPreferLocal true \
 								  -gatherMessages false]')
print '\n- Queue created'


#creazione delle bus destinations
d=AdminTask.createSIBDestination(\
   								'[-bus ' + siBus + ' \
   								  -name ' + queueName + \
      							' -type Queue \
   								  -reliability ASSURED_PERSISTENT \
   								  -description  \
   								  -node ' + node +\
      							' -server ' + server +' ]')
print '\n- Bus destination created'


#creazione queue connection factory
connFactName = queueName + 'CF'
endpoint='localhost:' + endpointPort + ':BootstrapBasicMessaging'
# Script di Daniele
sibJMSConnFact=AdminTask.createSIBJMSConnectionFactory(node + '(cells/' + cell + '/nodes/' + node + '|node.xml)', \
      							'[-type queue \
   								  -name ' + connFactName + \
      							' -jndiName jms/' + connFactName + \
   	  				   			' -description  \
   								  -category  \
 								  -busName ' + siBus + ' \
 								  -clientID  \
 								  -nonPersistentMapping ExpressNonPersistent \
 								  -readAhead Default \
 								  -tempQueueNamePrefix  \
								  -tempTopicNamePrefix  \
								  -durableSubscriptionHome ' + node + '.' + server + '-' + siBus + ' \
								  -shareDurableSubscriptions InCluster \
								  -target  \
							   	  -targetType BusMember \
								  -targetSignificance Preferred \
								  -targetTransportChain  \
								  -providerEndPoints ' + endpoint + \
								' -connectionProximity Bus \
								  -containerAuthAlias  \
								  -mappingAlias  \
								  -authDataAlias  \
								  -shareDataSourceWithCMP false \
								  -logMissingTransactionContext false \
								  -manageCachedHandles false \
								  -xaRecoveryAuthAlias  \
								  -persistentMapping ReliablePersistent \
								  -consumerDoesNotModifyPayloadAfterGet false \
								  -producerDoesNotModifyPayloadAfterSet false]')
print '\n- Queue connection factory created'


#creazione message activation specifications
actSpecName = queueName + 'AS'
sibJMSActivSpec=AdminTask.createSIBJMSActivationSpec(node + '(cells/' + cell + '/nodes/' + node + '|node.xml)', \
      							'[-name '+ actSpecName + \
   	  				   			' -jndiName jms/' + actSpecName +  \
      	  				   		' -destinationJndiName jms/'+ queueName + \
   	  	  				     	' -description \
 								  -busName ' + siBus + ' \
 								  -clientId  \
 								  -durableSubscriptionHome ' + node + '.' +server + '-' + siBus + \
   								' -destinationType javax.jms.Queue \
 								  -messageSelector  \
 								  -acknowledgeMode Auto-acknowledge \
 								  -subscriptionName  \
 								  -maxBatchSize 1 \
 								  -maxConcurrency 1 \
 								  -subscriptionDurability NonDurable \
 								  -shareDurableSubscriptions InCluster \
 								  -authenticationAlias  \
 								  -readAhead Default \
 								  -target  \
 								  -targetType BusMember \
 								  -targetSignificance Preferred \
 								  -targetTransportChain  \
 								  -providerEndPoints  \
 								  -shareDataSourceWithCMP false \
 								  -consumerDoesNotModifyPayloadAfterGet false \
 								  -forwarderDoesNotModifyPayloadAfterSet false \
 								  -alwaysActivateAllMDBs false \
 								  -retryInterval 30 \
 								  -autoStopSequentialMessageFailure 0 \
 								  -failingMessageDelay 0]')
print '\n- Queue activation specification created'


# Setup bus security
print '\n' + '- Setup bus security'

	# Generic
AdminTask.modifySecurityDomain('[-securityDomainName "' + securityDomainName + '" -securityDomainDescription ' + securityDomainDescription + ']')  
AdminTask.unsetAppActiveSecuritySettings('[-securityDomainName "' + securityDomainName + '" -unsetAppSecurityEnabled true]')  
AdminTask.unsetAppActiveSecuritySettings('[-securityDomainName "' + securityDomainName + '" -unsetEnforceJava2Security true -unsetIssuePermissionWarning true -unsetEnforceFineGrainedJCASecurity true]')  
AdminTask.unsetAppActiveSecuritySettings('[-securityDomainName "' + securityDomainName + '" -unsetActiveUserRegistry true]')  
AdminTask.unconfigureUserRegistry('[-securityDomainName "' + securityDomainName + '" -userRegistryType LocalOSUserRegistry]')  
AdminTask.unconfigureUserRegistry('[-securityDomainName "' + securityDomainName + '" -userRegistryType LDAPUserRegistry]')  
AdminTask.unconfigureUserRegistry('[-securityDomainName "' + securityDomainName + '" -userRegistryType CustomUserRegistry]')  
AdminTask.unconfigureTrustedRealms('[-securityDomainName "' + securityDomainName + '" -communicationType inbound]')  
AdminTask.unconfigureTrustAssociation('[-securityDomainName "' + securityDomainName + '" ]')  
AdminTask.unconfigureSpnego('[-securityDomainName "' + securityDomainName + '"]')  
AdminTask.unconfigureCSIInbound('[-securityDomainName "' + securityDomainName + '"]')  
AdminTask.unconfigureCSIOutbound('[-securityDomainName "' + securityDomainName + '"]')  
AdminTask.unconfigureJAASLogin('[-securityDomainName "' + securityDomainName + '" -loginType application ]')  
AdminTask.unconfigureJAASLogin('[-securityDomainName "' + securityDomainName + '" -loginType system ]')  
AdminTask.unconfigureAuthzConfig('[-securityDomainName "' + securityDomainName + '" ]')  
AdminTask.setAppActiveSecuritySettings('[-securityDomainName "' + securityDomainName + '" -customProperties ["com.ibm.security.SAF.authorization="]]')  
AdminTask.setLTPATimeout('[-securityDomainName "' + securityDomainName + '" -timeout ]')  
AdminTask.unsetAppActiveSecuritySettings('[-securityDomainName "' + securityDomainName + '" -unsetUseDomainQualifiedUserNames true -unsetCacheTimeout true]')  
AdminTask.setAppActiveSecuritySettings('[-securityDomainName "' + securityDomainName + '" -customProperties ["com.ibm.websphere.security.util.authCacheEnabled=","com.ibm.websphere.security.util.authCacheCustomKeySupport=","com.ibm.websphere.security.util.authCacheSize=","com.ibm.websphere.security.util.authCacheMaxSize="]]')  
AdminTask.setAppActiveSecuritySettings('[-securityDomainName "' + securityDomainName + '" -customProperties ["was.security.EnableSyncToOSThread=","was.security.EnableRunAsIdentity="]]') 
AdminTask.mapResourceToSecurityDomain('[-securityDomainName "' + securityDomainName + '" -resourceName Cell=]') 

AdminTask.getSecurityDomainForResource('[-resourceName SIBus=' + siBus + ' -getEffectiveDomain false]')  
AdminTask.mapResourceToSecurityDomain('[-securityDomainName "' + securityDomainName + '" -resourceName SIBus=' + siBus + ']')  
AdminTask.listAuthDataEntries()  
AdminTask.getSecurityDomainForResource('[-resourceName SIBus=' + siBus + ' -getEffectiveDomain false]')  
AdminTask.listAuthDataEntries('[-securityDomainName "' + securityDomainName + '" ]')

#sibus = [sib for sib in AdminConfig.getid('/SIBus:/').split("\r\n") if AdminConfig.showAttribute(sib, 'name') == siBus]
for sib in AdminConfig.getid('/SIBus:/').split("\r\n"): 
	if AdminConfig.showAttribute(sib, 'name') == siBus:
		sibus = sib
		break
AdminConfig.modify(sibus, '[[secure "false"]]') 


	# User and groups
AdminTask.addUserToBusConnectorRole('[-user ' + user + ' -uniqueName ' + userUID + ' -bus ' + siBus + ']')


	# Default access role
	
	# Remove the default role ALLAUTHENTICATED
try:
	AdminTask.removeGroupFromDefaultRole('[-bus ' + siBus + ' -role Sender -group AllAuthenticated]')  
	AdminTask.removeGroupFromDefaultRole('[-bus ' + siBus + ' -role Receiver -group AllAuthenticated]')  
	AdminTask.removeGroupFromDefaultRole('[-bus ' + siBus + ' -role Browser -group AllAuthenticated]')  
	AdminTask.removeGroupFromDefaultRole('[-bus ' + siBus + ' -role Creator -group AllAuthenticated]')  

except Exception:
	print "Error in ALLAUTHENTICATED roles removing."
	
	
	
	# pampuse roles
AdminTask.addUserToDefaultRole('[-user ' + user + ' -uniqueName ' + userUID + ' -bus ' + siBus + ' -role Sender]')  
AdminTask.addUserToDefaultRole('[-user ' + user + ' -uniqueName ' + userUID + ' -bus ' + siBus + ' -role Receiver]')  
AdminTask.addUserToDefaultRole('[-user ' + user + ' -uniqueName ' + userUID + ' -bus ' + siBus + ' -role Browser]')  
AdminTask.addUserToDefaultRole('[-user ' + user + ' -uniqueName ' + userUID + ' -bus ' + siBus + ' -role Creator]')  


# Setup JMS security
print '\n' + '- Setup JMS security'

	# Queue connection factory
#connectionFactory = [connFact for connFact in AdminConfig.getid('/J2CConnectionFactory:/').split("\r\n") if AdminConfig.showAttribute(connFact, 'name') == connFactName]
for connFact in AdminConfig.getid('/J2CConnectionFactory:/').split("\r\n"): 
	if AdminConfig.showAttribute(connFact, 'name') == connFactName:
		connectionFactory = connFact
		break
AdminTask.modifySIBJMSConnectionFactory(connectionFactory, \
									'[-name ' + connFactName + \
									' -jndiName jms/' + connFactName + \
									' -description \
									  -category \
									  -busName ' + siBus + ' \
									  -nonPersistentMapping ExpressNonPersistent \
									  -readAhead Default \
									  -tempQueueNamePrefix \
									  -target \
									  -targetType BusMember \
									  -targetSignificance Preferred \
									  -targetTransportChain \
									  -providerEndPoints ' + endpoint + ' \
									  -connectionProximity Bus \
									  -authDataAlias \
									  -containerAuthAlias ' + node + '/' + user + ' \
									  -mappingAlias DefaultPrincipalMapping \
									  -shareDataSourceWithCMP false \
									  -logMissingTransactionContext false \
									  -manageCachedHandles false \
									  -xaRecoveryAuthAlias \
									  -persistentMapping ReliablePersistent \
									  -consumerDoesNotModifyPayloadAfterGet false \
									  -producerDoesNotModifyPayloadAfterSet false]') 

	# Activation specification
#activationSpec = [actSpec for actSpec in AdminConfig.getid('/J2CActivationSpec:/').split("\r\n") if AdminConfig.showAttribute(actSpec, 'name') == actSpecName]
for actSpec in AdminConfig.getid('/J2CActivationSpec:/').split("\r\n"): 
	if AdminConfig.showAttribute(actSpec, 'name') == actSpecName:
		activationSpec = actSpec
		break
AdminTask.modifySIBJMSActivationSpec(activationSpec, \
									'[-name ' + actSpecName + ' \
									  -jndiName jms/' + actSpecName + ' \
									  -destinationJndiName jms/' + queueName + ' \
									  -description \
									  -busName ' + siBus + ' \
									  -clientId \
									  -durableSubscriptionHome ' + node + '.' +server + '-' + siBus + ' \
									  -destinationType javax.jms.Queue \
									  -messageSelector \
									  -acknowledgeMode Auto-acknowledge \
									  -subscriptionName \
									  -maxBatchSize 1 \
									  -maxConcurrency 1 \
									  -subscriptionDurability NonDurable \
									  -shareDurableSubscriptions InCluster \
									  -authenticationAlias ' + node + '/' + user + ' \
									  -readAhead Default \
									  -target \
									  -targetType BusMember \
									  -targetSignificance Preferred \
									  -targetTransportChain \
									  -providerEndPoints \
									  -shareDataSourceWithCMP false \
									  -consumerDoesNotModifyPayloadAfterGet false \
									  -forwarderDoesNotModifyPayloadAfterSet false \
									  -alwaysActivateAllMDBs false \
									  -retryInterval 30 \
									  -autoStopSequentialMessageFailure 0 \
									  -failingMessageDelay 0]')




#Salvataggio configurazione
AdminConfig.save()
print '\n\nConfiguration saved.'





print '\nThe new SIBus list is:'
print AdminTask.listSIBuses()

print '\nThe new bus member list is:'
print AdminTask.listSIBusMembers('[-bus MDBSIBus ]')

print '\nThe new bus destination list is:'
print AdminTask.listSIBDestinations('[-bus MDBSIBus ]')

print '\nThe new queue is:'
print sibJMSQueue

print '\nThe new queue factory is:'
print sibJMSConnFact

print '\nThe new queue activation specification is:'
print sibJMSActivSpec


print '\n\n\nNew security configurations:\n'
print '  [-securityDomainName "' + securityDomainName + '" -securityDomainDescription ' + securityDomainDescription + ']\n\n'
print '  [-securityDomainName "' + securityDomainName + '" -resourceName SIBus=' + siBus + ']\n\n'
print '  [-user ' + user + ' -uniqueName ' + userUID + ' -bus ' + siBus + ']\n\n'
print '  ' + sibus + ' [[secure "true"]]'
print '\n  Removed:'
print '    [-bus ' + siBus + ' -role Sender -group AllAuthenticated]' 
print '    [-bus ' + siBus + ' -role Receiver -group AllAuthenticated]' 
print '    [-bus ' + siBus + ' -role Browser -group AllAuthenticated]' 
print '    [-bus ' + siBus + ' -role Creator -group AllAuthenticated]' 
print '\n  Added:'
print '    [-user ' + user + ' -uniqueName ' + userUID + ' -bus ' + siBus + ' -role Sender]' 
print '    [-user ' + user + ' -uniqueName ' + userUID + ' -bus ' + siBus + ' -role Receiver]'
print '    [-user ' + user + ' -uniqueName ' + userUID + ' -bus ' + siBus + ' -role Browser]'
print '    [-user ' + user + ' -uniqueName ' + userUID + ' -bus ' + siBus + ' -role Creator]'






print '\n\n\n*****End script*****\n\n'