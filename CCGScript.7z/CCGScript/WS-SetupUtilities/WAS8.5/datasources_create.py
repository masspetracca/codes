#@PydevCodeAnalysisIgnore


sys.path.append("C:/DeLauri/WorkSpaces/WorkSpaceCCG_RAD/CCGScript/WS-SetupUtilities/WAS8.5/")
from script_setup_parameters import *




print '\n*****Start script*****\n'



#creazione JDBC provider DB2 Toolbox XA
print '\n' + ' - New JDBC provider creating..'

newJdbcProvider=AdminTask.createJDBCProvider(\
					     '[-scope Node=' + node + ',Server=' + server + ' \
					       -databaseType DB2 \
					       -providerType "DB2 UDB for iSeries (Native)" \
					       -implementationType "Origine dati XA" \
					       -name "DB2 UDB for iSeries (Native XA)" \
					       -description "" \
					       -classpath [${OS400_NATIVE_JDBC40_DRIVER_PATH}/db2_classes.jar ] \
					       -nativePath "" ]')

#Creazione alias
print '\n' + ' - New J2C adapters creating..'

j = 0
for autenticationName in autenticationNameList:       # creo tutti gli alias che trovo nella autenticationNameList
	
	autenticationUser = autenticationUserList[j]
	j2cpampuse=AdminTask.createAuthDataEntry('[-alias '+ autenticationName +' -user '+ autenticationUser +' -password '+ autenticationPwd +' -description ]')
	j = j + 1


#creazione datasources
print '\n' + ' - New datasources creating..'

#AdminTask.createDatasource(newJdbcProvider, '[-name ' + dataSourceName + ' -jndiName jdbc/' + dataSourceName + ' -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper -containerManagedPersistence true -componentManagedAuthenticationAlias A65BD99F_PAMP_WEB/pampuse -xaRecoveryAuthAlias -configureResourceProperties [[databaseName java.lang.String E65BD99F]]]') 
i = 0
for dataSourceName in dsList:       # creo tutti i datasource che trovo nella dsList
    # seleziono l'indirizzo server giusto
    server = dsServerList[i]
    aliasName = aliasNameList[i]
    pampds= AdminTask.createDatasource(newJdbcProvider, '[-name ' + dataSourceName + ' -jndiName jdbc/' + dataSourceName + ' -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper -containerManagedPersistence true -componentManagedAuthenticationAlias ' + node + '/' + aliasName + ' -xaRecoveryAuthAlias -configureResourceProperties [[databaseName java.lang.String ' + server + ']]]') 
#    pampds=AdminTask.createDatasource(newJdbcProvider, \
#    				     '[-name ' + dataSourceName + ' \
#    				       -jndiName jdbc/' + dataSourceName + ' \
#    				       -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper \
#    				       -containerManagedPersistence true \
#    				       -componentManagedAuthenticationAlias ' + node + '/' + aliasName + '\
#    				       -xaRecoveryAuthAlias \
#    				       -configureResourceProperties [[serverName java.lang.String ' + server + ']]]')
    
    dataSource = AdminConfig.getid('/DataSource:' + dataSourceName + '/')
    
    AdminConfig.create('MappingModule', ''+dataSource+'', '[[authDataAlias ' + node + '/' + aliasName + '] [mappingConfigAlias ""]]')
    CMPConnFac = AdminConfig.getid('/CMPConnectorFactory:'+dataSourceName+'_CF/')
    AdminConfig.modify(''+CMPConnFac+'', '[[name "' + dataSourceName + '_CF"] [authDataAlias "' + node + '/' + aliasName + '"] [xaRecoveryAuthAlias ""]]') 
    AdminConfig.create('MappingModule', ''+CMPConnFac+'', '[[authDataAlias ' + node + '/' + aliasName + '] [mappingConfigAlias ""]]')  
    i = i + 1

#Salvataggio configurazione
AdminConfig.save()
print '\n\nConfiguration saved.'

# Print results
print '\n\nThe new JDBC provider list is:'
print AdminConfig.list('JDBCProvider', AdminConfig.getid('/Cell:' + cell + '/Node:' + node +'/'))
   
print '\nThe new JAAS account list is:'
print AdminTask.listAuthDataEntries()

print '\nThe new datasource list is:'
print AdminConfig.list('DataSource', AdminConfig.getid('/Cell:' + cell + '/Node:' + node + '/'))



print '\n\n\n*****End script*****\n\n'