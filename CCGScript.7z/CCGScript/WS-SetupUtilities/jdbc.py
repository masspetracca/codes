#@PydevCodeAnalysisIgnore

#Installazione  environment
node='H65BD99F_PAMPSE'
cell='H65BD99F_PAMPSE'
server='PAMPSE'
pampsvr='10.0.40.236'
dwhsvr='10.0.40.236'
cssvr='10.0.40.236'
stsvr='10.0.40.236'


print '*****Start script*****'
#creazione JDBC provider DB2 Toolbox
newJdbcProvider=AdminTask.createJDBCProvider(\
   '[-scope Node=' + node + ' '+ '\
   -databaseType DB2 \
   -providerType "DB2 UDB for iSeries (Toolbox)" \
   -implementationType "Connection pool data source" \
   -name "DB2 UDB for iSeries (Toolbox)" \
   -description "DB2_Toolbox" \
   -classpath [${OS400_TOOLBOX_JDBC_DRIVER_PATH}/jt400.jar ] \
   -nativePath "" ]')
   
print '\n- New JDBC provider created'

#Installazione utenze
j2cpampuse=AdminTask.createAuthDataEntry(\
   '[-alias pampuse \
   -user pampuse \
   -password ndapc1pFC \
   -description \
   "Pamp account" ]')

print '\n- New J2C adapters created'
   
#creazione datasources pampuse 
   
pampds=AdminTask.createDatasource(\
   newJdbcProvider, \
   '[-name pampds -jndiName jdbc/pampds \
   -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper \
   -containerManagedPersistence true \
   -componentManagedAuthenticationAlias ' + node + '/pampuse \
   -configureResourceProperties [[serverName java.lang.String ' + pampsvr + ']]]')

dwhds=AdminTask.createDatasource(\
   newJdbcProvider, \
   '[-name dwhds -jndiName jdbc/dwhds \
   -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper \
   -containerManagedPersistence true \
   -componentManagedAuthenticationAlias ' + node + '/pampuse \
   -configureResourceProperties [[serverName java.lang.String ' + dwhsvr + ']]]')

pampds=AdminTask.createDatasource(\
   newJdbcProvider, \
   '[-name csds -jndiName jdbc/csds \
   -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper \
   -containerManagedPersistence true \
   -componentManagedAuthenticationAlias ' + node + '/pampuse \
   -configureResourceProperties [[serverName java.lang.String ' + cssvr + ']]]')

pampds=AdminTask.createDatasource(\
   newJdbcProvider, \
   '[-name stds -jndiName jdbc/stds \
   -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper \
   -containerManagedPersistence true \
   -componentManagedAuthenticationAlias ' + node + '/pampuse \
   -configureResourceProperties [[serverName java.lang.String ' + stsvr + ']]]')

print '\n- New datasources created'

#Salvataggio configurazione
AdminConfig.save()
print '\n- Configuration saved'

print '\nThe new JDBC provider list is:'
print AdminConfig.list(\
   'JDBCProvider', AdminConfig.getid( \
   '/Cell:'+cell+'/Node:'+node+'/'))
   
print '\nThe new JAAS account list is:'
print AdminTask.listAuthDataEntries()

print '\nThe new datasource list is:'
print AdminConfig.list(\
   'DataSource', AdminConfig.getid( \
   '/Cell:'+cell+'/Node:'+node+'/'))

print '\n*****End script*****'