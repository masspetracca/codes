#@PydevCodeAnalysisIgnore
'''
#Installazione prod environment
node='A65BD99F_PAMP_WEB'
cell='A65BD99F_PAMP_WEB'
server='PAMP_WEB'
pampsvr='10.0.10.240'
dwhsvr='10.0.10.240'
cssvr='10.0.10.240'
stsvr='10.0.10.240'
'''

#Installazione svil environment
node='win7-PCNode01'
cell='win7-PCNode01Cell'
server='server1'
pampsvr='10.0.10.240'
dwhsvr='10.0.10.240'
cssvr='10.0.10.240'
stsvr='10.0.10.240'

print '*****Start script*****'
#creazione JDBC provider DB2 Toolbox
newJdbcProvider=AdminTask.createJDBCProvider(\
   '[-scope Node=' + node + ' '+ '\
    -databaseType DB2 \
    -providerType "DB2 UDB for iSeries (Toolbox)" \
    -implementationType "Origine dati XA" \
    -name "DB2 UDB for iSeries (Toolbox XA)" \
    -description "DB2_Toolbox with XA" \
    -classpath [${OS400_TOOLBOX_JDBC_DRIVER_PATH}/jt400.jar ] \
    -nativePath "" ]') 

print '\n- New JDBC provider created'

#Installazione utenze
j2cpampuse=AdminTask.createAuthDataEntry(\
   '[-alias pampuse \
   -user pampuse \
   -password ndapc1pFC \
   -description \
   "Pamp account" ]')

print '\n- New J2C adapters created'
   
#creazione datasources pampuse 
   
pampds=AdminTask.createDatasource(\
   newJdbcProvider, \
   '[-name pampds -jndiName jdbc/pampds \
   -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper \
   -containerManagedPersistence true \
   -componentManagedAuthenticationAlias ' + node + '/pampuse \
   -configureResourceProperties [[serverName java.lang.String ' + pampsvr + ']]]')

dwhds=AdminTask.createDatasource(\
   newJdbcProvider, \
   '[-name dwhds -jndiName jdbc/dwhds \
   -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper \
   -containerManagedPersistence true \
   -componentManagedAuthenticationAlias ' + node + '/pampuse \
   -configureResourceProperties [[serverName java.lang.String ' + dwhsvr + ']]]')

pampds=AdminTask.createDatasource(\
   newJdbcProvider, \
   '[-name csds -jndiName jdbc/csds \
   -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper \
   -containerManagedPersistence true \
   -componentManagedAuthenticationAlias ' + node + '/pampuse \
   -configureResourceProperties [[serverName java.lang.String ' + cssvr + ']]]')

pampds=AdminTask.createDatasource(\
   newJdbcProvider, \
   '[-name stds -jndiName jdbc/stds \
   -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper \
   -containerManagedPersistence true \
   -componentManagedAuthenticationAlias ' + node + '/pampuse \
   -configureResourceProperties [[serverName java.lang.String ' + stsvr + ']]]')

print '\n- New datasources created'

#Salvataggio configurazione
AdminConfig.save()
print '\n- Configuration saved'

print '\nThe new JDBC provider list is:'
print AdminConfig.list(\
   'JDBCProvider', AdminConfig.getid( \
   '/Cell:'+cell+'/Node:'+node+'/'))
   
print '\nThe new JAAS account list is:'
print AdminTask.listAuthDataEntries()

print '\nThe new datasource list is:'
print AdminConfig.list(\
   'DataSource', AdminConfig.getid( \
   '/Cell:'+cell+'/Node:'+node+'/'))

print '\n*****End script*****\n\n'