#@PydevCodeAnalysisIgnore
# Author: Paolo Cocchi



sys.path.append("C:/workspace/CCGScript/WS-SetupUtilities/")
from script_setup_parameters import *




print '\n*****Start script*****\n'



serverID = AdminConfig.getid('/Server:' + server + '/')		# id del server


# Setup Logging
print '\n' + ' - Setup logging.. \n'

# Nelle successive 2 righe si tenta il settaggio di attributi annidati. 
# I settaggi funzionano, ma come effetto collaterale vengono sballati i colori della console di RAD.
# Per questo motivo si procede con l'accesso diretto a tali attributi.

#AdminConfig.modify(serverID, '[[errorStreamRedirect [[rolloverType "' + rolloverType + '"] [maxNumberOfBackupFiles "' + maxNumberOfBackupFiles + '"] [rolloverSize "' + rolloverSize + '"] [fileName "${SERVER_LOG_ROOT}/SystemErr.log"] [baseHour "24"] [rolloverPeriod "24"] [formatWrites "true"] [messageFormatKind "BASIC"] [suppressWrites "false"] [suppressStackTrace "false"] ]]]')
#AdminConfig.modify(serverID, '[[outputStreamRedirect [[rolloverType "' + rolloverType + '"] [maxNumberOfBackupFiles "' + maxNumberOfBackupFiles + '"] [rolloverSize "' + rolloverSize + '"] [fileName "${SERVER_LOG_ROOT}/SystemErr.log"] [baseHour "24"] [rolloverPeriod "24"] [formatWrites "true"] [messageFormatKind "BASIC"] [suppressWrites "false"] [suppressStackTrace "false"] ]]]')

errorStreamRedirectID = AdminConfig.showAttribute(serverID, 'errorStreamRedirect')
outputStreamRedirectID = AdminConfig.showAttribute(serverID, 'outputStreamRedirect')

AdminConfig.modify(errorStreamRedirectID, '[[rolloverType "' + rolloverType + '"] \
                                            [maxNumberOfBackupFiles ' + maxNumberOfBackupFiles + '] \
                                            [rolloverSize ' + rolloverSize + ']]')
AdminConfig.modify(outputStreamRedirectID, '[[rolloverType "' + rolloverType + '"] \
                                             [maxNumberOfBackupFiles ' + maxNumberOfBackupFiles + '] \
                                             [rolloverSize ' + rolloverSize + ']]')

sysoutLogging = AdminConfig.showall(errorStreamRedirectID) + '\n' + AdminConfig.showall(outputStreamRedirectID)



# Setup transaction time
print '\n' + ' - Setup transaction time.. \n'

# Le successive 6 righe modificano un campo (nel file serverindex.xml) che in server1 (server predefinito esistente dopo 
# l'installazione di WS) già esiste, per questo su server1 viene fatto un modify.
# Nella configurazione di un altro server creato manualmente (ad esempio server2), questo campo NON esiste, ed andrebbe 
# dunque prima creato e poi modificato.
# Poiché in entrambi i casi l'unico parametro del campo viene settato con una stringa vuota, sembra che queta impostazione
# possa essere saltata.

#for servEntry in AdminConfig.getid('/ServerEntry:/').split("\r\n"): 
#	if AdminConfig.showAttribute(servEntry, 'serverName') == server:
#		serverEntry = servEntry
#		break
#recoveryLog = AdminConfig.showAttribute(serverEntry, 'recoveryLog')
#AdminConfig.modify(recoveryLog, '[[transactionLogDirectory ""]]')

#applicationServer = [appServer for appServer in AdminConfig.getid('/ApplicationServer:/').split("\r\n") if AdminConfig.showAttribute(appServer, 'server') == serverID]
#transactionService = [transService for transService in AdminConfig.getid('/TransactionService:/').split("\r\n") if AdminConfig.showAttribute(transService, 'context') == applicationServer]
for appServer in AdminConfig.getid('/ApplicationServer:/').split("\r\n"):
	if AdminConfig.showAttribute(appServer, 'server') == serverID:
		applicationServer = appServer
		break
for transService in AdminConfig.getid('/TransactionService:/').split("\r\n"):
	if AdminConfig.showAttribute(transService, 'context') == applicationServer:
		transactionService = transService
		break
AdminConfig.modify(transactionService, '[[httpProxyPrefix ""] \
                                         [totalTranLifetimeTimeout ' + totalTranLifetimeTimeout + '] \
                                         [LPSHeuristicCompletion "ROLLBACK"] \
                                         [httpsProxyPrefix ""] \
                                         [enableFileLocking "true"] \
                                         [enable "true"] \
                                         [transactionLogDirectory ""] \
                                         [enableProtocolSecurity "true"] \
                                         [propogatedOrBMTTranLifetimeTimeout ' + propogatedOrBMTTranLifetimeTimeout + '] \
                                         [heuristicRetryWait "0"] \
                                         [enableLoggingForHeuristicReporting "false"] \
                                         [asyncResponseTimeout ' + asyncResponseTimeout + '] \
                                         [clientInactivityTimeout ' + clientInactivityTimeout + '] \
                                         [acceptHeuristicHazard "false"] \
                                         [heuristicRetryLimit "0"]]') 

sysoutTransactionTime = AdminConfig.showall(transactionService)



# Setup the thread timeout
print '\n' + ' - Setup thread timeout.. \n'

#threadPoolManager = [thrPoolMan for thrPoolMan in AdminConfig.getid('/ThreadPoolManager:/').split("\r\n") if AdminConfig.showAttribute(thrPoolMan, 'context') == serverID]
#threadPool = [thrPool for thrPool in AdminConfig.list('ThreadPool', threadPoolManager).split("\r\n") if AdminConfig.showAttribute(thrPool, 'name') == "WebContainer"]
for thrPoolMan in AdminConfig.getid('/ThreadPoolManager:/').split("\r\n"): 
	if AdminConfig.showAttribute(thrPoolMan, 'context') == serverID:
		threadPoolManager = thrPoolMan
		break
for thrPool in AdminConfig.list('ThreadPool', threadPoolManager).split("\r\n"): 
	if AdminConfig.showAttribute(thrPool, 'name') == "WebContainer":
		threadPool = thrPool
		break
AdminConfig.modify(threadPool, '[[maximumSize "50"] \
                                 [name "WebContainer"] \
                                 [inactivityTimeout "' + inactivityTimeout + '"] \
                                 [minimumSize "50"] \
                                 [description ""] \
                                 [isGrowable "false"]]') 

sysoutThreadTimeout = AdminConfig.showall(threadPool)



# Setup jt400 directory
print '\n' + ' - Setup jt400 directory.. \n'

#directoryVariable = [variable for variable in AdminConfig.getid('/VariableSubstitutionEntry:/').split("\r\n") if AdminConfig.showAttribute(variable, 'symbolicName') == "OS400_TOOLBOX_JDBC_DRIVER_PATH"]
for variable in AdminConfig.getid('/VariableSubstitutionEntry:/').split("\r\n"): 
	if AdminConfig.showAttribute(variable, 'symbolicName') == "OS400_TOOLBOX_JDBC_DRIVER_PATH":
		directoryVariable = variable
		break
AdminConfig.modify(directoryVariable, '[[symbolicName "OS400_TOOLBOX_JDBC_DRIVER_PATH"] \
                                        [description ""] \
                                        [value "' + directory + '"]]') 

sysoutJt400Directory = AdminConfig.showall(directoryVariable)



# Create security domain
print '\n' + ' - Create security domain.. \n'

AdminTask.createSecurityDomain('[-securityDomainName "' + securityDomainName + \
							  '" -securityDomainDescription PAMP_Security_Realm]') 

sysoutCreateSecurityDomain = '[-securityDomainName "' + securityDomainName + \
                            '" -securityDomainDescription PAMP_Security_Realm]'





#Salvataggio configurazione
AdminConfig.save()
print '\n\nConfiguration saved.'


# Print results
print '\n\n\nNew configurations:'
print '\n\n  Setup logging:\n\n' + sysoutLogging
print '\n\n  Setup transaction time:\n\n' + sysoutTransactionTime
print '\n\n  Setup thread timeout:\n\n' + sysoutThreadTimeout
print '\n\n  Setup jt400 directory:\n\n' + sysoutJt400Directory
print '\n\n  Create security domain:\n\n' + sysoutCreateSecurityDomain






print '\n\n\n*****End script*****\n\n'