#@PydevCodeAnalysisIgnore
# Author: Paolo Cocchi
# DataSources settings; the script modifies data sources setting in: 
#     C:\Program Files (x86)\IBM\SDP\runtimes\base_v7\profiles\AppSrv01\config\cells\win7-PCNode01Cell\nodes\win7-PCNode01\resouces.xml

# Configuration parameters
dsList = ['csds', 'dwhds' ,'pampds', 'stds']       # Insert DataSource to set
dsLibraryList = ['I400DTA', 'I400PWP1', 'PAMPUSE', 'I400DTAST']     # Insert DataSource Library, in the same DataSourceList's order
connectionTimeout = '180'
maxConnections = '10'
unusedTimeout = '1800'
minConnections = '0'
agedTimeout = '0'
reapTime = '180'


print '\n*****Start script*****'


for dataSourceName in dsList:       # imposto tutti i datasource che trovo nella dsList
    
    print '\n ' + dataSourceName + ' settings..'
    
    dataSource = AdminConfig.getid('/DataSource:' + dataSourceName + '/')       # salvo in una variabile l'id del datasource
    propertySet = AdminConfig.showAttribute(dataSource, 'propertySet')      # salvo in una variabile il riferimento all'attributo 'propertySet' del datasource
    
    
    #impostazioni pool connessione
    AdminConfig.modify(dataSource, '[[connectionPool [[connectionTimeout "' + connectionTimeout + '"] \
                                                 [maxConnections "' + maxConnections + '"] \
                                                 [unusedTimeout "' + unusedTimeout + '"] \
                                                 [minConnections "' + minConnections + '"] \
                                                 [purgePolicy "EntirePool"] \
                                                 [agedTimeout "' + agedTimeout + '"] \
                                                 [reapTime "' + reapTime + '"] ]]]')
    
    #impostazione libreria
    library = ''
    
    # seleziono la libreria giusta
    if dataSourceName == 'csds':
        library = dsLibraryList[0]
    if dataSourceName == 'dwhds':
        library = dsLibraryList[1]
    if dataSourceName == 'pampds':
        library = dsLibraryList[2]
    if dataSourceName == 'stds':
        library = dsLibraryList[3]
    
    # seleziono e imposto la propriet� 'libraries' all'interno della lista di propriet� propertySet
    propertyName = 'libraries'
    libraryProperty = [property for property in AdminConfig.list('J2EEResourceProperty', propertySet).split("\r\n") if AdminConfig.showAttribute(property, 'name') == propertyName]
    AdminConfig.modify(libraryProperty[0], \
                           '[[name "libraries"] \
                             [type "java.lang.String"] \
                             [description "Specifies one or more libraries that you want to add to or replace the library list of the server job, and optionally sets the default library (default schema). The server uses specified libraries to resolve unqualified stored procedure names, and stored procedures use them to resolve unqualified names. To specify multiple libraries, use commas or spaces to separate individual entries. You can use *LIBL as a placeholder for the current library list of the server job using the following rules; 1)When the first entry is *LIBL, the specified libraries are added to the current library list of the server job. 2) When you do not use *LIBL, the specified libraries replace the current library list of the server job. Setting of the default schema depends on whether you use \'sql\' or \'system\' for the naming property. For \'sql\' naming the following rules apply... 1) The first entry (unless it is *LIBL) becomes the default schema 2) When the first entry is *LIBL, the second entry becomes the default schema. 3) When you do not set this property or when it contains only *LIBL, the user profile becomes the default schema. For \'system\' naming the following rules apply... 1) The server uses the specified libraries to search for unqualified names. 2) When you do not set this property or when it contains only *LIBL, the server uses the current library list of the server job to search for unqualified names.  "] \
                             [value "' + library + '"] \
                             [required "false"]\
                            ]')

    #Salvataggio configurazione
    AdminConfig.save()
    print ' Settings saved.'
    
    print '\n  - Connection pool settings:'
    print '      connectionTimeout = ' + connectionTimeout
    print '      maxConnections = ' + maxConnections
    print '      unusedTimeout = ' + unusedTimeout
    print '      minConnections = ' + minConnections
    print '      agedTimeout = ' + agedTimeout
    print '      reapTime = ' + reapTime
    
    print '\n  - Library settings:'
    print '      libraries = ' + library
    
    
    print '\n ' + dataSourceName + ' setup.. done.'
    
    print '\n '




#Salvataggio configurazione
AdminConfig.save()

print '\n*****End script*****\n\n'