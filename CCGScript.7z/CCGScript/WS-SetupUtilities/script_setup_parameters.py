#@PydevCodeAnalysisIgnore
# Author: Paolo Cocchi



# genericParameters.py parameters

    # Generic parameters
#applicationServer = "AppSrv01"
cell = "C65BD99F_PAMP_QA"
node = "C65BD99F_PAMP_QA" 
server = "PAMP_QA" 

    # Setup Logging - parameters
rolloverType="BOTH"
maxNumberOfBackupFiles="200"
rolloverSize="10"

    # Setup transaction time - parameters
totalTranLifetimeTimeout = "10000"
propogatedOrBMTTranLifetimeTimeout = "10000"
asyncResponseTimeout = "30"
clientInactivityTimeout = "60"

    # Setup the thread timeout - parameters
inactivityTimeout = "300000"

    # Setup jt400 directory - parameters
directory = "C:\Program Files (x86)\IBM\IBMIMShared\plugins\com.ibm.datatools.db2.iseries_3.1.120.v20121008_1514\driver"

    # Create security domain - parameters
securityDomainName = "PAMP Security Realm"
securityDomainDescription = "PAMP_Security_Realm"



#  datasources_create.py parameters

    #Configuration parameters
dsList = ['csds', 'dwhds' ,'pampds', 'stds']       # Insert DataSource to set
dsServerList = ['10.0.10.240', '10.0.10.240', '10.0.10.240', '10.0.10.240']     # Insert datasource server address, in the same DataSourceList's order
aliasName = 'pampuse'
aliasUser = 'pampuse'
aliasPasswd = 'ndapc1pFC'
aliasDescription = 'Pamp account'



#  datasources_config.py parameters

    # Configuration parameters
dsLibraryList = ['I400DTA', 'I400PWP1', 'PAMPUSE', 'I400DTAST']     # Insert DataSource Library, in the same DataSourceList's order
connectionTimeout = '180'
maxConnections = '10'
unusedTimeout = '1800'
minConnections = '0'
agedTimeout = '0'
reapTime = '180'



#  jms.py parameters

    # Configuration parameters
siBus = 'MDBSIBus'
queueName='MDBStarter'
endpointPort = '7276'       # Questo parametro corrisponde alla porta SIB_ENDPOINT_ADDRESS del server

    # Questi parametri corrispondono rispettivamente a 'name' e 'uid' di uno degli utenti definiti nel file 'users.props'
user = 'pampuse'
userUID = '0'

