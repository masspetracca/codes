#@PydevCodeAnalysisIgnore
# Author: Paolo Cocchi



sys.path.append("C:/workspace/CCGScript/WS-SetupUtilities/")
from script_setup_parameters import *




print '\n*****Start script*****\n'



#creazione JDBC provider DB2 Toolbox XA
print '\n' + ' - New JDBC provider creating..'

newJdbcProvider=AdminTask.createJDBCProvider(\
                                            '[-scope Node=' + node + ' '+ '\
                                              -databaseType DB2 \
                                              -providerType "DB2 UDB for iSeries (Toolbox)" \
                                              -implementationType "Origine dati pool di connessioni" \
                                              -name "DB2 UDB for iSeries (Toolbox)" \
                                              -description "DB2_Toolbox" \
                                              -classpath [${OS400_TOOLBOX_JDBC_DRIVER_PATH}/jt400.jar ] \
                                              -nativePath "" ]') 



#Creazione alias
print '\n' + ' - New J2C adapters creating..'

j2cpampuse=AdminTask.createAuthDataEntry(\
                                        '[-alias ' + aliasName + ' \
                                          -user ' + aliasUser + ' \
                                          -password ' + aliasPasswd + ' \
                                          -description "' + aliasDescription + '" ]')




#creazione datasources
print '\n' + ' - New datasources creating..'

i = 0
for dataSourceName in dsList:       # creo tutti i datasource che trovo nella dsList
    # seleziono l'indirizzo server giusto
    server = dsServerList[i]
   
    pampds=AdminTask.createDatasource(newJdbcProvider, \
                                                '[-name ' + dataSourceName + ' \
                                                  -jndiName jdbc/' + dataSourceName + ' \
                                                  -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper \
                                                  -containerManagedPersistence true \
                                                  -componentManagedAuthenticationAlias ' + node + '/' + aliasName + '\
                                                  -configureResourceProperties [[serverName java.lang.String ' + server + ']]]')
    i = i + 1





#Salvataggio configurazione
AdminConfig.save()
print '\n\nConfiguration saved.'

# Print results
print '\n\nThe new JDBC provider list is:'
print AdminConfig.list('JDBCProvider', AdminConfig.getid('/Cell:' + cell + '/Node:' + node +'/'))
   
print '\nThe new JAAS account list is:'
print AdminTask.listAuthDataEntries()

print '\nThe new datasource list is:'
print AdminConfig.list('DataSource', AdminConfig.getid('/Cell:' + cell + '/Node:' + node + '/'))



print '\n\n\n*****End script*****\n\n'