#@PydevCodeAnalysisIgnore

#Installazione 
node='H65BD99F_PAMPSE'
cell='H65BD99F_PAMPSE'
server='PAMPSE'
endpoint='localhost:10012:BootstrapBasicMessaging'

print '*****Start script*****'

#Creazione del service integration bus
if 1>0:
    newsibus=AdminTask.createSIBus(\
       '[-bus MDBSIBus \
       -busSecurity false \
       -scriptCompatibility 6.1 ]')
    print '\n- New SIBus created'

#creazione bus member
    newbusmember=AdminTask.addSIBusMember(\
       '[-bus MDBSIBus \
       -node ' + node + \
       ' -server ' + server + \
       ' -fileStore  \
       -logSize 20 \
       -minPermanentStoreSize 20 \
       -maxPermanentStoreSize 100 \
       -unlimitedPermanentStoreSize false \
       -minTemporaryStoreSize 20 \
       -maxTemporaryStoreSize 100 \
       -unlimitedTemporaryStoreSize false ]')
    print '\n- New SIBus member created'
#creazione della coda
queueName='MDBStarter'

#AdminTask.createSIBDestination(\
 #  '[-bus MDBSIBus -name MDBSample -type Queue -reliability ASSURED_PERSISTENT -description  -node ccgimac99Node02 -server server1 ]')

#creazione delle bus destinations
d=AdminTask.createSIBDestination(\
   '[-bus MDBSIBus \
   -name ' +queueName +\
   ' -type Queue \
   -reliability ASSURED_PERSISTENT \
   -description  \
   -node ' + node +\
   ' -server ' + server +' ]')
print '\n- Bus destination created'

#creazione queue factory
f=AdminTask.createSIBJMSConnectionFactory(\
   'amiloNode02(cells/'+cell+'/nodes/'+node+'|node.xml)', \
   '[-type queue \
   -name ' + queueName +'CF' +\
   ' -jndiName jms/'+ queueName + 'CF'\
   ' -description  \
   -category  \
   -busName MDBSIBus \
   -clientID  \
   -nonPersistentMapping ExpressNonPersistent \
   -readAhead Default \
   -tempQueueNamePrefix  \
   -tempTopicNamePrefix  \
   -durableSubscriptionHome '+node+'.'+server+'-MDBSIBus \
   -shareDurableSubscriptions InCluster \
   -target  \
   -targetType BusMember \
   -targetSignificance Preferred \
   -targetTransportChain  \
   -providerEndPoints '+ endpoint + \
   ' -connectionProximity Bus \
   -containerAuthAlias  \
   -mappingAlias  \
   -authDataAlias  \
   -shareDataSourceWithCMP false \
   -logMissingTransactionContext false \
   -manageCachedHandles false \
   -xaRecoveryAuthAlias  \
   -persistentMapping ReliablePersistent \
   -consumerDoesNotModifyPayloadAfterGet false \
   -producerDoesNotModifyPayloadAfterSet false]')
print '\n- Queue connection factory created'

#creazione queue
q=AdminTask.createSIBJMSQueue(\
   'amiloNode02(cells/'+cell+'/nodes/'+node+'|node.xml)', \
   '[-name ' + queueName +\
   ' -jndiName jms/' + queueName +\
   ' -description  \
   -deliveryMode Application \
   -readAhead AsConnection \
   -busName MDBSIBus \
   -queueName ' + queueName +\
   ' -scopeToLocalQP false \
   -producerBind false \
   -producerPreferLocal true \
   -gatherMessages false]')
print '\n- Queue created'

#creazione message activation specifications
a=AdminTask.createSIBJMSActivationSpec(\
   'amiloNode02(cells/'+cell+'/nodes/'+node+'|node.xml)', \
   '[-name '+queueName + 'AS' + \
   ' -jndiName jms/' + queueName + 'AS' \
   ' -destinationJndiName jms/'+ queueName +\
   ' -description \
   -busName MDBSIBus \
   -clientId  \
   -durableSubscriptionHome ' + node + '.' +server + '-MDBSIBus' + \
   ' -destinationType javax.jms.Queue \
   -messageSelector  \
   -acknowledgeMode Auto-acknowledge \
   -subscriptionName  \
   -maxBatchSize 1 \
   -maxConcurrency 1 \
   -subscriptionDurability NonDurable \
   -shareDurableSubscriptions InCluster \
   -authenticationAlias  \
   -readAhead Default \
   -target  \
   -targetType BusMember \
   -targetSignificance Preferred \
   -targetTransportChain  \
   -providerEndPoints  \
   -shareDataSourceWithCMP false \
   -consumerDoesNotModifyPayloadAfterGet false \
   -forwarderDoesNotModifyPayloadAfterSet false \
   -alwaysActivateAllMDBs false \
   -retryInterval 30 \
   -autoStopSequentialMessageFailure 0 \
   -failingMessageDelay 0]')
print '\n- Queue activation specification created'

#Salvataggio configurazione
AdminConfig.save()
print '\n- Configuration saved'

print '\nThe new SIBus list is:'
print AdminTask.listSIBuses()

print '\nThe new bus member list is:'
print AdminTask.listSIBusMembers('[-bus MDBSIBus ]')

print '\nThe new bus destination list is:'
print AdminTask.listSIBDestinations('[-bus MDBSIBus ]')

print '\nThe new queue is:'
print q

print '\nThe new queue factory is:'
print f

print '\nThe new queue activation specification is:'
print a

print '\n*****End script*****'
