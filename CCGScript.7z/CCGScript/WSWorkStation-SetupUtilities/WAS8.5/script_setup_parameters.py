#@PydevCodeAnalysisIgnore
# Author: Paolo Cocchi



# genericParameters.py parameters

    # Generic parameters
#applicationServer = "AppSrv01"
cell = "dp-ccg-ws04Node01Cell"
node = "dp-ccg-ws04Node01" 
server = "server1" 

    # Setup Logging - parameters
rolloverType="BOTH"
maxNumberOfBackupFiles="200"
rolloverSize="10"

    # Setup transaction time - parameters
totalTranLifetimeTimeout = "10000"
propogatedOrBMTTranLifetimeTimeout = "10000"
asyncResponseTimeout = "30"
clientInactivityTimeout = "60"

    # Setup the thread timeout - parameters
inactivityTimeout = "300000"

    # Setup jt400 directory - parameters
directory = "C:\Program Files (x86)\IBM\SDPShared\plugins\com.ibm.datatools.db2.iseries_3.1.120.v20131108_1418\driver"

    # Create security domain - parameters
securityDomainName = "PAMP Security Realm"
securityDomainDescription = "PAMP_Security_Realm"



#  datasources_create.py parameters

autenticationNameList = ['pampuse','intrat','infop','terrctrl2','pampuse2']
autenticationUserList = ['pampuse','intrat','infop','terrctrl2','pampuse2']
autenticationPwd = 'ndapc1pfc'

#Configuration parameters
dsList = ['csds', 'dwhds' ,'pampds', 'stds','infods','intratds','terrctrl']       # Insert DataSource to set
dsServerList = ['10.0.40.10', '10.0.10.230', '10.0.10.230', '10.0.40.10','10.0.10.230','10.0.10.230','10.0.10.230']     # Insert datasource server address, in the same DataSourceList's order
aliasNameList = ['pampuse','pampuse','pampuse2','pampuse','infop','intrat','terrctrl2']
#aliasUser = 'pampuse'
#aliasPasswd = 'ndapc1pFC'
#aliasDescription = 'Pamp account'



#  datasources_config.py parameters

    # Configuration parameters
dsLibraryList = ['I400DTA', 'I400PWP1', 'PAMPUSE2', 'I400DTAST','INFOP2','INTRAT2','TERRCTRL2']     # Insert DataSource Library, in the same DataSourceList's order
connectionTimeout = '180'
maxConnections = '10'
unusedTimeout = '1800'
minConnections = '0'
agedTimeout = '0'
reapTime = '180'



#  jms.py parameters

    # Configuration parameters
siBus = 'MDBSIBus'
queueName='MDBStarter'
endpointPort = '7276'       # Questo parametro corrisponde alla porta SIB_ENDPOINT_ADDRESS del server

    # Questi parametri corrispondono rispettivamente a 'name' e 'uid' di uno degli utenti definiti nel file 'users.props'
user = 'pampuse'
userUID = '0'

