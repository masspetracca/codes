'''
Created on 17/feb/2011

@author: buffoni

Questo script cancella tutte le foreign key dello schema pampuse


'''



import pyodbc 
schema='PAMPUSE'
print '--- Sript started'

#odbc_sources=['DSN=ROMA-SVIL;PWD=ndapc1pFC','DSN=ROMA-PROD;PWD=ndapc1pFC']
#odbc_sources=['DSN=ROMA-SVIL;PWD=ndapc1pFC']
#odbc_sources=['DSN=ROMA-PROD;PWD=ndapc1pFC']
#schemas=['PAMPUSE','PAMPPROD']

odbc_sources=['DSN=NCPAMP-TO;PWD=ndapc1pFC']
schemas=['NCPAMPTO']

for odbc in odbc_sources:
    for schema in schemas:
        print '\nConnecting to %s' % odbc
        conn = pyodbc.connect(odbc,autocommit=True)
        print 'Connected to %s\n' % odbc
        curs = conn.cursor()        
        query="SELECT TABLE_NAME , CONSTRAINT_NAME FROM QSYS2.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA ='%s'  AND CONSTRAINT_TYPE='FOREIGN KEY'" % schema
        curs.execute(query)
        constraints=curs.fetchall()
        for c in constraints:
            query="ALTER TABLE %s.%s DROP FOREIGN KEY %s.%s" %(schema,c[0],schema,c[1])
            print "Dropping foreign key %s" % c[1]
            curs.execute(query)
        
        
print '\n--- Sript correctly executed'




 


