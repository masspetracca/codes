'''
Created on 17/feb/2011

@author: buffoni

Questo script effettua un reset delle colonne identity, aggiornare la lista delle table column
 
'''

import pyodbc 
print '--- Sript started'

table_column=[('PMPTANREG','ANCODE'),('PMPTAPPRH','APPROVEID'),('PMPTBT','BTID'),('PMPTBTM','BTID'),('PMPTCLASS','CLASSID'),('PMPTCORPAC','CAID'),('PMPTGROUP','GRID'),('PMPTHCLASS','INC'),('PMPTINSTR','INSTRID'),('PMPTLOGACT','ACTID'),('PMPTLOGOKB','LOGID'),('PMPTRC','RCCODE'),('PMPTRST','RSTID'),('PMPTRSTSTP','RSTPARID'),('PMPTSCHED','PRCID'),('PMPTSETS','SETID'),('PMPTSST','SSTID'),('PMPTST','STID'),('PMPXCONF','UPDID'),('PMPXCONFDF','UPDID'),('PMPXCORPAC','UPDID'),('PMPXDELTA','UPDID'),('PMPXDELTDF','UPDID'),('PMPXGROUP','UPDID'),('PMPXHISDE','UPDID'),('PMPXHISPR','UPDID'),('PMPXINSTR','UPDID'),('PMPXMAR','UPDID'),('PMPXMINMAR','UPDID'),('PMPXPER','UPDID'),('PMPXPERDF','UPDID'),('PMPXSCHED','UPDID'),('PMPXSETPAR','UPDID'),('PMPXSETS','UPDID'),('PMPXSETUP','UPDID'),('PMPXSPREAD','UPDID'),('PMPXSTRA','UPDID')]


#odbc_sources=['DSN=ROMEPAMP-PROD;PWD=ndapc1pFC','DSN=ROMEPAMP-SVIL;PWD=ndapc1pFC']
#odbc_sources=['DSN=NCPAMP-TO;PWD=ndapc1pFC','DSN=NCPAMP-TT;PWD=ndapc1pFC','DSN=NCPAMP-PT;PWD=ndapc1pFC','DSN=NCPAMP-PROD;PWD=ndapc1pFC','DSN=NCPAMP-DR;PWD=ndapc1pFC']
#odbc_sources=['DSN=NCPAMP-PROD;PWD=ndapc1pFC']
odbc_sources=['DSN=NCPAMP-TT;PWD=ndapc1pFC']


for odbc in odbc_sources:
    print '\nConnecting to %s' % odbc
    conn = pyodbc.connect(odbc,autocommit=True)
    print 'Connected to %s\n' % odbc
    curs = conn.cursor() 
    for c in table_column:
        query='select max('+c[1]+') from '+c[0]
        print '\nExecuting query: '+query
        curs.execute(query)
        record=curs.fetchall()[0][0]
        max_instrid=1
        if record is not None:
            max_instrid=record+1
        query='ALTER TABLE '+c[0]+' ALTER COLUMN '+c[1]+' RESTART WITH '+str(max_instrid)
        print 'Executing query: '+query
        curs.execute(query)
        print 'Table '+c[0]+': counter of column '+c[1]+' restarted from '+str(max_instrid)

print '\n--- Script correctly executed'

 


