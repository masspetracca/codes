'''
Created on 27/apr/2012

@author: lamanna
'''
from json import JSONEncoder

import pyodbc


print '--- Script started'

#odbc_sources=['DSN=ROMA-SVIL;PWD=ndapc1pFC','DSN=ROMA-PROD;PWD=ndapc1pFC']
odbc_sources = ['DSN=ROMA-SVIL;PWD=ndapc1pFC']
#odbc_sources=['DSN=ROMA-PROD;PWD=ndapc1pFC']

schemas = ['PAMPUSE']
instrid=13579

#ciclo sulle risorse odbc 
for odbc in odbc_sources:
    #sugli schemi 
    for schema in schemas:
            
            arrtot=[]
            
            #connessione alla risorsa odbc
            print '\nConnecting to %s' % odbc
            conn = pyodbc.connect(odbc, autocommit=True)
            print 'Connected to %s\n' % odbc
            curs = conn.cursor() 
            
            queryHistPrice = "select pricedate,closepr from %s.PMPTHISPR  where instrid=%d order by pricedate asc" % (schema,instrid)
            
            print queryHistPrice
            
            curs.execute(queryHistPrice)
            datalist = curs.fetchall()

            #per ogni riga della tabella
            for row in datalist:
                dateString="%s" %row[0]
                dateString="%s/%s/%s"%(dateString[8:10],dateString[5:7],dateString[0:4])
                pricef=float("%s"%row[1])
                arrmini=[dateString,pricef]
                arrtot.append(arrmini)
            
            jsonstring=JSONEncoder().encode(arrtot)
            
            f = open("histpr_%d.js"% instrid, 'wb')
            f.write(jsonstring)
            f.close()

            
            