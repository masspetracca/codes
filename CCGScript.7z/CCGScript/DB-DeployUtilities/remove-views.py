'''
Created on 17/feb/2011

@author: buffoni

Questo script cancella tutti i trigger dello schema pampuse


'''



import pyodbc 


print '--- Sript started'

#odbc_sources=['DSN=ROMA-SVIL;PWD=ndapc1pFC','DSN=ROMA-PROD;PWD=ndapc1pFC']
#odbc_sources=['DSN=ROMA-SVIL;PWD=ndapc1pFC']
#odbc_sources=['DSN=ROMA-PROD;PWD=ndapc1pFC']
odbc_sources=['DSN=NCPAMP-TO;PWD=ndapc1pFC']


#schemas=['PAMPUSE','PAMPPROD']
schemas=['NCPAMPTO']

for odbc in odbc_sources:
    for schema in schemas:
        print '\nConnecting to %s' % odbc
        conn = pyodbc.connect(odbc,autocommit=True)
        print 'Connected to %s\n' % odbc
        curs = conn.cursor()     
    
        querySELECT="SELECT TABLE_NAME FROM QSYS2.sysviews where table_schema='%s'" % schema
        for i in range(1,100):
            curs.execute(querySELECT)
            views=curs.fetchall()
            if len(views)==0: break 
            queryDROP="DROP VIEW %s.%s" %(schema,views[0][0])
            print "Dropping view %s.%s" %(schema,views[0][0])
            curs.execute(queryDROP)
     
        querySELECT="SELECT TABLE_NAME FROM QSYS2.tables where table_schema='%s' and TABLE_TYPE='MATERIALIZED QUERY TABLE'" % schema
        for i in range(1,100):
            curs.execute(querySELECT)
            tables=curs.fetchall()
            if len(tables)==0: break 
            queryDROP="DROP TABLE %s.%s" %(schema,tables[0][0])
            print "Dropping materialized table %s.%s" %(schema,tables[0][0])
            curs.execute(queryDROP)
        
        
print '\n--- Sript correctly executed'




 


