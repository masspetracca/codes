'''
Created on 27/apr/2012

@author: lamanna
'''


from json import JSONEncoder

import pyodbc
import re

print '--- Script started'

#odbc_sources=['DSN=ROMA-SVIL;PWD=ndapc1pFC','DSN=ROMA-PROD;PWD=ndapc1pFC']
odbc_sources = ['DSN=ROMA-SVIL;PWD=ndapc1pFC']
#odbc_sources=['DSN=ROMA-PROD;PWD=ndapc1pFC']

schemas = ['PAMPUSE']
tables = ['PMPTMARHIS', "PMPTRC"]



#ciclo sulle risorse odbc 
for odbc in odbc_sources:
    #sugli schemi 
    for schema in schemas:
        #e sulle tabelle in input
        for table in tables:
            responseDict={"status": 0,"startRow": 0, "endRow": 6, "totalRows": 7}
            totalDict={"response":responseDict}
            arrayRighe=[]
            #connessione alla risorsa odbc
            print '\nConnecting to %s' % odbc
            conn = pyodbc.connect(odbc, autocommit=True)
            print 'Connected to %s\n' % odbc
            curs = conn.cursor()        
            #preparo la query per ottenere il nome dei campi della tabella in analisi
            queryField = "SELECT COLUMN_NAME, DATA_TYPE, CHAR_MAX_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE, IS_NULLABLE FROM QSYS2.COLUMNS_S where TABLE_SCHEMA='%s' and TABLE_NAME='%s'" % (schema, table)
            #eseguo la query
            curs.execute(queryField)
            #salvo in field list la lista di campi
            fieldlist = curs.fetchall()
         
            
            #ciclo sulla lista di campi per ottenere una stringa di campi elencante tutti i campi da inserire nella select
            fields = ""
            for field in fieldlist:
                fields += field[0] + ","
                        
            #preparo la query che recupera le prime 1000 righe dalla tabella in analisi 
            queryData = "SELECT %s FROM %s.%s fetch first 100 rows only" % (fields[:-1], schema, table)
            
            print queryData
            
            curs.execute(queryData)
            datalist = curs.fetchall()

            #per ogni riga della tabella
            for row in datalist:
                riga = {}
                #ciclo sui campi
                for i in range(len(fieldlist)):
                    
                    if ("%s"% row[i]!="None"):
                        
                        if("TIME" in fieldlist[i][1]):
                            date="%s" %row[i]
                            #e per ognuno creo un elemento con il nome del campo preso dalla lista apposita ed il relativo valore preso dalla riga
                            riga[fieldlist[i][0]]='###new Date(%s,%s,%s)###' % (date[0:4],date[5:7],date[8:10])
                        elif("INTEGER" in fieldlist[i][1]):
                            riga[fieldlist[i][0]]=row[i]
                        elif("DECIMAL" in fieldlist[i][1]):
                            riga[fieldlist[i][0]]=float("%s"%row[i])    
                        else:
                            riga[fieldlist[i][0]]="%s"%row[i] 
                arrayRighe.append(riga)
                
            responseDict["data"]=arrayRighe        
            jsonstring=JSONEncoder().encode(totalDict)
            
            p = re.compile('(###\"|\"###)')

            jsonstring=p.sub("", jsonstring)
            f = open("%s.%s_fetch.js"% (schema,table), 'wb')
            f.write(jsonstring)
            f.close()

            
          
                    
                #aggiungo object alla lista    
                #listElement.appendChild(obElement)

print '--- Script completed'         

