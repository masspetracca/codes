'''
Created on 25/apr/2012

@author: lamanna

Script per recuperare i campi di una tabella
'''


import pyodbc 
from xml.dom.minidom import Document


print '--- Script started'

#odbc_sources=['DSN=ROMA-SVIL;PWD=ndapc1pFC','DSN=ROMA-PROD;PWD=ndapc1pFC']
odbc_sources = ['DSN=ROMA-SVIL;PWD=ndapc1pFC']
#odbc_sources=['DSN=ROMA-PROD;PWD=ndapc1pFC']

schemas = ['PAMPUSE']
tables = ['PMPTINSTR']





'''
for odbc in odbc_sources:
    for schema in schemas:
        for table in tables:
            print '\nConnecting to %s' % odbc
            conn = pyodbc.connect(odbc, autocommit=True)
            print 'Connected to %s\n' % odbc
            curs = conn.cursor()        
            query = "SELECT COLUMN_NAME, DATA_TYPE, CHAR_MAX_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE, IS_NULLABLE FROM QSYS2.COLUMNS_S where TABLE_SCHEMA='%s' and TABLE_NAME='%s'" % (schema, table)
            curs.execute(query)
            constraints = curs.fetchall()
            for field in constraints:
                fieldxml = docData.createElement("field")
                fieldxml.setAttribute("name", field[0])
                fields.appendChild(fieldxml)
'''            

#ciclo sulle risorse odbc 
for odbc in odbc_sources:
    #sugli schemi 
    for schema in schemas:
        #e sulle tabelle in input
        for table in tables:
            
            # Create the minidom document
            docData = Document()
            # Creo elemento list che contiene tutti gli oggetti
            listElement = docData.createElement("List")
            docData.appendChild(listElement)

            # inizializzo xml per DS
            docDS = Document()

            # Creo elemento list che contiene tutti gli oggetti
            dSElement = docData.createElement("DataSource")
            dSElement.setAttribute("ID", "%s.%s"%(schema,table))
            dSElement.setAttribute("serverType", "sql")
            dSElement.setAttribute("tableName", "%s.%s"%(schema,table))

            docDS.appendChild(dSElement)

            fieldsElement = docData.createElement("fields")
            dSElement.appendChild(fieldsElement)
            
            
            #connessione alla risorsa odbc
            print '\nConnecting to %s' % odbc
            conn = pyodbc.connect(odbc, autocommit=True)
            print 'Connected to %s\n' % odbc
            curs = conn.cursor()        
            #preparo la query per ottenere il nome dei campi della tabella in analisi
            queryField = "SELECT COLUMN_NAME, DATA_TYPE, CHAR_MAX_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE, IS_NULLABLE FROM QSYS2.COLUMNS_S where TABLE_SCHEMA='%s' and TABLE_NAME='%s'" % (schema, table)
            #eseguo la query
            curs.execute(queryField)
            #salvo in field list la lista di campi
            fieldlist = curs.fetchall()
            
            for field in fieldlist:
                fieldElement = docData.createElement("field")
                fieldElement.setAttribute("name", field[0])
                
                if("CHARACTER" in field[1]):
                    fieldElement.setAttribute("type", "text")    
                elif("INTEGER" in field[1]):   
                    fieldElement.setAttribute("type", "integer")
                elif("TIME" in field[1]):   
                    fieldElement.setAttribute("type", "date")
                elif("DECIMAL" in field[1]):
                    fieldElement.setAttribute("type", "float")   
                else:
                    fieldElement.setAttribute("type", field[1])
                    
                fieldsElement.appendChild(fieldElement)
                
            
            
            
            
            
            
            #ciclo sulla lista di campi per ottenere una stringa di campi elencante tutti i campi da inserire nella select
            fields = ""
            for field in fieldlist:
                fields += field[0] + ","
                        
            #preparo la query che recupera le prime 1000 righe dalla tabella in analisi 
            queryData = "SELECT %s FROM %s.%s fetch first 1000 rows only" % (fields[:-1], schema, table)
            
            print queryData
            
            curs.execute(queryData)
            datalist = curs.fetchall()

            #per ogni riga della tabella
            for row in datalist:
                #creo un oggetto object che conterra i vari campi della tabella con il relativo contenuto
                obElement = docData.createElement("Object")
                #ciclo sui campi
                for i in range(len(fieldlist)):
                    #e per ognuno creo un elemento con il nome del campo preso dalla lista apposita ed il relativo valore preso dalla riga
                    fieldElement = docData.createElement(fieldlist[i][0])
                    fieldtext = docData.createTextNode("%s" % row[i])
                    fieldElement.appendChild(fieldtext)
                    #aggiugno quindi l'elemento all'object
                    obElement.appendChild(fieldElement)
                    
                #aggiungo object alla lista    
                listElement.appendChild(obElement)

            #scrivo su un file il contenuto della tabella                             
            f = open("%s.%s.data.xml"% (schema,table), 'wb')
            docData.writexml(f, encoding='utf-8', indent='    ', newl='\n')
            f.close()

# Print our newly created XML
print docDS.toprettyxml(indent="  ")     
        
''' 
       for c in constraints:
            query="ALTER TABLE %s.%s DROP FOREIGN KEY %s.%s" %(schema,c[0],schema,c[1])
            print "Dropping foreign key %s" % c[1]
            curs.execute(query)
            
            
        SELECT TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME, ORDINAL_POSITION, COLUMN_DEFAULT, IS_NULLABLE, DATA_TYPE, CHAR_MAX_LENGTH, CHAR_OCTET_LENGTH, NUMERIC_PRECISION, NUMERIC_PREC_RADIX, NUMERIC_SCALE, DATETIME_PRECISION, INTERVAL_TYPE, INTERVAL_PRECISION, CHAR_SET_CATALOG, CHAR_SET_SCHEMA, CHARACTER_SET_NAME, COLLATION_CATALOG, COLLATION_SCHEMA, COLLATION_NAME, DOMAIN_CATALOG, DOMAIN_SCHEMA, DOMAIN_NAME, UDT_CATALOG, UDT_SCHEMA, UDT_NAME, SCOPE_CATALOG, SCOPE_SCHEMA, SCOPE_NAME, MAX_CARDINALITY, DTD_IDENTIFIER, IS_SEF_REF 
    FROM QSYS2.COLUMNS_S where TABLE_SCHEMA='PAMPUSE' and TABLE_NAME='PMPTINSTR'
'''
        
print '\n--- Script correctly executed'
