/*
 * Main function
 */
function SetNameElement()
{
    Repository.EnsureOutputVisible("Script");
    Session.Output( "=========================================" );
    Session.Output( "JScript: Set Name Element" );
    Session.Output( "=========================================" );
	
	var treeSelectedElements  = Repository.GetTreeSelectedElements();
	var element as EA.Element;
	var name = "test ";

	for (var a = 0; a < treeSelectedElements.Count ;a++){
		element = treeSelectedElements.GetAt(a);
		Session.Output("Element Type: "+element.Type);
		switch (element.Type)
		{
			case "UseCase":
			{
				var constrColl as EA.Collection;
				Session.Output("Element Name: "+element.Name);
				if (element.Type == "UseCase"){
					var appo = element.Name;
					element.Name = name+appo;
					element.Update();
				}
				break;
			}
			case "Requirement":
			{
				treeSelectedElements.
				Session.Output("Element Name: "+element.Name);
				if (element.Type == "Requirement"){
					var appo = element.Name;
					element.Name = name+appo;
					element.Update();
				}
				break;
			}
			default:
			{
				// Error message
				Session.Prompt("This script does not support items of this type "+element.Type, 0 );
			}	
		}
	}	
}
SetNameElement();