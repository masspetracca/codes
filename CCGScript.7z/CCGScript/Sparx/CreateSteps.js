var input;
/*
 * Main function
 */
function CreateSteps()
{
    Repository.EnsureOutputVisible("Script");
    Session.Output( "=========================================" );
    Session.Output( "JScript: Create Steps" );
    Session.Output( "=========================================" );
	
	var treeSelectedType = Repository.GetTreeSelectedItemType();
	var scene as EA.Scenario;
	var sceneAlt as EA.Scenario;
	var scenary as EA.Collection;
	var steps as EA.Collection;
	var alternativePosition = -1;
	var input = new Array("1.	RM requests the \"Master Data Management\" feature related to the desired asset class.",
						  "2.	The system allows access to a list of the financial instruments belonging to the desired asset class by displaying a predefined subset of details. In particular, it will display: -	internal identifier of the financial instrument -	instrument status (enabled, disabled, delisted, underlying) -	master data details");
			
	
	switch (treeSelectedType)
    {
		case 4:
        {
			var element as EA.Element;
            element = Repository.GetTreeSelectedObject();
			Session.Output("Element Name: "+element.Name);
			if (element.Type == "UseCase"){
				scenary = element.Scenarios;
				element.c
				Session.Output("Numbers of scenarios: "+ scenary.Count );
				if (scenary.Count > 0){
					Session.Output("Cleaning usecase");
					for(var s= 0;s<scenary.Count;s++){
						scene = scenary.GetAt(s);
						steps = scene.Steps;
						var step as EA.ScenarioStep;
						Session.Output(steps.Count);
						for (var f = 0;f<steps.Count;f++){
							step = steps.GetAt(f);
							var ext as EA.Collection;
							ext = step.Extensions;
							for (var t = 0;t<ext.Count;t++){
								ext.DeleteAt(t,true);
								ext.Refresh();
							}
							step.Update();
							steps.Refresh();
						}
						scenary.DeleteAt(s,true);
						scenary.Refresh();
					}
					Session.Output("Cleaning completed");
				}
				
				scene = scenary.AddNew(element.Name,"Basic Path");
				basicPathId = scene.Name;
				Session.Output("Begin to iterate on input and creating steps");
				steps = scene.Steps;
				
				//creating step
				for (var stepT=0;stepT<input.length;stepT++){
					Session.Output(input[stepT]);
					var appo = input[stepT];
					var subject = "User";
					
					Session.Output("System found at: "+appo.indexOf("System"));
					if (appo.indexOf("System") >-1 ){
						subject = "System";
					}
					Session.Output(subject);
					if(appo.charAt(0)==" "){
						appo=appo.replace(" ", "");
					}
					
					var dot = appo.indexOf(".")+1;
					//check if alternative flow
					if (appo.substring(dot,appo.length).toLowerCase().indexOf("alternative flow:") > -1){
						Session.Output("Jump");
						alternativePosition = stepT+1;
						
				    //if alternative position not found then create normal step
					}else if(alternativePosition == -1){
						Session.Output("no Alternative");
						var step as EA.ScenarioStep;
						step = steps.AddNew((appo.substring(dot,appo.length)).replace(/-/g,"\n-"),"Basic Path");
						if (subject == "User"){
							step.StepType = 1; //step.StepType.stActor;
						}else{
							step.StepType = 0; //step.StepType.stSystem;
						}
						step.Pos = stepT+1;
						
						step.Update();
						steps.Refresh();	
					}
					
				}
				//refresch and update
				scene.Update();
				scenary.Refresh();

				
				/*for(var stepT=0;stepT<input.length;stepT++){
					if(input[stepT].toLowerCase().indexOf("alternative flow:")>-1{
						Session.Output("for alternative_ "stepT);
						alternativePosition = stepT;
					}
				}*/
				
				if(alternativePosition>-1){
					Session.Output("alternativePosition "+alternativePosition);
					var extensions as EA.Collection;
					var extension as EA.ScenarioExtension;
					var stepsAl as EA.Collection;
					var stepAl as EA.ScenarioStep;
					for (var stepT=(alternativePosition);stepT<input.length;stepT++){
						var appo = input[stepT];
						var subject = "User";
						if (appo.indexOf("System") >-1 ){
							subject = "System";
						}
						Session.Output(subject);
						if(appo.charAt(0)==" "){
							Session.Output("char "+appo.charAt(0));
							appo=appo.replace(" ", "");
						}
						
						var dot = appo.indexOf(".");
						var stringhe = appo.split(" -> Step ");
						var st as EA.ScenarioStep;
						st = steps.GetAt((parseInt(stringhe[0].substring(0,dot-1))-1));
						extensions = st.Extensions;
						extension = extensions.AddNew("Step "+stringhe[0].substring(0,dot-1)+" Alternative flow","Alternate");
						sceneAlt = extension.Scenario;
						stepsAl = sceneAlt.Steps;
						stepAl = stepsAl.AddNew((stringhe[0].substring(dot+1,stringhe[0].length)).replace(/-/g,"-"),"Alternate");
						if (subject == "User"){
							stepAl.StepType = 1; // step.StepType.stActor;
						}else{
							stepAl.StepType = 0; //step.StepType.stSystem;
						}
						stepAl.Update();
						stepsAl.Refresh();
						sceneAlt.Update();
						if (stringhe.length>1){
							steps = scene.Steps;
							step = steps.GetAt(parseInt(stringhe[1].substring(0,dot-1))-1);
							extension.Join = step.StepGUID;
						}
						extension.Update();
						extensions.Refresh();
						stepAl.Update();
						stepsAl.Refresh();	
						scene.Update();		
						scenary.Refresh();
						alternativePosition++;
					}
					//sceneAlt.Update();
					scene.Update();
					Session.Output("Alternate created");
					scenary.Refresh();
				}
			}	
			
			break;
		}
		default:
        {
            // Error message
            Session.Prompt("This script does not support items of this type.", 0 );
        }
		
		
	}
}

CreateSteps();