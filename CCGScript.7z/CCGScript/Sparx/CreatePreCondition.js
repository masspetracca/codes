/*
 * Main function
 */
function CreatePreCondition()
{
    Repository.EnsureOutputVisible("Script");
    Session.Output( "=========================================" );
    Session.Output( "JScript: Create Pre-Condition" );
    Session.Output( "=========================================" );
	
	//var treeSelectedType = Repository.GetTreeSelectedItemType();
	var treeSelectedElements  = Repository.GetTreeSelectedElements();
	var element as EA.Element;
	var constraint = "TEST";
	var note = "TEST";
	
	for (var a = 0; a < treeSelectedElements.Count ;a++){
		element = treeSelectedElements.GetAt(a);
		Session.Output("Element Type: "+element.Type);
		switch (element.Type)
		{
			case "UseCase":
			{
				var constrColl as EA.Collection;
				var constr as EA.Constraint;
				//element = treeSelectedElements.GetAt(a);
				//Repository.GetTreeSelectedObject();
				Session.Output("Element Name: "+element.Name);
				if (element.Type == "UseCase"){
						if (!(note == "")){
							element.Notes = note;
						}
						if (!(constraint == "")){	
							constrColl = element.Constraints;
							constr = constrColl.AddNew(constraint,"Pre-condition");
							constr.Type = "Pre-condition";
							constr.Status = "Approved";
							constr.Update();
							constrColl.Refresh();
						}
						element.Update();
				}
			
				break;
			}
			default:
			{
				// Error message
				Session.Prompt("This script does not support items of this type.", 0 );
			}
			
			
		}
	}	
}

CreatePreCondition();