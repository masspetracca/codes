/*
 * Main function
 */
function ReplaceStringOnActivityAction()
{
    Repository.EnsureOutputVisible("Script");
    Session.Output( "=========================================" );
    Session.Output( "JScript: Set Name Element" );
    Session.Output( "=========================================" );
	
	var treeSelectedElements  = Repository.GetTreeSelectedElements();
	var element as EA.Element;
	var name = "new ";
	var search = "";

	for (var a = 0; a < treeSelectedElements.Count ;a++){
		element = treeSelectedElements.GetAt(a);
		Session.Output("Element Type: "+element.Type);
		switch (element.Type)
		{
			case "UseCase":
			{
				var constrColl as EA.Collection;
				Session.Output("Element Name: "+element.Name);
				if (element.Type == "UseCase"){
					if (search == "" ){
						Session.Output("search =='' ");
						var appo = element.Name;
						element.Name = name+appo;
						element.Update();
					}else{
						var appo = element.Name;
						Session.Output("test "+appo.replace(search,name));
						element.Name = appo.replace(search,name);
						element.Update();
					}
				}
				break;
			}
			case "Requirement":
			{
				Session.Output("Element Name: "+element.Name);
				if (element.Type == "Requirement"){
					if (search == "" ){
						Session.Output("search =='' ");
						var appo = element.Name;
						element.Name = name+appo;
						element.Update();
					}else{
						var appo = element.Name;
						Session.Output("test "+appo.replace(search,name));
						element.Name = appo.replace(search,name);
						element.Update();
					}
				}
				break;
			}
			case "Activity":
			{
				Session.Output("Element Name: "+element.Name);
				if (element.Type == "Activity"){
					if (search == "" ){
						Session.Output("search =='' ");
						var appo = element.Name;
						element.Name = name+appo;
						element.Update();
					}else{
						var appo = element.Name;
						Session.Output("test "+appo.replace(search,name));
						element.Name = appo.replace(search,name) ;
						element.Update();
					}
				}
				break;
			}
			case "Action":
			{
				Session.Output("Element Name: "+element.Name);
				if (element.Type == "Action"){
					if (search == "" ){
						Session.Output("search =='' ");
						var appo = element.Name;
						element.Name = name+appo;
						element.Update();
					}else{
						var appo = element.Name;
						Session.Output("test "+appo.replace(search,name));
						element.Name = appo.replace(search,name);
						element.Update();
					}
				}
				break;
			}
			default:
			{
				// Error message
				Session.Prompt("This script does not support items of this type "+element.Type, 0 );
			}	
		}
	}	
}
ReplaceStringOnActivityAction();