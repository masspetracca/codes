
#Installazione production environment
node='D65BD99F_PAMP_WEB'
cell='D65BD99F_PAMP_WEB'
server='PAMP_WEB'
file=sys.argv[0]+'/CCGPortal.ear'

print '*****Start script*****'

AdminApp.update('CCGPortal', 'app', '[ -operation update \
    -contents '+file+' \
    -nopreCompileJSPs \
    -installed.ear.destination CCGPortal \
    -distributeApp \
    -nouseMetaDataFromBinary \
    -nodeployejb \
    -createMBeansForResources \
    -noreloadEnabled \
    -nodeployws \
    -validateinstall warn \
    -processEmbeddedConfig \
    -filepermission .*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755 \
    -noallowDispatchRemoteInclude \
    -noallowServiceRemoteInclude \
    -asyncRequestDispatchType DISABLED \
    -nouseAutoLink \
    -MapModulesToServers [[ CCGPortalEJB CCGPortalEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cell+',node='+node+',server='+server+' ][ PampWeb PampWeb.war,WEB-INF/web.xml WebSphere:cell='+cell+',node='+node+',server='+server+' ]]]' ) 

#Salvataggio configurazione
AdminConfig.save()
print '\n- Configuration saved'

print '\n*****End script*****'
