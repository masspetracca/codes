
#Installazione production environment
file=sys.argv[0]+'/CCGPortal.ear'

print '*****Start script: PAMP PT EAR *****'

AdminApp.update('CCGPortal', 'app', '[ -operation update \
    -contents '+file+' \
    -nopreCompileJSPs \
    -installed.ear.destination CCGPortal \
    -distributeApp \
    -nouseMetaDataFromBinary \
    -nodeployejb \
    -createMBeansForResources \
    -noreloadEnabled \
    -nodeployws \
    -validateinstall warn \
    -noprocessEmbeddedConfig \
    -filepermission .*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755 \
    -noallowDispatchRemoteInclude \
    -noallowServiceRemoteInclude \
    -asyncRequestDispatchType DISABLED \
    -nouseAutoLink \
    -MapModulesToServers [[ CCGPortalEJB CCGPortalEJB.jar,META-INF/ejb-jar.xml WebSphere:cell=H65BD99F_NCPAMP_PT,node=H65BD99F_NCPAMP_PT,server=NCPAMP_PT+WebSphere:cell=H65BD99F_NCPAMP_PT,node=IHSRM01-node,server=webccgrm01 ][ PampWeb PampWeb.war,WEB-INF/web.xml WebSphere:cell=H65BD99F_NCPAMP_PT,node=H65BD99F_NCPAMP_PT,server=NCPAMP_PT+WebSphere:cell=H65BD99F_NCPAMP_PT,node=IHSRM01-node,server=webccgrm01 ]]]' )

#Salvataggio configurazione
AdminConfig.save()
print '\n- Configuration saved'

print '\n*****End script*****'
 