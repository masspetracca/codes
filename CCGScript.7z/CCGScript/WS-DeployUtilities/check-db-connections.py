'''
Created on 17/feb/2011

@author: buffoni

Questo script testa le connessioni ai sistemi
 

'''

import pyodbc 
print '--- Sript started'


odbc_sources=['DSN=ROMA-SVIL;PWD=ndapc1pFC','DSN=ROMA-BKP;PWD=ndapc1pFC','DSN=ROMA-DR;PWD=ndapc1pFC','DSN=ROMA-PROD;PWD=ndapc1pFC']

for odbc in odbc_sources:
    print 'Connecting to %s' % odbc
    conn = pyodbc.connect(odbc,autocommit=True)
    print 'Connected to %s\n' % odbc
print '\n--- Sript correctly executed'







 


