
#Installazione production environment
file=sys.argv[0]+'/CCGPortal.ear'

print '*****Start script: PAMP TO EAR *****'

AdminApp.update('CCGPortal', 'app', '[ -operation update \
    -contents '+file+' \
    -nopreCompileJSPs \
    -installed.ear.destination CCGPortal \
    -distributeApp \
    -nouseMetaDataFromBinary \
    -nodeployejb \
    -createMBeansForResources \
    -noreloadEnabled \
    -nodeployws \
    -validateinstall warn \
    -noprocessEmbeddedConfig \
    -filepermission .*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755 \
    -noallowDispatchRemoteInclude \
    -noallowServiceRemoteInclude \
    -asyncRequestDispatchType DISABLED \
    -nouseAutoLink \
    -MapModulesToServers [[ CCGPortalEJB CCGPortalEJB.jar,META-INF/ejb-jar.xml WebSphere:cell=H65BD99F_NCPAMP_TO,node=IHSRM01-node,server=webccgrm01+WebSphere:cell=H65BD99F_NCPAMP_TO,node=H65BD99F_NCPAMP_TO,server=NCPAMP_TO ][ PampWeb PampWeb.war,WEB-INF/web.xml WebSphere:cell=H65BD99F_NCPAMP_TO,node=IHSRM01-node,server=webccgrm01+WebSphere:cell=H65BD99F_NCPAMP_TO,node=H65BD99F_NCPAMP_TO,server=NCPAMP_TO ]]]' )  


#Salvataggio configurazione
AdminConfig.save()
print '\n- Configuration saved'

print '\n*****End script*****'

