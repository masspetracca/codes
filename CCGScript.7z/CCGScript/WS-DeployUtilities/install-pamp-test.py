
#Installazione test environement 230

node='I65BD99F_PAMP_WEB'
cell='I65BD99F_PAMP_WEB'
server='PAMP_WEB'
file=sys.argv[0]+'/CCGPortal.ear'

print '*****Start script*****'
#    -contents /ear/CCGPortal.ear \
AdminApp.update('CCGPortal', 'app', '[ -operation update \
    -contents C:/ear/CCGPortal.ear \
    -nopreCompileJSPs \
    -installed.ear.destination CCGPortal \
    -distributeApp -nouseMetaDataFromBinary \
    -nodeployejb \
    -createMBeansForResources \
    -noreloadEnabled \
    -nodeployws \
    -validateinstall warn \
    -noprocessEmbeddedConfig \
    -filepermission .*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755 \
    -noallowDispatchRemoteInclude \
    -noallowServiceRemoteInclude \
    -asyncRequestDispatchType DISABLED \
    -nouseAutoLink \
    -MapModulesToServers [[ CCGPortalEJB CCGPortalEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cell+',node='+node+',server='+server+'+WebSphere:cell='+cell+',node='+node+',server='+server+' ]\
        [ PampWeb PampWeb.war,WEB-INF/web.xml WebSphere:cell='+cell+',node='+node+',server='+server+'+WebSphere:cell='+cell+',node='+node+',server='+server+' ]]]' )
 
#Salvataggio configurazione
AdminConfig.save()
print '\n- Configuration saved'

print '\n*****End script*****'
