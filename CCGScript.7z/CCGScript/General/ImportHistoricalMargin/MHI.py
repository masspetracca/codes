from xml.dom.minidom import parse, Node
import os,fnmatch
import re

import os,  sys, time, re 
from PyQt4.QtCore import * 
from PyQt4.QtSql import * 
from PyQt4.QtGui import * 

#Apre i file 
f1 = open('MargHist.txt', 'r')
f2 = open('RcCodeList.txt', 'w')

linesList=[line.split(';') for line in f1.readlines()]
rcList=[]
for line in linesList:
    if (line[2] not in rcList) and line[2]!='':
        rcList.append(line[2])

app = QApplication(sys.argv) 
maxdb = QSqlDatabase.addDatabase("QODBC", "TESTPAMPUSE")
maxdb.setUserName("PAMPUSE") 
maxdb.setPassword("LAPAMP") 

aperturamaxdb = maxdb.open() 
if not aperturamaxdb: 
    print(maxdb.lastError().text()) 
    sys.exit(1) 
print maxdb.isOpen() 
print maxdb.isValid() 
query1maxdb =QSqlQuery(maxdb) 
query1maxdb.exec_(QString("SELECT * FROM PMPTINSTR")) 
query1maxdb.next() 
print query1maxdb.isValid()


