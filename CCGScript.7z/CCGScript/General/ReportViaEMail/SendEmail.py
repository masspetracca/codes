#!/usr/bin/python

'''
This script send the entire content to the directory to a list of recipients

@author: buffoni
'''


import os, shutil
import sys
import smtplib
# For guessing MIME type based on file name extension
import mimetypes

from optparse import OptionParser

from email import encoders
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from datetime import datetime
from datetime import date
Date=date.today().strftime('%Y%m%d') #Fromato data nel file

COMMASPACE = ', '


def main():
    parser = OptionParser(usage="""\
Send the contents of a directory as a MIME message.

Usage: %prog [options]

""")
    parser.add_option('-d', '--directory',
                      type='string', action='store',
                      help="""Mail the contents of the specified directory,
                      otherwise use the current directory.  Only the regular
                      files in the directory are sent, and we don't recurse to
                      subdirectories.""")
    parser.add_option('-b', '--bkpdirectory',
                      type='string', action='store', default=['Storico'],
                      help="""Move the files to the specified directory,
                      otherwise use the subdirectory Storico.""")
    parser.add_option('-l', '--logfile',
                      type='string', action='store', default='log.txt',
                      help="""log file name. Default is log.txt""")
    parser.add_option('-o', '--output',
                      type='string', action='store', metavar='FILE',
                      help="""Print the composed message to FILE instead of
                      sending the message to the SMTP server.""")
    parser.add_option('-s', '--sender',
                      type='string', action='store', metavar='SENDER',
                      help='The value of the From: header (required)')
    parser.add_option('-r', '--recipient',
                      type='string', action='store', metavar='RECIPIENT',
                      dest='recipients',
                      help='A To: header value (at least one required). Comma separated list of addresses')

    opts, args = parser.parse_args()
    if not opts.sender or not opts.recipients:
        parser.print_help()
        sys.exit(1)
    directory = opts.directory
    bkpdirectory= opts.bkpdirectory
    logfile=opts.logfile
    log = open(logfile, 'a')
    if not directory:
        directory = '.'
    # Create the enclosing (outer) message
    outer = MIMEMultipart()
    outer['Subject'] = 'CC&G - Executive Reports'
    outer['To'] = COMMASPACE.join(opts.recipients.split(','))
    outer['From'] = opts.sender
    outer.preamble = 'You will not see this in a MIME-aware mail reader.\n'
    
    text='\nPlease find attached the set of Executive Reports as of  yesterday.\n\nKind Regards.\n\nCC&G\nFinancial Operations\n\n'

    outer.attach(MIMEText(text, 'plain'))
    
    filelist=os.listdir(directory)
    if len(filelist)==0:
        log.writelines(datetime.now().strftime('%Y-%m-%d %H:%M:%S')+ ' - The folder is empty\n')
        return
    
    for filename in filelist:
        path = os.path.join(directory, filename)
        if not os.path.isfile(path):
            continue
        # Guess the content type based on the file's extension.  Encoding
        # will be ignored, although we should check for simple things like
        # gzip'd or compressed files.
        ctype, encoding = mimetypes.guess_type(path)
        if ctype is None or encoding is not None:
            # No guess could be made, or the file is encoded (compressed), so
            # use a generic bag-of-bits type.
            ctype = 'application/octet-stream'
        maintype, subtype = ctype.split('/', 1)
        if maintype == 'text':
            fp = open(path)
            # Note: we should handle calculating the charset
            msg = MIMEText(fp.read(), _subtype=subtype)
            fp.close()
        elif maintype == 'image':
            fp = open(path, 'rb')
            msg = MIMEImage(fp.read(), _subtype=subtype)
            fp.close()
        elif maintype == 'audio':
            fp = open(path, 'rb')
            msg = MIMEAudio(fp.read(), _subtype=subtype)
            fp.close()
        else:
            fp = open(path, 'rb')
            msg = MIMEBase(maintype, subtype)
            msg.set_payload(fp.read())
            fp.close()
            # Encode the payload using Base64
            encoders.encode_base64(msg)
        # Set the filename parameter
        msg.add_header('Content-Disposition', 'attachment', filename=filename)
        outer.attach(msg)
    # Now send or store the message
    composed = outer.as_string()
    if opts.output:
        fp = open(opts.output, 'w')
        fp.write(composed)
        fp.close()
    else:
        s = smtplib.SMTP('webmailrm.ccgnet.it')
        recipientlist=opts.recipients.split(',')
        s.sendmail(opts.sender, recipientlist, composed)
        log.writelines(datetime.now().strftime('%Y-%m-%d %H:%M:%S')+' - Mail sent\n')
        s.quit()


    #Spostamento files
    src = directory
    dst = bkpdirectory
    for f in os.listdir(src):
        shutil.move(os.path.join(src,f),dst)
        log.writelines(datetime.now().strftime('%Y-%m-%d %H:%M:%S')+ ' - ' + f + ' moved to the backup folder\n')
    
    log.close()

if __name__ == '__main__':
    main()