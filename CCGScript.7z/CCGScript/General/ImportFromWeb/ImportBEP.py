#!/usr/bin/env python

import urllib2
import urllib
import re
from string import rfind

log = open('log.txt', 'w')

#import the lesson list
inputFile =open('LinkList.txt','r')
#inputFileText=inputFile.read()
#lessonList=re.findall('href=\"(http[^\"]*)\"', inputFileText)
lessonList=inputFile.readlines()

#authentication
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor())
urllib2.install_opener(opener)
params = urllib.urlencode(dict(amember_login='dbuffoni', amember_pass='itsalldown', login_attempt_id='1598789865',submit='Sign In'))
f = opener.open('http://www.businessenglishpod.com/aMember/member.php', params)
data = f.read()
f.close()

i=0
for url in lessonList:
    i+=1
    
    f = opener.open(url)
    urlText = f.read()
    f.close()

    filesLinkList=re.findall('href=\"(http[^\"]*\.mp3)\"', urlText)
    filesLinkList+=re.findall('href=\"(http[^\"]*\.pdf)\"', urlText)
    filesLinkList+=re.findall('href=\"(http[^\"]*\.m4v)\"', urlText)
    filesLinkList+=re.findall('href=\"(http[^\"]*\.mov)\"', urlText)
    filesLinkList+=re.findall('href=\"(http[^\"]*\.mp4)\"', urlText)
    fileNameLinkList=[(link[rfind(link,'/')+1:len(link)],link) for link in filesLinkList]
    
    
    for (fileName,fileLink) in fileNameLinkList:
        
        try:
            fileContent=urllib2.urlopen(fileLink).read()
            output = open('podcasts/'+fileName,'wb')
            output.write(fileContent)
            output.flush();
            dim=output.__sizeof__
            output.close()
            log.write('%s\t%s\t%s\n' % (fileName,fileLink,url))
            log.flush()
        except:
            log.write('Error on lesson:\t%s\t%s\t%s\n' % (fileName,fileLink,url))
            try:
                output.close()
            except:pass
            print('%s\t%s\t%s' % (fileName,fileLink,url))
    print 'Percentage: {0:.2%}.'.format(float(i)/float(len(lessonList)))
print('Terminated!')
log.close()