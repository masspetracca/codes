#!/usr/bin/python

'''
Questo accoda i messaggi swift contenuti in una cartella facenti riferimento ad una data specifica in un unico file di output

@author: buffoni
'''


import os,fnmatch
import re
import time
from datetime import datetime
from datetime import date
Date=date.today().strftime('%Y%m%d') #Fromato data nel file

######################################################
# Configurare queste variabili come nell'esempio
#Date="20110315" #Scommentare questa riga per fissare una data specifica  
InputFolder="C:/workspace/CCGScript/General/SelectSwiftMessages/Storico"
OutputFolder="C:/workspace/CCGScript/General/SelectSwiftMessages/Mt940"
LogFolder="C:/workspace/CCGScript/General/SelectSwiftMessages/Log"

######################################################


log =   open(os.path.join(LogFolder,'log.txt'), 'a')
mt940=""
OutputFile="FromSWIFT_"+Date+".dat"

filelist=[os.path.join(InputFolder,file) for file in os.listdir(InputFolder) if file.find(Date)>0]

i=0
for filename in filelist:
    file=open(filename,'r')
    firstline=file.readline()
    if(firstline.find("{2:O940")>0):
        i+=1
        text=file.read()
        if(i>1):
            mt940.write('\n'+firstline+text)
        else:
            mt940 = open(os.path.join(OutputFolder,OutputFile),'w')
            mt940.write(firstline+text)
        file.close()
        log.writelines(datetime.now().strftime('%Y-%m-%d %H:%M:%S')+" - File "+filename+" appended to "+ OutputFile+'\n')
                
print(str(i)+ " files appended to the following file:"+OutputFile)


if (i>0):
    mt940.close()
log.close()



