'''
Created on 17/feb/2011

@author: buffoni

Inserting Data
-----
To insert data, pass the insert SQL to Cursor.execute, along with any parameters necessary:
-----
cursor.execute("insert into products(id, name) values ('pyodbc', 'awesome library')")
cnxn.commit()
cursor.execute("insert into products(id, name) values (?, ?)", 'pyodbc', 'awesome library')
cnxn.commit()
Note the calls to cnxn.commit(). You must call commit or your changes will be lost! When the connection is closed, any pending changes will be rolled back. This makes error recovery very easy, but you must remember to call commit.
----
Updating and Deleting
----
Updating and deleting work the same way, pass the SQL to execute. However, you often want to know how many records were affected when updating and deleting, in which case you can use the cursor.rowcount value:
cursor.execute("delete from products where id <> ?", 'pyodbc')
print cursor.rowcount, 'products deleted'
cnxn.commit()
Since execute always returns the cursor, you will sometimes see code like this. (Notice the rowcount on the end.)
deleted = cursor.execute("delete from products where id <> 'pyodbc'").rowcount
cnxn.commit()
Note the calls to cnxn.commit(). You must call commit or your changes will be lost! When the connection is closed, any pending changes will be rolled back. This makes error recovery very easy, but you must remember to call commit. 
'''

import pyodbc 

conn = pyodbc.connect('DSN=TESTPAMPUSE;PWD=lapamp',autocommit=False)
curs = conn.cursor() 
curs = conn.cursor() 
curs.execute('select instrid,status from pmptinstr') 
print curs.fetchall() 


