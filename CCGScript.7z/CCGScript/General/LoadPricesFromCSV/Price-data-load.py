'''
Created on 28/Sep/2012

@author: buffoni

Questo script carica dati in formato CSV sulla tabella di storico prezzi

'''

import pyodbc 
import csv
from datetime import datetime
print '--- Sript started'


filename='InputTestFileID2.csv'
odbc='DSN=ROMEPAMP-TEST;PWD=ndapc1pFC'
load_segment=6
log = open('log.txt', 'a')


print 'Connecting to %s' % odbc
conn = pyodbc.connect(odbc,autocommit=False)
curs = conn.cursor()
print 'Connected to %s\n' % odbc
i=0
ik=0
new_time=datetime.now()
initial_time=new_time
old_time=new_time
lastrow=''

with open(filename, 'rb') as csvfile:
    csvreader = csv.reader(csvfile, delimiter=',', quotechar='"')
    for row in csvreader:
        #increment the counters
        i=i+1 
        ik=i%load_segment
        
        query='INSERT INTO PMPTHISPR (INSTRID, PRICEDATE, CLOSEPR) values (%s,\'%s 00:00:00\',%s)' % (row[0],row[1],row[2])
        log.writelines('%s\nGO\n\n' % query)
        
        try:
            curs.execute(query)
        except Exception,e:
            print 'Error: execution interrupted.'
            print e.args
            print 'Last record committed (row %s): %s\n' % (i,lastrow)
            quit()
        
        #this code is executed only at the end of the load segment
        if ik==0 and i!=0:
            #Performance calculation
            #Delta time calculated as the difference between the systemdate and the systemdate when the last commit is executed.
            #The performance is calculated dividinge the delta time in micoseconds by the load segment (records in a commit)
            new_time=datetime.now()    
            performance=((new_time-old_time).microseconds)/load_segment
            performance_glob=((new_time-initial_time).microseconds)/i
            old_time=new_time
                   
    
            #Commit
            conn.commit()

            #save the last committed row
            lastrow=(',').join(row)
            
            print 'Records committed:\t%s\tSegment performance:\t%s\tTotal performance:\t%s\tLast row: "%s"' % (i,performance,performance_glob,lastrow)
        
    #Commit
    conn.commit()
    print 'Records committed:\t%s\t\t\t\t\tTotal performance:\t%s\tLast row: "%s"' % (i,performance_glob,(',').join(row))
    
    log.close()    

        
print '\n--- Sript correctly executed:'

