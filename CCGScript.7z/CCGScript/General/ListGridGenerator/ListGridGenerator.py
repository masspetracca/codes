#!/usr/bin/python
# -*- coding: utf-8 -*-

# openfiledialog.py

import sys
from PyQt4 import QtGui
from PyQt4 import QtCore
from xml.dom.minidom import parse, Node
from string import upper, lower, strip
from exceptions import Exception


class MainWindow(QtGui.QMainWindow):
  
    def __init__(self):
        super(MainWindow, self).__init__()
        
        self.initUI()
        
    def initUI(self):

        self.textEdit = QtGui.QTextEdit()
        self.setCentralWidget(self.textEdit)
        self.statusBar()
        self.setFocus()

        openFile = QtGui.QAction(QtGui.QIcon('open.png'), 'Open', self)
        openFile.setShortcut('Ctrl+O')
        openFile.setStatusTip('Open a ds.xml file')
        self.connect(openFile, QtCore.SIGNAL('triggered()'), self.showDialog)

        menubar = self.menuBar()
        fileMenu = menubar.addMenu('&File')
        fileMenu.addAction(openFile)
        
        self.setGeometry(300, 300, 800, 400)
        self.setWindowTitle('ListGrid Java code generator')        
    
    def showDialog(self):

        filename = QtGui.QFileDialog.getOpenFileName(self, 'Open file','/home')
        fname = open(filename,'r')             
        xmltree = parse(fname)
        fname.close()
        
        data=self.produceCode(xmltree)
        
        self.textEdit.setText(data)
        
    def produceCode(self,xmltree):

        fieldList=[(lower(f.getAttribute('name')),f.getAttribute('name'),strip(f.getAttribute('title')),upper(f.getAttribute('type'))) for f in xmltree.getElementsByTagName('field')]
        fieldListString=''
        for f in fieldList:
            fieldListString+=f[0].encode()+"Field,"
        
        data="//Field list\n"
        
        #lista dei campi
        for f in fieldList:
            data+= "ListGridField %sField = new ListGridField(\"%s\"); //%s\n" % f[0:3]
            
        #lista formattatori
        formatterString="Field.setCellFormatter(new CellFormatter() {\n"
        formatterString+="\tpublic String format(Object value, ListGridRecord record, int rowNum, int colNum) {\n"
        formatterString+="\t\tif (value == null)return null;\n"
        formatterString+="\t\tString val = null;\n"
        formatterString+="\t\ttry {\n"
        formatterString+="\t\t\tNumberFormat nf = NumberFormat.getFormat(\"0.00\");\n"
        formatterString+="\t\t\tval = nf.format(((Number) value).doubleValue());\n"
        formatterString+="\t\t} catch (Exception e) {\n"
        formatterString+="\t\t\treturn value.toString();\n"
        formatterString+="\t\t}\n"
        formatterString+="\t\treturn val;\n"
        formatterString+="\t}\n"
        formatterString+="});\n\n"
        
        data+= "\n"
        floatList=[f[0] for f in fieldList if f[3]=='FLOAT']
        for f in floatList:
            data+="//"+f+" field formatter\n"+f+formatterString
        #assegnamento dei campi alla griglia (this)
        data+= "\n\n//Fields set\nthis.setFields(%s);" % fieldListString.strip(',')
        
        return data
        
app = QtGui.QApplication(sys.argv)
ex = MainWindow()
ex.show()
app.exec_()