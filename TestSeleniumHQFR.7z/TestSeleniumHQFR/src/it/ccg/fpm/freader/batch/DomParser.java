package it.ccg.fpm.freader.batch;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;


public class DomParser {
	private String wOUT;
	private String c;
	private String wURL;
	private String wLINE;
	private String wREQ;
	private String wNName;
	private String wNTYPE;
	private String wCNAME;
	private String wACTION;
	private String wNVALUE;
	private String wDURL;
	private String wDATE;
	private int swWPOST;
	private String wLLINE;
	private int idx;
	private String wVUOTO;

	//public static void main(String[] args) throws IOException {
	DomParser() throws DocumentException, IOException { 
	System.out.println("Inizio <DomParser>");		
    
    wOUT= "";
	c="\n";

	File outValues = 
			  //new File("dati/"+"Selenium_testOUT.xml");
			  (new File(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTVALUES_FILE_OUTPUT())); 

	  FileWriter writerValues = null;
	  
	  try {
		  
		  boolean deleted = false;							
	      if (outValues.exists()) {							
	    	  deleted = outValues.delete();						
	      }
	      else {
	    	  System.out.println("rimosso file da: " + outValues.getAbsolutePath() + ", " + deleted);							
	    	  writerValues = new FileWriter(outValues, false);
	      }
	  } catch  (IOException e) {e.printStackTrace();}


	    //read File
 	    BufferedReader in = new BufferedReader
					(new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTFIELDS_FILE_OUTPUT()));
		SAXReader reader = new SAXReader();
		Document document = reader.read(in);
		Element root = document.getRootElement();
		System.out.println("Root Element: "+root.getName());

		wURL=" ";
     	wDURL=" ";
  	  	wOUT=" ";
  	  	wLINE=" ";
  	  	wLLINE=" ";
  	  	wREQ=" ";
  	  	wREQ=" ";
  	  	wNName=" ";
  	  	wNTYPE=" ";
  	  	wCNAME=" ";
  	  	wACTION=" ";
  	  	wNVALUE=" ";
  	  	wVUOTO=" ";
  	  	idx=1;
	  	
		
	    for ( Iterator i = root.elementIterator(); i.hasNext(); ) {
            Element row = (Element) i.next();

            //<post> o <click>
            Iterator itr = row.elementIterator();
            while(itr.hasNext()){

             	Element child = (Element) itr.next();
  
                  //navigazione nodi 
                  System.out.println("Element Name:"+child.getQualifiedName() );
                  System.out.println("Element Value:"+child.getText());
                  
                  //reqID check 
                  if (child.getQualifiedName().contains("reqID") == true) {
                	  System.out.println("<reqID>"+child.getQualifiedName() );
                	  wREQ=child.getText().substring(0, 15);
                	  wDURL= ("[#INSERT#]Navigazione: viene acceduta la pagina la cui url risulta");
                  }
                  //dateID check 
                  if (child.getQualifiedName().contains("dateID") == true) {
                	  System.out.println("<dateID>"+child.getQualifiedName() );
                	  wDATE= (child.getText());
                   }
                  //url check 
                  if (child.getQualifiedName().contains("openURL") == true) {
                	  System.out.println("<openURL>"+child.getQualifiedName() );
                	  wURL= (child.getText());
                	  wURL=wDURL+wURL+" ";
                	  idx=1;


					  wLLINE=(wREQ+"|"+wDATE+"|"+idx+"|"+wURL+"|"+wNName+"|"+wNTYPE+"|"+wCNAME+"|"+wACTION+"|"+wNVALUE+"|"+wOUT+c);
                 	  writerValues.write(wLLINE);
                 	  
                 	  wURL=" ";
		        	  wDURL=" ";
		        	  wOUT=" ";
		        	  wLINE=" ";
		        	  wLLINE=" ";
		        	  wNName=" ";
		        	  wNTYPE=" ";
		        	  wCNAME=" ";
		        	  wACTION=" ";
		        	  wNVALUE=" ";
		        	  wVUOTO=" ";
		        	  swWPOST = 1;
		        	  idx++;
                  }
                  //line check: POST 
                  if ((child.getQualifiedName().contains("response") == true)                 		  
                  && (child.getText().contains("post")) == true) {
		        	  if (swWPOST == 0) {
		        		  wURL="CLICK";

						  wLLINE=(wREQ+"|"+wDATE+"|"+idx+"|"+wVUOTO+"|"+wNName+"|"+wNTYPE+"|"+wCNAME+"|"+wACTION+"|"+wNVALUE+"|"+wOUT+c);
	                 	  writerValues.write(wLLINE);

	                 	  wURL=" ";
			        	  wOUT=" ";
			        	  wLINE=" ";
			        	  wLLINE="";
			        	  wNName=" ";
			        	  wNTYPE=" ";
			        	  wCNAME=" ";
			        	  wACTION=" ";
			        	  wNVALUE=" ";
			        	  idx++;

			        	  
		        	  }
		        	  swWPOST = 0;
		        	  System.out.println("<POST>"+child.getQualifiedName() );
                	  wLINE = ("Stato Base: Attende la risposta dall^oggetto ");
                      wOUT=wLINE;
                  }
                //line check: CLICK
                  if ((child.getQualifiedName().contains("response") == true)                 		  
                  && (child.getText().contains("click")) == true) {
	        		  wURL="POST";

	        		  wLLINE=(wREQ+"|"+wDATE+"|"+idx+"|"+wVUOTO+"|"+wNName+"|"+wNTYPE+"|"+wCNAME+"|"+wACTION+"|"+wNVALUE+"|"+wOUT+c);
                 	  writerValues.write(wLLINE);

                 	  wURL=" ";
		        	  wOUT=" ";
		        	  wLINE=" ";
		        	  wLLINE="";
		        	  wNName=" ";
		        	  wNTYPE=" ";
		        	  wCNAME=" ";
		        	  wACTION=" ";
		        	  wNVALUE=" ";
		        	  wVUOTO=" ";
		        	  idx++;

		        	  

                	  System.out.println("<CLICK>"+child.getQualifiedName() );
                	  wLINE = ("Navigazione: Invia la richiesta all^oggetto ");
                      wOUT=wLINE;
                  }
                  if (child.getQualifiedName().contains("nodeName") == true) {
                	  System.out.println("<nodeName>"+child.getText() );
                	  wLINE+= (child.getText());
                      wOUT  =wLINE;
		        	  wNName=child.getText();
                  }
                  if (child.getQualifiedName().contains("nodeType") == true) {
                	  System.out.println("<nodeType>"+child.getText() );
                	  wLINE+= (", "+child.getText());
                      wOUT  =wLINE;
		        	  wNTYPE=child.getText();
                  }
                  if (child.getQualifiedName().contains("childName") == true) {
                	  System.out.println("<childName>"+child.getText() );
                	  wLINE+= (" di cui "+child.getText());
                      wOUT  =wLINE;
		        	  wCNAME=child.getText();
                  }
                  if (child.getQualifiedName().contains("nodeValue") == true) {
                	  System.out.println("<nodeValue>"+child.getText() );
                	  wLINE+= (", con contenuto "+child.getText());
                      wOUT  =wLINE;
		        	  wNVALUE=child.getText();
                  }
                  if (child.getQualifiedName().contains("action") == true) {
                	  System.out.println("<action>"+child.getText() );
                	  wLINE+= (", quindi viene eseguito "+child.getText()+". Il progressivo della riga risulta:"+idx);
                      wOUT  =wLINE;
		        	  wACTION=child.getText();
                  }
 
            }
	    }
		writerValues.close();
		System.out.println("Fine esecuzione <DataFileCompleto> - estrazione : File Data");
	}



}