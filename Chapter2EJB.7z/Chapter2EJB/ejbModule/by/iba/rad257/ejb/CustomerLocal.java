package by.iba.rad257.ejb;
/**
 * Local interface for Enterprise Bean: Customer
 */
public interface CustomerLocal extends javax.ejb.EJBLocalObject {
    
    /**
     * Set accessor for persistent attribute: id
     */
    public void setId(java.lang.Integer newId);
    
    /**
     * Get accessor for persistent attribute: name
     */
    public java.lang.String getName();
    
    /**
     * Set accessor for persistent attribute: name
     */
    public void setName(java.lang.String newName);
    
    /**
     * Get accessor for persistent attribute: id
     */
    public java.lang.Integer getId();
    /**
     * This method was generated for supporting the relationship role named orders.
     * It will be deleted/edited when the relationship is deleted/edited.
     */
    public java.util.Collection getOrders();
    /**
     * This method was generated for supporting the relationship role named orders.
     * It will be deleted/edited when the relationship is deleted/edited.
     */
    public void setOrders(java.util.Collection anOrders);
}
