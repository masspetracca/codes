package by.iba.rad257.ejb;
/**
 * Remote interface for Enterprise Bean: SayHello
 */
public interface SayHello extends javax.ejb.EJBObject {
    public String greet(String name) throws java.rmi.RemoteException;
}
