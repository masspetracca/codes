package by.iba.rad257.ejb;

import com.ibm.ejs.container.*;

/**
 * EJSCMPCustomerHomeBean_7dd938c7
 */
public class EJSCMPCustomerHomeBean_7dd938c7 extends EJSHome {
	/**
	 * EJSCMPCustomerHomeBean_7dd938c7
	 */
	public EJSCMPCustomerHomeBean_7dd938c7() throws java.rmi.RemoteException {
		super();	}
	/**
	 * findByPrimaryKey_Local
	 */
	public by.iba.rad257.ejb.CustomerLocal findByPrimaryKey_Local(java.lang.Integer primaryKey) throws javax.ejb.FinderException, java.rmi.RemoteException {
		return (by.iba.rad257.ejb.CustomerLocal)super.activateBean_Local(primaryKey);
	}
	/**
	 * create_Local
	 */
	public by.iba.rad257.ejb.CustomerLocal create_Local(java.lang.Integer id) throws javax.ejb.CreateException, java.rmi.RemoteException {
		BeanO beanO = null;
		by.iba.rad257.ejb.CustomerLocal result = null;
		boolean createFailed = false;
		boolean preCreateFlag = false;
		try {
			beanO = super.createBeanO();
			by.iba.rad257.ejb.CustomerBean bean = (by.iba.rad257.ejb.CustomerBean) beanO.getEnterpriseBean();
			preCreateFlag = super.preEjbCreate(beanO);
			bean.ejbCreate(id);
			Object ejsKey = keyFromBean(bean);
			result = (by.iba.rad257.ejb.CustomerLocal) super.postCreate_Local(beanO, ejsKey, true);
			bean.ejbPostCreate(id);
			super.afterPostCreate(beanO, ejsKey);
		}
		catch (javax.ejb.CreateException ex) {
			createFailed = true;
			throw ex;
		} catch (java.rmi.RemoteException ex) {
			createFailed = true;
			throw ex;
		} catch (Throwable ex) {
			createFailed = true;
			throw new CreateFailureException(ex);
		} finally {
			if(preCreateFlag && !createFailed)
				super.afterPostCreateCompletion(beanO);
			if (createFailed) {
				super.createFailure(beanO);
			}
		}
		return result;
	}
	/**
	 * findOrdersCustomerInverseByOrdersKey_Local
	 */
	public by.iba.rad257.ejb.CustomerLocal findOrdersCustomerInverseByOrdersKey_Local(java.lang.Integer key) throws javax.ejb.FinderException, java.rmi.RemoteException {
		by.iba.rad257.ejb.CustomerLocal result = null;
		EntityBeanO beanO = null;

		java.lang.Integer pKey = null;
		try {
			beanO = super.getFinderEntityBeanO();
			by.iba.rad257.ejb.ConcreteCustomer_7dd938c7 bean = (by.iba.rad257.ejb.ConcreteCustomer_7dd938c7) beanO.getEnterpriseBean();
			pKey = bean.ejbFindOrdersCustomerInverseByOrdersKey_Local(key);
			result = (by.iba.rad257.ejb.CustomerLocal)activateBean_Local(pKey);
			super.releaseFinderEntityBeanO(beanO);
			beanO = null;
		}
		catch (javax.ejb.FinderException finderEx) {
			super.releaseFinderEntityBeanO(beanO);
			beanO = null;
			throw finderEx;
		}
		finally {
			if (beanO != null )
				super.discardFinderEntityBeanO(beanO);
		}
		return result;
	}
	/**
	 * findByPrimaryKeyForCMR_Local
	 */
	public by.iba.rad257.ejb.CustomerLocal findByPrimaryKeyForCMR_Local(java.lang.Integer key) throws javax.ejb.FinderException, java.rmi.RemoteException {
		return (by.iba.rad257.ejb.CustomerLocal)super.activateBean_Local(key);
	}
	/**
	 * keyFromBean
	 */
	public Object keyFromBean(javax.ejb.EntityBean generalEJB) {
		by.iba.rad257.ejb.ConcreteCustomer_7dd938c7 tmpEJB = (by.iba.rad257.ejb.ConcreteCustomer_7dd938c7) generalEJB;
		return tmpEJB.getId();
	}
	/**
	 * keyFromFields
	 */
	public java.lang.Integer keyFromFields(java.lang.Integer f0) {
		return f0;
	}
}
