package by.iba.rad257.ejb;
/**
 * Local interface for Enterprise Bean: Order
 */
public interface OrderLocal extends javax.ejb.EJBLocalObject {
    /**
     * Get accessor for persistent attribute: id
     */
    public java.lang.Integer getId();
    /**
     * Set accessor for persistent attribute: id
     */
    public void setId(java.lang.Integer newId);
    /**
     * Get accessor for persistent attribute: shipped
     */
    public boolean getShipped();
    /**
     * Set accessor for persistent attribute: shipped
     */
    public void setShipped(boolean newShipped);
    /**
     * Get accessor for persistent attribute: address
     */
    public java.lang.String getAddress();
    /**
     * Set accessor for persistent attribute: address
     */
    public void setAddress(java.lang.String newAddress);
}
