package by.iba.rad257.ejb;

/**
 * Bean implementation class for Enterprise Bean: SayHello
 */
public class SayHelloBean implements javax.ejb.SessionBean {
    private javax.ejb.SessionContext mySessionCtx;

    /**
     * getSessionContext
     */
    public javax.ejb.SessionContext getSessionContext() {
        return mySessionCtx;
    }

    /**
     * setSessionContext
     */
    public void setSessionContext(javax.ejb.SessionContext ctx) {
        mySessionCtx = ctx;
    }

    /**
     * ejbCreate
     */
    public void ejbCreate() throws javax.ejb.CreateException {
    }

    /**
     * ejbActivate
     */
    public void ejbActivate() {
    }

    /**
     * ejbPassivate
     */
    public void ejbPassivate() {
    }

    /**
     * ejbRemove
     */
    public void ejbRemove() {
    }

    public String greet(String name) {
        return "Hello, " + name + " !";
    }
}
