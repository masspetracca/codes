package by.iba.rad257.ejb;

import com.ibm.ejs.container.*;

/**
 * EJSRemoteStatelessSayHello_c7cf8d33
 */
public class EJSRemoteStatelessSayHello_c7cf8d33 extends EJSWrapper implements SayHello {
	/**
	 * EJSRemoteStatelessSayHello_c7cf8d33
	 */
	public EJSRemoteStatelessSayHello_c7cf8d33() throws java.rmi.RemoteException {
		super();	}
	/**
	 * greet
	 */
	public java.lang.String greet(java.lang.String name) throws java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		Object[] _jacc_parms = null;
		java.lang.String _EJS_result = null;
		try {
			if (container.doesJaccNeedsEJBArguments( this ))
			{
				_jacc_parms = new Object[1];
				_jacc_parms[0] = name;
			}
	by.iba.rad257.ejb.SayHelloBean beanRef = (by.iba.rad257.ejb.SayHelloBean)container.preInvoke(this, 0, _EJS_s, _jacc_parms);
			_EJS_result = beanRef.greet(name);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try{
				container.postInvoke(this, 0, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
}
