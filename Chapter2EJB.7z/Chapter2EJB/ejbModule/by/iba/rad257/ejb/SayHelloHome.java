package by.iba.rad257.ejb;
/**
 * Home interface for Enterprise Bean: SayHello
 */
public interface SayHelloHome extends javax.ejb.EJBHome {
    /**
     * Creates a default instance of Session Bean: SayHello
     */
    public by.iba.rad257.ejb.SayHello create() throws javax.ejb.CreateException, java.rmi.RemoteException;
}
