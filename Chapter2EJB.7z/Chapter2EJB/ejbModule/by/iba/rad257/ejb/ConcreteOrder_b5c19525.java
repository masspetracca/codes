package by.iba.rad257.ejb;

import com.ibm.ws.ejbpersistence.beanextensions.*;
import com.ibm.websphere.cpmi.*;
import by.iba.rad257.ejb.websphere_deploy.OrderBeanCacheEntry_b5c19525;

/**
 * Bean implementation class for Enterprise Bean: Order
 */
public class ConcreteOrder_b5c19525 extends by.iba.rad257.ejb.OrderBean implements javax.ejb.EntityBean, ConcreteBeanWithLink, ConcreteBeanWithForwardLink {
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		super.setEntityContext(ctx);
		instanceExtension.setEntityContext(ctx);
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		super.unsetEntityContext();
		instanceExtension.unsetEntityContext();
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
			super.ejbActivate();
			instanceExtension.ejbActivate();
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
		instanceExtension.ejbLoad();
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
		super.ejbPassivate();
		instanceExtension.ejbPassivate();
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
		super.ejbRemove();
		instanceExtension.ejbRemove();
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
		super.ejbStore();
		instanceExtension.ejbStore();
	}
	private ConcreteBeanInstanceExtension instanceExtension;
	private OrderBeanCacheEntry_b5c19525 dataCacheEntry;
	/**
	 * _WSCB_getInstanceInfo
	 */
	public PMConcreteBeanInstanceInfo _WSCB_getInstanceInfo() {
			return instanceExtension;
	}
	/**
	 * ConcreteOrder_b5c19525
	 */
	public ConcreteOrder_b5c19525() {
		super();
		instanceExtension = ConcreteBeanInstanceExtensionFactory.getInstance(this);
	}
	/**
	 * getInjector
	 */
	private by.iba.rad257.ejb.websphere_deploy.OrderBeanInjector_b5c19525 getInjector() {
		return (by.iba.rad257.ejb.websphere_deploy.OrderBeanInjector_b5c19525)instanceExtension.getInjector();
	}
	/**
	 * hydrate
	 */
	public void hydrate(Object inRecord) {
		dataCacheEntry = (by.iba.rad257.ejb.websphere_deploy.OrderBeanCacheEntry_b5c19525) inRecord;;
		super.ejbLoad();
	}
	/**
	 * resetCMP
	 */
	public void resetCMP() {
			dataCacheEntry = null;
	}
	/**
	 * resetCMR
	 */
	public void resetCMR() {
			ordersCustomerInverseLink = null;
	}
	/**
	 * ejbFindByPrimaryKey
	 */
	public java.lang.Integer ejbFindByPrimaryKey(java.lang.Integer primaryKey) throws javax.ejb.FinderException {
		return (java.lang.Integer)instanceExtension.ejbFindByPrimaryKey(primaryKey);
	}
	/**
	 * ejbFindByPrimaryKey
	 */
	public Object ejbFindByPrimaryKey(java.lang.Object pk) throws javax.ejb.FinderException {
		return ejbFindByPrimaryKey((java.lang.Integer)pk);
	}
	/**
	 * ejbFindByPrimaryKeyForCMR_Local
	 */
	public java.lang.Integer ejbFindByPrimaryKeyForCMR_Local(java.lang.Integer pk) throws javax.ejb.FinderException {
		return (java.lang.Integer)instanceExtension.ejbFindByPrimaryKey(pk);
	}
	/**
	 * ejbCreate
	 */
	public java.lang.Integer ejbCreate(java.lang.Integer id) throws javax.ejb.CreateException {
		dataCacheEntry = (OrderBeanCacheEntry_b5c19525) instanceExtension.createDataCacheEntry();
		 super.ejbCreate(id);
		return (java.lang.Integer)instanceExtension.ejbCreate();
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(java.lang.Integer id) throws javax.ejb.CreateException {
		super.ejbPostCreate(id);
		instanceExtension.ejbPostCreate();
	}
	/**
	 * createPrimaryKey
	 */
	public Object createPrimaryKey() {
		return getId();
	}
	/**
	 * getNumberOfFields
	 */
	public int getNumberOfFields() {
		return 5;
	}
	/**
	 * getLink
	 */
	public com.ibm.ws.ejbpersistence.associations.AssociationLink getLink(java.lang.String name) {
		if (name.equals("ordersCustomerInverse")) return getOrdersCustomerInverseLink();
		return null;
	}
	/**
	 * executeFinderForLink
	 */
	public java.lang.Object executeFinderForLink(java.lang.String name, java.lang.Object key) throws javax.ejb.FinderException {
		if (name.equals("ordersCustomerInverse")){
			by.iba.rad257.ejb.websphere_deploy.CustomerBeanInternalLocalHome_7dd938c7 home = (by.iba.rad257.ejb.websphere_deploy.CustomerBeanInternalLocalHome_7dd938c7)instanceExtension.getHomeForLink("ordersCustomerInverse");
		  return home.findByPrimaryKeyForCMR((java.lang.Integer)key);
		}
		return null;
	}
	/**
	 * getOrdersCustomerInverseKey
	 */
	public java.lang.Integer getOrdersCustomerInverseKey() {
		if (ordersCustomerInverseLink == null) return dataCacheEntry.getOrdersCustomerInverseKey();
		return (java.lang.Integer) ordersCustomerInverseLink.getKey();
	}
	/**
	 * getOrdersCustomerInverseLink
	 */
	private com.ibm.ws.ejbpersistence.associations.AssociationLink getOrdersCustomerInverseLink() {
		if (ordersCustomerInverseLink == null) 
		ordersCustomerInverseLink = instanceExtension.createLink("ordersCustomerInverse",dataCacheEntry.getOrdersCustomerInverseKey(),4);
		return ordersCustomerInverseLink;
	}
	private com.ibm.ws.ejbpersistence.associations.AssociationLink ordersCustomerInverseLink;
	/**
	 * ejbFindOrdersByOrdersCustomerInverseKey_Local
	 */
	public java.util.Collection ejbFindOrdersByOrdersCustomerInverseKey_Local(java.lang.Integer key) throws javax.ejb.FinderException {
		Object[] result = instanceExtension.getAssociatedKeys("ordersCustomerInverse",key);
		if (result!=null )  return (java.util.Collection) result[0];
		javax.resource.cci.IndexedRecord record = instanceExtension.getInputRecord("findOrdersByOrdersCustomerInverseKey_Local");
		getInjector().findOrdersByOrdersCustomerInverseKey_Local(key, record);
		return (java.util.Collection) instanceExtension.executeFind("findOrdersByOrdersCustomerInverseKey_Local", record);
	}
	/**
	 * refreshForeignKey
	 */
	public void refreshForeignKey() {
		if (ordersCustomerInverseLink != null) 
		dataCacheEntry.setOrdersCustomerInverseKey((java.lang.Integer) ordersCustomerInverseLink.getKey());
	}
	/**
	 * getOCCColumn
	 */
	public long getOCCColumn() {
		return dataCacheEntry.getOCCColumn();
	}
	/**
	 * Get accessor for persistent attribute: id
	 */
	public java.lang.Integer getId() {
		return dataCacheEntry.getId();
	}
	/**
	 * Set accessor for persistent attribute: id
	 */
	public void setId(java.lang.Integer newId) {
		if (instanceExtension.needValuesOnMarkDirty())
			instanceExtension.markDirty(0,getId(),newId);
		else
			instanceExtension.markDirty(0);
		dataCacheEntry.setId(newId);
	}
	/**
	 * Get accessor for persistent attribute: shipped
	 */
	public boolean getShipped() {
		return dataCacheEntry.getShipped();
	}
	/**
	 * Set accessor for persistent attribute: shipped
	 */
	public void setShipped(boolean newShipped) {
		if (instanceExtension.needValuesOnMarkDirty())
			instanceExtension.markDirty(1,getShipped(),newShipped);
		else
			instanceExtension.markDirty(1);
		dataCacheEntry.setShipped(newShipped);
	}
	/**
	 * Get accessor for persistent attribute: address
	 */
	public java.lang.String getAddress() {
		return dataCacheEntry.getAddress();
	}
	/**
	 * Set accessor for persistent attribute: address
	 */
	public void setAddress(java.lang.String newAddress) {
		if (instanceExtension.needValuesOnMarkDirty())
			instanceExtension.markDirty(2,getAddress(),newAddress);
		else
			instanceExtension.markDirty(2);
		dataCacheEntry.setAddress(newAddress);
	}
	/**
	 * Get accessor for persistent attribute: ordersCustomerInverse_id
	 */
	public java.lang.Integer getOrdersCustomerInverse_id() {
		return dataCacheEntry.getOrdersCustomerInverse_id();
	}
	/**
	 * Set accessor for persistent attribute: ordersCustomerInverse_id
	 */
	public void setOrdersCustomerInverse_id(java.lang.Integer newOrdersCustomerInverse_id) {
		if (instanceExtension.needValuesOnMarkDirty())
			instanceExtension.markDirty(3,getOrdersCustomerInverse_id(),newOrdersCustomerInverse_id);
		else
			instanceExtension.markDirty(3);
		dataCacheEntry.setOrdersCustomerInverse_id(newOrdersCustomerInverse_id);
	}
}
