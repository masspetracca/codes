package by.iba.rad257.ejb;
/**
 * Local Home interface for Enterprise Bean: Customer
 */
public interface CustomerLocalHome extends javax.ejb.EJBLocalHome {
    /**
     * Creates an instance from a key for Entity Bean: Customer
     */
    public by.iba.rad257.ejb.CustomerLocal create(java.lang.Integer id) throws javax.ejb.CreateException;
    /**
     * Finds an instance using a key for Entity Bean: Customer
     */
    public by.iba.rad257.ejb.CustomerLocal findByPrimaryKey(java.lang.Integer primaryKey) throws javax.ejb.FinderException;
}
