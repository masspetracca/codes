package by.iba.rad257.ejb.websphere_deploy;

/**
 * Internal Home interface for Enterprise Bean: Customer
 */
public interface CustomerBeanInternalHome_7dd938c7 extends javax.ejb.EJBHome {
}
