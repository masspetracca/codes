package by.iba.rad257.ejb.websphere_deploy.CLOUDSCAPE_V51_1;

/**
 * OrderBeanExtractor_b5c19525
 */
public class OrderBeanExtractor_b5c19525 extends com.ibm.ws.ejbpersistence.dataaccess.AbstractEJBExtractor {
	/**
	 * OrderBeanExtractor_b5c19525
	 */
	public OrderBeanExtractor_b5c19525() {
		int[] pkCols={1};
		setPrimaryKeyColumns(pkCols);

		int[] dataCols={1,2,3,4};
		setDataColumns(dataCols);
	}
	/**
	 * extractData
	 */
	public com.ibm.ws.ejbpersistence.cache.DataCacheEntry extractData(com.ibm.ws.ejbpersistence.dataaccess.RawBeanData dataRow) throws com.ibm.ws.ejbpersistence.utilpm.ErrorProcessingResultCollectionRow, com.ibm.ws.ejbpersistence.utilpm.PersistenceManagerInternalError {
		int[] dataColumns = getDataColumns();

		by.iba.rad257.ejb.websphere_deploy.CLOUDSCAPE_V51_1.OrderBeanCacheEntryImpl_b5c19525 entry=
			(by.iba.rad257.ejb.websphere_deploy.CLOUDSCAPE_V51_1.OrderBeanCacheEntryImpl_b5c19525) createDataCacheEntry();

		entry.setDataForID(dataRow.getInt(dataColumns[0]), dataRow.wasNull());
		entry.setDataForSHIPPED(dataRow.getByte(dataColumns[1])==1);
		entry.setDataForADDRESS(dataRow.getString(dataColumns[2]));
		entry.setDataForORDERSCUSTOMERINVERSE_ID(dataRow.getInt(dataColumns[3]), dataRow.wasNull());

		return entry;
	}
	/**
	 * extractPrimaryKey
	 */
	public Object extractPrimaryKey(com.ibm.ws.ejbpersistence.dataaccess.RawBeanData dataRow) throws com.ibm.ws.ejbpersistence.utilpm.ErrorProcessingResultCollectionRow, com.ibm.ws.ejbpersistence.utilpm.PersistenceManagerInternalError {
		int[] primaryKeyColumns = getPrimaryKeyColumns();

		java.lang.Integer key;
		key=new Integer(dataRow.getInt(primaryKeyColumns[0]));

		return key;
	}
	/**
	 * getHomeName
	 */
	public String getHomeName() {
		return "Order";
	}
	/**
	 * getChunkLength
	 */
	public int getChunkLength() {
		return 4;
	}
	/**
	 * createDataCacheEntry
	 */
	public com.ibm.ws.ejbpersistence.cache.DataCacheEntry createDataCacheEntry() {
		return new by.iba.rad257.ejb.websphere_deploy.CLOUDSCAPE_V51_1.OrderBeanCacheEntryImpl_b5c19525();
	}
}
