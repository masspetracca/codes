package by.iba.rad257.ejb.websphere_deploy;

/**
 * Internal Home interface for Enterprise Bean: Order
 */
public interface OrderBeanInternalHome_b5c19525 extends javax.ejb.EJBHome {
}
