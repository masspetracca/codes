package by.iba.rad257.ejb.websphere_deploy.CLOUDSCAPE_V51_1;

import java.util.ArrayList;
import java.util.List;
import com.ibm.ws.ejbdeploy.JChapter2EJB.CLOUDSCAPE_V51_1.RdbRuntimeUpdateTemplate;

/**
 * CustomerBeanPartialUpdateQueryHelper
 */
public class CustomerBeanPartialUpdateQueryHelper {
	/**
	 * getUpdateTemplates
	 */
	static java.util.List getUpdateTemplates() {
		java.util.List result = new java.util.ArrayList(1);
		{
			String[] assignmentColumns = {"NAME = ?, "};
			boolean isNullablePredicates = false;
			RdbRuntimeUpdateTemplate aTemplate0 = new RdbRuntimeUpdateTemplate(" UPDATE CUSTOMER SET ", " WHERE ID = ? ", assignmentColumns,47, isNullablePredicates);
			int[] dirtyMap = {1};
			aTemplate0.cmpFieldMap(dirtyMap);
			result.add(aTemplate0);
		}
		 return result;
	}
}
