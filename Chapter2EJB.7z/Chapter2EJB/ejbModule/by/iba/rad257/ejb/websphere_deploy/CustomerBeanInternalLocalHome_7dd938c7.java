package by.iba.rad257.ejb.websphere_deploy;

/**
 * Internal Local Home interface for Enterprise Bean: Customer
 */
public interface CustomerBeanInternalLocalHome_7dd938c7 {
	/**
	 * findOrdersCustomerInverseByOrdersKey_Local
	 */
	public by.iba.rad257.ejb.CustomerLocal findOrdersCustomerInverseByOrdersKey_Local(java.lang.Integer key) throws javax.ejb.FinderException;
	/**
	 * findByPrimaryKeyForCMR
	 */
	public by.iba.rad257.ejb.CustomerLocal findByPrimaryKeyForCMR(java.lang.Integer key) throws javax.ejb.FinderException;
}
