package by.iba.rad257.ejb.websphere_deploy;

/**
 * Cache Entry interface for Enterprise Bean: Customer
 */
public interface CustomerBeanCacheEntry_7dd938c7 extends java.io.Serializable {
	/**
	 * getId
	 */
	public java.lang.Integer getId();
	/**
	 * setId
	 */
	public void setId(java.lang.Integer newId);
	/**
	 * getName
	 */
	public java.lang.String getName();
	/**
	 * setName
	 */
	public void setName(java.lang.String newName);
	/**
	 * getOCCColumn
	 */
	public long getOCCColumn();
}
