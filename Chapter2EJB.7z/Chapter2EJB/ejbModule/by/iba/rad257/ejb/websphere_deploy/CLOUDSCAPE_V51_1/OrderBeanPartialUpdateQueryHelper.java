package by.iba.rad257.ejb.websphere_deploy.CLOUDSCAPE_V51_1;

import java.util.ArrayList;
import java.util.List;
import com.ibm.ws.ejbdeploy.JChapter2EJB.CLOUDSCAPE_V51_1.RdbRuntimeUpdateTemplate;

/**
 * OrderBeanPartialUpdateQueryHelper
 */
public class OrderBeanPartialUpdateQueryHelper {
	/**
	 * getUpdateTemplates
	 */
	static java.util.List getUpdateTemplates() {
		java.util.List result = new java.util.ArrayList(1);
		{
			String[] assignmentColumns = {"SHIPPED = ?, ","ADDRESS = ?, ","ORDERSCUSTOMERINVERSE_ID = ?, "};
			boolean isNullablePredicates = false;
			RdbRuntimeUpdateTemplate aTemplate0 = new RdbRuntimeUpdateTemplate(" UPDATE ORDER1 SET ", " WHERE ID = ? ", assignmentColumns,95, isNullablePredicates);
			String[] predicateColumns = {"SHIPPED"};
			aTemplate0.setPredicateColumns(predicateColumns,122);
			int[] dirtyMap = {1,2,4};
			aTemplate0.cmpFieldMap(dirtyMap);
			result.add(aTemplate0);
		}
		 return result;
	}
}
