package by.iba.rad257.ejb.websphere_deploy;

/**
 * Injector interface for Enterprise Bean: Customer
 */
public interface CustomerBeanInjector_7dd938c7 extends com.ibm.ws.ejbpersistence.beanextensions.EJBPartialInjector {
	/**
	 * findOrdersCustomerInverseByOrdersKey_Local
	 */
	public void findOrdersCustomerInverseByOrdersKey_Local(java.lang.Integer key, javax.resource.cci.IndexedRecord record);
}
