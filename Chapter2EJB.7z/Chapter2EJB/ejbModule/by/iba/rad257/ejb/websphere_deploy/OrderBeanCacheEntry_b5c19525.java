package by.iba.rad257.ejb.websphere_deploy;

/**
 * Cache Entry interface for Enterprise Bean: Order
 */
public interface OrderBeanCacheEntry_b5c19525 extends java.io.Serializable {
	/**
	 * getId
	 */
	public java.lang.Integer getId();
	/**
	 * setId
	 */
	public void setId(java.lang.Integer newId);
	/**
	 * getShipped
	 */
	public boolean getShipped();
	/**
	 * setShipped
	 */
	public void setShipped(boolean newShipped);
	/**
	 * getAddress
	 */
	public java.lang.String getAddress();
	/**
	 * setAddress
	 */
	public void setAddress(java.lang.String newAddress);
	/**
	 * getOCCColumn
	 */
	public long getOCCColumn();
	/**
	 * getOrdersCustomerInverse_id
	 */
	public java.lang.Integer getOrdersCustomerInverse_id();
	/**
	 * setOrdersCustomerInverse_id
	 */
	public void setOrdersCustomerInverse_id(java.lang.Integer newOrdersCustomerInverse_id);
	/**
	 * getOrdersCustomerInverseKey
	 */
	public java.lang.Integer getOrdersCustomerInverseKey();
	/**
	 * setOrdersCustomerInverseKey
	 */
	public void setOrdersCustomerInverseKey(java.lang.Integer newOrdersCustomerInverseKey);
}
