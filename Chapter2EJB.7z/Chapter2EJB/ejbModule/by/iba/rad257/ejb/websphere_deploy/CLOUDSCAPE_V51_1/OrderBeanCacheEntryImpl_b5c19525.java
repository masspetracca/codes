package by.iba.rad257.ejb.websphere_deploy.CLOUDSCAPE_V51_1;

/**
 * OrderBeanCacheEntryImpl_b5c19525
 */
public class OrderBeanCacheEntryImpl_b5c19525 extends com.ibm.ws.ejbpersistence.cache.DataCacheEntry implements by.iba.rad257.ejb.websphere_deploy.OrderBeanCacheEntry_b5c19525 {
	/**
	 * getId
	 */
	public java.lang.Integer getId() {
		if(ID_IsNull)
			return null;
		else
			return new Integer(ID_Data);
	}
	/**
	 * setId
	 */
	public void setId(Integer data) {
		if (data == null)
			this.ID_IsNull= true;
		else {
			this.ID_IsNull= false;
			this.ID_Data=data.intValue(); }
	}
	/**
	 * setDataForID
	 */
	public void setDataForID(int data, boolean isNull) {
		this.ID_Data=data;
		this.ID_IsNull=isNull;
	}
	private int ID_Data;
	private boolean ID_IsNull = true;
	/**
	 * getShipped
	 */
	public boolean getShipped() {
		return SHIPPED_Data;
	}
	/**
	 * setShipped
	 */
	public void setShipped(boolean data) {
		this.SHIPPED_Data=data;
	}
	/**
	 * setDataForSHIPPED
	 */
	public void setDataForSHIPPED(boolean data) {
		this.SHIPPED_Data=data;
	}
	private boolean SHIPPED_Data;
	/**
	 * getAddress
	 */
	public java.lang.String getAddress() {
		return ADDRESS_Data;
	}
	/**
	 * setAddress
	 */
	public void setAddress(String data) {
		this.ADDRESS_Data=data;
	}
	/**
	 * setDataForADDRESS
	 */
	public void setDataForADDRESS(String data) {
		this.ADDRESS_Data=data;
	}
	private String ADDRESS_Data;
	/**
	 * getOrdersCustomerInverse_id
	 */
	public java.lang.Integer getOrdersCustomerInverse_id() {
		if(ORDERSCUSTOMERINVERSE_ID_IsNull)
			return null;
		else
			return new Integer(ORDERSCUSTOMERINVERSE_ID_Data);
	}
	/**
	 * setOrdersCustomerInverse_id
	 */
	public void setOrdersCustomerInverse_id(Integer data) {
		if (data == null)
			this.ORDERSCUSTOMERINVERSE_ID_IsNull= true;
		else {
			this.ORDERSCUSTOMERINVERSE_ID_IsNull= false;
			this.ORDERSCUSTOMERINVERSE_ID_Data=data.intValue(); }
	}
	/**
	 * setDataForORDERSCUSTOMERINVERSE_ID
	 */
	public void setDataForORDERSCUSTOMERINVERSE_ID(int data, boolean isNull) {
		this.ORDERSCUSTOMERINVERSE_ID_Data=data;
		this.ORDERSCUSTOMERINVERSE_ID_IsNull=isNull;
	}
	private int ORDERSCUSTOMERINVERSE_ID_Data;
	private boolean ORDERSCUSTOMERINVERSE_ID_IsNull = true;
	/**
	 * getOCCColumn
	 */
	public long getOCCColumn() {
		return 0;
	}
	/**
	 * getOrdersCustomerInverseKey
	 */
	public java.lang.Integer getOrdersCustomerInverseKey() {
		if(ORDERSCUSTOMERINVERSE_ID_IsNull)
			return null;
		else
			return new Integer(ORDERSCUSTOMERINVERSE_ID_Data);
	}
	/**
	 * setOrdersCustomerInverseKey
	 */
	public void setOrdersCustomerInverseKey(java.lang.Integer data) {
		if (data == null)
			ORDERSCUSTOMERINVERSE_ID_IsNull= true;
		else {
			ORDERSCUSTOMERINVERSE_ID_IsNull= false;
			this.ORDERSCUSTOMERINVERSE_ID_Data=data.intValue(); }
	}
	/**
	 * getForeignKey
	 */
	public Object getForeignKey(String role) {
		if(role.equals("ordersCustomerInverse"))
			return getOrdersCustomerInverseKey();
		else
			return null;
	}
}
