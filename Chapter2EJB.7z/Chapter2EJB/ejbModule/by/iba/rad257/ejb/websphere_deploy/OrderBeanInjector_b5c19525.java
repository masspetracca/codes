package by.iba.rad257.ejb.websphere_deploy;

/**
 * Injector interface for Enterprise Bean: Order
 */
public interface OrderBeanInjector_b5c19525 extends com.ibm.ws.ejbpersistence.beanextensions.EJBPartialInjector {
	/**
	 * findOrdersByOrdersCustomerInverseKey_Local
	 */
	public void findOrdersByOrdersCustomerInverseKey_Local(java.lang.Integer key, javax.resource.cci.IndexedRecord record);
}
