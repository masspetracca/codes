package by.iba.rad257.ejb.websphere_deploy.CLOUDSCAPE_V51_1;

/**
 * OrderBeanInjectorImpl_b5c19525
 */
public class OrderBeanInjectorImpl_b5c19525 implements by.iba.rad257.ejb.websphere_deploy.OrderBeanInjector_b5c19525 {
	/**
	 * ejbCreate
	 */
	public void ejbCreate(com.ibm.ws.ejbpersistence.beanextensions.ConcreteBean cb, javax.resource.cci.IndexedRecord record) {
		by.iba.rad257.ejb.ConcreteOrder_b5c19525 concreteBean=(by.iba.rad257.ejb.ConcreteOrder_b5c19525)cb;
		record.set(0,concreteBean.getId());
		record.set(1,new Boolean(concreteBean.getShipped()));
		record.set(2,concreteBean.getAddress());
		record.set(3,concreteBean.getOrdersCustomerInverseKey());
	}
	/**
	 * ejbStore
	 */
	public void ejbStore(com.ibm.ws.ejbpersistence.beanextensions.ConcreteBean cb, javax.resource.cci.IndexedRecord record) {
		by.iba.rad257.ejb.ConcreteOrder_b5c19525 concreteBean=(by.iba.rad257.ejb.ConcreteOrder_b5c19525)cb;
		record.set(0,concreteBean.getId());
		record.set(1,new Boolean(concreteBean.getShipped()));
		record.set(2,concreteBean.getAddress());
		record.set(3,concreteBean.getOrdersCustomerInverseKey());
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove(com.ibm.ws.ejbpersistence.beanextensions.ConcreteBean cb, javax.resource.cci.IndexedRecord record) {
		by.iba.rad257.ejb.ConcreteOrder_b5c19525 concreteBean=(by.iba.rad257.ejb.ConcreteOrder_b5c19525)cb;
		record.set(0,concreteBean.getId());
	}
	/**
	 * ejbFindByPrimaryKey
	 */
	public void ejbFindByPrimaryKey(Object pkeyObject, javax.resource.cci.IndexedRecord record) {
		java.lang.Integer pkey=(java.lang.Integer)pkeyObject;
		record.set(0,pkey);
	}
	/**
	 * findOrdersByOrdersCustomerInverseKey_Local
	 */
	public void findOrdersByOrdersCustomerInverseKey_Local(java.lang.Integer fkey, javax.resource.cci.IndexedRecord record) {
		record.set(0,fkey);
	}
	/**
	 * readReadChecking
	 */
	public void readReadChecking(com.ibm.ws.ejbpersistence.beanextensions.ConcreteBean cb, javax.resource.cci.IndexedRecord record) {
		by.iba.rad257.ejb.ConcreteOrder_b5c19525 concreteBean=(by.iba.rad257.ejb.ConcreteOrder_b5c19525)cb;
		record.set(0,concreteBean.getId());
		record.set(1,new Boolean(concreteBean.getShipped()));
	}
	/**
	 * ejbPartialStore
	 */
	public void ejbPartialStore(com.ibm.ws.ejbpersistence.beanextensions.ConcreteBean cb, javax.resource.cci.IndexedRecord record) {
		by.iba.rad257.ejb.ConcreteOrder_b5c19525 concreteBean=(by.iba.rad257.ejb.ConcreteOrder_b5c19525)cb;
		com.ibm.ws.ejbpersistence.beanextensions.ConcreteBeanInstanceExtension  instanceExtension = (com.ibm.ws.ejbpersistence.beanextensions.ConcreteBeanInstanceExtension)concreteBean._WSCB_getInstanceInfo();
		 
		record.set(0,concreteBean.getId());
		if(instanceExtension.isDirty(1))
		{
			record.set(1,new Boolean(concreteBean.getShipped()));
		}
		if(instanceExtension.isDirty(2))
		{
			record.set(2,concreteBean.getAddress());
		}
		if(instanceExtension.isDirty(4))
		{
			record.set(3,concreteBean.getOrdersCustomerInverseKey());
		}
	}
	/**
	 * ejbStoreGetDirtyColumnFields
	 */
	public void ejbStoreGetDirtyColumnFields(com.ibm.ws.ejbpersistence.beanextensions.ConcreteBean cb, boolean[] dirtyBitmap) {
		
	}
}
