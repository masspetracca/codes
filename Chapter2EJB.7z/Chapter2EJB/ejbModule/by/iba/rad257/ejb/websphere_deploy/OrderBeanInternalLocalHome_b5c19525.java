package by.iba.rad257.ejb.websphere_deploy;

/**
 * Internal Local Home interface for Enterprise Bean: Order
 */
public interface OrderBeanInternalLocalHome_b5c19525 {
	/**
	 * findOrdersByOrdersCustomerInverseKey_Local
	 */
	public java.util.Collection findOrdersByOrdersCustomerInverseKey_Local(java.lang.Integer key) throws javax.ejb.FinderException;
}
