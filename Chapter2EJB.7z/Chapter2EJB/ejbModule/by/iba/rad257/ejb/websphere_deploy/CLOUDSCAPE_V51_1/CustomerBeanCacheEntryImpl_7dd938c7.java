package by.iba.rad257.ejb.websphere_deploy.CLOUDSCAPE_V51_1;

/**
 * CustomerBeanCacheEntryImpl_7dd938c7
 */
public class CustomerBeanCacheEntryImpl_7dd938c7 extends com.ibm.ws.ejbpersistence.cache.DataCacheEntry implements by.iba.rad257.ejb.websphere_deploy.CustomerBeanCacheEntry_7dd938c7 {
	/**
	 * getId
	 */
	public java.lang.Integer getId() {
		if(ID_IsNull)
			return null;
		else
			return new Integer(ID_Data);
	}
	/**
	 * setId
	 */
	public void setId(Integer data) {
		if (data == null)
			this.ID_IsNull= true;
		else {
			this.ID_IsNull= false;
			this.ID_Data=data.intValue(); }
	}
	/**
	 * setDataForID
	 */
	public void setDataForID(int data, boolean isNull) {
		this.ID_Data=data;
		this.ID_IsNull=isNull;
	}
	private int ID_Data;
	private boolean ID_IsNull = true;
	/**
	 * getName
	 */
	public java.lang.String getName() {
		return NAME_Data;
	}
	/**
	 * setName
	 */
	public void setName(String data) {
		this.NAME_Data=data;
	}
	/**
	 * setDataForNAME
	 */
	public void setDataForNAME(String data) {
		this.NAME_Data=data;
	}
	private String NAME_Data;
	/**
	 * getOCCColumn
	 */
	public long getOCCColumn() {
		return 0;
	}
}
