package by.iba.rad257.ejb.websphere_deploy.CLOUDSCAPE_V51_1;

/**
 * CustomerBeanExtractor_7dd938c7
 */
public class CustomerBeanExtractor_7dd938c7 extends com.ibm.ws.ejbpersistence.dataaccess.AbstractEJBExtractor {
	/**
	 * CustomerBeanExtractor_7dd938c7
	 */
	public CustomerBeanExtractor_7dd938c7() {
		int[] pkCols={1};
		setPrimaryKeyColumns(pkCols);

		int[] dataCols={1,2};
		setDataColumns(dataCols);
	}
	/**
	 * extractData
	 */
	public com.ibm.ws.ejbpersistence.cache.DataCacheEntry extractData(com.ibm.ws.ejbpersistence.dataaccess.RawBeanData dataRow) throws com.ibm.ws.ejbpersistence.utilpm.ErrorProcessingResultCollectionRow, com.ibm.ws.ejbpersistence.utilpm.PersistenceManagerInternalError {
		int[] dataColumns = getDataColumns();

		by.iba.rad257.ejb.websphere_deploy.CLOUDSCAPE_V51_1.CustomerBeanCacheEntryImpl_7dd938c7 entry=
			(by.iba.rad257.ejb.websphere_deploy.CLOUDSCAPE_V51_1.CustomerBeanCacheEntryImpl_7dd938c7) createDataCacheEntry();

		entry.setDataForID(dataRow.getInt(dataColumns[0]), dataRow.wasNull());
		entry.setDataForNAME(dataRow.getString(dataColumns[1]));

		return entry;
	}
	/**
	 * extractPrimaryKey
	 */
	public Object extractPrimaryKey(com.ibm.ws.ejbpersistence.dataaccess.RawBeanData dataRow) throws com.ibm.ws.ejbpersistence.utilpm.ErrorProcessingResultCollectionRow, com.ibm.ws.ejbpersistence.utilpm.PersistenceManagerInternalError {
		int[] primaryKeyColumns = getPrimaryKeyColumns();

		java.lang.Integer key;
		key=new Integer(dataRow.getInt(primaryKeyColumns[0]));

		return key;
	}
	/**
	 * getHomeName
	 */
	public String getHomeName() {
		return "Customer";
	}
	/**
	 * getChunkLength
	 */
	public int getChunkLength() {
		return 2;
	}
	/**
	 * createDataCacheEntry
	 */
	public com.ibm.ws.ejbpersistence.cache.DataCacheEntry createDataCacheEntry() {
		return new by.iba.rad257.ejb.websphere_deploy.CLOUDSCAPE_V51_1.CustomerBeanCacheEntryImpl_7dd938c7();
	}
}
