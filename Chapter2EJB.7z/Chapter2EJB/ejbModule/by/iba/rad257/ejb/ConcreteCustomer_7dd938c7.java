package by.iba.rad257.ejb;

import com.ibm.ws.ejbpersistence.beanextensions.*;
import com.ibm.websphere.cpmi.*;
import by.iba.rad257.ejb.websphere_deploy.CustomerBeanCacheEntry_7dd938c7;

/**
 * Bean implementation class for Enterprise Bean: Customer
 */
public class ConcreteCustomer_7dd938c7 extends by.iba.rad257.ejb.CustomerBean implements javax.ejb.EntityBean, ConcreteBeanWithLink {
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		super.setEntityContext(ctx);
		instanceExtension.setEntityContext(ctx);
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		super.unsetEntityContext();
		instanceExtension.unsetEntityContext();
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
			super.ejbActivate();
			instanceExtension.ejbActivate();
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
		instanceExtension.ejbLoad();
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
		super.ejbPassivate();
		instanceExtension.ejbPassivate();
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
		super.ejbRemove();
		instanceExtension.ejbRemove();
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
		super.ejbStore();
		instanceExtension.ejbStore();
	}
	private ConcreteBeanInstanceExtension instanceExtension;
	private CustomerBeanCacheEntry_7dd938c7 dataCacheEntry;
	/**
	 * _WSCB_getInstanceInfo
	 */
	public PMConcreteBeanInstanceInfo _WSCB_getInstanceInfo() {
			return instanceExtension;
	}
	/**
	 * ConcreteCustomer_7dd938c7
	 */
	public ConcreteCustomer_7dd938c7() {
		super();
		instanceExtension = ConcreteBeanInstanceExtensionFactory.getInstance(this);
	}
	/**
	 * getInjector
	 */
	private by.iba.rad257.ejb.websphere_deploy.CustomerBeanInjector_7dd938c7 getInjector() {
		return (by.iba.rad257.ejb.websphere_deploy.CustomerBeanInjector_7dd938c7)instanceExtension.getInjector();
	}
	/**
	 * hydrate
	 */
	public void hydrate(Object inRecord) {
		dataCacheEntry = (by.iba.rad257.ejb.websphere_deploy.CustomerBeanCacheEntry_7dd938c7) inRecord;;
		super.ejbLoad();
	}
	/**
	 * resetCMP
	 */
	public void resetCMP() {
			dataCacheEntry = null;
	}
	/**
	 * resetCMR
	 */
	public void resetCMR() {
			ordersLink = null;
	}
	/**
	 * ejbFindByPrimaryKey
	 */
	public java.lang.Integer ejbFindByPrimaryKey(java.lang.Integer primaryKey) throws javax.ejb.FinderException {
		return (java.lang.Integer)instanceExtension.ejbFindByPrimaryKey(primaryKey);
	}
	/**
	 * ejbFindByPrimaryKey
	 */
	public Object ejbFindByPrimaryKey(java.lang.Object pk) throws javax.ejb.FinderException {
		return ejbFindByPrimaryKey((java.lang.Integer)pk);
	}
	/**
	 * ejbFindByPrimaryKeyForCMR_Local
	 */
	public java.lang.Integer ejbFindByPrimaryKeyForCMR_Local(java.lang.Integer pk) throws javax.ejb.FinderException {
		return (java.lang.Integer)instanceExtension.ejbFindByPrimaryKey(pk);
	}
	/**
	 * ejbCreate
	 */
	public java.lang.Integer ejbCreate(java.lang.Integer id) throws javax.ejb.CreateException {
		dataCacheEntry = (CustomerBeanCacheEntry_7dd938c7) instanceExtension.createDataCacheEntry();
		 super.ejbCreate(id);
		return (java.lang.Integer)instanceExtension.ejbCreate();
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(java.lang.Integer id) throws javax.ejb.CreateException {
		super.ejbPostCreate(id);
		instanceExtension.ejbPostCreate();
	}
	/**
	 * createPrimaryKey
	 */
	public Object createPrimaryKey() {
		return getId();
	}
	/**
	 * getNumberOfFields
	 */
	public int getNumberOfFields() {
		return 3;
	}
	/**
	 * getLink
	 */
	public com.ibm.ws.ejbpersistence.associations.AssociationLink getLink(java.lang.String name) {
		if (name.equals("orders")) return getOrdersLink();
		return null;
	}
	/**
	 * executeFinderForLink
	 */
	public java.lang.Object executeFinderForLink(java.lang.String name, java.lang.Object key) throws javax.ejb.FinderException {
		if (name.equals("orders")){
			by.iba.rad257.ejb.websphere_deploy.OrderBeanInternalLocalHome_b5c19525 home = (by.iba.rad257.ejb.websphere_deploy.OrderBeanInternalLocalHome_b5c19525)instanceExtension.getHomeForLink("orders");
		  return home.findOrdersByOrdersCustomerInverseKey_Local((java.lang.Integer)key);
		}
		return null;
	}
	/**
	 * getOrders
	 */
	public java.util.Collection getOrders() {
		return (java.util.Collection)getOrdersLink().getValue();
	}
	/**
	 * setOrders
	 */
	public void setOrders(java.util.Collection value) {
		getOrdersLink().setValue(value);
	}
	/**
	 * getOrdersLink
	 */
	private com.ibm.ws.ejbpersistence.associations.AssociationLink getOrdersLink() {
		if (ordersLink == null) 
		ordersLink = instanceExtension.createLink("orders",null,2);
		return ordersLink;
	}
	private com.ibm.ws.ejbpersistence.associations.AssociationLink ordersLink;
	/**
	 * ejbFindOrdersCustomerInverseByOrdersKey_Local
	 */
	public java.lang.Integer ejbFindOrdersCustomerInverseByOrdersKey_Local(java.lang.Integer key) throws javax.ejb.FinderException {
		Object[] result = instanceExtension.getAssociatedKeys("orders",key);
		if (result!=null )  return (java.lang.Integer) result[0];
		javax.resource.cci.IndexedRecord record = instanceExtension.getInputRecord("findOrdersCustomerInverseByOrdersKey_Local");
		getInjector().findOrdersCustomerInverseByOrdersKey_Local(key, record);
		return (java.lang.Integer) instanceExtension.executeFind("findOrdersCustomerInverseByOrdersKey_Local", record);
	}
	/**
	 * getOCCColumn
	 */
	public long getOCCColumn() {
		return dataCacheEntry.getOCCColumn();
	}
	/**
	 * Get accessor for persistent attribute: id
	 */
	public java.lang.Integer getId() {
		return dataCacheEntry.getId();
	}
	/**
	 * Set accessor for persistent attribute: id
	 */
	public void setId(java.lang.Integer newId) {
		if (instanceExtension.needValuesOnMarkDirty())
			instanceExtension.markDirty(0,getId(),newId);
		else
			instanceExtension.markDirty(0);
		dataCacheEntry.setId(newId);
	}
	/**
	 * Get accessor for persistent attribute: name
	 */
	public java.lang.String getName() {
		return dataCacheEntry.getName();
	}
	/**
	 * Set accessor for persistent attribute: name
	 */
	public void setName(java.lang.String newName) {
		if (instanceExtension.needValuesOnMarkDirty())
			instanceExtension.markDirty(1,getName(),newName);
		else
			instanceExtension.markDirty(1);
		dataCacheEntry.setName(newName);
	}
}
