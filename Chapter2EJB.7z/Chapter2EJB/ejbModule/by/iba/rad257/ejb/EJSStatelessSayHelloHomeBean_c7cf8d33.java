package by.iba.rad257.ejb;

import com.ibm.ejs.container.*;

/**
 * EJSStatelessSayHelloHomeBean_c7cf8d33
 */
public class EJSStatelessSayHelloHomeBean_c7cf8d33 extends EJSHome {
	/**
	 * EJSStatelessSayHelloHomeBean_c7cf8d33
	 */
	public EJSStatelessSayHelloHomeBean_c7cf8d33() throws java.rmi.RemoteException {
		super();	}
	/**
	 * create
	 */
	public by.iba.rad257.ejb.SayHello create() throws javax.ejb.CreateException, java.rmi.RemoteException {
BeanO beanO = null;
by.iba.rad257.ejb.SayHello result = null;
boolean createFailed = false;
try {
	result = (by.iba.rad257.ejb.SayHello) super.createWrapper(null);
}
catch (javax.ejb.CreateException ex) {
	createFailed = true;
	throw ex;
} catch (java.rmi.RemoteException ex) {
	createFailed = true;
	throw ex;
} catch (Throwable ex) {
	createFailed = true;
	throw new CreateFailureException(ex);
} finally {
	if (createFailed) {
		super.createFailure(beanO);
	}
}
return result;	}
}
