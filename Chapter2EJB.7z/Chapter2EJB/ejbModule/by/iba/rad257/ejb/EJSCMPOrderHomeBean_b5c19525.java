package by.iba.rad257.ejb;

import com.ibm.ejs.container.*;

/**
 * EJSCMPOrderHomeBean_b5c19525
 */
public class EJSCMPOrderHomeBean_b5c19525 extends EJSHome {
	/**
	 * EJSCMPOrderHomeBean_b5c19525
	 */
	public EJSCMPOrderHomeBean_b5c19525() throws java.rmi.RemoteException {
		super();	}
	/**
	 * findByPrimaryKey_Local
	 */
	public by.iba.rad257.ejb.OrderLocal findByPrimaryKey_Local(java.lang.Integer primaryKey) throws javax.ejb.FinderException, java.rmi.RemoteException {
		return (by.iba.rad257.ejb.OrderLocal)super.activateBean_Local(primaryKey);
	}
	/**
	 * create_Local
	 */
	public by.iba.rad257.ejb.OrderLocal create_Local(java.lang.Integer id) throws javax.ejb.CreateException, java.rmi.RemoteException {
		BeanO beanO = null;
		by.iba.rad257.ejb.OrderLocal result = null;
		boolean createFailed = false;
		boolean preCreateFlag = false;
		try {
			beanO = super.createBeanO();
			by.iba.rad257.ejb.OrderBean bean = (by.iba.rad257.ejb.OrderBean) beanO.getEnterpriseBean();
			preCreateFlag = super.preEjbCreate(beanO);
			bean.ejbCreate(id);
			Object ejsKey = keyFromBean(bean);
			result = (by.iba.rad257.ejb.OrderLocal) super.postCreate_Local(beanO, ejsKey, true);
			bean.ejbPostCreate(id);
			super.afterPostCreate(beanO, ejsKey);
		}
		catch (javax.ejb.CreateException ex) {
			createFailed = true;
			throw ex;
		} catch (java.rmi.RemoteException ex) {
			createFailed = true;
			throw ex;
		} catch (Throwable ex) {
			createFailed = true;
			throw new CreateFailureException(ex);
		} finally {
			if(preCreateFlag && !createFailed)
				super.afterPostCreateCompletion(beanO);
			if (createFailed) {
				super.createFailure(beanO);
			}
		}
		return result;
	}
	/**
	 * findOrdersByOrdersCustomerInverseKey_Local
	 */
	public java.util.Collection findOrdersByOrdersCustomerInverseKey_Local(java.lang.Integer key) throws javax.ejb.FinderException, java.rmi.RemoteException {
		java.util.Collection result = null;
		EntityBeanO beanO = null;

		try {
			beanO = super.getFinderEntityBeanO();
			by.iba.rad257.ejb.ConcreteOrder_b5c19525 bean = (by.iba.rad257.ejb.ConcreteOrder_b5c19525) beanO.getEnterpriseBean();
			java.util.Collection pKeys = bean.ejbFindOrdersByOrdersCustomerInverseKey_Local(key);
			result = super.getCMP20Collection_Local(pKeys);
			super.releaseFinderEntityBeanO(beanO);
			beanO = null;
		}
		catch (javax.ejb.FinderException finderEx) {
			super.releaseFinderEntityBeanO(beanO);
			beanO = null;
			throw finderEx;
		}
		finally {
			if (beanO != null )
				super.discardFinderEntityBeanO(beanO);
		}
		return result;
	}
	/**
	 * keyFromBean
	 */
	public Object keyFromBean(javax.ejb.EntityBean generalEJB) {
		by.iba.rad257.ejb.ConcreteOrder_b5c19525 tmpEJB = (by.iba.rad257.ejb.ConcreteOrder_b5c19525) generalEJB;
		return tmpEJB.getId();
	}
	/**
	 * keyFromFields
	 */
	public java.lang.Integer keyFromFields(java.lang.Integer f0) {
		return f0;
	}
}
