



public class Talker {

    public static void talk(Animal animal) {

        System.out.println(animal.makeNoise());

    }
    




}