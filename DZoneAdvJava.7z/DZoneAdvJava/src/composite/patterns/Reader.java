package composite.patterns;

public interface Reader {

    public void read(); 

}