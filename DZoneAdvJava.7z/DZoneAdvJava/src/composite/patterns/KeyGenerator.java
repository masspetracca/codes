package composite.patterns;

public final class KeyGenerator {

    private final String seed;

    public KeyGenerator(String seed) {

        this.seed = seed;

    }

    public CryptographicKey generate(CryptographicKey CryptoKey) {
		return CryptoKey;

        // ...Do some cryptographic work to generate the key...

    }

	public String getSeed() {
		return seed;
	}

}