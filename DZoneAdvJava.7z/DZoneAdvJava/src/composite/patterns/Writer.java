package composite.patterns;

public interface Writer {

    public void write(); 

}