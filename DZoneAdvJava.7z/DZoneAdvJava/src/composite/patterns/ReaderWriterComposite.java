package composite.patterns;

public class ReaderWriterComposite<T extends Reader & Writer> implements Reader, Writer {

    private final List<T> readerWriters;

    public WriterComposite(List<T> readerWriters) {

        this.readerWriters = readerWriters;

    }

    @Override

    public void write() {

        for (Writer writer: this.readerWriters) {

            writer.write(); 

        }

    }

    @Override

    public void read() {

        for (Reader reader: this.readerWriters) {

            reader.read(); 

        }

    }

}