package composite.patterns;

import java.util.List;

public class WriterComposite<T extends Writer> implements Writer {

    private final List<T> writers;

    public WriterComposite(List<T> writers) {

        this.writers = writer;

    }

    @Override

    public void write() {

        for (Writer writer: this.writers) {

            writer.write(); 

        }

    }

}