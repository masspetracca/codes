package composite.patterns;

public abstract class AbstractWriter {

    public abstract void write();

}