package composite.patterns;

public class File {

    public final String read(int bytes) {

        // Execute the read on the file system

        return "Some read data";

    }

    public final void write(String data) {

        // Execute the write to the file system

    }

}