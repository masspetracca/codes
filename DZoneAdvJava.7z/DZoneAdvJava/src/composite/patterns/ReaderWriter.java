package composite.patterns;

public interface ReaderWriter implements Reader, Writer {}
