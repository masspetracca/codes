package composite.patterns;

public class CryptographicKey {

}
