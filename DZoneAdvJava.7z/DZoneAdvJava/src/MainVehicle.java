
public class MainVehicle {

	public static void main(String[] args) {

		Vehicle originalVehicle = new Vehicle("Corvette");

		Vehicle clonedVehicle = originalVehicle.customClone();

		System.out.println("Cloned Vehicle#"+clonedVehicle.getModel());
		
		Vehicle cVehicle = (Vehicle) originalVehicle.customClone();

		System.out.println("(Vehicle)#"+cVehicle.getModel());
		
		Object cVehicle1 = originalVehicle.customClone();

		//System.out.println(cVehicle1.getModel()); // ERROR: getModel not a method of Object
		System.out.println("castVehicle#"+((Vehicle) cVehicle1).getModel()); 

	}

}
