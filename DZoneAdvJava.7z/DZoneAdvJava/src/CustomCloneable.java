public interface CustomCloneable {

    public Object customClone();

}