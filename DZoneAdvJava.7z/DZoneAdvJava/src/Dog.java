

public class Dog implements Animal {

    @Override

    public String makeNoise() {

        return "Woof";

    }

}