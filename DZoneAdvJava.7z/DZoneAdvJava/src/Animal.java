public interface Animal {

    public String makeNoise();

}
