package com.ibm.example.impl;

import javax.ejb.Local;
import javax.ejb.Stateless;

import com.ibm.example.EJBConverterLocal;

/**
 * Session Bean implementation class EJBConverter
 */
@Stateless
@Local(EJBConverterLocal.class)
public class EJBConverter implements EJBConverterLocal {
	
	public double convertToCelsius(double fahrenheit) {
		return (fahrenheit - 32) * (5 / 9d);
	}
	
	public double convertToFahrenheit(double celsius) {
		return celsius * (9 / 5d) + 32;
	}
}
