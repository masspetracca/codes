package base;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Page {
	
	public static WebDriver driver;
	public static TopNavigation topNav;
	
	public Page() {
		
		if(driver==null) {
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("profile.default_content_setting_values.notifications", 2);
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("--disable-extensions");
		options.addArguments("--disable-infobars");

		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\executables\\chromedriver.exe");
		driver = new ChromeDriver(options);
		//driver.get("https://www.google.com/");
		driver.get("https://accounts.google.com/signin/v2/identifier?hl=it&passive=true&continue=https%3A%2F%2Fwww.google.com%2F&flowName=GlifWebSignIn&flowEntry=ServiceLogin/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		topNav = new TopNavigation();
		}
		
	}

}
