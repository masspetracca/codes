<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-10-29T17:06:42</lastRun>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>0</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>61046c3e-1c79-4fde-acbb-8b707d059ed0</testSuiteGuid>
   <testCaseLink>
      <guid>8b7a538b-bacc-4a8d-a0c7-bb7fa9532293</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/Test Suite/RU08-NUC01-T01</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ba509621-69e6-48e1-9bc6-4c41a07fc003</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/Test Suite/RU08-NUC01-T02</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4472a58b-f969-4ba3-8a46-763fb97fdc1b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/Test Suite/RU08-NUC01-T03</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
