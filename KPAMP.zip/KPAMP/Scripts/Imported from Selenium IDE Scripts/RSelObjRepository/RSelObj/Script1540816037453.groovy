import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('')

WebUI.navigateToUrl('https://10.0.10.230:10044/PampWeb/login.jsp')

WebUI.setText(findTestObject('Object Repository/Page_CCG Portal/input_Username_j_username'), 'mpetracc')

WebUI.setText(findTestObject('Object Repository/Page_CCG Portal/input_Password_j_password'), '.mpetrac008')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_CCG Portal/input_Password_j_password'), 'YaVcYVjucopeeJ1hpyWlvw==')

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/input_Password_submitLabel'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/span_Risk Engine_isc_Jopen_ico'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/td_S.T. SLOIM Statistics'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/img_ST ID_isc_4V'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/div_Increase'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/td_Rank_headerButtonOver'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/img_Stress Test ID_isc_34'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/img_Stress Test ID_isc_34'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/img_Stress Test ID_isc_34'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/div_10174'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/img_Scenario_isc_3G'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/div_Increase'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/div_Show'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/span'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/span_1'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/b_Nome Cognomes profile'))

WebUI.click(findTestObject('Object Repository/Page_CCG Portal/font_Logout'))

