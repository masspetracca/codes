

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class EncryptPdfDocument {

    static String user = "user";
    static String owner = "owner";
    static String destination = "provaENCRYPT.pdf";

    public EncryptPdfDocument() throws FileNotFoundException, DocumentException {
    //public static void main(String... args) throws FileNotFoundException, DocumentException {

        Document document = new Document(PageSize.A4);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(destination));

        // secure pdf with password protection
        writer.setEncryption(
                user.getBytes(),
                owner.getBytes(),
                PdfWriter.ALLOW_COPY | PdfWriter.ALLOW_PRINTING,
                PdfWriter.ENCRYPTION_AES_256 | PdfWriter.DO_NOT_ENCRYPT_METADATA);

        document.open();
        document.add(new Paragraph("Secure Pdf with Password using iText"));
        document.close();

    }
}
