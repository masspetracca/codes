package it.ccg.test.collaudo.server.bus;

public class TestCollaudoQAEAO {

	public TestCollaudoQAEAO(int returnCode) {
		// TODO Auto-generated constructor stub
	}
	public TestCollaudoQAEAO() {
		// TODO Auto-generated constructor stub
	}
	public String getKeyId() {
		return keyId;
	}
	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}
	public String getKeyDate() {
		return keyDate;
	}
	public void setKeyDate(String keyDate) {
		this.keyDate = keyDate;
	}
	public String getKeyProg() {
		return keyProg;
	}
	public void setKeyProg(String keyProg) {
		this.keyProg = keyProg;
	}
	public String getkeyExtraFNM() {
		return keyExtraFNM;
	}
	public void setkeyExtraFNM(String keyExtraFNM) {
		this.keyExtraFNM = keyExtraFNM;	
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getNodeName() {
		return nodeName;
	}
	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}
	public String getNodeType() {
		return nodeType;
	}
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}
	public String getNodeValue() {
		return nodeValue;
	}
	public void setNodeValue(String nodeValue) {
		this.nodeValue = nodeValue;
	}
	public String getnodeChild() {
		return nodeChild;
	}
	public void setnodeChild(String nodeChild) {
		this.nodeChild = nodeChild;
	}
	public String getnodeChild1() {
		return nodeChild1;
	}
	public void setnodeChild1(String nodeChild1) {
		this.nodeChild1 = nodeChild1;
	}
	public String getnodeChild2() {
		return nodeChild2;
	}
	public void setnodeChild2(String nodeChild2) {
		this.nodeChild2 = nodeChild2;
	}
	public String getnodeChild3() {
		return nodeChild3;
	}
	public void setnodeChild3(String nodeChild3) {
		this.nodeChild3 = nodeChild3;
	}
	public String getnodeChild4() {
		return nodeChild4;
	}
	public void setnodeChild4(String nodeChild4) {
		this.nodeChild4 = nodeChild4;
	}
	public String getnodeChild5() {
		return nodeChild5;
	}
	public void setnodeChild5(String nodeChild5) {
		this.nodeChild5 = nodeChild5;
	}
	public String getnodeChild6() {
		return nodeChild6;
	}
	public void setnodeChild6(String nodeChild6) {
		this.nodeChild6 = nodeChild6;
	}
	public String getnodeChild7() {
		return nodeChild7;
	}
	public void setnodeChild7(String nodeChild7) {
		this.nodeChild7 = nodeChild7;
	}
	public String getnodeChild8() {
		return nodeChild8;
	}
	public void setnodeChild8(String nodeChild8) {
		this.nodeChild8 = nodeChild8;
	}
	public String getnodeChild9() {
		return nodeChild9;
	}
	public void setnodeChild9(String nodeChild9) {
		this.nodeChild9 = nodeChild9;
	}
	public String getnodeChild10() {
		return nodeChild10;
	}
	public void setnodeChild10(String nodeChild10) {
		this.nodeChild10 = nodeChild10;
	}
	
	public String getnodeChild11() {
		return nodeChild11;
	}
	public void setnodeChild11(String nodeChild11) {
		this.nodeChild11 = nodeChild11;
	}
	public String getnodeChild12() {
		return nodeChild12;
	}
	public void setnodeChild12(String nodeChild12) {
		this.nodeChild12 = nodeChild12;
	}
	public String getnodeChild13() {
		return nodeChild13;
	}
	public void setnodeChild13(String nodeChild13) {
		this.nodeChild13 = nodeChild13;
	}
	public String getnodeChild14() {
		return nodeChild14;
	}
	public void setnodeChild14(String nodeChild14) {
		this.nodeChild14 = nodeChild14;
	}
	public String getnodeChild15() {
		return nodeChild15;
	}
	public void setnodeChild15(String nodeChild15) {
		this.nodeChild15 = nodeChild15;
	}
	public String getnodeChild16() {
		return nodeChild16;
	}
	public void setnodeChild16(String nodeChild16) {
		this.nodeChild16 = nodeChild16;
	}
	public String getnodeChild17() {
		return nodeChild17;
	}
	public void setnodeChild17(String nodeChild17) {
		this.nodeChild17 = nodeChild17;
	}
	public String getnodeChild18() {
		return nodeChild18;
	}
	public void setnodeChild18(String nodeChild18) {
		this.nodeChild18 = nodeChild18;
	}
	public String getnodeChild19() {
		return nodeChild19;
	}
	public void setnodeChild19(String nodeChild19) {
		this.nodeChild19 = nodeChild19;
	}
	public String getnodeChild20() {
		return nodeChild20;
	}
	public void setnodeChild20(String nodeChild20) {
		this.nodeChild20 = nodeChild20;
	}

	
	public String getnodeChild21() {
		return nodeChild21;
	}
	public void setnodeChild21(String nodeChild21) {
		this.nodeChild21 = nodeChild21;
	}
	public String getnodeChild22() {
		return nodeChild22;
	}
	public void setnodeChild22(String nodeChild22) {
		this.nodeChild22 = nodeChild22;
	}
	public String getnodeChild23() {
		return nodeChild23;
	}
	public void setnodeChild23(String nodeChild23) {
		this.nodeChild23 = nodeChild23;
	}
	public String getnodeChild24() {
		return nodeChild24;
	}
	public void setnodeChild24(String nodeChild24) {
		this.nodeChild24 = nodeChild24;
	}
	public String getnodeChild25() {
		return nodeChild25;
	}
	public void setnodeChild25(String nodeChild25) {
		this.nodeChild25 = nodeChild25;
	}
	public String getnodeChild26() {
		return nodeChild26;
	}
	public void setnodeChild26(String nodeChild26) {
		this.nodeChild26 = nodeChild26;
	}
	public String getnodeChild27() {
		return nodeChild27;
	}
	public void setnodeChild27(String nodeChild27) {
		this.nodeChild27 = nodeChild27;
	}
	public String getnodeChild28() {
		return nodeChild28;
	}
	public void setnodeChild28(String nodeChild28) {
		this.nodeChild28 = nodeChild28;
	}
	public String getnodeChild29() {
		return nodeChild29;
	}
	public void setnodeChild29(String nodeChild29) {
		this.nodeChild29 = nodeChild29;
	}
	public String getnodeChild30() {
		return nodeChild30;
	}
	public void setnodeChild30(String nodeChild30) {
		this.nodeChild30 = nodeChild30;
	}

	
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String keyId;
	public String keyDate;
	public String keyProg;
	public String keyExtraFNM;
	public String status;
	public String nodeName;
	public String nodeType;
	public String nodeValue;
	public String nodeChild;
	public String nodeChild1;
	public String nodeChild2;
	public String nodeChild3;
	public String nodeChild4;
	public String nodeChild5;
	public String nodeChild6;
	public String nodeChild7;
	public String nodeChild8;
	public String nodeChild9;
	public String nodeChild10;
	public String nodeChild11;
	public String nodeChild12;
	public String nodeChild13;
	public String nodeChild14;
	public String nodeChild15;
	public String nodeChild16;
	public String nodeChild17;
	public String nodeChild18;
	public String nodeChild19;
	public String nodeChild20;
	public String nodeChild21;
	public String nodeChild22;
	public String nodeChild23;
	public String nodeChild24;
	public String nodeChild25;
	public String nodeChild26;
	public String nodeChild27;
	public String nodeChild28;
	public String nodeChild29;
	public String nodeChild30;
	public String action;
	public String note;

}
