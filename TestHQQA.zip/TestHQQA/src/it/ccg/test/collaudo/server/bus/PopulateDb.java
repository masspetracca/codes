package it.ccg.test.collaudo.server.bus;



import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

public class PopulateDb {
	
	//Table access keys
	private static String kArea = ""; 
	private static String kStato = ""; 
	private static String kFreq ="";
	private static String kTipo ="";

	private static String Tab_col0 = "KEYID";
	private static String Tab_col1 = "DATEID";
	private static String Tab_col2 = "PROGID";
	private static String Tab_col3 = "KEYFNM";
	private static String Tab_col4 = "STATUS";
	
	private static String Tab_col5 = "NODENAME";
	private static String Tab_col6 = "NODETYPE";

	private static String Tab_col7 = "CHILDNAME";
	private static String Tab_col8 = "CHILDNAME1";
	private static String Tab_col9 = "CHILDNAME2";
	private static String Tab_col10 = "CHILDNAME3";
	private static String Tab_col11 = "CHILDNAME4";
	private static String Tab_col12 = "CHILDNAME5";
	private static String Tab_col13 = "CHILDNAME6";
	private static String Tab_col14 = "CHILDNAME7";
	private static String Tab_col15 = "CHILDNAME8";
	private static String Tab_col16 = "CHILDNAME9";
	private static String Tab_col17 = "CHILDNAME10";
	private static String Tab_col18 = "CHILDNAME11";
	private static String Tab_col19 = "CHILDNAME12";
	private static String Tab_col20 = "CHILDNAME13";
	private static String Tab_col21 = "CHILDNAME14";
	private static String Tab_col22 = "CHILDNAME15";
	private static String Tab_col23 = "CHILDNAME16";
	private static String Tab_col24 = "CHILDNAME17";
	private static String Tab_col25 = "CHILDNAME18";
	private static String Tab_col26 = "CHILDNAME19";
	private static String Tab_col27 = "CHILDNAME20";
	private static String Tab_col28 = "CHILDNAME21";
	private static String Tab_col29 = "CHILDNAME22";
	private static String Tab_col30 = "CHILDNAME23";
	private static String Tab_col31 = "CHILDNAME24";
	private static String Tab_col32 = "CHILDNAME25";
	private static String Tab_col33 = "CHILDNAME26";
	private static String Tab_col34 = "CHILDNAME27";
	private static String Tab_col35 = "CHILDNAME28";
	private static String Tab_col36 = "CHILDNAME29";
	private static String Tab_col37 = "CHILDNAME30";
	private static String Tab_col38 = "NODEACTION";
	private static String Tab_col39 = "NODEVALUE";
	private static String Tab_col40 = "NOTE";
	private static String Tab_col41 = "";
	private static String TableName = PropertyFiles.getTabName1();

	private static String vcol3 = "";
	private static String vcol4 = "";
	private static String vcol5 = "";

	private static String sdate =null;
	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

//	private static String tabFreq ="";
	private int ctrIns;
//	private int ctrUpd;
 	private int returnCode = 0;
 	private static String sqlUpdate;
//	
//
//	private static Object rs;
	
	PreparedStatement st;
	private String sqlDelete;
	private int ctrDel;


	public PopulateDb(String keyDateData,String keyIdData, String keyProgData, String keyExtraFNM, String statusData, String nodeNameData , String nodeTypeData,  String childNameData,  String childNameData1,  String childNameData2,  String childNameData3,  String childNameData4,  String childNameData5,  String childNameData6,  String childNameData7,  String childNameData8,  String childNameData9,  String childNameData10
			, String childNameData11,  String childNameData12,  String childNameData13,  String childNameData14,  String childNameData15,  String childNameData16,  String childNameData17,  String childNameData18,  String childNameData19,  String childNameData20
			, String childNameData21,  String childNameData22,  String childNameData23,  String childNameData24,  String childNameData25,  String childNameData26,  String childNameData27,  String childNameData28,  String childNameData29,  String childNameData30
			, String actionData, String nodeValueData, String noteData) throws ClassNotFoundException, IOException, SQLException, IllegalAccessException, InstantiationException {
		
		
		//upate table
		       sqlUpdate= 
				"INSERT INTO "+TableName
				+"("
				+""+Tab_col0
				+", "+Tab_col1
				+", "+Tab_col2
				+", "+Tab_col3
				+", "+Tab_col4
				+", "+Tab_col5
				+", "+Tab_col6
				+", "+Tab_col7
				+", "+Tab_col8
				+", "+Tab_col9
				+", "+Tab_col10
				+", "+Tab_col11
				+", "+Tab_col12
				+", "+Tab_col13
				+", "+Tab_col14
				+", "+Tab_col15
				+", "+Tab_col16
				+", "+Tab_col17
				+", "+Tab_col18
				+", "+Tab_col19
				+", "+Tab_col20
				+", "+Tab_col21
				+", "+Tab_col22
				+", "+Tab_col23
				+", "+Tab_col24
				+", "+Tab_col25
				+", "+Tab_col26
				+", "+Tab_col27
				+", "+Tab_col28
				+", "+Tab_col29
				+", "+Tab_col30
				+", "+Tab_col31
				+", "+Tab_col32
				+", "+Tab_col33
				+", "+Tab_col34
				+", "+Tab_col35
				+", "+Tab_col36
				+", "+Tab_col37
				+", "+Tab_col38
				+", "+Tab_col39
				+", "+Tab_col40
				+") VALUES ("
				+"'"+keyDateData+"'" 
				+", '"+keyIdData.substring(0,keyIdData.length() )+"'" 				
				+",  "+keyProgData
				+",  "+keyExtraFNM
				+", '"+statusData+"'" 
				+", '"+nodeNameData+"'" 
				+", '"+nodeTypeData+"'" 
				+", '"+childNameData+"'" 
				+", '"+childNameData1+"'" 
				+", '"+childNameData2+"'" 
				+", '"+childNameData3+"'" 
				+", '"+childNameData4+"'" 
				+", '"+childNameData5+"'" 
				+", '"+childNameData6+"'" 
				+", '"+childNameData7+"'" 
				+", '"+childNameData8+"'" 
				+", '"+childNameData9+"'" 
				+", '"+childNameData10+"'" 
				+", '"+childNameData11+"'" 
				+", '"+childNameData12+"'" 
				+", '"+childNameData13+"'" 
				+", '"+childNameData14+"'" 
				+", '"+childNameData15+"'" 
				+", '"+childNameData16+"'" 
				+", '"+childNameData17+"'" 
				+", '"+childNameData18+"'" 
				+", '"+childNameData19+"'" 
				+", '"+childNameData20+"'" 
				+", '"+childNameData21+"'" 
				+", '"+childNameData22+"'" 
				+", '"+childNameData23+"'" 
				+", '"+childNameData24+"'" 
				+", '"+childNameData25+"'" 
				+", '"+childNameData26+"'" 
				+", '"+childNameData27+"'" 
				+", '"+childNameData28+"'" 
				+", '"+childNameData29+"'" 
				+", '"+childNameData30+"'" 
				+", '"+actionData+"'" 
				+", '"+nodeValueData+"'" 
				+", '"+noteData+"'" 
				+")"
				;

	    System.out.println(sqlUpdate);		
		++ctrIns;
		//setting upd parameters
		TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 
		upd.setSqlUpdate(sqlUpdate);	
}



	



}


	
		
							
   

