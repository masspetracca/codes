package com.ibm.was.wssample.sei.echo;



@javax.jws.WebService (endpointInterface="com.ibm.was.wssample.sei.echo.EchoServicePortType", targetNamespace="http://com/ibm/was/wssample/sei/echo/", serviceName="EchoService", portName="EchoServicePort")
public class EchoSOAPImpl{

    public EchoStringResponse echoOperation(EchoStringInput parameter) {
        // TODO Auto-generated method stub
        return null;
    }

}