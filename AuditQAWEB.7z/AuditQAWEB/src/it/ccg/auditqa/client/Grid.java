package it.ccg.auditqa.client;


import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.widgets.form.FilterBuilder;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;

public class Grid extends ListGrid {
	
	final FilterBuilder advancedFilter = new FilterBuilder();  

	public Grid() {
		super();
		
		DataSource pampqa = DataSource.get("auditqa");
		this.setDataSource(pampqa);
		
		this.setFetchOperation("fetch_all");
		this.setAutoFetchData(true);
		
		this.setCanEdit(true);
		this.setEditEvent(ListGridEditEvent.DOUBLECLICK);  
		this.setModalEditing(true);
		this.setShowFilterEditor(true); 
		this.setCanRemoveRecords(true);

		ListGrid grid = new ListGrid();
		
		ListGridField id = new ListGridField("MAID", 120);
		id.setAttribute("title", "Id");
		ListGridField proj = new ListGridField("MAPRO", 120);
		proj.setAttribute("title", "Project");
		ListGridField vers = new ListGridField("MAVERS", 120);
		vers.setAttribute("title", "Version");
		ListGridField tick = new ListGridField("MATICK", 120);
		tick.setAttribute("title", "Ticker");
		ListGridField repo = new ListGridField("MAREPO", 120);
		repo.setAttribute("title", "Reporter");
		ListGridField handle = new ListGridField("MAHAND", 120);
		handle.setAttribute("title", "Handler");
		ListGridField prio = new ListGridField("MAPRIO", 120);
		prio.setAttribute("title", "Priority");
		ListGridField seve = new ListGridField("MASEVE", 120);
		seve.setAttribute("title", "Severity");
		ListGridField repro = new ListGridField("MAREPR", 120);
		repro.setAttribute("title", "Reproducibility");
		ListGridField stat = new ListGridField("MASTAT", 120);
		stat.setAttribute("title", "Status");
		ListGridField resol = new ListGridField("MARESOL", 120);
		resol.setAttribute("title", "Resolution");
		ListGridField proje = new ListGridField("MADPROJ", 120);
		proje.setAttribute("title", "Projection");
		ListGridField cat = new ListGridField("MACAT", 120);
		cat.setAttribute("title", "Category");
		ListGridField dtsub = new ListGridField("MADTSUB", 120);
		dtsub.setAttribute("title", "DateSubmitted");
		ListGridField supd = new ListGridField("MALSUPD", 120);
		supd.setAttribute("title", "LastUpdated");
		ListGridField eta = new ListGridField("MAETA", 120);
		eta.setAttribute("title", "Eta");
		ListGridField views = new ListGridField("MAVIEST", 120);
		views.setAttribute("title", "ViewState");
		ListGridField summ = new ListGridField("MASUMM", 120);
		summ.setAttribute("title", "Summary");
		ListGridField duedt = new ListGridField("MADUED", 120);
		duedt.setAttribute("title", "DueDate");
		ListGridField desc = new ListGridField("MADESC", 120);
		desc.setAttribute("title", "Description");
 
       	
        this.setFields(
        		id, proj, vers, tick, repo, handle, prio
        		, seve, repro, stat, resol, proje, cat
        		, dtsub, supd, eta, views, summ, duedt, desc
        		);  
        grid.draw();
		}
		

}
