package it.ccg.auditqa.client;


import it.ccg.auditqa.client.Grid;
import it.ccg.auditqa.client.Layout;

import com.smartgwt.client.data.Record;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.TextAreaItem;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.SectionStackSection;
import com.smartgwt.client.widgets.layout.VLayout;

public class InsertSectionStackSection extends SectionStackSection {
	
	private Grid grid;
	
	public InsertSectionStackSection(Layout mainLayout) {
		super();
		
		this.grid = mainLayout.getListGrid();
		  
		// Insert form
        final DynamicForm insertForm = new DynamicForm();
        
        final TextAreaItem messageAreaItem = new TextAreaItem();  
        messageAreaItem.setTitle("Message");
        messageAreaItem.setWidth(400);
        messageAreaItem.setHeight(60);
        messageAreaItem.setRequired(true);
        
       
        insertForm.setItems(messageAreaItem
        		);
        
       // buttons
        final IButton insertButton = new IButton();
        insertButton.setTitle("Insert");
        insertButton.setHeight(25);
        insertButton.setWidth(60);
        insertButton.setAlign(Alignment.CENTER);
        insertButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				try {
            		Record record = new Record();
            		
                	record.setAttribute("TITLE", "null");
                	record.setAttribute("MAID", (Integer)messageAreaItem.getValue());
                   	record.setAttribute("MAVERS", (String)messageAreaItem.getValue());
                	record.setAttribute("MATICK", (String)messageAreaItem.getValue());
                	record.setAttribute("MAPRO", (String)messageAreaItem.getValue());
                	record.setAttribute("MAREPO", (String)messageAreaItem.getValue());
                   	record.setAttribute("MAHAND", (String)messageAreaItem.getValue());
                	record.setAttribute("MAPRIO", (String)messageAreaItem.getValue());
                   	record.setAttribute("MASEVE", (String)messageAreaItem.getValue());
                	record.setAttribute("MAREPR", (String)messageAreaItem.getValue());
                   	record.setAttribute("MARESOL", (String)messageAreaItem.getValue());
                	record.setAttribute("MADPROJ", (String)messageAreaItem.getValue());
                   	record.setAttribute("MACAT", (String)messageAreaItem.getValue());
                	record.setAttribute("MADTSUB", (String)messageAreaItem.getValue());
                   	record.setAttribute("MALSUPD", (String)messageAreaItem.getValue());
                	record.setAttribute("MAETA", (String)messageAreaItem.getValue());
                   	record.setAttribute("MAVIEST", (String)messageAreaItem.getValue());
                	record.setAttribute("MASUMM", (String)messageAreaItem.getValue());
                	record.setAttribute("MADUEDT", (String)messageAreaItem.getValue());
                   	record.setAttribute("MADESC", (String)messageAreaItem.getValue());
                
                	grid.addData(record);
                	
                	grid.redraw();
                	
                	insertForm.reset();
            	}
            	catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
        
        final IButton cancelButton = new IButton();
        cancelButton.setTitle("Cancel");
        cancelButton.setHeight(25);
        cancelButton.setWidth(60);
        cancelButton.setAlign(Alignment.CENTER);
        cancelButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				insertForm.reset();
				
			}
		});
        
        HLayout hLayout = new HLayout();  
        hLayout.setMembersMargin(15);
        hLayout.setAutoHeight();
        hLayout.setLayoutLeftMargin(360);
        hLayout.addMember(cancelButton);  
        hLayout.addMember(insertButton);
        
        // buttons       
        VLayout vLayout = new VLayout();
        vLayout.addMember(insertForm);
        vLayout.addMember(hLayout);
        
	}

}
