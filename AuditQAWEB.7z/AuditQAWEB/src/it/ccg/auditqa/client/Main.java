package it.ccg.auditqa.client;

import it.ccg.auditqa.client.Layout;

import com.google.gwt.core.client.EntryPoint;

public class Main implements EntryPoint {

	@Override
	public void onModuleLoad() {
		
		new Layout();
		
	}

}
