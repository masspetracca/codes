package it.ccg.auditqa.server.standalone;

import it.ccg.auditqa.server.standalone.TestRunnerDriverProperties;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import org.apache.commons.lang.ArrayUtils;

public class TestRunnerDriverProperties {
	
	
	private String branch;
	private String fileRoot;
	private String testRoot;
	private String[] files;
	private String httpTarget;
	private Integer httpPort;
	private Integer seleniumTimeout;
	private Boolean maximizeBrowser;
	private Boolean captureScreenshot;
	private Boolean saveMessages;
	private Boolean batchCommit;
	private String browser;
	private String batchLog;
	
	

	public static TestRunnerDriverProperties getInstace(String fileAbsolutePath) {
		
		TestRunnerDriverProperties instance = new TestRunnerDriverProperties();
		
		try {
			instance.loadFromFile(fileAbsolutePath);
		}
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
		return instance;
	}
	
	public static void setInstace(TestRunnerDriverProperties instance, String fileAbsolutePath) {
		
		try {
			instance.writeToFile(fileAbsolutePath);
		}
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}
	
	
	public TestRunnerDriverProperties() {
		// TODO Auto-generated constructor stub
	}
	
	
	private void loadFromFile(String fileAbsolutePath) throws Exception {
		
		// load from file
		Properties properties = new Properties();
		properties.load(new FileInputStream(fileAbsolutePath));
		
		this.branch = properties.getProperty("branch");
		this.fileRoot = properties.getProperty("fileRoot");
		this.testRoot = properties.getProperty("testRoot");
		this.files = (properties.getProperty("files") != null) ? properties.getProperty("files").split(",") : null;
		this.httpTarget = properties.getProperty("httpTarget");
		this.httpPort = (properties.getProperty("httpPort").trim().length() > 0) ? Integer.parseInt(properties.getProperty("httpPort")) : null;
		this.seleniumTimeout = (properties.getProperty("seleniumTimeout").length() > 0) ? Integer.parseInt(properties.getProperty("seleniumTimeout")) : null;
		this.maximizeBrowser = (properties.getProperty("maximizeBrowser").trim().length() > 0) ? Boolean.parseBoolean(properties.getProperty("maximizeBrowser")) : null;
		this.captureScreenshot = (properties.getProperty("captureScreenshot").trim().length() > 0) ? Boolean.parseBoolean(properties.getProperty("captureScreenshot")) : null;
		this.saveMessages = (properties.getProperty("saveMessages").trim().length() > 0) ? Boolean.parseBoolean(properties.getProperty("saveMessages")) : null;
		this.batchCommit = (properties.getProperty("batchCommit").trim().length() > 0) ? Boolean.parseBoolean(properties.getProperty("batchCommit")) : null;
		this.browser = properties.getProperty("browser");
		this.batchLog = properties.getProperty("batchLog");
		
	}
	
	private void writeToFile(String fileAbsolutePath) throws Exception {
		
		Properties prop = new Properties();
		//set the properties value
		prop.setProperty("branch", (this.branch != null) ? this.branch : "");
		prop.setProperty("fileRoot", (this.fileRoot != null) ? this.fileRoot: "");
		prop.setProperty("testRoot", (this.testRoot != null) ? this.testRoot: "");
		
		String arrayString = ArrayUtils.toString(this.files);
		prop.setProperty("files", (this.files != null) ? arrayString.substring(1, (arrayString.length() - 1)) : "");
		
		prop.setProperty("httpTarget", (this.httpTarget != null) ? this.httpTarget : "");
		prop.setProperty("httpPort", (this.httpPort != null) ? Integer.toString(this.httpPort) : "");
		prop.setProperty("seleniumTimeout", (this.seleniumTimeout != null) ? Integer.toString(this.seleniumTimeout) : "");
		prop.setProperty("maximizeBrowser", (this.maximizeBrowser != null) ? Boolean.toString(this.maximizeBrowser) : "");
		prop.setProperty("captureScreenshot", (this.captureScreenshot != null) ? Boolean.toString(this.captureScreenshot) : "");
		prop.setProperty("saveMessages", (this.saveMessages != null) ? Boolean.toString(this.saveMessages) : "");
		prop.setProperty("batchCommit", (this.batchCommit != null) ? Boolean.toString(this.batchCommit) : "");
		prop.setProperty("browser", (this.browser != null) ? this.browser : "");
		prop.setProperty("batchLog", (this.batchLog != null) ? this.batchLog : "");
		
		//save properties to file
		prop.store(new FileOutputStream(fileAbsolutePath), null);
	    
	}
	
	
	public boolean isValid() {
		
		boolean result = false;
		
		
		return result;
	}


	public String getBranch() {
		return branch;
	}

	public String getFileRoot() {
		return fileRoot;
	}

	public String getTestRoot() {
		return testRoot;
	}

	public String[] getFiles() {
		return files;
	}

	public String getHttpTarget() {
		return httpTarget;
	}

	public Integer getHttpPort() {
		return httpPort;
	}

	public Integer getSeleniumTimeout() {
		return seleniumTimeout;
	}

	public Boolean isMaximizeBrowser() {
		return maximizeBrowser;
	}

	public Boolean isCaptureScreenshot() {
		return captureScreenshot;
	}

	public Boolean isSaveMessages() {
		return saveMessages;
	}

	public Boolean isBatchCommit() {
		return batchCommit;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public void setFileRoot(String fileRoot) {
		this.fileRoot = fileRoot;
	}

	public void setTestRoot(String testRoot) {
		this.testRoot = testRoot;
	}

	public void setFiles(String[] files) {
		this.files = files;
	}

	public void setHttpTarget(String httpTarget) {
		this.httpTarget = httpTarget;
	}

	public void setHttpPort(Integer httpPort) {
		this.httpPort = httpPort;
	}

	public void setSeleniumTimeout(Integer seleniumTimeout) {
		this.seleniumTimeout = seleniumTimeout;
	}

	public void setMaximizeBrowser(Boolean maximizeBrowser) {
		this.maximizeBrowser = maximizeBrowser;
	}

	public void setCaptureScreenshot(Boolean captureScreenshot) {
		this.captureScreenshot = captureScreenshot;
	}

	public void setSaveMessages(Boolean saveMessages) {
		this.saveMessages = saveMessages;
	}

	public void setBatchCommit(Boolean batchCommit) {
		this.batchCommit = batchCommit;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public void setBatchLog(String batchLog) {
		this.batchLog = batchLog;
	}

	public String getBrowser() {
		return browser;
	}

	public String getBatchLog() {
		return batchLog;
	}
	
	
	
	@Override
	public String toString() {
		
		String output = new String();
		output += "[branch: " + this.branch + "\n" + 
				  "fileRoot: " + this.fileRoot + "\n" + 
				  "testRoot: " + this.testRoot + "\n" + 
				  "files: " + ArrayUtils.toString(this.files) + "\n" + 
				  "httpTarget: " + this.httpTarget + "\n" + 
				  "httpPort: " + this.httpPort + "\n" + 
				  "seleniumTimeout: " + this.seleniumTimeout + "\n" + 
				  "maximizeBrowser: " + this.maximizeBrowser + "\n" + 
				  "captureScreenshot: " + this.captureScreenshot + "\n" + 
				  "saveMessages: " + this.saveMessages + "\n" + 
				  "batchCommit: " + this.batchCommit + "\n" + 
				  "browser: " + this.browser + "\n" + 
				  "batchLog: " + this.batchLog + "]";
		
		
		
		return output;
	}

}
