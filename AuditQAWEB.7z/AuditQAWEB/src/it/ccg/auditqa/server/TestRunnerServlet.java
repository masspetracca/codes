package it.ccg.auditqa.server;



import it.ccg.auditqa.server.standalone.TestRunnerProcessor;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.ibm.websphere.validation.base.config.level51.requestmetricsvalidation_51_NLS;

/**
 * Servlet implementation class TestRunnerServlet
 */
public class TestRunnerServlet extends HttpServlet {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 5929790840078582514L;


	/**
     * @see HttpServlet#HttpServlet()
     */
    public TestRunnerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		throw new ServletException("Http GET request not allowed.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String _operationId = request.getParameter("_operationId");
		_operationId.equalsIgnoreCase("run"); 
			this.run(request, response);
	}
	
	private void run(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			String classCanonicalName = TestRunnerProcessor.class.getCanonicalName();
			//URL url = TestRunnerProcessor.class.getResource("TestRunnerProcessor.class");
			
			URL smartGwtPropsURL = Thread.currentThread().getContextClassLoader().getResource("server.properties");
			Properties smartGwtProps = new Properties();
			smartGwtProps.load(new FileInputStream(new File(smartGwtPropsURL.getFile())));
			
			String absoluteWebRoot = smartGwtProps.getProperty("webRoot");
			
			String classesAbsolutePath = absoluteWebRoot + "/WEB-INF/classes";
			String libAbsolutePath = absoluteWebRoot + "/WEB-INF/lib";
			
			// TODO: remove
			System.out.println("********");
			System.out.println(classCanonicalName);
			System.out.println(classesAbsolutePath);
			System.out.println("********");

			String classpath = libAbsolutePath + "\\*" + ";" + 
			   classesAbsolutePath + ";" + 
			   absoluteWebRoot + "\\qualityt\\" + ";" + 
			   "%JAVA_HOME%\\lib\\QALogAnalyzer.jar" + ";";

//old		
//			String classpath = libAbsolutePath + "\\*" + ";" + 
//							   classesAbsolutePath + ";" + 
//							   absoluteWebRoot + "\\qualitytest\\tools\\selenium" + ";" + 
//							   "%JAVA_HOME%\\lib\\tools.jar" + ";" + 
//							   "%JAVA_HOME%\\lib\\dt.jar" + ";" + 
//							   "C:\\workspace\\PampQA\\build\\classes"; //<< localhost
//							   //SystemProperties.getProperty("user.install.root") + "\\installedApps\\I65BD99F_PAMP_QA\\QualityTestEAR.ear\\QualityTestEJB.jar";
//			
//			

			String command = "java -cp \"" + classpath + "\" " + classCanonicalName + " " + "\"" ;
			
			System.out.println("Executing TestRunner in separate process. command: " + command);
			
			// Execute
			Process process = Runtime.getRuntime().exec(command);
			
			// Read output
			
			System.out.println("*** Output from TestRunner process - START ***");
			
			System.out.println("*** Output from TestRunner process - END ***");
			
			

			
		}
		catch(Exception e) {
			
			e.printStackTrace();
			
			response.setStatus(500);
		}
		
	}
	
	

	
	

}
