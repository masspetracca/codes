package cetaceo;

import acquatico.*;
import mammifero.*;

public interface Cetaceo extends Mammifero, Acquatico {
public boolean getPresenteInItalia();
}
