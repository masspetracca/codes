package main;

import animale.*;
import mammifero.*;
import acquatico.*;
import cetaceo.*;

public class Main {
  static void StampaSchedaMammifero(Mammifero m){
  
    System.out.println("ORDINE: " + m.getOrdine());
    System.out.println("GENERE: " + m.getGenere());
    System.out.println("SPECIE: " + m.getSpecie());
    System.out.println("CIBO PREFERITO: "+ m.getCiboPreferito());
    System.out.println("GESTAZIONE MESI: "+ m.getMesiDiGestazione());
  }

  static void StampaSchedaCetaceo(Cetaceo c){
    StampaSchedaMammifero(c);
    System.out.println("MAX % SALINITA' TOLLERATA : " +
                       (int)(c.getMaxSalinitaAcqua()*100));
    System.out.println("PRESENTE IN ITALIA: " +
                       (c.getPresenteInItalia()?"SI":"NO"));
    System.out.println("---------------------------------------------------- ");
  }

  public static void main(String[] args) {
    Cetaceo tursiope = new CetaceoIMP
      ("Tursiops", "truncatus", "pesce azzurro", 12, (float).05, true);
    Mammifero pippo = new MammiferoIMP
       ("Pippo", "topolino", "cibo", 9);
    System.out.println("==============      MUSEO DI RIO      ==============");
    System.out.println("****************  ****************  ****************");
    StampaSchedaMammifero(tursiope);
    StampaSchedaMammifero(pippo);  
  }
}
