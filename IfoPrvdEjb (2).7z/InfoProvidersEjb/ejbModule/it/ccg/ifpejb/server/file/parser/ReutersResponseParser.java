package it.ccg.ifpejb.server.file.parser;

import it.ccg.ifpejb.server.file.template.ReutersResponseTemplate;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class ReutersResponseParser {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	
	public ReutersResponseParser() throws Exception {
		
	}
	
	
	public ReutersResponseTemplate parse(File file) throws Exception {
		
		if(!file.exists()) {
			
			logger.error(new StandardLogMessage("File \'" + file.getAbsolutePath() + "\' not exists."));
			
			throw new Exception("File \'" + file.getAbsolutePath() + "\' not exists.");
		}
		
		ReutersResponseTemplate reutersResponseTemplate = null;
		BufferedReader br = null;
		try {
			// apro lo stream per leggere il file
			br = new BufferedReader(new FileReader(file));
			
			
			// salto la prima riga d'intestazione
			String line = br.readLine();
			line = br.readLine();
			
			List<Object[]> recordList = new ArrayList<Object[]>();
			
			while(line != null) {
				
				Object[] record = line.split(",");
				
				recordList.add(record);
				
				line = br.readLine();
			}
			
				
			br.close();
			
			reutersResponseTemplate = new ReutersResponseTemplate(recordList);
		}
		catch(Exception e) {
			logger.error(new StandardLogMessage(e.toString()));
			
			throw new Exception(e.toString());
		}
		finally {
			if(br != null) {
				br.close();
			}
		}
		
		return reutersResponseTemplate;
	}
	
	

}
