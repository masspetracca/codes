package it.ccg.ifpejb.server.file.parser;


import it.ccg.ifpejb.server.file.template.ReutersRequestTemplate;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class ReutersRequestParser {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	public ReutersRequestParser() throws Exception {
		
	}
	
	public ReutersRequestTemplate parse(File file) throws Exception {
		
		if(!file.exists()) {
			
			throw new Exception("File \'" + file.getAbsolutePath() + "\' not exists.");
		}
		
		List<String> instruments = new ArrayList<String>();
		
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(file);
			
			NodeList instrumentNodeList = document.getElementsByTagName("Identifier");
			
			for(int i=0; i<instrumentNodeList.getLength(); i++) {
				Node instrumentNode = instrumentNodeList.item(i);
				
				instruments.add(instrumentNode.getTextContent());
			}
			
		}
		catch(Exception e) {
			
			logger.error(new StandardLogMessage(e.toString()));
			
			throw new Exception(e.toString());
		}
		

		return new ReutersRequestTemplate(instruments);
	}
	
	
	
	
}
