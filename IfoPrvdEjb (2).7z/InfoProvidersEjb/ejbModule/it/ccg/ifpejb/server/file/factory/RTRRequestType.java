package it.ccg.ifpejb.server.file.factory;

public enum RTRRequestType {
	
	NIR_REQUEST,
	FUTCP_REQUEST;

}
