package it.ccg.ifpejb.server.ftp;

import it.ccg.ifpejb.server.exception.FTPException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.commons.net.ftp.FTPFile;

public interface FTPServiceInterface {
	
	public FTPFile getResponseFileInfo(String fileName) throws FTPException;
	public FTPFile[] getResponseFilesInfo() throws FTPException;
	
	public void downloadResponseFile(String fileName, File outputFile) throws FTPException;
	public void downloadRequestFile(String fileName, File outputFile) throws FTPException;
	public void uploadRequestFile(String fileName, File inputFile)throws FTPException;
	
	public boolean responseFileIsPresent(String fileName) throws FTPException;
	public boolean requestFileIsPresent(String fileName) throws FTPException;

}
