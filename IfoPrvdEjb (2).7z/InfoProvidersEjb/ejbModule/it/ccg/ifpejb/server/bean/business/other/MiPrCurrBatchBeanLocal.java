package it.ccg.ifpejb.server.bean.business.other;

public interface MiPrCurrBatchBeanLocal {
	
	public void syncCurrToMiPr() throws Exception;

}
