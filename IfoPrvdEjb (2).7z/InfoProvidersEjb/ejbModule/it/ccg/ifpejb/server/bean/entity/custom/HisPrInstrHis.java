package it.ccg.ifpejb.server.bean.entity.custom;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.*;


@Entity
public class HisPrInstrHis implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Transient
	private int priceDate;
	@Transient
	private BigDecimal closingPrice;
	

	public HisPrInstrHis() {
		
	}
	
	
	public HisPrInstrHis(int priceDate, BigDecimal closingPrice) {
		
		this.priceDate = priceDate;
		this.closingPrice = closingPrice;
	}


	
	public int getPriceDate() {
		return priceDate;
	}

	
	public void setPriceDate(int priceDate) {
		this.priceDate = priceDate;
	}

	
	public BigDecimal getClosingPrice() {
		return closingPrice;
	}

	
	public void setClosingPrice(BigDecimal closingPrice) {
		this.closingPrice = closingPrice;
	}
   
}
