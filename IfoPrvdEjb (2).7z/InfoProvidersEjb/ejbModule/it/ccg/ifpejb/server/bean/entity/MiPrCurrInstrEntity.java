package it.ccg.ifpejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the TF.FORX database table.
 * 
 */
@Entity
@Table(name="TF.FORX")
public class MiPrCurrInstrEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(nullable=false, precision=9)
	private BigDecimal feadd;

	@Column(nullable=false, precision=9)
	private BigDecimal fechg;

	@Column(name="\"FECSQ�\"", nullable=false, precision=3)
	private BigDecimal fecsq�;

	@Column(nullable=false, length=2)
	private String fecurr;

	@Column(nullable=false, length=40)
	private String fedesc;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal feerat;

	@Column(nullable=false, precision=7, scale=4)
	private BigDecimal feint;

    public MiPrCurrInstrEntity() {
    }

	public BigDecimal getFeadd() {
		return this.feadd;
	}

	public void setFeadd(BigDecimal feadd) {
		this.feadd = feadd;
	}

	public BigDecimal getFechg() {
		return this.fechg;
	}

	public void setFechg(BigDecimal fechg) {
		this.fechg = fechg;
	}

	public BigDecimal getFecsq�() {
		return this.fecsq�;
	}

	public void setFecsq�(BigDecimal fecsq�) {
		this.fecsq� = fecsq�;
	}

	public String getFecurr() {
		return this.fecurr;
	}

	public void setFecurr(String fecurr) {
		this.fecurr = fecurr;
	}

	public String getFedesc() {
		return this.fedesc;
	}

	public void setFedesc(String fedesc) {
		this.fedesc = fedesc;
	}

	public BigDecimal getFeerat() {
		return this.feerat;
	}

	public void setFeerat(BigDecimal feerat) {
		this.feerat = feerat;
	}

	public BigDecimal getFeint() {
		return this.feint;
	}

	public void setFeint(BigDecimal feint) {
		this.feint = feint;
	}

}