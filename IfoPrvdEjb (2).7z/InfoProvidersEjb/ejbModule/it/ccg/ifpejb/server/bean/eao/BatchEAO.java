package it.ccg.ifpejb.server.bean.eao;


import it.ccg.ifpejb.server.bean.entity.BatchEntity;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;

import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BatchEAO
 */
@SuppressWarnings("unchecked")
@Stateless(mappedName = "BatchEAO")
public class BatchEAO implements BatchEAOLocal {

	@PersistenceContext(unitName = "InfoProvidersEjb", type = PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Resource
	private SessionContext sessionContext;
	
	private String tableName = ((Table)(BatchEntity.class.getAnnotation(Table.class))).name();
	
	
    /**
     * Default constructor. 
     */
    public BatchEAO() throws Exception {
    	
    }

	@Override
	public List<BatchEntity> fetch() throws Exception {
		
		Query query = em.createNamedQuery("getAllBatches");
		List<BatchEntity> batchesList = (List<BatchEntity>)query.getResultList();
		
		return batchesList;
	}

	@Override
	public BatchEntity findByPrimaryKey(int batchID) throws Exception {
		
		return (BatchEntity)em.find(BatchEntity.class, batchID);
	}

	@Override
	public BatchEntity add(BatchEntity batchEntity) throws Exception {
		
		// set current user
		batchEntity.setUpdatingUser(this.sessionContext.getCallerPrincipal().getName());
		
		em.persist(batchEntity);
		
		
		logger.info(new StandardLogMessage("Persisted data into \'" + this.tableName + "\'. " + batchEntity));
		
		return batchEntity;
	}
	

	@Override
	public void update(BatchEntity batchEntity) throws Exception {
		
		throw new Exception("Update function not implemented.");
	}

	@Override
	public void remove(BatchEntity batchEntity) throws Exception {
		
		BatchEntity temp = findByPrimaryKey(batchEntity.getBatchId());
		
		em.remove(temp);
		
		
		logger.info(new StandardLogMessage("Deleted data into \'" + this.tableName + "\'. " + batchEntity));
	}



}
