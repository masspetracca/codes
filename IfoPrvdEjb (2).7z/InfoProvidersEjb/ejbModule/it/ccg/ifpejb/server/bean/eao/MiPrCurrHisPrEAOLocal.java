package it.ccg.ifpejb.server.bean.eao;

import it.ccg.ifpejb.server.bean.entity.MiPrCurrHisPrEntity;

import java.math.BigDecimal;

public interface MiPrCurrHisPrEAOLocal {
	
	public MiPrCurrHisPrEntity findByPrimaryKey(String paramString, BigDecimal paramBigDecimal) throws Exception;
	public void add(MiPrCurrHisPrEntity paramMiPrCurrHisPrEntity) throws Exception;
	
}

