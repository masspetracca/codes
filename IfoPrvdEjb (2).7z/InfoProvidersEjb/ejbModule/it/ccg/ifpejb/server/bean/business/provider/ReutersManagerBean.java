package it.ccg.ifpejb.server.bean.business.provider;


import it.ccg.ifpejb.server.bean.eao.InstrEAOLocal;
import it.ccg.ifpejb.server.bean.entity.InstrEntity;
import it.ccg.ifpejb.server.exception.ExceptionUtil;
import it.ccg.ifpejb.server.file.factory.RTRRequestType;
import it.ccg.ifpejb.server.file.factory.ReutersRequestFactory;
import it.ccg.ifpejb.server.file.parser.ReutersRequestParser;
import it.ccg.ifpejb.server.file.template.ReutersRequestTemplate;
import it.ccg.ifpejb.server.ftp.FTPFactory;
import it.ccg.ifpejb.server.ftp.FTPServiceInterface;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;
import it.ccg.ifpejb.server.providerengine.ProviderEngine;
import it.ccg.ifpejb.server.security.SecurityEjb;
import it.ccg.ifpejb.server.system.SystemProperties;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ReutersManagement
 */
@Stateless
public class ReutersManagerBean implements ReutersManagerBeanLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	private static final Logger monitorLogger = LoggerFactory.getLogger(LoggerFactory.MONITOR_LOGGER);
	
	
	private FTPServiceInterface ftpServiceInterface;
	
	
	@EJB
	private InstrEAOLocal instrumentsEAOLocal;
	
	@EJB
	private BaseBeanLocal baseBeanLocal;
	
	private static Properties properties;
	
	private static String TEMP_DIR_ABSOLUTE_PATH;
	
	private static String PROVIDER_NAME;
	private static String FLOW_NIR_NAME;
	private static String FLOW_FCP_NAME;
	private static String FLOW_COLL_NAME;
	private static String NIR_REQUEST_FILE_NAME;
	private static String FCP_REQUEST_FILE_NAME;
	private static String COLL_REQUEST_FILE_NAME;
	
	
	private static String PATH_SEPARATOR;
	

    /**
     * Default constructor. 
     */
    public ReutersManagerBean() throws Exception {
    	
    	try {
    		
    		properties = SystemProperties.getProperties();
        	
        	TEMP_DIR_ABSOLUTE_PATH = properties.getProperty("user.install.root") +
      	    						 properties.getProperty("ifp_temp_dir_relative_path");
        	
        	PATH_SEPARATOR = properties.getProperty("file.separator");
        	
        	// provider engine IDs from properties file
        	PROVIDER_NAME = properties.getProperty("provider.reuters.name");
        	
    	}
    	catch(Exception e) {
    		
    		logger.warn(new StandardLogMessage("Exception into bean constructor. Exception: " + e));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
    }
    
    
    @Override
    public void checkNirAlignment() throws Exception {

		try {
			
			FLOW_NIR_NAME = properties.getProperty("provider.reuters.flow.nir.name");
        	NIR_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_NIR_NAME).getRequestFileName();
        	
			
			logger.info(new StandardLogMessage("Reuters NIR request alignment check started."));
			
			
	    	boolean aligned = true;
			
			// computation START
			
			// local list
			List<InstrEntity> enabledInstrList = this.instrumentsEAOLocal.fetchEnabled("IRNODE", "Reuters");
			List<InstrEntity> oneShotInstrList = this.instrumentsEAOLocal.fetchOneShot("IRNODE", "Reuters");
			List<InstrEntity> tempList = new ArrayList<InstrEntity>();
			tempList.addAll(enabledInstrList);
			tempList.addAll(oneShotInstrList);
			List<String> localList = new ArrayList<String>();
			for(InstrEntity entity : tempList) {
				
				localList.add(entity.getReutersIdentifierCode());
			}
			
			// remote list
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.REUTERS_SERVICE);
			
			// create temporary folder and files to work
			String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + NIR_REQUEST_FILE_NAME;
			File file = new File(tempFileAbsPath);
			file.createNewFile();
			
			this.ftpServiceInterface.downloadRequestFile(NIR_REQUEST_FILE_NAME, file);
			
			ReutersRequestParser reutersRequestParser = new ReutersRequestParser();
			ReutersRequestTemplate reutersRequestTemplate = reutersRequestParser.parse(file);
			List<String> remoteInstrumentList = reutersRequestTemplate.getInstruments();
			
			
			// confronta
			
			// 
			for(String ricCode : localList) {
				if(!remoteInstrumentList.contains(ricCode)) {
					
					aligned = false;
					
					logger.warn(new StandardLogMessage("Reuters code \'" + ricCode + "\' enabled in local environment but not present in remote Node intrument list."));
				}
			}
			
			//
			for(String ricCode : remoteInstrumentList) {
				if(!localList.contains(ricCode)) {
					
					aligned = false;
					
					logger.warn(new StandardLogMessage("Reuters code \'" + ricCode + "\' present in remote Node intrument list but disabled in local environment."));
				}
			}
			
			
			// computation END
			
			if(aligned) {
				logger.info(new StandardLogMessage("Reuters NIR local and remote instrument lists aligned."));
				
				monitorLogger.info(new StandardLogMessage("Reuters NIR local and remote instrument lists aligned."));
			}
			else {
				logger.warn(new StandardLogMessage("Reuters NIR local and remote instrument lists not aligned."));
				
				monitorLogger.warn(new StandardLogMessage("Reuters NIR local and remote instrument lists not aligned. Read logs for details."));
			}
			
			
			// delete tempWorkingFolder
			//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
		}
		catch(Exception e) {
			// monitor error
			monitorLogger.error(new StandardLogMessage("Reuters NIR request alignment check failed."));
			// default logger
			logger.error(new StandardLogMessage("Reuters NIR request alignment check failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Reuters NIR request alignment check failed.");
		}
		
	}
    
    @Override
    public void alignNirRequest() throws Exception {
    	
    	try {
    		
    		FLOW_NIR_NAME = properties.getProperty("provider.reuters.flow.nir.name");
        	NIR_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_NIR_NAME).getRequestFileName();
        	
    		
    		logger.info(new StandardLogMessage("Reuters NIR request alignment started."));
    		
        	
    		List<InstrEntity> enabledInstrList = this.instrumentsEAOLocal.fetchEnabled("IRNODE","Reuters");
    		List<InstrEntity> oneShotInstrList = this.instrumentsEAOLocal.fetchOneShot("IRNODE","Reuters");
    		List<InstrEntity> instrList = new ArrayList<InstrEntity>();
    		instrList.addAll(enabledInstrList);
    		instrList.addAll(oneShotInstrList);
    		
    		
    		logger.info(new StandardLogMessage("Instrument list size: " + instrList.size()));
    		logger.info(new StandardLogMessage("Instrument list details: " + instrList));
    		
    		
    		// create temporary folder and files to work
    		String tempWorkingFolderName = SecurityEjb.getUniqueToken();
    		File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
    		if(!tempWorkingFolder.mkdir()) {
    			
    			throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
    		}
    		
    		String tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + NIR_REQUEST_FILE_NAME;
    		File fileToSaveInto = new File(tempFileAbsPath);
    		fileToSaveInto.createNewFile();
    		
    		ReutersRequestFactory reutersXMLRequestFactory = new ReutersRequestFactory();
    		reutersXMLRequestFactory.createRequestFile(RTRRequestType.NIR_REQUEST, fileToSaveInto, instrList);
    		
    		this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.REUTERS_SERVICE);
    		
    		this.ftpServiceInterface.uploadRequestFile(fileToSaveInto.getName(), fileToSaveInto);
    		
    		
    		monitorLogger.info(new StandardLogMessage("Reuters NIR request successfully aligned."));
    		logger.info(new StandardLogMessage("Reuters NIR request successfully aligned."));
    		
    		
    		// delete tempWorkingFolder
    		//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
    		
    	}
    	catch(Exception e) {
    		// monitor error
			monitorLogger.error(new StandardLogMessage("Reuters NIR request alignment failed."));
			// default logger
			logger.error(new StandardLogMessage("Reuters NIR request alignment failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Reuters NIR request alignment failed.");
    	}
    	
    }
    
    
    @Override
    public void checkFcpAlignment() throws Exception {
    	
    	try {
    		
    		FLOW_FCP_NAME = properties.getProperty("provider.reuters.flow.fcp.name");
        	FCP_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_FCP_NAME).getRequestFileName();
        	
        	
    		logger.info(new StandardLogMessage("Reuters FCP request alignment check started."));
    		
    		
	    	boolean aligned = true;
			
			// computation START
			
			// local list
			List<InstrEntity> enabledInstrList = this.instrumentsEAOLocal.fetchEnabled("F", "Reuters");
			List<InstrEntity> oneShotInstrList = this.instrumentsEAOLocal.fetchOneShot("F", "Reuters");
			List<InstrEntity> tempList = new ArrayList<InstrEntity>();
			tempList.addAll(enabledInstrList);
			tempList.addAll(oneShotInstrList);
			List<String> localList = new ArrayList<String>();
			for(InstrEntity entity : tempList) {
				
				localList.add(entity.getReutersIdentifierCode());
			}
			
			// remote list
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.REUTERS_SERVICE);
			
			// create temporary folder and files to work
			String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + FCP_REQUEST_FILE_NAME;
			File file = new File(tempFileAbsPath);
			file.createNewFile();
			
			this.ftpServiceInterface.downloadRequestFile(FCP_REQUEST_FILE_NAME, file);
			
			ReutersRequestParser reutersRequestParser = new ReutersRequestParser();
			ReutersRequestTemplate reutersRequestTemplate = reutersRequestParser.parse(file);
			List<String> remoteInstrumentList = reutersRequestTemplate.getInstruments();
			
			
			// confronta
			
			// 
			for(String ricCode : localList) {
				if(!remoteInstrumentList.contains(ricCode)) {
					
					aligned = false;
					
					logger.warn(new StandardLogMessage("Reuters code \'" + ricCode + "\' enabled in local environment but not present in remote Future intrument list."));
				}
			}
			
			//
			for(String ricCode : remoteInstrumentList) {
				if(!localList.contains(ricCode)) {
					
					aligned = false;
					
					logger.warn(new StandardLogMessage("Reuters code \'" + ricCode + "\' present in remote Future intrument list but disabled in local environment."));
				}
			}
			
			
			// computation END
			
			if(aligned) {
				logger.info(new StandardLogMessage("Reuters FCP local and remote instrument lists aligned."));
				
				monitorLogger.info(new StandardLogMessage("Reuters FCP local and remote instrument lists aligned."));
			}
			else {
				logger.warn(new StandardLogMessage("Reuters FCP local and remote instrument lists not aligned."));
				
				monitorLogger.warn(new StandardLogMessage("Reuters FCP local and remote instrument lists not aligned. Read logs for details."));
			}
			
			// delete tempWorkingFolder
			//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
		}
		catch(Exception e) {
			// monitor error
			monitorLogger.error(new StandardLogMessage("Reuters FCP request alignment check failed."));
			// default logger
			logger.error(new StandardLogMessage("Reuters FCP request alignment check failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Reuters FCP request alignment check failed.");
		}
		
	}
    
    
    
    
    @Override
    public void alignFcpRequest() throws Exception {
    	
    	try {
    		
    		FLOW_FCP_NAME = properties.getProperty("provider.reuters.flow.fcp.name");
        	FCP_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_FCP_NAME).getRequestFileName();
        	
        	
    		logger.info(new StandardLogMessage("Reuters FCP request alignment started."));
        	
        	
        	List<InstrEntity> enabledInstrList = this.instrumentsEAOLocal.fetchEnabled("F","Reuters");
        	List<InstrEntity> oneShotInstrList = this.instrumentsEAOLocal.fetchOneShot("F","Reuters");
        	List<InstrEntity> instrList = new ArrayList<InstrEntity>();
        	instrList.addAll(enabledInstrList);
        	instrList.addAll(oneShotInstrList);
        	
        	logger.info(new StandardLogMessage("Instrument list size: " + instrList.size()));
        	logger.info(new StandardLogMessage("Instrument list details: " + instrList));
        	
        	
        	// create temporary folder and files to work
        	String tempWorkingFolderName = SecurityEjb.getUniqueToken();
    		File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
    		if(!tempWorkingFolder.mkdir()) {
    			
    			throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
    		}
    		
    		String tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + FCP_REQUEST_FILE_NAME;
    		File fileToSaveInto = new File(tempFileAbsPath);
    		fileToSaveInto.createNewFile();
        	
        	ReutersRequestFactory reutersRequestFactory = new ReutersRequestFactory();
        	reutersRequestFactory.createRequestFile(RTRRequestType.FUTCP_REQUEST, fileToSaveInto, instrList);

        	this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.REUTERS_SERVICE);

        	this.ftpServiceInterface.uploadRequestFile(fileToSaveInto.getName(), fileToSaveInto);


        	monitorLogger.info(new StandardLogMessage("Reuters FCP request successfully aligned."));
    		logger.info(new StandardLogMessage("Reuters FCP request successfully aligned."));
    		
    		
    		// delete tempWorkingFolder
    		//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
    	}
    	catch(Exception e) {
    		// monitor error
			monitorLogger.error(new StandardLogMessage("Reuters FCP request alignment failed."));
			// default logger
			logger.error(new StandardLogMessage("Reuters FCP request alignment failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Reuters FCP request alignment failed.");
		}
    	
    }


	@Override
	public void checkCollAlignment() throws Exception {
		
		try {
			
			FLOW_COLL_NAME = properties.getProperty("provider.reuters.flow.coll.name");
        	COLL_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_COLL_NAME).getRequestFileName();
        	
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}


	@Override
	public void alignCollRequest() throws Exception {
		
		try {
			
			FLOW_COLL_NAME = properties.getProperty("provider.reuters.flow.coll.name");
        	COLL_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_COLL_NAME).getRequestFileName();
        	
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
    

}
