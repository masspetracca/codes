package it.ccg.ifpejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the IFPFILE database table.
 * 
 */
@Entity
@Table(name="IFPTFILE")
@NamedQueries({
	@NamedQuery(name="fetchAllFtpFiles", query="SELECT ftpFile FROM FTPFileEntity ftpFile"),
	@NamedQuery(name="fetchByName", query="SELECT ftpFile FROM FTPFileEntity ftpFile WHERE ftpFile.fileName = :fileName")
})
public class FTPFileEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.TABLE, generator="ID_FILE_TABLE_GENERATOR")
	@TableGenerator(name="ID_FILE_TABLE_GENERATOR", table="IFPTIDGEN", pkColumnName="ID_NAME", pkColumnValue="USER_SEQUENCE", valueColumnName="ID_VALUE")
	@Column(name="FILE_ID", unique=true, nullable=false)
	private int fileId;

	@Column(name="CONTENT", length=10000)
	private String fileContent;

	@Column(name="FILE_NAME", nullable=false, length=30)
	private String fileName;

	@Column(name="P_BATCH_ID", nullable=false)
	private int parentBatchId = -1;

	@Column(name="UPDDATE", nullable=false)
	private Timestamp updateDate = new Timestamp(System.currentTimeMillis());
	
	@Column(name="UPDTYPE")
	private String updateType = "C";
	
	@Column(name="UPDUSR", nullable=false, length=30)
	private String updatingUser = "SYSTEM";
	
	
    public FTPFileEntity() {
    	
    }
    
    public FTPFileEntity(String fileName, String fileContent, int parentBatchId) {
    	this.fileName = fileName;
    	this.fileContent = fileContent;
    	this.parentBatchId = parentBatchId;
    }
    

	public int getFileId() {
		return this.fileId;
	}

	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	public String getFileContent() {
		return this.fileContent;
	}

	public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getParentBatchId() {
		return this.parentBatchId;
	}

	public void setParentBatchId(int parentBatchId) {
		this.parentBatchId = parentBatchId;
	}

	public Timestamp getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdatingUser() {
		return this.updatingUser;
	}

	public void setUpdatingUser(String updatingUser) {
		this.updatingUser = updatingUser;
	}
	
	public String getUpdateType() {
		return updateType;
	}

	public void setUpdateType(String updateType) {
		this.updateType = updateType;
	}
	
	
	@Override
	public String toString() {
		
		return "[FILE_ID: " + this.fileId + ", FILE_NAME: " + this.fileName + ", P_BATCH_ID: " + this.parentBatchId + "]";
	}

}