package it.ccg.ifpejb.server.bean.eao;



import it.ccg.ifpejb.server.bean.entity.FTPFileEntity;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;

import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class FTPFileEAO
 */
@SuppressWarnings("unchecked")
@Stateless(mappedName = "FTPFileEAO")
public class FTPFileEAO implements FTPFileEAOLocal {

	@PersistenceContext(unitName = "InfoProvidersEjb", type = PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Resource
	private SessionContext sessionContext;
	
	private String tableName = ((Table)(FTPFileEntity.class.getAnnotation(Table.class))).name();
	
    /**
     * Default constructor. 
     */
    public FTPFileEAO() throws Exception {
    	
    }
	
	@Override
	public List<FTPFileEntity> fetch() throws Exception {
		
		Query query = em.createNamedQuery("fetchAllFtpFiles");
		
		return (List<FTPFileEntity>)query.getResultList();
	}

	@Override
	public FTPFileEntity findByPrimaryKey(int fileId) throws Exception {
		
		return (FTPFileEntity) em.find(FTPFileEntity.class, fileId);
	}
	
	
	@Override
	public FTPFileEntity findByName(String fileName) throws Exception {
		
		Query query = em.createNamedQuery("fetchByName");
		query.setParameter("fileName", fileName);
		
		FTPFileEntity fileEntity = null;
		List<FTPFileEntity> list = (List<FTPFileEntity>)query.getResultList();
		if(list.size() != 0) {
			fileEntity = list.get(0);
		}
		
		return fileEntity;
	}
	

	@Override
	public FTPFileEntity add(FTPFileEntity fileEntity) throws Exception {
		
		// set current user
		fileEntity.setUpdatingUser(this.sessionContext.getCallerPrincipal().getName());
		
		em.persist(fileEntity);
		
		logger.info(new StandardLogMessage("Persisted data into \'" + this.tableName + "\'. " + fileEntity));
		
		
		return fileEntity;
	}


	@Override
	public void update(FTPFileEntity fileEntity) throws Exception {
		
		// TODO
	}

	@Override
	public void remove(FTPFileEntity fileEntity) throws Exception {
		
		FTPFileEntity temp = findByPrimaryKey(fileEntity.getFileId());
		
		em.remove(temp);
		
		
		logger.info(new StandardLogMessage("Deleted data into \'" + this.tableName + "\'. " + fileEntity));
		
	}

}
