package it.ccg.ifpejb.server.bean.business.other;

import it.ccg.ifpejb.server.bean.eao.HisPrEAOLocal;
import it.ccg.ifpejb.server.bean.eao.InstrEAOLocal;
import it.ccg.ifpejb.server.bean.eao.MiPrCurrHisPrEAOLocal;
import it.ccg.ifpejb.server.bean.entity.HisPrEntity;
import it.ccg.ifpejb.server.bean.entity.InstrEntity;
import it.ccg.ifpejb.server.bean.entity.MiPrCurrHisPrEntity;
import it.ccg.ifpejb.server.exception.ExceptionUtil;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;
import it.ccg.ifpejb.server.system.MailManager;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MiPrCurrBatchBean
 */
@Stateless
@Local(MiPrCurrBatchBeanLocal.class)
public class MiPrCurrBatchBean implements MiPrCurrBatchBeanLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	private static final Logger monitorLogger = LoggerFactory.getLogger(LoggerFactory.MONITOR_LOGGER);

	
	@EJB
	private InstrEAOLocal instrEAOLocal;
	
	@EJB
	private HisPrEAOLocal hisPrEAOLocal;
	
	@EJB
	private MiPrCurrHisPrEAOLocal miPrCurrHisPrEAOLocal;
	
	
	
    /**
     * Default constructor. 
     */
    public MiPrCurrBatchBean() {
    	
    }
    
    
    @Override
	public void syncCurrToMiPr() throws Exception {
    	
    	String environment = "I400DTA.TCOCCYF00F";
    	
    	try {
    		logger.info(new StandardLogMessage("Synchronize currency to " + environment + " started."));

			List<InstrEntity> currList = this.instrEAOLocal.fetchEnabled("C", "Bloomberg");
			
			List<Integer> currIDList = new ArrayList<Integer>();
			for(InstrEntity instr : currList) {
				
				currIDList.add(Integer.valueOf(instr.getInstrumentId()));
			}
			
			logger.info(new StandardLogMessage("Fetched enabled currency IDs: " + currIDList));
			
			List<HisPrEntity> hisPrList = this.hisPrEAOLocal.fetchLastDateHisPr(currIDList);
			
			for(HisPrEntity hisPr : hisPrList) {
				
				logger.info(new StandardLogMessage("Fetched data: " + hisPr));
			}
			
			// convert to destination format
			List<MiPrCurrHisPrEntity> miPrcurrHisPrList = this.convertHPE2MPCE(hisPrList);
			
			// persist
			this.persistInMiDR(miPrcurrHisPrList);
			
			logger.info(new StandardLogMessage("Historical data successfully persisted in " + environment + "."));
			
			monitorLogger.info(new StandardLogMessage("Synchronize currency to " + environment + " successfully executed."));
			logger.info(new StandardLogMessage("Synchronize currency to " + environment + " successfully executed."));
			
    	}
    	catch (Exception e) {
    		
    		// log
	        monitorLogger.error(new StandardLogMessage("Synchronize currency to " + environment + " failed."));
	        logger.error(new StandardLogMessage("Synchronize currency to " + environment + " failed."));
	        ExceptionUtil.logCompleteStackTrace(logger, e);
	        
	        // send mail
	        MailManager mailManager = new MailManager();
	        String message = "Synchronize currency to " + environment + " failed.";
	        mailManager.sendMail("InfoProviders System batch generic error", message, null);
	        
	        // throw at caller
	        throw new Exception("Synchronize currency to " + environment + " failed.");
    	}
    	
	}
    
    
	private List<MiPrCurrHisPrEntity> convertHPE2MPCE(List<HisPrEntity> hisPrList) throws Exception {
	      
		List<MiPrCurrHisPrEntity> mpceList = new ArrayList<MiPrCurrHisPrEntity>();
		
		for (HisPrEntity hisPr : hisPrList) {
			
			InstrEntity instr = this.instrEAOLocal.findByPrimaryKey(hisPr.getId().getInstrumentId());
			
			MiPrCurrHisPrEntity mpce = new MiPrCurrHisPrEntity();
			
			// Original currency Bloomberg code format: 'XXXYYY Curncy'
			String bbgCode = instr.getBloombergCode().trim().split(" ")[0];
			// Check on BBGCODE
			if(bbgCode.length() != 6) {
				
				throw new Exception("Not valid BBGCODE: " + bbgCode);
			}
			
			mpce.setCcyBlom(bbgCode);
			mpce.setCcyData(new BigDecimal(hisPr.getId().getPriceDate()));
			mpce.setCcyOra(new BigDecimal(hisPr.getId().getPriceTime()));
			mpce.setCcyVal(hisPr.getClosingPrice());
			mpce.setCcConv("M");
			mpce.setCcyIso(bbgCode.substring(0, 3));
			mpce.setCcySet(bbgCode.substring(3, 6));
			
			mpceList.add(mpce);
		}
		
		
		return mpceList;
	}
	
	
	private void persistInMiDR(List<MiPrCurrHisPrEntity> miPrHisPrList) throws Exception {
	
		for(MiPrCurrHisPrEntity miPrHisPr : miPrHisPrList) {
			
			// check for duplicate key
			MiPrCurrHisPrEntity temp = this.miPrCurrHisPrEAOLocal.findByPrimaryKey(miPrHisPr.getCcyBlom(), miPrHisPr.getCcyData());
			
			if(temp != null) {
				
				logger.warn(new StandardLogMessage("Duplicate key found in I400DTAEU.TCOCCYF00F. " + temp));
				
				// skip
				continue;
			}
			
			// persist
			this.miPrCurrHisPrEAOLocal.add(miPrHisPr);
			
		}
		
	}
	
	
    
    // OLD
	/*@Override
	@Job(name="MiPr-RmINFOP_CURR_Sync", methodClass=MiPrCurrBatchBeanLocal.class, description="Copy Currency from Rm.INFOP to MiPr")
    public void syncCurrToMiPr() throws Exception {
		
		try {
			
			// per ogni strumento leggi l'ultimo valore scritto su INFOP
			System.out.println("@@ leggo da INFOP");
			
			List<InstrEntity> instrList = this.instrEAOLocal.fetchEnabled("C", "Bloomberg");
			List<Integer> currIdList = new ArrayList<Integer>();
			for(InstrEntity instr : instrList) {
				
				currIdList.add(instr.getInstrumentId());
			}
			
			List<HisPrEntity> hisPrList = this.hisPrEAOLocal.fetchLastDateHisPr(currIdList);
			
			for(HisPrEntity hisPr : hisPrList) {
				
				logger.info(new StandardLogMessage("Fetched data: " + hisPr));
			}
			
			
			// convert data from INFOP to MiPr format
			List<MiPrCurrHisPrEntity> miPrHisPrList = new ArrayList<MiPrCurrHisPrEntity>();
			for(HisPrEntity hisPr : hisPrList) {
				
				MiPrCurrHisPrEntity miPrHisPr = new MiPrCurrHisPrEntity();
				
				InstrEntity instr = this.instrEAOLocal.findByPrimaryKey(hisPr.getId().getInstrumentId());
				String bbgCode = instr.getInstrumentName();
				
				miPrHisPr.setCcyBlom(bbgCode);
				miPrHisPr.setCcyData(new BigDecimal(hisPr.getId().getPriceDate()));
				miPrHisPr.setCcyOra(new BigDecimal(hisPr.getId().getPriceTime()));
				miPrHisPr.setCcyVal(hisPr.getClosingPrice());
				miPrHisPr.setCcConv("M");
				miPrHisPr.setCcyIso(bbgCode.substring(0, 3));
				miPrHisPr.setCcySet(bbgCode.substring(3, 6));
				
				
				miPrHisPrList.add(miPrHisPr);
				
			}
			
			
			// scrivi su MiPr
			System.out.println("@@ scrivo su MiPr");
			
			for(MiPrCurrHisPrEntity miPrHisPr : miPrHisPrList) {
				
				// check for duplicate key
				MiPrCurrHisPrEntity temp = this.miPrCurrHisPrEAOLocal.findByPrimaryKey(miPrHisPr.getCcyBlom(), miPrHisPr.getCcyData());
				
				if(temp != null) {
					
					logger.warn(new StandardLogMessage("Pair \'CCYBLOM: " + temp.getCcyBlom() + ", CCYDATA: " + temp.getCcyData() + "\' already exists in TCOCCYF00F. Skipping data."));
					
					// skip
					continue;
				}
				
				this.miPrCurrHisPrEAOLocal.add(miPrHisPr);
			}
			
		}
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
		
	}*/
	

}
