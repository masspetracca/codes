package it.ccg.ifpejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the IFPTBATCH database table.
 * 
 */
@Entity
@Table(name="IFPTBATCH")
@NamedQueries({
	@NamedQuery(name="getAllBatches", query="SELECT batch FROM BatchEntity batch"),
	@NamedQuery(name="getLastBatchId", query="SELECT max(batch.batchId) FROM BatchEntity batch")
})
public class BatchEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.TABLE, generator="ID_BATCH_TABLE_GENERATOR")
	@TableGenerator (name="ID_BATCH_TABLE_GENERATOR", table="IFPTIDGEN", pkColumnName="ID_NAME", pkColumnValue="USER_SEQUENCE", valueColumnName="ID_VALUE")
	@Column(name="BATCH_ID", unique=true, nullable=false)
	private int batchId;

	@Column(name="BATCHDESC", length=255)
	private String batchDescription;

	@Column(name="CLOSEMKTDT", nullable=false, length=1)
	private String activeOnClosedMarketDays = "T";

	@Column(nullable=false, length=30)
	private String provider;

	@Column(name="UPDDATE", nullable=false)
	private Timestamp updateDate = new Timestamp(System.currentTimeMillis());
	
	@Column(name="UPDTYPE", nullable=false, length=1)
	private String updateType = "C";

	@Column(name="UPDUSR", nullable=false, length=30)
	private String updatingUser;

    public BatchEntity() {
    	
    }
    
    public BatchEntity(String provider, String batchDescription) {
    	this.provider = provider;
    	this.batchDescription = batchDescription;
    }

	public int getBatchId() {
		return this.batchId;
	}

	public void setBatchId(int batchId) {
		this.batchId = batchId;
	}

	public String getBatchDescription() {
		return this.batchDescription;
	}

	public void setBatchDescription(String batchDescription) {
		this.batchDescription = batchDescription;
	}

	public String getActiveOnClosedMarketDays() {
		return this.activeOnClosedMarketDays;
	}

	public void setActiveOnClosedMarketDays(String activeOnClosedMarketDays) {
		this.activeOnClosedMarketDays = activeOnClosedMarketDays;
	}

	public String getProvider() {
		return this.provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public Timestamp getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdatingUser() {
		return this.updatingUser;
	}

	public void setUpdatingUser(String updatingUser) {
		this.updatingUser = updatingUser;
	}

	public String getUpdateType() {
		return updateType;
	}

	public void setUpdateType(String updateType) {
		this.updateType = updateType;
	}

	@Override
	public String toString() {
		
		return "[BATCH_ID: " + this.batchId + ", BATCHDESC: " + this.batchDescription + ", PROVIDER: " + this.provider + "]";
	}
	
	
	

}