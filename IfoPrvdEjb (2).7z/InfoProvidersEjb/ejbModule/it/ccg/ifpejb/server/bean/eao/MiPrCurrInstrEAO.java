package it.ccg.ifpejb.server.bean.eao;

import it.ccg.ifpejb.server.bean.entity.MiPrCurrInstrEntity;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class MiPrCurrInstrEAO
 */
@Stateless
@Local(MiPrCurrInstrEAOLocal.class)
public class MiPrCurrInstrEAO implements MiPrCurrInstrEAOLocal {

    /**
     * Default constructor. 
     */
    public MiPrCurrInstrEAO() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public MiPrCurrInstrEntity findByPrimaryKey(String paramString,
			BigDecimal paramBigDecimal) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<MiPrCurrInstrEntity> fetchAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
