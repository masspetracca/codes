package it.ccg.ifpejb.server.bean.eao;

import it.ccg.ifpejb.server.bean.entity.MiPrCurrHisPrEntity;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

@Stateless
@Local({MiPrCurrHisPrEAOLocal.class})
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class MiPrCurrHisPrEAO implements MiPrCurrHisPrEAOLocal {

	@PersistenceContext(unitName="InfoProvidersEjb_testEnv_MilanoDR", type=PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	private String tableName = ((Table)MiPrCurrHisPrEntity.class.getAnnotation(Table.class)).name();
	
	
	
	public MiPrCurrHisPrEntity findByPrimaryKey(String ccyBlom, BigDecimal ccyData) throws Exception {
		
		Query query = this.em.createNamedQuery("fetchByInstrId&PriceDate");
		query.setParameter("ccyBlom", ccyBlom);
		query.setParameter("ccyData", ccyData);
		
		@SuppressWarnings("unchecked")
		List<MiPrCurrHisPrEntity> list = (List<MiPrCurrHisPrEntity>)query.getResultList();
		
		MiPrCurrHisPrEntity result = null;
		
		if(list.size() == 1) {
			
			result = list.get(0);
		}
		else if(list.size() > 1) {
			
			logger.warn(new StandardLogMessage("Multiple values for [CCYBLOM: " + ccyBlom + ", CCYDATA: " + ccyData + "]"));
			
			throw new Exception("Multiple values for [CCYBLOM: " + ccyBlom + ", CCYDATA: " + ccyData + "]");
		}
		
		
		return result;
	}
	
	
	public void add(MiPrCurrHisPrEntity mpce) throws Exception {
		
		this.em.persist(mpce);
		
		logger.info(new StandardLogMessage("Persisted data into '" + this.tableName + "'. " + mpce));
	}
	
	
	
}