package it.ccg.ifpejb.server.bean.business.provider;

import it.ccg.ifpejb.server.bean.eao.BatchEAOLocal;
import it.ccg.ifpejb.server.bean.eao.FTPFileEAOLocal;
import it.ccg.ifpejb.server.bean.eao.HisPrEAOLocal;
import it.ccg.ifpejb.server.bean.eao.InstrEAOLocal;
import it.ccg.ifpejb.server.bean.entity.BatchEntity;
import it.ccg.ifpejb.server.bean.entity.FTPFileEntity;
import it.ccg.ifpejb.server.bean.entity.HisPrEntity;
import it.ccg.ifpejb.server.bean.entity.InstrEntity;
import it.ccg.ifpejb.server.exception.DuplicateKeyException;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BaseBean
 */
@Stateless
public class BaseBean implements BaseBeanLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@EJB
	private InstrEAOLocal instrEAOLocal;
	
	@EJB
	private HisPrEAOLocal historicalPricesEAOLocal;
	
	@EJB
	private FTPFileEAOLocal ftpFileEAOLocal;
	
	@EJB
	private BatchEAOLocal batchEAOLocal;
	
	

    /**
     * Default constructor. 
     */
    public BaseBean() {
    	
    }
    

    @Override
	public void persistHistoricalData(List<HisPrEntity> hisPrEntityList) throws Exception {
		
    	try {
    	
			boolean duplicateKeyFoundFlag = false;
			
	    	for(HisPrEntity hisPrEntity : hisPrEntityList) {
	    		
	    		// gestione chiave duplicata
	    		// *********************************************************************************************************************
	    		HisPrEntity temp = this.historicalPricesEAOLocal.findByPrimaryKey(hisPrEntity.getId());
	    		
	    		// se il dato gi� esiste
				if(temp != null) {
					
					logger.warn(new StandardLogMessage("Pair \'INSTR_ID: " + temp.getId().getInstrumentId() + ", PRICADATE: " + temp.getId().getPriceDate() + "\' already exists in IFTPHISPR. Skipping data."));
					
					duplicateKeyFoundFlag = true;
					
					// skip
					continue;
				}
	    		// *********************************************************************************************************************
	    		
				// scrivi dato 
				this.historicalPricesEAOLocal.add(hisPrEntity);
			}
	    	
			if(duplicateKeyFoundFlag) {
				
				logger.warn(new StandardLogMessage("Persisting data successfully completed. Duplicate key values found in new data."));
				
				throw new DuplicateKeyException("Persisting data successfully completed. Duplicate key values found in new data.");
			}
			else {
				
				logger.info(new StandardLogMessage("Persisting data successfully completed."));
			}
			
    	}
    	catch(Exception e) {
    		
    		logger.error(new StandardLogMessage(e.toString()));
    		
			throw e;
		}
    }
    
	
    @Override
	public void saveJobInfo(String provider, String batchDesc, List<HisPrEntity> hisPrEntityList, String fileName, String fileAbsPath) throws Exception {
    	
    	try {
    		// save information about executed batch
    		BatchEntity batchEntity = new BatchEntity(provider, batchDesc);
    		this.batchEAOLocal.add(batchEntity);
    		logger.info(new StandardLogMessage("Batch info successfully stored."));
    		
    		// save information about downloaded file
    		File file = new File(fileAbsPath);
    		String fileContent = this.getFileContent(file);
    		// 
    		if(fileContent.length() > 9999) {
    			
    			fileContent = "/";
    			
    			logger.warn(new StandardLogMessage("Updating prices history with batch and data source file info -  File content length (" + fileContent.length() + ") > maxLength (10000). Field \'CONTENT\' set to \'/\'."));
    		}
    		
    		FTPFileEntity fileEntity = new FTPFileEntity(fileName, fileContent, batchEntity.getBatchId());
    		fileEntity = this.ftpFileEAOLocal.add(fileEntity);
    		logger.info(new StandardLogMessage("File info successfully stored."));
    		
    		// update persisted historical data with p_file_id
    		for(HisPrEntity hisPrEntity : hisPrEntityList) {
    			// set p_file_id for each HistoricalPricesEntity
    			hisPrEntity.setParentFileId(fileEntity.getFileId());
    		}
    		logger.info(new StandardLogMessage("Historical data P_FILE_ID successfully updated."));
    	}
    	catch(Exception e) {
    		logger.error(new StandardLogMessage(e.toString()));
    		
			throw e;
		}
    	
    }
    
    
    @Override
	public void updateOneShotToDisable(List<HisPrEntity> hisPrEntityList) throws Exception {
    	
    	try {
	    	for(HisPrEntity hisPrEntity : hisPrEntityList) {
				int instrId = hisPrEntity.getId().getInstrumentId();
				InstrEntity instrEntity = this.instrEAOLocal.findByPrimaryKey(instrId);
				
				if(instrEntity.getStatus().equalsIgnoreCase("O")) {
					instrEntity.setStatus("D");
				}
			}
	    	
	    	
	    	logger.info(new StandardLogMessage("ONESHOT correctly changed to DISABLE."));
    	}
    	catch(Exception e) {
    		logger.error(new StandardLogMessage(e.toString()));
    		
			throw e;
		}
    	
    }
    
    
    @Override
    public void deleteTempWorkingFolder(File tempWorkingFolder) throws Exception {
    	
    	try {
			FileUtils.deleteDirectory(tempWorkingFolder);
			
			logger.info(new StandardLogMessage("Temp working folder successfully deleted: \'" + tempWorkingFolder + "\'."));
		}
		catch(IOException e) {
			
			logger.warn(new StandardLogMessage("Unable to delete temp folder \'" + tempWorkingFolder + "\'."));
			
			throw e;
		}
    	
    }


    
    
    // *****************************************************************************
    // PRIVATE METHODS
    // *****************************************************************************
    
    
    private String getFileContent(File file) throws Exception {
    	
		BufferedReader br = new BufferedReader(new FileReader(file));
		String fileContent = new String();
		
		String line = br.readLine();
		while(line != null) {
			fileContent += line + "\n";
			
			line = br.readLine();
		}
		
		
		return fileContent;
	}
	

}
