package it.ccg.ifpejb.server.bean;


import it.ccg.ifpejb.server.exception.ExceptionUtil;
import it.ccg.ifpejb.server.exception.FTPException;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;
import it.ccg.ifpejb.server.system.FTPErrorManager;
import it.ccg.ifpejb.server.system.LocalBeanLookup;
import it.ccg.ifpejb.server.system.MailManager;
import it.ccg.ifpejb.server.system.SystemProperties;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.log4j.Logger;



/**
 * Session Bean implementation class BloombergTimerBean
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class TimerBean implements TimerBeanLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	private static final Logger monitorLogger = LoggerFactory.getLogger(LoggerFactory.MONITOR_LOGGER);
	
	
	@Resource
	private TimerService timerService;
	
	
    /**
     * Default constructor. 
     */
    public TimerBean() {
    	
    }
    
    
	@Override
	public TimerDTO createTimer(TimerDTO timerDTO) throws Exception {
		
		TimerDTO result = null;
		
		if(this.getTimer(timerDTO.getName()) != null) {
			logger.error("Duplicate timer name.");
			
			return null;
		}
		
		result = (TimerDTO)(this.timerService.createTimer(timerDTO.getStartDateTime(), timerDTO.getInterval(), timerDTO)).getInfo();
		
		
		logger.info(new StandardLogMessage("Timer created: " + timerDTO));
		
		
		return result;
	}
	
	
	@Override
	public TimerDTO createSingleActionTimer(TimerDTO timerDTO) throws Exception {
		
		TimerDTO result = null;
		
		if(this.getTimer(timerDTO.getName()) != null) {
			
			logger.error("Duplicate timer name.");
			
			return null;
		}
		
		result = (TimerDTO)(this.timerService.createTimer(timerDTO.getStartDateTime(), timerDTO)).getInfo();
		
		
		logger.info(new StandardLogMessage("Timer created: " + timerDTO));
		
		
		return result;
	}
	
	
	@Override
	public void deleteTimer(String timerName) throws Exception {
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = this.timerService.getTimers();
    	for(Timer timer : collection) {
    		if(((String)((TimerDTO)timer.getInfo()).getName()).equals(timerName)) {
    			
    			timer.cancel();
    			
    			logger.info(new StandardLogMessage("Timer \'" + timerName + "\' deleted."));
    		}
    	}
	}
	
	
	@Override
	public void deleteAllTimers() throws Exception {
		
		while(this.timerService.getTimers().iterator().hasNext()) {
			
			Timer timer = (Timer)this.timerService.getTimers().iterator().next();
			
			String timerName = ((TimerDTO)timer.getInfo()).getName();
			
			timer.cancel();
    		
			
    		logger.info(new StandardLogMessage("Timer \'" + timerName + "\' deleted."));
    	}
		
	}
	

	@Override
	public TimerDTO getTimer(String timerName) throws Exception {
		
		TimerDTO timerDTO = null;
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = this.timerService.getTimers();
    	
    	for(Timer timer : collection) {
    		
    		if(((String)((TimerDTO)timer.getInfo()).getName()).equals(timerName)) {
    			
    			timerDTO = (TimerDTO)timer.getInfo();
    		}
    	}
		
    	
    	
		return timerDTO;
	}
	

	@Override
	public List<TimerDTO> getAllTimers() throws Exception {
		
		List<TimerDTO> list = new ArrayList<TimerDTO>();
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = this.timerService.getTimers();
    	
    	for(Timer timer : collection) {
    		
    		TimerDTO timerDTO = (TimerDTO)timer.getInfo();
    		
    		list.add(timerDTO);
    	}
		
    	
		return list;
	}
	
	
	
	@Timeout
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void timeout(Timer timer) {
		
		TimerDTO timerDTO = (TimerDTO)timer.getInfo();
		
		logger.info(new StandardLogMessage("Timer \'" + timerDTO.getName() + "\' expired."));
		
		JobDTO jobDTO = timerDTO.getJobDTO();
		String methodName = jobDTO.getMethodName();
		Class<?> methodClass = jobDTO.getMethodClass();
		
		
		try {
			Method method = methodClass.getMethod(methodName, (Class<?>[])null);
			
			// class is an EJB interface
			Object classInstance = LocalBeanLookup.lookup(methodClass.getCanonicalName());
			
			method.invoke(classInstance, (Object[])null);
		}
		catch(InvocationTargetException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e.getCause());
			
			if(e.getCause() instanceof FTPException) {
				
				this.manageFTPException(timerDTO);
			}
			
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
		}
		
		
	}
	
	
	
	private void manageFTPException(TimerDTO timerDTO) {
		
		try {
			JobDTO jobDTO = timerDTO.getJobDTO();
			
			int FTP_ERROR_TIMER_INTERVAL_IN_SECONDS = Integer.parseInt(SystemProperties.getProperty("ftp.error.attempt.interval"));
			int FTP_ERROR_MAX_ATTEMPT = Integer.parseInt(SystemProperties.getProperty("ftp.error.attempt.number"));
			
			String HELPDESK_MAIL_ADDRESS = SystemProperties.getProperty("mail.to.helpdesk");
			String[] DEV_MAIL_ADDRESSES = (SystemProperties.getProperty("mail.to.dev")).split(",");
			
			
			// (*)
			// If it is the first call, this method creates a new ticket.
			// Else, it increments the opened ticket.
			String jobName = jobDTO.getName();
			FTPErrorManager.registerTicket(jobName);
			
			String provider = timerDTO.getProvider();
			
			if(FTPErrorManager.getCounter(jobName) < FTP_ERROR_MAX_ATTEMPT) {
				
				String timerName = jobName + "_repeat-after-ftpexception";
				
				// The expired timer instance still exists while execution is into @Timeout method
				if(this.getTimer(timerName) != null) {
					
					this.deleteTimer(timerName);
				}
				
				TimerDTO repeatTimerDTO = new TimerDTO(timerName, true, new Date(System.currentTimeMillis() + FTP_ERROR_TIMER_INTERVAL_IN_SECONDS*1000), provider, jobDTO);
				
				this.createSingleActionTimer(repeatTimerDTO);
				
				// Error message
				String errorMessage = provider + " FTP error. Job \'" + jobName + "\' failed. Job will run again in " + FTP_ERROR_TIMER_INTERVAL_IN_SECONDS + " seconds.";
				
				// monitor warning
				monitorLogger.error(new StandardLogMessage(errorMessage));
				// default logger
				logger.error(new StandardLogMessage(errorMessage));
				
				// send notification mail
				// default constructor --> send mail to default TO and CC lists (properties file)
				MailManager mailManager = new MailManager();
				mailManager.sendMail("InfoProviders System FTP error", errorMessage, null);
			}
			else {
				
				// Error message
				String errorMessage = provider + " FTP error (3rd attempt). Job \'" + jobName + "\' failed. Mail sent to CC&G HelpDesk.";
				
				// monitor warning
				monitorLogger.error(new StandardLogMessage(errorMessage));
				// default logger
				logger.error(new StandardLogMessage(errorMessage));
				
				// send notification mail to CC&GHelpDesk
				String[] toMailAddressList = {HELPDESK_MAIL_ADDRESS};
				String[] ccMailAddressList = DEV_MAIL_ADDRESSES;
				MailManager mailManager = new MailManager(toMailAddressList, ccMailAddressList);
				mailManager.sendMail("InfoProviders System FTP Error", errorMessage, null);
				
				// (*)
				// Delete the opened ticket.
				FTPErrorManager.destroyTicket(jobName);
			}
			
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
		}
		
		
		
	}
	
	
	
}
