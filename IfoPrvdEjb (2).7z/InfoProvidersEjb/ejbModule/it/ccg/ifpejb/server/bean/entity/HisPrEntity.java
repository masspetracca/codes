package it.ccg.ifpejb.server.bean.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the IFPTHISPR database table.
 * 
 */
@Entity
@Table(name="IFPTHISPR")
@NamedQueries({
	@NamedQuery(name="getAllHistoricalPrices", query="SELECT hisPr FROM HisPrEntity hisPr ORDER BY hisPr.id.priceDate DESC"),
	
	@NamedQuery(name="getAllHistoricalPricesFromLastBatch", query="SELECT hisPr FROM HisPrEntity hisPr " +
																  "WHERE hisPr.parentFileId = " +
																	  "(SELECT ftpFile.fileId from FTPFileEntity ftpFile " +
																		  "WHERE ftpFile.parentBatchId = " +
																		  	"(SELECT MAX(batch.batchId) from BatchEntity batch))"),
																		  
	@NamedQuery(name="getPriceDateByInstr", query="SELECT hisPr.id.priceDate, hisPr.closingPrice FROM HisPrEntity hisPr WHERE hisPr.id.instrumentId =?1"),
	
	@NamedQuery(name="getInstrMinDate", query="SELECT MIN(hisPr.id.priceDate) FROM HisPrEntity hisPr WHERE hisPr.id.instrumentId = :instrId"),
	
	@NamedQuery(name="getByInstrId&PriceDate", query="SELECT hisPr " +
												     "FROM HisPrEntity hisPr " +
												     "WHERE hisPr.id.instrumentId = :instrId AND hisPr.id.priceDate = :priceDate"),
	
	@NamedQuery(name="getLastDateHisPr", query="SELECT hisPr " +
											   "FROM HisPrEntity hisPr " +
											   "WHERE hisPr.id.priceDate > :date"),
										
	/*@NamedQuery(name="fetchLastDateHisPr", query="SELECT hisPr " +
											   "FROM HisPrEntity hisPr " +
											   "WHERE hisPr.id.instrumentId IN (:instrIDsList) AND " + 
										   										"hisPr.id.priceDate = (" + 
														   										"SELECT MAX(hisPrTemp.id.priceDate) " + 
														   										"FROM HisPrEntity hisPrTemp " + 
														   										"WHERE hisPrTemp.id.instrumentId = hisPr.id.instrumentId" + 
										   													")")*/
   @NamedQuery(name="fetchLastDateHisPr", query="SELECT hisPr " +
											   	"FROM HisPrEntity hisPr " +
												"WHERE hisPr.id.instrumentId IN (:instrIDsList) AND " + 
											   										"hisPr.id.priceDate = (" + 
															   										"SELECT MAX(hisPrTemp.id.priceDate) " + 
															   										"FROM HisPrEntity hisPrTemp " + 
															   										"WHERE hisPrTemp.id.instrumentId = hisPr.id.instrumentId" + 
											   													")")
											
})
/*	
	@NamedQuery(name="fetchInfoTest", query="SELECT new HisPrInfo(hisPr.id.instrumentId, instr.instrumentName, MIN(hisPr.id.priceDate), MAX(hisPr.id.priceDate), COUNT(hisPr.id.priceDate)) " + 
											"FROM HisPrEntity hisPr JOIN hisPr.instr instr " + 
											"WHERE 1=1 " +
											"GROUP BY hisPr.id.instrumentId, instr.instrumentName " + 
											"HAVING 1=1 " + 
											"ORDER BY hisPr.id.instrumentId")*/
public class HisPrEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;
	//***********************************************
	// Manually created foreign keys
	//***********************************************
	// uni-directional many-to-one association to Instr
	@ManyToOne
	@JoinColumn(name="INSTR_ID")
	private InstrEntity instr;
	//***********************************************

	@EmbeddedId
	private HisPrEntityPK id;

	@Column(name="CLOSEPR", nullable=false, precision=16, scale=5)
	private BigDecimal closingPrice;

	@Column(name="P_FILE_ID", nullable=false)
	private int parentFileId = -1;

	@Column(nullable=false, length=1)
	private String status;

	@Column(name="UPDDATE", nullable=false)
	private Timestamp updateDate = new Timestamp(System.currentTimeMillis());

	@Column(name="UPDTYPE", nullable=false, length=1)
	private String updateType = "C";

	@Column(name="UPDUSR", nullable=false, length=30)
	private String updatingUser = "SYSTEM";
	
	
    public HisPrEntity() {
    	
    }
    

	public HisPrEntityPK getId() {
		return this.id;
	}

	public void setId(HisPrEntityPK id) {
		this.id = id;
	}
	
	public BigDecimal getClosingPrice() {
		return this.closingPrice;
	}

	public void setClosingPrice(BigDecimal closingPrice) {
		this.closingPrice = closingPrice;
	}

	public int getParentFileId() {
		return this.parentFileId;
	}

	public void setParentFileId(int parentFileId) {
		this.parentFileId = parentFileId;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateType() {
		return this.updateType;
	}

	public void setUpdateType(String updateType) {
		this.updateType = updateType;
	}

	public String getUpdatingUser() {
		return this.updatingUser;
	}

	public void setUpdatingUser(String updatingUser) {
		this.updatingUser = updatingUser;
	}


	public InstrEntity getInstr() {
		return instr;
	}


	public void setInstr(InstrEntity instr) {
		this.instr = instr;
	}
	
	
	@Override
	public String toString() {
		
		return "[INSTR_ID: " + this.id.getInstrumentId() + ", PRICEDATE: " + this.id.getPriceDate() + ", PRICE: " + this.closingPrice + "]";
	}


	@Override
	public HisPrEntity clone() throws CloneNotSupportedException {
		
		HisPrEntity hisPr = new HisPrEntity();
		
		HisPrEntityPK id = new HisPrEntityPK();
		id.setInstrumentId(this.getId().getInstrumentId());
		id.setPriceDate(this.getId().getPriceDate());
		id.setPriceTime(this.getId().getPriceTime());
		
		hisPr.id = id;
		
		hisPr.closingPrice = this.closingPrice;
		hisPr.parentFileId = this.parentFileId;
		hisPr.status = this.status;
		
		
		return hisPr;
	}
	
	
	

}