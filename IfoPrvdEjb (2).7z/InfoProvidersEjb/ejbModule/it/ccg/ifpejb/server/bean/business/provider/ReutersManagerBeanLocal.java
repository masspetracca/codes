package it.ccg.ifpejb.server.bean.business.provider;


import javax.ejb.Local;

@Local
public interface ReutersManagerBeanLocal {
	
	public void checkNirAlignment() throws Exception;
	public void alignNirRequest() throws Exception;
	
	public void checkFcpAlignment() throws Exception;
	public void alignFcpRequest() throws Exception;
	
	public void checkCollAlignment() throws Exception;
	public void alignCollRequest() throws Exception;

}
