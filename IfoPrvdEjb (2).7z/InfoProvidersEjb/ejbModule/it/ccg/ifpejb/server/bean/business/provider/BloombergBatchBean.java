package it.ccg.ifpejb.server.bean.business.provider;

import it.ccg.ifpejb.server.bean.eao.FTPFileEAOLocal;
import it.ccg.ifpejb.server.bean.eao.InstrEAOLocal;
import it.ccg.ifpejb.server.bean.entity.HisPrEntity;
import it.ccg.ifpejb.server.bean.entity.HisPrEntityPK;
import it.ccg.ifpejb.server.bean.entity.InstrEntity;
import it.ccg.ifpejb.server.exception.DuplicateKeyException;
import it.ccg.ifpejb.server.exception.ExceptionUtil;
import it.ccg.ifpejb.server.exception.FTPException;
import it.ccg.ifpejb.server.exception.NewDataNotAvailableException;
import it.ccg.ifpejb.server.file.parser.BloombergResponseParser;
import it.ccg.ifpejb.server.file.template.BloombergResponseTemplate;
import it.ccg.ifpejb.server.file.util.BloombergResponseFTPFileComparator;
import it.ccg.ifpejb.server.ftp.FTPFactory;
import it.ccg.ifpejb.server.ftp.FTPServiceInterface;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;
import it.ccg.ifpejb.server.providerengine.ProviderEngine;
import it.ccg.ifpejb.server.security.SecurityEjb;
import it.ccg.ifpejb.server.system.MailManager;
import it.ccg.ifpejb.server.system.SystemProperties;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.log4j.Logger;

import com.bloomberg.datalic.api.BBDES;


/**
 * Session Bean implementation class BloombergBatchBean
 */
@Stateless
public class BloombergBatchBean implements BloombergBatchBeanLocal {
	
	private static Properties properties;
	
	private static String TEMP_DIR_ABSOLUTE_PATH;
	
	private static String PROVIDER_NAME;
	private static String FLOW_CURR_NAME;
	private static String FLOW_NIR_NAME;
	private static String CURR_RESPONSE_ENC_FILE_NAME;
	private static String CURR_RESPONSE_DEC_FILE_NAME;
	private static String NIR_RESPONSE_ENC_FILE_NAME;
	private static String NIR_RESPONSE_DEC_FILE_NAME;
	
	private static String PATH_SEPARATOR;
	
	private static String DEC_KEY;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	private static final Logger monitorLogger = LoggerFactory.getLogger(LoggerFactory.MONITOR_LOGGER);
	
	
	private FTPServiceInterface ftpServiceInterface;
	
	
	@EJB
	private InstrEAOLocal instrEAOLocal;
	
	@EJB
	private FTPFileEAOLocal ftpFileEAOLocal;
	
	@EJB
	private BloombergManagerBeanLocal bloombergManagerBeanLocal;
	
	@EJB
	private BaseBeanLocal baseBeanLocal;
	
	

    /**
     * Default constructor. 
     */
    public BloombergBatchBean() throws Exception {
		
    	try {
    		
    		properties = SystemProperties.getProperties();
    		
        	TEMP_DIR_ABSOLUTE_PATH = properties.getProperty("user.install.root") +
    		  						 properties.getProperty("ifp_temp_dir_relative_path");
        	
        	PATH_SEPARATOR = properties.getProperty("file.separator");
        	
        	
        	// provider engine IDs from properties file
        	PROVIDER_NAME = properties.getProperty("provider.bloomberg.name");
        	
    		DEC_KEY = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getDataDecKey();
    		
    	}
    	catch(Exception e) {
    		
    		logger.warn(new StandardLogMessage("Exception into bean constructor. Exception: " + e));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
    }
    
    
    
    // Batches START ***************************************************************************************************************************************
    
    @Override
	public void currencyRatesBatch() throws Exception {
    	
		try {
			
			logger.info(new StandardLogMessage("Bloomberg CURR synchronization started."));
			
			
			// first, check Bloomberg request alignment
			// NON BLOCCANTE
			try {
				this.bloombergManagerBeanLocal.checkCurrAlignment();
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Bloomberg CURR request alignment check failed."));
				// default logger
				logger.warn(new StandardLogMessage("Bloomberg CURR request alignment check failed."));
			}
			
			
			FLOW_CURR_NAME = properties.getProperty("provider.bloomberg.flow.curr.name");
			CURR_RESPONSE_ENC_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_CURR_NAME).getResponseFileName();
        	CURR_RESPONSE_DEC_FILE_NAME = CURR_RESPONSE_ENC_FILE_NAME + ".dec";
			
			
			// create temporary folder and files to work
			// ***************************************************************************************************************
			String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempEncFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + CURR_RESPONSE_ENC_FILE_NAME;
			if(!new File(tempEncFileAbsPath).createNewFile()) {
				
				throw new Exception("Unable to create temp file \'" + tempEncFileAbsPath + "\'.");
			}
			
			String tempDecFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + CURR_RESPONSE_DEC_FILE_NAME;
			if(!new File(tempDecFileAbsPath).createNewFile()) {
				
				throw new Exception("Unable to create temp file \'" + tempDecFileAbsPath + "\'.");
			}
			// ***************************************************************************************************************
			
			// get file from ftp and save it into tempEncFileAbsPath
			String fileName = this.getFileFromFTP(CURR_RESPONSE_ENC_FILE_NAME, new File(tempEncFileAbsPath));
			
			// decrypting
			this.decriptFile(tempEncFileAbsPath, tempDecFileAbsPath);
			
			// TODO
			// check if response instruments match request instruments
			/*if(!this.checkInstrumnetsMatching("CUR", new File(tempDecFileAbsPath))) {
				
				throw new Exception("Instruments list in response file \'" + tempDecFileAbsPath + "\' doesn\'t match instruments list in remote request file.");
			}*/
			
			// parse file
			BloombergResponseParser bloombergResponseParser = new BloombergResponseParser();
			BloombergResponseTemplate bloombergResponseTemplate = bloombergResponseParser.parse(new File(tempDecFileAbsPath));
			List<HisPrEntity> hisPrEntityList = this.convertRawDataToHPE(bloombergResponseTemplate);
			
			// persist data
			try {
				this.baseBeanLocal.persistHistoricalData(hisPrEntityList);
			}
			catch(DuplicateKeyException e) {
				
				monitorLogger.warn(new StandardLogMessage("Bloomberg CURR batch - Duplicate key values found in new data."));
			}
			
			// save information about executed batch
			this.baseBeanLocal.saveJobInfo("Bloomberg", "Bloomberg CURR synchronization", hisPrEntityList, fileName, tempDecFileAbsPath);
			
			// change status from oneShot to disable for each ex-oneShot instrument in the input list
			try {
				this.baseBeanLocal.updateOneShotToDisable(hisPrEntityList);
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Bloomberg CURR batch - Unable to change ONESHOT to DISABLE."));
				// default logger
				logger.warn(new StandardLogMessage("Bloomberg CURR batch - Unable to change ONESHOT to DISABLE."));
				ExceptionUtil.logCompleteStackTrace(logger, e);
			}
			
			// align bloomberg request
			try {
				this.bloombergManagerBeanLocal.alignCurrRequest();
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Bloomberg CURR request alignment failed."));
				// default logger
				logger.warn(new StandardLogMessage("Bloomberg CURR request alignment failed."));
				ExceptionUtil.logCompleteStackTrace(logger, e);
			}
			
			// monitor info
			monitorLogger.info(new StandardLogMessage("Bloomberg CURR synchronization successfully executed."));
			// default logger
			logger.info(new StandardLogMessage("Bloomberg CURR synchronization successfully executed."));
			
			
			// delete tempWorkingFolder
			//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
			
		}
		catch(NewDataNotAvailableException e) {
			// monitor warning
			monitorLogger.warn(new StandardLogMessage("Bloomberg CURR synchronization not completed. New data not available."));
			// default logger
			logger.warn(new StandardLogMessage("Bloomberg CURR synchronization not completed. New data not available."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Bloomberg CURR synchronization not completed. New data not available.");
		}
		catch(FTPException e) {
			
			// default logger
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			// FTPEception is managed into caller class.
			throw e;
		}
		catch(Exception e) {
			// monitor error
			monitorLogger.error(new StandardLogMessage("Bloomberg CURR synchronization failed."));
			// default logger
			logger.error(new StandardLogMessage("Bloomberg CURR synchronization failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// send notification mail
			MailManager mailManager = new MailManager();
			String message = "Bloomberg CURR synchronization failed.";
			mailManager.sendMail("InfoProviders System generic error", message, null);
			
			// throw at caller
			throw new Exception("Bloomberg CURR synchronization failed.");
		}
		
    }
    
    @Override
	public void nodesInterestRatesBatch() throws Exception {
    	
		try {
			
			
			logger.info(new StandardLogMessage("Bloomberg NIR synchronization started."));
			
			// first, check Bloomberg request alignment
			// NON BLOCCANTE
			try {
				this.bloombergManagerBeanLocal.checkNirAlignment();
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Bloomberg NIR request alignment check failed."));
				// default logger
				logger.warn(new StandardLogMessage("Bloomberg NIR request alignment check failed."));
			}
			

			FLOW_NIR_NAME = properties.getProperty("provider.bloomberg.flow.nir.name");
        	NIR_RESPONSE_ENC_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_NIR_NAME).getResponseFileName();
        	NIR_RESPONSE_DEC_FILE_NAME = NIR_RESPONSE_ENC_FILE_NAME + ".dec";
			
			
			// create temporary folder and files to work
			// *****************************************************************************************************************

			String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempEncFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + NIR_RESPONSE_ENC_FILE_NAME;
			if(!new File(tempEncFileAbsPath).createNewFile()) {
				
				throw new Exception("Unable to create temp file \'" + tempEncFileAbsPath + "\'.");
			}
			
			String tempDecFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + NIR_RESPONSE_DEC_FILE_NAME;
			if(!new File(tempDecFileAbsPath).createNewFile()) {
				
				throw new Exception("Unable to create temp file \'" + tempDecFileAbsPath + "\'.");
			}
			// *****************************************************************************************************************
			
			
			// get file from ftp and save it into tempEncFileAbsPath
			String fileName = this.getFileFromFTP(NIR_RESPONSE_ENC_FILE_NAME, new File(tempEncFileAbsPath));
			
			// decrypting
			this.decriptFile(tempEncFileAbsPath, tempDecFileAbsPath);
			
			// parse file
			BloombergResponseParser bloombergResponseParser = new BloombergResponseParser();
			BloombergResponseTemplate bloombergResponseTemplate = bloombergResponseParser.parse(new File(tempDecFileAbsPath));
			List<HisPrEntity> hisPrEntityList = this.convertRawDataToHPE(bloombergResponseTemplate);
			
			// persist data
			try {
				this.baseBeanLocal.persistHistoricalData(hisPrEntityList);
			}
			catch(DuplicateKeyException e) {
				
				monitorLogger.warn(new StandardLogMessage("Bloomberg NIR batch - Duplicate key values found in new data."));
			}
			
			// save information about executed batch
			this.baseBeanLocal.saveJobInfo("Bloomberg", "Bloomberg NIR synchronization", hisPrEntityList, fileName, tempDecFileAbsPath);
			
			// change status from oneShot to disable for each ex-oneShot instrument
			try {
				this.baseBeanLocal.updateOneShotToDisable(hisPrEntityList);
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Bloomberg NIR batch - Unable to change ONESHOT to DISABLE."));
				// default logger
				logger.warn(new StandardLogMessage("Bloomberg NIR batch - Unable to change ONESHOT to DISABLE."));
				ExceptionUtil.logCompleteStackTrace(logger, e);
			}
			
			// align bloomberg request
			try {
				this.bloombergManagerBeanLocal.alignNirRequest();
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Bloomberg NIR request alignment failed."));
				// default logger
				logger.warn(new StandardLogMessage("Bloomberg NIR request alignment failed."));
				ExceptionUtil.logCompleteStackTrace(logger, e);
			}
			
			// monitor info
			monitorLogger.info(new StandardLogMessage("Bloomberg NIR synchronization successfully executed."));
			// default logger
			logger.info(new StandardLogMessage("Bloomberg NIR synchronization successfully executed."));
			
			
			// delete tempWorkingFolder
			//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
		}
		catch(NewDataNotAvailableException e) {
			// monitor warning
			monitorLogger.warn(new StandardLogMessage("Bloomberg NIR synchronization not completed. New data not available."));
			// default logger
			logger.warn(new StandardLogMessage("Bloomberg NIR synchronization not completed. New data not available."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Bloomberg NIR synchronization not completed. New data not available.");
		}
		catch(FTPException e) {
			
			// default logger
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			// FTPEception is managed into caller class.
			throw e;
		}
		catch(Exception e) {
			// monitor error
			monitorLogger.error(new StandardLogMessage("Bloomberg NIR synchronization failed."));
			// default logger
			logger.error(new StandardLogMessage("Bloomberg NIR synchronization failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// send notification mail
			MailManager mailManager = new MailManager();
			String message = "Bloomberg NIR synchronization failed.";
			mailManager.sendMail("InfoProviders System batch generic error", message, null);
			
			// throw at caller
			throw new Exception("Bloomberg NIR synchronization failed.");
		}
		
    }
    
    
    // Batches END ***************************************************************************************************************************************
    
    
    
	// Getting file START ***************************************************************************************************************************************
    
    // get file from ftp and save it into tempFileAbsPath
    private String getFileFromFTP(String outType, File fileToSaveInto) throws Exception {
    	
    	String fileName = null;
    	
    	// initialize ftpService
		this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.BLOOMBERG_SERVICE);
		
		// compute file name to download
		FTPFile[] fileArray = this.ftpServiceInterface.getResponseFilesInfo();
		fileName = this.getOutTypeLastFileInfo(fileArray, outType).getName();
		
		// controllo file gi� scaricato / dati gi� scaricati
		if(this.ftpFileEAOLocal.findByName(fileName) != null) {
			
			logger.warn(new StandardLogMessage("File \'" + fileName + "\' already downloaded. New data not available."));
			
			throw new NewDataNotAvailableException("File \'" + fileName + "\' already downloaded. New data not available.");
		}
		
		// download file
		this.ftpServiceInterface.downloadResponseFile(fileName, fileToSaveInto);
    	
		
		logger.info(new StandardLogMessage("File \'" + fileName + "\' successfully downloaded."));
		
		
		return fileName;
		
    }
    
	// Getting file END ***************************************************************************************************************************************
    
    
    // Parsing file START ***************************************************************************************************************************************
    
    // This method correctly converts bloomberg response data in the form [BBGCODE, RESERVED, RESERVED, PRICE, DATE]
	private List<HisPrEntity> convertRawDataToHPE(BloombergResponseTemplate bloombergResponseTemplate) throws Exception {
		
		try {
			
			List<Object[]> data = bloombergResponseTemplate.getData();
			
			List<HisPrEntity> list = new ArrayList<HisPrEntity>();
			
			for(Object[] record : data) {
		
				// check corrupted data
				if(record.length < 3) {
					
					String errorMessage = "Missing values in data file. Corrupted line: " + ArrayUtils.toString(record);
					
					logger.warn(new StandardLogMessage(errorMessage));
					
					monitorLogger.warn(new StandardLogMessage(errorMessage));
					
					continue;
				}
				
				for(Object object : record) {
					
					if(((String)object).trim().equalsIgnoreCase("") ||
					   ((String)object).trim().equalsIgnoreCase("N.A.") ||
					   ((String)object).trim().equalsIgnoreCase("N.D.") ||
					   ((String)object).trim().equalsIgnoreCase("N.S.") ||
					   ((String)object).trim().equalsIgnoreCase("FLD UNKNOWN")) {
						
						String errorMessage = "Invalid values in data file. Corrupted line: " + ArrayUtils.toString(record);
						
						logger.error(new StandardLogMessage(errorMessage));
						
						monitorLogger.error(new StandardLogMessage(errorMessage));
						
						throw new Exception(errorMessage);
					}
					
				}
				
				
				
				HisPrEntity hisPrEntity = new HisPrEntity();
				HisPrEntityPK hisPrEntityPK = new HisPrEntityPK();
				
				String bbgCode = ((String)record[0]).trim();
				int date = Integer.parseInt(((String)record[4]).trim());
				String price = ((String)record[3]).trim();
				
				InstrEntity instrEntity = this.instrEAOLocal.findByBloombergCode(bbgCode);
				
				// *** IMPORTANT ***
				// Check if the downloaded line matches with an instrument in my static data.
				// IF NOT, it means i am downloading something useless and someone directly modified 
				// Bloomberg request file on Bloomberg account folder;
				// or i am testing some new instrument in a different environment!!!
				if(instrEntity == null) {
					
					logger.warn(new StandardLogMessage("Instrument having Bloomberg Code \'" + bbgCode + "\' not fount in Static Data. Check StaticData/Bloomberg request alignment."));
					monitorLogger.warn(new StandardLogMessage("Instrument having Bloomberg Code \'" + bbgCode + "\' not fount in Static Data. Check StaticData/Bloomberg request alignment."));
					
					continue;
					//throw new Exception();
				}
				// ***
				
				int instrumentId = (instrEAOLocal.findByBloombergCode((String)record[0])).getInstrumentId();
				hisPrEntityPK.setInstrumentId(instrumentId);
				hisPrEntityPK.setPriceDate(date);
				//hisPrEntityPK.setPriceTime(priceTime);
				hisPrEntity.setId(hisPrEntityPK);
				hisPrEntity.setClosingPrice(new BigDecimal(price));
				
				list.add(hisPrEntity);
				
			}
			
			logger.info(new StandardLogMessage("Parsing successfully completed."));
			

			return list;
		}
		catch(Exception e) {
			
			throw new Exception("Cannot convert from raw data to HistoricalPricesEntity. " + e.toString());
		}
		
	}
	
    // Parsing file END ***************************************************************************************************************************************
    
    
    
	private void decriptFile(String encFileAbsPath, String decFileAbsPath) throws Exception {
		
		try {
			BBDES bbDes = new BBDES(DEC_KEY);
			bbDes.setuseCAPoption(true);
			bbDes.setuuencode(true);
			bbDes.decryptDES(encFileAbsPath, decFileAbsPath);
			
			logger.info(new StandardLogMessage("Decripting file successfully completed."));
		}
		catch(Exception e) {
			
			throw new Exception("File decrypting failed.");
		}
		
	}
	
	
	/*private boolean checkInstrumnetsMatching(String instrumentsType, File responseFile) throws Exception {
		boolean result = false;
		
		try {
	    	
			String remoteRequestFileName = null;
			
			if(instrumentsType.equalsIgnoreCase("CUR")) {
				
				remoteRequestFileName = REMOTE_BBG_CURR_REQ_FILE_NAME;
			}
			else if(instrumentsType.equalsIgnoreCase("NIR")) {
				
				remoteRequestFileName = REMOTE_BBG_NIR_REQ_FILE_NAME;
			}
			else {
				
				throw new Exception("Cannot find file from Bloomberg server. File type \'" + instrumentsType + "\' not found.");
			}
			
			
			// remote request instruments list
			
			// create temporary folder and files to work
			String tempWorkingFolderName = Crypto.MD5(Util.getUniqueToken());
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + REMOTE_BBG_CURR_REQ_FILE_NAME;
			File file = new File(tempFileAbsPath);
			file.createNewFile();
			
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.BLOOMBERG_SERVICE);
			this.ftpServiceInterface.downloadRequestFile(remoteRequestFileName, new FileOutputStream(file));
			
			BloombergRequestParser bloombergRequestParser = new BloombergRequestParser();
			BloombergRequestTemplate bloombergRequestTemplate = bloombergRequestParser.parse(file);
			List<String> remoteSecuritiesList = bloombergRequestTemplate.getSecurities();
			
    	}
		catch(Exception e) {
			
			throw new Exception("File download failed.");
		}
		
		
		return result;
	}*/
	
	
	
	private FTPFile getOutTypeLastFileInfo(FTPFile[] fileArray, String outType) throws Exception {
		
		// file name format: outType.yyyymmdd (for example: "ifp_bbg_nir.out.20120303")
		
		String prefix = outType + ".";
		
		Set<FTPFile> fileList = new TreeSet<FTPFile>(new BloombergResponseFTPFileComparator(prefix));
		
		for(FTPFile file : fileArray) {
			
			String fileName = file.getName();
			
			if(fileName.startsWith(prefix)) {
				
				// scarto tutti i file bbg_curr.out.yyyymmdd.n
				if(fileName.split("\\.").length > 3) {
					
					continue;
				}
				
				fileList.add(file);
			}
		}
		
		if(fileList.size() < 1) {
			
			throw new Exception(outType + " data not available on Bloomberg server.");
		}
		
		// prendo il primo, la lista � ordinata in modo decrescente secondo la data
		return ((FTPFile)fileList.toArray()[0]);
	}
	
	
	

	

}
