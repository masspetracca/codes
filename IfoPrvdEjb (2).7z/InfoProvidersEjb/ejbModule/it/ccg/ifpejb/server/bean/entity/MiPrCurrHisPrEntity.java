package it.ccg.ifpejb.server.bean.entity;

import it.ccg.ifpejb.server.system.DateTimeUtils;

import java.io.Serializable;
import javax.persistence.*;

import java.math.BigDecimal;


/**
 * The persistent class for the TCOCCYF00F database table.
 * 
 */
@Entity
@Table(name="TCOCCYF00F")
@NamedQueries({
	@NamedQuery(name="fetchByInstrId&PriceDate", query="SELECT hisPr " +
												       "FROM MiPrCurrHisPrEntity hisPr " +
												     	"WHERE hisPr.ccyBlom = :ccyBlom AND hisPr.ccyData = :ccyData")
											
})
public class MiPrCurrHisPrEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(nullable=false, length=6)
	private String ccyBlom;

	@Column(nullable=false, precision=8)
	private BigDecimal ccyData;
	
	@Column(nullable=false, precision=6)
	private BigDecimal ccyOra = new BigDecimal(000000);
	
	@Column(nullable=false, precision=9, scale=6)
	private BigDecimal ccyVal;

	@Column(nullable=false, length=1)
	private String ccConv;
	
	@Column(nullable=false, length=3)
	private String ccyIso;

	@Column(nullable=false, length=10)
	private String ccyPgm = "IFP";

	@Column(nullable=false, length=3)
	private String ccySet;
	
	@Column(nullable=false, precision=8)
	private BigDecimal ccyDTEla = new BigDecimal(DateTimeUtils.getCurrentDateYYYYMMDD());
	
	@Column(nullable=false, precision=6)
	private BigDecimal ccyTime = new BigDecimal(DateTimeUtils.getCurrentTimeHHMMSS());

	@Column(nullable=false, length=10)
	private String ccyUser = "SYSTEM";

	
	
    public MiPrCurrHisPrEntity() {
    	
    }

	
	
	
	public String getCcConv() {
		return ccConv;
	}




	public void setCcConv(String ccConv) {
		this.ccConv = ccConv;
	}




	public String getCcyBlom() {
		return ccyBlom;
	}




	public void setCcyBlom(String ccyBlom) {
		this.ccyBlom = ccyBlom;
	}




	public BigDecimal getCcyData() {
		return ccyData;
	}




	public void setCcyData(BigDecimal ccyData) {
		this.ccyData = ccyData;
	}




	public BigDecimal getCcyDTEla() {
		return ccyDTEla;
	}




	public void setCcyDTEla(BigDecimal ccyDTEla) {
		this.ccyDTEla = ccyDTEla;
	}




	public String getCcyIso() {
		return ccyIso;
	}




	public void setCcyIso(String ccyIso) {
		this.ccyIso = ccyIso;
	}




	public BigDecimal getCcyOra() {
		return ccyOra;
	}




	public void setCcyOra(BigDecimal ccyOra) {
		this.ccyOra = ccyOra;
	}




	public String getCcyPgm() {
		return ccyPgm;
	}




	public void setCcyPgm(String ccyPgm) {
		this.ccyPgm = ccyPgm;
	}




	public String getCcySet() {
		return ccySet;
	}




	public void setCcySet(String ccySet) {
		this.ccySet = ccySet;
	}




	public BigDecimal getCcyTime() {
		return ccyTime;
	}




	public void setCcyTime(BigDecimal ccyTime) {
		this.ccyTime = ccyTime;
	}




	public String getCcyUser() {
		return ccyUser;
	}




	public void setCcyUser(String ccyUser) {
		this.ccyUser = ccyUser;
	}




	public BigDecimal getCcyVal() {
		return ccyVal;
	}




	public void setCcyVal(BigDecimal ccyVal) {
		this.ccyVal = ccyVal;
	}




	@Override
	public String toString() {
		
		return "[" + 
				"CCYBLOM: " + this.ccyBlom + ", CYYDATA: " + this.ccyData + ", CCYORA: " + this.ccyOra + ", CCYVAL: " + this.ccyVal + 
				", CCCONV: " + this.ccConv + ", CCYISO: " + this.ccyIso + ", CCYSET: " + this.ccySet + 
				", CCYPGM: " + this.ccyPgm + ", CCYUSER: " + this.ccyUser + ", CCYDTELA: " + this.ccyDTEla + ", CCYTIME: " + this.ccyTime + 
				"]";
	}
	
	
	

}