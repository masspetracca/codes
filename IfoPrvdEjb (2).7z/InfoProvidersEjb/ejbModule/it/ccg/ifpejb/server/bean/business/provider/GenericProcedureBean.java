package it.ccg.ifpejb.server.bean.business.provider;

import it.ccg.ifpejb.server.bean.eao.HisPrEAOLocal;
import it.ccg.ifpejb.server.bean.eao.InstrEAOLocal;
import it.ccg.ifpejb.server.bean.entity.HisPrEntity;
import it.ccg.ifpejb.server.bean.entity.HisPrEntityPK;
import it.ccg.ifpejb.server.bean.entity.InstrEntity;
import it.ccg.ifpejb.server.exception.ExceptionUtil;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;
import it.ccg.ifpejb.server.system.SystemProperties;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Properties;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class GenericFunctionBean
 */
@Stateless
public class GenericProcedureBean implements GenericProcedureBeanLocal {
    
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	private static String TEMP_UPLOAD_FOLDER_ABSOLUTE_PATH;
	
	@EJB
	private InstrEAOLocal instrEAOLocal;
	
	@EJB
	private HisPrEAOLocal historicalPricesEAOLocal;
	
	@EJB
	private BaseBeanLocal baseBeanLocal;
	
	
	
	/**
     * Default constructor. 
     */
    public GenericProcedureBean() throws Exception {
    	
    	try {
    		
    		TEMP_UPLOAD_FOLDER_ABSOLUTE_PATH = SystemProperties.getProperty("user.install.root") +
    										   SystemProperties.getProperty("ifp_upload_dir_relative_path");
    	}
    	catch(Exception e) {
    		
    		logger.warn(new StandardLogMessage("Exception into bean constructor. Exception: " + e));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
		
    }
    
    
    // Procedures START ***************************************************************************************************************************************

	@Override
	public void addHistoricalDataFromUploadedFile(String fileName) throws Exception {
		
		try {
	    	logger.info(new StandardLogMessage("Procedure \'addHistoricalDataFromUploadedFile\' started."));
			
			// uploaded file
			String uploadedFileAbsolutePath = TEMP_UPLOAD_FOLDER_ABSOLUTE_PATH + fileName;
			File uploadedFile = new File(uploadedFileAbsolutePath);
			
			System.out.println("WARN - name: " + fileName);
			
			System.out.println("WARN - abs path: " + uploadedFile.getAbsolutePath());
			System.out.println("WARN - file name: " + uploadedFile.getName());
			System.out.println("WARN - path: " + uploadedFile.getPath());
			
			
			// parse file
			List<HisPrEntity> hisPrEntityList = this.convertData(uploadedFile);
			
			// persist data
			this.baseBeanLocal.persistHistoricalData(hisPrEntityList);
	
			// save information about executed procedure
			this.baseBeanLocal.saveJobInfo("/", "Historical data inserting from uploaded file", hisPrEntityList, fileName, uploadedFileAbsolutePath);
			
			// delete uploaded file
			if(!uploadedFile.delete()) {
				
				logger.warn(new StandardLogMessage("Unable to delete uploaded file \'" + uploadedFileAbsolutePath + "\'."));
			}
			else {
				
				logger.info(new StandardLogMessage("Uploaded file \'" + uploadedFileAbsolutePath + "\' correctly deleted."));
			}
			
			
			logger.info(new StandardLogMessage("Procedure \'addHistoricalDataFromUploadedFile\' correctly executed."));
		}
		catch(Exception e) {
			logger.error(new StandardLogMessage("Procedure \'addHistoricalDataFromUploadedFile\' failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Procedure \'addHistoricalDataFromUploadedFile\' failed.");
		}
		
	}
	
	// TODO
	/*@Override
	public void checkInstrumentHistoricalDataAlignment(int instrumentId) throws Exception {
		
		int minPriceDate = this.historicalPricesEAOLocal.getInstrMinPriceDate(instrumentId);
		
		GregorianCalendar gc = new GregorianCalendar(new Integer(Integer.toString(minPriceDate).substring(0, 4)),
													 new Integer(Integer.toString(minPriceDate).substring(4, 6)), 
													 new Integer(Integer.toString(minPriceDate).substring(6, 8)));
		
		GregorianCalendar todayGC = new GregorianCalendar();
		int today = Integer.parseInt(Integer.toString(todayGC.get(Calendar.YEAR)) + 
									 String.format("%02d", todayGC.get(Calendar.MONTH) + 1) + 
									 String.format("%02d", todayGC.get(Calendar.DATE)));
		
		
		int priceDate;
		HisPrEntityPK hisPrEntityPK = new HisPrEntityPK();
		hisPrEntityPK.setInstrumentId(instrumentId);
		HisPrEntity hisPrEntity;
		do {
			
			priceDate = Integer.parseInt(Integer.toString(gc.get(Calendar.YEAR)) + 
					 					 String.format("%02d", gc.get(Calendar.MONTH) + 1) + 
					 					 String.format("%02d", gc.get(Calendar.DATE)));
			
			if((gc.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY) && (gc.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY)) {
				
				hisPrEntityPK.setPriceDate(priceDate);
				
				hisPrEntity = this.historicalPricesEAOLocal.findByPrimaryKey(hisPrEntityPK);
				
				if(hisPrEntity != null) {
					
					logger.debug(new StandardLogMessage("Pair \'INSTR_ID: " + hisPrEntityPK.getInstrumentId() + ", PRICADATE: " + hisPrEntityPK.getPriceDate() + 
																				 "\' (day of week: " + gc.get(Calendar.DAY_OF_WEEK) + ") found."));
				}
				else {
					
					logger.warn(new StandardLogMessage("Pair \'INSTR_ID: " + hisPrEntityPK.getInstrumentId() + ", PRICADATE: " + hisPrEntityPK.getPriceDate() + 
							 													"\' (day of week: " + gc.get(Calendar.DAY_OF_WEEK) + ") not found."));
				}
				
			}
			
			
			gc.add(Calendar.DAY_OF_MONTH, 1);
		}
		while(priceDate < today);
		
	}*/
	
	// Procedures END ***************************************************************************************************************************************
	
	
	// Parsing file END ***************************************************************************************************************************************
	
	// convert data file (file line format --> [code, date, price])
    private List<HisPrEntity> convertData(File file) throws Exception {
		List<HisPrEntity> list = new ArrayList<HisPrEntity>();
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		
		// salto la prima riga d'intestazione
		String line = br.readLine();
		
		line = br.readLine();
		while(line != null) {
			String[] values = line.split(",");
			
			// check corrupted data
			if(values.length < 3) {
				logger.warn(new StandardLogMessage("Missing values in data file. Corrupted line: \'" + line + "\'"));
				
				line = br.readLine();
				
				continue;
			}
			
			String code = values[0].trim();
			int date = Integer.parseInt(values[1].trim());
			String price = values[2].trim();
			
			HisPrEntity hisPrEntity = new HisPrEntity();
			HisPrEntityPK hisPrEntityPK = new HisPrEntityPK();
			
			InstrEntity instrEntity = this.instrEAOLocal.findByCode(code);
			if(instrEntity == null) {
				logger.error(new StandardLogMessage("Instrument having Code \'" + code + "\' not fount in Static Data. Check Static Data and Providers request alignment."));
				
				throw new Exception("Instrument having Code \'" + code + "\' not fount in Static Data. Check Static Data and Providers request alignment.");
			}
			int instrumentId = instrEntity.getInstrumentId();
			hisPrEntityPK.setInstrumentId(instrumentId);
			hisPrEntityPK.setPriceDate(date);
			hisPrEntity.setId(hisPrEntityPK);
			hisPrEntity.setClosingPrice(new BigDecimal(price));
			
			list.add(hisPrEntity);
			
			line = br.readLine();
		}
		
		return list;
	}
    
    // Parsing file END ***************************************************************************************************************************************
    
	

}
