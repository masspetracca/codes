package it.ccg.ifpejb.server.exception;

public class NewDataNotAvailableException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public NewDataNotAvailableException() {
		super();
	}
	
	public NewDataNotAvailableException(String msg) {
		super(msg);
	}
	
}