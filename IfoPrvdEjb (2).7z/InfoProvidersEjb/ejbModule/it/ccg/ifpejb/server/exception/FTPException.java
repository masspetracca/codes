package it.ccg.ifpejb.server.exception;

public class FTPException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public FTPException() {
		super();
	}
	
	public FTPException(String msg) {
		super(msg);
	}

}
