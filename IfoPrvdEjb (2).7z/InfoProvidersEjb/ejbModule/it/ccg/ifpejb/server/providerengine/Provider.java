package it.ccg.ifpejb.server.providerengine;


import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;



@XmlRootElement(name="provider")
@XmlAccessorType(XmlAccessType.FIELD)
public class Provider {
	
	@XmlElement
	private String name;
	
	@XmlElement
	private String url;
	
	@XmlElement
	private String userName;
	
	@XmlElement
	private String password;
	
	@XmlElement
	private String dataDecKey;
	
	@XmlElement
	private String downloadDataDir;
	
	@XmlElement
	private String uploadRequestDir;
	
	@XmlElement
	private String downloadRequestDir;
	
	@XmlElement(name="flow")
	private List<Flow> flowList;
	
	
	
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDataDecKey() {
		return dataDecKey;
	}

	public void setDataDecKey(String dataDecKey) {
		this.dataDecKey = dataDecKey;
	}

	public String getDownloadDataDir() {
		return downloadDataDir;
	}
	
	public void setDownloadDataDir(String downloadDataDir) {
		this.downloadDataDir = downloadDataDir;
	}

	public String getUploadRequestDir() {
		return uploadRequestDir;
	}

	public void setUploadRequestDir(String uploadRequestDir) {
		this.uploadRequestDir = uploadRequestDir;
	}

	public String getDownloadRequestDir() {
		return downloadRequestDir;
	}

	public void setDownloadRequestDir(String downloadRequestDir) {
		this.downloadRequestDir = downloadRequestDir;
	}

	public List<Flow> getFlowList() {
		return flowList;
	}

	public void setFlowList(List<Flow> flowList) {
		this.flowList = flowList;
	}
	
	
	@Override
	public String toString() {
		
		String toString = "[name: " + this.name + ", " + "\n" + 
						"   url: " + this.url + ", " + "\n" + 
						"   userName: " + this.userName + ", " + "\n" + 
						"   password: " + this.password + ", " + "\n" + 
						"   dataDecKey: " + this.dataDecKey + ", " + "\n" + 
						"   downloadDataDir: " + this.downloadDataDir + ", " + "\n" + 
						"   uploadRequestDir: " + this.uploadRequestDir + ", " + "\n" + 
						"   downloadRequestDir: " + this.downloadRequestDir + ", " + "\n" + 
						"   flowList: [";
		
		if(this.flowList != null) {
			   		
	   		for(Flow flow : this.flowList) {
	   			
	   			toString += flow.toString() + ", ";
	   		}
	   		
	   		toString = toString.substring(0, toString.length() - 2);
		}
		
		toString += "]]";
		
		
		return toString;
	}
	
	
	
	// *** Query ***
	
	public Flow getFlowByName(String flowName) {
		
		Flow flow = null;
		
		for(Flow f : this.flowList) {
			
			if(f.getName().equalsIgnoreCase(flowName)) {
				
				flow = f;
				
				break;
			}
		
		}
		
		
		return flow;
	}
	
	/*public Flow getFlowByJobMethodNClass(String method, Class<?> _class) {
		
		Flow flow = null;
		
		_1: for(Flow f : this.flowList) {
			
			for(Job j : f.getJobList()) {
				
				if(j.getMethodName().equalsIgnoreCase(method) && j.getMethodClass().equalsIgnoreCase(_class.getCanonicalName())) {
					
					flow = f;
					
					break _1;
				}
			}
			
			
		}
		
		
		return flow;
	}*/
	
	
	
}
