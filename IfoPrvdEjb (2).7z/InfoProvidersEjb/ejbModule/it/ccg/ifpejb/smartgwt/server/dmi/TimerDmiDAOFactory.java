package it.ccg.ifpejb.smartgwt.server.dmi;

import it.ccg.ifpejb.server.system.LocalBeanLookup;

public class TimerDmiDAOFactory {
	
	
	public TimerDmiDAOFactory() {
		
	}
	
	
	
	public TimerDmiDAOLocal create() throws Exception {
        
        TimerDmiDAOLocal timerDmiDAOLocal = (TimerDmiDAOLocal)LocalBeanLookup.lookup(TimerDmiDAOLocal.class.getName());
		
		return timerDmiDAOLocal;
	}

}
