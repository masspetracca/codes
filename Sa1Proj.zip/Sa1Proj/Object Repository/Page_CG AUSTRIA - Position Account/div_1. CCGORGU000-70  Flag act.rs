<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_1. CCGORGU000-70  Flag act</name>
   <tag></tag>
   <elementGuidId>e7670a17-c336-459f-94e9-d240cb6733f5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='CPAAPAC010_chg_dialog']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>CPAAPAC010_chg_dialog</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ui-dialog-content ui-widget-content</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>scrolltop</name>
      <type>Main</type>
      <value>0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>scrollleft</name>
      <type>Main</type>
      <value>0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
 
    
    
	1. CCGORGU000-70  Flag activation not allowed with deact.date

 












  PARTICIPANT CODE : 
  

 	 2116×2116 
  
  
  
  


  MARKET CODE : 
  
  			 - 03 - CCPA - AUSTRIA
  


  ACCOUNT CODE : 
  
   	 	
			CLIENT
			HOUSE
 	 	 
   


  POSITION ACCOUNT ID : 
  2116


  ACCOUNT DESCRIPTION : 
  


  MARGIN GROUP : 
  


  COLLATERAL ACCOUNT ID : 
  

   	 CO-2116-1×CO-2116-1 
  


  SETTLEMENT ACCOUNT ID : 
  
    SA-2057SA-2051 - MEI3 FUND - A×SA-2051 - MEI3 FUND - A 
  


  DFF ACCOUNT ID : 
  
     CO-2116-2CO-2119-2 - CPP-XVIE - BTS DEFAULT FUND DYNAMIC - A×CO-2119-2 - CPP-XVIE - BTS DEFAULT FUND DYNAMIC - A 
  


  MEMBER TYPE : 
  


  POSITION TYPE : 
  


  GCM CODE : 
  
 	 21162121 - TIMBER HILL (EUROPE) AG - CLIENT - A×2121 - TIMBER HILL (EUROPE) AG - CLIENT - A 
  


  ACTIVATION DATE : 
  


  DEACTIVATION DATE : 
  


  ACTIVATION STATUS : 
  
		ACTIVE
		DEACTIVE
      



</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;CPAAPAC010_chg_dialog&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <value>//div[@id='CPAAPAC010_chg_dialog']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='close'])[2]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Change - PGM: CPAPACKC10'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[10]/div[2]</value>
   </webElementXpaths>
</WebElementEntity>
