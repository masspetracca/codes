<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>xpath__.____normalize-space_text____and_normalize-space_.___CC_amp_G_-_London_Stock_Exchange_Group____1__following__span_1_</name>
   <tag></tag>
   <elementGuidId>80afaca2-dadf-4d4b-842e-32adb1be21d5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='CC&amp;amp;G - London Stock Exchange Group'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
