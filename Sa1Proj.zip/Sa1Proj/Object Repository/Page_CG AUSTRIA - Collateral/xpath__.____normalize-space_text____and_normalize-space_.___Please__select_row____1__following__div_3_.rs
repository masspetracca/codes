<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>xpath__.____normalize-space_text____and_normalize-space_.___Please__select_row____1__following__div_3_</name>
   <tag></tag>
   <elementGuidId>64544549-3e5f-4d55-a3e4-e0939f5737c9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Please, select row'])[1]/following::div[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
