<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>xpath__.____normalize-space_text____and_normalize-space_.___CURRENCY_CODE______1__following__option_12_</name>
   <tag></tag>
   <elementGuidId>5e836345-c31f-4af2-b3da-33dd0c7b3ff5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='CURRENCY CODE :'])[1]/following::option[12]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
