<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_EX ACCOUNT ID      DF PART</name>
   <tag></tag>
   <elementGuidId>f305936c-4245-47b6-90dd-f7085fba0c3b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='CPADFPW010_chg_dialog']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>CPADFPW010_chg_dialog</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ui-dialog-content ui-widget-content</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>scrolltop</name>
      <type>Main</type>
      <value>0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>scrollleft</name>
      <type>Main</type>
      <value>0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
 
    
    
	

 









  EX ACCOUNT ID : 
  



  DF PARTICIPANT ACCOUNT ID : 
  



   ACCOUNT ID : 
  




  DF ACCOUNT ID : 
  
     CPP-XVIECPP-XVIE - DEFAULT FUND XVIE - A×CPP-XVIE - DEFAULT FUND XVIE - A 
  


  ACCOUNT DESCRIPTION : 
  


  CLEARING AGENT CODE : 
  
     21162119 - BT CAPITAL PARTNERS S.A. - A×2119 - BT CAPITAL PARTNERS S.A. - A 
  



  CURRENCY CODE : 
  
ATS - OSTERREICHISCHE SCHILLINGAUD - AUSTRALIAN DOLLARBGN - BULGRIAN LEVBRL - BRAZILIAN REALCAD - CANADIAN DOLLARCHF - SWISS FRANCCNY - CHINESE YUANCZK - CZECH CROWNDEM - DEUTSCHE MARKDKK - DANISH KRONEEUR - EUROGBP - GREAT BRITAIN POUNDHKD - HONG KONG DOLLARHRK - CROATIAN KUNAHUF - HUNGARIAN FORINTIDR - INDONESIAN RUPIAHILS - ISRAELI NEW SHEKELINR - INDIAN RUPEEISK - ICELANDIC KRONAITL - LIRE ITALIANEJPY - JAPANESE YENKRW - KOREAN WONLTL - LITHUANIAN LITASLVL - LATVIAN LATSMXN - MEXICAN PESOMYR - MALAYSIAN RINGGITNOK - NORWEGIAN KRONENZD - NEW ZELAND DOLLARPHP - PHILIPPINE PESOPLN - POLISH ZLOTYRON - RUMANISCHE RONRSD - SERBIAN DINARRUB - RUSSIAN RUBLESEK - SWEDISH KRONASGD - SINGAPORE DOLLARSKK - SLOVAK KORUNATHB - THAI BAHTTRY - TURKISCHE LIRAUSD - U.S. DOLLARZAR - SOUTH AFRICAN RAND



  EX ACCOUNT : 
  



  COLLATERAL TYPE : 
  
		CASH
		SECURITIES
      




  ACTIVATION DATE : 
  


  DEACTIVATION DATE : 
  


  ACTIVATION STATUS : 
  
		ACTIVE
		DEACTIVE
      



</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;CPADFPW010_chg_dialog&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <value>//div[@id='CPADFPW010_chg_dialog']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='close'])[2]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Change - PGM: CPADFPAC10'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[10]/div[2]</value>
   </webElementXpaths>
</WebElementEntity>
