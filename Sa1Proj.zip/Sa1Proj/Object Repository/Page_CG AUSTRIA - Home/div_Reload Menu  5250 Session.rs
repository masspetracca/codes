<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Reload Menu  5250 Session</name>
   <tag></tag>
   <elementGuidId>c2e50f60-c665-4b6a-bfbd-f228a8c1047e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sidr']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>sidr</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sidr left</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
    

  Reload Menu





  5250 Session





  Tool Links




  Settlement System





  Portale Cognos





  Help Desk Mantis





  ManageEngine ServiceDesk Plus





  NTS new treasury system





  Liquidity tool






  Home




  DashBoard





  Job Monitor





  Event Monitor





  Reports





  Flows





  Change the Settlement Days





  Import File to System





  Export File to CSV





  Download Files CCG





  Charts






  Clearing




  Deposit/Withdrawal




  Collateral Accounts Balance Items





  Collateral Transactions LOG





  Cash





  Government Deposit





  Bulk Deposits





  Load Deposits





  Collateral Class Default -W





  Issuer Group Setup - W





  Maintenance Elegible Instruments - W





  List BCE Elegible Instruments - W






  Inquiry




  Positions





  Trade Totals






  Trade




  MTA Trade Entry





  MTA Scan Historical Trade





  MTA Trade Manual Update





  BOND Trade Entry





  BOND Scan Historical Trades





  BOND Trade Manual Update





  Eseguiti tramite X-TRM





  Trade Extraction






  Report Generation




  Intraday Reports






  Master Files




  Class/Series/Group




  Class scan





  Class scan - WEB





  Series Manteinence





  Series Maintenance - NEW





  Dividend Update





  Dividend Update NEW





  Product Group





  Foreign Exchanges Rates





  Foreign Exchange Rates - W






  External Organization




  Members Update -W





  Exchange Maintenance - W





  Collateral Accounts Management





  Collateral Accounts - W





  Default Cash Excess Parameters






  Calendar / Dates - W




  1.  Daytime Processing Date





  2.  Nightly Processing Date





  3.  Month-end Processing Date





  4. Add a Year to System Calendar





  5. Delete a Year from System calendar





  6. Maintain Days





  7. Print Calendar Holidays





  8. Deleted Trade





  9. Maintenance to Calendar of Currencies





  10. New multiplier






  Calendar/Dates





  Report Title






  Corporate Action




  Delivery Specifications





  Contract Adjustment per MTA e E/A Idem





  Contract Adjustment per MTA e E/A Idem - W





  Maintaining Symbol in Contract/Adjustment





  Spread Rates





  Spread Rates -W







  Price




  Price System Parameter




  IDEM System parameter





  IDEX System Parameter





  FTSE System Parameter





  TLX System Parameter





  COMBO Parameter





  AGREX System Parameter







  Settlement




  Gestione Fail/Buy-in/Sell-out




  Acquisizione Ordini ad Agenti/Eseguiti





  Abbinamento transazioni Inserite/Annullate per Cor





  Invio Ordini a TAS





  GESTIONE SELL_OUT




  Monitoraggio Sell-Out (Stato regolam. 011,015,034)





  Stampa controllo sell-out posticipati





  Attivazione manuale del Sell-Out





  Sell-Out immediato





  Notifica di Esecuzione Sell-Out MTA (RP - ME07)





  Notifica di Esecuzione Sell-Out MTS (RP - ME08)





  Gestione Compensi Associati Buy In





  Gestione Compensi da Conto CC&amp;G (90555/90777)





  Stampe Riepilogativa Buy-In








  FAIL




  Instructions  End Validity





  Partite Controparte





  Partite Prodotto





  Instructions End Validity - only MKT





  Fail Trade MTA/IDEM





  MONITOR Stato Regolam.





  Monitor Stato Regolam. WEB





  Parzializzazione





  Gestione Bolli per Buy-In





  Stampa Partite in Fail





  Stampa Stato Singola Partita





  Stampa Partite alla data





  Stampa Partite Stato Regol. 034





  Stampa - Report CB30 Diff.LIquid.





  Stampa Ciclo Regol.Lordo ME101





  Stampa - Stato Singolo TRN





  Stampa - Parz. Azionario ME20





  Stampa - Parz. Obbligaz. ME21






  Default Fund




  Gestione parametri





  Gestione Net Main File





  Gestione Quote Member





  Inquiry storico Quote Member





  Rettifica Margine





  DFF MONITOR ICT




  Parametri spedizione





  Archivio flusso da spedire





  Log FTP - Comandi di spedizione





  Log FTP - Dati spediti





  Gestione parametri tipo calcolo





  Lancio calcolo quota Manuale







  Authorizations




  User/Group Management





  Functions/Users Authorizations Management





  Groups Authorizations Management





</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidr&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <value>//div[@id='sidr']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[2]/div</value>
   </webElementXpaths>
</WebElementEntity>
