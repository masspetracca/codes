<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>xpath__.____normalize-space_text____and_normalize-space_.___DF_Account____1__following__a_2_</name>
   <tag></tag>
   <elementGuidId>b6d9de88-52cc-43d2-a009-205f2b820274</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='DF Account'])[1]/following::a[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
