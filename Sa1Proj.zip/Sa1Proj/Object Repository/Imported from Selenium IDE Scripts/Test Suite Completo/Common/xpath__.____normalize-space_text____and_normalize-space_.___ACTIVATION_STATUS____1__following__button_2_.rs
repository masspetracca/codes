<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>xpath__.____normalize-space_text____and_normalize-space_.___ACTIVATION_STATUS____1__following__button_2_</name>
   <tag></tag>
   <elementGuidId>8f0f690d-8902-45f3-a31c-ccbe64d2d878</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='ACTIVATION STATUS'])[1]/following::button[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
