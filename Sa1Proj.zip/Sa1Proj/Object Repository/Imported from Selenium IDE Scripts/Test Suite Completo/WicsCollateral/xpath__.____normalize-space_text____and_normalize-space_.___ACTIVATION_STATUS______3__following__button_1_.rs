<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>xpath__.____normalize-space_text____and_normalize-space_.___ACTIVATION_STATUS______3__following__button_1_</name>
   <tag></tag>
   <elementGuidId>1d1eca6b-a9e8-4a19-9811-33eae116f2a1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='ACTIVATION STATUS :'])[3]/following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
