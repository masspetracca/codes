<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>id_chgMARGGRP</name>
   <tag></tag>
   <elementGuidId>07b9508b-4a80-4964-ae87-7f352eca3f48</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[id='chgMARGGRP']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
