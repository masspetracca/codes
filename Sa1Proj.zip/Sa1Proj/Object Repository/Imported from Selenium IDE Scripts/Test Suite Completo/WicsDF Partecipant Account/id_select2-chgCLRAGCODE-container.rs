<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>id_select2-chgCLRAGCODE-container</name>
   <tag></tag>
   <elementGuidId>9fd7c647-b819-4d5f-b58e-d27630b807f5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[id='select2-chgCLRAGCODE-container']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
