<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>id_select2-dspDFTACCOU-container</name>
   <tag></tag>
   <elementGuidId>4b95ae2e-35b8-4f5f-a33c-dab1c9f36e83</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[id='select2-dspDFTACCOU-container']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
