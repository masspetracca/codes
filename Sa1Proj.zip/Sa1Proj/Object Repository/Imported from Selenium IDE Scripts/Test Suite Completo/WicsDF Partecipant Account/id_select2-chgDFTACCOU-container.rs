<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>id_select2-chgDFTACCOU-container</name>
   <tag></tag>
   <elementGuidId>0e87edd6-b4ce-4c22-af9d-9af162cb9561</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[id='select2-chgDFTACCOU-container']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
