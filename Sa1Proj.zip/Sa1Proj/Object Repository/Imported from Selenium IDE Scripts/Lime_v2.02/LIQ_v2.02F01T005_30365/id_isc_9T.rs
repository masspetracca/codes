<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>id_isc_9T</name>
   <tag></tag>
   <elementGuidId>4cd78b57-ccdb-4f19-a633-d571b9d77feb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[id='isc_9T']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
