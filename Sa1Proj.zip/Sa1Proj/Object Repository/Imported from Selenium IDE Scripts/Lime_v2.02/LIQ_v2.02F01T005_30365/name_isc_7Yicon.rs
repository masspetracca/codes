<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>name_isc_7Yicon</name>
   <tag></tag>
   <elementGuidId>38545149-354b-49dc-8d30-b920a4844dff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[name='isc_7Yicon']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
