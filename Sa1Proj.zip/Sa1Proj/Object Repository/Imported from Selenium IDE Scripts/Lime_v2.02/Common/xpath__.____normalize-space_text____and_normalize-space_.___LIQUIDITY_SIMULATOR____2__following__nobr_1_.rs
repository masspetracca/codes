<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>xpath__.____normalize-space_text____and_normalize-space_.___LIQUIDITY_SIMULATOR____2__following__nobr_1_</name>
   <tag></tag>
   <elementGuidId>0440b8ef-2d51-4a1e-82a1-657d1d7fa4a4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='LIQUIDITY SIMULATOR'])[2]/following::nobr[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
