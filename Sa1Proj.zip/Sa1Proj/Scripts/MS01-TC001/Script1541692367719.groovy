import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.apache.commons.io.filefilter.FalseFileFilter
import org.apache.commons.io.filefilter.TrueFileFilter

import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('')

WebUI.navigateToUrl('http://wics-test/ccpacg/')

WebUI.setText(findTestObject('Page_CG AUSTRIA - Login/input_Login_utente (1)'), 'PETRACCA')

WebUI.setEncryptedText(findTestObject('Page_CG AUSTRIA - Login/input_Login_password (1)'), '0UPVPN7E41imvqSiXfxE9w==')

'Verify Login Utente MS01\r\n'
//WebUI.verifyElementText(findTestObject('Page_CG AUSTRIA - Login/input_Login_utente (1)'), 'masspetracca@gmail.com', FailureHandling.CONTINUE_ON_FAILURE)
//WebUI.setText(findTestObject('Page_CG AUSTRIA - Login/input_Login_utente (1)'), 'masspetracca@gmail.com')

WebUI.click(findTestObject('Page_CG AUSTRIA - Login/input_Login_submit'))

'Verify Checkpoint M. Scenario MS01\r\n'
WebUI.verifyCheckpoint(findCheckpoint('Checkpoints/TDScenLogin'), TrueFileFilter.TRUE)

//WebUI.closeBrowser()

