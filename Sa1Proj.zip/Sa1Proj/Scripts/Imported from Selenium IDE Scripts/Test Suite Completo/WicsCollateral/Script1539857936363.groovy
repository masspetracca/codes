import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('')

WebUI.navigateToUrl('http://wics-test/ccpacg/')

WebUI.setText(findTestObject('Page_CG AUSTRIA - Login/input_Login_utente (1)'), 'PETRACCA')

WebUI.setEncryptedText(findTestObject('Page_CG AUSTRIA - Login/input_Login_password (1)'), '0UPVPN7E41imvqSiXfxE9w==')

WebUI.click(findTestObject('Page_CG AUSTRIA - Login/input_Login_submit'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/div_MENU'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Clearing'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Master Files.old'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_External Organization'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Members Update -W'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Members Update -W/button_STATUS_display ui-butto (2)'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Members Update -W/button_Return (2)'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Members Update -W/button_STATUS_change ui-button (2)'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Members Update -W/input_MNEMONIC CODE _MNEMONIC (2)'), 
    'FB')

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Members Update -W/span_2116 (1)'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Members Update -W/input_NAME _NAME (2)'), 'ABN AMRO CLEARING BANK N.V.V.XXXXX')

WebUI.navigateToUrl('http://wics-test/ccpacg/cpacolw010.pgm?smurfid=00204173f0793cca3cc9843e65f53ee16b4960a6f1e879288dc0755327b8270c&rnd=301707&bread=Home**Collateral&namepgm=Collateral&')

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/button_ACTIVATION STATUS_displ (1)'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/button_Return (1)'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/button_ACTIVATION STATUS_chang (1)'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_ACCOUNT DESCRIPTION _DES (1)'), 'FBG MARGI')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/select_ATS - OSTERREICHISCHE S (1)'), 
    'CHF', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/select_ACTIVEDEACTIVE (1)'), 'D', 
    true)

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/button_Change (1)'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/button_A_add ui-button ui-widg (1)'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_EX ACCOUNT ID _ECOLLACCO (1)'), 'AAAAA')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_ACCOUNT DESCRIPTION _DES_1 (1)'), 'A')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_ACCOUNT DESCRIPTION _DES_2 (1)'), 'AA')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_ACCOUNT DESCRIPTION _DES_3 (1)'), 'AAA')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_ACCOUNT DESCRIPTION _DES_4 (1)'), 'AAAA')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_ACCOUNT DESCRIPTION _DES_5 (1)'), 'AAAAA')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_ACCOUNT DESCRIPTION _DES_6 (1)'), 'AAAAAA')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_ACCOUNT DESCRIPTION _DES_7 (1)'), 'AAAAAA')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/select_ATS - OSTERREICHISCHE S_1 (1)'), 
    'CAD', true)

WebUI.verifyElementAttributeValue('noty_message', null, null, 0, FailureHandling.STOP_ON_FAILURE)

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_EX ACCOUNT _EXTACCOUNT (1)'), 'EX ACC')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/select_CASHSECURITIES (1)'), 'S', 
    true)

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Members Update -W/button_OK (2)'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Master Files.old'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_External Organization'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Members Update -W'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Members Update -W/a_Collateral'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/button_ACTIVATION STATUS_displ (1)'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/span_2116'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/button_Return (1)'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/button_ACTIVATION STATUS_chang (1)'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_ACCOUNT DESCRIPTION _DES (1)'), 'FBG MARGIN')

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/button_Change (1)'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/button_A_add ui-button ui-widg (1)'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_EX ACCOUNT ID _ECOLLACCO (1)'), 'AAA')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_ACCOUNT DESCRIPTION _DES_8'), 'A')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_ACCOUNT DESCRIPTION _DES_9'), 'AA')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_ACCOUNT DESCRIPTION _DES_10'), 'AAa')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_ACCOUNT DESCRIPTION _DES_11'), 'AAa')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/select_ATS - OSTERREICHISCHE S_2'), 
    'BGN', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/select_CASHSECURITIES (1)'), 'S', 
    true)

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/input_EX ACCOUNT _EXTACCOUNT (1)'), 'a')

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Collateral/button_Add'))

