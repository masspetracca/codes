import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('')

WebUI.navigateToUrl('http://wics-test/ccpacg/')

WebUI.setText(findTestObject('Page_CG AUSTRIA - Login/input_Login_utente (1)'), 'PETRACCA')

WebUI.setEncryptedText(findTestObject('Page_CG AUSTRIA - Login/input_Login_password (1)'), '0UPVPN7E41imvqSiXfxE9w==')

WebUI.click(findTestObject('Page_CG AUSTRIA - Login/input_Login_submit'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/div_MENU'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Clearing'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Master Files.old'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_External Organization'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Members Update -W'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Members Update -W/a_DF Participant Account'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/button_ACTIVATION STATUS_displ'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/div_close_CPADFPW010_dsp_dialo'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/button_Return'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/button_ACTIVATION STATUS_chang'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/span_CPP-XVIE'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/span_CPP-XVIE'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/span_CPP-XVIE - DEFAULT FUND X'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/span_Next'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/span_Prev'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/span_Prev'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/div_EX ACCOUNT ID      DF PART'))

WebUI.setText(findTestObject('Page_CG AUSTRIA - DF Participant Ac/input_DEACTIVATION DATE _DEACT'), '2012-01-31')

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/div_EX ACCOUNT ID      DF PART'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/div_EX ACCOUNT ID      DF PART'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/div_ACTIVATION STATUS    ACTIV'))

WebUI.selectOptionByValue(findTestObject('Page_CG AUSTRIA - DF Participant Ac/select_ACTIVEDEACTIVE'), 'D', true)

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/button_Change'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/td_CPP-XVIE'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/td_BHV DEFAULT FUND DYNAMIC'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/button_A_delete ui-button ui-w'))

WebUI.click(findTestObject('Page_CG AUSTRIA - DF Participant Ac/button_Cancel'))

