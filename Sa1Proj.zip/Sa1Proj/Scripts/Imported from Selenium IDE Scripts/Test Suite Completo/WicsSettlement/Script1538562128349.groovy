import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.driver.KatalonWebDriverBackedSelenium as KatalonWebDriverBackedSelenium
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.thoughtworks.selenium.Selenium as Selenium
import org.openqa.selenium.firefox.FirefoxDriver as FirefoxDriver
import org.openqa.selenium.WebDriver as WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium as WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern as Pattern
import static org.apache.commons.lang3.StringUtils.join

WebUI.openBrowser('')

WebUI.navigateToUrl('http://wics-test/ccpacg/')

WebUI.setText(findTestObject('Page_CG AUSTRIA - Login/input_Login_utente (1)'), 'PETRACCA')

WebUI.setEncryptedText(findTestObject('Page_CG AUSTRIA - Login/input_Login_password (1)'), '0UPVPN7E41imvqSiXfxE9w==')

WebUI.click(findTestObject('Page_CG AUSTRIA - Login/input_Login_submit'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/div_MENU'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Clearing'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Master Files.old'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_External Organization'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Members Update -W'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Members Update -W/a_Settlement'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/button_ACTIVATION STATUS_displ'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/span_MEI2 HAUSS'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/span_2212'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/span__select2-selection__arrow'))

WebUI.doubleClick(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/b'))

WebUI.doubleClick(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/span__select2-selection__arrow'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/button_Return'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/button_ACTIVATION STATUS_chang'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/input_DESCRIPTION _DESCR'), 'MEI2 HAUS')

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/span_SA-2050'))

WebUI.doubleClick(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/span_SA-2050'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/span_2212_1'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/input_SECURITY ACCOUNT CODE _S'), 'AAABBBB')

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Settlement/button_Change'))

WebUI.closeBrowser()
