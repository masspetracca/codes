import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.driver.KatalonWebDriverBackedSelenium as KatalonWebDriverBackedSelenium
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.thoughtworks.selenium.Selenium as Selenium
import org.openqa.selenium.firefox.FirefoxDriver as FirefoxDriver
import org.openqa.selenium.WebDriver as WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium as WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern as Pattern
import static org.apache.commons.lang3.StringUtils.join

WebUI.openBrowser('')

WebUI.navigateToUrl('http://wics-test/ccpacg/')

WebUI.setText(findTestObject('Page_CG AUSTRIA - Login/input_Login_utente (1)'), 'PETRACCA')

WebUI.setEncryptedText(findTestObject('Page_CG AUSTRIA - Login/input_Login_password (1)'), '0UPVPN7E41imvqSiXfxE9w==')

WebUI.click(findTestObject('Page_CG AUSTRIA - Login/input_Login_submit'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/div_MENU'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Clearing'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Master Files.old'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_External Organization'))

WebUI.click(findTestObject('Page_CG AUSTRIA - Home/span_Members Update -W'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Members Update -W/a_Position Account_1'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Position Account/button_ACTIVATION STATUS_displ (1)'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Position Account/button_Return'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Position Account/button_ACTIVATION STATUS_chang (1)'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Position Account/input_ACCOUNT DESCRIPTION _DES'), 'FBG CLIEN')

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Position Account/span_SA-2057'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Position Account/span_CO-2116-2'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Position Account/span_CO-2116-2'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Position Account/span_2116_4'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Position Account/input_DEACTIVATION DATE _DEACT'), '2013-01-01')

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Position Account/div_PARTICIPANT CODE      2116_1'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Position Account/button_Change'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Position Account/input_DEACTIVATION DATE _DEACT'), '')

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Position Account/div_1. CCGORGU000-70  Flag act'))

