import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('')

WebUI.navigateToUrl('http://wics-test/ccpacg/')

WebUI.setText(findTestObject('Page_CG AUSTRIA - Login/input_Login_utente (1)'), 'PETRACCA')

WebUI.setEncryptedText(findTestObject('Page_CG AUSTRIA - Login/input_Login_password (1)'), '0UPVPN7E41imvqSiXfxE9w==')

WebUI.click(findTestObject('Page_CG AUSTRIA - Login/input_Login_submit'))

WebUI.navigateToUrl('http://wics-test/ccpacg/home.pgm')

/*
WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Home/img'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Home/div_Reload Menu  5250 Session'))

WebUI.click(findTestObject('null'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Home/span_Master Files'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Home/span_ClassSeriesGroup'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Home/span_Class scan - WEB'))
*/
WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/input_CLASS SYMBOL_ww_fCCLASS'), 'AO')

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/input_UI CUSIP_WEBPRDU010_filt'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/select_- 03 - CCPA - AUSTRIA'), 
    '03', true)

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/input_UI CUSIP_WEBPRDU010_filt'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/select_- 03 - CCPA - AUSTRIA'), 
    '', true)

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/input_UI CUSIP_WEBPRDU010_filt'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/input_CLASS SYMBOL_ww_fCCLASS'), '')

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_GG.3_display ui-button'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_Return'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_GG.3_change ui-button u'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/input_CLASS SYMBOL_CCLASS'), 'ANN')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/select_OptionFutureBondCashRep'), 
    'O', true)

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/input_CLASS DESCRIPTION_CDESC'), '5,29% LHB-Tir. nr SV 99-19 /11')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/select_PremiumVariation'), 
    'V', true)

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/input_UNIT OF TRADE_CMULTF'), '')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/input_NSV_CNSV'), '11,0000')

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_Change'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/select_- 03 - CCPA - AUSTRIA_1'), 
    '03', true)

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_Change'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/label_SPECIAL FLAG'))

/*
//WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_Cancel'))

//WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_B_delete ui-button ui-w'))

//WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_Delete'))

//WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_Cancel'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_B_copy ui-button ui-wid'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/input_TO CODE_CCLASS_B'), 'AA')


WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_Add'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_Cancel'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_Add'))

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/input_CLASS SYMBOL_CCLASS_1'), 'A')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/input_CLASS SYMBOL_CCLASS_2'), 'AA')

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/input_CLASS SYMBOL_CCLASS_3'), 'AA')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/select_PremiumVariation_1'), 
    'V', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/select_YesNo'), 'N', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/select_- 03 - CCPA - AUSTRIA_2'), 
    '03', true)


WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_Add'))

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_Cancel'))
*/

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Class scan - WEB/button_Export to Csv'))

