package it.ccg.calculator.main;


public class TestOperators {
	public TestOperators() throws Exception {
		setUpTest();
		System.out.println("t.operators");
	}
	/*
	 * Setup before each test case
	 */
	protected void setUpTest() throws Exception {
		System.out.println("setup Test");
		//TestCalculator tcal = new TestCalculator(null);
	}

	/*
	 * Setup operators
	 */
	public static double addOper(Integer oper) {
		// TODO Auto-generated method stub
		return oper;
	}
	public void finalize() throws Throwable {
		super.finalize();
	}

		

}
