package it.ccg.calculator.main.testing;

import org.junit.Test;

import it.ccg.calculator.main.TestOperators;


public class TestCalculator extends junit.framework.TestCase {
	private int oper1;
	private int oper2;
	
//	public TestCalculator() {
//		System.out.println("T.calculator1 - inizio");
////		testMethodSum1();
////		testMethodSum2();
////		testMethodSub1();
////		testMethodSub2();
////		System.out.println("T.calculator1 - fine");
////		//assertEquals("t.calculator - fine",1,1);	
//	}
//	


	public TestCalculator(String arg0) {
		super(arg0);
	}






	@Test
    public final void testMethodSum1(){
		System.out.println("START.test m. sum1");
		oper1 = 3000;
		oper2 = 2000;
		//oper1 = 0;
		//oper2 = 0;
        double  result = TestOperators.addOper(oper1+oper2);
		assertEquals("STOP-1",oper1,oper2);
		System.out.println("END.test m. sum-1: " + result);
		//valore atteso NOT zero
    }
	  
    @Test
    public final void testMethodSum2(){
    	assertTrue(true);
    }

	@Test
    public final void testMethodSub1(){
		System.out.println("START.test m. sub1");
		oper1 = 3000;
		oper2 = 3000;
		//oper1 = 0;
		//oper2 = 0;
        double  result = TestOperators.addOper(oper1+oper2);
		assertEquals("STOP-2",oper1,oper2);
		System.out.println("END.test m. sub-1: " + result);
		//valore atteso NOT zero
    }
	  
    @Test
    public final void testMethodSub2(){
    	assertTrue(true);
    }

	
}
