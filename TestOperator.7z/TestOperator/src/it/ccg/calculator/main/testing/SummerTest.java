package it.ccg.calculator.main.testing;

import org.junit.Test;

import it.ccg.calculator.main.TestOperators;


/**
 * @author mpetracc
 * @version 1.0
 * @created 29-dic-2015 15.34.34
 */
public class SummerTest extends junit.framework.TestCase {

	private int result;
	private int oper1;
	private int oper2;

	public SummerTest(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	/**
	 * 
	 * @param arg0
	 */
	public SummerTest(String arg0){
		super(arg0);	
	}
//
//	/**
//	 * 
//	 * @param args
//	 */
//	public static void main(String[] args){
//
//	}

	/**
	 * 
	 * @exception Exception
	 */
	protected void setUp()
	  throws Exception{
		super.setUp();
	}

	/**
	 * 
	 * @exception Exception
	 */
	protected void tearDown()
	  throws Exception{
		super.tearDown();
	}

	  
	
	@Test
	public final void testSummer(){
		assertEquals("OK-1",1,1);
	}

	@Test
	public final void testMultiplier(){
		assertEquals("OK-2",1,1);
	}
//	@Test
//	public final void testMultiplier1(){
//		assertEquals("OK-3",1,2);
//	}
	@Test
  public final void testMethodSum1(){
		System.out.println("test m. sum1");
		oper1 = 3000;
		oper2 = 3000;
		//oper1 = 0;
		//oper2 = 0;
		double  result = TestOperators.addOper(oper1+oper2);
		assertEquals("STOP-1",oper1,oper2);
		System.out.println("test m. sum-1: " + result);
		//valore atteso NOT zero
  }


}//end SummerTest