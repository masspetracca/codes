package it.ccg.calculator.main.testing;

import it.ccg.calculator.main.TestOperators;

public class MainTest {
	  private static String s1;

	public static void main(String[] args) throws Exception {
		  System.out.println("Inizio  <MainTest>");

		  TestOperators();
		  TestCalculator();

		  System.out.println("Fine esecuzione <MainTest>");
	  }

	private static void TestCalculator() {
		TestCalculator tc = new TestCalculator(s1);
		//throw new RuntimeException("Test not implemented -1");			
	}

	private static void TestOperators() throws Exception  {
		TestOperators top = new TestOperators(); 	
		//throw new RuntimeException("Test not implemented -2");	
	}
}
