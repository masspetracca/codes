/*
 * Decompiled with CFR 0_102.
 */
package com.demo.routines;

import java.io.PrintStream;

public class DemoRoutines {
	public DemoRoutines(String url) {
		// TODO Auto-generated constructor stub
        if (url == null) {
        	url = "http://www.google.com";
        }
        System.out.println(url);
        getPropertiesStringUrl();
    }
    
	   public static String getPropertiesStringUrl() {
	        return "exec 'explorer.exe http://talendforge.org/file_fetch.txt'";
	    }
	

	public static void helloExemple(String message) {
        if (message == null) {
            message = "World";
        }
        System.out.println("Hello " + message + " !");
    }

    public static String getExemple(String message) {
        if (message == null) {
            message = "World";
        }
        return "Hello " + message + " !";
    }

    public static String getPropertiesUrl() {
        return "http://talendforge.org/file_fetch.txt";
    }

    public static String getLabel(int i) {
        String message = " value > 50";
        if (i < 50) {
            message = " value < 50";
        }
        return message;
    }

    public static Boolean getFilter(int i, int i2) {
        if (i < i2) {
            return true;
        }
        return false;
    }

    public static String getRandomOpenDay() {
        String[] day = new String[]{"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
        int i = Long.valueOf(Math.round(Math.random() * 4.0)).intValue();
        return day[i];
    }

    public static String getRandomIndividu() {
        String[] individu = new String[]{"Eric DUPOND", "Jean DURAND", "Michael DELAMONTAGNE", "Sophie DUPUIS", "Laure DELAFORGE", "Martin DUJARDIN", "Sylvie DUPUIT", "Corinne LILOU", "Frederique LAPTOP"};
        int i = Long.valueOf(Math.round(Math.random() * 8.0)).intValue();
        return individu[i];
    }
    
}
