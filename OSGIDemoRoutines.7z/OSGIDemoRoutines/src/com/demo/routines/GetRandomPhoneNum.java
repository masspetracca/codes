/*
 * Decompiled with CFR 0_102.
 * 
 * Could not load the following classes:
 *  routines.Numeric
 */
package com.demo.routines;

import java.io.PrintStream;
import routines.Numeric;

public class GetRandomPhoneNum {
    public static String GetPhone() {
        String Tel = "0";
        Tel = Tel.concat(String.valueOf(Math.round(Numeric.random((Integer)1, (Integer)6).intValue())));
        for (int i = 0; i < 8; ++i) {
            Tel = Tel.concat(String.valueOf(Math.round(Numeric.random((Integer)0, (Integer)9).intValue())));
        }
        return Tel;
    }

    public static void main(String[] args) {
        System.out.println(GetRandomPhoneNum.GetPhone());
    }
}
