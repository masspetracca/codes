package com.demo.routines;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
/*
 * If your bundle needs to be notified at the time 
 * of bundle startup or shutdown then you should create a class implementing 
 * the BundleActivator interface (deve avere costruttori pubblici)
 * Follow these rules when creating the class:
 * Class.newInstance()
 * 
 */
public class Activator implements BundleActivator {
    private String url;
	public void start(BundleContext context) throws Exception {
        //System.out.println("Start Activate");
        url = "exec 'explorer.exe http://talendforge.org/file_fetch.txt'";
        Activate(url);
        //System.out.println("File:"+url);
    }
	public void stop(BundleContext context) throws Exception {
        System.out.println("Stop Activate");
    }
    private void Activate(String url) {
		// TODO Auto-generated method stub
    	DemoRoutines af = new DemoRoutines(url);
 		
	}

}