package TestListnerOnFailure;


public class TestConfig{


	
	public static String server="smtp.gmail.com";
	public static String from = "vaffaproject@gmail.com";
	public static String password = "vaffa123";
	public static String[] to ={"seleniumcoaching@gmail.com","trainer@way2automation.com"};
	public static String subject = "Test Report";
	
	public static String messageBody ="TestMessage";
	public static String attachmentPath=System.getProperty("user.dir")+"//Reports.zip";
	public static String attachmentName="reports.zip";
	
	
	
	
	
	
	
	
	
}
