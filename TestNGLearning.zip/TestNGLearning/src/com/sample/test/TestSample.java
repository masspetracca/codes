package com.sample.test;

import java.net.MalformedURLException;
import java.net.URL;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class TestSample {

	@Test
	public void testLogin() throws MalformedURLException {
		DesiredCapabilities cap = DesiredCapabilities.firefox();
		cap.setBrowserName("firefox");
		cap.setPlatform(Platform.ANY);
		
		RemoteWebDriver driver = new RemoteWebDriver(new URL("http://localhost:4444/wb/hub"),cap);
		driver.get("http://gmail.com");
		driver.findElement(By.id("Email")).sendKeys("raman@gmail.com");
		
		driver.findElement(By.id("Password")).sendKeys("ssdffff"); 
		driver.quit();
		
		
	}
}
