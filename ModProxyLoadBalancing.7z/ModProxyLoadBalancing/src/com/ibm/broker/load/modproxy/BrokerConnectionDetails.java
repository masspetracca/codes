package com.ibm.broker.load.modproxy;

/**
 * IBM WebSphere developerWorks
 * Article  : Load balance WebSphere Message Broker HTTP traffic, Part 1: using WebSphere Plug-in and IBM HTTP Server
 * Author1  : Rahul Gupta (rahul.gupta@in.ibm.com)
 * Author2  : Devipriya Selvarajan (dselvara@in.ibm.com)
 * 
 * NOTE
 * ------------------------------------------------------------------------------
 * This program is provided in good faith and AS-IS. There is no warranty or 
 * further service implied or committed and any supplied sample code is not 
 * supported via IBM product service channels. You may submit a question using 
 * the developerWork Article but a response is not guaranteed.
 * ------------------------------------------------------------------------------
 * 
 **/

/* Purpose if this class is to capture connection details of the specific instance
 * of broker. Details about broker host name, Queue Manager name and Queue Manager
 * listener port will be captured in a object if this class.
 * */

public class BrokerConnectionDetails {

	private String hostname     = null;
	private String portNumber   = null;
	private String qManagerName = null;

	public BrokerConnectionDetails() {
		this.hostname     = new String();
		this.portNumber   = new String();
		this.qManagerName = new String();
	}
	
    public BrokerConnectionDetails(String hostname, 
    		String portNumber, String qManagerName) {
		this.hostname     = new String(hostname);
		this.portNumber   = new String(portNumber);
		this.qManagerName = new String(qManagerName);
	}
    
	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getPortNumber() {
		return portNumber;
	}

	public void setPortNumber(String portNumber) {
		this.portNumber = portNumber;
	}

	public String getqManagerName() {
		return qManagerName;
	}

	public void setqManagerName(String qManagerName) {
		this.qManagerName = qManagerName;
	}
    
}
