package com.ibm.broker.load.modproxy;


/**
 * IBM WebSphere developerWorks
 * Article  : Load balance WebSphere Message Broker HTTP traffic. Part 2 - using mod_proxy modules and Apache HTTP Server
 * Author1  : Rahul Gupta (rahul.gupta@in.ibm.com)
 * Author2  : Devipriya Selvarajan (dselvara@in.ibm.com)
 * 
 * NOTE
 * ------------------------------------------------------------------------------
 * This program is provided in good faith and AS-IS. There is no warranty or 
 * further service implied or committed and any supplied sample code is not 
 * supported via IBM product service channels. You may submit a question using 
 * the developerWork Article but a response is not guaranteed.
 * ------------------------------------------------------------------------------
 * 
 **/

/*
 * The purpose of this class is to interact with user, capture broker connection
 * details like Broker host name, Broker Queue Manager name, Broker Queue Manager
 * listener port number. Once all the information is captured then using broker
 * proxy API's generate the mod proxy file.
 */

import com.ibm.broker.config.proxy.BrokerConnectionParameters;
import com.ibm.broker.config.proxy.BrokerProxy;
import com.ibm.broker.config.proxy.ConfigManagerProxyLoggedException;
import com.ibm.broker.config.proxy.MQBrokerConnectionParameters;
import com.ibm.broker.load.modproxy.WriteModProxyFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class GenerateModProxy {

public static void main(String[] args){

		BufferedReader br						   = null;
		BufferedReader bc 						   = null;
		BufferedReader fn 						   = null;
		String continued 	   					   = new String();
		String filename                            = new String();
		BrokerConnectionDetails[] brokerConnection = new BrokerConnectionDetails [20];
		BrokerConnectionParameters[] bcp           = new BrokerConnectionParameters [20];
		BrokerProxy[] bp                           = new BrokerProxy [20];
		WriteModProxyFile mpf    				   = new WriteModProxyFile();
		int count 								   = 0;
		Map <BrokerProxy,java.lang.String[]> mp    = new HashMap <BrokerProxy,java.lang.String[] > () ;

		System.out.println("=========================================================================================");
		System.out.println("*****************************************************************************************");
		System.out.println("***********WebSphere Message Broker Mod Proxy Configuration Generation Tool**************");
		System.out.println("*****************************************************************************************");
		System.out.println("=========================================================================================");
		System.out.println("");
		
		try {
			do
			{
				System.out.print("Do you want to add Broker Connection Details ? (y/n) = ");
				br = new BufferedReader(new InputStreamReader(System.in));
				continued = br.readLine();
				System.out.println("");
				String[] hostname = new String[1];

				for (int i=0;i<6;i++)
				{
					brokerConnection[i]= new BrokerConnectionDetails();
				}

				if(continued.equalsIgnoreCase("Y") || continued.equalsIgnoreCase("YES"))
				{
					System.out.println("*****************************************************************************************");
					System.out.println("");
					System.out.println("Please Enter the Broker Connection Details ( Hostname, QMName , QMPort )");
					System.out.println("");
					
					System.out.print("Enter the Broker Hostname                            = ");
					bc = new BufferedReader(new InputStreamReader(System.in));
					brokerConnection[count].setHostname(bc.readLine());
					System.out.println("");

					System.out.print("Enter the Queue Manager Name                         = ");
					bc = new BufferedReader(new InputStreamReader(System.in));
					brokerConnection[count].setqManagerName(bc.readLine());
					System.out.println("");

					System.out.print("Enter the Queue Manager Listener Port Number         = ");
					bc = new BufferedReader(new InputStreamReader(System.in));
					brokerConnection[count].setPortNumber(bc.readLine());
					System.out.println("");

					bcp[count] = new MQBrokerConnectionParameters(brokerConnection[count].getHostname(),
							Integer.parseInt(brokerConnection[count].getPortNumber()),
							brokerConnection[count].getqManagerName());

					bp[count] = BrokerProxy.getInstance(bcp[count]);	
					hostname[0] = brokerConnection[count].getHostname();
					mp.put(bp[count],hostname);
					
					System.out.println("Broker HTTP Service Details for this Broker Connection");
					System.out.println(bp[count].getPortConfigAsCSV(16000));
					
					count++;
				}
				else if(continued.equalsIgnoreCase("N") || continued.equalsIgnoreCase("NO"))
				{
					if(count==0)
					{
						System.out.println("=========================================================================================");
						System.out.println("*****************************************************************************************");
						System.out.println("*******************No Broker Connections Provided, Exiting tool**************************");
						System.out.println("*****************************************************************************************");
						System.out.println("=========================================================================================");
						System.exit(-1);
					}
					break;
				}
				else
				{
					System.out.println("");
					System.out.println("=========================================================================================");
					System.out.println("*****************************************************************************************");
					System.out.println("********Usage Error - Input not understood, Valid options are Y(Yes) / N(No) ************");
					System.out.println("*****************************************************************************************");
					System.out.println("=========================================================================================");
					System.out.println("");
				}
			}while(!continued.equalsIgnoreCase("N") || continued.equalsIgnoreCase("NO"));
			
			System.out.println("*****************************************************************************************");
			System.out.println("");
			System.out.print("Enter the file name for Mod Proxy                    = ");
			fn = new BufferedReader(new InputStreamReader(System.in));
			mpf.setFileName(fn.readLine());
			System.out.println("");

			System.out.print("Enter the location of file                           = ");
			fn = new BufferedReader(new InputStreamReader(System.in));
			filename = fn.readLine();
			mpf.setFileLocation(filename);
			System.out.println("");
           
			mpf.setFileData(BrokerProxy.generateModProxyPlugin(mp,16000));
			mpf.writeDataToFile();
			
			System.out.println("=========================================================================================");
			System.out.println("*****************************************************************************************");
			System.out.println("********Congratulation Mod Proxy Balancer Generated Configuration Successfully***********");
			System.out.println("**********************Exiting Mod Proxy Configuration Generation Tool********************");
			System.out.println("*****************************************************************************************");
			System.out.println("=========================================================================================");

		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (ConfigManagerProxyLoggedException ex){
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
	}
}