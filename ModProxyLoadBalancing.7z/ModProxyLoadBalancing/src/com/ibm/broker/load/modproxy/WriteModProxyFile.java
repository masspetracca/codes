package com.ibm.broker.load.modproxy;

/**
 * IBM WebSphere developerWorks
 * Article  : Load balance WebSphere Message Broker HTTP traffic. Part 2 - using mod_proxy modules and Apache HTTP Server
 * Author1  : Rahul Gupta (rahul.gupta@in.ibm.com)
 * Author2  : Devipriya Selvarajan (dselvara@in.ibm.com)
 * 
 * NOTE
 * ------------------------------------------------------------------------------
 * This program is provided in good faith and AS-IS. There is no warranty or 
 * further service implied or committed and any supplied sample code is not 
 * supported via IBM product service channels. You may submit a question using 
 * the developerWork Article but a response is not guaranteed.
 * ------------------------------------------------------------------------------
 * 
 **/

/*
 * The purpose of this class if to capture the name and location of ModProxy file to
 * be created and then write the contents of this file using the data generated through
 * broker proxy API.
 * */

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WriteModProxyFile {
	private String fileName     = null;
	private String fileLocation = null;
	private String fileData     = null;

	public WriteModProxyFile(String fileName, 
			String fileLocation, String fileData) {
		this.fileName     = new String(fileName);
		this.fileLocation = new String(fileLocation);
		this.fileData     = new String(fileData);
	}

	public WriteModProxyFile() {
		this.fileName     = new String();
		this.fileLocation = new String();
		this.fileData     = new String();
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public String getFileData() {
		return fileData;
	}

	public void setFileData(String fileData) {
		this.fileData = fileData;
	}

	public void writeDataToFile() {
		FileWriter fileWriter = null;
		try {
			String absoluteFileName = this.fileLocation + 
			"/" + this.fileName;
			File newTextFile = new File(absoluteFileName);
			fileWriter = new FileWriter(newTextFile);
			fileWriter.write(this.fileData);
			fileWriter.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			try {
				fileWriter.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
}
