INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T01', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU01-NUC01-T01.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T01', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Liquidity Items - CCAM - View', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T01', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T01', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T01', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T01', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU01-NUC01-T02.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Liquidity Items - CCAM - Filters', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=17||length=20||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Nov 30 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Wed||3]', '/* Date Chooser and filter */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=17||length=20||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Nov 30 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=23||length=26||classIndex=1||classLength=2]/nextMonthButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=23||length=26||classIndex=1||classLength=2]/nextMonthButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=23||length=26||classIndex=1||classLength=2]/nextMonthButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=17||length=20||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Nov 30 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element', '${KEY_TAB}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'blur', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'focus', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon="showDateRange"]', 'TRUE', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon="showDateRange"]', '${KEY_TAB}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'blur', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||index=3||Class=FloatItem]/element', '/* List Grid filterEditor', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'focus', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||index=3||Class=FloatItem]/element', 'TRUE', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E10||index=3||Class=FloatItem]/element', '/* List Grid filterEditor', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E10||index=3||Class=FloatItem]/element', '>10', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E10||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E10||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.6200000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.6200000||index=3||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.6200000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 54, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.6200000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 55, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.62||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 56, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.62||index=3||Class=FloatItem]/element', '${KEY_LEFT}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 57, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.62||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 58, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.62||index=3||Class=FloatItem]/element', '${KEY_LEFT}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 59, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.62||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 60, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.62||index=3||Class=FloatItem]/element', '${KEY_LEFT}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 61, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E643273270000.62||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 62, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E643273270000.62||index=3||Class=FloatItem]/element', '>643273270000.62', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 63, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 64, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 65, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C643||index=3||Class=FloatItem]/element', '/* List Grid filterEditor', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 66, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C643||index=3||Class=FloatItem]/element', '<643', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 67, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 68, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 69, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C643||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 70, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C643||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 71, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 72, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 73, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C643||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 74, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C643||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 75, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 76, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430||index=3||Class=FloatItem]/element', '<6430', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 77, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 78, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 79, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 80, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 81, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 82, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 83, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 84, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 85, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 86, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430000||index=3||Class=FloatItem]/element', '<6430000', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 87, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 88, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 89, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 90, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 91, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 92, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 93, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E100||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 94, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E100||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 95, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E100||index=3||Class=FloatItem]/element', '/* List Grid filterEditor', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 96, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E100||index=3||Class=FloatItem]/element', '>100', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 97, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 98, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 99, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E100||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 100, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E100||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 101, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E1000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 102, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E1000||index=3||Class=FloatItem]/element', '>1000', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 103, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 104, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 105, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 106, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 107, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E1000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 108, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E1000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 109, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 110, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 111, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 112, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 113, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||value=EOD||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 114, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||value=EOD||index=1||Class=TextItem]/element', 'EOD', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 115, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 116, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 117, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 118, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 119, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/cancelButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 120, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/cancelButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 121, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 122, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 123, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||value=Auto||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 124, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||value=Auto||index=1||Class=TextItem]/element', 'Auto', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 125, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 126, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 127, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Window||index=386||length=388||classIndex=0||classLength=1||roleIndex=2||roleLength=3||title=Select%20Fields%20to%20export...||scRole=dialog]/item[0][Class="HLayout"]/member[Class=VStack||index=2||length=5||classIndex=0||classLength=1]/member[Class=ImgButton||index=2||length=4||classIndex=2||classLength=4||roleIndex=2||roleLength=4||scRole=button||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 128, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Window||index=386||length=388||classIndex=0||classLength=1||roleIndex=2||roleLength=3||title=Select%20Fields%20to%20export...||scRole=dialog]/item[0][Class="HLayout"]/member[Class=VStack||index=2||length=5||classIndex=0||classLength=1]/member[Class=ImgButton||index=2||length=4||classIndex=2||classLength=4||roleIndex=2||roleLength=4||scRole=button||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 129, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Window||index=386||length=388||classIndex=0||classLength=1||roleIndex=2||roleLength=3||title=Select%20Fields%20to%20export...||scRole=dialog]/item[3][Class="HLayout"]/member[Class=Button||index=0||length=2||classIndex=0||classLength=2||roleIndex=0||roleLength=2||title=Export||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T02', 130, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Window||index=386||length=388||classIndex=0||classLength=1||roleIndex=2||roleLength=3||title=Select%20Fields%20to%20export...||scRole=dialog]/item[3][Class="HLayout"]/member[Class=Button||index=0||length=2||classIndex=0||classLength=2||roleIndex=0||roleLength=2||title=Export||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU01-NUC01-T03.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Liquidity Items - CCAM - Grouping', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Sort%20Ascending||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Sort%20Ascending||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Sort%20Descending||1]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Sort%20Descending||1]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Configure%20Sort...||2]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Configure%20Sort...||2]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=MultiSortDialog||index=12||length=14||classIndex=0||classLength=1||roleIndex=1||roleLength=2||title=Sort||scRole=dialog]/multiSortPanel/addLevelButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Auto%20Fit%20All%20Columns||4]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Auto%20Fit%20All%20Columns||4]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Auto%20Fit%20All%20Columns||4]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Auto%20Fit%20All%20Columns||4]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[title=Cash%20amount||2]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[title=Cash%20amount||2]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[title=Cash%20amount||2]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[title=Cash%20amount||2]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[title=Item%20group%20ID.||3]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[title=Item%20group%20ID.||3]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[title=Reliability||4]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[title=Reliability||4]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[title=Is%20eod||5]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'secondClick', 'scLocator=//Menu[level=1]/body/row[title=Is%20eod||5]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Sort%20Descending||1]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Sort%20Descending||1]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/hscrollbar/peer[Class=SpritedHSimpleScrollThumb||index=0||length=1||classIndex=0||classLength=1||title=%26nbsp%3B||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDrop', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/hscrollbar/peer[Class=SpritedHSimpleScrollThumb||index=0||length=1||classIndex=0||classLength=1||title=%26nbsp%3B||name=main]/', '+490,-3', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 54, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Configure%20Grouping...||10]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 55, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Configure%20Grouping...||10]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 56, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=MultiGroupDialog||index=144||length=145||classIndex=0||classLength=1||roleIndex=1||roleLength=2||title=Group||scRole=dialog]/applyButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 57, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=MultiGroupDialog||index=144||length=145||classIndex=0||classLength=1||roleIndex=1||roleLength=2||title=Group||scRole=dialog]/applyButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 58, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=47||groupTitle=Week%20%2347||17]/col[fieldName=groupTitle||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 59, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=47||groupTitle=Week%20%2347||17]/col[fieldName=groupTitle||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 60, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 61, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 62, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Add%20formula%20column...||15]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 63, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Add%20formula%20column...||15]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 64, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="FormulaBuilder"]/formulaForm/item[name=formulaField||title=Formula||value=||index=0||Class=AutoFitTextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 65, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="FormulaBuilder"]/formulaForm/item[name=formulaField||title=Formula||value=||index=0||Class=AutoFitTextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 66, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="FormulaBuilder"]/formulaForm/item[name=formulaField||title=Formula||value=%3D||index=0||Class=AutoFitTextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 67, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="FormulaBuilder"]/formulaForm/item[name=formulaField||title=Formula||value=%3D||index=0||Class=AutoFitTextAreaItem]/element', '=', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 68, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="FormulaBuilder"]/fieldKey/body/row[name=cash_amount||title=Cash%20amount||mappingKey=A||0]/col[fieldName=mappingKey||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 69, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="FormulaBuilder"]/fieldKey/body/row[name=cash_amount||title=Cash%20amount||mappingKey=A||0]/col[fieldName=mappingKey||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 70, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="FormulaBuilder"]/formulaForm/item[name=formulaField||title=Formula||value=%3DA+100||index=0||Class=AutoFitTextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 71, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="FormulaBuilder"]/formulaForm/item[name=formulaField||title=Formula||value=%3DA+100||index=0||Class=AutoFitTextAreaItem]/element', '#NAME?', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 72, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="FormulaBuilder"]/saveButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 73, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="FormulaBuilder"]/saveButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 74, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 75, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 76, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Add%20summary%20column...||17]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 77, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Add%20summary%20column...||17]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 78, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="SummaryBuilder"]/fieldKey/body/row[name=cash_amount||title=Cash%20amount||3]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 79, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="SummaryBuilder"]/fieldKey/body/row[name=cash_amount||title=Cash%20amount||3]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 80, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="SummaryBuilder"]/saveButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 81, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/fieldEditorWindow/item[0][Class="SummaryBuilder"]/saveButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 82, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=item_reliability]/L', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 83, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDrop', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=item_reliability]/L', '-153,+9', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 84, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=is_eod]/L', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 85, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=48||groupTitle=Week%20%2348||0]/col[fieldName=item_reliability||5]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 86, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDropToObject', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=is_eod]/L', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=48||groupTitle=Week%20%2348||0]/col[fieldName=item_reliability||5]', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 87, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=formulaField1]/L', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 88, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/row[groupTitle=true||is_eod=true||1]/col[fieldName=is_eod||6]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 89, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDropToObject', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=formulaField1]/L', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/row[groupTitle=true||is_eod=true||1]/col[fieldName=is_eod||6]', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 90, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/R', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 91, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/body/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 92, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDropToObject', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/R', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/body/', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 93, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/R', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 94, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=48||groupTitle=Week%20%2348||summaryField1=-115%2C341%2C581.57||0]/col[fieldName=summaryField1||8]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 95, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDropToObject', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/R', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=48||groupTitle=Week%20%2348||summaryField1=-115%2C341%2C581.57||0]/col[fieldName=summaryField1||8]', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 96, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 97, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 98, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Ungroup||10]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 99, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Ungroup||10]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 100, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 101, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 102, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 103, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 104, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 105, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 106, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[title=New%20Field||6]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 107, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[title=New%20Field||6]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 108, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[title=New%20Field||7]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 109, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[title=New%20Field||7]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 110, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[title=Is%20eod||5]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 111, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[title=Is%20eod||5]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 112, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[title=Reliability||4]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 113, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[title=Reliability||4]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 114, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[title=Item%20group%20ID.||3]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 115, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[title=Item%20group%20ID.||3]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 116, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 117, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/body/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 118, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 119, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 120, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/header/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 121, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/header/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 122, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 123, '0.1', 'http://10.0.10.173:9081/CCAM/', 'secondClick', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 124, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU01-NUC01-T03', 125, '0.1', 'http://10.0.10.173:9081/CCAM/', 'secondClick', 'scLocator=//Portlet[ID="liquidity_items_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T01', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU02-NUC01-T01.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T01', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Countries - CCAM - View', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T01', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T01', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T01', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T01', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T01', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T01', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T01', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU02-NUC01-T02.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Countries - CCAM - Filters', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||value=Euroope||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||value=Euroope||index=3||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||value=Europe||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||value=Europe||index=3||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||value=Europe||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||value=Europe||index=3||Class=TextItem]/element', 'Europe', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||value=AX||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||value=AX||index=1||Class=TextItem]/element', 'AX', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||value=Europe||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||value=Europe||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||value=AX||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||value=AX||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||value=Africa||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_zone||title=Country%20zone||value=Africa||index=3||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||value=AX||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||value=AX||index=1||Class=TextItem]/element', 'AX', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||value=AX||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 54, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||value=AX||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 55, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 56, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||index=1||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 57, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T02', 58, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_iso2||title=Country%20ISO2||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU02-NUC01-T03.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Countries - CCAM - Grouping', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Country%20zone||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Country%20zone||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=country_name]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'contextMenu', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=country_name]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Country%20name||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Country%20name||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=country_zone]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'contextMenu', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=country_zone]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Ungroup||9]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Ungroup||9]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=country_name]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'contextMenu', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=country_name]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Country%20name||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Country%20name||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/body/row[groupValue=Niger||10]/col[fieldName=country_iso3||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/item[0][Class="ListGrid"]/body/row[groupValue=Niger||10]/col[fieldName=country_iso3||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU02-NUC01-T03', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_country_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T01', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU03-NUC01-T01.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T01', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Entities - CCAM - View', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T01', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T01', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T01', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T01', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[1]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T01', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[1]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T01', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T01', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU03-NUC01-T02.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Entities - CCAM - Filter', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'selectWindow', 'null', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[1]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[1]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/body/row[lei=3021||country_name=United%20Kingdom||12]/col[fieldName=country_name||2]', 'Select Country Name', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/body/row[lei=3021||country_name=United%20Kingdom||12]/col[fieldName=country_name||2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=lei||title=LEI%20Code||index=0||Class=SelectItem]/textbox', 'Select LEI code', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=lei||title=LEI%20Code||index=0||Class=SelectItem]/textbox', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/body/vscrollbar/peer[Class=SpritedVSimpleScrollThumb||index=0||length=1||classIndex=0||classLength=1||title=%26nbsp%3B||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDrop', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/body/vscrollbar/peer[Class=SpritedVSimpleScrollThumb||index=0||length=1||classIndex=0||classLength=1||title=%26nbsp%3B||name=main]/', '+13,+358', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/body/vscrollbar/peer[Class=SpritedVSimpleScrollThumb||index=0||length=1||classIndex=0||classLength=1||title=%26nbsp%3B||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDrop', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/body/vscrollbar/peer[Class=SpritedVSimpleScrollThumb||index=0||length=1||classIndex=0||classLength=1||title=%26nbsp%3B||name=main]/', '+8,-621', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/body/vscrollbar/peer[Class=SpritedVSimpleScrollThumb||index=0||length=1||classIndex=0||classLength=1||title=%26nbsp%3B||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDrop', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/body/vscrollbar/peer[Class=SpritedVSimpleScrollThumb||index=0||length=1||classIndex=0||classLength=1||title=%26nbsp%3B||name=main]/', '+5,+59', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=unipol||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=unipol||index=0||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cab||title=CAB%20code||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cab||title=CAB%20code||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_name||title=Country%20name||value=United||index=4||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_name||title=Country%20name||value=United||index=4||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_name||title=Country%20name||index=4||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_name||title=Country%20name||index=4||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=unipol||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=unipol||index=0||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T02', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU03-NUC01-T03.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Entities - CCAM - Grouping and refresh', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'selectWindow', 'null', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[1]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[1]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_name||title=Country%20name||index=4||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_name||title=Country%20name||index=4||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=country_name]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=country_name]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=country_name]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'contextMenu', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=country_name]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Country%20name||9]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Country%20name||9]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/body/row[groupValue=Italy||5]/col[fieldName=legal_name||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/body/row[groupValue=Italy||5]/col[fieldName=legal_name||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=country_name]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'contextMenu', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=country_name]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Ungroup||10]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Ungroup||10]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU03-NUC01-T03', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_entities_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T01', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU04-NUC01-T01.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T01', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Accounts - CCAM - View', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T01', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[2]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T01', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[2]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T01', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T01', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU04-NUC01-T02.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Accounts - CCAM - Filters', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[2]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[2]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||value=true||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||value=true||index=3||Class=TextItem]/element', 'TRUE', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||value=true||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||value=true||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=lei]/L', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDrop', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=lei]/L', '+69,+9', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=iban]/L', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/body/row[iban=000000090000||acc_name=BANCA%20D%27ITALIA%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20||0]/col[fieldName=iban||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDropToObject', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=iban]/L', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/body/row[iban=000000090000||acc_name=BANCA%20D%27ITALIA%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20||0]/col[fieldName=iban||1]', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=brescia||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=brescia||index=0||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=brescia||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=brescia||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=unicredit||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=unicredit||index=0||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=unicredit||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=unicredit||index=0||Class=TextItem]/element', 'unicredit', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=unicredit||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=unicredit||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=italia||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=italia||index=0||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=italia||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=italia||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=unicredit||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=unicredit||index=0||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=iban]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=iban]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 54, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=iban]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T02', 55, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=iban]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU04-NUC01-T03.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Accounts - CCAM - Grouping', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[2]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[2]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||value=true||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||value=true||index=3||Class=TextItem]/element', 'TRUE', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||value=true||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||value=true||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=own_fund||title=Own%20fund||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=lei]/L', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDrop', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=lei]/L', '+69,+9', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=iban]/L', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/body/row[iban=000000090000||acc_name=BANCA%20D%27ITALIA%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20||0]/col[fieldName=iban||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDropToObject', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=iban]/L', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/body/row[iban=000000090000||acc_name=BANCA%20D%27ITALIA%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20||0]/col[fieldName=iban||1]', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=brescia||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=brescia||index=0||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=brescia||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=brescia||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=unicredit||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=unicredit||index=0||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Account%20name||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Account%20name||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/body/row[acc_name=GRUPPO%20UNICREDIT%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20||13]/col[fieldName=acc_name||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/body/row[acc_name=GRUPPO%20UNICREDIT%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20||13]/col[fieldName=acc_name||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/body/row[acc_name=EUROCLEAR%20BANK%20SA%5CNV%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20||4]/col[fieldName=acc_name||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/body/row[acc_name=EUROCLEAR%20BANK%20SA%5CNV%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20||4]/col[fieldName=acc_name||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/body/row[acc_name=GRUPPO%20INTESA%20SANPAOLO%20%20%20%20%20%20%20%20%20%20%20%20%20||6]/col[fieldName=acc_name||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/body/row[acc_name=GRUPPO%20INTESA%20SANPAOLO%20%20%20%20%20%20%20%20%20%20%20%20%20||6]/col[fieldName=acc_name||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/body/row[acc_name=BANCA%20NAZ%20LAVORO%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20||10]/col[fieldName=acc_name||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU04-NUC01-T03', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_accounts_tab_2"]/item[0][Class="ListGrid"]/body/row[acc_name=BANCA%20NAZ%20LAVORO%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20||10]/col[fieldName=acc_name||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T01', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU05-NUC01-T01.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T01', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Eod margins stg - CCAM - View', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T01', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[4]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T01', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[4]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T01', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T01', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU05-NUC01-T02.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Eod margins stg - CCAM - Filters', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[4]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[4]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/pickList/body/row[firm_client=C||2]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/pickList/body/row[firm_client=C||2]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=C||index=2||Class=SelectItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=C||index=2||Class=SelectItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=C||index=2||Class=SelectItem]/pickList/body/row[firm_client=F||1]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=C||index=2||Class=SelectItem]/pickList/body/row[firm_client=F||1]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=F||index=2||Class=SelectItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=F||index=2||Class=SelectItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=F||index=2||Class=SelectItem]/pickList/body/row[0]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=F||index=2||Class=SelectItem]/pickList/body/row[0]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=sella||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=sella||index=1||Class=TextItem]/element', 'sella', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/textbox', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/textbox', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/pickList/body/row[firm_client=C||2]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/pickList/body/row[firm_client=C||2]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=sella||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=sella||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=unicredit||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=unicredit||index=1||Class=TextItem]/element', 'unicredit', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/textbox', '/* il test � POSTPONED a causa di un malfunzionamento dell''oggetto CalcDate */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/textbox', '/* il test � POSTPONED a causa di un malfunzionamento dell''oggetto CalcDate */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '/* il test � POSTPONED a causa di un malfunzionamento dell''oggetto CalcDate */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T02', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '/* il test � POSTPONED a causa di un malfunzionamento dell''oggetto CalcDate */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU05-NUC01-T03.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Eod margins stg - CCAM - Grouping', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[4]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[4]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/pickList/body/row[firm_client=F||1]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/pickList/body/row[firm_client=F||1]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=F||index=2||Class=SelectItem]/textbox', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=F||index=2||Class=SelectItem]/textbox', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=F||index=2||Class=SelectItem]/pickList/body/row[firm_client=F||1]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=F||index=2||Class=SelectItem]/pickList/body/row[firm_client=F||1]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=26||length=29||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=26||length=29||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=32||length=35||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=32||length=35||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 54, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 55, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 56, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', 'intesa', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 57, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 58, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 59, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=unicredit||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 60, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=unicredit||index=1||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 61, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=unicredit||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 62, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=unicredit||index=1||Class=TextItem]/element', 'unicredit', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 63, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 64, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 65, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 66, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/sorter/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 67, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU05-NUC01-T03', 68, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_eodmarg_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T01', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU06-NUC01-T01.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T01', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Voluntary contributions stg - CCAM - View', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T01', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T01', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T01', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T01', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[5]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T01', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[5]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T01', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T01', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU06-NUC01-T02.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Voluntary contributions stg - CCAM - Filter', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[5]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[5]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/pickList/body/row[firm_client=F||1]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||index=2||Class=SelectItem]/pickList/body/row[firm_client=F||1]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=F||index=2||Class=SelectItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=F||index=2||Class=SelectItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=F||index=2||Class=SelectItem]/pickList/body/row[firm_client=C||2]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=F||index=2||Class=SelectItem]/pickList/body/row[firm_client=C||2]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=C||index=2||Class=SelectItem]/textbox', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=C||index=2||Class=SelectItem]/textbox', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=C||index=2||Class=SelectItem]/pickList/body/row[0]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=firm_client||title=Firm%20client||value=C||index=2||Class=SelectItem]/pickList/body/row[0]/col[fieldName=firm_client||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T02', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU06-NUC01-T03.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Voluntary contributions stg - CCAM - Grouping and refresh', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=VLayout||index=1||length=4||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=4||classIndex=1||classLength=4]/member[Class=MenuButton||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Menu||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[5]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[5]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Firm%20client||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Firm%20client||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/body/row[firm_client=F||groupValue=Firm||3]/col[fieldName=dt_calc||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU06-NUC01-T03', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_voluntcontrib_tab_2"]/item[0][Class="ListGrid"]/body/row[firm_client=F||groupValue=Firm||3]/col[fieldName=dt_calc||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T01', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU07-NUC01-T01.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T01', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Transactions - CCAM - View', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T01', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[2]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T01', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[2]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T01', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T01', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU07-NUC01-T02.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Transactions - CCAM - View', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[2]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[2]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||index=2||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||index=2||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=25||length=28||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=25||length=28||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=31||length=34||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=31||length=34||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=25||length=28||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=25||length=28||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=31||length=34||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=31||length=34||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||index=3||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||index=3||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=97||length=100||classIndex=2||classLength=3]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=97||length=100||classIndex=2||classLength=3]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=103||length=106||classIndex=3||classLength=4]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=103||length=106||classIndex=3||classLength=4]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=97||length=100||classIndex=2||classLength=3]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 54, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=97||length=100||classIndex=2||classLength=3]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 55, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 56, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 57, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 58, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 59, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 60, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 61, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 62, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 63, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 64, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 65, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 66, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 67, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 68, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 69, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=dt_effect]/L', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 70, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/body/row[trans_id=66||dt_input=Mon Oct 10 2011 12:00:00 GMT+0200 (W. Europe Daylight Time)||0]/col[fieldName=dt_input||2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 71, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDropToObject', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=dt_effect]/L', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/body/row[trans_id=66||dt_input=Mon Oct 10 2011 12:00:00 GMT+0200 (W. Europe Daylight Time)||0]/col[fieldName=dt_input||2]', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 72, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 73, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 74, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 75, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 76, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 77, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 78, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=CARIPARMA||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 79, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=CARIPARMA||index=1||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 80, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=CARIPARMA||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T02', 81, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=CARIPARMA||index=1||Class=TextItem]/element', 'CARIPARMA', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU07-NUC01-T03.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Transactions - CCAM - View', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[2]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[2]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||index=2||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||index=2||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=25||length=28||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=25||length=28||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=31||length=34||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=31||length=34||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=25||length=28||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=25||length=28||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=31||length=34||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=31||length=34||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '/* date value test POSTPONED  */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_input||title=dt_input||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_input||title=Input%20date||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||index=3||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||index=3||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=97||length=100||classIndex=2||classLength=3]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=97||length=100||classIndex=2||classLength=3]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=103||length=106||classIndex=3||classLength=4]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=103||length=106||classIndex=3||classLength=4]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=97||length=100||classIndex=2||classLength=3]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 54, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=97||length=100||classIndex=2||classLength=3]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 55, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 56, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 57, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 58, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 59, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 60, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 61, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 62, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 63, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 64, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 65, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 66, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_effect||title=dt_effect||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 67, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 68, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_effect||title=Effect%20date||value=[object Object]||index=3||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 69, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=dt_effect]/L', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 70, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/body/row[trans_id=66||dt_input=Mon Oct 10 2011 12:00:00 GMT+0200 (W. Europe Daylight Time)||0]/col[fieldName=dt_input||2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 71, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDropToObject', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=dt_effect]/L', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/body/row[trans_id=66||dt_input=Mon Oct 10 2011 12:00:00 GMT+0200 (W. Europe Daylight Time)||0]/col[fieldName=dt_input||2]', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 72, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 73, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 74, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 75, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 76, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 77, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 78, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=CARIPARMA||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 79, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=CARIPARMA||index=1||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 80, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=CARIPARMA||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 81, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=CARIPARMA||index=1||Class=TextItem]/element', 'CARIPARMA', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 82, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 83, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 84, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=BANCA%20D%27ITALIA||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 85, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=BANCA%20D%27ITALIA||index=1||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 86, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=BANCA%20D%27ITALIA||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 87, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=acc_name||title=Account%20name||value=BANCA%20D%27ITALIA||index=1||Class=TextItem]/element', 'BANCA D''ITALIA', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 88, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 89, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 90, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Columns||6]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 91, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Columns||6]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 92, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Trans.%20amount||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 93, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Trans.%20amount||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 94, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 95, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 96, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Ungroup||9]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 97, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Ungroup||9]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 98, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 99, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 100, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Account%20name||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 101, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Account%20name||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 102, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 103, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 104, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Ungroup||9]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 105, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Ungroup||9]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 106, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU07-NUC01-T03', 107, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="liquidity_transactions_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T01', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU08-NUC01-T01.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T01', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Default fund stg - CCAM - View', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T01', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[6]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T01', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[6]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T01', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T01', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU08-NUC01-T02.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Default fund stg - CCAM - Filters', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[6]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[6]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=nuova||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=nuova||index=1||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/body/vscrollbar/peer[Class=SpritedVSimpleScrollThumb||index=0||length=1||classIndex=0||classLength=1||title=%26nbsp%3B||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDrop', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/body/vscrollbar/peer[Class=SpritedVSimpleScrollThumb||index=0||length=1||classIndex=0||classLength=1||title=%26nbsp%3B||name=main]/', '+11,-375', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=nuova||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=nuova||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', 'intesa', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Sort%20Ascending||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Sort%20Ascending||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=21||length=24||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=21||length=24||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=27||length=30||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=27||length=30||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 54, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 55, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 56, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 57, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/cancelButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 58, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/cancelButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 59, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 60, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 61, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E739969000||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 62, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E739969000||index=2||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 63, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E7399||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 64, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E7399||index=2||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 65, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E7399||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 66, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E7399||index=2||Class=FloatItem]/element', '>7399 /* FILTER - Posizionamento errato */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 67, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 68, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 69, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E7399||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T02', 70, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E7399||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU08-NUC01-T03.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Default fund stg - CCAM - Grouping and refresh', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[6]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[6]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=nuova||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=nuova||index=1||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/body/vscrollbar/peer[Class=SpritedVSimpleScrollThumb||index=0||length=1||classIndex=0||classLength=1||title=%26nbsp%3B||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'dragAndDrop', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/body/vscrollbar/peer[Class=SpritedVSimpleScrollThumb||index=0||length=1||classIndex=0||classLength=1||title=%26nbsp%3B||name=main]/', '+11,-375', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=nuova||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=nuova||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=legal_name||title=Legal%20name||value=intesa||index=1||Class=TextItem]/element', 'intesa', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Sort%20Ascending||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Sort%20Ascending||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '/* Filter - Calc Date POSTPONED  */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '/* Filter - Calc Date POSTPONED  */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '/* Filter - Calc Date POSTPONED  */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '/* Filter - Calc Date POSTPONED  */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=21||length=24||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=21||length=24||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '/* Filter - Calc Date POSTPONED  */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '/* Filter - Calc Date POSTPONED  */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=27||length=30||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=27||length=30||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '/* Filter - Calc Date POSTPONED  */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=%24yesterday||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/cancelButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/cancelButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 54, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 55, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E739969000||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 56, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E739969000||index=2||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 57, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E7399||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 58, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E7399||index=2||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 59, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E7399||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 60, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E7399||index=2||Class=FloatItem]/element', '>7399 /* FILTER - Posizionamento errato */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 61, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 62, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 63, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E7399||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU08-NUC01-T03', 64, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_deffund_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=df_contribution||title=Default%20fund%20contrib.||value=%3E7399||index=2||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T01', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU09-NUC01-T01.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T01', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Repo stg - CCAM - View', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T01', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T01', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[7]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T01', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[7]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T01', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T01', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU09-NUC01-T02.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Repo stg - CCAM - Filter', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[7]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[7]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=28||length=31||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=28||length=31||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/', '/*  Ref Date errore nel filtro - POSTPONED */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=34||length=37||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=34||length=37||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=counterparty_name||title=Counterparty%20name||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=counterparty_name||title=Counterparty%20name||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=counterparty_name||title=Counterparty%20name||value=intesa||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=counterparty_name||title=Counterparty%20name||value=intesa||index=3||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=counterparty_name||title=Counterparty%20name||value=intesa||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=counterparty_name||title=Counterparty%20name||value=intesa||index=3||Class=TextItem]/element', 'intesa', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||index=6||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||index=6||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=53||length=56||classIndex=2||classLength=3]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=53||length=56||classIndex=2||classLength=3]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=59||length=62||classIndex=3||classLength=4]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 54, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=59||length=62||classIndex=3||classLength=4]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 55, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 56, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 57, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 58, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 59, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 60, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 61, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 62, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 63, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 64, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 65, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 66, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 67, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||index=7||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 68, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||index=7||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 69, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 70, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 71, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=69||length=72||classIndex=4||classLength=5]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 72, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=69||length=72||classIndex=4||classLength=5]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 73, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 74, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 75, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=75||length=78||classIndex=5||classLength=6]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 76, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=75||length=78||classIndex=5||classLength=6]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 77, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 78, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 79, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 80, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 81, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 82, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 83, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 84, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 85, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 86, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 87, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 88, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 89, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||deal_number=57555||face_value=50000000||1]/col[fieldName=face_value||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 90, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||deal_number=57555||face_value=50000000||1]/col[fieldName=face_value||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 91, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||deal_number=57555||face_value=50000000||1]/col[fieldName=face_value||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 92, '0.1', 'http://10.0.10.173:9081/CCAM/', 'contextMenu', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||deal_number=57555||face_value=50000000||1]/col[fieldName=face_value||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 93, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 94, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 95, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=82||length=84||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%2250000000%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 96, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=82||length=84||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%2250000000%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 97, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=82||length=84||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 98, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=82||length=84||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 99, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 100, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 101, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 102, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 103, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 104, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 105, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T02', 106, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '50000000 /* Face Value eand Return Value Filters POSTPONED  because Ret Value allow 1 only char  */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU09-NUC01-T03.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Repo stg - CCAM - Grouping and refresh', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[7]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[7]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=28||length=31||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=28||length=31||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/', '/*  Ref Date errore nel filtro - POSTPONED */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=34||length=37||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=34||length=37||classIndex=1||classLength=2]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_ref||title=Ref.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=counterparty_name||title=Counterparty%20name||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=counterparty_name||title=Counterparty%20name||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=counterparty_name||title=Counterparty%20name||value=intesa||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=counterparty_name||title=Counterparty%20name||value=intesa||index=3||Class=TextItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=counterparty_name||title=Counterparty%20name||value=intesa||index=3||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=counterparty_name||title=Counterparty%20name||value=intesa||index=3||Class=TextItem]/element', 'intesa', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||index=6||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||index=6||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=53||length=56||classIndex=2||classLength=3]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=53||length=56||classIndex=2||classLength=3]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=59||length=62||classIndex=3||classLength=4]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=59||length=62||classIndex=3||classLength=4]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 54, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 55, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 56, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 57, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_deal||title=dt_deal||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 58, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 59, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_deal||title=Deal.%20date||value=[object Object]||index=6||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 60, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||index=7||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 61, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||index=7||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 62, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 63, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 64, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=69||length=72||classIndex=4||classLength=5]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 65, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=69||length=72||classIndex=4||classLength=5]/dateGrid/body/row[Wed=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 66, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 67, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 68, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=75||length=78||classIndex=5||classLength=6]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 69, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=75||length=78||classIndex=5||classLength=6]/dateGrid/body/row[Thu=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||3]/col[fieldName=Thu||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 70, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 71, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 72, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 73, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 74, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 75, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=21%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=21%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 76, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 77, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 78, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 79, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_settle||title=dt_settle||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=22%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=22%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 80, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 81, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_settle||title=Settle.%20date||value=[object Object]||index=7||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 82, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||deal_number=57555||face_value=50000000||1]/col[fieldName=face_value||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 83, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||deal_number=57555||face_value=50000000||1]/col[fieldName=face_value||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 84, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||deal_number=57555||face_value=50000000||1]/col[fieldName=face_value||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 85, '0.1', 'http://10.0.10.173:9081/CCAM/', 'contextMenu', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=Wed Dec 21 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||deal_number=57555||face_value=50000000||1]/col[fieldName=face_value||4]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 86, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 87, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 88, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=82||length=84||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%2250000000%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 89, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=82||length=84||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%2250000000%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 90, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=82||length=84||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 91, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=82||length=84||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 92, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 93, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 94, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 95, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 96, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 97, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 98, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 99, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '50000000 /* Face Value eand Return Value Filters POSTPONED  because Ret Value allow 1 only char  */', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 100, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 101, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 102, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[title=by%20Month||2]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 103, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[title=by%20Month||2]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 104, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 105, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 106, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Ungroup||9]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 107, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Ungroup||9]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 108, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 109, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 110, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[title=by%20Day||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 111, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[title=by%20Day||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 112, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||5]/col[fieldName=dt_ref||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 113, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_ref=Thu Dec 22 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||5]/col[fieldName=dt_ref||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 114, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 115, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 116, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Face%20value||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 117, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/headerContextMenu[Class=Menu||index=0||length=1||classIndex=0||classLength=1||roleIndex=0||roleLength=1||scRole=menu]/body/row[title=Group%20by%20Face%20value||8]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 118, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 119, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||value=50000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 120, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 121, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=face_value||title=Face%20value||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 122, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 123, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 124, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 125, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 126, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 127, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 128, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU09-NUC01-T03', 129, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/header/member[Class=Img||index=1||length=5||classIndex=0||classLength=1||name=main]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T01', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU10-NUC01-T01.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T01', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Interop. Link stg - CCAM - View', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T01', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T01', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[7]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T01', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[7]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T01', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T01', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_repo_tab_2"]/maximizeButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU10-NUC01-T02.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Interop. Link stg - CCAM - Filter', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=19||length=22||classIndex=0||classLength=1]/dateGrid/body/row[Tue=Tue Dec 27 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Tue||2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=19||length=22||classIndex=0||classLength=1]/dateGrid/body/row[Tue=Tue Dec 27 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Tue||2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=25||length=28||classIndex=1||classLength=2]/dateGrid/body/row[Wed=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=25||length=28||classIndex=1||classLength=2]/dateGrid/body/row[Wed=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=27%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=27%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=27%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=27%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=27%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=27%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=27%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=27%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=28%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=28%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=28%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=28%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=28%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=28%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=28%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=28%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Tue Dec 13 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||ccg_initmar=4159890425.29||10]/col[fieldName=ccg_initmar||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'contextMenu', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Tue Dec 13 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||ccg_initmar=4159890425.29||10]/col[fieldName=ccg_initmar||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=36||length=38||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%224159890425.29%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=36||length=38||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%224159890425.29%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=36||length=38||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=36||length=38||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_initmar||title=CCG%20IM%20on%20Cnet||index=1||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_initmar||title=CCG%20IM%20on%20Cnet||index=1||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_initmar||title=CCG%20IM%20on%20Cnet||value=%224159890425.29||index=1||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_initmar||title=CCG%20IM%20on%20Cnet||value=%224159890425.29||index=1||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_initmar||title=CCG%20IM%20on%20Cnet||value=4159890425.29||index=1||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_initmar||title=CCG%20IM%20on%20Cnet||value=4159890425.29||index=1||Class=FloatItem]/element', '4159890425', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||ccg_add_initmar_Tm2=605000000||0]/col[fieldName=ccg_add_initmar_Tm2||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||ccg_add_initmar_Tm2=605000000||0]/col[fieldName=ccg_add_initmar_Tm2||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||ccg_add_initmar_Tm2=605000000||0]/col[fieldName=ccg_add_initmar_Tm2||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'contextMenu', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||ccg_add_initmar_Tm2=605000000||0]/col[fieldName=ccg_add_initmar_Tm2||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=60||length=62||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%22605000000%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=60||length=62||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%22605000000%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=60||length=62||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=60||length=62||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 54, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 55, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 56, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 57, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 58, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 59, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 60, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 61, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 62, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '605000000', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 63, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 64, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 65, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 66, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 67, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 68, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=605000000||index=3||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 69, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 70, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 71, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 72, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 73, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 74, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 75, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||value=605000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 76, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||value=605000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 77, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||value=601000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 78, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||value=601000000||index=4||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 79, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||value=601000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 80, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||value=601000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 81, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 82, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||index=4||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 83, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=cnet_cash_call]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 84, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=cnet_cash_call]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 85, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 86, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 87, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||cnet_excess_cash=58874678||1]/col[fieldName=cnet_excess_cash||6]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 88, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||cnet_excess_cash=58874678||1]/col[fieldName=cnet_excess_cash||6]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 89, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||cnet_excess_cash=58874678||1]/col[fieldName=cnet_excess_cash||6]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 90, '0.1', 'http://10.0.10.173:9081/CCAM/', 'contextMenu', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||cnet_excess_cash=58874678||1]/col[fieldName=cnet_excess_cash||6]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 91, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 92, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 93, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=79||length=81||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%2258874678%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 94, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=79||length=81||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%2258874678%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 95, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=79||length=81||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 96, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=79||length=81||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 97, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 98, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 99, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 100, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 101, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 102, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 103, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 104, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 105, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 106, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 107, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 108, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 109, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 110, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||index=6||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 111, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 112, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 113, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 114, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 115, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 116, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 117, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/clearButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 118, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/clearButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 119, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 120, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 121, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 122, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 123, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_cash_call||title=Cnet%20cash.%20call||index=5||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 124, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_cash_call||title=Cnet%20cash.%20call||index=5||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 125, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_cash_call||title=Cnet%20cash.%20call||value=0||index=5||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 126, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_cash_call||title=Cnet%20cash.%20call||value=0||index=5||Class=FloatItem]/element', '${KEY_LEFT}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 127, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_cash_call||title=Cnet%20cash.%20call||value=0||index=5||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T02', 128, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_cash_call||title=Cnet%20cash.%20call||value=0||index=5||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU10-NUC01-T03.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Interop. Link stg - CCAM - Grouping and refresh', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', '//div[@id=''isc_H'']/table/tbody/tr/td/table/tbody/tr/td[2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=19||length=22||classIndex=0||classLength=1]/dateGrid/body/row[Tue=Tue Dec 27 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Tue||2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 11, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=19||length=22||classIndex=0||classLength=1]/dateGrid/body/row[Tue=Tue Dec 27 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Tue||2]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 12, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 13, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon="chooserIcon"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 14, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=DateChooser||index=25||length=28||classIndex=1||classLength=2]/dateGrid/body/row[Wed=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 15, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=DateChooser||index=25||length=28||classIndex=1||classLength=2]/dateGrid/body/row[Wed=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Wed||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 16, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 17, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 18, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=27%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=27%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 19, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=27%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=27%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 20, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=27%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=27%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 21, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||value=27%24fs%2412%24fs%242016||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=27%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 22, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=28%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=28%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 23, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=28%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=28%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 24, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=28%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=28%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 25, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||value=28%24fs%2412%24fs%242016||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||value=28%24fs%2412%24fs%242016||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 26, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 27, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 28, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Tue Dec 13 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||ccg_initmar=4159890425.29||10]/col[fieldName=ccg_initmar||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 29, '0.1', 'http://10.0.10.173:9081/CCAM/', 'contextMenu', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Tue Dec 13 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||ccg_initmar=4159890425.29||10]/col[fieldName=ccg_initmar||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 30, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 31, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 32, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=36||length=38||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%224159890425.29%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 33, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=36||length=38||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%224159890425.29%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 34, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=36||length=38||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 35, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=36||length=38||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 36, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_initmar||title=CCG%20IM%20on%20Cnet||index=1||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 37, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_initmar||title=CCG%20IM%20on%20Cnet||index=1||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 38, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_initmar||title=CCG%20IM%20on%20Cnet||value=%224159890425.29||index=1||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 39, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_initmar||title=CCG%20IM%20on%20Cnet||value=%224159890425.29||index=1||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 40, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_initmar||title=CCG%20IM%20on%20Cnet||value=4159890425.29||index=1||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 41, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_initmar||title=CCG%20IM%20on%20Cnet||value=4159890425.29||index=1||Class=FloatItem]/element', '4159890425', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 42, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 43, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||ccg_add_initmar_Tm2=605000000||0]/col[fieldName=ccg_add_initmar_Tm2||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 44, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||ccg_add_initmar_Tm2=605000000||0]/col[fieldName=ccg_add_initmar_Tm2||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 45, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||ccg_add_initmar_Tm2=605000000||0]/col[fieldName=ccg_add_initmar_Tm2||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 46, '0.1', 'http://10.0.10.173:9081/CCAM/', 'contextMenu', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||ccg_add_initmar_Tm2=605000000||0]/col[fieldName=ccg_add_initmar_Tm2||3]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 47, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 48, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=title||1]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 49, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=60||length=62||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%22605000000%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 50, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=60||length=62||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%22605000000%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 51, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=60||length=62||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 52, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=60||length=62||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 53, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 54, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 55, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 56, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 57, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 58, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 59, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 60, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 61, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 62, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '605000000', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 63, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 64, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 65, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 66, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=%3D605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 67, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 68, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=605000000||index=3||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 69, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 70, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||value=605000000||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 71, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 72, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm2||title=CCG%20add.init.mar.%20T-2||index=3||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 73, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 74, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 75, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||value=605000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 76, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||value=605000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 77, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||value=601000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 78, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||value=601000000||index=4||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 79, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||value=601000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 80, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||value=601000000||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 81, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||index=4||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 82, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=ccg_add_initmar_Tm1||title=CCG%20add.init.mar%20T-1||index=4||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 83, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=cnet_cash_call]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 84, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/header/headerButton[fieldName=cnet_cash_call]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 85, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 86, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 87, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||cnet_excess_cash=58874678||1]/col[fieldName=cnet_excess_cash||6]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 88, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||cnet_excess_cash=58874678||1]/col[fieldName=cnet_excess_cash||6]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 89, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||cnet_excess_cash=58874678||1]/col[fieldName=cnet_excess_cash||6]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 90, '0.1', 'http://10.0.10.173:9081/CCAM/', 'contextMenu', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/body/row[dt_calc=Wed Dec 28 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||cnet_excess_cash=58874678||1]/col[fieldName=cnet_excess_cash||6]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 91, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 92, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=0]/body/row[title=Copy||0]/col[fieldName=icon||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 93, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=79||length=81||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%2258874678%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 94, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=79||length=81||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=textArea||title=textArea||value=%2258874678%22||index=1||Class=TextAreaItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 95, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//autoID[Class=Dialog||index=79||length=81||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 96, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//autoID[Class=Dialog||index=79||length=81||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Copy%20Cells||scRole=alertdialog]/item[0][Class="DynamicForm"]/item[name=done||title=Done||index=2||Class=ButtonItem]/button/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 97, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 98, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 99, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 100, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 101, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 102, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 103, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 104, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 105, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 106, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 107, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 108, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||value=%3E588||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 109, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||index=6||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 110, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_excess_cash||title=Cnet%20excess%20cash||index=6||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 111, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 112, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 113, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 114, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 115, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 116, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 117, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/clearButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 118, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/clearButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 119, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 120, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 121, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 122, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 123, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_cash_call||title=Cnet%20cash.%20call||index=5||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 124, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_cash_call||title=Cnet%20cash.%20call||index=5||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 125, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_cash_call||title=Cnet%20cash.%20call||value=0||index=5||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 126, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_cash_call||title=Cnet%20cash.%20call||value=0||index=5||Class=FloatItem]/element', '${KEY_LEFT}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 127, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementReadyForKeyPresses', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_cash_call||title=Cnet%20cash.%20call||value=0||index=5||Class=FloatItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 128, '0.1', 'http://10.0.10.173:9081/CCAM/', 'sendKeys', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=cnet_cash_call||title=Cnet%20cash.%20call||value=0||index=5||Class=FloatItem]/element', '${KEY_ENTER}', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 129, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 130, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/[icon="showDateRange"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 131, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 132, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 133, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 134, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24yesterday||1]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 135, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 136, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||index=0||Class=ComboBoxItem]/[icon="picker"]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 137, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 138, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_calc||title=dt_calc||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=valueField||title=valueField||index=0||Class=ComboBoxItem]/pickList/body/row[valueField=%24today||0]/col[fieldName=valueField||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 139, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 140, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=dt_calc||title=Calc.%20date||value=[object Object]||index=0||Class=MiniDateRangeItem]/rangeDialog/okButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 141, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 142, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 143, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU10-NUC01-T03', 144, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="datastaging_interop_tab_2"]/item[0][Class="ListGrid"]/headerMenuButton/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T01', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU11-NUC01-T01.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T01', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Liquidity Params - CCAM - View', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T01', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Menu[level=1]/body/row[8]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T01', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Menu[level=1]/body/row[8]/col[fieldName=title||0]', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T01', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_liqparam_tab_2"]/item[0][Class="VLayout"]/member[Class=DynamicForm||index=0||length=3||classIndex=0||classLength=1]/item[name=%3Cnobr%3ECredit%20lines%3C%24fs%24nobr%3E||title=%3Cnobr%3ECredit%20lines%3C%24fs%24nobr%3E||value=22||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T01', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_liqparam_tab_2"]/item[0][Class="VLayout"]/member[Class=DynamicForm||index=0||length=3||classIndex=0||classLength=1]/item[name=%3Cnobr%3ECredit%20lines%3C%24fs%24nobr%3E||title=%3Cnobr%3ECredit%20lines%3C%24fs%24nobr%3E||value=22||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T02', 1, '0.1', 'http://10.0.10.173:9081/CCAM/', 'echo', '', 'RU11-NUC01-T02.rctest', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T02', 2, '0.1', 'http://10.0.10.173:9081/CCAM/', 'open', '/CCAM/', 'Liquidity Params - CCAM - Edit', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T02', 3, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_liqparam_tab_2"]/item[0][Class="VLayout"]/member[Class=DynamicForm||index=0||length=3||classIndex=0||classLength=1]/item[name=%3Cnobr%3ECredit%20lines%3C%24fs%24nobr%3E||title=%3Cnobr%3ECredit%20lines%3C%24fs%24nobr%3E||value=25||index=0||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T02', 4, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_liqparam_tab_2"]/item[0][Class="VLayout"]/member[Class=DynamicForm||index=0||length=3||classIndex=0||classLength=1]/item[name=%3Cnobr%3ECredit%20lines%3C%24fs%24nobr%3E||title=%3Cnobr%3ECredit%20lines%3C%24fs%24nobr%3E||value=25||index=0||Class=TextItem]/element', '22', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T02', 5, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_liqparam_tab_2"]/item[0][Class="VLayout"]/member[Class=DynamicForm||index=0||length=3||classIndex=0||classLength=1]/item[name=%3Cnobr%3ECash%20for%20settlement%3C%24fs%24nobr%3E||title=%3Cnobr%3ECash%20for%20settlement%3C%24fs%24nobr%3E||value=222||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T02', 6, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_liqparam_tab_2"]/item[0][Class="VLayout"]/member[Class=DynamicForm||index=0||length=3||classIndex=0||classLength=1]/item[name=%3Cnobr%3ECash%20for%20settlement%3C%24fs%24nobr%3E||title=%3Cnobr%3ECash%20for%20settlement%3C%24fs%24nobr%3E||value=222||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T02', 7, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_liqparam_tab_2"]/item[0][Class="VLayout"]/member[Class=DynamicForm||index=0||length=3||classIndex=0||classLength=1]/item[name=%3Cnobr%3ECash%20for%20settlement%3C%24fs%24nobr%3E||title=%3Cnobr%3ECash%20for%20settlement%3C%24fs%24nobr%3E||value=225||index=1||Class=TextItem]/element', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T02', 8, '0.1', 'http://10.0.10.173:9081/CCAM/', 'type', 'scLocator=//Portlet[ID="refdata_liqparam_tab_2"]/item[0][Class="VLayout"]/member[Class=DynamicForm||index=0||length=3||classIndex=0||classLength=1]/item[name=%3Cnobr%3ECash%20for%20settlement%3C%24fs%24nobr%3E||title=%3Cnobr%3ECash%20for%20settlement%3C%24fs%24nobr%3E||value=225||index=1||Class=TextItem]/element', '222', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T02', 9, '0.1', 'http://10.0.10.173:9081/CCAM/', 'waitForElementClickable', 'scLocator=//Portlet[ID="refdata_liqparam_tab_2"]/item[0][Class="VLayout"]/member[Class=HLayout||index=2||length=3||classIndex=0||classLength=1]/member[Class=Button||index=1||length=2||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Save||scRole=button]/', '', '', '')
GO
INSERT INTO PAMPQA.PMPTXSSEL(SELNAPP, SELTNAM, SELPRG, SELVID, SELBURL, SELCMD, SELTARG, SELVAL, SELOBJID, UPDTYPE)
  VALUES('CCAM', 'RU11-NUC01-T02', 10, '0.1', 'http://10.0.10.173:9081/CCAM/', 'click', 'scLocator=//Portlet[ID="refdata_liqparam_tab_2"]/item[0][Class="VLayout"]/member[Class=HLayout||index=2||length=3||classIndex=0||classLength=1]/member[Class=Button||index=1||length=2||classIndex=0||classLength=1||roleIndex=0||roleLength=1||title=Save||scRole=button]/', '', '', '')
GO
