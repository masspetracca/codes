package SeleniumTesting;

import com.thoughtworks.selenium.DefaultSelenium;
import com.thoughtworks.selenium.Selenium;

public class GmailTest {
	 public static void main(String[] args) {
		 Selenium sel = new DefaultSelenium("localhost", 4444, "firefox", "http://gmail.com");
		 sel.start();
		 sel.open("/");
		 sel.windowMaximize();
		 sel.windowFocus();
		 sel.type("id=Email", "selenium");
	}
}
