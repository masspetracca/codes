package SeleniumTesting;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Selenium3 {
	private static WebElement img;

	public static void main(String[] args) {
		
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		driver.get("http://google.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
//		driver.findElement(By.name("q")).sendKeys("wayautomation");
//		//WebDriverWait wait = new WebDriverWait(driver, 5);
//		//wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElement("/html/body/div/div[3]")));
//		driver.findElement(By.xpath("/html/body/div/div[3]"));
//		driver.findElement(By.linkText("Practis"));
//		
//		WebElement mainSlider = driver.findElement(By.xpath("slider"));
//		WebElement menu = driver.findElement(By.xpath("/html/body/div/div[3]"));
//		int width = mainSlider.getSize().width/2;
//		
//		Actions act = new Actions(driver);
//		act.contextClick(img).perform();
//		act.moveToElement(menu).perform();
//		act.sendKeys(Keys.chord(Keys.CONTROL+"a")).perform();
//		
//		driver.findElement(By.id("identifierID")).click();
//		act.sendKeys(Keys.chord(Keys.CONTROL+"v")).perform();
//		
//		act.dragAndDrop(draggable,droppable).perform();
//		
//		driver.findElement(By.linkText("Practice site 1")).click();
//		
////		Alert alert = new driver.switchTo().alert();
////		System.out.println(alert.getText());
////		alert.accept();
//		
//		WebDriverWait wait = new WebDriverWait(driver, 10);
//		Alert alert = wait.until(ExpectedConditions.alertIsPresent());
//		
//		System.out.println(alert.getText());
//		alert.accept();
//		
//		//WebDriverManager.chromedriver().setup();
//		WebDriver drver = new ChromeDriver();
//		
//		drver.get("htpps://www.w3schools.com/jsref/trfy.asp?file"); 
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		
//		driver.switchTo().frame("iframeResult");
//		driver.findElement(By.xpath("/html/body/button")).click();
//		
//		List<WebElement> frames = driver.findElements(By.tagName(""));
//		
//		System.out.print(frames.size());
//		
//		for (WebElement frame: frames) {
//			System.out.println(frame.getAttribute("id"));
//		}
//		driver.switchTo().frame("iframeResult");
//		driver.findElement(By.xpath("/html/body/button")).click();
//		
//		driver.switchTo().defaultContent();
//		
//		List<WebElement> frame = driver.findElements(By.tagName("id"));
//		System.out.println(frames.size());
		
	
		
	}
}
