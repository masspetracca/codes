package SeleniumTesting;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TestDropDown {
	public static WebDriver driver;
	
	public static boolean isElementPresent(String locator) {
		/*try{
		driver.findElement(By.xpath(locator));
		return true;
		}catch(Throwable t) {
			return false;
		}*/
		int size = driver.findElements(By.xpath(locator)).size();
		if (size==0) {
			return false;
		} else {
			return true;
		}
	}
	
	public static void main(String[] args) {
		//WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.wikipedia.org/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.findElement(By.name("language")).sendKeys("Dansk");
		driver.findElement(By.id("searchLanguage")).sendKeys("Eesti");
		
		WebElement dropdown = driver.findElement(By.id("searchLangage"));
		
		Select sel = new Select(dropdown);
		sel.selectByVisibleText("Eesti");
		sel.selectByValue("hi");
		System.out.println(("//*[@id='searchLanguage32434']"));
		
		/*
		 * id
			name
			cssSelector
			Xpath
			className
			tagName
			linkText
			partialLinkText
			Xpath - Firebug and Firepath - Chropath
		   <input type="email" class="whsOnd zHQkBf" jsname="YPqjbf" autocomplete="username" spellcheck="false" tabindex="0" aria-label="Email or phone" name="identifier" autocapitalize="none" id="identifierId" dir="ltr" data-initial-dir="ltr" data-initial-value="" badinput="false">
			//tagName[@attribute='value'] - Relative Xpath, Absolute xpath, partial xpath
			//input[@name='identifier'][@id='identifierId']
			//input[@name='identifier' and @id='identifierId']
			//input[@id='identifierId']
			//*[@id="identifierId"]
			//*[@id="identifierId"]
			//input[@name='q']
			//*[@id="view_container"]/div/div/div[2]/div/div[1]/div/form/content/section/div/content/div[1]/div/div[1]/div/div[1]
		 */
		
		/*
		XPATH SYNTAX
		-----------------
		//tagName[@attribute='value']
		//tagName[@attribute='value'][@attribute='value'][@attribute='value']
		//tagName[starts-with(@attribute,'value')]
		//tagName[contains(@attribute,'value')]
		//tagName[text()='value']
		//tagName[contains(text(),'partialvalue')]
		//tagName[@attribute='value']/..
		//tagName[@attribute='value']/parent::tagname
		//tagName[@attribute='value']/following-sibling::tagname
		//tagName[@attribute='value']/preceding-sibling::tagname[1]
		
		CSS SYNTAX
		-------------------
		input[id='identifierId']
		input[id='identifierId'][type='email']
		input[id^='identifie'] - starts-with
		input[id$='tifierId'] - ends-with
		input[id*='tifier'] - contains
		#identifierId - id
		tagName - tagName
		.Xb9hP - className
		input#identifierId.whsOnd.zHQkBf[type='email']
		div.aCsJod.oJeWuf > div > div:first-child
		div.aCsJod.oJeWuf > div > div:last-child
		div.aCsJod.oJeWuf > div > div:nth-child(2)
		div[jsname='dWPKW'] > div > div > div > div:nth-child(2)
 
		 */
	}
}
