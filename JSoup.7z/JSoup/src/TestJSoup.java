import java.io.File;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class TestJSoup {
	File input = new File("/tmp/input.html");
	Document doc = Jsoup.parse(input, "UTF-8", "http://example.com/");
	org.jsoup.nodes.Element content = doc.getElementById("content");
	 public TestJSoup() {
		// TODO Auto-generated constructor stub
		 Elements links = content.getElementsByTag("a");
			for (Element link : links) {  
				String linkHref = ( link).attr("href");  
				String linkText = ((org.jsoup.nodes.Element) link).text();
			}
	}
	
	
}
