package it.ccg.test.collaudo.server.bus;

public class WriteScenario {

	String OutScenario;
	
	
	public WriteScenario(String outScenario) {
		OutScenario = outScenario;
	}

	public String getWriteScenario(String outScenario) {
		return outScenario;
	}

	public void setWriteScenario(String outScenario) {
		OutScenario = outScenario;
		
	}

}
