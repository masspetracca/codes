package it.ccg.test.collaudo.server.bus;



import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

public class PopulateDb {
	
	//Table access keys
	private static String kArea = ""; 
	private static String kStato = ""; 
	private static String kFreq ="";
	private static String kTipo ="";
	
	String nodeGifDtData;
	String nodeIDGifData;
	String nodeGFDescData;
	String nodeAmountData;

	private static String TabLIME_col0 = "UATLIME_DT";
	private static String TabLIME_col1 = "UATLIME_ID_LIME";
	private static String TabLIME_col2 = "UATLIME_ID_GIF";
	private static String TabLIME_col3 = "UATLIME_GFDESC";
	private static String TabLIME_col4 = "UATLIME_AMOUNT";
	private String TableNameGIROFO = PropertyFiles.getTabName2();
	
	
//	private static String Tab_col4 = "";
//	private static String Tab_col5 = "";

	
	private static String TabGIROFO_col0 = "UATGIF_DT";
	private static String TabGIROFO_col1 = "UATGIF_ID";
	private static String TabGIROFO_col2 = "UATGIF_GFDESC";
	private static String TabGIROFO_col3 = "UATGIF_AMOUNT";
//	private static String Tab_col4 = "";
//	private static String Tab_col5 = "";
//
//	private static String Tab_col6 = "";
//	private static String Tab_col7 = "";
//	private static String Tab_col8 = "";
//	private static String Tab_col9 = "";
//	private static String Tab_col10 = "";
	private String TableNameLIME = PropertyFiles.getTabName1();

	private static String vcol3 = "";
	private static String vcol4 = "";
	private static String vcol5 = "";

	private static String sdate =null;
	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

//	private static String tabFreq ="";
	private int ctrIns;
//	private int ctrUpd;
 	private int returnCode = 0;
 	private static String sqlUpdate;
//	
//
//	private static Object rs;
	
	PreparedStatement st;
	private String sqlDelete;
	private int ctrDel;


	public PopulateDb(String kGifDt, String kIDGifData, String nodeGFDescData, String nodeAmountData) throws ClassNotFoundException, IOException, SQLException, IllegalAccessException, InstantiationException {
		
		
		//upate table
		       sqlUpdate= 
				"INSERT INTO "+TableNameGIROFO
				+"("
				+""+TabGIROFO_col0
				+", "+TabGIROFO_col1
				+", "+TabGIROFO_col2
				+", "+TabGIROFO_col3
				+") VALUES ("
				+kGifDt				
				+", '"+kIDGifData+"'" 
				+", '"+nodeGFDescData+"'" 
				+", '"+nodeAmountData+"'" 
				+")"
				;

	    System.out.println(sqlUpdate);		
		++ctrIns;
		//setting upd parameters
		TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 
		upd.setSqlUpdate(sqlUpdate);	
}


	public PopulateDb(String kLimeDt, String kIDLime, String kIDGif, String nodeLIMEDescData, String nodeAmountData) {
		//upate table
	       sqlUpdate= 
			"INSERT INTO "+TableNameLIME
			+"("
			+""+TabLIME_col0
			+", "+TabLIME_col1
			+", "+TabLIME_col2
			+", "+TabLIME_col3
			+", "+TabLIME_col4
			+") VALUES ("
			+kLimeDt				
			+", '"+kIDLime+"'" 
			+", '"+kIDGif+"'" 
			+", '"+nodeLIMEDescData+"'" 
			+", '"+nodeAmountData+"'" 
			+")"
			;

			 System.out.println(sqlUpdate);		
			 ++ctrIns;
			//setting upd parameters
			TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 
			upd.setSqlUpdate(sqlUpdate);	
	}


	



}


	
		
							
   

