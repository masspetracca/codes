package it.ccg.test.collaudo.server.bus;


public class TestCollaudoQAUPD {
	

	public String getSqlUpdate() {
		return sqlUpdate;
	}

	public void setSqlUpdate(String sqlUpdate) {
		TestCollaudoQAUPD.sqlUpdate = sqlUpdate;
	}

	private static String sqlUpdate;
	
	

}
