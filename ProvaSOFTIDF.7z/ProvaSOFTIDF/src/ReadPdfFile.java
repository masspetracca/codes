import java.io.File;
import java.io.FileOutputStream;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.lowagie.text.rtf.RtfWriter2;

public class ReadPdfFile {

	public static void main(String[] args) {
	    try {

	        Document document = new Document();

	        File  file = new File("filePDF/file.doc");
	        if(!file.exists())
	            file.createNewFile();

	        com.lowagie.text.Document doc = null;
			
			RtfWriter2.getInstance(doc, new FileOutputStream("filePDF/file.doc"));
	        	//.getInstance(document, new FileOutputStream("/home/mujafar/Desktop/file.doc"));
	        System.out.println("file created");
	        document.open();

	    PdfReader reader = new PdfReader("filePDF/measures_en.pdf");
	    int n = reader.getNumberOfPages();
	    System.out.println("total no of pages:::"+n);
	    String s="";
	    for(int i=1;i<=n;i++)
	    {

	        s=PdfTextExtractor.getTextFromPage(reader, i);


	        System.out.println("string:::"+s);
	        System.out.println("====================");

	        document.add(new Paragraph(s));
	        document.newPage();
	    }
	    document.close();
	    System.out.println("completed");
	    } catch (Exception de) {}
	    }

}

