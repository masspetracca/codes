package com.TestSel.src;


public class Home {

	/*
	 * 
	 * Calculators  - add, sub, mul, div
	 * 1. methods --> add, sub, mul , div
	 * 2. return --> int
	 * 3. parameters --> 2  int
	 * 
	 * 
	 * 
	 */
	
	// instance / local / class variables
	
	/*
	 * 
	 * instance --- declared class body
	 * local variables --- declared inside method body
	 * 
	 */
	
	static int i = 10; //instance variables -- Global variable
	// these variables belongs to the instance of this class
	
	public void go(){
		
		i=356;
		int j = 234;
		
	}
	
	public void show(){
		
		i=7438;
		
		
	}
}
