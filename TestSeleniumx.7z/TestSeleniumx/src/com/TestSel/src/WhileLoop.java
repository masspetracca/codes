package com.TestSel.src;


public class WhileLoop {
	
	/*
	 *  loops are not statements --> they are not terminated but exits
	 *  entry criteria --> loop condition must be true
	 *  exist criteria --> loop condition is False
	 * 
	 * 
	 */

	public static void main(String[] args) {

		int i=11;
		
		while(true){
			
			i++;
			
		}
		
		/*do{
			
			System.out.println(i);
			i++;
			
		}
		while(i<=10);*/
		//System.out.println(i);
		//System.out.println("After loop");
		

	}

}
