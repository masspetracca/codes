package com.TestSel.src;

public class ForLoop {

	public static void main(String[] args) {

		/*
		 * 
		 * while --> when the number of iterations are unknown
		 * For --> number of iterations are known
		 * do While --> at least for one time irrespective of the condition
		 * 
		 * 
		 * 
		 */

		
		
		for(int i=1;i<=10 ;i++){
			
			
			System.out.println(i);
			i++;
			
		}

	}

}
