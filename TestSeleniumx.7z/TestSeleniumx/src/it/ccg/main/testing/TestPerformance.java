package it.ccg.main.testing;


public class TestPerformance {

	
	
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("Test di performance:");
		TestPerformance log = new TestPerformance();
		for (int i=0; i<10; i++) {
		    sb.append(i);
		    sb.append(" ");
			log.debug("User [" + i + "] called method X with [" + i + "]");
		}
		
		log.info(sb.toString());
	}

	private void debug(String stringDebug) {
		System.out.println(stringDebug);			
	}

	private boolean isDebugEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	private void info(String stringLog) {
		System.out.println(stringLog);		
	}
	
}
