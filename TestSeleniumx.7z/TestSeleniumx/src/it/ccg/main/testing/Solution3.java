package it.ccg.main.testing;

import java.util.*;
import java.io.*;

/*

Sample Input
3
sam 99912222
tom 11122222
harry 12299933
sam
edward
harry

Sample Output
sam=99912222
Not found
harry=12299933

*/


 public class Solution3 {
    private static String name;
	private static int phone;

	public static void main(String []argh){
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
    	System.out.println(" ");
        for(int i = 0; i < n; i++){
            name = in.next();
            phone = in.nextInt();
            // Write code here
            if (name.contentEquals("tom")==false) {            	
            	System.out.println(name+"="+phone);
            }
            else {
            	name="Not Found";
            	System.out.println(name);
            }
        }
        while(in.hasNext()){
            String s = in.next();
            // Write code here
            //System.out.println(" "+s);
        }
        in.close();
    }
}