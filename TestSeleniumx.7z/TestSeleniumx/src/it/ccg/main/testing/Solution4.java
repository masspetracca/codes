package it.ccg.main.testing;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

import javax.management.BadStringOperationException;

public class Solution4 {

    String sn;
    
    public static void main(String[] args) throws BadStringOperationException {
       try (
        Scanner in = new Scanner(System.in)) {
        String s = in.next();
        int sn = Integer.parseInt(s);
        System.out.println(sn);
       }
    	
    }
}