package it.ccg.main.testing;

import java.util.Scanner;

public class Solution9 {

	    private static double div =0;

		public static void main(String[] args) {
	        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
	    	Scanner scan = new Scanner(System.in);	
	    	int max=4;
        	System.out.println("\n");
	        for(int i = 0; i<max; i++){
	            double num = scan.nextDouble();
	            num = num /3;
	            // Write code here
	            if (num <=1) { 
	            	System.out.println("Not prime");//: "+num);
	            }
	            else {
	            	System.out.println("Prime");//+num);
	            }

	        }
	    }
}
