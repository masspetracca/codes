package it.ccg.main.testing;

//Complete this code or write your own from scratch
import java.util.*;
import java.io.*;

public class Solution1 {
  public static void main(String []argh){
      Scanner in = new Scanner(System.in);
      int n = in.nextInt();
      for(int i = 0; i < n; i++){
          String name = in.next();
          int phone = in.nextInt();
          //System.out.println(name+"="+phone);
          // Write code here
          if (name.contains("sam") ||name.contains("harry") ) {
              System.out.println(name+"="+phone);
          } else{
            System.out.println("Not found");  
          }
      }
      while(in.hasNext()){
          String s = in.next();
          // Write code here
      }
      in.close();
  }
}