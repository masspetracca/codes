package it.ccg.main.testing;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;

public class ImageTest {

public static void main(String[] args) {

try {

byte[] imageInByte;
BufferedImage originalImage = ImageIO.read(new File(
"a1.jpg"));

// convert BufferedImage to byte array
ByteArrayOutputStream baos = new ByteArrayOutputStream();
ImageIO.write(originalImage, "jpg", baos);



baos.flush();
imageInByte = baos.toByteArray();
System.out.println("The encoded image byte array ============ "+imageInByte );
baos.close();

// convert byte array back to BufferedImage
InputStream in = new ByteArrayInputStream(imageInByte);
BufferedImage bImageFromConvert = ImageIO.read(in);

ImageIO.write(bImageFromConvert, "jpg", new File(
"new-a1.jpg"));

} catch (IOException e) {
System.out.println(e.getMessage());
}
}
} 