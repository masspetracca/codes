package it.ccg.main.testing;

import java.util.Scanner;

import com.TestSel.src.Calculator;

class Solution8 {

    public static void main(String[] args) {
    	Scanner scan = new Scanner(System.in);
        
      	int Da = scan.nextInt();
        int Ma = scan.nextInt();
        int Ya = scan.nextInt();
        int De = scan.nextInt();
        int Me = scan.nextInt();
        int Ye = scan.nextInt();
        scan.close();   
        int Yel2 = Ye -2000; 
        int n = (Yel2*(Da-De));

        AdvancedArithmetic myCalculator = new Calculator();
        int comp = myCalculator.divisorSum(n);
        System.out.println(comp);
        
        System.out.println("I implemented: " + myCalculator.getClass().getInterfaces()[0].getName() );
        System.out.println(comp);
    }
}