package it.ccg.main.testing;

import java.util.Arrays;
import java.util.Scanner;

public class Solution2 {

	private static int i;
	private static int n;
	private static int x;

	public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        n = in.nextInt();
        int[] arr = new int[n];
        for(int i=0; i < arr.length; i++){
            arr[i] = in.nextInt();
        }
        for(i = 1; i < arr.length; i++) {
            Arrays.sort(arr);
            System.out.print( arr[i]+" ");
        }
        x=(i+1)-n;
        System.out.print(x);
        in.close();
    }
}