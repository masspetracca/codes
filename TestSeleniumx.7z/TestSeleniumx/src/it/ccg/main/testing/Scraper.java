package it.ccg.main.testing;


import org.jsoup.*;
import org.jsoup.helper.*;
import org.jsoup.nodes.*;
import org.jsoup.select.*;

import java.io.*; // Only needed if scraping a local File.

public class Scraper {


	public Scraper() {

		Document doc = null;

		try {
			doc = Jsoup.connect("https://www.fxstreet.com/economic-calendar").get();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		Element table = doc.getElementById("search_form");
		Elements rows = table.getElementsByTag("div");
		
		for (Element row : rows) {
			Elements tds = row.getElementsByTag("ul");
			for (int i = 0; i < tds.size(); i++) {
				if (i == 1) System.out.println(tds.get(i).text());
			}
		}
	
	}
	
	public static void main (String args[]) {

		new Scraper();
	
	}
	
}