package it.ccg.main.testing;

import java.io.IOException;
import java.util.Iterator;

import org.jsoup.*;
import org.jsoup.nodes.*;

//import java.io.*; // Only needed if scraping a local File.

public class Scrapx {
	
	public Scrapx()  {
		Document doc = null;
		String url = "https://www.premierleague.com/tables";
		try {
			doc = Jsoup.connect(url).get();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    Element table = doc.select("table").first();
	    Iterator<Element> team = table.select("td[class=team]").iterator();
	    Iterator<Element> rank = table.select("td[id=tooltip]").iterator();
	    Iterator<Element> points = table.select("td[class=points]").iterator();
	    System.out.println(team.next().text());
	    System.out.println(rank.next().text()); 
	    System.out.println(points.next().text());
	}

	public static void main (String args[])  {
		new Scrapx();
	}
}


