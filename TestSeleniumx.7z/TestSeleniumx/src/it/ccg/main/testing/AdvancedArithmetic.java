package it.ccg.main.testing;

public interface AdvancedArithmetic {
		int divisorSum(int n);
}
