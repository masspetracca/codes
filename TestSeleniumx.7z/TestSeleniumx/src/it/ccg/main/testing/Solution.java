package it.ccg.main.testing;

import java.io.*;
import java.util.*;


public class Solution {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] arr = new int[n];
        for(int i=0; i < n; i++){
            arr[i] = in.nextInt();
          //System.out.println(arr[i]);
        }
        in.close();
        //System.out.println("#"+n);
        for(int i=n; i <= n;){
        	if (i>0) {
	        	i--;
	            System.out.println(arr[i]);
        
        	}
        }
    }
}