package test;

import java.sql.ResultSet;
import java.sql.SQLException;

import kpmg.webccr.Depositi;
import kpmg.db.PrepareCallException;

public class Test {
	public static ResultSet a() throws SQLException, PrepareCallException{
		Depositi dep = new Depositi();
		
		ResultSet rs = dep.LoadDepositi();
	  return rs;

	}
}
