package kpmg.webccr;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import kpmg.db.Dbutil;
import kpmg.db.PrepareCallException;

import java.sql.ResultSet;
public class Depositi 
{
    public  Depositi(){
    
    }  
    
	public ResultSet LoadDepositi() throws PrepareCallException, SQLException 
	{
        String sql="select * from Depositi ";
        PreparedStatement prepStat = Dbutil.prepareStatement(sql);
        
	    return prepStat.executeQuery(); 
	}
}
