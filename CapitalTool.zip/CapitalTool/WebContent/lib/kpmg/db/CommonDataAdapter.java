package kpmg.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class CommonDataAdapter {
	
	public static ResultSet loadHoliday() throws PrepareCallException, SQLException{
 
        String sql= "SELECT * FROM util_holiday";
        PreparedStatement prepStat = Dbutil.prepareStatement(sql);
	      return prepStat.executeQuery(); 

	}
}
