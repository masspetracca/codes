package kpmg.db;

import kpmg.util.*;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

//import com.ibm.db2.jcc.am.*;



public class Dbutil {
	
     public static Connection conn=null;
     public static String ErrMessageSql=""; 

	public static Connection getConnection(){
		return dbConnection.getConnection();
	}  
	
	public static String currencyFormat(BigDecimal n) {
	    return NumberFormat.getCurrencyInstance().format(n);
	}
	
	public static String numberFormat(BigDecimal bd) {
		
		if (bd == null) 
			bd=new BigDecimal(0);
		
		bd = bd.setScale(0, BigDecimal.ROUND_DOWN);

		//return new DecimalFormat("#0.##").format(bd);
		DecimalFormat df = new DecimalFormat("#,##0.###"); //"#,##0.###";  #0.##

		df.setMaximumFractionDigits(2);
		df.setMinimumFractionDigits(0);
		df.setGroupingUsed(true);

		return  df.format(bd);
	}
	
	public static String numberFormat2dec(BigDecimal bd) {
		
		if (bd == null) 
			bd=new BigDecimal(0);
		
		bd = bd.setScale(2, BigDecimal.ROUND_DOWN);

		//return new DecimalFormat("#0.##").format(bd);
		DecimalFormat df = new DecimalFormat("#,##0.###"); //"#,##0.###";  #0.##

		df.setMaximumFractionDigits(2);
		df.setMinimumFractionDigits(0);
		df.setGroupingUsed(true);

		return  df.format(bd);
	}	
	
	public static boolean  isRecordSetEmpty(ResultSet rs) throws SQLException {

		return ! rs.isBeforeFirst();
	}
	 
	 public static ResultSet execute(PreparedStatement prepStat) throws SQLException{
		 prepStat.execute();
		 return  (ResultSet) prepStat.getResultSet();
	 }
	 public static PreparedStatement PrepareCall(String sql) throws PrepareCallException{
		 Connection conn=getConnection();
			try {
				return conn.prepareCall(sql,ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY,ResultSet.HOLD_CURSORS_OVER_COMMIT);
			} catch (SQLException e) {
				 throw new PrepareCallException("errore nella query "+sql+" db2="+e.getMessage());
			}
	 }
	 public static PreparedStatement prepareStatement(String sql) throws PrepareCallException{
		 Connection conn=getConnection();
		 System.out.println("query= "+sql);
			try {
				return conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY,ResultSet.HOLD_CURSORS_OVER_COMMIT);
			} catch (SQLException e) {
				 throw new PrepareCallException("errore nella query "+sql+" db2="+e.getMessage());
			}
	 }
	 

	    public static void importaDati() throws SQLException, PrepareCallException{
            
	    	System.out.println("\nImporta dati \n");
	    	
	    	String sql="CALL RISK_MON.sp_Load_Data_From_DB2_ORDINARIO_FIRST(null)";
            PreparedStatement prepStat = Dbutil.PrepareCall(sql);
           // prepStat.setDate(1, dataprec);  
         //   prepStat.setDate(2, dataprec); 
    	     Dbutil.execute(prepStat); 
    	     
    	     System.out.println(" Importa dati RISK_MON.sp_Load_Data_From_DB2_ORDINARIO_SECOND");
    	     
              sql="CALL RISK_MON.sp_Load_Data_From_DB2_ORDINARIO_SECOND(null)";
              prepStat = Dbutil.PrepareCall(sql);
             Dbutil.execute(prepStat); 
             
             System.out.println(" Importa dati RISK_MON.sp_Load_Data_From_DB2_ORDINARIO_FIRST");
             
              sql="CALL RISK_MON.sp_Load_Data_From_DB2_ORD_Titoli_Margini(null)";
              prepStat = Dbutil.PrepareCall(sql);
             Dbutil.execute(prepStat); 
             
             System.out.println(" Importa dati RISK_MON.sp_Load_Data_From_DB2_ORD_Titoli_Margini");
             
              sql="CALL RISK_MON.sp_Load_Data_From_DB2_ORD_Margini_Iniziali(null)";
              prepStat = Dbutil.PrepareCall(sql);
             Dbutil.execute(prepStat); 
             
             sql="CALL RISK_MON.sp_Load_Data_From_DB2_ORD_Margini_Iniziali(null)";
             prepStat = Dbutil.PrepareCall(sql);
            Dbutil.execute(prepStat);
            
            sql="CALL RISK_MON.sp_Load_Data_From_DB2_STRESS(null)";
            prepStat = Dbutil.PrepareCall(sql);
           Dbutil.execute(prepStat);
           
           sql="CALL RISK_MON.sp_Load_Data_From_DB2_STRESS_Titoli_a_garanzia(null)";
           prepStat = Dbutil.PrepareCall(sql);
           Dbutil.execute(prepStat);
           
           sql="CALL RISK_MON.sp_Load_Data_From_DB2_STRESS_PosDerivati(null)";
           prepStat = Dbutil.PrepareCall(sql);
           Dbutil.execute(prepStat);
           
             
             System.out.println(" Importa dati RISK_MON.sp_Load_Data_From_DB2_ORD_Margini_Iniziali");
	    }
	    public static void loadHoliday(){
	    	 Connection conn=getConnection();
	    	 dateUtil.listHoliday=new ArrayList<String>();
	    	 
	    	Statement stmt = null;
	
	        String query = "SELECT * FROM util_holiday";
	        java.sql.ResultSet rs;
			try {
				stmt = conn.createStatement();
				rs = stmt.executeQuery(query);
		
				while (rs.next()) {
					dateUtil.listHoliday.add(rs.getString(1)+"-"+rs.getString(2));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	   }
	    
	    
	    public static void printSQLException(SQLException ex) {

	        for (Throwable e : ex) {
	            if (e instanceof SQLException) {
	                if (ignoreSQLException(
	                    ((SQLException)e).
	                    getSQLState()) == false) {

	                    e.printStackTrace(System.err);
	                    System.err.println("SQLState: " +
	                        ((SQLException)e).getSQLState());

	                    System.err.println("Error Code: " +
	                        ((SQLException)e).getErrorCode());

	                    System.err.println("Message: " + e.getMessage());

	                    Throwable t = ex.getCause();
	                    while(t != null) {
	                        System.out.println("Cause: " + t);
	                        t = t.getCause();
	                    }
	                }
	            }
	        }
	    }
	    
	    public static boolean ignoreSQLException(String sqlState) {

	        if (sqlState == null) {
	            System.out.println("The SQL state is not defined!");
	            return false;
	        }

	        // X0Y32: Jar file already exists in schema
	        if (sqlState.equalsIgnoreCase("X0Y32"))
	            return true;

	        // 42Y55: Table already exists in schema
	        if (sqlState.equalsIgnoreCase("42Y55"))
	            return true;

	        return false;
	    }
	    
}
