package kpmg.db;

public class PrepareCallException extends Exception {
    public PrepareCallException(String message) {
        super(message);
    }
}