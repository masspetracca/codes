package kpmg.db;

import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import java.sql.Connection;
import java.sql.ResultSet;

public class dbConnection {
	private static Connection conn;
	
	public static void main(String[] args) throws PrepareCallException, SQLException  {
		 System.out.println("Avvio Main WebCrLib!");


	}
	public static  Connection getConnection() {
		return getConnectionLocal();
	//	return getConnectionServer();
	}
	
	  public  static Connection getConnectionServer() {
	    	Context ctx=null;
	    	
	 
		//	if (conn!=null) return conn;
	    	 try { 
	    		  ctx = new InitialContext();
	    	 
	    	 }
	    	 catch (Exception ex){
	    	       System.out.print("Check classpath. Cannot load InitialContext : "+ex.getMessage() );
	    	    }
	    	 	
	    	 try { 
	    		 javax.sql.DataSource dataSource = (DataSource) ctx.lookup("db2webc"); //java:comp/env/jdbc/db2webc
	    		 conn = dataSource.getConnection();
	    	 } catch (NamingException ex){
	    	       System.out.print("Check classpath. Cannot load db driver: "+ex.getMessage() );
	   	    }
	    	 catch (Exception ex){
	  	       System.out.print("Check classpath. Cannot load db driver: "+ex.getMessage() );
	 	    }
			return conn;		

	    }
	  
	 public static  Connection getConnectionLocal() {
		 Connection result = null;
		//  String DB_CONN_STRING = "jdbc:db2://10.0.10.245:50000/KPMGDB:currentSchema=RISK_MON;allowNextOnExhaustedResultSet=1;resultSetHoldability=1;queryCloseImplicit=2;";//allowNextOnExhaustedResultSet=1;";// +(com.ibm.db2.jcc.DB2BaseDataSource.YES) + ";";
		  String DB_CONN_STRING = "jdbc:as400://10.0.10.245;naming=system;errors=full;libraries=CAP_LIQ;date format=iso;"; // date format=iso;"; date format=iso;

		   // String DRIVER_CLASS_NAME ="com.ibm.db2.jcc.DB2Driver";// "COM.ibm.db2.jdbc.app.DB2Driver"; //"com.ibm.db2.jcc.DB2Driver";  COM.ibm.db2.jdbc.app.DB2Driver
		  String DRIVER_CLASS_NAME ="com.ibm.as400.access.AS400JDBCDriver";
		   String USER_NAME = "KPMGDB";
		    String PASSWORD = "kpmg1";

		    
		    try {
		      Class.forName(DRIVER_CLASS_NAME).newInstance();
		    }
		    catch (Exception ex){
		       System.out.print("Check classpath. Cannot load db driver: " + DRIVER_CLASS_NAME);
		       ex.printStackTrace();
		    }
		    
		      try {
				result = (Connection) DriverManager.getConnection(DB_CONN_STRING,USER_NAME,PASSWORD);
		        result.setHoldability(ResultSet.HOLD_CURSORS_OVER_COMMIT);
		        System.out.println("Connessionje al database avvenuta con successo");
			    //  result.setAutoCommit(false);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		    return result; 
		  }
}
