/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kpmg.db;

/**
 *
 * @author etto
 */

// data iniz estraz e fine estraz 


public class sqldef {
	
	public static String Q_LOAD_PARAMGROUP_BY_TITLE = "select * from PARAMGRUPPI where TITOLO = 'NOMEPARAMGROUP'";
		
	public static String Q_LOAD_FIELDS_PARAM_GROUP = "select * from Param where ID_PG = ID_PARAM_GROUP ORDER BY ORD";
	
	public static String Q_SEARCH_MAX = "select MAX(CAMPOMAX) AS CAMPOMAX from NOMETABELLA  where CAMPOCOND <= date('VALORECOND')";
	
	public static String Q_LOAD_PARAM_GROUP = "select  * from NOMETABELLA where CAMPOCOND = date('VALORECOND')";

	public static String Q_LOAD_PARAM_BY_CONDITION = "SELECT * FROM ORD_Report WHERE aram_input<>0"; 
    
}
		
		
		
		
		
		
		
		
		