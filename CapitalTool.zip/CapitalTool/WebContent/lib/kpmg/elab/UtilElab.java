package kpmg.elab;

import java.math.BigDecimal;

public class UtilElab {
	public static BigDecimal getRsBigDecimal(BigDecimal val,BigDecimal defVal){
		
		if (val==null) return defVal;
		return val;
	}
}
