package kpmg;

import java.lang.reflect.Field;
import kpmg.Param.*;
public class NameParInp extends DataObject{
	

		
		public  class gruppo1 extends DataObject {
				
				public  String par1="par1";
				public  String par2="par1";
			}
		public  class gruppo2 extends DataObject {
			
			public  String par1="par1";
			public  String par2="par1";
		}
		

		
}


