package kpmg.Param;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataObject {
	  
	   	   
	 /*   public DataObject() {  
	        try {  
	            for(Field f : Types.class.getSuperclass().getFields())  
	            	fields.put(f.getName(), f.getInt(null));  
	        } catch (SecurityException e) {  
	            throw new RuntimeException("unexpected", e);  
	        } catch (IllegalAccessException e) {  
	            throw new RuntimeException("unexpected", e);  
	        }  
	    }  
	   
	    public static int getField(String fieldName) {return fields.get(fieldName);}  
	   
	    public static void init() {  
	        String[] fields = {"ARRAY", "BIGINT", "BINARY", "BIT", "BLOB", "BOOLEAN", "CHAR",  
	            "CLOB", "DATALINK", "DATE", "DECIMAL", "DISTINCT", "DOUBLE", "FLOAT", "INTEGER",  
	            "JAVA_OBJECT", "LONGVARBINARY", "LONGVARCHAR", "NULL", "NUMERIC", "OTHER", "REAL",  
	            "REF", "SMALLINT", "STRUCT", "TIME", "TIMESTAMP", "TINYINT", "VARBINARY", "VARCHAR"};  
	        DataObject app = new DataObject();  
	        for(String f : fields)  
	            System.out.format("%13s=%4d%n", f, app.getField(f));  
	    }
	   */
	   
	/*private static int addToListField(List<Object> list, List<Object> listvalue){
		if ( Class.e Object.class==Class.class)
			
		for (Object obj : listvalue) {
			String name="";
			if (obj instanceof Class)
				name=((Class) obj).getName();
			if (obj instanceof Class)
				name=((Class) obj).getName();
			 list.add(obj);
			 System.out.format("type is %s ",  .getName());
			 

		 }
	}*/
	   

	
	
	


}
