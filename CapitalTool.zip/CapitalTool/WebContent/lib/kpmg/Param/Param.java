package kpmg.Param;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import kpmg.util.dataInput;
import kpmg.util.dateUtil;

import org.json.simple.JSONArray;
import org.json.simple.JSONValue;

public class Param {
	public static Map<String, Param> fields = new HashMap<String, Param>();  
	public int id;
	public int tipo;
	public String Titolo;
	public Object parent;
	public String format;
	public String formatDivInput;
	public String formatDivLabel;
	public dataInput dtInput;
	public String fieldName;
	public String inputName;
	public Object valore;
	
	
	public Param(JSONArray data){
		int count = data.size();
		for(int i=0;i<count;i++)  {
			 System.out.println("Param parm ="+data.get(i));
		}
	}
	public Param(){
		this.Titolo = "";
		this.tipo = 0;
		this.parent = 0;
		this.format = "";
		this.formatDivInput = "";
		this.formatDivLabel = "";
		this.fieldName = "";
		this.inputName = "";
		this.valore = "";
		
	}
	
	public void decode()  { 
	  String s="[\"gruppo1\",\"gruppo2\",]";
	  Object obj=JSONValue.parse(s);
	  JSONArray array=(JSONArray)obj;
	  System.out.println("======the 2nd element of array======");
	  System.out.println(array.get(1));
	}
	
	public String writeParam()
	{
		String stringa = "";

		String sValore = "";
    		 switch (this.tipo) 
    		 {
    		 	case 0:
    		 		sValore = (String)this.valore;
    			 break;
    		 	case 1:  // Data
	            	 if(this.valore != null && this.valore.equals("") == false)
	            	 {		
	            		 sValore= dateUtil.DateToItStringDate((java.util.Date) this.valore);
	            	 }
	            	 else
	            	 {
	            		 sValore = (String)this.valore;
	            	 }
            	 break;
    		 	case 3:
    		 		sValore = (String)this.valore.toString();
    		 	break;
    		 	
	             default: // Stringa
	            	 sValore = (String)this.valore;
                 break;
    		 }
    		 if(this.tipo != 2)
    		 {
    			 	stringa = "<div class='" + this.formatDivLabel + "'>" + this.Titolo + ":</div>" +
					" <div class='" + this.formatDivInput + "'>" +
					" <input onclick='funzione(this.id, " + this.tipo + ");' type='text' tipo=" + this.tipo + " class='" + this.format.trim() + "' id='" + this.inputName.trim() + "' name='" + this.inputName.trim() + "' value='" + sValore + "'>" +
					" </div>";
    		 }
    		 else
    		 {
    				stringa = "<div class='" + this.formatDivLabel + "'>" + this.Titolo + ":</div>" +
    				" <div class='" + this.formatDivInput + "'>";
    				for(int i = 0; i<6; i++)
    				{
    					stringa += " <input onclick='funzione(this.id, " + this.tipo + ");' type='text' tipo=" + this.tipo + " class='" + this.format.trim() + "' id='" + this.inputName.trim() + "' name='" + this.inputName.trim() + "' value='" + sValore + "'>";
    				}
    				stringa += " </div>";   			 
    		 }
    		 
		return stringa;
	}
}
