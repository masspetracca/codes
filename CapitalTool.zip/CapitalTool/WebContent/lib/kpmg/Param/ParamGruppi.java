package kpmg.Param;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONValue;

import kpmg.db.Dbutil;
import kpmg.db.PrepareCallException;
import kpmg.db.sqldef;
import kpmg.util.dataInput;
import kpmg.util.dateUtil;


public  class ParamGruppi extends DataObject {
	
//	public ParamGruppo gruppo1;
	public int id_pg;
	public JSONArray gruppi=null;
	public String Titolo;
	public String Descrizione;
	public String TableName;
	public List<Param> parametri = new ArrayList<Param>();
	
	public ParamGruppi(){
		//gruppo1=new ParamGruppo();
		//loadFromFile();
	
		
	}
	
	   public JSONArray decode(String str)  { 
		   
		   Object obj=JSONValue.parse(str);
			  
		   return (JSONArray)obj; 
		// String s="[[\"gruppo1\",\"tit gruppo1\",[[\"param1\",\"int\",\"param 1\"],[\"param1\",\"int\",\"param 1\"]]  ]]";
		 // String s="[\"gruppo1\",\"tit gruppo1\",]";
		//   String s="[[1,2],[3,4],[5,6]]";
	/*	 Object obj=null; 
		  obj=JSONValue.parse(str);
		  this.gruppi=(JSONArray)obj; 
		  int count = this.gruppi.size();
			for(int i=0;i<count;i++)  {
				obj=gruppi.get(i);
				JSONArray gruppo=(JSONArray)obj;
				
				this.listGruppi.add(new ParamGruppo(gruppo)); 
				System.out.println(gruppo);
				
			}
*/

		}
	   
	   public int loadFromFile(String nomeFile) throws IOException{
			BufferedReader br = null;
			System.out.println("ParamGruppi.LoadFromFile file="+nomeFile);
			String sCurrentLine;

			br = new BufferedReader(new FileReader(nomeFile));
			
			while ((sCurrentLine = br.readLine().trim()) != null) {
				if (sCurrentLine.compareTo("")!=0){ // kegge le righe 
					sCurrentLine="[\"gruppo1\",\"tit gruppo1\",[[\"g1.param1\",\"int\",\" g1 param 1\"],[\"g1.param2\",\"int\",\"param 2\"]]]";
					JSONArray gruppo=decode(sCurrentLine);	
					this.parametri.add(new Param(gruppo)); 
				}
			}
			if (br != null)br.close();
			System.out.println("Lista Gruppi="+parametri);
			
			return 0;
	   }
	   
	   public ParamGruppi LoadFromDb(String nomeParamGroup) throws PrepareCallException, SQLException
	   {
	        String sqlPG= sqldef.Q_LOAD_PARAMGROUP_BY_TITLE;
	        
	        sqlPG = sqlPG.replace("NOMEPARAMGROUP", nomeParamGroup);
	         
	        PreparedStatement prepStat = Dbutil.prepareStatement(sqlPG);

		    ResultSet rsParamGroup = prepStat.executeQuery(); 
	//	    ParamGruppi Parametrogruppo = new ParamGruppi();
		    
		    while(rsParamGroup.next())
		    {
		    	this.id_pg = rsParamGroup.getInt("ID_PG");
		    	this.Titolo = rsParamGroup.getString("TITOLO");
		    	this.Descrizione = rsParamGroup.getString("DESCRIZIONE");
		    	this.TableName = rsParamGroup.getString("TABLENAME");
		    }
		    
	        String sqlP= sqldef.Q_LOAD_FIELDS_PARAM_GROUP;
	        sqlP = sqlP.replace("ID_PARAM_GROUP",Integer.toString(this.id_pg));
	        PreparedStatement prepStatParam = Dbutil.prepareStatement(sqlP);
	        
	        ResultSet rsParam = prepStatParam.executeQuery(); 
	        
		    while(rsParam.next())
		    {
		    	Param tmpParam = new Param();
		    	tmpParam.id = rsParam.getInt("ID_P");
		    	tmpParam.Titolo = rsParam.getString("TITOLO");
		    	tmpParam.parent = rsParam.getInt("ID_PG");
		    	tmpParam.fieldName = rsParam.getString("FIELDNAME");
		    	tmpParam.inputName = rsParam.getString("INPUTNAME");
		    	tmpParam.tipo = rsParam.getInt("TIPO");
		    	tmpParam.format = rsParam.getString("FORMAT");
		    	tmpParam.formatDivInput = rsParam.getString("FORMATDIVINPUT");
		    	tmpParam.formatDivLabel = rsParam.getString("FORMATDIVLABEL");
		    	
		    	this.parametri.add(tmpParam); 	
		    }
	    	System.out.println("titolo param group:" + this.Titolo);

		   return this;
	   }
	   
	   public int WriteParamGroupToDb() throws PrepareCallException, SQLException
	   {
	        String sqlInsParam="insert into NOMETABELLA ";
	        
	        String campi = "";
	        String valori = "";
	        int i = 0;
	    	for(Param p : this.parametri)
	    	{
	    		i = i+1;
	    			
	    		campi += p.fieldName + " ";
	    		
	    		 switch (p.tipo) 
	    		 {
	    		 	 case 0:
	    		 		valori += "'" + p.valore.toString() + "' ";
	    			 break;
		             case 1:           	 
            			 valori += "DATE('" + dateUtil.DateToSqlStringDate((Date)p.valore) + "') ";
		             break;
		             case 3:  
		            	 valori += "" + p.valore + " ";
		             break;	
		             case 4:  
		            	 valori += "" + p.valore + " ";
		             break;		             
		             default: 
		            	 valori += "'" + p.valore.toString().trim() + "' ";
                     break;

	    		 }

	    		
	    		if(i < this.parametri.size())
	    		{
	    			campi += ",";
	    			valori += ",";
	    		}
	    	}
	    	sqlInsParam += "(" + campi + ")" + " VALUES (" + valori + ")";
	    	
	    	sqlInsParam = sqlInsParam.replace("NOMETABELLA",this.TableName);
	    	
	        PreparedStatement prepStatParam = Dbutil.prepareStatement(sqlInsParam);        
	        return  prepStatParam.executeUpdate();
	       
	   }
	   
	   public int ReadParamGroupFromRequest(HttpServletRequest request)
	   {
	    	for(Param p : this.parametri)
	    	{
	    		 switch (p.tipo) 
	    		 {
	    		 	case 0:
	    		 		p.valore = (String)request.getParameter(p.inputName);
	    			 break;
		             case 1:  
//		            	 System.out.println("Provo ad assegnare la data " + valore);
		            	  dataInput dtIn = new dataInput(request.getParameter(p.inputName).trim(), "");
		            	 			     	        
		            	 p.valore = dtIn.asDate();
		             break;
		             case 3:
		            	 BigDecimal bd= new BigDecimal (request.getParameter(p.inputName)); 
		            	 p.valore = bd;
		            	 break;
		             case 4:
		            	 p.valore = Integer.parseInt(request.getParameter(p.inputName));
		            	 break;
		             default: 
		            	 p.valore = request.getParameter(p.inputName);            	 
                     break;
	    		 }
	    		System.out.println("Leggo da Request form inputName=" + p.inputName + " valore = " + request.getParameter(p.inputName));
	    	}
		   return 0;	   
	   }
	   
	   public int ReadParamGroupFromDbByLastDate(String campomax, String campocond, String valorecond) throws PrepareCallException, SQLException, ParseException	
	   {
		   System.out.println("Valore condizione = " + valorecond);
	        String sqlLoadMax=sqldef.Q_SEARCH_MAX;
	        
	        dataInput dtIn = new dataInput(valorecond, "");
	        // dtIn.asDate();
	        
	        sqlLoadMax = sqlLoadMax.replace("NOMETABELLA", this.TableName);
	        sqlLoadMax = sqlLoadMax.replace("CAMPOMAX", campomax);	         
	        sqlLoadMax = sqlLoadMax.replace("CAMPOCOND", campocond);	
	        sqlLoadMax = sqlLoadMax.replace("VALORECOND", dateUtil.DateToSqlStringDate(dtIn.asDate()));
	        
	        
	        PreparedStatement prepStat = Dbutil.prepareStatement(sqlLoadMax);

		    ResultSet rsMax = prepStat.executeQuery(); 
		    
		    while(rsMax.next())
		    {
		    	String max = rsMax.getString(campomax);
		    	
		    	System.out.println("Massima data trovata: " + max);
		    	if (max != null)
		    	{
			    	String sqlLoadParamGroup=sqldef.Q_LOAD_PARAM_GROUP;
			    	sqlLoadParamGroup = sqlLoadParamGroup.replace("NOMETABELLA", this.TableName);	         
			    	sqlLoadParamGroup = sqlLoadParamGroup.replace("CAMPOCOND", campocond);	
			    	sqlLoadParamGroup = sqlLoadParamGroup.replace("VALORECOND", max);
			        
			        PreparedStatement prepStatPG = Dbutil.prepareStatement(sqlLoadParamGroup);
	
				    ResultSet rsPG = prepStatPG.executeQuery(); 
				    ResultSetMetaData rsm = rsPG.getMetaData (); 
	    
				    int i = 0;
				    while(rsPG.next())
				    {
				    	i = i+1;
				    	System.out.println("RIGA: " + i);
					    for (int x = 1; x <= rsm.getColumnCount (); x ++)
					    { 
					    	System.out.println("leggo valore della colonna " + rsm.getColumnName (x) + " = " + rsPG.getString(rsm.getColumnName(x) ));
					    	this.setParamValueFromDb( rsm.getColumnName(x), rsPG.getString(rsm.getColumnName(x)));
					    }
				    }
		    	}
		    }
		   return 0;
	   }
	   
	   public int setParamValue(String inputnameparametro, String valore) throws ParseException
	   {
	    	for(Param p : this.parametri)
	    	{
	    	//	System.out.println("Confronto: " + p.inputName + " con " + inputnameparametro);
	    		if(p.inputName.equals(inputnameparametro))
	    		{
		    		 switch (p.tipo) 
		    		 {
		    		 	case 0:
		    		 		p.valore = (String)valore;
		    			 break;
			             case 1:  
	//		            	 System.out.println("Provo ad assegnare la data " + valore);
			            	  dataInput dtIn = new dataInput(valore.trim(), "");
			            	 			     	        
			            	 p.valore = dtIn.asDate();
			             break;
			             case 3:
			            	 BigDecimal bd= new BigDecimal (valore); 
			            	 p.valore = bd;
			            	 break;
			             case 4:
			            	 p.valore = Integer.parseInt(valore);
			            	 break;
			             default: 
			            	 p.valore = valore;            	 
	                     break;
		    		 }
		    		 
		    		 System.out.println("Assegno valore a parametro inputName " + inputnameparametro + " il valore: " + p.valore);
	    		}
	    	}
	    	
		   return 0;
	   }

	   public int setParamValueFromDb(String fieldtnameparametro, String valore) throws ParseException
	   {
	    	for(Param p : this.parametri)
	    	{

	    		if(p.fieldName.equals(fieldtnameparametro))
	    		{
		    		 switch (p.tipo) 
		    		 {
		    		 	case 0:
		    		 		p.valore = valore;
		    			 break;
		    		 	case 1:  // Data
			            	 if(valore != null && valore.equals("") == false)
			            	 {		
			            		 System.out.println("Ho letto la seguente data da DB: " + valore);;
			            		 p.valore = dateUtil.StringDateToDate(valore);
			            	 }
			            	 else
			            	 {
			            		 p.valore = valore;
			            	 }
		            	 break;
		    		 	case 3:
			            	 BigDecimal bd= new BigDecimal (valore); 
			            	 p.valore = bd;
			            	 break;
			             case 4:
			            	 p.valore = Integer.parseInt(valore);
			             break;
			             default: // Stringa
			            	  p.valore = valore;;
	                     break;
		    		 }
			    	 
		    		 System.out.println("Assegno valore a parametro fieldName " + fieldtnameparametro + " il valore: " + p.valore.toString());
		    			
	    		}
	    	}
	    	
		   return 0;
	   }
	   
	   public String getParamValue(String inputnameparametro) throws ParseException
	   {
		   String stringa = "";
	    	for(Param p : this.parametri)
	    	{
	    	//	System.out.println("Confronto: " + p.inputName + " con " + inputnameparametro);
	    		if(p.inputName.equals(inputnameparametro))
	    		{
		    		 switch (p.tipo) 
		    		 {
			             case 1:  // Data
			            	 if(p.valore.toString() != null && p.valore.toString().equals("") == false)
			            	 {		            		          		 
			            		 stringa = dateUtil.DateToItStringDate((Date)p.valore);
			            	 }
			            	 else
			            	 {
			            		 stringa = p.valore.toString();
			            	 }
			             break;
			             default: // Stringa
			            	 stringa = p.valore.toString();
	                     break;
		    		 }
		    		 System.out.println("Restituisco valore a parametro inputname " + inputnameparametro + " il valore: " + stringa);
	    			
	    		}
	    	}
	    	return stringa;
		   
	   }
}
