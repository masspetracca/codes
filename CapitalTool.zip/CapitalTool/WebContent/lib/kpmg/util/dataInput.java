package kpmg.util;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;

public class dataInput {
  	private String strVal=null;
	private String fieldName="";
	public  String msg="";
	//public  boolean error=false; 
	
	public  dataInput(String val,String afieldName){
	
		fieldName=afieldName;
		if(null!=val && val.length()>0) strVal=val;
		else msg="Il campo <b>"+fieldName+"</b> non può essere vuoto: <br />";
	}
	public boolean asCheckBoolean(){
		msg=""; // annulla il msg se popolato perchè valore vuoto
		if (null!=strVal) return true;
		else return false;
	}
	public int asInt(){
		if (msg.length()>0) return 0;
		  try {
  	        return Integer.parseInt(strVal);
  	    } catch (NumberFormatException e) {
  	    	msg="Il valore del campo <b>"+fieldName+"</b> deve essere numerico <br />";
  	        return 0;
  	    }
	}
	public String asString(){
		return strVal;
	}
	public Date asDate(){
		if (msg.length()>0) return null;
  	  strVal=strVal.replace("/", "-"); //
	      try {

	    	  return dateUtil.sqlDateToutilDate(strVal);
			} catch (ParseException e) {
				System.out.println("data Parse Exception ="+strVal+"=");
				msg="Il valore del campo <b>"+fieldName+"</b> deve essere di tipo data giorno/mese/anno <br />";
				return null;
			}catch(IllegalArgumentException e) {
				System.out.println("data Parse Exception ="+strVal);
				msg="Il valore del campo <b>"+fieldName+"</b> deve essere di tipo data giorno/mese/anno <br />";
				return null;
		   	}	    	 
	}
	public BigDecimal asDecimal(){
		BigDecimal bd= new BigDecimal(0);
		if (msg.length()>0) return bd;
		strVal=strVal.replace(",", ".");
		try {
			return new BigDecimal(strVal);
			 
		} catch (NumberFormatException e) {
			msg="Il valore del campo <b>"+fieldName+"</b> deve essere numerico <br />";
  	        return bd;
		}
	}
}




