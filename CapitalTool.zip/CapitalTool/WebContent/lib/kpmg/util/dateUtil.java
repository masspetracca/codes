package kpmg.util;

import java.text.*;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import kpmg.db.Dbutil;

public class dateUtil{
	private static final DateFormat utilDateFormatter = new SimpleDateFormat("dd/MM/yyyy");
	private static final DateFormat sqlDateFormatter = new SimpleDateFormat("yyyy-MM-dd");
	public static List<String> listHoliday=null;
	
	
	
	public static String DateToSqlStringDate(Date uDate)
	{
		//return java.sql.Date.valueOf(sqlDateFormatter.format(uDate));
		return sqlDateFormatter.format(uDate);
	}
	
	public static String DateToItStringDate(Date uDate)
	{
		//return java.sql.Date.valueOf(sqlDateFormatter.format(uDate));
		return utilDateFormatter.format(uDate);
	}
	
	public static Date StringDateToDate(String uDate) throws ParseException
	{
		//return (java.util.Date)utilDateFormatter.parse(sDate);	
		return parseDate(uDate,"yyyy-MM-dd",true);
	}
	
	public static Date sqlDateToutilDate(String sDate) throws ParseException
	{
		//return (java.util.Date)utilDateFormatter.parse(sDate);	
		return parseDate(sDate,"dd-MM-yyyy",true);
	}
	
	public static  Date parseDate(String maybeDate, String format, boolean lenient) throws ParseException {
	    Date date = null;

	    // test date string matches format structure using regex
	    // - weed out illegal characters and enforce 4-digit year
	    // - create the regex based on the local format string
	    String reFormat = Pattern.compile("d+|M+").matcher(Matcher.quoteReplacement(format)).replaceAll("\\\\d{1,2}");
	    reFormat = Pattern.compile("y+").matcher(reFormat).replaceAll("\\\\d{4}");
	    if ( Pattern.compile(reFormat).matcher(maybeDate).matches() ) {

	      // date string matches format structure, 
	      // - now test it can be converted to a valid date
	      SimpleDateFormat sdf =  new SimpleDateFormat(format); //(SimpleDateFormat)DateFormat.getDateInstance();
	      sdf.applyPattern(format);
	      sdf.setLenient(lenient);
	      try { date = sdf.parse(maybeDate); } catch (ParseException e) { }
	    } 
	    return date;
	  } 
	
	public static java.sql.Date addBusinessDay(final java.sql.Date sqldata, final Integer numBusinessDays) {
		Date data=new java.util.Date(sqldata.getTime());
		Calendar cal=dateToCalendar(data);
	    cal=addBusinessDayCal(cal,numBusinessDays);
	    Date dt=cal.getTime();
		return new java.sql.Date(  dt.getTime());
	}
	
	public static Calendar addBusinessDayCal(final Calendar cal, final int anumDays)
	{	
		Integer numBusinessDays= new Integer(anumDays);
	    if (cal == null )
	    {
	        return cal;
	    }
	    final int numDays = Math.abs(numBusinessDays.intValue());
	    final int dateAddition = numBusinessDays.intValue() < 0 ? -1 : 1;//if numBusinessDays is negative
	    int businessDayCount = 0;
	    boolean isfirstLoop=true;
	    while (businessDayCount < numDays)
	    {
	    		 if (!(numBusinessDays.intValue()==0 ))
	    			cal.add(Calendar.DATE, dateAddition);
	    			
	    /* if (numBusinessDays.intValue()<0) {
	    	if (!(numBusinessDays.intValue()<=0 && isfirstLoop))
	    		cal.add(Calendar.DATE, dateAddition);
	    } else if (!(numBusinessDays.intValue()>=0 && isfirstLoop))
	    		cal.add(Calendar.DATE, dateAddition); */

	    	
	       isfirstLoop=false;
	        //check weekend
	        if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)
	        {
	            continue;//adds another day
	        }

	        //check holiday
	        if (isHoliday(cal))//implement isHoliday yourself
	        {
	            continue;//adds another day
	        }

	        businessDayCount++;
	    }
	    return cal;
	}
	
	private static boolean isHoliday(final Calendar cal){
		  if (listHoliday == null) { 
			  Dbutil.loadHoliday();
			  if (listHoliday == null)
		        throw new IllegalArgumentException(" listHoliday must not be null");  

		    } 
		
		 Integer year= new Integer( cal.get(Calendar.YEAR)); ;
		
		Calendar adt=Calendar.getInstance();
		 adt= Holidays.EasterMonday( cal.get(Calendar.YEAR));
		if (isSameDay(cal, adt)) return true;
		adt=Holidays.GoodFridayObserved(cal.get(Calendar.YEAR));
		if (isSameDay(cal, adt)) return true;
		
		if (cal.get(Calendar.DAY_OF_YEAR) ==1) return true;
		if (cal.get(Calendar.DAY_OF_YEAR) ==359 || cal.get(Calendar.DAY_OF_YEAR) ==360) return true; // natale 
		
		String syear=Integer.toString(year);
		Calendar tmpCal=Calendar.getInstance();
		for (String s : listHoliday){
			try {
				tmpCal=dateToCalendar(dateUtil.sqlDateToutilDate(s+"-"+syear));
			} catch (ParseException ex) {
				 Logger.getLogger(dateUtil.class.getName()).log(Level.SEVERE, "my msg", ex);
				 System.out.print("errore conversione data in isHoliday from db : " + ex.getMessage());
				 return false;
			}
			if (isSameDay(cal,tmpCal)) return true;
		}
		
		return false;
	}
	
	public static Calendar dateToCalendar(Date date){
		// convert back  Date date = cal.getTime();
		Calendar cal=Calendar.getInstance();
		DateFormat format=new SimpleDateFormat("yyyy/mm/dd");
		format.format(date);
		cal= format.getCalendar();
		return cal;  
	}
	
	public static java.sql.Date  addMonth(java.sql.Date sqldate,int numMounth){
		Calendar cal = Calendar.getInstance(); 
		java.util.Date today=new Date();
		if (sqldate==null) {
			sqldate=new java.sql.Date(today.getTime());
		} 
		Date data=new java.util.Date(sqldate.getTime());
    	cal.setTime(data); 
    	cal.add(Calendar.MONTH, numMounth); 
    	Date dt = cal.getTime();
		return new java.sql.Date(dt.getTime()) ;
	}
	
	public static boolean isSameDay(Calendar cal1, Calendar cal2) {
	    if (cal1 == null || cal2 == null)
	        return false;
	    return (cal1.get(Calendar.ERA) == cal2.get(Calendar.ERA)
	            && cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) 
	            && cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR));
	}

}
