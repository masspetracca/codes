package kpmg;

import java.io.IOException;

import kpmg.Param.ParamGruppi;

//import webCrLib.Param.ParamGruppi.ParamGruppo;

public class Main {

	public static int levelDebug = 3;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println( " ******************************** ");
		System.out.println( "\n WebCr Start \n");
		System.out.println( " ******************************** ");
		
	//	DataObject.getListClasses(NameParInp.class);
	//	DataObject.getListFields(NameParInp.gruppo1.class);
		//Field[] list=ParIn.getListFields();
		//Map<String, Integer> gruppo1fields=NameParInp.gruppo1.fields;
		
		ParamGruppi par=new ParamGruppi();
		try {
			par.loadFromFile("C:\\KPMG1\\IBM\rationalsdp\\ccg2\\WebcCr\\WebContent\\param.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void debugVal(int level,String msg,String val){
		if (levelDebug>=level && levelDebug!=0) System.out.println(msg+"="+val);
	}
	
	public static String  showParamStruct(){
	/*	ParamInputGruppi gruppi =new ParamInputGruppi();
		
		List<Field> fields= gruppi.getListFields();
		 for (Field field : fields) {
			 
			 System.out.format("name %s ", field.getName());
			 

		 }*/
		 return "";
	}

}
