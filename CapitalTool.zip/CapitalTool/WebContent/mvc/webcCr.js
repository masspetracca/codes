
 
 $( document ).ready(function() {
	
        $('#Calendario_ParamDefault').datepicker(
        		{
        			
        	    }
        	).on('changeDate', function(){
        		  $('.datepicker').hide();
        	}); 

 });
 
function funzione(id, tipo)
{
//	alert("id ="+ id + " tipo =" + tipo);
	if(tipo == 1)
	{
		$('#'+id).datepicker();
	    if ($('.datepicker').style !=null) $('.datepicker').style.height = '220px';
	    
	}

}

 function currentMenu(){
	  var url = window.location;
	  $('ul.nav a[href="'+ url +'"]').parent("li").addClass('open');       
	  $('ul.nav a[href="'+ url +'"]').parent("li").addClass('current');
	  $("ul#top-menu li.menu-item.current").addClass("open");
 }
 
	function dateToStrTimeStamp(temp) {
		   
	    var dateStr = temp.getFullYear().toString() + 
	                  temp.getMonth().toString() + 
	                  temp.getDate().toString();
	
	    return dateStr;
	}
	
	function gestParametri(){
		if (document.getElementById('gestParametri').style.display=='block'){
			document.getElementById('gestParametri').style.display='none';
			document.getElementById('span_puls_Apri_gestParametri').innerHTML='Apri';
		}
		else {
			document.getElementById('gestParametri').style.display='block';
			document.getElementById('span_puls_Apri_gestParametri').innerHTML='Chiudi';
		}
	} 
	
	function formSubmit(str_op){
		document.getElementById(str_op).submit();
		
	}
	function closeOpenGroup(str){
		if (document.getElementById(str).style.display=='block')
			document.getElementById(str).style.display='none';
		else document.getElementById(str).style.display='block';
	}
