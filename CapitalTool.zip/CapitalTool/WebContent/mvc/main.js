//angular.module('webc');

//alert('fff');

function navMenuCtrl($scope, $location) 
{ 
    $scope.isActive = function (viewLocation) { 
       // return viewLocation === $location.path();
       var z = location.pathname.substring(location.pathname.lastIndexOf('/')+1);

         var s=false; //alert('fff');
        if(z.indexOf(viewLocation) != -1) s=true;
        return s;
    };
}