package it.ccg.qtejb.server.ldap;

import it.ccg.qtejb.server.logengine.LoggerFactory;

import javax.ejb.Local;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class User
 */
@Stateless
@Local(LDAPUserBeanLocal.class)
public class LDAPUserBean implements LDAPUserBeanLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
    /**
     * Default constructor. 
     */
    public LDAPUserBean() {
        // TODO Auto-generated constructor stub
    	
    }
    
    
	@Override
	public LDAPUserDTO getLDAPUserByUID(String uid) throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		LDAPUserDTO user = manager.getUserByUID(uid);
		
		
		return user;
	}
	
	
}
