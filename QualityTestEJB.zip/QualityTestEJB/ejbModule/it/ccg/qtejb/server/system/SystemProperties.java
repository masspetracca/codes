package it.ccg.qtejb.server.system;


import it.ccg.qtejb.server.logengine.LoggerFactory;
import it.ccg.qtejb.server.logengine.StandardLogMessage;

import java.io.FileInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class SystemProperties {
	

	private static final String PROPERTIES_FILE_ABS_PATH = System.getProperty("user.install.root") + "/properties/qt.properties";
	
	private static Properties properties = null;
	
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	
	public static void loadSystemProperties() throws Exception {
		
		// load properties from file
		properties = new Properties();
		properties.load(new FileInputStream(PROPERTIES_FILE_ABS_PATH));
		
		// load other system properties
		properties.put("user.install.root", System.getProperty("user.install.root"));
		
		
		logger.info(new StandardLogMessage("QualityTest system properties successfully loaded from file: " + PROPERTIES_FILE_ABS_PATH));	
	}
	
	
	public static String getProperty(String propertyName) throws Exception {
		
		if(properties == null) {
			
			loadSystemProperties();
		}
		
		return properties.getProperty(propertyName);
	}
	
	public static Properties getProperties() throws Exception {
		
		if(properties == null) {
			
			loadSystemProperties();
		}
		
		return properties;
	}
    
	
	public static String getPropertiesFileAbsPath() {
		return PROPERTIES_FILE_ABS_PATH;
	}
	
}
