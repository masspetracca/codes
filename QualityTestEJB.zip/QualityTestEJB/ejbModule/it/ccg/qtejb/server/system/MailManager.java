package it.ccg.qtejb.server.system;



import it.ccg.qtejb.server.logengine.ExceptionUtil;
import it.ccg.qtejb.server.logengine.LoggerFactory;
import it.ccg.qtejb.server.logengine.StandardLogMessage;

import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;

public class MailManager {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	private static Properties properties;
	
	private static String MAIL_SENDER;
	private static String MAIL_SENDER_ALIAS;
	private static String MAIL_SMTP_HOST;
	private static int MAIL_SMTP_PORT;
	
	private String[] toMailAddressList;
	private String[] ccMailAddressList;
	
	
	public MailManager() throws Exception {
			
		properties = SystemProperties.getProperties();
		
    	MAIL_SENDER = properties.getProperty("mail.sender");
    	MAIL_SENDER_ALIAS = properties.getProperty("mail.sender.alias");
    	MAIL_SMTP_HOST = properties.getProperty("mail.smtp.host");
    	MAIL_SMTP_PORT = Integer.parseInt(properties.getProperty("mail.smtp.port"));
    	
    	toMailAddressList = (properties.getProperty("mail.to.dev")).split(",");
    	ccMailAddressList = (properties.getProperty("mail.cc")).split(",");
    	
	}
	
	public MailManager(String[] toMailAddressList, String[] ccMailAddressList) throws Exception {
		
		properties = SystemProperties.getProperties();
    	
    	MAIL_SENDER = properties.getProperty("mail.sender");
    	MAIL_SENDER_ALIAS = properties.getProperty("mail.sender.alias");
    	MAIL_SMTP_HOST = properties.getProperty("mail.smtp.host");
    	MAIL_SMTP_PORT = Integer.parseInt(properties.getProperty("mail.smtp.port"));
    	
    	this.toMailAddressList = toMailAddressList != null ? toMailAddressList : new String[0];
    	this.ccMailAddressList = ccMailAddressList != null ? ccMailAddressList : new String[0];
    	
	}
	
	
	public void sendMail(String messageSubject, String messageText, File[] attachments) throws Exception {
		
		try {
			
			List<InternetAddress> toList = new ArrayList<InternetAddress>();
			for(String address : toMailAddressList) {
				if(!address.trim().equalsIgnoreCase("")) {
					toList.add(new InternetAddress(address));
				}
			}
			
			List<InternetAddress> ccList = new ArrayList<InternetAddress>();
			for(String address : ccMailAddressList) {
				if(!address.trim().equalsIgnoreCase("")) {
					ccList.add(new InternetAddress(address));
				}
			}
			
			// check empty recipients list
			if(toList.size() == 0) {
				
				logger.error(new StandardLogMessage("Empty recipients list. Notification mail not sent."));
				
				return;
			}
			
			
			Properties smtpProperties = new Properties();
			smtpProperties.put("mail.smtp.host", MAIL_SMTP_HOST); 
			smtpProperties.put("mail.smtp.port", MAIL_SMTP_PORT);
			
			Session session = Session.getDefaultInstance(smtpProperties);
		
		
			MimeMessage mimeMessage = new MimeMessage(session);
			
			// sender
			mimeMessage.setFrom(new InternetAddress(MAIL_SENDER, MAIL_SENDER_ALIAS));
			
			// to
			InternetAddress[] toArray = new InternetAddress[toList.size()];
			toArray = toList.toArray(toArray);
			mimeMessage.setRecipients(Message.RecipientType.TO, toArray);
			
			// cc
			InternetAddress[] ccArray = new InternetAddress[ccList.size()];
			ccArray = ccList.toArray(ccArray);
			mimeMessage.setRecipients(Message.RecipientType.CC, ccArray);
			
			// object
			mimeMessage.setSubject(messageSubject);
			mimeMessage.setSentDate(new Date(System.currentTimeMillis()));	
			
			
			
			// mail content
			Multipart multipart = new MimeMultipart();
			
				// message
				MimeBodyPart messagePart = new MimeBodyPart();
				messagePart.setContent(this.getHtmlMessage(messageText), "text/html");
	            multipart.addBodyPart(messagePart);
				
				// attachments
				if(attachments != null) {
					for(File attachment : attachments) {
						MimeBodyPart attachmentPart = new MimeBodyPart();
						
						FileDataSource fileDataSource = new FileDataSource(attachment) {
							@Override
				            public String getContentType() {
								
								return "application/octet-stream";
							}
						};
						
						attachmentPart.setDataHandler(new DataHandler(fileDataSource));
						attachmentPart.setFileName(attachment.getName());
						
			            multipart.addBodyPart(attachmentPart);
					}
				}
            
				
				mimeMessage.setContent(multipart);
            
            
            // send mail
            Transport.send(mimeMessage);
            
            
            
            logger.info(new StandardLogMessage("Notification mail correctly sent TO: " + toList.toString() + "; CC: " + ccList.toString()));
            
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
		}
	}
	
	
	private String getHtmlMessage(String message) throws UnknownHostException {
		
		InetAddress localhost = InetAddress.getLocalHost();
		
		String host = "<br><br>Server: <span class=\"host\">" + localhost.getHostAddress() + "</span><br>";
		
		String style = "<style>" +
						"body {" +
							"font-family: Arial;" +
							"font-size: 10pt;" +
						"}" +
						".host {" +
							"font-weight:bold" +
						"}" +
						"</style>";
		
		String messageParagraph = "<p class=\"message\">" + message + "</p>";
		
		String htmlCode = style + messageParagraph + host;
		
		return htmlCode;
	}
	

}
