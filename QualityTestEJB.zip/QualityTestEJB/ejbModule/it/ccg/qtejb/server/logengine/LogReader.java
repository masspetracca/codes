package it.ccg.qtejb.server.logengine;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class LogReader {
	
	private static String LOG_FILE_DIR_ABSOLUTE_PATH;
	
	
	public LogReader(String logDirAbsolutePath) throws Exception {
		
		LOG_FILE_DIR_ABSOLUTE_PATH = logDirAbsolutePath;
	}
	
	
	
	public List<LogLineDTO> getLog(String fileName, String dateTime, Object[] type, String classMethod, String user, String subMessage) throws Exception {
		
		List<LogLineDTO> log = new ArrayList<LogLineDTO>();
		
		// read log file
		String logFileAbsolutePath = LOG_FILE_DIR_ABSOLUTE_PATH + fileName;
		BufferedReader br = new BufferedReader(new FileReader(new File(logFileAbsolutePath)));  
    	
		String line;
    	while((line = br.readLine()) != null) {
    		String[] tempComponents = line.split("\\|");
    		
    		// datetime, type, classmethod, user, message
    		String[] lineComponents = new String[5];
    		
    		if(tempComponents.length < 5) {
    			
    			if(tempComponents.length > 2) {
	    			if(tempComponents[2].startsWith("com.isomorphic")) {
	    				
	    				lineComponents[0] = tempComponents[0];
	    				lineComponents[1] = tempComponents[1];
	    				lineComponents[2] = tempComponents[2];
	    				lineComponents[3] = "isomorphic";
	    				lineComponents[4] = tempComponents[3];
	    				
	    				if(this.matchFilters(lineComponents, dateTime, type, classMethod, user, subMessage)) {
	    					
	    					log.add(new LogLineDTO(lineComponents[0], lineComponents[1], lineComponents[2], lineComponents[3], lineComponents[4]));
	    				}
	    				
	    			}
    			}
    			// invalid log line
    			else {
    				lineComponents[0] = "";
    				lineComponents[1] = "";
    				lineComponents[2] = "";
    				lineComponents[3] = "";
    				lineComponents[4] = line;
    				
        			if(this.matchFilters(lineComponents, dateTime, type, classMethod, user, subMessage)) {
        				
        				log.add(new LogLineDTO(lineComponents[0], lineComponents[1], lineComponents[2], lineComponents[3], lineComponents[4]));
        			}
    			}
    		}
    		else {
    			
    			lineComponents[0] = tempComponents[0];
				lineComponents[1] = tempComponents[1];
				lineComponents[2] = tempComponents[2];
				lineComponents[3] = tempComponents[3];
				lineComponents[4] = tempComponents[4];
    			
    			if(this.matchFilters(lineComponents, dateTime, type, classMethod, user, subMessage)) {
    				
    				log.add(new LogLineDTO(lineComponents[0], lineComponents[1], lineComponents[2], lineComponents[3], lineComponents[4]));
    			}
    		}
	    }
    	
    	br.close();
    	
    	return log;
	}
	
	
	// if you don't want filter to work, set filter fields to null
	private boolean matchFilters(String[] lineComponents, String dateTime, Object[] type, String classMethod, String user, String subMessage) {
		
		boolean result = true;
		
		if(dateTime != null) {
			
			if(!(lineComponents[0].toUpperCase()).contains(dateTime.toUpperCase())) {
				
				result = false;
			}
		}
		if(type != null) {
			
			if(!this.matchLog4JLevel(type, lineComponents[1])) {
				
				result = false;
			}
		}
		if(classMethod != null) {
			
			if(!(lineComponents[2].toUpperCase()).contains(classMethod.toUpperCase())) {
				
				result = false;
			}
		}
		if(user != null) {
			
			if(!(lineComponents[3].toUpperCase()).contains(user.toUpperCase())) {
				
				result = false;
			}
		}
		if(subMessage != null) {
			
			if(!(lineComponents[4].toUpperCase()).contains(subMessage.toUpperCase())) {
				
				result = false;
			}
		}
		
		
		return result;
	}
	
	
	private boolean matchLog4JLevel(Object[] requestedLevels, String lineLevel) {
		
		boolean result = false;
		
		for(Object l : requestedLevels) {
			
			if(lineLevel.equalsIgnoreCase((String)l)) {
				
				result = true;
				
				break;
			}
		}
		
		
		return result;
	}
	
	
}
