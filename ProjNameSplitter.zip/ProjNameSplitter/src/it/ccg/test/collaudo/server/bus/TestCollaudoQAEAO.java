package it.ccg.test.collaudo.server.bus;

public class TestCollaudoQAEAO {

	public TestCollaudoQAEAO(int returnCode) {
		// TODO Auto-generated constructor stub
	}
	public TestCollaudoQAEAO() {
		// TODO Auto-generated constructor stub
	}
	public String getKeyId() {
		return keyId;
	}
	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}
	public String getKeyDate() {
		return keyDate;
	}
	public void setKeyDate(String keyDate) {
		this.keyDate = keyDate;
	}
	public String getKeyProg() {
		return keyProg;
	}
	public void setKeyProg(String keyProgData) {
		this.keyProg = keyProgData;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getNodeName() {
		return nodeName;
	}
	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}
	public String getNodeType() {
		return nodeType;
	}
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}
	public String getNodeValue() {
		return nodeValue;
	}
	public void setNodeValue(String nodeValue) {
		this.nodeValue = nodeValue;
	}
	public String getnodeChild() {
		return nodeChild;
	}
	public void setnodeChild(String nodeChild) {
		this.nodeChild = nodeChild;
	}
	public String getnodeChild1() {
		return nodeChild1;
	}
	public void setnodeChild1(String nodeChild1) {
		this.nodeChild1 = nodeChild1;
	}
	public String getnodeChild2() {
		return nodeChild2;
	}
	public void setnodeChild2(String nodeChild2) {
		this.nodeChild2 = nodeChild2;
	}
	public String getnodeChild3() {
		return nodeChild3;
	}
	public void setnodeChild3(String nodeChild3) {
		this.nodeChild3 = nodeChild3;
	}
	public String getnodeChild4() {
		return nodeChild4;
	}
	public void setnodeChild4(String nodeChild4) {
		this.nodeChild4 = nodeChild4;
	}
	public String getnodeChild5() {
		return nodeChild5;
	}
	public void setnodeChild5(String nodeChild5) {
		this.nodeChild5 = nodeChild5;
	}
	public String getnodeChild6() {
		return nodeChild6;
	}
	public void setnodeChild6(String nodeChild6) {
		this.nodeChild6 = nodeChild6;
	}
	public String getnodeChild7() {
		return nodeChild7;
	}
	public void setnodeChild7(String nodeChild7) {
		this.nodeChild7 = nodeChild7;
	}
	public String getnodeChild8() {
		return nodeChild8;
	}
	public void setnodeChild8(String nodeChild8) {
		this.nodeChild8 = nodeChild8;
	}
	public String getnodeChild9() {
		return nodeChild9;
	}
	public void setnodeChild9(String nodeChild9) {
		this.nodeChild9 = nodeChild9;
	}



	
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String keyId;
	public String keyDate;
	public String keyProg;
	public String status;
	public String nodeName;
	public String nodeType;
	public String nodeValue;
	public String nodeChild;
	public String nodeChild1;
	public String nodeChild2;
	public String nodeChild3;
	public String nodeChild4;
	public String nodeChild5;
	public String nodeChild6;
	public String nodeChild7;
	public String nodeChild8;
	public String nodeChild9;
	public String action;
	public String note;

}
