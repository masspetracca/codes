package it.ccg.test.collaudo.server.bus;

public class ListNamesSplitter {
    static String lastName = "";
	static String firstName= "";

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public  void setFirstName(String firstName) {
		this.firstName = firstName;
	}
}
