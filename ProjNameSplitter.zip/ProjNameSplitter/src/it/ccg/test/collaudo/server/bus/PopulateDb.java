package it.ccg.test.collaudo.server.bus;



import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

public class PopulateDb {
	
	//Table access keys
	private static String kArea = ""; 
	private static String kStato = ""; 
	private static String kFreq ="";
	private static String kTipo ="";

	private static String Tab_col0 = "FNAMELNAME";
	private static String Tab_col1 = "FNAME";
	private static String Tab_col2 = "LNAME";

	
	private static String Tab_col4 = "MASK";
	
	private static String Tab_col5 = "NODENAME";
	private static String Tab_col6 = "NODETYPE";

	private static String Tab_col7 = "CHILDNAME";
	private static String Tab_col8 = "CHILDNAME1";
	private static String Tab_col9 = "CHILDNAME2";
	private static String Tab_col10 = "CHILDNAME3";
	private static String Tab_col11 = "CHILDNAME4";
	private static String Tab_col12 = "CHILDNAME5";
	private static String Tab_col13 = "CHILDNAME6";
	private static String Tab_col14 = "CHILDNAME7";
	private static String Tab_col15 = "CHILDNAME8";
	private static String Tab_col16 = "CHILDNAME9";
	private static String Tab_col38 = "NODEACTION";
	private static String Tab_col39 = "NODEVALUE";
	private static String Tab_col40 = "NOTE";
	private static String Tab_col41 = "";

	private static String TableName = PropertyFiles.getTabName1();

	private static String vcol3 = "";
	private static String vcol4 = "";
	private static String vcol5 = "";

	private static String sdate =null;
	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

//	private static String tabFreq ="";
	private int ctrIns;
//	private int ctrUpd;
 	private int returnCode = 0;
 	private static String sqlUpdate;
//	
//
//	private static Object rs;
	
	PreparedStatement st;
	private String sqlDelete;
	private int ctrDel;


	public PopulateDb(String keyDateData,String keyIdData, String keyProgData, String statusData, String nodeNameData , String nodeTypeData,  String childNameData,  String childNameData1,  String childNameData2,  String childNameData3,  String childNameData4,  String childNameData5,  String childNameData6,  String childNameData7,  String childNameData8,  String childNameData9
			, String actionData, String nodeValueData, String noteData) throws ClassNotFoundException, IOException, SQLException, IllegalAccessException, InstantiationException {
		
		
		//upate table
		       sqlUpdate= 
				"INSERT INTO "+TableName
				+"("
				+""+Tab_col0
				+", "+Tab_col1
				+", "+Tab_col2
				+", "+Tab_col4
				+", "+Tab_col5
				+", "+Tab_col6
				+", "+Tab_col7
				+", "+Tab_col8
				+", "+Tab_col9
				+", "+Tab_col10
				+", "+Tab_col11
				+", "+Tab_col12
				+", "+Tab_col13
				+", "+Tab_col14
				+", "+Tab_col15
				+", "+Tab_col16
				+", "+Tab_col38
				+", "+Tab_col39
				+", "+Tab_col40
				+") VALUES ("
				+"'"+keyDateData+"'" 
				+", '"+keyIdData.substring(0,keyIdData.length() )+"'" 				
				+", '"+keyProgData+"'"
				+", '"+statusData+"'" 
				+", '"+nodeNameData+"'" 
				+", '"+nodeTypeData+"'" 
				+", '"+childNameData+"'" 
				+", '"+childNameData1+"'" 
				+", '"+childNameData2+"'" 
				+", '"+childNameData3+"'" 
				+", '"+childNameData4+"'" 
				+", '"+childNameData5+"'" 
				+", '"+childNameData6+"'" 
				+", '"+childNameData7+"'" 
				+", '"+childNameData8+"'" 
				+", '"+childNameData9+"'" 
				+", '"+actionData+"'" 
				+", '"+nodeValueData+"'" 
				+", '"+noteData+"'" 
				+")"
				;

	    System.out.println(sqlUpdate);		
		++ctrIns;
		//setting upd parameters
		TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 
		upd.setSqlUpdate(sqlUpdate);	
}





	



}


	
		
							
   

