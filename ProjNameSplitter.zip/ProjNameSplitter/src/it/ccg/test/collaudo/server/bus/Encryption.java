package it.ccg.test.collaudo.server.bus;

public class Encryption {

	static private String encr;

	public Encryption() {
		// TODO Auto-generated constructor stub
	}

	public static String getEncr() {
		return encr;
	}

	public static void setEncr(String encr) {
		Encryption.encr = encr;
	}
	
	
	

}
