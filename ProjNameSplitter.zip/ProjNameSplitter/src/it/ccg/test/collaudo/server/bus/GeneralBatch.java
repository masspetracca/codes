package it.ccg.test.collaudo.server.bus;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.logging.Logger;

public class GeneralBatch {
	
	//chiavi di accesso per UPD
	private static String kArea = ""; 
	private static String kStato = ""; 
	private static String kFreq ="";
	private static String kTipo ="";

	private static String Tab_col0 = "FNAMELNAME";
	private static String Tab_col1 = "FNAME";
	private static String Tab_col2 = "LNAME";

	
	private static String Tab_col3 = "STATUS";
	private static String Tab_col4 = "NODENAME";
	private static String Tab_col5 = "NODETYPE";

	private static String Tab_col6 = "NODEVALUE";
	private static String Tab_col7 = "nodeChild";
	private static String Tab_col8 = "ACTION";
	private static String Tab_col9 = "NOTE";
	private static String Tab_col10 = "";
	private static String TableName = "PMPTHSPLIT";

	private static String vcol3 = "";
	private static String vcol4 = "";
	private static String vcol5 = "";

	private static String sdate =null;
	private static String nomeTab;
	

	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

	private static String tabFreq ="";
	private int ctrIns;
	private int ctrUpd;
	private int returnCode = 0;
	
 	private static String sqlUpdate;


	String stl;
	String tok;
	//TestCollaudoQA testcollaudoqa;
	Logger userLog;
	int indx;
	String keyIdData;
	String keyDateData;
	String keyProgData;

	String statusData;
	String nodeTypeData;
	String nodeNameData;
	String nodeValueData;
	String nodeChildData;
	String nodeChildData1;
	String nodeChildData2;
	String nodeChildData3;
	String nodeChildData4;
	String nodeChildData5;
	String nodeChildData6;
	String nodeChildData7;
	String nodeChildData8;
	String nodeChildData9;


	String actionData;
	String noteData;

	String oldIdData;
	private String line;
	private String file;
	private String lastName;
	private String firstName;
	
	

	public GeneralBatch(int returnCode) throws IOException, SQLException, IllegalAccessException, InstantiationException, ClassNotFoundException {

		Object rs;
		//String driver
		PropertyFiles pf;
		
		//String PreparedStatement
		PreparedStatement st;
		
		try {
			pf = new PropertyFiles();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PropertyFiles.getDbDriverTest();
		PropertyFiles.getTabName1();
		nomeTab=PropertyFiles.getTabName1();


		Class.forName(PropertyFiles.getDbDriverTest()).newInstance();
		//String url = "jdbc:db2://localhost:50000/DB2";
		String url = PropertyFiles.getDbConnStringTest();
		//String prop = ("user"+PropertyFiles.getDbUserTest()+"password"+PropertyFiles.getDbPasswordTest());
		
		Properties props = new Properties();
		//props.setProperty("user", "db2admin");
		props.setProperty("user", PropertyFiles.getDbUserTest());
		
		//props.setProperty("password", "main");
		props.setProperty("password", PropertyFiles.getDbPasswordTest());
		
		
		sdate = day.now();
		
		String sdateaaaa = sdate.substring(0, 4);
		String sdatemm =   sdate.substring(5, 7);
		String sdategg = sdate.substring(8, 10);
		
		String stimehh = sdate.substring(11, 13);
		String stimemm = sdate.substring(14, 16);
		String stimess = sdate.substring(17, 19);
		
		sDate = (sdateaaaa+sdatemm+sdategg);
		sTime = (stimehh+stimemm+stimess);
		System.out.println("date:"+sDate);
		System.out.println("time:"+sTime);
	
		
		
		System.out.println("Inizio <PopulateDb> popolamento tabelle DB2 via JDBC");
		//segnalazioni di test
		System.out.println("**************************************");
		System.out.println("**       Segnalazioni tecniche      **");
		System.out.println("**************************************");
		System.out.println("url per POPOLAMENTO di : "+nomeTab+" "+url);
		System.out.println("drivers: "+PropertyFiles.getDbDriverTest());
		System.out.println("User Test: "+ PropertyFiles.getDbUserTest());
		System.out.println("Password Test: "+ PropertyFiles.getDbPasswordTest());
		System.out.println("**************************************");
		

	   	GetProperties();
 
		//create Connection
		Connection conn = DriverManager.getConnection(url, props);

    	BufferedReader in = new BufferedReader
        //(new FileReader("datiPM/Selenium_testOUT.txt"));
		(new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTVALUES_FILE_OUTPUT()));
    	

    	
 	    TestCollaudoQAEAO pdb = new TestCollaudoQAEAO();
 		keyIdData = " ";
 		keyDateData= " ";
 		keyProgData= " ";  
 		statusData= " ";
 		nodeTypeData= " ";
 		nodeNameData= " ";
 		nodeValueData= " ";
 		nodeChildData= " ";
 		nodeChildData1= " ";
 		nodeChildData2= " ";
 		nodeChildData3= " ";
 		nodeChildData4= " ";
 		nodeChildData5= " ";
 		nodeChildData6= " ";
 		nodeChildData7= " ";
 		nodeChildData8= " ";
 		nodeChildData9= " ";
 		
 		actionData= " ";
 		noteData= " ";

        while ((stl = in.readLine()) != null) {
         	System.out.println("readData: "+stl);

     	    tok=" ";
    	    indx=0;
 	        StringTokenizer f= new StringTokenizer(stl, ";");
	        while(f.hasMoreTokens()) {
	        	    indx++; 
	        		//System.out.println("NOT TOKEN : "+indx+stl);
	        		nextC(f, pdb);
	      		  
	        		String name =  tok;
				    
			    	if(name.split("\\w+").length>1){
					       lastName = name.substring(name.lastIndexOf(" ")+1);
					       firstName = name.substring(0, name.lastIndexOf(' '));
				    }
				     else{
				       firstName = name;
				    }
			    	System.out.println("lastName:"+lastName+" ; " +"firstName:"+firstName);

	        		keyIdData   = name;
					keyDateData = firstName;
					keyProgData = lastName;

					//CRUD
	        		DeleteDb(keyIdData, keyDateData, keyProgData);

		        	TestCollaudoQAUPD deld = new TestCollaudoQAUPD(); 	        
		        	//System.out.println("String per DELETE:"+deld.getSqlUpdate());
		        	st = conn.prepareStatement(deld.getSqlUpdate());
		    	    st.executeUpdate();
	
		    	    PopulateDb(keyIdData, keyDateData, keyProgData, statusData, nodeNameData, nodeTypeData, nodeChildData
	    	    		, nodeChildData1, nodeChildData2, nodeChildData3, nodeChildData4, nodeChildData5, nodeChildData6, nodeChildData7, nodeChildData8, nodeChildData9
	    	    		, actionData, nodeValueData, noteData);
	
	
		    	    TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 	        
		    	    //System.out.println("String per INSERT:"+upd.getSqlUpdate());
		    	    st = conn.prepareStatement(upd.getSqlUpdate());
		    	    st.executeUpdate();
	        }
	}

     in.close();
     System.out.println("Fine esecuzione ##End ...Read Data Test Collaudo QA");
 }


	private void nextC(StringTokenizer f, TestCollaudoQAEAO pdb) {
	    if (indx == 1) {
 	    	tok = (String)f.nextElement();
	    	keyDateData = tok;	        	    	
	    	pdb.setKeyDate(keyDateData);        	    	
	    }
	    if (indx == 2) {
	    	tok = (String)f.nextElement();
	    	keyIdData = tok;
	    	pdb.setKeyId(keyIdData);	       
	    }
	    if (indx == 3) {
	    	tok = (String)f.nextElement();
	    	keyProgData = "0";
	    	//keyProgData = tok;
	    	pdb.setKeyProg(keyProgData);
	    }
	    if (indx == 4) {
	    	tok = (String)f.nextElement();
	    	statusData = tok;
	    	pdb.setStatus(statusData);
	    }
	    if (indx == 5) {
	    	tok = (String)f.nextElement();
	    	nodeNameData = tok;
	    	pdb.setNodeName(nodeNameData);
	    }
	    if (indx == 6) {
	    	tok = (String)f.nextElement();
	    	nodeTypeData = tok;
	    	pdb.setNodeType(nodeTypeData);
	    }
	    if (indx == 7) {
	    	tok = (String)f.nextElement();
	    	nodeChildData = tok;
	    	pdb.setnodeChild(nodeChildData);
	    }
	    if (indx == 8) {
	    	tok = (String)f.nextElement();
	    	nodeChildData1 = tok;
	    	pdb.setnodeChild1(nodeChildData1);
	    }
	    if (indx == 9) {
	    	tok = (String)f.nextElement();
	    	nodeChildData2 = tok;
	    	pdb.setnodeChild2(nodeChildData2);
	    }
	    if (indx == 10) {
	    	tok = (String)f.nextElement();
	    	nodeChildData3 = tok;
	    	pdb.setnodeChild3(nodeChildData3);
	    }
	    if (indx == 11) {
	    	tok = (String)f.nextElement();
	    	nodeChildData4 = tok;
	    	pdb.setnodeChild4(nodeChildData4);
	    }
	    if (indx == 12) {
	    	tok = (String)f.nextElement();
	    	nodeChildData5 = tok;
	    	pdb.setnodeChild5(nodeChildData5);
	    }
	    if (indx == 13) {
	    	tok = (String)f.nextElement();
	    	nodeChildData6 = tok;
	    	pdb.setnodeChild6(nodeChildData6);
	    }
	    if (indx == 14) {
	    	tok = (String)f.nextElement();
	    	nodeChildData7 = tok;
	    	pdb.setnodeChild7(nodeChildData7);
	    }
	    if (indx == 15) {
	    	tok = (String)f.nextElement();
	    	nodeChildData8 = tok;
	    	pdb.setnodeChild8(nodeChildData8);
	    }
	    if (indx == 16) {
	    	tok = (String)f.nextElement();
	    	nodeChildData9 = tok;
	    	pdb.setnodeChild9(nodeChildData9);
	    }
	    if (indx > 16) {
	    	 System.out.println("Fine anomala  ... "+(String)f.nextElement());
	    	 System.exit(10);
	    }
        System.out.println("token:"+indx+"="+tok);
		
	}







	private void DeleteDb(String keyIdData, String keyDateData, String keyProgData) throws IOException, SQLException, IllegalAccessException, InstantiationException, ClassNotFoundException {
		DeleteDb ddb = new DeleteDb(keyIdData, keyDateData, keyProgData);
	}




	private void PopulateDb(String keyDateData, String keyIdData, String keyProgData, String statusData, String nodeNameData, String nodeTypeData,  String nodeChildData
		,  String nodeChildData1,  String nodeChildData2,  String nodeChildData3,  String nodeChildDat4,  String nodeChildData5,  String nodeChildData6,  String nodeChildData7,  String nodeChildData8,  String nodeChildData9
		, String actionData, String nodeValueData, String noteData) throws ClassNotFoundException, IOException, SQLException, IllegalAccessException, InstantiationException {
		
		PopulateDb pdb = new PopulateDb(keyDateData, keyIdData, keyProgData,statusData, nodeNameData, nodeTypeData,  nodeChildData
				,  nodeChildData1,  nodeChildData2,  nodeChildData3,  nodeChildData4,  nodeChildData5,  nodeChildData6,  nodeChildData7,  nodeChildData8,  nodeChildData9
				, actionData, nodeValueData, noteData);

	}
	
	
	private static void GetProperties() throws IOException {
		PropertyFiles pf = new PropertyFiles();
	}
	







}


	
		
							
   


