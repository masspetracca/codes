package it.ccg.irifpejb.server.logengine;

import org.apache.log4j.Logger;


public class LoggerFactory {
	
	public static final String EJB_LOGGER = "intratIFP.ejb.logger";
	public static final String WEB_LOGGER = "intratIFP.web.server";
	public static final String USER_LOGGER = "intratIFP.web.user_logger";
	public static final String MONITOR_LOGGER = "intratIFP.monitor_logger";
	
	
	public static Logger getLogger(final String loggerType) {
		
		Logger logger = null;
		
		if(loggerType.equalsIgnoreCase(EJB_LOGGER)) {
			
			logger =  Logger.getLogger(EJB_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(WEB_LOGGER)) {
			
			logger =  Logger.getLogger(WEB_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(USER_LOGGER)) {
			
			logger =  Logger.getLogger(USER_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(MONITOR_LOGGER)) {
			
			logger =  Logger.getLogger(MONITOR_LOGGER);
		}
		
		
		return logger;
	}

}
