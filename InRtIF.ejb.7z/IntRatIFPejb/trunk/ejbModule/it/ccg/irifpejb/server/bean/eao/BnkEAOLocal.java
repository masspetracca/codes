package it.ccg.irifpejb.server.bean.eao;

import it.ccg.irifpejb.server.bean.entity.RctBnkFtctEntity;

public interface BnkEAOLocal {
	
	public RctBnkFtctEntity findByPrimaryKey(String fitchnickname,int fitchcode) throws Exception;
	
	public void add(RctBnkFtctEntity e) throws Exception;

}
