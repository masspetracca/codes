package it.ccg.irifpejb.server.exception;


import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import org.apache.log4j.Logger;

public class ExceptionUtil {
	
	
	public static void logCompleteStackTrace(Logger logger, Exception exception) {
		
		logger.error(new StandardLogMessage(exception.toString()));
		
		StackTraceElement[] stackTraceElements = exception.getStackTrace();
		for(StackTraceElement element : stackTraceElements) {
			
			logger.error(new StandardLogMessage(element.toString()));
		}
		
	}
	
	
}
