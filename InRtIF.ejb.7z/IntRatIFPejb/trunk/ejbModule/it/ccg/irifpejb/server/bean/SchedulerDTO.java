package it.ccg.irifpejb.server.bean;

import java.util.Date;

public class SchedulerDTO extends TimerDTO {

	
	private int dayOfMonth = -1;
	private boolean onMounthEnd;
	private boolean onMounthStart;
	private int dayOfWeek = -1;
	
	public SchedulerDTO(){
		super();
		super.setScheduler(true);
	}
	
	/**
	 * 
	 * @param name
	 * @param startDateTime
	 * @param interval
	 * @param provider
	 * @param jobDTO
	 */
	public SchedulerDTO(String name, Date startDateTime, int dayOfMonth, String provider, JobDTO jobDTO) {
		//public TimerDTO(String name, boolean isSingle, Date startDateTime, long interval, String provider, JobDTO jobDTO) {
		super(name,false,startDateTime,86400000,provider,jobDTO);
		super.setScheduler(true);
		this.dayOfMonth = dayOfMonth;
	}
	
	/**
	 * 
	 * @param name
	 * @param startDateTime
	 * @param onMonthEnd
	 * @param provider
	 * @param jobDTO
	 */
	public SchedulerDTO(String name, Date startDateTime, boolean onMonthEnd, String provider, JobDTO jobDTO) {
		super(name,false,startDateTime,86400000,provider,jobDTO);
		super.setScheduler(true);
		this.onMounthEnd = onMonthEnd;
	}
	
	/**
	 * 
	 * @param name
	 * @param startDateTime
	 * @param provider
	 * @param onMonthStart
	 * @param jobDTO
	 */
	public SchedulerDTO(String name, Date startDateTime, String provider, boolean onMonthStart, JobDTO jobDTO) {
		super(name,false,startDateTime,86400000,provider,jobDTO);
		super.setScheduler(true);
		this.onMounthStart = onMonthStart;
	}
	
	/**
	 * 
	 * @param name
	 * @param startDateTime
	 * @param dayOfWeek
	 * @param provider
	 * @param jobDTO
	 */
	public SchedulerDTO(String name, Date startDateTime, String provider, int dayOfWeek, JobDTO jobDTO) {
		super(name,false,startDateTime,86400000,provider,jobDTO);
		super.setScheduler(true);
		this.dayOfWeek = dayOfWeek;
	}

	/**
	 * @return the onMonthEnd
	 */
	public boolean isOnMonthEnd() {
		return onMounthEnd;
	}

	/**
	 * @param onMonthEnd the onMonthEnd to set
	 */
	public void setOnMonthEnd(boolean onMonthEnd) {
		this.onMounthEnd = onMonthEnd;
	}

	/**
	 * @return the onMonthStar
	 */
	public boolean isOnMonthStar() {
		return onMounthStart;
	}

	/**
	 * @param onMonthStar the onMonthStar to set
	 */
	public void setOnMonthStar(boolean onMonthStar) {
		this.onMounthStart = onMonthStar;
	}

	/**
	 * @return the dayOfWeek
	 */
	public int getDayOfWeek() {
		return dayOfWeek;
	}

	/**
	 * @param dayOfWeek the dayOfWeek to set
	 */
	public void setDayOfWeek(int dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}

	/**
	 * @return the dateInterval
	 */
	public int getDayOfMonth() {
		return dayOfMonth;
	}

	/**
	 * @param dateInterval the dateInterval to set
	 */
	public void setDayOfMonth(int dayOfMonth) {
		this.dayOfMonth = dayOfMonth;
	}

	/**
	 * @return the onMonthStart
	 */
	public boolean isOnMonthStart() {
		return onMounthStart;
	}

	/**
	 * @param onMonthStart the onMonthStart to set
	 */
	public void setOnMonthStart(boolean onMonthStart) {
		this.onMounthStart = onMonthStart;
	}
	
	
}
