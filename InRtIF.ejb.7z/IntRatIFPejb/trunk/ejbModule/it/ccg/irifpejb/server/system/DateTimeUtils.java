package it.ccg.irifpejb.server.system;

import java.util.Calendar;
import java.util.Date;

public class DateTimeUtils {
	
	
	@SuppressWarnings("deprecation")
	public static int getCurrentDateYYYYMMDD() {
		
		// OLD - not working because of strange results from Calendar.MONTH
		
		/*Calendar calendar = Calendar.getInstance();
		
		String yyyy = String.format("%1$04d", calendar.get(Calendar.YEAR));
		String mm = String.format("%1$02d", calendar.get(Calendar.MONTH + 1));
		String dd = String.format("%1$02d", calendar.get(Calendar.DAY_OF_MONTH));
		
		return Integer.parseInt(yyyy + mm + dd);*/
		
		
		Date date = new Date(System.currentTimeMillis());
		
		String yyyy = String.format("%1$04d", date.getYear() + 1900);
		String mm = String.format("%1$02d", date.getMonth() + 1);
		String dd = String.format("%1$02d", date.getDate());
		
		return Integer.parseInt(yyyy + mm + dd);
		
	}
	
	
	public static int getCurrentTimeHHMMSS() {
		
		Calendar calendar = Calendar.getInstance();
		
		String hh = String.format("%1$02d", calendar.get(Calendar.HOUR_OF_DAY));
		String mm = String.format("%1$02d", calendar.get(Calendar.MINUTE));
		String ss = String.format("%1$02d", calendar.get(Calendar.SECOND));
		
		return Integer.parseInt(hh + mm + ss);
	}
	
}
