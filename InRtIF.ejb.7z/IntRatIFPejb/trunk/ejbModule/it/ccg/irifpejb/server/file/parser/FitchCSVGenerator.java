package it.ccg.irifpejb.server.file.parser;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import it.ccg.irifpejb.server.bean.entity.BankEntity;
import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.file.factory.FITCHRequestType;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import org.apache.log4j.Logger;

public class FitchCSVGenerator {
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	public FitchCSVGenerator(){
		
	}
	
	public void createRequestFile(FITCHRequestType requestType, File outputFile, List<BankEntity> bankList) throws Exception {
		
		if(requestType == FITCHRequestType.BANK_REQUEST) {
			
			this.createBankRequestFile(outputFile, bankList);
		}
		/*else if(requestType == BBGRequestType.NIR_REQUEST) {
			
			this.createNirRequestFile(outputFile, bankList);
		}*/
		else {
			
			logger.error(new StandardLogMessage("Invalid Reuters request type \'" + requestType + "\'."));
			
			throw new Exception("Invalid Reuters request type \'" + requestType + "\'.");
		}
		
	}
	
	public void createBankRequestFile(File outputFile,List<BankEntity> in) throws IOException{
		logger.info(new StandardLogMessage("in FitchCSVGenerator.getFitchCsvFile()"));
		try {
			FileWriter out = new FileWriter(outputFile);
			out.append("CUSIP,ISIN,Customer Identifier,VS ID,Agent Common ID,Security Common ID,Agent ID");
			out.append('\n');
	
			for(int i = 0;i<in.size();i++){
				/*
				 * Raffaele De Lauri
				 * 29/05/2014
				 * cambio contenuto delle righe per workaround a problemi Fitch
				 * vecchio:
				 * out.append(",,"+in.get(i).getBankName()+",,"+in.get(i).getFitchCode()+",,");
				 */
				out.append(",,,,"+in.get(i).getFitchCode()+",,");
				out.append('\n');
			}
			out.flush();
			out.close();
			logger.debug(new StandardLogMessage("return"));
			
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw e;
		}
	}
}
