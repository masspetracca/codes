package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the RCITIDGEN database table.
 * 
 */
@Entity
@Table(name="RCITIDGEN")
public class IdgenEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="ID_NAME", nullable=false, length=30)
	private String idName;

	@Column(name="ID_VALUE", nullable=false)
	private int idValue;

    public IdgenEntity() {
    }

	public String getIdName() {
		return this.idName;
	}

	public void setIdName(String idName) {
		this.idName = idName;
	}

	public int getIdValue() {
		return this.idValue;
	}

	public void setIdValue(int idValue) {
		this.idValue = idValue;
	}

}