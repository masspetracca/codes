package it.ccg.irifpejb.server.bean.business;



import javax.ejb.Local;

@Local
public interface FitchManagerBeanLocal {
	
	public void checkReqAlign_BANK() throws Exception;
	public void alignReq_BANK() throws Exception;
	
}
