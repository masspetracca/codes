package it.ccg.irifpejb.server.bean.eao;

import it.ccg.irifpejb.server.bean.entity.RctHisRtgEntity;
import it.ccg.irifpejb.server.bean.entity.RctHisRtgEntityPK;

import java.util.List;

public interface HistoricalRatingEAOLocal {
	public List<RctHisRtgEntity> fetch() throws Exception;
	public RctHisRtgEntity findByPrimaryKey(RctHisRtgEntityPK pK) throws Exception;
	
	public List<RctHisRtgEntity> fetchLastDateHisRtg(List<Integer> bankIDs) throws Exception;
	
	public void add(RctHisRtgEntity ie) throws Exception;
	public void update(RctHisRtgEntity ie) throws Exception;
	public void remove(RctHisRtgEntity ie) throws Exception;
}
