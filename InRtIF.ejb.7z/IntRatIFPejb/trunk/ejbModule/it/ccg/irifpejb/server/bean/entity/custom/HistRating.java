package it.ccg.irifpejb.server.bean.entity.custom;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: HistRating
 *
 */
@Entity

public class HistRating implements Serializable {

	
	private static final long serialVersionUID = 1L;
	@Transient
	private String bloombCode;
	@Transient
	private String fitchRtg;
	@Transient
	private String moodRtg;
	@Transient
	private String spRtg;
	@Transient
	private int rtgDate;
	
	public HistRating() {
		super();
	}

	/**
	 * 
	 * @param bloombCode
	 * @param fitchRtg
	 * @param moodRtg
	 * @param spRtg
	 */
	public HistRating(String bloombCode,String fitchRtg,String moodRtg,String spRtg,int rtgDate) {
		this.bloombCode=bloombCode;
		this.fitchRtg=fitchRtg;
		this.moodRtg=moodRtg;
		this.spRtg=spRtg;
		this.rtgDate=rtgDate;
	}
	/**
	 * @return the rtgDate
	 */
	public int getRtgDate() {
		return rtgDate;
	}

	/**
	 * @param rtgDate the rtgDate to set
	 */
	public void setRtgDate(int rtgDate) {
		this.rtgDate = rtgDate;
	}

	/**
	 * @return the bloombCode
	 */
	public String getBloombCode() {
		return bloombCode;
	}

	/**
	 * @param bloombCode the bloombCode to set
	 */
	public void setBloombCode(String bloombCode) {
		this.bloombCode = bloombCode;
	}

	/**
	 * @return the fitchRtg
	 */
	public String getFitchRtg() {
		return fitchRtg;
	}

	/**
	 * @param fitchRtg the fitchRtg to set
	 */
	public void setFitchRtg(String fitchRtg) {
		this.fitchRtg = fitchRtg;
	}

	/**
	 * @return the moodRtg
	 */
	public String getMoodRtg() {
		return moodRtg;
	}

	/**
	 * @param moodRtg the moodRtg to set
	 */
	public void setMoodRtg(String moodRtg) {
		this.moodRtg = moodRtg;
	}

	/**
	 * @return the spRtg
	 */
	public String getSpRtg() {
		return spRtg;
	}

	/**
	 * @param spRtg the spRtg to set
	 */
	public void setSpRtg(String spRtg) {
		this.spRtg = spRtg;
	}
	
	
   
}
