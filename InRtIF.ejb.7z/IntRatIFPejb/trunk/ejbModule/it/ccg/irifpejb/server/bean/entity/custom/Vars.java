package it.ccg.irifpejb.server.bean.entity.custom;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Transient;


@Entity
public class Vars implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int varid;
	@Transient
	private String vardesc;
	
	
	public Vars() {
		
	}
	
	
	public Vars(int varid, String vardesc) {
		
		this.varid = varid;
		this.vardesc = vardesc;
	}



	public int getVarid() {
		return varid;
	}

	public void setVarid(int varid) {
		this.varid = varid;
	}
	
	public String getVardesc() {
		return vardesc;
	}
	
	public void setVardesc(String vardesc) {
		this.vardesc = vardesc;
	}
	

}
