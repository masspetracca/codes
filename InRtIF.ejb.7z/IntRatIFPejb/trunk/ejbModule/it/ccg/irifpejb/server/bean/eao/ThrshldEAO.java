package it.ccg.irifpejb.server.bean.eao;

import javax.ejb.Local;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class ThrshldEAO
 */
@Stateless
@Local(ThrshldEAOLocal.class)
public class ThrshldEAO implements ThrshldEAOLocal {

    /**
     * Default constructor. 
     */
    public ThrshldEAO() {
        // TODO Auto-generated constructor stub
    }

}
