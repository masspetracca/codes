package it.ccg.irifpejb.smartgwt.server.util;

import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EmbeddedId;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.Column;

import org.apache.log4j.Logger;

import com.isomorphic.criteria.AdvancedCriteria;
import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;

public class DmiEAOUtil {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	@SuppressWarnings("unchecked")
	public static JpaQuery getFilteredQuery(JpaQuery jpaQuery, DSRequest dsRequest) throws Exception {
		
		// Retrieve entity type and entity instance name
		Class<?> entityType = Class.forName(jpaQuery.getFromClause().split(" ")[1]);
		String entityInstanceName = jpaQuery.getFromClause().split(" ")[2];
		
		
		// where
		String filteredWhereClause = new String();
		
		// Inizializza la WHERE clause filtrata.
		// Se la query originale ha WHERE clause vuota, inizializzala a 'WHERE 1=1'..
		if(jpaQuery.getWhereClause() == null || (jpaQuery.getWhereClause() != null && jpaQuery.getWhereClause().trim().length() == 0)) {
			
			filteredWhereClause = "WHERE 1=1";
		}
		// .. altrimenti mantieni quella originale. Se il client specificher� dei filtri, questi verranno AGGIUNTI.
		else {
			
			filteredWhereClause = jpaQuery.getWhereClause();
		}
		
    	AdvancedCriteria advancedCriteria = dsRequest.getAdvancedCriteria();
		Map<String, Object> criteriaStructure = advancedCriteria.getCriteriaAsMap();
		
		List<Map<String, Object>> criteriaList = (List<Map<String, Object>>)criteriaStructure.get("criteria");
		
		// this happens when client sends a single map, without nested structures
		if(criteriaList == null) {
			
			criteriaList = new ArrayList<Map<String,Object>>();
			criteriaList.add(criteriaStructure);
		}
		else {
			if((criteriaList.size() > 0) && (criteriaList.get(0).get("criteria") !=  null)) {
				
				criteriaList = (List<Map<String, Object>>)criteriaList.get(0).get("criteria");
			}
		}
		
		
		logger.debug(new StandardLogMessage("criteriaList: " + criteriaList));
		
		
		CriteriaJpqlOperatorConverter criteriaJpqlOperatorConverter = new CriteriaJpqlOperatorConverter();
		
		if(criteriaList.size() > 0) {
			
			//filteredWhereClause = "WHERE 1=1";
			
			for(Map<String, Object> criteria : criteriaList) {
	    		
	    		if(criteria.isEmpty()) {
	    			
	    			break;
	    		}
	    		
	    		// fieldName, operator, value
	    		String fieldName = (String)criteria.get("fieldName");
	    		String operator = (String)criteria.get("operator");
	    		Object value = criteria.get("value");
	    		
	    		//System.out.println("@@ raw value: " + value);
	    		//System.out.println("@@ raw value class: " + value.getClass());
	    		
	    		// check value type
    			if(value instanceof Date) {
    				
    				value = "'" + (new Timestamp(((java.util.Date)value).getTime())).toString() + "'";
    			}
    			// OLD Date
    			/*if(value instanceof Date) {
    				
        			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        			value = sdf.format((Date)value);
    			}*/
	    		// general case, useless
	    		else if(value instanceof String) {
	    			
	    			value = "'"+value+"'";
	    		}
    			
	    		//System.out.println("@@ parsed value: " + value);
    			
    			
    			// TODO: remove
    			System.out.println("### fieldName: " + fieldName + ", entityType: " + entityType);
    			
    			// Controlla se il field sia dell'oggetto Entity corrente, 
    			// o se quest'ultimo abbia una PK_Entity e il field appartenga ad essa.
    			fieldName = getCorrectJPAField(fieldName, entityType);
    			
	    		
	    		filteredWhereClause += " AND " + criteriaJpqlOperatorConverter.convertToJPQL(entityInstanceName + "." + fieldName, operator, value);
	    	}
		}
		
		
    	// order by
		String filteredOrderByClause = new String();
		
		List<String> sortByFieldsList = dsRequest.getSortByFields();
    	
		// Se da client viene specificato un ordinamento, sovrascrivi la ORDER BY clause originale..
    	if(sortByFieldsList.size() > 0) {
    		
    		filteredOrderByClause = "ORDER BY" + " ";
    		
    		for(String sortByField : sortByFieldsList) {
    			
    			if(sortByField.charAt(0) == '-') {
    				
    				// Controlla se il field sia dell'oggetto Entity corrente, 
        			// o se quest'ultimo abbia una PK_Entity e il field appartenga ad essa.
        			String fieldName = getCorrectJPAField(sortByField.substring(1), entityType);
        			
    				filteredOrderByClause += entityInstanceName + "."  + fieldName + " desc" + ",";
        		}
        		else {
        			
        			// Controlla se il field sia dell'oggetto Entity corrente, 
        			// o se quest'ultimo abbia una PK_Entity e il field appartenga ad essa.
        			String fieldName = getCorrectJPAField(sortByField, entityType);
        			
        			filteredOrderByClause += entityInstanceName + "."  + fieldName + ",";
        		}
        		
        	}
        	
    		filteredOrderByClause = filteredOrderByClause.substring(0, filteredOrderByClause.length() - 1);
    	}
    	// ..altrimenti mantieni quella originale.
    	else {
    		
    		filteredOrderByClause = jpaQuery.getOrderByClause();
    	}
    	
    	JpaQuery filteredJpaQuery = new JpaQuery(jpaQuery.getSelectClause(), 
    											 jpaQuery.getFromClause(), 
    											 filteredWhereClause, 
    											 jpaQuery.getGroupByClause(), 
    											 jpaQuery.getHavingClause(), 
    											 filteredOrderByClause);
		
    	
		return filteredJpaQuery;
	}
	
	
	
	public static DSResponse executeQuery(JpaQuery jpaQuery, DSRequest dsRequest, EntityManager em) {
		
		DSResponse dsResponse = new DSResponse();
		
		
		// Creo la query da eseguire
		Query query = createJpaQuery(jpaQuery, em);
    	
		// Eseguo la query senza paging
		@SuppressWarnings("rawtypes")
		List dataList = query.getResultList();
		
    	// Paging - DataSource protocol: get requested row range  
		long totalRows = dataList.size();
        long startRow = (int)dsRequest.getStartRow();  
        long endRow = (int)dsRequest.getEndRow();
        endRow = Math.min(endRow, totalRows);
		
		// Inserisco i dati della dsResponse - ora implemento il paging
		dsResponse.setData(dataList.subList((int)startRow, (int)endRow));
		
		// Tell client what rows are being returned, and what's available  
        dsResponse.setStartRow(startRow);
        dsResponse.setEndRow(endRow);
        dsResponse.setTotalRows(totalRows);
		
        
        return dsResponse;
	}
	
	
	private static Query createJpaQuery(JpaQuery jpaQuery, EntityManager em) {
		
		Query query = em.createQuery(jpaQuery.toString());
		
		return query;
	}
	
	
	private static String getCorrectJPAField(String fieldName, Class<?> entityType) throws Exception {
		
		String correctFieldName = null;
		
		// cerca il field nell'entity corrente
		Field field = null;
		try {
			field = entityType.getDeclaredField(fieldName);
		}
		catch(NoSuchFieldException e) {
			// DO NOTHING, field rimane = null
		}
			
		// se l'ho trovato
		if(field != null) {
			correctFieldName = fieldName;
		}
		// se NON l'ho trovato, cerco nell'eventuale PK_Entity
		else {
			Field[] fields = entityType.getDeclaredFields();
			
			for(Field f : fields) {
				if(f.getAnnotation(EmbeddedId.class) != null) {
					Class<?> PK_EntityType = f.getType();
					// cerca il field nella PK_Entity
					Field pkField = null;
					try {
						pkField = PK_EntityType.getDeclaredField(fieldName);
					}
					catch(NoSuchFieldException e) {
						// DO NOTHING, pkField rimane == null
					}
					// se l'ho trovato..
					if(pkField != null) {
						
						correctFieldName = f.getName() + "." + fieldName;
						// l'ho trovato, esci dal ciclo
						break;
					}
					// .. altrimenti continua a cercare
				}
			}
			/*
			 * check in field's annotation
			 */
			if (correctFieldName == null || correctFieldName.equalsIgnoreCase("")){
				for(Field f : fields) {
					if(f.getAnnotation(Column.class) != null){
						Column colAnn = f.getAnnotation(Column.class);
						if(colAnn.name().equalsIgnoreCase(fieldName)){
							correctFieldName =  f.getName();
						}
					}
				}
			}
		}
		
		// Se alla fine del giro non ho trovato il field neanche nella PK_Entity,
		// allora c'� un errore.
		if(correctFieldName == null) {
			throw new Exception("Not valid JPA field: " + fieldName);
		}
		
		return correctFieldName;
	}
	
	
	
	
	
	// *** OLD **********************************************************
	// ******************************************************************
	
	/*public static DSResponse executeQuery(JpaQuery jpaQuery, Map<String, Object> jpaQueryParams, DSRequest dsRequest, EntityManager em) {
		
		DSResponse dsResponse = new DSResponse();
		
		// Creo la query da eseguire
		Query query = createJpaQuery(jpaQuery, jpaQueryParams, em);
    	
    	// Paging - DataSource protocol: get requested row range  
		long totalRows = getTotalRows(jpaQuery, jpaQueryParams, em);
        long startRow = (int)dsRequest.getStartRow();  
        long endRow = (int)dsRequest.getEndRow();
        endRow = Math.min(endRow, totalRows);
        
		// Settaggi per il paging
        long firstResult = startRow;
        long maxResults = endRow - startRow;
        query.setFirstResult((int)firstResult);
    	query.setMaxResults((int)maxResults);
		
		// Eseguo la query
		@SuppressWarnings("rawtypes")
		List dataList = query.getResultList();
		
		// Inserisco i dati della dsResponse
		dsResponse.setData(dataList);
		
		// Tell client what rows are being returned, and what's available  
        dsResponse.setStartRow(startRow);  
        dsResponse.setEndRow(endRow);  
        dsResponse.setTotalRows(totalRows);
		
        
        return dsResponse;
	}
	
	
	private static long getTotalRows(JpaQuery jpaQuery, Map<String, Object> jpaQueryParams, EntityManager em) {
		
		// Generate COUNT query
		JpaQuery jpaQueryCount = new JpaQuery();
		
		
		
		
		Query query = createJpaQuery(jpaQueryCount, jpaQueryParams, em);
		
		@SuppressWarnings("rawtypes")
		List tempList = query.getResultList();
		
    	
    	return tempList.size();
    }*/
	
	
	/*private static Query createJpaQuery(JpaQuery jpaQuery, Map<String, Object> jpaQueryParams, EntityManager em) {
		
		Query query = em.createQuery(jpaQuery.toString());
		
		if(jpaQueryParams != null) {
			
			Set<String> keySet = jpaQueryParams.keySet();
			
			for(String param : keySet) {
			
				if(jpaQueryParams.get(param) instanceof Long) {
					query.setParameter(param, ((Long)jpaQueryParams.get(param)).intValue());
				}
				else {
					query.setParameter(param, jpaQueryParams.get(param));
				}
			}
		}
		
		
		return query;
	}*/



}
