package it.ccg.irifpejb.smartgwt.server.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.isomorphic.criteria.AdvancedCriteria;
import com.isomorphic.datasource.DSRequest;

public class CriteriaParser {
	
	
	
	public CriteriaParser() {
		
	}
	
	
	@SuppressWarnings("unchecked")
	public List<CriteriaDTO> getCriteria(DSRequest dsRequest) {
		
		List<CriteriaDTO> criteriaDTOList = new ArrayList<CriteriaDTO>();
		
		// OLD
		AdvancedCriteria advancedCriteria = dsRequest.getAdvancedCriteria();
		Map<String, Object> criteriaStructure = advancedCriteria.getCriteriaAsMap();
		List<Map<String, Object>> criteriaList = (List<Map<String, Object>>)criteriaStructure.get("criteria");
		
		if((criteriaList.size() > 0) && (criteriaList.get(0).get("criteria") !=  null)) {
			criteriaList = (List<Map<String, Object>>)criteriaList.get(0).get("criteria");
		}
		
		/*@SuppressWarnings("rawtypes")
		Map criteriaMap = dsRequest.getCriteria();
		List<Map<String, Object>> criteriaList = null;
		
		if(criteriaMap.get("_constructor") != null) {
			if(((String)criteriaMap.get("_constructor")).equalsIgnoreCase("AdvancedCriteria")) {
				
				criteriaList = (List<Map<String, Object>>)criteriaMap.get("criteria");
			}
			else {
				AdvancedCriteria advancedCriteria = dsRequest.getAdvancedCriteria();
				Map<String, Object> criteriaStructure = advancedCriteria.getCriteriaAsMap();
				
				criteriaList = (List<Map<String, Object>>)criteriaStructure.get("criteria");
			}
		}
		else {
			
			AdvancedCriteria advancedCriteria = dsRequest.getAdvancedCriteria();
			Map<String, Object> criteriaStructure = advancedCriteria.getCriteriaAsMap();
			
			criteriaList = (List<Map<String, Object>>)criteriaStructure.get("criteria");
		}*/
		
		
		CriteriaDTO criteriaDTO = null;
		
		for(Map<String, Object> criteria : criteriaList) {
    		
    		if(criteria.isEmpty()) {
    			break;
    		}
    		
    		// fieldName, operator, value
    		String fieldName = (String)criteria.get("fieldName");
    		String operator = (String)criteria.get("operator");
    		Object value = criteria.get("value");
    		
    		criteriaDTO = new CriteriaDTO(fieldName, operator, value);
    		
    		criteriaDTOList.add(criteriaDTO);
		}
		
		
		return criteriaDTOList;
	}

}
