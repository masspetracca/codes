package it.ccg.irifpejb.smartgwt.server.dmi;

import java.sql.Timestamp;

import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.smartgwt.server.util.DmiEAOUtil;
import it.ccg.irifpejb.smartgwt.server.util.JpaQuery;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;

/**
 * Session Bean implementation class IssuesDmiEAO
 */
@Stateless
@Local(IssuesDmiEAOLocal.class)
public class IssuesDmiEAO implements IssuesDmiEAOLocal {

	@PersistenceContext(unitName="IntRatIFPejb", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	
    /**
     * Default constructor. 
     */
    public IssuesDmiEAO() {
    	
    }
    
    
    @Override
	public DSResponse fetch(DSRequest dsRequest) throws Exception {

    	JpaQuery jpaQuery = new JpaQuery("SELECT new Issues(f.id.valueDate,f.id.rTicker,f.dsplyName,f.matDate,f.fitchRtg,f.moodRtg,f.spRtg,f.mtStOtrSpr,f.indSec)", "FROM it.ccg.irifpejb.server.bean.entity.RctIssuesEntity f", "", "", "", "");
		
		
		JpaQuery filteredJpaQuery = DmiEAOUtil.getFilteredQuery(jpaQuery, dsRequest);
		
    	logger.info(new StandardLogMessage("query: " + filteredJpaQuery.toString()));
    	
    	
		return DmiEAOUtil.executeQuery(filteredJpaQuery, dsRequest, this.em);
	}
}
