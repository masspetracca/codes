package it.ccg.irifpejb.smartgwt.server.dmi;

import it.ccg.irifpejb.server.bean.entity.BankEntity;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.smartgwt.server.util.DmiEAOUtil;
import it.ccg.irifpejb.smartgwt.server.util.JpaQuery;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;

/**
 * Session Bean implementation class CmtEAO
 */
@Stateless
public class BankDmiEAO implements BankDmiEAOLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@PersistenceContext(unitName="IntRatIFPejb", type=PersistenceContextType.TRANSACTION)
	private EntityManager em;

	/**
     * Default constructor. 
     */
    public BankDmiEAO() throws Exception {
    	
    }
    
	@Override
	public DSResponse fetch(DSRequest dsRequest) throws Exception {
		
		JpaQuery jpaQuery = new JpaQuery("SELECT new Bank(bank.bankId,bank.abiCode,bank.bankName,bank.bloombCode,bank.country,bank.ctp,bank.fitchCode,bank.parBnkBlCd,bank.parBnkName,bank.parBnkTick,bank.participnt,bank.rTicker,bank.status)", "FROM it.ccg.irifpejb.server.bean.entity.BankEntity bank", "", "", "", "ORDER BY bank.bankName");
		
		
		JpaQuery filteredJpaQuery = DmiEAOUtil.getFilteredQuery(jpaQuery, dsRequest);
		
    	logger.debug(new StandardLogMessage("query: " + filteredJpaQuery.toString()));
    	
    	
		return DmiEAOUtil.executeQuery(filteredJpaQuery, dsRequest, this.em);
	}



	@Override
	public BankEntity add(DSRequest dsRequest) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public BankEntity update(DSRequest dsRequest) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public BankEntity remove(DSRequest dsRequest) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	/*private long getTotalRows(String jpaQueryString, Map<String, Object> jpaQueryParams) {
		
		Query query = this.createJpaQuery(jpaQueryString, jpaQueryParams);
		
		@SuppressWarnings("rawtypes")
		List tempList = query.getResultList();
		
    	
    	return tempList.size();
    }*/
	
	
	/*private DSResponse executeQuery(JpaQuery jpaQuery, Map<String, Object> jpaQueryParams, DSRequest dsRequest) {
		
		DSResponse dsResponse = new DSResponse();
		
		
		// Creo la query da eseguire
		Query query = this.createJpaQuery(jpaQuery.toString(), jpaQueryParams);
    	
		// Eseguo la query senza paging
		@SuppressWarnings("rawtypes")
		List dataList = query.getResultList();
		
    	// Paging - DataSource protocol: get requested row range  
		long totalRows = dataList.size();
        long startRow = (int)dsRequest.getStartRow();  
        long endRow = (int)dsRequest.getEndRow();
        endRow = Math.min(endRow, totalRows);
		
		// Inserisco i dati della dsResponse - ora implemento il paging
		dsResponse.setData(dataList.subList((int)startRow, (int)endRow));
		
		// Tell client what rows are being returned, and what's available  
        dsResponse.setStartRow(startRow);
        dsResponse.setEndRow(endRow);
        dsResponse.setTotalRows(totalRows);
		
        
        return dsResponse;
	}*/
	
	
	// OLD
	/*private DSResponse executeQuery(JpaQuery jpaQuery, Map<String, Object> jpaQueryParams, DSRequest dsRequest) {
		DSResponse dsResponse = new DSResponse();
		
		
		// Creo la query da eseguire
		Query query = this.createJpaQuery(jpaQuery.toString(), jpaQueryParams);
    	
    	// Paging - DataSource protocol: get requested row range  
		long totalRows = this.getTotalRows(jpaQuery.toString(), jpaQueryParams);
        long startRow = (int)dsRequest.getStartRow();  
        long endRow = (int)dsRequest.getEndRow();
        endRow = Math.min(endRow, totalRows);
        long firstResult = startRow;
        long maxResults = endRow - startRow;
        
		// Settaggi per il paging
        query.setFirstResult((int)firstResult);
    	query.setMaxResults((int)maxResults);
		
		// Eseguo la query
		@SuppressWarnings("rawtypes")
		List dataList = query.getResultList();
		
		// Inserisco i dati della dsResponse
		dsResponse.setData(dataList);
		
		// Tell client what rows are being returned, and what's available  
        dsResponse.setStartRow(startRow);  
        dsResponse.setEndRow(endRow);  
        dsResponse.setTotalRows(totalRows);
		
        
        return dsResponse;
	}*/
	
	
	/*private Query createJpaQuery(String jpaQueryString, Map<String, Object> jpaQueryParams) {
		
		Query query = em.createQuery(jpaQueryString);
		
		if(jpaQueryParams != null) {
			
			Set<String> keySet = jpaQueryParams.keySet();
			
			for(String param : keySet) {
			
				if(jpaQueryParams.get(param) instanceof Long) {
					query.setParameter(param, ((Long)jpaQueryParams.get(param)).intValue());
				}
				else {
					query.setParameter(param, jpaQueryParams.get(param));
				}
			}
		}
		
		
		return query;
	}*/
	


	/*@Override
	public BankEntity add(DSRequest dsRequest) throws Exception {
		
		logger.debug(new StandardLogMessage("Operation id: " + dsRequest.getOperationId() + ", Operation type: " + dsRequest.getOperationType() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		
		@SuppressWarnings("unchecked")
		Map<String, Object> valueMap = dsRequest.getValues();
    	logger.info(new StandardLogMessage("New values: " + valueMap));
    	
		// make object
    	BankEntity instrEntity = new InstrEntity();
    	instrEntity.setBloombergCode((String)valueMap.get("bloombergCode"));
    	instrEntity.setClassCode((String)valueMap.get("classCode"));
    	instrEntity.setCurrency((String)valueMap.get("currency"));
    	instrEntity.setDataType((String)valueMap.get("dataType"));
    	instrEntity.setInstrumentName((String)valueMap.get("instrumentName"));
    	instrEntity.setInstrumentSubtype((String)valueMap.get("instrumentSubtype"));
    	instrEntity.setInstrumentType((String)valueMap.get("instrumentType"));
    	instrEntity.setIsinCode((String)valueMap.get("isinCode"));
    	instrEntity.setMarketCode((String)valueMap.get("marketCode"));
    	instrEntity.setNote((String)valueMap.get("note"));
    	instrEntity.setProvider((String)valueMap.get("provider"));
    	instrEntity.setReutersIdentifierCode((String)valueMap.get("reutersIdentifierCode"));
    	instrEntity.setSegmentCode((String)valueMap.get("segmentCode"));
    	instrEntity.setStatus((String)valueMap.get("status"));
    	
    	// persist
    	this.instrEAOLocal.add(instrEntity);
    	
    	// se lo status � settato a 'E' (enabled) o 'O' (one shot) aggiungi il nuovo strumento alle liste remote di scarico
    	if(((String)valueMap.get("status")).equalsIgnoreCase("E") || ((String)valueMap.get("status")).equalsIgnoreCase("O")) {
    		
    		this.updateRemoteRequest(valueMap);
    	}
    	
    	
    	// Return just persisted object to refresh client.
		return instrEntity;
	}



	@Override
	public InstrEntity update(DSRequest dsRequest) throws Exception {
		
		@SuppressWarnings("unchecked")
		Map<String, Object> newValueMap = dsRequest.getValues();
		@SuppressWarnings("unchecked")
		Map<String, Object> oldValueMap = dsRequest.getOldValues();
		
		// get object before the update (for log)
		InstrEntity oldInstr = this.instrEAOLocal.findByPrimaryKey(Integer.parseInt((String)newValueMap.get("instrumentId")));
    	
		logger.info(new StandardLogMessage("Old values: " + oldInstr));
		
    	// make object to persist
    	InstrEntity temp = new InstrEntity();
    	temp.setInstrumentId(Integer.parseInt((String)newValueMap.get("instrumentId")));
    	temp.setBloombergCode((String)newValueMap.get("bloombergCode"));
    	temp.setClassCode((String)newValueMap.get("classCode"));
    	temp.setCurrency((String)newValueMap.get("currency"));
    	temp.setDataType((String)newValueMap.get("dataType"));
    	temp.setInstrumentName((String)newValueMap.get("instrumentName"));
    	temp.setInstrumentSubtype((String)newValueMap.get("instrumentSubtype"));
    	temp.setInstrumentType((String)newValueMap.get("instrumentType"));
    	temp.setIsinCode((String)newValueMap.get("isinCode"));
    	temp.setMarketCode((String)newValueMap.get("marketCode"));
    	temp.setNote((String)newValueMap.get("note"));
    	temp.setProvider((String)newValueMap.get("provider"));
    	temp.setReutersIdentifierCode((String)newValueMap.get("reutersIdentifierCode"));
    	temp.setSegmentCode((String)newValueMap.get("segmentCode"));
    	temp.setStatus((String)newValueMap.get("status"));
    	
    	// persist
    	InstrEntity updatedInstr = this.instrEAOLocal.update(temp);
    	
    	logger.info(new StandardLogMessage("New values: " + updatedInstr));
    	
    	// update request only if attribute 'status' was changed
    	if(!((String)newValueMap.get("status")).equalsIgnoreCase((String)oldValueMap.get("status"))) {
    		
    		this.updateRemoteRequest(oldValueMap);
    	}
    	
    	
    	// Return just persisted object to refresh client.
    	return updatedInstr;
	}



	@Override
	public InstrEntity remove(DSRequest dsRequest) throws Exception {
		
		@SuppressWarnings("unchecked")
		Map<String, Object> oldValueMap = dsRequest.getOldValues();
    	logger.info(new StandardLogMessage("Old values: " + oldValueMap));
		
    	// make object
    	InstrEntity instrEntity = new InstrEntity();
    	instrEntity.setInstrumentId((int)((Long)oldValueMap.get("instrumentId")).longValue());
    	
    	// remove
    	this.instrEAOLocal.remove(instrEntity);
    	
    	// update request
    	this.updateRemoteRequest(oldValueMap);
    	
    	
		return instrEntity;
	}
	
	
	// This method updates request for new enabled added or updated instrument.
	// To check what request, the filter is [provider, instrumentType]
	private void updateRemoteRequest(Map<String, Object> valueMap) throws Exception {
		
		if(provider.equalsIgnoreCase("Reuters")) {
			
			timerName += "REUTERS_";
			
			if(instrumentType.equalsIgnoreCase("IRNODE")) {
				
				timerName += "IRNODE";
				
    			jobDTO = this.jobManagerBeanLocal.getJobByName("RTR_NIR_REQ_ALIGN");
			}
			else if(instrumentType.equalsIgnoreCase("F")) {
				
				timerName += "F";
				
    			jobDTO = this.jobManagerBeanLocal.getJobByName("RTR_FCP_REQ_ALIGN");
			}
			else {
				
				throw new Exception("Not valid instrument type \'" + instrumentType + "\'.");
			}
			
		}
		else if(provider.equalsIgnoreCase("Bloomberg")) {
			
			timerName += "BLOOMBERG_";
			
			if(instrumentType.equalsIgnoreCase("C")) {
				
				timerName += "C";
    			
    			jobDTO = this.jobManagerBeanLocal.getJobByName("BBG_CURR_REQ_ALIGN");
			}
			else if(instrumentType.equalsIgnoreCase("IRNODE")) {
				
				timerName += "IRNODE";
    			
    			jobDTO = this.jobManagerBeanLocal.getJobByName("BBG_NIR_REQ_ALIGN");
			}
			else {
				
				throw new Exception("Not valid instrument type \'" + instrumentType + "\'.");
			}
			
		}
		else {
			
			throw new Exception("Not valid provider \'" + provider + "\'.");
		}
		
		
		String provider = (String)valueMap.get("provider");
		String instrumentType = (String)valueMap.get("instrumentType");
		
		JobDTO jobDTO = this.jobManagerBeanLocal.getJobBy_Provider_DataType_JobType(provider, instrumentType, JobType.REQ_ALIGN);
		
		// check if jobDTO != null
		if(jobDTO == null) {
			
			throw new Exception("Job not found for [provider: \'" + provider + "\', instrumentType: " + instrumentType + "].");
		}
		
		String timerName = "updateRequest_" + provider + "_" + instrumentType;
		
		// Delete if it already exists
		if(this.timerBeanLocal.getTimer(timerName) != null) {
			
			this.timerBeanLocal.deleteTimer(timerName);
		}
		
		TimerDTO timerDTO = new TimerDTO(timerName, true, new Date(System.currentTimeMillis() + 60*1000), provider, jobDTO);
		
		this.timerBeanLocal.createSingleActionTimer(timerDTO);
	}
	*/
	
}
