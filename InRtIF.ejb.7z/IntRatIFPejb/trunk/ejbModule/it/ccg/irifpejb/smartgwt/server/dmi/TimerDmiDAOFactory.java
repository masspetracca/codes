package it.ccg.irifpejb.smartgwt.server.dmi;

import it.ccg.irifpejb.server.system.LocalBeanLookup;

public class TimerDmiDAOFactory {
	
	
	public TimerDmiDAOFactory() {
		
	}
	
	
	
	public TimerDmiDAOLocal create() throws Exception {
        
        TimerDmiDAOLocal timerDmiDAOLocal = (TimerDmiDAOLocal)LocalBeanLookup.lookup(TimerDmiDAOLocal.class.getName());
		
		return timerDmiDAOLocal;
	}

}
