package it.ccg.irifpejb.smartgwt.server.dmi;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;

public interface HistoricalRatingDmiEAOLocal {

	public DSResponse fetch(DSRequest dsRequest) throws Exception;
}
