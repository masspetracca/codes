package it.ccg.irifpejb.smartgwt.server.util;



public class JpaQuery {
	
	private String selectClause;
	private String fromClause;
	private String whereClause;
	private String groupByClause;
	private String havingClause;
	private String orderByClause;
	
	
	public JpaQuery() {
		
		super();
	}
	
	
	public JpaQuery(String selectClause, String fromClause, String whereClause, String groupByClause, String havingClause, String orderByClause) {
		
		this.selectClause = selectClause;
		this.fromClause = fromClause;
		this.whereClause = whereClause;
		this.groupByClause = groupByClause;
		this.havingClause = havingClause;
		this.orderByClause = orderByClause;
	}


	public String getSelectClause() {
		return selectClause;
	}


	public void setSelectClause(String selectClause) {
		this.selectClause = selectClause;
	}


	public String getFromClause() {
		return fromClause;
	}


	public void setFromClause(String fromClause) {
		this.fromClause = fromClause;
	}


	public String getWhereClause() {
		return whereClause;
	}


	public void setWhereClause(String whereClause) {
		this.whereClause = whereClause;
	}


	public String getGroupByClause() {
		return groupByClause;
	}


	public void setGroupByClause(String groupByClause) {
		this.groupByClause = groupByClause;
	}


	public String getHavingClause() {
		return havingClause;
	}


	public void setHavingClause(String havingClause) {
		this.havingClause = havingClause;
	}


	public String getOrderByClause() {
		return orderByClause;
	}


	public void setOrderByClause(String orderByClause) {
		this.orderByClause = orderByClause;
	}
	
	
	@Override
	public String toString() {
		
		return this.selectClause + " " +
			   this.fromClause + " " +
			   this.whereClause + " " +
			   this.groupByClause + " " +
			   this.havingClause + " " +
			   this.orderByClause;
	}
	
	
}
