package it.ccg.irifpejb.smartgwt.server.dmi;

import it.ccg.irifpejb.server.system.LocalBeanLookup;

public class IssuesDmiEAOFactory {
	
	
	public IssuesDmiEAOFactory() {
		
	}
	
	public IssuesDmiEAOLocal create() throws Exception {

		IssuesDmiEAOLocal issuesDmiEAOLocal = (IssuesDmiEAOLocal)LocalBeanLookup.lookup(IssuesDmiEAOLocal.class.getName());
		
		return issuesDmiEAOLocal;
	}

}