package it.ccg.irifpejb.smartgwt.server.dmi;

import it.ccg.irifpejb.server.system.LocalBeanLookup;

public class VarsDmiEAOFactory {
	
	
	public VarsDmiEAOFactory() {
		
	}
	
	
	
	public VarsDmiEAOLocal create() throws Exception {

		VarsDmiEAOLocal varsDmiEAOLocal = (VarsDmiEAOLocal)LocalBeanLookup.lookup(VarsDmiEAOLocal.class.getName());
		
		return varsDmiEAOLocal;
	}

}
