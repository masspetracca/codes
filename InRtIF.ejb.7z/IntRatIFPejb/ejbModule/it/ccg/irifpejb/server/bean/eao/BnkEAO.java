package it.ccg.irifpejb.server.bean.eao;

import javax.ejb.Local;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class BnkEAO
 */
@Stateless
@Local(BnkEAOLocal.class)
public class BnkEAO implements BnkEAOLocal {

    /**
     * Default constructor. 
     */
    public BnkEAO() {
        // TODO Auto-generated constructor stub
    }

}
