package it.ccg.irifpejb.server.bean.entity.custom;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Transient;


@Entity
public class VarHHis implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Transient
	private BigDecimal varvalue;
	@Transient
	private Date valuedate;
	

	public VarHHis() {
		
	}
	
	
	public VarHHis(Date valuedate, BigDecimal varvalue) {
		
		this.varvalue = varvalue;
		this.valuedate = valuedate;
	}


	public BigDecimal getVarvalue() {
		return varvalue;
	}


	public void setVarvalue(BigDecimal varvalue) {
		this.varvalue = varvalue;
	}


	public Date getValuedate() {
		return valuedate;
	}


	public void setValuedate(Date valuedate) {
		this.valuedate = valuedate;
	}


	
   
}
