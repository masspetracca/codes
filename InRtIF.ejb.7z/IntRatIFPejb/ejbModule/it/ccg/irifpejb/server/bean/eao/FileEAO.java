package it.ccg.irifpejb.server.bean.eao;



import it.ccg.irifpejb.server.bean.entity.FileEntity;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class FTPFileEAO
 */
@SuppressWarnings("unchecked")
@Stateless(mappedName = "FTPFileEAO")
public class FileEAO implements FileEAOLocal {

	@PersistenceContext(unitName = "IntRatIFPejb", type = PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Resource
	private SessionContext sessionContext;
	
	private String tableName = ((Table)(FileEntity.class.getAnnotation(Table.class))).name();
	
    /**
     * Default constructor. 
     */
    public FileEAO() throws Exception {
    	
    }
	
	@Override
	public List<FileEntity> fetch() throws Exception {
		
		Query query = em.createNamedQuery("fetchAllFtpFiles");
		
		return (List<FileEntity>)query.getResultList();
	}

	@Override
	public FileEntity findByPrimaryKey(int fileId) throws Exception {
		
		return (FileEntity)em.find(FileEntity.class, fileId);
	}
	
	
	@Override
	public FileEntity findByName(String fileName) throws Exception {
		
		Query query = em.createNamedQuery("fetchByName");
		query.setParameter("fileName", fileName);
		
		FileEntity fileEntity = null;
		List<FileEntity> list = (List<FileEntity>)query.getResultList();
		if(list.size() != 0) {
			fileEntity = list.get(0);
		}
		
		return fileEntity;
	}
	

	@Override
	public FileEntity add(FileEntity fileEntity) throws Exception {
		
		// set current user
		fileEntity.setUpdusr(this.sessionContext.getCallerPrincipal().getName());
		
		em.persist(fileEntity);
		
		logger.info(new StandardLogMessage("Persisted data into \'" + this.tableName + "\'. " + fileEntity));
		
		
		return fileEntity;
	}


	@Override
	public void update(FileEntity fileEntity) throws Exception {
		
		// TODO
	}

	@Override
	public void remove(FileEntity fileEntity) throws Exception {
		
		FileEntity temp = findByPrimaryKey(fileEntity.getFileId());
		
		em.remove(temp);
		
		
		logger.info(new StandardLogMessage("Deleted data into \'" + this.tableName + "\'. " + fileEntity));
		
	}

}
