package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the RCTBNKFTCT database table.
 * 
 */
@Entity
@Table(name="PAMPTEST.RCTBNKFTCT")
public class BnkFtcTEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private BnkFtcTEntityPK id;
	
	@Column(nullable=false, length=20)
	private String accountsys;

	@Column(unique=true, nullable=false, length=50)
	private String fitchnname;

	@Column(nullable=false, length=1)
	private String isconsolid;

	@Column(nullable=false)
	private Timestamp latestper;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

    public BnkFtcTEntity() {
    }

	public String getAccountsys() {
		return this.accountsys;
	}

	public void setAccountsys(String accountsys) {
		this.accountsys = accountsys;
	}

	public String getFitchnname() {
		return this.fitchnname;
	}

	public void setFitchnname(String fitchnname) {
		this.fitchnname = fitchnname;
	}

	public String getIsconsolid() {
		return this.isconsolid;
	}

	public void setIsconsolid(String isconsolid) {
		this.isconsolid = isconsolid;
	}

	public Timestamp getLatestper() {
		return this.latestper;
	}

	public void setLatestper(Timestamp latestper) {
		this.latestper = latestper;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

	/**
	 * @return the id
	 */
	public BnkFtcTEntityPK getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(BnkFtcTEntityPK id) {
		this.id = id;
	}

}