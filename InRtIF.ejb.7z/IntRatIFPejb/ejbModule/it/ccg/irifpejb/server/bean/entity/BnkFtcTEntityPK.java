package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class BnkFtcTEntityPK implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -418304440365854458L;
	
	@Column(unique=true, nullable=false)
	private String fitchCode;
	
	@Column(unique=true, nullable=false)
	private String fitchNickName;

	/**
	 * @return the fitchCode
	 */
	public String getFitchCode() {
		return fitchCode;
	}

	/**
	 * @param fitchCode the fitchCode to set
	 */
	public void setFitchCode(String fitchCode) {
		this.fitchCode = fitchCode;
	}

	/**
	 * @return the fitchNickName
	 */
	public String getFitchNickName() {
		return fitchNickName;
	}

	/**
	 * @param fitchNickName the fitchNickName to set
	 */
	public void setFitchNickName(String fitchNickName) {
		this.fitchNickName = fitchNickName;
	}
	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof BnkFtcTEntityPK)) {
			return false;
		}
		BnkFtcTEntityPK castOther = (BnkFtcTEntityPK)other;
		return 
			(this.fitchCode == castOther.fitchCode )&& this.fitchNickName.equals(castOther.fitchNickName);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.fitchCode.hashCode();
		hash = hash * prime + this.fitchNickName.hashCode();
		
		return hash;
    }
}