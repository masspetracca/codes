package it.ccg.irifpejb.server.file.template;

import java.util.List;

public class FitchResponseTemplate {
	
	
	List<Object[]> data;
	List<Object[]> codes;
	
	
	public FitchResponseTemplate(List<Object[]> data, List<Object[]> codes) {
		
		this.data = data;
		this.codes = codes;
	}
	
	
	public List<Object[]> getData() {
		return data;
	}
	
	public void setData(List<Object[]> data) {
		this.data = data;
	}
	
	public List<Object[]> getCodes() {
		return codes;
	}
	
	public void setCodes(List<Object[]> codes) {
		this.codes = codes;
	}
	

}
