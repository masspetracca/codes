package it.ccg.irifpejb.smartgwt.server.dmi;

import it.ccg.irifpejb.server.system.LocalBeanLookup;

public class VarHDmiEAOFactory {
	
	
	public VarHDmiEAOFactory() {
		
	}
	
	
	
	public VarHDmiEAOLocal create() throws Exception {

		VarHDmiEAOLocal hisPrDmiEAOLocal = (VarHDmiEAOLocal)LocalBeanLookup.lookup(VarHDmiEAOLocal.class.getName());
		
		return hisPrDmiEAOLocal;
	}

}
