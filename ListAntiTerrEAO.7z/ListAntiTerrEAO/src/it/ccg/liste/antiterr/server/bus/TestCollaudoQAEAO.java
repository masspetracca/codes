package it.ccg.liste.antiterr.server.bus;

public class TestCollaudoQAEAO {

	public TestCollaudoQAEAO(int returnCode) {
		// TODO Auto-generated constructor stub
	}
	public TestCollaudoQAEAO() {
		// TODO Auto-generated constructor stub
	}
	public String getKeyId() {
		return keyId;
	}
	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}
	public String getKeyDate() {
		return keyDate;
	}
	public void setKeyDate(String keyDate) {
		this.keyDate = keyDate;
	}
	public String getKeyProg() {
		return keyProg;
	}
	public void setKeyProg(String keyProg) {
		this.keyProg = keyProg;
	}
	public String getOpenUrl() {
		return openUrl;
	}
	public void setOpenUrl(String openUrl) {
		this.openUrl = openUrl;
	}
	public String getNodeName() {
		return nodeName;
	}
	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}
	public String getNodeType() {
		return nodeType;
	}
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}
	public String getNodeValue() {
		return nodeValue;
	}
	public void setNodeValue(String nodeValue) {
		this.nodeValue = nodeValue;
	}
	public String getChildName() {
		return childName;
	}
	public void setChildName(String childName) {
		this.childName = childName;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String keyId;
	public String keyDate;
	public String keyProg;
	public String openUrl;
	public String nodeName;
	public String nodeType;
	public String nodeValue;
	public String childName;
	public String action;
	public String note;

}
