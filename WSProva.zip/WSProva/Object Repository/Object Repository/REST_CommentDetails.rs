<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>REST_CommentDetails</name>
   <tag></tag>
   <elementGuidId>55f9a29e-6134-4dff-804e-058dae614e1b</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
