<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>POST</name>
   <tag></tag>
   <elementGuidId>01ff2c22-783d-4ebb-83df-f3cffd772a0b</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;{\n\n \&quot;meta\&quot;: {\n\n   \&quot;code\&quot;: 200\n\n },\n\n \&quot;data\&quot;: [\n\n   {\n\n     \&quot;latitude\&quot;: 40.714198749,\n\n     \&quot;id\&quot;: \&quot;93496093\&quot;,\n\n     \&quot;longitude\&quot;: 74.006001183,\n\n     \&quot;name\&quot;: \&quot;John\u0027s Pizzeria 278 Bleecker St NY, NY\&quot;\n\n   },\n\n   {\n\n     \&quot;latitude\&quot;: 40.7142,\n\n     \&quot;id\&quot;: \&quot;46371155\&quot;,\n\n     \&quot;longitude\&quot;: 74.0064,\n\n     \&quot;name\&quot;: \&quot;Thunderpocalypse 2012\&quot;\n\n   },\n\n   {\n\n     \&quot;latitude\&quot;: 40.714201754,\n\n     \&quot;id\&quot;: \&quot;35932492\&quot;,\n\n     \&quot;longitude\&quot;: 74.006397137,\n\n     \&quot;name\&quot;: \&quot;Avenue of the Americas, New York\&quot;\n\n   },\n\n   {\n\n     \&quot;latitude\&quot;: 40.71296389,\n\n     \&quot;id\&quot;: \&quot;1023103828\&quot;,\n\n     \&quot;longitude\&quot;: 74.00388611,\n\n     \&quot;name\&quot;: \&quot;Manhattan Municipal Building\&quot;\n\n   },\n\n   {\n\n     \&quot;latitude\&quot;: 40.71322,\n\n     \&quot;id\&quot;: \&quot;92582758\&quot;,\n\n     \&quot;longitude\&quot;: 74.003963,\n\n     \&quot;name\&quot;: \&quot;Sleepers Filming Location\&quot;\n\n   },\n\n   {\n\n     \&quot;latitude\&quot;: 40.716833,\n\n     \&quot;id\&quot;: \&quot;97921846\&quot;,\n\n     \&quot;longitude\&quot;: 74.005833,\n\n     \&quot;name\&quot;: \&quot;Atera\&quot;\n\n   }\n\n ]\n\n}&quot;,
  &quot;contentType&quot;: &quot;application/xml&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/xml</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>http://localhost:3000/posts?=&amp;=&amp;=&amp;=&amp;=&amp;=&amp;=</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()
</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
