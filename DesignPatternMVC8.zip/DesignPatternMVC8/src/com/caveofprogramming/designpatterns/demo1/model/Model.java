package com.caveofprogramming.designpatterns.demo1.model;

public class Model {

}
