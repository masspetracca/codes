
public class Bankaccount {
	
	private String name;
	private double balance;
	
	public Bankaccount(String name, double balance)
	throws NegativeAmountException
	{
	// set name and balance
		this.setName(name);
		this.setBalance(balance);
		
	// make sure balance is not negative
		if (balance > 0) {
			this.setBalance(balance);
		}
	// throw exception if balance is negative
		System.out.println("balance is negative");
	}
	public Bankaccount(String name)
		throws NegativeAmountException
	{
	// set name and use 0 balance
		balance = 0;
		this.name = name;
	}
	public void setBalance(double balance) {
		this.balance = balance;		
	}
	public double getBalance() {
		return balance;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
}
