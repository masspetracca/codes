
public class DepositLogic {
	public void deposit(double amount) throws NegativeAmountException {
	// update balance by subtracting withdrawal amount
	// throw exception if funds are not sufficient
	// make sure withdrawal amount is not negative
	// throw NegativeAmountException if amount is negative
	// throw InsufficientFundsException if balance < amount
	}

	public void withdraw(double amount)
	throws InsufficientFundsException, NegativeAmountException {
	// return current balance
	}
	public double getBalance() {
	// print bank statement including customer name
	// and current account balance 
		return 0;
	}
	public void printStatement(){
	}

}
