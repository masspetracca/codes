INSERT INTO PAMPTEST.PMANXXXS(MAID, MAPRO, MAREPO, MAHAND, MAPRIO, MASEVE, MAREPR, MASTAT, MARESL, MAPROJ, MARECA, MADASU, MALAUP, MAETA, MAVSTA, MASUMM, MADUED, MADESC)
  VALUES(14578, 'Sviluppo Java', 'mpetracc', 'fnelli', 'urgent', 'minor', 'N/A', 'PAMP 2.0', 'PAMP', 'Aug 06 2014', '', '', '', 'public', 'Aug 06 2014', 'Report - problema dati back test obbligazionario', 'assigned', 'open')
GO
INSERT INTO PAMPTEST.PMANXXXS(MAID, MAPRO, MAREPO, MAHAND, MAPRIO, MASEVE, MAREPR, MASTAT, MARESL, MAPROJ, MARECA, MADASU, MALAUP, MAETA, MAVSTA, MASUMM, MADUED, MADESC)
  VALUES(14561, 'Sviluppo Java', 'mpetracc', 'dbuffoni', 'low', 'minor', 'N/A', 'PAMP 2.0', 'PAMP', 'Aug 04 2014', '', '', '', 'public', 'Aug 04 2014', 'PAMP 2.0.1 - PUN BASELOAD/PEAKLOAD', 'assigned', 'open')
GO
INSERT INTO PAMPTEST.PMANXXXS(MAID, MAPRO, MAREPO, MAHAND, MAPRIO, MASEVE, MAREPR, MASTAT, MARESL, MAPROJ, MARECA, MADASU, MALAUP, MAETA, MAVSTA, MASUMM, MADUED, MADESC)
  VALUES(14554, 'Sviluppo Java', 'mpetracc', 'fnelli', 'normal', 'minor', 'N/A', 'PAMP 2.0', 'PAMP', 'Aug 01 2014', '', '', '', 'public', 'Aug 01 2014', 'PAMP 2.0.1: Alerter: Default fund exceeded - prevedere soglia % per il Default Found.', 'assigned', 'open')
GO
INSERT INTO PAMPTEST.PMANXXXS(MAID, MAPRO, MAREPO, MAHAND, MAPRIO, MASEVE, MAREPR, MASTAT, MARESL, MAPROJ, MARECA, MADASU, MALAUP, MAETA, MAVSTA, MASUMM, MADUED, MADESC)
  VALUES(14385, 'Sviluppo Java', 'mpetracc', 'dbuffoni', 'normal', 'minor', 'N/A', 'PAMP 2.0', 'PAMP', 'Jul 10 2014', '', '', '', 'public', 'Jul 31 2014', 'PAMP Alerter: Default fund exceeded.', 'assigned', 'open')
GO
INSERT INTO PAMPTEST.PMANXXXS(MAID, MAPRO, MAREPO, MAHAND, MAPRIO, MASEVE, MAREPR, MASTAT, MARESL, MAPROJ, MARECA, MADASU, MALAUP, MAETA, MAVSTA, MASUMM, MADUED, MADESC)
  VALUES(14462, 'Sviluppo Java', 'mpetracc', 'dbuffoni', 'low', 'minor', 'N/A', 'Reporting 2.0', 'Reporting', 'Jul 23 2014', 'Host System: 10.0.10.10', '', '', 'public', 'Jul 23 2014', 'Report MIC e Stress test: Alcune modifiche da apportare', 'assigned', 'open')
GO
INSERT INTO PAMPTEST.PMANXXXS(MAID, MAPRO, MAREPO, MAHAND, MAPRIO, MASEVE, MAREPR, MASTAT, MARESL, MAPROJ, MARECA, MADASU, MALAUP, MAETA, MAVSTA, MASUMM, MADUED, MADESC)
  VALUES(14458, 'Sviluppo Java', 'mpetracc', 'dbuffoni', 'urgent', 'minor', 'N/A', 'PAMP 2.0', 'PAMP', 'Jul 23 2014', '', '', '', 'public', 'Jul 23 2014', 'PAMP - Stress Test Bond. Partecipanti ICSD sono esclusi dai nostri stress test.', 'assigned', 'open')
GO
INSERT INTO PAMPTEST.PMANXXXS(MAID, MAPRO, MAREPO, MAHAND, MAPRIO, MASEVE, MAREPR, MASTAT, MARESL, MAPROJ, MARECA, MADASU, MALAUP, MAETA, MAVSTA, MASUMM, MADUED, MADESC)
  VALUES(14162, 'Sviluppo Java', 'dbuffoni', 'dbuffoni', 'normal', 'minor', 'have not tried', 'Reporting 2.0', 'Reporting', 'Jun 17 2014', '', '', '', 'public', 'Jul 10 2014', 'Report stress test con cover 4 e report bt e st per partecipanti', 'assigned', 'open')
GO
INSERT INTO PAMPTEST.PMANXXXS(MAID, MAPRO, MAREPO, MAHAND, MAPRIO, MASEVE, MAREPR, MASTAT, MARESL, MAPROJ, MARECA, MADASU, MALAUP, MAETA, MAVSTA, MASUMM, MADUED, MADESC)
  VALUES(14277, 'Sviluppo Java', 'dbuffoni', 'dbuffoni', 'normal', 'minor', 'have not tried', 'Reporting 2.0', 'PAMP', 'Jun 27 2014', '', '', '', 'public', 'Jul 10 2014', 'Report non funzionanti', 'assigned', 'open')
GO
INSERT INTO PAMPTEST.PMANXXXS(MAID, MAPRO, MAREPO, MAHAND, MAPRIO, MASEVE, MAREPR, MASTAT, MARESL, MAPROJ, MARECA, MADASU, MALAUP, MAETA, MAVSTA, MASUMM, MADUED, MADESC)
  VALUES(14204, 'Sviluppo Java', 'rdelauri', 'dbuffoni', 'high', 'block', 'always', '', 'InfoProviders', 'Jun 20 2014', '', '', '', 'public', 'Jul 10 2014', 'Errore procedura bloomberg NIR su infoprovider', 'assigned', 'fixed')
GO
INSERT INTO PAMPTEST.PMANXXXS(MAID, MAPRO, MAREPO, MAHAND, MAPRIO, MASEVE, MAREPR, MASTAT, MARESL, MAPROJ, MARECA, MADASU, MALAUP, MAETA, MAVSTA, MASUMM, MADUED, MADESC)
  VALUES(14181, 'Sviluppo Java', 'rdelauri', 'dbuffoni', 'normal', 'feature', 'N/A', '', 'InfoProviders', 'Jun 18 2014', '', '', '', 'public', 'Jul 10 2014', 'Curve da censire in Pamp', 'assigned', 'open')
GO
INSERT INTO PAMPTEST.PMANXXXS(MAID, MAPRO, MAREPO, MAHAND, MAPRIO, MASEVE, MAREPR, MASTAT, MARESL, MAPROJ, MARECA, MADASU, MALAUP, MAETA, MAVSTA, MASUMM, MADUED, MADESC)
  VALUES(14312, 'Sviluppo Java', 'mpetracc', 'dbuffoni', 'normal', 'minor', 'have not tried', 'Reporting 2.0', 'PAMP', 'Jul 01 2014', '', '', '', 'public', 'Jul 10 2014', 'Internal Rating:  bilanci delle banche  abilitate.', 'assigned', 'open')
GO
