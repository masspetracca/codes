package it.interfaceabstraction.com;

public class InterfaceDemo1 {
	private static String engineType = "6 Cyl";

	public static void main(String [] args) {
		CarsInterface myInterface = new InterfaceDemo();
		myInterface.engineStart(engineType , true);
	}
}
