package it.interfaceabstraction.com;


public class Honda extends Cars {
	
	public Honda (int startSpeed) {
		super(startSpeed);
	}

	@Override
	public void increaseSpeed() {
		protectedSpeed++;
		Cars c1 = new Cars();
		c1.decreaseSpeed();
		System.out.println("Increasing Speed of Honda");
	}
	
	public void headupDisplayNavigation() {
		System.out.println("Honda Specific Functionality");
	}
	
	public void stop() {
		Cars c1 = new Cars();
		c1.decreaseSpeed();
	}
}
