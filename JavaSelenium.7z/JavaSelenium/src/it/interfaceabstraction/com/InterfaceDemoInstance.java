package it.interfaceabstraction.com;

public class InterfaceDemoInstance {

	public static void main(String[] args) {
		CarsInterface myInterface = new InterfaceDemo();
		myInterface.engineStart("6 Cyl", true);
	}
}
