package it.interfaceabstraction.com;

public interface CarsInterface {

	public String speed = "100";
	
	void engineStart(String engineType, boolean isKeyLess);
}	
