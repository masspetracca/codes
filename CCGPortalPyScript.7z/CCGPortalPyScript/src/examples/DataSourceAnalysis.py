'''
Questo script frnisce comode informazioni di utilizzo dei DataSource su progetti SmartGWT
per lanciarlo e' sufficiente copiarlo nella root del progetto ed eseguirlo

@author: buffoni
'''


from xml.dom.minidom import parse, Node
import os,fnmatch
import re

#ListDir
#-------------------------------------------------------------
#ottiene la lista dei file con estensione .java presenti nella dir
# e in tutte le sue subdir
def listdir(root, path=""):
    # recursive listdir
    files = []
    try:
        for file in os.listdir(os.path.join(root, path)):
            pathname = os.path.join(path, file)
            fullFilePath=os.path.join(root, pathname)
            if os.path.isdir(fullFilePath):
                files.extend(listdir(root, pathname))
            elif fnmatch.fnmatchcase(fullFilePath, '*.java') :
                files.append(pathname)
    except OSError:pass
    return files

#Apre i file di output
f1 = open('report/datasources_implementation.txt', 'w')
f4 = open('report/databindings_implementation.txt', 'w')
f2 = open('report/datasources_schemas.txt', 'w')
f3 = open('report/datasources_bindings.txt', 'w')
log = open('report/log.txt', 'w')

#DataSource implementation
#-------------------------------------------------------------

#Scrive intestazione
f1.writelines('ID'+'\t'+'FileName'+'\n')

i=0
usedIdList=['batchUpload'] #batchUpload is always used
for file in listdir(os.curdir,"src"): 
    text = open(file).read()
    datasources = re.findall('DataSource.get[A-Za-z]{0,10}\(\"(.*)\"\)', text)
    for ds in datasources: 
        if usedIdList.count(ds)==0:
            usedIdList.append(ds)
        f1.writelines(ds+'\t'+file+'\n')
        i+=1
print('datasources_implementation.txt: written '+str(i)+' lines')
log.writelines('datasources_implementation.txt: written '+str(i)+' lines'+'\n')

#Databindings implementation
#-------------------------------------------------------------

#Scrive intestazione
f4.writelines('BindingID'+'\t'+'FileName'+'\n')

i=0
usedBindIdList=[] #lista dei bindings utilizzati
for file in listdir(os.curdir,"src"): 
    text = open(file).read()
    bindings = re.findall('\.set[A-Za-z]{0,10}Operation\(\"(.*)\"\)', text)
    bindings+=re.findall('\.setOperationId\(\"(.*)\"\)', text)
    bindings+=re.findall('\.setOptionOperationId\(\"(.*)\"\)', text)
    for bind in bindings: 
        if usedBindIdList.count(bind)==0:
            usedBindIdList.append(bind)
        f4.writelines(bind+'\t'+file+'\n')
        i+=1
print('databindings_implementation.txt: written '+str(i)+' lines')
log.writelines('databindings_implementation.txt: written '+str(i)+' lines'+'\n')


#DataSchemaAnalysis
#-------------------------------------------------------------

#DS PATH
dspath='war\ds'
#ottiene la lista di files nella directory corrente
path =os.path.join(os.path.abspath(os.curdir),dspath)
files = os.listdir(path)
#Apre il file di output

#Scrive l'intestazione
f2.writelines('ID'+'\t'+'tableName'+'\t'+'name'+'\t'+'title'+'\t'+'type'+'\t'+ 'length' +'\t'+ 'width'+'\t'+'detail'+'\t'+ 'primaryKey'+'\t'+ 'customSQL'+'\t'+ 'tableName' +'\n')
#cicla sui files .xml
i=0
notUsedIdList=[]
for filename in fnmatch.filter(files, '*.xml'):
    #parsa il file
    xmltree = parse(os.path.join(path,filename))
    #prende gli attibuti del nodo principale, il datasource
    for dsNode in xmltree.getElementsByTagName('DataSource'):
        tableAttr=dsNode.getAttribute('tableName').upper()
        idAttr=str(dsNode.getAttribute('ID'))
        if notUsedIdList.count(idAttr)==0 and usedIdList.count(idAttr)==0:
            notUsedIdList.append(idAttr)
        #prende gli attributi dei nodi figli
        for fieldNode in xmltree.getElementsByTagName('field'):
            i+=1
            fieldNameAttr=fieldNode.getAttribute('name')
            fieldTitleAttr=fieldNode.getAttribute('title')
            fieldTypeAttr=fieldNode.getAttribute('type')
            fieldLenAttr=fieldNode.getAttribute('length')
            fieldWidthAttr=fieldNode.getAttribute('width')
            fieldDetailAttr=fieldNode.getAttribute('detail')
            fieldPKAttr=fieldNode.getAttribute('primaryKey')
            custSQLAttr=fieldNode.getAttribute('customSQL')
            tableNameAttr=fieldNode.getAttribute('tableName').upper()
            f2.writelines(idAttr+'\t'+tableAttr+'\t'+fieldNameAttr+'\t'+fieldTitleAttr+'\t'+fieldTypeAttr+'\t'+ fieldLenAttr + '\t'+ fieldWidthAttr+'\t'+fieldDetailAttr+'\t'+ fieldPKAttr+'\t'+ custSQLAttr+'\t'+ tableNameAttr +'\n')
print('datasources_schemas.txt: written '+str(i)+' lines')
log.writelines('datasources_schemas.txt: written '+str(i)+' lines'+'\n')

#DataBindings analysys
#-------------------------------------------------------------
#Scrive l'intestazione
f3.writelines('ID'+'\t'+'MainTable'+'\t'+'OperationId'+'\t'+'OperationType'+'\t'+'Clauses'+'\t'+'Tables'+'\n')
#cicla sui files .xml
i=0
notUsedBindIdList=[]
for filename in fnmatch.filter(files, '*.xml'):
    #parsa il file
    xmltree = parse(os.path.join(path,filename))
    #prende gli attibuti del nodo principale, il datasource
    for dsNode in xmltree.getElementsByTagName('DataSource'):
        tableAttr=dsNode.getAttribute('tableName')
        idAttr=str(dsNode.getAttribute('ID'))
        
        #prende gli attributi dei nodi figli
        for fieldNode in xmltree.getElementsByTagName('operationBinding'):
            i+=1
            fieldOperationId=fieldNode.getAttribute('operationId')
            if notUsedBindIdList.count(fieldOperationId)==0 and usedBindIdList.count(fieldOperationId)==0:
                notUsedBindIdList.append(fieldOperationId)
            if fieldOperationId=='':
                fieldOperationId='DEFAULT'
            fieldOperationType=fieldNode.getAttribute('operationType').lower()
            clausesNodes=fieldNode.childNodes
            clauseList=''
            tableString=''
            for clauseNode in clausesNodes:
                if clauseNode.nodeType!=1:
                    continue
                if clauseList!='':
                    clauseList+=','
                clauseList+=clauseNode.nodeName
                if clauseNode.nodeName=='tableClause':
                    tableString=clauseNode.firstChild.nodeValue.replace('\n','').replace('\t','').replace(' ','').upper()
            f3.writelines(idAttr+'\t'+tableAttr.upper()+'\t'+fieldOperationId+'\t'+fieldOperationType+'\t'+clauseList+'\t'+tableString+'\n')
print('datasources_bindings.txt: written '+str(i)+' lines')
log.writelines('datasources_bindings.txt: written '+str(i)+' lines'+'\n')

usedIdList.sort()
notUsedIdList.sort()

usedBindIdList.sort()
notUsedBindIdList.sort()
if notUsedBindIdList[0]=='':
    notUsedBindIdList=notUsedBindIdList[1:]
    

log.writelines('\nDataSource list for index.html\n')
i=0
for id in usedIdList:
    if i>0: 
        log.writelines(',' + id)
    else:
        log.writelines(id)
    i+=1
log.writelines('<!--')
for id in notUsedIdList:
    log.writelines(',' + id)
log.writelines('-->\n')   

log.writelines('\nDataSource list (X) indicates USED\n')
for id in usedIdList:
    log.writelines(id +'\tX\n')
for id in notUsedIdList:
    log.writelines(id +'\n')


log.writelines('\nBindings list (X) indicates USED\n')
for id in usedBindIdList:
    log.writelines(id +'\tX\n')
for id in notUsedBindIdList:
    log.writelines(id +'\n')

 
print('End')


f2.close()
f1.close()
f3.close()
log.close()







