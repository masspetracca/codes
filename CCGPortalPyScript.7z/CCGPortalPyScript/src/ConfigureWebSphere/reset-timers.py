'''
Created on 17/feb/2011

@author: buffoni

Questo script effettua un reset delle colonne identity, aggiornare la lista delle table column
 
'''



import pyodbc 
print '--- Sript started'

table_column=[('PMPTANREG','ANCODE'),('PMPTCORPAC','CAID'),('PMPTGROUP','GRID'),('PMPTINSTR','INSTRID'),('PMPTLOGACT','ACTID'),('PMPTRC','RCCODE'),('PMPTSCHED','PRCID'),('PMPTSETS','SETID'),('PMPXCONF','UPDID'),('PMPXCONFDF','UPDID'),('PMPXCORPAC','UPDID'),('PMPXDELTA','UPDID'),('PMPXDELTDF','UPDID'),('PMPXGROUP','UPDID'),('PMPXHISDE','UPDID'),('PMPXHISPR','UPDID'),('PMPXINSTR','UPDID'),('PMPXMAR','UPDID'),('PMPXMINMAR','UPDID'),('PMPXPER','UPDID'),('PMPXPERDF','UPDID'),('PMPXSCHED','UPDID'),('PMPXSETPAR','UPDID'),('PMPXSETS','UPDID'),('PMPXSETUP','UPDID'),('PMPXSPREAD','UPDID'),('PMPXSTRA','UPDID')]
odbc_sources=['DSN=ROMA-PROD;PWD=ndapc1pFC','DSN=ROMA-SVIL;PWD=ndapc1pFC','DSN=ROMA-BKP;PWD=ndapc1pFC','DSN=ROMA-DR;PWD=ndapc1pFC']

for odbc in odbc_sources:
    print '\nConnecting to %s' % odbc
    conn = pyodbc.connect(odbc,autocommit=True)
    print 'Connected to %s\n' % odbc
    curs = conn.cursor() 
    for c in table_column:
        query='select max('+c[1]+') from '+c[0]
        print '\nExecuting query: '+query
        curs.execute(query)
        record=curs.fetchall()[0][0]
        max_instrid=0
        if record is not None:
            max_instrid=record+1
        query='ALTER TABLE '+c[0]+' ALTER COLUMN '+c[1]+' RESTART WITH '+str(max_instrid)
        print 'Executing query: '+query
        curs.execute(query)
        print 'Table '+c[0]+': counter of column '+c[1]+' restarted from '+str(max_instrid)

print '\n--- Sript correctly executed'




 


