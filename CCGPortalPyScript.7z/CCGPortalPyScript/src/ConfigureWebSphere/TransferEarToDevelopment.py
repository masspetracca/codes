#lanciare tramite il seguente comando (configurare host, porta e utenza)
import ftplib



#Installazione backup environment
user='buffoni'
pwd='facile01'
server='10.0.10.240'
source='C:/buffoni/deploy/CCGPortal.ear'
destination='/pampweb/test/CCGPortal.ear'

print '*****Start script*****'

s = ftplib.FTP(server,user,pwd)

f = open(source,'rb')               
s.storbinary('STOR '+destination, f)        

f.close()                               
s.quit()


print '\n*****End script*****'
