#Installazione production nella macchina di sviluppo (lasciato voulutamente vuoto)

print '*****Start script*****'

print '\n- No deploy'

print '\n*****End script*****'
