#lanciare tramite il seguente comando (configurare host, porta e utenza)
#/QIBM/UserData/WebSphere/AppServer/V7/ND/profiles/PAMP_WEB/bin/wsadmin -lang jython -f /pampweb/install-portal-test.py -conntype SOAP -port 10006 -host 10.0.10.240 -username usr -password pwd

#Installazione backup environment
node='C65BD99F_PAMP_WEB'
cell='C65BD99F_PAMP_WEB'
server='PAMP_WEB'
file='/pampweb/produzione/CCGPortal.ear'

print '*****Start script*****'

AdminApp.update('CCGPortal', 'app', '[ -operation update \
    -contents '+file+' \
    -nopreCompileJSPs \
    -installed.ear.destination /PampWeb \
    -distributeApp \
    -nouseMetaDataFromBinary \
    -nodeployejb \
    -createMBeansForResources \
    -noreloadEnabled \
    -nodeployws \
    -validateinstall warn \
    -processEmbeddedConfig \
    -filepermission .*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755 \
    -noallowDispatchRemoteInclude \
    -noallowServiceRemoteInclude \
    -asyncRequestDispatchType DISABLED \
    -nouseAutoLink \
    -MapModulesToServers [[ CCGPortalEJB CCGPortalEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cell+',node='+node+',server='+server+' ][ PampWeb PampWeb.war,WEB-INF/web.xml WebSphere:cell='+cell+',node='+node+',server='+server+' ]]]' ) 

#Salvataggio configurazione
AdminConfig.save()
print '\n- Configuration saved'

print '\n*****End script*****'
