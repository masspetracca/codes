package it.ccg.tcfrontend.server.servlet.loginlogout;


import it.ccg.tcejb.server.bean.eao.TctCompanyEAO;
import it.ccg.tcejb.server.bean.eao.TctUserEntityEAO;
import it.ccg.tcejb.server.bean.entity.TctCompanyEntity;
import it.ccg.tcejb.server.bean.entity.TctUserEntity;
import it.ccg.tcejb.server.bean.entity.TctUserEntityPK;
import it.ccg.tcejb.server.exception.DataNotAvailableException;
import it.ccg.tcejb.server.security.LDAPManager;
import it.ccg.tcejb.server.security.LDAPUserDTO;
import it.ccg.tcejb.server.security.UserInfoManager;
import it.ccg.tcejb.server.security.view.TokenManagerLocal;
import it.ccg.tcfrontend.server.security.SecurityMessages;
import it.ccg.tcfrontend.server.security.TokenManagement;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.Date;

import javax.ejb.EJB;
import javax.naming.NamingException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ibm.websphere.security.WSSecurityException;
import com.ibm.websphere.security.auth.WSLoginFailedException;
import com.ibm.websphere.security.auth.WSSubject;
import com.isomorphic.log.Logger;


public class LoginFilter implements Filter {

	@EJB 
	TokenManagerLocal tokenManager = null; 
	
	@EJB 
	UserInfoManager userInfoManager = null;
	
	@EJB
	TctUserEntityEAO tctuserentityeao;
	
	@EJB
	TctCompanyEAO tctCompanyEAO;


	static class FilteredRequest extends HttpServletRequestWrapper {

		public FilteredRequest(HttpServletRequest request) {
			super(request);
		}

		@Override
		public String getParameter(String paramName) {
			String temp =  super.getParameter(paramName);
			if (temp != null && !temp.equals("")) {
				temp = temp.replaceAll("<", "&lt;").replaceAll(">", "&gt;");
				temp = temp.replaceAll("eval\\((.*)\\)", "");
				temp = temp.replaceAll("[\\\"\\\'][\\s]*((?i)javascript):(.*)[\\\"\\\']", "\"\"");
				temp = temp.replaceAll("((?i)script)", "");
				/*temp = temp.replaceAll("'", "");
				temp = temp.replaceAll("\"", "");
				temp = temp.replaceAll(";", "");
				temp = temp.replaceAll("%", "");
				temp = temp.replaceAll("&", "");*/
			}
			return temp;
		}
	}

	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		HttpServletRequest httpServletRequest = ((HttpServletRequest) request);

		LoginWrapper myRes = new LoginWrapper((HttpServletResponse) response);

		// TODO new
		// Needed for logged users count
		// Loading login.jsp creates a new session inherited by logged in user
		// Invalidating this session --> new session after login --> i enter into Sessionlistener.sessionCreated method

		
		/*HttpSession httpSession = httpServletRequest.getSession();
		System.out.println("*************************************PRIMA***************************** " + httpSession.getId());
		
//		TokenManagement.invalidateSession(httpServletRequest, httpServletResponse);
		httpSession.invalidate();
		System.out.println("*************************************DOPO***************************** " + httpSession.getId());*/

		//Logger
		Logger log = new Logger(it.ccg.tcfrontend.server.servlet.loginlogout.LoginFilter.class.getName());

		//Inizializzazione messaggi d'errore
		SecurityMessages sM=new SecurityMessages();

		// create wrapper
		String userName = (request.getParameter("j_username") != null && request.getParameter("j_username") != "") ? request.getParameter("j_username").trim():null;
		String password = (request.getParameter("j_password") != null && request.getParameter("j_password") != "") ? request.getParameter("j_password").trim():null;
//		LoginWrapper myRes = new LoginWrapper((HttpServletResponse) response);

		/**
		 * Prima di chiamare la catena: 
		 *  - fare l'escape di username e password
		 */
		FilteredRequest filteredRequest = new FilteredRequest(httpServletRequest);
		chain.doFilter(filteredRequest, myRes);

		String LOGMESSAGE = "User: " + userName + "| OperationName: LoginFilter "; 
		String ERRMESSAGE = LOGMESSAGE + " - Error: ";
		String SECMESSAGE = LOGMESSAGE + " - Security event: ";
		
		// post login actions here
		Throwable t = WSSubject.getRootLoginException();
		if (t != null) {

			t = determineCause(t);
			Cookie c;
			//javax.naming.AuthenticationException: LDAP 49 INVALID CREDENTIALS
			//javax.naming.OperationNotSupportedException: LDAP 53 ACCOUNT LOCKED
			if (t instanceof javax.naming.AuthenticationException){
				c = new Cookie("loginError", sM.smAuthenticationError());

				log.info(SECMESSAGE + "Invalid credentials");
			}
			else if (t instanceof javax.naming.OperationNotSupportedException){
				c = new Cookie("loginError", sM.smAccountLocked());

				log.error(SECMESSAGE + "Account locked");
			}
			else{
				c = new Cookie(ERRMESSAGE + "loginError", sM.smAuthenticationError());
			}

			c.setMaxAge(-1);
			myRes.addCookie(c);
			myRes.sendMyRedirect("loginError.jsp");

		} else {
			//Form usrname o pw vuote
			if (userName.equals("") || password.equals("")) {
				myRes.sendMyRedirect("loginError.jsp");
			}
			// now it is safe to send index.html redirect
			else{
				//Get username
				String user = httpServletRequest.getUserPrincipal().getName();
				
				Cookie c = new Cookie("loginError", "");
				c.setMaxAge(-1);
				
				//Obtain the session object, create a new session if doesn't exist
				HttpSession session = (httpServletRequest).getSession();

				//Creo il "session token"
				String token = "";
				String generatingToken=(String)session.getId() + "hakunamatata" + (httpServletRequest).getUserPrincipal().getName();

				try {
					token = TokenManagement.MD5(generatingToken);
				} catch (NoSuchAlgorithmException e) {
					log.error(ERRMESSAGE,e.getMessage());
					log.error(ERRMESSAGE,e.getStackTrace());
				}

				//Assegno il token alla sessione corrente
				session.setAttribute("TOKEN1", token);

				//Metodo che memorizza la coppia (USER,COMPANY) sulla hashmap statica
				//Se eccezione rilevata, invalidiamo la sessione
				try {
					setUserInfo(user);
				} catch (Exception e) {
				
					String logoutPage= "/loginError.jsp";
					
					log.error(ERRMESSAGE,e.getMessage());
					log.error(ERRMESSAGE,e.getStackTrace());
					
					//Utilizzo ibm_security_logout e faccio il forward verso la pagina di login
					String  logoutURL= "ibm_security_logout?logout=Logout&logoutExitPage=" + logoutPage;
					
//					System.out.println(((HttpServletRequest) request).getSession().getServletContext().toString());
					RequestDispatcher dispatcher =  ((HttpServletRequest) request).getSession().getServletContext().getRequestDispatcher(logoutURL);
				    try {
						dispatcher.forward(request, response);
					} catch (ServletException e1) {
						log.error(ERRMESSAGE,e1.getMessage());
						log.error(ERRMESSAGE,e1.getStackTrace());
					}
					return;
				}
				
				//Recupero lo user per fare la update sulla hashtable 
				//che associa user e token (gestione login concorrenti)

				try {
					tokenManager.upsert(user,token) ;
				} catch (Exception e) {
					log.error(ERRMESSAGE,e.getMessage());
					log.error(ERRMESSAGE,e.getStackTrace());
				}
				// authentication successful, remove the cookie
				
				myRes.addCookie(c);
				myRes.sendMyRedirect("index.html");

				log.info(SECMESSAGE + "User authenticated with the following session identification code: "+(String)session.getId());

			}
		}



	}


	public Throwable determineCause(Throwable e) {
		Throwable rootEx = e, tempEx = null;
		// keep looping until there are no more embedded
		// WSLoginFailedException or WSSecurityException exceptions
		while (true) {
			if (e instanceof WSLoginFailedException) {
				tempEx = ((WSLoginFailedException) e).getCause();
			} else if (e instanceof WSSecurityException) {
				tempEx = ((WSSecurityException) e).getCause();
			} else if (e instanceof NamingException) {
				// check for Ldap embedded exception
				tempEx = ((NamingException) e).getRootCause();
			} else {
				// this is the root from the WebSphere
				// Application Server perspective
				return rootEx;
			}
			if (tempEx != null) {
				// we have nested exception, check it
				rootEx = tempEx;
				e = tempEx;
				continue;
			} else {
				// the cause was null, return parent
				return rootEx;
			}
		} // while
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	//Metodo che memorizza la coppia (USER,COMPANY) sulla hashmap statica
	public void setUserInfo(String user) throws Exception{

		//inizializzo ldapmanager per query su ldap
		LDAPManager ldapManager = new LDAPManager();

		//cerco su LDAP la entry corrispondente allo userid che sto cercando
		LDAPUserDTO ldapUserDTO=ldapManager.getUserInfoByUserId(user);
		String companyCode = ldapUserDTO.getOu();
		//recupero il nome completo=cn
		String fullname= ldapUserDTO.getCn();
		String email = ldapUserDTO.getMail()==null?"":ldapUserDTO.getMail();
		
		//inserisco la company e il fullname dello user recuperandola dal campo OU dell' LDAP entry
		userInfoManager.add("COMPANYCODE", companyCode);
		userInfoManager.add("FULLNAME", fullname);
		
		userInfoManager.add("EMAIL", email);
		
		
		//recuperare company ID sulla tabella a partire dalla company
		TctCompanyEntity userCompany=tctCompanyEAO.findByCompanyCode(companyCode);
		if(userCompany==null||userCompany.getCmpnId()==0){
			throw new DataNotAvailableException("No company found on DB having company code "+companyCode);
		}
		userInfoManager.add("COMPANYID", userCompany.getCmpnId()+"");
		userInfoManager.add("COMPANY", userCompany.getCompanyName()==null?"":userCompany.getCompanyName());
		
		//UPSERT UTENTE nella tabella dedicata
		
		//recupero se presente l'entity dello user da db
		TctUserEntity tctuser=tctuserentityeao.findByPrimaryKey(userCompany.getCmpnId(), user);
		
		/*
		 * commento 
		 * Raffaele De Lauri
		 * 08/10/2014
		 */
		//String mailLDAP= ldapUserDTO.getMail();
		//se l'utente non � presente dovremo inserire una riga contentente le informazioni di questo "nuovo utente"
		if(tctuser==null){
			
			TctUserEntity newuser=new TctUserEntity();
			TctUserEntityPK newuserPK= new TctUserEntityPK();
			
			newuserPK.setCmpnid(userCompany.getCmpnId());
			newuserPK.setUserName(user);
			newuser.setId(newuserPK);
			
			// se su LDAP non c'� una mail definita mettiamo il notify a False e a null l'email
			if(email==null||email.equalsIgnoreCase("")){				
				newuser.setNotify("F");
			}
			//altrimenti setto la mail con il valore contenuto nell'LDAP ed il notify a false
			else{
				newuser.setEMail(email);
				newuser.setNotify("T");
			}
			
			//store
			tctuserentityeao.insertEntity(newuser);
			
//			System.out.println("NEW USER ADDED");
		}
		//se l'email su ldap � diversa da null e l'utente gi� esiste 
		else if(email!=null){
			
			//se l'indirizzo email sulla tabella � nullo o la mail su ldap � diversa da quello memorizzata in tabella 
			if(tctuser.getEMail()==null||(!(tctuser.getEMail().equalsIgnoreCase(email)))){
				//aggiorno la voce in tabella
				
				TctUserEntity newuser=new TctUserEntity();
				TctUserEntityPK newuserPK= new TctUserEntityPK();
				
				newuserPK.setCmpnid(userCompany.getCmpnId());
				newuserPK.setUserName(user);
				newuser.setId(newuserPK);
				
				newuser.setEMail(email);
				newuser.setUpdDate(new Timestamp(new Date().getTime()));
				newuser.setUpdType("U");
				
				
				
//				System.out.println("MAIL USER UPDATED");
				
				
				tctuserentityeao.updateEntity(newuser);
	
			}
			
			
		}
		

	}

}