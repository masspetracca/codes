package it.ccg.tcfrontend.server.servlet.general;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;

import com.ibm.icu.text.SimpleDateFormat;
import com.isomorphic.rpc.RPCManager;
import com.isomorphic.rpc.RPCRequest;
import com.isomorphic.rpc.RPCResponse;
import it.ccg.tcejb.server.bean.eao.*;
import it.ccg.tcejb.server.bean.entity.TctSrcFlHEntity;
import it.ccg.tcejb.server.bean.entity.TctUplfEntity;
import it.ccg.tcejb.server.util.ExceptionUtil;
import it.ccg.tcejb.server.util.XmlManager;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class xmlServlet
 */
@WebServlet("/ccgportal/xmlServlet")
public class xmlServlet extends HttpServlet {
	

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8740896081365649044L;
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = LoggerFactory.getLogger(LoggerFactory.USER_LOGGER);

	@EJB
	TctSrcFlHEntityEAO tctSrcFlhEntityEAO;
	
	@EJB
	TctUplfEntityEAO tctUplfEntityEAO;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public xmlServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug(new StandardLogMessage("Eseguo download"));
		download(request, response);
	}
	
	private void download(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		try {
			String params = request.getParameter("params").toString();
			String[] paramarr=params.split(",");
			String source=paramarr[0].trim();//runId
			String download=paramarr[1];//uplId
			String listDate=paramarr[2];//filename
			String operation=paramarr[3];
			
			if(operation.equalsIgnoreCase("attach")){
				
				logger.debug(new StandardLogMessage("Inizio download RunId:"+ source + " - UploadId: "+ download+" - FileName: "+listDate));
				TctUplfEntity result = tctUplfEntityEAO.retrieveByRunIdAndUplId(Integer.parseInt(source), Integer.parseInt(download));
				//System.out.println(result.getUplfileFilename()+" - "+result.getUplfileFilesize());
				
				String fileName = result.getUplfileFilename();
				String contentType="";
				String punto =".";
				for(int i=0;i<fileName.length();i++){
					if(fileName.charAt(i)== punto.charAt(0)){
						contentType = fileName.substring(i+1, fileName.length());
					}
					
				}
				System.out.println("tipo: "+contentType);
				
				ServletOutputStream op = response.getOutputStream();
				response.setContentType("application/"+contentType);
				response.setHeader("Content-Disposition", "attachment; filename="+listDate);
				
				logger.debug(new StandardLogMessage("Inizio download file attached"));
				response.setContentLength((int)result.getUplfile().length);
				byte[] xml = result.getUplfile();
				op.write(xml, 0, (int)result.getUplfile().length);
				
				op.flush();
				op.close();
				logger.debug(new StandardLogMessage("Download terminato"));
			}
			else{
			
			Date audDateTime = new Date(new Long(listDate));
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			
			TctSrcFlHEntity result= tctSrcFlhEntityEAO.fetchSrcByDownloadIdAndSourceList(source, download);
			
			ServletOutputStream op = response.getOutputStream();
			response.setContentType("application/xml");
			response.setHeader("Content-Disposition", "attachment; filename="+formatter.format(audDateTime)+"_"+source+".xml");
			
			
			
			if(source.equalsIgnoreCase("EC")){
				logger.debug(new StandardLogMessage("Inizio download source EC"));
				response.setContentLength((int)result.getEcFile().length);
				byte[] xml = result.getEcFile();
				op.write(xml, 0, (int)result.getEcFile().length);
			
			}else if(source.equalsIgnoreCase("OFAC")){
				logger.debug(new StandardLogMessage("Inizio download source OFAC"));
				response.setContentLength((int)result.getOfacFile().length);
				byte[] xml = result.getOfacFile();
				op.write(xml, 0, (int)result.getOfacFile().length);
				
			}else if(source.equalsIgnoreCase("UN")){
				logger.debug(new StandardLogMessage("Inizio download source UN"));
				response.setContentLength((int)result.getUnFile().length);
				byte[] xml = result.getUnFile();
				op.write(xml, 0, (int)result.getUnFile().length);
				
			}
			
			//byte[] bbuf = result.getUnFile();

            //op.write(bbuf, 0, (int)result.getUnFile().length);
            
			op.flush();
			op.close();
			logger.debug(new StandardLogMessage("Download terminato"));
			}
			
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			ExceptionUtil.logCompleteStackTrace(userLogger, e);
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}
		
	}
}
