package it.ccg.tcfrontend.server.servlet.security;



import it.ccg.tcejb.server.bean.eao.view.UserActionReportEAOLocal;
import it.ccg.tcejb.server.security.view.PwdManagerLocal;
import it.ccg.tcejb.server.security.view.TokenManagerLocal;
import it.ccg.tcejb.server.util.UserActionDto;
import it.ccg.tcfrontend.server.security.RemoveInvalidChar;
import it.ccg.tcfrontend.server.security.SecuritySettings;
import it.ccg.tcfrontend.server.security.TokenManagement;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;
import java.util.HashMap;

import javax.ejb.EJB;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.isomorphic.log.Logger;



/**
 * Servlet Filter implementation class SecurityFilter
 */
//@WebFilter("/SecurityFilter")
public class SecurityFilter implements Filter {

	@EJB TokenManagerLocal tokenManager; 
	@EJB PwdManagerLocal pwmanager;
	@EJB UserActionReportEAOLocal userActionReport;

	public SecurityFilter() {

	}

	public void destroy() {

	}


	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		//Logger
		Logger log = new Logger(it.ccg.tcfrontend.server.servlet.security.SecurityFilter.class.getName());

		HttpServletResponse httpServletResponse = (HttpServletResponse)response;
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;

		boolean isMultipartContent = false;

		// Log messages
		String userName = null;
		try{
			userName = httpServletRequest.getUserPrincipal().getName();
		}
		catch(Exception e){
			log.error("User: NOT AVAILABLE| OperationName: SecurityFilter ");
		}

		String LOGMESSAGE = "User: " + userName + "| OperationName: SecurityFilter "; 
		String ERRMESSAGE = LOGMESSAGE + " - Error: ";	
		String SECMESSAGE = LOGMESSAGE + " - Security event: ";
		
		try {
			Context context = new InitialContext();

			//UserActionReportEAOLocal userActionReport = (UserActionReportEAOLocal)context.lookup("ejblocal:it.ccg.tcfrontend.server.eao.UserActionReportEAOLocal");
			userActionReport.addAction(userName, httpServletRequest.getRequestURI());

			HashMap<String, UserActionDto> report = userActionReport.getActionReport();

		} catch (NamingException e) {
			log.error("Security filter Exception: "+ e.getMessage());
		}

		if(ServletFileUpload.isMultipartContent(httpServletRequest)) {

			isMultipartContent=true;

		}

		if(SecuritySettings.getIsEnable()) {

			HttpSession currentSession = httpServletRequest.getSession(false);
//			log.info(LOGMESSAGE + " - Session correctly started.");
			// Evito di scrivere log inutili dopo un logout forzato
			try {
				if(currentSession== null) {
					log.info(LOGMESSAGE + " - Current session has been invalidated.");
					TokenManagement.invalidateSession(httpServletRequest, httpServletResponse);
					return;
				}
			}
			catch(Exception e) {
				log.error(ERRMESSAGE + "Error getting session.");
				TokenManagement.invalidateSession(httpServletRequest, httpServletResponse);
				return;
			}
		}

		//Recupero il path della request in modo da escludere login e logout dalla validate del t1 
		String path = httpServletRequest.getRequestURI();
		String contentType = httpServletRequest.getContentType();

		//GET operation not allowed per tutte le servlet
		if(httpServletRequest.getMethod().compareToIgnoreCase("GET")==0 && !path.contains("ibm_security_logout") && !path.contains("Chart")
				&& !path.contains("SystemPropertiesLoad") && !path.contains("SPL")){
			log.info(SECMESSAGE + " - GET operation not allowed, invalidating session.");
			TokenManagement.invalidateSession(httpServletRequest, httpServletResponse);
			return;
		}


		//		Add X-FRAME-OPTIONS response header to tell IE8 (and any other browsers who
		//		 * decide to implement) not to display this content in a frame.
		// 

		if(!path.contains("Chart") && !path.contains("GeneralDownloadReport")  && !path.contains("GeneralDownloadPlainTextFile")   
				&& !isMultipartContent){
			httpServletResponse.addHeader("X-FRAME-OPTIONS", "DENY");
		}


		if(!path.contains("IDACall")){

			Enumeration<String > paramNames = request.getParameterNames();

			String allowedNames = "anndaysper,annv,anvartype,approval,batchId,calcWindow," +
					"classId,comment,crcoeff,crlog,crndaysper,crnv,crvartype,diviscode,EMAIL," +
					"filename,grname,instrid,instruments,K,MULTIPLIER,NAME,NEWPW,NOTIFY,OLDPW," +
					"PHONENUMB,prcId,propose,rccode,rownumber,SPOTPRICE,status,SURNAME,toDo,USER," +
					"USERDESC";

			while(paramNames.hasMoreElements()) {

				String paramName = paramNames.nextElement();
				String paramValue = request.getParameter(paramName);
				String[] allowArr = allowedNames.split(",");

				for(int i =0; i<allowArr.length; i++){

					if(allowArr[i].compareToIgnoreCase(paramName)==0){

						try {

							//Solo stampa la funzione va sostituita
							if(RemoveInvalidChar.checkInvalidChar(paramValue)) {

								log.info(SECMESSAGE + "Invalid char have been checked, invalidating session.");

								TokenManagement.invalidateSession(httpServletRequest, httpServletResponse);

								return;
							}
						} 
						catch (Exception e) {
							log.error(ERRMESSAGE,e.getMessage());
							log.error(ERRMESSAGE,e.getStackTrace());
						}
					}
				}
			}
		}


		if(path.contains("Logout") || path.contains("ibm_security_logout")){
			chain.doFilter(httpServletRequest, httpServletResponse);
			return;
		}

		else {
			// Eseguo i varti controlli solo se la sicurezza � abilitata
			if(SecuritySettings.getIsEnable()) {

				try {
					//Valido il "session token" per xsrf
					if(!TokenManagement.validateT1(httpServletRequest, httpServletResponse, tokenManager, pwmanager)){
						//TokenManagement.invalidateSession(httpServletRequest, httpServletResponse, tokenManager, sM.smInvalidateSession());
						TokenManagement.invalidateSession(httpServletRequest, httpServletResponse);
						log.info(SECMESSAGE + "Cross site request forgery detected, invalidating session.");

						return;
					}
				} catch (NoSuchAlgorithmException e) {
					log.error(ERRMESSAGE,e.getMessage());
					log.error(ERRMESSAGE,e.getStackTrace());
				}

				try {
					//Valido il "session token" per accessi concorrenti
					if(!TokenManagement.validateT1ForConcurr(httpServletRequest, httpServletResponse, tokenManager, pwmanager)){
						String user = ((HttpServletRequest) request).getUserPrincipal().getName();
						//Vado a sovrascrivere il valore del token nella HashTable
						tokenManager.upsert(user,"") ;
						//TokenManagement.invalidateSession(httpServletRequest, httpServletResponse, tokenManager, sM.smInvalidateSessionForConcurrent());
						TokenManagement.invalidateSession(httpServletRequest, httpServletResponse);
						log.info(SECMESSAGE + "Concurrent login detected, invalidating session.");

						return;
					}
				} catch (Exception e) {
					log.error(ERRMESSAGE,e.getMessage());
					log.error(ERRMESSAGE,e.getStackTrace());
				}
			}
			chain.doFilter(httpServletRequest, httpServletResponse);
		}
	}

	public void init(FilterConfig fConfig) throws ServletException {

	}

}