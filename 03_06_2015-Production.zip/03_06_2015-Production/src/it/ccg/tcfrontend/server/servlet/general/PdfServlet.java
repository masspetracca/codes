package it.ccg.tcfrontend.server.servlet.general;

import it.ccg.tcejb.server.bean.eao.TctAggrEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctCorrLstEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctCorrispEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctRunRegEAO;
import it.ccg.tcejb.server.bean.entity.TctCorrLstEntity;
import it.ccg.tcejb.server.bean.entity.TctCorrisp;
import it.ccg.tcejb.server.bean.entity.TctCorrispEntity;
import it.ccg.tcejb.server.bean.entity.TctRunRegEntity;
import it.ccg.tcejb.server.bean.system.PDFGeneratorLocal;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.security.UserInfoManager;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcfrontend.client.security.Privileges;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.ibm.icu.text.SimpleDateFormat;
import com.lowagie.text.Document;
import com.smartgwt.client.util.SC;


/**
 * Servlet implementation class PdfServlet
 */
@WebServlet("/ccgportal/PdfServlet")
public class PdfServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	private PrintWriter outStream = null;

	@EJB
	private TctCorrispEntityEAO tctCorrispEntityLocal;
	
	@EJB
	private TctCorrLstEntityEAO tctCorrLstEntityLocal;
	
	@EJB
	private TctRunRegEAO tctRunRegEntityLocal;

	@EJB
	private PDFGeneratorLocal pdfGenerator;
	
	@EJB
	private UserInfoManager userInfoManager;
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PdfServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.createReport(request, response);
	}

	private void createReport(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		try {

			String params = request.getParameter("params").toString();
			
			String[] paramArr = params.split(",");
			String id = paramArr[0];//nel caso di tctcorrlst corrisponde al nome dell'utente che genera il report, nel caso di tctcorrisp � il runid
			//String companyId = paramArr[1];
			String companyId = userInfoManager.fetchField("COMPANYID");
			String operation = paramArr[1];
			String clientName  = "";
			if(paramArr.length==5){
				clientName = paramArr[4];
			}else if(paramArr.length==6){
				clientName = paramArr[5]+","+paramArr[4];
			}else if (paramArr.length==7){
				clientName = paramArr[6]+","+paramArr[5]+","+paramArr[4];
			} 
			
			
			if(operation.equalsIgnoreCase("tctcorrisp")){
				SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
				String path = "ANL_"+companyId+"_"+formatter.format(new Date())+".pdf";
				File f = new File(System.getProperty("user.install.root")+ "/TcReport/"+path);

				if(!f.exists()){
					List<TctCorrisp> corrispList = tctCorrispEntityLocal.retrieveByRunIdAndCmpnId(Integer.parseInt(id),Integer.parseInt(companyId));
					TctRunRegEntity runregList = tctRunRegEntityLocal.retrieveByRunIdAndCmpnId(Integer.parseInt(id),Integer.parseInt(companyId));
					if(corrispList.size()==0){
						this.pdfGenerator.generateRunregPdf(runregList/*,Integer.parseInt(companyId),id*/,path);
					}else
						this.pdfGenerator.generatePdf(corrispList,runregList,/*Integer.parseInt(companyId),id,*/path);
				}

				int length = 0;
				logger.debug(new StandardLogMessage("Inizio download analysis report: "+path));
				ServletOutputStream op = response.getOutputStream();
				response.setContentType("application/pdf");
				response.setContentLength((int)f.length());
				response.setHeader("Content-Disposition", "attachment;filename=\""+path);
				
				byte[] bbuf = new byte[1024];
				DataInputStream in = new DataInputStream(new FileInputStream(f));

				while ((in != null) && ((length = in.read(bbuf)) != -1)) {
					op.write(bbuf, 0, length);
				}

				response.setStatus(HttpServletResponse.SC_OK);
				logger.debug(new StandardLogMessage("Download eseguitio di "+path));
				in.close();
				op.flush();
				op.close();
			}
			else if(operation.equalsIgnoreCase("tctcorrlst")){
				SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
				String path = "ADM_"+companyId+"_"+formatter.format(new Date())+".pdf";
				File f = new File(System.getProperty("user.install.root")+ "/TcReport/"+path);
				
				if(!f.exists()){
					List<TctCorrLstEntity> corrList = tctCorrLstEntityLocal.retrieveByCmpnId(Integer.parseInt(companyId));
					this.pdfGenerator.generateCorrLstPdf(corrList,/*Integer.parseInt(companyId),*/id,path,clientName);
				}

				int length = 0;
				logger.debug(new StandardLogMessage("Inizio download admission report: "+path));
				ServletOutputStream op = response.getOutputStream();
				response.setContentType("application/pdf");
				response.setContentLength((int)f.length());
				response.setHeader("Content-Disposition", "attachment;filename=\""+path);

				byte[] bbuf = new byte[1024];
				DataInputStream in = new DataInputStream(new FileInputStream(f));

				while ((in != null) && ((length = in.read(bbuf)) != -1)) {
					op.write(bbuf, 0, length);
				}
				response.setStatus(HttpServletResponse.SC_OK);
				logger.debug(new StandardLogMessage("Download eseguitio di "+path));
				in.close();
				op.flush();
				op.close();

			}
		}
		catch (Exception e) {

			//response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}

	}

}
