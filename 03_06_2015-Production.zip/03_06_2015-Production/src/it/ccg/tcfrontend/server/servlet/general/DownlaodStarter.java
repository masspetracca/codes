package it.ccg.tcfrontend.server.servlet.general;

import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.ext.src.business.Starter;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class DownlaodStarter
 */
@WebServlet("/tcfrontend/admin/DownlaodStarter")
public class DownlaodStarter extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger log = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	@EJB
	public Starter starter;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DownlaodStarter() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug(new StandardLogMessage("in DownlaodStarter.doPost")); 
		String src = request.getParameter("src");
			if (src.equalsIgnoreCase("ALL")){
				try {
					starter.startTerroristDataFlow();
				} catch (BackEndException e) {
					log.error(new StandardLogMessage("Error "+e.getMessage()));;
					e.printStackTrace();
				}
			}else if (src.equalsIgnoreCase("FIND")){
				try {
					starter.startFindMatch(1);
				} catch (BackEndException e) {
					log.error(new StandardLogMessage("Error "+e.getMessage()));;
					e.printStackTrace();
				}
			}else if (src.equalsIgnoreCase("OPTIM")){
				try {
					starter.startOptimization(0);
				} catch (BackEndException e) {
					log.error(new StandardLogMessage("Error "+e.getMessage()));;
					e.printStackTrace();
				}
			}
		log.debug(new StandardLogMessage("done"));
	}

}
