package it.ccg.tcfrontend.server.servlet.general;

import it.ccg.tcejb.server.ext.src.business.Starter;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;

import java.io.IOException;
import java.util.HashMap;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.isomorphic.rpc.RPCManager;
import com.isomorphic.rpc.RPCRequest;
import com.isomorphic.rpc.RPCResponse;

/**
 * Servlet implementation class MatchClient
 */
@WebServlet("/ccgportal/MatchClient")
public class MatchClient extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	@EJB
	private Starter starter;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MatchClient() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.matchClient(request, response);
	}
	
private void matchClient(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	RPCManager rpc = null;
	try {
		rpc = new RPCManager(request, response);
	} catch (Exception e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	//Ottengo gli oggetti di richiesta e di risposta
			RPCRequest rpcRequest = rpc.getRequest();;
			RPCResponse rpcResponse = new RPCResponse();;
			
			// creo un hashmap per la risposta
			HashMap<String, String> responseParams = new HashMap<String, String>();
			
	
		try {
		
			String params = request.getParameter("params").toString();
			String company = request.getParameter("company").toString();
			
			String[] paramArr = params.split(",");
			logger.debug(new StandardLogMessage("Parametri match :"+ params));
			starter.startFindMatch(Integer.parseInt(company), paramArr);
			//Popolo il parametro con una risposta positiva
			responseParams.put("RESULT","0" );
			//response.setStatus(HttpServletResponse.SC_OK);

		}catch (Exception e) {
			//Popolo il parametro con una risposta negativa
			responseParams.put("RESULT","1" );
			
			//Loggo sul log utente
			//log.error(logMessage);
			
		}
		// creo una response e la popolo con con i parametri di risposta
		rpcResponse.setData(responseParams);
		try {
			rpc.send(rpcRequest,rpcResponse);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}


