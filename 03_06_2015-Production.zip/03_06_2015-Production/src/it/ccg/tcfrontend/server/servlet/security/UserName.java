package it.ccg.tcfrontend.server.servlet.security;

import it.ccg.tcejb.server.exception.PropertyException;
import it.ccg.tcejb.server.properties.PropertiesEAO;
import it.ccg.tcejb.server.properties.view.PropertiesEAOLocal;
import it.ccg.tcejb.server.security.UserInfoManager;
import it.ccg.tcfrontend.server.utils.Roles;

import java.io.IOException;
import java.util.HashMap;


import com.isomorphic.log.Logger;
import com.isomorphic.rpc.RPCManager;
import com.isomorphic.rpc.RPCResponse;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class UserName
 */
@WebServlet(description = "Recupera i ruoli utente", urlPatterns = { "/ccgportal/UserName" })
public class UserName extends HttpServlet {
	
	@EJB 
	UserInfoManager userInfoManager;
	
	@EJB
	PropertiesEAOLocal propeao;
	
	private static final long serialVersionUID = 1L;
	
	private String[] arrRoles = Roles.getAllRoles();
	
	
	    
    private void doWork(HttpServletRequest request, HttpServletResponse response) {
//    	Logger log = new Logger(it.ccg.pamp.server.servlet.general.GeneralUserFullName.class.getName());
//    	String logMessage = "User: " + request.getUserPrincipal().getName() + "| OperationName: UserName"; 
    	
    	//Variabili locali
    	String user="";
    	String userRoles="";
    	String enabledCommands="";
    	String isApproveEnabled="";
    	
    	
    	
    	
		//Creo l'oggetto RPC per la gestione SmartGWT dei parametri della servlet
		RPCManager rpc = null;		
		try {
			rpc = new RPCManager(request, response);
		} catch (Exception rpcException) {
			System.out.println("Error creating RPCManager: "+rpcException.getMessage());
			System.out.println(rpcException.getStackTrace().toString());
		}

		//Ottengo gli oggetti di richiesta e di risposta
		//RPCRequest rpcRequest = rpc.getRequest();;
		RPCResponse rpcResponse = new RPCResponse();;
		
		// creo un hashmap per la risposta
		HashMap<String, String> responseParams = new HashMap<String, String>();
	
		try {
			
			HashMap<String, String> propmap=propeao.getPropertyMap();
			
			int isApproveFromProp = Integer.parseInt(propmap.get("approve").toString());
			
			if(isApproveFromProp==1){
				isApproveEnabled="T";
			}
			else isApproveEnabled="F";
			
			System.out.println("******************" + isApproveFromProp);
			System.out.println("******************" + isApproveEnabled);
			
			//Popolo il parametro di risposta con una risposta positiva
			user=request.getUserPrincipal().getName();
			
			for (int i=0;i<arrRoles.length;i++) {
				if (request.isUserInRole(arrRoles[i])) {
					userRoles+=arrRoles[i]+",";
					
					//recupero comandi attivi per il ruolo
					String enabledComm4Role=propmap.get(arrRoles[i]);
					if(enabledComm4Role!=null&&!enabledComm4Role.isEmpty()){
						enabledCommands+=(enabledCommands.equalsIgnoreCase(""))?(enabledComm4Role):(","+enabledComm4Role);
					}
				}
			}
			userRoles=userRoles.substring(0,userRoles.length()-1);
			
			responseParams.put("USER", user);
			responseParams.put("ROLES", userRoles);
			responseParams.put("RESPONSE", "0");
			// recuperare da ldap
			responseParams.put("COMPANY", userInfoManager.fetchField("COMPANY"));
			responseParams.put("FULLNAME", userInfoManager.fetchField("FULLNAME"));
			responseParams.put("COMPANYCODE", userInfoManager.fetchField("COMPANYCODE"));
			responseParams.put("COMPANYID", userInfoManager.fetchField("COMPANYID"));
			responseParams.put("EMAIL", userInfoManager.fetchField("EMAIL"));
			
			responseParams.put("ISAPPROVEENABLED", isApproveEnabled);
			
			//recuperatidai properties
			responseParams.put("ENABLEDCOMMANDS", enabledCommands);
			
//			System.out.println("*****************USER***************"+userInfoManager.fetchField("EMAIL"));
			
			
//			logMessage = "User: " + user + "| User authenticated";
			
			//Loggo sul log utente
//			log.info(logMessage);
			
		} catch (Exception e) {
			responseParams.put("RESPONSE", "Error authenticating the user");
			System.out.println("Servlet RPC error:");
			e.printStackTrace();
			
		} 

		// creo una response e la popolo con con i parametri di risposta
		rpcResponse.setData(responseParams);

		// restituzione del risultato
		try {
			rpc.send(rpcResponse);
		} catch (Exception rpcException) {
			System.out.println("Error creating response: "+rpcException.getMessage());
			System.out.println(rpcException.getStackTrace().toString());
		}
	}
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doWork(request, response);
	}

}
