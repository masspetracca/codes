package it.ccg.tcfrontend.server.servlet.security;

import it.ccg.tcejb.server.security.view.SessionInfoLocal;

import javax.ejb.EJB;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.isomorphic.log.Logger;

public class SessionListener  implements HttpSessionListener {
	
	Logger log = new Logger(it.ccg.tcfrontend.server.servlet.security.SessionListener.class.getName());
	
	
	@EJB
	private SessionInfoLocal sessionInfoLocal;
	
	
    /**
     * Default constructor. 
     */
    public SessionListener() {
        // TODO Auto-generated constructor stub
    }


	/**
     * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent arg0) {
    	
    	try {
    		String currentUser = this.sessionInfoLocal.getCurrentUser();
    		
    		if(currentUser != null && !currentUser.equalsIgnoreCase("WAS")) {
    			
    			// user correctly logged, but did it grant PAMP roles?
    			log.debug("Roles check for user: " + currentUser);
    			// if yes
    			if(this.sessionInfoLocal.getCurrentUserRoles().size() > 0) {
    				
    				log.debug("User \'" + currentUser + "\' granted PAMP roles: " + this.sessionInfoLocal.getCurrentUserRoles());
    				
    				this.sessionInfoLocal.addLoggedUser(currentUser);
                	
    				log.debug("User added to logged user list. [user: " + currentUser + ", roles: " + this.sessionInfoLocal.getCurrentUserRoles() + "]");
    			}
    			// otherwise
    			else {
    				
    				log.error("User \'" + currentUser + "\' didn't grant any of PAMP required roles.");
                }
    			
    			
            }
        	
        }
    	catch (Exception e) {
    		
    		log.error(e.toString());
    		
    		e.printStackTrace();
		}
    	
    }
    
    /**
     * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent arg0) {
    	
    	try {
    		String currentUser = this.sessionInfoLocal.getCurrentUser();
        	
    		if(currentUser != null && !currentUser.equalsIgnoreCase("WAS")) {
    			
    			log.debug("Logged out user: " + currentUser);
            	
            	this.sessionInfoLocal.removeLoggedUser(currentUser);
            	
            	log.debug("User removed from logged user list: " + currentUser);
            }
    		
        }
    	catch (Exception e) {
    		
    		log.error(e.toString());
    		
    		e.printStackTrace();
		}
    	
    }
	
}