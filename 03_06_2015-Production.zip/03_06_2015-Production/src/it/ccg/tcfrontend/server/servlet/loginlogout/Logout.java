package it.ccg.tcfrontend.server.servlet.loginlogout;

import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ibm.websphere.security.WSSecurityHelper;
import com.isomorphic.log.Logger;

/**
 * Servlet implementation class Logout
 */
@WebServlet(description = "Servlet richiamata per forzare il Logout", urlPatterns = { "/ccgportal/Logout" })
public class Logout extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Logout() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logout(request, response);
	}
	
	public void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Logger
		Logger log = new Logger(it.ccg.tcfrontend.server.servlet.loginlogout.Logout.class.getName());
		String LOGMESSAGE = "User: " + request.getUserPrincipal().getName() + "| OperationName: logout "; 
		String ERRMESSAGE = LOGMESSAGE + " - Error: ";
		String SECMESSAGE = LOGMESSAGE + " - Security event: ";
		// invalidate session
		/*HttpSession currentSession = requset.getSession(false);
		if (currentSession != null) {
			Cookie[] cookies = requset.getCookies();
			if (cookies != null && cookies.length > 0) {
				for (int i = 0; i < cookies.length; i++) {
					cookies[i].setMaxAge(0);
					cookies[i].setValue(null);
				}
			}
			currentSession.invalidate();
		}
		// remove SSO cookies
		WSSecurityHelper.revokeSSOCookies(requset, response);*/
		
		
		
		
		/*String logoutPage="/login.jsp";

		String  logoutURL= "ibm_security_logout?logout=Logout&logoutExitPage="+logoutPage;
		
		log.info(SECMESSAGE + "User logged out.");

		response.sendRedirect(response.encodeURL(logoutURL));*/
		
		
		
		String logoutPage= "/login.jsp";

		//Utilizzo ibm_security_logout e faccio il forward verso la pagina di login
		String  logoutURL= "ibm_security_logout?logout=Logout&logoutExitPage=" + logoutPage;
		
		
		RequestDispatcher dispatcher =  request.getSession().getServletContext().getRequestDispatcher(logoutURL);
	    try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		log.info(SECMESSAGE + "User logged out.");

	}


}
