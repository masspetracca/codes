package it.ccg.tcfrontend.server.servlet.general;


import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;

import javax.annotation.security.RolesAllowed;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class SPL
 */
@WebServlet("/tcfrontend/admin/SystemPropertiesLoad")
public class SPL extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PrintWriter out;
	
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SPL() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doWork(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doWork(request, response);
	}

private void doWork(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	try {
    		// load system properties
    		SystemProperties.loadSystemProperties();
        	
    		// render page
    		this.renderPage(response);
    	}
    	catch(Exception e) {
    		// default logger
			try {
				ExceptionUtil.logCompleteStackTrace(logger, e);
				this.renderError(response, "Unable to load system properties. Read logs for details.");
			}
			catch(Exception e1) {
				
				e1.printStackTrace();
			}
		}
    	
    }
    
//	@RolesAllowed("admin")
    private void renderPage(HttpServletResponse response) throws Exception {
    	
    	this.out = response.getWriter();
    	
    	this.out.println("Properties successfully loaded!" + "<br>");
    	this.out.println("<br>");
    	this.out.println(new Timestamp(System.currentTimeMillis()));
    	this.out.println("<br>");
		
		/*BufferedReader bufferedReader = new BufferedReader(new FileReader(new File(SystemProperties.getPropertiesFileAbsPath())));    
		
		String line = bufferedReader.readLine();
		
		while(line != null) {
			out.println(line + "<br>");
			
			line = bufferedReader.readLine();
		}*/
    }
    
    private void renderError(HttpServletResponse response, String errorMessage) throws Exception {
    	
    	this.out = response.getWriter();
    	
    	this.out.println("Error: " + errorMessage);
    	this.out.println();
    	this.out.println();
    }
}
