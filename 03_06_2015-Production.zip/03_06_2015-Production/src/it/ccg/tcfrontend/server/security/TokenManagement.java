package it.ccg.tcfrontend.server.security;

import it.ccg.tcejb.server.security.view.PwdManagerLocal;
import it.ccg.tcejb.server.security.view.TokenManagerLocal;
import it.ccg.tcfrontend.server.utils.LogBuffer;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;
import com.isomorphic.datasource.DataSource;

public class TokenManagement {


	//Valida il t che viene creato contestualmente alla richiesta di login(nella LoginFilter)
	//Dopo ogni chiamata alla IDACall
	//Richiamato in SecureIDACAll
	public static boolean validateT1(HttpServletRequest request, HttpServletResponse response, TokenManagerLocal tokenManager, PwdManagerLocal pwmanager) throws IOException, NoSuchAlgorithmException{
		//Session
		HttpSession session = ((HttpServletRequest) request).getSession();

		setSessionMaxInactiveInterval(session);

		//Session token
		String tfromfilter = (String) session.getAttribute("TOKEN1");

		//Token generation
		String tcalc = MD5((String)session.getId() + "hakunamatata" + request.getUserPrincipal().getName());

		//(XSRF)
		//Controllo che il token creato al momento della login e quello ricalcolato qui
		//ad ogni richiesta, siano uguali. Se non lo sono invalido la sessione, cacello i cookie e faccio la redirect
		if(tfromfilter==null || tfromfilter.compareToIgnoreCase(tcalc)!=0){ 
			return false;
		}
		else return true;


	}

	//Valida il t che viene creato contestualmente alla richiesta di login(nella LoginFilter)
	//Dopo ogni chiamata alla IDACall
	//Richiamato in SecureIDACAll
	public static boolean validateT1ForConcurr(HttpServletRequest request, HttpServletResponse response, TokenManagerLocal tokenManager, PwdManagerLocal pwmanager) throws Exception{
		//Recupero la sessione
		HttpSession session = ((HttpServletRequest) request).getSession();

		setSessionMaxInactiveInterval(session);

		//Session token
		String tfromfilter = (String) session.getAttribute("TOKEN1");
		//Token from table (pmpttoken)
		String tfromtable  = tokenManager.fetchToken(request.getUserPrincipal().getName());

		//Token generation
		String tcalc = MD5((String)session.getId() + "hakunamatata" + request.getUserPrincipal().getName());

		//(CONCURRENT LOGIN)
		//Controllo che il token memorizzato nella HashTable e quello ricalcolato qui
		//ad ogni richiesta, siano uguali. Se non lo sono invalido la sessione, cacello i cookie e faccio la redirect 
		//alla pagina di loginerror.
		if(tcalc.compareToIgnoreCase(tfromtable)!=0){

			return false;

		}
		else return true;
	}


	//Valida il t che viene creato dopo ogni richiesta di update, add
	//Richiamato nei DMI
	public static boolean validateT2(DSRequest dsRequest) throws Exception{

		//Logger
		/*Logger log = new Logger(it.ccg.pamp.server.security.TokenManagement.class.getName());
		String LOGMESSAGE = "User: " + dsRequest.getUserId() + "| OperationName: validateT2 "; 
		String ERRMESSAGE = LOGMESSAGE + " - Error: ";
		String SECMESSAGE = LOGMESSAGE + " - Security event: ";*/
		
		
		String fieldsFromDsRequest = null;

		Map map = null;
		
		
		if(dsRequest.getOperationType().compareToIgnoreCase("remove") == 0 ) {
			
			map = dsRequest.getOldValues();
			
			fieldsFromDsRequest = (String)dsRequest.getHttpServletRequest().getParameter("pfields");
		}
		else {
			
			map = dsRequest.getValues();
			
			fieldsFromDsRequest = (String)dsRequest.getHttpServletRequest().getParameter("fields");
		}
		
		
		
		String str = "";
		
		
		
		String[] fieldsArr = fieldsFromDsRequest.split(",");
		
		
		
		String tFromDsRequest = (String)map.get("TOKEN");
		//String tFromDsRequest = (String)dsRequest.getHttpServletRequest().getParameter("TOKEN");
		//String tFromDsRequest = (String)dsRequest.getAttribute("TOKEN");


		DataSource ds = dsRequest.getDataSource();

		for(int i=0;i<fieldsArr.length;i++) { 
			if(map.get(fieldsArr[i])!=null) {
				/*String fieldType = ds.getField(fieldsArr[i]).getType();
				
				if(fieldType.compareToIgnoreCase("FLOAT") == 0) {
					
					System.out.println("-------------->" + map.get(fieldsArr[i]) + "- " + fieldsArr[i] + " - " + fieldsArr[i].getClass());
				
					String strValue=((String) map.get(fieldsArr[i])).replace(",", ".");
					
					Float value = Float.parseFloat(strValue);					
					
					
					String f = String.format("%.3f", value);

					str+=  f;

				}
				
				else */
				
				str+= map.get(fieldsArr[i]);

			}
		}


		String tcalc = TokenManagement.generateSHA1(str.trim());
		

		HttpServletRequest request = dsRequest.getHttpServletRequest();
		
		if(request.getSession(false) != null && tFromDsRequest.compareTo(tcalc)!=0) {
			//log.info(SECMESSAGE + "Token 2 validation failed with the following token from ds request: " + tFromDsRequest + " and the following expected token: " + tcalc);
			
			return false;
		}

		else return true;
		
	}

	//Valida il t che viene creato dopo ogni richiesta di remove
	//Richiamato nei DMI
	public static boolean validateT2ForRemove(DSRequest dsRequest, DSResponse dsresponse) throws Exception{

		//Logger
		/*Logger log = new Logger(it.ccg.pamp.server.security.TokenManagement.class.getName());
		String LOGMESSAGE = "User: " + dsRequest.getUserId() + "| OperationName: validateT2ForRemove "; 
		String ERRMESSAGE = LOGMESSAGE + " - Error: ";
		String SECMESSAGE = LOGMESSAGE + " - Security event: ";*/

		String pkfieldsFromDsRequest = (String)dsRequest.getHttpServletRequest().getParameter("pfields");


		String str = "";
		Map map = dsRequest.getOldValues();
		Map m2=dsRequest.getValues();
		String tFromDsRequest = (String) map.get("TOKEN");
		//		String tFromDsRequest = (String) map.get("UPDUSR");

		String[] fieldsArr = pkfieldsFromDsRequest.split(",");

		DataSource ds = dsRequest.getDataSource();

		List pkList = ds.getPrimaryKeys();

		Iterator it = pkList.iterator();

		for(int i=0;i<fieldsArr.length;i++){ 
			if(map.get(fieldsArr[i])!=null){
				str+= map.get(fieldsArr[i]);
			}
		}

		String tcalc = TokenManagement.generateSHA1(str.trim());

		HttpServletRequest request = dsRequest.getHttpServletRequest();
		if(request.getSession(false) != null && tFromDsRequest.compareTo(tcalc)!=0) {
			//log.info(SECMESSAGE + "Token 2 validation failed with the following token from ds request: " + tFromDsRequest + " and the following expected token: " + tcalc);

			return false;
		}

		else return true;

	}

	// Metodo che dato un byte[] di dati genera la stringa 
	// che ne rappresenta l'esadecimale
	private static String convertToHex(byte[] data) { 
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < data.length; i++) { 
			int halfbyte = (data[i] >>> 4) & 0x0F;
			int two_halfs = 0;
			do { 
				if ((0 <= halfbyte) && (halfbyte <= 9)) 
					buf.append((char) ('0' + halfbyte));
				else 
					buf.append((char) ('a' + (halfbyte - 10)));
				halfbyte = data[i] & 0x0F;
			} while(two_halfs++ < 1);
		} 
		return buf.toString();
	} 

	public static boolean detectScriptString(DSRequest dsRequest, LogBuffer outLogBuffer) throws Exception{
		
		//Logger
		/*Logger log = new Logger(it.ccg.pamp.server.security.TokenManagement.class.getName());
		String LOGMESSAGE = "User: " + dsRequest.getUserId() + "| OperationName: detectScriptString "; 
		String SECMESSAGE = LOGMESSAGE + " - Security event: ";*/


		String fieldsFromDsRequest = null;

		Map map = null;
		
		
		if(dsRequest.getOperationType().compareToIgnoreCase("remove") == 0 ) {
			
			map = dsRequest.getOldValues();
			
			fieldsFromDsRequest = (String)dsRequest.getHttpServletRequest().getParameter("pfields");
		}
		else {
			
			map = dsRequest.getValues();
			
			fieldsFromDsRequest = (String)dsRequest.getHttpServletRequest().getParameter("fields");
		}
		
		

		//Map map = dsRequest.getValues();
		
		
		String[] fieldsArr = fieldsFromDsRequest.split(",");

		HttpServletRequest request = dsRequest.getHttpServletRequest();

		DataSource ds = dsRequest.getDataSource();

		
		
		Pattern scriptPattern = Pattern.compile("<.*[Ss].*[Cc].*[Rr].*[Ii].*[Pp].*[Tt].*>", Pattern.DOTALL);
		Pattern imgPattern = Pattern.compile("<.*[Ii].*[Mm].*[Gg].*>", Pattern.DOTALL);
		Pattern htmlPattern = Pattern.compile("<.*[Hh].*[Tt].*[Mm].*[Ll].*>", Pattern.DOTALL);
		Pattern objectPattern = Pattern.compile("<.*[Oo].*[Bb].*[Jj].*[Ee].*[Cc].*[Tt].*>", Pattern.DOTALL);
		Pattern videoPattern = Pattern.compile("<.*[Vv].*[Ii].*[Dd].*[Ee].*[Oo].*>", Pattern.DOTALL);
		Pattern alertPattern = Pattern.compile("<.*[Aa].*[Ll].*[Ee].*[Rr].*[Tt].*>", Pattern.DOTALL);
		Pattern basePattern = Pattern.compile("<.*[Bb].*[Aa].*[Ss].*[Ee].*[6].*[4].*>", Pattern.DOTALL);
		
		Pattern[] patterns = {scriptPattern, imgPattern, htmlPattern, objectPattern, videoPattern, alertPattern, basePattern};

		
		for(int i=0;i<fieldsArr.length;i++) { 
			if(map.get(fieldsArr[i])!=null) {
				
				String fieldType = ds.getField(fieldsArr[i]).getType();

				if(fieldType.compareToIgnoreCase("TEXT") == 0) {
					
					for(Pattern pattern : patterns) {
					
						Matcher matcher = pattern.matcher(map.get(fieldsArr[i]).toString());
						
						if(matcher.find()) {
							//log.info(SECMESSAGE + "XSS detected. Invalidating session.");
							outLogBuffer.setMessage((String)map.get(fieldsArr[i]));
							
							return false;
						}
					
					}
					
					
				}
			}
		}

		return true;
	}
	

	//Metodo che data una stringa Genera il codice SHA1 (in esadecimale)
	public static String generateSHA1(String text) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		
		text = text.replaceAll("[^A-Za-z0-9]", "0");
		
		
		MessageDigest md;
		md = MessageDigest.getInstance("SHA-1");
		byte[] sha1hash = new byte[40];
		md.update(text.getBytes("iso-8859-1"), 0, text.length());
		sha1hash = md.digest();
		return convertToHex(sha1hash);
	} 

	//Metodo che data una stringa Genera il codice MD5 (in esadecimale)
	public static String MD5(String text) throws NoSuchAlgorithmException, UnsupportedEncodingException  {
		
		text = text.replaceAll("[^A-Za-z0-9]", "0");
		
		
		MessageDigest md;
		md = MessageDigest.getInstance("MD5");
		byte[] md5hash = new byte[32];
		md.update(text.getBytes("iso-8859-1"), 0, text.length());
		md5hash = md.digest();
		return convertToHex(md5hash);
	} 


	public static void setSessionMaxInactiveInterval(HttpSession session){
//		System.out.println("******************************************************* setSessionMaxInactiveInterval ***************************************************************************");
//		System.out.println("************************ setSessionMaxInactiveInterval SESSIONID: " + session.getId());
		session.setMaxInactiveInterval(10*60);

	}

	/* * Tramite ibm_security_logout:
        - Cancella i cookie SSO (single sign-on) / LTPA (Lightweight Third Party Authentication)
        - Invalida la sessione HTTP
        - Rimuove l'utente dalla cache di autenticazione

      Al momento della disconnessione, l'utente viene reindirizzato a una pagina di 
      uscita di disconnessione(Login page).*/
/*	public static void invalidateSession(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, TokenManagerLocal tokenManager, String errorType) throws IOException{

		String logoutPage= "/concurrentError.jsp";

		//Utilizzo ibm_security_logout e faccio il forward verso la pagina di login
		String  logoutURL= "ibm_security_logout?logout=Logout&logoutExitPage=" + logoutPage;
		
		
		RequestDispatcher dispatcher =  httpServletRequest.getSession().getServletContext().getRequestDispatcher(logoutURL);
	    try {
			dispatcher.forward(httpServletRequest, httpServletResponse);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}*/

	
	public static void invalidateSession(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException{
		
		String logoutPage= "/login.jsp";

		//Utilizzo ibm_security_logout e faccio il forward verso la pagina di login
		String  logoutURL= "ibm_security_logout?logout=Logout&logoutExitPage=" + logoutPage;
		
		
		RequestDispatcher dispatcher =  httpServletRequest.getSession().getServletContext().getRequestDispatcher(logoutURL);
	    try {
			dispatcher.forward(httpServletRequest, httpServletResponse);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	/* * Tramite ibm_security_logout:
        - Cancella i cookie SSO (single sign-on) / LTPA (Lightweight Third Party Authentication)
        - Invalida la sessione HTTP
        - Rimuove l'utente dalla cache di autenticazione

      Al momento della disconnessione, l'utente viene reindirizzato a una pagina di 
      uscita di disconnessione(Login error page).*/
	/*public static void invalidateAndLock(HttpServletRequest request, HttpServletResponse
			response, TokenManagerLocal tokenManager) throws Exception{

		//Inizializzazione messaggi d'errore
		SecurityMessages sM=new SecurityMessages();

		//Logger
		Logger log = new Logger(it.ccg.pamp.server.security.TokenManagement.class.getName());
		String LOGMESSAGE = "User: " + request.getUserPrincipal().getName() + "| OperationName: invalidateAndLock "; 
		String ERRMESSAGE = LOGMESSAGE + " - Error: ";
		String SECMESSAGE = LOGMESSAGE + " - Security event: ";

		log.info(LOGMESSAGE);

		Cookie c = new Cookie("loginError", sM.smInvalidateSessionForConcurrent());

		c.setMaxAge(-1);
		response.addCookie(c);

		String notvalidtoken = "";

		notvalidtoken = MD5("zxcvfr4321qaz");

		//Definisco la pagina dove fare la redirect 
		String logoutPage="/login.jsp";

		String user = ((HttpServletRequest) request).getUserPrincipal().getName();




		//Utilizzo ibm_security_logout e faccio la redirect verso la pagina di loginError
		String  logoutURL= "ibm_security_logout?logout=Logout&logoutExitPage=" + logoutPage;

		response.sendRedirect(response.encodeURL(logoutURL));





	}*/


}