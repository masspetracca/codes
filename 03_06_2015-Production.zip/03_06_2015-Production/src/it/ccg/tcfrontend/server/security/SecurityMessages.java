package it.ccg.tcfrontend.server.security;

import java.util.LinkedHashMap;

public class SecurityMessages {
	

	public  LinkedHashMap<Integer,String> map = new LinkedHashMap<Integer, String>();
	
	public SecurityMessages() {
		super();
		map.put(-100,"Invalid credential error.<br /> After 3 wrong trials the account will be locked. To obtain a new password please contact the helpdesk.");
		map.put(-101,"Account locked error.<br /> The account is now locked after 3 unsuccessful trials. Please wait 30 minutes to get it unlocked.");
		map.put(-102,"Another user is currently logged on using the same account. <br /> The two sessions have been invalidated.");
		map.put(-103,"Current session has been invalidated.");
		map.put(-104,"User profile not complete. Current session has been invalidated. Please contact the helpdesk for further information.");
		
	}
	
	public String getMessageDescription(String code){
		try{
			//I cookies per definizione vogliono stringhe come parametri. 
			//Per garantire la sicurezza ed evitare cross site scripting, facciamo il parseInt dell'intero che viene passato come stringa
			return (map.get(Integer.parseInt(code)) != null ? map.get(Integer.parseInt(code)) : "ERROR");
		}
		catch(Exception e){
			return map.get(-100);
		}
	}
	
	public  String smAuthenticationError(){return("-100");}
	
	public  String smAccountLocked(){return("-101");}
	
	public  String smInvalidateSessionForConcurrent(){return("-102");}
	
	public  String smInvalidateSession(){return("-103");}
	
	public  String smNoCompanyAfterLogin(){return("-104");}

	
	
		
	
}
