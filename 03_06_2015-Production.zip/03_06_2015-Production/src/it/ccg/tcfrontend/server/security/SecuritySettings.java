package it.ccg.tcfrontend.server.security;

import it.ccg.tcejb.server.exception.PropertyException;
import it.ccg.tcejb.server.properties.view.PropertiesEAOLocal;
import it.ccg.tcfrontend.client.utils.DevelopmentMode;
import it.ccg.tcfrontend.server.utils.ProxyEJB;



public class SecuritySettings {
	
	// jndi lookup of ejb interface
	private static  PropertiesEAOLocal propertiesEAOLocal = (PropertiesEAOLocal)ProxyEJB.getEJBInterfaceReference("ejb/PropertiesEAO");
	

	public static boolean getIsEnable() {
		
		boolean isEnable = false;
		
		if(DevelopmentMode.getDevelopmentMode()){
			return false;
		}
		
		try {
			int value = Integer.parseInt((propertiesEAOLocal.getPropertyMap().get("security")));
			
			if(value != 0) {
				isEnable = true;
			}
			
			
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PropertyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isEnable;
	}


	
}