package it.ccg.tcfrontend.server.security;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class RemoveInvalidChar {
	
	//Not valid characters
	//static String notValidChar = "/,\\,>,<,?,=,%,$,�,\",#";
	
	
	
	private static Pattern pattern = Pattern.compile("[/\\\\><?=%$�\"#]");
	
	public static boolean checkInvalidChar(String str) throws Exception {
		
		boolean result = false;
		
		Matcher matcher = pattern.matcher(str);
		
		if(matcher.find()) {
			result = true;
		}
		
		return result;
		
	}
	
	
	// OLD
	/*public static void removeInvalidChar(String str) throws Exception{

		//Logger
		Logger log = new Logger(it.ccg.pamp.server.security.RemoveInvalidChar.class.getName());
		String LOGMESSAGE =  "| OperationName: SecurityFilter removeInvalidChar "; 
		String SECMESSAGE = LOGMESSAGE + " - Security event: ";
		
		String[] invalidChars = notValidChar.split(",");

		for(int i =0; i<invalidChars.length;i++){
			String invalidChar = invalidChars[i];

			if(str.contains(invalidChar)){
				if(invalidChar.compareTo("\\")==0){
					str = str.replaceAll("\\" + invalidChar, "");
				}
				else {str = str.replaceAll(invalidChar, "");}
				
				log.info(SECMESSAGE + "Invalid char have been removed: " + str);

			}
		}

	}*/
	
	/*public static void removeInvalidChar(String str, HttpServletRequest httpServletRequest) throws Exception{

		//Logger
		Logger log = new Logger(it.ccg.pamp.server.security.TokenManagement.class.getName());
		String LOGMESSAGE =  "| OperationName: SecurityFilter removeinvalidchar "; 
		String SECMESSAGE = LOGMESSAGE + " - Security event: ";
		
		
		String[] invalidChars = notValidChar.split(",");

		String str1 = "";
		
		for(int i =0; i<invalidChars.length;i++){
			String invalidChar = invalidChars[i];

			if(str.contains(invalidChar)){
				if(invalidChar.compareTo("\\")==0){
					str1 = str.replaceAll("\\" + invalidChar, "");
				}
				else str1 = str.replaceAll(invalidChar, "");

			}
		}
		log.info(SECMESSAGE + "invalid char have been removed. Initially string: " + str + "  Modifyed string: " + str1);

	}
	*/

}
