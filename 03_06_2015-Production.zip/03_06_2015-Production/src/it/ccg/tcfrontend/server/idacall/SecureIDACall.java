package it.ccg.tcfrontend.server.idacall;

import it.ccg.tcfrontend.server.utils.DevelopmentModeServerSide;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isomorphic.rpc.RPCManager;
import com.isomorphic.servlet.IDACall;
import com.isomorphic.servlet.RequestContext;

/**
 * Servlet implementation class SecureIDACall
 */
public class SecureIDACall extends IDACall {

	private static final long serialVersionUID = 1L;

	public void processRequest(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
	{
		//L'utente non � autenticato: se sono in development mode (Costante settata qui!!!!!!) 
		//allora passo io la stringa con i ruoli
		//Altrimenti lancio un'eccezione
		if(DevelopmentModeServerSide.getDevelopmentMode()){
			try {
				RequestContext context = RequestContext.instance(this, request, response);   
				RPCManager rpc = new RPCManager(request, response);
				rpc.setAuthenticated(true);
				rpc.setUserRoles("user"); 
				processRPCTransaction(rpc, context);
			
				
			} catch (Throwable e) {
				handleError(response, e);
			}
		} 
		else {
			super.processRequest(request, response);
		}
	} 

	
	
}

