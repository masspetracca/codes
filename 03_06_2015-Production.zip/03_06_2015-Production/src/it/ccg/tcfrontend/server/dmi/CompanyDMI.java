package it.ccg.tcfrontend.server.dmi;

import it.ccg.tcejb.server.security.UserInfoManager;
import it.ccg.tcfrontend.server.utils.ProxyEJB;

import java.sql.Timestamp;
import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletRequest;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;
import com.isomorphic.datasource.DataSource;

public class CompanyDMI {

	private static  UserInfoManager userInfoManager = (UserInfoManager)ProxyEJB.getEJBInterfaceReference("ejb/UserInfoManager");

	//metodo utilizzato per forzare la company durante le query
	//la company da filtrare sar� presa dall'oggetto privileges che contiene la company dello user loggato recuperata al momento del login
	public DSResponse enforceCompanyFilter(DSRequest dsRequest, HttpServletRequest servletRequest)  
			throws Exception  
			{  
		int companyId=1;
		String user="TEST";

		if(userInfoManager!=null){
			companyId = Integer.parseInt(userInfoManager.fetchField("COMPANYID"));  
			user=servletRequest.getUserPrincipal().getName();
		}

		if (DataSource.isAdd(dsRequest.getOperationType())) { 

			dsRequest.setFieldValue("CMPNID", companyId);
			dsRequest.setFieldValue("UPDTYPE", "C");
			dsRequest.setFieldValue("UPDUSER", user);
			dsRequest.setFieldValue("UPDDATE", systemDate());
		}
		else  if(DataSource.isUpdate(dsRequest.getOperationType())) {

			dsRequest.setFieldValue("CMPNID", companyId);
			dsRequest.setFieldValue("UPDTYPE", "U");
			dsRequest.setFieldValue("UPDUSER", user);
			dsRequest.setFieldValue("UPDDATE", systemDate());

		} else{
			dsRequest.setCriteriaValue("CMPNID", companyId);  
		}
		return dsRequest.execute();  
			} 


	//Get System date
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}

}
