package it.ccg.tcfrontend.server.dmi;

import it.ccg.tcejb.server.security.UserInfoManager;
import it.ccg.tcfrontend.server.utils.ProxyEJB;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;
import com.isomorphic.log.Logger;


public class UserDMI {

	private static  UserInfoManager userInfoManager = (UserInfoManager)ProxyEJB.getEJBInterfaceReference("ejb/UserInfoManager");

	//Fetch operation
	public DSResponse fetch(DSRequest dsRequest,HttpServletRequest servletRequest) throws Exception { 
		DSResponse response=null;
		Logger log = new Logger(it.ccg.tcfrontend.server.dmi.UserDMI.class.getName());
		
		int companyId=1;
		String user="TEST";

		if(userInfoManager!=null){
			companyId = Integer.parseInt(userInfoManager.fetchField("COMPANYID"));  
			user=servletRequest.getUserPrincipal().getName();
		}

		try{
			user=servletRequest.getUserPrincipal().getName();
		}
		catch(Exception e){
			System.out.println("Authentication failed: getting System user");
		}

		String logMessage = "User: " + user + "| OperationType: "+ dsRequest.getOperationType() + "| OperationID: "+dsRequest.getOperationId();

		Map<String,String> c=dsRequest.getCriteria();
		c.put("USER", user);
		c.put("CMPNID", companyId+"");

		dsRequest.setCriteria(c);

		try{
			response=dsRequest.execute();		
		}
		catch(Exception e){
			throw(e);
		}

		return response;
	}

	//Add operation
	public DSResponse add(DSRequest dsRequest,HttpServletRequest servletRequest)throws Exception   {

		int companyId=1;
		String user="TEST";

		if(userInfoManager!=null){
			companyId = Integer.parseInt(userInfoManager.fetchField("COMPANYID"));  
			user=servletRequest.getUserPrincipal().getName();
		}

		dsRequest.setFieldValue("CMPNID", companyId);
		dsRequest.setFieldValue("UPDUSR", user);
		dsRequest.setFieldValue("UPDTYPE", "C");
		dsRequest.setFieldValue("UPDDATE", systemDate());


		return dsRequest.execute();  

	}  

	//Update operation
	public DSResponse update(DSRequest dsRequest,HttpServletRequest servletRequest)throws Exception   {

		int companyId=1;
		String user="TEST";

		if(userInfoManager!=null){
			companyId = Integer.parseInt(userInfoManager.fetchField("COMPANYID"));  
			user=servletRequest.getUserPrincipal().getName();
		}

		Map<String,String> c=dsRequest.getCriteria();
		c.put("USER", user);
		c.put("CMPNID", companyId+"");
		
		dsRequest.setCriteria(c);
		
		dsRequest.setFieldValue("CMPNID", companyId);
		dsRequest.setFieldValue("UPDUSR", user);
		dsRequest.setFieldValue("UPDTYPE", "U");
		dsRequest.setFieldValue("UPDDATE", systemDate());

		
		return dsRequest.execute();  

	}  


	//Remove operation
	public DSResponse remove(DSRequest dsRequest,HttpServletRequest servletRequest)throws Exception   { 

		int companyId=1;
		String user="TEST";

		if(userInfoManager!=null){
			companyId = Integer.parseInt(userInfoManager.fetchField("COMPANYID"));  
			user=servletRequest.getUserPrincipal().getName();
		}

		dsRequest.setFieldValue("UPDUSR", user);
		dsRequest.setFieldValue("CMPNID", companyId+"");


		return dsRequest.execute();  

	}

	//Get System date
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}




}
