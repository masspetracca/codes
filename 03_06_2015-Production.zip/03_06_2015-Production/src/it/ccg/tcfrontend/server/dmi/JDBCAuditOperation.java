package it.ccg.tcfrontend.server.dmi;

import it.ccg.tcejb.server.security.UserInfoManager;
import it.ccg.tcfrontend.server.utils.ProxyEJB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;
import com.isomorphic.datasource.DataSource;
import com.isomorphic.sql.SQLConnectionManager;

public class JDBCAuditOperation {  

	private static  UserInfoManager userInfoManager = (UserInfoManager)ProxyEJB.getEJBInterfaceReference("ejb/UserInfoManager");

	public DSResponse jdbcUpdateAuditRun(DSRequest dsRequest) throws Exception { 

		/*return updateAuditTable(dsRequest,null, "INSERT INTO TCTUSRACT(AUDIT_OPERATIONTYPE, AUDIT_CHANGETIME, AUDIT_MODIFIER, OLDRECORD, NEWRECORD, CMPNID, RUNID) VALUES(?, ?, ?, ?, ?, ?, ?)");  */
		
		return updateAuditTable(dsRequest,null, "INSERT INTO TCTUSRACT(AUDIT_OPERATIONTYPE, AUDIT_CHANGETIME, AUDIT_MODIFIER, NEWRECORD, CMPNID, RUNID) VALUES(?, ?, ?, ?, ?, ?)");

		/*} 
		else return dsRequest.execute();*/
	}  

	/*public DSResponse jdbcUpdateRUNRecall(DSRequest req) throws Exception {  
	        return update(req, "update TCTRUNREG set SUBDATE='' REPORT='F' where CMPNID=? and RUNID=?");  
	    }*/

	public DSResponse updateAuditTable(DSRequest dsRequest, DSResponse dsResponse, String sqlQuery) throws Exception{

		DSResponse resp = dsRequest.execute();
		
		Connection conn = SQLConnectionManager.getConnection();  

		int companyId=1;
		String user="user";
		int runId=-1;

		if(userInfoManager!=null){
			companyId = Integer.parseInt(userInfoManager.fetchField("COMPANYID"));  
			user = dsRequest.getUserId();
		}

		DataSource ds = dsRequest.getDataSource();

		//Array contenente i nomi dei campi del record		
		List attributes=ds.getFieldNames();
		//Mappe valori record
		Map oldValuesmap = dsRequest.getOldValues();
		Map newValuesmap = dsRequest.getValues();


		/*System.out.println("***********OLDVALMAP: "+oldValuesmap);
		System.out.println("***********NEWVALMAP: "+newValuesmap);*/

		String oldValuesStr = "";
		String newValuesStr = "";

		Iterator it = attributes.iterator();

		//OLD 
		while(it.hasNext()){

			String fieldName = it.next().toString();
			oldValuesStr+= fieldName+": "+oldValuesmap.get(fieldName)+" | ";
			if(oldValuesmap.get("RUNID")!=null){
			runId=Integer.parseInt(oldValuesmap.get("RUNID").toString());
			}
			if(newValuesmap.get(fieldName)==null){
				newValuesStr+= fieldName+": "+oldValuesmap.get(fieldName)+" | ";
			}else newValuesStr+= fieldName+": "+newValuesmap.get(fieldName)+" | ";
		}
		/*System.out.println("***********OLDVAL: "+oldValuesStr);
		System.out.println("***********NEWVAL: "+newValuesStr);*/


		PreparedStatement stmt = conn.prepareStatement(sqlQuery);  
		stmt.setString(1, dsRequest.getOperation());      
		stmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));        
		stmt.setString(3, user);
		//	        Object compID = req.getFieldValue("CMPNID");//.getValues().get("compid");
//		stmt.setString(4, oldValuesStr);  
		stmt.setString(4, newValuesStr);  
		stmt.setInt(5, companyId);
		stmt.setInt(6, runId);
		stmt.executeUpdate();  
		stmt.close();  

		resp.setStatus(DSResponse.STATUS_SUCCESS);  
		return resp;  
	}




} 