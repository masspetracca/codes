package it.ccg.tcfrontend.server.dmi;

import it.ccg.tcejb.server.security.UserInfoManager;
import it.ccg.tcfrontend.server.utils.ProxyEJB;

import java.sql.Connection;  
import java.sql.PreparedStatement;  
import java.sql.ResultSet;
import java.sql.Timestamp;  
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
  
import com.isomorphic.datasource.BasicDataSource;  
import com.isomorphic.datasource.DSRequest;  
import com.isomorphic.datasource.DSResponse;  
  
public class JDBCOperations {  
  
	private static  UserInfoManager userInfoManager = (UserInfoManager)ProxyEJB.getEJBInterfaceReference("ejb/UserInfoManager");
	
	 
	
	public DSResponse jdbcUpdateOutstandingCorrisp(DSRequest req) throws Exception {  
		return update(req, "update TCTCORRISP set UPDDATE=?,STATUS='F', UPDUSER=? where CMPNID=? and STATUS='O'");  
	}
	
    public DSResponse jdbcUpdateRUN(DSRequest req) throws Exception {  
     return update1(req, "update TCTRUNREG set SUBDATE=?,REPORT='T', UPDUSER=?, SUBMITTER=? where CMPNID=? and  RUNID in(select RUNID from TCTRUNREG where SUBDATE is NULL and MATCHFOUND='T')");  
    }  
    
    public DSResponse jdbcUpdateRUNRecall(DSRequest req) throws Exception {  
        return update2(req, "update TCTRUNREG set UPDDATE=?, SUBDATE=NULL , REPORT='F',APPROVER='', UPDUSER=?, SUBMITTER='', APPROVED='F' where CMPNID=? and RUNID IN(?)");  
    }
  
    public DSResponse jdbcUpdateRecallCorrisp(DSRequest req) throws Exception {  

        return update3(req, "update TCTCORRISP set UPDDATE=?, STATUS='O', UPDUSER=? where CMPNID=? and RUNID IN(?) and STATUS IN ('F','P')");  
    } 
    
    public DSResponse jdbcUpdateApproveRUN(DSRequest req) throws Exception {  
        return update4(req, "update TCTRUNREG set UPDDATE=?, APPROVER=?, UPDUSER=?, APPROVED='T' where CMPNID=? and SUBDATE IS NOT NULL and APPROVED='F' and MATCHFOUND = 'T'");  
    }
        
    
    /*
    public DSResponse jdbcUpdateForcedMatchFalnegt(DSRequest req) throws Exception {  
        return update(req, "update TCTFALNEGT set UPDDATE=?,STATUS='T', UPDUSER=? where CMPNID=? and STATUS='O'");  
    }
    */
      
    public DSResponse update(DSRequest req, String sql) throws Exception {  
  
        DSResponse resp = new DSResponse();  
  
        
        // We must mark the DSRequest as transactional, so that SmartClient Server knows whether  
        // to mark it as failed if another transactional update fails  
        req.setPartOfTransaction(true);  
        
        // We make the update part of the transaction by using the dataSource's transaction  
        // object, which in the case of a SQLDataSource will be a java.sql.Connection  
        Connection conn = (Connection)((BasicDataSource)req.getDataSource()).getTransactionObject(req);  
        if (conn == null) {  
            resp.setStatus(-1);  
            resp.setData("No transaction to join.  Please make some changes before clicking " +  
                         "the Save buttons");  
            return resp;  
        }  
        
        int companyId=1;

		if(userInfoManager!=null){
			companyId = Integer.parseInt(userInfoManager.fetchField("COMPANYID"));  
		}

        PreparedStatement stmt = conn.prepareStatement(sql);  
        stmt.setTimestamp(1, new Timestamp(System.currentTimeMillis()));        
        stmt.setString(2, req.getUserId());
//        Object compID = req.getFieldValue("CMPNID");//.getValues().get("compid");
        stmt.setInt(3, companyId);
        stmt.executeUpdate();  
        stmt.close();  
//        resp.setParameter("TEST", "test");
        
        resp.setStatus(DSResponse.STATUS_SUCCESS);  
        return resp;  
    }
    
    public DSResponse update1(DSRequest req, String sql) throws Exception {  
    	  
        DSResponse resp = new DSResponse();  
  
        
        // We must mark the DSRequest as transactional, so that SmartClient Server knows whether  
        // to mark it as failed if another transactional update fails  
        req.setPartOfTransaction(true);  
        
        // We make the update part of the transaction by using the dataSource's transaction  
        // object, which in the case of a SQLDataSource will be a java.sql.Connection  
        Connection conn = (Connection)((BasicDataSource)req.getDataSource()).getTransactionObject(req);  
        if (conn == null) {  
            resp.setStatus(-1);  
            resp.setData("No transaction to join.  Please make some changes before clicking " +  
                         "the Save buttons 1");  
            return resp;  
        }  
        
        int companyId=1;

		if(userInfoManager!=null){
			companyId = Integer.parseInt(userInfoManager.fetchField("COMPANYID"));  
		}

        PreparedStatement stmt = conn.prepareStatement(sql);  
        stmt.setTimestamp(1, new Timestamp(System.currentTimeMillis()));        
        stmt.setString(2, req.getUserId());
        stmt.setString(3, req.getUserId());
//        Object compID = req.getFieldValue("CMPNID");//.getValues().get("compid");
        stmt.setInt(4, companyId);
        stmt.executeUpdate();  
        stmt.close();  
//        resp.setParameter("TEST", "test");
        
        resp.setStatus(DSResponse.STATUS_SUCCESS);  
        return resp;  
    } 
    
    public DSResponse update2(DSRequest req, String sql) throws Exception {  
    	  
        DSResponse resp = new DSResponse();  
  
        
        // We must mark the DSRequest as transactional, so that SmartClient Server knows whether  
        // to mark it as failed if another transactional update fails  
        req.setPartOfTransaction(true);  
        
        // We make the update part of the transaction by using the dataSource's transaction  
        // object, which in the case of a SQLDataSource will be a java.sql.Connection  
        Connection conn = (Connection)((BasicDataSource)req.getDataSource()).getTransactionObject(req);  
        if (conn == null) {  
            resp.setStatus(-1);  
            resp.setData("No transaction to join.  Please make some changes before clicking " +  
                         "the Save buttons 2");  
            return resp;  
        }  
        
        int companyId=1;

		if(userInfoManager!=null){
			companyId = Integer.parseInt(userInfoManager.fetchField("COMPANYID"));  
		}

        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
        stmt.setString(2, req.getUserId());
        stmt.setInt(3, companyId);
        stmt.setString(4,req.getValues().get("RUNID").toString());
        stmt.executeUpdate();  
        stmt.close();  
        
        resp.setStatus(DSResponse.STATUS_SUCCESS);  
        return resp;  
    }
    
    
    public DSResponse update3(DSRequest req, String sql) throws Exception {  
  	  
        DSResponse resp = new DSResponse();  
  
        
        // We must mark the DSRequest as transactional, so that SmartClient Server knows whether  
        // to mark it as failed if another transactional update fails  
        req.setPartOfTransaction(true);  
        
        // We make the update part of the transaction by using the dataSource's transaction  
        // object, which in the case of a SQLDataSource will be a java.sql.Connection  
        Connection conn = (Connection)((BasicDataSource)req.getDataSource()).getTransactionObject(req);  
        if (conn == null) {  
            resp.setStatus(-1);  
            resp.setData("No transaction to join.  Please make some changes before clicking " +  
                         "the Save buttons 3");  
            return resp;  
        }  
        
        int companyId=1;

		if(userInfoManager!=null){
			companyId = Integer.parseInt(userInfoManager.fetchField("COMPANYID"));  
		}
		
//		int[] runId = (int[]) req.getValues().get("RUNID"); 
//
//		String run = "";
//		
//		run = runId[0]+"";
//		
//		if(runId.length>1){	
//			for(int i=1;i<runId.length;i++){
//				run += ","+runId[i];
//			}
//		}
		
		req.getFieldValue("RUNID");
		
	    PreparedStatement stmt = conn.prepareStatement(sql);  
        stmt.setTimestamp(1, new Timestamp(System.currentTimeMillis()));        
        stmt.setString(2, req.getUserId());
        stmt.setInt(3, companyId);
        //stmt.setString(4, run);
        stmt.setString(4,req.getValues().get("RUNID").toString());
        stmt.executeUpdate();  
        stmt.close();  
       
        
        resp.setStatus(DSResponse.STATUS_SUCCESS);  
        return resp;  
    }

    public DSResponse update4(DSRequest req, String sql) throws Exception {  
    	  
        DSResponse resp = new DSResponse();  
  
        
        // We must mark the DSRequest as transactional, so that SmartClient Server knows whether  
        // to mark it as failed if another transactional update fails  
        req.setPartOfTransaction(true);  
        
        // We make the update part of the transaction by using the dataSource's transaction  
        // object, which in the case of a SQLDataSource will be a java.sql.Connection  
        Connection conn = (Connection)((BasicDataSource)req.getDataSource()).getTransactionObject(req);  
        if (conn == null) {  
            resp.setStatus(-1);  
            resp.setData("No transaction to join.  Please make some changes before clicking " +  
                         "the Save buttons 3");  
            return resp;  
        }  
        
        int companyId=1;

		if(userInfoManager!=null){
			companyId = Integer.parseInt(userInfoManager.fetchField("COMPANYID"));  
		}
				
		req.getFieldValue("RUNID");
		
	    PreparedStatement stmt = conn.prepareStatement(sql);  
        stmt.setTimestamp(1, new Timestamp(System.currentTimeMillis()));        
        stmt.setString(2, req.getUserId());
        stmt.setString(3, req.getUserId());
        stmt.setInt(4, companyId);
        stmt.executeUpdate();  
        stmt.close();  
       
        
        resp.setStatus(DSResponse.STATUS_SUCCESS);  
        return resp;  
    }
    
    
    /*  
    public DSResponse updateOutstandingCorrisp(DSRequest req, String sql) throws Exception {  
  
        DSResponse resp = new DSResponse();  
        
        System.out.println(sql);
  
        // We must mark the DSRequest as transactional, so that SmartClient Server knows whether  
        // to mark it as failed if another transactional update fails  
        req.setPartOfTransaction(true);  
          
        // We make the update part of the transaction by using the dataSource's transaction  
        // object, which in the case of a SQLDataSource will be a java.sql.Connection  
        Connection conn = (Connection)((BasicDataSource)req.getDataSource()).getTransactionObject(req);  
        if (conn == null) {  
            resp.setStatus(-1);  
            resp.setData("No transaction to join.  Please make some changes before clicking " +  
                         "the Save buttons");  
            return resp;  
        }  
        PreparedStatement stmt = conn.prepareStatement(sql);  
       // stmt.setTimestamp(1, new Timestamp(System.currentTimeMillis()));  
        Object compID = req.getValues().get("compid");  
        stmt.setInt(1, Integer.parseInt(compID.toString()));  
        stmt.executeUpdate();  
        stmt.close();  
        resp.setStatus(DSResponse.STATUS_SUCCESS);  
        return resp;  
    }
    */
    
    
    
    
    
} 