package it.ccg.tcfrontend.server.dmi;


import javax.ejb.Local;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;


@Local
public interface TimerDmiDAOLocal {
	
	public DSResponse fetch(DSRequest dsRequest) throws Exception;
	public Object add(DSRequest dsRequest) throws Exception;
	public Object update(DSRequest dsRequest) throws Exception;
	public Object remove(DSRequest dsRequest) throws Exception;
	public Object removeAll(DSRequest dsRequest) throws Exception;
	
}
