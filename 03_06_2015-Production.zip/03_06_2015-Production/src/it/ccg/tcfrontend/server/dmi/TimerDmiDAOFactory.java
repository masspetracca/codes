package it.ccg.tcfrontend.server.dmi;

import it.ccg.tcejb.server.system.LocalBeanLookup;

public class TimerDmiDAOFactory {
	
	
	public TimerDmiDAOFactory() {
		
	}
	
	
	
	public TimerDmiDAOLocal create() throws Exception {
        
        TimerDmiDAOLocal timerDmiDAOLocal = (TimerDmiDAOLocal)LocalBeanLookup.lookup(TimerDmiDAOLocal.class.getName());
        
        if(timerDmiDAOLocal==null)
        System.out.println("************* timerDmiDAOLocal not found");
        else System.out.println("************* timerDmiDAOLocal FOUND");
		
		return timerDmiDAOLocal;
	}

}
