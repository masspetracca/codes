package it.ccg.tcfrontend.server.exceptions;



public class PropertyException extends Exception {



	public PropertyException(String message) {
		super(message);
		
	}

	

}