package it.ccg.tcfrontend.server.utils;

public class DevelopmentModeServerSide {

	public static boolean getDevelopmentMode(){
		return  false;
	}
	
}
