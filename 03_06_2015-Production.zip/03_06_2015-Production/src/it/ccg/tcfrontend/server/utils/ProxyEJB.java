package it.ccg.tcfrontend.server.utils;

import javax.naming.InitialContext;

public class ProxyEJB {

	private static String ejbBusinessInterfacePrefix = "java:comp/env/";
	
	public static Object getEJBInterfaceReference(String ejbRefName) {
		try {
			return new InitialContext().lookup(ejbBusinessInterfacePrefix + ejbRefName);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
