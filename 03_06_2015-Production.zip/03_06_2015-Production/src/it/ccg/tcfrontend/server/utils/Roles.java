package it.ccg.tcfrontend.server.utils;


public class Roles {

	public static String USER="user";
	public static String VISITOR="visitor";
	public static String MANAGER="manager";
	public static String ADMIN="admin";
	public static String SUPERVISOR="supervisor";
	public static String APPROVER="approver";
	
	
	public static String[] getAllRoles(){
		return new String[]{USER,VISITOR,ADMIN,MANAGER,SUPERVISOR,APPROVER};
	}
	
}
