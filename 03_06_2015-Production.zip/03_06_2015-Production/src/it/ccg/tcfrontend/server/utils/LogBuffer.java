package it.ccg.tcfrontend.server.utils;


public class LogBuffer {
	
	private String message;
	
	
	public LogBuffer() {
		this.message = new String();
	}


	
	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}

}
