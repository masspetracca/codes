package it.ccg.tcfrontend.client;

import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.events.MenuItemClickEvent;
import com.smartgwt.client.widgets.viewer.DetailViewer;

public class DetailsWindow extends Window {
	private DetailViewer detailsV;

	final int TOPTOOLBARHEIGHT = 30; // Top toolbar height
	final int BOTTOMTOOLBARHEIGHT = 30; // Bottom toolbar height
	final int BUTWIDTH = 100; // Button width
	final int CTRHEIGHT = 20; // Control height
	final int CTRMARGINS = 15; // Control margins

	final boolean BUTSHOWDOWN = true;
	final boolean BUTSHOWROLLOVER = true;

	public DetailsWindow(ListGrid grid, String id, String name, int width) {
		super();
		this.setID("DT" + id);
		this.setTitle(name);
		this.setLeft("25%");
		this.setTop("25%");
		this.setWidth(width);
		this.setHeight(400);
	
		this.setCanDragReposition(true);
		this.setCanDragResize(true);
		
		detailsV = new DetailViewer();
		detailsV.setDatetimeFormatter(DateDisplayFormat.TOEUROPEANSHORTDATETIME);

		detailsV.setWidth("95%");
		detailsV.setLayoutAlign(VerticalAlignment.CENTER);
		detailsV.setRecordsPerBlock(6);
		detailsV.setDataSource(grid.getDataSource());
		detailsV.setShowDetailFields(true);
		detailsV.viewSelectedData(grid);
		detailsV.setEmptyCellValue("n/a");
//		detailsV.setShowEmptyField(false);
		
		
		this.addItem(detailsV);
		
		final Window w = this;
		Menu menu = new Menu();
		menu.setWidth(140);
		MenuItem closeItem = new MenuItem("Close");

		closeItem.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {

				w.destroy();
			}
		});
	
		this.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {

				w.destroy();
			}
		});
		// Define context menu
		menu.setItems(closeItem);
		this.setContextMenu(menu);

		this.draw();

	}

	public static DetailsWindow windowCreator(ListGrid grid, String chid, String name, int numCol) {
		// TODO Auto-generated method stub
		DetailsWindow ew = (DetailsWindow) Canvas.getById("DT" + chid);
		int width = numCol <= 6 ? numCol * 100 + 500 : 1200;
		if (ew != null) {
			ew.setVisible(true);
			ew.getDetailsV().viewSelectedData(grid);
			ew.bringToFront();
			ew.setTitle(name);
			ew.setWidth(width);
			return ew;
		} else {
			return new DetailsWindow(grid, chid, name, width);

		}
	}

	public DetailViewer getDetailsV() {
		return detailsV;
	}

	public void setDetailsV(DetailViewer detailsV) {
		this.detailsV = detailsV;
	}

}
