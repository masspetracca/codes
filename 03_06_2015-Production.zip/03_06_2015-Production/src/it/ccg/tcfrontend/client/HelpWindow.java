package it.ccg.tcfrontend.client;

import java.util.LinkedHashMap;

import com.smartgwt.client.types.ContentsType;
import com.smartgwt.client.types.SendMethod;
import com.smartgwt.client.widgets.HTMLPane;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.tab.TabSet;

public class HelpWindow  extends Window {


	public HelpWindow(TabSet mts, String sourcePan) {
		super();

		final Window wind=this;
		this.setID(sourcePan+"_hw");
		// this.setAutoSize(true);
		this.setTitle("Help");
		this.setWidth(800);
		this.setHeight(600);
		this.centerInPage();
		this.setCanDragReposition(true);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);
		
		this.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {

				wind.destroy();
			}
		});

		HTMLPane hp = new HTMLPane();
		hp.setHeight100();
		hp.setWidth100();
		hp.setHttpMethod(SendMethod.POST);
		hp.setContentsType(ContentsType.PAGE);
		LinkedHashMap<String, Integer> params=new LinkedHashMap<String, Integer>();
		//params.put("instrId", instrid);
		hp.setContentsURL("helppages/"+sourcePan+".html");
		hp.setMargin(0);
		hp.setPadding(0);
		this.addItem(hp);
		//workingArea.addChild(window);
		this.draw();

	}

	
	public static HelpWindow windowCreator2(TabSet mts, String sourcePan) {

		return new HelpWindow(mts, sourcePan);
		

		// }

	}

}