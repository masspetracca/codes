package it.ccg.tcfrontend.client;

import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardControlBar;
import it.ccg.tcfrontend.client.controls.WindowsCounter;
import it.ccg.tcfrontend.client.security.Privileges;

import java.util.Date;

import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.DataSourceField;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.util.Page;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.layout.LayoutSpacer;

public class TemplateWindow extends Window{
	
	private ListGrid mainGrid = new ListGrid();
	
	
	public TemplateWindow(final ListGrid grid, final String controlId, final String tabella){
		
		super();
		final Window w = this;
		this.setID("Template");
		this.setTitle("Template");
		this.setWidth(450);
		this.setHeight(350);
		
		this.setTop(Page.getHeight()/2+WindowsCounter.getCounter()*20-this.getWidth()/2);
		this.setLeft(Page.getWidth()/2+WindowsCounter.getCounter()*10-this.getHeight()/2);
		
		this.setCanDragReposition(true);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);
		
		final DataSource tctttmpl=SecureDS.get("tctttmpl");
		mainGrid.setDataSource(tctttmpl);
		mainGrid.setWidth("99%");
		mainGrid.setHeight100();
		mainGrid.setMargin(5);
		mainGrid.setWrapCells(true);  
		mainGrid.setFixedRecordHeights(false);  
		mainGrid.setCanEdit(true);  
		mainGrid.setAutoFetchData(true);
//		mainGrid.setRemoveIcon("icons/16/save.png"); remove1
		
		mainGrid.setEmptyMessage("No Saved Preferences");  
		mainGrid.setCanRemoveRecords(true);  
		mainGrid.setFetchOperation("tctttmplfetch");
		
		Criteria crit = new Criteria();
		//crit.addCriteria("CONTROLID",controlId);
		
		crit.addCriteria("CONTROLID",controlId+tabella);
		mainGrid.setInitialCriteria(crit);
		
		mainGrid.draw();
		
	    //Top control bar
	    StandardControlBar topControlBar = new StandardControlBar();
	    topControlBar.setAlign(Alignment.CENTER);
	    topControlBar.setWidth("99%");
	    
	    //Save template 
	    final TextItem tmplname = new TextItem();
	    tmplname.setShowTitle(false);
	    StandardButton saveButton = new StandardButton("Save template");
	    DynamicForm form = new DynamicForm();
	    form.setFields(tmplname);
	    topControlBar.addMember(form);
	    topControlBar.addMember(saveButton);
	    
		//Bottom control bar
		StandardControlBar bottomControlBar = new StandardControlBar();
		bottomControlBar.setAlign(Alignment.CENTER);
		bottomControlBar.setWidth("99%");

		LayoutSpacer ls = new LayoutSpacer();
        bottomControlBar.addMember(ls);
		StandardButton loadButton = new StandardButton("Load template");
		
		//Click handler save button
		saveButton.addClickHandler(new ClickHandler() {
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
				
				Criteria crit = new Criteria();
				//crit.addCriteria("CONTROLID", controlId);
				crit.addCriteria("CONTROLID", controlId+tabella);
				crit.addCriteria("SAVENAME", (String) tmplname.getValue());
				
				tctttmpl.fetchData(crit, new DSCallback(){

					@Override
					public void execute(DSResponse response, Object rawData, DSRequest request) {
						Record[] recs = response.getData();
						if (recs.length==0){
						if(tmplname.getValue()!=null){
							final Record rec = new Record();  
							//rec.setAttribute("CONTROLID", controlId);  
							rec.setAttribute("CONTROLID", controlId+tabella);
							rec.setAttribute("SAVENAME", tmplname.getValue()); 
							rec.setAttribute("CONTENT", grid.getFieldState());  
							rec.setAttribute("HIGHLIGHT", grid.getHiliteState());
							tctttmpl.addData(rec, new DSCallback() {
								
								@Override
								public void execute(DSResponse response, Object rawData, DSRequest request) {
									
									Privileges.storeDefaultControlState(rec);
								}
							});
						}else{
							SC.warn("Please give a title to the new template");
						}}
						else SC.say("The template already exists");
					}});
				}
		});
		
		//Click handler load button
		loadButton.addClickHandler(new ClickHandler() {  
			public void onClick(ClickEvent event) {  

				Record lgr = mainGrid.getSelectedRecord();
				if(lgr!=null){
				lgr.setAttribute("UPDDATE", new Date());
				mainGrid.updateData(lgr);
				Privileges.storeDefaultControlState(lgr);

					String content=lgr.getAttributeAsString("CONTENT");
					String highlight=lgr.getAttributeAsString("HIGHLIGHT");
					for(DataSourceField f:grid.getDataSource().getFields()){
						f.setAttribute("detail", "false");
					}
					grid.setFieldState(content);
					grid.setHiliteState(highlight);
					grid.redraw();
					w.destroy();

				
			}  else SC.warn("Please select a template");
				}
		});  
		

		//Destroy
		this.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {

				w.destroy();
			}
		});
		
	
		bottomControlBar.addMember(loadButton);
		bottomControlBar.addMember(ls);
		this.addItem(topControlBar);
		this.addItem(mainGrid);
		this.addItem(bottomControlBar);
		this.draw();
			
	}

	public static TemplateWindow windowCreator(ListGrid grid, String IDpanel, String tabella) {

		TemplateWindow mw = (TemplateWindow) Canvas.getById("Template");
		if (mw != null) {
			mw.setVisible(true);
			mw.restore();
			mw.bringToFront();
			return mw;
		} else {
			return new TemplateWindow(grid, IDpanel, tabella);

		}

	}
	
	
	
	
}
