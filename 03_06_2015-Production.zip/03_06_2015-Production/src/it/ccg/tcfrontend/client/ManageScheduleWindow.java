package it.ccg.tcfrontend.client;

import java.sql.Timestamp;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;

import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.menu.TextifyMenuItem;
import it.ccg.tcfrontend.client.menu.ViewDetailsMenuItem;
import it.ccg.tcfrontend.client.security.Privileges;
import it.ccg.tcfrontend.client.utils.ConvertString2Array;

import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.MultipleAppearance;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.validator.IntegerRangeValidator;
import com.smartgwt.client.widgets.form.validator.RegExpValidator;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.layout.HLayout;

public class ManageScheduleWindow extends Window{

	String winId=this.getID();

	DataSource tctscheduler=SecureDS.get("tctscheduler");
	DataSource tctusract=SecureDS.get("tctusract");

	public ManageScheduleWindow(final ListGrid grid){

		super();
		this.setID("ManageSchedule");
		this.setTitle("Add a new schedule");
		this.setWidth(400);
		this.setHeight(300);
		this.centerInPage();
		this.setPadding(10);
		this.setMargin(10);
		this.setMembersMargin(10);

		this.setCanDragReposition(true);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);

		final Window w = this;

		final DynamicForm dynamicForm = new DynamicForm();


		// Schedule name text item
		final TextItem nameTextItem = new TextItem("name"); 
		nameTextItem.setTitle("Schedule name"); 
		nameTextItem.setType("text");
		nameTextItem.setRequired(true);
		nameTextItem.setWidth(250);

		// Note text item
		final TextItem noteItem = new TextItem("description"); 
		noteItem.setTitle("Note");
		noteItem.setRequired(true);
		noteItem.setType("text");
		noteItem.setWidth(250);
		noteItem.setHeight(50);

		//Scheduler Hour 
		final TextItem hourItem = new TextItem("numberValue");
		hourItem.setTitle("Hour (0-23)");
		hourItem.setRequired(true);
		hourItem.setWidth(250);
		hourItem.setType("int");
		IntegerRangeValidator integerRangeValidator = new IntegerRangeValidator();  
		integerRangeValidator.setMin(0);  
		integerRangeValidator.setMax(23);  
		integerRangeValidator.setErrorMessage("Hour value must be an integer between 0 and 23.");
		String[] userRoles=Privileges.getUserRoles();
		String userRolesStr="";
		for(int i=0;i<userRoles.length;i++){
			String userRole=userRoles[i];
			userRolesStr+=userRole+",";
		}
		if(!userRolesStr.contains("admin")){
			hourItem.setValidators(integerRangeValidator);
		}

		/*RegExpValidator regMonthDayExpValidator = new RegExpValidator("[0-23]");
		regMonthDayExpValidator.setErrorMessage("Hour value must be an integer between 0 and 23.");
		hourItem.setValidators(regMonthDayExpValidator);*/

		//Scheduler days
		final SelectItem dayOfWeekSelectItem = new SelectItem("stringValue"); 
		dayOfWeekSelectItem.setTitle("Day of week");
		dayOfWeekSelectItem.setMultiple(true);
		dayOfWeekSelectItem.setMultipleAppearance(MultipleAppearance.PICKLIST);
		dayOfWeekSelectItem.setWidth(250);
		dayOfWeekSelectItem.setAllowEmptyValue(false);
		dayOfWeekSelectItem.setValidateOnChange(true);
		dayOfWeekSelectItem.setRequired(true);	
		LinkedHashMap<String, String> dayOfWeekValueMap = new LinkedHashMap<String, String>();
		dayOfWeekValueMap.put("mon","Monday");
		dayOfWeekValueMap.put("tue","Tuesday");
		dayOfWeekValueMap.put("wed","Wednesday");
		dayOfWeekValueMap.put("thu","Thursday");
		dayOfWeekValueMap.put("fri","Friday");
		dayOfWeekValueMap.put("sat","Saturday");
		dayOfWeekValueMap.put("sun","Sunday");
		dayOfWeekSelectItem.setValueMap(dayOfWeekValueMap);

		// job select item
		final SelectItem jobSelectItem = new SelectItem("methodName");
		jobSelectItem.setTitle("Job name");
		jobSelectItem.setRequired(true);
		LinkedHashMap<String, String> jobValueMap = new LinkedHashMap<String, String>();
		if(userRolesStr.contains("admin")){
			jobValueMap.put("startTerroristDataFlow","Import terrorist lists");
		}
		jobValueMap.put("startFindMatch","Find matches");
		jobSelectItem.setValueMap(jobValueMap);
		jobSelectItem.setWidth(250);


		// add items to form
		dynamicForm.setItems(nameTextItem, jobSelectItem, dayOfWeekSelectItem, hourItem, noteItem);


		//Activate
		final IButton addButton = new StandardButton("Activate");
		addButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				if(!dynamicForm.validate()) {
					return;
				}

				final Record[] rec1 = grid.getRecords();
				int jobNameCont = 0;
				int methodNameCont = 0;

				
				for(int i=0;i<rec1.length;i++){
					//controllo che non ho gi� inserito uno schedule con lo stesso nome
					if(nameTextItem.getValue().toString().equalsIgnoreCase(rec1[i].getAttribute("name"))){
						jobNameCont++;
					}
					//controllo che non ho gi� inserito uno schedule dello stesso metodo
					if(jobSelectItem.getValue().toString().equalsIgnoreCase(rec1[i].getAttribute("methodName"))){
						methodNameCont++;
					}
				}

				if(jobNameCont>=1 && methodNameCont==0){
					SC.warn("A schedule with this schedule name already exists.");
				}else if(jobNameCont==0 && methodNameCont>=1){
					SC.warn("A schedule with this job name already exists.");
				}else if(jobNameCont>=1 && methodNameCont>=1){
					SC.warn("A schedule with this schedule name/job name already exists.");
				}/*else if(jobNameCont>=1 && methodNameCont<1){
					SC.warn("A schedule with this name already exists.");
				}
				if(jobNameCont>=1 || methodNameCont>=1){
					SC.warn("A schedule with this name/job name already exists.");
				}*/
				else{
					String[] daysArr = dayOfWeekSelectItem.getValues();
					String days = ConvertString2Array.array2String(daysArr);

					String methodName = jobSelectItem.getValue().toString();

					String scheduLeDesc = nameTextItem.getValue().toString();

					String desc = noteItem.getValue().toString();

					int hours = Integer.parseInt(hourItem.getValue().toString());

//					Integer companyID;
//
//					if(methodName.compareToIgnoreCase("startFindMatch")==0){
//						companyID = Privileges.getCompanyID();
//					} else  companyID=-1;


					final Record rec = new Record();
//					rec.setAttribute("companyId", companyID);
					rec.setAttribute("stringValue", days);
					rec.setAttribute("methodName", methodName);
					rec.setAttribute("name", scheduLeDesc);
					rec.setAttribute("description", desc);
					rec.setAttribute("numberValue", hours);
					rec.setAttribute("updType", "C");
					
					tctscheduler.addData(rec, new DSCallback() {

						@Override
						public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

							String[] fieldnames = tctscheduler.getFieldNames();
							String newRecordStr = "";

							for(int w=0;w<fieldnames.length;w++){
								if(fieldnames[w].compareToIgnoreCase("companyId")==0)
									newRecordStr+="";
								else{
									if(rec.getAttributeAsString(fieldnames[w])==null)
										newRecordStr+=fieldnames[w]+":  | ";
									else
										newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
								}
							}
							
							Record usrActRecord = new Record();

							usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctscheduler_add");
							usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
							usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
							usrActRecord.setAttribute("NEWRECORD", newRecordStr);
							usrActRecord.setAttribute("RUNID", -1);
							
							tctusract.addData(usrActRecord);

							grid.invalidateCache();
							grid.fetchData();

							w.destroy();

							SC.say("Schedule correctly created.");
						}
					});
				}
			}
		});




		//Cancel
		final IButton cancelButton = new StandardButton("Clear");
		cancelButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				dynamicForm.reset();

			}
		});

		HLayout hButtonLayout = new HLayout();  
		hButtonLayout.setMembersMargin(15);
		hButtonLayout.setAlign(Alignment.CENTER);
		hButtonLayout.addMember(addButton);
		hButtonLayout.addMember(cancelButton);

		this.addItem(dynamicForm);
		this.addItem(hButtonLayout);



		this.draw();

		this.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {

				w.destroy();
			}
		});



	}


	public static ManageScheduleWindow windowCreator(ListGrid grid) {

		ManageScheduleWindow mw = (ManageScheduleWindow) Canvas.getById("ManageSchedule");
		if (mw != null) {
			mw.setVisible(true);
			mw.restore();
			mw.bringToFront();
			return mw;
		} else {
			return new ManageScheduleWindow(grid);

		}

	}








}