package it.ccg.tcfrontend.client;

import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardControlBar;

import java.util.LinkedHashMap;

import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.DataSourceField;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DragDataAction;
import com.smartgwt.client.types.ExportFormat;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.EnumUtil;
import com.smartgwt.client.widgets.AnimationCallback;
import com.smartgwt.client.widgets.TransferImgButton;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.BooleanItem;
import com.smartgwt.client.widgets.form.fields.FormItem;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.events.ChangeEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangeHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VStack;


public class ExportWindow extends Window {
/*	final int TOPTOOLBARHEIGHT = 30; // Top toolbar height
	final int BOTTOMTOOLBARHEIGHT = 30; // Bottom toolbar height
	final int BUTWIDTH = 100; // Button width
	final int CTRHEIGHT = 22; // Control height
	final int CTRMARGINS = 15; // Control margins
	final boolean BUTSHOWDOWN = true;
	final boolean BUTSHOWROLLOVER = true;*/

	public ExportWindow(ListGrid statGrid) {
		super();
		ExportWindow ew = new ExportWindow(statGrid,"");
	}
	
	public ExportWindow(ListGrid statGrid,final String operationId) {
		super();

		final DynamicForm exportForm = new DynamicForm();
		exportForm.setLayoutAlign(VerticalAlignment.CENTER);
		exportForm.setNumCols(4);
		exportForm.setWidth(350);
		SelectItem exportTypeItem = new SelectItem("exportType", "<nobr>Export type</nobr>");
		exportTypeItem.setWidth("170");
		exportTypeItem.setDefaultToFirstOption(true);

		LinkedHashMap<String, String> valueMap = new LinkedHashMap<String, String>();
		valueMap.put("xls", "XLS (Excel97)");
		valueMap.put("csv", "CSV (Excel)");
		valueMap.put("xml", "XML");
		valueMap.put("ooxml", "XLSX (Excel2007/OOXML)");

		exportTypeItem.setValueMap(valueMap);

		BooleanItem showInWindowItem = new BooleanItem();
		showInWindowItem.setName("exportFormatted");
		showInWindowItem.setTitle("Export what you see");
		showInWindowItem.setAlign(Alignment.LEFT);
		exportForm.setItems(exportTypeItem, showInWindowItem);
		
		final ListGrid staticsGrid= statGrid;
		
		final Window winModal = this;
		winModal.setWidth(490);
		winModal.setHeight(300);
		winModal.setAlign(Alignment.CENTER);

		winModal.setTitle("Select Fields to export...");
		winModal.setShowMinimizeButton(false);
		winModal.setIsModal(true);
		winModal.setShowModalMask(true);
		winModal.centerInPage();
		winModal.setKeepInParentRect(true);
		winModal.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {

				winModal.destroy();
			}
		});

		LayoutSpacer ls = new LayoutSpacer();

		final HLayout setLay = new HLayout();
		setLay.setMargin(10);
		setLay.setHeight(200);
		setLay.setMembersMargin(15);
		setLay.setAlign(Alignment.CENTER);
		setLay.setWidth(480);

		setLay.addMember(ls);

		final ListGrid myList1 = new ListGrid();
		myList1.setCanDragRecordsOut(true);
		myList1.setCanAcceptDroppedRecords(true);
		myList1.setCanReorderFields(true);
		myList1.setDragDataAction(DragDataAction.MOVE);
		myList1.setFields(new ListGridField("fieldDesc"));
		myList1.setWidth(170);
		myList1.setHeight(180);
		myList1.setCellHeight(24);
		myList1.setImageSize(16);
		myList1.setShowEdges(true);
		myList1.setBorder("0px");
		myList1.setBodyStyleName("normal");
		myList1.setAlternateRecordStyles(true);
		myList1.setShowHeader(false);
		myList1.setLeaveScrollbarGap(false);
		myList1.setEmptyMessage("<br><br>Drag &amp; drop fields here");

		ListGridField[] lg = staticsGrid.getAllFields();
		ListGridRecord[] lgrArr = new ListGridRecord[lg.length];

		for (int i = 0; i < lg.length; i++) {

			ListGridField lgf = lg[i];

			ListGridRecord lgr = new ListGridRecord();

			lgr.setAttribute("fieldDesc", lgf.getTitle());
			lgr.setAttribute("fieldName", lgf.getName());

//			System.out.println("desc:"+lgf.getTitle()+"   "+"name:"+lgf.getName());
			
			lgrArr[i] = lgr;
		}

		myList1.setData(lgrArr);
		/*
		 * LayoutSpacer ls=new LayoutSpacer(); hStack.addMember(ls);
		 */
		setLay.addMember(myList1);

		final ListGrid myList2 = new ListGrid();
		myList2.setCanDragRecordsOut(true);
		myList2.setCanAcceptDroppedRecords(true);
		myList2.setCanReorderFields(true);
		myList2.setCanReorderRecords(true);
		myList2.setDragDataAction(DragDataAction.MOVE);
		myList2.setFields(new ListGridField("fieldDesc"));
		myList2.setWidth(170);
		myList2.setHeight(180);
		myList2.setCellHeight(24);
		myList2.setImageSize(16);
		myList2.setShowEdges(true);
		myList2.setBorder("0px");
		myList2.setBodyStyleName("normal");
		myList2.setAlternateRecordStyles(true);
		myList2.setShowHeader(false);
		myList2.setLeaveScrollbarGap(false);
		myList2.setEmptyMessage("<br><br>Drag &amp; drop selected fields here");

		VStack vStack = new VStack(10);
		vStack.setWidth(50);
		vStack.setHeight(100);
		vStack.setLayoutAlign(Alignment.CENTER);

		TransferImgButton right = new TransferImgButton(TransferImgButton.RIGHT);
		right
				.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
					public void onClick(ClickEvent event) {
						myList2.transferSelectedData(myList1);
					}
				});

		TransferImgButton rightAll = new TransferImgButton(
				TransferImgButton.RIGHT_ALL);
		rightAll.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
					public void onClick(ClickEvent event) {
						Record[] records = myList1.getRecords();
						myList1.setData(new Record[] {});
						for (Record record : records) {
							myList2.addData(record);
						}
					}
				});

		TransferImgButton left = new TransferImgButton(TransferImgButton.LEFT);
		left
				.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
					public void onClick(ClickEvent event) {
						myList1.transferSelectedData(myList2);
					}
				});

		TransferImgButton leftAll = new TransferImgButton(
				TransferImgButton.LEFT_ALL);
		leftAll
				.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
					public void onClick(ClickEvent event) {
						Record[] records = myList2.getRecords();
						myList2.setData(new Record[] {});
						for (Record record : records) {
							myList1.addData(record);
						}
					}
				});
		vStack.addMember(right);
		vStack.addMember(left);
		vStack.addMember(rightAll);
		vStack.addMember(leftAll);

		setLay.addMember(vStack);
		setLay.addMember(myList2);
		setLay.addMember(ls);

		winModal.addItem(setLay);
		
	 

		showInWindowItem.addChangeHandler(new ChangeHandler() {  
			public void onChange(ChangeEvent event) {
				if((Boolean) event.getValue()){
				winModal.animateResize(490, 100, null,500);  
				setLay.hide(); 
				}
				else {
					winModal.animateResize(490, 300, new AnimationCallback(){

						@Override
						public void execute(boolean earlyFinish) {
							setLay.show();
						}},500);
					
				}
			}
			  
	});  

		final  StandardButton exportButton = new StandardButton("Export");

		exportButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
					public void onClick(
						com.smartgwt.client.widgets.events.ClickEvent event) {
						
						Record[] records = myList2.getRecords();
						
						//Lista di campi da esportare
						String[] fi = new String[records.length];
						for (int i = 0; i < records.length; i++) {

							fi[i] = records[i].getAttributeAsString("fieldName");
						}
						
						
						
						 //Valore della combo di selezione esportazione
						String exportAs = (String) exportForm.getField("exportType").getValue();
	                    //Valore boolean item
						FormItem item = exportForm.getField("exportFormatted");
						boolean showInWindow = item.getValue() == null ? false : (Boolean) item.getValue();

							// exportAs is either XML or CSV, which we can do with
							// requestProperties
							DSRequest dsRequestProperties = new DSRequest();
							
						if(operationId.compareTo("")!=0)
							{dsRequestProperties.setOperationId(operationId);}
						
						
						dsRequestProperties.setExportAs((ExportFormat) EnumUtil.getEnum(ExportFormat.values(), exportAs));
						dsRequestProperties.setExportDelimiter(";");
							dsRequestProperties.setShowPrompt(true);
                            dsRequestProperties.setPrompt("Export in progress, please wait...");
							//dsRequestProperties.setPromptStyle(PromptStyle.DIALOG);
							dsRequestProperties.setIgnoreTimeout(true);
							staticsGrid.setExportFields(fi);
//							staticsGrid.setex
							if(showInWindow){

	                        staticsGrid.exportClientData(dsRequestProperties);
	                        winModal.destroy();
	                       }else{
								staticsGrid.exportData(dsRequestProperties);	
								winModal.destroy();
							}

					}
				});

		final StandardButton cancelButton = new StandardButton("Cancel");

		cancelButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
					public void onClick(
							com.smartgwt.client.widgets.events.ClickEvent event) {

						winModal.destroy();

					}
				});

		
		StandardControlBar exportBar = new StandardControlBar();
		exportBar.setAlign(Alignment.CENTER);
		exportBar.addMember(exportButton);
		exportBar.addMember(cancelButton);
		
		LayoutSpacer ls3 = new LayoutSpacer();
		
	    winModal.addItem(ls3);
        winModal.addItem(exportForm);
		exportForm.addChild(ls3);
        winModal.addItem(exportBar);
		
		winModal.draw();

	}
	
	
	//**************EXPORT BACK TEST MEMBER RESULTS (maingrid + subgrids)*********************************
	public ExportWindow(DataSource ds, final String operationId, final ListGrid mainGrid) {
		super();

		final DynamicForm exportForm = new DynamicForm();
		exportForm.setLayoutAlign(VerticalAlignment.CENTER);
		exportForm.setNumCols(4);
		exportForm.setWidth(350);
		SelectItem exportTypeItem = new SelectItem("exportType", "<nobr>Export type</nobr>");
		exportTypeItem.setWidth("170");
		exportTypeItem.setDefaultToFirstOption(true);

		LinkedHashMap<String, String> valueMap = new LinkedHashMap<String, String>();
		valueMap.put("xls", "XLS (Excel97)");
		valueMap.put("csv", "CSV (Excel)");
		valueMap.put("xml", "XML");
		valueMap.put("ooxml", "XLSX (Excel2007/OOXML)");

		exportTypeItem.setValueMap(valueMap);

		BooleanItem showInWindowItem = new BooleanItem();
		showInWindowItem.setName("exportFormatted");
		showInWindowItem.setTitle("Export what you see");
		showInWindowItem.setAlign(Alignment.LEFT);
		exportForm.setItems(exportTypeItem, showInWindowItem);
		
		final ListGrid staticsGrid= new ListGrid();
		staticsGrid.setDataSource(ds);
		
		final Window winModal = this;
		winModal.setWidth(490);
		winModal.setHeight(300);
		winModal.setAlign(Alignment.CENTER);

		winModal.setTitle("Select Fields to export...");
		winModal.setShowMinimizeButton(false);
		winModal.setIsModal(true);
		winModal.setShowModalMask(true);
		winModal.centerInPage();
		winModal.setKeepInParentRect(true);
		winModal.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {

				winModal.destroy();
			}
		});

		LayoutSpacer ls = new LayoutSpacer();

		final HLayout setLay = new HLayout();
		setLay.setMargin(10);
		setLay.setHeight(200);
		setLay.setMembersMargin(15);
		setLay.setAlign(Alignment.CENTER);
		setLay.setWidth(480);

		setLay.addMember(ls);

		final ListGrid myList1 = new ListGrid();
		myList1.setCanDragRecordsOut(true);
		myList1.setCanAcceptDroppedRecords(true);
		myList1.setCanReorderFields(true);
		myList1.setDragDataAction(DragDataAction.MOVE);
		ListGridField lgf1 = new ListGridField("fieldDesc");
		myList1.setFields(new ListGridField("fieldDesc"));
		myList1.setWidth(170);
		myList1.setHeight(180);
		myList1.setCellHeight(24);
		myList1.setImageSize(16);
		myList1.setShowEdges(true);
		myList1.setBorder("0px");
		myList1.setBodyStyleName("normal");
		myList1.setAlternateRecordStyles(true);
		myList1.setShowHeader(false);
		myList1.setLeaveScrollbarGap(false);
		myList1.setEmptyMessage("<br><br>Drag &amp; drop fields here");

		/*ListGridField[] lg = staticsGrid.getAllFields();
		ListGridRecord[] lgrArr = new ListGridRecord[lg.length];

		for (int i = 0; i < lg.length; i++) {

			ListGridField lgf = lg[i];

			ListGridRecord lgr = new ListGridRecord();

			lgr.setAttribute("fieldDesc", lgf.getTitle());
			lgr.setAttribute("fieldName", lgf.getName());

//			System.out.println("desc:"+lgf.getTitle()+"   "+"name:"+lgf.getName());
			
			lgrArr[i] = lgr;
		}

		myList1.setData(lgrArr);*/
		
		DataSourceField[] dsf= ds.getFields();
		ListGridRecord[] lgrArr = new ListGridRecord[dsf.length];

		for (int i = 0; i < dsf.length; i++) {

			DataSourceField lgf = dsf[i];

			ListGridRecord lgr = new ListGridRecord();

			lgr.setAttribute("fieldDesc", lgf.getTitle());
			lgr.setAttribute("fieldName", lgf.getName());

//			System.out.println("desc:"+lgf.getTitle()+"   "+"name:"+lgf.getName());
			
			lgrArr[i] = lgr;
		}

		myList1.setData(lgrArr);
		
		/*
		 * LayoutSpacer ls=new LayoutSpacer(); hStack.addMember(ls);
		 */
		setLay.addMember(myList1);

		final ListGrid myList2 = new ListGrid();
		myList2.setCanDragRecordsOut(true);
		myList2.setCanAcceptDroppedRecords(true);
		myList2.setCanReorderFields(true);
		myList2.setCanReorderRecords(true);
		myList2.setDragDataAction(DragDataAction.MOVE);
		myList2.setFields(new ListGridField("fieldDesc"));
		myList2.setWidth(170);
		myList2.setHeight(180);
		myList2.setCellHeight(24);
		myList2.setImageSize(16);
		myList2.setShowEdges(true);
		myList2.setBorder("0px");
		myList2.setBodyStyleName("normal");
		myList2.setAlternateRecordStyles(true);
		myList2.setShowHeader(false);
		myList2.setLeaveScrollbarGap(false);
		myList2.setEmptyMessage("<br><br>Drag &amp; drop selected fields here");

		VStack vStack = new VStack(10);
		vStack.setWidth(50);
		vStack.setHeight(100);
		vStack.setLayoutAlign(Alignment.CENTER);

		TransferImgButton right = new TransferImgButton(TransferImgButton.RIGHT);
		right
				.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
					public void onClick(ClickEvent event) {
						myList2.transferSelectedData(myList1);
					}
				});

		TransferImgButton rightAll = new TransferImgButton(
				TransferImgButton.RIGHT_ALL);
		rightAll.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
					public void onClick(ClickEvent event) {
						Record[] records = myList1.getRecords();
						myList1.setData(new Record[] {});
						for (Record record : records) {
							myList2.addData(record);
						}
					}
				});

		TransferImgButton left = new TransferImgButton(TransferImgButton.LEFT);
		left.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
					public void onClick(ClickEvent event) {
						myList1.transferSelectedData(myList2);
					}
				});

		TransferImgButton leftAll = new TransferImgButton(
				TransferImgButton.LEFT_ALL);
		leftAll.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
					public void onClick(ClickEvent event) {
						Record[] records = myList2.getRecords();
						myList2.setData(new Record[] {});
						for (Record record : records) {
							myList1.addData(record);
						}
					}
				});
		vStack.addMember(right);
		vStack.addMember(left);
		vStack.addMember(rightAll);
		vStack.addMember(leftAll);

		setLay.addMember(vStack);
		setLay.addMember(myList2);
		setLay.addMember(ls);

		winModal.addItem(setLay);
		
	 

		showInWindowItem.addChangeHandler(new ChangeHandler() {  
			public void onChange(ChangeEvent event) {
				if((Boolean) event.getValue()){
				winModal.animateResize(490, 100, null,500);  
				setLay.hide(); 
				}
				else {
					winModal.animateResize(490, 300, new AnimationCallback(){

						@Override
						public void execute(boolean earlyFinish) {
							setLay.show();
						}},500);
					
				}
			}
			  
	});  

		final  StandardButton exportButton = new StandardButton("Export");

		exportButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
					public void onClick(
						com.smartgwt.client.widgets.events.ClickEvent event) {
						
						Record[] records = myList2.getRecords();
						
						//Lista di campi da esportare
						String[] fi = new String[records.length];
						for (int i = 0; i < records.length; i++) {

							fi[i] = records[i].getAttributeAsString("fieldName");
						}
						
						
						
						 //Valore della combo di selezione esportazione
						String exportAs = (String) exportForm.getField("exportType").getValue();
	                    //Valore boolean item
						FormItem item = exportForm.getField("exportFormatted");
						boolean showInWindow = item.getValue() == null ? false : (Boolean) item.getValue();

						// exportAs is either XML or CSV, which we can do with
						// requestProperties
						DSRequest dsRequestProperties = new DSRequest();
					if(operationId.compareTo("")!=0)
						{dsRequestProperties.setOperationId(operationId);}
					

					dsRequestProperties.setCriteria(mainGrid.getCriteria());
						
						dsRequestProperties.setExportAs((ExportFormat) EnumUtil.getEnum(ExportFormat.values(), exportAs));
						dsRequestProperties.setExportDelimiter(";");
							dsRequestProperties.setShowPrompt(true);
                            dsRequestProperties.setPrompt("Export in progress, please wait...");
							//dsRequestProperties.setPromptStyle(PromptStyle.DIALOG);
							dsRequestProperties.setIgnoreTimeout(true);
							staticsGrid.setExportFields(fi);
//							staticsGrid.setex
							if(showInWindow){

	                        staticsGrid.exportClientData(dsRequestProperties);
	                        winModal.destroy();
	                       }else{
								staticsGrid.exportData(dsRequestProperties);	
								winModal.destroy();
							}

					}
				});

		final StandardButton cancelButton = new StandardButton("Cancel");

		cancelButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
					public void onClick(
							com.smartgwt.client.widgets.events.ClickEvent event) {

						winModal.destroy();

					}
				});

		
		StandardControlBar exportBar = new StandardControlBar();
		exportBar.setAlign(Alignment.CENTER);
		exportBar.addMember(exportButton);
		exportBar.addMember(cancelButton);
		
		LayoutSpacer ls3 = new LayoutSpacer();
		
	    winModal.addItem(ls3);
        winModal.addItem(exportForm);
		exportForm.addChild(ls3);
        winModal.addItem(exportBar);
		
		winModal.draw();

	
	}
	//***********************************************
	
	
	public static ExportWindow windowCreator(ListGrid statGrid) {
		
			return new ExportWindow(statGrid);
		
	
	}
	public static ExportWindow windowCreator(ListGrid statGrid,String operationId) {
		
		return new ExportWindow(statGrid,operationId);
	

}public static ExportWindow windowCreator(DataSource ds, String operationId, ListGrid mainGrid) {
	
	return new ExportWindow(ds, operationId, mainGrid);


}

}
