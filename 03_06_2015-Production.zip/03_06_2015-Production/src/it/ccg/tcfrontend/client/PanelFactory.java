/*
 * Isomorphic SmartGWT web presentation layer
 * Copyright 2000 and beyond Isomorphic Software, Inc.
 *
 * OWNERSHIP NOTICE
 * Isomorphic Software owns and reserves all rights not expressly granted in this source code,
 * including all intellectual property rights to the structure, sequence, and format of this code
 * and to all designs, interfaces, algorithms, schema, protocols, and inventions expressed herein.
 *
 *  If you have any questions, please email <sourcecode@isomorphic.com>.
 *
 *  This entire comment must accompany any portion of Isomorphic Software source code that is
 *  copied or moved from this file.
 */

package it.ccg.tcfrontend.client;


import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.tab.TabSet;

public interface PanelFactory {

    Canvas create(TabSet mainTabSet,String panelID);

    String getID();

    String getDescription();

	Canvas create(TabSet mainTabSet, String nodeID, int attributeAsInt, String attributeAsString);
}
