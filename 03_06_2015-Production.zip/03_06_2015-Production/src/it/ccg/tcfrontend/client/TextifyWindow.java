package it.ccg.tcfrontend.client;

import com.smartgwt.client.widgets.HTMLPane;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;

public class TextifyWindow extends Window{
	
	
	public TextifyWindow(ListGrid grid) {
		final Window winModal = this;
		this.setSize("80%","80%");
		this.setCanDragResize(true);
		this.setAlign(Alignment.CENTER);
		this.setTitle("Copy this text to your spreadsheet...");
		this.setShowMinimizeButton(false);
		this.setIsModal(false);
		this.centerInPage();
		this.setKeepInParentRect(true);
		this.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {

				winModal.destroy();
			}
		});
		
		final HTMLPane contentHTML = new HTMLPane(); 
		/*contentHTML.setSize("98%","100%");
		contentHTML.setCanDragResize(false);
		contentHTML.setPadding(15);  
		contentHTML.setOverflow(Overflow.HIDDEN);  
		contentHTML.setCanDragResize(true);  
		contentHTML.setCanSelectText(true);*/
		
		//Caricamento lista campi visibili (usare datasource per tutti i campi)
		ListGridField[] fields=grid.getFields();
		String[] fieldNames= new String[fields.length];
		
		//Creazione header
		String contentString="<TABLE class=\"textify\"><TR class=\"textify\">";
		int i=0;
		for(ListGridField f:fields){
			contentString+="<TD>"+f.getTitle()+"</TD>";
			fieldNames[i]=f.getName();
			i++;
		}
		contentString+="</TR>";
		
		String value;
		//Creazione valori
		ListGridRecord[] selRecords=grid.getSelection();
		for(ListGridRecord sr:selRecords){
			contentString+="<TR>";
			for(String n:fieldNames){
				value=sr.getAttributeAsString(n);
				value=(value==null?"":value);
				contentString+="<TD>"+value+"</TD>";
			}
			contentString+="</TR>";
		}
		contentString+="</TABLE>";
		contentHTML.setContents(contentString);
		this.addItem(contentHTML);
		this.draw();	
	}
	
	public static TextifyWindow windowCreator(ListGrid grid) {
		
		return new TextifyWindow(grid);
	
	}
}

