package it.ccg.tcfrontend.client.security;

import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.utils.DevelopmentMode;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.google.gwt.core.client.GWT;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.LoginRequiredCallback;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.Window;

public class Privileges {

	private static String[] userRoles;
	private static String[] enabledCommands;
	private static String username;
	private static String status;
	private static String fullname;
	private static String company;
	private static int companyID;
	private static String email;

	private static String isApproveEnabled;

	private static Map<String,String> controlLayout=new HashMap<String,String>();
	private static Map<String,String> controlHilite=new HashMap<String,String>();


	public static String[] getUserRoles() {
		return userRoles;
	}

	public static void setUserRoles(String[] allRoles) {
		Privileges.userRoles = allRoles;
	}

	public static String getUsername() {
		return username;
	}

	public static void setUsername(String username) {
		Privileges.username = username;
	}

	public static String getStatus(){
		if(status!=null)
			return status;
		else return "F";
	}

	public static void setStatus(String newstatus){
		Privileges.status=newstatus;
	}

	public static String getEmail() {
		return email;
	}

	public static void setEmail(String email) {
		Privileges.email = email;
	}

	public static String getControlLayout(String controlId) {
		return controlLayout.get(controlId);
	}

	public static String getControlHilite(String controlId) {
		return controlHilite.get(controlId);
	}


	public static boolean hasPrivileges(String[] requiredRoles) {
		if(userRoles==null) return false;
		for (String reqRole : requiredRoles) {
			for (String usrRole : userRoles) {
				if (reqRole.compareToIgnoreCase(usrRole) == 0) {
					return true;
				}
			}
		}
		return false;
	}


	public static boolean isControlON4User(String controlID) {
		if(controlID==null||controlID.trim().isEmpty()||enabledCommands==null) return false;

		for (String enabledID : enabledCommands) {
			if (enabledID.compareToIgnoreCase(controlID) == 0) {
				return true;
			}
		}

		return false;
	}

	//Store control layout from db
	public static void storeDefaultControlState(){
		DataSource templateDS = SecureDS.get("tctttmpl");
		DSRequest templateDSREQ=new DSRequest();
		templateDSREQ.setOperationId("tctttmplfetchdefault");

		templateDS.fetchData(null, new DSCallback(){
			@Override
			public void execute(DSResponse response, Object rawData, DSRequest request) {
				for(Record r:response.getData()){
					controlLayout.put(r.getAttributeAsString("CONTROLID"), r.getAttributeAsString("CONTENT"));
					controlHilite.put(r.getAttributeAsString("CONTROLID"), r.getAttributeAsString("HIGHLIGHT"));
				}
			}},templateDSREQ);		
	}

	//Store control layout from db
	public static void storeDefaultControlState(Record r){
		controlLayout.put(r.getAttributeAsString("CONTROLID"), r.getAttributeAsString("CONTENT"));
		controlHilite.put(r.getAttributeAsString("CONTROLID"), r.getAttributeAsString("HIGHLIGHT"));	
	}

	//Ritorna true se il sisteme � nello stato working
	public static boolean isWorking(){
		if(getStatus().compareToIgnoreCase("F")==0) return false;
		else return true;
	}

	public static boolean isAdmin(){
		for (String usrRole : userRoles) {
			if (usrRole.compareToIgnoreCase("admin") == 0) {
				return true;
			}
		}
		return false;
	}
	
	public static boolean isApprover(){
		for (String usrRole : userRoles) {
			if (usrRole.compareToIgnoreCase("approver") == 0) {
				return true;
			}
		}
		return false;
	}
	
	public static boolean isUser(){
		for (String usrRole : userRoles) {
			if (usrRole.compareToIgnoreCase("user") == 0) {
				return true;
			}
		}
		return false;
	}

	public static String getFullname() {
		return fullname;
	}

	public static void setFullname(String fullname) {
		Privileges.fullname = fullname;
	}

	public static String getCompany() {
		return company;
	}

	public static void setCompany(String company) {
		Privileges.company = company;
	}

	public static int getCompanyID() {
		return companyID;
	}

	public static void setCompanyID(int companyID) {
		Privileges.companyID = companyID;
	}


	public static String[] getEnabledCommands() {
		return enabledCommands;
	}

	public static void setEnabledCommands(String[] enabledCommands) {
		Privileges.enabledCommands = enabledCommands;
	}

	public static String toStringPriv(){

		return "Privileges [userRoles=" + Arrays.toString(userRoles)
				+ ", username=" + username + ", status=" + status
				+ ", fullname=" + fullname + ", company=" + company
				+ ", companyID=" + companyID + "]";
	}

	public static String getIsApproveEnabled() {
		return isApproveEnabled;
	}

	public static void setIsApproveEnabled(String isApproveEnabled) {
		Privileges.isApproveEnabled = isApproveEnabled;
	}

}

