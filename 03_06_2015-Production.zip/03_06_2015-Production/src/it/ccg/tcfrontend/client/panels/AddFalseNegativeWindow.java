package it.ccg.tcfrontend.client.panels;

import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardComboBox;
import it.ccg.tcfrontend.client.security.Privileges;

import java.util.Date;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.events.ChangeEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangeHandler;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;

public class AddFalseNegativeWindow extends Window{

	String winId=this.getID();
	protected VLayout workingArea = new VLayout();
	final StandardComboBox aggregCombo;
	final protected StandardButton saveButton = new StandardButton("Save");

	final Window w = this;

	String aggregId ;
	String downId;
	String entityName;
	String source;
	String eventcombo;
	String clntId;
	//	String cmpnId;

	final DataSource tctfalnegt = SecureDS.get("tctfalnegt");
	final DataSource tctusract = SecureDS.get("tctusract");

	public AddFalseNegativeWindow(String param){

		super();
		this.setID("AddFalseNegativeWindow");
		this.setTitle("Add Positive Match");
		this.setWidth(400);
		this.setHeight(200);
		this.setCanDragReposition(true);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);
		this.setMembersMargin(3);
		this.centerInPage();

		saveButton.disable();

		final DynamicForm form = new DynamicForm();  
		form.setHeight100();
		form.setWidth(255);
		form.setPadding(10);
		form.setAlign(Alignment.RIGHT);

		clntId = param;
		/*String paramArr[] = param.split(",");
		clntId = paramArr[0];
		cmpnId = paramArr[1]; */

		//DataSource utilizzato per la tabella della lista dei clienti
		final DataSource tctaggrentDS = SecureDS.get("tctaggrentclientstaticdata");
		aggregCombo= new StandardComboBox("Aggregation Id");
		aggregCombo.setOptionDataSource(tctaggrentDS);
		ListGridField aggrId = new ListGridField("AGGREGID");
		aggrId.setWidth("20%");
		aggregCombo.setValidateOnChange(true);
		aggregCombo.setValueField("AGGREGID");
		aggregCombo.setDisplayField("AGGREGID");
		aggregCombo.setPickListWidth(500);
		aggregCombo.setPickListFields(aggrId, new ListGridField("ENTITYNAME"));
		aggregCombo.setFilterLocally(true);
		aggregCombo.setRequired(true);
		aggregCombo.setOptionOperationId("tctaggrent_fetch_aggregid");


		// Utilizzato per prendere i valori dalla combo
		aggregCombo.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent event) {
				if (event.getValue() != null){
					eventcombo = event.getValue().toString();
					saveButton.setDisabled(false);
					AdvancedCriteria crit = new AdvancedCriteria();
					crit.addCriteria("AGGREGID", eventcombo);

					DSRequest req = new DSRequest();
					req.setOperationId("tctaggrent_fetch_aggregid");

					tctaggrentDS.fetchData(crit, new DSCallback() {

						@Override
						public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
							Record[] result = dsResponse.getData();

							aggregId = result[0].getAttributeAsString("AGGREGID");
							downId = result[0].getAttributeAsString("DOWNLOADID");
							entityName = result[0].getAttributeAsString("ENTITYNAME");
							source = result[0].getAttributeAsString("SRCLIST");
						}
					}, req);

				}
				else if (event.getValue() == null){
					eventcombo = null;
					saveButton.setDisabled(true);
				}
			}


		});




		saveButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
			public void onClick(
					com.smartgwt.client.widgets.events.ClickEvent event) {

				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}
				else{
					String confMessage="Are you sure you to save the couple "+aggregId+" / "+entityName+"as Forced Postive Match?";

					SC.confirm(confMessage,
							new BooleanCallback() {public void execute(Boolean value) {

								if (value != null && value){

									/*final Record rec = new Record();
									rec.setAttribute("AGGRID", aggregId);
									rec.setAttribute("DOWNLOADID", downId);
									rec.setAttribute("ENTITYNAME", entityName);
									rec.setAttribute("SOURCE", source);
									rec.setAttribute("CLNTID", clntId);
									rec.setAttribute("STATUS", "F");*/

									Criteria crit = new Criteria();
									crit.setAttribute("AGGRID", aggregId);
									crit.setAttribute("DOWNLOADID", downId);
									crit.setAttribute("ENTITYNAME", entityName);
									crit.setAttribute("SOURCE", source);
									crit.setAttribute("CLNTID", clntId);
									crit.setAttribute("STATUS", "F");

									tctfalnegt.fetchData(crit, new DSCallback() {

										@Override
										public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
											// TODO Auto-generated method stub
											Record[] recArr = dsResponse.getData();
											if(recArr.length>=1){
												SC.warn("This client already exists in the Positive match table.");
											}
											else{
												DSRequest req = new DSRequest();
												req.setAttribute("operationId", "tctscheduler_add");  
												
												final Record rec = new Record();
												rec.setAttribute("AGGRID", aggregId);
												rec.setAttribute("DOWNLOADID", downId);
												rec.setAttribute("ENTITYNAME", entityName);
												rec.setAttribute("SOURCE", source);
												rec.setAttribute("CLNTID", clntId);
												rec.setAttribute("STATUS", "F");

												tctfalnegt.addData(rec, new DSCallback() {

													@Override
													public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

														String[] fieldnames = tctfalnegt.getFieldNames();
														String newRecordStr = "";

														for(int w=0;w<fieldnames.length;w++){
															if(fieldnames[w].compareToIgnoreCase("CMPNID")==0)
																newRecordStr+="";
															else{
																if(rec.getAttributeAsString(fieldnames[w])==null)
																	newRecordStr+=fieldnames[w]+":  | ";
																else
																	newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
															}
														}

														Record usrActRecord = new Record();

														usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctfalnegt_add");
														usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
														usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
														usrActRecord.setAttribute("NEWRECORD", newRecordStr);
														usrActRecord.setAttribute("RUNID", -1);

														tctusract.addData(usrActRecord);

														w.destroy();
														SC.say("Client correctly updated.");
													}
												}, req);
											}
										}
									});

									/*DSRequest req = new DSRequest();
									req.setAttribute("operationId", "tctscheduler_add");  

									tctfalnegt.addData(rec, new DSCallback() {

										@Override
										public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

											String[] fieldnames = tctfalnegt.getFieldNames();
											String newRecordStr = "";

											for(int w=0;w<fieldnames.length;w++){
												if(fieldnames[w].compareToIgnoreCase("CMPNID")==0)
													newRecordStr+="";
												else
												newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
											}

											Record usrActRecord = new Record();

											usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctfalnegt_add");
											usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
											usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
											usrActRecord.setAttribute("NEWRECORD", newRecordStr);
											usrActRecord.setAttribute("RUNID", -1);

											tctusract.addData(usrActRecord);

											w.destroy();
											SC.say("Client correctly updated");
										}
									}, req);*/

								}

							}});
				}}
		});

		//form.setItems(aggregCombo);

		LayoutSpacer lstop = new LayoutSpacer();
		lstop.setHeight("40");
		this.workingArea.addMember(lstop);
		this.workingArea.addMember(aggregCombo.inDynamicForm());
		this.workingArea.addMember(lstop);
		this.workingArea.addMember(saveButton);



		this.addItem(workingArea);
		this.draw();


		this.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {

				w.destroy();
			}
		});
	}


	public static AddFalseNegativeWindow windowCreator(String param) {

		AddFalseNegativeWindow mw = (AddFalseNegativeWindow) Canvas.getById("AddFalseNegativeWindow");
		if (mw != null) {
			mw.setVisible(true);
			mw.restore();
			mw.bringToFront();
			return mw;
		} else {
			return new AddFalseNegativeWindow(param);

		}

	}

}
