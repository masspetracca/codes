package it.ccg.tcfrontend.client.panels;

import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardControlBar;
import it.ccg.tcfrontend.client.security.Privileges;
import it.ccg.tcfrontend.client.utils.Regex;

import java.util.LinkedHashMap;

import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.StaticTextItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.validator.RegExpValidator;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.tab.TabSet;

public class EmailNotificationWindow extends Window{

	DynamicForm nameform;
	StaticTextItem nameItem;  
	DynamicForm emailform;
	StaticTextItem emailItem;  
	DynamicForm notifyform;
	SelectItem notifyItem;  
	
	final DataSource tctUserDS = SecureDS.get("tctuser");
	
	StandardControlBar bottomControlBar = new StandardControlBar();
	LayoutSpacer ls = new LayoutSpacer();

	public EmailNotificationWindow(final TabSet mainTabSet){

		super();
		final Window w = this;
		this.setID("EmailNotificationWindow");
		this.setTitle(Privileges.getFullname()+ "'s notification status");
		this.setWidth(330);
		this.setHeight(280);
		this.centerInPage();
		this.setCanDragReposition(true);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);
		this.setShowMinimizeButton(false);
		this.setAlign(VerticalAlignment.CENTER);
		this.setAlign(Alignment.CENTER);
		this.setIsModal(true);

		//final Window w = this;

		//< > " ' % ; ) ( & + -
		//Nama Surname validator
		RegExpValidator regExpValidatorName = new RegExpValidator();  
		regExpValidatorName.setExpression(Regex.regexNameSurname());  
		RegExpValidator regExpValidatorSurName = new RegExpValidator();  
		regExpValidatorSurName.setExpression(Regex.regexNameSurname());  

		//Name
		nameform = new DynamicForm();
		nameform.setHeight("10%");
		nameform.setAlign(Alignment.LEFT);

		nameItem = new StaticTextItem();  
		nameItem.setTitle("Name");  
		//nameItem.setValue(Privileges.getFullname());
		nameItem.setHeight("10%");
		
		//Email
		RegExpValidator regExpValidatorEmail = new RegExpValidator();  
		regExpValidatorEmail.setExpression(Regex.regexEmail());  

		emailform = new DynamicForm();
		emailform.setHeight("20%");
		emailform.setAlign(Alignment.LEFT);

		emailItem = new StaticTextItem();  
		emailItem.setTitle("Email");  
		//emailItem.setValue(Privileges.getEmail());
		emailItem.setHeight("20%");
		
		//Notify
		notifyform = new DynamicForm();
		notifyform.setHeight("20%");
		notifyform.setAlign(Alignment.LEFT);

		LinkedHashMap<String, String> valueMap = new LinkedHashMap<String, String>();  
		valueMap.put("T", "Enable");
		valueMap.put("F", "Disable"); 
		notifyItem = new SelectItem();  
		notifyItem.setValueMap(valueMap);
		notifyItem.setRequired(true);
		notifyItem.setTitle("Notify");
		//notifyItem.setValue(Privileges.getStatus());
		
		//Fetch iniziale
        showUserProfile();
		
		//Save button
		StandardButton saveButton=new StandardButton("Save");
		saveButton.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {

				String notify = "";

				//se l'utente possiede una mail 
				if(emailItem.getValue()!=null){
					//la notifica pu� essere abilitata/disabilitata
					if(notifyItem.getValue()!=null){
						notify = (String) notifyItem.getValue();
					}

					
					Record rec = new Record();
					rec.setAttribute("USERNAME", Privileges.getUsername());
//					rec.setAttribute("CMPNID", Privileges.getCompanyID());
					rec.setAttribute("EMAIL", Privileges.getEmail());
					rec.setAttribute("NOTIFY", notify);
//					System.out.println(Privileges.getUsername()+","+Privileges.getCompanyID()+","+notify);
					tctUserDS.updateData(rec, new DSCallback() {
						
						@Override
						public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
							SC.say("Email notification status correctly update ");
							
						}
					});
					
				}else
					SC.warn("No email available, please contact the help desk.");

			}});
		
		//Cancel Button
		StandardButton cancelbButton = new StandardButton("Cancel");
		cancelbButton.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
				w.destroy();
			}});

		StandardControlBar bottomControlBar = new StandardControlBar();
		LayoutSpacer ls = new LayoutSpacer();
		ls.setHeight("10%");
		bottomControlBar.setHeight("30%");
		bottomControlBar.setAlign(Alignment.CENTER);
		bottomControlBar.addMember(saveButton);
		bottomControlBar.addMember(cancelbButton);

		//Close click handler
		this.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {
				w.destroy();
			}
		});



		nameform.setFields(nameItem);
		notifyform.setFields(notifyItem);
		emailform.setFields(emailItem);

		this.addItem(ls);
		this.addItem(nameform);
		this.addItem(emailform);
		this.addItem(notifyform);
		this.addItem(ls);
		this.addItem(bottomControlBar);

		this.draw();

	}

	public void showUserProfile(){
		Criteria crit = new Criteria();
		crit.setAttribute("USERNAME", Privileges.getUsername());
//		crit.setAttribute("CMPNID", Privileges.getCompanyID());
		tctUserDS.fetchData(crit, new DSCallback() {
			
			@Override
			public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
				
				final Record[] result =dsResponse.getData();
				
				//Name
				nameItem.setValue(Privileges.getFullname());
				emailItem.setValue(Privileges.getEmail());
				notifyItem.setValue(result[0].getAttributeAsString("NOTIFY"));
			}
		});
				
}
	
	public void updateUserProfile(final String notify){
		Criteria crit = new Criteria();
		crit.setAttribute("USERNAME", Privileges.getUsername());
//		crit.setAttribute("CMPNID", Privileges.getCompanyID());
		tctUserDS.fetchData(crit, new DSCallback() {
			
			@Override
			public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
				
				final Record[] result =dsResponse.getData();
				
				result[0].setAttribute("NOTIFY", notify);
				//notifyItem.setValue(result[0].getAttributeAsString("NOTIFY"));
				tctUserDS.updateData(result[0]);
			}
		});
				
}

	public static EmailNotificationWindow windowCreator(TabSet mainTabSet) {

		EmailNotificationWindow mw = (EmailNotificationWindow) Canvas.getById("EmailNotificationWindow");
		if (mw != null) {
			mw.setVisible(true);
			mw.restore();
			mw.bringToFront();
			return mw;
		} else {
			return new EmailNotificationWindow(mainTabSet);

		}


	}
}
