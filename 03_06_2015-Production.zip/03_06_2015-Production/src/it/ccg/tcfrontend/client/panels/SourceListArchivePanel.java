package it.ccg.tcfrontend.client.panels;

import java.util.Date;

import it.ccg.tcfrontend.client.ExportWindow;
import it.ccg.tcfrontend.client.HelpWindow;
import it.ccg.tcfrontend.client.PanelFactory;
import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardControlBar;
import it.ccg.tcfrontend.client.controls.StandardListGrid;
import it.ccg.tcfrontend.client.interf.Refreshable;
import it.ccg.tcfrontend.client.menu.TextifyMenuItem;
import it.ccg.tcfrontend.client.menu.ViewDetailsMenuItem;
import it.ccg.tcfrontend.client.utils.ClientMessages;

import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.data.RecordList;
import com.smartgwt.client.data.SortSpecifier;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.Cursor;
import com.smartgwt.client.types.RPCTransport;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.ImgButton;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.DoubleClickEvent;
import com.smartgwt.client.widgets.events.DoubleClickHandler;
import com.smartgwt.client.widgets.events.MouseOutEvent;
import com.smartgwt.client.widgets.events.MouseOutHandler;
import com.smartgwt.client.widgets.events.MouseOverEvent;
import com.smartgwt.client.widgets.events.MouseOverHandler;
import com.smartgwt.client.widgets.grid.CellFormatter;
import com.smartgwt.client.widgets.grid.HoverCustomizer;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.CellClickEvent;
import com.smartgwt.client.widgets.grid.events.CellClickHandler;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.tab.TabSet;
import com.smartgwt.client.widgets.viewer.DetailViewer;

public class SourceListArchivePanel extends VLayout implements Refreshable{

	final protected  TabSet mainTabSet;
	protected StandardControlBar topControlBar = new StandardControlBar();
	//protected HLayout tablesArea = new HLayout();
	protected VLayout workingArea = new VLayout();
	protected StandardControlBar bottomControlBar = new StandardControlBar();
	private static final String DESCRIPTION = "Source list archive";

	private HLayout rollOverCanvas; 
	private ListGridRecord lgr;
	
	final protected StandardButton exportButton = new StandardButton("Export");
	final protected StandardButton printButton = new StandardButton("Print");
	final protected StandardButton downloadButton = new StandardButton("Download");

	private StandardListGrid sourceListGrid;
	//private StandardListGrid typeListGrid;


	public SourceListArchivePanel(final TabSet mainTabSet, String panelID) {
		super();

		this.mainTabSet=mainTabSet;


		//REFRESH LABEL AND BUTTON
		final Label refresh = new Label();  
		refresh.setHeight(30);  
		refresh.setPadding(10);  
		refresh.setAlign(Alignment.CENTER);  
		refresh.setValign(VerticalAlignment.CENTER);  
		refresh.setWrap(false);  
		refresh.setIcon("icons/24/refresh.png");  
		refresh.setCanHover(true);
		refresh.setShowHover(false);

		refresh.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				refresh.setOpacity(50);
				refresh.setCursor(Cursor.POINTER);
			}
		});


		refresh.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				refresh.setOpacity(100);
				refresh.setCursor(Cursor.DEFAULT);
			}
		});

		refresh.setContents("<i>Refresh</i>");  

		refresh.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				sourceListGrid.invalidateCache();
				//typeListGrid.invalidateCache();
			}
		});

		LayoutSpacer lstop = new LayoutSpacer();
		lstop.setWidth("40%");

		//HELP LABEL AND BUTTON
		final Label helpLabel = new Label();  
		helpLabel.setHeight(30);  
		helpLabel.setPadding(10);  
		helpLabel.setAlign(Alignment.CENTER);  
		helpLabel.setValign(VerticalAlignment.CENTER);  
		helpLabel.setWrap(false);  
		helpLabel.setIcon("icons/24/help24.png");  
		helpLabel.setCanHover(true);
		helpLabel.setShowHover(false);

		helpLabel.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				helpLabel.setOpacity(50);
				helpLabel.setCursor(Cursor.POINTER);
			}
		});

		helpLabel.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				helpLabel.setOpacity(100);
				helpLabel.setCursor(Cursor.DEFAULT);
			}
		});

		helpLabel.setContents("<i>Help</i>");  

		helpLabel.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				HelpWindow.windowCreator2(mainTabSet, "");

			}
		});

		LayoutSpacer lstop1 = new LayoutSpacer();
		lstop.setWidth("60%");

		topControlBar.addMember(lstop1);
		topControlBar.addMember(refresh);
		topControlBar.addMember(helpLabel);

		this.workingArea.addMember(topControlBar);

		// DataSource utilizzato per la tabella delle liste sorgenti
		final DataSource sourceListDS = SecureDS.get("tctsrcupdt");
		sourceListDS.getField("SRCLIST").setAttribute("width", "35%");

		sourceListGrid=new StandardListGrid(panelID);/*{  
			@Override
			protected Canvas getRollOverCanvas(Integer rowNum, Integer colNum) {  
				lgr = this.getRecord(rowNum);  
				// final Date audDate = lgr.getAttributeAsDate("LISTDATE");

				if(rollOverCanvas == null) {  
					rollOverCanvas = new HLayout(3);  
					rollOverCanvas.setSnapTo("TR");  
					rollOverCanvas.setWidth(50);  
					rollOverCanvas.setHeight(22);  

					ImgButton downloadImg = new ImgButton();  
					downloadImg.setShowDown(false);  
					downloadImg.setShowRollOver(false);  
					downloadImg.setLayoutAlign(Alignment.CENTER);  
					downloadImg.setSrc("download.png");  
					downloadImg.setPrompt("Download file");  
					downloadImg.setHeight(16);  
					downloadImg.setWidth(16);  
					downloadImg.addClickHandler(new ClickHandler() {  
						public void onClick(ClickEvent event) {  
							String source = lgr.getAttributeAsString("SRCLIST");
							String download = lgr.getAttributeAsString("DOWNLOADID");
							Date audDate = lgr.getAttributeAsDate("LISTDATE");

							String paramStr = source+","+download+","+audDate.getTime()+",download";

							RPCRequest rpcRequest = new RPCRequest();

							rpcRequest.setHttpMethod("POST");
							// Sto dicendo al client di aprire un hidden frame dal quale generare la richiesta in POST
							rpcRequest.setTransport(RPCTransport.HIDDENFRAME);
							rpcRequest.setActionURL("ccgportal/xmlServlet?params=" + paramStr);

							RPCManager.sendRequest(rpcRequest);
						}  
					});  

					rollOverCanvas.addMember(downloadImg);
				}  
				return rollOverCanvas;  

			}*/

			/*@Override  
            protected Canvas getCellHoverComponent(Record record, Integer rowNum, Integer colNum) {  
                DetailViewer detailViewer = new DetailViewer();  
                detailViewer.setWidth(200);  
                detailViewer.setDataSource(sourceListDS);  
                Criteria criteria = new Criteria();  
                criteria.addCriteria("UPDID", record.getAttribute("UPDID"));  
                detailViewer.fetchData(criteria);  

                return detailViewer;  
            } */
		//};  
		sourceListGrid.setShowRollOverCanvas(true);

		sourceListGrid.setDataSource(sourceListDS);
		sourceListGrid.setAutoFetchData(true);
		sourceListGrid.setAlign(Alignment.CENTER);
		sourceListGrid.setWidth("99%");
		sourceListGrid.setHeight("80%");

		sourceListGrid.setShowFilterEditor(true);
		sourceListGrid.setFilterOnKeypress(false);
		sourceListGrid.setCanEdit(false);
		SortSpecifier sortspec = new SortSpecifier("LISTDATE", SortDirection.DESCENDING);
		sourceListGrid.addSort(sortspec);
		sourceListGrid.setCanHover(true);  
		sourceListGrid.setShowHover(true);  
		//sourceListGrid.setShowHoverComponents(true); 
		sourceListGrid.setContextMenu(createContextMenuCorrisp());
		
		ListGridField download = new ListGridField("DOWNLOAD","Downlaod File");
		download.setWidth(30);
		download.setAlign(Alignment.CENTER);
		download.setShowTitle(false);
		download.setCanEdit(false);
		download.setShowHover(true);
		download.setHoverCustomizer(new HoverCustomizer() {
			
			@Override
			public String hoverHTML(Object value, ListGridRecord record, int rowNum,
					int colNum) {
				String download="Download the selected source list.";
				return download;
			}
		});
		
		sourceListGrid.setFields(new ListGridField("UPDID", "Update ID"),new ListGridField("SRCLIST", "List Source"),
				new ListGridField("LISTDATE", "Date"),new ListGridField("DOWNLOADID", "Download ID"),  
				new ListGridField("UPDDATE", "Update Date"),new ListGridField("UPDTYPE", "Update type"),
				new ListGridField("UPDUSER", "Update User"), 
				new ListGridField("NOTE", "Note"),download);

		sourceListGrid.getField("DOWNLOAD").setCellFormatter(new CellFormatter() {

			@Override
			public String format(Object value, ListGridRecord record, int rowNum,
					int colNum) {

				return Canvas.imgHTML("download.png",12,12);
				
			}
		});
		
				
		sourceListGrid.addCellClickHandler(new CellClickHandler() {

			@Override
			public void onCellClick(CellClickEvent event) {

				ListGridRecord record=event.getRecord(); 
				int colNum = event.getColNum();
				int rowNum = event.getRowNum();
				String fieldName = sourceListGrid.getFieldName(colNum);  

				if(fieldName.equalsIgnoreCase("DOWNLOAD")) {

					String source = record.getAttributeAsString("SRCLIST");
					String download = record.getAttributeAsString("DOWNLOADID");
					Date audDate = record.getAttributeAsDate("LISTDATE");

					String paramStr = source+","+download+","+audDate.getTime()+",download";

					RPCRequest rpcRequest = new RPCRequest();

					rpcRequest.setHttpMethod("POST");
					// Sto dicendo al client di aprire un hidden frame dal quale generare la richiesta in POST
					rpcRequest.setTransport(RPCTransport.HIDDENFRAME);
					rpcRequest.setActionURL("ccgportal/xmlServlet?params=" + paramStr);

					RPCManager.sendRequest(rpcRequest);

				}
			}
		});
		
		/*sourceListGrid.addDoubleClickHandler(new DoubleClickHandler() {

			@Override
			public void onDoubleClick(DoubleClickEvent event) {

				ListGridRecord lgr = sourceListGrid.getSelectedRecord(); 
				String source = lgr.getAttributeAsString("SRCLIST");
				String download = lgr.getAttributeAsString("DOWNLOADID");

				String paramStr = source+","+download+",download";
				RPCRequest rpcRequest = new RPCRequest();

				rpcRequest.setHttpMethod("POST");
				// Sto dicendo al client di aprire un hidden frame dal quale generare la richiesta in POST
				rpcRequest.setTransport(RPCTransport.HIDDENFRAME);
				rpcRequest.setActionURL("ccgportal/xmlServlet?params=" + paramStr);

				RPCManager.sendRequest(rpcRequest);

			}
		});
		 */

		this.workingArea.addMember(sourceListGrid);

		downloadButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				ListGridRecord[] lgr = sourceListGrid.getSelectedRecords();
				if(lgr!=null && lgr.length==1){

					String source = lgr[0].getAttributeAsString("SRCLIST");
					String download = lgr[0].getAttributeAsString("DOWNLOADID");
					Date audDate = lgr[0].getAttributeAsDate("LISTDATE");

					String paramStr = source+","+download+","+audDate.getTime()+",download";

					RPCRequest rpcRequest = new RPCRequest();

					rpcRequest.setHttpMethod("POST");
					// Sto dicendo al client di aprire un hidden frame dal quale generare la richiesta in POST
					rpcRequest.setTransport(RPCTransport.HIDDENFRAME);
					rpcRequest.setActionURL("ccgportal/xmlServlet?params=" + paramStr);

					RPCManager.sendRequest(rpcRequest);

				}
				else if(lgr.length>1){
					SC.say("Please select one record only");
				}else SC.say("Please select one record to download");
			}	
		});

		// Export button
		exportButton.setTooltip(ClientMessages.export());
		this.exportButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
				RecordList reclistforexport = new RecordList();
				reclistforexport = sourceListGrid.getRecordList();
				if (reclistforexport.getLength() != 0)
					ExportWindow.windowCreator(sourceListGrid);
				else
					SC.say("No record to export");
			}
		});

		//Print button
		printButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				VLayout[] v = new VLayout[] { sourceListGrid };

				Canvas.showPrintPreview(v, null, DESCRIPTION, null);
			}
		});

		bottomControlBar.addMember(downloadButton);
		bottomControlBar.addMember(exportButton);
		bottomControlBar.addMember(printButton);


		this.workingArea.addMember(bottomControlBar);


		//Working area
		this.addMember(workingArea);
	}

	//Factory
	public static class Factory implements PanelFactory {
		private String id;
		public Canvas create(TabSet mainTabSet, String panelID) {
			SourceListArchivePanel panel = new SourceListArchivePanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

		public String getID() {
			return id;
		}

		public String getDescription() {
			return null;
		}

		public Canvas create(TabSet mainTabSet, String panelID, int instrid, String instrname) {
			SourceListArchivePanel panel = new SourceListArchivePanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

	}

	/*private VLayout createTrackForm(String source, String downId){

		containerLayout.setHeight(sourceListGrid.getHeight());
		containerLayout.setWidth("49%");

		htmlFlow.setWidth("100%");
		htmlFlow.setHeight("100%");


		Map<String,String> params = new HashMap<String,String>();
		params.put("srcList", source);
		params.put("downloadId", downId);
		params.put("op", "parse");
		//htmlFlow.setText("<h2>Loading data...</h2>");

		MyRPCRequest request = new MyRPCRequest("ccgportal/xmlServlet",params);

		RPCManager.sendRequest(request,new RPCCallback() {

			@Override
			public void execute(RPCResponse response, Object rawData, RPCRequest request) {
				HashMap<String, String> respMap = (HashMap<String, String>) response.getDataAsMap();

				htmlFlow.setText(respMap.get("data"));
				//htmlFlow.setContents(respMap.get("data").substring(0, 1000));
				//htmlFlow.draw();
			}
		});
		//containerLayout.redraw();
		containerLayout.addMember(htmlFlow);

	return containerLayout;
}*/

	// Context menu CORRISP
	private Menu createContextMenuCorrisp() {
		Menu menu = new Menu();
		menu.setWidth(140);

		String name ="";
		ListGridRecord lgr = sourceListGrid.getSelectedRecord();
		if(lgr!=null)
			name = lgr.getAttributeAsString("UPDID");

		//View Details
		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);

		//Textify Selection
		TextifyMenuItem textItem = new TextifyMenuItem();

		menu.setItems(viewDetItem,textItem);

		return menu;
	}

	@Override
	public void refresh() {
		// TODO Auto-generated method stub

	}
}