package it.ccg.tcfrontend.client.panels;

import java.util.HashMap;
import java.util.Map;

import it.ccg.tcfrontend.client.ExportWindow;
import it.ccg.tcfrontend.client.HelpWindow;
import it.ccg.tcfrontend.client.PanelFactory;
import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.SecureStandardShowButton;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardComboBox;
import it.ccg.tcfrontend.client.controls.StandardControlBar;
import it.ccg.tcfrontend.client.controls.StandardListGrid;
import it.ccg.tcfrontend.client.interf.Refreshable;
import it.ccg.tcfrontend.client.menu.TextifyMenuItem;
import it.ccg.tcfrontend.client.menu.ViewDetailsMenuItem;
import it.ccg.tcfrontend.client.utils.ClientMessages;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.RecordList;
import com.smartgwt.client.data.SortSpecifier;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.BackgroundRepeat;
import com.smartgwt.client.types.Cursor;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.types.OperatorId;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.MouseOutEvent;
import com.smartgwt.client.widgets.events.MouseOutHandler;
import com.smartgwt.client.widgets.events.MouseOverEvent;
import com.smartgwt.client.widgets.events.MouseOverHandler;
import com.smartgwt.client.widgets.form.fields.events.ChangeEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangeHandler;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.tab.TabSet;

public class AuditTrailPanel extends VLayout implements Refreshable{

	final protected  TabSet mainTabSet;
	protected StandardControlBar topControlBar = new StandardControlBar();
	//protected StandardControlBar showControlBar = new StandardControlBar();
	protected HLayout topTablesArea = new HLayout();
	protected VLayout workingArea = new VLayout();
	protected StandardControlBar bottomControlBar = new StandardControlBar();
	private static final String DESCRIPTION = "Audit Trail";

	private String eventcombo;
	private int instrumentID;
	private String instrumentName;

	final StandardComboBox runCombo = new StandardComboBox("Run");
	final SecureStandardShowButton showItem = new SecureStandardShowButton();
	final protected StandardButton userActItem = new StandardButton("User activity");
	final protected StandardButton exportButton = new StandardButton("Export");
	final protected StandardButton printButton = new StandardButton("Print");

	private StandardListGrid terroristListGrid;
	private StandardListGrid clientListGrid;
	private StandardListGrid corrispListGrid;

	public AuditTrailPanel(final TabSet mainTabSet, String panelID) {
		super();

		this.mainTabSet=mainTabSet;

		//LABEL AUDIT TRAIL
		// Definizione label
		final Label auditTrailLabel= new Label();

		auditTrailLabel.setHeight(10);
		auditTrailLabel.setWidth100();
		auditTrailLabel.setPadding(4);
		auditTrailLabel.setAlign(Alignment.LEFT);
		auditTrailLabel.setValign(VerticalAlignment.CENTER);
		auditTrailLabel.setWrap(false);
		auditTrailLabel.setBackgroundImage("newskins/header.png");
		auditTrailLabel.setBackgroundRepeat(BackgroundRepeat.REPEAT_X);
		auditTrailLabel.setContents("Select the run you want to analyze and click show");

		this.workingArea.addMember(auditTrailLabel);

		//REFRESH LABEL AND BUTTON
		final Label refresh = new Label();  
		refresh.setHeight(30);  
		refresh.setPadding(10);  
		refresh.setAlign(Alignment.CENTER);  
		refresh.setValign(VerticalAlignment.CENTER);  
		refresh.setWrap(false);  
		refresh.setIcon("icons/24/refresh.png");  
		refresh.setCanHover(true);
		refresh.setShowHover(false);

		refresh.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				refresh.setOpacity(50);
				refresh.setCursor(Cursor.POINTER);
			}
		});


		refresh.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				refresh.setOpacity(100);
				refresh.setCursor(Cursor.DEFAULT);
			}
		});

		refresh.setContents("<i>Refresh</i>");  

		refresh.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				terroristListGrid.invalidateCache();
				clientListGrid.invalidateCache();
				corrispListGrid.invalidateCache();


			}
		});

		//HELP LABEL AND BUTTON
		final Label helpLabel = new Label();  
		helpLabel.setHeight(30);  
		helpLabel.setPadding(10);  
		helpLabel.setAlign(Alignment.CENTER);  
		helpLabel.setValign(VerticalAlignment.CENTER);  
		helpLabel.setWrap(false);  
		helpLabel.setIcon("icons/24/help24.png");  
		helpLabel.setCanHover(true);
		helpLabel.setShowHover(false);

		helpLabel.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				helpLabel.setOpacity(50);
				helpLabel.setCursor(Cursor.POINTER);
			}
		});

		helpLabel.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				helpLabel.setOpacity(100);
				helpLabel.setCursor(Cursor.DEFAULT);
			}
		});

		helpLabel.setContents("<i>Help</i>");  

		helpLabel.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				HelpWindow.windowCreator2(mainTabSet, "");

			}
		});

		//FilterCombo
		//Data sources utilizzato dal filtro 
		final DataSource activityLogDS = SecureDS.get("tctrunreg");


		runCombo.setOptionDataSource(activityLogDS);
		ListGridField runId = new ListGridField("RUNID");
		runId.setWidth(200);
		ListGridField matchFound = new ListGridField("MATCHFOUND");
		matchFound.setWidth(100);
		ListGridField runDate = new ListGridField("RUNDATE");
		runDate.setWidth(150);
		runCombo.setValueField("RUNID");
		runCombo.setDisplayField("RUNID");
		runCombo.setPickListSort(new SortSpecifier[] {new SortSpecifier("RUNID", SortDirection.DESCENDING)});
		runCombo.setPickListWidth(466);
		runCombo.setPickListFields(runId, matchFound,runDate);
		runCombo.setFilterLocally(true);

		// Utilizzato per prendere i valori dalla combo
		runCombo.addChangeHandler(new ChangeHandler() {
			public void onChange(ChangeEvent event) {
				if (event.getValue() != null){
					showItem.setDisabled(false);
					userActItem.setDisabled(false);
					eventcombo = event.getValue().toString();
					}
				else if (event.getValue() == null){
					showItem.setDisabled(true);
					userActItem.setDisabled(true);
					eventcombo = null;
				}
			}

		});



		showItem.setTooltip(ClientMessages.ttpShowBtn());
		showItem.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				showData();
			}
		});

		// User Activity button click handler
		userActItem.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				if (eventcombo != null) {
					int comboSelection = Integer.parseInt(eventcombo);
					setInstrumentID(comboSelection);
					setInstrumentName(runCombo.getDisplayValue());

					UserActivityWindow.windowCreator(comboSelection);
				}
			}
		});


		LayoutSpacer lstop = new LayoutSpacer();
		lstop.setWidth("35%");

		showItem.setDisabled(true);
		userActItem.setDisabled(true);
		
		topControlBar.addMember(runCombo.inDynamicForm());
		topControlBar.addMember(showItem);
		topControlBar.addMember(userActItem);
		topControlBar.addMember(lstop);
		topControlBar.addMember(refresh);
		topControlBar.addMember(helpLabel);

		this.workingArea.addMember(topControlBar);

		topTablesArea.setHeight("52%");

		// DataSource utilizzato per la tabella della lista dei terroristi
		final DataSource tctTerroristListDS = SecureDS.get("tctaggrent");
		tctTerroristListDS.getField("RUNDATE").setDetail(true);

		terroristListGrid=new StandardListGrid(panelID, "tctaggrent");
		terroristListGrid.setDataSource(tctTerroristListDS);
		terroristListGrid.setFetchOperation("tctaggrent_fetch");
		terroristListGrid.setWidth100();
		terroristListGrid.setHeight("50%");
		terroristListGrid.setShowFilterEditor(true);
		terroristListGrid.setFilterOnKeypress(false);
		terroristListGrid.setCanEdit(false);
		terroristListGrid.setEditEvent(ListGridEditEvent.NONE);
		terroristListGrid.setSortField("UPDDATE");
		terroristListGrid.setSortDirection(SortDirection.DESCENDING);
		terroristListGrid.setContextMenu(createContextMenu());
		
		
		VLayout terroristListLayout= new VLayout();
		terroristListLayout.setWidth("40%");
		terroristListLayout.setHeight100();

		// Definizione Terrorist label
		Label terroristListLabel= new Label();

		terroristListLabel.setHeight(10);
		terroristListLabel.setWidth100();
		terroristListLabel.setPadding(4);
		terroristListLabel.setAlign(Alignment.LEFT);
		terroristListLabel.setValign(VerticalAlignment.CENTER);
		terroristListLabel.setWrap(false);
		terroristListLabel.setBorder(terroristListGrid.getBorder());
		terroristListLabel.setBackgroundImage("newskins/header.png");
		terroristListLabel.setBackgroundRepeat(BackgroundRepeat.REPEAT_X);
		terroristListLabel.setContents("List of terrorists");


		terroristListLayout.addMember(terroristListLabel);
		terroristListLayout.addMember(terroristListGrid);

		this.topTablesArea.addMember(terroristListLayout);

		LayoutSpacer ls1=new LayoutSpacer();
		ls1.setWidth("1,5%");

		this.topTablesArea.addMember(ls1);

		// DataSource utilizzato per la tabella della lista dei clienti
		final DataSource tctClientHStatDatDS = SecureDS.get("tctclienth");

		clientListGrid=new StandardListGrid(panelID, "tctclienth");
		clientListGrid.setDataSource(tctClientHStatDatDS);
		clientListGrid.setWidth100();
		clientListGrid.setHeight("50%");
		clientListGrid.setShowFilterEditor(true);
		clientListGrid.setFilterOnKeypress(false);
		clientListGrid.setCanEdit(false);
		clientListGrid.setContextMenu(createContextMenuClient());

		VLayout clientListLayout= new VLayout();
		clientListLayout.setWidth("40%");
		clientListLayout.setHeight100();

		// Definizione Client label
		Label clientListLabel= new Label();

		clientListLabel.setHeight(10);
		clientListLabel.setWidth100();
		clientListLabel.setPadding(4);
		clientListLabel.setAlign(Alignment.LEFT);
		clientListLabel.setValign(VerticalAlignment.CENTER);
		clientListLabel.setWrap(false);
		clientListLabel.setBorder(clientListGrid.getBorder());
		clientListLabel.setBackgroundImage("newskins/header.png");
		clientListLabel.setBackgroundRepeat(BackgroundRepeat.REPEAT_X);
		clientListLabel.setContents("List of clients");


		clientListLayout.addMember(clientListLabel);
		clientListLayout.addMember(clientListGrid);

		this.topTablesArea.addMember(clientListLayout);

		this.workingArea.addMember(topTablesArea);

		LayoutSpacer lstop2 = new LayoutSpacer();
		lstop2.setHeight("2,5%");
		this.workingArea.addMember(lstop2);

		// DataSource utilizzato per la tabella delle corrispondenze
		final DataSource tctcorrispDS = SecureDS.get("tctcorrisp");
		tctcorrispDS.getField("RUNID").setDetail(true);
		HashMap<String, String> val = new HashMap<String, String>();
		val.put("O", "Outstanding");
		val.put("F", "False positive");
		val.put("P", "Positive match");
		tctcorrispDS.getField("STATUS").setValueMap(val);
		
		corrispListGrid=new StandardListGrid(panelID, "tctcorrisp");
		corrispListGrid.setDataSource(tctcorrispDS);
		corrispListGrid.setFetchOperation("tctcorrisp_fetch");
		corrispListGrid.setWidth100();
		corrispListGrid.setHeight("*");
		corrispListGrid.setShowFilterEditor(true);
		corrispListGrid.setFilterOnKeypress(false);
		corrispListGrid.setCanEdit(false);
		corrispListGrid.setContextMenu(createContextMenuCorrisp());

		// Definizione Corrispondenze label
		Label corrispListLabel= new Label();

		corrispListLabel.setHeight(10);
		corrispListLabel.setWidth100();
		corrispListLabel.setPadding(4);
		corrispListLabel.setAlign(Alignment.LEFT);
		corrispListLabel.setValign(VerticalAlignment.CENTER);
		corrispListLabel.setWrap(false);
		corrispListLabel.setBorder(corrispListGrid.getBorder());
		corrispListLabel.setBackgroundImage("newskins/header.png");
		corrispListLabel.setBackgroundRepeat(BackgroundRepeat.REPEAT_X);
		corrispListLabel.setContents("Selected run results");


		this.workingArea.addMember(corrispListLabel);
		this.workingArea.addMember(corrispListGrid);

		// Export button
		exportButton.setTooltip(ClientMessages.export());
		this.exportButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
				RecordList reclistforexport = new RecordList();
				reclistforexport = clientListGrid.getRecordList();
				if (reclistforexport.getLength() != 0)
					ExportWindow.windowCreator(clientListGrid,"tctaggrent_fetch");
				else
					SC.say("No record to export");
			}
		});

		//Print button
		printButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				VLayout[] v = new VLayout[] { clientListGrid };

				Canvas.showPrintPreview(v, null, DESCRIPTION, null);
			}
		});

		bottomControlBar.addMember(exportButton);
		bottomControlBar.addMember(printButton);

		this.workingArea.addMember(bottomControlBar);


		//Working area
		this.addMember(workingArea);
	}

	//Factory
	public static class Factory implements PanelFactory {
		private String id;
		public Canvas create(TabSet mainTabSet, String panelID) {
			AuditTrailPanel panel = new AuditTrailPanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

		public String getID() {
			return id;
		}

		public String getDescription() {
			return null;
		}

		public Canvas create(TabSet mainTabSet, String panelID, int instrid, String instrname) {
			AuditTrailPanel panel = new AuditTrailPanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

	}


	public void setInstrumentID(int instrumentID) {
		this.instrumentID = instrumentID;
	}

	public void setInstrumentName(String instrumentName) {
		this.instrumentName = instrumentName;
	}

	public int getInstrumentID() {
		return this.instrumentID;
	}

	public String getInstrumentName() {
		return instrumentName;
	}

	public void showData() {
		if (eventcombo != null) {
			int comboSelection = Integer.parseInt(eventcombo);
			setInstrumentID(comboSelection);
			setInstrumentName(runCombo.getDisplayValue());

			AdvancedCriteria crit = new AdvancedCriteria();
			crit.addCriteria("RUNID", comboSelection);

			terroristListGrid.filterData(crit);
			clientListGrid.filterData(crit);
			corrispListGrid.filterData(crit);

		} else {
			SC.say("Please select a valid Run value");
		}
	}


	// Context menu TERRORIST LIST
	private Menu createContextMenu() {
		Menu menu = new Menu();
		menu.setWidth(140);

		String name ="";
		ListGridRecord lgr = terroristListGrid.getSelectedRecord();
		if(lgr!=null)
			name = lgr.getAttributeAsString("AGGREGID");

		//View Details
		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);

		//Textify Selection
		TextifyMenuItem textItem = new TextifyMenuItem();

		menu.setItems(viewDetItem,textItem);

		return menu;
	}

	// Context menu CLIENT HISTORY
	private Menu createContextMenuClient() {
		Menu menu = new Menu();
		menu.setWidth(140);

		String name ="";
		ListGridRecord lgr = terroristListGrid.getSelectedRecord();
		if(lgr!=null)
			name = lgr.getAttributeAsString("CLNTID");

		//View Details
		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);

		//Textify Selection
		TextifyMenuItem textItem = new TextifyMenuItem();

		menu.setItems(viewDetItem,textItem);

		return menu;
	}

	// Context menu CORRISP
	private Menu createContextMenuCorrisp() {
		Menu menu = new Menu();
		menu.setWidth(140);

		String name ="";
		ListGridRecord lgr = terroristListGrid.getSelectedRecord();
		if(lgr!=null)
			name = lgr.getAttributeAsString("RUNID");

		//View Details
		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);

		//Textify Selection
		TextifyMenuItem textItem = new TextifyMenuItem();

		menu.setItems(viewDetItem,textItem);

		return menu;
	}


	@Override
	public void refresh() {
		// TODO Auto-generated method stub

	}

}
