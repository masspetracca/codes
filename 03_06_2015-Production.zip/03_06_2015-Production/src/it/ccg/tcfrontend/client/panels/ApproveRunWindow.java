package it.ccg.tcfrontend.client.panels;

import java.util.Date;

import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.SecureDoubleClick;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardListGrid;
import it.ccg.tcfrontend.client.security.Privileges;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.Criterion;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.data.SortSpecifier;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCQueueCallback;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Cursor;
import com.smartgwt.client.types.OperatorId;
import com.smartgwt.client.types.SelectionAppearance;
import com.smartgwt.client.types.SelectionStyle;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.fields.LinkItem;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.CellClickEvent;
import com.smartgwt.client.widgets.grid.events.CellClickHandler;
import com.smartgwt.client.widgets.grid.events.CellHoverEvent;
import com.smartgwt.client.widgets.grid.events.CellHoverHandler;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickHandler;
import com.smartgwt.client.widgets.grid.events.SelectionChangedHandler;
import com.smartgwt.client.widgets.grid.events.SelectionEvent;
import com.smartgwt.client.widgets.grid.events.SelectionUpdatedEvent;
import com.smartgwt.client.widgets.grid.events.SelectionUpdatedHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;

public class ApproveRunWindow extends Window{

	String winId=this.getID();
	protected VLayout workingArea = new VLayout();

	final String[] role = Privileges.getUserRoles();

	final DataSource tctrunreg = SecureDS.get("tctrunreg");	
	final DataSource tctcorrisp = SecureDS.get("tctcorrisp");
	final DataSource tctusract = SecureDS.get("tctusract");

	//Grids
	private StandardListGrid runregListGrid;
	private StandardListGrid corrispListGrid;

	//Buttons
	final protected StandardButton buttonApproveAll = new StandardButton("Approve all", "APPROVERUN001");
	//final protected StandardButton buttonApproveSelected = new StandardButton("Approve Selected Run", "APPROVERUN002");  

	public ApproveRunWindow(final LinkItem approveLink, final String isApproveEnabled){

		super();
		this.setID("ApproveWindow");
		this.setTitle("Approve window");
		this.setWidth(750);
		this.setHeight(500);
		this.setCanDragReposition(true);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);
		this.setMembersMargin(3);
		this.centerInPage();

		final Window me = this;

		runregListGrid = new StandardListGrid("ApproveRun");

		tctrunreg.getField("APPROVED").setAttribute("hidden", "true");
		tctrunreg.getField("RUNID").setAttribute("width", 100);
		tctrunreg.getField("REPORT").setAttribute("width", "100%");
		tctrunreg.getField("APPROVER").setAttribute("hidden", "true");
		tctrunreg.getField("UPDUSER").setAttribute("detail", true);

		//DataSource utilizzato per la tabella della lista dei clienti
		runregListGrid.setDataSource(tctrunreg);
		runregListGrid.setWidth100();
		runregListGrid.setHeight("45%");
		runregListGrid.setShowFilterEditor(false);
		runregListGrid.setFilterOnKeypress(false);
		runregListGrid.setAutoFetchData(true);   
		runregListGrid.setCanEdit(false);
		runregListGrid.setAlternateRecordStyles(true);  
		runregListGrid.setSelectionType(SelectionStyle.SINGLE);  
		runregListGrid.setMargin(5);


		AdvancedCriteria criteria = new AdvancedCriteria(OperatorId.AND, new Criterion[]{
				new Criterion("SUBDATE", OperatorId.NOT_NULL),
				new Criterion("APPROVED", OperatorId.EQUALS, "F"),
				new Criterion("MATCHFOUND", OperatorId.EQUALS, "T")

		});

		runregListGrid.fetchData(criteria);

		SortSpecifier sortspec = new SortSpecifier("RUNID", SortDirection.ASCENDING);
		runregListGrid.addSort(sortspec);

		LayoutSpacer ls1 = new LayoutSpacer();
		ls1.setHeight(10);


		corrispListGrid = new StandardListGrid("ApproveRun");

		//DataSource utilizzato per la tabella della lista dei clienti
		corrispListGrid.setDataSource(tctcorrisp);
		corrispListGrid.setWidth100();
		corrispListGrid.setHeight("45%");
		corrispListGrid.setShowFilterEditor(true);
		corrispListGrid.setFilterOnKeypress(false);
		corrispListGrid.setAutoFetchData(false);   
		corrispListGrid.setCanEdit(false);
		corrispListGrid.setAlternateRecordStyles(true);  
		corrispListGrid.setSelectionType(SelectionStyle.SINGLE);  
		//corrispListGrid.setSelectionType(SelectionStyle.SIMPLE);  
		//corrispListGrid.setSelectionAppearance(SelectionAppearance.CHECKBOX);
		corrispListGrid.setMargin(5);



		SortSpecifier sort = new SortSpecifier("RUNID", SortDirection.DESCENDING);
		runregListGrid.addSort(sort);


		workingArea.addMembers(ls1,runregListGrid,corrispListGrid);

		//selezione singolo run dalla tctrunreg
		runregListGrid.addSelectionChangedHandler(new SelectionChangedHandler() {

			@Override
			public void onSelectionChanged(SelectionEvent event) {
				// TODO Auto-generated method stub

				Criteria criteria = new Criteria();
				criteria.setAttribute("RUNID", event.getRecord().getAttribute("RUNID"));
				corrispListGrid.fetchData(criteria);
			}
		});


		//Download report
		runregListGrid.addCellClickHandler(new CellClickHandler() {

			@Override
			public void onCellClick(CellClickEvent event) {

				ListGridRecord record=event.getRecord(); 
				int colNum = event.getColNum();
				int rowNum = event.getRowNum();
				String fieldName = runregListGrid.getFieldName(colNum);  
				String val = runregListGrid.getRecord(rowNum).getAttributeAsString("REPORT");

				if(fieldName.equalsIgnoreCase("REPORT") && val.equalsIgnoreCase("T")) {

					int runId = record.getAttributeAsInt("RUNID");
//					int comanyID = record.getAttributeAsInt("CMPNID");

					String paramStr = runId+/*","+comanyID+*/",tctcorrisp";

					RPCRequest rpcRequest = new RPCRequest();

					rpcRequest.setHttpMethod("POST");
					rpcRequest.setDownloadResult(true);

					// Sto dicendo al client di aprire un hidden frame dal quale generare la richiesta in POST
					//rpcRequest.setTransport(RPCTransport.HIDDENFRAME);
					rpcRequest.setActionURL("ccgportal/PdfServlet?params=" + paramStr);
					//RPCManager.setShowPrompt(true);
					RPCManager.sendRequest(rpcRequest);	
					//RPCManager.setShowPrompt(false);

				}
			}
		});

		runregListGrid.setCanHover(true);
		runregListGrid.setShowHover(false);
		runregListGrid.addCellHoverHandler(new CellHoverHandler() {

			@Override
			public void onCellHover(CellHoverEvent event) {
				ListGridRecord record=event.getRecord(); 
				int colNum = event.getColNum();
				String fieldName = runregListGrid.getFieldName(colNum);  

				if(fieldName.equalsIgnoreCase("REPORT")&&(record.getAttributeAsString("REPORT").equalsIgnoreCase("T"))) {

					runregListGrid.getChildren()[2].setCursor(Cursor.POINTER);
				}
				else{
					runregListGrid.getChildren()[2].setCursor(Cursor.DEFAULT);
				}
			}
		});

		runregListGrid.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}
				try {
					SecureDoubleClick.secureDoubleClickRecord(event, runregListGrid, "APPROVERUN003");
				} catch (Exception e) {
				}
			}
		});	

		/*buttonApproveSelected.setWidth(700); 
		buttonApproveSelected.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}

				else{
					String confMessage="";

					final ListGridRecord[] result = runregListGrid.getSelectedRecords();
					//System.out.println("Result: "+result.length);
					String rec = "";
					if(result!=null && result.length!=0){
						if(result.length==1)
							rec = result[0].getAttributeAsString("RUNID");
						else{
							rec = result[0].getAttributeAsString("RUNID");
							for(int i=1;i<result.length;i++){
								if(!result[i].getAttributeAsString("RUNID").equalsIgnoreCase(result[i-1].getAttributeAsString("RUNID")))
									rec += "," +result[i].getAttributeAsString("RUNID");
							}
						}

						final String runIds = rec;

						if(result.length==1)
							confMessage="Are you sure you want to approve the analyzed results related to the run id "+rec+" ?";

						else
							confMessage="Are you sure you want to approve the analyzed results related to the run ids "+rec+" ?";


						SC.confirm(confMessage,
								new BooleanCallback() {
							public void execute(Boolean value) {

								if (value != null && value) {

									int totalrows=runregListGrid.getTotalRows();

									if(totalrows==0){
										SC.warn("No rows to submit.");
									}
									else{

										RPCManager.startQueue();
										RPCManager.setShowPrompt(true);

										for(int i=0;i<result.length;i++){

											//automaticamente tutti gli outstanding diventano false positive
											result[i].setAttribute("APPROVED", "T");
											result[i].setAttribute("APPROVER", Privileges.getUsername());
											runregListGrid.updateData(result[i]);

										}

										if(result.length == totalrows){
											RPCManager.sendQueue(new RPCQueueCallback() {

												@Override
												public void execute(RPCResponse... response) {
													runregListGrid.invalidateCache();
													approveLink.hide();
													me.destroy();
													SC.say("RunId "+runIds+" approved. Please refer to the activity log for details.");
													//drawTopBar(approveLink, isApproveEnabled);


												}
											});
										}else{
											RPCManager.sendQueue(new RPCQueueCallback() {

												@Override
												public void execute(RPCResponse... response) {
													runregListGrid.invalidateCache();
													SC.say("RunId "+runIds+" approved. Please refer to the activity log for details.");
													//approveLink.show();
													//drawTopBar(approveLink, isApproveEnabled);


												}
											});
										}
									}
								}
							}
						});
					}else
						SC.say("Please select one record to download");

					//runregListGrid.invalidateCache()
				}
			}	
		});*/


		buttonApproveAll.setWidth(700);  
		buttonApproveAll.addClickHandler(new ClickHandler() {  
			@Override  
			public void onClick(ClickEvent event) {


				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}

				else{
					String confMessage="";

					final ListGridRecord[] result = runregListGrid.getRecords();

					String rec = "";

					if(result.length==1)
						rec = result[0].getAttributeAsString("RUNID");
					else{
						rec = result[0].getAttributeAsString("RUNID");
						for(int i=1;i<result.length;i++){
							if(!result[i].getAttributeAsString("RUNID").equalsIgnoreCase(result[i-1].getAttributeAsString("RUNID")))
								rec += "," +result[i].getAttributeAsString("RUNID");
						}
					}
					if(result.length==1)
						confMessage="Are you sure you want to approve the analyzed results related to the run id "+rec+" ?";

					else
						confMessage="Are you sure you want to approve the analyzed results related to the run ids "+rec+" ?";

					final String runIds = rec;

					SC.confirm(confMessage,
							new BooleanCallback() {
						public void execute(Boolean value) {

							if (value != null && value) {

								int totalrows=runregListGrid.getTotalRows();

								if(totalrows==0){
									SC.warn("No rows to submit.");
								}
								else{

									//RPCManager.setShowPrompt(true);
									//RPCManager.startQueue();

									//for(int i=0;i<result.length;i++){

									//automaticamente tutti gli outstanding diventano false positive
									/*result[i].setAttribute("APPROVED", "T");
										result[i].setAttribute("APPROVER", Privileges.getUsername());
										runregListGrid.updateData(result[i]);*/

									
									AdvancedCriteria criteria = new AdvancedCriteria(OperatorId.AND, new Criterion[]{
											new Criterion("SUBDATE", OperatorId.NOT_NULL),
											new Criterion("APPROVED", OperatorId.EQUALS, "F"),
											new Criterion("MATCHFOUND", OperatorId.EQUALS, "T")

									});

									tctrunreg.fetchData(criteria, new DSCallback() {
										
										@Override
										public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
											// TODO Auto-generated method stub
											Record[] rec = dsResponse.getData();
											
											RPCManager.startQueue();
											RPCManager.setShowPrompt(true);
											
											updateAuditTableSubmitRunReg(rec);
											
											rec[0].setAttribute("APPROVED", "T");
											rec[0].setAttribute("APPROVER", Privileges.getUsername());
											runregListGrid.updateData(rec[0]);
											
											Record r = new Record();  
											DSRequest req = new DSRequest();
											req.setAttribute("operationId", "reportApproveUpdate");  
											tctrunreg.updateData(r,null, req);
											
											
											RPCManager.sendQueue(new RPCQueueCallback() {

												@Override
												public void execute(RPCResponse... response) {
													approveLink.hide();
													runregListGrid.invalidateCache();
													me.destroy();
													SC.say("RunId "+runIds+" approved. Please refer to the activity log for details.");
												}
											});
										}
									});

									//}
									/*RPCManager.sendQueue(new RPCQueueCallback() {

										@Override
										public void execute(RPCResponse... response) {
											approveLink.hide();
											me.destroy();
											SC.say("RunId "+runIds+" approved. Please refer to the activity log for details.");
										}
									});*/
								}
							}
						}
					});
				}
			}  
		});  

		HLayout hLayoutButtons = new HLayout();  
		hLayoutButtons.setWidth100();  
		LayoutSpacer ls = new LayoutSpacer();
		//ls.setWidth(160);
		ls.setWidth(280);
		hLayoutButtons.setLayoutMargin(10);  
		hLayoutButtons.setMembersMargin(10);  
		hLayoutButtons.addMembers(ls,/* buttonApproveSelected,*/ buttonApproveAll); 

		workingArea.addMember(hLayoutButtons);


		this.addItem(workingArea);


		this.draw();

		final Window w = this;
		this.addCloseClickHandler(new CloseClickHandler() {

			@Override
			public void onCloseClick(CloseClickEvent event) {
				w.destroy();

			}
		});

	}

	public void drawTopBar(final LinkItem approveLink, final String isApproveEnabled){

		AdvancedCriteria crit = new AdvancedCriteria();
		crit.setAttribute("SUBDATE", OperatorId.IS_NULL);
		crit.setAttribute("APPROVED", "F");
		crit.setAttribute("MATCHFOUND", "T");

		tctrunreg.fetchData(crit, new DSCallback() {

			@Override
			public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
				Record[] approveRec = dsResponse.getData();
				System.out.println("***** //- "+approveRec.length);
				int contApprove = 0;
				for(int i=0;i<role.length;i++){
					if(role[i].equalsIgnoreCase("approver")){
						contApprove++;
					}
				}

				if(isApproveEnabled.compareToIgnoreCase("T")==0 && contApprove == 1 && approveRec.length>0){
					approveLink.show();
				}
				else{					
					approveLink.hide();
				}
			}

		});

	}

	public void updateAuditTableSubmitRunReg(Record[] recArr){

		for(int i=0;i<recArr.length;i++){
			Record rec = recArr[i];
			String[] fieldnames = tctrunreg.getFieldNames();
			String newRecordStr = "";
			int runid = rec.getAttributeAsInt("RUNID");
			Date date=new Date();
			for(int w=0;w<fieldnames.length;w++){
				if(fieldnames[w].compareToIgnoreCase("APPROVER")==0){
					newRecordStr+=fieldnames[w]+": "+Privileges.getUsername()+" | ";
				} else if(fieldnames[w].compareToIgnoreCase("CMPNID")==0){
					newRecordStr+="";
				} else if(fieldnames[w].compareToIgnoreCase("APPROVED")==0){
					newRecordStr+=fieldnames[w]+": 'T' | ";
				} else if(fieldnames[w].compareToIgnoreCase("UPDDATE")==0){
					newRecordStr+=fieldnames[w]+": "+date+" | ";
				} else if(fieldnames[w].compareToIgnoreCase("UPDUSER")==0){
					newRecordStr+=fieldnames[w]+": "+Privileges.getUsername()+" | ";
				} else{
					if(rec.getAttributeAsString(fieldnames[w])==null)
						newRecordStr+=fieldnames[w]+":  | ";
					else
						newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
				}
			}

			Record usrActRecord = new Record();

			usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctrunreg_update");
			usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
			usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
			usrActRecord.setAttribute("NEWRECORD", newRecordStr);
//			usrActRecord.setAttribute("CMPNID", Privileges.getCompanyID());
			usrActRecord.setAttribute("RUNID", runid);

			tctusract.addData(usrActRecord);


		}

	}

	public static ApproveRunWindow windowCreator(LinkItem approveLink, String isApproveEnabled) {

		ApproveRunWindow mw = (ApproveRunWindow) Canvas.getById("ApproveWindow");
		if (mw != null) {
			mw.setVisible(true);
			mw.restore();
			mw.bringToFront();
			return mw;
		} else {
			return new ApproveRunWindow(approveLink, isApproveEnabled);

		}

	}

}