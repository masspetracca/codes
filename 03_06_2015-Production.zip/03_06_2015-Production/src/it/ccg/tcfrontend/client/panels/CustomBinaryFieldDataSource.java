package it.ccg.tcfrontend.client.panels;

import it.ccg.tcfrontend.client.controls.SecureDS;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import com.isomorphic.datasource.BasicDataSource;
import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;
import com.isomorphic.rpc.RPCManager;
import com.isomorphic.servlet.ISCFileItem;
import com.smartgwt.client.data.DataSource;

public class CustomBinaryFieldDataSource extends BasicDataSource{
	
	   
    private byte[] fileData;  
    private static List listData = new ArrayList(); 
	public void downloadData(DSRequest dsRequest, RPCManager rpc){  
        DSResponse dsResponse = new DSResponse();  
        try {  
            rpc.doCustomResponse();  
            HttpServletResponse response = rpc.getContext().response; 
            
             Map res = dsRequest.getCriteria();
            System.out.println("11 "+res.get("UPLFILE_filename"));
            System.out.println("22 "+res.get("UPLID"));
            System.out.println("33 "+res.get("RUNID"));
            System.out.println(dsRequest.getDataSourceName());
            
            //byte[] bytes = this.getBinaryResponse(res);
            System.out.println("****");
            //System.out.println("**//*/* "+bytes.length);
            
            response.setHeader("content-disposition", "attachment; filename="+res.get("UPLFILE_filename"));   
            response.setContentType("text/plain");  
           
            dsResponse = dsRequest.execute(); 
            
            
            Map record = dsResponse.getDataMap();
              
            ServletOutputStream out = response.getOutputStream();  
            out.write(record.get("UPLFILE_filename").toString().getBytes());  
            dsResponse.setStatus(DSResponse.STATUS_SUCCESS);  
            rpc.send(dsRequest, dsResponse);
            
            
           /* Map record = dsResponse.getDataMap();
            
            Byte[] file = (Byte[]) dsResponse.getFieldValue("UPLFILE");
            ServletOutputStream out = response.getOutputStream();  
            out.write(record.get("UPLFILE").toString().getBytes());*/
            
            //List list = dsResponse.getDataList();
            /*Map record = dsResponse.getDataMap();  
            String result = "";  
            //Iterator iterator = list.iterator();  
            //while (iterator.hasNext()) {  
                //Map record =  (Map)iterator.next();  
                String itemName = (record.get("UPLFILE_filename") == null)?"":record.get("UPLFILE_filename").toString();  
                String description = (record.get("UPLFILE") == null)?"":record.get("UPLFILE").toString();  
                result = result + itemName + " : " + description + "\r\n\r\n";  
           // }  
            ServletOutputStream out = response.getOutputStream();  
            out.write(result.getBytes());*/  
            
            /* Map list = dsResponse.getDataMap();  
            String result = "";  
           // Iterator iterator = list.iterator();  
           // while (iterator.hasNext()) {  
                //Map record =  (Map)iterator.next();  
                String itemName = (list.get("UPLFILE_filename") == null)?"":list.get("UPLFILE_filename").toString();  
                String description = (list.get("UPLFILE_filesize") == null)?"":list.get("UPLFILE_filesize").toString();  
                result = result + itemName + " : " + description + "\r\n\r\n";  
            //}  
            ServletOutputStream out = response.getOutputStream();  
            out.write(list.get("UPLFILE_filesize").toString().getBytes());  */
            
            //byte[] bytes = null;  
    		//ISCFileItem item = null;
            
            //byte[] bytes = null;  
    		//ISCFileItem item = null;
    		
    		//Map result2 = dsRequest.getCriteria();  
    		/*String operationType = dsRequest.getOperationType();  
    		if (operationType.equals("downloadFile")) {  
    			bytes = this.getBinaryResponse(result);  
    			result.put("UPLFILE", bytes); 
    			result.put("RUNID", result.get("RUNID")); 
    			result.put("UPLFILE_filesize", (bytes == null)?0:bytes.length);  
    			dsResponse.setData(result);  
    		}*/
            
            dsResponse.setStatus(DSResponse.STATUS_SUCCESS); 
            //return dsResponse;
            rpc.send(dsRequest, dsResponse);  
        } catch (Exception e) {  
            try {  
                rpc.sendFailure(dsRequest, e.getMessage());  
            } catch(Exception er) {}   
        } 
    }
	
	private byte[] getBinaryResponse(Map map) {  
		byte[] bytes = null;  
		Iterator iterator = listData.iterator();  
		while (iterator.hasNext()) {  
			Map mapRecord = (Map)iterator.next();  
			if (mapRecord.get("UPLID").toString().equals(map.get("UPLID").toString()) ) {  
				bytes = mapRecord.get("UPLFILE").toString().getBytes();   
			}  
		}  
		return bytes;  
	}

		/*public DSResponse executeFetch(DSRequest dsRequest) throws Exception {  
		DSResponse dsResponse = new DSResponse(this); 

		//dsResponse.setDataSource(tctuplf);
        // A normal fetch should generally *not* return binary data for the binary  
        // field, because in most cases JavaScript logic in the browser would not be able to do  
        // anything with it (there would be no way to, for example, launch a PDF viewer for a PDF  
        // file included in Record data).  However the fetch operation is allowed to return binary  
        // data encoded as text (generally base64) for the cases where this is useful (for example  
        // some browsers support providing images as base64 encoded text).  
        // _filename, _filesize and _date_created are implied whenever a field of type "binary" is declared.  
		
		Map mappa = dsRequest.getCriteria();
		System.out.println("**"+mappa.size());
		System.out.println("***"+dsResponse.getDataList().size());
		//listData = dsResponse.getDataList();
		//System.out.println(listData.size());
		List list = new ArrayList();  
        Map mapRecord = new HashMap();  
        Iterator iterator = listData.iterator();  
        while (iterator.hasNext()) {  
            mapRecord = (Map)iterator.next();
            mapRecord.remove("UPLID");  
            list.add(mapRecord);  
        }  
        dsResponse.setData(list);
        return dsResponse;   
	} 


	public DSResponse execute(DSRequest dsRequest) throws Exception {  
		DSResponse dsResponse = new DSResponse(this); 
		
		byte[] bytes = null;  
		ISCFileItem item = null;
		
		Map mappa = dsRequest.getCriteria();
		//System.out.println("44 "+mappa.get("UPLFILE_FILENAME"));
        //System.out.println("55 "+mappa.get("UPLID"));
        System.out.println("66 "+mappa.get("RUNID"));
		
		//int runId =0;
		Map result = dsRequest.getCriteria();  
		String operationType = dsRequest.getOperationType();  
		if (operationType.equals("downloadFile")) {  
			bytes = this.getBinaryResponse(result);  
			result.put("UPLFILE", bytes); 
			result.put("RUNID", mappa.get("RUNID")); 
			result.put("UPLFILE_filesize", (bytes == null)?0:bytes.length);  
			dsResponse.setData(result);  
		} else if (operationType.equals("fetch")) {
			dsResponse = this.executeFetch(dsRequest);  
		}else if (operationType.equals("add")) {  
			item = dsRequest.getUploadedFile("UPLFILE"); 
			fileData = item.get();  
			dsResponse = this.executeAdd(dsRequest);  
		} 
		return dsResponse;  
	}  
	
	private byte[] getBinaryResponse(Map map) {  
		byte[] bytes = null;  
		Iterator iterator = listData.iterator();  
		while (iterator.hasNext()) {  
			Map mapRecord = (Map)iterator.next();  
			if (mapRecord.get("UPLID").toString().equals(map.get("UPLID").toString()) ) {  
				bytes = mapRecord.get("UPLFILE").toString().getBytes();   
			}  
		}  
		return bytes;  
	}

	//Aggiungere nuovo file
	public DSResponse executeAdd(DSRequest dsRequest) throws Exception {  
		DSResponse dsResponse = new DSResponse(this);  
		Map newValues = dsRequest.getValues();  
		newValues.put("UPLFILE", fileData); 
		newValues.put("RUNID", mappa.get("RUNID")); 
		newValues.put("UPLFILE_date_created", new Date());  
		dsResponse.setData(newValues);  
		return dsResponse;
	} 
	

	public DSResponse executeUpdate(DSRequest dsRequest) throws Exception {  
		DSResponse dsResponse = new DSResponse(this);  
		Map updateValues = dsRequest.getValues();  
		updateValues.put("UPLFILE", fileData);  
		//updateValues.put("file_date_created", new Date());  
		dsResponse.setData(updateValues);  
		return dsResponse;  
	} */
}  

