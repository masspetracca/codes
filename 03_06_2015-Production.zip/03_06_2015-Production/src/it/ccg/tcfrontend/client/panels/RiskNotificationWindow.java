package it.ccg.tcfrontend.client.panels;

import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardControlBar;
import it.ccg.tcfrontend.client.security.Privileges;
import it.ccg.tcfrontend.client.utils.Regex;

import java.util.LinkedHashMap;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.LinkItem;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.StaticTextItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.validator.RegExpValidator;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.tab.TabSet;

public class RiskNotificationWindow extends Window{

	DynamicForm riskform;
	SelectItem riskItem;  
	
	final DataSource tctcompanyDS = SecureDS.get("tctcompany");
	String risk = "";

	
	StandardControlBar bottomControlBar = new StandardControlBar();
	LayoutSpacer ls = new LayoutSpacer();
	

	public RiskNotificationWindow(final TabSet mainTabSet, final LinkItem manageRiskLink){

		super();
		final Window w = this;
		this.setID("RiskNotificationWindow");
		this.setTitle(Privileges.getCompany()+ "'s risk profile");
		this.setWidth(340);
		this.setHeight(280);
		this.centerInPage();
		this.setCanDragReposition(true);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);
		this.setShowMinimizeButton(false);
		this.setAlign(VerticalAlignment.CENTER);
		this.setAlign(Alignment.CENTER);
		this.setIsModal(true);

		//final Window w = this;

		//< > " ' % ; ) ( & + -
		//Name Surname validator
		RegExpValidator regExpValidatorName = new RegExpValidator();  
		regExpValidatorName.setExpression(Regex.regexNameSurname());  
		RegExpValidator regExpValidatorSurName = new RegExpValidator();  
		regExpValidatorSurName.setExpression(Regex.regexNameSurname());  

		//Notify
		riskform = new DynamicForm();
		riskform.setHeight("20%");
		riskform.setAlign(Alignment.LEFT);

		LinkedHashMap<String, String> valueMap = new LinkedHashMap<String, String>();  
		valueMap.put("hr", "High risk");
		valueMap.put("mr", "Avarage risk");
		valueMap.put("lr", "Low risk");
		riskItem = new SelectItem();  
		riskItem.setValueMap(valueMap);
		riskItem.setRequired(true);
		riskItem.setTitle("Risk factor");
		
		//Fetch iniziale
        showUserProfile();
		
		//Save button
		StandardButton saveButton=new StandardButton("Save","RISKPROFILE001");
		saveButton.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {

				
				if(riskItem.getValue()!=null){
						risk = (String) riskItem.getValue();
					}

					
					tctcompanyDS.fetchData(null, new DSCallback() {
						
						@Override
						public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
							Record[] rec = dsResponse.getData();
							rec[0].setAttribute("RISKPROF", risk);
							tctcompanyDS.updateData(rec[0], new DSCallback() {
								
								@Override
								public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
									w.destroy();
									SC.say("Risk profile correctly updated");
									
																		
									tctcompanyDS.fetchData(null , new DSCallback() {
										
										@Override
										public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
											Record[] rec = dsResponse.getData();
											if(rec[0].getAttributeAsString("RISKPROF").equalsIgnoreCase("hr"))
												manageRiskLink.setLinkTitle("<font color=\"005596\">High risk selected</font>");
											else if(rec[0].getAttributeAsString("RISKPROF").equalsIgnoreCase("mr"))
												manageRiskLink.setLinkTitle("<font color=\"005596\">Avarage risk selected</font>");
											else if(rec[0].getAttributeAsString("RISKPROF").equalsIgnoreCase("lr"))
												manageRiskLink.setLinkTitle("<font color=\"005596\">Low risk selected</font>");
										}
									});
									
								}
							});
							
						}
					});
			}});
		
		//Cancel Button
		StandardButton cancelbButton = new StandardButton("Cancel");
		cancelbButton.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
				w.destroy();
			}});

		StandardControlBar bottomControlBar = new StandardControlBar();
		LayoutSpacer ls = new LayoutSpacer();
		ls.setHeight("20%");
		bottomControlBar.setHeight("30%");
		bottomControlBar.setAlign(Alignment.CENTER);
		bottomControlBar.addMember(saveButton);
		bottomControlBar.addMember(cancelbButton);

		//Close click handler
		this.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {
				w.destroy();
			}
		});

		riskform.setFields(riskItem);
		
		this.addItem(ls);
		this.addItem(riskform);
		//this.addItem(ls);
		this.addItem(bottomControlBar);

		this.draw();

	}

	public void showUserProfile(){
//		Criteria crit = new Criteria();
//		crit.setAttribute("CMPNID", Privileges.getCompanyID());
		tctcompanyDS.fetchData(null, new DSCallback() {
			
			@Override
			public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
				
				final Record[] result =dsResponse.getData();
				
				riskItem.setValue(result[0].getAttributeAsString("RISKPROF"));
			}
		});
				
}
	
	
	public static RiskNotificationWindow windowCreator(TabSet mainTabSet, LinkItem manageRiskLink) {

		RiskNotificationWindow mw = (RiskNotificationWindow) Canvas.getById("RiskNotificationWindow");
		if (mw != null) {
			mw.setVisible(true);
			mw.restore();
			mw.bringToFront();
			return mw;
		} else {
			return new RiskNotificationWindow(mainTabSet,manageRiskLink);

		}


	}
}
