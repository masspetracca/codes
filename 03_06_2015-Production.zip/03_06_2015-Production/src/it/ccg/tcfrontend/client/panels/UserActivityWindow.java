package it.ccg.tcfrontend.client.panels;

import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.StandardListGrid;
import it.ccg.tcfrontend.client.menu.TextifyMenuItem;
import it.ccg.tcfrontend.client.menu.ViewDetailsMenuItem;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.Criterion;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.types.OperatorId;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.menu.Menu;

public class UserActivityWindow extends Window{

	String winId=this.getID();
	protected VLayout workingArea = new VLayout();
	
	//Grid
	private StandardListGrid usrActListGrid;
	
	public UserActivityWindow(int comboSelection){

		super();
		this.setID("UserActivityWindow");
		this.setTitle("User Activity Log - Run: " + comboSelection);
		this.setWidth(800);
		this.setHeight(500);
		this.setCanDragReposition(true);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);
		this.setMembersMargin(3);
		this.centerInPage();

		usrActListGrid = new StandardListGrid("UserActAudit");
		//DataSource utilizzato per la tabella della lista dei clienti
		DataSource tctUserActDS = SecureDS.get("tctusract");		
		
		usrActListGrid.setDataSource(tctUserActDS);
		usrActListGrid.setWidth100();
		usrActListGrid.setHeight100();
		usrActListGrid.setShowFilterEditor(true);
		usrActListGrid.setFilterOnKeypress(false);
		usrActListGrid.setAutoFetchData(true);  
		usrActListGrid.setSortField("AUDIT_REVISION");  
		usrActListGrid.setSortDirection(SortDirection.DESCENDING);  
		usrActListGrid.setCanEdit(false);
		usrActListGrid.setMargin(5);
//		usrActListGrid.setFetchOperation("audit_fetchRunId");
		

		AdvancedCriteria crit = new AdvancedCriteria(OperatorId.OR, new Criterion[]{
		          new Criterion("RUNID", OperatorId.EQUALS, -1),
		          new Criterion("RUNID", OperatorId.EQUALS, comboSelection)
		      });
		
		

		usrActListGrid.filterData(crit);
		
		workingArea.addMember(usrActListGrid);
		this.addItem(workingArea);

		usrActListGrid.setContextMenu(createContextMenuAuditUsrAct());
	
		this.draw();

		final Window w = this;
		this.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {

				w.destroy();
			}
		});

	}

	public static UserActivityWindow windowCreator(int comboSelection) {

		UserActivityWindow mw = (UserActivityWindow) Canvas.getById("UserActivityWindow");
		if (mw != null) {
			mw.setVisible(true);
			mw.restore();
			mw.bringToFront();
			return mw;
		} else {
			return new UserActivityWindow(comboSelection);

		}

	}

	private Menu createContextMenuAuditUsrAct() {
		Menu menu = new Menu();
		menu.setWidth(140);

		String name ="";
		ListGridRecord lgr = usrActListGrid.getSelectedRecord();
		if(lgr!=null)
			name = lgr.getAttributeAsString("RUNID");

		//View Details
		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);

		//Textify Selection
		TextifyMenuItem textItem = new TextifyMenuItem();

		menu.setItems(viewDetItem,textItem);

		return menu;

	}

	


}