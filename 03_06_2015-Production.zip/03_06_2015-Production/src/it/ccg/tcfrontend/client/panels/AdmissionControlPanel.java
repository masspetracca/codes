package it.ccg.tcfrontend.client.panels;

import java.sql.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import it.ccg.tcfrontend.client.ExportWindow;
import it.ccg.tcfrontend.client.HelpWindow;
import it.ccg.tcfrontend.client.PanelFactory;
import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.SecureDoubleClick;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardControlBar;
import it.ccg.tcfrontend.client.controls.StandardListGrid;
import it.ccg.tcfrontend.client.controls.StandardRefreshButton;
import it.ccg.tcfrontend.client.interf.Refreshable;
import it.ccg.tcfrontend.client.menu.TextifyMenuItem;
import it.ccg.tcfrontend.client.menu.ViewDetailsMenuItem;
import it.ccg.tcfrontend.client.security.Privileges;
import it.ccg.tcfrontend.client.utils.ClientMessages;

import com.ibm.xylem.IdentityHashMap.MapEntry;
import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.data.RecordList;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.BackgroundRepeat;
import com.smartgwt.client.types.Cursor;
import com.smartgwt.client.types.PromptStyle;
import com.smartgwt.client.types.RPCTransport;
import com.smartgwt.client.types.TitleOrientation;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.DoubleClickEvent;
import com.smartgwt.client.widgets.events.DoubleClickHandler;
import com.smartgwt.client.widgets.events.MouseOutEvent;
import com.smartgwt.client.widgets.events.MouseOutHandler;
import com.smartgwt.client.widgets.events.MouseOverEvent;
import com.smartgwt.client.widgets.events.MouseOverHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.FormItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.tab.TabSet;

public class AdmissionControlPanel extends VLayout implements Refreshable{

	final protected  TabSet mainTabSet;
	protected StandardControlBar topControlBar = new StandardControlBar();
	//protected HLayout topTablesArea = new HLayout();
	protected HLayout searchArea = new HLayout();
	protected VLayout workingArea = new VLayout();
	protected StandardControlBar bottomControlBar = new StandardControlBar();
	private static final String DESCRIPTION = "Adimssion control";
	
	final DataSource tctcorrlstDS = SecureDS.get("tctcorrlst");

	private int instrumentID;
	private String instrumentName;

	final StandardButton searchItem = new StandardButton("Search");
	final protected StandardButton exportButton = new StandardButton("Export");
	final protected StandardButton printButton = new StandardButton("Print");
	final protected StandardButton genReportButton = new StandardButton("Generate Report");

	private StandardListGrid corrispListGrid;
	private String toSearch;
	private String toSearch1;
	
	public AdmissionControlPanel(final TabSet mainTabSet, String panelID){
		super();

		this.mainTabSet=mainTabSet;

		//LABEL ADMISSION CONTROL
		// Definizione label
		final Label admissionLabel= new Label();

		admissionLabel.setHeight(10);
		admissionLabel.setWidth100();
		admissionLabel.setPadding(4);
		admissionLabel.setAlign(Alignment.LEFT);
		admissionLabel.setValign(VerticalAlignment.CENTER);
		admissionLabel.setWrap(false);
		admissionLabel.setBackgroundImage("newskins/header.png");
		admissionLabel.setBackgroundRepeat(BackgroundRepeat.REPEAT_X);
		admissionLabel.setContents("Insert the client name and alias");

		this.workingArea.addMember(admissionLabel);

		//REFRESH LABEL AND BUTTON
		final Label refresh = new Label();  
		refresh.setHeight(30);  
		refresh.setPadding(10);  
		refresh.setAlign(Alignment.CENTER);  
		refresh.setValign(VerticalAlignment.CENTER);  
		refresh.setWrap(false);  
		refresh.setIcon("icons/24/refresh.png");  
		refresh.setCanHover(true);
		refresh.setShowHover(false);

		refresh.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				refresh.setOpacity(50);
				refresh.setCursor(Cursor.POINTER);
			}
		});


		refresh.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				refresh.setOpacity(100);
				refresh.setCursor(Cursor.DEFAULT);
			}
		});

		refresh.setContents("<i>Refresh</i>");  

		refresh.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				corrispListGrid.invalidateCache();
			}
		});

		// Refresh Button
		/*StandardRefreshButton refreshbutton = new StandardRefreshButton(this);
		refreshbutton.setTooltip(ClientMessages.refresh());
		 */

		LayoutSpacer lstop = new LayoutSpacer();
		lstop.setWidth("40%");

		//HELP LABEL AND BUTTON
		final Label helpLabel = new Label();  
		helpLabel.setHeight(30);  
		helpLabel.setPadding(10);  
		helpLabel.setAlign(Alignment.CENTER);  
		helpLabel.setValign(VerticalAlignment.CENTER);  
		helpLabel.setWrap(false);  
		helpLabel.setIcon("icons/24/help24.png");  
		helpLabel.setCanHover(true);
		helpLabel.setShowHover(false);

		helpLabel.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				helpLabel.setOpacity(50);
				helpLabel.setCursor(Cursor.POINTER);
			}
		});

		helpLabel.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				helpLabel.setOpacity(100);
				helpLabel.setCursor(Cursor.DEFAULT);
			}
		});

		helpLabel.setContents("<i>Help</i>");  

		helpLabel.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				HelpWindow.windowCreator2(mainTabSet, "");

			}
		});



		final DynamicForm form = new DynamicForm(); 
		form.setTitleOrientation(TitleOrientation.TOP);

		final TextItem firstName = new TextItem("firstName", "Client name");
		form.setNumCols(1);

		form.setFields(firstName);


		/*addButton.setShowRollOver(true);
		addButton.setIcon("add.gif");
		addButton.setTooltip("Add a new alias as input for the research");*/


		//ADD LABEL AND BUTTON
		final Label addLabel = new Label();  
		addLabel.setHeight(50);
		addLabel.setValign(VerticalAlignment.BOTTOM);
		addLabel.setWidth(20);
		addLabel.setAlign(Alignment.CENTER);  
		addLabel.setValign(VerticalAlignment.CENTER);  
		addLabel.setWrap(false);  
		addLabel.setIcon("add.png");  
		addLabel.setCanHover(true);
		addLabel.setShowHover(false);

		addLabel.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				addLabel.setOpacity(50);
				addLabel.setCursor(Cursor.POINTER);
			}
		});

		addLabel.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				addLabel.setOpacity(100);
				addLabel.setCursor(Cursor.DEFAULT);
			}
		});


		addLabel.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {

				FormItem[] formItemArr=form.getFields();
				//limitazione a 3 campi
				if(formItemArr.length==3){
					SC.warn("No more than 3 name/alias fields are allowed");
					return;
				}

				final TextItem nName = new TextItem(formItemArr.length+"", "Alias"+formItemArr.length);

				FormItem[] newFIArr= new FormItem[formItemArr.length+1];
				form.setNumCols(newFIArr.length);

				int i=0;
				for(FormItem fi:formItemArr){
					fi.setColSpan(1);
					newFIArr[i]=fi;
					i++;
				}
				nName.setColSpan(1);
				newFIArr[i]=nName;

				form.setFields(newFIArr);
			}
		});




		/*removeButton.setShowRollOver(true);
		removeButton.setTooltip("Remove last alias inserted");
		removeButton.setIcon("delete.gif");*/

		//REMOVE LABEL AND BUTTON
		final Label removeLabel = new Label();  
		removeLabel.setHeight(50);  
		removeLabel.setValign(VerticalAlignment.BOTTOM);
		removeLabel.setWidth(25);  
		removeLabel.setAlign(Alignment.CENTER);  
		removeLabel.setValign(VerticalAlignment.CENTER);  
		removeLabel.setWrap(false);  
		removeLabel.setIcon("minus.png");  
		removeLabel.setCanHover(true);
		removeLabel.setShowHover(false);

		removeLabel.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				removeLabel.setOpacity(50);
				removeLabel.setCursor(Cursor.POINTER);
			}
		});

		removeLabel.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				removeLabel.setOpacity(100);
				removeLabel.setCursor(Cursor.DEFAULT);
			}
		});

		removeLabel.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				FormItem[] formItemArr=form.getFields();
				//limitazione a 3 campi
				if(formItemArr.length==1){
					SC.warn("At least 1 name/alias field has to be shown.");
					return;
				}
				formItemArr[formItemArr.length-1].clearValue();
				FormItem[] newFIArr= new FormItem[formItemArr.length-1];
				form.setNumCols(newFIArr.length);

				int i=0;
				for(FormItem fi:formItemArr){
					if(i==formItemArr.length-1) break;
					fi.setColSpan(1);
					newFIArr[i]=fi;
					i++;
				}

				form.setFields(newFIArr);
			}
		});

		this.topControlBar.addMember(form);
		topControlBar.addMember(addLabel);
		topControlBar.addMember(removeLabel);

		searchItem.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				// Se il sistema � nello stato di working viene lanciato un mess di notifica
				if (Privileges.isWorking()) {
					SC.say("The system is currently busy");
					return;
				}

				toSearch="";
				
				Map<String,String> rec = new HashMap<String, String>(form.getValues());

				
				if(rec.get("firstName")==null){
					SC.warn("Please insert a Client Name as searching criteria before performing this action.");
					genReportButton.disable();
					return;
				}else{
					toSearch += rec.get("firstName") + ",";
					if(rec.get("1")!=null && rec.get("2")!=null){
					toSearch += rec.get("1") + "," +rec.get("2");
					}else if(rec.get("1")!=null && rec.get("2")==null){
						toSearch += rec.get("1");
					}else if(rec.get("1")==null && rec.get("2")!=null){
						SC.warn("Please insert Alias1 as searching criteria before Alias2.");
						genReportButton.disable();
						return;
					}
				}
				
				//SC.say(toSearch);

				genReportButton.enable();
				Map<String,String> param = new HashMap<String, String>();
				param.put("params", toSearch);
				param.put("company", Privileges.getCompanyID()+"");

				RPCRequest rpcRequest = new RPCRequest();
				rpcRequest.setShowPrompt(true);
				rpcRequest.setPromptStyle(PromptStyle.CURSOR);
				rpcRequest.setParams(param);
				rpcRequest.setHttpMethod("POST");
				rpcRequest.setActionURL("ccgportal/MatchClient");
				RPCManager.sendRequest(rpcRequest, new RPCCallback() {

					@Override
					public void execute(RPCResponse response, Object rawData, RPCRequest request) {
						// Gestione della risposta
						Map<String, String> responseMap;
						// Gestione della mappa della risposta
						responseMap = response.getAttributeAsMap("data");
						// Sono stati trovati dei match
						if (responseMap.get("RESULT").equalsIgnoreCase("0")) {
//							AdvancedCriteria crit1 = new AdvancedCriteria();
//							crit1.addCriteria("CMPNID", Privileges.getCompanyID());

							corrispListGrid.fetchData(/*crit1*/null, new DSCallback() {
								
								@Override
								public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
									if(dsResponse.getData().length==0)
										corrispListGrid.setEmptyMessage("No match found.");
//									corrispListGrid.invalidateCache();
								}
							});
							corrispListGrid.invalidateCache();

						}
					}
				});
			}
		});


		topControlBar.addMember(lstop);
		topControlBar.addMember(refresh);
		topControlBar.addMember(helpLabel);

		this.workingArea.addMember(topControlBar);
		searchArea.setHeight("3%");
		searchArea.addMember(searchItem);
		this.workingArea.addMember(searchArea);

		//Corrisp list grid
		corrispListGrid=new StandardListGrid(panelID);
		corrispListGrid.setDataSource(tctcorrlstDS);

		corrispListGrid.setWidth100();
		corrispListGrid.setHeight100();
		corrispListGrid.setFetchOperation("tctcorrlst_fetch_cmpnid");
		corrispListGrid.setShowFilterEditor(true);
		corrispListGrid.setFilterOnKeypress(false);
		corrispListGrid.setCanEdit(false);
		corrispListGrid.setAutoSaveEdits(true);
		corrispListGrid.setAutoFetchData(false);
		

		//if(corrispListGrid.isFrstTimeDraw())
			corrispListGrid.setEmptyMessage("Please enter the client name and press the search button.");
		//else
			//corrispListGrid.setEmptyMessage("No items to show.");
		
		corrispListGrid.setContextMenu(createContextMenu());

		// Double click handler sulla corrispListGrid: � possibile editarla solo se 
		//si hanno i privilegi necessari
		corrispListGrid.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}
				try {
						SecureDoubleClick.secureDoubleClickRecord(event, corrispListGrid, "ADMCONTROLTAB001");
						
				} catch (Exception e) {
				}
			}
		});	
		
		
		LayoutSpacer ls = new LayoutSpacer();
		ls.setHeight("1%");
		this.workingArea.addMember(ls);
		this.workingArea.addMember(corrispListGrid);

		// Export button
		exportButton.setTooltip(ClientMessages.export());
		this.exportButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
				RecordList reclistforexport = new RecordList();
				reclistforexport = corrispListGrid.getRecordList();
				if (reclistforexport.getLength() != 0)
					ExportWindow.windowCreator(corrispListGrid,"tctcorrlst_fetch_cmpnid");
				else
					SC.say("No record to export");
			}
		});

		//Print button
		printButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				VLayout[] v = new VLayout[] { corrispListGrid };

				Canvas.showPrintPreview(v, null, DESCRIPTION, null);
			}
		});

		genReportButton.disable();
		
		//Generate report button
		genReportButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {

				// Se il sistema � nello stato di working viene lanciato un mess di notifica
				if (Privileges.isWorking()) {
					SC.say("The system is currently busy");
					return;
				}
				
				toSearch1="";
				
				Map<String,String> rec = new HashMap<String, String>(form.getValues());

				if(rec.get("firstName")==null){
					SC.warn("Please perform the search action before performing this one.");
					return;
				}else{
					toSearch1 += rec.get("firstName") + ",";
					if(rec.get("1")!=null && rec.get("2")!=null){
					toSearch1 += rec.get("1") + "," +rec.get("2");
					}else if(rec.get("1")!=null && rec.get("2")==null){
						toSearch1 += rec.get("1");
					}else if(rec.get("1")==null && rec.get("2")!=null){
						SC.warn("Please perform the search action before performing this one.");
						return;
					}
				}
				
				if(!toSearch.equalsIgnoreCase(toSearch1)){
					SC.warn("Please perform the search action before performing this one.");
					return;
				}
				
				// Recupero i record selezionati
				String paramStr = Privileges.getUsername().toString()+/*","+Privileges.getCompanyID()+*/",tctcorrlst,"+"0,0,"+toSearch1;

				RPCRequest rpcRequest = new RPCRequest();

				//						rpcRequest.setShowPrompt(true);
				//						rpcRequest.setPromptStyle(PromptStyle.CURSOR);
				//	    				
				rpcRequest.setHttpMethod("POST");
				// Sto dicendo al client di aprire un hidden frame dal quale generare la richiesta in POST
				rpcRequest.setTransport(RPCTransport.HIDDENFRAME);

				rpcRequest.setActionURL("ccgportal/PdfServlet?params=" + paramStr);
				RPCManager.sendRequest(rpcRequest);
			}
		});


		bottomControlBar.addMember(genReportButton);
		bottomControlBar.addMember(exportButton);
		bottomControlBar.addMember(printButton);

		this.workingArea.addMember(bottomControlBar);


		//Working area
		this.addMember(workingArea);
	}

	//Factory
	public static class Factory implements PanelFactory {
		private String id;
		public Canvas create(TabSet mainTabSet, String panelID) {
			AdmissionControlPanel panel = new AdmissionControlPanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

		public String getID() {
			return id;
		}

		public String getDescription() {
			return null;
		}

		public Canvas create(TabSet mainTabSet, String panelID, int instrid, String instrname) {
			AdmissionControlPanel panel = new AdmissionControlPanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

	}


	public void setInstrumentID(int instrumentID) {
		this.instrumentID = instrumentID;
	}

	public void setInstrumentName(String instrumentName) {
		this.instrumentName = instrumentName;
	}

	public int getInstrumentID() {
		return this.instrumentID;
	}

	public String getInstrumentName() {
		return instrumentName;
	}


	// Context menu MATCHING
	private Menu createContextMenu() {
		Menu menu = new Menu();
		menu.setWidth(140);

		String name = "";

		ListGridRecord lgr = corrispListGrid.getSelectedRecord();
		if(lgr!=null){
			name = lgr.getAttributeAsString("CLNTID");
		}
		//View Details
		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);

		//Textify Selection
		TextifyMenuItem textItem = new TextifyMenuItem();

		menu.setItems(viewDetItem,textItem);

		return menu;
	}



	@Override
	public void refresh() {
		//corrispListGrid.invalidateCache();
	}

}
