package it.ccg.tcfrontend.client.panels;

import it.ccg.tcfrontend.client.ExportWindow;
import it.ccg.tcfrontend.client.HelpWindow;
import it.ccg.tcfrontend.client.PanelFactory;
import it.ccg.tcfrontend.client.controls.SecureDS;

import it.ccg.tcfrontend.client.controls.SecureDoubleClick;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardControlBar;
import it.ccg.tcfrontend.client.controls.StandardListGrid;
import it.ccg.tcfrontend.client.controls.StandardMenuItem;
import it.ccg.tcfrontend.client.interf.Refreshable;
import it.ccg.tcfrontend.client.menu.TextifyMenuItem;
import it.ccg.tcfrontend.client.menu.ViewDetailsMenuItem;
import it.ccg.tcfrontend.client.security.Privileges;
import it.ccg.tcfrontend.client.utils.ClientMessages;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.Criterion;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.data.RecordList;
import com.smartgwt.client.data.SortSpecifier;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCQueueCallback;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.BackgroundRepeat;
import com.smartgwt.client.types.Cursor;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.OperatorId;
import com.smartgwt.client.types.SelectionStyle;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.MouseOutEvent;
import com.smartgwt.client.widgets.events.MouseOutHandler;
import com.smartgwt.client.widgets.events.MouseOverEvent;
import com.smartgwt.client.widgets.events.MouseOverHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.LinkItem;
import com.smartgwt.client.widgets.form.fields.MiniDateRangeItem;
import com.smartgwt.client.widgets.grid.CellFormatter;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.CellClickEvent;
import com.smartgwt.client.widgets.grid.events.CellClickHandler;
import com.smartgwt.client.widgets.grid.events.CellHoverEvent;
import com.smartgwt.client.widgets.grid.events.CellHoverHandler;
import com.smartgwt.client.widgets.grid.events.EditCompleteEvent;
import com.smartgwt.client.widgets.grid.events.EditCompleteHandler;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickHandler;
import com.smartgwt.client.widgets.grid.events.RowHoverEvent;
import com.smartgwt.client.widgets.grid.events.RowHoverHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.MenuItemIfFunction;
import com.smartgwt.client.widgets.menu.MenuItemSeparator;
import com.smartgwt.client.widgets.menu.events.MenuItemClickEvent;
import com.smartgwt.client.widgets.tab.TabSet;


public class DashboardPanel extends VLayout implements Refreshable{

	final protected  TabSet mainTabSet;
	protected StandardControlBar topControlBar = new StandardControlBar();
	protected HLayout approveBar = new HLayout();
	protected HLayout refreshHelpBar = new HLayout();
	protected StandardControlBar corrispListControlBar = new StandardControlBar();
	protected VLayout workingArea = new VLayout();
	protected HLayout bottomTablesArea= new HLayout();
	private static final String DESCRIPTION = "Dashboard";

	private LinkItem approveLink = new LinkItem();
	final DynamicForm approvDynForm = new DynamicForm();

	final protected String STDF="Std. filters";
	final protected String ADVF="Adv. Filters";

	final protected StandardButton submitButton = new StandardButton("Submit","DASHBOARD001");
	final protected StandardButton printButton = new StandardButton("Print");
	final protected StandardButton exportButton = new StandardButton("Export");


	private StandardListGrid corrispListGrid;
	private StandardListGrid activityLogListGrid;
	private StandardListGrid sourceListUpdateListGrid;
	private StandardListGrid matchingClientListGrid;


	private DataSource tctrunreg = SecureDS.get("tctrunreg");
	private String[] requestedRoles;
	private String[] requestedRolesApprover;
	final String[] role = Privileges.getUserRoles();


	final DataSource tctusract = SecureDS.get("tctusract");
	final DataSource tctcorrisp = SecureDS.get("tctcorrisp");
	final DataSource tctfalnegt = SecureDS.get("tctfalnegt");


	final DataSource tctuplf = SecureDS.get("tctuplf");	

	Record[] record;
	Record[] recArr;
	Record[] approveRec;

	String clientid ="";
	String aggrid = "";
	String downloadid = "";

	int rowNum = 0;

	String isApproveEnabled ="";

	ListGridField upload;
	ListGridField check;

	public DashboardPanel(final TabSet mainTabSet, final String panelID) {
		super();

		final DataSource  tctmatchingclient= SecureDS.get("tctmatchingclient");
		final DataSource tctsrcupdt = SecureDS.get("tctsrcupdt");

		MiniDateRangeItem dateTime = new MiniDateRangeItem();
		dateTime.setDateDisplayFormat(DateDisplayFormat.TOEUROPEANSHORTDATETIME);
		MiniDateRangeItem date = new MiniDateRangeItem();
		date.setDateDisplayFormat(DateDisplayFormat.TOEUROPEANSHORTDATE);

		this.mainTabSet=mainTabSet;

		isApproveEnabled = Privileges.getIsApproveEnabled();

		//Metodo che disegna la barra contenente il link per la finestra di approvazione e refresh
		//drawTopBar();

		approveLink.addClickHandler(new com.smartgwt.client.widgets.form.fields.events.ClickHandler() {

			@Override
			public void onClick(
					com.smartgwt.client.widgets.form.fields.events.ClickEvent event) {
				ApproveRunWindow.windowCreator(approveLink, isApproveEnabled);
			}
		});


		/*final Label refresh = new Label();  
		refresh.setHeight(30);  
		refresh.setPadding(10);  
		refresh.setAlign(Alignment.CENTER);  
		refresh.setValign(VerticalAlignment.CENTER);  
		refresh.setWrap(false);  
		refresh.setIcon("icons/24/refresh.png");  
		refresh.setCanHover(true);
		refresh.setShowHover(false);

		refresh.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				refresh.setOpacity(50);
				refresh.setCursor(Cursor.POINTER);
			}
		});


		refresh.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				refresh.setOpacity(100);
				refresh.setCursor(Cursor.DEFAULT);
			}
		});


		//refresh.setShowEdges(true);  
		refresh.setContents("<i>Refresh</i>");  

		refresh.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				activityLogListGrid.invalidateCache();
				corrispListGrid.invalidateCache();
				matchingClientListGrid.invalidateCache();
				sourceListUpdateListGrid.invalidateCache();
			}
		});


		LayoutSpacer lstop = new LayoutSpacer();
		topControlBar.addMember(lstop);

		topControlBar.addMember(refresh);

		final Label helpLabel = new Label();  
		helpLabel.setHeight(30);  
		helpLabel.setPadding(10);  
		helpLabel.setAlign(Alignment.CENTER);  
		helpLabel.setValign(VerticalAlignment.CENTER);  
		helpLabel.setWrap(false);  
		helpLabel.setIcon("icons/24/help24.png");  
		helpLabel.setCanHover(true);
		helpLabel.setShowHover(false);

		helpLabel.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				helpLabel.setOpacity(50);
				helpLabel.setCursor(Cursor.POINTER);
			}
		});


		helpLabel.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				helpLabel.setOpacity(100);
				helpLabel.setCursor(Cursor.DEFAULT);
			}
		});


		//refresh.setShowEdges(true);  
		helpLabel.setContents("<i>Help</i>");  

		helpLabel.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				HelpWindow.windowCreator2(mainTabSet, "");

			}
		});



		topControlBar.addMember(helpLabel);*/


		//corrispListGrid= new StandardListGrid(panelID);
		corrispListGrid= new StandardListGrid(panelID,"tctcorrisp");
		corrispListGrid.setDataSource(tctcorrisp);

		Map<String,String> valueMap = new HashMap<String, String>();
		valueMap.put("O", "Outstanding");
		valueMap.put("F", "False Positive");
		valueMap.put("P", "Positive match");
		tctcorrisp.getField("STATUS").setValueMap(valueMap);

		corrispListGrid.setWidth100();
		corrispListGrid.setHeight("50%");
		corrispListGrid.setShowFilterEditor(true);
		corrispListGrid.setFilterOnKeypress(false);
		corrispListGrid.setCanEdit(false);
		corrispListGrid.setAutoSaveEdits(false);
		corrispListGrid.setAutoFetchData(true);
		corrispListGrid.setCanHover(true);
		corrispListGrid.setShowHover(false);
		corrispListGrid.setContextMenu(createContextMenu());
		corrispListGrid.setFetchOperation("tctcorrisp_fetch_foroutstanding");

		//*******************************************************
		/*analyzed = new ListGridField("Analyzed");
		analyzed.setWidth(100);
		analyzed.setAlign(Alignment.LEFT);
		analyzed.setCanEdit(false);*/
		//*******************************************************

		//ListGridField[] fields = corrispListGrid.getAllFields();
		//System.out.println("***"+ fields.length);

		/*ListGridField[] newFields= corrispListGrid.getAllFields();
	    newFields[newFields.length+1] = analyzed;

		corrispListGrid.setFields(newFields);*/


		/*DSRequest req = new DSRequest();
		req.setOperationId("tctfalnegt_fetch_positivematch");

		tctfalnegt.fetchData(null, new DSCallback() {

			@Override
			public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
				//RECORD LIST TCTFALNEGT
				record = dsResponse.getData();
				System.out.println("******2--"+record.length);

			}
		}, req);*/

		//*******************************************************
		/*DSRequest req1 = new DSRequest();
		req1.setOperationId("tctcorrisp_fetch_foroutstanding");
		tctcorrisp.fetchData(null, new DSCallback() {

			@Override
			public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

				DSRequest req = new DSRequest();
				req.setOperationId("tctfalnegt_fetch_positivematch");

				tctfalnegt.fetchData(null, new DSCallback() {

					@Override
					public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
						//RECORD LIST TCTFALNEGT
						record = dsResponse.getData();
						System.out.println("******2--"+record.length);



				//RECORD LIST TCTCORRISP
				recArr = dsResponse.getData();
				System.out.println("******0--"+recArr.length);

				for(int i=0;i<recArr.length;i++){
					for(int k=0;k<record.length;k++){

						if(recArr[i].getAttributeAsString("CLNTID").equalsIgnoreCase(record[k].getAttributeAsString("CLNTID"))
								&& recArr[i].getAttributeAsString("DOWNLOADID").equalsIgnoreCase(record[k].getAttributeAsString("DOWNLOADID"))
								&& recArr[i].getAttributeAsString("CMPNID").equalsIgnoreCase(record[k].getAttributeAsString("CMPNID"))
								&& recArr[i].getAttributeAsString("AGGRID").equalsIgnoreCase(record[k].getAttributeAsString("AGGRID"))){

							System.out.println("OK!");

							clientid = recArr[i].getAttribute("CLNTID");
							aggrid = recArr[i].getAttribute("AGGRID");
							downloadid = recArr[i].getAttribute("DOWNLOADID");

							corrispListGrid.getField("Analyzed").setCellFormatter(new CellFormatter() {

								@Override
								public String format(Object value, ListGridRecord record, int rowNum, int colNum) {

									if(record.getAttribute("CLNTID").equalsIgnoreCase(clientid) && 
											record.getAttribute("AGGRID").equalsIgnoreCase(aggrid) &&
											record.getAttribute("DOWNLOADID").equalsIgnoreCase(downloadid)){
										return  Canvas.imgHTML("user.png",15,15);
									}
									else
										return null;
								}
							});		
						}
					}
				}
					}
				}, req);
			}


		},req1);*/
		//*******************************************************



		//*******************************************************
		/*corrispListGrid.setFields(new ListGridField("RUNID", "Run ID"),new ListGridField("CLNTID", "Client ID"), new ListGridField("CLNTNAME", "Client name"),
				new ListGridField("AGGRID", "Terr. ID"),new ListGridField("DOWNLOADID", "Download ID"),new ListGridField("ENTITYNAME", "Terrorist name"),
				new ListGridField("CORRINDEX", "Corr. index"),new ListGridField("STATUS", "Status"), analyzed,
				new ListGridField("UPDDATE", "Update Date"), new ListGridField("UPDUSER", "Update User"),new ListGridField("UPDTYPE", "Update type"));
		 */
		//*******************************************************



		/*Criteria crit1 = new Criteria();
		crit1.setAttribute("APPROVED", "F");
		crit1.setAttribute("MATCHFOUND", "T");
		crit1.setAttribute("SUBDATE", OperatorId.NOT_NULL);


		tctrunreg.fetchData(crit1, new DSCallback() {

			@Override
			public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
				approveRec = dsResponse.getData();
				System.out.println("***** - "+approveRec.length);
				int contApprove = 0;
				for(int i=0;i<role.length;i++){
					if(role[i].equalsIgnoreCase("approver")){
						contApprove++;
					}
				}

				//if(isApproveEnabled.compareToIgnoreCase("T")==0 && contApprove == 1 && approveRec.length>0){
				approveLink.setShowTitle(false);
				approveLink.setWidth(300);
				approveLink.setLinkTitle("<font color=\"#f21616\">There is a pending action: approve</font>");
				approveLink.hide();
				approvDynForm.setItems(approveLink);


				topControlBar.addMember(approvDynForm);

				if(isApproveEnabled.compareToIgnoreCase("T")==0 && contApprove == 1 && approveRec.length>0){
					approveLink.show();
				}				

				final Label refresh = new Label();  
				refresh.setHeight(30);  
				refresh.setPadding(10);  
				refresh.setAlign(Alignment.CENTER);  
				refresh.setValign(VerticalAlignment.CENTER);  
				refresh.setWrap(false);  
				refresh.setIcon("icons/24/refresh.png");  
				refresh.setCanHover(true);
				refresh.setShowHover(false);

				refresh.addMouseOverHandler(new MouseOverHandler() {

					@Override
					public void onMouseOver(MouseOverEvent event) {
						refresh.setOpacity(50);
						refresh.setCursor(Cursor.POINTER);
					}
				});


				refresh.addMouseOutHandler(new MouseOutHandler() {

					@Override
					public void onMouseOut(MouseOutEvent event) {
						refresh.setOpacity(100);
						refresh.setCursor(Cursor.DEFAULT);
					}
				});


				//refresh.setShowEdges(true);  
				refresh.setContents("<i>Refresh</i>");  

				refresh.addClickHandler(new ClickHandler() {

					@Override
					public void onClick(ClickEvent event) {
						activityLogListGrid.invalidateCache();
						corrispListGrid.invalidateCache();
						matchingClientListGrid.invalidateCache();
						sourceListUpdateListGrid.invalidateCache();
						drawTopBar();
					}
				});


				LayoutSpacer lstop = new LayoutSpacer();


				topControlBar.addMember(lstop);

				topControlBar.addMember(refresh);

				final Label helpLabel = new Label();  
				helpLabel.setHeight(30);  
				helpLabel.setPadding(10);  
				helpLabel.setAlign(Alignment.CENTER);  
				helpLabel.setValign(VerticalAlignment.CENTER);  
				helpLabel.setWrap(false);  
				helpLabel.setIcon("icons/24/help24.png");  
				helpLabel.setCanHover(true);
				helpLabel.setShowHover(false);

				helpLabel.addMouseOverHandler(new MouseOverHandler() {

					@Override
					public void onMouseOver(MouseOverEvent event) {
						helpLabel.setOpacity(50);
						helpLabel.setCursor(Cursor.POINTER);
					}
				});


				helpLabel.addMouseOutHandler(new MouseOutHandler() {

					@Override
					public void onMouseOut(MouseOutEvent event) {
						helpLabel.setOpacity(100);
						helpLabel.setCursor(Cursor.DEFAULT);
					}
				});


				//refresh.setShowEdges(true);  
				helpLabel.setContents("<i>Help</i>");  

				helpLabel.addClickHandler(new ClickHandler() {

					@Override
					public void onClick(ClickEvent event) {
						HelpWindow.windowCreator2(mainTabSet, "");

					}
				});



				topControlBar.addMember(helpLabel);
				//refreshHelpBar.addMembers(lstop, refresh, helpLabel);



			}

		});*/


		drawTopBarInit();
		this.addMember(topControlBar);


		// Double click handler sulla corrispListGrid: � possibile editarla solo se 
		//si hanno i privilegi necessari
		corrispListGrid.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}
				try {
					SecureDoubleClick.secureDoubleClickRecord(event, corrispListGrid, "DASHBOARDTAB001");
					//SC.say("OK doppio click! "+ Privileges.getEnabledCommands());
				} catch (Exception e) {
				}
			}
		});	

		corrispListGrid.addEditCompleteHandler(new EditCompleteHandler() {  


			@Override
			public void onEditComplete(EditCompleteEvent event) {

				activityLogListGrid.invalidateCache();
				corrispListGrid.invalidateCache();
				matchingClientListGrid.invalidateCache();
			}  
		}); 


		corrispListGrid.addRowHoverHandler(new RowHoverHandler() {

			@Override
			public void onRowHover(RowHoverEvent event) {
				Record record=event.getRecord(); 

				ListGridField field = corrispListGrid.getField("STATUS");  
				if(record.getAttributeAsString("STATUS").equalsIgnoreCase("O")){

					Map<String,String> map = new HashMap<String, String>();
					map.put("F","False Positive");
					map.put("P", "Positive Match");
					map.put("O", "Outstanding");
					field.setEditorValueMap(map);
				}


			}
		});


		// Definizione label
		Label corrispLabel= new Label();

		corrispLabel.setHeight(10);
		corrispLabel.setWidth100();
		corrispLabel.setPadding(4);
		corrispLabel.setAlign(Alignment.LEFT);
		corrispLabel.setValign(VerticalAlignment.CENTER);
		corrispLabel.setWrap(false);
		corrispLabel.setBorder(corrispListGrid.getBorder());
		corrispLabel.setBackgroundImage("newskins/header.png");
		corrispLabel.setBackgroundRepeat(BackgroundRepeat.REPEAT_X);
		corrispLabel.setContents("Outstanding matching entries");


		this.workingArea.addMember(corrispLabel);
		this.workingArea.addMember(corrispListGrid);


		//Toolbar controllo tabella corrispondenze

		// Export button
		exportButton.setTooltip(ClientMessages.export());
		this.exportButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
				RecordList reclistforexport = new RecordList();
				reclistforexport = corrispListGrid.getRecordList();
				if (reclistforexport.getLength() != 0)
					ExportWindow.windowCreator(corrispListGrid,"tctcorrisp_fetch_foroutstanding");
				else
					SC.say("No record to export");
			}
		});

		printButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				VLayout[] v = new VLayout[] { corrispListGrid };

				Canvas.showPrintPreview(v, null, DESCRIPTION, null);
			}
		});



		corrispListControlBar.addMember(submitButton);
		corrispListControlBar.addMember(exportButton);
		corrispListControlBar.addMember(printButton);
		this.workingArea.addMember(corrispListControlBar);

		submitButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {

			public void onClick(
					com.smartgwt.client.widgets.events.ClickEvent event) {

				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}

				else{


					Criteria crit = new Criteria();
					crit.setAttribute("STATUS", "O");

					tctcorrisp.fetchData(crit, new DSCallback() {

						@Override
						public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

							final Record[] recArr = dsResponse.getData();

							String confMessage="";

							if(recArr.length==0)
								SC.warn("No rows to submit.");
							else 
							{
								if(recArr.length==1){
									String rec = recArr[0].getAttributeAsString("RUNID");
									confMessage="Are you sure you want to submit the analyzed results related to the run id "+rec+" ?";
								}
								else if(recArr.length>=1){
									String rec = recArr[0].getAttributeAsString("RUNID");
									for(int i=1;i<recArr.length;i++){
										if(!recArr[i].getAttributeAsString("RUNID").equalsIgnoreCase(recArr[i-1].getAttributeAsString("RUNID")))
											rec += "," +recArr[i].getAttributeAsString("RUNID");
									}
									confMessage="Are you sure you want to submit the analyzed results related to the run ids "+rec+" ?";
								}

								SC.confirm(confMessage,
										new BooleanCallback() {public void execute(Boolean value) {

											if (value != null && value) {

												int totalrows=corrispListGrid.getTotalRows();
												final int[] editrows=corrispListGrid.getAllEditRows();
												String confMessage="";

												if(totalrows==0){
													SC.warn("No rows to submit.");
												}
												else if(totalrows!=editrows.length){
													confMessage="There are "+(totalrows-editrows.length)+" rows in Outstanding status. If you submit the form, such rows will be considered as False Positive. Do you want to proceed?";
													SC.confirm(confMessage,
															new BooleanCallback() {public void execute(Boolean value) {

																if (value != null && value) {

																	RPCManager.startQueue();

																	if(editrows.length!=0){
																		updateAuditTableWithClientEdit(editrows, recArr);
																	} else {
																		updateAuditTableWithoutClientEdit(recArr);
																	}
																	
																	if(!corrispListGrid.saveAllEdits()){

																		//covering ass manouver
																		corrispListGrid.setEditValue(0, "STATUS", "F");
																		corrispListGrid.saveAllEdits();
																	}


																	Record r = new Record();  
																	DSRequest req = new DSRequest();
																	req.setAttribute("operationId", "goodJDBCUpdate");  
																	tctrunreg.updateData(r,null, req);

																	Record r1 = new Record();  
																	DSRequest req1 = new DSRequest();
																	req1.setAttribute("operationId", "updateOutstandingCorrisp");  
																	tctcorrisp.updateData(r1, null, req1);  

																	AdvancedCriteria criteria = new AdvancedCriteria();
																	criteria.addCriteria("SUBDATE", OperatorId.IS_NULL);
																	criteria.addCriteria("MATCHFOUND","T");
																	
																	tctrunreg.fetchData(criteria, new DSCallback() {
																		
																		@Override
																		public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
																			// TODO Auto-generated method stub
																			Record[] rec = dsResponse.getData();
																			updateAuditTableSubmitRunReg(rec);
																		}
																	});
																	//*********************

																	/*for(int i=0;i<recArr.length;i++){
																	for(int k=0;k<record.length;k++){

																		if(recArr[i].getAttributeAsString("CLNTID").equalsIgnoreCase(record[k].getAttributeAsString("CLNTID"))
																				&& recArr[i].getAttributeAsString("DOWNLOADID").equalsIgnoreCase(record[k].getAttributeAsString("DOWNLOADID"))
																				&& recArr[i].getAttributeAsString("CMPNID").equalsIgnoreCase(record[k].getAttributeAsString("CMPNID"))
																				&& recArr[i].getAttributeAsString("AGGRID").equalsIgnoreCase(record[k].getAttributeAsString("AGGRID"))){


																			Record r2 = new Record();  
																			r2.setAttribute("CLNTID", recArr[i].getAttribute("CLNTID"));
																			r2.setAttribute("AGGRID", recArr[i].getAttribute("AGGRID"));
																			r2.setAttribute("DOWNLOADID", recArr[i].getAttribute("DOWNLOADID"));
																			r2.setAttribute("STATUS", "T");

																			tctfalnegt.updateData(r2);

																		}
																	}
																}*/
																	//*********************

																	RPCManager.sendQueue(new RPCQueueCallback() {

																		@Override
																		public void execute(RPCResponse... response) {

																			int contApprove = 0;
																			for(int i=0;i<role.length;i++){
																				if(role[i].equalsIgnoreCase("approver")){
																					contApprove++;
																				}
																			}

																			if(isApproveEnabled.compareToIgnoreCase("T")==0 && contApprove == 1){
																				approveLink.show();
																			}
																			else{					
																				approveLink.hide();
																			}

																		}
																	});
																}
															}
													});
												}
												else{

													RPCManager.startQueue();

													if(!corrispListGrid.saveAllEdits()){


														//covering ass manouver
														corrispListGrid.setEditValue(0, "STATUS", "F");
														corrispListGrid.saveAllEdits();
													}

													Record r = new Record();  
													//										r.setAttribute("compid", Privileges.getCompanyID()); 
													DSRequest req = new DSRequest();  
													req.setAttribute("operationId", "goodJDBCUpdate");  
													tctrunreg.updateData(r, null, req);

													Record r1 = new Record();  
													//										r1.setAttribute("compid", Privileges.getCompanyID()); 
													DSRequest req1 = new DSRequest();  
													req1.setAttribute("operationId", "updateOutstandingCorrisp");  
													tctcorrisp.updateData(r1, null, req1);  

													//*********************

													/*for(int i=0;i<recArr.length;i++){
													for(int k=0;k<record.length;k++){

														if(recArr[i].getAttributeAsString("CLNTID").equalsIgnoreCase(record[k].getAttributeAsString("CLNTID"))
																&& recArr[i].getAttributeAsString("DOWNLOADID").equalsIgnoreCase(record[k].getAttributeAsString("DOWNLOADID"))
																&& recArr[i].getAttributeAsString("CMPNID").equalsIgnoreCase(record[k].getAttributeAsString("CMPNID"))
																&& recArr[i].getAttributeAsString("AGGRID").equalsIgnoreCase(record[k].getAttributeAsString("AGGRID"))){


															Record r2 = new Record();  
															r2.setAttribute("CLNTID", recArr[i].getAttribute("CLNTID"));
															r2.setAttribute("AGGRID", recArr[i].getAttribute("AGGRID"));
															r2.setAttribute("DOWNLOADID", recArr[i].getAttribute("DOWNLOADID"));
															r2.setAttribute("STATUS", "T");

															tctfalnegt.updateData(r2);

														}
													}
												}*/
													//*********************

													RPCManager.sendQueue(new RPCQueueCallback() {

														@Override
														public void execute(RPCResponse... response) {

															int contApprove = 0;
															for(int i=0;i<role.length;i++){
																if(role[i].equalsIgnoreCase("approver")){
																	contApprove++;
																}
															}

															if(isApproveEnabled.compareToIgnoreCase("T")==0 && contApprove == 1){
																approveLink.show();
															}
															else{					
																approveLink.hide();
															}

														}
													});
												}

												//Metodo che disegna la barra contenente il link per la finestra di approvazione e refresh

												//drawTopBar();
												/*int contApprove = 0;
											for(int i=0;i<role.length;i++){
												if(role[i].equalsIgnoreCase("approver")){
													contApprove++;
												}
											}

											if(isApproveEnabled.compareToIgnoreCase("T")==0 && contApprove == 1){
												approveLink.show();
											}
											else{					
												approveLink.hide();
											}*/
											}

										}
								});
							}

						}
					});

				}

			}

		});


		LayoutSpacer ls0=new LayoutSpacer();
		ls0.setHeight(10);
		this.workingArea.addMember(ls0);

		bottomTablesArea.setWidth("99%");
		bottomTablesArea.setHeight("*");

		//activityLogListGrid=new StandardListGrid(panelID);
		activityLogListGrid=new StandardListGrid(panelID,"tctrunreg");
		/*ImgButton recordCanvas = new ImgButton();  
                    recordCanvas.setHeight(22);  
                    recordCanvas.setWidth100();  
                    recordCanvas.setAlign(Alignment.CENTER);  
                    ImgButton uploadImg = new ImgButton();  
                    uploadImg.setShowDown(false);  
                    uploadImg.setShowRollOver(false);  
                    uploadImg.setLayoutAlign(Alignment.CENTER);  
                    uploadImg.setSrc("add.png");  
                    uploadImg.setPrompt("Upload file");  
                    uploadImg.setHeight(16);  
                    uploadImg.setWidth(16);  
                    uploadImg.addClickHandler(new ClickHandler() {  
                        public void onClick(ClickEvent event) {  
                            SC.say("Upload file Icon Clicked for runid : " + record.getAttribute("RUNID"));  
                        }  
                    });  

                    recordCanvas.addMember(uploadImg);  
                    return recordCanvas;

                }else {  
                    return null;  
                } 

            }  
        }; */ 


		activityLogListGrid.setDataSource(tctrunreg);
		
		activityLogListGrid.setAutoFetchData(true);

		/*ListGridField rundate=activityLogListGrid.getField("RUNDATE");

		rundate.setFilterEditorType(dateTime);
		 */
		activityLogListGrid.setWidth100();
		activityLogListGrid.setHeight("*");
		Criteria crit = new Criteria();
		crit.addCriteria("MATCHFOUND", "T");
		activityLogListGrid.setInitialCriteria(crit);
		activityLogListGrid.setShowFilterEditor(true);
		activityLogListGrid.setFilterOnKeypress(false);
		activityLogListGrid.setCanEdit(false);
		activityLogListGrid.setAutoSaveEdits(true);
		//activityLogListGrid.setSelectionType(SelectionStyle.MULTIPLE);
		activityLogListGrid.setSelectionType(SelectionStyle.SINGLE);
		activityLogListGrid.setContextMenu(createContextMenuLog());
		SortSpecifier sortspec = new SortSpecifier("RUNID", SortDirection.DESCENDING);
		activityLogListGrid.addSort(sortspec);


		upload = new ListGridField("UPLOAD","Attached");
		upload.setWidth(60);
		upload.setAlign(Alignment.CENTER);
		upload.setCanEdit(false);

		check = new ListGridField("CHECK", "Run status");
		check.setWidth(30);
		check.setAlign(Alignment.CENTER);
		check.setCanEdit(false);
		check.setShowTitle(false);


		//Controllo se � abilitato il processo di approvazione per rendere visibili o meno i relativi campi
		if (isApproveEnabled.compareToIgnoreCase("T")==0){

			activityLogListGrid.setFields(check, new ListGridField("RUNID", "Run ID"),new ListGridField("RUNDATE", "Run date"),
					new ListGridField("MATCHFOUND", "Match found"),new ListGridField("SUBDATE", "Submission date"),  
					new ListGridField("UPDDATE", "Update Date"),  
					new ListGridField("APPROVER", "Approved by"), new ListGridField("SUBMITTER", "Submitted by"),
					new ListGridField("UPDTYPE", "Update type"),new ListGridField("UPDUSER", "Update User"),
					new ListGridField("APPROVED", "Approved"), new ListGridField("NOTE", "Note"),
					new ListGridField("REPORT", "Report"),
					upload);

		} else {

			activityLogListGrid.setFields(check,  new ListGridField("RUNID", "Run ID"),new ListGridField("RUNDATE", "Run date"),
					new ListGridField("MATCHFOUND", "Match found"),new ListGridField("SUBDATE", "Submission date"),  
					new ListGridField("UPDDATE", "Update Date"),  new ListGridField("SUBMITTER", "Submitted by"),
					new ListGridField("UPDTYPE", "Update type"),new ListGridField("UPDUSER", "Update User"), new ListGridField("NOTE", "Note"),
					new ListGridField("REPORT", "Report"),
					upload);

		}


		//****************************************************************************************************

		tctuplf.fetchData(null, new DSCallback() {

			@Override
			public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
				// TODO Auto-generated method stub
				final Record[] recs = dsResponse.getData();


				activityLogListGrid.getField("UPLOAD").setCellFormatter(new CellFormatter() {

					@Override
					public String format(Object value, ListGridRecord record, int rowNum,
							int colNum) {

						int elem =0;
						for(int i=0;i<recs.length;i++){
							if(recs[i].getAttribute("RUNID").equalsIgnoreCase(record.getAttribute("RUNID"))){
								elem++;
							}
						}

						return  elem + Canvas.imgHTML("up2.png",16,16);
					}
				});



			}
		});
		activityLogListGrid.invalidateCache();

		if (isApproveEnabled.compareToIgnoreCase("T")==0){


			activityLogListGrid.getField("CHECK").setCellFormatter(new CellFormatter() {

				@Override
				public String format(Object value, ListGridRecord record, int rowNum,
						int colNum) {

					if(!record.getAttribute("APPROVER").toString().equalsIgnoreCase("") && !record.getAttribute("SUBMITTER").toString().equalsIgnoreCase("")){
						return Canvas.imgHTML("doubleCheck.png",16,16);							
					}
					else if(record.getAttribute("APPROVER").toString().equalsIgnoreCase("") && !record.getAttribute("SUBMITTER").toString().equalsIgnoreCase("")){
						return Canvas.imgHTML("check.png",16,16);
					}
					else 
						return "";

				}
			});


		}else{
			activityLogListGrid.getField("CHECK").setCellFormatter(new CellFormatter() {

				@Override
				public String format(Object value, ListGridRecord record, int rowNum,
						int colNum) {

					if(!record.getAttribute("SUBMITTER").toString().equalsIgnoreCase("")){

						return Canvas.imgHTML("check.png",16,16);
					}
					else 
						return "";
				}
			});

		}


		//NO
		/*	activityLogListGrid.getField("UPLOAD").addRecordClickHandler(new RecordClickHandler() {

			@Override
			public void onRecordClick(RecordClickEvent event) {
				ListGridRecord lgr = new ListGridRecord();
				lgr = activityLogListGrid.getSelectedRecord();
				int runId = lgr.getAttributeAsInt("RUNID");
				//SC.say("Upload file Icon Clicked for runid : " + );
				AttachFileWindow.windowCreator(runId);
			}
		});*/
		//NO
		//********************************************************************************************
		activityLogListGrid.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}
				try {
					SecureDoubleClick.secureDoubleClickRecord(event, activityLogListGrid, "DASHBOARDTAB002");
					//SC.say("OK doppio click! " + Privileges.isControlON4User("DASHBOARDTAB002"));
				} catch (Exception e) {
				}
			}
		});	

		//Set up the handler to expand and what not
		activityLogListGrid.addCellClickHandler(new CellClickHandler() {

			@Override
			public void onCellClick(CellClickEvent event) {

				ListGridRecord record=event.getRecord(); 
				int colNum = event.getColNum();
				int rowNum = event.getRowNum();
				String fieldName = activityLogListGrid.getFieldName(colNum);  
				String val = activityLogListGrid.getRecord(rowNum).getAttributeAsString("REPORT");

				if(fieldName.equalsIgnoreCase("REPORT") && val.equalsIgnoreCase("T")) {

					int runId = record.getAttributeAsInt("RUNID");
//					int comanyID = record.getAttributeAsInt("CMPNID");

					String paramStr = runId+/*","+comanyID+*/",tctcorrisp";

					RPCRequest rpcRequest = new RPCRequest();

					rpcRequest.setHttpMethod("POST");
					rpcRequest.setDownloadResult(true);

					// Sto dicendo al client di aprire un hidden frame dal quale generare la richiesta in POST
					//rpcRequest.setTransport(RPCTransport.HIDDENFRAME);
					rpcRequest.setActionURL("ccgportal/PdfServlet?params=" + paramStr);
					//RPCManager.setShowPrompt(true);
					RPCManager.sendRequest(rpcRequest);	
					//RPCManager.setShowPrompt(false);

				}else if(fieldName.equalsIgnoreCase("UPLOAD")){
					int runId = record.getAttributeAsInt("RUNID");

					AttachFileWindow.windowCreator(runId, activityLogListGrid);
				}
			}
		});

		activityLogListGrid.setCanHover(true);
		activityLogListGrid.setShowHover(false);
		activityLogListGrid.addCellHoverHandler(new CellHoverHandler() {

			@Override
			public void onCellHover(CellHoverEvent event) {
				ListGridRecord record=event.getRecord(); 
				int colNum = event.getColNum();
				String fieldName = activityLogListGrid.getFieldName(colNum);  

				if(fieldName.equalsIgnoreCase("REPORT")&&(record.getAttributeAsString("REPORT").equalsIgnoreCase("T"))) {
					activityLogListGrid.getChildren()[3].setCursor(Cursor.POINTER);
				}else if(fieldName.equalsIgnoreCase("UPLOAD")) {
					activityLogListGrid.getChildren()[3].setCursor(Cursor.POINTER);
				}

				else{
					activityLogListGrid.getChildren()[3].setCursor(Cursor.DEFAULT);
				}
			}
		});

		VLayout activityLogLayout= new VLayout();
		activityLogLayout.setWidth100();
		activityLogLayout.setHeight100();


		// Definizione label
		Label activityLogLabel= new Label();

		activityLogLabel.setHeight(10);
		activityLogLabel.setWidth100();
		activityLogLabel.setPadding(4);
		activityLogLabel.setAlign(Alignment.LEFT);
		activityLogLabel.setValign(VerticalAlignment.CENTER);
		activityLogLabel.setWrap(false);
		activityLogLabel.setBorder(activityLogListGrid.getBorder());
		activityLogLabel.setBackgroundImage("newskins/header.png");
		activityLogLabel.setBackgroundRepeat(BackgroundRepeat.REPEAT_X);
		activityLogLabel.setContents("Activity log");


		activityLogLayout.addMember(activityLogLabel);
		activityLogLayout.addMember(activityLogListGrid);



		/*ListGridRecord[] lgrs = activityLogListGrid.getRecords();
		System.out.println("//// - "+lgrs.length);
		for(int i=0; i<lgrs.length;i++){

			attachedFiles(lgrs[i].getAttribute("RUNID"));
		}
		activityLogListGrid.invalidateCache();*/


		this.bottomTablesArea.addMember(activityLogLayout);

		LayoutSpacer ls1=new LayoutSpacer();
		ls1.setWidth("1%");

		this.bottomTablesArea.addMember(ls1);

		//sourceListUpdateListGrid=new StandardListGrid(panelID");
		sourceListUpdateListGrid=new StandardListGrid(panelID,"tctsrcupdt");
		sourceListUpdateListGrid.setDataSource(tctsrcupdt);

		tctsrcupdt.getField("SRCLIST").setAttribute("width", 100);
		tctsrcupdt.getField("LISTDATE").setAttribute("width", "100%");

		sourceListUpdateListGrid.setAutoFetchData(true);

		sourceListUpdateListGrid.setWidth100();
		sourceListUpdateListGrid.setHeight("*");
		sourceListUpdateListGrid.setShowFilterEditor(true);
		sourceListUpdateListGrid.setFilterOnKeypress(false);
		sourceListUpdateListGrid.setCanEdit(false);
		sourceListUpdateListGrid.setContextMenu(createContextMenuSource());
		SortSpecifier sortspecNew = new SortSpecifier("LISTDATE", SortDirection.DESCENDING);
		sourceListUpdateListGrid.addSort(sortspecNew);

		VLayout sourceListUpdateLayout= new VLayout();
		sourceListUpdateLayout.setWidth("230");
		sourceListUpdateLayout.setHeight100();


		// Definizione label
		Label sourceListUpdateLabel= new Label();

		sourceListUpdateLabel.setHeight(10);
		sourceListUpdateLabel.setWidth100();
		sourceListUpdateLabel.setPadding(4);
		sourceListUpdateLabel.setAlign(Alignment.LEFT);
		sourceListUpdateLabel.setValign(VerticalAlignment.CENTER);
		sourceListUpdateLabel.setWrap(false);
		sourceListUpdateLabel.setBorder(activityLogListGrid.getBorder());
		sourceListUpdateLabel.setBackgroundImage("newskins/header.png");
		sourceListUpdateLabel.setBackgroundRepeat(BackgroundRepeat.REPEAT_X);
		sourceListUpdateLabel.setContents("Source list update history");


		sourceListUpdateLayout.addMember(sourceListUpdateLabel);
		sourceListUpdateLayout.addMember(sourceListUpdateListGrid);


		this.bottomTablesArea.addMember(sourceListUpdateLayout);

		this.bottomTablesArea.addMember(ls1);



		matchingClientListGrid=new StandardListGrid(panelID, "matchingclients");
		matchingClientListGrid.setDataSource(tctmatchingclient);
		matchingClientListGrid.setWidth100();
		matchingClientListGrid.setHeight("*");
		matchingClientListGrid.setShowFilterEditor(true);
		matchingClientListGrid.setFilterOnKeypress(false);
		matchingClientListGrid.setCanEdit(false);
		matchingClientListGrid.setContextMenu(createContextMenuMatch());
		matchingClientListGrid.setAutoFetchData(true);

		matchingClientListGrid.setFetchOperation("tctcorrisp_fetch_forpositivematch");
		//matchingClientListGrid.setUpdateOperation("tctcorrisp_update_forpositivematch");

		VLayout matchingClientLayout= new VLayout();
		matchingClientLayout.setWidth("400");
		matchingClientLayout.setHeight100();


		// Definizione label
		Label matchingClientLabel= new Label();

		matchingClientLabel.setHeight(10);
		matchingClientLabel.setWidth100();
		matchingClientLabel.setPadding(4);
		matchingClientLabel.setAlign(Alignment.LEFT);
		matchingClientLabel.setValign(VerticalAlignment.CENTER);
		matchingClientLabel.setWrap(false);
		matchingClientLabel.setBorder(activityLogListGrid.getBorder());
		matchingClientLabel.setBackgroundImage("newskins/header.png");
		matchingClientLabel.setBackgroundRepeat(BackgroundRepeat.REPEAT_X);
		matchingClientLabel.setContents("Matching clients");




		matchingClientLayout.addMember(matchingClientLabel);
		matchingClientLayout.addMember(matchingClientListGrid);


		this.bottomTablesArea.addMember(matchingClientLayout);






		this.workingArea.addMember(bottomTablesArea);



		//Working area
		this.addMember(workingArea);






	}


	//Factory
	public static class Factory implements PanelFactory {
		private String id;
		public Canvas create(TabSet mainTabSet, String panelID) {
			DashboardPanel panel = new DashboardPanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

		public String getID() {
			return id;
		}

		public String getDescription() {
			return null;
		}

		public Canvas create(TabSet mainTabSet, String panelID, int instrid, String instrname) {
			DashboardPanel panel = new DashboardPanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

	}


	@Override
	public void refresh() {
		/*	mainGrid.invalidateCache();
		if (ADVF.equals(advancedButton.getTitle())) {
			showData();
		}
		else {
			mainGrid.filterData(filterBuilder.getCriteria());
		}
		 */

	}









	// Context menu OUTSTANDING MATCHING ENTRIES
	private Menu createContextMenu() {
		Menu menu = new Menu();
		menu.setWidth(140);



		// Set selection ad False Positive menu item
		MenuItem setSelASFalsePosItem = new MenuItem("Set as false positive");
		setSelASFalsePosItem.setEnableIfCondition(new MenuItemIfFunction() {
			public boolean execute(Canvas target, Menu menu, MenuItem item) {
				// Recupero i record selezionati
				ListGridRecord[] recordList = ((ListGrid) target).getSelectedRecords();
				// inizializzo l'utente di default
				requestedRoles = new String[] { "user"};
				// Se � stato selezionato almeno un recor e l'utente ha i
				// permessi necessari
				// il menu viene abilitato
				if (recordList.length > 0
						& Privileges.hasPrivileges(requestedRoles)) {
					return true;
				}
				return false;
			}
		});

		// Mette la s del plurale
		setSelASFalsePosItem
		.setDynamicTitleFunction(new com.smartgwt.client.widgets.menu.MenuItemStringFunction() {
			public String execute(Canvas target, Menu menu,
					MenuItem item) {
				// Recupero i record selezionati
				ListGridRecord[] recordList = ((ListGrid) target).getSelectedRecords();

				if (recordList.length > 1)
					return ("Set selected rows as False Positive");
				else
					return ("Set as False Positive");
			}
		});

		// Aggiunge il click handler
		setSelASFalsePosItem
		.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				// Se il sistema � nello stato di working viene lanciato
				// un mess di notifica
				if (Privileges.isWorking()) {
					SC.say("The system is currently busy");
					return;
				}

				// Recupero i record selezionati
				ListGridRecord[] recordList = corrispListGrid.getSelectedRecords();

				for(ListGridRecord lgr:recordList){

					int row=corrispListGrid.getRecordIndex(lgr);

					corrispListGrid.setEditValue(row, "STATUS", "F");

				}
			}
		});



		// Set selection ad False Positive menu item
		MenuItem setSelASPosMatchItem = new MenuItem("Set as Positive Match");
		setSelASPosMatchItem.setEnableIfCondition(new MenuItemIfFunction() {
			public boolean execute(Canvas target, Menu menu, MenuItem item) {
				// Recupero i record selezionati
				ListGridRecord[] recordList = ((ListGrid) target).getSelectedRecords();
				// inizializzo l'utente di default
				requestedRoles = new String[] { "user"};
				// Se � stato selezionato almeno un recor e l'utente ha i
				// permessi necessari
				// il menu viene abilitato
				if (recordList.length > 0
						& Privileges.hasPrivileges(requestedRoles)) {
					return true;
				}
				return false;
			}
		});

		// Mette la s del plurale
		setSelASPosMatchItem
		.setDynamicTitleFunction(new com.smartgwt.client.widgets.menu.MenuItemStringFunction() {
			public String execute(Canvas target, Menu menu,
					MenuItem item) {
				// Recupero i record selezionati
				ListGridRecord[] recordList = ((ListGrid) target).getSelectedRecords();

				if (recordList.length > 1)
					return ("Set selected rows as Positive Matches");
				else
					return ("Set as Positive Match");
			}
		});

		// Aggiunge il click handler
		setSelASPosMatchItem
		.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				// Se il sistema � nello stato di working viene lanciato
				// un mess di notifica
				if (Privileges.isWorking()) {
					SC.say("The system is currently busy");
					return;
				}

				// Recupero i record selezionati
				ListGridRecord[] recordList = corrispListGrid.getSelectedRecords();






				for(ListGridRecord lgr:recordList){

					int row=corrispListGrid.getRecordIndex(lgr);

					corrispListGrid.setEditValue(row, "STATUS", "P");

				}
				//corrispListGrid.refreshFields();
				//corrispListGrid.removeSelectedData();
			}
		});

		/*String operationId = "pmptinstr_update_all_eq";
		SecureMultiUpdateMenuItem multipleUpdateItem = new SecureMultiUpdateMenuItem(operationId,"enableCA");*/


		String name ="";
		ListGridRecord lgr = corrispListGrid.getSelectedRecord();
		if(lgr!=null)
			name = lgr.getAttributeAsString("CLNTID");


		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);
		TextifyMenuItem textItem = new TextifyMenuItem();
		MenuItemSeparator separator = new MenuItemSeparator();


		menu.addItem(viewDetItem);
		menu.addItem(textItem);
		menu.addItem(separator);
		menu.addItem(setSelASFalsePosItem);
		menu.addItem(setSelASPosMatchItem);

		return menu;
	}


	// Context menu ACTIVITY LOG
	private Menu createContextMenuLog() {
		Menu menu = new Menu();
		menu.setWidth(140);

		String name = "";

		ListGridRecord lgr = activityLogListGrid.getSelectedRecord();
		if(lgr!=null){
			name = lgr.getAttributeAsString("RUNID");
			//System.out.println(name);
		}
		//View Details
		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);

		//Textify Selection
		TextifyMenuItem textItem = new TextifyMenuItem();

		menu.setItems(viewDetItem,textItem);

		//Separatore
		MenuItemSeparator separator = new MenuItemSeparator();
		menu.addItem(separator);

		//Recall
		StandardMenuItem recallItem = new StandardMenuItem("Recall Report", "DASHBOARD002");

		recallItem.setEnableIfCondition(new MenuItemIfFunction() {
			public boolean execute(Canvas target, Menu menu, MenuItem item) {
				// Recupero il record selezionato
				ListGridRecord lgr = ((ListGrid) target).getSelectedRecord();
				String submissionDate = lgr.getAttributeAsString("SUBDATE");
				String report = lgr.getAttributeAsString("REPORT");


				// inizializzo l'utente di default
				//requestedRoles = new String[] {"user"};
				//requestedRolesApprover = new String[] {"approver"};

				// Se � stato selezionato un record e l'utente ha i permessi necessari il menu viene abilitato

				//Caso run sottomessa ma non ancora abilitata-->USER e APPROVER
				/*if (submissionDate!=null && report.equalsIgnoreCase("T") && approved.compareToIgnoreCase("F")==0 
						&& Privileges.isControlON4User("DASHBOARD002")){
					return true;
				}
				//Caso run sottomessa e abilitata-->APPROVER
				else if (submissionDate!=null && report.equalsIgnoreCase("T") && approved.compareToIgnoreCase("T")==0  
						&& Privileges.hasPrivileges(requestedRolesApprover)
						 && Privileges.isControlON4User("DASHBOARD002")){
					return true;
				}
				return false;*/
				if(submissionDate!=null && report.equalsIgnoreCase("T") && Privileges.isControlON4User("DASHBOARD002")){
					return true;
				}
				return false;
			}
		});
		// Aggiunge il click handler
		recallItem.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {

			@Override
			public void onClick(MenuItemClickEvent event) {

				// inizializzo l'utente di default
				requestedRoles = new String[] {"user"};
				requestedRolesApprover = new String[] {"approver"};

				//se sono APPROVER ma non USER posso eseguire la recall solo se SUBDATE!=NULL && APPROVED==F
				if (Privileges.isApprover() && !Privileges.isUser() && Privileges.isControlON4User("DASHBOARD002")){

					// Recupero i record selezionati
					final ListGridRecord[] lgrs = activityLogListGrid.getSelectedRecords();
					int matchFound = 0;
					int subNotAppr = 0;
					for(int i=0;i<lgrs.length;i++){
						String status = lgrs[i].getAttributeAsString("MATCHFOUND");
						String approved = lgrs[i].getAttributeAsString("APPROVED");
						String submissionDate = lgrs[i].getAttributeAsString("SUBDATE");

						if(status.equalsIgnoreCase("F"))
							matchFound++;
						if(submissionDate!=null && approved.equalsIgnoreCase("F"))
							subNotAppr++;
					}

					String confMessage="";

					//Sono stati trovati per la run selezionata
					if(matchFound==0 && subNotAppr==0){

						if(lgrs.length==1){
							confMessage="Are you sure you want to recall the selected run?";
							SC.confirm(confMessage,
									new BooleanCallback() {public void execute(Boolean value) {

										if (value != null && value){

											String run = "";
											
											if(lgrs.length==1)
												run = lgrs[0].getAttributeAsString("RUNID");

											final String runId = run;
											final AdvancedCriteria crit = new AdvancedCriteria();
											crit.addCriteria("RUNID", lgrs[0].getAttributeAsInt("RUNID"));

											String[] val = new String[2];
											val[0] = "F";
											val[1] = "P";

											crit.addCriteria("STATUS", OperatorId.IN_SET, val);

											tctcorrisp.fetchData(crit, new DSCallback() {
												@Override
												public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

													Record[] rec = dsResponse.getData();
													
													RPCManager.startQueue();

													rec[0].setAttribute("STATUS","O");
													tctcorrisp.updateData(rec[0]);

													Record r1 = new Record();
													r1.setAttribute("RUNID", runId);
													DSRequest req1 = new DSRequest();
													req1.setAttribute("operationId", "updateRecallCorrisp");  
													tctcorrisp.updateData(r1,null, req1);

													Record r = new Record();  
													r.setAttribute("RUNID", runId);
													DSRequest req = new DSRequest();
													req.setAttribute("operationId", "reportRecallUpdate");  
													tctrunreg.updateData(r,null, req);
													
													updateAuditTableRecallClient(rec);
													
													Criteria criteria = new Criteria();
													criteria.setAttribute("RUNID", lgrs[0].getAttribute("RUNID"));
													
													tctrunreg.fetchData(criteria, new DSCallback() {
														
														@Override
														public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
															// TODO Auto-generated method stub
															Record[] rec = dsResponse.getData();
															updateAuditTableRecallRunReg(rec);
														}
													});

													RPCManager.sendQueue(new RPCQueueCallback() {

														@Override
														public void execute(RPCResponse... response) {
															// TODO Auto-generated method stub
															matchingClientListGrid.invalidateCache();
															corrispListGrid.invalidateCache();
															activityLogListGrid.invalidateCache();
														}
													});
												}

											});

										}
									}
							});

						}else if(lgrs.length>1){
							SC.warn("Please select a single run.");
						}
					}/*else if(matchFound!=0 && subNotAppr==0){
						SC.warn("You cannot recall match found false run");
					}else if(matchFound==0 && subNotAppr!=0){
						SC.warn("You cannot recall not approved run");
					}*/else{
						//SC.warn("You cannot recall match found false and not approved run");
						SC.warn("You cannot recall not approved run");
					}

				}

				//se sono USER ma non APPROVER posso eseguire la recall solo se SUBDATE!=NULL && APPROVED==T
				else if (!Privileges.isApprover() && Privileges.isUser() && Privileges.isControlON4User("DASHBOARD002")){

					// Recupero i record selezionati
					final ListGridRecord[] lgrs = activityLogListGrid.getSelectedRecords();
					int matchFound = 0;
					int subAndAppr = 0;
					for(int i=0;i<lgrs.length;i++){
						String status = lgrs[i].getAttributeAsString("MATCHFOUND");
						String approved = lgrs[i].getAttributeAsString("APPROVED");
						String submissionDate = lgrs[i].getAttributeAsString("SUBDATE");

						if(status.equalsIgnoreCase("F"))
							matchFound++;
						if(submissionDate!=null && approved.equalsIgnoreCase("T"))
							subAndAppr++;
					}

					String confMessage="";

					//Sono stati trovati per la run selezionata
					if(matchFound==0 && subAndAppr==0){


						if(lgrs.length==1){
							confMessage="Are you sure you want to recall the selected run?";
							SC.confirm(confMessage,
									new BooleanCallback() {public void execute(Boolean value) {

										if (value != null && value){

											String run = "";
											if(lgrs.length==1)
												run = lgrs[0].getAttributeAsString("RUNID");
										

											final String runId = run;
											final AdvancedCriteria crit = new AdvancedCriteria();
											crit.addCriteria("RUNID", lgrs[0].getAttributeAsInt("RUNID"));

											String[] val = new String[2];
											val[0] = "F";
											val[1] = "P";

											crit.addCriteria("STATUS", OperatorId.IN_SET, val);

											tctcorrisp.fetchData(crit, new DSCallback() {
												@Override
												public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

													Record[] rec = dsResponse.getData();
													RPCManager.startQueue();

													rec[0].setAttribute("STATUS","O");
													tctcorrisp.updateData(rec[0]);

													Record r1 = new Record();
													r1.setAttribute("RUNID", runId); 
													DSRequest req1 = new DSRequest();
													req1.setAttribute("operationId", "updateRecallCorrisp");  
													tctcorrisp.updateData(r1,null, req1);

													Record r = new Record();  
													r.setAttribute("RUNID", runId);
													DSRequest req = new DSRequest();
													req.setAttribute("operationId", "reportRecallUpdate");  
													tctrunreg.updateData(r,null, req);

													updateAuditTableRecallClient(rec);
													
													Criteria criteria = new Criteria();
													criteria.setAttribute("RUNID", lgrs[0].getAttribute("RUNID"));
													
													tctrunreg.fetchData(criteria, new DSCallback() {
														
														@Override
														public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
															// TODO Auto-generated method stub
															Record[] rec = dsResponse.getData();
															updateAuditTableRecallRunReg(rec);
														}
													});
													
													RPCManager.sendQueue(new RPCQueueCallback() {

														@Override
														public void execute(RPCResponse... response) {
															// TODO Auto-generated method stub
															matchingClientListGrid.invalidateCache();
															corrispListGrid.invalidateCache();
															activityLogListGrid.invalidateCache();
														}
													});
												}

											});

										}
									}
							});

						}else if(lgrs.length>1){
							SC.warn("Please select a single run.");
						}
					
						
						/*

						if(lgrs.length==1){
							confMessage="Are you sure you want to recall the selected run?";
						}else if(lgrs.length>1){
							confMessage="Are you sure you want to recall the selected runs?";
						}
						SC.confirm(confMessage,
								new BooleanCallback() {public void execute(Boolean value) {

									if (value != null && value){

										for(int i=0;i<lgrs.length;i++){

											tctrunreg.fetchData(null, new DSCallback() {
												@Override
												public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

													//RPCManager.startQueue();

													Record r = new Record();  
													DSRequest req = new DSRequest();
													req.setAttribute("operationId", "reportRecallUpdate");  
													tctrunreg.updateData(r,new DSCallback() {

														@Override
														public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
															matchingClientListGrid.invalidateCache();
															corrispListGrid.invalidateCache();

														}
													}, req);
												}

											});




											ListGridRecord rec = lgrs[i];
											final int runid = rec.getAttributeAsInt("RUNID");
//											final int companyid = rec.getAttributeAsInt("CMPNID");

//											final Criteria crit = new Criteria();
//											crit.addCriteria("RUNID", runid);
//											crit.addCriteria("CMPNID", companyid);



											//Record updRec = new Record();
											//updRec.setAttribute("RUNID", runid);
											//updRec.setAttribute("CMPNID", companyid);
											rec.setAttribute("SUBDATE", "");
											rec.setAttribute("SUBMITTER", "");
											rec.setAttribute("APPROVER", "");
											rec.setAttribute("APPROVED","F");
											rec.setAttribute("REPORT","F");

											tctrunreg.updateData(rec, new DSCallback() {

												@Override
												public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

													final AdvancedCriteria crit1 = new AdvancedCriteria();
													crit1.addCriteria("RUNID", runid);
//													crit1.addCriteria("CMPNID", companyid);
													crit1.addCriteria("STATUS", OperatorId.NOT_EQUAL, "N");


													final DataSource tctmatchingentries = SecureDS.get("tctmatchingentries");

													tctmatchingentries.fetchData(crit1, new DSCallback() {

														@Override
														public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

															Record[] recs = dsResponse.getData();

															for(int i=0;i<recs.length;i++){
																Record rec=recs[i];

																rec.setAttribute("STATUS", "O");

																tctmatchingentries.updateData(rec);

															} 
															matchingClientListGrid.invalidateCache();
															corrispListGrid.invalidateCache();
															//drawTopBar();



														}
													});




												}
											});

										}

									}
								}
						});

					*/}/*else if(matchFound!=0 && subAndAppr==0){
						SC.warn("You cannot recall match found false run");
					}else if(matchFound==0 && subAndAppr!=0){
						SC.warn("You cannot recall approved run");
					}*/else{
						//SC.warn("You cannot recall match found false and approved run");
						SC.warn("You cannot recall approved run");
					}

				}
				//se sono USER e APPROVER posso eseguire la recall solo se SUBDATE!=NULL && APPROVED==NULL
				else if (Privileges.isUser() && Privileges.isApprover() && Privileges.isControlON4User("DASHBOARD002")){

					// Recupero i record selezionati
					final ListGridRecord[] lgrs = activityLogListGrid.getSelectedRecords();
					int matchFound = 0;
					for(int i=0;i<lgrs.length;i++){
						String status = lgrs[i].getAttributeAsString("MATCHFOUND");

						if(status.equalsIgnoreCase("F"))
							matchFound++;
					}

					String confMessage="";

					//Sono stati trovati per la run selezionata
					if(matchFound==0){


						if(lgrs.length==1){
							confMessage="Are you sure you want to recall the selected run?";
							/*}else if(lgrs.length>1){
							SC.warn("Please select a single run.");
							//confMessage="Are you sure you want to recall the selected runs?";
						}*/
							SC.confirm(confMessage,
									new BooleanCallback() {public void execute(Boolean value) {

										if (value != null && value){

											String run = "";
											//int[] run1 = new int[lgrs.length];

											if(lgrs.length==1)
												run = lgrs[0].getAttributeAsString("RUNID");
											//run1[0] = lgrs[0].getAttributeAsInt("RUNID");

											/*if(lgrs.length>1){	
											for(int i=1;i<lgrs.length;i++){
												run += ","+lgrs[i].getAttributeAsString("RUNID");
												//run1[i] = lgrs[i].getAttributeAsInt("RUNID");
											}
										}*/

											final String runId = run;
											//final int[] run11 = run1;
											//final int runId = lgrs[i].getAttributeAsInt("RUNID");
											final AdvancedCriteria crit = new AdvancedCriteria();
											crit.addCriteria("RUNID", lgrs[0].getAttributeAsInt("RUNID"));

											String[] val = new String[2];
											val[0] = "F";
											val[1] = "P";

											crit.addCriteria("STATUS", OperatorId.IN_SET, val);

											tctcorrisp.fetchData(crit, new DSCallback() {
												@Override
												public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

													Record[] rec = dsResponse.getData();
													RPCManager.startQueue();

													rec[0].setAttribute("STATUS","O");
													tctcorrisp.updateData(rec[0]);

													Record r1 = new Record();
													r1.setAttribute("RUNID", runId); //runId
													DSRequest req1 = new DSRequest();
													req1.setAttribute("operationId", "updateRecallCorrisp");  
													tctcorrisp.updateData(r1,null, req1);

													Record r = new Record();  
													r.setAttribute("RUNID", runId);
													DSRequest req = new DSRequest();
													req.setAttribute("operationId", "reportRecallUpdate");  
													tctrunreg.updateData(r,null, req);
													
													updateAuditTableRecallClient(rec);
													
													Criteria criteria = new Criteria();
													criteria.setAttribute("RUNID", lgrs[0].getAttribute("RUNID"));
													
													tctrunreg.fetchData(criteria, new DSCallback() {
														
														@Override
														public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
															// TODO Auto-generated method stub
															Record[] rec = dsResponse.getData();
															updateAuditTableRecallRunReg(rec);
														}
													});

													RPCManager.sendQueue(new RPCQueueCallback() {

														@Override
														public void execute(RPCResponse... response) {
															// TODO Auto-generated method stub
															matchingClientListGrid.invalidateCache();
															corrispListGrid.invalidateCache();
															activityLogListGrid.invalidateCache();
														}
													});
												}

											});

										}
									}
							});

						}else if(lgrs.length>1){
							SC.warn("Please select a single run.");
							//confMessage="Are you sure you want to recall the selected runs?";
						}
					
						
						/*

						if(lgrs.length==1){
							confMessage="Are you sure you want to recall the selected run?";
						}else if(lgrs.length>1){
							confMessage="Are you sure you want to recall the selected runs?";
						}
						SC.confirm(confMessage,
								new BooleanCallback() {public void execute(Boolean value) {

									if (value != null && value){

										for(int i=0;i<lgrs.length;i++){

											ListGridRecord rec = lgrs[i];
											final int runid = rec.getAttributeAsInt("RUNID");
											final int companyid = rec.getAttributeAsInt("CMPNID");

											final Criteria crit = new Criteria();
											crit.addCriteria("RUNID", runid);
											crit.addCriteria("CMPNID", companyid);



											Record updRec = new Record();
											updRec.setAttribute("RUNID", runid);
											updRec.setAttribute("CMPNID", companyid);
											rec.setAttribute("SUBDATE", "");
											rec.setAttribute("SUBMITTER", "");
											rec.setAttribute("APPROVER", "");
											rec.setAttribute("APPROVED","F");
											rec.setAttribute("REPORT","F");

											tctrunreg.updateData(rec, new DSCallback() {

												@Override
												public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

													final AdvancedCriteria crit1 = new AdvancedCriteria();
													crit1.addCriteria("RUNID", runid);
													crit1.addCriteria("CMPNID", companyid);
													crit1.addCriteria("STATUS", OperatorId.NOT_EQUAL, "N");


													final DataSource tctmatchingentries = SecureDS.get("tctmatchingentries");

													tctmatchingentries.fetchData(crit1, new DSCallback() {

														@Override
														public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

															Record[] recs = dsResponse.getData();

															for(int i=0;i<recs.length;i++){
																Record rec=recs[i];

																rec.setAttribute("STATUS", "O");

																tctmatchingentries.updateData(rec);

															} 
															matchingClientListGrid.invalidateCache();
															corrispListGrid.invalidateCache();
															//drawTopBar();



														}
													});




												}
											});

										}

									}
								}
						});

					*/}else {
						SC.warn("You cannot recall match found false");
					}

				}
			}
		});
		/*recallItem.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				// Se il sistema � nello stato di working viene lanciato un mess di notifica
				if (Privileges.isWorking()) {
					SC.say("The system is currently busy");
					return;
				}

				else{

					// Recupero i record selezionati
					ListGridRecord[] lgr = activityLogListGrid.getSelectedRecords();
					int falseNegative = 0;
					for(int i=0;i<lgr.length;i++){
						String status = lgr[i].getAttributeAsString("MATCHFOUND");
						if(status.equalsIgnoreCase("F"))
							falseNegative++;
					}

					if(falseNegative==0){

						String confMessage="";
						if(lgr.length==1){
							confMessage="Are you sure you want to recall the selected run?";
						}else if(lgr.length>1){
							confMessage="Are you sure you want to recall the selected runs?";
						}
						SC.confirm(confMessage,
								new BooleanCallback() {public void execute(Boolean value) {

									if (value != null && value){
										ListGridRecord[] lgr = activityLogListGrid.getSelectedRecords();

										for(int i=0;i<lgr.length;i++){
											int runId = lgr[i].getAttributeAsInt("RUNID");
											int companyId = lgr[i].getAttributeAsInt("CMPNID");

											final AdvancedCriteria crit = new AdvancedCriteria();
											crit.addCriteria("RUNID", runId);
											crit.addCriteria("CMPNID", companyId);
											crit.addCriteria("STATUS", OperatorId.NOT_EQUAL, "N");//*********************************************************************Aggiunto

											final DataSource corrispMatchingDS = SecureDS.get("tctmatchingentries");
											corrispMatchingDS.fetchData(crit, new DSCallback(){

												@Override
												public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
													Record[] result =dsResponse.getData();
													//SC.say("Result : "+result.length+", Status:"+result[0].getAttribute("STATUS"));

													for(int i=0;i<result.length;i++){
														result[i].setAttribute("STATUS", "O");
														//SC.say("RunId: "+result[i].getAttribute("RUNID")+", Status:"+result[i].getAttribute("STATUS"));
														corrispListGrid.updateData(result[i], new DSCallback() {

															@Override
															public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {


																tctrunreg.fetchData(crit, new DSCallback() {

																	@Override
																	public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
																		Record[] result =dsResponse.getData();

																		for(int i=0;i<result.length;i++){
																			result[i].setAttribute("SUBDATE", "");
																			result[i].setAttribute("REPORT","F");
																			activityLogListGrid.updateData(result[i]);

																		}
																		matchingClientListGrid.invalidateCache();
																	}
																});

															}
														});
													}

												}
											});
										}	
									}
								}
						});
					}//****************************
					else{
						SC.warn("Not possible make a recall without a match");
					}
				}
			}
		});*/

		menu.addItem(recallItem);

		//Report
		MenuItem reportItem = new MenuItem("Generate Report");
		reportItem
		.setEnableIfCondition(new MenuItemIfFunction() {
			public boolean execute(Canvas target, Menu menu, MenuItem item) {
				// Recupero il record selezionato
				ListGridRecord lgr = ((ListGrid) target).getSelectedRecord();
				//String submissionDate = lgr.getAttributeAsString("SUBDATE");
				String report = lgr.getAttributeAsString("REPORT");
				// inizializzo l'utente di default
				requestedRoles = new String[] {"user", "approver", "visitor", "manager"};
				// Se � stato selezionato un recor e l'utente ha i permessi necessari il menu viene abilitato
				if (report.equalsIgnoreCase("T") &&
						Privileges.hasPrivileges(requestedRoles)) {
					return true;
				}
				return false;
			}
		});
		// Aggiunge il click handler
		reportItem
		.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				// Se il sistema � nello stato di working viene lanciato un mess di notifica
				if (Privileges.isWorking()) {
					SC.say("The system is currently busy");
					return;
				}

				// Recupero i record selezionati
				ListGridRecord lgr = activityLogListGrid.getSelectedRecord();
				int runId = lgr.getAttributeAsInt("RUNID");
//				int companyId = lgr.getAttributeAsInt("CMPNID");


//				AdvancedCriteria crit = new AdvancedCriteria();
//				crit.addCriteria("RUNID", runId);

				String paramStr = runId+/*","+companyId+*/",tctcorrisp";
				//SC.say(paramStr);

				RPCRequest rpcRequest = new RPCRequest();

				rpcRequest.setHttpMethod("POST");
				rpcRequest.setDownloadResult(true);
				// Sto dicendo al client di aprire un hidden frame dal quale generare la richiesta in POST
				//rpcRequest.setTransport(RPCTransport.HIDDENFRAME);

				rpcRequest.setActionURL("ccgportal/PdfServlet?params=" + paramStr);
				RPCManager.sendRequest(rpcRequest);
			}
		});
		menu.addItem(reportItem);

		return menu;
	}

	// Context menu SOURCE LIST
	private Menu createContextMenuSource() {
		Menu menu = new Menu();
		menu.setWidth(140);

		String name = "";

		ListGridRecord lgr = activityLogListGrid.getSelectedRecord();
		if(lgr!=null){
			name = lgr.getAttributeAsString("UPDID");
		}
		//View Details
		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);

		//Textify Selection
		TextifyMenuItem textItem = new TextifyMenuItem();

		menu.setItems(viewDetItem,textItem);

		return menu;
	}

	// Context menu MATCHING
	private Menu createContextMenuMatch() {
		Menu menu = new Menu();
		menu.setWidth(140);

		String name = "";

		ListGridRecord lgr = activityLogListGrid.getSelectedRecord();
		if(lgr!=null){
			name = lgr.getAttributeAsString("CLNTID");
		}
		//View Details
		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);

		//Textify Selection
		TextifyMenuItem textItem = new TextifyMenuItem();

		menu.setItems(viewDetItem,textItem);

		return menu;
	}

	public void updateAuditTableWithClientEdit(int[] editrows, Record[] recArr){
		for(int j=0;j<editrows.length;j++){
			int editedRowNum=editrows[j];
			for(int i=0;i<recArr.length;i++){
				if( i!=editedRowNum){
					Record rec = recArr[i];
					String[] fieldnames = tctcorrisp.getFieldNames();
					String oldRecordStr = "";
					String newRecordStr = "";
					int runid = rec.getAttributeAsInt("RUNID");
					Date date=new Date();
					for(int w=0;w<fieldnames.length;w++){
						//newValuesStr+= fieldName+": "+newValuesmap.get(fieldName)+" | ";
						oldRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
						if(fieldnames[w].compareToIgnoreCase("UPDDATE")==0){
							newRecordStr+=fieldnames[w]+": "+date+" | ";
						} else if(fieldnames[w].compareToIgnoreCase("CMPNID")==0){
							newRecordStr+="";
						} else if(fieldnames[w].compareToIgnoreCase("STATUS")==0){
							newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";//"F"+" | ";
						} else if(fieldnames[w].compareToIgnoreCase("UPDUSER")==0){
							newRecordStr+=fieldnames[w]+": "+Privileges.getUsername()+" | ";
						} else {
							if(rec.getAttributeAsString(fieldnames[w])==null)
								newRecordStr+=fieldnames[w]+":  | ";
							else
								newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
						}
					}

					Record usrActRecord = new Record();

					usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctcorrisp_update");
					usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
					usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
					usrActRecord.setAttribute("NEWRECORD", newRecordStr);
					//usrActRecord.setAttribute("CMPNID", Privileges.getCompanyID());
					usrActRecord.setAttribute("RUNID", runid);

					tctusract.addData(usrActRecord);


				}


			}
		}
	}

	public void updateAuditTableWithoutClientEdit(Record[] recArr){

		for(int i=0;i<recArr.length;i++){
			Record rec = recArr[i];
			String[] fieldnames = tctcorrisp.getFieldNames();
			String oldRecordStr = "";
			String newRecordStr = "";
			int runid = rec.getAttributeAsInt("RUNID");
			Date date=new Date();
			for(int w=0;w<fieldnames.length;w++){
				//newValuesStr+= fieldName+": "+newValuesmap.get(fieldName)+" | ";
				oldRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
				if(fieldnames[w].compareToIgnoreCase("UPDDATE")==0){
					newRecordStr+=fieldnames[w]+": "+date+" | ";
				} else if(fieldnames[w].compareToIgnoreCase("CMPNID")==0){
					newRecordStr+="";
				} else if(fieldnames[w].compareToIgnoreCase("STATUS")==0){
					newRecordStr+=fieldnames[w]+": "+"F"+" | ";
				} else if(fieldnames[w].compareToIgnoreCase("UPDUSER")==0){
					newRecordStr+=fieldnames[w]+": "+Privileges.getUsername()+" | ";
				} else {
					if(rec.getAttributeAsString(fieldnames[w])==null)
						newRecordStr+=fieldnames[w]+":  | ";
					else
						newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
				}
			}

			Record usrActRecord = new Record();

			usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctcorrisp_update");
			usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
			usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
			usrActRecord.setAttribute("NEWRECORD", newRecordStr);
			//usrActRecord.setAttribute("CMPNID", Privileges.getCompanyID());
			usrActRecord.setAttribute("RUNID", runid);

			tctusract.addData(usrActRecord);


		}

	}
	
	
	public void updateAuditTableRecallClient(Record[] recArr){

		for(int i=0;i<recArr.length;i++){
			Record rec = recArr[i];
			String[] fieldnames = tctcorrisp.getFieldNames();
			String newRecordStr = "";
			int runid = rec.getAttributeAsInt("RUNID");
			Date date=new Date();
			for(int w=0;w<fieldnames.length;w++){
				if(fieldnames[w].compareToIgnoreCase("UPDDATE")==0){
					newRecordStr+=fieldnames[w]+": "+date+" | ";
				} else if(fieldnames[w].compareToIgnoreCase("CMPNID")==0){
					newRecordStr+="";
				} else if(fieldnames[w].compareToIgnoreCase("STATUS")==0){
					newRecordStr+=fieldnames[w]+": "+"O"+" | ";
				} else if(fieldnames[w].compareToIgnoreCase("UPDUSER")==0){
					newRecordStr+=fieldnames[w]+": "+Privileges.getUsername()+" | ";
				} else {
					if(rec.getAttributeAsString(fieldnames[w])==null)
						newRecordStr+=fieldnames[w]+":  | ";
					else
						newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
				}
			}

			Record usrActRecord = new Record();

			usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctcorrisp_update");
			usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
			usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
			usrActRecord.setAttribute("NEWRECORD", newRecordStr);
			//usrActRecord.setAttribute("CMPNID", Privileges.getCompanyID());
			usrActRecord.setAttribute("RUNID", runid);

			tctusract.addData(usrActRecord);


		}

	}
	
	public void updateAuditTableRecallRunReg(Record[] recArr){

		for(int i=0;i<recArr.length;i++){
			Record rec = recArr[i];
			String[] fieldnames = tctrunreg.getFieldNames();
			String newRecordStr = "";
			int runid = rec.getAttributeAsInt("RUNID");
			Date date=new Date();
			for(int w=0;w<fieldnames.length;w++){
				if(fieldnames[w].compareToIgnoreCase("APPROVER")==0){
					newRecordStr+=fieldnames[w]+": | ";
				} else if(fieldnames[w].compareToIgnoreCase("CMPNID")==0){
					newRecordStr+="";
				} else if(fieldnames[w].compareToIgnoreCase("APPROVED")==0){
					newRecordStr+=fieldnames[w]+": 'F' | ";
				} else if(fieldnames[w].compareToIgnoreCase("UPDDATE")==0){
					newRecordStr+=fieldnames[w]+": "+date+" | ";
				} else if(fieldnames[w].compareToIgnoreCase("UPDUSER")==0){
					newRecordStr+=fieldnames[w]+": "+Privileges.getUsername()+" | ";
				} else {
					if(rec.getAttributeAsString(fieldnames[w])==null)
						newRecordStr+=fieldnames[w]+":  | ";
					else
						newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
				}
			}

			Record usrActRecord = new Record();

			usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctrunreg_update");
			usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
			usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
			usrActRecord.setAttribute("NEWRECORD", newRecordStr);
			//usrActRecord.setAttribute("CMPNID", Privileges.getCompanyID());
			usrActRecord.setAttribute("RUNID", runid);

			tctusract.addData(usrActRecord);


		}

	}
	
	public void updateAuditTableSubmitRunReg(Record[] recArr){

		for(int i=0;i<recArr.length;i++){
			Record rec = recArr[i];
			String[] fieldnames = tctrunreg.getFieldNames();
			String newRecordStr = "";
			int runid = rec.getAttributeAsInt("RUNID");
			Date date=new Date();
			for(int w=0;w<fieldnames.length;w++){
				if(fieldnames[w].compareToIgnoreCase("APPROVER")==0){
					newRecordStr+=fieldnames[w]+": | ";
				} else if(fieldnames[w].compareToIgnoreCase("CMPNID")==0){
					newRecordStr+="";
				} else if(fieldnames[w].compareToIgnoreCase("APPROVED")==0){
					newRecordStr+=fieldnames[w]+": 'F' | ";
				} else if(fieldnames[w].compareToIgnoreCase("UPDDATE")==0){
					newRecordStr+=fieldnames[w]+": "+date+" | ";
				} else if(fieldnames[w].compareToIgnoreCase("UPDUSER")==0){
					newRecordStr+=fieldnames[w]+": "+Privileges.getUsername()+" | ";
				} else {
					if(rec.getAttributeAsString(fieldnames[w])==null)
						newRecordStr+=fieldnames[w]+":  | ";
					else
						newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
				}
			}

			Record usrActRecord = new Record();

			usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctrunreg_update");
			usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
			usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
			usrActRecord.setAttribute("NEWRECORD", newRecordStr);
			//usrActRecord.setAttribute("CMPNID", Privileges.getCompanyID());
			usrActRecord.setAttribute("RUNID", runid);

			tctusract.addData(usrActRecord);


		}

	}
	

	public void drawTopBarInit(){

		AdvancedCriteria criteria = new AdvancedCriteria(OperatorId.AND, new Criterion[]{
				new Criterion("SUBDATE", OperatorId.NOT_NULL),
				new Criterion("APPROVED", OperatorId.EQUALS, "F"),
				new Criterion("MATCHFOUND", OperatorId.EQUALS, "T")

		});

		tctrunreg.fetchData(criteria, new DSCallback() {

			@Override
			public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
				approveRec = dsResponse.getData();

				int contApprove = 0;
				for(int i=0;i<role.length;i++){
					if(role[i].equalsIgnoreCase("approver")){
						contApprove++;
					}
				}

				approveLink.setShowTitle(false);
				approveLink.setWidth(300);
				approveLink.setLinkTitle("<font color=\"#f21616\">There is a pending action: please approve submitted forms</font>");
				approveLink.hide();
				approvDynForm.setItems(approveLink);


				topControlBar.addMember(approvDynForm);

				if(isApproveEnabled.compareToIgnoreCase("T")==0 && contApprove == 1 && approveRec.length>0){
					approveLink.show();
				}				

				final Label refresh = new Label();  
				refresh.setHeight(30);  
				refresh.setPadding(10);  
				refresh.setAlign(Alignment.CENTER);  
				refresh.setValign(VerticalAlignment.CENTER);  
				refresh.setWrap(false);  
				refresh.setIcon("icons/24/refresh.png");  
				refresh.setCanHover(true);
				refresh.setShowHover(false);

				refresh.addMouseOverHandler(new MouseOverHandler() {

					@Override
					public void onMouseOver(MouseOverEvent event) {
						refresh.setOpacity(50);
						refresh.setCursor(Cursor.POINTER);
					}
				});


				refresh.addMouseOutHandler(new MouseOutHandler() {

					@Override
					public void onMouseOut(MouseOutEvent event) {
						refresh.setOpacity(100);
						refresh.setCursor(Cursor.DEFAULT);
					}
				});


				refresh.setContents("<i>Refresh</i>");  

				refresh.addClickHandler(new ClickHandler() {

					@Override
					public void onClick(ClickEvent event) {
						activityLogListGrid.invalidateCache();
						corrispListGrid.invalidateCache();
						matchingClientListGrid.invalidateCache();
						sourceListUpdateListGrid.invalidateCache();
						drawTopBar();
					}
				});


				LayoutSpacer lstop = new LayoutSpacer();


				topControlBar.addMember(lstop);

				topControlBar.addMember(refresh);

				final Label helpLabel = new Label();  
				helpLabel.setHeight(30);  
				helpLabel.setPadding(10);  
				helpLabel.setAlign(Alignment.CENTER);  
				helpLabel.setValign(VerticalAlignment.CENTER);  
				helpLabel.setWrap(false);  
				helpLabel.setIcon("icons/24/help24.png");  
				helpLabel.setCanHover(true);
				helpLabel.setShowHover(false);

				helpLabel.addMouseOverHandler(new MouseOverHandler() {

					@Override
					public void onMouseOver(MouseOverEvent event) {
						helpLabel.setOpacity(50);
						helpLabel.setCursor(Cursor.POINTER);
					}
				});


				helpLabel.addMouseOutHandler(new MouseOutHandler() {

					@Override
					public void onMouseOut(MouseOutEvent event) {
						helpLabel.setOpacity(100);
						helpLabel.setCursor(Cursor.DEFAULT);
					}
				});


				//refresh.setShowEdges(true);  
				helpLabel.setContents("<i>Help</i>");  

				helpLabel.addClickHandler(new ClickHandler() {

					@Override
					public void onClick(ClickEvent event) {
						HelpWindow.windowCreator2(mainTabSet, "");

					}
				});



				topControlBar.addMember(helpLabel);



			}

		});
	}

	public void drawTopBar(){


		AdvancedCriteria criteria = new AdvancedCriteria(OperatorId.AND, new Criterion[]{
				new Criterion("SUBDATE", OperatorId.NOT_NULL),
				new Criterion("APPROVED", OperatorId.EQUALS, "F"),
				new Criterion("MATCHFOUND", OperatorId.EQUALS, "T")

		});

		tctrunreg.fetchData(criteria, new DSCallback() {

			@Override
			public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
				approveRec = dsResponse.getData();
				//System.out.println("***** //- "+approveRec.length);
				int contApprove = 0;
				for(int i=0;i<role.length;i++){
					if(role[i].equalsIgnoreCase("approver")){
						contApprove++;
					}
				}

				if(isApproveEnabled.compareToIgnoreCase("T")==0 && contApprove == 1 && approveRec.length>0){
					approveLink.show();
				}
				else{					
					approveLink.hide();
				}
			}

		});
	}

}