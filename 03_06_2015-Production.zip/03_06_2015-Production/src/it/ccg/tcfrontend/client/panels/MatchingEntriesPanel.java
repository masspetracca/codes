package it.ccg.tcfrontend.client.panels;



import it.ccg.tcfrontend.client.ExportWindow;
import it.ccg.tcfrontend.client.HelpWindow;
import it.ccg.tcfrontend.client.PanelFactory;
import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.SecureDoubleClick;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardControlBar;
import it.ccg.tcfrontend.client.controls.StandardListGrid;
import it.ccg.tcfrontend.client.interf.Refreshable;
import it.ccg.tcfrontend.client.menu.TextifyMenuItem;
import it.ccg.tcfrontend.client.menu.ViewDetailsMenuItem;
import it.ccg.tcfrontend.client.security.Privileges;
import it.ccg.tcfrontend.client.utils.ClientMessages;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.data.RecordList;
import com.smartgwt.client.data.SortSpecifier;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.BackgroundRepeat;
import com.smartgwt.client.types.Cursor;
import com.smartgwt.client.types.OperatorId;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.DoubleClickEvent;
import com.smartgwt.client.widgets.events.DoubleClickHandler;
import com.smartgwt.client.widgets.events.MouseOutEvent;
import com.smartgwt.client.widgets.events.MouseOutHandler;
import com.smartgwt.client.widgets.events.MouseOverEvent;
import com.smartgwt.client.widgets.events.MouseOverHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.EditCompleteEvent;
import com.smartgwt.client.widgets.grid.events.EditCompleteHandler;
import com.smartgwt.client.widgets.grid.events.RowHoverEvent;
import com.smartgwt.client.widgets.grid.events.RowHoverHandler;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.MenuItemIfFunction;
import com.smartgwt.client.widgets.menu.MenuItemSeparator;
import com.smartgwt.client.widgets.menu.events.MenuItemClickEvent;
import com.smartgwt.client.widgets.tab.TabSet;

public class MatchingEntriesPanel extends VLayout implements Refreshable{

	final protected  TabSet mainTabSet;
	/*protected StandardControlBar nestedFilterControlBar = new StandardControlBar();*/
	protected StandardControlBar topControlBar = new StandardControlBar();
	protected StandardControlBar corrispListControlBar = new StandardControlBar();
	protected VLayout workingArea = new VLayout();

	private static final String DESCRIPTION = "Matching Entries";

	final DataSource tctcorrisp = SecureDS.get("tctcorrisp");
	final DataSource tctrunreg = SecureDS.get("tctrunreg");
	final DataSource tctusract = SecureDS.get("tctusract");


	final protected StandardButton submitButton = new StandardButton("Submit","MATCHENT001");
	//final protected StandardButton submitAsFalseButton = new StandardButton("Submit all as False Positive");
	final protected StandardButton printButton = new StandardButton("Print");
	final protected StandardButton exportButton = new StandardButton("Export");

	private StandardListGrid corrispListGrid;

	int rowNum =0;

	private String[] requestedRoles = new String[] { "user" };

	public MatchingEntriesPanel(final TabSet mainTabSet, String panelID) {
		super();


		/*	MiniDateRangeItem dateTime = new MiniDateRangeItem();
		dateTime.setDateDisplayFormat(DateDisplayFormat.TOEUROPEANSHORTDATETIME);
		MiniDateRangeItem date = new MiniDateRangeItem();
		date.setDateDisplayFormat(DateDisplayFormat.TOEUROPEANSHORTDATE);
		 */
		this.mainTabSet=mainTabSet;

		/*//Toolbar del filtro avanzato
		nestedFilterControlBar.setLayoutTopMargin(15);
		nestedFilterControlBar.setLayoutBottomMargin(15);
		nestedFilterControlBar.setAutoHeight();		
		nestedFilterControlBar.setVisible(false);
		this.addMember(nestedFilterControlBar);*/
		//Toolbar superiore

		final Label refresh = new Label();  
		refresh.setHeight(30);  
		refresh.setPadding(10);  
		refresh.setAlign(Alignment.CENTER);  
		refresh.setValign(VerticalAlignment.CENTER);  
		refresh.setWrap(false);  
		refresh.setIcon("icons/24/refresh.png");  
		refresh.setCanHover(true);
		refresh.setShowHover(false);

		refresh.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				refresh.setOpacity(50);
				refresh.setCursor(Cursor.POINTER);
			}
		});


		refresh.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				refresh.setOpacity(100);
				refresh.setCursor(Cursor.DEFAULT);
			}
		});


		//refresh.setShowEdges(true);  
		refresh.setContents("<i>Refresh</i>");  

		refresh.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				corrispListGrid.invalidateCache();



			}
		});


		LayoutSpacer lstop = new LayoutSpacer();
		topControlBar.addMember(lstop);

		topControlBar.addMember(refresh);




		final Label helpLabel = new Label();  
		helpLabel.setHeight(30);  
		helpLabel.setPadding(10);  
		helpLabel.setAlign(Alignment.CENTER);  
		helpLabel.setValign(VerticalAlignment.CENTER);  
		helpLabel.setWrap(false);  
		helpLabel.setIcon("icons/24/help24.png");  
		helpLabel.setCanHover(true);
		helpLabel.setShowHover(false);

		helpLabel.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				helpLabel.setOpacity(50);
				helpLabel.setCursor(Cursor.POINTER);
			}
		});


		helpLabel.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				helpLabel.setOpacity(100);
				helpLabel.setCursor(Cursor.DEFAULT);
			}
		});


		//refresh.setShowEdges(true);  
		helpLabel.setContents("<i>Help</i>");  

		helpLabel.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				HelpWindow.windowCreator2(mainTabSet, "");

			}
		});



		topControlBar.addMember(helpLabel);







		this.addMember(topControlBar);

		final DataSource activityLogDS = SecureDS.get("tctrunreg");
		// DataSource utilizzato per la tabella delle corrispondenze
		final DataSource tctcorrispDS = SecureDS.get("tctmatchingentries");
		/*Map<String,String> valueMap = new HashMap<String, String>();
		valueMap.put("O", "Outstanding");
		valueMap.put("F", "False Positive");
		valueMap.put("P", "Positive match");

		tctcorrispDS.getField("STATUS").setValueMap(valueMap);*/

		corrispListGrid= new StandardListGrid(panelID);
		corrispListGrid.setDataSource(tctcorrispDS);

		corrispListGrid.setWidth100();
		corrispListGrid.setHeight100();
		corrispListGrid.setShowFilterEditor(true);
		corrispListGrid.setFilterOnKeypress(false);
		corrispListGrid.setAutoSaveEdits(false);
		corrispListGrid.setAutoFetchData(true);
		//corrispListGrid.setCanEdit(false);
		corrispListGrid.setContextMenu(createContextMenu());
		corrispListGrid.setCanHover(true);
		corrispListGrid.setShowHover(false);

		SortSpecifier[] sortspec = new SortSpecifier[]{
        		new SortSpecifier("RUNID",SortDirection.DESCENDING),
        		new SortSpecifier("STATUS",SortDirection.DESCENDING)
        };

		corrispListGrid.setSort(sortspec);

		corrispListGrid.addRowHoverHandler(new RowHoverHandler() {

			@Override
			public void onRowHover(RowHoverEvent event) {
				Record record=event.getRecord(); 

				//int colNum = event.getColNum();
				//int rowNum = event.getRowNum();
				ListGridField field = corrispListGrid.getField("STATUS");  


				//String fieldName = corrispListGrid.getFieldName(colNum);  
				String fieldTitle = field.getTitle();


				if(record.getAttributeAsString("STATUS").equalsIgnoreCase("F")||record.getAttributeAsString("STATUS").equalsIgnoreCase("P")) {

					Map<String,String> map = new HashMap<String, String>();
					map.put("F","False Positive");
					map.put("P", "Positive Match");

					field.setEditorValueMap(map);

				}
				else{
					Map<String,String> map = new HashMap<String, String>();
					map.put("F","False Positive");
					map.put("P", "Positive Match");
					map.put("O", "Outstanding");

					field.setEditorValueMap(map);
				}


			}
		});

		// Double click handler sulla corrispListGrid: � possibile editarla solo se 
		//si hanno i privilegi necessari
		/*corrispListGrid.addDoubleClickHandler(new DoubleClickHandler() {

			@Override
			public void onDoubleClick(DoubleClickEvent event) {
				ListGridRecord lgr = corrispListGrid.getSelectedRecord();
				String status = lgr.getAttributeAsString("STATUS");

				String[] requestedRoles=new String[] {"user"};
				if(status.equalsIgnoreCase("O")){
					//if(Privileges.hasPrivileges(requestedRoles) && Privileges.isControlON4User("MATCHENTTAB001")){
						lgr.set_canEdit(true);
					//}
				}else 
					lgr.set_canEdit(false);
			}
		});*/

		// Double click handler sulla corrispListGrid: � possibile editarla solo se 
		//si hanno i privilegi necessari
		corrispListGrid.addDoubleClickHandler(new DoubleClickHandler() {
			@Override
			public void onDoubleClick(DoubleClickEvent event) {
				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}
				try {
					ListGridRecord lgr = corrispListGrid.getSelectedRecord();
					String status = lgr.getAttributeAsString("STATUS");

					if(status.equalsIgnoreCase("O")){
						SecureDoubleClick.secureDoubleClickRecord(event, lgr, "MATCHENTTAB001");
					} else 
						lgr.set_canEdit(false);
				}catch (Exception e) {
				}
			}
		});		



		/*corrispListGrid.addEditCompleteHandler(new EditCompleteHandler() {  


			@Override
			public void onEditComplete(EditCompleteEvent event) {
				activityLogDS.fetchData(null, new DSCallback() {  
		                    public void execute(DSResponse response, Object rawData, DSRequest request) {  
		                       // lastUpdatedLabel.setContents(response.getData()[0].getAttribute("lastUpdatedTime"));  
		                    }  
		                });  


				corrispListGrid.invalidateCache();

			}  
		}); */




		// Definizione label
		Label corrispLabel= new Label();

		corrispLabel.setHeight(10);
		corrispLabel.setWidth100();
		corrispLabel.setPadding(4);
		corrispLabel.setAlign(Alignment.LEFT);
		corrispLabel.setValign(VerticalAlignment.CENTER);
		corrispLabel.setWrap(false);
		corrispLabel.setBorder(corrispListGrid.getBorder());
		corrispLabel.setBackgroundImage("newskins/header.png");
		corrispLabel.setBackgroundRepeat(BackgroundRepeat.REPEAT_X);
		corrispLabel.setContents("Matching entries");


		this.workingArea.addMember(corrispLabel);
		this.workingArea.addMember(corrispListGrid);



		//Toolbar controllo tabella corrispondenze

		// Export button
		exportButton.setTooltip(ClientMessages.export());
		this.exportButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
				RecordList reclistforexport = new RecordList();
				reclistforexport = corrispListGrid.getRecordList();
				if (reclistforexport.getLength() != 0)
					ExportWindow.windowCreator(corrispListGrid);
				else
					SC.say("No record to export");
			}
		});

		printButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				VLayout[] v = new VLayout[] { corrispListGrid };

				Canvas.showPrintPreview(v, null, DESCRIPTION, null);
			}
		});


		submitButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {

			public void onClick(
					com.smartgwt.client.widgets.events.ClickEvent event) {

				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}

				else{

					Criteria crit = new Criteria();
					crit.setAttribute("STATUS", "O");

					tctcorrisp.fetchData(crit, new DSCallback() {

						@Override
						public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

							final Record[] recArr = dsResponse.getData();
							String rec = "";

							if(recArr.length==0)
								SC.warn("No runs to submit");
							else{
								if(recArr.length>0){
									rowNum = corrispListGrid.getRecordIndex(recArr[0]);
									if(recArr.length==1)
										rec = recArr[0].getAttributeAsString("RUNID");
									else if(recArr.length>1){
										rec = recArr[0].getAttributeAsString("RUNID");
										for(int i=1;i<recArr.length;i++){
											if(!recArr[i].getAttributeAsString("RUNID").equalsIgnoreCase(recArr[i-1].getAttributeAsString("RUNID")))
												rec += "," +recArr[i].getAttributeAsString("RUNID");
										}
									}
								}

								String confMessage="";

								if(recArr.length==1)
									confMessage="Are you sure you want to submit the analyzed results related to the run id "+rec+" ?";
								else
									confMessage="Are you sure you want to submit the analyzed results related to the run ids "+rec+" ?";

								SC.confirm(confMessage,
										new BooleanCallback() {public void execute(Boolean value) {

											if (value != null && value) {

												//	int totalrows=corrispListGrid.getTotalRows();
												final int[] editrows=corrispListGrid.getAllEditRows();
												//String confMessage="";

												/*if(totalrows==0){

												SC.warn("No rows to submit.");

											}

											else */
												//if(totalrows!=editrows.length){
												//confMessage="There are "+(totalrows-editrows.length)+" rows in Outstanding status. If you submit the form, such rows will be considered as False Positive. Do you want to proceed?";
												//SC.confirm(confMessage,
												//	new BooleanCallback() {public void execute(Boolean value) {

												//if (value != null && value) {

												//	RPCManager.startQueue();

												//if(!corrispListGrid.saveAllEdits()){

												//covering ass manouver
												Criteria crit = new Criteria();
												crit.setAttribute("STATUS", "O");
												//corrispListGrid.fetchData(crit, new DSCallback() {

												//@Override
												//public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

												//final Record[] rec = dsResponse.getData();
												String confMessage="";

												if(recArr.length==0){
													SC.warn("No rows to submit.");
												}

												else /*if(rec.length!=editrows.length)*/{
													confMessage="There are "+(recArr.length-editrows.length)+" rows in Outstanding status. If you submit the form, such rows will be considered as False Positive. Do you want to proceed?";
													SC.confirm(confMessage,
															new BooleanCallback() {public void execute(Boolean value) {

																if (value != null && value) {

																	int rowNum = 0;

																	if(recArr.length>0)
																		rowNum = corrispListGrid.getRecordIndex(recArr[0]);

																	RPCManager.startQueue();

																	if(editrows.length!=0){
																		updateAuditTableWithClientEdit(editrows, recArr);
																	} else {
																		updateAuditTableWithoutClientEdit(recArr);
																	}

																	if(!corrispListGrid.saveAllEdits()){
																		corrispListGrid.setEditValue(rowNum, "STATUS", "F");
																		corrispListGrid.saveAllEdits();
																	}

																	Record r = new Record();  
																	DSRequest req = new DSRequest();
																	req.setAttribute("operationId", "goodJDBCUpdate");  
																	tctrunreg.updateData(r,null, req);

																	Record r1 = new Record();  
																	DSRequest req1 = new DSRequest();
																	req1.setAttribute("operationId", "updateOutstandingCorrisp");  
																	tctcorrisp.updateData(r1, null, req1);  

																	AdvancedCriteria criteria = new AdvancedCriteria();
																	criteria.addCriteria("SUBDATE", OperatorId.IS_NULL);
																	criteria.addCriteria("MATCHFOUND","T");
																	tctrunreg.fetchData(criteria, new DSCallback() {

																		@Override
																		public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
																			// TODO Auto-generated method stub
																			Record[] rec = dsResponse.getData();
																			updateAuditTableSubmitRunReg(rec);
																		}
																	});

																	RPCManager.sendQueue();
																	corrispListGrid.invalidateCache();
																}
															}
													});
												}


												//}
												//});

												//}

												/*Record r = new Record();  
																DSRequest req = new DSRequest();
																req.setAttribute("operationId", "goodJDBCUpdate");  
																tctrunreg.updateData(r,null, req);

																Record r1 = new Record();  
																DSRequest req1 = new DSRequest();
																req1.setAttribute("operationId", "updateOutstandingCorrisp");  
																tctcorrisp.updateData(r1, null, req1);  

																RPCManager.sendQueue();*/

												//	}
												//}
												//});
												//	}
												/*else{

												RPCManager.startQueue();

												if(!corrispListGrid.saveAllEdits()){

													//covering ass manouver
													Criteria crit = new Criteria();
													crit.setAttribute("STATUS", "O");
													corrispListGrid.fetchData(crit, new DSCallback() {

														@Override
														public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

															Record[] rec = dsResponse.getData();
															int rowNum = 0;

															if(rec.length>0)
																rowNum = corrispListGrid.getRecordIndex(rec[0]);

															corrispListGrid.setEditValue(rowNum, "STATUS", "F");
															corrispListGrid.saveAllEdits();

														}
													});
												}

												corrispListGrid.saveAllEdits();
												Record r = new Record();  
												DSRequest req = new DSRequest();  
												req.setAttribute("operationId", "goodJDBCUpdate");  
												tctrunreg.updateData(r, null, req);

												Record r1 = new Record();  
												DSRequest req1 = new DSRequest();  
												req1.setAttribute("operationId", "updateOutstandingCorrisp");  
												tctcorrisp.updateData(r1, null, req1);  

												RPCManager.sendQueue();
											}*/

												/*else{
												//se non � stato fatto alcun cambiamento sui campi in outstanding della tabella
												if(!corrispListGrid.saveAllEdits()){
													//SC.say("nessun cambiamento");
													ListGridRecord[] result = corrispListGrid.getRecords();
													//System.out.println("Result: "+result.length);
													int cont =0;
													RPCManager.startQueue();
													for(int i=0;i<result.length;i++){
														System.out.println("Status: "+result[i].getAttributeAsString("STATUS"));
														if(result[i].getAttributeAsString("STATUS").equalsIgnoreCase("O")){
															//automaticamente tutti gli outstanding diventano false positive
															result[i].setAttribute("STATUS", "F");
															cont++;
															corrispListGrid.updateData(result[i]);
														}
													}

													if(cont==0)
														//se non ci sono record in outstanding nessun salvataggio viene eseguito
														SC.say("No outstanding record to submit");

													else{

														Record r = new Record();  
														r.setAttribute("compid", Privileges.getCompanyID()); 
														DSRequest req = new DSRequest();  
														req.setAttribute("operationId", "goodJDBCUpdate");  
														activityLogDS.updateData(r, null, req);

														RPCManager.sendQueue();
													}
												}
												//se invece sono stati fatti dei cambiamenti nella tabella
												else{
													ListGridRecord[] result = corrispListGrid.getRecords();

													RPCManager.startQueue();
													//salvo come prima cosa ci� che ho cambiato 
													corrispListGrid.saveAllEdits();

													RPCManager.sendQueue();

												}
											}*/
											}

										}
								});
							}
						}
					});

				}

			}

		});

		//termino il salvataggio dei cambiamenti effettuati sulla tabella
		/*corrispListGrid.addEditCompleteHandler(new EditCompleteHandler() {

			@Override
			public void onEditComplete(EditCompleteEvent event) {

				ListGridRecord[] result = corrispListGrid.getRecords();
				RPCManager.startQueue();

				for(int i=0;i<result.length;i++){
					if(result[i].getAttributeAsString("STATUS").equalsIgnoreCase("O")){
						result[i].setAttribute("STATUS", "F");
						//ogni outstanding diventa false positive
						corrispListGrid.updateData(result[i]);
					}
				}

				Record r = new Record();  
				r.setAttribute("compid", Privileges.getCompanyID()); 
				DSRequest req = new DSRequest();  
				req.setAttribute("operationId", "goodJDBCUpdate");  
				activityLogDS.updateData(r, null, req);

				RPCManager.sendQueue();
			}
		});*/


		corrispListControlBar.addMember(submitButton);
		corrispListControlBar.addMember(exportButton);
		corrispListControlBar.addMember(printButton);
		this.workingArea.addMember(corrispListControlBar);



		//Working area
		this.addMember(workingArea);


	}

	public void updateAuditTableSubmitRunReg(Record[] recArr){

		for(int i=0;i<recArr.length;i++){
			Record rec = recArr[i];
			String[] fieldnames = tctrunreg.getFieldNames();
			String newRecordStr = "";
			int runid = rec.getAttributeAsInt("RUNID");
			Date date=new Date();
			for(int w=0;w<fieldnames.length;w++){
				if(fieldnames[w].compareToIgnoreCase("UPDDATE")==0){
					newRecordStr+=fieldnames[w]+": "+date+" | ";
				} else if(fieldnames[w].compareToIgnoreCase("CMPNID")==0){
					newRecordStr+="";
				} else if(fieldnames[w].compareToIgnoreCase("UPDUSER")==0){
					newRecordStr+=fieldnames[w]+": "+Privileges.getUsername()+" | ";
				} else{
					if(rec.getAttributeAsString(fieldnames[w])==null)
						newRecordStr+=fieldnames[w]+":  | ";
					else
						newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
				}
			}

			Record usrActRecord = new Record();

			usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctrunreg_update");
			usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
			usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
			usrActRecord.setAttribute("NEWRECORD", newRecordStr);
//			usrActRecord.setAttribute("CMPNID", Privileges.getCompanyID());
			usrActRecord.setAttribute("RUNID", runid);

			tctusract.addData(usrActRecord);

		}

	}

	public void updateAuditTableWithClientEdit(int[] editrows, Record[] recArr){
		for(int j=0;j<editrows.length;j++){
			int editedRowNum=editrows[j];
			for(int i=0;i<recArr.length;i++){
				if( i!=editedRowNum){
					Record rec = recArr[i];
					String[] fieldnames = tctcorrisp.getFieldNames();
					String oldRecordStr = "";
					String newRecordStr = "";
					int runid = rec.getAttributeAsInt("RUNID");
					Date date=new Date();
					for(int w=0;w<fieldnames.length;w++){
						//newValuesStr+= fieldName+": "+newValuesmap.get(fieldName)+" | ";
						oldRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
						if(fieldnames[w].compareToIgnoreCase("UPDDATE")==0){
							newRecordStr+=fieldnames[w]+": "+date+" | ";
						} else if(fieldnames[w].compareToIgnoreCase("CMPNID")==0){
							newRecordStr+="";
						} else if(fieldnames[w].compareToIgnoreCase("STATUS")==0){
							newRecordStr+=fieldnames[w]+": "+"F"+" | ";
						} else if(fieldnames[w].compareToIgnoreCase("UPDUSER")==0){
							newRecordStr+=fieldnames[w]+": "+Privileges.getUsername()+" | ";
						} else{
							if(rec.getAttributeAsString(fieldnames[w])==null)
								newRecordStr+=fieldnames[w]+":  | ";
							else
								newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
						}
					}

					Record usrActRecord = new Record();

					usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctcorrisp_update");
					usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
					usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
					/*usrActRecord.setAttribute("OLDRECORD", oldRecordStr);*/
					usrActRecord.setAttribute("NEWRECORD", newRecordStr);
//					usrActRecord.setAttribute("CMPNID", Privileges.getCompanyID());
					usrActRecord.setAttribute("RUNID", runid);

					tctusract.addData(usrActRecord);


				}


			}
		}
	}

	public void updateAuditTableWithoutClientEdit(Record[] recArr){

		for(int i=0;i<recArr.length;i++){
			Record rec = recArr[i];
			String[] fieldnames = tctcorrisp.getFieldNames();
			String oldRecordStr = "";
			String newRecordStr = "";
			int runid = rec.getAttributeAsInt("RUNID");
			Date date=new Date();
			for(int w=0;w<fieldnames.length;w++){
				//newValuesStr+= fieldName+": "+newValuesmap.get(fieldName)+" | ";
				oldRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
				if(fieldnames[w].compareToIgnoreCase("UPDDATE")==0){
					newRecordStr+=fieldnames[w]+": "+date+" | ";
				} else if(fieldnames[w].compareToIgnoreCase("CMPNID")==0){
					newRecordStr+="";
				} else if(fieldnames[w].compareToIgnoreCase("STATUS")==0){
					newRecordStr+=fieldnames[w]+": "+"F"+" | ";
				} else if(fieldnames[w].compareToIgnoreCase("UPDUSER")==0){
					newRecordStr+=fieldnames[w]+": "+Privileges.getUsername()+" | ";
				} else{
					if(rec.getAttributeAsString(fieldnames[w])==null)
						newRecordStr+=fieldnames[w]+":  | ";
					else
						newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
				}
			}

			Record usrActRecord = new Record();

			usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctcorrisp_update");
			usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
			usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
			/*	usrActRecord.setAttribute("OLDRECORD", oldRecordStr);*/
			usrActRecord.setAttribute("NEWRECORD", newRecordStr);
//			usrActRecord.setAttribute("CMPNID", Privileges.getCompanyID());
			usrActRecord.setAttribute("RUNID", runid);

			tctusract.addData(usrActRecord);


		}

	}



	//Factory
	public static class Factory implements PanelFactory {
		private String id;
		public Canvas create(TabSet mainTabSet, String panelID) {
			MatchingEntriesPanel panel = new MatchingEntriesPanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

		public String getID() {
			return id;
		}

		public String getDescription() {
			return null;
		}

		public Canvas create(TabSet mainTabSet, String panelID, int instrid, String instrname) {
			MatchingEntriesPanel panel = new MatchingEntriesPanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

	}


	@Override
	public void refresh() {
		/*	mainGrid.invalidateCache();
		if (ADVF.equals(advancedButton.getTitle())) {
			showData();
		}
		else {
			mainGrid.filterData(filterBuilder.getCriteria());
		}
		 */

	}


	// Context menu
	private Menu createContextMenu() {
		Menu menu = new Menu();
		menu.setWidth(140);



		// Set selection ad False Positive menu item
		MenuItem setSelASFalsePosItem = new MenuItem("Set as false positive");
		setSelASFalsePosItem.setEnableIfCondition(new MenuItemIfFunction() {
			public boolean execute(Canvas target, Menu menu, MenuItem item) {
				// Recupero i record selezionati
				ListGridRecord[] recordList = ((ListGrid) target).getSelectedRecords();
				// inizializzo l'utente di default
				requestedRoles = new String[] { "user"};
				// Se � stato selezionato almeno un record e l'utente ha i
				// permessi necessari
				// il menu viene abilitato
				int cont =0;
				if (recordList.length > 0
						& Privileges.hasPrivileges(requestedRoles)) {
					for(ListGridRecord lgr:recordList){
						if(lgr.getAttributeAsString("STATUS").equalsIgnoreCase("O"))
							cont++;
					}
					if(cont!=recordList.length)
						return false;
					else
						return true;
				}
				return false;
			}
		});

		// Mette la s del plurale
		setSelASFalsePosItem
		.setDynamicTitleFunction(new com.smartgwt.client.widgets.menu.MenuItemStringFunction() {
			public String execute(Canvas target, Menu menu,
					MenuItem item) {
				// Recupero i record selezionati
				ListGridRecord[] recordList = ((ListGrid) target).getSelectedRecords();

				if (recordList.length > 1)
					return ("Set selected rows as False Positive");
				else
					return ("Set as False Positive");
			}
		});

		// Aggiunge il click handler
		setSelASFalsePosItem
		.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				// Se il sistema � nello stato di working viene lanciato
				// un mess di notifica
				if (Privileges.isWorking()) {
					SC.say("The system is currently busy");
					return;
				}

				// Recupero i record selezionati
				ListGridRecord[] recordList = corrispListGrid.getSelectedRecords();

				for(ListGridRecord lgr:recordList){

					int row=corrispListGrid.getRecordIndex(lgr);

					corrispListGrid.setEditValue(row, "STATUS", "F");

				}
				//corrispListGrid.refreshFields();
				//corrispListGrid.removeSelectedData();
			}
		});

		// Set selection ad False Positive menu item
		MenuItem setSelASPosMatchItem = new MenuItem("Set as Positive Match");
		setSelASPosMatchItem.setEnableIfCondition(new MenuItemIfFunction() {
			public boolean execute(Canvas target, Menu menu, MenuItem item) {
				// Recupero i record selezionati
				ListGridRecord[] recordList = ((ListGrid) target).getSelectedRecords();
				// inizializzo l'utente di default
				requestedRoles = new String[] { "user"};
				// Se � stato selezionato almeno un recor e l'utente ha i
				// permessi necessari
				// il menu viene abilitato
				int cont =0;
				if (recordList.length > 0
						& Privileges.hasPrivileges(requestedRoles)) {
					for(ListGridRecord lgr:recordList){
						if(lgr.getAttributeAsString("STATUS").equalsIgnoreCase("O"))
							cont++;
					}
					if(cont!=recordList.length)
						return false;
					else
						return true;
				}
				return false;
			}
		});

		// Mette la s del plurale
		setSelASPosMatchItem
		.setDynamicTitleFunction(new com.smartgwt.client.widgets.menu.MenuItemStringFunction() {
			public String execute(Canvas target, Menu menu,
					MenuItem item) {
				// Recupero i record selezionati
				ListGridRecord[] recordList = ((ListGrid) target).getSelectedRecords();

				if (recordList.length > 1)
					return ("Set selected rows as Positive Matches");
				else
					return ("Set as Positive Match");
			}
		});

		// Aggiunge il click handler
		setSelASPosMatchItem
		.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				// Se il sistema � nello stato di working viene lanciato
				// un mess di notifica
				if (Privileges.isWorking()) {
					SC.say("The system is currently busy");
					return;
				}

				// Recupero i record selezionati
				ListGridRecord[] recordList = corrispListGrid.getSelectedRecords();






				for(ListGridRecord lgr:recordList){

					int row=corrispListGrid.getRecordIndex(lgr);

					corrispListGrid.setEditValue(row, "STATUS", "P");

				}
				//corrispListGrid.refreshFields();
				//corrispListGrid.removeSelectedData();
			}
		});

		/*String operationId = "pmptinstr_update_all_eq";
		SecureMultiUpdateMenuItem multipleUpdateItem = new SecureMultiUpdateMenuItem(operationId,"enableCA");*/

		String name ="";
		ListGridRecord lgr = corrispListGrid.getSelectedRecord();
		if(lgr!=null)
			name = lgr.getAttributeAsString("CLNTID");


		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);
		TextifyMenuItem textItem = new TextifyMenuItem();
		MenuItemSeparator separator = new MenuItemSeparator();

		menu.addItem(viewDetItem);
		menu.addItem(textItem);
		menu.addItem(separator);
		menu.addItem(setSelASFalsePosItem);
		menu.addItem(setSelASPosMatchItem);

		return menu;
	}








}