package it.ccg.tcfrontend.client.panels;

import java.util.Date;

import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardListGrid;
import it.ccg.tcfrontend.client.security.Privileges;

import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.ButtonItem;
import com.smartgwt.client.widgets.form.fields.FileItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.grid.CellFormatter;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;

public class UploadFileWindow extends Window{

	String winId=this.getID();
	protected VLayout workingArea = new VLayout();
	final DataSource tctuplf = DataSource.get("tctuplf");	
	final DataSource tctusract = DataSource.get("tctusract");	

	public UploadFileWindow(final int runId, final StandardListGrid activityLogListGrid){

		super();
		this.setID("UploadFileWindow");
		this.setTitle("Upload file");//- Run: " + runId);
		this.setWidth(350);
		this.setHeight(180);
		this.setCanDragReposition(true);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);
		//this.setMembersMargin(3);
		this.centerInPage();


		final Window me = this;

		final DynamicForm uploadForm = new DynamicForm();  
		uploadForm.setDataSource(tctuplf); 
		uploadForm.setHeight100();  
		uploadForm.setWidth("80%");  
		//uploadForm.setLayoutAlign(VerticalAlignment.BOTTOM); 
		//uploadForm.setWidth("70%");  
		//uploadForm.setHeight("80%");

		final TextItem idEditItem = new TextItem("RUNID");
		//idEditItem.setWidth(150);  
		idEditItem.setCanEdit(false);
		idEditItem.setValue(runId);
		//idEditItem.setVisible(false);

		/*final TextItem userItem = new TextItem("UPDUSR");
		userItem.setHeight(0);  
		userItem.setCanEdit(false);
		userItem.setValue(Privileges.getUsername());
		userItem.setVisible(false);*/

		FileItem fileItem = new FileItem("UPLFILE");  
		//fileItem.setHint("Maximum file-size is ");  
		fileItem.setRequired(true);  

		IButton saveItem = new IButton("OK");
		//saveItem.setAlign(Alignment.CENTER);


		saveItem.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				
				if(!uploadForm.validate()) {
					return;
				}
				if (!uploadForm.hasErrors()) {  
					uploadForm.saveData(new com.smartgwt.client.data.DSCallback() {  
						public void execute(DSResponse response, Object data, DSRequest request) {  
							uploadForm.editNewRecord();

							Record[] rec = response.getData();
							updateAuditTableUploadFile(rec[0]);

							tctuplf.fetchData(null, new DSCallback() {

								@Override
								public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
									// TODO Auto-generated method stub
									final Record[] recs = dsResponse.getData();


									activityLogListGrid.getField("UPLOAD").setCellFormatter(new CellFormatter() {

										@Override
										public String format(Object value, ListGridRecord record, int rowNum,
												int colNum) {

											final Criteria crit = new Criteria();
											crit.setAttribute("RUNID", record.getAttribute("RUNID"));

											int elem =0;
											for(int i=0;i<recs.length;i++){
												if(recs[i].getAttribute("RUNID").equalsIgnoreCase(record.getAttribute("RUNID"))){
													elem++;
												}
											}

											return  elem + Canvas.imgHTML("up2.png",16,16);
										}
									});



								}
							});

							activityLogListGrid.invalidateCache();
							me.destroy();

						}  
					});  
				}
			}

		});

		IButton cancelButton = new IButton("Cancel");
		cancelButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				me.destroy();
			}
		});

		uploadForm.setFields(idEditItem, fileItem/*, userItem*/);

		HLayout hLayoutButtons = new HLayout();  
		hLayoutButtons.setWidth(300);  
		LayoutSpacer ls = new LayoutSpacer();
		ls.setWidth(50);
		hLayoutButtons.setLayoutMargin(10);  
		hLayoutButtons.setMembersMargin(10);  
		hLayoutButtons.addMembers(ls, saveItem, cancelButton);

		LayoutSpacer ls1 = new LayoutSpacer();
		ls1.setHeight(10);

		workingArea.addMembers(ls1, uploadForm, hLayoutButtons);

		//        workingArea.addMember(hLayoutButtons);

		this.addItem(workingArea);

		this.draw();

		this.addCloseClickHandler(new CloseClickHandler() {

			@Override
			public void onCloseClick(CloseClickEvent event) {
				me.destroy();

			}
		});
	}

	public void updateAuditTableUploadFile(Record rec){

		String[] fieldnames = tctuplf.getFieldNames();
		String newRecordStr = "";
		int runid = rec.getAttributeAsInt("RUNID");
		/*Date date=new Date();

		for(int w=0;w<fieldnames.length;w++){
			if(fieldnames[w].compareToIgnoreCase("APPROVER")==0){
				newRecordStr+=fieldnames[w]+": | ";
			} else if(fieldnames[w].compareToIgnoreCase("APPROVED")==0){
				newRecordStr+=fieldnames[w]+": 'F' | ";
			} else if(fieldnames[w].compareToIgnoreCase("UPDDATE")==0){
				newRecordStr+=fieldnames[w]+": "+date+" | ";
			} else if(fieldnames[w].compareToIgnoreCase("UPDUSER")==0){
				newRecordStr+=fieldnames[w]+": "+Privileges.getUsername()+" | ";
			} else newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
		}*/
		
		for(int w=0;w<fieldnames.length;w++){
			if(rec.getAttributeAsString(fieldnames[w])==null)
				newRecordStr+=fieldnames[w]+":  | ";
			else
				newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
		}

		Record usrActRecord = new Record();

		usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctuplf_add");
		usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
		usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
		usrActRecord.setAttribute("NEWRECORD",newRecordStr);
//		usrActRecord.setAttribute("CMPNID", Privileges.getCompanyID());
		usrActRecord.setAttribute("RUNID", runid);

		tctusract.addData(usrActRecord);

	}

	public static UploadFileWindow windowCreator(int runId,StandardListGrid activityLogListGrid) {

		UploadFileWindow mw = (UploadFileWindow) Canvas.getById("UploadFileWindow");
		if (mw != null) {
			mw.setVisible(true);
			mw.restore();
			mw.bringToFront();
			return mw;
		} else {
			return new UploadFileWindow(runId, activityLogListGrid);

		}

	}
}