package it.ccg.tcfrontend.client.panels;

import java.util.Date;

import it.ccg.tcfrontend.client.HelpWindow;
import it.ccg.tcfrontend.client.ManageScheduleWindow;
import it.ccg.tcfrontend.client.PanelFactory;
import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardControlBar;
import it.ccg.tcfrontend.client.interf.Refreshable;
import it.ccg.tcfrontend.client.menu.TextifyMenuItem;
import it.ccg.tcfrontend.client.menu.ViewDetailsMenuItem;
import it.ccg.tcfrontend.client.security.Privileges;

import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.BackgroundRepeat;
import com.smartgwt.client.types.Cursor;
import com.smartgwt.client.types.SelectionStyle;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.MouseOutEvent;
import com.smartgwt.client.widgets.events.MouseOutHandler;
import com.smartgwt.client.widgets.events.MouseOverEvent;
import com.smartgwt.client.widgets.events.MouseOverHandler;
import com.smartgwt.client.widgets.grid.CellFormatter;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.tab.TabSet;

public class SchedulerPanel extends VLayout implements Refreshable{

	final protected  TabSet mainTabSet;

	protected StandardControlBar topControlBar = new StandardControlBar();
	protected StandardControlBar bottomControlBar = new StandardControlBar();
	protected VLayout workingArea = new VLayout();

	private ListGrid mainGrid = new ListGrid();


//	final protected StandardButton startButton = new StandardButton("Start Immediately","SCHEDULER001");
	final protected StandardButton actSchedButton = new StandardButton("Create Schedule","SCHEDULER001");
	final protected StandardButton deactSchedButton = new StandardButton("Remove Schedule","SCHEDULER002");

	//Definizione datasource dello scheduler
	final DataSource tctscheduler=SecureDS.get("tctscheduler");
	final DataSource tctusract=SecureDS.get("tctusract");
	
	public SchedulerPanel(final TabSet mainTabSet, String panelID) {
		super();

		this.mainTabSet=mainTabSet;

		mainGrid.setDataSource(tctscheduler);
		mainGrid.setWidth100();
		mainGrid.setHeight100();
		mainGrid.setShowFilterEditor(true);
		mainGrid.setFilterOnKeypress(false);
		mainGrid.setAutoFetchData(true);
		mainGrid.setSelectionType(SelectionStyle.SINGLE);
		mainGrid.setFetchOperation("fetch");
		mainGrid.setUpdateOperation("update");
		mainGrid.setRemoveOperation("remove");
		mainGrid.setContextMenu(createContextMenu());

		
		/*// set interval field format
		ListGridField intervalLGField = schedListGrid.getField("interval");
		intervalLGField.setCellFormatter(new CellFormatter() {

			@Override
			public String format(Object value, ListGridRecord record, int rowNum, int colNum) {

				String formattedValue = new String();

				if(value != null) {
					long intervalInMillis = Long.parseLong(value.toString());
					long days = intervalInMillis / (24*60*60*1000);
					long hours = ((intervalInMillis - days * (24*60*60*1000)))/(60*60*1000);
					long minutes = ((intervalInMillis - days * (24*60*60*1000) - hours * (60*60*1000)))/(60*1000);

					formattedValue = days + "d-" + hours + "h-" + minutes + "m";
				}
				return formattedValue;
			}

		});*/
		
		//Refresh button
		final Label refresh = new Label();  
		refresh.setHeight(30);  
		refresh.setPadding(10);  
		refresh.setAlign(Alignment.CENTER);  
		refresh.setValign(VerticalAlignment.CENTER);  
		refresh.setWrap(false);  
		refresh.setIcon("icons/24/refresh.png");  
		refresh.setCanHover(true);
		refresh.setShowHover(false);

		refresh.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				refresh.setOpacity(50);
				refresh.setCursor(Cursor.POINTER);
			}
		});


		refresh.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				refresh.setOpacity(100);
				refresh.setCursor(Cursor.DEFAULT);
			}
		});

		refresh.setContents("<i>Refresh</i>");  

		refresh.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				mainGrid.invalidateCache();

			}
		});


		LayoutSpacer lstop = new LayoutSpacer();
		topControlBar.addMember(lstop);

		topControlBar.addMember(refresh);

		final Label helpLabel = new Label();  
		helpLabel.setHeight(30);  
		helpLabel.setPadding(10);  
		helpLabel.setAlign(Alignment.CENTER);  
		helpLabel.setValign(VerticalAlignment.CENTER);  
		helpLabel.setWrap(false);  
		helpLabel.setIcon("icons/24/help24.png");  
		helpLabel.setCanHover(true);
		helpLabel.setShowHover(false);

		helpLabel.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				helpLabel.setOpacity(50);
				helpLabel.setCursor(Cursor.POINTER);
			}
		});


		helpLabel.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				helpLabel.setOpacity(100);
				helpLabel.setCursor(Cursor.DEFAULT);
			}
		});


		//refresh.setShowEdges(true);  
		helpLabel.setContents("<i>Help</i>");  

		helpLabel.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				HelpWindow.windowCreator2(mainTabSet, "");

			}
		});

		topControlBar.addMember(helpLabel);

		this.addMember(topControlBar);

		
		deactSchedButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				String[] userRoles=Privileges.getUserRoles();
				String userRolesStr="";
				if(userRoles.length!=0){
					userRolesStr = userRoles[0];
					if(userRoles.length>1){
						for(int i=1;i<userRoles.length;i++){
							userRolesStr+=","+userRoles[i];
						}
					}
				}

				if(mainGrid.getSelectedRecord() == null) {
					SC.warn("Please select a schedule to delete.");
					return;
				} if(mainGrid.getSelectedRecord().getAttributeAsString("methodName").compareToIgnoreCase("startTerroristDataFlow")==0 && !userRolesStr.contains("admin") && userRolesStr.equalsIgnoreCase("user")){
					SC.warn("You can not remove the selected schedule.");
					return;
				} if(mainGrid.getSelectedRecord().getAttributeAsString("methodName").compareToIgnoreCase("startFindMatch")==0 && userRolesStr.equalsIgnoreCase("admin")){
					SC.warn("You can not remove the selected schedule.");
					return;
				}

				SC.confirm("Are you sure you want to delete the selected schedule? "/*+ userRolesStr*/, new BooleanCallback() {
					@Override
					public void execute(Boolean value) {
						if(value) {
							final Record rec = mainGrid.getSelectedRecord();
							mainGrid.removeData(rec, new DSCallback() {
								
								@Override
								public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {

									String[] fieldnames = tctscheduler.getFieldNames();
									String newRecordStr = "";
									
									for(int w=0;w<fieldnames.length;w++){
										if(fieldnames[w].compareToIgnoreCase("companyId")==0)
											newRecordStr+="";
										else{
											if(rec.getAttributeAsString(fieldnames[w])==null)
												newRecordStr+=fieldnames[w]+":  | ";
											else
												newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
										}
									}
									
									Record usrActRecord = new Record();

									usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctscheduler_delete");
									usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
									usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
									usrActRecord.setAttribute("NEWRECORD", newRecordStr);
									usrActRecord.setAttribute("RUNID", -1);
									
									tctusract.addData(usrActRecord);
									
									mainGrid.invalidateCache();
									mainGrid.fetchData();
								}
							});
						}
					}
				});
			}
		});



		//Activate schedule window
		actSchedButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				ManageScheduleWindow.windowCreator(mainGrid);
				
			}
		});

		//**************************


		// Definizione label
		Label schedulerLabel= new Label();

		schedulerLabel.setHeight(10);
		schedulerLabel.setWidth100();
		schedulerLabel.setPadding(4);
		schedulerLabel.setAlign(Alignment.LEFT);
		schedulerLabel.setValign(VerticalAlignment.CENTER);
		schedulerLabel.setWrap(false);
		schedulerLabel.setBorder(mainGrid.getBorder());
		schedulerLabel.setBackgroundImage("newskins/header.png");
		schedulerLabel.setBackgroundRepeat(BackgroundRepeat.REPEAT_X);
		schedulerLabel.setContents("Scheduler");


		this.workingArea.addMember(schedulerLabel);
		this.workingArea.addMember(mainGrid);

//		bottomControlBar.addMember(startButton);
		bottomControlBar.addMember(actSchedButton);
		bottomControlBar.addMember(deactSchedButton);
		this.workingArea.addMember(bottomControlBar);

		//Working area
		this.addMember(workingArea);

	}

	
	// Context menu 
	private Menu createContextMenu() {
		Menu menu = new Menu();
		menu.setWidth(140);

		String name ="";

		//View Details
		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);

		//Textify Selection
		TextifyMenuItem textItem = new TextifyMenuItem();

		menu.setItems(viewDetItem,textItem);

		return menu;
	}

	//Factory
	public static class Factory implements PanelFactory {
		private String id;
		public Canvas create(TabSet mainTabSet, String panelID) {
			SchedulerPanel panel = new SchedulerPanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

		public String getID() {
			return id;
		}

		public String getDescription() {
			return null;
		}

		public Canvas create(TabSet mainTabSet, String panelID, int instrid, String instrname) {
			SchedulerPanel panel = new SchedulerPanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

	}
	//Refresh
	@Override
	public void refresh() {
		mainGrid.invalidateCache();
	}
	
}