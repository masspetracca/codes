package it.ccg.tcfrontend.client.panels;

import it.ccg.tcfrontend.client.ExportWindow;
import it.ccg.tcfrontend.client.HelpWindow;
import it.ccg.tcfrontend.client.PanelFactory;
import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.SecureDoubleClick;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardControlBar;
import it.ccg.tcfrontend.client.controls.StandardListGrid;
import it.ccg.tcfrontend.client.controls.StandardMenuItem;
import it.ccg.tcfrontend.client.interf.Refreshable;
import it.ccg.tcfrontend.client.menu.TextifyMenuItem;
import it.ccg.tcfrontend.client.menu.ViewDetailsMenuItem;
import it.ccg.tcfrontend.client.security.Privileges;
import it.ccg.tcfrontend.client.utils.ClientMessages;

import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.RecordList;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.BackgroundRepeat;
import com.smartgwt.client.types.Cursor;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.MouseOutEvent;
import com.smartgwt.client.widgets.events.MouseOutHandler;
import com.smartgwt.client.widgets.events.MouseOverEvent;
import com.smartgwt.client.widgets.events.MouseOverHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickHandler;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.MenuItemIfFunction;
import com.smartgwt.client.widgets.menu.MenuItemSeparator;
import com.smartgwt.client.widgets.menu.events.MenuItemClickEvent;
import com.smartgwt.client.widgets.tab.TabSet;

public class ClientStaticDataPanel extends VLayout implements Refreshable{

	final protected  TabSet mainTabSet;
	protected StandardControlBar topControlBar = new StandardControlBar();
	protected StandardControlBar clientListControlBar = new StandardControlBar();
	protected VLayout workingArea = new VLayout();

	private static final String DESCRIPTION = "List of clients";


	final protected StandardButton saveButton = new StandardButton("Save", "CLIENTDATA001");
	final protected StandardButton exportButton = new StandardButton("Export");
	final protected StandardButton printButton = new StandardButton("Print");

	private StandardListGrid clientListGrid;

	//private String[] requestedRoles = new String[] { "user" };

	public ClientStaticDataPanel(final TabSet mainTabSet, String panelID) {
		super();

		this.mainTabSet=mainTabSet;

		//REFRESH LABEL
		final Label refresh = new Label();  
		refresh.setHeight(30);  
		refresh.setPadding(10);  
		refresh.setAlign(Alignment.CENTER);  
		refresh.setValign(VerticalAlignment.CENTER);  
		refresh.setWrap(false);  
		refresh.setIcon("icons/24/refresh.png");  
		refresh.setCanHover(true);
		refresh.setShowHover(false);

		refresh.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				refresh.setOpacity(50);
				refresh.setCursor(Cursor.POINTER);
			}
		});


		refresh.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				refresh.setOpacity(100);
				refresh.setCursor(Cursor.DEFAULT);
			}
		});


		refresh.setContents("<i>Refresh</i>");  

		refresh.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				clientListGrid.invalidateCache();

			}
		});


		LayoutSpacer lstop = new LayoutSpacer();
		topControlBar.addMember(lstop);

		topControlBar.addMember(refresh);

		//HELP LABEL
		final Label helpLabel = new Label();  
		helpLabel.setHeight(30);  
		helpLabel.setPadding(10);  
		helpLabel.setAlign(Alignment.CENTER);  
		helpLabel.setValign(VerticalAlignment.CENTER);  
		helpLabel.setWrap(false);  
		helpLabel.setIcon("icons/24/help24.png");  
		helpLabel.setCanHover(true);
		helpLabel.setShowHover(false);

		helpLabel.addMouseOverHandler(new MouseOverHandler() {

			@Override
			public void onMouseOver(MouseOverEvent event) {
				helpLabel.setOpacity(50);
				helpLabel.setCursor(Cursor.POINTER);
			}
		});


		helpLabel.addMouseOutHandler(new MouseOutHandler() {

			@Override
			public void onMouseOut(MouseOutEvent event) {
				helpLabel.setOpacity(100);
				helpLabel.setCursor(Cursor.DEFAULT);
			}
		});


		helpLabel.setContents("<i>Help</i>");  

		helpLabel.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				HelpWindow.windowCreator2(mainTabSet, "");

			}
		});

		topControlBar.addMember(helpLabel);

		this.addMember(topControlBar);

		// DataSource utilizzato per la tabella della lista dei clienti
		final DataSource tctClientStatDatDS = SecureDS.get("tctclient");

		clientListGrid= new StandardListGrid(panelID);
		clientListGrid.setDataSource(tctClientStatDatDS);
		clientListGrid.setWidth100();
		clientListGrid.setHeight100();
		clientListGrid.setShowFilterEditor(true);
		clientListGrid.setFilterOnKeypress(false);
		clientListGrid.setCanEdit(false);
		clientListGrid.setAutoFetchData(true);
		clientListGrid.setAutoSaveEdits(false);		
		clientListGrid.setCanHover(true);
		clientListGrid.setShowHover(false);
		clientListGrid.setContextMenu(createContextMenu());
			
		clientListGrid.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}
				try {
						SecureDoubleClick.secureDoubleClickRecord(event, clientListGrid, "CLIENTDATAB001");
						
				} catch (Exception e) {
				}
			}
		});	
		

		// Definizione label
		Label clientLabel= new Label();

		clientLabel.setHeight(10);
		clientLabel.setWidth100();
		clientLabel.setPadding(4);
		clientLabel.setAlign(Alignment.LEFT);
		clientLabel.setValign(VerticalAlignment.CENTER);
		clientLabel.setWrap(false);
		clientLabel.setBorder(clientListGrid.getBorder());
		clientLabel.setBackgroundImage("newskins/header.png");
		clientLabel.setBackgroundRepeat(BackgroundRepeat.REPEAT_X);
		clientLabel.setContents("List of clients");


		this.workingArea.addMember(clientLabel);
		this.workingArea.addMember(clientListGrid);


		//Toolbar controllo tabella corrispondenze

		//Save button
		saveButton.setTooltip(ClientMessages.save());

		saveButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
			public void onClick(
					com.smartgwt.client.widgets.events.ClickEvent event) {

				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}
				else{
					String confMessage="Are you sure you want to save all the edits?";

					SC.confirm(confMessage,
							new BooleanCallback() {public void execute(Boolean value) {

								if (value != null && value) 

									clientListGrid.saveAllEdits();
							}});
				}}
		});


		// Export button
		exportButton.setTooltip(ClientMessages.export());
		this.exportButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
				RecordList reclistforexport = new RecordList();
				reclistforexport = clientListGrid.getRecordList();
				if (reclistforexport.getLength() != 0)
					ExportWindow.windowCreator(clientListGrid);
				else
					SC.say("No record to export");
			}
		});

		//Print button
		printButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				VLayout[] v = new VLayout[] { clientListGrid };

				Canvas.showPrintPreview(v, null, DESCRIPTION, null);
			}
		});


		clientListControlBar.addMember(saveButton);
		clientListControlBar.addMember(exportButton);
		clientListControlBar.addMember(printButton);
		this.workingArea.addMember(clientListControlBar);

		//Working area
		this.addMember(workingArea);
	}



	//Factory
	public static class Factory implements PanelFactory {
		private String id;
		public Canvas create(TabSet mainTabSet, String panelID) {
			ClientStaticDataPanel panel = new ClientStaticDataPanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

		public String getID() {
			return id;
		}

		public String getDescription() {
			return null;
		}

		public Canvas create(TabSet mainTabSet, String panelID, int instrid, String instrname) {
			ClientStaticDataPanel panel = new ClientStaticDataPanel(mainTabSet, panelID);
			id = panel.getID();
			return panel;
		}

	}

	// Context menu
	private Menu createContextMenu() {
		Menu menu = new Menu();
		menu.setWidth(140);

		String name = "";

		ListGridRecord lgr = clientListGrid.getSelectedRecord();
		if(lgr!=null){
			name = lgr.getAttributeAsString("CLNTNAME");
		}
		//View Details
		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);

		//Textify Selection
		TextifyMenuItem textItem = new TextifyMenuItem();

		//Separatore
		MenuItemSeparator separator = new MenuItemSeparator();
		menu.addItem(separator);

		//Add Item
		StandardMenuItem addItem = new StandardMenuItem("Add as positive match","CLIENTDATA002");
		addItem
		.setEnableIfCondition(new MenuItemIfFunction() {
			public boolean execute(Canvas target, Menu menu, MenuItem item) {
				if (Privileges.isControlON4User("CLIENTDATA002")){
					return true;
				}
				return false;
			}
		});

		// Aggiunge il click handler
		addItem
		.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				// Se il sistema � nello stato di working viene lanciato un mess di notifica
				if (Privileges.isWorking()) {
					SC.say("The system is currently busy");
					return;
				}

				else{
					ListGridRecord[] lgr = clientListGrid.getSelectedRecords();
					for(int i=0;i<lgr.length;i++){

						String clntId = lgr[i].getAttribute("CLNTID");
//						String cmpnId = lgr[i].getAttribute("CMPNID");
//						String param = clntId+","+cmpnId;
						String param = clntId;

						AddFalseNegativeWindow.windowCreator(param);
					}
				}		
			}
		});

		//Manage Item
		StandardMenuItem manageItem = new StandardMenuItem("Manage positive matches...","CLIENTDATA003");
		manageItem
		.setEnableIfCondition(new MenuItemIfFunction() {
			public boolean execute(Canvas target, Menu menu, MenuItem item) {
				if (Privileges.isControlON4User("CLIENTDATA003")){
					return true;
				}
				return false;
			}
		});

		// Aggiunge il click handler
		manageItem
		.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				// Se il sistema � nello stato di working viene lanciato un mess di notifica
				if (Privileges.isWorking()) {
					SC.say("The system is currently busy");
					return;
				}

				else{
					ManageFalseNegativeWindow.windowCreator();
				}		
			}
		});
		/*
		 * TN_CCG16508
		 */
		menu.setItems(viewDetItem,textItem,separator,addItem,manageItem);

		return menu;
	}

	@Override
	public void refresh() {
		// TODO Auto-generated method stub

	}

}

