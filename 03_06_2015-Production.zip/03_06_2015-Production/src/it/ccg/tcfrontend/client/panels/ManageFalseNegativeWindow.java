package it.ccg.tcfrontend.client.panels;

import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.StandardControlBar;
import it.ccg.tcfrontend.client.controls.StandardListGrid;
import it.ccg.tcfrontend.client.security.Privileges;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.types.AnimationEffect;
import com.smartgwt.client.types.OperatorId;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.events.DoubleClickEvent;
import com.smartgwt.client.widgets.events.DoubleClickHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.MenuItemIfFunction;

public class ManageFalseNegativeWindow extends Window{

	String winId=this.getID();
	protected VLayout workingArea = new VLayout();
	//protected StandardControlBar bottomArea = new StandardControlBar();
	
	//final protected StandardButton newRowButton = new StandardButton("New Row");
	//final protected StandardButton deleteRowButton = new StandardButton("Delete Row"); 

	private StandardListGrid tctfnegativGrid;

	public ManageFalseNegativeWindow(){

		super();
		this.setID("ManageFalseNegativeWindow");
		this.setTitle("Manage positive match");
		this.setWidth(600);
		this.setHeight(350);
		this.setCanDragReposition(true);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);
		this.setMembersMargin(3);
		this.centerInPage();

		tctfnegativGrid = new StandardListGrid("Audit");
		//DataSource utilizzato 
		final DataSource tctfalnegtDS = SecureDS.get("tctfalnegt");

		tctfnegativGrid.setDataSource(tctfalnegtDS);
		tctfnegativGrid.setWidth100();
		tctfnegativGrid.setHeight100();
		Criteria crit = new Criteria();
		crit.addCriteria("STATUS", "F");
		tctfnegativGrid.setInitialCriteria(crit);
		tctfnegativGrid.setShowFilterEditor(true);
		tctfnegativGrid.setFilterOnKeypress(false);
		tctfnegativGrid.setCanEdit(true);
		tctfnegativGrid.setMargin(5);
		tctfnegativGrid.setAutoSaveEdits(true);
		tctfnegativGrid.setAutoFetchData(true);
		tctfnegativGrid.addDoubleClickHandler(new DoubleClickHandler() {
			
			@Override
			public void onDoubleClick(DoubleClickEvent event) {
				tctfnegativGrid.setCanEdit(false);
				
			}
		});
		
		workingArea.addMember(tctfnegativGrid);
		
		/*this.deleteRowButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}
				tctfnegativGrid.removeSelectedData();
			}
		});*/
		
		/*this.newRowButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}
				tctfnegativGrid.startEditingNew();
				tctfnegativGrid.invalidateCache();
			}
		});*/
		
		
		//bottomArea.addMember(newRowButton);
		
		/*LayoutSpacer ls = new LayoutSpacer();
		ls.setWidth("230");
		bottomArea.addMember(ls);
		bottomArea.addMember(deleteRowButton);
		LayoutSpacer lstop = new LayoutSpacer();
		lstop.setHeight("2%");
		workingArea.addMember(lstop);
		workingArea.addMember(bottomArea);*/
		this.addItem(workingArea);
		this.draw();

		final Window w = this;
		this.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {

				w.destroy();
			}
		});
	}
	
	public static ManageFalseNegativeWindow windowCreator() {

		ManageFalseNegativeWindow mw = (ManageFalseNegativeWindow) Canvas.getById("ManageFalseNegativeWindow");
		if (mw != null) {
			mw.setVisible(true);
			mw.restore();
			mw.bringToFront();
			return mw;
		} else {
			return new ManageFalseNegativeWindow();

		}

	}

}
