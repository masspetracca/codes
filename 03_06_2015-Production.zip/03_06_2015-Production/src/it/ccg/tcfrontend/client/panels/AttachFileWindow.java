package it.ccg.tcfrontend.client.panels;

import java.util.Date;

import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.SecureDoubleClick;
import it.ccg.tcfrontend.client.controls.StandardListGrid;
import it.ccg.tcfrontend.client.menu.TextifyMenuItem;
import it.ccg.tcfrontend.client.menu.ViewDetailsMenuItem;
import it.ccg.tcfrontend.client.security.Privileges;
import it.ccg.tcfrontend.client.utils.ClientMessages;

import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.RPCTransport;
import com.smartgwt.client.types.SelectionStyle;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.grid.CellFormatter;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.CellClickEvent;
import com.smartgwt.client.widgets.grid.events.CellClickHandler;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.menu.Menu;

public class AttachFileWindow extends Window{

	String winId=this.getID();
	protected VLayout workingArea = new VLayout();

	final DataSource tctusract = SecureDS.get("tctusract");	
	final DataSource tctuplf = SecureDS.get("tctuplf");	
	//Grid
	private StandardListGrid attachFileListGrid;

	ListGridField removeButton;

	public AttachFileWindow(final int runId,final StandardListGrid activityLogListGrid){

		super();
		this.setID("AttachFileWindow");
		this.setTitle("Attached file - Run: " + runId);
		this.setWidth(600);
		this.setHeight(500);
		this.setCanDragReposition(true);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);
		this.setMembersMargin(3);
		this.centerInPage();


		attachFileListGrid = new StandardListGrid("AttachFile");

		//DataSource utilizzato per la tabella della lista dei clienti
		attachFileListGrid.setDataSource(tctuplf);
		attachFileListGrid.setWidth100();
		attachFileListGrid.setHeight("90%");
		attachFileListGrid.setShowFilterEditor(false);
		attachFileListGrid.setFilterOnKeypress(false);
		attachFileListGrid.setAutoFetchData(true);    
		attachFileListGrid.setSortDirection(SortDirection.DESCENDING);  
		attachFileListGrid.setCanEdit(false);
		attachFileListGrid.setAlternateRecordStyles(true);  
		attachFileListGrid.setSelectionType(SelectionStyle.MULTIPLE);
		attachFileListGrid.setMargin(5);

		removeButton = new ListGridField("REMOVE", " ");
		removeButton.setWidth(30);
		removeButton.setAlign(Alignment.CENTER);
		removeButton.setCanEdit(false);

		ListGridField fileName = new ListGridField("UPLFILE_filename");
		fileName.setCellFormatter(new CellFormatter() {

			@Override
			public String format(Object value, ListGridRecord record, int rowNum,
					int colNum) {
				return  Canvas.imgHTML("note.png",16,16) + "     " +value;
			}
		});
		attachFileListGrid.setFields(fileName, new ListGridField("NOTE"), new ListGridField("UPDUSR"), new ListGridField("UPDDATE"),  removeButton);

		attachFileListGrid.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				//Se il sistema � nello stato di working  viene lanciato un mess di notifica
				if(Privileges.isWorking()){
					SC.say("The system is currently busy");
					return;
				}
				try {
					SecureDoubleClick.secureDoubleClickRecord(event, attachFileListGrid);//, "DASHBOARDTAB002"
				} catch (Exception e) {
				}
			}
		});

		attachFileListGrid.getField("REMOVE").setCellFormatter(new CellFormatter() {

			@Override
			public String format(Object value, ListGridRecord record, int rowNum,
					int colNum) {

				return  Canvas.imgHTML("remove.png",16,16);
			}
		});


		//Set up the handler to expand and what not
		attachFileListGrid.addCellClickHandler(new CellClickHandler() {

			@Override
			public void onCellClick(CellClickEvent event) {

				final ListGridRecord record=event.getRecord(); 
				int colNum = event.getColNum();
				String fieldName = attachFileListGrid.getFieldName(colNum);  			

				if(fieldName.equalsIgnoreCase("REMOVE")){
					String mess = "Do you really want to remove the selected record?";
					SC.confirm(mess, new BooleanCallback() {
						public void execute(Boolean value) {
							if (value != null && value) { 

								attachFileListGrid.removeData(record, new DSCallback() {

									@Override
									public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
										tctuplf.fetchData(null, new DSCallback() {


											@Override
											public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
												// TODO Auto-generated method stub
												final Record[] recs = dsResponse.getData();


												activityLogListGrid.getField("UPLOAD").setCellFormatter(new CellFormatter() {

													@Override
													public String format(Object value, ListGridRecord record, int rowNum,
															int colNum) {

														final Criteria crit = new Criteria();
														crit.setAttribute("RUNID", record.getAttribute("RUNID"));

														int elem =0;
														for(int i=0;i<recs.length;i++){
															if(recs[i].getAttribute("RUNID").equalsIgnoreCase(record.getAttribute("RUNID"))){
																elem++;
															}
														}

														return  elem + Canvas.imgHTML("up2.png",16,16);
													}
												});



											}
										});
										activityLogListGrid.invalidateCache();
										updateAuditTableSingleUploadFile(record);
									}
								});
							}
						}
					});
				}
			}
		});


		Criteria crit = new Criteria();
		crit.addCriteria("RUNID", runId);

		attachFileListGrid.fetchData(crit);

		LayoutSpacer ls1 = new LayoutSpacer();
		ls1.setHeight(10);

		workingArea.addMembers(ls1,attachFileListGrid);

		IButton buttonDownload = new IButton("Download File");  
		buttonDownload.setWidth(150);    

		/*buttonDownload.addClickHandler(new ClickHandler() {  
            public void onClick(ClickEvent event) {  
                ListGridRecord records = attachFileListGrid.getSelectedRecord();  
                if (records == null) {  
                    SC.say("You must select at least one record");  
                    return;  
                }  

                Criteria criteria = new Criteria();  
                //criteria.addCriteria("RUNID", records.getAttribute("RUNID"));
                criteria.addCriteria("UPLID", records.getAttribute("UPLID"));
                criteria.addCriteria("UPLFILE_filename", records.getAttribute("UPLFILE_filename"));

                DSRequest dsRequest = new DSRequest();  
                dsRequest.setOperationId("downloadDescriptions");  
                dsRequest.setDownloadResult(true);  
                dsRequest.setDataSource("tctuplf");  

                tctuplf.fetchData(criteria, null, dsRequest);  
            }  
        }); */

		buttonDownload.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				ListGridRecord[] lgr = attachFileListGrid.getSelectedRecords();
				if(lgr!=null && lgr.length==1){

					String runId = lgr[0].getAttributeAsString("RUNID");
					String uplId = lgr[0].getAttributeAsString("UPLID");
					String fileName = lgr[0].getAttributeAsString("UPLFILE_filename");

					String paramStr = runId+","+uplId+","+fileName+",attach";

//					System.out.println(paramStr);
					RPCRequest rpcRequest = new RPCRequest();

					rpcRequest.setHttpMethod("POST");
					// Sto dicendo al client di aprire un hidden frame dal quale generare la richiesta in POST
					rpcRequest.setTransport(RPCTransport.HIDDENFRAME);
					rpcRequest.setActionURL("ccgportal/xmlServlet?params=" + paramStr);

					RPCManager.sendRequest(rpcRequest);

				}
				else if(lgr.length>1){
					SC.say("Please select one record only");
				}else SC.say("Please select one record to download");
			}	
		});

		/*buttonDownload.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				final ListGridRecord selectedRecord = attachFileListGrid.getSelectedRecord(); 
				//Record rec = new Record();
				if (selectedRecord == null) {  
					SC.warn("You must select one record");  
					return;  
				} 
				System.out.println(selectedRecord.getAttribute("UPLID"));
				System.out.println(selectedRecord.getAttribute("UPLFILE_filename"));
				//System.out.println(selectedRecord.getAttribute("UPLFILE").length());
				System.out.println(selectedRecord.getAttribute("RUNID"));
				if(selectedRecord.getAttribute("UPLFILE")!=null)
					System.out.println("OK***");
				else
					System.out.println("NO***");
                tctuplf.downloadFile(selectedRecord,"UPLFILE"); 
			}
		});*/  

		IButton buttonView = new IButton();  
		buttonView.setWidth(150);  
		buttonView.setTitle("Upload File");  
		buttonView.addClickHandler(new ClickHandler() {  
			@Override  
			public void onClick(ClickEvent event) {  
				UploadFileWindow.windowCreator(runId, activityLogListGrid);
			}  
		});  

		IButton buttonDelete = new IButton("Delete File");  
		buttonDelete.setWidth(150); 
		buttonDelete.addClickHandler(new ClickHandler() {  
			@Override  
			public void onClick(ClickEvent event) {  

				final Record[] recArr = attachFileListGrid.getSelectedRecords();
				String message="";
				if(recArr.length>=1){
					if(recArr.length==1)
						message = "Do you really want to remove the selected record?";
					else if(recArr.length>1)
						message = "Do you really want to remove the selected records?";

					SC.confirm(message, new BooleanCallback() {
						public void execute(Boolean value) {
							if (value != null && value) { 
								for(int i=0;i<recArr.length;i++){
									attachFileListGrid.removeSelectedData(new DSCallback() {

										@Override
										public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
											tctuplf.fetchData(null, new DSCallback() {

												@Override
												public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
													// TODO Auto-generated method stub
													final Record[] recs = dsResponse.getData();


													activityLogListGrid.getField("UPLOAD").setCellFormatter(new CellFormatter() {

														@Override
														public String format(Object value, ListGridRecord record, int rowNum,
																int colNum) {

															final Criteria crit = new Criteria();
															crit.setAttribute("RUNID", runId);

															int elem =0;
															for(int i=0;i<recs.length;i++){
																if(recs[i].getAttribute("RUNID").equalsIgnoreCase(record.getAttribute("RUNID"))){
																	elem++;
																}
															}

															return  elem + Canvas.imgHTML("up2.png",16,16);
														}
													});



												}
											});
										}
									});
								}
								activityLogListGrid.invalidateCache();
								updateAuditTableUploadFile(recArr);
							}
							/*tctuplf.fetchData(null, new DSCallback() {

									@Override
									public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
										// TODO Auto-generated method stub
										final Record[] recs = dsResponse.getData();


										activityLogListGrid.getField("UPLOAD").setCellFormatter(new CellFormatter() {

											@Override
											public String format(Object value, ListGridRecord record, int rowNum,
													int colNum) {

												final Criteria crit = new Criteria();
												crit.setAttribute("RUNID", runId);

												int elem =0;
												for(int i=0;i<recs.length;i++){
													if(recs[i].getAttribute("RUNID").equalsIgnoreCase(record.getAttribute("RUNID"))){
														elem++;
													}
												}

												return  elem + Canvas.imgHTML("up2.png",16,16);
											}
										});



									}
								});*/
							//							activityLogListGrid.invalidateCache();
							//							updateAuditTableUploadFile(recArr);

						}
					});
				}
				else SC.say("Please select one record to delete.");
			}
		});

		HLayout hLayoutButtons = new HLayout();  
		hLayoutButtons.setWidth(500);  
		LayoutSpacer ls = new LayoutSpacer();
		ls.setWidth(40);
		hLayoutButtons.setLayoutMargin(10);  
		hLayoutButtons.setMembersMargin(10);  
		hLayoutButtons.addMembers(ls, buttonDownload, buttonView, buttonDelete);//, viewAsTiles); 

		workingArea.addMember(hLayoutButtons);

		this.addItem(workingArea);

		attachFileListGrid.setContextMenu(createContextMenuAuditUsrAct());

		this.draw();

		final Window w = this;
		this.addCloseClickHandler(new CloseClickHandler() {

			@Override
			public void onCloseClick(CloseClickEvent event) {
				w.destroy();

			}
		});

	}

	public void updateAuditTableUploadFile(Record[] recArr){

		for(int i=0;i<recArr.length;i++){
			Record rec = recArr[i];
			String[] fieldnames = tctuplf.getFieldNames();
			String newRecordStr = "";
			int runid = rec.getAttributeAsInt("RUNID");
			/*Date date=new Date();

		for(int w=0;w<fieldnames.length;w++){
			if(fieldnames[w].compareToIgnoreCase("APPROVER")==0){
				newRecordStr+=fieldnames[w]+": | ";
			} else if(fieldnames[w].compareToIgnoreCase("APPROVED")==0){
				newRecordStr+=fieldnames[w]+": 'F' | ";
			} else if(fieldnames[w].compareToIgnoreCase("UPDDATE")==0){
				newRecordStr+=fieldnames[w]+": "+date+" | ";
			} else if(fieldnames[w].compareToIgnoreCase("UPDUSER")==0){
				newRecordStr+=fieldnames[w]+": "+Privileges.getUsername()+" | ";
			} else newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
		}*/

			for(int w=0;w<fieldnames.length;w++){
				if(rec.getAttributeAsString(fieldnames[w])==null)
					newRecordStr+=fieldnames[w]+":  | ";
				else
					newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
			}

			Record usrActRecord = new Record();

			usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctuplf_remove");
			usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
			usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
			usrActRecord.setAttribute("NEWRECORD",rec);
			//		usrActRecord.setAttribute("CMPNID", Privileges.getCompanyID());
			usrActRecord.setAttribute("RUNID", runid);

			tctusract.addData(usrActRecord);
		}
	}

	public void updateAuditTableSingleUploadFile(Record rec){

		String[] fieldnames = tctuplf.getFieldNames();
		String newRecordStr = "";
		int runid = rec.getAttributeAsInt("RUNID");

		for(int w=0;w<fieldnames.length;w++){
			if(rec.getAttributeAsString(fieldnames[w])==null)
				newRecordStr+=fieldnames[w]+":  | ";
			else
				newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
		}

		/*Date date=new Date();

		for(int w=0;w<fieldnames.length;w++){
			if(fieldnames[w].compareToIgnoreCase("APPROVER")==0){
				newRecordStr+=fieldnames[w]+": | ";
			} else if(fieldnames[w].compareToIgnoreCase("APPROVED")==0){
				newRecordStr+=fieldnames[w]+": 'F' | ";
			} else if(fieldnames[w].compareToIgnoreCase("UPDDATE")==0){
				newRecordStr+=fieldnames[w]+": "+date+" | ";
			} else if(fieldnames[w].compareToIgnoreCase("UPDUSER")==0){
				newRecordStr+=fieldnames[w]+": "+Privileges.getUsername()+" | ";
			} else newRecordStr+=fieldnames[w]+": "+rec.getAttributeAsString(fieldnames[w])+" | ";
		}*/

		Record usrActRecord = new Record();

		usrActRecord.setAttribute("AUDIT_OPERATIONTYPE", "tctuplf_remove");
		usrActRecord.setAttribute("AUDIT_CHANGETIME", new Date());
		usrActRecord.setAttribute("AUDIT_MODIFIER", Privileges.getUsername());
		usrActRecord.setAttribute("NEWRECORD",newRecordStr);
		//	usrActRecord.setAttribute("CMPNID", Privileges.getCompanyID());
		usrActRecord.setAttribute("RUNID", runid);

		tctusract.addData(usrActRecord);

	}

	public static AttachFileWindow windowCreator(int runId, StandardListGrid activityLogListGrid) {

		AttachFileWindow mw = (AttachFileWindow) Canvas.getById("AttachFileWindow");
		if (mw != null) {
			mw.setVisible(true);
			mw.restore();
			mw.bringToFront();
			return mw;
		} else {
			return new AttachFileWindow(runId, activityLogListGrid);

		}

	}

	private Menu createContextMenuAuditUsrAct() {
		Menu menu = new Menu();
		menu.setWidth(140);

		String name ="";
		ListGridRecord lgr = attachFileListGrid.getSelectedRecord();
		if(lgr!=null)
			name = lgr.getAttributeAsString("RUNID");

		//View Details
		ViewDetailsMenuItem viewDetItem = new ViewDetailsMenuItem(name);

		//Textify Selection
		TextifyMenuItem textItem = new TextifyMenuItem();

		menu.setItems(viewDetItem,textItem);

		return menu;

	}




}