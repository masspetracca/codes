package it.ccg.tcfrontend.client.controls;




import it.ccg.tcfrontend.client.utils.Regex;

import com.smartgwt.client.types.TextMatchStyle;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.ComboBoxItem;
import com.smartgwt.client.widgets.form.fields.events.ChangeEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangeHandler;
import com.smartgwt.client.widgets.form.validator.RegExpValidator;

public class StandardComboBox extends ComboBoxItem {
	private DynamicForm dynamicForm;
	
	/**Standard Combobox for PAMP project
	 * @param title: Label of the control
	 */
	public StandardComboBox(String title) {
		super();
		this.setTitle("<nobr>"+title+"</nobr>");
		this.setTextMatchStyle(TextMatchStyle.SUBSTRING);
		this.setWidth(200);
		this.setValidateOnChange(true);
//		this.setRejectInvalidValueOnChange(true);
		this.setAutoFetchData(true);
		
		RegExpValidator regExpValidator = new RegExpValidator();  
		regExpValidator.setExpression(Regex.regexDescription());  
		this.setValidators(regExpValidator);
		
	}
	/**
	 * @return Return a dynamicForm containing the ComboBox
	 */
	public DynamicForm inDynamicForm(){
		DynamicForm df=new DynamicForm();
		setDynamicForm(df);
		df.setItems(this);
		return(df);
	}
	
	public DynamicForm getDynamicForm() {
		return dynamicForm;
	}
	public void setDynamicForm(DynamicForm dynamicForm) {
		this.dynamicForm = dynamicForm;
	}

}
