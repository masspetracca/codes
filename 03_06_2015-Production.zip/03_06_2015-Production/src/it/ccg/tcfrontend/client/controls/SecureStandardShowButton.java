package it.ccg.tcfrontend.client.controls;

import it.ccg.tcfrontend.client.security.Privileges;

public class SecureStandardShowButton extends StandardButton {

	final protected int BUTWIDTH=80; //Button width
	private String[] requestedRoles;
	
	public SecureStandardShowButton() {
		super("Show");
		setWidth(BUTWIDTH);
		setIcon("icons/16/filter.png");
		
		requestedRoles=new String[] {"user"};
		
		if(Privileges.hasPrivileges(requestedRoles))
			super.setDisabled(false);
		else {
			super.setDisabled(true);
			setIcon("icons/16/filter_Disabled.png");
		}
		
		
	}
	
	public String[] getRequestedRoles(){
		return requestedRoles;
	} 
	
	public void setRequestedRoles(String[] requestedRoles){
		this.requestedRoles=requestedRoles;
		if(Privileges.hasPrivileges(requestedRoles))
			super.setDisabled(false);
		else {super.setDisabled(true);
			}
	}

	
	@Override
	public void enable() {
		if(Privileges.hasPrivileges(requestedRoles))
			super.enable();
		else super.disable();
	}
	
	@Override
	public void setTooltip(String message){
		if(Privileges.hasPrivileges(requestedRoles))
			super.setTooltip(message);
		else 
		super.setTooltip("You have not sufficient privileges to do this task or the system is working");
	}

}
