package it.ccg.tcfrontend.client.controls;

import it.ccg.tcfrontend.client.security.Privileges;
import it.ccg.tcfrontend.client.utils.DevelopmentMode;

import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.widgets.IButton;

public class StandardButton extends IButton {
	

	final protected int BUTWIDTH=100; //Button width
	final protected int CTRHEIGHT=22; //Control height
	final protected int CTRMARGINS=15; //Control margins
	final protected boolean BUTSHOWDOWN=true; 
	final protected boolean BUTSHOWROLLOVER=true;

	public StandardButton(String title) {
		super(title);
		setWidth(BUTWIDTH);
		setHeight(CTRHEIGHT);
		setShowDown(BUTSHOWDOWN);
		setShowRollOver(BUTSHOWROLLOVER);
		setLayoutAlign(VerticalAlignment.CENTER);
	}

	
	public StandardButton(String title, String controlID) {
		super(title);
		setID(controlID);
		
		setWidth(BUTWIDTH);
		setHeight(CTRHEIGHT);
		setShowDown(BUTSHOWDOWN);
		setShowRollOver(BUTSHOWROLLOVER);
		setLayoutAlign(VerticalAlignment.CENTER);
		if(DevelopmentMode.getDevelopmentMode()||Privileges.isControlON4User(controlID))this.enable();
		else disable();
		
		
	}
	
	
}
