package it.ccg.tcfrontend.client.controls;

import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.widgets.ImgButton;
import com.smartgwt.client.widgets.layout.LayoutSpacer;

public class StandardHelpButton extends ImgButton{
	
	public StandardHelpButton() {
		super();
		this.setTooltip("Help");
		this.setShowRollOver(true);
		this.setShowDown(false);
		this.setSize("24px", "24px");
		this.setSrc("icons/24/help24.png");
		this.setLayoutAlign(Alignment.RIGHT);
		this.setLayoutAlign(Alignment.CENTER);
	}

	public void addToTopControlBar(StandardControlBar topControlBar) {

		LayoutSpacer lstop = new LayoutSpacer();
		topControlBar.addMember(lstop);
		topControlBar.addMember(this);

	}

}