package it.ccg.tcfrontend.client.controls;

public class WindowsCounter {

	public static int counter=0;

	public static int getCounter() {
		if(counter==10) counter=0;
		counter++;
		return counter;
	}

	public static void setCounter(int counter) {
		WindowsCounter.counter = counter;
	}
	
	
}
