package it.ccg.tcfrontend.client.controls;


public class StandardShowButton extends StandardButton {
	

	final protected int BUTWIDTH=80; //Button width

	public StandardShowButton() {
		super("Show");
		setWidth(BUTWIDTH);
		setIcon("icons/16/filter.png");
	}
}
