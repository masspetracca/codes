package it.ccg.tcfrontend.client.controls;


import it.ccg.tcfrontend.client.Main;
import it.ccg.tcfrontend.client.menu.GridTemplateMenuItem;
import it.ccg.tcfrontend.client.security.Privileges;
import it.ccg.tcfrontend.client.utils.ClientMessages;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gwt.i18n.client.DateTimeFormat;
import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.HandleErrorCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.DateDisplayFormatter;
import com.smartgwt.client.util.DateUtil;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.events.DrawEvent;
import com.smartgwt.client.widgets.events.DrawHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.events.EditFailedEvent;
import com.smartgwt.client.widgets.grid.events.EditFailedHandler;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.MenuItemSeparator;

public class StandardListGrid extends ListGrid{
	private String panelID;
	private String tabella;
	private boolean frstTimeDraw = true;


	public StandardListGrid(final String panelID){
		super();
		this.panelID=panelID;
		this.tabella = "";
		this.setCanAddFormulaFields(false);
		this.setCanAddSummaryFields(true);
		this.setAllowFilterExpressions(true); // Da inserire permette di filtrare tramite espressioni
		//		this.setShowAllRecords(false);
		this.setMinFieldWidth(90);


		final StandardListGrid me=this;

		//Gestione errore DB
		this.addEditFailedHandler(new EditFailedHandler(){

			@Override
			public void onEditFailed(EditFailedEvent event) {
				try{
					DSResponse resp = event.getDsResponse();
					if(resp.getStatus()==-1){

						if((resp.getAttributeAsString("data").compareToIgnoreCase("Operation not allowed because the system is currently working.")==0)){
							SC.warn("Operation not allowed because the system is currently working.");
						}

						//			    	SC.warn("The operation can not be completed due to table constraints. Please contact the support desk for more information.");
						else SC.warn(ClientMessages.DBerrorMessage());

					}

				}catch (Exception e) {
					System.out.println(e.toString());
				}}});
		this.addDrawHandler(new DrawHandler(){
			@Override
			//Il layout della tabella viene lanciato subito dopo il disegno a video
			public void onDraw(DrawEvent event) {
				me.setDefaultState();
			}});
		 

		DateUtil.setShortDateDisplayFormatter(new DateDisplayFormatter() {

			@Override
			public String format(Date date) {
				if(date == null) return null;
				DateTimeFormat dateFormatter = DateTimeFormat.getFormat("dd/MM/yyyy");
				String format = dateFormatter.format(date);
				return format;
			}
		});

		this.addDrawHandler(new DrawHandler() {

			@Override
			public void onDraw(DrawEvent event) {
				System.out.println("***C : "+frstTimeDraw);

				if(frstTimeDraw){
					Criteria crit = me.getFilterEditorCriteria();	

					setDefaultState();

					me.setFilterEditorCriteria(crit);

					frstTimeDraw=false;
				}

			}
		});

	}
	
	
//Nuovo costruttore utilizzato per salvare come nome nella tabella del template
//come campo controlid = panelId+nomeTabella
	public StandardListGrid(final String panelID, final String tabella){
		super();
		
			this.panelID = panelID;
			this.tabella = tabella;
		
		
		this.setCanAddFormulaFields(false);
		this.setCanAddSummaryFields(true);
		this.setAllowFilterExpressions(true); // Da inserire permette di filtrare tramite espressioni
		//		this.setShowAllRecords(false);
		this.setMinFieldWidth(90);


		final StandardListGrid me=this;

		//Gestione errore DB
		this.addEditFailedHandler(new EditFailedHandler(){

			@Override
			public void onEditFailed(EditFailedEvent event) {
				try{
					DSResponse resp = event.getDsResponse();
					if(resp.getStatus()==-1){

						if((resp.getAttributeAsString("data").compareToIgnoreCase("Operation not allowed because the system is currently working.")==0)){
							SC.warn("Operation not allowed because the system is currently working.");
						}

						//			    	SC.warn("The operation can not be completed due to table constraints. Please contact the support desk for more information.");
						else SC.warn(ClientMessages.DBerrorMessage());

					}

				}catch (Exception e) {
					System.out.println(e.toString());
				}}});

		DateUtil.setShortDateDisplayFormatter(new DateDisplayFormatter() {

			@Override
			public String format(Date date) {
				if(date == null) return null;
				DateTimeFormat dateFormatter = DateTimeFormat.getFormat("dd/MM/yyyy");
				String format = dateFormatter.format(date);
				return format;
			}
		});

		this.addDrawHandler(new DrawHandler() {

			@Override
			public void onDraw(DrawEvent event) {

				if(frstTimeDraw){
					Criteria crit = me.getFilterEditorCriteria();	

					setDefaultState();

					me.setFilterEditorCriteria(crit);

					frstTimeDraw=false;
				}

			}
		});

	}


	public  void setDefaultState(){
		//String fieldState=Privileges.getControlLayout(panelID);

		String fieldState="";
		if(panelID.equalsIgnoreCase("dashboard")){
			fieldState = Main.getControlLayout(panelID+tabella);
		}else{
			fieldState = Privileges.getControlLayout(panelID+tabella);
		}


		if(fieldState!=null)if(!fieldState.equalsIgnoreCase(""))this.setFieldState(fieldState);

	}

	/*public  void setDefaultState(){
		String fieldState = Privileges.getControlLayout(panelID+tabella);
		if(fieldState!=null)if(!fieldState.equalsIgnoreCase(""))this.setFieldState(fieldState);

	}*/

	//Men� contestuale della header bar
	@Override
	protected MenuItem[] getHeaderContextMenuItems(Integer fieldNum){

		MenuItem[] superItems = super.getHeaderContextMenuItems(fieldNum);

		List<MenuItem> list = new ArrayList<MenuItem>();

		for (MenuItem item : superItems)
		{
			list.add(item);
		}

		//Add custom items

		list.add(new MenuItemSeparator());

		final StandardListGrid me = this;


		//TemplateItem
		GridTemplateMenuItem templateItem = new GridTemplateMenuItem(getPanelID(),me, tabella);
		templateItem.setIcon("icons/16/save.png");

		//Aggiunta dei menu
		list.add(templateItem);

		MenuItem[] newItems = new MenuItem[list.size()];

		list.toArray(newItems);

		return newItems;
	}

	//Rimuove tutte le righe selezionate aggiornando prima il tipo transazione (tutto in una sola transazione)
	@Override
	public void removeSelectedData(){
		final StandardListGrid me=this;

		RPCManager.setHandleErrorCallback(new HandleErrorCallback() {
			@Override
			public void handleError(DSResponse response, DSRequest request) {
				SC.warn(ClientMessages.DBerrorMessage());
			}
		});

		if(this.getSelectedRecord()==null){
			SC.warn(ClientMessages.errorNoRecordSelected());
			return;
		}

		SC.confirm(ClientMessages.removeMessage(), new BooleanCallback() {
			public void execute(Boolean value) {
				if (value != null && value) {  					
					RPCManager.startQueue();
					for(Record r:me.getSelection()){
						r.setAttribute("UPDTYPE", "D");
						me.updateData(r);
						me.removeData(r);
					}
					RPCManager.sendQueue();
				}
			}
		});
	}

	
	public void setPanelID(String panelID) {
		this.panelID = panelID;
	}

	public String getPanelID() {
		return panelID;
	}


	public boolean isFrstTimeDraw() {
		return frstTimeDraw;
	}


	public void setFrstTimeDraw(boolean frstTimeDraw) {
		this.frstTimeDraw = frstTimeDraw;
	}



}