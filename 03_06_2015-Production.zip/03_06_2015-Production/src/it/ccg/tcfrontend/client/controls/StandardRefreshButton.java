package it.ccg.tcfrontend.client.controls;

import it.ccg.tcfrontend.client.interf.Refreshable;

import com.google.gwt.core.client.JavaScriptObject;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.widgets.ImgButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.layout.LayoutSpacer;

public class StandardRefreshButton extends ImgButton {

	public StandardRefreshButton(final Refreshable panel) {
		super();
		this.setTooltip("Refresh");
		this.setShowRollOver(true);
		this.setShowDown(false);
		this.setSize("24px", "24px");
		this.setSrc("icons/24/refreshgrey.png");
		this.setLayoutAlign(Alignment.RIGHT);
		this.setLayoutAlign(Alignment.CENTER);

		this.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				panel.refresh();

			}

		});
	}

	public void addToTopControlBar(StandardControlBar topControlBar) {

		LayoutSpacer lstop = new LayoutSpacer();
		topControlBar.addMember(lstop);
		topControlBar.addMember(this);

	}

}
