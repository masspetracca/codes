package it.ccg.tcfrontend.client.controls;

import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.widgets.ImgButton;
import com.smartgwt.client.widgets.layout.LayoutSpacer;

public class StandardDetachButton extends ImgButton{
	
	public StandardDetachButton() {
		super();
		this.setTooltip("Detach");
		this.setShowRollOver(true);
		this.setShowDown(false);
		this.setSize("16px", "16px");
		this.setSrc("icons/16/detachgrey.png");
		this.setLayoutAlign(Alignment.RIGHT);
		this.setLayoutAlign(Alignment.CENTER);
	}

	public void addToTopControlBar(StandardControlBar topControlBar) {

		LayoutSpacer lstop = new LayoutSpacer();
		topControlBar.addMember(lstop);
		topControlBar.addMember(this);

	}

}