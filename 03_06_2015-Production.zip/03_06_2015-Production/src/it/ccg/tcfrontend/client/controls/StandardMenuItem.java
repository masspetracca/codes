package it.ccg.tcfrontend.client.controls;

import com.smartgwt.client.widgets.menu.MenuItem;

public class StandardMenuItem extends MenuItem{
	
	public StandardMenuItem(String title) {
		super(title);
	}
	
	public StandardMenuItem(String title, String controlID) {
		super(title);
	}

}
