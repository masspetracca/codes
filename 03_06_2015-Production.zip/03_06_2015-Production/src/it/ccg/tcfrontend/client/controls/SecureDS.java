package it.ccg.tcfrontend.client.controls;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.google.gwt.core.client.JavaScriptObject;
import com.googlecode.gwt.crypto.bouncycastle.digests.SHA1Digest;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.DataSourceField;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.data.RequestTransformer;
import com.smartgwt.client.types.FieldType;
import com.smartgwt.client.util.JSOHelper;

public class SecureDS{

	static String transactionToken="";
	static Map<String, String> map = new HashMap<String, String>();

	//
	public static DataSource get(String dsID){
		DataSource datasource = DataSource.get(dsID);
		
		if(isReqTransformed(DataSource.get(dsID))) {
			datasource = DataSource.get(dsID);
		} 
		else{
			datasource = getTransformed(dsID);
		}
		
		return datasource;
	}



	public static boolean isReqTransformed(DataSource datasource){
		String dsID = datasource.getID();
		if(!map.isEmpty() && map.containsKey(dsID)){
			return true;
		}
		map.put(dsID, "true");
		return false;
	}


	public static DataSource getTransformed(final String ds) {
		final DataSource dataSource = DataSource.get(ds, new RequestTransformer() {

			@Override
			protected Object transformRequest(DSRequest dsRequest) {
				//Se stiamo effetuando operazioni di update, remove, add
				//Costruisco una stringa composta da tutti i nomi dei campi ed una composta
				//da tutti i rispettivi valori

				
				//if((dsRequest.getOperationType().getValue()).compareToIgnoreCase("fetch")!=0){
				if((dsRequest.getOperationType().getValue()).compareToIgnoreCase("add")==0 ||
				   (dsRequest.getOperationType().getValue()).compareToIgnoreCase("update")==0 ||
				   (dsRequest.getOperationType().getValue()).compareToIgnoreCase("remove")==0) {


					JavaScriptObject data = dsRequest.getData();
					
					
					String ds = dsRequest.getDataSource();
					String[] attributes=DataSource.get(ds).getFieldNames();
					String strValues = "";
					String strFields = "";
					String strValuesForAudit = "";
					String strFieldsForAudit = "";

					String strPKValues = "";
					String strPKFields = "";

					DataSource ds1 = DataSource.get(ds);
					

					for(int i=0; i<attributes.length; i++){


						if(JSOHelper.getAttribute(data, attributes[i])!=null){

							DataSourceField dsField = ds1.getField(attributes[i]);
							
							FieldType fieldType = dsField.getType();

							// Se siamo nel caso di primary key che non � una data, memorizzo la primary key in una stringa da passare per il t 
							if(ds1.getField(attributes[i]).getPrimaryKey() && (fieldType.compareTo(FieldType.DATE)!=0 && fieldType.compareTo(FieldType.DATETIME)!=0)){
								strPKFields+=attributes[i]+",";
								strPKValues+=JSOHelper.getAttribute(data, attributes[i]);
							}

							//if(attributes[i].compareToIgnoreCase("UPDUSR")!=0){
							
							//Non inserisco le date
							if(fieldType.compareTo(FieldType.DATE)==0 || fieldType.compareTo(FieldType.DATETIME)==0){
								strFieldsForAudit+= attributes[i]+",";
							}
							/*else if(fieldType.compareTo(FieldType.FLOAT)==0 && dsRequest.getOperationType() == DSOperationType.REMOVE){

							}*/
							else if(fieldType.compareTo(FieldType.FLOAT)==0){
								strFieldsForAudit+= attributes[i]+",";
								/*System.out.println("VALUE: "+JSOHelper.getAttributeAsDouble(data, attributes[i]));
								String f = NumberFormat.getFormat("#,###0.000").format(JSOHelper.getAttributeAsDouble(data, attributes[i]));
								strValues+=f;
								strFields+= attributes[i]+",";*/
							} 
							else {
								strFieldsForAudit+= attributes[i]+",";
								strValues+= JSOHelper.getAttribute(data, attributes[i]);
								strFields+= attributes[i]+",";
							}
							
							//}
						}
					}
					
					
					
					Map<String, String> parametersMap = new LinkedHashMap<String, String>();
					
					
					// caso remove
					if(dsRequest.getOperationType().getValue().compareToIgnoreCase("remove") == 0) {
						
						// Costruisco il t con le pk
						String pktHS1 = getSHA1for(strPKValues.trim());
						
						JSOHelper.setAttribute(data, "TOKEN", pktHS1);
						//parametersMap.put("TOKEN", pktHS1);
						//dsRequest.setAttribute("TOKEN", pktHS1);
						
						parametersMap.put("pfields", strPKFields);
						
					}
					// caso add e update
					else {
						
						// Costruisco il t con i fields
						String tHS1 = getSHA1for(strValues.trim());
						
						JSOHelper.setAttribute(data, "TOKEN", tHS1);
						//parametersMap.put("TOKEN", tHS1);
						//dsRequest.setAttribute("TOKEN", tHS1);
						
						parametersMap.put("fields", strFields);
						parametersMap.put("fields1", strFieldsForAudit);
						
					}
					
					
					//  setto i parametri
					dsRequest.setParams(parametersMap);
					
			
				}
				
				
				return getDefaultTransformResponse(dsRequest);

			}
		}, null);

		return dataSource;
	}

	static String getSHA1for(String text) {
		
		text = text.replaceAll("[^A-Za-z0-9]", "0");
		
		
		SHA1Digest sd = new SHA1Digest();
		byte[] bs = text.getBytes();
		sd.update(bs, 0, bs.length);
		byte[] result = new byte[20];
		sd.doFinal(result, 0);
		return byteArrayToHexString(result);
	}

	static String byteArrayToHexString(final byte[] b) {
		final StringBuffer sb = new StringBuffer(b.length * 2);
		for (int i = 0, len = b.length; i < len; i++) {
			int v = b[i] & 0xff;
			if (v < 16) sb.append('0');
			sb.append(Integer.toHexString(v));
		}
		return sb.toString();
	}

	public static void setTransactionToken(String str){
		transactionToken+=str;
	}
	public static String getTransactionToken(){
		return transactionToken;
	}



}
