package it.ccg.tcfrontend.client.controls;

import it.ccg.tcfrontend.client.security.Privileges;

public class SecureStandardButton extends StandardButton {

	private String[] requestedRoles;
	
	public SecureStandardButton(String title) {
		super(title);
		
		requestedRoles=new String[] {"user"};
		
		if(Privileges.hasPrivileges(requestedRoles))
			super.setDisabled(false);
		else {super.setDisabled(true);
		}
		
		
	}
	/*public SecureStandardButton(String title, String panel) {
		super(title);
		
		if(panel.compareToIgnoreCase("scheduler")==0){
		requestedRoles=new String[] {"user", "admin"};
		}
		
		if(Privileges.hasPrivileges(requestedRoles))
			super.setDisabled(false);
		else {super.setDisabled(true);
		}
		
		
	}*/
	
	/*public String[] getRequestedRoles(){
		return requestedRoles;
	} 
	
	public void setRequestedRoles(String[] requestedRoles){
		this.requestedRoles=requestedRoles;
		if(Privileges.hasPrivileges(requestedRoles))
			super.setDisabled(false);
		else {super.setDisabled(true);
			}
	}*/

	
	@Override
	public void enable() {
		if(Privileges.hasPrivileges(requestedRoles))
			super.enable();
		else super.disable();
	}
	
	@Override
	public void setTooltip(String message){
		if(Privileges.hasPrivileges(requestedRoles))
			super.setTooltip(message);
		else 
		super.setTooltip("You have not sufficient privileges to do this task");
	}

}
