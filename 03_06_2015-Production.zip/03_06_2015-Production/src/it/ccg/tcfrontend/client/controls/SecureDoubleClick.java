package it.ccg.tcfrontend.client.controls;

import it.ccg.tcfrontend.client.security.Privileges;

import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickEvent;

public class SecureDoubleClick {
	
	private static String[] requestedRoles;
	
	public SecureDoubleClick(){
		
	}

	public static void secureDoubleClickRecord(RecordDoubleClickEvent event, ListGrid grid){
		requestedRoles=new String[] {"user"};
		if(Privileges.hasPrivileges(requestedRoles)){
			grid.startEditing(event.getRecordNum(), event.getFieldNum(), true);
		}
		
	}
	
	public static void secureDoubleClickRecord(RecordDoubleClickEvent event, ListGrid grid,String controlID){
		requestedRoles=new String[] {"user"};
		grid.setID(controlID);
		
		if(Privileges.hasPrivileges(requestedRoles) && Privileges.isControlON4User(controlID)){
			grid.setCanEdit(true);
			grid.startEditing(event.getRecordNum(), event.getFieldNum(), true);
		}
	}
	
	public static void secureDoubleClickRecord(com.smartgwt.client.widgets.events.DoubleClickEvent event, ListGridRecord lgr,String controlID){
		requestedRoles=new String[] {"user"};
		
		if(Privileges.hasPrivileges(requestedRoles) && Privileges.isControlON4User(controlID)){
			lgr.set_canEdit(true);
		}
		
	}

}
