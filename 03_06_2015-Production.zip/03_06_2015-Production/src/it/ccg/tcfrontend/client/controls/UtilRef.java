package it.ccg.tcfrontend.client.controls;

import it.ccg.tcfrontend.client.data.ExplorerTreeNode;

public class UtilRef {
	
	private static ExplorerTreeNode[] navTreeData;

	public static ExplorerTreeNode[] getNavTreeData() {
		return navTreeData;
	}

	public static void setNavTreeData(ExplorerTreeNode[] navTreeData) {
		UtilRef.navTreeData = navTreeData;
	}
	
	

}
