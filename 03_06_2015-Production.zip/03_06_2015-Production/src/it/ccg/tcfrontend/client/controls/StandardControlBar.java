package it.ccg.tcfrontend.client.controls;

import com.smartgwt.client.widgets.layout.HLayout;

public class StandardControlBar extends HLayout {
	
	final protected int HEIGHT=30; //Toolbar height
	final protected int CTRHEIGHT=22; //Control height
	final protected int CTRMARGINS=15; //Control margins

	public StandardControlBar() {
		super();
		this.setHeight(HEIGHT);
		this.setWidth100();
		this.setShowResizeBar(false);
		this.setMembersMargin(CTRMARGINS);
		
	
		
	}
	

}
