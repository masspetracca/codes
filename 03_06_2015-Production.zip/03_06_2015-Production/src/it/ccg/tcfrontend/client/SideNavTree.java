/*
 * Isomorphic SmartGWT web presentation layer
 * Copyright 2000 and beyond Isomorphic Software, Inc.
 *
 * OWNERSHIP NOTICE
 * Isomorphic Software owns and reserves all rights not expressly granted in this source code,
 * including all intellectual property rights to the structure, sequence, and format of this code
 * and to all designs, interfaces, algorithms, schema, protocols, and inventions expressed herein.
 *
 *  If you have any questions, please email <sourcecode@isomorphic.com>.
 *
 *  This entire comment must accompany any portion of Isomorphic Software source code that is
 *  copied or moved from this file.
 */

package it.ccg.tcfrontend.client;

import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.controls.UtilRef;
import it.ccg.tcfrontend.client.data.ExplorerTreeNode;
import it.ccg.tcfrontend.client.data.TCNavTreeData;
import it.ccg.tcfrontend.client.security.Privileges;
import it.ccg.tcfrontend.client.utils.DevelopmentMode;


import com.smartgwt.client.types.SortArrow;
import com.smartgwt.client.types.TreeModelType;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.PasswordItem;
import com.smartgwt.client.widgets.form.fields.events.KeyPressEvent;
import com.smartgwt.client.widgets.form.fields.events.KeyPressHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.MenuItemIfFunction;
import com.smartgwt.client.widgets.menu.events.MenuItemClickEvent;
import com.smartgwt.client.widgets.tree.Tree;
import com.smartgwt.client.widgets.tree.TreeGrid;
import com.smartgwt.client.widgets.tree.TreeGridField;

public class SideNavTree extends TreeGrid {
	private String idSuffix = "";
	private String[] requestedRoles;
	private ExplorerTreeNode[] navTreeData;

	public SideNavTree() {
		this.setID("sidenavtree");
		
			
	this.navTreeData = TCNavTreeData.getData(idSuffix);
			
		setWidth100();
		setHeight100();
		setCustomIconProperty("icon");
		setAnimateFolderTime(100);
		setAnimateFolders(true);
		setAnimateFolderSpeed(1000);
		setShowSortArrow(SortArrow.CORNER);
		setShowAllRecords(true);
		setLoadDataOnDemand(false);
		setCanSort(false);
		setLeaveScrollbarGap(false);

		UtilRef.setNavTreeData(this.navTreeData);

		TreeGridField field = new TreeGridField();
		field.setCanFilter(true);
		field.setName("name");
		field.setTitle("<b>Navigation bar</b>");
		setFields(field);

		Tree tree = new Tree();
		tree.setModelType(TreeModelType.PARENT);
		tree.setNameProperty("name");
		tree.setOpenProperty("isOpen");
		tree.setIdField("nodeID");
		tree.setParentIdField("parentNodeID");
		tree.setRootValue("root" + idSuffix);

		tree.setData(navTreeData);

		//Gestione visibilit� dei pannelli
		//Se un exploreTreeNode ha setIsVisible a false, viene eliminato dall'albero
		for (int i =0;i<navTreeData.length;i++){
			ExplorerTreeNode t = navTreeData[i];
			if(t.getIsVisible().compareToIgnoreCase("false")==0){
				tree.remove(t);
			}
		/*	if(Project.isSecurityTest().compareToIgnoreCase("true")==0 && t.getName().compareToIgnoreCase("Log viewer")==0){
				tree.remove(t);
			}*/
		}
		
		setData(tree);
	/*	if (Project.isSecurityTest().compareToIgnoreCase("true")!=0){
		this.setContextMenu(createContextMenu());
		}*/
		
		}

	public ExplorerTreeNode[] getShowcaseData() {
		return navTreeData;
	}

	// Context menu nella navigation bar. Ha solo la voce console.
	private Menu createContextMenu() {
		Menu menu = new Menu();
		menu.setWidth(140);

		MenuItem consoleMenuItem = new MenuItem("Console...");
		
		consoleMenuItem.setEnableIfCondition(new MenuItemIfFunction() {
			public boolean execute(Canvas target, Menu menu, MenuItem item) {
			
				//Inserire qui eventuali condizioni
				requestedRoles=new String[] {"admin"};
				if (Privileges.hasPrivileges(requestedRoles))
					return true;
				return false;
			}
		});
		
		consoleMenuItem.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {

				final Window winModal = new Window();
				winModal.setWidth(360);
				winModal.setHeight(100);
				winModal.setTitle("");
				winModal.setShowMinimizeButton(false);
				winModal.setAlign(VerticalAlignment.CENTER);
				winModal.setIsModal(true);
				winModal.setShowModalMask(true);
				winModal.centerInPage();

				final DynamicForm form = new DynamicForm();
				final PasswordItem passwordItem = new PasswordItem();
				passwordItem.setTitle("Enter the password");
				passwordItem.setRequired(true);
				StandardButton showConsole = new StandardButton("Show console");
				showConsole.addClickHandler(new ClickHandler() {

					@Override
					public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
						if (passwordItem.getValue() != null && passwordItem.getValue().toString().equals("pampteam")) {

							SC.showConsole();
							winModal.destroy();

						} else
							SC.say("Please enter a valid password");

					}
				});

				passwordItem.addKeyPressHandler(new KeyPressHandler() {
					public void onKeyPress(KeyPressEvent event) {
						if (event.getKeyName().equalsIgnoreCase("Enter")) {
							if (passwordItem.getValue() != null && passwordItem.getValue().toString().equals("pampteam")) {

								SC.showConsole();
								winModal.destroy();

							} else
								SC.say("Please enter a valid password");

						}
					}
				});

				winModal.addCloseClickHandler(new CloseClickHandler() {
					public void onCloseClick(CloseClickEvent event) {
						winModal.destroy();
					}
				});

				form.setFields(passwordItem);
				winModal.addItem(form);
				winModal.addItem(showConsole);
				winModal.show();
			}
		});

		// Define context menu
		
		menu.setItems(consoleMenuItem);
		return menu;
	}
}
