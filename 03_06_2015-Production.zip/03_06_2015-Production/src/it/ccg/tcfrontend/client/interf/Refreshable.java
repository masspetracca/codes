package it.ccg.tcfrontend.client.interf;

public interface Refreshable {
	
	public abstract void refresh();

}
