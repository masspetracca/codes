package it.ccg.tcfrontend.client.utils;

public class ClientMessages {
	//Message Windows
	public static String noInstrSelected(){return("Please select a valid financial instrument");}
    public static String noInstrTypeSelected(){return("Please select a valid instrument type");}
	
    public static String SMStepControl(){return("You reached the end of the precalculated data");}
    
	//Field value
	public static String notValidFieldFormat(){return("Field format not valid");}
	
	//date value
	public static String notValidDateFormat(){return("Date format not valid");}
	
	public static String selectBefore(){return("Select a record before performing this action");}
	
	//Warn Mark.Maker Table (Spreads...)
	public static String markMarker(){return("Please assign this financial instrument to a Market Maker table");}
	
	//Simulation panel
	public static String recalculateConfidence(){return("Refresh uncovered events from price variations");}
	public static String stepUp(){return("Step up uncovered events");}
	public static String stepDown(){return("Step down uncovered events");}
	
	//Tooltips
	//Show
	public static String ttpShowBtn(){return("Click after changing the filter on the left. The data table will be updated.");}
	//New row
	public static String newrow(){return("Add a new row to the main table.");}
    //edit row: 
	public static String editrow(){return("Start editing the selected row values.");}
	//remove row: 
	public static String removerow(){return("Remove the selected rows. Use the shift and Ctrl keys to select multiple rows.");}
	//refresh: 
	public static String refresh(){return("Refresh all data in the active sheet.");}
	//detach: 
	public static String detach(){return("Put the main table in a portable window. The window is always kept on top.");}
	//export: 
	public static String export(){return("Export all filtered rows to a 'comma separated values (CSV)' file. Change the active filter to change the exported data. Reset the filters to export all rows.");}
	//import: 
	public static String importdata(){return("Access to a 'comma separated values (CSV)' file to import new values to the main table. See the examples to prepare the file to be imported.");}
	//market: 
	public static String market(){return("Change the active financial market list for every division.");}
	//segments: 
	public static String segments(){return("Change the segment list for every markets. To create a new segment be sure that its market already exists.");}
	//instr. type: 
	public static String instrtype(){return("Change the instrument type list. Instrument types are symbols referring to categories of financial instruments (Ex. A = Actions).");}
	//instr. subtype: 
	public static String instrsubtype(){return("Change the instrument Sub-type list. To create a new Sub-type be sure that its Instrument type already exists.");}
	//change archive--->restore: 
	public static String charchrest(){return("Restore the values of the selected change into the table where that change happened.");}
	//sort: 
	public static String sort(){return("Sort the row on multiple hierarchic levels. The order of the choosen fields will determine the sorting.");}
	//price series-> validate: 
	public static String prservalid(){return("Apply the Z-Score to search errors in data series.");}
	//adv. filters: 
	public static String advfilt(){return("Create a multilevel filter to select a subset of the table rows. Choose the logic operators, the table fields and the needed values and press 'Show'.");}
	//charts: 
	public static String charts(){return("Shows an interactive chart containing all the mosti important data series.");}
	//build summary: 
	public static String summary(){return("Build a new field in the table containing a summary statement (Ex. you have two field containing the price and the rettified price. You can create a new field containing the following statement: 'The price is 99.3 and the rettified price is 99.3').");}
	//build formula: 
	public static String builtformula(){return("Build a new field in the table containing a calculated value (Ex. you have a field containing the price in euro. You can create a new field containing the price in another currency with a fixed rate).");}
	//corporate actions: 
	public static String corpact(){return("Change the corporate actions of an instrument. Insert an old instrumentid value in a corporate action record to combine two data series.");}
	//Static data---->discard: 
	public static String discard(){return("Discard the changes and restore the previous values.");}
	//Static data---->save: 
	public static String save(){return("Save the changes.");}
	//Static data---->cacel: 
	public static String cancel(){return("Discard the changes and close the edit window.");}
	//print
	public static String print(){return("Print this page");}

	//Confirm messages
	public static String removeMessage(){return ("Do you really want to remove the record(s)?");}
	
	
	//Warn message
	public static String DBerrorMessage(){return ("The operation can not be completed due to table constraints. Please contact the support desk for more information.");}
	public static String errorRemovingMessage(){return ("An error happened while trying to remove the row(s). One or more rows are probably linked with others in the database.");}
	public static String errorSystemBusy(){return ("The system is currently busy working on some batch. Check the Log and try again later.");}
	public static String errorNoRecordSelected(){return ("No records selected");}
	public static String validselMessage(){return ("Please select a valid row");}
	public static String secureupdateselMessage(){return ("Please select a valid field to change");}
}

