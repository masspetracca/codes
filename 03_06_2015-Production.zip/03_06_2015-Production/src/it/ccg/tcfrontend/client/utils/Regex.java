package it.ccg.tcfrontend.client.utils;

public class Regex {

	//Change Password 
	public static String regexChangePassword(){return "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@_$%\\-&\\\\/])[^<>]{10,20}$";}
	
	//Profile window
	public static String regexNameSurname(){return "^[a-zA-Z0-9������������ \\t\\n\\x0B\\f\\r ]*$";}
	public static String regexEmail(){return "^([a-zA-Z0-9_.\\-+])+@(([a-zA-Z0-9\\-])+\\.)+[a-zA-Z0-9]{2,4}$";}
	public static String regexDescription(){return "^[a-zA-Z0-9������������ \\t\\n\\x0B\\f\\r \\.\\;\\:\\=\\{\\}\\(\\)\\+\\-\\,\\'\\_]*$";}
	public static String regexPhoneNumber(){return "^[0-9\\.\\+]+";}
	
	//General log viewer
	public static String regexLogViewer(){return "^([0-1][0-9]|[2][0-3]):([0-5][0-9])$";}
	
	
	
	
}
