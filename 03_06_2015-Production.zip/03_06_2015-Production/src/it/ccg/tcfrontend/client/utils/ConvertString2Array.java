package it.ccg.tcfrontend.client.utils;

public class ConvertString2Array {
	
	
	public  static String array2String(String[] stringarr){
		
		String stringafinale="";
		
		for(String mini: stringarr){
			
			String mini2="\""+mini+"\"";
			
			stringafinale+=mini+=",";
			
		}
		if(stringafinale.endsWith(",")){
		stringafinale=stringafinale.substring(0, stringafinale.length()-1);
		}
		else stringafinale+="";
		
		return stringafinale;
		
	}
	
public static String[] string2Array(String stringona) {
		
		/*
		
		if(stringona.length()<2||!(stringona.startsWith("{")&&stringona.endsWith("}"))){
			throw new Exception("String structure not valid");
		}
		*/
		stringona=stringona.substring(1, stringona.length()-1);
		
		String[] stringarr= stringona.split(",");
		
		return stringarr;
		
		
	}
	
	
	

}