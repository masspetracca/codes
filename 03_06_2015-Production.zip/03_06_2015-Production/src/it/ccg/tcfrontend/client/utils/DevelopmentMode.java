
package it.ccg.tcfrontend.client.utils;

public class DevelopmentMode {
	public static boolean getDevelopmentMode(){
		return 	false;
	}
}
