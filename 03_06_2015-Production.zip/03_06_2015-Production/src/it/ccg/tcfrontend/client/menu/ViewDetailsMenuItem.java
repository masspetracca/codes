package it.ccg.tcfrontend.client.menu;

import it.ccg.tcfrontend.client.DetailsWindow;

import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.MenuItemIfFunction;
import com.smartgwt.client.widgets.menu.events.MenuItemClickEvent;


public class ViewDetailsMenuItem extends MenuItem {
	public ViewDetailsMenuItem(String name) {
		super("View details");
		
		this.setEnableIfCondition(new MenuItemIfFunction() {
			public boolean execute(Canvas target, Menu menu, MenuItem item) {
				// Recupero i record selezionati
				ListGridRecord[] recordList = ((ListGrid) target).getSelection();
				
				//Inserire qui eventuali condizioni
				if(recordList.length>0)return true;
				return false;
			}
		});


		/*this.setDynamicTitleFunction(new com.smartgwt.client.widgets.menu.MenuItemStringFunction(){
			public String execute(Canvas target, Menu menu, MenuItem item) {
				// Recupero i record selezionati
				ListGridRecord[] recordList = ((ListGrid) target).getSelection();
				if(recordList.length>1)return("Compare details");
				else return("View details");
			}
		});*/

		// Aggiunge il click handler
		this.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				ListGrid grid=(ListGrid)(event.getTarget());
				ListGridRecord lgr = grid.getSelectedRecord();
				String name = new String();
				String winName = new String();
				int numCol = grid.getSelection().length;
				if(name!=null){
				winName = (numCol == 1 ? "Static details on " + name : "Compare static details on " + numCol + " terrorist names");
				}else {
					name = "";
				    winName = "Static details";
				}
				@SuppressWarnings("unused")
				DetailsWindow ecaw = DetailsWindow.windowCreator(grid, name, winName, numCol);
			}
		});
	}

}