package it.ccg.tcfrontend.client.menu;

import it.ccg.tcfrontend.client.TemplateWindow;
import it.ccg.tcfrontend.client.security.Privileges;

import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.MenuItemIfFunction;
import com.smartgwt.client.widgets.menu.events.MenuItemClickEvent;

public class GridTemplateMenuItem extends MenuItem {

	private String[] requestedRoles;
	
	public GridTemplateMenuItem(final String IDPanel) {
		super("Templates...");
		
		this.setEnableIfCondition(new MenuItemIfFunction() {
			public boolean execute(Canvas target, Menu menu, MenuItem item) {
				// inizializzo l'utente di default
				requestedRoles=new String[] {"user"};
				//Se l'utente ha i permessi necessari e se viene selezionato almeno un record
				//il menu viene abilitato
				ListGridRecord[] recordList = ((ListGrid) target).getSelection();
				
				if(recordList.length>0 && Privileges.hasPrivileges(requestedRoles)){
					return true;
				}
				return false;
			}
		});
		
		/*this.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				ListGrid lg=(ListGrid) event.getTarget();
				ListGridRecord record = lg.getSelectedRecord();
				if (record != null) {
				TemplateWindow.windowCreator(lg, IDPanel);
				}else {
					SC.say("Select a record before performing this action");
				}
			}
		});*/
	}

	/*public GridTemplateMenuItem(final String IDPanel,final ListGrid grid) {
		super("Layout templates...");
		
		this.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				
				TemplateWindow.windowCreator(grid, IDPanel);
				
			}
		});
	}*/
	
	//******************************
	public GridTemplateMenuItem(final String IDPanel,final ListGrid grid, final String tabella) {
		super("Layout templates...");
		
		this.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				
				TemplateWindow.windowCreator(grid, IDPanel, tabella);
				
			}
		});
	}

}
