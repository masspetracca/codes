package it.ccg.tcfrontend.client.menu;

import it.ccg.tcfrontend.client.TextifyWindow;

import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.MenuItemIfFunction;
import com.smartgwt.client.widgets.menu.events.MenuItemClickEvent;

public class TextifyMenuItem extends MenuItem {
	public TextifyMenuItem() {
		super("View as text");

		this.setEnableIfCondition(new MenuItemIfFunction() {
				public boolean execute(Canvas target, Menu menu, MenuItem item) {
					// Recupero i record selezionati
					ListGridRecord[] recordList = ((ListGrid) target).getSelection();

					//Inserire qui eventuali condizioni
					if(recordList.length>0)return true;
					return false;
				}
			});

			// Aggiunge il click handler
			this.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
				public void onClick(MenuItemClickEvent event) {
					@SuppressWarnings("unused")
					TextifyWindow ecaw = TextifyWindow.windowCreator((ListGrid)(event.getTarget()));
				}
			});
	}

}
