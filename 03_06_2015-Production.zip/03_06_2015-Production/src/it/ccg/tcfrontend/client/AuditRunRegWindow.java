package it.ccg.tcfrontend.client;

import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.form.fields.RadioGroupItem;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.events.EditCompleteEvent;
import com.smartgwt.client.widgets.grid.events.EditCompleteHandler;
import com.smartgwt.client.widgets.grid.events.RemoveRecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RemoveRecordClickHandler;

public class AuditRunRegWindow extends Window {

	public AuditRunRegWindow(ListGrid maingrid){

		super();
		this.setID("AuditRunRegWindow");
		this.setShowHeader(false);
		this.setShowTitle(false);
		this.setHeaderStyle("formattedWindowHeader");
		this.setBorder("formattedWindowHeader"); 
		this.setShowShadow(true);  
		this.setShadowSoftness(10);  
		this.setShadowOffset(10);  
		this.setShowEdges(false);
		this.setBackgroundColor("FAFAFA");
		this.setBorder("1px solid #c0c0c0");
		this.setShowCloseButton(false);
		this.setWidth(180);
		this.setHeight(110);
		this.setCanDragReposition(false);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);
		this.setShowMinimizeButton(false);
		this.setMembersMargin(5);

		//*********************AUDIT DS************************************
	
		final DataSource auditDS = DataSource.get("audit_tctrunreg");  
		final ListGrid auditList = new ListGrid();  
		auditList.setWidth(600);  
		auditList.setHeight(224);  
		auditList.setDataSource(auditDS);  
		auditList.setAutoFetchData(false);  
		//		        auditList.setSortField("audit_revision");  
		auditList.setSortDirection(SortDirection.DESCENDING);  
		auditList.setShowFilterEditor(true);  

		maingrid.addRemoveRecordClickHandler(new RemoveRecordClickHandler() {

			@Override
			public void onRemoveRecordClick(RemoveRecordClickEvent event) {

				auditList.invalidateCache();

			}
		});

		maingrid.addEditCompleteHandler(new EditCompleteHandler() {

			@Override
			public void onEditComplete(EditCompleteEvent event) {
				auditList.invalidateCache();
			}
		});


		this.addItem(auditList);

		final Window w = this;



	}

	public static AuditRunRegWindow windowCreator(ListGrid maingrid) {

		AuditRunRegWindow mw = (AuditRunRegWindow) Canvas.getById("AuditRunRegWindow");
		if (mw != null) {
			mw.setVisible(true);
			mw.restore();
			mw.bringToFront();
			return mw;
		} else {
			return new AuditRunRegWindow(maingrid);

		}


	}


}
