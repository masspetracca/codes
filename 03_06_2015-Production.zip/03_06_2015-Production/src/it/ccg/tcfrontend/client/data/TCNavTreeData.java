/*
 * Isomorphic SmartGWT web presentation layer
 * Copyright 2000 and beyond Isomorphic Software, Inc.
 *
 * OWNERSHIP NOTICE
 * Isomorphic Software owns and reserves all rights not expressly granted in this source code,
 * including all intellectual property rights to the structure, sequence, and format of this code
 * and to all designs, interfaces, algorithms, schema, protocols, and inventions expressed herein.
 *
 *  If you have any questions, please email <sourcecode@isomorphic.com>.
 *
 *  This entire comment must accompany any portion of Isomorphic Software source code that is
 *  copied or moved from this file.
 */

package it.ccg.tcfrontend.client.data;

import it.ccg.tcfrontend.client.panels.AdmissionControlPanel;
import it.ccg.tcfrontend.client.panels.ClientStaticDataPanel;
import it.ccg.tcfrontend.client.panels.DashboardPanel;
import it.ccg.tcfrontend.client.panels.MatchingEntriesPanel;
import it.ccg.tcfrontend.client.panels.SchedulerPanel;
import it.ccg.tcfrontend.client.panels.SourceListArchivePanel;
import it.ccg.tcfrontend.client.panels.TerroristListPanel;
import it.ccg.tcfrontend.client.panels.AuditTrailPanel;



public class TCNavTreeData {

	private String idSuffix;

	public TCNavTreeData(String idSuffix) {
		this.idSuffix = idSuffix;
	}

	private ExplorerTreeNode[] data;

	/**
	 * @return
	 */
	private ExplorerTreeNode[] getData() {
		if (data == null) {

			data = new ExplorerTreeNode[]{

				new ExplorerTreeNode("CTF Controls", "ctfControls", "root", null, null, true, idSuffix,"true"),
					new ExplorerTreeNode("Dashboard", "dashboard", "ctfControls", null, new DashboardPanel.Factory(), true, idSuffix,"true"),
					new ExplorerTreeNode("Admission control", "admissioncontrol", "ctfControls", null, new AdmissionControlPanel.Factory(), true, idSuffix,"true"),
					new ExplorerTreeNode("Matching Entries", "matchingentries", "ctfControls", null, new MatchingEntriesPanel.Factory(), true, idSuffix,"true"),
					new ExplorerTreeNode("Client static data", "clientstaticdata", "ctfControls", null, new ClientStaticDataPanel.Factory(), true, idSuffix,"true"),
					new ExplorerTreeNode("Terrorist List", "terroristlist", "ctfControls", null, new TerroristListPanel.Factory(), true, idSuffix,"true"),
					new ExplorerTreeNode("Audit trail", "audittrail", "ctfControls", null, new AuditTrailPanel.Factory(), true, idSuffix,"true"),
					new ExplorerTreeNode("Source list archive", "sourcelistarchive", "ctfControls", null, new SourceListArchivePanel.Factory(), true, idSuffix,"true"),
					new ExplorerTreeNode("Scheduler", "schedulerpanel", "ctfControls", null, new SchedulerPanel.Factory(), true, idSuffix,"true"),
			};


		}
		return data;
	}

	public static ExplorerTreeNode[] getData(String idSuffix) {
		return new TCNavTreeData(idSuffix).getData();

	}



}
