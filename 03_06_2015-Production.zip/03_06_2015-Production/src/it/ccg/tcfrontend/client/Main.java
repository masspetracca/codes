package it.ccg.tcfrontend.client;


import it.ccg.tcfrontend.client.controls.SecureDS;
import it.ccg.tcfrontend.client.controls.StandardButton;
import it.ccg.tcfrontend.client.data.ExplorerTreeNode;
import it.ccg.tcfrontend.client.panels.DashboardPanel;
import it.ccg.tcfrontend.client.panels.EmailNotificationWindow;
import it.ccg.tcfrontend.client.panels.RiskNotificationWindow;
import it.ccg.tcfrontend.client.security.Privileges;
import it.ccg.tcfrontend.client.utils.DevelopmentMode;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.client.History;
import com.google.gwt.user.client.HistoryListener;
import com.smartgwt.client.core.KeyIdentifier;
import com.smartgwt.client.rpc.LoginRequiredCallback;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.SelectionStyle;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.types.Visibility;
import com.smartgwt.client.util.DateDisplayFormatter;
import com.smartgwt.client.util.DateParser;
import com.smartgwt.client.util.DateUtil;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.events.ResizedEvent;
import com.smartgwt.client.widgets.events.ResizedHandler;
import com.smartgwt.client.widgets.events.ShowContextMenuEvent;
import com.smartgwt.client.widgets.events.ShowContextMenuHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.LinkItem;
import com.smartgwt.client.widgets.form.fields.PasswordItem;
import com.smartgwt.client.widgets.form.fields.events.KeyPressEvent;
import com.smartgwt.client.widgets.form.fields.events.KeyPressHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.MenuItemIfFunction;
import com.smartgwt.client.widgets.menu.events.ClickHandler;
import com.smartgwt.client.widgets.menu.events.MenuItemClickEvent;
import com.smartgwt.client.widgets.tab.Tab;
import com.smartgwt.client.widgets.tab.TabSet;
import com.smartgwt.client.widgets.tab.events.TabContextMenuEvent;
import com.smartgwt.client.widgets.tab.events.TabContextMenuHandler;
import com.smartgwt.client.widgets.tab.events.TabSelectedEvent;
import com.smartgwt.client.widgets.tab.events.TabSelectedHandler;
import com.smartgwt.client.widgets.tree.Tree;
import com.smartgwt.client.widgets.tree.TreeNode;
import com.smartgwt.client.widgets.tree.events.LeafClickEvent;
import com.smartgwt.client.widgets.tree.events.LeafClickHandler;

public class Main implements EntryPoint, HistoryListener {

	private TabSet mainTabSet;
	private SideNavTree sideNav;
	static HLayout headerLayout;
	static HLayout logoLayout;
	static LayoutSpacer spacerLayout = new LayoutSpacer();
	static HLayout accountLayout;
	//	static HLayout isWorkingLayout;
	static VLayout header2Layout;
	//	final static Label isWorkingLabel = new Label();  
	final DynamicForm linkDynForm = new DynamicForm();
	final DynamicForm accountDynForm = new DynamicForm();
	final DynamicForm logoutDynForm = new DynamicForm();
	final DynamicForm riskDynForm = new DynamicForm();
	final DynamicForm consoleDynForm = new DynamicForm();
	
	final DynamicForm downloadListeDynForm = new DynamicForm();
	final DynamicForm optimizDynForm = new DynamicForm();
	final DynamicForm propertiesDynForm = new DynamicForm();
	
	
	private LinkItem manageEmailLink = new LinkItem();
	final LinkItem manageRiskLink = new LinkItem();
	private LinkItem consoleLink = new LinkItem();
	private LinkItem logoutLink = new LinkItem();
	
	private LinkItem downloadListeLink = new LinkItem();
	private LinkItem optimizLink = new LinkItem();
	private LinkItem propertiesLink = new LinkItem();
	
	
	final static AccountMenuWindow accountWindow = new AccountMenuWindow(); 

	private static Map<String,String> controlLayout=new HashMap<String,String>();


	public void onModuleLoad() {

		final String initToken = History.getToken();

		DateUtil.setNormalDateDisplayFormatter(new DateDisplayFormatter() {

			@Override
			public String format(Date date) {
				if(date == null) return null;

				String format = DateUtil.TOEUROPEANSHORTDATE.format(date);
				return format;
			}
		});

		DateUtil.setNormalDatetimeDisplayFormatter(new DateDisplayFormatter() {

			@Override
			public String format(Date date) {
				if(date == null) return null;

				String format = DateUtil.TOEUROPEANSHORTDATETIME.format(date);
				return format;
			}
		});

		DateUtil.setShortDateDisplayFormatter(new DateDisplayFormatter() {

			@Override
			public String format(Date date) {
				if(date == null) return null;

				String format = DateUtil.TOEUROPEANSHORTDATE.format(date);
				return format;
			}
		});


		DateUtil.setShortDatetimeDisplayFormatter(new DateDisplayFormatter() {

			@Override
			public String format(Date date) {
				if(date == null) return null;

				String format = DateUtil.TOEUROPEANSHORTDATETIME.format(date);
				return format;
			}
		});


		DateUtil.setDateParser(new DateParser() {

			@Override
			public Date parse(String dateString) {
				final DateTimeFormat format = DateTimeFormat.getFormat("dd/MM/yyyy hh:mm");
				Date date = format.parse(dateString);
				return date;

			}
		});

		//******************Inizializzazione utente e ruoli*******************
		if(!DevelopmentMode.getDevelopmentMode()){

			RPCManager.setLoginRequiredCallback(new LoginRequiredCallback() {

				@Override
				public void loginRequired(int transactionNum, RPCRequest request,
						RPCResponse response) {
					com.google.gwt.user.client.Window.Location.assign(GWT.getHostPageBaseURL() + "login.jsp");
				}
			});

			//			Privileges.storeDefaultControlState();

			// Inizializzazione elenco RUOLI
			// Creazione della richiesta
			RPCRequest r = new RPCRequest();
			r.setPrompt("Loading environment");
			r.setShowPrompt(true);
			r.setActionURL("ccgportal/UserName");
			RPCManager.sendRequest(r, new RPCCallback() {
				public void execute(RPCResponse response, java.lang.Object rawData, RPCRequest request) {

					// Gestione della risposta
					Map<String, String> responseMap;
					// Gestione della mappa della risposta
					responseMap = response.getAttributeAsMap("data");


					String userResult = responseMap.get("USER");
					String rolesResult = responseMap.get("ROLES");
					String enabledCommands= responseMap.get("ENABLEDCOMMANDS");
					String companyResult= responseMap.get("COMPANY");
					String fullnameResult= responseMap.get("FULLNAME");

					String companyCode= responseMap.get("COMPANYCODE");
					String companyID= responseMap.get("COMPANYID");
					String email= responseMap.get("EMAIL");
					
					String isAppoveEnabled = responseMap.get("ISAPPROVEENABLED");

					String responseResult = responseMap.get("RESPONSE");


					// memorizza la stringa di risposta in userRoles
					if(responseResult.compareToIgnoreCase("0")==0){
						//Se non ci sono user roles finestra modale bloccante
						if(rolesResult==null || rolesResult.length()==0){

							final Window winModal = new Window();  
							winModal.setWidth(350);  
							winModal.setHeight(100);  
							winModal.setTitle(" ");  
							winModal.setShowMinimizeButton(false);  
							winModal.setShowCloseButton(false);
							winModal.setIsModal(true);  
							winModal.setShowModalMask(true);  
							winModal.centerInPage();  
							winModal.show();
							Label lab = new Label();
							lab.setContents("<b>Environment load failed, please close the browser and retry. If the problem persist contact the administrator</b>");
							lab.setAlign(Alignment.CENTER);
							lab.setWidth("90%");
							lab.setHeight("90%");
							winModal.addItem(lab);
							return;
						}
						//setto le variaili statiche della classe privileges che terranno traccia dello username e dei ruoli ad esseo assegnati
						Privileges.setUsername(userResult);
						Privileges.setUserRoles(rolesResult.split(","));
						Privileges.setEnabledCommands(enabledCommands.split(","));
						Privileges.setCompany(companyResult);
						Privileges.setFullname(fullnameResult);
						Privileges.setCompanyID(Integer.parseInt(companyID));
						Privileges.setEmail(email);

						Privileges.setIsApproveEnabled(isAppoveEnabled);

						Privileges.storeDefaultControlState();

						DataSource templateDS = SecureDS.get("tctttmpl");
						DSRequest templateDSREQ=new DSRequest();
						templateDSREQ.setOperationId("tctttmplfetchdefault");

						templateDS.fetchData(null, new DSCallback(){
							@Override
							public void execute(DSResponse response, Object rawData, DSRequest request) {
								for(Record r:response.getData()){
									controlLayout.put(r.getAttributeAsString("CONTROLID"), r.getAttributeAsString("CONTENT"));
								}

								drawMainPanel(initToken);

							}},templateDSREQ);	

						//drawMainPanel(initToken);
					}
					else{
						SC.warn("Environment load failed, please close the browser and retry. If the problem persist contact the administrator");
					}



				}

			});
		}
		
		else {

			Privileges.storeDefaultControlState();

			Privileges.setUsername("user");
			//			String ta[]={"causer"};
			String ta[]={"user","admin","causer", "approver"};
			//String ta[]={"user","admin","causer"};
			Privileges.setUserRoles(ta);
			Privileges.setCompany("Dev Company");
			Privileges.setFullname("Developer");
			Privileges.setCompanyID(1);
			Privileges.setIsApproveEnabled("T");


			DataSource templateDS = SecureDS.get("tctttmpl");
			DSRequest templateDSREQ=new DSRequest();
			templateDSREQ.setOperationId("tctttmplfetchdefault");

			templateDS.fetchData(null, new DSCallback(){
				@Override
				public void execute(DSResponse response, Object rawData, DSRequest request) {
					for(Record r:response.getData()){
						controlLayout.put(r.getAttributeAsString("CONTROLID"), r.getAttributeAsString("CONTENT"));
					}

					drawMainPanel(initToken);

				}},templateDSREQ);		

			//drawMainPanel(initToken);
		}

	}


	@Override
	public void onHistoryChanged(final String historyToken) {
		//        	ogni volta che si fa il refresh della pagina e la history del browser � cambiata,
		//        	viene richiamata la initialize().
		//		RPCManager.startQueue();
		//		this.initialize();


		//SC.say("*******HISTORY TOKEN: " + historyToken);
		if (historyToken == null || historyToken.equals("")) {
			mainTabSet.selectTab(0);
		} else {
			ExplorerTreeNode[] showcaseData = sideNav.getShowcaseData();
			for (ExplorerTreeNode explorerTreeNode : showcaseData) {
				if (explorerTreeNode.getNodeID().equals(historyToken)) {
					showSample(explorerTreeNode);
					sideNav.selectRecord(explorerTreeNode);
					Tree tree = sideNav.getData();
					TreeNode categoryNode = tree.getParent(explorerTreeNode);
					while (categoryNode != null && !"/".equals(tree.getName(categoryNode))) {
						tree.openFolder(categoryNode);
						categoryNode = tree.getParent(categoryNode);
					}
				}

			}}}





	//************************************Disegno della pagina principale dell'applicazione***************************************
	public void drawMainPanel(final String initToken){

		/*isWorkingLabel.setContents("<body><font size=\"3\" style=\"color:#FF0000\"> <b>System is working</b> </font></body>");
		isWorkingLabel.setPadding(5);
		isWorkingLabel.setWidth("100%");
		isWorkingLabel.setAlign(Alignment.RIGHT);
		isWorkingLabel.setAnimateTime(50);
		isWorkingLayout.addMember(isWorkingLabel);
		isWorkingLabel.hide();*/


		VLayout main = new VLayout() {

			@Override
			protected void onInit() {
				super.onInit();

				if (initToken.length() != 0) {					
					onHistoryChanged(initToken);
				}
			}
		};

		main.setWidth100();
		main.setHeight100();
		main.setLayoutMargin(5);
		main.setStyleName("tabSetContainer");

		HLayout sideNavAndWALayout = new HLayout();
		sideNavAndWALayout.setWidth100();
		sideNavAndWALayout.setHeight100();
		sideNavAndWALayout.setResizeBarSize(5);
		VLayout sideNavLayout = new VLayout();
		sideNavLayout.setHeight100();
		//sideNavLayout.setWidth(254);
		sideNavLayout.setWidth(200);
		sideNavLayout.setShowResizeBar(true);



		sideNav = new SideNavTree();
		sideNav.setSelectionType(SelectionStyle.NONE);

		sideNav.addLeafClickHandler(new LeafClickHandler() {
			public void onLeafClick(LeafClickEvent event) {

				final TreeNode node = event.getLeaf();

				if(node.getName().equalsIgnoreCase("Dashboard")){

					DataSource templateDS = SecureDS.get("tctttmpl");
					DSRequest templateDSREQ=new DSRequest();
					templateDSREQ.setOperationId("tctttmplfetchdefault");

					templateDS.fetchData(null, new DSCallback(){
						@Override
						public void execute(DSResponse response, Object rawData, DSRequest request) {
							for(Record r:response.getData()){
								controlLayout.put(r.getAttributeAsString("CONTROLID"), r.getAttributeAsString("CONTENT"));
							}

							showSample(node);

						}},templateDSREQ);
				}
				else
					showSample(node);

			}


		});

		sideNavLayout.addMember(sideNav);
		sideNavAndWALayout.addMember(sideNavLayout);

		mainTabSet = new TabSet();
		mainTabSet.setWidth100();
		mainTabSet.setHeight100();
		/*
		 * raffaele de lauri
		 * 29/05/2015
		 * TN_CCG17436
		 * aggiungo l'aggiornamento della posizione della window 
		 * nel caso in cui quest'ultima � visibile
		 */
		mainTabSet.addResizedHandler(new ResizedHandler() {
			
			@Override
			public void onResized(ResizedEvent event) {
				if (accountWindow!=null && accountWindow.isVisible()){
					accountWindow.setTop(0); 
					accountWindow.setLeft(mainTabSet.getWidth()- 250);
					accountWindow.bringToFront();
					//SC.say(accountWindow.isVisible()+"");
					accountWindow.show();
				}
				
			}
		});
		//All'avvio dell'appilicazione vogliamo che come main page compaia la Dashboard
		Tree tree = sideNav.getData();
		TreeNode[] nodeArr = tree.getAllNodes();
		for(int i=0;i<nodeArr.length;i++){
			final TreeNode node = nodeArr[i];
			if(node.getName().equalsIgnoreCase("Dashboard")){


				/*ExplorerTreeNode explorerTreeNode = (ExplorerTreeNode) node;
				PanelFactory factory = explorerTreeNode.getFactory();

				Canvas panel = factory.create(mainTabSet,explorerTreeNode.getNodeID());
				Tab tab = new Tab();
				tab.setID(factory.getID() + "_tab");
				tab.setAttribute("historyToken", explorerTreeNode.getNodeID());

				String sampleName = explorerTreeNode.getName();
				String icon = explorerTreeNode.getIcon();
				String imgHTML = Canvas.imgHTML(icon);
				String ball = new String();

				tab.setTitle("<span >" +ball+ imgHTML + "&nbsp;" + sampleName + "</span>");
				tab.setPane(panel);


				tab.setCanClose(true);
				mainTabSet.addTab(tab);*/

				showSample(node);

				/*DataSource templateDS = SecureDS.get("tctttmpl");
				DSRequest templateDSREQ=new DSRequest();
				templateDSREQ.setOperationId("tctttmplfetchdefault");

				templateDS.fetchData(null, new DSCallback(){
					@Override
					public void execute(DSResponse response, Object rawData, DSRequest request) {
						for(Record r:response.getData()){
							controlLayout.put(r.getAttributeAsString("CONTROLID"), r.getAttributeAsString("CONTENT"));
						}

						showSample(node);

					}},templateDSREQ);*/	

			}
		}



		mainTabSet.addTabSelectedHandler(new TabSelectedHandler() {
			public void onTabSelected(TabSelectedEvent event) {
				Tab selectedTab = event.getTab();
				String historyToken = selectedTab.getAttribute("historyToken");
				if (historyToken != null) {
					History.newItem(historyToken, false);
				} else {
					History.newItem("Dashboard", false);
				}
			}
		});

		Canvas mainTabSetCanvas = new Canvas();
		mainTabSetCanvas.setWidth100();
		mainTabSetCanvas.setHeight100();
		mainTabSetCanvas.setMargin(3);
		mainTabSetCanvas.addChild(mainTabSet);



		logoLayout = new HLayout();
		logoLayout.setHeight(60);
		Img logo = new Img("logo.gif",239,51); 		
		logoLayout.addMember(logo);

		headerLayout = new HLayout();
		headerLayout.setHeight(60);
		headerLayout.setShowResizeBar(true);

		header2Layout = new VLayout();
		header2Layout.setHeight(60);

		//		isWorkingLayout = new HLayout();
		accountLayout = new HLayout();
		//
		//		header2Layout.addMember(isWorkingLayout);


		header2Layout.addMember(accountLayout);
		headerLayout.addMember(logoLayout);
		LayoutSpacer ls = new LayoutSpacer();
		ls.setWidth("85%");
		//headerLayout.addMember(new LayoutSpacer());
		headerLayout.addMember(ls);
		headerLayout.addMember(header2Layout);


		//*************************************      Account window    *******************************
//		accountWindow.setTop(0); 
//		accountWindow.setLeft(mainTabSet.getWidth()- 500);
		mainTabSetCanvas.addChild(accountWindow);
		accountWindow.setVisibility(Visibility.HIDDEN); 
		//        accountWindow.setShowEdges(true);
		//        mainTabSetCanvas.(accountWindow);
		//        accountWindow.setParentElement(mainTabSetCanvas);

		mainTabSet.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				accountWindow.hide();
			}
		});

		headerLayout.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				accountWindow.hide();
			}
		});



		//************** Inserimento del link contenente info sullo username e sul ruolo utente e LOGOUT*************

		final LinkItem accountLink = new LinkItem();
		//Costruisco il menu per la gestione delle opzioni dell'account e per la logout.
		//Il menu verr� inserito nel main.(Le info su usr name e pw non sono disponibili nel main)
		//Link da visualizzare in alto a destra dello schermo. Visualizza user e ruoli.
		accountLink.setShowTitle(false);

		if(Privileges.getUserRoles()==null) return;

		String[] roles = Privileges.getUserRoles();

		String roleDesc = "";

		for(int i =0; i<roles.length; i++){
			if(roles[i].compareToIgnoreCase("user")==0)
				roleDesc +=  "User"+",";
			if (roles[i].compareToIgnoreCase("manager")==0)
				roleDesc +=  "Manager"+",";
			if (roles[i].compareToIgnoreCase("visitor")==0)
				roleDesc +=  "Visitor"+",";
			if (roles[i].compareToIgnoreCase("admin")==0)
				roleDesc +=  "Admin"+",";
			if (roles[i].compareToIgnoreCase("causer")==0)
				roleDesc +=  "Data Operator"+",";
			if (roles[i].compareToIgnoreCase("supervisor")==0)
				roleDesc +=  "Supervisor"+",";
			if (roles[i].compareToIgnoreCase("ccpamanagement")==0)
				roleDesc +=  "CCP.A Management"+",";
			if (roles[i].compareToIgnoreCase("approver")==0)
				roleDesc +=  "Approver"+",";

		}

		if(roleDesc.endsWith(",")){
			roleDesc=roleDesc.substring(0, roleDesc.length()-1);
		}

		accountLink.setWidth(300);
		accountLink.setLinkTitle("<font color=\"005596\"><b>"+Privileges.getFullname() + "</b>("+ roleDesc + ")<br>Company: "+ Privileges.getCompany() +"</font>");


		//Link da visualizzare in alto a destra dello schermo per il fattore di rischio scelto
		manageRiskLink.setShowTitle(false);
		manageRiskLink.setWidth(300);

		
		/*AdvancedCriteria crit = new AdvancedCriteria();
		crit.addCriteria("CMPNID", Privileges.getCompanyID());*/

		final DataSource tctCompanyDS = SecureDS.get("tctcompany");
		tctCompanyDS.fetchData(null, new DSCallback() {

			@Override
			public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
				Record[] rec = dsResponse.getData();
				if(rec[0].getAttributeAsString("RISKPROF").equalsIgnoreCase("hr"))
					manageRiskLink.setLinkTitle("<font color=\"005596\">High risk selected</font>");
				else if(rec[0].getAttributeAsString("RISKPROF").equalsIgnoreCase("mr"))
					manageRiskLink.setLinkTitle("<font color=\"005596\">Avarage risk selected</font>");
				else if(rec[0].getAttributeAsString("RISKPROF").equalsIgnoreCase("lr"))
					manageRiskLink.setLinkTitle("<font color=\"005596\">Low risk selected</font>");
			}
		});

		//Aggiunta dell'account link alla header del main
		linkDynForm.setItems(accountLink);
		accountLayout.addMember(linkDynForm);

		//Aggiunta del riskt link alla header del main
		riskDynForm.setItems(manageRiskLink);
		header2Layout.addMember(riskDynForm);

		//Link da visualizzare in alto a destra dello schermo per la console solo se l'utente ha come ruolo Admin
		String[] role = Privileges.getUserRoles();

		
		//Link nel menu che apre la finestra per la gestione dei dati dell'email
		manageEmailLink.setShowTitle(false);
		manageEmailLink.setLinkTitle("<font color=\"005596\">Manage email notification</font>");
		accountDynForm.setPadding(5);
		accountDynForm.setAlign(Alignment.LEFT);
		accountDynForm.setFields(manageEmailLink);



		//Link nel menu che permette di effettuare la logout(ridireziona nella pagina di login)
		logoutDynForm.setPadding(5);
		logoutLink.setShowTitle(false);
		logoutLink.setLinkTitle("<font color=\"005596\">Logout</font>");
		logoutDynForm.setAlign(Alignment.LEFT);
		logoutDynForm.setFields(logoutLink);
		
		accountWindow.addItem(accountDynForm);
		
		for(int i=0;i<role.length;i++){
			if(role[i].equalsIgnoreCase("Admin")){
				
				accountWindow.setWidth(220);
				accountWindow.setHeight(200);
				
				//Link nel menu che oermette di eseguire il download delle liste solo se l'utente ha come ruolo Admin
				downloadListeLink.setShowTitle(false);
				downloadListeDynForm.setPadding(5);
				downloadListeLink.setLinkTitle("<font color=\"005596\">Terrorist lists download</font>");
				downloadListeDynForm.setAlign(Alignment.LEFT);
				downloadListeDynForm.setFields(downloadListeLink);
				
				//Link nel menu che oermette di eseguire il download delle liste solo se l'utente ha come ruolo Admin
				optimizLink.setShowTitle(false);
				optimizDynForm.setPadding(5);
				optimizLink.setLinkTitle("<font color=\"005596\">Optimization</font>");
				optimizDynForm.setAlign(Alignment.LEFT);
				optimizDynForm.setFields(optimizLink);
				
				//Link nel menu che oermette di eseguire il download delle liste solo se l'utente ha come ruolo Admin
				propertiesLink.setShowTitle(false);
				propertiesDynForm.setPadding(5);
				propertiesLink.setLinkTitle("<font color=\"005596\">Refresh properties</font>");
				propertiesDynForm.setAlign(Alignment.LEFT);
				propertiesDynForm.setFields(propertiesLink);
				
				accountWindow.addItem(downloadListeDynForm);
				accountWindow.addItem(optimizDynForm);
				accountWindow.addItem(propertiesDynForm);
			}
		}
		
		//Aggiunta elementi alla window(menu)
		
		
		for(int i=0;i<role.length;i++){
			if(role[i].equalsIgnoreCase("Admin")){
				consoleLink.setShowTitle(false);
				consoleDynForm.setPadding(5);
				consoleLink.setLinkTitle("<font color=\"005596\">Console</font>");
				consoleDynForm.setAlign(Alignment.LEFT);
				consoleDynForm.setItems(consoleLink);
				//header2Layout.addMember(consoleDynForm);
				accountWindow.addItem(consoleDynForm);
			}
		}
		accountWindow.addItem(logoutDynForm);
		
		manageEmailLink.addClickHandler(new com.smartgwt.client.widgets.form.fields.events.ClickHandler() {

			@Override
			public void onClick(
					com.smartgwt.client.widgets.form.fields.events.ClickEvent event) {
				EmailNotificationWindow.windowCreator(mainTabSet);
			}
		}); 
		if(Privileges.isUser()){
			manageRiskLink.addClickHandler(new com.smartgwt.client.widgets.form.fields.events.ClickHandler() {

				@Override
				public void onClick(
						com.smartgwt.client.widgets.form.fields.events.ClickEvent event) {
					RiskNotificationWindow.windowCreator(mainTabSet,manageRiskLink);
				}
			}); 
		}else{
			manageRiskLink.setDisabled(true);
			}

		consoleLink.addClickHandler(new com.smartgwt.client.widgets.form.fields.events.ClickHandler() {

			@Override
			public void onClick(
					com.smartgwt.client.widgets.form.fields.events.ClickEvent event) {
				//SC.showConsole();
				final Window winModal = new Window();
				winModal.setWidth(360);
				winModal.setHeight(100);
				winModal.setTitle("");
				winModal.setShowMinimizeButton(false);
				winModal.setAlign(VerticalAlignment.CENTER);
				winModal.setIsModal(true);
				winModal.setShowModalMask(true);
				winModal.centerInPage();

				final DynamicForm form = new DynamicForm();
				final PasswordItem passwordItem = new PasswordItem();
				passwordItem.setTitle("Enter the password");
				passwordItem.setRequired(true);
				StandardButton showConsole = new StandardButton("Show console");
				showConsole.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {

					@Override
					public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
						if (passwordItem.getValue() != null && passwordItem.getValue().toString().equals("pampteam")) {

							SC.showConsole();
							winModal.destroy();

						} else
							SC.say("Please enter a valid password");

					}
				});

				passwordItem.addKeyPressHandler(new KeyPressHandler() {
					public void onKeyPress(KeyPressEvent event) {
						if (event.getKeyName().equalsIgnoreCase("Enter")) {
							if (passwordItem.getValue() != null && passwordItem.getValue().toString().equals("pampteam")) {

								SC.showConsole();
								winModal.destroy();

							} else
								SC.say("Please enter a valid password");

						}
					}
				});

				winModal.addCloseClickHandler(new CloseClickHandler() {
					public void onCloseClick(CloseClickEvent event) {
						winModal.destroy();
					}
				});

				form.setFields(passwordItem);
				winModal.addItem(form);
				winModal.addItem(showConsole);
				winModal.show();
			}
		}); 

		logoutLink.addClickHandler(new com.smartgwt.client.widgets.form.fields.events.ClickHandler() {

			@Override
			public void onClick(com.smartgwt.client.widgets.form.fields.events.ClickEvent event) {

				RPCRequest rpcRequest = new RPCRequest();

				rpcRequest.setActionURL("ccgportal/Logout");

				RPCManager.sendRequest(rpcRequest, new RPCCallback() {

					@Override
					public void execute(RPCResponse response, Object rawData, RPCRequest request) {
						
					}
				});

			}

		});
		
		downloadListeLink.addClickHandler(new com.smartgwt.client.widgets.form.fields.events.ClickHandler() {

			@Override
			public void onClick(com.smartgwt.client.widgets.form.fields.events.ClickEvent event) {

				RPCRequest rpcRequest = new RPCRequest();

				rpcRequest.setActionURL("tcfrontend/admin/DownlaodStarter?src=ALL");

				RPCManager.sendRequest(rpcRequest);
				
				SC.say("Terrorist list download started");

			}

		});
		
		optimizLink.addClickHandler(new com.smartgwt.client.widgets.form.fields.events.ClickHandler() {

			@Override
			public void onClick(com.smartgwt.client.widgets.form.fields.events.ClickEvent event) {

				RPCRequest rpcRequest = new RPCRequest();

				rpcRequest.setActionURL("tcfrontend/admin/DownlaodStarter?src=OPTIM");

				RPCManager.sendRequest(rpcRequest);
				
				SC.say("Optimization procedure started");

			}

		});
		
		propertiesLink.addClickHandler(new com.smartgwt.client.widgets.form.fields.events.ClickHandler() {

			@Override
			public void onClick(com.smartgwt.client.widgets.form.fields.events.ClickEvent event) {

				RPCRequest rpcRequest = new RPCRequest();

				rpcRequest.setActionURL("tcfrontend/admin/SystemPropertiesLoad");//SPL

				RPCManager.sendRequest(rpcRequest);
				
				SC.say("Properties refresh started");

			}

		});

		accountLink.addClickHandler(new com.smartgwt.client.widgets.form.fields.events.ClickHandler() {

			@Override
			public void onClick(
					com.smartgwt.client.widgets.form.fields.events.ClickEvent event) {
				accountWindow.setTop(0); 
				accountWindow.setLeft(mainTabSet.getWidth()- 250);
				/*
				 * raffaele de lauri
				 * 29/05/2015
				 * TN_CCG17436
				 * aggiungo il codice per posizionare la window
				 * sempre in primo piano
				 */
				accountWindow.bringToFront();
				accountWindow.show();
				

			}
		}); 

		//*************************************************************************************

		sideNavAndWALayout.addMember(mainTabSetCanvas);
		main.setResizeBarSize(5);
		main.addMember(headerLayout);
		main.addMember(sideNavAndWALayout);
		main.draw();

		//Tab context men�
		final Menu contextMenu = createContextMenu();
		mainTabSet.addTabContextMenuHandler(new TabContextMenuHandler() {

			@Override
			public void onTabContextMenu(TabContextMenuEvent event) {
				if(event.getTab()!=null){ contextMenu.showContextMenu();}
				event.cancel();
			}
		});
		mainTabSet.addShowContextMenuHandler(new ShowContextMenuHandler() {
			public void onShowContextMenu(ShowContextMenuEvent event) {
				int selectedTab = mainTabSet.getSelectedTabNumber();
				if (selectedTab != 0) {
					contextMenu.showContextMenu();
				}
				event.cancel();
			}
		});

		// Add history listener
		History.addHistoryListener(this);

	}

	//Apertura pannelli al click del menu a sx
	private void showSample(TreeNode node) {


		boolean isExplorerTreeNode = node instanceof ExplorerTreeNode;
		if (isExplorerTreeNode) {
			ExplorerTreeNode explorerTreeNode = (ExplorerTreeNode) node;

			PanelFactory factory = explorerTreeNode.getFactory();
			if (factory != null) {
				String panelID = factory.getID();
				Tab tab = null;
				if (panelID != null) {
					String tabID = panelID + "_tab";
					tab = mainTabSet.getTab(tabID);
				}
				if (tab == null) {

					Canvas panel = factory.create(mainTabSet,explorerTreeNode.getNodeID());
					tab = new Tab();
					tab.setID(factory.getID() + "_tab");

					//store history token on tab so that when an already open is selected, one can retrieve the
					//history token and update the URL
					tab.setAttribute("historyToken", explorerTreeNode.getNodeID());
					String sampleName = explorerTreeNode.getName();

					String icon = explorerTreeNode.getIcon();
					String imgHTML = Canvas.imgHTML(icon);
					String ball = new String();


					tab.setTitle("<span >" +ball+ imgHTML + "&nbsp;" + sampleName + "</span>");
					tab.setPane(panel);

					tab.setCanClose(true);
					mainTabSet.addTab(tab);
					mainTabSet.selectTab(tab);
					if (!SC.isIE()) {
						if (mainTabSet.getNumTabs() == 10) {
							mainTabSet.removeTabs(new int[]{1});
						}
					}
					History.newItem(explorerTreeNode.getNodeID(), false);
				} else {
					mainTabSet.selectTab(tab);
				}
			}
		}
	}

	//Context Menu
	private Menu createContextMenu() {
		Menu menu = new Menu();
		menu.setWidth(140);

		MenuItemIfFunction enableCondition = new MenuItemIfFunction() {
			public boolean execute(Canvas target, Menu menu, MenuItem item) {
				int selectedTab = mainTabSet.getSelectedTabNumber();
				return selectedTab != 0;
			}
		};

		MenuItem closeItem = new MenuItem("<u>C</u>lose");
		closeItem.setEnableIfCondition(enableCondition);
		closeItem.setKeyTitle("Alt+C");
		KeyIdentifier closeKey = new KeyIdentifier();
		closeKey.setAltKey(true);
		closeKey.setKeyName("C");
		closeItem.setKeys(closeKey);
		closeItem.addClickHandler(new ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				int selectedTab = mainTabSet.getSelectedTabNumber();
				mainTabSet.removeTab(selectedTab);
				mainTabSet.selectTab(selectedTab - 1);
			}
		});

		MenuItem closeAllButCurrent = new MenuItem("Close All But Current");
		closeAllButCurrent.setEnableIfCondition(enableCondition);
		closeAllButCurrent.addClickHandler(new ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				int selected = mainTabSet.getSelectedTabNumber();
				Tab[] tabs = mainTabSet.getTabs();
				int[] tabsToRemove = new int[tabs.length - 2];
				int cnt = 0;
				for (int i = 1; i < tabs.length; i++) {
					if (i != selected) {
						tabsToRemove[cnt] = i;
						cnt++;
					}
				}
				mainTabSet.removeTabs(tabsToRemove);
			}
		});

		MenuItem closeAll = new MenuItem("Close All");
		closeAll.setEnableIfCondition(enableCondition);
		closeAll.addClickHandler(new ClickHandler() {
			public void onClick(MenuItemClickEvent event) {
				Tab[] tabs = mainTabSet.getTabs();
				int[] tabsToRemove = new int[tabs.length - 1];

				for (int i = 1; i < tabs.length; i++) {
					tabsToRemove[i - 1] = i;
				}
				mainTabSet.removeTabs(tabsToRemove);
				mainTabSet.selectTab(0);
			}
		});

		menu.setItems(closeItem, closeAllButCurrent, closeAll);
		return menu;
	}

	public static String getControlLayout(String controlId) {
		return controlLayout.get(controlId);
	}

	public static void storeDefaultControlState(){
		DataSource templateDS = SecureDS.get("tctttmpl");
		DSRequest templateDSREQ=new DSRequest();
		templateDSREQ.setOperationId("tctttmplfetchdefault");

		templateDS.fetchData(null, new DSCallback(){
			@Override
			public void execute(DSResponse response, Object rawData, DSRequest request) {
				for(Record r:response.getData()){
					controlLayout.put(r.getAttributeAsString("CONTROLID"), r.getAttributeAsString("CONTENT"));
				}
			}},templateDSREQ);		
	}

}


