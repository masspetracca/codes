/**
 Frame busting Javascript that doesn't break out of frames on your own site

This version of the script compares the host of the topmost window with that of the current window. The catch is that accessing top.location.host will result in an error (as mentioned in the first section above).

To get around this, use try..catch exception handling and variable setting to determine whether or not the window is within a frame from another domain
 */
	  (function() {
	    var externallyFramed = false;
	    try {
	      externallyFramed = top.location.host != location.host;
	    }
	    catch(err) {
	      externallyFramed = true;
	    }
	    if(externallyFramed) {
	      top.location = location;
	    }
	  })();