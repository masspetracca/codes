(function($) {
				$.fn.validator = function(options) {
				
					var that = this;
					
					if(that[0].tagName.toLowerCase() != 'form') {
					
						throw new Error('Questo plugin funziona con i form.');
						
						return;
					
					}
					
					var settings = {
					
						pwd: false,
						chars: false,
						messages: {
						
							chars: 'I caratteri speciali non sono ammessi'
						
						
						},
						patterns: {
						
							email: /^[a-z-0-9_+.-]+@([a-z0-9-]+\.)+[a-z0-9]{2,7}$/,
							url: /(http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/,
							chars: /^[A-Za-z0-9\s\.]*$/
						
						
						},
						
						//error: '<div class="error"/>'
						
					
					
					};
        
        
					options = $.extend(settings, options);
					
					var validate = function() {
					
						var valid = true;
					
						if(options.email) {
						
							$('input.email', that).each(function() {
							
								var value = $(this).val();
								
								if(!options.patterns.email.test(value)) {
								
									$(options.error).text(options.messages.email).
									insertAfter($(this));
									
									valid = false;
								
								}    
							
							
							});
						
						}
						
						if(options.pwd) {
						
							$('input.passwordField', that).each(function() {
							
								var value = $(this).val();
								
								if(!options.patterns.chars.test(value)) {
								
									$('#Password').css('border-width', '2px');
									$('#Password').css('border-color', '#ff0000');
									$('#errorBox').show();
									$('#errorText').text(options.messages.chars);
									
									valid = false;
								
								}   
							
							
							});    
						
						
						}
						
						if(options.chars) {
						
							$('.loginField', that).each(function() {
							
								var value = $(this).val();

								if(!options.patterns.chars.test(value)) {
									/*$('#Username').css('border-width', '2px');
									$('#Username').css('border-color', '#ff0000');*/
									$('#errorBox').show();
									$('#errorText').text(options.messages.chars);
									
									valid = false;
								
								}    
							
							
							});    
						
						
						}
					
					  return valid;
					
					};
        
        
					return that.each(function() {
					
					
						that.bind('submit', function(event) {
							var valid = validate();
							if(!valid) {
								event.preventDefault();
								//event.stopPropagation();
							}
						});    
					
					
					});
				
				
				
				
				};
})(jQuery);