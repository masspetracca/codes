package com.spel.demo;

import org.springframework.stereotype.Component;

@Component("emp")
public class Employee {

	private int emp_id = 12;
	private String emp_name = "Martin";

	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

}
