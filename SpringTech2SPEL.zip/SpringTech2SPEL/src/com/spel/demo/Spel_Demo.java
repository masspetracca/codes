package com.spel.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Spel_Demo {

	public static void main(String[] args) {
		
		ApplicationContext acc = new ClassPathXmlApplicationContext("com/spel/config/beans.xml");
		
		User user = (User) acc.getBean("user");
		
		System.out.println("User id is "+ user.getId());

		System.out.println("User name is "+user.getName());
		
	}

}
