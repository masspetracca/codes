package it.ccg.infoprovider.server.util;

import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.service.system.SystemProperties;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class LogReader implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private static final String WS_INSTALL_DIR = System.getProperty("user.install.root");
	private static final String PATH_SEPARATOR = System.getProperty("file.separator");
	
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
	private String fileName;
	

	
	public LogReader(String fileName) throws Exception {
		
		this.fileName = fileName;
		
		this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		
	}
	
	
	
	public List<LogLine> getLog() throws Exception {
		List<LogLine> log = new ArrayList<LogLine>();
		
		// read log file
		String logFileAbsolutePath = WS_INSTALL_DIR + PATH_SEPARATOR + SystemProperties.getProperties().getProperty("ws_log_relative_path") + PATH_SEPARATOR + fileName;
		BufferedReader br = new BufferedReader(new FileReader(new File(logFileAbsolutePath)));  
    	
		String line;
    	while((line = br.readLine()) != null) {
    		String[] lineComponents = line.split("\\|");
    		
    		if(lineComponents.length < 5) {
    			
    			defaultLogger.warn(new StandardLogMessage(this.currentUser, "Invalid log line formatting in \'" + this.fileName + "\'. Line: \'" + line + "\'"));
    			
    			LogLine logLine = new LogLine();
    			logLine.setMessage(line);
    			log.add(logLine);
    		}
    		else {
    			
    			log.add(new LogLine(lineComponents[0], lineComponents[1], lineComponents[2], lineComponents[3], lineComponents[4]));
    		}
	    }
    	
    	br.close();
    	
    	return log;
	}
	
	
	
}
