package it.ccg.infoprovider.server.service.file.template;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BloombergCurrRequestFileTemplate {
	
	private Map<String, String> headers;
	private List<String> fields;
	private List<String> securities;
	
	
	public BloombergCurrRequestFileTemplate() {
		
		this.headers = new HashMap<String, String>();
		this.headers.put("FIRMNAME", "dl621");
		this.headers.put("FILETYPE", "pc");
		this.headers.put("CLOSINGVALUES", "yes");
		this.headers.put("DATEFORMAT", "yyyymmdd");
		this.headers.put("PROGRAMFLAG", "daily");
		this.headers.put("PROGRAMNAME", "getdata");
		
		this.fields = new ArrayList<String>();
		this.fields.add("PX_LAST");
		this.fields.add("PX_CLOSE_DT");
		
		
		this.securities = new ArrayList<String>();
	}
	
	
	public String getAsFileFormattedString() {
		String temp = new String();
		
		temp += "START-OF-FILE" + "\n";
		temp += "\n";
		
		Set<String> keySet = this.headers.keySet();
		for(String key : keySet) {
			temp += key + "=" + this.headers.get(key) + "\n";
		}
		temp += "\n";
		
		temp += "START-OF-FIELDS" + "\n";
		for(String field : this.fields) {
			temp += field + "\n";
		}
		temp += "END-OF-FIELDS" + "\n";
		temp += "\n";
		
		temp += "START-OF-DATA" + "\n";
		for(String security : this.securities) {
			temp += security + "\n";
		}
		temp += "END-OF-DATA" + "\n";
		temp += "\n";
		
		temp += "END-OF-FILE" + "\n";
		temp += "\n";
		
		
		return temp;
	}
	
	
	
	public Map<String, String> getHeaders() {
		return headers;
	}
	
	
	public List<String> getFields() {
		return fields;
	}


	public List<String> getSecurities() {
		return securities;
	}
	

	public void setSecurities(List<String> securities) {
		this.securities = securities;
	}



}
