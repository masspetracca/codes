package it.ccg.infoprovider.server.service.file.factory;

import it.ccg.infoprovider.server.bean.entity.InstrumentsEntity;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;

public class BloombergBond_ASCIIRequestFactory implements RequestFactory {
	
	
	private static final String WS_INSTALL_DIR = System.getProperty("user.install.root");
	private static final String PATH_SEPARATOR = System.getProperty("file.separator");
	
	private static final String ASCII_FILE_NAME = "bbg_bond.req";
	private static final String ASCII_FILE_ABSOLUTE_PATH = WS_INSTALL_DIR +  "/temp/infoprovider_temp" + PATH_SEPARATOR + ASCII_FILE_NAME;
	
	
	private static final Logger logger = Logger.getLogger(BloombergBond_ASCIIRequestFactory.class);
	
	
	public BloombergBond_ASCIIRequestFactory() {
		
	}

	@Override
	public File createRequestFile(List<InstrumentsEntity> instrList) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public File addInstrument(InstrumentsEntity instrEntity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public File removeInstrument(InstrumentsEntity instrEntity) {
		// TODO Auto-generated method stub
		return null;
	}

}
