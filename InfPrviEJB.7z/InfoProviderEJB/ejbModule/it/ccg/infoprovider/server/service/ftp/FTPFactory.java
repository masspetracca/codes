package it.ccg.infoprovider.server.service.ftp;



public class FTPFactory {
	
	final public static String REUTERS_SERVICE = "reuters";
	final public static String BLOOMBERG_SERVICE = "bloomberg";
	
	
	
	public static FTPServiceInterface getFTPService(final String service) throws Exception {
		if(service.equals(FTPFactory.REUTERS_SERVICE)) {
			return new FTPServiceReuters();
		}
		else if(service.equals(FTPFactory.BLOOMBERG_SERVICE)) {
			return new FTPServiceBloomberg();
		}
		else {
			
		}
		
		return null;
	}

	
}


