package it.ccg.infoprovider.server.service.file.factory;


import it.ccg.infoprovider.server.bean.entity.InstrumentsEntity;
import it.ccg.infoprovider.server.service.ftp.FTPFactory;
import it.ccg.infoprovider.server.service.ftp.FTPServiceInterface;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

public class ReutersNIR_XMLRequestFactory implements RequestFactory {
	
	private static final String WS_INSTALL_DIR = System.getProperty("user.install.root");
	private static final String PATH_SEPARATOR = System.getProperty("file.separator");
	
	private static final String XML_FILE_NAME = "NIR_List.xml";
	private static final String XML_FILE_ABSOLUTE_PATH = WS_INSTALL_DIR +  "/temp/infoprovider_temp" + PATH_SEPARATOR + XML_FILE_NAME;
	
	
	private static final Logger logger = Logger.getLogger(ReutersNIR_XMLRequestFactory.class);
	
	
	private FTPServiceInterface ftpServiceInterface;
	
	
	private Document document;
	
	
	public ReutersNIR_XMLRequestFactory() {
		
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		documentBuilderFactory.setNamespaceAware(true);
		documentBuilderFactory.setValidating(true);
		
		
		try {
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			this.document = documentBuilder.newDocument();
			
		} catch(ParserConfigurationException e) {
			
			ReutersNIR_XMLRequestFactory.logger.debug(e.toString());
		}
		
	}
	
	
	@Override
	public File createRequestFile(List<InstrumentsEntity> instrList) {
		
		
		// create the root element
		Element rootElement = this.document.createElement("ReportRequest");
		rootElement.setAttribute("xmlns", "http://www.reuters.com/Datascope/ReportRequest.xsd");
		this.document.appendChild(rootElement);
		
		//
		Element inputListElement = this.document.createElement("InputList");
		rootElement.appendChild(inputListElement);
		
			//
			Element inputListActionElement = this.document.createElement("InputListAction");
			Text inputListActionText = this.document.createTextNode("Replace");
			inputListActionElement.appendChild(inputListActionText);
		
		inputListElement.appendChild(inputListActionElement);
		
			//
			Element nameElement = this.document.createElement("Name");
			Text nameText = this.document.createTextNode("IRNodes");
			nameElement.appendChild(nameText);
		
		inputListElement.appendChild(nameElement);
		
		
		//
		for(InstrumentsEntity instrEntity : instrList) {
			Element instrElement = createInstrumentElement(instrEntity);
			
			inputListElement.appendChild(instrElement);
		}
		
		// write
		writeDocumentToFile(this.document);
		
		
		return new File(ReutersNIR_XMLRequestFactory.XML_FILE_ABSOLUTE_PATH);
	}
	
	@Override
	public File addInstrument(InstrumentsEntity instrEntity) {
		
		if(exists(instrEntity.getReutersIdentifierCode())) {
			
			ReutersNIR_XMLRequestFactory.logger.debug("Instrument having ricCode=\'" + instrEntity.getReutersIdentifierCode() + "\' yet in \'" + ReutersNIR_XMLRequestFactory.XML_FILE_NAME + "\'.");
			
			return new File(ReutersNIR_XMLRequestFactory.XML_FILE_ABSOLUTE_PATH);
		}
		
		Document document = this.loadDocumentFromFTPFile();
		
		NodeList inputListNodeList = document.getElementsByTagName("InputList");
		Node inputListElement = inputListNodeList.item(0);
		
		Element instrElement = createInstrumentElement(instrEntity);
		
		inputListElement.appendChild(instrElement);
		
		
		this.writeDocumentToFile(document);

		
		return new File(ReutersNIR_XMLRequestFactory.XML_FILE_ABSOLUTE_PATH);
	}
	
	@Override
	public File removeInstrument(InstrumentsEntity instrEntity) {
		
		String ricCode = instrEntity.getReutersIdentifierCode();
		
		if(!exists(ricCode)) {
			
			ReutersNIR_XMLRequestFactory.logger.debug("Instrument having ricCode=\'" + ricCode + "\' not in \'" + ReutersNIR_XMLRequestFactory.XML_FILE_NAME + "\'.");
			
			return new File(ReutersNIR_XMLRequestFactory.XML_FILE_ABSOLUTE_PATH);
		}
		
		
		Document document = this.loadDocumentFromFTPFile();
		
		Element rootElement = document.getDocumentElement();
		
		NodeList identifierNodeList = rootElement.getElementsByTagName("Identifier");
		
		if(identifierNodeList != null && identifierNodeList.getLength() > 0) {
			
			for(int i = 0 ; i < identifierNodeList.getLength(); i++) {
				Node node = identifierNodeList.item(i);
				
				if(node.getNodeValue().equalsIgnoreCase(ricCode)) {
					Node instrumentNode = node.getParentNode();
					Node inputListNode = instrumentNode.getParentNode();
					
					inputListNode.removeChild(instrumentNode);
					
					break;
				}
				else {
					continue;
				}
			}
		}
		
		this.writeDocumentToFile(document);
		
		
		return new File(ReutersNIR_XMLRequestFactory.XML_FILE_ABSOLUTE_PATH);
	}
	
	
	
	private Element createInstrumentElement(InstrumentsEntity instrEntity) {
		
		//
		Element instrumentElement = this.document.createElement("Instrument");
		
			//
			Element identifierTypeElement = this.document.createElement("IdentifierType");
			Text identifierTypeText = this.document.createTextNode("RIC");
			identifierTypeElement.appendChild(identifierTypeText);
	
			Element identifierElement = this.document.createElement("Identifier");
			Text identifierText = this.document.createTextNode(instrEntity.getReutersIdentifierCode());
			identifierElement.appendChild(identifierText);
			
			Element descriptionElement = this.document.createElement("Description");
			Text descriptionText = this.document.createTextNode(instrEntity.getInstrumentName());
			descriptionElement.appendChild(descriptionText);
			
		
		instrumentElement.appendChild(identifierTypeElement);
		instrumentElement.appendChild(identifierElement);
		instrumentElement.appendChild(descriptionElement);
		
		
		return instrumentElement;
	}
	
	private boolean exists(String ricCode) {
		boolean exist = false;

		Document document = this.loadDocumentFromFTPFile();
		
		Element rootElement = document.getDocumentElement();
		
		NodeList identifierNodeList = rootElement.getElementsByTagName("Identifier");
		
		if(identifierNodeList != null && identifierNodeList.getLength() > 0) {
			
			for(int i = 0 ; i < identifierNodeList.getLength(); i++) {
				Node node = identifierNodeList.item(i);
				if(node.getNodeValue().equalsIgnoreCase(ricCode)) {
					exist = true;
					break;
				}
				else {
					continue;
				}
			}
		}
		
	    return exist;
	}
	
	private Document loadDocumentFromFTPFile() {
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		
		Document document = null;
		
		try {
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			
			// download from Reuters server
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.REUTERS_SERVICE);
			this.ftpServiceInterface.downloadRequestFile(ReutersNIR_XMLRequestFactory.XML_FILE_NAME, new FileOutputStream(new File(ReutersNIR_XMLRequestFactory.XML_FILE_ABSOLUTE_PATH)));
			
			
			document = documentBuilder.parse(ReutersNIR_XMLRequestFactory.XML_FILE_ABSOLUTE_PATH);
			
		}
		catch(Exception e) {
			
			ReutersNIR_XMLRequestFactory.logger.debug(e.toString());
		}
		
		return document;
	}
	
	private void writeDocumentToFile(Document document) {
		try {
			OutputFormat outputFormat = new OutputFormat(document);
			outputFormat.setIndenting(true);

			//to generate output to console use this serializer
			//XMLSerializer serializer = new XMLSerializer(System.out, format);
			
			XMLSerializer serializer = new XMLSerializer(new FileOutputStream(new File(ReutersNIR_XMLRequestFactory.XML_FILE_ABSOLUTE_PATH)), outputFormat);
			serializer.serialize(document);

		}
		catch(Exception e) {
			
			ReutersNIR_XMLRequestFactory.logger.debug(e.toString());
		}
	}
	

}
