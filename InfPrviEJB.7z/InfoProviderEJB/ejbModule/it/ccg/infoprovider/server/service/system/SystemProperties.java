package it.ccg.infoprovider.server.service.system;


import java.io.FileInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class SystemProperties {
	

	private static final String propertyFilePath = System.getProperty("user.install.root") + "/properties/infoprovider.system.properties";
	
	private static Properties properties = null;
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	
	public static void loadProperties() throws Exception {
		properties = new Properties();
		
		try {
			
			defaultLogger.info("Loading InfoProvider system properties from file \'" + propertyFilePath + "\'.");
			
			// load all properties from file
			properties.load(new FileInputStream(propertyFilePath));
			
			SystemProperties.defaultLogger.info("InfoProvider system properties successfully loaded.");
			
		}
		catch(Exception e) {
			
			SystemProperties.defaultLogger.error(e.toString());
			
			throw new Exception(e.toString());
		}
	}


	public static Properties getProperties() throws Exception {
		if(properties == null) {
			
			loadProperties();
		}
		
		return properties;
	}
    

}
