package it.ccg.infoprovider.server.service.file.factory;

import it.ccg.infoprovider.server.bean.entity.InstrumentsEntity;
import it.ccg.infoprovider.server.service.file.template.BloombergCurrRequestFileTemplate;
import it.ccg.infoprovider.server.service.ftp.FTPFactory;
import it.ccg.infoprovider.server.service.ftp.FTPServiceInterface;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class BloombergCurr_ASCIIRequestFactory implements RequestFactory {
	
	private static final String WS_INSTALL_DIR = System.getProperty("user.install.root");
	private static final String PATH_SEPARATOR = System.getProperty("file.separator");
	
	private static final String ASCII_FILE_NAME = "bbg_curr.req";
	private static final String ASCII_FILE_ABSOLUTE_PATH = WS_INSTALL_DIR +  "/temp/infoprovider_temp" + PATH_SEPARATOR + ASCII_FILE_NAME;
	
	
	private static final Logger logger = Logger.getLogger(BloombergCurr_ASCIIRequestFactory.class);
	
	private FTPServiceInterface ftpServiceInterface;
	
	
	public BloombergCurr_ASCIIRequestFactory() {
		
		
		
	}
	

	@Override
	public File createRequestFile(List<InstrumentsEntity> instrList) {
		
		BloombergCurrRequestFileTemplate template = new BloombergCurrRequestFileTemplate();
		
		List<String> securitiesList = new ArrayList<String>();
		for(InstrumentsEntity instrEntity : instrList) {
			securitiesList.add(instrEntity.getBloombergCode());
		}
		
		template.setSecurities(securitiesList);
		
		
		// write
		this.writeDocumentToFile(template);
		
		
		return new File(BloombergCurr_ASCIIRequestFactory.ASCII_FILE_ABSOLUTE_PATH);
	}
	
	
	@Override
	public File addInstrument(InstrumentsEntity instrEntity) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	@Override
	public File removeInstrument(InstrumentsEntity instrEntity) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	private boolean exists(String ricCode) {
		boolean exist = false;

		BloombergCurrRequestFileTemplate template = this.loadDocumentFromFTPFile();
		
		// TODO
		
		/*Element rootElement = document.getDocumentElement();
		
		NodeList identifierNodeList = rootElement.getElementsByTagName("Identifier");
		
		if(identifierNodeList != null && identifierNodeList.getLength() > 0) {
			
			for(int i = 0 ; i < identifierNodeList.getLength(); i++) {
				Node node = identifierNodeList.item(i);
				if(node.getNodeValue().equalsIgnoreCase(ricCode)) {
					exist = true;
					break;
				}
				else {
					continue;
				}
			}
		}*/
		
	    return exist;
	}
	
	private BloombergCurrRequestFileTemplate loadDocumentFromFTPFile() {
		
		// TODO
		
		return null;
	}
	
	private void writeDocumentToFile(BloombergCurrRequestFileTemplate template) {
		
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new PrintWriter(new File(BloombergCurr_ASCIIRequestFactory.ASCII_FILE_ABSOLUTE_PATH)));
			bw.write(template.getAsFileFormattedString());

		}
		catch(Exception e) {
			
			BloombergCurr_ASCIIRequestFactory.logger.debug(e.toString());
		}
		finally {
			if(bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		}
	}
	
	

	

}
