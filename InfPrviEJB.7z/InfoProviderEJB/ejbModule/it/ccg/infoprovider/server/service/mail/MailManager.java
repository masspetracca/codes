package it.ccg.infoprovider.server.service.mail;



import it.ccg.infoprovider.server.bean.eao.UserEAOLocal;
import it.ccg.infoprovider.server.service.system.SystemProperties;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.ejb.EJB;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;

public class MailManager {
	
	
	private static final String MAIL_PROPERTIES_FILE_NAME = "mail.properties";
	
	
	public MailManager() {
		
	}
	

	@EJB 
	private UserEAOLocal userEAO;
	
	
	/*public String from = "pampmailer@ccg.it";
	public String fromName = "PAMP SYSTEM";*/
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public void sendMail(String userFrom, String[] userTo, String[] userCC, String msgSubject,String msgBody,String[] attachments, int notifyId) {
		
		/*HashMap<String,String> propertyMap = new HashMap<String,String>();
		
		try {
			propertyMap = properties.getPropertyMap();
		} catch (Exception e) {
			e.getMessage();
		}
		String from = propertyMap.get("mailAddress");
		String fromName = propertyMap.get("mailAlias");
		
		List<InternetAddress> ccList = new ArrayList<InternetAddress>();
		List<InternetAddress> userToList = new ArrayList<InternetAddress>(); 
		
		try {
			if (userFrom!=null) {
				from = userEAO.findByPrimaryKey(userFrom).getEmail();
				fromName = userEAO.findByPrimaryKey(userFrom).getSurName().trim()+","+userEAO.findByPrimaryKey(userFrom).getName().trim();
			}
			
			List<UserToNotify> notUsrList = new ArrayList<UserToNotify>();
			
			if (userTo!=null) {
				notUsrList = notUserEAO.getUserToNotifyListByUserNameAndNotifyId(userTo,notifyId);
			} else { 
				notUsrList = notUserEAO.getUserToNotifyListByNotifyId(notifyId);
			}
			
			for (UserToNotify notUsr:notUsrList) {
				InternetAddress ia = new InternetAddress(notUsr.getEmail());
				userToList.add(ia);
			}
			
			
		} catch (Exception e) {
			log.warn(e.getMessage()+" - "+e.getMessage());
		}
			
		if (userToList.size()>0) {
			//se c'� almeno un destinatario controllo la presenza di eventuali CC e creo la loro lista
			if (userCC!=null) {
				for (String cc:userCC) {
					try {
						if (userEAO.findByPrimaryKey(cc).getNotify().equalsIgnoreCase("T")) {
							InternetAddress ia;
							ia = new InternetAddress(userEAO.findByPrimaryKey(cc).getEmail());
							ccList.add(ia);
						} 
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		
		Properties properties = new Properties();
		properties.put("mail.smtp.host", propertyMap.get("mail.smtp.host")); 
		properties.put("mail.smtp.port", propertyMap.get("mail.smtp.port"));
		Session session = Session.getDefaultInstance(properties, null);
		
		Properties mailProps = new Properties();
		 
		try {
			System.out.println("default property path: "+rootDirectory+propertyPath);
			mailProps.load(new FileInputStream(rootDirectory+propertyPath));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		Session session = Session.getDefaultInstance(mailProps, null);
		
		
		try {
			MimeMessage message = new MimeMessage(session);
			//mittente
			message.setFrom(new InternetAddress(from.trim(),fromName));
			
			//destinatario/destinatari ed eventuali cc
			InternetAddress[] usrToArray = new InternetAddress[userToList.size()];
			message.setRecipients(Message.RecipientType.TO, userToList.toArray(usrToArray));
			
			if (ccList.size()>0) {
				InternetAddress[] ccArray = new InternetAddress[ccList.size()];
				message.setRecipients(Message.RecipientType.CC, ccList.toArray(ccArray));
			}
			
			//oggetto e data
			message.setSubject(msgSubject);
			message.setSentDate(new Date());	
			
			// testo del messaggio
			MimeBodyPart messagePart = new MimeBodyPart();
			
			messagePart.setContent(this.htmlBody(msgBody), "text/html");
			//messagePart.setText(msgBody);
			Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messagePart);
			
           
			// eventuali allegati
			if (attachments!=null) {
				for (String att:attachments) {
					MimeBodyPart attachmentPart = new MimeBodyPart();
					FileDataSource fileDataSource = new FileDataSource(att) {
					@Override
		            public String getContentType() {
						return "application/octet-stream";
					}
					};
					attachmentPart.setDataHandler(new DataHandler(fileDataSource));
					attachmentPart.setFileName(att);
		            multipart.addBodyPart(attachmentPart);
				}
			}
             
            message.setContent(multipart);
            Transport.send(message);
            
		} catch (Exception e) {
			log.warn(e.getMessage()+" - "+e.getStackTrace());
		}*/
	}
	
	public String htmlBody(String msgBody) throws UnknownHostException {
		
		InetAddress thisIp =InetAddress.getLocalHost();
		String host ="<br><br>Host System: <span class=\"host\">"+thisIp.getHostAddress()+"</span><br>";
		
		String style = "<style>"+
						"body {"+
						"font-family: Arial;"+
						"font-size: 10pt;"+
						"}"+
						".host {"+
						"font-weight:bold"+
						"}"+
						"</style>";
		
		msgBody = "<p class=\"msgBody\">"+msgBody+"</p>";
		
		String htmlCode = style + msgBody + host;
		
		return htmlCode;
			
	}
	

}
