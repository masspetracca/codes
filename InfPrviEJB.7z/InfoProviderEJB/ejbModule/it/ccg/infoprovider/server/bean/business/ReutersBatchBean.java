package it.ccg.infoprovider.server.bean.business;

import it.ccg.infoprovider.server.annotation.Batch;
import it.ccg.infoprovider.server.bean.eao.BatchEAOLocal;
import it.ccg.infoprovider.server.bean.eao.FTPFileEAOLocal;
import it.ccg.infoprovider.server.bean.eao.HistoricalPricesEAOLocal;
import it.ccg.infoprovider.server.bean.eao.InstrumentsEAOLocal;
import it.ccg.infoprovider.server.bean.entity.BatchEntity;
import it.ccg.infoprovider.server.bean.entity.FTPFileEntity;
import it.ccg.infoprovider.server.bean.entity.HistoricalPricesEntity;
import it.ccg.infoprovider.server.bean.entity.HistoricalPricesEntityPK;
import it.ccg.infoprovider.server.bean.entity.InstrumentsEntity;
import it.ccg.infoprovider.server.bean.providermanager.ReutersManagerBeanLocal;
import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.data.TimerData;
import it.ccg.infoprovider.server.service.ftp.FTPFactory;
import it.ccg.infoprovider.server.service.ftp.FTPServiceInterface;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.commons.net.ftp.FTPFile;
import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ReutersBatchBean
 */
@Stateless
public class ReutersBatchBean implements ReutersBatchBeanLocal {
	
	
	private static final String WS_INSTALL_DIR = System.getProperty("user.install.root");
	private static final String PATH_SEPARATOR = System.getProperty("file.separator");
	
	private static final String TEMP_FILE_NAME = "rtr_bondIR.csv.temp";
	private static final String TEMP_FILE_ABSOLUTE_PATH = WS_INSTALL_DIR + "/temp/infoprovider_temp" + PATH_SEPARATOR + TEMP_FILE_NAME;
	
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	private static final Logger monitorLogger = Logger.getLogger("it.ccg.infoprovider.server.monitorLogger");
	
	
	private FTPServiceInterface ftpServiceInterface;
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
	
	
	@EJB
	private InstrumentsEAOLocal instrEAOLocal;
	
	@EJB
	private HistoricalPricesEAOLocal historicalPricesEAOLocal;
	
	@EJB
	private FTPFileEAOLocal ftpFileEAOLocal;
	
	@EJB
	private BatchEAOLocal batchEAOLocal;
	
	@EJB
	private ReutersManagerBeanLocal reutersManagerBeanLocal;
	
	

    /**
     * Default constructor. 
     */
    public ReutersBatchBean() {
    	this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
    @Override
	public List<TimerData> getBatches() throws Exception {
		List<TimerData> list = new ArrayList<TimerData>();
		
		Class<?> timerClass = ReutersBatchBean.class;
		
		Method[] methods = timerClass.getMethods();
		
		List<String> batchList = new ArrayList<String>();
		for(Method method : methods) {
			if(method.getAnnotation(Batch.class) != null) {
				batchList.add(method.getName());
			}
		}
		
		for(String batch : batchList) {
			TimerData timerData = new TimerData();
			timerData.setBatchName(batch);
			list.add(timerData);
		}
		
		
		return list;
	}
    
    
    @Override
	@Batch
	public void bondInterestRatesBatch() {
   

		try {
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Batch \'bondInterestRatesBatch\' started."));
			monitorLogger.debug(new StandardLogMessage(this.currentUser, "Batch \'bondInterestRatesBatch\' started."));
			
			// initialize ftpService
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.REUTERS_SERVICE);
			
			// calculate file name to download
			FTPFile[] fileArray = this.ftpServiceInterface.getResponseFilesInfo();
			String fileName = this.getBondIRLastFileInfo(fileArray).getName();
			
			// controllo file gi� scaricato / dati gi� scaricati
			if(this.ftpFileEAOLocal.findByName(fileName) != null) {
				
				defaultLogger.warn(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' already downloaded. New data not available."));
				monitorLogger.warn(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' already downloaded. New data not available."));
				
				return;
			}
			
			// download file
			FileOutputStream fileOutputStream = new FileOutputStream(new File(ReutersBatchBean.TEMP_FILE_ABSOLUTE_PATH));
			this.ftpServiceInterface.downloadResponseFile(fileName, fileOutputStream);
			
			// parse file
			// TODO
			/*ReautersResponseParser reutersResponseParser = new BloombergResponseParser(new File(ReutersTimerBean.TEMP_FILE_ABSOLUTE_PATH));
			ReautersResponseFileMapping ReautersResponseFileMapping = reutersResponseParser.parse();
			ReutersTimerBean.defaultLogger.debug("Parsing successfully completed.");*/
			List<HistoricalPricesEntity> hisPrEntityList = this.convertBondIRData(/*reautersResponseFileMapping*/new File(ReutersBatchBean.TEMP_FILE_ABSOLUTE_PATH));
			
			// persist data
			for(HistoricalPricesEntity hisPrEntity : hisPrEntityList) {
				
				this.historicalPricesEAOLocal.add(hisPrEntity);
			}
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Persisting data successfully completed."));
			

			// save information about executed batch
			BatchEntity batchEntity = new BatchEntity("Reuters", "Bond IR data download");
			this.batchEAOLocal.add(batchEntity);
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Batch info successfully stored."));
			
			// save information about downloaded file
			File file = new File(ReutersBatchBean.TEMP_FILE_ABSOLUTE_PATH);
			String fileContent = this.getFileContent(file);
			FTPFileEntity fileEntity = new FTPFileEntity(fileName, fileContent, batchEntity.getBatchId());
			fileEntity = this.ftpFileEAOLocal.add(fileEntity);
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "File info successfully stored."));
			
			// update persisted data
			for(HistoricalPricesEntity hisPrEntity : hisPrEntityList) {
				// set p_file_id for each HistoricalPricesEntity
				hisPrEntity.setParentFileId(fileEntity.getParentBatchId());
				
				this.historicalPricesEAOLocal.update(hisPrEntity);
			}
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Updating prices history with batch and data source file info successfully completed."));
			
			// change status from oneShot to disable for each ex-oneShot reuters instrument
			for(HistoricalPricesEntity hisPrEntity : hisPrEntityList) {
				int instrId = hisPrEntity.getId().getInstrumentId();
				InstrumentsEntity instrEntity = this.instrEAOLocal.findByPrimaryKey(instrId);
				
				if(instrEntity.getStatus().equalsIgnoreCase("O")) {
					instrEntity.setStatus("D");
				}
				
				this.historicalPricesEAOLocal.update(hisPrEntity);
			}
			this.reutersManagerBeanLocal.updateReutersRequest();
			
			
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Batch \'bondInterestRatesBatch\' correctly executed."));
			monitorLogger.debug(new StandardLogMessage(this.currentUser, "Batch \'bondInterestRatesBatch\' correctly executed."));
		}
		catch(Exception e) {
			defaultLogger.error(new StandardLogMessage(this.currentUser, e.toString()));
			defaultLogger.error(new StandardLogMessage(this.currentUser, e.getMessage()));
			
			monitorLogger.error(new StandardLogMessage(this.currentUser, e.toString()));
			monitorLogger.error(new StandardLogMessage(this.currentUser, e.getMessage()));
			
			StackTraceElement[] stackTraceElements = e.getStackTrace();
			for(StackTraceElement element : stackTraceElements) {
				defaultLogger.error(new StandardLogMessage(this.currentUser, element.toString()));
				monitorLogger.error(new StandardLogMessage(this.currentUser, element.toString()));
			}
			
			defaultLogger.error(new StandardLogMessage(this.currentUser, "Computation failed."));
			monitorLogger.error(new StandardLogMessage(this.currentUser, "Computation failed."));
		}
		
	}
    
    
    
    
    
    
    private void getFileFromFTP() {
    	
    }
    
    
    private void getFileFromClient() {
    	
    }
    
	
	
	/*private List<HistoricalPricesEntity> convertBondIRData(ReautersResponseFileMapping reautersResponseFileMapping) {
		List<Object[]> dataMatrix = reautersResponseFileMapping.getData();
		
		List<HistoricalPricesEntity> list = new ArrayList<HistoricalPricesEntity>();
		
		for(Object[] record : dataMatrix) {
			HistoricalPricesEntity hisPrEntity = new HistoricalPricesEntity();
			HistoricalPricesEntityPK hisPrEntityPK = new HistoricalPricesEntityPK();
			
			try {
				int instrumentId = (instrEAOLocal.findByBloombergCode((String)record[0])).getInstrumentId();
				hisPrEntityPK.setInstrumentId(instrumentId);
				hisPrEntityPK.setPriceDate(Integer.parseInt((String)record[4]));
				hisPrEntity.setId(hisPrEntityPK);
				hisPrEntity.setClosingPrice(new BigDecimal((String)record[3]));
				
				list.add(hisPrEntity);
			} catch (Exception e) {
				e.printStackTrace();
				
				defaultLogger.error("Cannot convert from raw data to HistoricalPricesEntity.");
			}
			
			
		}
		
		
		return list;
	}*/
	
	private List<HistoricalPricesEntity> convertBondIRData(File file) throws Exception {
		List<HistoricalPricesEntity> list = new ArrayList<HistoricalPricesEntity>();
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		
		// salto la prima riga d'intestazione
		String line = br.readLine();
		
		line = br.readLine();
		while(line != null) {
			String[] values = line.split(",");
			
			// check corrupted data
			if(values.length < 3) {
				
				/*ReutersTimerBean.defaultLogger.error("Missing values in data file.");
				
				throw new Exception("Missing values in data file.");*/
				
				defaultLogger.warn(new StandardLogMessage(this.currentUser, "Missing values in data file. Corrupted line: \'" + line + "\'"));
				
				// send a mail
				
				line = br.readLine();
				
				continue;
				
			}
			
			
			String ricCode = values[0];
			int date = Integer.parseInt(values[1]);
			String yield = values[2];
			
			HistoricalPricesEntity hisPrEntity = new HistoricalPricesEntity();
			HistoricalPricesEntityPK hisPrEntityPK = new HistoricalPricesEntityPK();
			
			InstrumentsEntity instrEntity = this.instrEAOLocal.findByRICCode(ricCode);
			if(instrEntity == null) {
				defaultLogger.error(new StandardLogMessage(this.currentUser, "Instrument having RICCODE \'" + ricCode + "\' not fount in Static Data. Check Static Data and Reuters request alignment."));
				
				throw new Exception(new StandardLogMessage(this.currentUser, "Instrument having RICCODE \'" + ricCode + "\' not fount in Static Data. Check Static Data and Reuters request alignment.").toString());
			}
			
			int instrumentId = instrEntity.getInstrumentId();
			hisPrEntityPK.setInstrumentId(instrumentId);
			hisPrEntityPK.setPriceDate(date);
			hisPrEntity.setId(hisPrEntityPK);
			hisPrEntity.setClosingPrice(new BigDecimal(yield));
			
			list.add(hisPrEntity);
			
			
			line = br.readLine();
		}
		
		
		return list;
	}
	

	private String getFileContent(File file) throws Exception {
		BufferedReader br = new BufferedReader(new FileReader(file));
		String fileContent = new String();
		
		String line = br.readLine();
		while(line != null) {
			fileContent += line + "\n";
			
			line = br.readLine();
		}
		
		return fileContent;
	}
	
	
	
	private FTPFile getBondIRLastFileInfo(FTPFile[] fileArray) throws Exception {
		
		List<FTPFile> csvFileList = new ArrayList<FTPFile>();
		List<FTPFile> tempList = new ArrayList<FTPFile>();
		String fileName;
		String[] fileNameComponent;
		
		for(FTPFile file : fileArray) {
			fileName = file.getName();
			if(fileName.substring(fileName.length() - 4, fileName.length()).equalsIgnoreCase(".csv")) {
				tempList.add(file);
			}
		}
		
		
		for(FTPFile file : tempList) {
			fileName = file.getName();
			if(fileName.indexOf("NIR_") != -1) {
				csvFileList.add(file);
			}
		}
		
		if(csvFileList.size() < 1) {
			
			throw new Exception("Data not available.");
		}
		
		// file name pattern:  NIR_yyyymmdd.csv
		int yyyymmddMAX = -1;
		for(FTPFile file : csvFileList) {
			fileName = file.getName();
			
			fileNameComponent = fileName.split("\\.");
			fileNameComponent = fileNameComponent[0].split("_");
			
			int yyyymmddTEMP = Integer.parseInt(fileNameComponent[1]);
			if(yyyymmddTEMP > yyyymmddMAX) {
				yyyymmddMAX = yyyymmddTEMP;
			}
		}
		
		fileName = "NIR_" + Integer.toString(yyyymmddMAX) + ".csv";
		
		FTPFile file = new FTPFile();
		file.setName(fileName);
		
		return file;
	}
    
    

}
