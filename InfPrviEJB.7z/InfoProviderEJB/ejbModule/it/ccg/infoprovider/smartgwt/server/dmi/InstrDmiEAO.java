package it.ccg.infoprovider.smartgwt.server.dmi;



import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.bean.timer.BloombergTimerBeanLocal;
import it.ccg.infoprovider.server.bean.timer.ReutersTimerBeanLocal;
import it.ccg.infoprovider.server.data.TimerData;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.util.Date;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;

/**
 * Session Bean implementation class CmtEAO
 */
@Stateless
public class InstrDmiEAO implements InstrDmiEAOLocal {
	
	@PersistenceContext(name="InstrEM", unitName="InfoProviderEJB")
	private EntityManager em;
	
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
	
	@EJB
	private BuiltInDmiCmtEAOLocal builtInDmiCmtEAOLocal;
	
	@EJB
	private ReutersTimerBeanLocal reutersTimerBeanLocal;
	
	@EJB
	private BloombergTimerBeanLocal bloombergTimerBeanLocal;
	
	
	

    /**
     * Default constructor. 
     */
    public InstrDmiEAO() {
    	this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
    
    @Override
	public DSResponse update(DSRequest dsRequest) throws Exception {
    	
    	defaultLogger.debug(new StandardLogMessage(this.currentUser, "Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
    	
    	DSResponse dsResponse = builtInDmiCmtEAOLocal.update(dsRequest);
    	
    	
    	if(dsRequest.getValues().get("status") != null) {
    		
    		if(((String)dsRequest.getOldValues().get("provider")).equalsIgnoreCase("Reuters")) {
    			
    			// Delete if it already exists
    			if(this.reutersTimerBeanLocal.getTimer("infoprovider_updateReutersRequest") != null) {
    				this.reutersTimerBeanLocal.deleteTimer("infoprovider_updateReutersRequest");
    			}
    			
    			TimerData timerData = new TimerData("infoprovider_updateReutersRequest", true, new Date(new Date().getTime() + 60*1000), "Reuters", "updateReutersRequest");
    			
    			
    			this.reutersTimerBeanLocal.createSingleActionTimer(timerData);
    		}
    		else if(((String)dsRequest.getOldValues().get("provider")).equalsIgnoreCase("Bloomberg")) {
    			
    			// Delete if it already exists
    			if(this.bloombergTimerBeanLocal.getTimer("infoprovider_updateBloombergRequest") != null) {
    				this.bloombergTimerBeanLocal.deleteTimer("infoprovider_updateBloombergRequest");
    			}
    			
    			TimerData timerData = new TimerData("infoprovider_updateBloombergRequest", true, new Date(new Date().getTime() + 60*1000), "Bloomberg", "updateBloombergRequest");
    			
    			
    			this.bloombergTimerBeanLocal.createSingleActionTimer(timerData);
    		}
    		else {
    			
    		}
    	}
    	
    	
		return dsResponse;
	}
	

}
