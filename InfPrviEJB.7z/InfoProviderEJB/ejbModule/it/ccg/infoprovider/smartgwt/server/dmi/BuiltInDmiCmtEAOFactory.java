package it.ccg.infoprovider.smartgwt.server.dmi;

import it.ccg.infoprovider.server.service.system.LocalBeanLookup;

import org.apache.log4j.Logger;

public class BuiltInDmiCmtEAOFactory {
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	
	public BuiltInDmiCmtEAOFactory() {
		
	}
	
	
	
	public BuiltInDmiCmtEAOLocal create() {

		BuiltInDmiCmtEAOLocal builtInDmiCmtEAOLocal = (BuiltInDmiCmtEAOLocal)LocalBeanLookup.lookup(BuiltInDmiCmtEAOLocal.class.getName());
		
		return builtInDmiCmtEAOLocal;
	}


}
