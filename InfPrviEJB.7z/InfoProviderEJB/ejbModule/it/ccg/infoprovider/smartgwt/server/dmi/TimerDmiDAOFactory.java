package it.ccg.infoprovider.smartgwt.server.dmi;

import it.ccg.infoprovider.server.service.system.LocalBeanLookup;


import org.apache.log4j.Logger;

public class TimerDmiDAOFactory {
	
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	
	
	public TimerDmiDAOFactory() {
		
	}
	
	
	
	public TimerDmiDAOLocal create() {
        
        TimerDmiDAOLocal timerDmiDAOLocal = (TimerDmiDAOLocal)LocalBeanLookup.lookup(TimerDmiDAOLocal.class.getName());
		
		return timerDmiDAOLocal;
	}

}
