package it.ccg.infoprovider.smartgwt.server.dmi;

import it.ccg.infoprovider.server.service.system.LocalBeanLookup;

import org.apache.log4j.Logger;

public class HisPrDmiEAOFactory {
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	
	public HisPrDmiEAOFactory() {
		
	}
	
	
	
	public HisPrDmiEAOLocal create() {

		HisPrDmiEAOLocal hisPrDmiEAOLocal = (HisPrDmiEAOLocal)LocalBeanLookup.lookup(HisPrDmiEAOLocal.class.getName());
		
		return hisPrDmiEAOLocal;
	}

}
