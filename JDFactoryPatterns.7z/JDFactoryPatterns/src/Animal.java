
public interface Animal {
	public void speak();
	public void eat();
	public void dream();
	public void miPresento();
}
