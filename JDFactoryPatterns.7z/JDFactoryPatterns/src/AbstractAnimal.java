
public class AbstractAnimal {
	public void eat() {
		System.out.println("mangio");
	}
	public void dream () {
		System.out.println("dormo");
	}
	public void speack () {
		System.out.println("parlo");
	}
	public void miPresento() {
		// TODO Auto-generated method stub
		System.out.println("Mi presento ...");	
	}
}
