package ccg.ftrr.freader.batch;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;

public class FileFilter implements FilenameFilter {

    private String estensione = null;    
    /**
     * Creates a new instance of FileFilter 
     */
    public FileFilter() {
    		this.estensione = ".sql";  
    	 }
  	public boolean accept(File dir,String name){
        boolean valido = false;        
        //verifica l'estensione
        valido = name.endsWith(this.estensione);
        return valido;
    }

	private static void GetProperties() throws IOException {
		PropertyFiles pf = new PropertyFiles();
		
	}
}


