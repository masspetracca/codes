package it.ccg.tcejb.server.security;

import it.ccg.tcejb.server.exception.DataNotAvailableException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.Attribute;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;

import org.apache.log4j.Logger;

import sun.misc.BASE64Decoder;


public class LDAPManager {
	

	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	private Hashtable<String, String> env;
	private InitialLdapContext ctx;
	
	private String o;
	private String c;
	private String ou;
	
	
	
	public LDAPManager() throws Exception {
		
		this.env = new Hashtable<String, String>();
		/*
	     * Raffaele De Lauri
	     * TN_CCG16966
	     * 28/04/2015
	     * modifico l'instazazione della classe controllando il tipo di autentication attiva
	     */
		if (SystemProperties.getSystemProperty("u.autentication").equalsIgnoreCase("ldap")){
			this.env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			this.env.put(Context.PROVIDER_URL, "ldap://" + SystemProperties.getSystemProperty("ldap.address") + ":" + SystemProperties.getSystemProperty("ldap.port"));
			this.env.put(Context.SECURITY_AUTHENTICATION, "simple");
			this.env.put(Context.SECURITY_PRINCIPAL, SystemProperties.getSystemProperty("ldap.user"));
			this.env.put(Context.SECURITY_CREDENTIALS, decodeBASE64(SystemProperties.getSystemProperty("ldap.password")));
		}else if(SystemProperties.getSystemProperty("u.autentication").equalsIgnoreCase("active")){
			this.env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			this.env.put(Context.PROVIDER_URL, "ldap://" + SystemProperties.getSystemProperty("active.address") + ":" + SystemProperties.getSystemProperty("active.port"));
			this.env.put(Context.SECURITY_AUTHENTICATION, "simple");
			this.env.put(Context.SECURITY_PRINCIPAL, SystemProperties.getSystemProperty("active.user"));
			this.env.put(Context.SECURITY_CREDENTIALS, decodeBASE64(SystemProperties.getSystemProperty("active.password")));
		}else{
			throw (new Exception("NO autentication property"));
		}
		
		this.o = SystemProperties.getSystemProperty("ldap.user_set.o");
		this.c = SystemProperties.getSystemProperty("ldap.user_set.c");
		this.ou = SystemProperties.getSystemProperty("ldap.user_set.ou");
	}
	
	
	public LDAPUserDTO getUserInfoByUserId(String usrId) throws Exception{
		
		LDAPUserDTO ldapUserDTO = null;
		
		try {
			this.connect();
			 /*
		     * Raffaele De Lauri
		     * TN_CCG16966
		     * 28/04/2015
		     * modifico la procedura di reperimento dei dati in base al metodo di autenticazione utilizzato
		     */
			if (SystemProperties.getSystemProperty("u.autentication").equalsIgnoreCase("ldap")){
				NamingEnumeration<NameClassPair> namingEnumeration = this.ctx.list("o=" + this.o + ",c=" + this.c);
				
				while(namingEnumeration.hasMore()) {
					
				    NameClassPair ncp = namingEnumeration.next();
				    
				    Attributes attributes = ctx.getAttributes(ncp.getNameInNamespace());
				    
				    String cn = attributes.get("cn") != null ? (String)attributes.get("cn").get() : null;
				    String sn = attributes.get("sn") != null ? (String)attributes.get("sn").get() : null;
				    String uid = attributes.get("uid") != null ? (String)attributes.get("uid").get() : null;
				    
				    String mail = attributes.get("mail") != null ? (String)attributes.get("mail").get() : null;
				    /*
				     * Raffaele De Lauri
				     * TN_CCG16966
				     * 20/04/2015
				     * modifico la procedura di reperimento del campo OU
				     */
				    String ou="";
				    if (attributes.get("ou") != null){
					    for (int i = 0 ;i<attributes.get("ou").size();i++){
					    	if ((attributes.get("ou").size()==1) || (attributes.get("ou").size()-1 == i)){
					    		ou+= attributes.get("ou") != null ? (String)attributes.get("ou").get(i) : null;
					    	}else{
					    		ou+= attributes.get("ou") != null ? (String)attributes.get("ou").get(i)+"," : null;
					    	}
					    }
				    }else{
				    	ou=null;
				    }
				    /*
				     * fine TN_CCG16966
				     */
				    			    
				    // This check is to exclude not correctly formatted PortalAdmin LDAP entries
				    if((cn != null) && (sn != null) && (uid != null) && uid.compareToIgnoreCase(usrId)==0) {
				    	ldapUserDTO = new LDAPUserDTO(cn, sn, uid, this.o, this.c, null, mail, ou);
				    	break;
				    }				    
				}
			}else if(SystemProperties.getSystemProperty("u.autentication").equalsIgnoreCase("active")){
				SearchControls constraints = new SearchControls();
	            constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
	            String[] attrIDs = { "distinguishedName", "sn", "givenname", "mail", "telephonenumber", "cn"};
	            constraints.setReturningAttributes(attrIDs);
	            
				//NamingEnumeration<NameClassPair> namingEnumeration = this.ctx.list("OU=CCG,OU=LSEG,DC=lseg,DC=stockex,DC=local");
				NamingEnumeration namingEnumeration = ctx.search(SystemProperties.getSystemProperty("active.search1")+","+SystemProperties.getSystemProperty("active.search2")+","+SystemProperties.getSystemProperty("active.search3"), "sAMAccountName=" + usrId, constraints);
				
				while(namingEnumeration.hasMore()) {
					
				    //NameClassPair ncp = namingEnumeration.next();
				    
				    Attributes attributes = ((SearchResult)namingEnumeration.next()).getAttributes(); //ctx.getAttributes(ncp.getNameInNamespace());
				    
				    String cn = (attributes.get("givenname") != null ? (String)attributes.get("givenname").get() : null) +" "+(attributes.get("sn") != null ? (String)attributes.get("sn").get() : null);
				    String sn = attributes.get("sn") != null ? (String)attributes.get("sn").get() : null;
				    String mail = attributes.get("mail") != null ? (String)attributes.get("mail").get() : null;
				   
				    String ou="";
				    String uid="";
				    if (attributes.get("distinguishedname") != null){
				    	Attribute atr = attributes.get("distinguishedname"); 
				    	NamingEnumeration nE =atr.getAll();
				    	while(nE.hasMoreElements()){
				    		String dName = (String) nE.next();
				    		String[] attrs = dName.split(",");
				    		for (int i = 0 ;i<attrs.length;i++){
				    			if (attrs[i].toLowerCase().startsWith("ou=")){
						    		ou+= attrs[i] != null ? attrs[i].replaceAll("OU=", "")+"," : null;
						    	}else if(attrs[i].toLowerCase().startsWith("cn=")){
						    	   uid=	attrs[i] != null ? attrs[i].replaceAll("CN=", "") : null;
						    	}
						    }
				    	}
				    	ou=ou.substring(0,ou.length()-1);					    
				    }else{
				    	ou=null;
				    }
				    			    
				    // This check is to exclude not correctly formatted PortalAdmin LDAP entries
				    if((cn != null) && (sn != null) && (uid != null) && uid.compareToIgnoreCase(usrId)==0) {
				    	ldapUserDTO = new LDAPUserDTO(cn, sn, uid, this.o, this.c, null, mail, ou);
				    	break;
				    }
				}	
			}else{
				throw (new Exception("NO autentication property"));
			} 
		}
		catch(NamingException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw e;
		}
		finally {
			this.disconnect();
		}
		
		//se non troviamo l'utente
		if(ldapUserDTO==null){
			throw new DataNotAvailableException("NO user having id " + usrId + " found.");
		}
		//se lo troviamo 
		else{
			//ma il company code � nulla o vuota lanciamo un'eccezione
			if(ldapUserDTO.getOu()==null||ldapUserDTO.getOu().trim().equalsIgnoreCase("")){
				throw new DataNotAvailableException("NO company code associated to the user id " + usrId + " found.");
			}
		}
		return ldapUserDTO;
	}
	
	public List<LDAPUserDTO> listUsers() throws Exception {
		
		List<LDAPUserDTO> userList = new ArrayList<LDAPUserDTO>();
		
		try {
			this.connect();
			
			NamingEnumeration<NameClassPair> namingEnumeration = this.ctx.list("o=" + this.o + ",c=" + this.c);
			
			LDAPUserDTO ldapUserDTO = null;
			
			while(namingEnumeration.hasMore()) {
				
			    NameClassPair ncp = namingEnumeration.next();
			    
			    Attributes attributes = ctx.getAttributes(ncp.getNameInNamespace());
			    
			    String cn = attributes.get("cn") != null ? (String)attributes.get("cn").get() : null;
			    String sn = attributes.get("sn") != null ? (String)attributes.get("sn").get() : null;
			    String uid = attributes.get("uid") != null ? (String)attributes.get("uid").get() : null;
			    
			    String mail = attributes.get("mail") != null ? (String)attributes.get("mail").get() : null;
			    String ou = attributes.get("ou") != null ? (String)attributes.get("ou").get() : null;
			    
			    // non vedo o e c come attributi
			    //String o = attributes.get("o") != null ? (String)attributes.get("o").get() : null;
			    //String c = attributes.get("c") != null ? (String)attributes.get("c").get() : null;
			    
			    // non ritorno mai la password
			    //String userpassword = attributes.get("userpassword") != null ? (String)attributes.get("userpassword").get() : null;
			    
			    
			    ldapUserDTO = new LDAPUserDTO(cn, sn, uid, this.o, this.c, null, mail, ou);
			    
			    // This check is to exclude not correctly formatted PortalAdmin LDAP entries
			    if((cn != null) && (sn != null) && (uid != null)) {
				    
				    userList.add(ldapUserDTO);
			    }
			    else {
			    	
			    	logger.warn(new StandardLogMessage("Not valid LDAP user. NameClassPair: " + ncp.toString() + "; LDAPUserDTO: " + ldapUserDTO.toString()));
			    }
			    
			}
			
		} 
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		finally {
			
			this.disconnect();
		}
		
		
		return userList;
	}
	
	
	public LDAPUserDTO getUserByContextName(String userContextName) throws Exception {
		
		LDAPUserDTO ldapUserDTO = null;
		
		try {
			this.connect();
			
			Attributes attributes = this.ctx.getAttributes(userContextName);
			
			String cn = attributes.get("cn") != null ? (String)attributes.get("cn").get() : null;
		    String sn = attributes.get("sn") != null ? (String)attributes.get("sn").get() : null;
		    String uid = attributes.get("uid") != null ? (String)attributes.get("uid").get() : null;
		    
		    String mail = attributes.get("mail") != null ? (String)attributes.get("mail").get() : null;
		    String ou = attributes.get("ou") != null ? (((String)attributes.get("ou").get()).equalsIgnoreCase("") ? null : (String)attributes.get("ou").get()) : null;
			

		    // non vedo o e c come attributi
		    //String o = attributes.get("o") != null ? (String)attributes.get("o").get() : null;
		    //String c = attributes.get("c") != null ? (String)attributes.get("c").get() : null;
		    
		    // non ritorno mai la password
		    //String userpassword = attributes.get("userpassword") != null ? (String)attributes.get("userpassword").get() : null;
		    
		    
		    ldapUserDTO = new LDAPUserDTO(cn, sn, uid, this.o, this.c, null, mail, ou);
		    
		}
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
		
		return ldapUserDTO;
	}
	
	
	public LDAPUserDTO getUserByCN(String cn) throws Exception {
		
		LDAPUserDTO ldapUserDTO = null;
		
		try {
			this.connect();
			
			Attributes attributes = this.ctx.getAttributes("cn=" + cn + ",o=" + this.o + ",c=" + this.c);
			
			//String cn = attributes.get("cn") != null ? (String)attributes.get("cn").get() : null;
		    String sn = attributes.get("sn") != null ? (String)attributes.get("sn").get() : null;
		    String uid = attributes.get("uid") != null ? (String)attributes.get("uid").get() : null;
		    
		    String mail = attributes.get("mail") != null ? (String)attributes.get("mail").get() : null;
		    String ou = attributes.get("ou") != null ? (String)attributes.get("ou").get() : null;
			

		    // non vedo o e c come attributi
		    //String o = attributes.get("o") != null ? (String)attributes.get("o").get() : null;
		    //String c = attributes.get("c") != null ? (String)attributes.get("c").get() : null;
		    
		    // non ritorno mai la password
		    //String userpassword = attributes.get("userpassword") != null ? (String)attributes.get("userpassword").get() : null;
		    
		    
		    ldapUserDTO = new LDAPUserDTO(cn, sn, uid, this.o, this.c, null, mail, ou);
			
		} 
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
		
		return ldapUserDTO;
	}
	
	
	public LDAPUserDTO getUserByUID(String uid) throws Exception {
		
		LDAPUserDTO ldapUserDTO = null;
		
		try {
			
			List<LDAPUserDTO> list = this.listUsers();
			
			for(LDAPUserDTO user : list) {
				
				if(user.getUid() != null) {
					
					if(user.getUid().equalsIgnoreCase(uid)) {
						
						ldapUserDTO = user;
						
						break;
					}
				}
				else {
					
					logger.warn("User " + user + " has no uid.");
				}
				
			}
			
		} 
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
		
		return ldapUserDTO;
	}
	
	
	public Map<String, String> get_O_C_OU() throws Exception {
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("o", this.o);
		map.put("c", this.c);
		map.put("ou", this.ou);
		
		
		return map;
	}
	
	
	public void addUser(LDAPUserDTO ldapUserDTO) throws Exception {
		
		try {
			this.connect();
			
			BasicAttribute cn = new BasicAttribute("cn", ldapUserDTO.getCn());  
			BasicAttribute sn = new BasicAttribute("sn", ldapUserDTO.getSn());
			BasicAttribute uid = new BasicAttribute("uid", ldapUserDTO.getUid());
			BasicAttribute pwd = new BasicAttribute("userpassword",ldapUserDTO.getUserpassword());
			BasicAttribute mail = new BasicAttribute("mail", ldapUserDTO.getMail());
			
			BasicAttribute ou = new BasicAttribute("ou", ldapUserDTO.getOu());
			
			BasicAttribute objClass = new BasicAttribute("objectclass", "inetOrgPerson");
			objClass.add("ePerson");
			
	        // build the entry  
	        Attributes attributes = new BasicAttributes(); 
	        attributes.put(cn);  
	        attributes.put(sn);
	        attributes.put(uid);
	        attributes.put(pwd);
	        attributes.put(mail);
	        attributes.put(ou);
	        
	        attributes.put(objClass); 
	        
	        this.ctx.createSubcontext("cn=" + ldapUserDTO.getCn() + ",o=" + ldapUserDTO.getO() + ",c=" + ldapUserDTO.getC(), attributes);
	        
	        
	        logger.info(new StandardLogMessage("Added new user: " + ldapUserDTO.toString()));
		} 
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
	}
	
	
	public void removeUser(LDAPUserDTO ldapUserDTO) throws Exception {
		
		try {
			this.connect();
			
	        this.ctx.destroySubcontext("cn=" + ldapUserDTO.getCn() + ",o=" + ldapUserDTO.getO() + ",c=" + ldapUserDTO.getC());
	        
	        
	        logger.info(new StandardLogMessage("Removed user: " + ldapUserDTO.toString()));
		} 
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
	}
	
	// 
	public void removeUser(String userContextName) throws Exception {
		
		try {
			this.connect();
			
	        this.ctx.destroySubcontext(userContextName);
	        
	        
	        logger.info(new StandardLogMessage("Removed user: " + userContextName));
		} 
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
	}
	
	public void resetUserPassword(LDAPUserDTO ldapUserDTO,String pwd) throws Exception {
		System.out.println("LDAPManager.resetUserPassword(LDAPUserDTO ldapUserDTO,String pwd)");
		try {
			this.connect();
			
			ModificationItem[] mods = new ModificationItem[1];

			BasicAttribute mod0 = new BasicAttribute("userpassword", pwd);

            mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, mod0);
            
            System.out.println();
            this.ctx.modifyAttributes("cn=" + ldapUserDTO.getCn() + ",o=" + ldapUserDTO.getO() + ",c=" + ldapUserDTO.getC(), mods);
	        
	        logger.info(new StandardLogMessage("Password modified for user: " + ldapUserDTO.toString()));
		} 
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
	}
	
	private void connect() throws Exception {
		
		try {
			this.ctx = new InitialLdapContext(this.env, null);
		}
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
		//logger.debug(new StandardLogMessage("User \'" + this.env.get(Context.SECURITY_PRINCIPAL) + "\' connected to \'" + this.env.get(Context.PROVIDER_URL) + "\'"));
	}
	
	
	private void disconnect() throws Exception {
		
		try {
			this.ctx.close();
		}
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
		//logger.debug(new StandardLogMessage("Disconnected from \'" + this.env.get(Context.PROVIDER_URL) + "\'"));
	}
	
public static String decodeBASE64(String input) throws Exception {
		
		String output = null;
		
		try {
			BASE64Decoder decoder = new BASE64Decoder();
			
			output = new String(decoder.decodeBuffer(input));
		}
		catch(Exception e) {
			
			e.printStackTrace();
			
			throw e;
		}
		
		
		return output;
	}
	
}