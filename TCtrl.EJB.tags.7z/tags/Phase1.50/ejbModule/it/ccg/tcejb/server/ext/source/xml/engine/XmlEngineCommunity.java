package it.ccg.tcejb.server.ext.source.xml.engine;

import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.ext.source.xml.ec.ENTITY;
import it.ccg.tcejb.server.ext.source.xml.ec.ObjectFactory;
import it.ccg.tcejb.server.ext.source.xml.ec.WHOLE;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

public class XmlEngineCommunity {
	private static final Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	public static void main(String[] args){
		try {
			new XmlEngineCommunity().read();
		} catch (BackEndException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public WHOLE read(String path) throws JAXBException, BackEndException{
		try {
			InputStream inputStream = new FileInputStream(path);
			Reader reader;
			
			reader = new InputStreamReader(inputStream, "UTF-8");
			
			
			JAXBContext jaxbContext;
			WHOLE cont = null;
			
			jaxbContext = JAXBContext.newInstance(ObjectFactory.class, WHOLE.class);
			
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			cont = (WHOLE)jaxbUnmarshaller.unmarshal(reader);
				
			return cont;
		} catch (UnsupportedEncodingException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		} catch (FileNotFoundException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		}
	}
	
	/**
	 * Methods that use a determinate path
	 * C:/Users/rdelauri/Desktop/Antiterrorismo/Antiterrorismo/01_Requisiti utente/Flussi/onu/AQList.xml
	 * @return
	 * @throws BackEndException 
	 */
	public WHOLE read() throws BackEndException{
		File file = new File("C:/Users/rdelauri/Desktop/Antiterrorismo/Antiterrorismo/01_Requisiti utente/Flussi/XML comunitari/global.xml");
		JAXBContext jaxbContext;
		WHOLE cont=null;
		try {
			jaxbContext = JAXBContext.newInstance(ObjectFactory.class, WHOLE.class);
			
			
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			cont = (WHOLE)jaxbUnmarshaller.unmarshal(file);
			/*for(REGULATION r : cont.getRegulation()){
				System.out.println(r.getLink());
			}*/

			for (ENTITY e :cont.getENTITY()){
				System.out.println(e.getId());
			}
			
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		}
		return cont;
	}
	
	public WHOLE read(File file) throws BackEndException{

		JAXBContext jaxbContext;
		WHOLE cont = null;
		try {
			jaxbContext = JAXBContext.newInstance(ObjectFactory.class, WHOLE.class);
			
			
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			cont = (WHOLE)jaxbUnmarshaller.unmarshal(file);
			
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		}
		return cont;
	}
	
	public WHOLE read(InputStream iStream) throws BackEndException{

		JAXBContext jaxbContext;
		WHOLE cont = null;
		try {
			jaxbContext = JAXBContext.newInstance(ObjectFactory.class, WHOLE.class);
			
			
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			cont = (WHOLE)jaxbUnmarshaller.unmarshal(iStream);
			
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		}
		return cont;
	}
}
