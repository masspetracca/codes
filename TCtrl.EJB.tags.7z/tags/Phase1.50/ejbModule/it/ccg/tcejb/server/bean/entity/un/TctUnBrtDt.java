package it.ccg.tcejb.server.bean.entity.un;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTUNBRTDT database table.
 * 
 */
@Entity
@Table(name="TCTUNBRTDT")
@NamedQueries({
	@NamedQuery(name="deleteUnBrtDtEveryEntity", query="DELETE FROM TctUnBrtDt"),
	@NamedQuery(name="getUnBrtDtEntitiesById", query="SELECT entity FROM TctUnBrtDt entity WHERE entity.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctUnBrtDt implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="BIRTHDATID")
	private int birthDatId;

	@Column(nullable=false)
	private int entityid;

	@Column(length=30)
	private String typeOfDate;

	@Column(nullable=false)
	private int year;

	//bi-directional many-to-one association to TctUnIndiv
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	private TctUnIndiv tctunindiv;

    public TctUnBrtDt() {
    }

	public String getTypeOfDate() {
		return this.typeOfDate;
	}

	public void setTypeOfDate(String typeOfDate) {
		if (typeOfDate != null && typeOfDate.length()>30){
			ejbLogger.debug(typeOfDate+" >30 than truncate");
			this.typeOfDate = typeOfDate.substring(0, 29);
		}else{
			this.typeOfDate = typeOfDate;
		}
	}

	public int getYear() {
		return this.year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public TctUnIndiv getTctunindiv() {
		return this.tctunindiv;
	}

	public void setTctunindiv(TctUnIndiv tctunindiv) {
		this.tctunindiv = tctunindiv;
	}

	/**
	 * @return the birthDatId
	 */
	public int getBirthDatId() {
		return birthDatId;
	}

	/**
	 * @param birthDatId the birthDatId to set
	 */
	public void setBirthDatId(int birthDatId) {
		this.birthDatId = birthDatId;
	}

	/**
	 * @return the entityid
	 */
	public int getEntityid() {
		return entityid;
	}

	/**
	 * @param entityid the entityid to set
	 */
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}
	
	
}