package it.ccg.tcejb.server.bean.entity.un;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTUNADDR database table.
 * 
 */
@Entity
@Table(name="TCTUNADDR")
@NamedQueries({
	@NamedQuery(name="deleteUnAddrEveryEntity", query="DELETE FROM TctUnAddr"),
	@NamedQuery(name="getUnAddrEntitiesById", query="SELECT entity FROM TctUnAddr entity WHERE entity.entityid = :entityId ORDER BY entity.addressId ASC")
})
public class TctUnAddr implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	/*@EmbeddedId
	private TctUnAddrPK id;*/
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ADDRID")
	private int addrId;

	@Column(nullable=false)
	private int entityid;

	@Column(nullable=false, length=255)
	private String country;

	//bi-directional many-to-one association to TctUnEntit
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	//@Transient
	private TctUnEntit tctunentit;

    public TctUnAddr() {
    }
	
	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		if (country !=null && country.length()>255){
			ejbLogger.debug(country+" >255 than truncate");
			this.country = country.substring(0, 254);
		}else{
			this.country = country;
		}
	}

	public TctUnEntit getTctunentit() {
		return this.tctunentit;
	}

	public void setTctunentit(TctUnEntit tctunentit) {
		this.tctunentit = tctunentit;
	}

	/**
	 * @return the addrId
	 */
	public int getAddrId() {
		return addrId;
	}

	/**
	 * @param addrId the addrId to set
	 */
	public void setAddrId(int addrId) {
		this.addrId = addrId;
	}

	/**
	 * @return the entityid
	 */
	public int getEntityid() {
		return entityid;
	}

	/**
	 * @param entityid the entityid to set
	 */
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}
	
	
}