package it.ccg.tcejb.server.ext.source.xml.un;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="INDIVIDUAL" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DATAID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                   &lt;element name="VERSIONNUM" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                   &lt;element name="FIRST_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="SECOND_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="THIRD_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="UN_LIST_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="REFERENCE_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="LISTED_ON" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *                   &lt;element name="NAME_ORIGINAL_SCRIPT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="COMMENTS1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="NATIONALITY">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="VALUE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="LIST_TYPE">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="VALUE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="LAST_DAY_UPDATED">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="VALUE" type="{http://www.w3.org/2001/XMLSchema}dateTime" maxOccurs="unbounded"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="INDIVIDUAL_ALIAS" maxOccurs="unbounded">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="QUALITY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="ALIAS_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="INDIVIDUAL_ADDRESS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="INDIVIDUAL_DATE_OF_BIRTH">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="TYPE_OF_DATE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="YEAR" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="INDIVIDUAL_PLACE_OF_BIRTH">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="CITY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="STATE_PROVINCE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="INDIVIDUAL_DOCUMENT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="SORT_KEY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="SORT_KEY_LAST_MOD" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {"individual"})
@XmlRootElement(name = "INDIVIDUALS")
public class Individuals {

    @XmlElement(name = "INDIVIDUAL", required = true)
    protected List<Individual> individual;

    /**
     * Gets the value of the individual property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the individual property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getINDIVIDUAL().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ConsolidatedList.Individuals.Individual }
     * 
     * 
     */
    public List<Individual> getINDIVIDUAL() {
        if (individual == null) {
            individual = new ArrayList<Individual>();
        }
        return this.individual;
    }


    

}
