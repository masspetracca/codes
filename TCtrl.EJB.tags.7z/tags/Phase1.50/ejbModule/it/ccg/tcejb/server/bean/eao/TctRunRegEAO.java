package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctRunRegEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctRunRegEAO
 */
@Stateless
@LocalBean
public class TctRunRegEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctRunRegEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctRunRegEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctRunRegEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctRunRegEntity identification data: run id = "+entity.getRunId() +" , company id = "+entity.getCmpnid()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	/*
	    	 * TN_CCG15485
	    	 * raffaele de lauri
	    	 * if user is TN_CCG15485 than set System
	    	 */
	    	if (sessionContext.getCallerPrincipal().getName().equalsIgnoreCase("UNAUTHENTICATED")){
	    		entity.setUpdUser("System");
	    	}else{
	    		entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	}
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));	
    }
        
    public void insertEntity(List<TctRunRegEntity> entities) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctRunRegEntity entity)"));
    	int idxToFlush = 0;
    	for (TctRunRegEntity entity :entities){
    		ejbLogger.debug(new StandardLogMessage("TctRunRegEntity identification data: run id = "+entity.getRunId() +" , company id = "+entity.getCmpnid()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	/*
	    	 * TN_CCG15485
	    	 * raffaele de lauri
	    	 * if user is TN_CCG15485 than set System
	    	 */
	    	if (sessionContext.getCallerPrincipal().getName().equalsIgnoreCase("UNAUTHENTICATED")){
	    		entity.setUpdUser("System");
	    	}else{
	    		entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	}
	    	
	    	this.manager.persist(entity);
	    	idxToFlush++;
	    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
	    		ejbLogger.debug(new StandardLogMessage("insert"));
		    	this.manager.flush();
	    	}
    	}
    	ejbLogger.debug(new StandardLogMessage("last insert"));
    	this.manager.flush();
    }
    
  	public void deleteEntity(TctRunRegEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctRunRegEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctRunRegEntity identification data: run id = "+entity.getRunId() +" , company id = "+entity.getCmpnid()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctRunRegEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctRunReg entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctRunRegEntity identification data: run id = "+entity.getRunId() +" , company id = "+entity.getCmpnid()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("U");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public TctRunRegEntity retrieveRunByRunDate(TctRunRegEntity entity) throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in int retrieveLatestID(TctDownReg entity)"));
    	ejbLogger.debug(new StandardLogMessage("Run date "+df.format(new Date(entity.getRunDate().getTime()))));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getRunLatestIDByRdt");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("rdt", entity.getRunDate());
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
    	TctRunRegEntity run = (TctRunRegEntity) q.getSingleResult();
		ejbLogger.debug(new StandardLogMessage("return"));
    	return run;
  	}
  	
  	public TctRunRegEntity retrievePreviousRun(TctRunRegEntity entity) throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in int retrieveLatestID(TctDownReg entity)"));
    	ejbLogger.debug(new StandardLogMessage("Run date "+df.format(new Date(entity.getRunDate().getTime()))));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getPrevRun");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("run", entity.getRunId());
    	q.setParameter("cmpn", entity.getCmpnid());
    	
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
    	List<TctRunRegEntity> runs = (List<TctRunRegEntity>) q.getResultList();
    	TctRunRegEntity run = null;
    	if (runs.size()>0){
    		run = runs.get(0);
    	}
		ejbLogger.debug(new StandardLogMessage("return"));
    	return run;
  	}
  	//********************AGGIUNTA*****************
  	public TctRunRegEntity retrieveByRunIdAndCmpnId(int runId,int companyId) throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in retrieveByRunId(int runId,int companyId)"));
  		//ejbLogger.debug(new StandardLogMessage("Run date "+df.format(new Date(entity.getRunDate().getTime()))));
  		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
  		Query q = this.manager.createNamedQuery("getByRunIdRunReg");
  		ejbLogger.debug(new StandardLogMessage("populate named query"));
  		q.setParameter("runId", runId);
  		q.setParameter("cmpnId", companyId);

  		ejbLogger.debug(new StandardLogMessage("getResultList"));
  		TctRunRegEntity run = (TctRunRegEntity) q.getSingleResult();
  		ejbLogger.debug(new StandardLogMessage("return"));
  		return run;
}
}
