package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctAggrEntEntity;
import it.ccg.tcejb.server.bean.entity.TctAggrEntEntityPK;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.TreeMap;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctAggrEntityEAO
 */
@Stateless
@LocalBean
public class TctAggrEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctAggrEntityEAO() {
        // TODO Auto-generated constructor stub
    }
    public void insertEntity(TctAggrEntEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctAggrEntEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctAggrEntEntity identification data: aggregated id = "+entity.getId().getAggregId()+" source "+entity.getSrcList()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));	
    }
        
    public void insertEntity(List<TctAggrEntEntity> entities) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctAggrEntEntity entity)"));
    	Date insertDate = new Date();
    	
    	int idxToFlush = 0;
    	for (TctAggrEntEntity entity :entities){
    		ejbLogger.debug(new StandardLogMessage("TctAggrEntEntity identification data: aggregated id = "+entity.getId().getAggregId()+" source "+entity.getSrcList()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(insertDate.getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	this.manager.persist(entity);
	    	idxToFlush++;
	    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
	    		ejbLogger.debug(new StandardLogMessage("insert"));
		    	this.manager.flush();
	    	}
    	}
    	ejbLogger.debug(new StandardLogMessage("last insert"));
    	this.manager.flush();
    }
    
  	public void deleteEntity(TctAggrEntEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctAggrEntEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctAggrEntEntity identification data: aggregated id = "+entity.getId().getAggregId()+" source "+entity.getSrcList()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctAggrEntEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctAggrEntEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctAggrEntEntity identification data: aggregated id = "+entity.getId().getAggregId()+" source "+entity.getSrcList()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("U");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public TctAggrEntEntity retrieveAggregatedById(TctAggrEntEntityPK entityId) throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in TctAggrEnt retrieveAggregatedById(String entityId)"));
       	ejbLogger.debug(new StandardLogMessage("entityId : "+entityId));
       	TctAggrEntEntity toReturn = this.manager.find(TctAggrEntEntity.class, entityId);
       	
  		return toReturn;
  		
  	}
  	
  	/*
	 * raffaele de lauri
	 * TN_CCG14891
	 */
  	public TreeMap<String,TctAggrEntEntity> getTreeMapByDonwloadId(int downloadID) throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in TreeMap<String,TctAggrEntEntity> getTreeMapByDonwloadId(int downloadID)"));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getAggrEntByDownloadID");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("downloadid", downloadID);
    	
    	List<TctAggrEntEntity> appoReturn = (List<TctAggrEntEntity>) q.getResultList();
    	TreeMap<String,TctAggrEntEntity> mapToReturn = new TreeMap<String,TctAggrEntEntity>(); 
    	for(TctAggrEntEntity ent : appoReturn){
    		/*
			 * raffaele de lauri
			 * TN_CCG15280
			 */
    		mapToReturn.put(ent.getEntityName()+"%"+ent.getSrcList(), ent);
    	}
    	
    	return mapToReturn;  		
  	}
}
