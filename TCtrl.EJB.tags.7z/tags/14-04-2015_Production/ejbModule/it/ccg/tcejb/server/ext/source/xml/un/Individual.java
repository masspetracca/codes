package it.ccg.tcejb.server.ext.source.xml.un;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DATAID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="VERSIONNUM" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="FIRST_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SECOND_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UN_LIST_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="REFERENCE_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LISTED_ON" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="COMMENTS1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="NATIONALITY">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="VALUE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="LIST_TYPE">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="VALUE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="LAST_DAY_UPDATED">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="VALUE" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="INDIVIDUAL_ALIAS" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="QUALITY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="ALIAS_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="INDIVIDUAL_ADDRESS">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="STREET" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="CITY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="STATE_PROVINCE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="COUNTRY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="INDIVIDUAL_DATE_OF_BIRTH" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TYPE_OF_DATE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="DATE" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="INDIVIDUAL_PLACE_OF_BIRTH">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="CITY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="COUNTRY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="INDIVIDUAL_DOCUMENT" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TYPE_OF_DOCUMENT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="NUMBER" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="SORT_KEY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SORT_KEY_LAST_MOD" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "dataid",
    "versionnum",
    "firstname",
    "secondname",
    "thirdname",
    "nameoriginalscript",
    "unlisttype",
    "referencenumber",
    "listedon",
    "comments1",
    "nationality",
    "listtype",
    "lastdayupdated",
    "individualalias",
    "individualaddress",
    "individualdateofbirth",
    "individualplaceofbirth",
    "individualdocument",
    "sortkey",
    "sortkeylastmod"
})
@XmlRootElement(name = "INDIVIDUAL")
public class Individual {

	@XmlElement(name = "DATAID")
    protected int dataid;
    @XmlElement(name = "VERSIONNUM")
    protected int versionnum;
    @XmlElement(name = "FIRST_NAME", required = true)
    protected String firstname;
    @XmlElement(name = "SECOND_NAME", required = true)
    protected String secondname;
    @XmlElement(name = "THIRD_NAME", required = true)
    protected String thirdname;
    @XmlElement(name = "NAME_ORIGINAL_SCRIPT", required = true)
    protected String nameoriginalscript;
    @XmlElement(name = "UN_LIST_TYPE", required = true)
    protected String unlisttype;
    @XmlElement(name = "REFERENCE_NUMBER", required = true)
    protected String referencenumber;
    @XmlElement(name = "LISTED_ON", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar listedon;
    @XmlElement(name = "COMMENTS1", required = true)
    protected String comments1;
    @XmlElement(name = "NATIONALITY", required = true)
    protected Nationality nationality;
    @XmlElement(name = "LIST_TYPE", required = true)
    protected ListType listtype;
    @XmlElement(name = "LAST_DAY_UPDATED", required = true)
    protected LastDayUpdated lastdayupdated;
    @XmlElement(name = "INDIVIDUAL_ALIAS", required = true)
    protected List<IndividualAlias> individualalias;
    @XmlElement(name = "INDIVIDUAL_ADDRESS", required = true)
    protected List<IndividualAddress> individualaddress;
    @XmlElement(name = "INDIVIDUAL_DATE_OF_BIRTH", required = true)
    protected List<IndividualDateOfBirth> individualdateofbirth;
    @XmlElement(name = "INDIVIDUAL_PLACE_OF_BIRTH", required = true)
    protected IndividualPlaceOfBirth individualplaceofbirth;
    @XmlElement(name = "INDIVIDUAL_DOCUMENT", required = true)
    protected List<IndividualDocument> individualdocument;
    @XmlElement(name = "SORT_KEY", required = true)
    protected String sortkey;
    @XmlElement(name = "SORT_KEY_LAST_MOD", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar sortkeylastmod;

    /**
     * Gets the value of the dataid property.
     * 
     */
    public int getDATAID() {
        return dataid;
    }

    /**
     * Sets the value of the dataid property.
     * 
     */
    public void setDATAID(int value) {
        this.dataid = value;
    }

    /**
     * Gets the value of the versionnum property.
     * 
     */
    public int getVERSIONNUM() {
        return versionnum;
    }

    /**
     * Sets the value of the versionnum property.
     * 
     */
    public void setVERSIONNUM(int value) {
        this.versionnum = value;
    }

    /**
     * Gets the value of the firstname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFIRSTNAME() {
        return firstname;
    }

    /**
     * Sets the value of the firstname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFIRSTNAME(String value) {
        this.firstname = value;
    }

    /**
     * Gets the value of the secondname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSECONDNAME() {
        return secondname;
    }

    /**
     * Sets the value of the secondname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSECONDNAME(String value) {
        this.secondname = value;
    }

    /**
     * Gets the value of the unlisttype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUNLISTTYPE() {
        return unlisttype;
    }

    /**
     * Sets the value of the unlisttype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUNLISTTYPE(String value) {
        this.unlisttype = value;
    }

    /**
     * Gets the value of the referencenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREFERENCENUMBER() {
        return referencenumber;
    }

    /**
     * Sets the value of the referencenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREFERENCENUMBER(String value) {
        this.referencenumber = value;
    }

    /**
     * Gets the value of the listedon property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLISTEDON() {
        return listedon;
    }

    /**
     * Sets the value of the listedon property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLISTEDON(XMLGregorianCalendar value) {
        this.listedon = value;
    }

    /**
     * Gets the value of the comments1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMMENTS1() {
        return comments1;
    }

    /**
     * Sets the value of the comments1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMMENTS1(String value) {
        this.comments1 = value;
    }

    /**
     * Gets the value of the nationality property.
     * 
     * @return
     *     possible object is
     *     {@link NATIONALITY }
     *     
     */
    public Nationality getNATIONALITY() {
        return nationality;
    }

    /**
     * Sets the value of the nationality property.
     * 
     * @param value
     *     allowed object is
     *     {@link NATIONALITY }
     *     
     */
    public void setNATIONALITY(Nationality value) {
        this.nationality = value;
    }

    /**
     * Gets the value of the listtype property.
     * 
     * @return
     *     possible object is
     *     {@link LISTTYPE }
     *     
     */
    public ListType getLISTTYPE() {
        return listtype;
    }

    /**
     * Sets the value of the listtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link LISTTYPE }
     *     
     */
    public void setLISTTYPE(ListType value) {
        this.listtype = value;
    }

    /**
     * Gets the value of the lastdayupdated property.
     * 
     * @return
     *     possible object is
     *     {@link LASTDAYUPDATED }
     *     
     */
    public LastDayUpdated getLASTDAYUPDATED() {
        return lastdayupdated;
    }

    /**
     * Sets the value of the lastdayupdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link LASTDAYUPDATED }
     *     
     */
    public void setLASTDAYUPDATED(LastDayUpdated value) {
        this.lastdayupdated = value;
    }

    /**
     * Gets the value of the individualalias property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the individualalias property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getINDIVIDUALALIAS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link INDIVIDUALALIAS }
     * 
     * 
     */
    public List<IndividualAlias> getINDIVIDUALALIAS() {
        if (individualalias == null) {
            individualalias = new ArrayList<IndividualAlias>();
        }
        return this.individualalias;
    }

    /**
     * Gets the value of the individualaddress property.
     * 
     * @return
     *     possible object is
     *     {@link INDIVIDUALADDRESS }
     *     
     */
    public List<IndividualAddress> getINDIVIDUALADDRESS() {
        return individualaddress;
    }

    /**
     * Sets the value of the individualaddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link INDIVIDUALADDRESS }
     *     
     */
    public void setINDIVIDUALADDRESS(List<IndividualAddress> value) {
        this.individualaddress = value;
    }

    /**
     * Gets the value of the individualdateofbirth property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the individualdateofbirth property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getINDIVIDUALDATEOFBIRTH().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link INDIVIDUALDATEOFBIRTH }
     * 
     * 
     */
    public List<IndividualDateOfBirth> getINDIVIDUALDATEOFBIRTH() {
        if (individualdateofbirth == null) {
            individualdateofbirth = new ArrayList<IndividualDateOfBirth>();
        }
        return this.individualdateofbirth;
    }

    /**
     * Gets the value of the individualplaceofbirth property.
     * 
     * @return
     *     possible object is
     *     {@link INDIVIDUALPLACEOFBIRTH }
     *     
     */
    public IndividualPlaceOfBirth getINDIVIDUALPLACEOFBIRTH() {
        return individualplaceofbirth;
    }

    /**
     * Sets the value of the individualplaceofbirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link INDIVIDUALPLACEOFBIRTH }
     *     
     */
    public void setINDIVIDUALPLACEOFBIRTH(IndividualPlaceOfBirth value) {
        this.individualplaceofbirth = value;
    }

    /**
     * Gets the value of the individualdocument property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the individualdocument property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getINDIVIDUALDOCUMENT().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link INDIVIDUALDOCUMENT }
     * 
     * 
     */
    public List<IndividualDocument> getINDIVIDUALDOCUMENT() {
        if (individualdocument == null) {
            individualdocument = new ArrayList<IndividualDocument>();
        }
        return this.individualdocument;
    }

    /**
     * Gets the value of the sortkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSORTKEY() {
        return sortkey;
    }

    /**
     * Sets the value of the sortkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSORTKEY(String value) {
        this.sortkey = value;
    }

    /**
     * Gets the value of the sortkeylastmod property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSORTKEYLASTMOD() {
        return sortkeylastmod;
    }

    /**
     * Sets the value of the sortkeylastmod property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSORTKEYLASTMOD(XMLGregorianCalendar value) {
        this.sortkeylastmod = value;
    }

	/**
	 * @return the nameoriginalscript
	 */
	public String getNAMEORIGINALSCRIPT() {
		return nameoriginalscript;
	}

	/**
	 * @param nameoriginalscript the nameoriginalscript to set
	 */
	public void setNAMEORIGINALSCRIPT(String nameoriginalscript) {
		this.nameoriginalscript = nameoriginalscript;
	}

	/**
	 * @return the thirdname
	 */
	public String getTHIRDNAME() {
		return thirdname;
	}

	/**
	 * @param thirdname the thirdname to set
	 */
	public void setTHIRDNAME(String thirdname) {
		this.thirdname = thirdname;
	}
    
    
}
