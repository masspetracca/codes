package it.ccg.tcejb.server.ext.source.xml.ec;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="YEAR")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"date","regulation"})
public class YEAR {
	
	@XmlAttribute(name = "Date")
    protected String date;
	@XmlElement(name = "REGULATION")
    protected List<REGULATION> regulation;
	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}
	/**
	 * @return the regulation
	 */
	public List<REGULATION> getRegulation() {
		return regulation;
	}
	/**
	 * @param regulation the regulation to set
	 */
	public void setRegulation(List<REGULATION> regulation) {
		this.regulation = regulation;
	}
	
	
	
}
