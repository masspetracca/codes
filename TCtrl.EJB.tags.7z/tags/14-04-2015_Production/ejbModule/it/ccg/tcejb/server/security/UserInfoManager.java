package it.ccg.tcejb.server.security;

import it.ccg.tcejb.server.exception.DataNotAvailableException;
import it.ccg.tcejb.server.exception.DataNotValidException;

import java.util.Hashtable;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class UserInfoManager
 */
@Stateless
@LocalBean
public class UserInfoManager {
	

	private static final Hashtable<String, String> userTable = new Hashtable<String, String>();  
	
		
	public String fetchField(String fieldName) throws DataNotValidException {
		
		return userTable.get(fieldName);
		
	}

	
	public void add(String user, String company) throws DataNotAvailableException,DataNotValidException {
		
		userTable.put(user, company);
		
	}
	
	



}
