package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctSrcUpDtEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.util.Date;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctSrcUpDtEntityEAO
 */
@Stateless
@LocalBean
public class TctSrcUpDtEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctSrcUpDtEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctSrcUpDtEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctSrcUpDtEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctSrcUpDtEntity identification data: SrcList = "+entity.getSrcList()+" source "+entity.getListDate()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));	
    }
        
    
}
