package it.ccg.tcejb.server.ext.source.xml.un;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="STREET" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CITY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="STATE_PROVINCE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="COUNTRY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
		"note",
		"street",
	    "city",
	    "stateprovince",
	    "country",
	    "zipcode"
})
@XmlRootElement(name = "INDIVIDUALADDRESS")
public class IndividualAddress {

	@XmlElement(name = "NOTE")
    protected String note;
	@XmlElement(name = "STREET", required = true)
    protected String street;
    @XmlElement(name = "CITY", required = true)
    protected String city;
    @XmlElement(name = "STATE_PROVINCE", required = true)
    protected String stateprovince;
    @XmlElement(name = "COUNTRY", required = true)
    protected String country;
    @XmlElement(name = "ZIP_CODE", required = true)
    protected String zipcode;
    

    /**
     * Gets the value of the street property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTREET() {
        return street;
    }

    /**
     * Sets the value of the street property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTREET(String value) {
        this.street = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCITY() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCITY(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the stateprovince property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTATEPROVINCE() {
        return stateprovince;
    }

    /**
     * Sets the value of the stateprovince property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTATEPROVINCE(String value) {
        this.stateprovince = value;
    }

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOUNTRY() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOUNTRY(String value) {
        this.country = value;
    }

	/**
	 * @return the zipcode
	 */
	public String getZIPCODE() {
		return zipcode;
	}

	/**
	 * @param zipcode the zipcode to set
	 */
	public void setZIPCODE(String zipcode) {
		this.zipcode = zipcode;
	}
    
	/**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNOTE() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNOTE(String value) {
        this.note = value;
    }    
}
