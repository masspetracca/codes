package it.ccg.tcejb.server.bean;

import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.exception.DataNotValidException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.security.UserInfoManager;
import it.ccg.tcejb.server.system.LocalBeanLookup;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.ScheduleExpression;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.ejb.TimerService;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class SchedulerBean
 */
@Stateless
@LocalBean
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class SchedulerBean {
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	//private static final Logger monitorLogger = LoggerFactory.getLogger(LoggerFactory.MONITOR_LOGGER);
	
	
	@Resource
	private TimerService timerService;
	@EJB
	private UserInfoManager userInfoManager;
	
    /**
     * Default constructor. 
     */
    public SchedulerBean() {
        // TODO Auto-generated constructor stub
    }

    public Timer createTimer(SchedulerDTO schedulerDTO) throws Exception {
		
    	Timer result = null;
		
		if(this.getTimer(schedulerDTO.getName()) != null) {
			logger.error("Duplicate timer name.");
		}
		
		ScheduleExpression schExp = new ScheduleExpression();
		schExp.dayOfWeek(schedulerDTO.getStringValue());
		if(Integer.toString(schedulerDTO.getNumberValue()).length()>2){
			if(Integer.toString(schedulerDTO.getNumberValue()).length()==3){
				schExp.hour(Integer.parseInt((Integer.toString(schedulerDTO.getNumberValue()).substring(0, 1))));
				schExp.minute(Integer.parseInt((Integer.toString(schedulerDTO.getNumberValue()).substring(1, 3))));
				schExp.second(0);
			}else{				
				schExp.hour(Integer.parseInt((Integer.toString(schedulerDTO.getNumberValue()).substring(0, 2))));
				schExp.minute(Integer.parseInt((Integer.toString(schedulerDTO.getNumberValue()).substring(2, 4))));
				schExp.second(0);
			}
		}else{
			schExp.hour(schedulerDTO.getNumberValue());
			schExp.minute(0);
			schExp.second(0);
		}
		
		TimerConfig config = new TimerConfig();
		config.setInfo(schedulerDTO);
		
		result = this.timerService.createCalendarTimer(schExp, config);
		logger.debug(new StandardLogMessage("TimeOut "+result.getNextTimeout()));
		logger.info(new StandardLogMessage("Scheduler \'" + schedulerDTO.getName() + "\' created."));
		return result;
	}
    
    public SchedulerDTO getTimer(String timerName) throws Exception {
		
    	SchedulerDTO schedulerDTO = null;
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = this.timerService.getTimers();
    	
    	for(Timer timer : collection) {
    		if(((String)((SchedulerDTO)timer.getInfo()).getName()).equals(timerName)) {
    			
    			schedulerDTO = (SchedulerDTO)timer.getInfo();
    		}
    	}
		
		return schedulerDTO;
	}
    
    public List<SchedulerDTO> getAllTimers() {
		logger.debug(new StandardLogMessage("in SchedulerBean.getAllTimers()"));
		List<SchedulerDTO> list = new ArrayList<SchedulerDTO>();
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = this.timerService.getTimers();

    	for(Timer timer : collection) {
    		SchedulerDTO schedulerDTO = (SchedulerDTO)timer.getInfo();
    		list.add(schedulerDTO);
    	}
    	logger.debug(new StandardLogMessage("number fo timers "+list.size()));
  
		return list;
	}
    
    public List<SchedulerDTO> getTimersByCompanyCode() throws DataNotValidException {
		logger.debug(new StandardLogMessage("in SchedulerBean.getTimersByCompanyCode()"));
		List<SchedulerDTO> list = new ArrayList<SchedulerDTO>();
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = this.timerService.getTimers();
		int companyId = Integer.parseInt(userInfoManager.fetchField("COMPANYID"));
    	for(Timer timer : collection) {
    		if(((Integer)((SchedulerDTO)timer.getInfo()).getCompanyId())==companyId || ((Integer)((SchedulerDTO)timer.getInfo()).getCompanyId())==-1) {
    		SchedulerDTO schedulerDTO = (SchedulerDTO)timer.getInfo();
    		list.add(schedulerDTO);
    		}
    	}
    	logger.debug(new StandardLogMessage("number of timers "+list.size()));
  
		return list;
	}
    
    public int getCompanyId() throws DataNotValidException {
 		logger.debug(new StandardLogMessage("in SchedulerBean.getCompanyId()"));
 		int companyId = Integer.parseInt(userInfoManager.fetchField("COMPANYID"));
     	return companyId;
 	}
    
    public String getUserId() throws DataNotValidException {
 		logger.debug(new StandardLogMessage("in SchedulerBean.getUserId()"));
 		String userId = userInfoManager.fetchField("FULLNAME");
     	return userId;
 	}
    
    public Timestamp getTime() throws DataNotValidException {
 		logger.debug(new StandardLogMessage("in SchedulerBean.getTime()"));
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		Timestamp updDate = now;
     	return updDate;
 	}
    
    public void deleteTimer(String timerType) throws BackEndException {
		logger.debug(new StandardLogMessage("in TimerBean.deleteTimer(String timerName) throws BackEndException"));
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = this.timerService.getTimers();
    	for(Timer timer : collection) {
    		if(((String)((SchedulerDTO)timer.getInfo()).getName()).equals(timerType)) {
    			
    			timer.cancel();
    			
    			logger.info(new StandardLogMessage("Scheduler \'" + timerType + "\' deleted."));
    		}
    	}
	}
	
	public void deleteAllTimers() throws BackEndException {
		logger.debug(new StandardLogMessage("in deleteAllTimers() throws BackEndException"));
		while(this.timerService.getTimers().iterator().hasNext()) {
			Timer timer = (Timer)this.timerService.getTimers().iterator().next();
			String timerName = ((SchedulerDTO)timer.getInfo()).getName();
			timer.cancel();
    		logger.info(new StandardLogMessage("Scheduler \'" + timerName + "\' deleted."));
    	}
		
	}
	
	@Timeout
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void timeout(Timer timer) {
		try {
			SchedulerDTO scheduler = (SchedulerDTO)timer.getInfo();
			
			logger.info(new StandardLogMessage("Timer \'" + scheduler.getName() + "\' expired."));
			logger.info(new StandardLogMessage("IsCalendar "+timer.isCalendarTimer()));
			logger.info(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(timer.getNextTimeout()));
			
			String methodName = scheduler.getMethodName();
			String parameterType = scheduler.getParameterType();
			Class<?> methodClass = scheduler.getMethodClass();			
			Method method = null;
			
			if (parameterType==null){
				method = methodClass.getMethod(methodName);
			}else{
				method = methodClass.getMethod(methodName, Class.forName(parameterType));
			}
			
			// class is an EJB interface
			Object classInstance = LocalBeanLookup.lookup(methodClass.getCanonicalName());

			if (parameterType !=null){
				method.invoke(classInstance, scheduler.getCompanyId());
			}else{
				method.invoke(classInstance, (Object[])null);
			}
			
		}
		catch(Exception e) {
			// *** IMPORTANT ***
			// At this point, whatever exception type results as InvocationTargetException with no message.
			// For error details, it is necessary to log at job method level.
			ExceptionUtil.logCompleteStackTrace(logger, e);
		}
	}
}
