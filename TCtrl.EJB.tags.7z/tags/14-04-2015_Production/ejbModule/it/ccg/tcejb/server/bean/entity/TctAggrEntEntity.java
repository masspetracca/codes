package it.ccg.tcejb.server.bean.entity;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


/**
 * The persistent class for the TCTAGGRENT database table.
 * 
 */
@Entity
@Table(name="TCTAGGRENT")
@NamedQueries({
	@NamedQuery(name="getAggrEntByDownloadID",   query="SELECT entity " +
            "								              FROM TctAggrEntEntity entity " +
            "								             WHERE entity.id.downloadid  = :downloadid")
	
})
public class TctAggrEntEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TctAggrEntEntityPK id;

	@Column(nullable=false)
	private int entityid;

	@Column(nullable=false, length=255)
	private String entityName;

	@Column(nullable=false, length=1)
	private String isnew;

	@Column(nullable=false)
	private int nameid;

	@Column(length=2000)
	private String pdfLink;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date presentFrom;

	@Column(nullable=false, length=3)
	private String srcCode;

	@Column(nullable=false, length=30)
	private String srcList;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date srcLstDate;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	//bi-directional many-to-one association to TctCorrisp
	//@OneToMany(mappedBy="tctaggrent")
	@Transient
	private Set<TctCorrispEntity> tctcorrisps;

	//bi-directional many-to-one association to TctFalNegtEntity
	@OneToMany(mappedBy="tctaggrent", fetch=FetchType.LAZY)
	private Set<TctFalNegtEntity> tctfalnegts;

	//bi-directional many-to-one association to TctFalNegHEntity
	//@OneToMany(mappedBy="tctaggrent")
	@Transient
	private Set<TctFalNegHEntity> tctfalneghs;
		
	//bi-directional many-to-one association to TctDownRegEntity
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOWNLOADID", nullable=false, insertable=false, updatable=false)
	private TctDownRegEntity tctdownreg;
    
    //bi-directional many-to-one association to TctOptimiz
  	@OneToMany(mappedBy="tctaggrent", cascade={CascadeType.DETACH}, fetch=FetchType.LAZY)
  	private Set<TctOptimizEntity> tctoptimizs;
  	
  	//bi-directional many-to-one association to TctCorrLstEntity
  	@OneToMany(mappedBy="tctaggrent",fetch=FetchType.LAZY)
	private Set<TctCorrLstEntity> tctcorrlsts;
  	
	/**
	 * @return the id
	 */
	public TctAggrEntEntityPK getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(TctAggrEntEntityPK id) {
		this.id = id;
	}

	/**
	 * @return the entityid
	 */
	public int getEntityid() {
		return entityid;
	}

	/**
	 * @param entityid the entityid to set
	 */
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}

	/**
	 * @return the entityName
	 */
	public String getEntityName() {
		return entityName;
	}

	/**
	 * @param entityName the entityName to set
	 */
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	/**
	 * @return the isnew
	 */
	public String getIsnew() {
		return isnew;
	}

	/**
	 * @param isnew the isnew to set
	 */
	public void setIsnew(String isnew) {
		this.isnew = isnew;
	}

	/**
	 * @return the nameid
	 */
	public int getNameid() {
		return nameid;
	}

	/**
	 * @param nameid the nameid to set
	 */
	public void setNameid(int nameid) {
		this.nameid = nameid;
	}

	/**
	 * @return the pdfLink
	 */
	public String getPdfLink() {
		return pdfLink;
	}

	/**
	 * @param pdfLink the pdfLink to set
	 */
	public void setPdfLink(String pdfLink) {
		this.pdfLink = pdfLink;
	}

	/**
	 * @return the presentFrom
	 */
	public Date getPresentFrom() {
		return presentFrom;
	}

	/**
	 * @param presentFrom the presentFrom to set
	 */
	public void setPresentFrom(Date presentFrom) {
		this.presentFrom = presentFrom;
	}

	/**
	 * @return the srcCode
	 */
	public String getSrcCode() {
		return srcCode;
	}

	/**
	 * @param srcCode the srcCode to set
	 */
	public void setSrcCode(String srcCode) {
		this.srcCode = srcCode;
	}

	/**
	 * @return the srcList
	 */
	public String getSrcList() {
		return srcList;
	}

	/**
	 * @param srcList the srcList to set
	 */
	public void setSrcList(String srcList) {
		this.srcList = srcList;
	}

	/**
	 * @return the srcLstDate
	 */
	public Date getSrcLstDate() {
		return srcLstDate;
	}

	/**
	 * @param srcLstDate the srcLstDate to set
	 */
	public void setSrcLstDate(Date srcLstDate) {
		this.srcLstDate = srcLstDate;
	}

	/**
	 * @return the updDate
	 */
	public Timestamp getUpdDate() {
		return updDate;
	}

	/**
	 * @param updDate the updDate to set
	 */
	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	/**
	 * @return the updType
	 */
	public String getUpdType() {
		return updType;
	}

	/**
	 * @param updType the updType to set
	 */
	public void setUpdType(String updType) {
		this.updType = updType;
	}

	/**
	 * @return the updUser
	 */
	public String getUpdUser() {
		return updUser;
	}

	/**
	 * @param updUser the updUser to set
	 */
	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	/**
	 * @return the tctcorrisps
	 */
	public Set<TctCorrispEntity> getTctcorrisps() {
		return tctcorrisps;
	}

	/**
	 * @param tctcorrisps the tctcorrisps to set
	 */
	public void setTctcorrisps(Set<TctCorrispEntity> tctcorrisps) {
		this.tctcorrisps = tctcorrisps;
	}

	/**
	 * @return the tctdownreg
	 */
	public TctDownRegEntity getTctdownreg() {
		return tctdownreg;
	}

	/**
	 * @param tctdownreg the tctdownreg to set
	 */
	public void setTctdownreg(TctDownRegEntity tctdownreg) {
		this.tctdownreg = tctdownreg;
	}

	/**
	 * @return the tctfalnegts
	 */
	public Set<TctFalNegtEntity> getTctfalnegts() {
		return tctfalnegts;
	}

	/**
	 * @param tctfalnegts the tctfalnegts to set
	 */
	public void setTctfalnegts(Set<TctFalNegtEntity> tctfalnegts) {
		this.tctfalnegts = tctfalnegts;
	}

	/**
	 * @return the tctfalneghs
	 */
	public Set<TctFalNegHEntity> getTctfalneghs() {
		return tctfalneghs;
	}

	/**
	 * @param tctfalneghs the tctfalneghs to set
	 */
	public void setTctfalneghs(Set<TctFalNegHEntity> tctfalneghs) {
		this.tctfalneghs = tctfalneghs;
	}

	/**
	 * @return the tctoptimizs
	 */
	public Set<TctOptimizEntity> getTctoptimizs() {
		return tctoptimizs;
	}

	/**
	 * @param tctoptimizs the tctoptimizs to set
	 */
	public void setTctoptimizs(Set<TctOptimizEntity> tctoptimizs) {
		this.tctoptimizs = tctoptimizs;
	}

	/*@Column(nullable=false, length=255)
	private String entityName;

	@Column(nullable=false, length=1)
	private String isNew;

	@Column(length=2000)
	private String pdfLink;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date presentFrom;

	@Column(nullable=false, length=4)
	private String srcCode;

	@Column(nullable=false, length=30)
	private String srcList;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date srcLstDate;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	//bi-directional many-to-one association to TctDownRegEntity
    @ManyToOne
	@JoinColumn(name="DOWNLOADID", nullable=false, insertable=false, updatable=false)
	private TctDownRegEntity tctdownreg;
  
	//bi-directional many-to-one association to TctEcENameEntity
    @ManyToOne
	@JoinColumn(name="NAMEID", referencedColumnName="NAMEID", nullable=false)
	private TctEcENameEntity tctecename1;
  //bi-directional many-to-one association to TctEcENameEntity
    @ManyToOne
	@JoinColumn(name="NAMEID", referencedColumnName="NAMEID", nullable=false)
	private TctEcEName tctecename1;

	//bi-directional many-to-one association to TctEcENameEntity
    @ManyToOne
	@JoinColumns({
		@JoinColumn(name="ENTITYID", referencedColumnName="ENTITYID", nullable=false),
		@JoinColumn(name="NAMEID", referencedColumnName="NAMEID", nullable=false)
		})
	private TctEcENameEntity tctecename2;
    @ManyToOne
	@JoinColumns({
		@JoinColumn(name="ENTITYID", referencedColumnName="ENTITYID", nullable=false),
		@JoinColumn(name="NAMEID", referencedColumnName="NAMEID", nullable=false)
		})
	private TctEcEName tctecename2;
    
	//bi-directional many-to-one association to TctOfAkaAliasEntity
    @ManyToOne
	@JoinColumns({
		@JoinColumn(name="ENTITYID", referencedColumnName="ENTITYID", nullable=false),
		@JoinColumn(name="NAMEID", referencedColumnName="ENTITYID", nullable=false)
		})
	private TctOfEntitEntity tctofentit;
    
    @ManyToOne
	@JoinColumns({
		@JoinColumn(name="ENTITYID", referencedColumnName="ENTITYID", nullable=false),
		@JoinColumn(name="NAMEID", referencedColumnName="AKAID", nullable=false)
		})
	private TctOfAkaAliasEntity tctofakaal;

	//bi-directional many-to-one association to TctUnAliasEntity
    @ManyToOne
	@JoinColumns({
		@JoinColumn(name="ENTITYID", referencedColumnName="ENTITYID", nullable=false),
		@JoinColumn(name="ALAISID", referencedColumnName="ALAISID", nullable=false)
		})
	private TctUnAliasEntity tctunalia1;
  //bi-directional many-to-one association to TctUnAliasEntity
    @ManyToOne
	@JoinColumns({
		@JoinColumn(name="ENTITYID", referencedColumnName="ENTITYID", nullable=false),
		@JoinColumn(name="NAMEID", referencedColumnName="ALAISID", nullable=false)
		})
	private TctUnAlia tctunalia1;

	//bi-directional many-to-one association to TctUnAliasEntity
    @ManyToOne
	@JoinColumns({
		@JoinColumn(name="ENTITYID", referencedColumnName="DATAID", nullable=false),
		@JoinColumn(name="NAMEID", referencedColumnName="DATAID", nullable=false)
		})
	private TctUnEntit tctunentit;

	//bi-directional many-to-one association to TctUnAliasEntity
    @ManyToOne
	@JoinColumn(name="NAMEID", nullable=false)
	private TctUnAliasEntity tctunalia3;
    
  //bi-directional many-to-one association to TctUnAliasEntity
    @ManyToOne
	@JoinColumn(name="NAMEID", nullable=false)
	private TctUnAlia tctunalia3;

	//bi-directional many-to-one association to TctCorrispEntity
	@OneToMany(mappedBy="tctaggrent")
	private Set<TctCorrispEntity> tctcorrisps;

	//bi-directional many-to-one association to TctFalNegtEntity
	@OneToMany(mappedBy="tctaggrent")
	private Set<TctFalNegtEntity> tctfalnegts;

    public TctAggrEntEntity() {
    }

	public TctAggrEntEntityPK getId() {
		return this.id;
	}

	public void setId(TctAggrEntEntityPK id) {
		this.id = id;
	}
	
	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getIsNew() {
		return this.isNew;
	}

	public void setIsNew(String isNew) {
		this.isNew = isNew;
	}

	public String getPdfLink() {
		return this.pdfLink;
	}

	public void setPdfLink(String pdfLink) {
		this.pdfLink = pdfLink;
	}

	public Date getPresentFrom() {
		return this.presentFrom;
	}

	public void setPresentFrom(Date presentFrom) {
		this.presentFrom = presentFrom;
	}

	public String getSrcCode() {
		return this.srcCode;
	}

	public void setSrcCode(String srcCode) {
		this.srcCode = srcCode;
	}

	public String getSrcList() {
		return this.srcList;
	}

	public void setSrcList(String srcList) {
		this.srcList = srcList;
	}

	public Date getSrcLstDate() {
		return this.srcLstDate;
	}

	public void setSrcLstDate(Date srcLstDate) {
		this.srcLstDate = srcLstDate;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public TctDownRegEntity getTctdownreg() {
		return this.tctdownreg;
	}

	public void setTctdownreg(TctDownRegEntity tctdownreg) {
		this.tctdownreg = tctdownreg;
	}
	
	public TctEcEName getTctecename1() {
		return this.tctecename1;
	}

	public void setTctecename1(TctEcEName tctecename1) {
		this.tctecename1 = tctecename1;
	}
	
	public TctEcEName getTctecename2() {
		return this.tctecename2;
	}

	public void setTctecename2(TctEcEName tctecename2) {
		this.tctecename2 = tctecename2;
	}
	
	public TctOfAkaAliasEntity getTctofakaal() {
		return this.tctofakaal;
	}

	public void setTctofakaal(TctOfAkaAliasEntity tctofakaal) {
		this.tctofakaal = tctofakaal;
	}
	
	public TctUnAlia getTctunalia1() {
		return this.tctunalia1;
	}

	public void setTctunalia1(TctUnAlia tctunalia1) {
		this.tctunalia1 = tctunalia1;
	}

	public TctUnAlia getTctunalia3() {
		return this.tctunalia3;
	}

	public void setTctunalia3(TctUnAlia tctunalia3) {
		this.tctunalia3 = tctunalia3;
	}
	
	public Set<TctCorrispEntity> getTctcorrisps() {
		return this.tctcorrisps;
	}

	public void setTctcorrisps(Set<TctCorrispEntity> tctcorrisps) {
		this.tctcorrisps = tctcorrisps;
	}
	
	public Set<TctFalNegtEntity> getTctfalnegts() {
		return this.tctfalnegts;
	}

	public void setTctfalnegts(Set<TctFalNegtEntity> tctfalnegts) {
		this.tctfalnegts = tctfalnegts;
	}

	*//**
	 * @return the tctofentit
	 *//*
	public TctOfEntitEntity getTctofentit() {
		return tctofentit;
	}

	*//**
	 * @param tctofentit the tctofentit to set
	 *//*
	public void setTctofentit(TctOfEntitEntity tctofentit) {
		this.tctofentit = tctofentit;
	}

	*//**
	 * @return the tctunentit
	 *//*
	public TctUnEntit getTctunentit() {
		return tctunentit;
	}

	*//**
	 * @param tctunentit the tctunentit to set
	 *//*
	public void setTctunentit(TctUnEntit tctunentit) {
		this.tctunentit = tctunentit;
	}*/
	
}