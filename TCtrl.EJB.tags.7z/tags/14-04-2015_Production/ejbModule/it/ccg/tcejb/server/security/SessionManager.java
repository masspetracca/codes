package it.ccg.tcejb.server.security;


import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;
import it.ccg.tcejb.server.system.SystemProperties;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class SessionInfo
 */
@Stateless
@Local(SessionManagerLocal.class)
public class SessionManager implements SessionManagerLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Resource
	private SessionContext sessionContext;
	
	// Map<user, sessionId>
	private static Map<String, String> loggedUsersMap = null;
	
	private static String[] APP_ROLES = null;


    /**
     * Default constructor. 
     */
    public SessionManager() {
    	
    	if(loggedUsersMap == null) {
    		
    		loggedUsersMap = new HashMap<String, String>();
    	}
    }
    
    
    // To be called into Startup
    @Override
    public void init() throws BackEndException {
    	try {
	    	if(loggedUsersMap == null) {
	    		
	    		loggedUsersMap = new HashMap<String, String>();
	    	}
    	
			APP_ROLES = SystemProperties.getSystemProperty("security.roles").split(",");
		
    	logger.debug(new StandardLogMessage("SessionManager successfully initialized."));
    	} catch (Exception e) {
    		ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		}
    }
    
    
	@Override
	public void addLoggedUser(String userName, String sessionId) throws BackEndException {
		
		loggedUsersMap.put(userName, sessionId);
	}
	
	
	@Override
	public void removeLoggedUser(String userName) throws BackEndException {
		
		loggedUsersMap.remove(userName);
	}


	@Override
	public List<String> listLoggedUsers() throws BackEndException {
		
		List<String> loggedUsersList = new ArrayList<String>();
		
		Set<String> keySet = loggedUsersMap.keySet();
		for(String key : keySet) {
			
			loggedUsersList.add(key);
		}
		
		return loggedUsersList;
	}
    
    
	@Override
	public String getCurrentUser() throws BackEndException {
		
		String currentUser = this.sessionContext.getCallerPrincipal().getName();
			
		if(currentUser.equalsIgnoreCase("UNAUTHENTICATED")) {
			
			currentUser = "WAS";
		}
		
		return currentUser;
	}
    
	
	@Override
	public String getCurrentUserSessionId() throws BackEndException {
		
		String currentUser = this.sessionContext.getCallerPrincipal().getName();
		
		return loggedUsersMap.get(currentUser);
	}
    
	
	@Override
	public List<String> getCurrentUserRoles() throws BackEndException {
		
		List<String> userRoles = new ArrayList<String>();
		
		for(String role : APP_ROLES) {
			
			if(this.sessionContext.isCallerInRole(role)) {
				
				userRoles.add(role);
			}
		}
		
		return userRoles;
	}


    

}
