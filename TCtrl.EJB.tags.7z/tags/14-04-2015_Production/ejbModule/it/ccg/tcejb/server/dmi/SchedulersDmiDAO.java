package it.ccg.tcejb.server.dmi;

import it.ccg.tcejb.server.bean.SchedulerBean;
import it.ccg.tcejb.server.bean.SchedulerDTO;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.ext.src.business.Starter;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.security.LDAPUserDTO;
import it.ccg.tcejb.server.security.SecurityEjb;
import it.ccg.tcejb.server.security.UserInfoManager;
import it.ccg.tcejb.server.util.ExceptionUtil;
import it.ccg.tcejb.server.util.SchedulerType;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Timer;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;
import com.isomorphic.util.ErrorMessage;


public class SchedulersDmiDAO {
	
	@EJB 
	LDAPUserDTO lDAPUserDTO;
	
	@EJB 
	private UserInfoManager userInfoManager;
	
	private SchedulerBean timerBean;
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	public SchedulersDmiDAO() throws BackEndException{
		try {
			Context ctx;
			ctx = new InitialContext();
		
			timerBean = (SchedulerBean) ctx.lookup("ejblocal:" + SchedulerBean.class.getName());
		} catch (NamingException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		} 
	}
	
	public DSResponse fetch(DSRequest dsRequest) throws Exception {
		
		DSResponse dsResponse = new DSResponse();
		
		List<SchedulerDTO> timerList = this.timerBean.getTimersByCompanyCode(); 
		
		dsResponse.setData(timerList);
		
		return dsResponse;
	}

	
	public Object add(DSRequest dsRequest) throws Exception {
		
		
		Object resultObject = null;
		
		@SuppressWarnings("unchecked")
		Map<String, Object> valueMap = dsRequest.getValues();
		
		Timer tempSchedulerDTO = null;
		
				
		int companyId =0;
		
		if(valueMap.get("methodName").toString().compareToIgnoreCase("startFindMatch")==0){
			//companyID = lDAPUserDTO.getOu();
			companyId = this.timerBean.getCompanyId();
			//companyID = userInfoManager.fetchField("COMPANYID");
		} else  companyId=-1;
		
		String updUser = SecurityEjb.getCurrentUser();
		
//		GregorianCalendar cal = new GregorianCalendar();
//		Timestamp now = new Timestamp(cal.getTimeInMillis());
		Timestamp updDate = this.timerBean.getTime();
				
//		JobDTO jobDTO = new JobDTO(valueMap.get("companyId").toString().equalsIgnoreCase("-1")?-1:Integer.parseInt(valueMap.get("companyId").toString()), valueMap.get("companyId").toString().equalsIgnoreCase("-1")?"null":"Integer", valueMap.get("methodName").toString(), Starter.class, valueMap.get("description").toString());
//		SchedulerDTO(String name, int numberValue, SchedulerType typeOfScheduler, String stringValue, int companyId, String parameterType, String methodName, Class<?> methodClass, String description, String updUser, String updType, Date updDate) {
		SchedulerDTO dto = 
		new SchedulerDTO(valueMap.get("name").toString(), Integer.parseInt(valueMap.get("numberValue").toString()), SchedulerType.Daily , 
				valueMap.get("stringValue").toString(), companyId==-1?-1:companyId, 
						companyId==-1?null:"java.lang.Integer", valueMap.get("methodName").toString(), Starter.class, 
								valueMap.get("description").toString(),
								updUser, valueMap.get("updType").toString(), updDate);
//		new SchedulerDTO(valueMap.get("name").toString(), Integer.parseInt(valueMap.get("numberValue").toString()), SchedulerType.Daily , 
//				valueMap.get("stringValue").toString(), valueMap.get("companyId").toString().equalsIgnoreCase("-1")?-1:Integer.parseInt(valueMap.get("companyId").toString()), 
//						valueMap.get("companyId").toString().equalsIgnoreCase("-1")?null:"java.lang.Integer", valueMap.get("methodName").toString(), Starter.class, 
//								valueMap.get("description").toString()/*,
//						valueMap.get("updUser").toString(), valueMap.get("updType").toString(), ((Timestamp)valueMap.get("updDate"))*/);
	
		
		tempSchedulerDTO = this.timerBean.createTimer(dto);
		
		if(tempSchedulerDTO == null) {
			DSResponse dsResponse = new DSResponse();
			dsResponse.addError("name", new ErrorMessage("Timer \'" + (String)valueMap.get("name") + "\' already exists."));
			
			resultObject = dsResponse;
		}
		else {
			resultObject = tempSchedulerDTO;
		}
		
		return resultObject;
	}

	
	public Object update(DSRequest dsRequest) throws Exception {
		
		throw new Exception("Method 'update' not implemented.");
	}

	
	public Object remove(DSRequest dsRequest) throws Exception {
		
		@SuppressWarnings("unchecked")
		Map<String, Object> oldValueMap = dsRequest.getOldValues();
		
		String timerName = (String)oldValueMap.get("name");
		
		this.timerBean.deleteTimer(timerName);
		
		
		SchedulerDTO removedTimerDTO = new SchedulerDTO();
		removedTimerDTO.setName(timerName);
		
		
		return removedTimerDTO;
	}
	
	
	public Object removeAll(DSRequest dsRequest) throws Exception {
		
		DSResponse dsResponse = new DSResponse();
		
		this.timerBean.deleteAllTimers();
		
		return dsResponse;
	}
	
}
