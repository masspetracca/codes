package it.ccg.tcejb.server.ext.source.xml.ec;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="REGULATION")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"number","date","link","entity"})
public class REGULATION {

	@XmlAttribute(name = "Date")
    protected String date;
	@XmlAttribute(name = "Number")
    protected String number;
	@XmlAttribute(name = "Link")
    protected String link;
	@XmlElement(name = "ENTITY")
    protected List<ENTITY> entity;
	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}
	/**
	 * @return the number
	 */
	public String getNumber() {
		return number;
	}
	/**
	 * @param number the number to set
	 */
	public void setNumber(String number) {
		this.number = number;
	}
	/**
	 * @return the link
	 */
	public String getLink() {
		return link;
	}
	/**
	 * @param link the link to set
	 */
	public void setLink(String link) {
		this.link = link;
	}
	/**
	 * @return the entity
	 */
	public List<ENTITY> getEntity() {
		return entity;
	}
	/**
	 * @param entity the entity to set
	 */
	public void setEntity(List<ENTITY> entity) {
		this.entity = entity;
	}
	
	
}
