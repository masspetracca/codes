package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTCORRLST database table.
 * 
 */
@Embeddable
public class TctCorrLstEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int cmpnid;

	@Column(unique=true, nullable=false)
	private int downloadid;

	@Column(unique=true, nullable=false, length=20)
	private String aggregid;

    public TctCorrLstEntityPK() {
    }
	public int getCmpnid() {
		return this.cmpnid;
	}
	public void setCmpnid(int cmpnid) {
		this.cmpnid = cmpnid;
	}
	public int getDownloadid() {
		return this.downloadid;
	}
	public void setDownloadid(int downloadid) {
		this.downloadid = downloadid;
	}
	public String getAggregid() {
		return this.aggregid;
	}
	public void setAggregid(String aggregid) {
		this.aggregid = aggregid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctCorrLstEntityPK)) {
			return false;
		}
		TctCorrLstEntityPK castOther = (TctCorrLstEntityPK)other;
		return 
			(this.cmpnid == castOther.cmpnid)
			&& (this.downloadid == castOther.downloadid)
			&& this.aggregid.equals(castOther.aggregid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.cmpnid;
		hash = hash * prime + this.downloadid;
		hash = hash * prime + this.aggregid.hashCode();
		
		return hash;
    }
}