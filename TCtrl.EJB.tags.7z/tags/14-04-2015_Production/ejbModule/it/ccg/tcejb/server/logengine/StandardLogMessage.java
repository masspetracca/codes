package it.ccg.tcejb.server.logengine;

import it.ccg.tcejb.server.security.SecurityEjb;

public class StandardLogMessage {
	
	protected String currentUser;
	protected String message;
	
	
	public StandardLogMessage(String message) {
		
		try {
			this.currentUser = SecurityEjb.getCurrentUser();
		}
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
		this.message = message;
	}
	
	
	@Override
	public String toString() {
		
		return this.currentUser + "|" + this.message;
	}

}
