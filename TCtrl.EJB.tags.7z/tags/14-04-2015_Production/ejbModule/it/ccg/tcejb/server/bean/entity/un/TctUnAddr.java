package it.ccg.tcejb.server.bean.entity.un;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTUNADDR database table.
 * 
 */
@Entity
@Table(name="TCTUNADDR")
@NamedQueries({
	@NamedQuery(name="deleteUnAddrEveryEntity", query="DELETE FROM TctUnAddr"),
	@NamedQuery(name="getUnAddrEntitiesById", query="SELECT entity FROM TctUnAddr entity WHERE entity.entityid = :entityId ORDER BY entity.addressId ASC")
})
public class TctUnAddr implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	/*@EmbeddedId
	private TctUnAddrPK id;*/
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ADDRID")
	private int addrId;

	@Column(nullable=false)
	private int entityid;

	@Column(length=50)
	private String city;

	@Column(length=255)
	private String country;

	@Column(length=1000)
	private String note;

	@Column(length=50)
	private String stateProv;

	@Column(length=100)
	private String street;

	@Column(length=25)
	private String zipCode;

	//bi-directional many-to-one association to TctUnEntit
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	//@Transient
	private TctUnEntit tctunentit;

    //bi-directional many-to-one association to TctUnIndiv
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	//@Transient
	private TctUnIndiv tctunindiv;
    
    public TctUnAddr() {
    }
	
	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		if (country !=null && country.length()>255){
			ejbLogger.debug(country+" >255 than truncate");
			this.country = country.substring(0, 254);
		}else{
			this.country = country;
		}
	}

	public TctUnEntit getTctunentit() {
		return this.tctunentit;
	}

	public void setTctunentit(TctUnEntit tctunentit) {
		this.tctunentit = tctunentit;
	}

	/**
	 * @return the addrId
	 */
	public int getAddrId() {
		return addrId;
	}

	/**
	 * @param addrId the addrId to set
	 */
	public void setAddrId(int addrId) {
		this.addrId = addrId;
	}

	/**
	 * @return the entityid
	 */
	public int getEntityid() {
		return entityid;
	}

	/**
	 * @param entityid the entityid to set
	 */
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		if (city !=null && city.length()>50){
			ejbLogger.debug(city+" >50 than truncate");
			this.city = city.substring(0, 49);
		}else{
			this.city = city;
		}
	}

	/**
	 * @return the note
	 */
	public String getNote() {
		return note;
	}

	/**
	 * @param note the note to set
	 */
	public void setNote(String note) {
		if (note !=null && note.length()>1000){
			ejbLogger.debug(note+" >1000 than truncate");
			this.note = note.substring(0, 999);
		}else{
			this.note = note;
		}
	}

	/**
	 * @return the stateProv
	 */
	public String getStateProv() {
		return stateProv;
	}

	/**
	 * @param stateProv the stateProv to set
	 */
	public void setStateProv(String stateProv) {
		if (stateProv !=null && stateProv.length()>50){
			ejbLogger.debug(stateProv+" >50 than truncate");
			this.stateProv = stateProv.substring(0, 49);
		}else{
			this.stateProv = stateProv;
		}
	}

	/**
	 * @return the street
	 */
	public String getStreet() {
		return street;
	}

	/**
	 * @param street the street to set
	 */
	public void setStreet(String street) {
		if (street !=null && street.length()>100){
			ejbLogger.debug(street+" >100 than truncate");
			this.street = street.substring(0, 99);
		}else{
			this.street = street;
		}
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		if (zipCode !=null && zipCode.length()>25){
			ejbLogger.debug(zipCode+" >25 than truncate");
			this.zipCode = zipCode.substring(0, 24);
		}else{
			this.zipCode = zipCode;
		}
	}

	/**
	 * @return the tctunindiv
	 */
	public TctUnIndiv getTctunindiv() {
		return tctunindiv;
	}

	/**
	 * @param tctunindiv the tctunindiv to set
	 */
	public void setTctunindiv(TctUnIndiv tctunindiv) {
		this.tctunindiv = tctunindiv;
	}	
	
	
}