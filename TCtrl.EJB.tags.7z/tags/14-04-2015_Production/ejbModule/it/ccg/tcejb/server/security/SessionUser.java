package it.ccg.tcejb.server.security;

import java.io.Serializable;

public class SessionUser implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3795241518743424557L;
	
	private String userName;
	
	public SessionUser(String userName) {
		
		this.userName = userName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	

	@Override
	public boolean equals(Object o) {
		
		return this.userName.equalsIgnoreCase(((SessionUser)o).getUserName());
	}
	
	
	
	
}