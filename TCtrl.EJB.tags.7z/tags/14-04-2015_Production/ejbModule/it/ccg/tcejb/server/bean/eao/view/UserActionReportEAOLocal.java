package it.ccg.tcejb.server.bean.eao.view;

import it.ccg.tcejb.server.util.UserActionDto;

import java.util.HashMap;

public interface UserActionReportEAOLocal {

	public void addAction(String user, String action);
	public HashMap<String, UserActionDto> getActionReport();
	
}
