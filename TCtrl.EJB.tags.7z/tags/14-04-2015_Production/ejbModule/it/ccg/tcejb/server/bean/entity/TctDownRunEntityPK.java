package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTDOWNRUN database table.
 * 
 */
@Embeddable
public class TctDownRunEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int downloadid;

	@Column(unique=true, nullable=false)
	private int runid;

	@Column(unique=true, nullable=false)
	private int cmpnid;

    public TctDownRunEntityPK() {
    }
	public int getDownloadid() {
		return this.downloadid;
	}
	public void setDownloadid(int downloadid) {
		this.downloadid = downloadid;
	}
	public int getRunid() {
		return this.runid;
	}
	public void setRunid(int runid) {
		this.runid = runid;
	}
	public int getCmpnid() {
		return this.cmpnid;
	}
	public void setCmpnid(int cmpnid) {
		this.cmpnid = cmpnid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctDownRunEntityPK)) {
			return false;
		}
		TctDownRunEntityPK castOther = (TctDownRunEntityPK)other;
		return 
			(this.downloadid == castOther.downloadid)
			&& (this.runid == castOther.runid)
			&& (this.cmpnid == castOther.cmpnid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.downloadid;
		hash = hash * prime + this.runid;
		hash = hash * prime + this.cmpnid;
		
		return hash;
    }
}