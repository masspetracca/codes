package it.ccg.tcejb.server.bean.entity.ofac;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTOFPRGLS database table.
 * 
 */
@Entity
@Table(name="TCTOFPRGLS")
@NamedQueries({
	@NamedQuery(name="deleteOfPrgLstEveryEntity", query="DELETE FROM TctOfPrglEntity"),
	@NamedQuery(name="getOfPrgLstEntitiesById", query="SELECT entity FROM TctOfPrglEntity entity WHERE entity.id.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctOfPrglEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@EmbeddedId
	private TctOfPrglEntityPK id;

	@Column(nullable=false, length=255)
	private String prgValue;

	//bi-directional many-to-one association to TctOfEntitEntity
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	private TctOfEntitEntity tctofentit;

    public TctOfPrglEntity() {
    }

	public TctOfPrglEntityPK getId() {
		return this.id;
	}

	public void setId(TctOfPrglEntityPK id) {
		this.id = id;
	}
	
	public String getPrgValue() {
		return this.prgValue;
	}

	public void setPrgValue(String prgValue) {
		if (prgValue != null && prgValue.length()>255){
			ejbLogger.debug(prgValue+" >255 than truncate");
			this.prgValue = prgValue.substring(0, 254);
		}else{
			this.prgValue = prgValue;
		}
	}

	public TctOfEntitEntity getTctofentit() {
		return this.tctofentit;
	}

	public void setTctofentit(TctOfEntitEntity tctofentit) {
		this.tctofentit = tctofentit;
	}
	
}