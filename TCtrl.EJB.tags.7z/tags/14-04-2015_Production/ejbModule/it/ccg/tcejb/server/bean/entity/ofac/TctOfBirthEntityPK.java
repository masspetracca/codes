package it.ccg.tcejb.server.bean.entity.ofac;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTOFBIRTH database table.
 * 
 */
@Embeddable
public class TctOfBirthEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int plcBirthId;

	@Column(unique=true, nullable=false)
	private int entityid;

    public TctOfBirthEntityPK() {
    }
	public int getPlcBirthId() {
		return this.plcBirthId;
	}
	public void setPlcBirthId(int plcBirthId) {
		this.plcBirthId = plcBirthId;
	}
	public int getEntityid() {
		return this.entityid;
	}
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctOfBirthEntityPK)) {
			return false;
		}
		TctOfBirthEntityPK castOther = (TctOfBirthEntityPK)other;
		return 
			(this.plcBirthId == castOther.plcBirthId)
			&& (this.entityid == castOther.entityid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.plcBirthId;
		hash = hash * prime + this.entityid;
		
		return hash;
    }
}