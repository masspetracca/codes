package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the TCTCLNSRCH database table.
 * 
 */
@Entity
@Table(name="TCTCLNSRCH")
public class TctClnSrcHEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TctClnSrcHEntityPK id;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date clntFDate;

    @Lob()
	@Column(nullable=false)
	private byte[] clntFile;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	//bi-directional many-to-one association to TctCompanyEntity
    @ManyToOne
	@JoinColumn(name="CMPNID", nullable=false, insertable=false, updatable=false)
	private TctCompanyEntity tctcompany;

	//bi-directional one-to-one association to TctRunRegEntity
	@OneToOne
	@JoinColumns({
		@JoinColumn(name="CMPNID", referencedColumnName="RUNID", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="RUNID", referencedColumnName="CMPNID", nullable=false, insertable=false, updatable=false)
		})
	private TctRunRegEntity tctrunreg;

    public TctClnSrcHEntity() {
    }

	public TctClnSrcHEntityPK getId() {
		return this.id;
	}

	public void setId(TctClnSrcHEntityPK id) {
		this.id = id;
	}
	
	public Date getClntFDate() {
		return this.clntFDate;
	}

	public void setClntFDate(Date clntFDate) {
		this.clntFDate = clntFDate;
	}

	public byte[] getClntFile() {
		return this.clntFile;
	}

	public void setClntFile(byte[] clntFile) {
		this.clntFile = clntFile;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public TctCompanyEntity getTctcompany() {
		return this.tctcompany;
	}

	public void setTctcompany(TctCompanyEntity tctcompany) {
		this.tctcompany = tctcompany;
	}
	
	public TctRunRegEntity getTctrunreg() {
		return this.tctrunreg;
	}

	public void setTctrunreg(TctRunRegEntity tctrunreg) {
		this.tctrunreg = tctrunreg;
	}
	
}