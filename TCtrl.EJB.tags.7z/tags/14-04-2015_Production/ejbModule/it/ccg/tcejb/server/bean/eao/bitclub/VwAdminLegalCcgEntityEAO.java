package it.ccg.tcejb.server.bean.eao.bitclub;

import it.ccg.tcejb.server.bean.entity.bitclub.VwAdminLegalCcgEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

/**
 * Session Bean implementation class VwAdminLegalCcgEntityEAO
 */
@Stateless
@LocalBean
public class VwAdminLegalCcgEntityEAO {
	@PersistenceContext(unitName="ccgClient", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public VwAdminLegalCcgEntityEAO() {
        // TODO Auto-generated constructor stub
    }
  	
    @SuppressWarnings("unchecked")
	public List<VwAdminLegalCcgEntity> retrieveClient() throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in void getDesc() throws BackEndException"));
	    	ejbLogger.debug(new StandardLogMessage("createNativeQuery"));
	    	Query q = this.manager. createNativeQuery("SELECT DISTINCT ID_SOC," +
					"										 ABI," +
					"										 RAGIONE_SOCIALE," +
					"										 GRUPPO," +
					"										 NAZIONE," +
					"										 ID_RAPPR_LEGAL," +
					"										 LEGAL_NOME," +
					"										 LEGAL_COGN," +
					"										 ID_ADMIN," +
					"										 ADMIN_NOME," +
					"										 ADMIN_COGNOME" +
					"									FROM vw_admin_legal_ccg",VwAdminLegalCcgEntity.class);
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	List<VwAdminLegalCcgEntity> data = (List<VwAdminLegalCcgEntity>) q.getResultList();
	    	ejbLogger.debug(new StandardLogMessage("retrieved "+data.size()+" client"));
	    	ejbLogger.debug(new StandardLogMessage("return"));
	    	return data;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
}
