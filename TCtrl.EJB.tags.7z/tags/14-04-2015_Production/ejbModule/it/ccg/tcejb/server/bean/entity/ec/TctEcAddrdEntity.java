package it.ccg.tcejb.server.bean.entity.ec;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTECADDRD database table.
 * 
 */
@Entity
@Table(name="TCTECADDRD")
@NamedQueries({
	@NamedQuery(name="deleteEcAddrEveryEntity", query="DELETE FROM TctEcAddrdEntity"),
	@NamedQuery(name="getEcAddrEntitiesById", query="SELECT entity FROM TctEcAddrdEntity entity WHERE entity.id.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctEcAddrdEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@EmbeddedId
	private TctEcAddrdEntityPK id;

	@Column(length=200)
	private String city;

	@Column(length=200)
	private String country;

	@Column(length=100)
	private String legalBasis;

	@Column(length=50)
	private String number;

	@Column(length=2000)
	private String other;

	@Column(length=2000)
	private String pdfLink;

    @Temporal( TemporalType.DATE)
	private Date regDate;

	@Column(length=200)
	private String street;

	@Column(length=50)
	private String zipCode;

	//bi-directional many-to-one association to TctEcEntitEntity
	@ManyToOne(optional=true)
	@JoinColumn(name="ENTITYID", nullable=false, insertable=true, updatable=false)
	private TctEcEntitEntity tctecentit;

    public TctEcAddrdEntity() {
    }

	public TctEcAddrdEntityPK getId() {
		return this.id;
	}

	public void setId(TctEcAddrdEntityPK id) {
		this.id = id;
	}
	
	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		if (city != null && city.length()>200){
			ejbLogger.debug(city+" >200 than truncate");
			this.city = city.substring(0, 199);
		}else{
			this.city = city;
		}
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		if (country !=null && country.length()>200){
			ejbLogger.debug(country+" >200 than truncate");
			this.country = country.substring(0, 199);
		}else{
			this.country = country;
		}
	}

	public String getLegalBasis() {
		return this.legalBasis;
	}

	public void setLegalBasis(String legalBasis) {
		if (legalBasis != null && legalBasis.length()>100){
			ejbLogger.debug(legalBasis+" >100 than truncate");
			this.legalBasis = legalBasis.substring(0, 99);
		}else{
			this.legalBasis = legalBasis;
		}
	}

	public String getNumber() {
		return this.number;
	}

	public void setNumber(String number) {
		if (number != null && number.length()>50){
			ejbLogger.debug(number+" >50 than truncate");
			this.number = number.substring(0,49);
		}else{
			this.number = number;
		}
	}

	public String getOther() {
		return this.other;
	}

	public void setOther(String other) {
		if (other !=null && other.length()>2000){
			ejbLogger.debug(other+" >2000 than truncate");
			this.other = other.substring(0,1999);
		}else{
			this.other = other;
		}
	}

	public String getPdfLink() {
		return this.pdfLink;
	}

	public void setPdfLink(String pdfLink) {
		if (pdfLink !=null && pdfLink.length()>2000){
			ejbLogger.debug(pdfLink+" >2000 than truncate");
			this.pdfLink = pdfLink.substring(0,1999);
		}else{
			this.pdfLink = pdfLink;
		}
	}

	public Date getRegDate() {
		return this.regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public String getStreet() {
		return this.street;
	}

	public void setStreet(String street) {
		if (street != null && street.length()>200){
			ejbLogger.debug(street+" >200 than truncate");
			this.street = street.substring(0,199);
		}else{
			this.street = street;
		}
	}

	public String getZipCode() {
		return this.zipCode;
	}

	public void setZipCode(String zipCode) {
		if (zipCode != null && zipCode.length()>50){
			ejbLogger.debug(zipCode+" >50 than truncate");
			this.zipCode = zipCode.substring(0,49);
		}else{
			this.zipCode = zipCode;
		}
	}

	public TctEcEntitEntity getTctecentit() {
		return this.tctecentit;
	}

	public void setTctecentit(TctEcEntitEntity tctecentit) {
		this.tctecentit = tctecentit;
	}
	
}