package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the TCTUSER database table.
 * 
 */
@Entity
@Table(name="TCTUSER")
@NamedQueries({
	@NamedQuery(name="getCompanyIdByUsername", query="SELECT entity FROM TctUserEntity entity " +
			"										   WHERE entity.id.userName = :userName"),
	@NamedQuery(name="getNotificationUserByCompanyid", query="SELECT entity " +
			"													FROM TctUserEntity entity " +
			"									   			   WHERE entity.id.cmpnid = :cmpnid" +
			"													 AND entity.notify = 'T'")
})
public class TctUserEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TctUserEntityPK id;

	@Column(nullable=false, length=50)
	private String eMail;

	@Column(nullable=false, length=1)
	private String notify;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	//bi-directional many-to-one association to TctCompanyEntity
    @ManyToOne
	@JoinColumn(name="CMPNID", nullable=false, insertable=false, updatable=false)
	private TctCompanyEntity tctcompany;

    public TctUserEntity() {
    }

	public TctUserEntityPK getId() {
		return this.id;
	}

	public void setId(TctUserEntityPK id) {
		this.id = id;
	}
	
	public String getEMail() {
		return this.eMail;
	}

	public void setEMail(String eMail) {
		this.eMail = eMail;
	}

	public String getNotify() {
		return this.notify;
	}

	public void setNotify(String notify) {
		this.notify = notify;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public TctCompanyEntity getTctcompany() {
		return this.tctcompany;
	}

	public void setTctcompany(TctCompanyEntity tctcompany) {
		this.tctcompany = tctcompany;
	}
	
}