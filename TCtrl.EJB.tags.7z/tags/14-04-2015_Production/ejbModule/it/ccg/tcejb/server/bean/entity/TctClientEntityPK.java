package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTCLIENT database table.
 * 
 */
@Embeddable
public class TctClientEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int clntId;

	@Column(unique=true, nullable=false)
	private int cmpnId;

    public TctClientEntityPK() {
    }
	public int getClntId() {
		return this.clntId;
	}
	public void setClntId(int clntId) {
		this.clntId = clntId;
	}
	public int getCmpnId() {
		return this.cmpnId;
	}
	public void setCmpnId(int cmpnId) {
		this.cmpnId = cmpnId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctClientEntityPK)) {
			return false;
		}
		TctClientEntityPK castOther = (TctClientEntityPK)other;
		return 
			(this.clntId == castOther.clntId)
			&& (this.cmpnId == castOther.cmpnId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.clntId;
		hash = hash * prime + this.cmpnId;
		
		return hash;
    }
}