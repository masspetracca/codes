package it.ccg.tcejb.server.bean;


public interface DownloadManagerLocal {

	public void downloadECList();
	public void downloadUNList();
	public void downloadOFACList();
	public void deleteDownloadedList();
}
