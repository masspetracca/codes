package it.ccg.tcejb.server.find.business;

import it.ccg.tcejb.server.bean.AnalysisController;
import it.ccg.tcejb.server.bean.OptimizationController;
import it.ccg.tcejb.server.bean.entity.TctAggrEntEntity;
import it.ccg.tcejb.server.bean.entity.TctClientEntity;
import it.ccg.tcejb.server.bean.entity.TctCompanyEntity;
import it.ccg.tcejb.server.bean.entity.TctCorrLstEntity;
import it.ccg.tcejb.server.bean.entity.TctCorrLstEntityPK;
import it.ccg.tcejb.server.bean.entity.TctCorrispEntity;
import it.ccg.tcejb.server.bean.entity.TctCorrispEntityPK;
import it.ccg.tcejb.server.bean.entity.TctOptimizEntity;
import it.ccg.tcejb.server.bean.entity.TctOptimizEntityPK;
import it.ccg.tcejb.server.bean.entity.TctRunRegEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardCheckPointMessage;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;
import it.ccg.tcejb.server.util.NameCleaner;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.Future;

import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

import com.wcohen.ss.BasicStringWrapperIterator;
import com.wcohen.ss.JaroWinkler;
import com.wcohen.ss.SoftTFIDF;
import com.wcohen.ss.api.Tokenizer;
import com.wcohen.ss.tokens.SimpleTokenizer;

/**
 * Session Bean implementation class MatchFinder
 */
@Stateless
@LocalBean
@ConcurrencyManagement(ConcurrencyManagementType.CONTAINER)
@TransactionManagement(TransactionManagementType.CONTAINER)
public class MatchFinder {
	private static final Logger calcLogger = Logger.getLogger(LoggerFactory.CALCULATION_LOGGER);
	private SoftTFIDF softTfIdf;

	@EJB
	private OptimizationController optimizationController;
	@EJB
	private AnalysisController analysisController;
    /**
     * Default constructor. 
     * @throws BackEndException 
     */
    public MatchFinder() throws BackEndException {
    	//calcLogger.debug("in MatchFinder()");
    	try {
			softTfIdf = new SoftTFIDF(new SimpleTokenizer(false,true),new JaroWinkler(),new Double(SystemProperties.getSystemProperty("jarowinkler.thrshld")));
		} catch (NumberFormatException e) {
			ExceptionUtil.logCompleteStackTrace(calcLogger, e);
			//calcLogger.error(new StandardCheckPointMessage("Error during instantion "+e.getMessage()));
			throw new BackEndException(e.getMessage());
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(calcLogger, e);
			//calcLogger.error(new StandardCheckPointMessage("Error during instantion "+e.getMessage()));
			throw new BackEndException(e.getMessage());
		}
    }

    @Asynchronous
    public Future<List<TctCorrispEntity>> analyze(TctClientEntity client, TreeMap<String,TctAggrEntEntity> aggregMap,TctRunRegEntity runReg, TreeSet<String> fPositivCorrisp ,double thrsld1,double thrsld2) throws BackEndException{
    	List<TctCorrispEntity> corrisponds = new ArrayList<TctCorrispEntity>();
    	List<Object> bufferLogger = new ArrayList<Object>(); 
    	//bufferLogger.add(new StandardCheckPointMessage("Start analysis on "+client.getClntName()));
    	calcLogger.info(new StandardCheckPointMessage("Start analysis on "+client.getClntName()+" "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	bufferLogger.add(new StandardLogMessage(client.getClntName()+" thread "+Thread.currentThread().getName()));
        //ejbLogger.debug(new StandardLogMessage(client.getClntnName()+" thread "+Thread.currentThread().getName()));
    	NameCleaner cleaner = new NameCleaner();
    	
    	try {
    	/*
    	 * remove special characters
    	 */
        Set<String> keys = aggregMap.keySet();
        String cleanedClinetName = cleaner.clean(client.getClntName());
    	String cleanedClinetAlias1="",cleanedClinetAlias2="",cleanedClinetAlias3="";
    	if ((client.getClntAlias1() != null)&& !(client.getClntAlias1().equalsIgnoreCase(""))){
    		cleanedClinetAlias1 = cleaner.clean(client.getClntAlias1());
    	}
    	if ((client.getClntAlias2() != null)&& !(client.getClntAlias2().equalsIgnoreCase(""))){
    		cleanedClinetAlias2 = cleaner.clean(client.getClntAlias2());
    	}
    	if ((client.getClntAlias3() != null)&& !(client.getClntAlias3().equalsIgnoreCase(""))){
    		cleanedClinetAlias3 = cleaner.clean(client.getClntAlias3());
    	}
    	/*
    	 * CYCLE TERRORISTS
    	 */
        for (String aggregName : keys){
        	/*
			 * raffaele de lauri
			 * TN_CCG15280
			 */
        	String realAggregName = aggregName.split("%")[0];
        	/*
        	 * check if client and terrorist are OLD entry  
        	 */
        	/*
        	 * IF (CLIENT is OLD  and TERRORIST IS OLD) OR (CLIENT_TERRORIST IS FALSE_POSITIVE) continue
        	 */
        	if(!(((TctAggrEntEntity)aggregMap.get(aggregName)).getIsnew().equalsIgnoreCase("N") && client.getIsNew().equalsIgnoreCase("N") || fPositivCorrisp.contains((client.getClntName()+"-"+realAggregName)))){
        		bufferLogger.add(new StandardLogMessage(realAggregName+" isn't false positive and both "+realAggregName+" and "+client.getClntName()+" aren't old entry"));
        		String cleanedAggrName = cleaner.clean(realAggregName);
        		//ejbLogger.debug(new StandardLogMessage(aggregName+" isn't false positive and both "+aggregName+" and "+client.getClntnName()+" aren't old entry"));
        		/*
        		 * EXECUTE  Soft TF-IDF on the CLIENT/TERRORIST couple
        		 */
        		double result = this.softTfIdf.score(this.softTfIdf.prepare(cleanedClinetName), this.softTfIdf.prepare(cleanedAggrName));
        		double result1 = 0,result2 = 0,result3 = 0;
        		if ((client.getClntAlias1() != null)&& !(client.getClntAlias1().equalsIgnoreCase(""))){
        			result1 = this.softTfIdf.score(this.softTfIdf.prepare(cleanedClinetAlias1), this.softTfIdf.prepare(cleanedAggrName));
        		}
        		
        		if ((client.getClntAlias2() != null)&& !(client.getClntAlias2().equalsIgnoreCase(""))){
        			result2 = this.softTfIdf.score(this.softTfIdf.prepare(cleanedClinetAlias2), this.softTfIdf.prepare(cleanedAggrName) );
        		}
        		
        		if ((client.getClntAlias3() != null)&& !(client.getClntAlias3().equalsIgnoreCase(""))){
        			result3 = this.softTfIdf.score(this.softTfIdf.prepare(cleanedClinetAlias3), this.softTfIdf.prepare(cleanedAggrName) );
        		}
            	TreeSet<Double> orderingTreeSet = new TreeSet<Double>();
            	orderingTreeSet.add(result);
            	orderingTreeSet.add(result1);
            	orderingTreeSet.add(result2);
            	orderingTreeSet.add(result3);
            	/*
            	 * get the max result of score between clientName and clientAlias
            	 */
            	double finalResult = orderingTreeSet.last();
            	
            	/*
            	 * CLASSIFY Soft TF-IDF index
            	 */
        		if (finalResult>=thrsld2 && finalResult<thrsld1){
        			/*
        			 * INSERT CORRESPONDENCE as NOT_MATCH
        			 */
        			bufferLogger.add(new StandardLogMessage(finalResult+" >= "+thrsld2+" and < "+thrsld1));
        			//ejbLogger.debug(new StandardLogMessage(finalResult+" >= "+thrsld2+" and < "+thrsld1));
        			TctCorrispEntity corrisp = new TctCorrispEntity();
        			TctCorrispEntityPK pk = new TctCorrispEntityPK();
        			pk.setClntid(client.getId().getClntId());
        			pk.setCmpnid(client.getId().getCmpnId());
        			pk.setRunId(runReg.getRunId());
        			pk.setAggrId(((TctAggrEntEntity)aggregMap.get(aggregName)).getId().getAggregId());
        			pk.setDownloadid(((TctAggrEntEntity)aggregMap.get(aggregName)).getId().getDownloadid());
        			
        			corrisp.setId(pk);
        			corrisp.setClntName(client.getClntName());
        			corrisp.setCorrIndex(new BigDecimal(finalResult));
        			/*
        			 * raffaele de lauri
        			 * TN_CCG15280
        			 */
        			corrisp.setEntityName(aggregName.split("%")[0]);
        			corrisp.setStatus("D");
        			//corrisp.setTctaggrent((TctAggrEntEntity)aggregMap.get(aggregName));
        			corrisp.setTctclient(client);
        			corrisp.setTctrunreg(runReg);
        			
        			corrisponds.add(corrisp);
        		}else if(finalResult>thrsld1) {
        			/*
        			 * INSERT CORRESPONDENCE as MATCH
        			 */
        			bufferLogger.add(new StandardLogMessage(finalResult+" > "+thrsld1));
        			//ejbLogger.debug(new StandardLogMessage(finalResult+" > "+thrsld1));
        			TctCorrispEntity corrisp = new TctCorrispEntity();
        			TctCorrispEntityPK pk = new TctCorrispEntityPK();
        			pk.setClntid(client.getId().getClntId());
        			pk.setCmpnid(client.getId().getCmpnId());
        			pk.setRunId(runReg.getRunId());
        			pk.setAggrId(((TctAggrEntEntity)aggregMap.get(aggregName)).getId().getAggregId());
        			pk.setDownloadid(((TctAggrEntEntity)aggregMap.get(aggregName)).getId().getDownloadid());
        			
        			corrisp.setId(pk);
        			corrisp.setClntName(client.getClntName());
        			corrisp.setCorrIndex(new BigDecimal(finalResult));
        			/*
        			 * raffaele de lauri
        			 * TN_CCG15280
        			 */
        			corrisp.setEntityName(aggregName.split("%")[0]);
        			corrisp.setStatus("O");
        			//corrisp.setTctaggrent((TctAggrEntEntity)aggregMap.get(aggregName));
        			corrisp.setTctclient(client);
        			corrisp.setTctrunreg(runReg);
        			
        			corrisponds.add(corrisp);
        		}
        	}
        }
        this.analysisController.incrementFinishedOptim();
        bufferLogger.add(new StandardCheckPointMessage("Analysis on "+client.getClntName()+" completed "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
        //ejbLogger.info(new StandardCheckPointMessage("Analysis on "+client.getClntnName()+" completed"));
        
        } catch (BackEndException e) {
        	ExceptionUtil.logCompleteStackTrace(calcLogger, e);
        	bufferLogger.add(new StandardCheckPointMessage("Analysis on "+client.getClntName()+" terminated with errors: "+e.getMessage()));
			throw new BackEndException(e.getMessage());
		}finally{
			for (Object o : bufferLogger){
	        	if(o instanceof StandardCheckPointMessage){
	        		 calcLogger.info(o);
	        	}else{
	        		calcLogger.debug(o);
	        	}
	        }
		}
    	return new AsyncResult<List<TctCorrispEntity>>(corrisponds);
    }
    
    public List<TctCorrLstEntity> analyze(TreeMap<String,TctAggrEntEntity> aggregMap,TctCompanyEntity company, double thrsld1,double thrsld2,String... clientNames) throws BackEndException{
    	List<TctCorrLstEntity> corrisponds = new ArrayList<TctCorrLstEntity>();
    	List<Object> bufferLogger = new ArrayList<Object>(); 
    	//bufferLogger.add(new StandardCheckPointMessage("Start analysis on "+client.getClntName()));
    	calcLogger.info(new StandardCheckPointMessage("Start analysis on "+clientNames[0]+" "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	bufferLogger.add(new StandardLogMessage(clientNames[0]+" thread "+Thread.currentThread().getName()));
        //ejbLogger.debug(new StandardLogMessage(client.getClntnName()+" thread "+Thread.currentThread().getName()));
    	NameCleaner cleaner = new NameCleaner();
    	try {
    	
        Set<String> keys = aggregMap.keySet();
        String cleanedClinetName = cleaner.clean(clientNames[0]);
    	String cleanedClinetAlias1="",cleanedClinetAlias2="",cleanedClinetAlias3="";
    	if (clientNames.length>1){
	    	if ((clientNames[1] != null)&& !(clientNames[1].equalsIgnoreCase(""))){
	    		cleanedClinetAlias1 = cleaner.clean(clientNames[1]);
	    	}
    	}
    	
    	if (clientNames.length>2){
	    	if ((clientNames[2] != null)&& !(clientNames[2].equalsIgnoreCase(""))){
	    		cleanedClinetAlias2 = cleaner.clean(clientNames[2]);
	    	}
    	}
    	if (clientNames.length>3){
	    	if ((clientNames[3] != null)&& !(clientNames[3].equalsIgnoreCase(""))){
	    		cleanedClinetAlias3 = cleaner.clean(clientNames[3]);
	    	}
    	}

        for (String aggregName : keys){
        	/*
			 * raffaele de lauri
			 * TN_CCG15280
			 */
        	String realAggregName = ((String[])aggregName.split("%"))[0];
        	String cleanedAggrName = cleaner.clean(realAggregName);
    		double result = this.softTfIdf.score(this.softTfIdf.prepare(cleanedClinetName), this.softTfIdf.prepare(cleanedAggrName) );
    		double result1 = 0,result2 = 0,result3 = 0;
    		if ((cleanedClinetAlias1 != null)&& !(cleanedClinetAlias1.equalsIgnoreCase(""))){
    			result1 = this.softTfIdf.score(this.softTfIdf.prepare(cleanedClinetAlias1), this.softTfIdf.prepare(cleanedAggrName) );
    		}
    		
    		if ((cleanedClinetAlias2 != null)&& !(cleanedClinetAlias2.equalsIgnoreCase(""))){
    			result2 = this.softTfIdf.score(this.softTfIdf.prepare(cleanedClinetAlias2), this.softTfIdf.prepare(cleanedAggrName) );
    		}
    		
    		if ((cleanedClinetAlias3 != null)&& !(cleanedClinetAlias3.equalsIgnoreCase(""))){
    			result3 = this.softTfIdf.score(this.softTfIdf.prepare(cleanedClinetAlias3), this.softTfIdf.prepare(cleanedAggrName) );
    		}
        	TreeSet<Double> orderingTreeSet = new TreeSet<Double>();
        	orderingTreeSet.add(result);
        	orderingTreeSet.add(result1);
        	orderingTreeSet.add(result2);
        	orderingTreeSet.add(result3);
        	
        	double finalResult = orderingTreeSet.last();
        	
    		if (finalResult>=thrsld2 && finalResult<thrsld1){
    			bufferLogger.add(new StandardLogMessage(finalResult+" >= "+thrsld2+" and < "+thrsld1));
    			//ejbLogger.debug(new StandardLogMessage(finalResult+" >= "+thrsld2+" and < "+thrsld1));
    			TctCorrLstEntity corrisp = new TctCorrLstEntity();
    			TctCorrLstEntityPK pk = new TctCorrLstEntityPK();
    			pk.setCmpnid(company.getCmpnId());
    			pk.setAggregid(((TctAggrEntEntity)aggregMap.get(aggregName)).getId().getAggregId());
    			pk.setDownloadid(((TctAggrEntEntity)aggregMap.get(aggregName)).getId().getDownloadid());
    			
    			corrisp.setId(pk);
    			corrisp.setClntName(clientNames[0]);
    			corrisp.setCorrIndex(new BigDecimal(finalResult));
    			/*
    			 * raffaele de lauri
    			 * TN_CCG15280
    			 */
    			corrisp.setEntityName(realAggregName);
    			corrisp.setStatus("D");
    			corrisp.setTctcompany(company);
    			
    			corrisponds.add(corrisp);
    		}else if(finalResult>thrsld1) {
    			bufferLogger.add(new StandardLogMessage(finalResult+" > "+thrsld1));
    			//ejbLogger.debug(new StandardLogMessage(finalResult+" > "+thrsld1));
    			TctCorrLstEntity corrisp = new TctCorrLstEntity();
    			TctCorrLstEntityPK pk = new TctCorrLstEntityPK();
    			pk.setCmpnid(company.getCmpnId());
    			pk.setAggregid(((TctAggrEntEntity)aggregMap.get(aggregName)).getId().getAggregId());
    			pk.setDownloadid(((TctAggrEntEntity)aggregMap.get(aggregName)).getId().getDownloadid());
    			
    			corrisp.setId(pk);
    			corrisp.setClntName(clientNames[0]);
    			corrisp.setCorrIndex(new BigDecimal(finalResult));
    			/*
    			 * raffaele de lauri
    			 * TN_CCG15280
    			 */
    			corrisp.setEntityName(realAggregName);
    			corrisp.setStatus("O");
    			corrisp.setTctcompany(company);
    			
    			corrisponds.add(corrisp);
    		}
    	}

        bufferLogger.add(new StandardCheckPointMessage("Analysis on "+clientNames[0]+" completed "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
        //ejbLogger.info(new StandardCheckPointMessage("Analysis on "+client.getClntnName()+" completed"));
        
        } catch (BackEndException e) {
        	ExceptionUtil.logCompleteStackTrace(calcLogger, e);
        	bufferLogger.add(new StandardCheckPointMessage("Analysis on "+clientNames[0]+" terminated with errors: "+e.getMessage()));
			throw new BackEndException(e.getMessage());
		}finally{
			for (Object o : bufferLogger){
	        	if(o instanceof StandardCheckPointMessage){
	        		 calcLogger.info(o);
	        	}else{
	        		calcLogger.debug(o);
	        	}
	        }
		}
    	return corrisponds;
    }
    
    /**
     * 
     * @param client
     * @param aggregMap
     * @param JWThrshld
     * @param itId
     * @return
     * @throws BackEndException
     */
    @Asynchronous
    public Future<List<TctOptimizEntity>> optimize(TctClientEntity client, TreeMap<String,TctAggrEntEntity> aggregMap ,double JWThrshld,int itId) throws BackEndException{
    	List<Object> bufferLogger = new ArrayList<Object>(); 
    	List<TctOptimizEntity> corrisponds = new ArrayList<TctOptimizEntity>();
    	calcLogger.info(new StandardCheckPointMessage("Start optimizing on "+client.getClntName()+" "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	//bufferLogger.add(new StandardCheckPointMessage("Start optimizing on "+client.getClntName()+" "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	bufferLogger.add(new StandardLogMessage(client.getClntName()+" thread "+Thread.currentThread().getName()));
        //ejbLogger.debug(new StandardLogMessage(client.getClntnName()+" thread "+Thread.currentThread().getName()));
	    NameCleaner cleaner = new NameCleaner();
    	try {
	        Set<String> keys = aggregMap.keySet();
	        String cleanedClinetName = cleaner.clean(client.getClntName());
	    	String cleanedClinetAlias1="",cleanedClinetAlias2="",cleanedClinetAlias3="";
	    	if ((client.getClntAlias1() != null)&& !(client.getClntAlias1().equalsIgnoreCase(""))){
	    		cleanedClinetAlias1 = cleaner.clean(client.getClntAlias1());
	    	}
	    	if ((client.getClntAlias2() != null)&& !(client.getClntAlias2().equalsIgnoreCase(""))){
	    		cleanedClinetAlias2 = cleaner.clean(client.getClntAlias2());
	    	}
	    	if ((client.getClntAlias3() != null)&& !(client.getClntAlias3().equalsIgnoreCase(""))){
	    		cleanedClinetAlias3 = cleaner.clean(client.getClntAlias3());
	    	}
	        for (String aggregName : keys){
	        	/*
				 * raffaele de lauri
				 * TN_CCG15280
				 */
	        	String realAggregName = ((String[])aggregName.split("%"))[0];
	        	String cleanedAggrName = cleaner.clean(realAggregName);
				double result = this.softTfIdf.score(this.softTfIdf.prepare(cleanedClinetName), this.softTfIdf.prepare(cleanedAggrName) );
        		double result1 = 0,result2 = 0,result3 = 0;
        		if ((client.getClntAlias1() != null)&& !(client.getClntAlias1().equalsIgnoreCase(""))){
        			result1 = this.softTfIdf.score(this.softTfIdf.prepare(cleanedClinetAlias1), this.softTfIdf.prepare(cleanedAggrName) );
        		}
        		
        		if ((client.getClntAlias2() != null)&& !(client.getClntAlias2().equalsIgnoreCase(""))){
        			result2 = this.softTfIdf.score(this.softTfIdf.prepare(cleanedClinetAlias2), this.softTfIdf.prepare(cleanedAggrName) );
        		}
        		
        		if ((client.getClntAlias3() != null)&& !(client.getClntAlias3().equalsIgnoreCase(""))){
        			result3 = this.softTfIdf.score(this.softTfIdf.prepare(cleanedClinetAlias3), this.softTfIdf.prepare(cleanedAggrName) );
        		}
        		
            	TreeSet<Double> orderingTreeSet = new TreeSet<Double>();
            	orderingTreeSet.add(result);
            	orderingTreeSet.add(result1);
            	orderingTreeSet.add(result2);
            	orderingTreeSet.add(result3);
	        	
	        	double finalResult = orderingTreeSet.last();
	        	TctOptimizEntity optim = new TctOptimizEntity();
	        	TctOptimizEntityPK pk = new TctOptimizEntityPK();
	        	pk.setAggrid(aggregMap.get(aggregName).getId().getAggregId());
	        	pk.setClntid(client.getId().getClntId());
	        	pk.setCmpnid(client.getId().getCmpnId());
	        	pk.setDownloadid(aggregMap.get(aggregName).getId().getDownloadid());
	        	pk.setItId(itId);
	        	
	        	optim.setId(pk);
	        	optim.setCorrIndex(new BigDecimal(finalResult));
	        	/*
				 * raffaele de lauri
				 * TN_CCG15280
				 */
	        	optim.setEntityName(aggregName.split("%")[0]);
	        	optim.setClientName(client.getClntName());
	        	optim.setSource(aggregMap.get(aggregName).getSrcList());
	        	
	        	//optim.setTctaggrent(aggregMap.get(aggregName));
	        	//optim.setTctclient(client);
	        	optim.setJwThrshld(new BigDecimal(JWThrshld));
	        	
	        	if (optim.getCorrIndex().doubleValue()>0){
	        		corrisponds.add(optim);
	        	}
	        }
	        
	        this.optimizationController.incrementFinishedOptim();
	        bufferLogger.add(new StandardCheckPointMessage("Optimization on "+client.getClntName()+" completed "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
	        //ejbLogger.info(new StandardCheckPointMessage("Optimizing on "+client.getClntnName()+" completed"));
        } catch (BackEndException e) {
        	ExceptionUtil.logCompleteStackTrace(calcLogger, e);
        	bufferLogger.add(new StandardCheckPointMessage("Analysis on "+client.getClntName()+" terminated with errors: "+e.getMessage()));
			throw new BackEndException(e.getMessage());
		}finally{
			for (Object o : bufferLogger){
	        	if(o instanceof StandardCheckPointMessage){
	        		 calcLogger.info(o);
	        	}else{
	        		calcLogger.debug(o);
	        	}
	        }
		}
    	return new AsyncResult<List<TctOptimizEntity>>(corrisponds);
    }
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public void trainSecondString(Set<String> aggregated,List<TctClientEntity> clients) throws BackEndException{
    	calcLogger.debug(new StandardLogMessage("in void trainSecondString(Set<String> aggregated,double threshold)"));
    	calcLogger.info(new StandardCheckPointMessage("Start training secondoString "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	NameCleaner cleaner = new NameCleaner();
		//Tokenizer tokenizer = new SimpleTokenizer(false,true);
		
		//this.softTfIdf = new SoftTFIDF(tokenizer,new JaroWinkler(),new Double(SystemProperties.getSystemProperty("jarowinkler.thrshld")));
		List corpus = new ArrayList();
		for (String s : aggregated){
			/*
			 * raffaele de lauri
			 * TN_CCG15280
			 */
			s = cleaner.clean(s.split("%")[0]);
			corpus.add(this.softTfIdf.prepare(s));
		}
		for (TctClientEntity client : clients){
			String clientName = "",clientAlias = "";
			
			clientName = cleaner.clean(client.getClntName());
			corpus.add(this.softTfIdf.prepare(clientName));
			if(client.getClntAlias1()!=null && !(client.getClntAlias1().equalsIgnoreCase(""))){
				clientAlias = cleaner.clean(client.getClntAlias1());
				corpus.add(this.softTfIdf.prepare(clientAlias));
			}
			if(client.getClntAlias2()!=null && !(client.getClntAlias2().equalsIgnoreCase(""))){
				clientAlias = cleaner.clean(client.getClntAlias2());
				corpus.add(this.softTfIdf.prepare(clientAlias));
			}
			if(client.getClntAlias1()!=null && !(client.getClntAlias1().equalsIgnoreCase(""))){
				clientAlias = cleaner.clean(client.getClntAlias1());
				corpus.add(this.softTfIdf.prepare(clientAlias));
			}
		}
		softTfIdf.train(new BasicStringWrapperIterator(corpus.iterator()));
		
		calcLogger.info(new StandardCheckPointMessage("Training completed "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    }
    
    @SuppressWarnings("unchecked")
	public void trainSecondString(Set<String> aggregated,String... clients) throws BackEndException{
    	calcLogger.debug(new StandardLogMessage("in void trainSecondString(Set<String> aggregated,double threshold)"));
    	calcLogger.info(new StandardCheckPointMessage("Start training secondoString "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	NameCleaner cleaner = new NameCleaner();
		//Tokenizer tokenizer = new SimpleTokenizer(false,true);
		
		//this.softTfIdf = new SoftTFIDF(tokenizer,new JaroWinkler(),new Double(SystemProperties.getSystemProperty("jarowinkler.thrshld")));
		@SuppressWarnings("rawtypes")
		List corpus = new ArrayList();
		for (String s : aggregated){
			/*
			 * raffaele de lauri
			 * TN_CCG15280
			 */
			s = cleaner.clean(s.split("%")[0]);
			corpus.add(this.softTfIdf.prepare(s));
		}
		for (String s : clients){
			String clientName = "";
			
			clientName = cleaner.clean(s);
			corpus.add(this.softTfIdf.prepare(clientName));
		}
		softTfIdf.train(new BasicStringWrapperIterator(corpus.iterator()));
		
		calcLogger.info(new StandardCheckPointMessage("Training completed "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    }
    
    
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void trainSecondStringForOptimization(Set<String> aggregated,List<TctClientEntity> clients,Double thrshld) throws BackEndException{
       	calcLogger.debug(new StandardLogMessage("in void trainSecondString(Set<String> aggregated,double threshold)"));
       	calcLogger.info(new StandardCheckPointMessage("Start training secondoString "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
       	/*NameCleaner cleaner = new NameCleaner();*/
   		Tokenizer tokenizer = new SimpleTokenizer(false,true);
   		
   		this.softTfIdf = new SoftTFIDF(tokenizer,new JaroWinkler(),thrshld);
       	NameCleaner cleaner = new NameCleaner();
   		List corpus = new ArrayList();
   		for (String s : aggregated){
   			/*
			 * raffaele de lauri
			 * TN_CCG15280
			 */
   			s = cleaner.clean(s.split("%")[0]);
   			corpus.add(this.softTfIdf.prepare(s));
   		}
   		for (TctClientEntity client : clients){
			String clientName = "",clientAlias = "";
			
			clientName = cleaner.clean(client.getClntName());
			corpus.add(this.softTfIdf.prepare(clientName));
			if(client.getClntAlias1()!=null && !(client.getClntAlias1().equalsIgnoreCase(""))){
				clientAlias = cleaner.clean(client.getClntAlias1());
				corpus.add(this.softTfIdf.prepare(clientAlias));
			}
			if(client.getClntAlias2()!=null && !(client.getClntAlias2().equalsIgnoreCase(""))){
				clientAlias = cleaner.clean(client.getClntAlias2());
				corpus.add(this.softTfIdf.prepare(clientAlias));
			}
			if(client.getClntAlias1()!=null && !(client.getClntAlias1().equalsIgnoreCase(""))){
				clientAlias = cleaner.clean(client.getClntAlias1());
				corpus.add(this.softTfIdf.prepare(clientAlias));
			}
		}
   		softTfIdf.train(new BasicStringWrapperIterator(corpus.iterator()));
   		calcLogger.info(new StandardCheckPointMessage("Training completed "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
       }
}
