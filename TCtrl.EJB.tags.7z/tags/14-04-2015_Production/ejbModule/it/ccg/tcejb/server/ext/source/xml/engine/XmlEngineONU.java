package it.ccg.tcejb.server.ext.source.xml.engine;

import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.ext.source.xml.un.ConsolidatedList;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

public class XmlEngineONU {
	private static final Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	public static void main(String[] args){
		try {
			new XmlEngineONU().read();
		} catch (BackEndException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ConsolidatedList read(String path)throws JAXBException, BackEndException{
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(path);
			Reader reader = new InputStreamReader(inputStream, "UTF-8");
			
			//File file = new File(path);
			JAXBContext jaxbContext;
			ConsolidatedList cont = null;
	
			jaxbContext = JAXBContext.newInstance(ConsolidatedList.class);
			
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			cont = (ConsolidatedList)jaxbUnmarshaller.unmarshal(reader);
							
			return cont;
		} catch (UnsupportedEncodingException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		} catch (FileNotFoundException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		}finally{
			try {
				if (inputStream!=null)
					inputStream.close();
			} catch (IOException e) {
				ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
				throw new BackEndException(e);
			}
		}
	}
	
	/**
	 * Methods that use a determinate path
	 * C:/Users/rdelauri/Desktop/Antiterrorismo/Antiterrorismo/01_Requisiti utente/Flussi/onu/AQList.xml
	 * @return
	 * @throws BackEndException 
	 */
	public ConsolidatedList read() throws BackEndException{
		File file = new File("C:/Temp/AQList.xml");
		JAXBContext jaxbContext;
		ConsolidatedList cont =null;
		try {
			jaxbContext = JAXBContext.newInstance(ConsolidatedList.class);
			
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			cont = (ConsolidatedList)jaxbUnmarshaller.unmarshal(file);
	
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		}
		return cont;
	}
	
	public ConsolidatedList read(File file) throws BackEndException{
		
		JAXBContext jaxbContext;
		ConsolidatedList cont =null;
		try {
			jaxbContext = JAXBContext.newInstance(ConsolidatedList.class);
			
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			cont = (ConsolidatedList)jaxbUnmarshaller.unmarshal(file);
	
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		}
		return cont;
	}
	
	public ConsolidatedList read(InputStream iStream) throws BackEndException{
		
		JAXBContext jaxbContext;
		ConsolidatedList cont =null;
		try {
			jaxbContext = JAXBContext.newInstance(ConsolidatedList.class);
			
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			cont = (ConsolidatedList)jaxbUnmarshaller.unmarshal(iStream);
	
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		}
		return cont;
	}
}
