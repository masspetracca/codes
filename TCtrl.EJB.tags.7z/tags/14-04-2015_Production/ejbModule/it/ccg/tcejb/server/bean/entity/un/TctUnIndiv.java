package it.ccg.tcejb.server.bean.entity.un;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TCTUNINDIV database table.
 * 
 */
@Entity
@Table(name="TCTUNINDIV")
@NamedQueries({
	@NamedQuery(name="getUnIndividualsById", query="SELECT entity FROM TctUnIndiv entity WHERE entity.dataId = :dataId ORDER BY entity.dataId ASC"),
	@NamedQuery(name="getUnIndividuals", query="SELECT entity FROM TctUnIndiv entity ORDER BY entity.dataId ASC"),
	@NamedQuery(name="getUnIndividualsBySrcListDate", query="SELECT entity " +
			   "										 FROM TctUnIndiv entity " +
			   "										WHERE entity.dateGenerated = :srcListDate " +
			   "										ORDER BY entity.dataId ASC"),
    @NamedQuery(name="getUnIndLatestSrcListDate",    query="SELECT MAX(entity.dateGenerated) " +
	           "										   FROM TctUnIndiv entity"),
	/*
	 * raffaele de lauri
	 * TN_CCG15298
	 */
    @NamedQuery(name="getUnLatestIndividuals", query="SELECT entity " +
               "								     FROM TctUnIndiv entity " +
               "								    WHERE entity.releasedDt = (SELECT MAX(entity2.releasedDt) " +
               "								 							  FROM TctUnIndiv entity2" +
               "															 WHERE entity2.dataId = entity.dataId)" +
    		   "								    ORDER BY entity.dataId ASC"),
    @NamedQuery(name="deleteUnEveryIndividuals", query="DELETE FROM TctUnIndiv")
})
public class TctUnIndiv implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Id
	@Column(unique=true, nullable=false)
	private int dataId;

	@Column(length=1000)
	private String comments1;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date dateGenerated;

	@Column(nullable=false, length=255)
	private String firstName;

	@Column(nullable=false)
	private Timestamp listedOn;

	@Column(length=255)
	private String nOrgScript;

	@Column(nullable=false, length=50)
	private String refNumber;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date releasedDt;

	@Column(nullable=true, length=255)
	private String secondName;

	@Column(nullable=true, length=255)
	private String sortKey;

	@Column(nullable=true)
	private Timestamp sortKeyLsMod;

	@Column(nullable=true, length=255)
	private String thirdName;

	@Column(nullable=false, length=50)
	private String unListTp;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=10)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	//bi-directional many-to-one association to TctUnAlia
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnAlia> tctunalias;

	//bi-directional many-to-one association to TctUnBrtDt
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnBrtDt> tctunbrtdts;

	//bi-directional many-to-one association to TctUnBtPlc
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnBtPlc> tctunbtplcs;

	//bi-directional many-to-one association to TctUnLstUp
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnLstUp> tctunlstups;

	//bi-directional many-to-one association to TctUnNat
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnNat> tctunnats;

	//bi-directional many-to-one association to TctUnNat
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnInDoc> tctunindoc;
	
	//bi-directional many-to-one association to TctUnAddr
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunindiv")
	//@Transient
	private Set<TctUnAddr> tctunaddrs;
		
    public TctUnIndiv() {
    }

	public int getDataId() {
		return this.dataId;
	}

	public void setDataId(int dataId) {
		this.dataId = dataId;
	}

	public String getComments1() {
		return this.comments1;
	}

	public void setComments1(String comments1) {
		if (comments1 != null && comments1.length()>1000){
			ejbLogger.debug(comments1+" >1000 than truncate");
			this.comments1 = comments1.substring(0, 999);
		}else{
			this.comments1 = comments1;
		}
	}

	public Date getDateGenerated() {
		return this.dateGenerated;
	}

	public void setDateGenerated(Date dateGenerated) {
		this.dateGenerated = dateGenerated;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		if (firstName !=null && firstName.length()>255){
			ejbLogger.debug(firstName+" >255 than truncate");
			this.firstName = firstName.substring(0, 254);
		}else{
			this.firstName = firstName;
		}
	}

	public Timestamp getListedOn() {
		return this.listedOn;
	}

	public void setListedOn(Timestamp listedOn) {
		this.listedOn = listedOn;
	}

	public String getNOrgScript() {
		return this.nOrgScript;
	}

	public void setNOrgScript(String nOrgScript) {
		if (nOrgScript!=null && nOrgScript.length()>255){
			ejbLogger.debug(nOrgScript+" >255 than truncate");
			this.nOrgScript = nOrgScript.substring(0, 254);
		}else{
			this.nOrgScript = nOrgScript;
		}
	}

	public String getRefNumber() {
		return this.refNumber;
	}

	public void setRefNumber(String refNumber) {
		if (refNumber != null && refNumber.length()>50){
			ejbLogger.debug(refNumber+" >50 than truncate");
			this.refNumber = refNumber.substring(0, 49);
		}else{
			this.refNumber = refNumber;
		}
	}

	public Date getReleasedDt() {
		return this.releasedDt;
	}

	public void setReleasedDt(Date releasedDt) {
		this.releasedDt = releasedDt;
	}

	public String getSecondName() {
		return this.secondName;
	}

	public void setSecondName(String secondName) {
		/*
		 * raffale de lauri
		 * TN_CCG15247
		 */
		if (secondName!=null && secondName.length()>255){
			ejbLogger.debug(secondName+" >255 than truncate");
			this.secondName = secondName.substring(0, 254);
		}else{
			this.secondName = secondName;
		}
	}

	public String getSortKey() {
		return this.sortKey;
	}

	public void setSortKey(String sortKey) {
		if (sortKey != null && sortKey.length()>255){
			ejbLogger.debug(sortKey+" >255 than truncate");
			this.sortKey = sortKey.substring(0, 254);
		}else{
			this.sortKey = sortKey;
		}
	}

	public Timestamp getSortKeyLsMod() {
		return this.sortKeyLsMod;
	}

	public void setSortKeyLsMod(Timestamp sortKeyLsMod) {
		this.sortKeyLsMod = sortKeyLsMod;
	}

	public String getThirdName() {
		return this.thirdName;
	}

	public void setThirdName(String thirdName) {
		/*
		 * raffale de lauri
		 * TN_CCG15247
		 */
		if (thirdName!=null && thirdName.length()>255){
			ejbLogger.debug(thirdName+" >255 than truncate");
			this.thirdName = thirdName.substring(0, 254);
		}else{
			this.thirdName = thirdName;
		}
	}

	public String getUnListTp() {
		return this.unListTp;
	}

	public void setUnListTp(String unListTp) {
		if (unListTp != null && unListTp.length()>50){
			ejbLogger.debug(unListTp+" >50 than truncate");
			this.unListTp = unListTp.substring(0, 49);
		}else{
			this.unListTp = unListTp;
		}
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public Set<TctUnAlia> getTctunalias() {
		return this.tctunalias;
	}

	public void setTctunalias(Set<TctUnAlia> tctunalias) {
		this.tctunalias = tctunalias;
	}
	
	public Set<TctUnBrtDt> getTctunbrtdts() {
		return this.tctunbrtdts;
	}

	public void setTctunbrtdts(Set<TctUnBrtDt> tctunbrtdts) {
		this.tctunbrtdts = tctunbrtdts;
	}
	
	public Set<TctUnBtPlc> getTctunbtplcs() {
		return this.tctunbtplcs;
	}

	public void setTctunbtplcs(Set<TctUnBtPlc> tctunbtplcs) {
		this.tctunbtplcs = tctunbtplcs;
	}
		
	public Set<TctUnLstUp> getTctunlstups() {
		return this.tctunlstups;
	}

	public void setTctunlstups(Set<TctUnLstUp> tctunlstups) {
		this.tctunlstups = tctunlstups;
	}
	
	public Set<TctUnNat> getTctunnats() {
		return this.tctunnats;
	}

	public void setTctunnats(Set<TctUnNat> tctunnats) {
		this.tctunnats = tctunnats;
	}

	/**
	 * @return the nOrgScript
	 */
	public String getnOrgScript() {
		return nOrgScript;
	}

	/**
	 * @param nOrgScript the nOrgScript to set
	 */
	public void setnOrgScript(String nOrgScript) {
		this.nOrgScript = nOrgScript;
	}

	/**
	 * @return the tctunindoc
	 */
	public Set<TctUnInDoc> getTctunindoc() {
		return tctunindoc;
	}

	/**
	 * @param tctunindoc the tctunindoc to set
	 */
	public void setTctunindoc(Set<TctUnInDoc> tctunindoc) {
		this.tctunindoc = tctunindoc;
	}

	/**
	 * @return the tctunaddrs
	 */
	public Set<TctUnAddr> getTctunaddrs() {
		return tctunaddrs;
	}

	/**
	 * @param tctunaddrs the tctunaddrs to set
	 */
	public void setTctunaddrs(Set<TctUnAddr> tctunaddrs) {
		this.tctunaddrs = tctunaddrs;
	}
	
}