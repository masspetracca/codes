package it.ccg.tcejb.server.bean.entity.ec;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;

import java.util.Date;


/**
 * The persistent class for the TCTECBIRTH database table.
 * 
 */
@Entity
@Table(name="TCTECBIRTH")
@NamedQueries({
	@NamedQuery(name="deleteEcBirthEveryEntity", query="DELETE FROM TctEcBirthEntity"),
	@NamedQuery(name="getEcBirthEntitiesById", query="SELECT entity FROM TctEcBirthEntity entity WHERE entity.id.entityid = :entityId ORDER BY entity.id.birthId ASC")
})
public class TctEcBirthEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	@EmbeddedId
	private TctEcBirthEntityPK id;

	@Column(length=50)
	private String country;

	@Column(length=100)
	private String date;

	@Column(length=100)
	private String legalBasis;

	@Column(length=2000)
	private String pdfLink;

	@Column(length=255)
	private String place;

    @Temporal( TemporalType.DATE)
	private Date regDate;

	//bi-directional many-to-one association to TctEcEntitEntity
    @ManyToOne(optional=true)
	@JoinColumn(name="ENTITYID", nullable=true, insertable=true, updatable=true)
	private TctEcEntitEntity tctecentit;

    public TctEcBirthEntity() {
    }

	public TctEcBirthEntityPK getId() {
		return this.id;
	}

	public void setId(TctEcBirthEntityPK id) {
		this.id = id;
	}
	
	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		if (country != null && country.length()>50){
			ejbLogger.debug(country+" >50 than truncate");
			this.country = country.substring(0, 49);
		}else{
			this.country = country;
		}
	}

	public String getDate() {
		return this.date;
	}

	public void setDate(String date) {
		if (date !=null && date.length()>100){
			ejbLogger.debug(date+" >100 than truncate");
			this.date = date.substring(0, 99);
		}else{
			this.date = date;
		}
	}

	public String getLegalBasis() {
		return this.legalBasis;
	}

	public void setLegalBasis(String legalBasis) {
		if (legalBasis != null && legalBasis.length()>100){
			ejbLogger.debug(legalBasis+" >100 than truncate");
			this.legalBasis = legalBasis.substring(0, 99);
		}else{
			this.legalBasis = legalBasis;
		}
	}

	public String getPdfLink() {
		return this.pdfLink;
	}

	public void setPdfLink(String pdfLink) {
		if (pdfLink !=null &&pdfLink.length()>2000){
			ejbLogger.debug(pdfLink+" >2000 than truncate");
			this.pdfLink = pdfLink.substring(0, 1999);
		}else{
			this.pdfLink = pdfLink;
		}
	}

	public String getPlace() {
		return this.place;
	}

	public void setPlace(String place) {
		if (place !=null && place.length()>255){
			ejbLogger.debug(place+" >255 than truncate");
			this.place = place.substring(0, 254);
		}else{
			this.place = place;
		}
	}

	public Date getRegDate() {
		return this.regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public TctEcEntitEntity getTctecentit() {
		return this.tctecentit;
	}

	public void setTctecentit(TctEcEntitEntity tctecentit) {
		this.tctecentit = tctecentit;
	}
	
}