package it.ccg.tcejb.server.system;


import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

//import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

import sun.reflect.Reflection;

public class LocalBeanLookup {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	public static Object lookup(String beanLocalInterfaceCompleteName) throws BackEndException {
		
		/*String initialContextFactory = "com.ibm.websphere.naming.WsnInitialContextFactory";  
        String providerUrl = "corbaloc:iiop:localhost:2809";  
        
        Hashtable<String, String> environment = new Hashtable<String, String>();  
        environment.put(Context.INITIAL_CONTEXT_FACTORY, initialContextFactory);  
        environment.put(Context.PROVIDER_URL, providerUrl); */
        
        Object object = null;
        
        try {  
            Context ctx = new InitialContext(/*environment*/); 
            
            object = ctx.lookup("ejblocal:" + beanLocalInterfaceCompleteName);
            
            
            logger.debug(new StandardLogMessage("Caller class: " + Reflection.getCallerClass(2) + "  ##  Instance of " + beanLocalInterfaceCompleteName + " looked up."));
        } 
        catch(NamingException e) {
            
        	ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
        }
        
		
		return object;
	}

}
