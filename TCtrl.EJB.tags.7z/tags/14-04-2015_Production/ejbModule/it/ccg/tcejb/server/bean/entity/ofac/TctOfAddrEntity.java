package it.ccg.tcejb.server.bean.entity.ofac;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTOFADDR database table.
 * 
 */
@Entity
@Table(name="TCTOFADDR")
@NamedQueries({
	@NamedQuery(name="deleteOfAddrEveryEntity", query="DELETE FROM TctOfAddrEntity"),
	@NamedQuery(name="getOFAddrEntitiesById", query="SELECT entity FROM TctOfAddrEntity entity WHERE entity.id.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctOfAddrEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@EmbeddedId
	private TctOfAddrEntityPK id;

	@Column(nullable=false, length=255)
	private String addr1;

	@Column(length=255)
	private String addr2;

	@Column(length=255)
	private String addr3;

	@Column(nullable=false, length=50)
	private String city;

	@Column(nullable=false, length=50)
	private String country;

	@Column(nullable=false, length=50)
	private String posCode;

	//bi-directional many-to-one association to TctOfEntitEntity
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	private TctOfEntitEntity tctofentit;

    public TctOfAddrEntity() {
    }

	public TctOfAddrEntityPK getId() {
		return this.id;
	}

	public void setId(TctOfAddrEntityPK id) {
		this.id = id;
	}
	
	public String getAddr1() {
		return this.addr1;
	}

	public void setAddr1(String addr1) {
		if (addr1 != null && addr1.length()>255){
			ejbLogger.debug(addr1+" >255 than truncate");
			this.addr1 = addr1.substring(0, 254);
		}else{
			this.addr1 = addr1;
		}
	}

	public String getAddr2() {
		return this.addr2;
	}

	public void setAddr2(String addr2) {
		if (addr2 != null && addr2.length()>255){
			ejbLogger.debug(addr2+" >255 than truncate");
			this.addr2 = addr2.substring(0, 254);
		}else{
			this.addr2 = addr2;
		}
	}

	public String getAddr3() {
		return this.addr3;
	}

	public void setAddr3(String addr3) {
		if (addr3 != null && addr3.length()>255){
			ejbLogger.debug(addr3+" >255 than truncate");
			this.addr3 = addr3.substring(0, 254);
		}else{
			this.addr3 = addr3;
		}
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		if (city != null && city.length()>50){
			ejbLogger.debug(city+" >50 than truncate");
			this.city = city.substring(0, 49);
		}else{
			this.city = city;
		}
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		if (country != null && country.length()>50){
			ejbLogger.debug(country+" >50 than truncate");
			this.country = country.substring(0, 49);
		}else{
			this.country = country;
		}
	}

	public String getPosCode() {
		return this.posCode;
	}

	public void setPosCode(String posCode) {
		if (posCode != null && posCode.length()>50){
			ejbLogger.debug(posCode+" >50 than truncate");
			this.posCode = posCode.substring(0, 49);
		}else{
			this.posCode = posCode;
		}
	}

	public TctOfEntitEntity getTctofentit() {
		return this.tctofentit;
	}

	public void setTctofentit(TctOfEntitEntity tctofentit) {
		this.tctofentit = tctofentit;
	}
	
}