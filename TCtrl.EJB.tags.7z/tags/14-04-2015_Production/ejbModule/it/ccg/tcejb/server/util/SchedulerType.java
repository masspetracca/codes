package it.ccg.tcejb.server.util;

public enum SchedulerType {
		Daily
		
}
