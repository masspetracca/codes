package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;


public class TctCorrisp implements Serializable {
	private static final long serialVersionUID = 1L;

	private String clntName;

	private int runId;

	private int clntid;

	private String aggrId;

	private int cmpnid;

	private int downloadid;

	private BigDecimal corrIndex;

	private String entityName;

	private String status;

	private Timestamp updDate;

	private String updType;
	
	private String updUser;
	
	private int entityId;
	
	private String srclist;
	
	private Timestamp subDate;
	
	private Timestamp runDate;
	
	private String user;
	
	
	
    public TctCorrisp() {
    }


	public String getClntName() {
		return clntName;
	}



	public void setClntName(String clntName) {
		this.clntName = clntName;
	}



	public BigDecimal getCorrIndex() {
		return corrIndex;
	}



	public void setCorrIndex(BigDecimal corrIndex) {
		this.corrIndex = corrIndex;
	}



	public String getEntityName() {
		return entityName;
	}



	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public Timestamp getUpdDate() {
		return updDate;
	}



	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}



	public String getUpdType() {
		return updType;
	}



	public void setUpdType(String updType) {
		this.updType = updType;
	}



	public String getUpdUser() {
		return updUser;
	}



	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}



	public int getEntityId() {
		return entityId;
	}



	public void setEntityId(int entityId) {
		this.entityId = entityId;
	}



	public String getSrclist() {
		return srclist;
	}



	public void setSrclist(String srclist) {
		this.srclist = srclist;
	}



	public Timestamp getSubDate() {
		return subDate;
	}



	public void setSubDate(Timestamp subDate) {
		this.subDate = subDate;
	}



	public Timestamp getRunDate() {
		return runDate;
	}



	public void setRunDate(Timestamp runDate) {
		this.runDate = runDate;
	}



	public String getUser() {
		return user;
	}



	public void setUser(String user) {
		this.user = user;
	}



	public int getRunId() {
		return runId;
	}



	public void setRunId(int runId) {
		this.runId = runId;
	}



	public int getClntid() {
		return clntid;
	}



	public void setClntid(int clntid) {
		this.clntid = clntid;
	}



	public String getAggrId() {
		return aggrId;
	}



	public void setAggrId(String aggrId) {
		this.aggrId = aggrId;
	}



	public int getCmpnid() {
		return cmpnid;
	}



	public void setCmpnid(int cmpnid) {
		this.cmpnid = cmpnid;
	}



	public int getDownloadid() {
		return downloadid;
	}



	public void setDownloadid(int downloadid) {
		this.downloadid = downloadid;
	}
	
	
    
}