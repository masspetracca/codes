package it.ccg.tcejb.server.security.view;



public interface TokenManagerLocal {

public String fetchToken(String user) throws Exception;

	
	public void add(String user, String token) throws Exception;

	public void upsert(String user, String token) throws Exception;
}
