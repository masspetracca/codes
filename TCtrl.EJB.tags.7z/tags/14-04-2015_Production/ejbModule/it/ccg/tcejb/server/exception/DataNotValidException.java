package it.ccg.tcejb.server.exception;

import javax.ejb.ApplicationException;

import org.apache.log4j.Logger;


@ApplicationException(rollback=true)

public class DataNotValidException  extends Exception {

	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");

	private static final long serialVersionUID = 1L;

	public DataNotValidException(String message) {
		super("Data not valid: "+message);
	}
}