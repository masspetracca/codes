package it.ccg.tcejb.server.bean.entity.ofac;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTOFCITZ database table.
 * 
 */
@Embeddable
public class TctOfCitzEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int citizId;

	@Column(unique=true, nullable=false)
	private int entityid;

    public TctOfCitzEntityPK() {
    }
	public int getCitizId() {
		return this.citizId;
	}
	public void setCitizId(int citizId) {
		this.citizId = citizId;
	}
	public int getEntityid() {
		return this.entityid;
	}
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctOfCitzEntityPK)) {
			return false;
		}
		TctOfCitzEntityPK castOther = (TctOfCitzEntityPK)other;
		return 
			(this.citizId == castOther.citizId)
			&& (this.entityid == castOther.entityid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.citizId;
		hash = hash * prime + this.entityid;
		
		return hash;
    }
}