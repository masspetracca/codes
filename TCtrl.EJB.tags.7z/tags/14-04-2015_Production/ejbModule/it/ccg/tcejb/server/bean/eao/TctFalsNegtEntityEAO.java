package it.ccg.tcejb.server.bean.eao;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import it.ccg.tcejb.server.bean.entity.TctFalNegtEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctFalsNegtEntityEAO
 */
@Stateless
@LocalBean
public class TctFalsNegtEntityEAO {

	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctFalsNegtEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctFalNegtEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctFalNegtEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctFalNegtEntity identification data: client id = "+entity.getId().getClntid() +" , company id = "+entity.getId().getCmpnid()+" , aggregated id= "+entity.getId().getAggrId()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));	
    }
        
    public void insertEntity(List<TctFalNegtEntity> entities) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in insertEntity(List<TctCorrispEntity> entities)"));
    	int idxToFlush = 0;
    	for (TctFalNegtEntity entity :entities){
    		ejbLogger.debug(new StandardLogMessage("TctFalNegtEntity identification data: client id = "+entity.getId().getClntid() +" , company id = "+entity.getId().getCmpnid()+" , aggregated id= "+entity.getId().getAggrId()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	idxToFlush++;
	    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
	    		ejbLogger.debug(new StandardLogMessage("insert"));
		    	this.manager.flush();
	    	}
    	}
    	ejbLogger.debug(new StandardLogMessage("last insert"));
    	this.manager.flush();
    }
    
  	public void deleteEntity(TctFalNegtEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctFalNegtEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctFalNegtEntity identification data: client id = "+entity.getId().getClntid() +" , company id = "+entity.getId().getCmpnid()+" , aggregated id= "+entity.getId().getAggrId()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctFalNegtEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctClientEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctFalNegtEntity identification data: client id = "+entity.getId().getClntid() +" , company id = "+entity.getId().getCmpnid()+" , aggregated id= "+entity.getId().getAggrId()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("U");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	@SuppressWarnings("unchecked")
	public List<TctFalNegtEntity> retrieveFalseNegativeByCompanyID(int companyId) throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in List<TctFalNegtEntity> retrieveFalseNegativeByCompanyID(int companyId)"));
    	ejbLogger.debug(new StandardLogMessage("Company id "+companyId));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getFNegativeByCmpnId");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("cmpnId", companyId);
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
    	List<TctFalNegtEntity> falseNegative = (List<TctFalNegtEntity>) q.getResultList();
    	    	
		ejbLogger.debug(new StandardLogMessage("return"));
    	return falseNegative;
  		
  	}
}
