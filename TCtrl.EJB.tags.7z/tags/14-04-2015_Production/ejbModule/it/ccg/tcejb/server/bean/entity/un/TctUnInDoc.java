package it.ccg.tcejb.server.bean.entity.un;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTUNINDOC database table.
 * 
 */
@Entity
@Table(name="TCTUNINDOC")
@NamedQueries({
	@NamedQuery(name="deleteUnIndDocEveryEntity", query="DELETE FROM TctUnInDoc"),
	@NamedQuery(name="getUnIndDocEntitiesById", query="SELECT entity FROM TctUnInDoc entity WHERE entity.entityid = :entityId ORDER BY entity.addressId ASC")
})
public class TctUnInDoc implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private int documentId;

	@Column(nullable=false)
	private int entityId;

	@Column(length=255)
	private String number;

	@Column(length=255)
	private String typeOfDoc;

	@Column(length=1000)
	private String note;
	
	@ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	//@Transient
	private TctUnIndiv tctunindiv;
	
    public TctUnInDoc() {
    }

	public int getDocumentId() {
		return this.documentId;
	}

	public void setDocumentId(int documentId) {
		this.documentId = documentId;
	}

	public int getEntityId() {
		return this.entityId;
	}

	public void setEntityId(int entityId) {
		this.entityId = entityId;
	}

	public String getNumber() {
		return this.number;
	}

	public void setNumber(String number) {
		if (number !=null && number.length()>255){
			ejbLogger.debug(number+" >255 than truncate");
			this.number = number.substring(0, 254);
		}else{
			this.number = number;
		}
	}

	public String getTypeOfDoc() {
		return this.typeOfDoc;
	}

	public void setTypeOfDoc(String typeOfDoc) {
		if (typeOfDoc !=null && typeOfDoc.length()>255){
			ejbLogger.debug(number+" >255 than truncate");
			this.typeOfDoc = typeOfDoc.substring(0, 254);
		}else{
			this.typeOfDoc = typeOfDoc;
		}
	}

	/**
	 * @return the tctunindiv
	 */
	public TctUnIndiv getTctunindiv() {
		return tctunindiv;
	}

	/**
	 * @param tctunindiv the tctunindiv to set
	 */
	public void setTctunindiv(TctUnIndiv tctunindiv) {
		this.tctunindiv = tctunindiv;
	}

	/**
	 * @return the note
	 */
	public String getNote() {
		return note;
	}

	/**
	 * @param note the note to set
	 */
	public void setNote(String note) {
		if (note !=null && note.length()>1000){
			ejbLogger.debug(number+" >1000 than truncate");
			this.note = note.substring(0, 999);
		}else{
			this.note = note;
		}
	}
	
}