package it.ccg.tcejb.server.bean.entity.ec;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TCTECENTIT database table.
 * 
 */
@Entity
@Table(name="TCTECENTIT")
@NamedQueries({
	@NamedQuery(name="getEcEntitiesById", query="SELECT entity FROM TctEcEntitEntity entity WHERE entity.entityId = :entityId ORDER BY entity.entityId ASC"),
	@NamedQuery(name="getEcEntities", query="SELECT entity FROM TctEcEntitEntity entity ORDER BY entity.entityId ASC"),
	@NamedQuery(name="getEcEntitiesBySrcListDate", query="SELECT entity " +
			   "										 FROM TctEcEntitEntity entity " +
			   "										WHERE entity.regDate = :srcListDate " +
			   "										  AND entity.type = 'E'" +
			   " 										ORDER BY entity.entityId ASC"),
    @NamedQuery(name="getEcPeopleBySrcListDate", query="SELECT entity " +
		       "										  FROM TctEcEntitEntity entity " +
		       "										 WHERE entity.regDate = :srcListDate " +
		       "										   AND entity.type = 'P'" +
		       " 										 ORDER BY entity.entityId ASC"),
    @NamedQuery(name="getEcLatestSrcListDate",    query="SELECT MAX(entity.srcListDate) " +
	           "										   FROM TctEcEntitEntity entity"),
    /*
     * raffaele de lauri
     * TN_CCG15298
     */
	@NamedQuery(name="getEcLatestEntities", query="SELECT entity " +
               "								     FROM TctEcEntitEntity entity " +
               "								    WHERE entity.type = 'E' " +
               "								      AND entity.srcListDate = (SELECT MAX(entity2.srcListDate) " +
               "								 							  FROM TctEcEntitEntity entity2" +
               "															 WHERE entity2.type = 'E')" +
    		   "								    ORDER BY entity.entityId ASC"),
	/*
	 * raffaele de lauri
	 * TN_CCG15298
	 */
    @NamedQuery(name="getEcLatestPeople",   query="SELECT TctEcEntitEntity " +
               "								   FROM TctEcEntit entity " +
               "								  WHERE entity.type = 'P' " +
               "								    AND entity.srcListDate = (SELECT MAX(entity2.srcListDate) " +
               "								 							    FROM TctEcEntitEntity entity2" +
               "															   WHERE entity2.type = 'P'" +
               "															     AND entity2.entityId = entity.entityId)" +
 		       "								  ORDER BY entity.entityId ASC"),
    @NamedQuery(name="deleteEcEveryEntity", query="DELETE FROM TctEcEntitEntity")
})
public class TctEcEntitEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@Id
	@Column(unique=true, nullable=false)
	private int entityId;

	@Column(length=100)
	private String legalBasis;

	@Column(length=2000)
	private String pdfLink;

    @Temporal( TemporalType.DATE)
	private Date regDate;

	@Column(length=255)
	private String remark;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date srcListDate;

	@Column(nullable=false, length=1)
	private String type;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	//bi-directional many-to-one association to TctEcAddrdEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctecentit")
	private Set<TctEcAddrdEntity> tctecaddrds;

	//bi-directional many-to-one association to TctEcBirthEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctecentit")
	private Set<TctEcBirthEntity> tctecbirths;

	//bi-directional many-to-one association to TctEcCitizEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctecentit")
	private Set<TctEcCitizEntity> tcteccitizs;

	//bi-directional many-to-one association to TctEcENameEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctecentit")
	private Set<TctEcENameEntity> tctecenames;

	//bi-directional many-to-one association to TctEcPssPtEntity
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctecentit")
	private Set<TctEcPssPtEntity> tctecpsspts;

    public TctEcEntitEntity() {
    }

	public int getEntityId() {
		return this.entityId;
	}

	public void setEntityId(int entityId) {
		this.entityId = entityId;
	}

	public String getLegalBasis() {
		return this.legalBasis;
	}

	public void setLegalBasis(String legalBasis) {
		if (legalBasis != null && legalBasis.length()>100){
			ejbLogger.debug(legalBasis+" >100 than truncate");
			this.legalBasis = legalBasis.substring(0, 99);
		}else{
			this.legalBasis = legalBasis;
		}
	}

	public String getPdfLink() {
		return this.pdfLink;
	}

	public void setPdfLink(String pdfLink) {
		if (pdfLink != null && pdfLink.length()>2000){
			ejbLogger.debug(pdfLink+" >2000 than truncate");
			this.pdfLink = pdfLink.substring(0, 1999);
		}else{
			this.pdfLink = pdfLink;
		}
	}

	public Date getRegDate() {
		return this.regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		if (remark != null && remark.length()>255){
			ejbLogger.debug(remark+" >255 than truncate");
			this.remark = remark.substring(0, 254);
		}else{
			this.remark = remark;
		}
	}

	public Date getSrcListDate() {
		return this.srcListDate;
	}

	public void setSrcListDate(Date srcListDate) {
		this.srcListDate = srcListDate;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		if (type != null && type.length()>1){
			ejbLogger.debug(type+" >1 than truncate");
			this.type = type.substring(0,1);
		}else{
			this.type = type;
		}
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public Set<TctEcAddrdEntity> getTctecaddrds() {
		return this.tctecaddrds;
	}

	public void setTctecaddrds(Set<TctEcAddrdEntity> tctecaddrds) {
		this.tctecaddrds = tctecaddrds;
	}
	
	public Set<TctEcBirthEntity> getTctecbirths() {
		return this.tctecbirths;
	}

	public void setTctecbirths(Set<TctEcBirthEntity> tctecbirths) {
		this.tctecbirths = tctecbirths;
	}
	
	public Set<TctEcCitizEntity> getTcteccitizs() {
		return this.tcteccitizs;
	}

	public void setTcteccitizs(Set<TctEcCitizEntity> tcteccitizs) {
		this.tcteccitizs = tcteccitizs;
	}
	
	public Set<TctEcENameEntity> getTctecenames() {
		return this.tctecenames;
	}

	public void setTctecenames(Set<TctEcENameEntity> tctecenames) {
		this.tctecenames = tctecenames;
	}
	
	public Set<TctEcPssPtEntity> getTctecpsspts() {
		return this.tctecpsspts;
	}

	public void setTctecpsspts(Set<TctEcPssPtEntity> tctecpsspts) {
		this.tctecpsspts = tctecpsspts;
	}
	
}