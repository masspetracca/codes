package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctCorrLstEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/*
 * ticket 14899
 */

/**
 * Session Bean implementation class TctCorrLstEntityEAO
 */
@Stateless
@LocalBean
public class TctCorrLstEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctCorrLstEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctCorrLstEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctCorrLstEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctCorrLstEntity identification data: company id = "+entity.getId().getCmpnid()+" , aggregated id= "+entity.getId().getAggregid()+" , download id= "+entity.getId().getDownloadid()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));	
    }
        
    public void insertEntity(List<TctCorrLstEntity> entities) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in insertEntity(List<TctCorrLstEntity> entities)"));
    	int idxToFlush = 0;
    	for (TctCorrLstEntity entity :entities){
    		ejbLogger.debug(new StandardLogMessage("TctCorrLstEntity identification data: company id = "+entity.getId().getCmpnid()+" , aggregated id= "+entity.getId().getAggregid()+" , download id= "+entity.getId().getDownloadid()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	idxToFlush++;
	    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
	    		ejbLogger.debug(new StandardLogMessage("insert"));
		    	this.manager.flush();
	    	}
    	}
    	ejbLogger.debug(new StandardLogMessage("last insert"));
    	this.manager.flush();
    }
    
  	public void deleteEntity(TctCorrLstEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in TctCorrLstEntity(TctCorrispEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctCorrLstEntity identification data: company id = "+entity.getId().getCmpnid()+" , aggregated id= "+entity.getId().getAggregid()+" , download id= "+entity.getId().getDownloadid()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void deleteEveryEntity(int cmpnid) throws BackEndException{
  		try{
  			ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteEveryCorrLst");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("cmpnid", cmpnid);
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	this.manager.flush();
	    	
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctCorrLstEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctClientEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctCorrLstEntity identification data: company id = "+entity.getId().getCmpnid()+" , aggregated id= "+entity.getId().getAggregid()+" , download id= "+entity.getId().getDownloadid()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("U");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	//********************AGGIUNTA*****************
	public List<TctCorrLstEntity> retrieveByCmpnId(int companyId) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in retrieveByRunId(int companyId)"));
	   // ejbLogger.debug(new StandardLogMessage("Run date "+df.format(new Date(entity.getRunDate().getTime()))));
	    ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	Query q = this.manager.createNamedQuery("getByCmpnId");
	ejbLogger.debug(new StandardLogMessage("populate named query"));
	q.setParameter("cmpnId", companyId);
	
	ejbLogger.debug(new StandardLogMessage("getResultList"));
	List<TctCorrLstEntity> run = (List<TctCorrLstEntity>) q.getResultList();
	ejbLogger.debug(new StandardLogMessage("return"));
	return run;
	}
}
