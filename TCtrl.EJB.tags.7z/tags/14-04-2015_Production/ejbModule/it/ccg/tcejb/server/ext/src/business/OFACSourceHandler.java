package it.ccg.tcejb.server.ext.src.business;

import it.ccg.tcejb.server.bean.DownloadManagerLocal;
import it.ccg.tcejb.server.bean.eao.ofac.TctOfEntityEAO;
import it.ccg.tcejb.server.bean.entity.TctSrcUpDtEntity;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfAddrEntity;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfAddrEntityPK;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfAkaAliasEntity;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfAkaAliasEntityPK;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfBirthEntity;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfBirthEntityPK;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfCitzEntity;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfCitzEntityPK;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfDtBirEntity;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfDtBirEntityPK;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfEntitEntity;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfIdLstEntity;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfIdLstEntityPK;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfNatnEntity;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfNatnEntityPK;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfPrglEntity;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfPrglEntityPK;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfVsInfEntity;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfVsInfEntityPK;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.ext.source.xml.engine.XmlEngineOFAC;
import it.ccg.tcejb.server.ext.source.xml.ofac.Address;
import it.ccg.tcejb.server.ext.source.xml.ofac.Aka;
import it.ccg.tcejb.server.ext.source.xml.ofac.Citizenship;
import it.ccg.tcejb.server.ext.source.xml.ofac.DateOfBirthItem;
import it.ccg.tcejb.server.ext.source.xml.ofac.Id;
import it.ccg.tcejb.server.ext.source.xml.ofac.Nationality;
import it.ccg.tcejb.server.ext.source.xml.ofac.PlaceOfBirthItem;
import it.ccg.tcejb.server.ext.source.xml.ofac.SdnEntry;
import it.ccg.tcejb.server.ext.source.xml.ofac.SdnList;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardCheckPointMessage;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Future;

import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class OFACSourceHandler
 */
@Stateless
@Local(ExtSourceHandlerInterface.class)
@LocalBean
@ConcurrencyManagement(ConcurrencyManagementType.CONTAINER)
@TransactionManagement(TransactionManagementType.CONTAINER)
public class OFACSourceHandler implements ExtSourceHandlerInterface {

	private static final Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private SdnList ofacObj;
	
	/*@EJB
	private SessionManager sessionManager;*/
	@EJB
	private DownloadManagerLocal downLoadManager;
	@EJB
	private TctOfEntityEAO tctOfEntity;
	
    /**
     * Default constructor. 
     */
    public OFACSourceHandler() {
    	try {
			Context context = new InitialContext();
			this.downLoadManager = (DownloadManagerLocal) context.lookup("ejblocal:it.ccg.tcejb.server.bean.DownloadManagerLocal");
		} catch (NamingException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
		}
    }

	/**
     * @throws BackEndException 
	 * @see ExtSourceHandlerInterface#getDate()
     */
    @Asynchronous
    public Future<TctSrcUpDtEntity> getData(String user,int downloadID) throws BackEndException {
       ejbLogger.info(new StandardCheckPointMessage("Start OFAC getData "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
       ejbLogger.debug(new StandardLogMessage("OFAC thread "+Thread.currentThread().getName()));
       try {
		this.downloadSourceFile();
    			
		boolean isNew = this.checkIsNewList();
		TctSrcUpDtEntity srcUpd = null;
		if (isNew){
			this.storeListData(user);
			srcUpd = new TctSrcUpDtEntity();
			srcUpd.setSrcList("OFAC");
			srcUpd.setListDate(new SimpleDateFormat("MM/dd/yyyy").parse(this.ofacObj.getPublshInformation().getPublishDate()));
			srcUpd.setDownloadid(downloadID);
			srcUpd.setUpdDate(new Timestamp(new Date().getTime()));
			srcUpd.setUpdType("C");
			srcUpd.setUpdUser(user);
			//this.tctSrcUpDtEntityEAO.insertEntity(srcUpd);
		}else{ 
			ejbLogger.info(new StandardCheckPointMessage("Completed OFAC getData without new record "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
			return new AsyncResult<TctSrcUpDtEntity>(srcUpd);
		}
		return new AsyncResult<TctSrcUpDtEntity>(srcUpd);
       } catch (BackEndException e) {
    	   ejbLogger.info(new StandardCheckPointMessage("OFAC getData complited with error "+e.getMessage()));
    	   ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
		   throw e;
	   } catch (ParseException e) {
		   ejbLogger.info(new StandardCheckPointMessage("OFAC getData complited with error "+e.getMessage()));
    	   ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
		   throw new BackEndException(e);
	   } 
    }

	/**
     * @throws BackEndException 
	 * @see ExtSourceHandlerInterface#checkIsNewList()
     */
    /*
     * non gestisco l'eccezione perch� loggata all'interno del metodo
     */
    public boolean checkIsNewList() throws BackEndException {
    	ejbLogger.debug("in OFACSourceHandler.checkIsNewList");
    	try {
    		GregorianCalendar srcGCalendar = null;
    		Date srcLastDate = tctOfEntity.getLatestSrcListDate();
	    	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	    	
	    	if (srcLastDate !=null){
	    		srcGCalendar = new GregorianCalendar();
		    	srcGCalendar.setTime(srcLastDate);
	    	}else{
	    		return true;
	    	}
	    	GregorianCalendar listDate = new GregorianCalendar();
			listDate.setTime(formatter.parse(this.ofacObj.getPublshInformation().getPublishDate()));
			
			return listDate.after(srcGCalendar);
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }

	/**
     * @throws BackEndException 
	 * @see ExtSourceHandlerInterface#downloadSourceFile()
     */
    public void downloadSourceFile() throws BackEndException {
    	ejbLogger.debug("in OFACSourceHandler.downloadSourceFile");
        this.downLoadManager.downloadOFACList();
        XmlEngineOFAC xmlEngine = new XmlEngineOFAC();
        try {
        	ofacObj = xmlEngine.read(SystemProperties.getSystemProperty("ofac.file.name"));
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
        
    }

	@Override
	public void storeListData(String user) throws BackEndException {
		//TODO
		ejbLogger.debug("in OFACSourceHandler.storeListData");
		this.tctOfEntity.deleteEveryEntity();
		List<SdnEntry> entities = this.ofacObj.getSdnEntry();
		List<TctOfEntitEntity> ofEntities = new ArrayList<TctOfEntitEntity>();
		try {
			ejbLogger.debug(new StandardLogMessage("Entities"));
			Date insertDate = new Date();
			for(SdnEntry sdnEnt : entities){
				ejbLogger.debug(new StandardLogMessage("Entity "+sdnEnt.getUid()));
				TctOfEntitEntity ent = new TctOfEntitEntity();
				ent.setEntityId(sdnEnt.getUid());
				ent.setFirstName(sdnEnt.getFirstName()!=null? sdnEnt.getFirstName().trim().replaceAll("'", "''"):"");
				ent.setLastName(sdnEnt.getLastName()!=null?sdnEnt.getLastName().trim().replaceAll("'", "''"):"");
				ent.setRemarks(sdnEnt.getRemarks());
				ent.setSdnType(sdnEnt.getSdnType());
				ent.setTitle(sdnEnt.getTitle()!=null ?sdnEnt.getTitle().trim().replaceAll("'", "''"):"");
				ent.setSrcListDate(new SimpleDateFormat("MM/dd/yyyy").parse(this.ofacObj.getPublshInformation().getPublishDate()));
				
				ent.setUpdDate(new Timestamp(new Date().getTime()));
				if (sdnEnt.getProgramList()!=null && sdnEnt.getProgramList().getProgram().size()>0){
					ejbLogger.debug(new StandardLogMessage("pgrList"));
					Set<TctOfPrglEntity> pgrList = new HashSet<TctOfPrglEntity>();
					for (String pgmLst: sdnEnt.getProgramList().getProgram()){
						TctOfPrglEntity pgr = new TctOfPrglEntity();
						TctOfPrglEntityPK pk = new TctOfPrglEntityPK();
						pk.setEntityid(sdnEnt.getUid());
						pgr.setId(pk);
						pgr.setPrgValue(pgmLst);
						pgrList.add(pgr);
					}
					ent.setTctofprgls(pgrList);
				}else{
					ejbLogger.debug(new StandardLogMessage("no pgrList"));
				}
				if (sdnEnt.getAkaList()!=null && sdnEnt.getAkaList().getAka().size()>0){
					ejbLogger.debug(new StandardLogMessage("aka alias"));
					Set<TctOfAkaAliasEntity> akaLs = new HashSet<TctOfAkaAliasEntity>();
					for (Aka aka : sdnEnt.getAkaList().getAka()){
						ejbLogger.debug(new StandardLogMessage("aka alias " +aka.getUid()));
						TctOfAkaAliasEntity ofAka = new TctOfAkaAliasEntity();
						TctOfAkaAliasEntityPK pk = new TctOfAkaAliasEntityPK();
						pk.setAkaId(aka.getUid());
						pk.setEntityid(sdnEnt.getUid());
						
						ofAka.setId(pk);
						ofAka.setCategory(aka.getCategory()!=null?aka.getCategory().trim().replaceAll("'", "''"):"");
						ofAka.setFirstName(aka.getFirstName()!=null?aka.getFirstName().trim().replaceAll("'", "''"):"");
						ofAka.setLastName(aka.getLastName()!=null ?aka.getLastName().trim().replaceAll("'", "''"):"");
						ofAka.setType(aka.getType()!=null?aka.getType().trim().replaceAll("'", "''"):"");
						ofAka.setTctofentit(ent);
						akaLs.add(ofAka);
					}
					ent.setTctofakaals(akaLs);
				}else{
					ejbLogger.debug(new StandardLogMessage("no aka alias"));
				}
				
				if (sdnEnt.getIdList()!=null && sdnEnt.getIdList().getId().size()>0){
					ejbLogger.debug(new StandardLogMessage("id list"));
					Set<TctOfIdLstEntity> idsLists = new HashSet<TctOfIdLstEntity>();
					for (Id id :sdnEnt.getIdList().getId()){
						ejbLogger.debug(new StandardLogMessage("id list " +id.getUid()));
						TctOfIdLstEntity ids = new TctOfIdLstEntity();
						TctOfIdLstEntityPK pk = new TctOfIdLstEntityPK();
						pk.setIdLstId(id.getUid());
						pk.setEntityid(sdnEnt.getUid());
						
						ids.setId(pk);
						ids.setExpirDate(id.getExpirationDate()!=null ?id.getExpirationDate().trim().replaceAll("'", "''"):"");
						ids.setIdCountry(id.getIdCountry()!=null ?id.getIdCountry().trim().replaceAll("'", "''"):"");
						ids.setIdNumber(id.getIdNumber()!=null ?id.getIdNumber().trim().replaceAll("'", "''"):"");
						ids.setIdType(id.getIdType()!=null ?id.getIdType().trim().replaceAll("'", "''"):"");
						ids.setIssueDate(id.getIssueDate()!=null ?id.getIssueDate().trim().replaceAll("'", "''"):"");
						ids.setTctofentit(ent);
						
						idsLists.add(ids);
					}
					ent.setTctofidlsts(idsLists);
				}else{
					ejbLogger.debug(new StandardLogMessage("no id list"));
				}
				if (sdnEnt.getPlaceOfBirthList()!=null && sdnEnt.getPlaceOfBirthList().getPlaceOfBirthItem().size()>0){
					ejbLogger.debug(new StandardLogMessage("birth"));
					Set<TctOfBirthEntity> births = new HashSet<TctOfBirthEntity>();
					for(PlaceOfBirthItem pbi : sdnEnt.getPlaceOfBirthList().getPlaceOfBirthItem()){
						ejbLogger.debug(new StandardLogMessage("birth " +pbi.getUid()));
						TctOfBirthEntity birth = new TctOfBirthEntity();
						TctOfBirthEntityPK pk = new TctOfBirthEntityPK();
						pk.setPlcBirthId(pbi.getUid());
						pk.setEntityid(sdnEnt.getUid());
						
						birth.setId(pk);
						birth.setMainEntry(Boolean.toString(pbi.isMainEntry()));
						birth.setPlaceBirth(pbi.getPlaceOfBirth()!=null?pbi.getPlaceOfBirth().trim().replaceAll("'", "''"):"");
						birth.setTctofentit(ent);
						births.add(birth);
					}
					ent.setTctofbirths(births);
				}else{
					ejbLogger.debug(new StandardLogMessage("no birth"));
				}
				if (sdnEnt.getCitizenshipList()!=null && sdnEnt.getCitizenshipList().getCitizenship().size()>0){
					ejbLogger.debug(new StandardLogMessage("citizen"));
					Set<TctOfCitzEntity> citzs = new HashSet<TctOfCitzEntity>();
					for(Citizenship ctzs : sdnEnt.getCitizenshipList().getCitizenship()){
						ejbLogger.debug(new StandardLogMessage("citizen " +ctzs.getUid()));
						TctOfCitzEntity ctc = new TctOfCitzEntity();
						TctOfCitzEntityPK pk = new TctOfCitzEntityPK();
						pk.setCitizId(ctzs.getUid());
						pk.setEntityid(sdnEnt.getUid());
						ctc.setId(pk);
						
						ctc.setCountry(ctzs.getCountry()!=null?ctzs.getCountry().trim().replaceAll("'", "''"):"");
						ctc.setMainEntry(Boolean.toString(ctzs.isMainEntry()));
						ctc.setTctofentit(ent);
						citzs.add(ctc);
					}
					ent.setTctofcitzs(citzs);
				}else{
					ejbLogger.debug(new StandardLogMessage("no citizen"));
				}
				if (sdnEnt.getNationalityList()!=null && sdnEnt.getNationalityList().getNationality().size()>0){
					ejbLogger.debug(new StandardLogMessage("nationality"));
					Set<TctOfNatnEntity> nationalitys = new HashSet<TctOfNatnEntity>();
					for (Nationality natl : sdnEnt.getNationalityList().getNationality()){
						ejbLogger.debug(new StandardLogMessage("nationality "+natl.getUid()));
						TctOfNatnEntity nat = new TctOfNatnEntity();
						TctOfNatnEntityPK pk = new TctOfNatnEntityPK();
						pk.setNationId(natl.getUid());
						pk.setEntityid(sdnEnt.getUid());
						nat.setId(pk);
						nat.setCountry(natl.getCountry()!=null?natl.getCountry().trim().replaceAll("'", "''"):"");
						nat.setMainEntry(Boolean.toString(natl.isMainEntry()));
						nat.setTctofentit(ent);
						nationalitys.add(nat);
					}
					ent.setTctofnatns(nationalitys);
				}else{
					ejbLogger.debug(new StandardLogMessage("no nationality"));
				}
				if (sdnEnt.getDateOfBirthList()!=null && sdnEnt.getDateOfBirthList().getDateOfBirthItem().size()>0){
					ejbLogger.debug(new StandardLogMessage("date of birth"));
					Set<TctOfDtBirEntity> dtBirths = new HashSet<TctOfDtBirEntity>();
					for(DateOfBirthItem dtBirth: sdnEnt.getDateOfBirthList().getDateOfBirthItem()){
						ejbLogger.debug(new StandardLogMessage("date of birth "+dtBirth.getUid()));
						TctOfDtBirEntity dt = new TctOfDtBirEntity();
						TctOfDtBirEntityPK pk = new TctOfDtBirEntityPK();
						pk.setDtBrtId(dtBirth.getUid());
						pk.setEntityid(sdnEnt.getUid());
						dt.setId(pk);
						dt.setDateBirth(dtBirth.getDateOfBirth());
						dt.setMainEntry(Boolean.toString(dtBirth.isMainEntry()));
						dt.setTctofentit(ent);
						
						dtBirths.add(dt);
					}
					ent.setTctofdtbirs(dtBirths);
				}else{
					ejbLogger.debug(new StandardLogMessage("no date of birth"));
				}
				if (sdnEnt.getAddressList()!=null && sdnEnt.getAddressList().getAddress().size()>0){
					ejbLogger.debug(new StandardLogMessage("Address"));
					Set<TctOfAddrEntity> addrs = new HashSet<TctOfAddrEntity>();
					for(Address adr : sdnEnt.getAddressList().getAddress()){
						ejbLogger.debug(new StandardLogMessage("Address "+adr.getUid()));
						TctOfAddrEntity address = new TctOfAddrEntity();
						TctOfAddrEntityPK pk = new TctOfAddrEntityPK();
						pk.setAddrId(adr.getUid());
						pk.setEntityid(sdnEnt.getUid());
						
						address.setId(pk);
						address.setAddr1(adr.getAddress1()!=null?adr.getAddress1().trim().replaceAll("'", "''"):"");
						address.setAddr2(adr.getAddress2()!=null?adr.getAddress2().trim().replaceAll("'", "''"):"");
						address.setAddr3(adr.getAddress3()!=null?adr.getAddress3().trim().replaceAll("'", "''"):"");
						address.setCity(adr.getCity()!=null?adr.getCity().trim().replaceAll("'", "''"):"");
						address.setCountry(adr.getCountry()!=null?adr.getCountry().trim().replaceAll("'", "''"):"");
						address.setPosCode(adr.getPostalCode()!=null?adr.getPostalCode().trim().replaceAll("'", "''"):"");
						address.setTctofentit(ent);
						
						addrs.add(address);
					}
					ent.setTctofaddrs(addrs);
				}else{
					ejbLogger.debug(new StandardLogMessage("no address"));
				}
				if (sdnEnt.getVesselInfo() != null){
					ejbLogger.debug(new StandardLogMessage("vessel"));
					Set<TctOfVsInfEntity> vsss = new HashSet<TctOfVsInfEntity>();
					TctOfVsInfEntity vessel = new TctOfVsInfEntity();
					TctOfVsInfEntityPK pk = new TctOfVsInfEntityPK();
					pk.setEntityid(sdnEnt.getUid());
					vessel.setId(pk);
					vessel.setCallSign(sdnEnt.getVesselInfo().getCallSign()!=null?sdnEnt.getVesselInfo().getCallSign().trim().replaceAll("'", "''"):"");
					if (sdnEnt.getVesselInfo().getGrossRegisteredTonnage()!=null)
						vessel.setGregTonn(sdnEnt.getVesselInfo().getGrossRegisteredTonnage());
					
					if (sdnEnt.getVesselInfo().getTonnage()!=null)
						vessel.setTonnage(sdnEnt.getVesselInfo().getTonnage());
					
					vessel.setVesselFlag(sdnEnt.getVesselInfo().getVesselFlag()!=null?sdnEnt.getVesselInfo().getVesselFlag().trim().replaceAll("'", "''"):"");
					vessel.setVesselOwne(sdnEnt.getVesselInfo().getVesselOwner()!=null ? sdnEnt.getVesselInfo().getVesselOwner().trim().replaceAll("'", "''"):"");
					vessel.setVesselType(sdnEnt.getVesselInfo().getVesselType()!=null?sdnEnt.getVesselInfo().getVesselType().trim().replaceAll("'", ""):"''");
					vessel.setTctofentit(ent);
					vsss.add(vessel);
					ent.setTctofvsinfs(vsss);
				}else{
					ejbLogger.debug(new StandardLogMessage("no vessel"));
				}
				ent.setUpdDate(new Timestamp(insertDate.getTime()));
				ent.setUpdType("C");
				ent.setUpdUser(user);
				
				ofEntities.add(ent);
			}
			tctOfEntity.insertEntity(ofEntities);
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}

}
