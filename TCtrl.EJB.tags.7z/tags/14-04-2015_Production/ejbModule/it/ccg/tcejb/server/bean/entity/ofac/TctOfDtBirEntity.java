package it.ccg.tcejb.server.bean.entity.ofac;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTOFDTBIR database table.
 * 
 */
@Entity
@Table(name="TCTOFDTBIR")
@NamedQueries({
	@NamedQuery(name="deleteOfDtBirthEveryEntity", query="DELETE FROM TctOfDtBirEntity"),
	@NamedQuery(name="getOfDtBirthEntitiesById", query="SELECT entity FROM TctOfDtBirEntity entity WHERE entity.id.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctOfDtBirEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@EmbeddedId
	private TctOfDtBirEntityPK id;

	@Column(nullable=false, length=50)
	private String dateBirth;

	@Column(length=50)
	private String mainEntry;

	//bi-directional many-to-one association to TctOfEntitEntity
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	private TctOfEntitEntity tctofentit;

    public TctOfDtBirEntity() {
    }

	public TctOfDtBirEntityPK getId() {
		return this.id;
	}

	public void setId(TctOfDtBirEntityPK id) {
		this.id = id;
	}
	
	public String getDateBirth() {
		return this.dateBirth;
	}

	public void setDateBirth(String dateBirth) {
		if (dateBirth != null && dateBirth.length()>50){
			ejbLogger.debug(dateBirth+" >50 than truncate");
			this.dateBirth = dateBirth.substring(0, 49);
		}else{
			this.dateBirth = dateBirth;
		}
	}

	public String getMainEntry() {
		return this.mainEntry;
	}

	public void setMainEntry(String mainEntry) {
		if (mainEntry != null && mainEntry.length()>50){
			ejbLogger.debug(mainEntry+" >50 than truncate");
			this.mainEntry = mainEntry.substring(0, 49);
		}else{
			this.mainEntry = mainEntry;
		}
	}

	public TctOfEntitEntity getTctofentit() {
		return this.tctofentit;
	}

	public void setTctofentit(TctOfEntitEntity tctofentit) {
		this.tctofentit = tctofentit;
	}
	
}