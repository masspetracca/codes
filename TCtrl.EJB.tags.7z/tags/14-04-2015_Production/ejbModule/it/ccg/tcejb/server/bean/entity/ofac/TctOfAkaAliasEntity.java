package it.ccg.tcejb.server.bean.entity.ofac;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTOFAKAAL database table.
 * 
 */
@Entity
@Table(name="TCTOFAKAAL")
@NamedQueries({
	@NamedQuery(name="deleteOfAkaAliasEveryEntity", query="DELETE FROM TctOfAkaAliasEntity"),
	@NamedQuery(name="getOfAkaAliasEntitiesById", query="SELECT entity FROM TctOfAkaAliasEntity entity WHERE entity.id.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctOfAkaAliasEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	@EmbeddedId
	private TctOfAkaAliasEntityPK id;

	@Column(nullable=false, length=50)
	private String category;

	@Column(length=255)
	private String firstName;

	@Column(nullable=false, length=255)
	private String lastName;

	@Column(nullable=false, length=30)
	private String type;

	/*//bi-directional many-to-one association to TctAggrEntEntity
	@OneToMany(mappedBy="tctofakaal")
	private Set<TctAggrEntEntity> tctaggrents;
*/
	//bi-directional many-to-one association to TctOfEntitEntity
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	private TctOfEntitEntity tctofentit;

    public TctOfAkaAliasEntity() {
    }

	public TctOfAkaAliasEntityPK getId() {
		return this.id;
	}

	public void setId(TctOfAkaAliasEntityPK id) {
		this.id = id;
	}
	
	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		if (category != null && category.length()>50){
			ejbLogger.debug(category+" >50 than truncate");
			this.category = category.substring(0, 49);
		}else{
			this.category = category;
		}
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		if (firstName != null && firstName.length()>255){
			ejbLogger.debug(firstName+" >255 than truncate");
			this.firstName = firstName.substring(0, 254);
		}else{
			this.firstName = firstName;
		}
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		if (lastName != null && lastName.length()>255){
			ejbLogger.debug(lastName+" >255 than truncate");
			this.lastName = lastName.substring(0, 254);
		}else{
			this.lastName = lastName;
		}
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		if (type != null && type.length()>30){
			ejbLogger.debug(lastName+" >30 than truncate");
			this.type = type.substring(0, 29);
		}else{
			this.type = type;
		}
	}

	public TctOfEntitEntity getTctofentit() {
		return this.tctofentit;
	}

	public void setTctofentit(TctOfEntitEntity tctofentit) {
		this.tctofentit = tctofentit;
	}
	
}