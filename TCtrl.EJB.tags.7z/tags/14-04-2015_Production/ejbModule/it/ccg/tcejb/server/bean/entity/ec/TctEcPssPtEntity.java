package it.ccg.tcejb.server.bean.entity.ec;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;

import java.util.Date;


/**
 * The persistent class for the TCTECPSSPT database table.
 * 
 */
@Entity
@Table(name="TCTECPSSPT")
@NamedQueries({
	@NamedQuery(name="deleteEcPssPtEveryEntity", query="DELETE FROM TctEcPssPtEntity"),
	@NamedQuery(name="getEcPssPtEntitiesById", query="SELECT entity FROM TctEcPssPtEntity entity WHERE entity.id.entityid = :entityId ORDER BY entity.id.pssPrtId ASC")
})
public class TctEcPssPtEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@EmbeddedId
	private TctEcPssPtEntityPK id;

	@Column(length=50)
	private String country;

	@Column(length=100)
	private String legalBasis;

	@Column(length=200)
	private String number;

	@Column(length=2000)
	private String pdfLink;

    @Temporal( TemporalType.DATE)
	private Date regDate;

	//bi-directional many-to-one association to TctEcEntitEntity
    @ManyToOne(optional=true)
	@JoinColumn(name="ENTITYID", nullable=true, insertable=true, updatable=true)
	private TctEcEntitEntity tctecentit;

    public TctEcPssPtEntity() {
    }

	public TctEcPssPtEntityPK getId() {
		return this.id;
	}

	public void setId(TctEcPssPtEntityPK id) {
		this.id = id;
	}
	
	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		if (country != null && country.length()>50){
			ejbLogger.debug(country+" >50 than truncate");
			this.country = country.substring(0, 49);
		}else{
			this.country = country;
		}
	}

	public String getLegalBasis() {
		return this.legalBasis;
	}

	public void setLegalBasis(String legalBasis) {
		if (legalBasis != null && legalBasis.length()>100){
			ejbLogger.debug(legalBasis+" >100 than truncate");
			this.legalBasis = legalBasis.substring(0, 99);
		}else{
			this.legalBasis = legalBasis;
		}
	}

	public String getNumber() {
		return this.number;
	}

	public void setNumber(String number) {
		if (number != null && number.length()>200){
			ejbLogger.debug(number+" >200 than truncate");
			this.number = number.substring(0, 199);
		}else{
			this.number = number;
		}		
	}

	public String getPdfLink() {
		return this.pdfLink;
	}

	public void setPdfLink(String pdfLink) {
		if (pdfLink != null && pdfLink.length()>2000){
			ejbLogger.debug(pdfLink+" >2000 than truncate");
			this.pdfLink = pdfLink.substring(0, 1999);
		}else{
			this.pdfLink = pdfLink;
		}
		
	}

	public Date getRegDate() {
		return this.regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public TctEcEntitEntity getTctecentit() {
		return this.tctecentit;
	}

	public void setTctecentit(TctEcEntitEntity tctecentit) {
		this.tctecentit = tctecentit;
	}
	
}