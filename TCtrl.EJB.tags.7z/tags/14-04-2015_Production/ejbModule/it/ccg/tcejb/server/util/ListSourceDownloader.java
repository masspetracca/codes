package it.ccg.tcejb.server.util;

import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

public class ListSourceDownloader {
	public static final String UN="un";
	public static final String EC="ec";
	public static final String OFAC="ofac";
	private String UNFN="un.file.name";
	private String ECFN="ec.file.name";
	private String OFACFN="ofac.file.name";
	
	private Logger log = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	public void readFile(String webUrlProp,String fileNameProp){
		log.debug(new StandardLogMessage("in ListSourceDownloader.readFile(String webUrlProp,String fileNameProp)"));
		try{
			log.debug(new StandardLogMessage("file download start"));
			FileUtils.copyURLToFile(new URL(SystemProperties.getSystemProperty(webUrlProp)),new File(SystemProperties.getSystemProperty(fileNameProp)));
			log.debug(new StandardLogMessage("file download complete"));
		}catch(IOException ioE){
			ExceptionUtil.logCompleteStackTrace(log, ioE);
		} catch (BackEndException bEEx) {
			ExceptionUtil.logCompleteStackTrace(log, bEEx);
		}
	}
	
	public void readFile(Source source) throws MalformedURLException, IOException, BackEndException{
		log.debug(new StandardLogMessage("in ListSourceDownloader.readFile(String webUrlProp,String fileNameProp)"));
			switch (source) {
			case EC:
				log.debug(new StandardLogMessage("file download start"));
				log.debug(new StandardLogMessage("URL: "+SystemProperties.getSystemProperty(EC)));
				log.debug(new StandardLogMessage("File name: "+SystemProperties.getSystemProperty(this.ECFN)));
				FileUtils.copyURLToFile(new URL(SystemProperties.getSystemProperty(EC)),new File(SystemProperties.getSystemProperty(this.ECFN)));
				log.debug(new StandardLogMessage("file download complete"));
				break;
			case UN:
				log.debug(new StandardLogMessage("file download start"));
				log.debug("URL: "+SystemProperties.getSystemProperty(UN));
				log.debug("File name: "+SystemProperties.getSystemProperty(this.UNFN));
				FileUtils.copyURLToFile(new URL(SystemProperties.getSystemProperty(UN)),new File(SystemProperties.getSystemProperty(this.UNFN)));
				log.debug(new StandardLogMessage("file download complete"));
				break;
			case OFAC:
				log.debug(new StandardLogMessage("file download start"));
				log.debug(new StandardLogMessage("URL: "+SystemProperties.getSystemProperty(OFAC)));
				log.debug(new StandardLogMessage("File name: "+SystemProperties.getSystemProperty(this.OFACFN)));
				FileUtils.copyURLToFile(new URL(SystemProperties.getSystemProperty(OFAC)),new File(SystemProperties.getSystemProperty(this.OFACFN)));
				log.debug(new StandardLogMessage("file download complete"));
				break;
			}
	}
	
	public enum Source{
		UN, EC, OFAC
		
	}
}
