package it.ccg.tcejb.server.bean.entity.ofac;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTOFNATN database table.
 * 
 */
@Embeddable
public class TctOfNatnEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int nationId;

	@Column(unique=true, nullable=false)
	private int entityid;

    public TctOfNatnEntityPK() {
    }
	public int getNationId() {
		return this.nationId;
	}
	public void setNationId(int nationId) {
		this.nationId = nationId;
	}
	public int getEntityid() {
		return this.entityid;
	}
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctOfNatnEntityPK)) {
			return false;
		}
		TctOfNatnEntityPK castOther = (TctOfNatnEntityPK)other;
		return 
			(this.nationId == castOther.nationId)
			&& (this.entityid == castOther.entityid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.nationId;
		hash = hash * prime + this.entityid;
		
		return hash;
    }
}