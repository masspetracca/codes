package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTAGGRENT database table.
 * 
 */
@Embeddable
public class TctAggrEntEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false, length=20)
	private String aggregId;

	@Column(unique=true, nullable=false)
	private int downloadid;

    public TctAggrEntEntityPK() {
    }
	public String getAggregId() {
		return this.aggregId;
	}
	public void setAggregId(String aggregId) {
		this.aggregId = aggregId;
	}
	public int getDownloadid() {
		return this.downloadid;
	}
	public void setDownloadid(int downloadid) {
		this.downloadid = downloadid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctAggrEntEntityPK)) {
			return false;
		}
		TctAggrEntEntityPK castOther = (TctAggrEntEntityPK)other;
		return 
			this.aggregId.equals(castOther.aggregId)
			&& (this.downloadid == castOther.downloadid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.aggregId.hashCode();
		hash = hash * prime + this.downloadid;
		
		return hash;
    }
}