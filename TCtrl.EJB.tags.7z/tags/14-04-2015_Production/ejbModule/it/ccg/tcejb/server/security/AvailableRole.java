package it.ccg.tcejb.server.security;

public class AvailableRole {
	
	public static final String ADMIN = "admin";
	public static final String USER = "user";
	public static final String VISITOR = "visitor";

}
