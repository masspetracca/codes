package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TCTDOWNREG database table.
 * 
 */
@Entity
@Table(name="TCTDOWNREG")
@NamedQueries({
	/*
	 * raffale de lauri
	 * TN_CCG15333
	 * select only download without status E (DOWNLAOD EMPTY) 
	 */
	@NamedQuery(name="getDonwLatestIDByDdt",   query="SELECT entity.downlaodId " +
            "								          FROM TctDownRegEntity entity " +
            "								         WHERE entity.downloadDt = :ddt" +
            "										   AND entity.status IS NULL"),
	@NamedQuery(name="getDonwLatestID",   query="SELECT entity " +
            "								       FROM TctDownRegEntity entity " +
            "								      WHERE entity.downloadDt = (SELECT MAX(entity2.downloadDt)" +
            "										    					   FROM TctDownRegEntity entity2" +
            "																  WHERE entity2.status IS NULL)")
	
})
public class TctDownRegEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="DOWNLAODID")
	private int downlaodId;

	@Column(nullable=false)
	private Timestamp downloadDt;

	@Column(length=255)
	private String note;

	@Column(length=1)
	private String status;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=55)
	private String updUser;

	//bi-directional many-to-one association to TctAggrEntEntity
	@OneToMany(mappedBy="tctdownreg")
	private Set<TctAggrEntEntity> tctaggrents;

	//bi-directional many-to-one association to TctDownRunEntity
	@OneToMany(mappedBy="tctdownreg")
	private Set<TctDownRunEntity> tctdownruns;

	//bi-directional one-to-one association to TctSrcFlHEntity
	@OneToOne(mappedBy="tctdownreg")
	private TctSrcFlHEntity tctsrcflh;

    public TctDownRegEntity() {
    }

	public int getDownlaodId() {
		return this.downlaodId;
	}

	public void setDownlaodId(int downlaodId) {
		this.downlaodId = downlaodId;
	}

	public Timestamp getDownloadDt() {
		return this.downloadDt;
	}

	public void setDownloadDt(Timestamp downloadDt) {
		this.downloadDt = downloadDt;
	}

	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public Set<TctAggrEntEntity> getTctaggrents() {
		return this.tctaggrents;
	}

	public void setTctaggrents(Set<TctAggrEntEntity> tctaggrents) {
		this.tctaggrents = tctaggrents;
	}
	
	public Set<TctDownRunEntity> getTctdownruns() {
		return this.tctdownruns;
	}

	public void setTctdownruns(Set<TctDownRunEntity> tctdownruns) {
		this.tctdownruns = tctdownruns;
	}
	
	public TctSrcFlHEntity getTctsrcflh() {
		return this.tctsrcflh;
	}

	public void setTctsrcflh(TctSrcFlHEntity tctsrcflh) {
		this.tctsrcflh = tctsrcflh;
	}
	
}