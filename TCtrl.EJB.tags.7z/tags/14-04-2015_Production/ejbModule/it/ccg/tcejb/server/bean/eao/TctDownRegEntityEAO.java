package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctDownRegEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctDownRegEntityEAO
 */
@Stateless
@LocalBean
public class TctDownRegEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctDownRegEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertDownload(TctDownRegEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctDownReg entity)"));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public int retrieveLatestIDByDownloadDate(TctDownRegEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in int retrieveLatestID(TctDownReg entity)"));
	    	ejbLogger.debug(new StandardLogMessage("Downloaddate "+df.format(new Date(entity.getDownloadDt().getTime()))));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getDonwLatestIDByDdt");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("ddt", entity.getDownloadDt());
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	int id = (Integer) q.getSingleResult();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return id;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
 
    public TctDownRegEntity retrieveLatestDownloadID() throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in TctDownReg retrieveLatestDownloadID()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getDonwLatestID");
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	TctDownRegEntity toReturn = (TctDownRegEntity) q.getSingleResult();
	    	ejbLogger.debug("retrieved id: "+toReturn.getDownlaodId());
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return toReturn;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
}
