package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TCTRUNREG database table.
 * 
 */
@Entity
@Table(name="TCTRUNREG")
@NamedQueries({
	@NamedQuery(name="getRunLatestIDByRdt",   query="SELECT entity " +
            "								          FROM TctRunRegEntity entity " +
            "								         WHERE entity.runDate = :rdt"),
	@NamedQuery(name="getPrevRun",   		  query="SELECT entity " +
			"										   FROM TctRunRegEntity entity " +
			"										  WHERE entity.runDate = (SELECT MAX(entity2.runDate)" +
			"										                        	FROM TctRunRegEntity entity2" +
			"										                           WHERE entity.cmpnid = entity2.cmpnid" +
			"										                           and entity2.runId <> :run)" +
			"										    AND entity.cmpnid = :cmpn"),
			@NamedQuery(name="getByRunIdRunReg",   query="SELECT entity " +
                    "								FROM TctRunRegEntity entity " +
                    "								WHERE entity.runId  = :runId " +
                    "								AND entity.cmpnid  = :cmpnId")  
	
})
public class TctRunRegEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="RUNID")
	private int runId;

	@Column(nullable=false)
	private int cmpnid;

	@Column(length=255)
	private String note;

	@Column(nullable=false, length=1)
	private String report;
	
	@Column(nullable=false, length=1)
	private String approved;

	@Column(nullable=false, length=1)
	private String matchFound;
	
	@Column(nullable=false)
	private Timestamp runDate;

	private Timestamp subDate;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=55)
	private String updUser;
	
	@Column(length=55)
	private String submitter;
	
	@Column(length=55)
	private String approver;

	//bi-directional many-to-one association to TctClientHEntity
	@OneToMany(mappedBy="tctrunreg")
	private Set<TctClientHEntity> tctclienths;

	//bi-directional many-to-one association to TctCorrispEntity
	@OneToMany(mappedBy="tctrunreg")
	private Set<TctCorrispEntity> tctcorrisps;

	//bi-directional many-to-one association to TctDownRunEntity
	@OneToMany(mappedBy="tctrunreg")
	private Set<TctDownRunEntity> tctdownruns;

	/*//bi-directional many-to-one association to TctFalNegHEntity
	@OneToMany(mappedBy="tctrunreg1")
	private Set<TctFalNegHEntity> tctfalneghs1;*/

	//bi-directional many-to-one association to TctFalNegHEntity
	//@OneToMany(mappedBy="tctrunreg")
	@Transient
	private Set<TctFalNegHEntity> tctfalneghs;

	//bi-directional many-to-one association to TctCompanyEntity
    @ManyToOne
	@JoinColumn(name="CMPNID", nullable=false, insertable=false, updatable=false)
	private TctCompanyEntity tctcompany;

	//bi-directional one-to-one association to TctClnSrcHEntity
	@OneToOne(mappedBy="tctrunreg")
	private TctClnSrcHEntity tctclnsrch;

    public TctRunRegEntity() {
    }
	
	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getReport() {
		return this.report;
	}

	public void setReport(String report) {
		this.report = report;
	}
	
	public String getApproved() {
		return approved;
	}

	public void setApproved(String approved) {
		this.approved = approved;
	}

	public Timestamp getRunDate() {
		return this.runDate;
	}

	public void setRunDate(Timestamp runDate) {
		this.runDate = runDate;
	}

	public Timestamp getSubDate() {
		return this.subDate;
	}

	public void setSubDate(Timestamp subDate) {
		this.subDate = subDate;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public String getSubmitter() {
		return submitter;
	}

	public void setSubmitter(String submitter) {
		this.submitter = submitter;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public Set<TctClientHEntity> getTctclienths() {
		return this.tctclienths;
	}

	public void setTctclienths(Set<TctClientHEntity> tctclienths) {
		this.tctclienths = tctclienths;
	}
	
	public Set<TctCorrispEntity> getTctcorrisps() {
		return this.tctcorrisps;
	}

	public void setTctcorrisps(Set<TctCorrispEntity> tctcorrisps) {
		this.tctcorrisps = tctcorrisps;
	}
	
	public Set<TctDownRunEntity> getTctdownruns() {
		return this.tctdownruns;
	}

	public void setTctdownruns(Set<TctDownRunEntity> tctdownruns) {
		this.tctdownruns = tctdownruns;
	}
	
/*	public Set<TctFalNegHEntity> getTctfalneghs1() {
		return this.tctfalneghs1;
	}

	public void setTctfalneghs1(Set<TctFalNegHEntity> tctfalneghs1) {
		this.tctfalneghs1 = tctfalneghs1;
	}*/
	
	public Set<TctFalNegHEntity> getTctfalneghs() {
		return this.tctfalneghs;
	}

	public void setTctfalneghs(Set<TctFalNegHEntity> tctfalneghs) {
		this.tctfalneghs = tctfalneghs;
	}
	
	public TctCompanyEntity getTctcompany() {
		return this.tctcompany;
	}

	public void setTctcompany(TctCompanyEntity tctcompany) {
		this.tctcompany = tctcompany;
	}
	
	public TctClnSrcHEntity getTctclnsrch() {
		return this.tctclnsrch;
	}

	public void setTctclnsrch(TctClnSrcHEntity tctclnsrch) {
		this.tctclnsrch = tctclnsrch;
	}

	/**
	 * @return the runId
	 */
	public int getRunId() {
		return runId;
	}

	/**
	 * @param runId the runId to set
	 */
	public void setRunId(int runId) {
		this.runId = runId;
	}

	/**
	 * @return the cmpnid
	 */
	public int getCmpnid() {
		return cmpnid;
	}

	/**
	 * @param cmpnid the cmpnid to set
	 */
	public void setCmpnid(int cmpnid) {
		this.cmpnid = cmpnid;
	}

	/**
	 * @return the matchFound
	 */
	public String getMatchFound() {
		return matchFound;
	}

	/**
	 * @param matchFound the matchFound to set
	 */
	public void setMatchFound(String matchFound) {
		this.matchFound = matchFound;
	}
	
}