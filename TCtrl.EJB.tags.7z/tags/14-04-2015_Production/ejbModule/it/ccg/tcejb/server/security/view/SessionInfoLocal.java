package it.ccg.tcejb.server.security.view;


import it.ccg.tcejb.server.security.SessionUser;

import java.util.List;

public interface SessionInfoLocal {
	
	public void addLoggedUser(String userName) throws Exception;
	public void removeLoggedUser(String userName) throws Exception;
	
	public String getCurrentUser() throws Exception;
	public List<String> getCurrentUserRoles() throws Exception;
	
	public List<SessionUser> listLoggedUsers() throws Exception;
	
}
