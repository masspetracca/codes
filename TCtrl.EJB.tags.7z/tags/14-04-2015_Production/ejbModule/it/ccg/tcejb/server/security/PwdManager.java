package it.ccg.tcejb.server.security;

import it.ccg.tcejb.server.security.view.PwdManagerLocal;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.Properties;

import javax.ejb.Stateless;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.OperationNotSupportedException;
import javax.naming.directory.Attribute;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.log4j.Logger;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
import javax.ejb.Local;
import javax.ejb.LocalBean;

/**
 * Session Bean implementation class PwdManager
 */
@Stateless
@Local(PwdManagerLocal.class)
@LocalBean
public class PwdManager implements PwdManagerLocal {
	
	private Properties env;
	private static final String[] returnedAttributes = { "cn", "sn", "uid", "userPassword" };
	private static final String USER_INSTALL_ROOT = "user.install.root";
	private static final String INSTALL_DIR = System.getProperty(USER_INSTALL_ROOT);
	private static final String PROPERTIES_DIRECTORY_NAME = "properties";
	private static final String PROPERTIES_FILE_NAME = "pamp.properties";
	private static final String PATH_SEPARATOR = System.getProperty("file.separator");
	private static final String PROPERTIES_FILE_RELATIVE_PATH = PATH_SEPARATOR + PROPERTIES_DIRECTORY_NAME + PATH_SEPARATOR + PROPERTIES_FILE_NAME;
	private static final String PROPERTIES_FILE_ABSOLUTE_PATH = INSTALL_DIR + PROPERTIES_FILE_RELATIVE_PATH;
	
	private static String SEARCH_BASE;
	
	private static final String FILTER_PREFIX = "(&(objectClass=inetOrgPerson)(sn=";
	private static final String FILTER_SUFFIX = "))";
	private static final String PASSWORD_ATTRIBUTE_ID = "userPassword";
	private static final String USER_NOT_FOUND = "USER NOT FOUND.";
	private static final String OLD_PWD_NOT_ACCEPTED = "OLD PASSWORD NOT APPROVED.";
	private static final String ACCOUNT_LOCKED = "TOO MANY ERRORS: ACCOUNT LOCKED. TRY AGAIN IN TWO MINUTES.";
	private static final String LDAP_CONNECTION_PROBLEMS = "PROBLEMS CONNECTING TO THE LDAP SERVER, PLEASE CONTACT THE SERVER ADMINISTRATOR.";
	private static final String BAD_PASSWORD = "xxX�$%&89WASQ";
	
	Logger userLog = Logger.getLogger(this.getClass().getName());

	/**
	 * Default constructor.
	 */
	public PwdManager() {
		
	}

	/**
	 * Intercetto l'eccezione di connessione LDAP, altrimenti invierebbe al
	 * client l'IP del server.
	 * 
	 * @return DirContext
	 * @throws Exception
	 */
	private DirContext openLDAPConnection() throws Exception {
		DirContext ctx = null;
		try {
			env = loadPropertiesFile();
			ctx = new InitialDirContext(env);
		} catch (NamingException ce) {
			throw new Exception(LDAP_CONNECTION_PROBLEMS);
		} catch (Exception e) {
			throw e;
		}
		return ctx;
	}
	
	private void openWrongLDAPConnection(String userName) throws Exception {
		userLog.info("************* openWrongLDAPConnection(" + userName + ")************************");
		DirContext context = null;
		try {
			userLog.info("********************** openWrongLDAPConnection() = blocco try **************************");
			Properties props = new Properties();
			props.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			props.put(Context.PROVIDER_URL, "ldap://ccgsvr01.ccgnet.it:389");
			props.put(Context.SECURITY_PRINCIPAL, "sn=" + userName);
			props.put(Context.SECURITY_CREDENTIALS, BAD_PASSWORD);
			context = new InitialDirContext(props);
			context.close();
		} finally {
			if (context != null) {
				context.close();
			}
		}
		userLog.info("********************** FINE openWrongLDAPConnection() **************************");
	}

	private Properties loadPropertiesFile() throws Exception {
		Properties props = null;
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(new File(PROPERTIES_FILE_ABSOLUTE_PATH));
			props = new Properties();
			props.load(fis);
			String encodedPassword =  props.getProperty(Context.SECURITY_CREDENTIALS);
			props.setProperty(Context.SECURITY_CREDENTIALS, decode(encodedPassword));
			fis.close();
		} catch (Exception e) {
			throw e;
		} finally {
			if (fis != null) {
				fis.close();
			}
		}
		return props;
	}

	/**
	 * Mi aspetto che: 
	 * - (user && oldPassword && newPassword) != null 
	 * - (user && oldPassword && newPassword) != "" 
	 * - oldPassword != newPassword
	 */
	public boolean changeUserPassword(String user, String oldPassword, String newPassword) throws Exception {
		boolean passwordChanged = false;
		DirContext ctx = null;
		String ldapUserToBeChanged = null;
		try {
			ctx = openLDAPConnection();
			ldapUserToBeChanged = findAndVerifyLDAPUser(ctx, user, oldPassword);
			passwordChanged = changePassword(ctx, ldapUserToBeChanged, newPassword);
			ctx.close();
		} catch (Exception e) {
			throw e;
		}
		return passwordChanged;
	}

	private boolean changePassword(DirContext context, String ldapUser, String newPassword) throws Exception {
		boolean success = false;
		try {
			Attribute attr = new BasicAttribute(PASSWORD_ATTRIBUTE_ID, newPassword);
			ModificationItem item = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, attr);
			context.modifyAttributes(ldapUser, new ModificationItem[] { item });
			success = true;
		} catch (NamingException e) {
			throw e;
		}
		return success;
	}

	private String findAndVerifyLDAPUser(DirContext context, String user, String oldPasswordFromClient) throws Exception {
		
		String userToChange = null;
		DirContext clonedCtx = null;
		
		try {
			
			if(SEARCH_BASE == null) {
					
				Properties prop = new Properties();
				prop.load(new FileReader(new File(System.getProperty("user.install.root") + "/properties/pamp.properties")));
				
				String o = prop.getProperty("ldap.o");
				String c = prop.getProperty("ldap.c");
				
				SEARCH_BASE = "o=" + o + ",c=" + c;
				
			}
			
			SearchControls ctls = new SearchControls();
			ctls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			ctls.setReturningAttributes(returnedAttributes);
			String filter = FILTER_PREFIX + user + FILTER_SUFFIX;
			NamingEnumeration<SearchResult> answer = context.search(SEARCH_BASE, filter, ctls);
			/**
			 * Attenzione: ipotizzo che NON ESISTANO DUE UTENTI CON LO STESSO
			 * userName, e che quindi la ricerca mi restituisca SEMPRE E SOLO un
			 * utente.
			 */
			if (answer.hasMoreElements()) {
				while (answer.hasMoreElements()) {
					SearchResult a = answer.nextElement();
					userToChange = a.getName() + "," + SEARCH_BASE;
					/**
					 * Apro una nuova connessione LDAP per verificare la vecchia
					 * password. Se lancia una eccezione, la vecchia password �
					 * sbagliata
					 */
					Properties clonedEnv = (Properties) context.getEnvironment().clone();
					clonedEnv.put(Context.SECURITY_PRINCIPAL, userToChange);
					clonedEnv.put(Context.SECURITY_CREDENTIALS, oldPasswordFromClient);
					clonedCtx = new InitialDirContext(clonedEnv);
					/**
					 * Chiudo subito, mi serve solo per verifica
					 */
					clonedCtx.close();
				}
			} else
				throw new Exception(USER_NOT_FOUND);
		} catch (OperationNotSupportedException one) {
			
			//one.printStackTrace();
			
			throw new Exception(ACCOUNT_LOCKED);
		} catch (NamingException ne) {
			
			//ne.printStackTrace();
			
			throw new Exception(OLD_PWD_NOT_ACCEPTED);
		} catch (Exception e) {
			
			//e.printStackTrace();
			
			throw e;
		}
		
		return userToChange;
	}
	
	// FUNZIONE PER ENCODE DI UNA STRINGA
	public String encode(String stringToEncode){
		String returnValue = "";
		BASE64Encoder encoder = new BASE64Encoder();
		try{
			returnValue = encoder.encode(stringToEncode.getBytes());;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return returnValue;
	}
	
	// FUNZIONE PER DECODE DI UNA STRINGA
	public String decode(String stringToDecode){
		String returnValue = "";
		BASE64Decoder decoder = new BASE64Decoder();
		try {
			String decodedString = new String(decoder.decodeBuffer(stringToDecode));
			returnValue = decodedString;	
		} catch (Exception e) {
			e.printStackTrace();
		}
		return returnValue;
	}
	
	public boolean disableUserAccount(String user) throws Exception {
		userLog.info("********************** disableUserAccount(" + user + ") **************************");
		//System.out.println("********************** disableUserAccount(" + user + ") **************************");
		boolean disabled = false;
		for (int i = 0; i < 10; i++) {
			try {
				userLog.info("********************** disableUserAccount(), ciclo for, i=" + i + " **************************");
				//System.out.println("********************** disableUserAccount(), ciclo for, i=" + i + " **************************");
				openWrongLDAPConnection(user);
			} catch (OperationNotSupportedException one) {
				one.printStackTrace();
				// account locked
				userLog.info("*** OperationNotSupportedException = " + one.getMessage());
				disabled = true;
				return disabled;
			} catch (NamingException ne) {
				// password errata: ignoro l'eccezione
				ne.printStackTrace();
				userLog.info("*** NamingException = " + ne.getMessage());
			}
		}
		//System.out.println("********************** FINE disableUserAccount() **************************");
		userLog.info("********************** FINE disableUserAccount() **************************");
		return disabled;
	}
}
