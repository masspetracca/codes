package it.ccg.tcejb.server.bean.entity.un;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTUNALIAS database table.
 * 
 */
@Entity
@Table(name="TCTUNALIAS")
@NamedQueries({
	@NamedQuery(name="deleteUnAlaisEveryEntity", query="DELETE FROM TctUnAlia"),
	@NamedQuery(name="getUnAliasEntitiesById", query="SELECT entity FROM TctUnAlia entity WHERE entity.entityid = :entityId ORDER BY entity.addressId ASC")
})
public class TctUnAlia implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	/*@EmbeddedId
	private TctUnAliaPK id;*/
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ALAISID")
	private int alaisId;

	@Column(nullable=false)
	private int entityid;

	@Column(nullable=false, length=200)
	private String aliasName;

	@Column(length=30)
	private String quality;

	//bi-directional many-to-one association to TctUnEntit
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	//@Transient
	private TctUnEntit tctunentit;

	//bi-directional many-to-one association to TctUnIndiv
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	//@Transient
	private TctUnIndiv tctunindiv;

    public TctUnAlia() {
    }
	
	public String getAliasName() {
		return this.aliasName;
	}

	public void setAliasName(String aliasName) {
		aliasName=aliasName.replaceAll("'", "''");
		aliasName=aliasName.replaceAll("�", "''");
		if (aliasName.length()>200){
			this.aliasName = aliasName.substring(0,199);
		}else{
			this.aliasName = aliasName;
		}
	}

	public String getQuality() {
		return this.quality;
	}

	public void setQuality(String quality) {
		if (quality != null && quality.length()>30){
			ejbLogger.debug(quality+" >30 than truncate");
			this.quality = quality.substring(0, 29);
		}else{
			this.quality = quality;
		}
	}

	public TctUnEntit getTctunentit() {
		return this.tctunentit;
	}

	public void setTctunentit(TctUnEntit tctunentit) {
		this.tctunentit = tctunentit;
	}
	
	public TctUnIndiv getTctunindiv() {
		return this.tctunindiv;
	}

	public void setTctunindiv(TctUnIndiv tctunindiv) {
		this.tctunindiv = tctunindiv;
	}

	/**
	 * @return the alaisId
	 */
	public int getAlaisId() {
		return alaisId;
	}

	/**
	 * @param alaisId the alaisId to set
	 */
	public void setAlaisId(int alaisId) {
		this.alaisId = alaisId;
	}

	/**
	 * @return the entityid
	 */
	public int getEntityid() {
		return entityid;
	}

	/**
	 * @param entityid the entityid to set
	 */
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}
	
}