package it.ccg.tcejb.server.ext.src.business;

import it.ccg.tcejb.server.bean.DownloadManagerLocal;
import it.ccg.tcejb.server.bean.eao.un.TctUnEntityEAO;
import it.ccg.tcejb.server.bean.eao.un.TctUnIndivEntityEAO;
import it.ccg.tcejb.server.bean.entity.TctSrcUpDtEntity;
import it.ccg.tcejb.server.bean.entity.un.TctUnAddr;
import it.ccg.tcejb.server.bean.entity.un.TctUnAlia;
import it.ccg.tcejb.server.bean.entity.un.TctUnBrtDt;
import it.ccg.tcejb.server.bean.entity.un.TctUnBtPlc;
import it.ccg.tcejb.server.bean.entity.un.TctUnEntit;
import it.ccg.tcejb.server.bean.entity.un.TctUnInDoc;
import it.ccg.tcejb.server.bean.entity.un.TctUnIndiv;
import it.ccg.tcejb.server.bean.entity.un.TctUnLstUp;
import it.ccg.tcejb.server.bean.entity.un.TctUnNat;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.ext.source.xml.engine.XmlEngineONU;
import it.ccg.tcejb.server.ext.source.xml.un.ConsolidatedList;
import it.ccg.tcejb.server.ext.source.xml.un.Entity;
import it.ccg.tcejb.server.ext.source.xml.un.EntityAddress;
import it.ccg.tcejb.server.ext.source.xml.un.EntityAlias;
import it.ccg.tcejb.server.ext.source.xml.un.Individual;
import it.ccg.tcejb.server.ext.source.xml.un.IndividualAddress;
import it.ccg.tcejb.server.ext.source.xml.un.IndividualAlias;
import it.ccg.tcejb.server.ext.source.xml.un.IndividualDateOfBirth;
import it.ccg.tcejb.server.ext.source.xml.un.IndividualDocument;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardCheckPointMessage;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Future;

import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.bind.JAXBException;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class UNSourceHandler
 */
@Stateless
@Local(ExtSourceHandlerInterface.class)
@LocalBean
@ConcurrencyManagement(ConcurrencyManagementType.CONTAINER)
@TransactionManagement(TransactionManagementType.CONTAINER)
public class UNSourceHandler implements ExtSourceHandlerInterface {
	private static final Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	/*@EJB
	private SessionManager sessionManager;*/
	@EJB
	private DownloadManagerLocal downLoadManager;
	@EJB
	private TctUnEntityEAO tctUnEntity;
	@EJB
	private TctUnIndivEntityEAO tctUnIndividualEAO;

	private ConsolidatedList unObj;
    /**
     * Default constructor. 
     */
    public UNSourceHandler() {
    	try {
			Context context = new InitialContext();
			this.downLoadManager = (DownloadManagerLocal) context.lookup("ejblocal:it.ccg.tcejb.server.bean.DownloadManagerLocal");
		} catch (NamingException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
		}
    }

	/**
     * @see ExtSourceHandlerInterface#getDate()
     */
    @Asynchronous
    public Future<TctSrcUpDtEntity> getData(String user,int downloadID) throws BackEndException {
    	ejbLogger.info(new StandardCheckPointMessage("Start UN getData "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
		ejbLogger.debug(new StandardLogMessage("UN thread "+Thread.currentThread().getName()));
	       try {
			this.downloadSourceFile();
			
			boolean isNew = this.checkIsNewList();
			TctSrcUpDtEntity srcUpd = null;
			if (isNew){
				this.storeListData(user);
				srcUpd = new TctSrcUpDtEntity();
				srcUpd.setSrcList("UN");
				srcUpd.setListDate(unObj.getDateGenerated().toGregorianCalendar().getTime());
				srcUpd.setDownloadid(downloadID);
				srcUpd.setUpdDate(new Timestamp(new Date().getTime()));
				srcUpd.setUpdType("C");
				srcUpd.setUpdUser(user);
			}else{ 
				ejbLogger.info(new StandardCheckPointMessage("Completed UN getData without new record "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
				return new AsyncResult<TctSrcUpDtEntity>(srcUpd);
			}
			ejbLogger.info(new StandardCheckPointMessage("Completed UN getData "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
			return new AsyncResult<TctSrcUpDtEntity>(srcUpd);
	       } catch (BackEndException e) {
	    	   ejbLogger.info(new StandardCheckPointMessage("UN getData complited with error "+e.getMessage()));
	    	   ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			   throw new BackEndException(e);
		   }
    }

	/**
     * @throws BackEndException 
	 * @see ExtSourceHandlerInterface#checkIsNewList()
     */
    @SuppressWarnings("unused")
	public boolean checkIsNewList() throws BackEndException {
    	ejbLogger.debug("in UNSourceHandler.checkIsNewList()");
    	try {
	    	GregorianCalendar srcGCalendar = null;
			/*
			 * raffaele de lauri
			 * TN_CCG15298
			 */
			Date srcLastDate = tctUnEntity.getLatestSrcListDate();
	    	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	    	
	    	if (srcLastDate !=null){
	    		srcGCalendar = new GregorianCalendar();
		    	srcGCalendar.setTime(srcLastDate);
	    	}else{
	    		return true;
	    	}
	    	GregorianCalendar listDate = new GregorianCalendar();
	    	
			listDate.setTime(formatter.parse(formatter.format(this.unObj.getDateGenerated().toGregorianCalendar().getTime())));
			
			return listDate.after(srcGCalendar);
			
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
		
    }

	/**
     * @throws BackEndException 
	 * @see ExtSourceHandlerInterface#downloadSourceFile()
     */
    public void downloadSourceFile() throws BackEndException {
    	ejbLogger.debug("in UNSourceHandler.downloadSourceFile()");
    	this.downLoadManager.downloadUNList();
		XmlEngineONU xmlEngine = new XmlEngineONU();
		try {
			unObj = xmlEngine.read(SystemProperties.getSystemProperty("un.file.name"));
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }

	@Override
	public void storeListData(String user) throws BackEndException {
		ejbLogger.debug(new StandardLogMessage("in UNSourceHandler.storeListData()"));
		this.tctUnEntity.deleteEveryEntity();
		List<TctUnEntit> ents = new ArrayList<TctUnEntit>(); 
		List<TctUnIndiv> inds = new ArrayList<TctUnIndiv>(); 
		Date insertDate = new Date();

		for (Entity unEn : unObj.getENTITIES().getENTITY()){
			ejbLogger.debug(new StandardLogMessage("Entity "+unEn.getDATAID()));
			TctUnEntit ent = new TctUnEntit();
			ent.setDataId(unEn.getDATAID());
			if (unEn.getCOMMENTS1()!=null) ent.setComments1(unEn.getCOMMENTS1().trim());
			ent.setDateGenerated(unObj.getDateGenerated().toGregorianCalendar().getTime());
			if (unEn.getFIRSTNAME()!=null) ent.setFirstName(unEn.getFIRSTNAME().trim());
			if (unEn.getNAMEORIGINALSCRIPT()!=null) ent.setnOrgScript(unEn.getNAMEORIGINALSCRIPT().trim());
			ent.setListedOn(new Timestamp(unEn.getLISTEDON().toGregorianCalendar().getTimeInMillis()));
			ent.setUnListTp(unEn.getLISTTYPE().getVALUE());
			ent.setRefNumber(unEn.getREFERENCENUMBER());
			ent.setReleasedDt(unObj.getDateGenerated().toGregorianCalendar().getTime());
			ent.setSortKey(unEn.getSORTKEY());
			if (unEn.getSORTKEYLASTMOD()!=null) ent.setSortKeyLsMod(new Timestamp(unEn.getSORTKEYLASTMOD().toGregorianCalendar().getTimeInMillis()));
			ent.setUpdDate(new Timestamp(insertDate.getTime()));
			ent.setUpdType("C");
			ent.setUpdUser(user);
			
			if (unEn.getENTITYADDRESS() !=null && unEn.getENTITYADDRESS().size()>0){
				ejbLogger.debug(new StandardLogMessage("Address for entity "+ unEn.getDATAID()));
				Set<TctUnAddr> addrs = new HashSet<TctUnAddr>();
				for (EntityAddress addr: unEn.getENTITYADDRESS()){
					/*
					 * raffaele de lauri
					 * TN_CCG15247
					 */
					if ((addr.getNOTE()!=null && !addr.getNOTE().equalsIgnoreCase("")) || 
							(addr.getSTREET()!=null && !addr.getSTREET().equalsIgnoreCase("")) || 
							(addr.getCITY()!=null && !addr.getCITY().equalsIgnoreCase("")) || 
							(addr.getSTATEPROVINCE()!=null && !addr.getSTATEPROVINCE().equalsIgnoreCase("")) || 
							(addr.getCOUNTRY() != null && !addr.getCOUNTRY().equalsIgnoreCase("")) || 
							(addr.getZIPCODE()!=null && !addr.getZIPCODE().equalsIgnoreCase(""))){
							
							TctUnAddr add= new TctUnAddr();
							add.setEntityid(unEn.getDATAID());
							if (addr.getCITY()!=null) add.setCity(addr.getCITY().trim().replaceAll(",", ""));
							if (addr.getNOTE()!=null) add.setNote(addr.getNOTE().trim());
							if (addr.getCOUNTRY()!=null) add.setCountry(addr.getCOUNTRY().trim().replaceAll(",", ""));
							if (addr.getSTATEPROVINCE()!=null) add.setStateProv(addr.getSTATEPROVINCE().trim().replaceAll(",", ""));
							if (addr.getSTREET()!=null) add.setStreet(addr.getSTREET().trim().replaceAll(",", ""));
							if (addr.getZIPCODE()!=null) add.setZipCode(addr.getZIPCODE().trim().replaceAll(",", ""));
							
							add.setTctunentit(ent);
							
							addrs.add(add);
					}
					/* raffaele de lauri
					 * 05/03/2015
					 * vecchoi codice
					 * if (addr.getCOUNTRY()!=null && !addr.getCOUNTRY().equalsIgnoreCase("")){
						TctUnAddr add= new TctUnAddr();
						add.setEntityid(unEn.getDATAID());
						add.setCountry(addr.getCOUNTRY());
						add.setCity(addr.getCITY());
						add.setNote(addr.getNOTE());
						add.setStateProv(addr.getSTATEPROVINCE());
						add.setStreet(addr.getSTREET());
						add.setZipCode(addr.getZIPCODE());
						
						add.setTctunentit(ent);
						
						addrs.add(add);
					}*/
				}
				/* 
				 * raffaele de lauri
				 * TN_CCG15247
				 */
				if (addrs.size()>0)
					ent.setTctunaddrs(addrs);
			}else{
				ejbLogger.debug(new StandardLogMessage("no Address for entity "+ unEn.getDATAID()));
			}
			if (unEn.getENTITYALIAS() !=null && unEn.getENTITYALIAS().size()>0){
				ejbLogger.debug(new StandardLogMessage("alias for entity "+ unEn.getDATAID()));
				Set<TctUnAlia> aliass = new HashSet<TctUnAlia>();
				for (EntityAlias unAlias: unEn.getENTITYALIAS()){
					if ((unAlias.getALIASNAME()!= null && !unAlias.getALIASNAME().equalsIgnoreCase(""))&&(unAlias.getQUALITY()!= null && !unAlias.getQUALITY().equalsIgnoreCase(""))){
						TctUnAlia ali= new TctUnAlia();
						ali.setEntityid(unEn.getDATAID());
						ali.setAliasName(unAlias.getALIASNAME().trim().replaceAll(",", ""));
						ali.setQuality(unAlias.getQUALITY().trim().replaceAll(",", ""));
						ali.setTctunentit(ent);
						
						aliass.add(ali);
					}else{
						continue;
					}
				}
			ent.setTctunalias(aliass);
			}else{
					ejbLogger.debug(new StandardLogMessage("no alias for entity "+ unEn.getDATAID()));
			}
			
			if (unEn.getLASTDAYUPDATED()!=null && unEn.getLASTDAYUPDATED().getVALUE().size()>0 ){
				ejbLogger.debug(new StandardLogMessage("Last update list type for entity "+ unEn.getDATAID()));
				Set<TctUnLstUp> updLst = new HashSet<TctUnLstUp>();
				for(XMLGregorianCalendar date : unEn.getLASTDAYUPDATED().getVALUE()){
					TctUnLstUp updt = new TctUnLstUp();
					updt.setEntityid(unEn.getDATAID());
					updt.setValue(date.toGregorianCalendar().getTime());
					updt.setTctunentit(ent);
					
					updLst.add(updt);
				}
				ent.setTctunlstups(updLst);
			}else{
				ejbLogger.debug(new StandardLogMessage("No last update list type for entity "+ unEn.getDATAID()));
			}	
			
			ents.add(ent);
		}
		tctUnEntity.insertEntity(ents);
		
		for (Individual unInd : unObj.getINDIVIDUALS().getINDIVIDUAL()){
			ejbLogger.debug(new StandardLogMessage("Individual "+unInd.getDATAID()));
			TctUnIndiv ind = new TctUnIndiv();
			ind.setDataId(unInd.getDATAID());
			if (unInd.getCOMMENTS1()!=null) ind.setComments1(unInd.getCOMMENTS1().trim());
			ind.setDateGenerated(unObj.getDateGenerated().toGregorianCalendar().getTime());
			ind.setUnListTp(unInd.getLISTTYPE().getVALUE());
			ind.setFirstName(unInd.getFIRSTNAME().trim());
			ind.setListedOn(new Timestamp(unInd.getLISTEDON().toGregorianCalendar().getTimeInMillis()));
			if (unInd.getNAMEORIGINALSCRIPT()!=null) ind.setNOrgScript(unInd.getNAMEORIGINALSCRIPT().trim());
			ind.setRefNumber(unInd.getREFERENCENUMBER());
			ind.setReleasedDt(unObj.getDateGenerated().toGregorianCalendar().getTime());
			if (unInd.getSECONDNAME()!= null) ind.setSecondName(unInd.getSECONDNAME().trim());
			ind.setSortKey(unInd.getSORTKEY());
			if (unInd.getSORTKEYLASTMOD()!=null) ind.setSortKeyLsMod(new Timestamp(unInd.getSORTKEYLASTMOD().toGregorianCalendar().getTimeInMillis()));
			if (unInd.getTHIRDNAME()!=null) ind.setThirdName(unInd.getTHIRDNAME().trim());
			ind.setUpdDate(new Timestamp(insertDate.getTime()));
			ind.setUpdType("C");
			ind.setUpdUser(user);
			
			if (unInd.getINDIVIDUALADDRESS() !=null && unInd.getINDIVIDUALADDRESS().size()>0){
				ejbLogger.debug(new StandardLogMessage("Address for individual "+ unInd.getDATAID()));
				Set<TctUnAddr> address = new HashSet<TctUnAddr>();
				for (IndividualAddress unAddr: unInd.getINDIVIDUALADDRESS()){
					if ((unAddr.getNOTE()!=null && !unAddr.getNOTE().equalsIgnoreCase("")) || 
						(unAddr.getSTREET()!=null && !unAddr.getSTREET().equalsIgnoreCase("")) || 
						(unAddr.getCITY()!=null && !unAddr.getCITY().equalsIgnoreCase("")) || 
						(unAddr.getSTATEPROVINCE()!=null && !unAddr.getSTATEPROVINCE().equalsIgnoreCase("")) || 
						(unAddr.getCOUNTRY() != null && !unAddr.getCOUNTRY().equalsIgnoreCase("")) || 
						(unAddr.getZIPCODE()!=null && !unAddr.getZIPCODE().equalsIgnoreCase(""))){
						
						TctUnAddr addr= new TctUnAddr();
						addr.setEntityid(unInd.getDATAID());
						if (unAddr.getCITY()!=null) addr.setCity(unAddr.getCITY().trim().replaceAll(",", ""));
						if (unAddr.getNOTE()!=null) addr.setNote(unAddr.getNOTE().trim());
						if (unAddr.getCOUNTRY()!=null) addr.setCountry(unAddr.getCOUNTRY().trim().replaceAll(",", ""));
						if (unAddr.getSTATEPROVINCE()!=null) addr.setStateProv(unAddr.getSTATEPROVINCE().trim().replaceAll(",", ""));
						if (unAddr.getSTREET()!=null) addr.setStreet(unAddr.getSTREET().trim().replaceAll(",", ""));
						if (unAddr.getZIPCODE()!=null) addr.setZipCode(unAddr.getZIPCODE().trim().replaceAll(",", ""));
						addr.setTctunindiv(ind);
						
						address.add(addr);
					}else{
						continue;
					}
				}
				ind.setTctunaddrs(address);
			}else{
					ejbLogger.debug(new StandardLogMessage("no address for individual "+ unInd.getDATAID()));
			}
			
			if (unInd.getINDIVIDUALDOCUMENT() !=null && unInd.getINDIVIDUALDOCUMENT().size()>0){
				ejbLogger.debug(new StandardLogMessage("Document for individual "+ unInd.getDATAID()));
				Set<TctUnInDoc> documents = new HashSet<TctUnInDoc>();
				for (IndividualDocument unDoc: unInd.getINDIVIDUALDOCUMENT()){
					if ((unDoc.getNUMBER()!=null && !unDoc.getNUMBER().equalsIgnoreCase("") )|| 
						(unDoc.getTYPEOFDOCUMENT()!=null && !unDoc.getTYPEOFDOCUMENT().equalsIgnoreCase("")) || 
						(unDoc.getNOTE()!=null && !unDoc.getNOTE().equalsIgnoreCase(""))){
						TctUnInDoc doc= new TctUnInDoc();
						doc.setEntityId(unInd.getDATAID());
						if (unDoc.getNOTE()!=null )doc.setNote(unDoc.getNOTE().trim());
						if (unDoc.getNUMBER()!=null) doc.setNumber(unDoc.getNUMBER().trim());
						if (unDoc.getTYPEOFDOCUMENT()!=null) doc.setTypeOfDoc(unDoc.getTYPEOFDOCUMENT().trim().replaceAll(",", ""));
						doc.setTctunindiv(ind);
						
						documents.add(doc);
					}else{
						continue;
					}
				}
				ind.setTctunindoc(documents);
			}else{
					ejbLogger.debug(new StandardLogMessage("no document for individual "+ unInd.getDATAID()));
			}
			
			if (unInd.getINDIVIDUALALIAS() !=null && unInd.getINDIVIDUALALIAS().size()>0){
				ejbLogger.debug(new StandardLogMessage("alias for individual "+ unInd.getDATAID()));
				Set<TctUnAlia> aliass = new HashSet<TctUnAlia>();
				for (IndividualAlias unAlias: unInd.getINDIVIDUALALIAS()){
					if ((unAlias.getALIASNAME()!= null && !unAlias.getALIASNAME().equalsIgnoreCase(""))&&(unAlias.getQUALITY()!= null && !unAlias.getQUALITY().equalsIgnoreCase(""))){
						TctUnAlia ali= new TctUnAlia();
						ali.setEntityid(unInd.getDATAID());
						ali.setAliasName(unAlias.getALIASNAME().trim().replaceAll(",", ""));
						ali.setQuality(unAlias.getQUALITY().trim().replaceAll(",", ""));
						ali.setTctunindiv(ind);
						
						aliass.add(ali);
					}else{
						continue;
					}
				}
				ind.setTctunalias(aliass);
			}else{
					ejbLogger.debug(new StandardLogMessage("no alias for individual "+ unInd.getDATAID()));
			}
			
			if (unInd.getINDIVIDUALDATEOFBIRTH()!=null && unInd.getINDIVIDUALDATEOFBIRTH().size()>0){
				ejbLogger.debug(new StandardLogMessage("date of birth for individual "+ unInd.getDATAID()));
				Set<TctUnBrtDt> brtDts = new HashSet<TctUnBrtDt>();
				for(IndividualDateOfBirth datOfBirth : unInd.getINDIVIDUALDATEOFBIRTH()){
					TctUnBrtDt brtDt = new TctUnBrtDt();
					brtDt.setEntityid(unInd.getDATAID());
					brtDt.setTypeOfDate(datOfBirth.getTYPEOFDATE());
					brtDt.setYear(datOfBirth.getYEAR());
					if (datOfBirth.getDATE()!=null) brtDt.setBirthDate((datOfBirth.getDATE().toGregorianCalendar()).getTime());
					brtDt.setTctunindiv(ind);
					
					brtDts.add(brtDt);
				}
				ind.setTctunbrtdts(brtDts);
			}else{
				ejbLogger.debug(new StandardLogMessage("no date of birth for individual "+ unInd.getDATAID()));
			}
			
			if (unInd.getINDIVIDUALPLACEOFBIRTH() !=null && (unInd.getINDIVIDUALPLACEOFBIRTH().getSTATEPROVINCE()!=null || unInd.getINDIVIDUALPLACEOFBIRTH().getCITY()!=null)){
				ejbLogger.debug(new StandardLogMessage("place of birth for individual "+ unInd.getDATAID()));
				Set<TctUnBtPlc> brtPlcs = new HashSet<TctUnBtPlc> ();
				TctUnBtPlc brtplc = new TctUnBtPlc();
				brtplc.setEntityid(unInd.getDATAID());
				brtplc.setStateProv(unInd.getINDIVIDUALPLACEOFBIRTH().getSTATEPROVINCE());
				brtplc.setCity(unInd.getINDIVIDUALPLACEOFBIRTH().getCITY());
				brtplc.setTctunindiv(ind);
				brtPlcs.add(brtplc);
				
				ind.setTctunbtplcs(brtPlcs);
			}else{
				ejbLogger.debug(new StandardLogMessage("no place of birth for individual "+ unInd.getDATAID()));
			}
			
			if (unInd.getNATIONALITY()!=null){
				ejbLogger.debug(new StandardLogMessage("nationality for individual "+ unInd.getDATAID()));
				Set<TctUnNat> nats = new HashSet<TctUnNat>();
				TctUnNat nat = new TctUnNat();
				nat.setEntityid(unInd.getDATAID());
				nat.setValue(unInd.getNATIONALITY().getVALUE());
				nat.setTctunindiv(ind);
				nats.add(nat);
				
				ind.setTctunnats(nats);
			}else{
				ejbLogger.debug(new StandardLogMessage("no nationality for individual "+ unInd.getDATAID()));
			}
			
			if (unInd.getLASTDAYUPDATED()!=null && unInd.getLASTDAYUPDATED().getVALUE()!=null ){
				ejbLogger.debug(new StandardLogMessage("Last update list type for individual "+ unInd.getDATAID()));
				Set<TctUnLstUp> updLst = new HashSet<TctUnLstUp>();
				for(XMLGregorianCalendar date : unInd.getLASTDAYUPDATED().getVALUE()){
					TctUnLstUp updt = new TctUnLstUp();
					updt.setEntityid(unInd.getDATAID());
					updt.setValue(date.toGregorianCalendar().getTime());
					updt.setTctunindiv(ind);
					
					updLst.add(updt);
				}				
				ind.setTctunlstups(updLst);
			}else{
				ejbLogger.debug(new StandardLogMessage("No last update list type for individual "+ unInd.getDATAID()));
			}
			
			
			inds.add(ind);
		}
		this.tctUnIndividualEAO.insertIndividual(inds);		
	}

}
