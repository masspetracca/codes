package it.ccg.tcejb.server.bean.entity.ec;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTECENAME database table.
 * 
 */
@Entity
@Table(name="TCTECENAME")
@NamedQueries({
	@NamedQuery(name="deleteEcNamePtEveryEntity", query="DELETE FROM TctEcENameEntity"),
	@NamedQuery(name="getEcNamePtEntitiesById", query="SELECT entity FROM TctEcENameEntity entity WHERE entity.id.entityid = :entityId ORDER BY entity.id.nameId ASC")
})
public class TctEcENameEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	@EmbeddedId
	private TctEcENameEntityPK id;

	@Column(length=100)
	private String firstName;

	@Column(length=200)
	private String function;

	@Column(length=1)
	private String gender;

	@Column(length=3)
	private String language;

	@Column(length=100)
	private String lastName;

	@Column(length=100)
	private String legalBasis;

	@Column(length=100)
	private String middleName;

	@Column(length=2000)
	private String pdfLink;

    @Temporal( TemporalType.DATE)
	private Date regDate;

	@Column(length=50)
	private String title;

	@Column(length=2000)
	private String wholeName;

	/*//bi-directional many-to-one association to TctAggrEntEntity
	@OneToMany(mappedBy="tctecename1")
	private Set<TctAggrEntEntity> tctaggrents1;

	//bi-directional many-to-one association to TctAggrEntEntity
	@OneToMany(mappedBy="tctecename2")
	private Set<TctAggrEntEntity> tctaggrents2;*/

	//bi-directional many-to-one association to TctEcEntitEntity
	@ManyToOne(optional=false)
	@JoinColumn(name="ENTITYID", nullable=true, insertable=true, updatable=true)
	private TctEcEntitEntity tctecentit;

    public TctEcENameEntity() {
    }

	public TctEcENameEntityPK getId() {
		return this.id;
	}

	public void setId(TctEcENameEntityPK id) {
		this.id = id;
	}
	
	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		if (firstName != null && firstName.length()>100){
			ejbLogger.debug(firstName+" >100 than truncate");
			this.firstName = firstName.substring(0, 99);
		}else{
			this.firstName = firstName;
		}
	}

	public String getFunction() {
		return this.function;
	}

	public void setFunction(String function) {
		if (function != null && function.length()>200){
			ejbLogger.debug(function+" >200 than truncate");
			this.function = function.substring(0, 199);
		}else{
			this.function = function;
		}
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLanguage() {
		return this.language;
	}

	public void setLanguage(String language) {
		if (language != null && language.length()>3){
			ejbLogger.debug(language+" >3 than truncate");
			this.language = language.substring(0, 2);
		}else{
			this.language = language;
		}
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		if (lastName != null && lastName.length()>100){
			ejbLogger.debug(lastName+" >100 than truncate");
			this.lastName = lastName.substring(0, 99);
		}else{
			this.lastName = lastName;
		}
	}

	public String getLegalBasis() {
		return this.legalBasis;
	}

	public void setLegalBasis(String legalBasis) {
		if (legalBasis !=null && legalBasis.length()>100){
			ejbLogger.debug(legalBasis+" >100 than truncate");
			this.legalBasis = legalBasis.substring(0, 99);
		}else{
			this.legalBasis = legalBasis;
		}
	}

	public String getMiddleName() {
		return this.middleName;
	}

	public void setMiddleName(String middleName) {
		if (middleName != null && middleName.length()>100){
			ejbLogger.debug(middleName+" >100 than truncate");
			this.middleName = middleName.substring(0, 99);
		}else{
			this.middleName = middleName;
		}
	}

	public String getPdfLink() {
		return this.pdfLink;
	}

	public void setPdfLink(String pdfLink) {
		if (pdfLink != null && pdfLink.length()>2000){
			ejbLogger.debug(pdfLink+" >2000 than truncate");
			this.pdfLink = pdfLink.substring(0, 1999);
		}else{
			this.pdfLink = pdfLink;
		}
	}

	public Date getRegDate() {
		return this.regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		if (title != null && title.length()>50){
			ejbLogger.debug(title+" >50 than truncate");
			this.title = title.substring(0, 49);
		}else{
			this.title = title;
		}
	}

	public String getWholeName() {
		return this.wholeName;
	}

	public void setWholeName(String wholeName) {
		if (wholeName != null && wholeName.length()>2000){
			ejbLogger.debug(title+" >2000 than truncate");
			this.wholeName = wholeName.substring(0, 1999);
		}else{
			this.wholeName = wholeName;
		}
	}
	
	public TctEcEntitEntity getTctecentit() {
		return this.tctecentit;
	}

	public void setTctecentit(TctEcEntitEntity tctecentit) {
		this.tctecentit = tctecentit;
	}
	
}