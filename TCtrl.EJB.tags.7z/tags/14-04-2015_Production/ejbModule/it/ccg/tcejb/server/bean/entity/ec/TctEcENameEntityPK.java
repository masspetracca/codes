package it.ccg.tcejb.server.bean.entity.ec;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTECENAME database table.
 * 
 */
@Embeddable
public class TctEcENameEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int nameId;

	@Column(unique=true, nullable=false)
	private int entityid;

    public TctEcENameEntityPK() {
    }
	public int getNameId() {
		return this.nameId;
	}
	public void setNameId(int nameId) {
		this.nameId = nameId;
	}
	public int getEntityid() {
		return this.entityid;
	}
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctEcENameEntityPK)) {
			return false;
		}
		TctEcENameEntityPK castOther = (TctEcENameEntityPK)other;
		return 
			(this.nameId == castOther.nameId)
			&& (this.entityid == castOther.entityid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.nameId;
		hash = hash * prime + this.entityid;
		
		return hash;
    }
}