package it.ccg.tcejb.server.bean.entity.ofac;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTOFDTBIR database table.
 * 
 */
@Embeddable
public class TctOfDtBirEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int dtBrtId;

	@Column(unique=true, nullable=false)
	private int entityid;

    public TctOfDtBirEntityPK() {
    }
	public int getDtBrtId() {
		return this.dtBrtId;
	}
	public void setDtBrtId(int dtBrtId) {
		this.dtBrtId = dtBrtId;
	}
	public int getEntityid() {
		return this.entityid;
	}
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctOfDtBirEntityPK)) {
			return false;
		}
		TctOfDtBirEntityPK castOther = (TctOfDtBirEntityPK)other;
		return 
			(this.dtBrtId == castOther.dtBrtId)
			&& (this.entityid == castOther.entityid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.dtBrtId;
		hash = hash * prime + this.entityid;
		
		return hash;
    }
}