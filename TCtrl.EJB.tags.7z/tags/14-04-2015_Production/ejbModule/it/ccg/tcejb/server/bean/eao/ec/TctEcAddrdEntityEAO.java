package it.ccg.tcejb.server.bean.eao.ec;

import it.ccg.tcejb.server.bean.entity.ec.TctEcAddrdEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctEcAddrdEntityEAO
 */
@Stateless
@LocalBean
public class TctEcAddrdEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctEcAddrdEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctEcAddrdEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctEcAddrd entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcAddrd identification data: EC Entity code = "+entity.getId().getEntityid() +" , address id = "+entity.getId().getAddressId()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public void insertEntity(Set<TctEcAddrdEntity> entities) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctEcEntit entity)"));
	    	for (TctEcAddrdEntity entity : entities){
	    		ejbLogger.debug(new StandardLogMessage("TctEcAddrd identification data: EC Entity code = "+entity.getId().getEntityid() +" , address id = "+entity.getId().getAddressId()));
		    	
		    	this.manager.persist(entity);
	    	}
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	this.manager.flush();
	    	
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
  	public void deleteEntity(TctEcAddrdEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctEcEntit entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcAddrd identification data: EC Entity code = "+entity.getId().getEntityid() +" , address id = "+entity.getId().getAddressId()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void deleteEveryEntity() throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteEcAddrEveryEntity");
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	this.manager.flush();
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctEcAddrdEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctEcAddrd entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcAddrd identification data: EC Entity code = "+entity.getId().getEntityid() +" , address id = "+entity.getId().getAddressId()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	@SuppressWarnings("unchecked")
	public  List<TctEcAddrdEntity> retrieveEntityAddrByEntId(int entityId) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<TctEcAddrd> retrieveEntityAddrByEntId(int entityId)"));
	    	ejbLogger.debug(new StandardLogMessage("ecEntityId "+entityId));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getEcAddrEntitiesById");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("entityId", entityId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	List<TctEcAddrdEntity> ecAddEntities = (List<TctEcAddrdEntity>) q.getResultList();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return ecAddEntities;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
}
