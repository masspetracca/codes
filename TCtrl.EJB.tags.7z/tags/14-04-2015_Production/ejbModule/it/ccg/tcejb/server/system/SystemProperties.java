package it.ccg.tcejb.server.system;


import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class SystemProperties {
	
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	

	private static final String PROPERTIES_SYSTEM_FILE_ABS_PATH = System.getProperty("user.install.root") + 
															      System.getProperty("file.separator") +
															      "properties" + 
															      System.getProperty("file.separator") +
															      "terrorismcontrol.properties";
	
	private static final String PROPERTIES_BUSINES_NAMES_FILE_ABS_PATH = System.getProperty("user.install.root") + 
																	      System.getProperty("file.separator") +
																	      "properties" + 
																	      System.getProperty("file.separator") +
																	      "businnes_entity.properties";
	
	
	private static Properties systemProperties = null;
	private static Properties businessProperties = null;
	
	
	public static void loadSystemProperties() throws BackEndException {
		
		// load properties from file
		systemProperties = new Properties();
		try {
			systemProperties.load(new FileInputStream(PROPERTIES_SYSTEM_FILE_ABS_PATH));
						// load other system properties
			systemProperties.put("user.install.root", System.getProperty("user.install.root"));
			systemProperties.put("file.separator", System.getProperty("file.separator"));
			
			
			logger.debug(new StandardLogMessage("Terrorism control system properties successfully loaded from file: " + PROPERTIES_SYSTEM_FILE_ABS_PATH));
		} catch (FileNotFoundException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		}
	}
	
	public static void loadBusinessNamesProperties() throws BackEndException {
		
		// load properties from file
		businessProperties = new Properties();
		try {
			businessProperties.load(new FileInputStream(PROPERTIES_BUSINES_NAMES_FILE_ABS_PATH));
						// load other system properties
			/*businessProperties.put("user.install.root", System.getProperty("user.install.root"));
			businessProperties.put("file.separator", System.getProperty("file.separator"));*/
			
			
			logger.debug(new StandardLogMessage("Terrorism control businness names properties successfully loaded from file: " + PROPERTIES_BUSINES_NAMES_FILE_ABS_PATH));
		} catch (FileNotFoundException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		}
	}
		
	public static String getSystemProperty(String propertyName) throws BackEndException {
		
		if(systemProperties == null) {
			
			loadSystemProperties();
		}
		
		return systemProperties.getProperty(propertyName);
	}
	
	public static String getBusinessNamesProperty(String propertyName) throws BackEndException {
		
		if(businessProperties == null) {
			
			loadBusinessNamesProperties();
		}
		
		return businessProperties.getProperty(propertyName);
	}

	public static Properties getSystemProperties() throws BackEndException {
		
		if(systemProperties == null) {
			
			loadSystemProperties();
		}
		
		return systemProperties;
	}
	
	public static Properties getBusinessNamesProperties() throws BackEndException {
		
		if(businessProperties == null) {
			
			loadBusinessNamesProperties();
		}
		
		return businessProperties;
	}

	public static String getSystemPropertiesFileAbsPath() {
		
		return PROPERTIES_SYSTEM_FILE_ABS_PATH;
	}
	
	public static String getBusinessPropertiesFileAbsPath() {
		
		return PROPERTIES_BUSINES_NAMES_FILE_ABS_PATH;
	}
}
