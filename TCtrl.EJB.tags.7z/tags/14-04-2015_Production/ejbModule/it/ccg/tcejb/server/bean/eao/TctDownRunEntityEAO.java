package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctDownRunEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NamedQuery;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctDownRunEntityEAO
 */
@Stateless
@LocalBean
public class TctDownRunEntityEAO {

	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctDownRunEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertDownload(TctDownRunEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertDownload(TctDownRunEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public int retrieveLatestDownID() throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in int retrieveLatestID(TctDownReg entity)"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getDonwRunLatestID");
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	int id = -1;
	    	try{
	    		id= (Integer) q.getSingleResult();
	    	}catch(NoResultException e){
	    		ejbLogger.debug(new StandardLogMessage("No result from donwload run table"));
	    	}
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return id;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
    
    /*
     * NamedQuery(name="getDonwloadIDbyRun",   query="SELECT entity.id.downloadid " +
            "								          FROM TctDownRunEntity entity " +
            "								         WHERE entity.id.runid  = :run")
     */
    public int retrieveDownloadByRunId(int runId) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in int retrieveLatestID(TctDownReg entity)"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getDonwloadIDbyRun");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("run", runId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	int id = -1;
	    	try{
	    		id= (Integer) q.getSingleResult();
	    	}catch(NoResultException e){
	    		ejbLogger.debug(new StandardLogMessage("No result from donwload run table"));
	    	}
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return id;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  
  	}
}
