package it.ccg.tcejb.server.bean.entity.ofac;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTOFVSINF database table.
 * 
 */
@Embeddable
public class TctOfVsInfEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	//@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="VESSINFID")
	private int vessInfId;

	@Column(unique=true, nullable=false)
	private int entityid;

    public TctOfVsInfEntityPK() {
    }
	public int getVessInfId() {
		return this.vessInfId;
	}
	public void setVessInfId(int vessInfId) {
		this.vessInfId = vessInfId;
	}
	public int getEntityid() {
		return this.entityid;
	}
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctOfVsInfEntityPK)) {
			return false;
		}
		TctOfVsInfEntityPK castOther = (TctOfVsInfEntityPK)other;
		return 
			(this.vessInfId == castOther.vessInfId)
			&& (this.entityid == castOther.entityid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.vessInfId;
		hash = hash * prime + this.entityid;
		
		return hash;
    }
}