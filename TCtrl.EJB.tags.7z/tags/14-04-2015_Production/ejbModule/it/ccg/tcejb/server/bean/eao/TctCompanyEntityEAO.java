package it.ccg.tcejb.server.bean.eao;

import java.sql.Timestamp;
import java.util.Date;

import it.ccg.tcejb.server.bean.entity.TctCompanyEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctCompanyEntityEAO
 */
@Stateless
@LocalBean
public class TctCompanyEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctCompanyEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertDownload(TctCompanyEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctCompanyEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public void deleteEntity(TctCompanyEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctCompanyEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctCompanyEntity identification data: company id = "+entity.getCmpnId()+" name= "+entity.getCompanyName()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
    
    public void updateEntity(TctCompanyEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctCompanyEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctCompanyEntity identification data: company id = "+entity.getCmpnId()+" name= "+entity.getCompanyName()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("U");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
    
    public TctCompanyEntity retrieveCompanyByCompanyId(int companyId) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in TctCompanyEntity retrieveCompanyByCompanyId(int companyId)"));
		TctCompanyEntity toReturn = this.manager.find(TctCompanyEntity.class, companyId);
		
		return toReturn;
  	}
    
    public TctCompanyEntity retrieveCompanyIdByUsername(String companyCode) throws BackEndException{
  		try{
  		
	    	ejbLogger.debug(new StandardLogMessage("in TctCompanyEntity retrieveCompanyIdByUsername(String companyCode)"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getCompanyByCompanyCode");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("companyCode", companyCode);
	    	
	    	TctCompanyEntity toReturn = (TctCompanyEntity) q.getSingleResult();
	    	return toReturn;
	    	
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
    
}
