/*
 * Imagine that this class requires lots of configuration
 * before use, e.g. via constructor parameters
 */
public class Dog extends AbstractAnimal implements Animal {
	@Override
	public void miPresento() {
		System.out.println("Sono un cane...");
	}
	
	@Override
	public void speak() {
		System.out.println("parlo,");
		
	}

	@Override
	public void dream() {
		// TODO Auto-generated method stub
		System.out.println("N.A.");
	}


}
