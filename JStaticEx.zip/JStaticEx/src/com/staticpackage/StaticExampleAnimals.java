package com.staticpackage;

public class StaticExampleAnimals {
	private int legsCount = 4;
	private String name;
	private String sexId;
	private static int instance = 0;
	
	public StaticExampleAnimals(String name) {
		this.name = name;
		instance++;
	}
	

	public String sexId() {
		return sexId;
	}
	
	public static int instance() {
		return instance;
	}
	public int getLegsCount() {
		return legsCount;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	
}