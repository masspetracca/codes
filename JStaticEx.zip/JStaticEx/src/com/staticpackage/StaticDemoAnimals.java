package com.staticpackage;

public class StaticDemoAnimals {

	public static void main(String[] args) {
		StaticExampleAnimals s1 = new StaticExampleAnimals("Felino");
		System.out.println("Family name is: " + s1.getName());
		System.out.println("Gambe #: " + s1.getLegsCount());
		System.out.println("This is intance no: " + StaticExampleAnimals.instance());

		StaticExampleAnimals s2 = new StaticExampleAnimals("Canide");
		System.out.println("Family name is: " + s2.getName());
		System.out.println("Gambe #: " + s2.getLegsCount());
		System.out.println("This is intance no: " + StaticExampleAnimals.instance());
	}
}