package it.corso.jsf.business;

import javax.ejb.Local;

@Local
public interface EsempioRestJsonBeanLocal {

}
