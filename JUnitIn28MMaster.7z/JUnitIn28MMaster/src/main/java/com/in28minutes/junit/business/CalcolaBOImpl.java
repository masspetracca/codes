package com.in28minutes.junit.business;

import java.math.BigDecimal;
import java.util.List;

import com.in28minutes.junit.business.exception.DifferentCurrenciesException;
import com.in28minutes.junit.model.Amount;
import com.in28minutes.junit.model.AmountImpl;
import com.in28minutes.junit.model.Currency;
import com.in28minutes.junit.model.Importo;
import com.in28minutes.junit.model.Product;

public class CalcolaBOImpl implements CalcolaBO {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.clarity.model.ClientBO#getClientProductsSum(java.util.List)
	 */
	@Override
	public Amount getImportoSum(List<Importo> imp)
			throws DifferentCurrenciesException {
				return getImportoSum(imp);

//		if (imp.size() == 0)
//			return new AmountImpl(BigDecimal.ZERO, Currency.EURO);
//
//		if (!isCurrencySameForAllImporti(imp)) {
//			throw new DifferentCurrenciesException();
//		}

//		BigDecimal importoSum = calculateImportoSum(imp);
//
//		Currency firstImportoCurrency = imp.get(0).getImporto()		
//				.getCurrency();

//		return new AmountImpl(importoSum, firstImportoCurrency);
//		return new AmountImpl(importoSum, null);
		
		
	}


//	private BigDecimal calculateImportoSum(List<Importo> imp) {
//		BigDecimal sum = BigDecimal.ZERO;
//		// Calculate Sum of Importo
//		for (Importo importo : imp) {
//			sum = sum.add(imp.getImporto()
//					.getValue());
//		}
//		return sum;
//	}

//	private boolean isCurrencySameForAllImporti(List<Importo> imp)
//			throws DifferentCurrenciesException {
//
//		Currency firstProductCurrency = imp.get(0).getAmount()
//				.getCurrency();
//
//		for (Importo importo : imp) {
//			boolean currencySameAsFirstImporto = imp.get(0).getAmount()
//					.getCurrency().equals(firstImportoCurrency);
//			if (!currencySameAsFirstImporto) {
//				return false;
//			}
//		}
//
//		return true;
//	}




}