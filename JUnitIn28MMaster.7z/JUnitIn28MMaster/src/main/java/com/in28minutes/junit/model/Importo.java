package com.in28minutes.junit.model;

/**
 * Product Model API.
 */
public interface Importo {

	double getImporto();

	String getName();
}
