package com.in28minutes.junit.business;

import java.util.List;

import com.in28minutes.junit.business.exception.DifferentCurrenciesException;
import com.in28minutes.junit.model.Amount;
import com.in28minutes.junit.model.Importo;
import com.in28minutes.junit.model.Product;

public interface CalcolaBO {

	Amount getImportoSum(List<Importo> importi)
			throws DifferentCurrenciesException;

}