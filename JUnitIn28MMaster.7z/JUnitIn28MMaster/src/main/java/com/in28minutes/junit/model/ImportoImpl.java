package com.in28minutes.junit.model;

/**
 * Collateral Model Object.
 */
public class ImportoImpl implements Importo {

	private double importo;

	private String name;

	public ImportoImpl(double importo, String name) {
		super();
		this.importo = importo;
		this.name = name;
	}

	@Override
	public double getImporto() {
		return importo;
	}

	public void setImporto(double importo) {
		this.importo = importo;
	}

	@Override
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
