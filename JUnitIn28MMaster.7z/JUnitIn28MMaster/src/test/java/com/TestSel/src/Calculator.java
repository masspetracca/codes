package com.TestSel.src;


public class Calculator implements AdvancedArithmetic {
	
	
	public int getSum(int num1, int num2){ 
		//parameters
		int result = num1+num2;
		return result;
		
	}
	
	public int getSub(int num1, int num2){
		
		
		return num1-num2;
		
	}
	
	public int getMult(int num1, int num2){
		
		
		return num1*num2;
		
	}

	public int getDiv(int num1, int num2){
	
	
	return num1/num2;
	
	}

	@Override
	public int divisorSum(int n) {
		// TODO Auto-generated method stub
		return n;
	}



}
