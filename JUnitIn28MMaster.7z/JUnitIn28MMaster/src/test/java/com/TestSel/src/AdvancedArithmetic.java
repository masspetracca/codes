package com.TestSel.src;

public interface AdvancedArithmetic {
		int divisorSum(int n);
}
