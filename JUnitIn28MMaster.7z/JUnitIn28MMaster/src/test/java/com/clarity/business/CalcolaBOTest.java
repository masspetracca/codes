package com.clarity.business;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.in28minutes.junit.business.CalcolaBO;
import com.in28minutes.junit.business.CalcolaBOImpl;
import com.in28minutes.junit.business.exception.DifferentCurrenciesException;
import com.in28minutes.junit.model.Amount;
import com.in28minutes.junit.model.AmountImpl;
import com.in28minutes.junit.model.Currency;
import com.in28minutes.junit.model.Importo;
import com.in28minutes.junit.model.ImportoImpl;
import com.in28minutes.junit.model.ImportoType;
import com.in28minutes.junit.model.Product;
import com.in28minutes.junit.model.ProductImpl;
import com.in28minutes.junit.model.ProductType;

public class CalcolaBOTest {

	private CalcolaBO calcolaBO = new CalcolaBOImpl();

	@Test
	public void testImportoSum() throws DifferentCurrenciesException {

		List<Importo> imp = new ArrayList<Importo>();

		imp.add(new ImportoImpl(100, "Importo 100"));

		imp.add(new ImportoImpl(120, "Product 20"));
	}

	@Test(expected = DifferentCurrenciesException.class)
	public void testClientProductSum1() throws DifferentCurrenciesException {

		List<Importo> imp = new ArrayList<Importo>();

		imp.add(new ImportoImpl(100, "Importo 100"));

		imp.add(new ImportoImpl(120, "Product 20"));

		@SuppressWarnings("unused")
		Importo temp = null;

//		temp = importo.getImportoSum(imp);
	}

//	@Test
//	public void testClientProductSum2() {
//
//		List<Product> products = new ArrayList<Product>();
//
//		Amount temp = null;
//
//		try {
//			temp = ImportoImpl.getClientProductsSum(imp);
//		} catch (DifferentCurrenciesException e) {
//		}
//		assertEquals(Currency.EURO, temp.getCurrency());
//		assertEquals(BigDecimal.ZERO, temp.getValue());
//	}

}