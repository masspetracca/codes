package com.jwt.spring;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
 
public class Test {
    public static void main(String[] args) {
        XmlBeanFactory factory = new XmlBeanFactory(
                newClassPathResource("Beans.xml"));
        HelloWorld helloObj = (HelloWorld) factory.getBean("helloWorld");
        helloObj.getMessage();
    }


}