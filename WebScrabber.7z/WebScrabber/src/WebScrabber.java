import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;



public class WebScrabber {
	    public static void main(String[] args) throws IOException {

	        BufferedReader buff;
	        InputStreamReader inStream;
	        String htmlCode = null;
	        try{
	            URL url = new URL("http://rads.stackoverflow.com/amzn/click/473246031");
	            URLConnection urlConnection = (URLConnection)url.openConnection();



	            inStream = new InputStreamReader(urlConnection.getInputStream());
	            buff = new BufferedReader(inStream);

	            while(true){
	                if (buff.readLine()!=null){
	                    htmlCode += buff.readLine() + "\n";
	                    System.out.println("htmlCode: "+htmlCode);
	                }else{
	                    break;
	                }
	            }

	            int startFrom = htmlCode.indexOf("<div class=\"zg_rank\">");
	            int endFrom = htmlCode.indexOf("</div>");

	            String idNumber = htmlCode.substring(startFrom, endFrom);

	            System.out.println(idNumber);
	        }catch(Exception e){};  

	    }

}
