package com.ibm.example;

public interface EJBConverterLocal {
	
	public double convertToCelsius(double fahrenheit);
	
	public double convertToFahrenheit(double celsius);
}
