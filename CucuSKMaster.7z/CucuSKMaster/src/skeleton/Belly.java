package skeleton;

public class Belly {
    public void eat(int cukes) {

    }
}
