package com.qaxml2csv;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class Xml2Csv {

	static String req;
	
	


	public static void main(String args[]) throws Exception {

		if (args.length <= 0) {
			System.out.println("Argument ko:" + args[0] + " must be a String.");
	        System.exit(1);
		}
		
		req=args[0];
		System.out.println("Requirement ok:" + req);
		Xml2Csv();

	}


	private static void Xml2Csv() throws ParserConfigurationException, SAXException, IOException, TransformerFactoryConfigurationError, TransformerException {
		File stylesheet = new File("files/20170302MGPFabbisogno.xsl");
		File xmlSource = new File("files/"+req+".xml");

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.parse(xmlSource);

		StreamSource stylesource = new StreamSource(stylesheet);
		Transformer transformer = TransformerFactory.newInstance()
				.newTransformer(stylesource);
		Source source = new DOMSource(document);
		Result outputTarget = new StreamResult(new File(
				"csv/"+req+".rctest.csv"));
		transformer.transform(source, outputTarget);

	}

}