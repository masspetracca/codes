package it.ccg.portaladminejb.bean.service;

public interface PAMPQueueLocal {
	
	public 

}
