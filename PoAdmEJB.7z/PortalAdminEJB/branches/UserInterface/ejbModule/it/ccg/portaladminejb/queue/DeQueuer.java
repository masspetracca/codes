package it.ccg.portaladminejb.queue;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class DeQueuer {
	private QueueConnectionFactory connFact;
	private Context ctx;
	private Destination dest;
	
	public DeQueuer() throws NamingException{
		ctx = new InitialContext();
		connFact = (QueueConnectionFactory)ctx.lookup("jms/MDBStarterCF");
		dest = (Destination) ctx.lookup("jms/MDBStarter");
	}
	
	public void pull(){
		System.out.println("pull");
		Connection conn;
		try {
			conn = connFact.createConnection();
			conn.start();
			System.out.println("create session");
			Session sess = (Session) conn.createSession(false,Session.AUTO_ACKNOWLEDGE);
			System.out.println("create consumer");
			MessageConsumer msgCons = sess.createConsumer(dest);
			int i = 1;
			System.out.println("receive");
			while (msgCons.receive()!=null){
				System.out.println(""+i++);
			}

			System.out.println("close");
			msgCons.close();
			sess.close();
			conn.close();
			System.out.println("bye bye");
		} catch (JMSException e) {
			System.out.println("JMSException "+e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void put(){
		System.out.println("put");
		try {
			
			Connection conn = connFact.createConnection("admin","admin");
			System.out.println("create session");
			conn.start();
			Session sess = (Session) conn.createSession(false,Session.AUTO_ACKNOWLEDGE);
			
			System.out.println("create producer");
			MessageProducer msgPro = sess.createProducer(dest);
			msgPro.setTimeToLive(0);
			System.out.println("createobject");
			TextMessage txtMsg = sess.createTextMessage("azzzz");
			System.out.println("send");
			msgPro.send(txtMsg);
			System.out.println("close");
			sess.close();
			conn.close();
			System.out.println("bye bye");
		} catch (JMSException e) {
			System.out.println("JMSException "+e.getMessage());
			e.printStackTrace();
		}
	}
}
