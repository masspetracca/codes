package it.ccg.portaladminejb.server;
import javax.ejb.Local;

@Local
public interface TestBeanLocal {

}
