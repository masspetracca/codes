package it.ccg.portaladminejb.bean.service;

import javax.ejb.Local;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class PAMPQueue
 */
@Stateless
@Local(PAMPQueueLocal.class)
public class PAMPQueue implements PAMPQueueLocal {

    /**
     * Default constructor. 
     */
    public PAMPQueue() {
        // TODO Auto-generated constructor stub
    }

}
