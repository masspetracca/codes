package it.ccg.portaladminejb.server.bean.eao;

import it.ccg.portaladminejb.server.bean.entity.BatchEntity;

import java.util.List;

public interface BatchEAOLocal {

	public List<BatchEntity> getAllJobs();
}
