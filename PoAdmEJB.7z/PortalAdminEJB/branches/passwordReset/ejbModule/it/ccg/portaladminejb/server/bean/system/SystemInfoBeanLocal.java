package it.ccg.portaladminejb.server.bean.system;

import java.util.List;

public interface SystemInfoBeanLocal {
	
	public List<String> listInstalledApps() throws Exception;

}
