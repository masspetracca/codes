package it.ccg.portaladminejb.server.logengine;

import it.ccg.portaladminejb.server.security.Security;

public class StandardLogMessage {
	
	private String currentUser;
	private String message;
	
	
	public StandardLogMessage(String message) {
		
		try {
			this.currentUser = Security.getCurrentUser();
		}
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
		this.message = message;
	}
	
	
	@Override
	public String toString() {
		
		return this.currentUser + "|" + this.message;
	}

}
