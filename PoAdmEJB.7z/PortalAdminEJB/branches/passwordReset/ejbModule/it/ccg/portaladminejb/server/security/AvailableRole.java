package it.ccg.portaladminejb.server.security;

public class AvailableRole {
	
	public static final String ADMIN = "admin";

}
