package it.ccg.portaladminejb.server.dto;

public class Role {
	
	private String role;
	
	
	public Role(String role) {
		this.role = role;
	}


	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}


	@Override
	public String toString() {
		
		return this.role;
	}


	@Override
	public boolean equals(Object o) {
		
		return this.role.equalsIgnoreCase(((Role)o).getRole());
	}
	
	
	
	

}
