package it.ccg.portaladminejb.server.logengine;

import org.apache.log4j.Logger;


public class PALoggerFactory {
	
	public static final String EJB_LOGGER = "portaladminejb.server.logger";
	public static final String WEB_LOGGER = "portaladminweb.server.logger";
	public static final String USER_LOGGER = "portaladminweb.server.user_logger";
	
	
	public static Logger getLogger(String loggerType){
		
		Logger logger = null;
		
		
		if(loggerType.equalsIgnoreCase(EJB_LOGGER)) {
			
			logger =  Logger.getLogger(EJB_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(WEB_LOGGER)) {
			
			logger =  Logger.getLogger(WEB_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(USER_LOGGER)) {
			
			logger =  Logger.getLogger(USER_LOGGER);
		}
		else {
			
			try {
				throw new Exception("loggerType \'" + loggerType + "\' not defined.");
			}
			catch (Exception e) {
				
				e.printStackTrace();
			}
			
		}
		
		
		return logger;
	}

}
