package it.ccg.portaladminejb.server.util;


import it.ccg.portaladminejb.server.logengine.StandardLogMessage;

import org.apache.log4j.Logger;

public class ExceptionUtil {
	
	
	public static void logCompleteStackTrace(Logger logger, Exception exception) {
		
		try {
			logger.error(new StandardLogMessage(exception.toString()));
			
			StackTraceElement[] stackTraceElements = exception.getStackTrace();
			for(StackTraceElement element : stackTraceElements) {
				logger.error(new StandardLogMessage(element.toString()));
			}
		}
		catch(Exception e) {
			
			logger.error(e.toString());
			
			StackTraceElement[] stackTraceElements = e.getStackTrace();
			for(StackTraceElement element : stackTraceElements) {
				logger.error(element.toString());
			}
		}
		
	}
	
	
}
