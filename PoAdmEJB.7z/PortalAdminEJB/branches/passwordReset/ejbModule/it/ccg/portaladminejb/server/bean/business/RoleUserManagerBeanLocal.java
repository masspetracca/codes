package it.ccg.portaladminejb.server.bean.business;

import java.util.Map;

public interface RoleUserManagerBeanLocal {
	
	public void saveUserRoleMatching(Map<String, String[]> userRolesMap) throws Exception;
	public void saveRoleUserMatching(Map<String, String[]> roleUsersMap) throws Exception;

}
