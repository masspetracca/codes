package it.ccg.portaladminejb.server.logengine;


import java.net.URL;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class Log4jSetup {
	
	private static Logger logger;
	
	
	public static void loadLog4JProperties() throws Exception {
		
		URL log4jPropertiesURL = Thread.currentThread().getContextClassLoader().getResource("log4j.xml");
		
		DOMConfigurator.configure(log4jPropertiesURL);
		
		logger = PALoggerFactory.getLogger(PALoggerFactory.EJB_LOGGER);
		
		logger.debug(new StandardLogMessage("PortalAdmin system Log4J properties successfully loaded from " + log4jPropertiesURL));
		
	}
	
	
}
