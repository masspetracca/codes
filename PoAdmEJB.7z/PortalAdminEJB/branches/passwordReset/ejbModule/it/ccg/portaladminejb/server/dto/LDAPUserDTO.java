package it.ccg.portaladminejb.server.dto;

public class LDAPUserDTO {

	private String cn;
	private String sn;
	private String uid;
	private String o = "ccg";
	private String c = "pamp";
	private String userpassword;
	private String mail;
	private String ou;
	
	public LDAPUserDTO() {
		
	}
	
	public LDAPUserDTO(String cn, String sn, String uid, String userpassword, String mail, String ou){
		this.cn=cn;
		this.sn=sn;
		this.uid=uid;
		this.userpassword=userpassword;
		this.mail = mail;
		this.ou = ou;
	}
	
	
	public LDAPUserDTO(String cn, String sn, String uid, String o, String c, String userpassword, String mail, String ou){
		this.cn=cn;
		this.sn=sn;
		this.uid=uid;
		this.o=o;
		this.c=c;
		this.userpassword=userpassword;
		this.mail = mail;
		this.ou = ou;
	}
	

	/**
	 * @return the cn
	 */
	public String getCn() {
		return cn;
	}

	/**
	 * @param cn the cn to set
	 */
	public void setCn(String cn) {
		this.cn = cn;
	}

	/**
	 * @return the sn
	 */
	public String getSn() {
		return sn;
	}

	/**
	 * @param sn the sn to set
	 */
	public void setSn(String sn) {
		this.sn = sn;
	}

	/**
	 * @return the uid
	 */
	public String getUid() {
		return uid;
	}

	/**
	 * @param uid the uid to set
	 */
	public void setUid(String uid) {
		this.uid = uid;
	}

	/**
	 * @return the o
	 */
	public String getO() {
		return o;
	}

	/**
	 * @param o the o to set
	 */
	public void setO(String o) {
		this.o = o;
	}

	/**
	 * @return the c
	 */
	public String getC() {
		return c;
	}

	/**
	 * @param c the c to set
	 */
	public void setC(String c) {
		this.c = c;
	}

	/**
	 * @return the userpassword
	 */
	public String getUserpassword() {
		return userpassword;
	}

	/**
	 * @param userpassword the userpassword to set
	 */
	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}


	public String getMail() {
		return mail;
	}


	public void setMail(String mail) {
		this.mail = mail;
	}


	public String getOu() {
		return ou;
	}


	public void setOu(String ou) {
		this.ou = ou;
	}
	
	
	@Override
	public String toString() {
		
		return "[cn: " + this.cn + ", sn: " + this.sn + ", uid: " + this.uid + ", o: " + this.o + ", c: " + this.c + ", mail: " + this.mail + ", ou: " + this.ou + "]";
	}
	
	
	@Override
	public boolean equals(Object o) {
		
		if(!(o instanceof LDAPUserDTO)) {
			
			return super.equals(o);
		}
		
		LDAPUserDTO rightObject = (LDAPUserDTO)o;
		
		
		return ("cn=" + this.getCn() + ",o=" + this.getO() + ",c=" + this.getC()).equalsIgnoreCase("cn=" + rightObject.getCn() + ",o=" + rightObject.getO() + ",c=" + rightObject.getC());
	}
	
	
}
