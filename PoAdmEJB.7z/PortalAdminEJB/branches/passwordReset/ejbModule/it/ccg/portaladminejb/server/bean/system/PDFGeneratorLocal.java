package it.ccg.portaladminejb.server.bean.system;

import it.ccg.portaladminejb.server.dto.LDAPUserDTO;
import it.ccg.portaladminejb.server.dto.Role;

import java.util.List;
import java.util.Map;

import javax.ejb.Local;

import com.lowagie.text.Document;

@Local
public interface PDFGeneratorLocal {

	public Document generatePdf(Map<LDAPUserDTO,List<Role>> map);
	public Map<LDAPUserDTO,List<Role>> populateMap();
	public void cleanTemporaryFile();
}
