package it.ccg.portaladminejb.server.logengine;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class LogService implements LogServiceInterface {
	
	
	//private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.EJB_LOGGER);
	

    /**
     * Default constructor. 
     */
    public LogService() {
		
		
    }
    

	@Override
	public List<Map<String, String>> getLogsListByType(String logType) throws Exception {
		
		// leggi la directory dei log e ritorna la lista dei nomi
		List<Map<String, String>> list = new ArrayList<Map<String,String>>();
		File file = new File(LogEngine.getLOG_FILE_DIR_ABSOLUTE_PATH());
		
		String[] fileArray = file.list();
		for(String fileName : fileArray) {
			if(fileName.startsWith(logType)) {
				Map<String, String> map = new HashMap<String, String>();
				map.put("logFileName", fileName);
				
				list.add(map);
			}
			
		}
		
		
		return list;
	}


	@Override
	public List<LogLineDTO> getLog(String logFileName, Map<String, String> filterParams) throws Exception {
		
		
		//String dateTime = filterParams.get("dateTime");
		String type = filterParams.get("type");
		String classMethod = filterParams.get("classMethod");
		String user = filterParams.get("user");
		String message = filterParams.get("message");
		
		// ex filtering
		/*// *****
		CriteriaParser criteriaParser = new CriteriaParser();
		List<CriteriaDTO> criteriaDTOList = criteriaParser.parse(dsRequest);
		// *****
		
		for(CriteriaDTO criteriaDTO : criteriaDTOList) {
			if(criteriaDTO.getFieldName().equalsIgnoreCase("type")) {
				type = (String)criteriaDTO.getValue();
			}
			else if(criteriaDTO.getFieldName().equalsIgnoreCase("classMethod")) {
				classMethod = (String)criteriaDTO.getValue();
			}
			else if(criteriaDTO.getFieldName().equalsIgnoreCase("user")) {
				user = (String)criteriaDTO.getValue();
			}
			else if(criteriaDTO.getFieldName().equalsIgnoreCase("message")) {
				subMessage = (String)criteriaDTO.getValue();
			}
		}*/
		
		
		LogReader logReader = new LogReader(LogEngine.getLOG_FILE_DIR_ABSOLUTE_PATH());
		
		List<LogLineDTO> log = logReader.getLog(logFileName, type, classMethod, user, message);
		
		
		// ex paging
		/*long totalRows = log.size();
        long startRow = (int)dsRequest.getStartRow();  
        long endRow = (int)dsRequest.getEndRow();
        endRow = Math.min(endRow, totalRows);
		
		log = log.subList((int)startRow, (int)endRow);
		
		
		dsResponse.setData(log);
		
		// Tell client what rows are being returned, and what's available
        dsResponse.setStartRow(startRow);
        dsResponse.setEndRow(endRow);  
        dsResponse.setTotalRows(totalRows);*/
        
		
		return log;
		
	}
    
    
    


}
