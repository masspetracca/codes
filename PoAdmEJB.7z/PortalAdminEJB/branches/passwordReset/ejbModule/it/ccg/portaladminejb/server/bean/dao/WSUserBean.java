package it.ccg.portaladminejb.server.bean.dao;

import it.ccg.portaladminejb.server.dto.LDAPUserDTO;
import it.ccg.portaladminejb.server.dto.WSUserDTO;
import it.ccg.portaladminejb.server.service.ldap.LDAPManager;
import it.ccg.portaladminejb.server.service.mBean.AppManagementMBean;
import it.ccg.portaladminejb.server.service.mBean.SecurityAdminMBean;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class WSUser
 */
@Stateless
@Local(WSUserBeanLocal.class)
public class WSUserBean implements WSUserBeanLocal {

    /**
     * Default constructor. 
     */
    public WSUserBean() {
        // TODO Auto-generated constructor stub
    }
    
    
	@Override
	public List<WSUserDTO> listWSUsers() throws Exception {
		
		SecurityAdminMBean securityAdminMBean = new SecurityAdminMBean();
		
		List<WSUserDTO> userList = securityAdminMBean.getUsers();
		
		
		return userList;
	}


	@Override
	public List<WSUserDTO> listRoleRelatedUsers(String role) throws Exception {
		
		AppManagementMBean appManagementMBean = new AppManagementMBean();
		
		List<String> userContextNameList = appManagementMBean.getRoleRelatedUsers(role);
		
		// *** 
		LDAPManager ldapManager = new LDAPManager();
		
		List<WSUserDTO> userList = new ArrayList<WSUserDTO>();
		
		LDAPUserDTO ldapUserDTO = null;
		
		for(String userContextName : userContextNameList) {
			
			ldapUserDTO = ldapManager.getUserByContextName(userContextName);
			
			userList.add(new WSUserDTO(ldapUserDTO.getCn(), ldapUserDTO.getO(), ldapUserDTO.getC(), ldapUserDTO.getUid()));
		}
		// ***
		
		
		return userList;
	}


	@Override
	public List<WSUserDTO> listRoleNotRelatedUsers(String role) throws Exception {
		
		List<WSUserDTO> tempList = this.listWSUsers();
		
		tempList.removeAll(this.listRoleRelatedUsers(role));
		
		
		return tempList;
	}

}
