package it.ccg.fpm.freader.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringTokenizer;

import it.ccg.fpm.freader.batch.DateUtils;
import it.ccg.fpm.freader.batch.PropertyFiles;

public class DataFileCompleto {
	 private static String ft;
	 private static String stl;
	 private static String wOUT;
	 private static String c;
	 private static String tok;
	 private static String is;
	 private static String s;
	 private static int swWAIT;
	 private static int swCLICK;

	 private static String sdate =null;
	 private static String sTime ="";
	 private static String sDate = "";
	 static DateUtils day = new DateUtils();
	private static String visK;
	private static String pre;
	private static String expr;
	private static String substitute;
	private static int swItem;


	
	
	DataFileCompleto() throws IOException{ 			
	 /**
	 * Elaborazione file .xml 
	 */
		//public static void main(String[] args) throws Exception {
		
		sdate = day.now();
		 
		 String sdateaaaa = sdate.substring(0, 4);
		 String sdatemm =   sdate.substring(5, 7);
		 String sdategg = sdate.substring(8, 10);
		
	 	 String stimehh = sdate.substring(11, 13);
		 String stimemm = sdate.substring(14, 16);
		 String stimess = sdate.substring(17, 19);
		
		 sDate = (sdateaaaa+sdatemm+sdategg);
		 sTime = (stimehh+stimemm+stimess);
		 System.out.println("date:"+sDate);
		 System.out.println("time:"+sTime);
		 
		 GetProperties();
		 DataFile();

	  
	  }	
	  private static void GetProperties() throws IOException {
		PropertyFiles pf = new PropertyFiles();
	  }


	private static void DataFile() throws FileNotFoundException {
		System.out.println("Inizio esecuzione <DataFileCompleto>");

		//read File
		BufferedReader in = new BufferedReader
	  			//(new FileReader("datiPM/"+"outFPM.txt"));
				(new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTFPM_FILE_INPUT()));
	  try {

		  File outValues = 
			  //new File("dati/"+"Selenium_tests.xml");
			  (new File(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTFIELDS_FILE_OUTPUT())); 
		  
		  
		  FileWriter writerValues = null;
		  
		  try {
			  
			  boolean deleted = false;							
		      if (outValues.exists()) {							
		    	  deleted = outValues.delete();						
		      }
		      else {
		    	  System.out.println("rimosso file da: " + outValues.getAbsolutePath() + ", " + deleted);							
		    	  writerValues = new FileWriter(outValues, false);
		      }
		  } catch  (IOException e) {e.printStackTrace();}
	      
		  //main			
		    swWAIT=0;
		    swCLICK=0;
		    wOUT= "";
			c="\n";
			
			System.out.println("<?xml version='1.0' encoding='UTF-8'?>");
			wOUT= "<?xml version='1.0' encoding='UTF-8'?>";
			writerValues.write(wOUT);
			
			System.out.println("<TUPampQA>");
			wOUT= "<TUPampQA>";
			writerValues.write(c+wOUT);
	
			
		    //string tokenizer
			while ((stl = in.readLine()) != null){
			    swWAIT=0;
			    swCLICK=0;
			    is=" ";
			    s= " ";
            	
				StringTokenizer f=new StringTokenizer(stl, "|");
			    				
			    //while tokens
				while(f.hasMoreTokens()) {
				    tok = (String) f.nextElement();
				    
				    expr = "fs";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "%3A";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "%20";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "x07C";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%22";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);				    

				    expr = "%24";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);				    

				    expr = "%26";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    

				    expr = "%3A";
				    substitute = "";
				    tok = tok.replaceAll(expr, substitute);


				    expr = "%3B";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "%3C";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "%3E";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%20";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
	
				    expr = "%26";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%27";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%3D";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%24";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%270";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);				    
				    
				    expr = "&quot;";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "nbsp;";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "span";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "%img";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				    
				    expr = "nobr";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "&lt;";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);

				    expr = "&gt;";
				     substitute = "";
				    tok = tok.replaceAll(expr, substitute);
				     
					//#test: RF45-NUC03-Tnn: element
					if (tok.contains("!--StartingTest") == true) {
						 System.out.println("<TUgroup>");
			     	     wOUT= "<TUgroup>";
					     writerValues.write(c+wOUT);
					     
						 wOUT= "";
						 System.out.println("<reqID>");
						 wOUT= "<reqID>";
						 writerValues.write(c+wOUT);

						 ft = tok;
			        	 //System.out.println(ft.substring(43, ft.length()));
						 System.out.println(ft.substring(13, ft.length()));
			        	 //wOUT= ft.substring(43, ft.length());
						 wOUT= ft.substring(15, ft.length());
						 writerValues.write(c+wOUT);
			      	
						 wOUT= "";
						 System.out.println("</reqID>");
						 wOUT= "</reqID>";
						 writerValues.write(wOUT);

						//date
						 wOUT= "";
						 System.out.println("<dateID>");
						 wOUT= "<dateID>";
						 writerValues.write(c+wOUT);

			        	 System.out.println(sDate+sTime);
			        	 wOUT= sDate+sTime;
			      		 writerValues.write(wOUT);
			      		 
						 wOUT= "";
						 System.out.println("</dateID>");
						 wOUT= "</dateID>";
						 writerValues.write(wOUT);
						 
					}
					if (tok.contains("#Killing Firefox") == true) {	
						 System.out.println("<TUgroup>");
			     	     wOUT= "<TUgroup>";
					     writerValues.write(c+wOUT);
					     
						 wOUT= "";
						 System.out.println("<reqID>");
						 wOUT= "<reqID>";
						 writerValues.write(c+wOUT);
			      	
						 wOUT= "";
						 System.out.println("</reqID>");
						 wOUT= "</reqID>";
						 writerValues.write(wOUT);

						 System.out.println("</TUgroup>");
			     	     wOUT= "</TUgroup>";
					     writerValues.write(c+wOUT);

					}
					   //#end: element
					if (tok.contains("#end") == true)  {
						System.out.println("</TUgroup>");
				   	    wOUT= "</TUgroup>";
						 writerValues.write(c+wOUT);
					}

					//open url: element
					 if (tok.contains("open ")  == true) {						 
					     wOUT= "";
						 System.out.println("<openURL>");
						 wOUT= "<openURL>";
						 writerValues.write(c+wOUT);
						 
						 //next element searching to write <openURL>url</openURL>
     					 tok = (String) f.nextElement();
						 
     					 //url
     					 ft = tok;
			        	 System.out.println(ft);
			        	 wOUT= ft;
			      		 writerValues.write(wOUT);
			      		 
						 wOUT= "";
						 System.out.println("</openURL>");
						 wOUT= "</openURL>";
						 writerValues.write(wOUT);
						 wOUT= "";
					}

					 
					is=" ";
					//object: meta content to analyse 
					if (tok.contains("ListGrid")  == true){
						 is = "ListGrid";				
					}
					if (tok.contains("DynamicForm")  == true){
						 is = "DynamicForm";				
					}
					if (tok.contains("Portlet")  == true){
						 is = "Portlet";				
					}
					if (tok.contains("TreeGrid")  == true){
						 is = "TreeGrid";				
					}
					if (tok.contains("VStack")  == true){
						 is = "VStack";				
					}
					if (tok.contains("TabSet")  == true){
						 is = "TabSet";				
					}
					if (tok.contains("Window")  == true){
						 is = "Window";				
					}



	   			   //sw environments
					if (tok.contains("waitForElementCl") == true) {
						swWAIT = 1;
						swCLICK = 0;
					}
					
					if (tok.contains("click ") == true) {
						swWAIT = 0;
						swCLICK = 1;
					}

					if ((tok.contains("clickAndWait") == true)  
					&& (tok.contains("id=submitLabel") == true)) {
						swWAIT = 0;
						swCLICK = 0;
					}
					
					//clickAndWait: element
					if (tok.contains("clickAndWait") == true)  {
					     wOUT= "";
						 System.out.println("<clickAndWait>");
						 wOUT= "<clickAndWait>";
						 writerValues.write(c+wOUT);

						 //id=submitLabel (successivo clickAndWait)
						 wOUT= "";
						 ft=(String) f.nextElement();
			        	 System.out.println(ft);
			        	 wOUT= ft;
			      		 writerValues.write(wOUT);

						 wOUT= "";
						 System.out.println("</clickAndWait>");
						 wOUT= "</clickAndWait>";
						 writerValues.write(c+wOUT);
					 }


	   			   //waitForElementClickable: elements
					if (swWAIT == 1) {
						if ((tok.contains("waitForElementCl") == true)  
						|| (tok.contains("/row")  == true)
						|| (tok.contains("/col")  == true)
						|| (tok.contains("=//")  == true)
//					    && (tok.contains("classIndex=")  == true))
//						|| (tok.contains("scRole=")  == true)
//						|| (tok.contains("title=")  == true)
						|| (tok.contains("#end:")  == true)
						|| (tok.contains("value=")  == true)
					    || (tok.contains("Class=DateItem")  == true)
					    || (tok.contains("Class=ComboBoxItem")  == true)
					    || (tok.contains("Class=CheckboxItem")  == true)
					    || (tok.contains("Class=TextAreaItem")  == true)
					    || (tok.contains("Class=SelectItem")  == true)
//					    || (tok.contains("_TextAreaItem")  == true)
//					    || (tok.contains("_CheckboxItem")  == true)
					    || (tok.contains("ListGrid")  == true)
					    || (tok.contains("Class=MiniDateRangeItem")  == true)
					    || (tok.contains("Class=DateRangeItem")  == true)
					    || (tok.contains("Class=RelativeDateItem")  == true)
					    || (tok.contains("Class=SndIntLn")  == true)
//					    || (tok.contains("/body/")  == true)
//					    || (tok.contains("/header/")  == true)
//					    || (tok.contains("/headerButton")  == true)
						|| (tok.contains("!--")  == true)
					    || (tok.contains("scLocator=//Portlet")  == true)
					    || (tok.contains("scLoca")  == true)
					    || (tok.contains("value")  == true) 
					    || (tok.contains("item[name=")  == true) 
					    || (tok.contains("id=submitLabel")  == true)
						){
							waitELEM();
							writerValues.write(s);
							s="";
						}
					}
					
					  
				   //click: elements
					if (swCLICK == 1) {
						if ((tok.contains("click ") == true)  
								|| (tok.contains("/row")  == true)
								|| (tok.contains("/col")  == true)
								|| (tok.contains("=//")  == true)
//							    && ((tok.contains("classIndex=")  == true))
//								|| (tok.contains("scRole=")  == true)
//								|| (tok.contains("title=")  == true)
								|| (tok.contains("#end:")  == true)
								|| (tok.contains("value=")  == true)
							    || (tok.contains("Class=DateItem")  == true)
							    || (tok.contains("Class=ComboBoxItem")  == true)
							    || (tok.contains("Class=CheckboxItem")  == true)
							    || (tok.contains("Class=TextAreaItem")  == true)
							    || (tok.contains("Class=SelectItem")  == true)
//							    || (tok.contains("_TextAreaItem")  == true)
//							    || (tok.contains("_CheckboxItem")  == true)
							    || (tok.contains("ListGrid")  == true)
							    || (tok.contains("Class=MiniDateRangeItem")  == true)
							    || (tok.contains("Class=DateRangeItem")  == true)
							    || (tok.contains("Class=RelativeDateItem")  == true)
							    || (tok.contains("Class=SndIntLn")  == true)
//							    || (tok.contains("/body/")  == true)
//							    || (tok.contains("/header/")  == true)
//							    || (tok.contains("/headerButton")  == true)
								|| (tok.contains("!--")  == true)
							    || (tok.contains("scLocator=//Portlet")  == true)
							    || (tok.contains("scLoca")  == true)
							    || (tok.contains("value")  == true) 
							    || (tok.contains("item[name=")  == true) 
							    || (tok.contains("id=submitLabel")  == true)
								){
							clickELEM();
							writerValues.write(s);
							s="";
						}
					}


				} //end while readDATA	
			} //closing
			
			System.out.println("</TUPampQA>");
	   	    wOUT= "</TUPampQA>";
	   	    writerValues.write(c+wOUT);

			in.close();
			writerValues.close();
			System.out.println("Fine esecuzione <DataFileCompleto> - estrazione : File Data");
			//end while read  
	  } catch (IOException e) { e.printStackTrace();}
	}
	
	private static void clickELEM() {

		//click: element
		if (tok.contains("click ") == true)  {
		   wOUT= "";
		   System.out.println("<response>click</response>");
		   wOUT= "<response>click</response>";
		   s   =  c+wOUT;
		   wOUT= "";
		}
		
//		//node: <element>
//	    if ((tok.contains("=//")  == true)
//    &&  (tok.contains("//Portlet")  == true)) {
//		   wOUT= "";
//		   System.out.println("<nodeName>"+is+"</nodeName>");
//		   wOUT= "<nodeName>"+is+"</nodeName>";
//		   s   +=  c+wOUT;
//	 }

		
	    //node: title=
		if ((tok.contains("title=")  == true)
		&& (tok.contains("Untitled Button")  == true)){
			//continue
			;
		}
		  
//	    //node: title=
//		if ((tok.contains("title=")  == true) 
//		&& (tok.contains("Untitled Button")  == false)
//		&& (tok.contains("title=Month")  == false) 
//		&& (tok.contains("title=Section")  == false)) {
//		   wOUT= "";
//		   System.out.println("<nodeType>"+tok.substring(6, tok.length())+"</nodeType>");
//		   wOUT= "<nodeType>"+tok.substring(6, tok.length())+"</nodeType>";
//		   s   +=  c+wOUT;
//		}
//		
		
	    //node: title=
		if (tok.contains("type=")  == true) { 
		   wOUT= "";
		   System.out.println("<nodeType>"+tok.substring(6, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(6, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;
		}
		   
	    //name: General=		
		if (tok.contains("name=General")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>General</nodeChild>");
		   wOUT= "<nodeChild>General</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
		
	    //name: Comp.=		
		if (tok.contains("name=Comp.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Comp.</nodeChild>");
		   wOUT= "<nodeChild>Comp.</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Haircut=		
		if (tok.contains("name=Haircut")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Haircut</nodeChild>");
		   wOUT= "<nodeChild>Haircut</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: ID=		
		if (tok.contains("ID=")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeName>Portlet</nodeName>");
		   wOUT= "<nodeName>Portlet</nodeName>";
		   s   +=  c+wOUT;		   
		   wOUT= "";
		   System.out.println("<nodeType>PortletID</nodeType>");
		   wOUT= "<nodeType>PortletID</nodeType>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: HC=		
		if (tok.contains("name=HC")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>HC</nodeChild>");
		   wOUT= "<nodeChild>HC</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Equities=		
		if (tok.contains("name=Equities")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Equities</nodeChild>");
		   wOUT= "<nodeChild>Equities</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Eq.=		
		if (tok.contains("name=Eq.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Eq.</nodeChild>");
		   wOUT= "<nodeChild>Eq.</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Back=		
		if (tok.contains("name=Back")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Back</nodeChild>");
		   wOUT= "<nodeChild>Back</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Equity=		
		if (tok.contains("name=Equity")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Equity</nodeChild>");
		   wOUT= "<nodeChild>Equity</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	    //name: Bond=		
		if (tok.contains("name=Bond")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Bond</nodeChild>");
		   wOUT= "<nodeChild>Bond</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	    //name: Bond=		
		if (tok.contains("name=iBond")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>iBond</nodeChild>");
		   wOUT= "<nodeChild>iBond</nodeChild>";
		   s   +=  c+wOUT;		   
		}
   
		//name: ListGrid
		if ((tok.contains("ListGrid")  == true)  
	&&	(tok.contains("scRole=list")  == false))  {
		   wOUT= "";
		   System.out.println("<nodeName>ListGrid</nodeName>");
		   wOUT= "<nodeName>ListGrid</nodeName>";
		   s   +=  c+wOUT;		   
		}	

		///item[name= && 'ListGrid'
		if ((tok.contains("/item[name=")  == true)
		&& (tok.contains("ListGrid")  == true)) {
//		   System.out.println("<nodeType>"+tok.substring(102, tok.length())+"</nodeType>");
//		   wOUT= "<nodeType>"+tok.substring(102, tok.length())+"</nodeType>";
			   System.out.println("<nodeType>"+tok.substring(89, tok.length())+"</nodeType>");
			   wOUT= "<nodeType>"+tok.substring(89, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;		   
		   wOUT= "";			
		}
		
		//name: Class=MiniDateRangeItem
		if (tok.contains("Class=MiniDateRangeItem")  == true) { 
		   wOUT= "";
		   System.out.println("<nodeName>MiniDateRangeItem</nodeName>");
		   wOUT= "<nodeName>MiniDateRangeItem</nodeName>";
		   s   +=  c+wOUT;
		   if (tok.contains("showDateRange")  == true) {
			   wOUT= "";
			   System.out.println("<nodeType>showDateRange</nodeType>");
			   wOUT= "<nodeType>showDateRange</nodeType>";
			   s   +=  c+wOUT;		   
			}
		   if (tok.contains("rangeDialog/rangeForm")  == true) {
			   wOUT= "";
			   System.out.println("<nodeType>REF_DT</nodeType>");
			   wOUT= "<nodeType>REF_DT</nodeType>";
			   s   +=  c+wOUT;		   
			}
		   if (tok.contains("rangeDialog/okButton")  == true) {
			   wOUT= "";
			   System.out.println("<nodeType>okButton</nodeType>");
			   wOUT= "<nodeType>okButton</nodeType>";
			   s   +=  c+wOUT;		   
			}

		}

		
	    //name: Class=DateRangeItem
		if (tok.contains("Class=DateRangeItem")  == true) { 
		   wOUT= "";
		   System.out.println("<nodeName>DateRangeItem</nodeName>");
		   wOUT= "<nodeName>DateRangeItem</nodeName>";
		   s   +=  c+wOUT;		   
		   wOUT= "";		   
		   
		   if (tok.contains("item[name=toField")  == true) { 
			   System.out.println("<nodeType>toField</nodeType>");
			   wOUT= "<nodeType>toField</nodeType>";
			   s   +=  c+wOUT;		   
			   wOUT= "";
		   }
		   
		   if (tok.contains("item[name=fromField")  == true) { 
			   System.out.println("<nodeType>fromField</nodeType>");
			   wOUT= "<nodeType>fromField</nodeType>";
			   s   +=  c+wOUT;		   
			   wOUT= "";
		   }
		}//end name

		//name: value
	    if ((tok.contains("item[name=toField")  == true) 
	    || (tok.contains("item[name=fromField")  == true)) {
	    	swItem=1;
	    }
	    
		if ((swItem==1)     
		&& (tok.contains("value")  == true)) {    
		   System.out.println("<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>");
		   wOUT= "<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>";
		   s   +=  c+wOUT;		   
		   wOUT= "";
		   swItem=0;
		}


		
	    //name: Class=RelativeDateItem
		if (tok.contains("RelativeDateItem")  == true) { 
		   wOUT= "";
		   System.out.println("<nodeName>RelativeDateItem</nodeName>");
		   wOUT= "<nodeName>RelativeDateItem</nodeName>";
		   s   +=  c+wOUT;		   
		   wOUT= "";		
		}//end name

		//item[name=toField
		if (tok.contains("item[name=toField")  == true) {
		   System.out.println("<nodeType>toField</nodeType>");
		   wOUT= "<nodeType>toField</nodeType>";
		   s   +=  c+wOUT;		   
		   wOUT= "";			
		}
		
		//item[name=fromField
		if (tok.contains("item[name=fromField")  == true) {
			   System.out.println("<nodeType>fromField</nodeType>");
			   wOUT= "<nodeType>fromField</nodeType>";
			   s   +=  c+wOUT;		   
			   wOUT= "";			
		}
		
		//value
		if ((tok.contains("value")  == true)) {    
		   System.out.println("<nodeChild>value</nodeChild>");
		   wOUT= "<nodeChild>value</nodeChild>";
		   s   +=  c+wOUT;		   
		   wOUT= "";
		 }		

		///item[name= && 'ListGrid'
		if ((tok.contains("/item[name=")  == true)
		&& (tok.contains("ListGrid")  == true)) {
//		   System.out.println("<nodeType>"+tok.substring(102, tok.length())+"</nodeType>");
//		   wOUT= "<nodeType>"+tok.substring(102, tok.length())+"</nodeType>";
			   System.out.println("<nodeType>"+tok.substring(89, tok.length())+"</nodeType>");
			   wOUT= "<nodeType>"+tok.substring(89, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;		   
		   wOUT= "";			
		}
		
		
		//name: Class=DynamicForm && classIndex=
		if (tok.contains("Class=DynamicForm")  == true) { 
//		&& (tok.contains("classIndex=")  == true))  {
		   wOUT= "";
		   System.out.println("<nodeName>DynamicForm</nodeName>");
		   wOUT= "<nodeName>DynamicForm</nodeName>";
		   s   +=  c+wOUT;		   
		}

		//name: Eq. Condifence parameters=		
		if (tok.contains("name=Eq. Condifence parameters")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Eq. Condifence parameters</nodeChild>");
		   wOUT= "<nodeChild>Eq. Condifence parameters</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Static=		
		if (tok.contains("name=Static")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Static</nodeChild>");
		   wOUT= "<nodeChild>Static</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: Stress=		
		if (tok.contains("name=Stress")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Stress</nodeChild>");
		   wOUT= "<nodeChild>Stress</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: S.T.=		
		if (tok.contains("name=S.T.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>S.T.</nodeChild>");
		   wOUT= "<nodeChild>S.T.</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
		
	    //name: Ix.=		
		if (tok.contains("name=Ix.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Ix.</nodeChild>");
		   wOUT= "<nodeChild>Ix.</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Curr.=		
		if (tok.contains("name=Curr.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Curr.</nodeChild>");
		   wOUT= "<nodeChild>Curr.</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	    //name: Type=		
		if (tok.contains("name=Type")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Type</nodeChild>");
		   wOUT= "<nodeChild>Type</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Currency=		
		if (tok.contains("name=Currency")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Currency</nodeChild>");
		   wOUT= "<nodeChild>Currency</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Risk=		
		if (tok.contains("name=Risk")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Risk</nodeChild>");
		   wOUT= "<nodeChild>Risk</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	    //name: Indices=		
		if (tok.contains("name=Indices")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Indices</nodeChild>");
		   wOUT= "<nodeChild>Indices</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	    //name: Instr=		
		if (tok.contains("name=Instr.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Instr.</nodeChild>");
		   wOUT= "<nodeChild>Instr.</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: B.T.=		
		if (tok.contains("name=B.T.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>B.T.</nodeChild>");
		   wOUT= "<nodeChild>B.T.</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: Bankstaticdata		
		if (tok.contains("name=Bankstaticdata")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Bankstaticdata</nodeChild>");
		   wOUT= "<nodeChild>Bankstaticdata</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Bankbalancehistory		
		if (tok.contains("name=Bankbalancehistory")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Bankbalancehistory</nodeChild>");
		   wOUT= "<nodeChild>Bankbalancehistory</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Bankapprovedratinghistory		
		if (tok.contains("name=Bankapprovedratinghistory")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Bankapprovedratinghistory</nodeChild>");
		   wOUT= "<nodeChild>Bankapprovedratinghistory</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Ratingtranscode		
		if (tok.contains("name=Ratingtranscode")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Ratingtranscode</nodeChild>");
		   wOUT= "<nodeChild>Ratingtranscode</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Riskcommittee		
		if (tok.contains("name=Riskcommittee")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Riskcommittee</nodeChild>");
		   wOUT= "<nodeChild>Riskcommittee</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Parameterselection		
		if (tok.contains("name=Parameterselection")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Parameterselection</nodeChild>");
		   wOUT= "<nodeChild>Parameterselection</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Ratingsproposal		
		if (tok.contains("name=Ratingsproposal")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Ratingsproposal</nodeChild>");
		   wOUT= "<nodeChild>Ratingsproposal</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Linearregressionsettings		
		if (tok.contains("name=Linearregressionsettings")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Linearregressionsettings</nodeChild>");
		   wOUT= "<nodeChild>Linearregressionsettings</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Scheduler		
		if (tok.contains("name=Scheduler")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Scheduler</nodeChild>");
		   wOUT= "<nodeChild>Scheduler</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Logviewer		
		if (tok.contains("name=Logviewer")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Logviewer</nodeChild>");
		   wOUT= "<nodeChild>Logviewer</nodeChild>";
		   s   +=  c+wOUT;		   
		}


	    //name: Comparables=		
		if (tok.contains("Comparables")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Comparables</nodeChild>");
		   wOUT= "<nodeChild>Comparables</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	    //name: Scheduler=		
		if (tok.contains("Scheduler")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Scheduler</nodeChild>");
		   wOUT= "<nodeChild>Scheduler</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: Reports=		
		if (tok.contains("name=Reports")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Reports</nodeChild>");
		   wOUT= "<nodeChild>Reports</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: Eq. Confidence parameters=		
		if (tok.contains("Eq. Confidence parameters")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Eq. Confidence parameters</nodeChild>");
		   wOUT= "<nodeChild>Eq. Confidence parameters</nodeChild>";
		   s   +=  c+wOUT;		   
		}
 
		//name: EquityDerivatives=		
		if (tok.contains("EquityDerivatives")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>EquityDerivatives</nodeChild>");
		   wOUT= "<nodeChild>EquityDerivatives</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: Bond=		
		if (tok.contains("Bond")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Bond</nodeChild>");
		   wOUT= "<nodeChild>Bond</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: Bond=		
		if (tok.contains("Bond")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Bond</nodeChild>");
		   wOUT= "<nodeChild>Bond</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: iBond=		
		if (tok.contains("iBond")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>iBond</nodeChild>");
		   wOUT= "<nodeChild>iBond</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
		//name: Indices=		
		if (tok.contains("Indices")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Indices</nodeChild>");
		   wOUT= "<nodeChild>Indices</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: Currency=		
		if (tok.contains("Currency")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Currency</nodeChild>");
		   wOUT= "<nodeChild>Currency</nodeChild>";
		   s   +=  c+wOUT;		   
		}
 
		//name: RiskEngine=		
		if (tok.contains("RiskEngine")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>RiskEngine</nodeChild>");
		   wOUT= "<nodeChild>RiskEngine</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: StressTest=		
		if (tok.contains("StressTest")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>StressTest</nodeChild>");
		   wOUT= "<nodeChild>StressTest</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: RiskEngine=		
		if (tok.contains("RiskEngine")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>RiskEngine</nodeChild>");
		   wOUT= "<nodeChild>RiskEngine</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: BackTest=		
		if (tok.contains("BackTest")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>BackTest</nodeChild>");
		   wOUT= "<nodeChild>BackTest</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: Comparables=		
		if (tok.contains("Comparables")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Comparables</nodeChild>");
		   wOUT= "<nodeChild>Comparables</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
		//name: General=		
		if (tok.contains("General")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>General</nodeChild>");
		   wOUT= "<nodeChild>General</nodeChild>";
		   s   +=  c+wOUT;		   
		}

         
//	    //node: title=Month		
//		if (tok.contains("title=Month")  == true)  {
//		   wOUT= "";
//		   System.out.println("<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>");
//		   wOUT= "<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>";
//		   s   +=  c+wOUT;		   
//		}
//
//		
//	    //node: title=Section		
//		if (tok.contains("title=Section")  == true)  {
//		   wOUT= "";
//		   System.out.println("<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>");
//		   wOUT= "<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>";
//		   s   +=  c+wOUT;   
//		}

//	
//		//node: Class=RecordEditor
//		if (tok.contains("Class=RecordEditor")  == true){
//		   wOUT= "";
//		   System.out.println("<nodeChild>RecordEditor</nodeChild>");
//		   wOUT= "<nodeChild>RecordEditor</nodeChild>";
//		   s   +=  c+wOUT;
//		}

		
//		//node: ID=
//		if (tok.contains("[ID=")  == true){
//		   wOUT= "";
//		   System.out.println("<nodeType>"+tok.substring(25, 38)+"</nodeType>");
//		   wOUT= "<nodeType>"+tok.substring(25, 38)+"</nodeType>";
//		   s   +=  c+wOUT;
//		   wOUT= "";
//		}

//		//node: item[
//		if (tok.contains("item[")  == true){
//		   System.out.println("<nodeType>"+tok.substring(41, 49)+"</nodeType>");
//		   wOUT= "<nodeType>"+tok.substring(41, 49)+"</nodeType>";
//		   s   +=  c+wOUT;
//		   wOUT= "";
//		}

//		//node: ITEM_ID &&  body/row
//		if ((tok.contains("ITEM_ID=")  == true)
//	&&   (tok.contains("/body/row")  == true)) {
//		   System.out.println("<nodeType>"+tok.substring(30, tok.length())+"</nodeType>");
//		   wOUT= "<nodeType>"+tok.substring(30, tok.length())+"</nodeType>";
//		   s   +=  c+wOUT;
//		   wOUT= "";
//		}
		//node: ITEM_ID &&  body/row
		if ((tok.contains("ITEM_ID=")  == true)
	&&   (tok.contains("/body/row")  == true) 
	&&   (tok.contains("Class=DateItem")  == false) 
	&&   (tok.contains("Class=MiniDateRangeItem")  == false) 
	&&   (tok.contains("Class=DateRangeItem")  == false) 
	&&   (tok.contains("Class=RelativeDateItem")  == false) 
	&&   (tok.contains("Class=SndIntLnk")  == false) 
	&&   (tok.contains("Class=LCHFails")  == false) 
	&&   (tok.contains("Class=ComboBoxItem")  == false) 
	&&   (tok.contains("Class=CheckboxItem")  == false) 
	&&   (tok.contains("Class=SelectItem")  == false) 
	&&   (tok.contains("Class=ListGrid")  == false) 
	&&    (tok.contains("Class=EodCshCll")  == false)) {
		   System.out.println("<nodeType>"+tok.substring(30, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(30, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;
		   wOUT= "";
		}


		//node: CASH_AMNT=
		if (tok.contains("CASH_AMNT=")  == true) {
  		   System.out.println("<nodeName>CASH_AMNT</nodeName>");
		   wOUT= "<nodeName>CASH_AMNT</nodeName>";
		   s   +=  c+wOUT;
		   wOUT= "";
  		   System.out.println("<nodeType>"+tok.substring(30, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(30, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;
		   wOUT= "";
		}


		//node: EodCshCll=
		if (tok.contains("EodCshCll=")  == true) {
  		   System.out.println("<nodeName>EodCshCll</nodeName>");
		   wOUT= "<nodeName>EodCshCll</nodeName>";
		   s   +=  c+wOUT;
		   wOUT= "";
  		   System.out.println("<nodeType>"+tok.substring(30, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(30, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;
		   wOUT= "";
		}

		//node: REF_DT
		if ((tok.contains("REF_DT")  == true) 
		&&  (tok.contains("/body/row[REF_DT=") == true)) {
//		|| (tok.contains("name=REF_DT")  == true)
//		|| (tok.contains("title=REF_DT")  == true))) {
		   System.out.println("<nodeType>REF_DT</nodeType>");
		   wOUT= "<nodeType>REF_DT</nodeType>";
		   s   +=  c+wOUT;
		   wOUT= "";
  		   System.out.println("<nodeChild>"+tok.substring(83, tok.length())+"</nodeChild>");
		   wOUT= "<nodeChild>"+tok.substring(83, tok.length())+"</nodeChild>";
		   s   +=  c+wOUT;
		   wOUT= "";
		}
		
		
		//node: value=
		if (tok.contains("value=")  == true){
		   wOUT= "";
		   System.out.println("<nodeType>"+tok.substring(6, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(6, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;
		}

//
//	    //name=		
//		if (tok.contains("name=")  == true)  {
//		   wOUT= "";
//		   System.out.println("<nodeType>"+tok.substring(51, tok.length())+"</nodeType>");
//		   wOUT= "<nodeType>"+tok.substring(51, tok.length())+"</nodeType>";
//		   s   +=  c+wOUT;		   
//		}
		
	    //node: Class=Portlet
		if ((tok.contains("Class=Portlet")  == true) 
	||  (tok.contains("scLoca")  == true)) {
		   wOUT= "";
		   System.out.println("<nodeName>Portlet</nodeName>");
		   wOUT= "<nodeName>Portlet</nodeName>";
		   s   +=  c+wOUT;	
		}
		  
		  
	    //node: ID="Portlet:Portlet"
		if ((tok.contains("scLocator=//Portlet")  == true) 
		&& (tok.contains("filterEditor")  == true)) {
		   wOUT= "";
		   System.out.println("<nodeType>Portlet:filterEditor</nodeType>");
		   wOUT= "<nodeType>Portlet:filterEditor</nodeType>";
		   s   +=  c+wOUT;   
		}
			
		//Portlet[ID=
		if (tok.contains("//Portlet[ID=")  == true){
		   wOUT= "";
		   System.out.println("<nodeChild>liquidity_ord</nodeChild>");
		   wOUT= "<nodeChild>liquidity_ord</nodeChild>";
		   s   +=  c+wOUT;
		   wOUT= "";
		}
		  	
		//node: TextAreaItem
		if (tok.contains("_TextAreaItem")  == true) {
		   wOUT= "";
		   System.out.println("<nodeType>TextAreaItem</nodeType>");
		   wOUT= "<nodeType>TextAreaItem</nodeType>";
		   s   +=  c+wOUT;
		   
		}

	    //node: CheckboxItem
		if (tok.contains("_CheckboxItem")  == true) {
		   wOUT= "";
		   System.out.println("<nodeType>CheckboxItem</nodeType>");
		   wOUT= "<nodeType>CheckboxItem</nodeType>";
		   s   +=  c+wOUT;

		}

	    //node: function
		if (tok.contains("!--")  == true) {
		   wOUT= "";
		   System.out.println("<nodeType>"+tok.substring(3, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(3, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;

		}





	    //node: [INSTRID=
		if (tok.contains("[INSTRID=")  == true)  {
		   wOUT= "";
		   String str = tok.valueOf(tok.substring(0, tok.length()));
		  
		   String[] set = str.split("INSTRID=");
		   pre = "INSTRID=";
		   for(int k=0;k<set.length;++k)
		   {
			visK  = set[k];
		   }
		   int iMAX = 5;
		   if (iMAX<5) {
			  iMAX=0; 
		   }
		   if (iMAX>=5) {
			   System.out.println("<nodeType>"+pre+visK.substring(0, iMAX)+"</nodeType>");
			   wOUT= "<nodeType>"+pre+visK.substring(0, iMAX)+"</nodeType>";
			   s   +=  c+wOUT;   
		   }
		}	

//	    //node: INSTRNAME=
//		if (tok.contains("INSTRNAME=")  == true)  {
//		   wOUT= "";
//		   String str = tok.valueOf(tok.substring(0, tok.length()));
//		  
//		   String[] set = str.split("INSTRNAME=");
//		   pre = "INSTRNAME=";
//		   for(int k=0;k<set.length;++k)
//		   {
//			visK  = set[k];
//		   }
//		   int iMAX = 25;
//		   if (iMAX<25) {
//			  iMAX=0; 
//		   }
//		   if (iMAX>=25) {
//			   System.out.println("<nodeChild>"+pre+visK.substring(0, iMAX)+"</nodeChild>");
//			   wOUT= "<nodeChild>"+pre+visK.substring(0, iMAX)+"</nodeChild>";
//			   s   +=  c+wOUT;   
//		   }
//		}	

	    //node: ISINCODE=
		if (tok.contains("ISINCODE=")  == true)  {
		   wOUT= "";
		   String str = tok.valueOf(tok.substring(0, tok.length()));
		  
		   String[] set = str.split("ISINCODE=");
		   pre = "ISINCODE=";
		   for(int k=0;k<set.length;++k)
		   {
			visK  = set[k];
		   }
		   int iMAX = 12;
		   if (iMAX<12) {
			  iMAX=0; 
		   }
		   if (iMAX>=12) {
			   System.out.println("<nodeType>"+pre+visK.substring(0, iMAX)+"</nodeType>");
			   wOUT= "<nodeType>"+pre+visK.substring(0, iMAX)+"</nodeType>";
			   s   +=  c+wOUT;   
		   }
		}	

		
	}
	
	private static void waitELEM() {

		//wait element
		if (tok.contains("waitForElementCl") == true)  {
		    System.out.println("<response>post</response>");
		    wOUT= "<response>post</response>";
		    s   =  c+wOUT;
			wOUT= "";
		}

//		//node: <element>
//	    if ((tok.contains("=//")  == true)
//    &&  (tok.contains("//Portlet")  == true)) {
//		   wOUT= "";
//		   System.out.println("<nodeName>"+is+"</nodeName>");
//		   wOUT= "<nodeName>"+is+"</nodeName>";
//		   s   +=  c+wOUT;
//	 }
		  

	    //node: title=
		if ((tok.contains("title=")  == true)
		&& (tok.contains("Untitled Button")  == true)){
			//continue
			;
		}
		
	    //node: title=
		if (tok.contains("type=")  == true) { 
		   wOUT= "";
		   System.out.println("<nodeType>"+tok.substring(6, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(6, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;
		}	
		
//	    //node: title=
//		if ((tok.contains("title=")  == true) 
//		&& (tok.contains("Untitled Button")  == false)
//		&& (tok.contains("title=Month")  == false)
//		&& (tok.contains("title=Section")  == false)) {
//		   wOUT= "";
//		   System.out.println("<nodeType>"+tok.substring(6, tok.length())+"</nodeType>");
//		   wOUT= "<nodeType>"+tok.substring(6, tok.length())+"</nodeType>";
//		   s   +=  c+wOUT;
//		}
	
//	    //node: title=		
//		if (tok.contains("title=Month")  == true)  {
//		   wOUT= "";
//		   System.out.println("<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>");
//		   wOUT= "<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>";
//		   s   +=  c+wOUT;
//		   
//
//		}
		
		
	    //name: Comp.=		
		if (tok.contains("name=Comp.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Comp.</nodeChild>");
		   wOUT= "<nodeChild>Comp.</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Comparables=		
		if (tok.contains("Comparables")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Comparables</nodeChild>");
		   wOUT= "<nodeChild>Comparables</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Haircut=		
		if (tok.contains("name=Haircut")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Haircut</nodeChild>");
		   wOUT= "<nodeChild>Haircut</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: ID=		
		if (tok.contains("ID=")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeName>Portlet</nodeName>");
		   wOUT= "<nodeName>Portlet</nodeName>";
		   s   +=  c+wOUT;		   
		   wOUT= "";
		   System.out.println("<nodeType>PortletID</nodeType>");
		   wOUT= "<nodeType>PortletID</nodeType>";
		   s   +=  c+wOUT;
		 }
		
		
	    //name: HC=		
		if (tok.contains("name=HC")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>HC</nodeChild>");
		   wOUT= "<nodeChild>HC</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Equities=		
		if (tok.contains("name=Equities")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Equities</nodeChild>");
		   wOUT= "<nodeChild>Equities</nodeChild>";
		   s   +=  c+wOUT;		   
		}
	    //name: Eq.=		
		if (tok.contains("name=Eq.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Eq.</nodeChild>");
		   wOUT= "<nodeChild>Eq.</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Back=		
		if (tok.contains("name=Back")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Back</nodeChild>");
		   wOUT= "<nodeChild>Back</nodeChild>";
		   s   +=  c+wOUT;		   
		}
	    //name: Equity=		
		if (tok.contains("name=Equity")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Equity</nodeChild>");
		   wOUT= "<nodeChild>Equity</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	    //name: Bond=		
		if (tok.contains("name=Bond")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Bond</nodeChild>");
		   wOUT= "<nodeChild>Bond</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	    //name: iBond=		
		if (tok.contains("name=iBond")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>iBond</nodeChild>");
		   wOUT= "<nodeChild>iBond</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//
//	    //name: scRole=		
//		if ((tok.contains("scRole=")  == true)  
//		&& (tok.contains("scRole=list"))  == false)  {
//		   wOUT= "";
//		   System.out.println("<nodeName>"+tok.substring(7, 13)+"</nodeName>");
//		   wOUT= "<nodeName>"+tok.substring(7, 13)+"</nodeName>";
//		   s   +=  c+wOUT;		   
//		}
		
		
	    //name: Class=ComboBoxItem
		if (tok.contains("Class=ComboBoxItem")  == true) { 
		   wOUT= "";
		   System.out.println("<nodeName>ComboBoxItem</nodeName>");
		   wOUT= "<nodeName>ComboBoxItem</nodeName>";
		   s   +=  c+wOUT;		   
		}


		//name: Class=MiniDateRangeItem
		if (tok.contains("Class=MiniDateRangeItem")  == true) { 
		   wOUT= "";
		   System.out.println("<nodeName>MiniDateRangeItem</nodeName>");
		   wOUT= "<nodeName>MiniDateRangeItem</nodeName>";
		   s   +=  c+wOUT;
		   if (tok.contains("showDateRange")  == true) {
			   wOUT= "";
			   System.out.println("<nodeType>showDateRange</nodeType>");
			   wOUT= "<nodeType>showDateRange</nodeType>";
			   s   +=  c+wOUT;		   
			}
		   if (tok.contains("rangeDialog/rangeForm")  == true) {
			   wOUT= "";
			   System.out.println("<nodeType>REF_DT</nodeType>");
			   wOUT= "<nodeType>REF_DT</nodeType>";
			   s   +=  c+wOUT;		   
			}
		   if (tok.contains("rangeDialog/okButton")  == true) {
			   wOUT= "";
			   System.out.println("<nodeType>okButton</nodeType>");
			   wOUT= "<nodeType>okButton</nodeType>";
			   s   +=  c+wOUT;		   
			}

		}
		
	    //name: Class=DateRangeItem
		if (tok.contains("Class=DateRangeItem")  == true) { 
		   wOUT= "";
		   System.out.println("<nodeName>DateRangeItem</nodeName>");
		   wOUT= "<nodeName>DateRangeItem</nodeName>";
		   s   +=  c+wOUT;		   
		   wOUT= "";		   
		   
		   if (tok.contains("item[name=toField")  == true) { 
			   System.out.println("<nodeType>toField</nodeType>");
			   wOUT= "<nodeType>toField</nodeType>";
			   s   +=  c+wOUT;		   
			   wOUT= "";
		   }
		   
		   if (tok.contains("item[name=fromField")  == true) { 
			   System.out.println("<nodeType>fromField</nodeType>");
			   wOUT= "<nodeType>fromField</nodeType>";
			   s   +=  c+wOUT;		   
			   wOUT= "";
		   }
		}//end name

		
		//name: field
	    if ((tok.contains("item[name=toField")  == true) 
	    || (tok.contains("item[name=fromField")  == true)) {
	    	swItem=1;
	    }
	    
		if ((swItem==1)     
		&& (tok.contains("value")  == true)) {    
			   System.out.println("<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>");
			   wOUT= "<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>";
			   s   +=  c+wOUT;		   
			   wOUT= "";
			   swItem=0;
		}
		
		    //name: Class=DateRangeItem
			if (tok.contains("Class=DateRangeItem")  == true) { 
			   wOUT= "";
			   System.out.println("<nodeName>DateRangeItem</nodeName>");
			   wOUT= "<nodeName>DateRangeItem</nodeName>";
			   s   +=  c+wOUT;		   
			   wOUT= "";		   
			   
			   if (tok.contains("item[name=toField")  == true) { 
				   System.out.println("<nodeType>toField</nodeType>");
				   wOUT= "<nodeType>toField</nodeType>";
				   s   +=  c+wOUT;		   
				   wOUT= "";
			   }
			   
			   if (tok.contains("item[name=fromField")  == true) { 
				   System.out.println("<nodeType>fromField</nodeType>");
				   wOUT= "<nodeType>fromField</nodeType>";
				   s   +=  c+wOUT;		   
				   wOUT= "";
			   }
			}//end name

			//item=
		    if ((tok.contains("item[name=toField")  == true) 
		    || (tok.contains("item[name=fromField")  == true)) {
		    	swItem=1;
		    }
		    
			if ((swItem==1)     
			&& (tok.contains("value")  == true)) {    
				   System.out.println("<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>");
				   wOUT= "<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>";
				   s   +=  c+wOUT;		   
				   wOUT= "";
				   swItem=0;
			}

		
		    //name: Class=RelativeDateItem
			if (tok.contains("RelativeDateItem")  == true) { 
			   wOUT= "";
			   System.out.println("<nodeName>RelativeDateItem</nodeName>");
			   wOUT= "<nodeName>RelativeDateItem</nodeName>";
			   s   +=  c+wOUT;		   
			   wOUT= "";		
			}//end name

			//item[name=toField
			if (tok.contains("item[name=toField")  == true) {
			   System.out.println("<nodeType>toField</nodeType>");
			   wOUT= "<nodeType>toField</nodeType>";
			   s   +=  c+wOUT;		   
			   wOUT= "";			
			}
			
			//item[name=fromField
			if (tok.contains("item[name=fromField")  == true) {
				   System.out.println("<nodeType>fromField</nodeType>");
				   wOUT= "<nodeType>fromField</nodeType>";
				   s   +=  c+wOUT;		   
				   wOUT= "";			
			}
		
	    //name: Class=ComboBoxItem
		if (tok.contains("ComboBoxItem")  == true) { 
		   wOUT= "";
		   System.out.println("<nodeName>ComboBoxItem</nodeName>");
		   wOUT= "<nodeName>ComboBoxItem</nodeName>";
		   s   +=  c+wOUT;		   
		}
		
		//valueField
		if ((tok.contains("valueField")  == true)) {    
		   System.out.println("<nodeChild>valueField</nodeChild>");
		   wOUT= "<nodeChild>valueField</nodeChild>";
		   s   +=  c+wOUT;		   
		   wOUT= "";
		 }
		
	    //name: Class=DynamicForm && classIndex=
		if (tok.contains("Class=DynamicForm")  == true) {  
//		&& (tok.contains("classIndex=")  == true))  {
		   wOUT= "";
		   System.out.println("<nodeName>DynamicForm</nodeName>");
		   wOUT= "<nodeName>DynamicForm</nodeName>";
		   s   +=  c+wOUT;		   
		}
		
		//name: Class="ListGrid"
		if ((tok.contains("ListGrid")  == true)
		&& (tok.contains("Class=")  == true)
		) { 
		   wOUT= "";
		   System.out.println("<nodeName>ListGrid</nodeName>");
		   wOUT= "<nodeName>ListGrid</nodeName>";
		   s   +=  c+wOUT;		   
		}

		
		//name: Eq. Condifence parameters=		
		if (tok.contains("name=Eq. Condifence parameters")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Eq. Condifence parameters</nodeChild>");
		   wOUT= "<nodeChild>Eq. Condifence parameters</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Static=		
		if (tok.contains("name=Static")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Static</nodeChild>");
		   wOUT= "<nodeChild>Static</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		
	    //name: Stress=		
		if (tok.contains("name=Stress")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Stress</nodeChild>");
		   wOUT= "<nodeChild>Stress</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: S.T.=		
		if (tok.contains("name=S.T.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>S.T.</nodeChild>");
		   wOUT= "<nodeChild>S.T.</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
		
	    //name: Ix.=		
		if (tok.contains("name=Ix.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Ix.</nodeChild>");
		   wOUT= "<nodeChild>Ix.</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Curr.=		
		if (tok.contains("name=Curr.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Curr.</nodeChild>");
		   wOUT= "<nodeChild>Curr.</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	    //name: Type=		
		if (tok.contains("name=Type")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Type</nodeChild>");
		   wOUT= "<nodeChild>Type</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Currency=		
		if (tok.contains("name=Currency")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Currency</nodeChild>");
		   wOUT= "<nodeChild>Currency</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Risk=		
		if (tok.contains("name=Risk")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Risk</nodeChild>");
		   wOUT= "<nodeChild>Risk</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	    //name: Indices=		
		if (tok.contains("name=Indices")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Indices</nodeChild>");
		   wOUT= "<nodeChild>Indices</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	    //name: Instr=		
		if (tok.contains("name=Instr.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Instr.</nodeChild>");
		   wOUT= "<nodeChild>Instr.</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	    //name: B.T.=		
		if (tok.contains("name=B.T.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>B.T.</nodeChild>");
		   wOUT= "<nodeChild>B.T.</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: Bankstaticdata		
		if (tok.contains("name=Bankstaticdata")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Bankstaticdata</nodeChild>");
		   wOUT= "<nodeChild>Bankstaticdata</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Bankbalancehistory		
		if (tok.contains("name=Bankbalancehistory")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Bankbalancehistory</nodeChild>");
		   wOUT= "<nodeChild>Bankbalancehistory</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Bankapprovedratinghistory		
		if (tok.contains("name=Bankapprovedratinghistory")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Bankapprovedratinghistory</nodeChild>");
		   wOUT= "<nodeChild>Bankapprovedratinghistory</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Ratingtranscode		
		if (tok.contains("name=Ratingtranscode")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Ratingtranscode</nodeChild>");
		   wOUT= "<nodeChild>Ratingtranscode</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Riskcommittee		
		if (tok.contains("name=Riskcommittee")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Riskcommittee</nodeChild>");
		   wOUT= "<nodeChild>Riskcommittee</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Parameterselection		
		if (tok.contains("name=Parameterselection")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Parameterselection</nodeChild>");
		   wOUT= "<nodeChild>Parameterselection</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Ratingsproposal		
		if (tok.contains("name=Ratingsproposal")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Ratingsproposal</nodeChild>");
		   wOUT= "<nodeChild>Ratingsproposal</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Linearregressionsettings		
		if (tok.contains("name=Linearregressionsettings")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Linearregressionsettings</nodeChild>");
		   wOUT= "<nodeChild>Linearregressionsettings</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Scheduler		
		if (tok.contains("name=Scheduler")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Scheduler</nodeChild>");
		   wOUT= "<nodeChild>Scheduler</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		//name: Logviewer		
		if (tok.contains("name=Logviewer")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Logviewer</nodeChild>");
		   wOUT= "<nodeChild>Logviewer</nodeChild>";
		   s   +=  c+wOUT;		   
		}
	    //name: General=		
		if (tok.contains("General")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>General</nodeChild>");
		   wOUT= "<nodeChild>General</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	    //name: Scheduler=		
		if (tok.contains("Scheduler")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Scheduler</nodeChild>");
		   wOUT= "<nodeChild>Scheduler</nodeChild>";
		   s   +=  c+wOUT;		   
		}

	
	    //name: S.T.=		
		if (tok.contains("name=S.T.")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>S.T.</nodeChild>");
		   wOUT= "<nodeChild>S.T.</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
	    //name: Reports=		
		if (tok.contains("name=Reports")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Reports</nodeChild>");
		   wOUT= "<nodeChild>Reports</nodeChild>";
		   s   +=  c+wOUT;		   
		}


		//name: Eq. Confidence parameters=		
		if (tok.contains("Eq. Confidence parameters")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Eq. Confidence parameters</nodeChild>");
		   wOUT= "<nodeChild>Eq. Confidence parameters</nodeChild>";
		   s   +=  c+wOUT;		   
		}
 
		//name: EquityDerivatives=		
		if (tok.contains("EquityDerivatives")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>EquityDerivatives</nodeChild>");
		   wOUT= "<nodeChild>EquityDerivatives</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: Bond=		
		if (tok.contains("Bond")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Bond</nodeChild>");
		   wOUT= "<nodeChild>Bond</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: Bond=		
		if (tok.contains("Bond")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Bond</nodeChild>");
		   wOUT= "<nodeChild>Bond</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: iBond=		
		if (tok.contains("iBond")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>iBond</nodeChild>");
		   wOUT= "<nodeChild>iBond</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
		//name: Indices=		
		if (tok.contains("Indices")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Indices</nodeChild>");
		   wOUT= "<nodeChild>Indices</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: Currency=		
		if (tok.contains("Currency")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Currency</nodeChild>");
		   wOUT= "<nodeChild>Currency</nodeChild>";
		   s   +=  c+wOUT;		   
		}
 
		//name: RiskEngine=		
		if (tok.contains("RiskEngine")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>RiskEngine</nodeChild>");
		   wOUT= "<nodeChild>RiskEngine</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: StressTest=		
		if (tok.contains("StressTest")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>StressTest</nodeChild>");
		   wOUT= "<nodeChild>StressTest</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: RiskEngine=		
		if (tok.contains("RiskEngine")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>RiskEngine</nodeChild>");
		   wOUT= "<nodeChild>RiskEngine</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: BackTest=		
		if (tok.contains("BackTest")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>BackTest</nodeChild>");
		   wOUT= "<nodeChild>BackTest</nodeChild>";
		   s   +=  c+wOUT;		   
		}

		//name: Comparables=		
		if (tok.contains("Comparables")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>Comparables</nodeChild>");
		   wOUT= "<nodeChild>Comparables</nodeChild>";
		   s   +=  c+wOUT;		   
		}
		
		//name: General=		
		if (tok.contains("General")  == true)  {
		   wOUT= "";
		   System.out.println("<nodeChild>General</nodeChild>");
		   wOUT= "<nodeChild>General</nodeChild>";
		   s   +=  c+wOUT;		   
		}
	
//	    //node: title=		
//		if (tok.contains("title=Section")  == true)  {
//		   wOUT= "";
//		   System.out.println("<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>");
//		   wOUT= "<nodeChild>"+tok.substring(6, tok.length())+"</nodeChild>";
//		   s   +=  c+wOUT;
//		}

		
		//node: Class=RecordEditor
		if (tok.contains("Class=RecordEditor")  == true){
		   wOUT= "";
		   System.out.println("<nodeName>RecordEditor</nodeName>");
		   wOUT= "<nodeName>RecordEditor</nodeName>";
		   s   +=  c+wOUT;
		}
		
		//valueField
		if ((tok.contains("valueField")  == true)) {    
		   System.out.println("<nodeChild>valueField</nodeChild>");
		   wOUT= "<nodeChild>valueField</nodeChild>";
		   s   +=  c+wOUT;		   
		   wOUT= "";
		 }

		



		//node: ITEM_ID &&  body/row
		if ((tok.contains("ITEM_ID=")  == true)
	&&   (tok.contains("/body/row")  == true) 
	&&   (tok.contains("Class=DateItem")  == false) 
	&&   (tok.contains("Class=MiniDateRangeItem")  == false) 
	&&   (tok.contains("Class=DateRangeItem")  == false) 
	&&   (tok.contains("Class=RelativeDateItem")  == false) 
	&&   (tok.contains("Class=SndIntLnk")  == false) 
	&&   (tok.contains("Class=LCHFails")  == false) 
	&&   (tok.contains("Class=ComboBoxItem")  == false) 
	&&   (tok.contains("Class=CheckboxItem")  == false) 
	&&   (tok.contains("Class=SelectItem")  == false) 
	&&   (tok.contains("Class=ListGrid")  == false) 
	&&    (tok.contains("Class=EodCshCll")  == false)){
		   System.out.println("<nodeType>"+tok.substring(30, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(30, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;
		   wOUT= "";
		}

//		//node: ITEM_ID && NOT body/row
//		if ((tok.contains("ITEM_ID=")  == true)
//	&&   (tok.contains("/body/row")  == false)) {
//		   System.out.println("<nodeType>"+tok.substring(30, tok.length())+"</nodeType>");
//		   wOUT= "<nodeType>"+tok.substring(30, tok.length())+"</nodeType>";
//		   s   +=  c+wOUT;
//		   wOUT= "";
//		}

		//node: CASH_AMNT=
		if (tok.contains("CASH_AMNT=")  == true) {
  		   System.out.println("<nodeChild>CASH_AMNT</nodeChild>");
		   wOUT= "<nodeChild>CASH_AMNT</nodeChild>";
		   s   +=  c+wOUT;
		   wOUT= "";
  		   System.out.println("<nodeType>"+tok.substring(30, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(30, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;
		   wOUT= "";
		}


		//node: EodCshCll=
		if (tok.contains("EodCshCll=")  == true) {
  		   System.out.println("<nodeChild>EodCshCll</nodeChild>");
		   wOUT= "<nodeChild>EodCshCll</nodeChild>";
		   s   +=  c+wOUT;
		   wOUT= "";
  		   System.out.println("<nodeType>"+tok.substring(30, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(30, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;
		   wOUT= "";
		}

		//node: REF_DT
		if ((tok.contains("REF_DT")  == true) 
		&&  (tok.contains("/body/row[REF_DT=") == true)) {
//		|| (tok.contains("name=REF_DT")  == true)
//		|| (tok.contains("title=REF_DT")  == true))) {
		   System.out.println("<nodeType>REF_DT</nodeType>");
		   wOUT= "<nodeType>REF_DT</nodeType>";
		   s   +=  c+wOUT;
		   wOUT= "";
  		   System.out.println("<nodeChild>"+tok.substring(83, tok.length())+"</nodeChild>");
		   wOUT= "<nodeChild>"+tok.substring(83, tok.length())+"</nodeChild>";
		   s   +=  c+wOUT;
		   wOUT= "";
		}

				
		//node: value=
		if (tok.contains("value=")  == true){
		   wOUT= "";
		   System.out.println("<nodeType>"+tok.substring(6, tok.length())+"</nodeType>");
		   wOUT= "<nodeType>"+tok.substring(6, tok.length())+"</nodeType>";
		   s   +=  c+wOUT;
		}

//	    //name=		
//		if (tok.contains("name=")  == true)  {
//		   wOUT= "";
//		   System.out.println("<nodeChild>"+tok.substring(51, tok.length())+"</nodeChild>");
//		   wOUT= "<nodeChild>"+tok.substring(51, tok.length())+"</nodeChild>";
//		   s   +=  c+wOUT;		   
//		}
		  
	    //node: Class=Portlet
		if ((tok.contains("Class=Portlet")  == true) 
	||  (tok.contains("scLoca")  == true)) {
		   wOUT= "";
		   System.out.println("<nodeName>Portlet</nodeName>");
		   wOUT= "<nodeName>Portlet</nodeName>";
		   s   +=  c+wOUT;	
		}
	  
	    //node: ID="Portlet:Portlet"
		if ((tok.contains("scLocator=//Portlet")  == true) 
		&& (tok.contains("filterEditor")  == true)) {
		   wOUT= "";
		   System.out.println("<nodeType>Portlet:filterEditor</nodeType>");
		   wOUT= "<nodeType>Portlet:filterEditor</nodeType>";
		   s   +=  c+wOUT;   
		}
		
		//Portlet[ID=
		if (tok.contains("//Portlet[ID=")  == true){
		   wOUT= "";
		   System.out.println("<nodeChild>liquidity_ord</nodeChild>");
		   wOUT= "<nodeChild>liquidity_ord</nodeChild>";
		   s   +=  c+wOUT;
		   wOUT= "";
		}
		
		//node: TextAreaItem
		if (tok.contains("_TextAreaItem")  == true) {
		   wOUT= "";
		   System.out.println("<nodeType>TextAreaItem</nodeType>");
		   wOUT= "<nodeType>TextAreaItem</nodeType>";
		   s   +=  c+wOUT;
		   
		}

	    //node: CheckboxItem
		if (tok.contains("_CheckboxItem")  == true) {
		   wOUT= "";
		   System.out.println("<nodeType>CheckboxItem</nodeType>");
		   wOUT= "<nodeType>CheckboxItem</nodeType>";
		   s   +=  c+wOUT;

		}


		//node: TextAreaItem
		if (tok.contains("_TextAreaItem")  == true) {
		   wOUT= "";
		   System.out.println("<nodeType>TextAreaItem</nodeType>");
		   wOUT= "<nodeType>TextAreaItem</nodeType>";
		   s   +=  c+wOUT;
			

		}
	
	    //node: CheckboxItem
		if (tok.contains("_CheckboxItem")  == true) {
		   wOUT= "";
		   System.out.println("<nodeType>CheckboxItem</nodeType>");
		   wOUT= "<nodeType>CheckboxItem</nodeType>";
		   s   +=  c+wOUT;
		}

	    //node: [INSTRID=
		if (tok.contains("[INSTRID=")  == true)  {
		   wOUT= "";
		   String str = tok.valueOf(tok.substring(0, tok.length()));
		  
		   String[] set = str.split("INSTRID=");
		   pre = "INSTRID=";
		   for(int k=0;k<set.length;++k)
		   {
			visK  = set[k];
		   }
		   int iMAX = 5;
		   if (iMAX<5) {
			  iMAX=0; 
		   }
		   if (iMAX>=5) {
			   System.out.println("<nodeType>"+pre+visK.substring(0, iMAX)+"</nodeType>");
			   wOUT= "<nodeType>"+pre+visK.substring(0, iMAX)+"</nodeType>";
			   s   +=  c+wOUT;   
		   }
		}	

//	    //node: INSTRNAME=
//		if (tok.contains("INSTRNAME=")  == true)  {
//		   wOUT= "";
//		   String str = tok.valueOf(tok.substring(0, tok.length()));
//		  
//		   String[] set = str.split("INSTRNAME=");
//		   pre = "INSTRNAME=";
//		   for(int k=0;k<set.length;++k)
//		   {
//			visK  = set[k];
//		   }
//		   int iMAX = 25;
//		   if (iMAX<25) {
//			  iMAX=0; 
//		   }
//		   if (iMAX>=25) {
//			   System.out.println("<nodeChild>"+pre+visK.substring(0, iMAX)+"</nodeChild>");
//			   wOUT= "<nodeChild>"+pre+visK.substring(0, iMAX)+"</nodeChild>";
//			   s   +=  c+wOUT;   
//		   }
//		}	

	    //node: ISINCODE=
		if (tok.contains("ISINCODE=")  == true)  {
		   wOUT= "";
		   String str = tok.valueOf(tok.substring(0, tok.length()));
		  
		   String[] set = str.split("ISINCODE=");
		   pre = "ISINCODE=";
		   for(int k=0;k<set.length;++k)
		   {
			visK  = set[k];
		   }
		   int iMAX = 12;
		   if (iMAX<12) {
			  iMAX=0; 
		   }
		   if (iMAX>=12) {
			   System.out.println("<nodeType>"+pre+visK.substring(0, iMAX)+"</nodeType>");
			   wOUT= "<nodeType>"+pre+visK.substring(0, iMAX)+"</nodeType>";
			   s   +=  c+wOUT;   
		   }
		}	

	}

}
		 
		
		

 
	  
