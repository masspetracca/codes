package it.ccg.fpm.freader.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.StringTokenizer;

import it.ccg.fpm.freader.batch.FileFilter;
import it.ccg.fpm.freader.batch.PropertyFiles;

public class GetFiles {
	    private static String Lline = null;
		private static int ctrRead;
		private String tok;
		private String[] set;
	    /**
	     * @param args the command line arguments
	     * @throws IOException 
	     */
		private String pre;
		private String visK;
		private int k;
		private int iMAX;
		
	    //public static void main(String[] args) throws IOException {
	    	GetFiles() throws IOException{ 
	    	System.out.println("Inizio <File Filter> ");

			//Vengono prelevati gli attributi del progetto
			GetProperties();
			
	    	File parentDir = new File(PropertyFiles.getCartellaDati());
	        FilenameFilter fileFilter = new FileFilter();
	        File[] listaFileInput = null;
	        if(parentDir.isDirectory()) {
	        	listaFileInput = parentDir.listFiles(fileFilter);
	        }
	        //System.out.println("Errore directory");
	        FileReader reader = null;
	        String Uline = null;
	        File outputFile = new File(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTFPM_FILE_INPUT());
	        File currFile = null;
	        BufferedReader in = null;
	        FileWriter writer = null;
	        String line = null;
	        try{
	            //imposta il writer per il file di output
	            writer = new FileWriter(outputFile);
	            if (listaFileInput!=null && listaFileInput.length == 0) {
	            	System.out.println("Attenzione: nessun file da elaborare !");
	            	System.exit(1);
	            }
	            //itera sulla lista di file
	            for(int i=0;i< listaFileInput.length; i++){
	                currFile = listaFileInput[i];
	                System.out.println("Sto elaborando il file: " + currFile.getName());
	                reader = new FileReader(currFile);
	                in = new BufferedReader(reader);
	                int ictr = 0;
	                ctrRead = 0;
	                String Sline = null;
	                
	                
	                while ((line = in.readLine()) != null) {
	                	if (ictr == 0) {
	                		if (Lline == line) {
	                		   Sline = line;
	                 		}
	                	}
	                	
//	    			    //scarti: scrivo una riga soltanto
//	                	if (line.contains("Located in isScElementClickable") == true) {
//	                		while 
//	    	                ((line.contains("Located in isScElementClickable") == true)
//	                		) { 
//	                			System.out.println(">> SCARTO: "+line);
//	                			line = in.readLine();
//	                		  }
//	                	}
	                   	   tok="";
	                	   ctrRead = ctrRead + 1;
	                	   System.out.println("riga: " + ctrRead + " " + line);
	                
	                	   //
		    				if (line.contains("info: Starting test") == false) { 
		    					StringTokenizer f=new StringTokenizer(line, "/");
		    				
		        			    //while tokens
		        				while(f.hasMoreTokens()) {
			        				tok += (String) f.nextElement();
		        					
			        				if ((tok.contains("row") == true) 
				        			|| (tok.contains("member") == true)) { 
//		        					|| (tok.contains("item") == true)) {
				    				   String str = tok.valueOf(tok.substring(0, tok.length()));

				    				   pre = line.substring(0, 16);
				    				   visK="";
	
				    				   set = str.split("row");
				    				   k=0;
				    				   for(k=0;k<set.length;++k)
				    				   {
				    					visK  = set[k];
				    				   }

//				    				   if (k== 1) {
//					    				   set = str.split("item");
//					    				   for(k=0;k<set.length;++k)
//					    				   {
//					    					visK  = set[k];
//					    				   }
//				    				   }
				    				   

				    				   if (k== 1) {
					    				   set = str.split("member");
					    				   for(k=0;k<set.length;++k)
					    				   {
					    					visK  = set[k];
					    				   }
				    				   }
				    				   
				    				   iMAX = k;
				    				   if (iMAX<k) {
				    					  iMAX=0; 
				    				   }
				    				   
				    				   if (iMAX>=k) {
				    					   System.out.println("write: "+visK);
				    					   String vis = pre+visK;
						    			   writer.write(vis+"\r\n");
				    				   }
				    				   
				    				   
		        					}//end token
		        					
		        				}//end slash
		    				} // line not having "info: Starting test" 
		    				System.out.println("write: "+line);
		    				writer.write(line+"\r\n");
	                
	                   	}// end EOF
	                System.out.println("Ho finito di elaborare il file: " + currFile.getName());
	                if (Sline != Uline) {
	       		 		System.out.println("---ultima riga: " + Uline);
	                    Lline = Uline;
	                    Uline = null;
	                    
	                }
	            }
	        }catch(IOException ioEx){
	            System.out.println(ioEx.getMessage());
	            ioEx.printStackTrace();
	        }finally{
	            try{
	                if(in!= null) in.close();
	                if(writer!= null) writer.close();
	            }catch(IOException ioEx){
	                System.out.println(ioEx.getMessage());
	                ioEx.printStackTrace();
	            }
	        }
	        
	    }
		private static void GetProperties() throws IOException {
			PropertyFiles pf = new PropertyFiles();
			
		}
	    
	}