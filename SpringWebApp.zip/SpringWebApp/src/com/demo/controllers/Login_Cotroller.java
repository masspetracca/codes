package com.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Login_Cotroller {

	/*
	@RequestMapping(value="/login" , method=RequestMethod.GET)
	public ModelAndView loadloginpage()
	{
		ModelAndView mav = new ModelAndView("login");
		System.out.println("Login method has been called");
		return mav;
	}
	*/
	
	@RequestMapping(value="/login" , method=RequestMethod.GET)
	public String loadloginpage()
	{
		return "login";
	}
	
}
