package it.ccg.infoproviderweb.client.data;

import java.util.List;

import com.smartgwt.client.util.SC;

public class UserData {
	
	private static UserData currentUserData;
	
	private String name;
	private String surname;
	private List<String> userRolesList;
	
	
	public UserData() {
		
	}
	
	public UserData(String name, String surname, List<String> userRolesList) {
		this.name = name;
		this.surname = surname;
		this.userRolesList = userRolesList;
	}
	
	
	public String getName() {
		return name;
	}


	public String getSurname() {
		return surname;
	}


	public List<String> getUserRolesList() {
		return userRolesList;
	}



	public static UserData getCurrentUserData() {
		if(UserData.currentUserData == null) {
			SC.say("Cannot retrieve user data, will exit..");
			
			com.google.gwt.user.client.Window.Location.assign("/InfoProviderWEB/login.html");
		}
		
		return currentUserData;
	}
	
	public static void setCurrentUserData(UserData currentUserData) {
		UserData.currentUserData = currentUserData;
	}

}
