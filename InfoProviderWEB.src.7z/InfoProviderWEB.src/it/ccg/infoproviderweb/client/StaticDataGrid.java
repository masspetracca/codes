package it.ccg.infoproviderweb.client;



import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.DataSourceField;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.widgets.grid.ListGrid;

public class StaticDataGrid extends ListGrid {
	
	
	public StaticDataGrid() {
		
		super();
		
		this.setAlternateRecordStyles(true);
		this.setHeight("100%");
		this.setWidth("100%");
		
		this.setShowFilterEditor(true);
		
		this.setCanEdit(true);
		this.setEditEvent(ListGridEditEvent.DOUBLECLICK);
		this.setUpdateOperation("update");
		
		this.setDataSource(DataSource.get("instr"));
		
		
		this.setFetchOperation("fetch");
		
		this.setAutoFetchData(true);
		
		
		// default DataSourceField properties
		this.setDSFieldsDefaultProperties();
		
		// I set 'detail'=false for each ListGridField i want to see at startup
		String[] fieldsNames = {"instrumentId", "instrumentName", "isinCode", "classCode", "reutersIdentifierCode", "bloombergCode", "instrumentType", "instrumentSubtype", "provider", "status"};
		this.showFieldsList(fieldsNames);
		
	}
	
	
	private void setDSFieldsDefaultProperties() {
		DataSource datasource = this.getDataSource();
		DataSourceField[] dsFields = datasource.getFields();
		
		for(DataSourceField dsField : dsFields) {
			
		}
	}
	
	
	private void showFieldsList(String[] fieldsNames) {
		DataSource datasource = this.getDataSource();
		DataSourceField[] dsFields = datasource.getFields();
		
		for(DataSourceField dsField : dsFields) {
			dsField.setAttribute("detail", true);
			
			for(String fieldName : fieldsNames) {
				if(dsField.getName().equalsIgnoreCase(fieldName)) {
					dsField.setAttribute("detail", false);
					
					continue;
				}
			}
		}
	}
	
	

}
