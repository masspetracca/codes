package it.ccg.infoproviderweb.client;




import it.ccg.infoproviderweb.client.ac.ACSection;
import it.ccg.infoproviderweb.client.data.UserData;

import java.util.ArrayList;
import java.util.List;

import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.BkgndRepeat;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.tab.Tab;
import com.smartgwt.client.widgets.tab.TabSet;


public class MainLayout extends VLayout {
	
	private static MainLayout mainLayout;													//	mainLayout
	
	private static HLayout headerHLayout = new HLayout();									//		headerHLayout
	private HLayout tabSetHLayout = new HLayout();											//		tabSetHLayout
	
	Tab administrativeConsoleTab;
	
	private Label label = new Label();
	
	
	
	public static MainLayout createInstance() {
		
		mainLayout = new MainLayout();
		
		HeaderUserSection headerUserSection = (HeaderUserSection)headerHLayout.getMember(2);
		headerUserSection.getAccountWindow().setLeft(mainLayout.getWidth() - 200);
		mainLayout.addChild(headerUserSection.getAccountWindow());
		
		return mainLayout;
		
	}
	
	
	
	public MainLayout() {
		super();
		
		
		

		// definisco la struttura
		// ***************************************************************************
		
		// header -----------------------------------------------------------------------
		
		headerHLayout.setHeight("10%");
		headerHLayout.setWidth100();
		headerHLayout.setLayoutTopMargin(new Integer(5));
		headerHLayout.setShowResizeBar(true);
		
		
		// logo  
		Img logo = new Img("CCGlogo.gif",237,51); 	
		headerHLayout.addMember(logo, 0);
		
		// white space
		LayoutSpacer layoutSpacer = new LayoutSpacer();
		layoutSpacer.setHeight("10%");
		layoutSpacer.setWidth100();
		headerHLayout.addMember(layoutSpacer, 1);
		
		// user info
		headerHLayout.addMember(new HeaderUserSection(this), 2);
		
		// header -------------------------------------------------------------------
		
		
		
		// label --------------------------------------------------------------------
		
		label.setHeight(25);
		label.setWidth100();
		label.setPadding(4);
		label.setAlign(Alignment.LEFT);
		label.setValign(VerticalAlignment.TOP);
		label.setWrap(false);
        label.setBackgroundImage("label.png");
		label.setBackgroundRepeat(BkgndRepeat.REPEAT_X);
		label.setContents("<nobr><h2>External historical feed management panel</h2></nobr> <br><br>");
		
		// label --------------------------------------------------------------------
		
		
		
		// tab set ----------------------------------------------------------------------
		TabSet tabSet = new TabSet(); 
		
		List<Tab> tempList = new ArrayList<Tab>();
		
		if(UserData.getCurrentUserData().getUserRolesList().contains("admin")) {
			Tab administrativeConsoleTab = new Tab("Administrative console");
			administrativeConsoleTab.setPane(new ACSection());
			
			tempList.add(administrativeConsoleTab);
		}
        
        Tab staticDataTab = new Tab("Static data");
        staticDataTab.setPane(new StaticDataSection());
        tempList.add(staticDataTab);
        
        Tab historicalDataTab = new Tab("Historical data");
        historicalDataTab.setPane(HistoricalDataSection.getInstance());
        tempList.add(historicalDataTab);
        
        
        Tab[] tabArray = new Tab[tempList.size()];
        tabArray = tempList.toArray(tabArray);
        
        tabSet.setTabs(tabArray);
        
        
        tabSetHLayout.addMember(tabSet);
        // tab set ----------------------------------------------------------------------
        
        

		this.addMember(headerHLayout);
		this.addMember(label);
		this.addMember(tabSetHLayout);
		
		this.setWidth("99%");
		this.setHeight("99%");
		this.setLeft("8");
		this.setTop("3");
		
		
		this.draw();
		
		// ***************************************************************************

		
	}

	

	public static MainLayout getMainLayout() {
		return mainLayout;
	}


	/*public void setMainLayout(MainLayout mainLayout) {
		this.mainLayout = mainLayout;
	}*/


	public static HLayout getHeaderHLayout() {
		return headerHLayout;
	}


	/*public void setHeaderHLayout(HLayout headerHLayout) {
		this.headerHLayout = headerHLayout;
	}*/


	public HLayout getTabSetHLayout() {
		return tabSetHLayout;
	}


	public void setTabSetHLayout(HLayout tabSetHLayout) {
		this.tabSetHLayout = tabSetHLayout;
	}



	public Tab getAdministrativeConsoleTab() {
		return administrativeConsoleTab;
	}
	
	

}

