package it.ccg.infoproviderweb.client;



import it.ccg.infoproviderweb.client.data.UserData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.VisibilityMode;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.CheckboxItem;
import com.smartgwt.client.widgets.form.fields.DateTimeItem;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.fields.events.ChangedEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangedHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.layout.SectionStack;
import com.smartgwt.client.widgets.layout.SectionStackSection;
import com.smartgwt.client.widgets.layout.VLayout;

public class StaticDataSection extends Canvas {
	
	public StaticDataSection() {
		// old  ***
		// this.addChild(staticDataGrid);
		// old  ***
		
		
		List<SectionStackSection> sectionStackSectionList = new ArrayList<SectionStackSection>();
		
		
		
		final ListGrid staticDataGrid = new StaticDataGrid();
		staticDataGrid.setHeight("65%");
        
        SectionStackSection gridSectionStackSection = new SectionStackSection("Instruments");
        gridSectionStackSection.setItems(staticDataGrid);
        gridSectionStackSection.setExpanded(true);
        gridSectionStackSection.setResizeable(false);
        gridSectionStackSection.setCanCollapse(false);
        
        
        sectionStackSectionList.add(gridSectionStackSection);
		
		
		
		// se sono amministratore..
		if(UserData.getCurrentUserData().getUserRolesList().contains("admin")) {
			
			// ..posso editare gli strumenti presenti in anagrafica
			staticDataGrid.setCanEdit(true);
			
			// ..posso aggiungere nuovi strumenti
			
			
			
			IButton importButton = new IButton("Import data", new ClickHandler() {
				
				@Override
				public void onClick(ClickEvent event) {
					ImportWindow.getInstance(staticDataGrid);
				}
			});
			
			
			
			VLayout vLayout = new VLayout();
			vLayout.addMember(this.createAddInstrumentForm());
			vLayout.addMember(importButton);
			
			
			
			SectionStackSection addSectionStackSection = new SectionStackSection("Add instruments");
			addSectionStackSection.setExpanded(false);
			addSectionStackSection.setResizeable(false);
			
			addSectionStackSection.setItems(vLayout);
	        
	        sectionStackSectionList.add(addSectionStackSection);
		}
		
		
		
		SectionStack sectionStack = new SectionStack();
        sectionStack.setWidth100();
        sectionStack.setHeight100();
        sectionStack.setVisibilityMode(VisibilityMode.MULTIPLE);  
        sectionStack.setAnimateSections(true);
        
        SectionStackSection[] sections = new SectionStackSection[sectionStackSectionList.size()];
        sections = sectionStackSectionList.toArray(sections);
        
        sectionStack.setSections(sections);
        
        
        this.addChild(sectionStack);
		
		
	}
	
	
	
	
	private DynamicForm createAddInstrumentForm() {
		final DynamicForm dynamicForm = new DynamicForm();
		
		final DataSource timerDataSource = DataSource.get("instr");
		dynamicForm.setDataSource(timerDataSource);
		
		
		
		return dynamicForm;
	}

}
