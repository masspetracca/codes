package it.ccg.infoproviderweb.client.ac;



import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;

public class ACLogCanvas extends Canvas {
	
	private ListGrid listGrid;
	
	
	public ACLogCanvas() {
		super();
		this.setWidth100();
		this.setHeight100();
		this.setLeft(10);
		
		
		// form section
		final HLayout formLayout = this.createFormLayout();
		// form section
		
		
		// grid section
		listGrid = this.createListGrid();
		listGrid.setWidth100();
        listGrid.setHeight100();
        
        // grid section
        
        
        VLayout mainVLayout = new VLayout();
        mainVLayout.setWidth100();
        mainVLayout.setHeight100();
        mainVLayout.setMembers(formLayout, listGrid);
        
        
        
        this.addChild(mainVLayout);
        
	}
	
	
	private HLayout createFormLayout() {
		
		final DynamicForm dynamicForm = new DynamicForm();
		
		final DataSource logDataSource = DataSource.get("log");
		
		// name text item
		final SelectItem logSelectItem = new SelectItem("log");
		logSelectItem.setType("enum");
		logSelectItem.setRequired(true);
		logSelectItem.setTitle("Log");
		
		logDataSource.performCustomOperation("fetchLogNames", new Record(), new DSCallback() {
			
			@Override
			public void execute(DSResponse response, Object rawData, DSRequest request) {
				
				Record[] data = response.getData();
				
				LinkedHashMap<String, String> valueMap = new LinkedHashMap<String, String>();
				
				for(Record record : data) {
					valueMap.put(record.getAttributeAsString("logFileName"), record.getAttributeAsString("logFileName"));
				}
				
				logSelectItem.setValueMap(valueMap);
				
			}
		}, new DSRequest());
	        
		dynamicForm.setItems(logSelectItem);
		
		
		// buttons
        final IButton showButton = new IButton();
        showButton.setTitle("Show");
        showButton.setHeight(25);
        showButton.setWidth(60);
        showButton.setAlign(Alignment.CENTER);
        showButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(!dynamicForm.validate()) {
        			return;
        		}
				
				DSRequest dsRequest = new DSRequest();
				Map<String,String> params = new HashMap<String, String>();
				params.put("logFileName", logSelectItem.getValueAsString());
				dsRequest.setParams(params);
				
				
				listGrid.fetchData(listGrid.getCriteria(), new DSCallback() {
					
					@Override
					public void execute(DSResponse response, Object rawData, DSRequest request) {
						
						
					}
					
				}, dsRequest);
				
				
				listGrid.invalidateCache();
				
			}
		});
        
        
        
        
        HLayout hButtonLayout = new HLayout();
        hButtonLayout.setLayoutLeftMargin(30);
        hButtonLayout.addMember(showButton);
        // buttons
        
        
        HLayout layout = new HLayout();
        layout.addMember(dynamicForm);
        layout.addMember(hButtonLayout);
        layout.setLayoutBottomMargin(10);
		
		
		return layout;
		
	}
	
	
	
	private ListGrid createListGrid() {
		ListGrid timerGrid = new ListGrid() {
			@Override
			protected String getCellCSSText(ListGridRecord record, int rowNum, int colNum) {
				String type = record.getAttributeAsString("type");
            	if(type != null){
					
            		if(type.equalsIgnoreCase("ERROR")) {
            			
						return "color:#FF0000";
					} 
            		else if(type.equalsIgnoreCase("WARN")) {
						
						return "color:#B17A0F";
					}
            		else if(type.equalsIgnoreCase("DEBUG")) {
						
						return "color:#2569d0";
					}
            		else if(type.equalsIgnoreCase("INFO")) {
						
						return "color:#000000";
					}
            		else {
                		
                		return super.getCellCSSText(record, rowNum, colNum);
                	}
				
            	}
            	else {
            		
            		return super.getCellCSSText(record, rowNum, colNum);
            	}
			}
		};
		
		
		DataSource dataSource = DataSource.get("log");
		timerGrid.setDataSource(dataSource);
		
		timerGrid.setFetchOperation("fetch");
		
		timerGrid.setShowFilterEditor(true);
		
		
		return timerGrid;
	}
	
	

}
