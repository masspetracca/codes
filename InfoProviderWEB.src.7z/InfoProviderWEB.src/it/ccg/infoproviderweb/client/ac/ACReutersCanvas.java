package it.ccg.infoproviderweb.client.ac;


import com.smartgwt.client.widgets.Canvas;

public class ACReutersCanvas extends Canvas {
	
	public ACReutersCanvas() {
		
		super();
		this.setWidth100();
		this.setHeight100();
		this.setLeft(10);
		
	}
	
	
}
