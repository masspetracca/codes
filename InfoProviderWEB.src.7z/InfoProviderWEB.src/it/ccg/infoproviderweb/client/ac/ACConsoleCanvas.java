package it.ccg.infoproviderweb.client.ac;



import it.ccg.infoproviderweb.client.MainLayout;
import it.ccg.infoproviderweb.client.data.UserData;

import java.util.List;
import java.util.Map;

import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;

public class ACConsoleCanvas extends Canvas {
	
	private ListGrid listGrid;
	
	
	public ACConsoleCanvas() {
		super();
		this.setWidth100();
		this.setHeight100();
		this.setLeft(10);
		
		
		// form section
		final HLayout formLayout = this.createFormLayout();
		// form section
		
		
		// grid section
		listGrid = this.createListGrid();
		listGrid.setWidth100();
        listGrid.setHeight100();
        
        // grid section
        
        
        VLayout mainVLayout = new VLayout();
        mainVLayout.setWidth100();
        mainVLayout.setHeight100();
        mainVLayout.setMembers(formLayout/*, listGrid*/);
        
        
        
        this.addChild(mainVLayout);
        
	}
	
	
	private HLayout createFormLayout() {
		
		final DynamicForm dynamicForm = new DynamicForm();
		
		
		// buttons
        final IButton showButton = new IButton();
        showButton.setTitle("Start");
        showButton.setHeight(25);
        showButton.setWidth(60);
        showButton.setAlign(Alignment.CENTER);
        showButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				/*DSRequest dsRequest = new DSRequest();
				
				listGrid.fetchData(listGrid.getCriteria(), new DSCallback() {
					
					@Override
					public void execute(DSResponse response, Object rawData, DSRequest request) {
						
						
					}
					
				}, dsRequest);*/
				
				
				// now RPC
				
				RPCRequest rpcRequest = new RPCRequest();
				rpcRequest.setActionURL("servlet/Test");
				
				RPCManager.sendRequest(rpcRequest, new RPCCallback() {
					@SuppressWarnings("unchecked")
					public void execute(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						Map<String, Object> data = response.getAttributeAsMap("data");
						
						String testMessage = (String)data.get("testMessage");
						
						
						SC.say(testMessage);
						
					}

				});
				
				
			}
		});
        
        
        
        
        HLayout hButtonLayout = new HLayout();
        hButtonLayout.setLayoutLeftMargin(30);
        hButtonLayout.addMember(showButton);
        // buttons
        
        
        HLayout layout = new HLayout();
        layout.addMember(dynamicForm);
        layout.addMember(hButtonLayout);
        layout.setLayoutBottomMargin(10);
		
		
		return layout;
		
	}
	
	
	
	private ListGrid createListGrid() {
		ListGrid timerGrid = new ListGrid();
		
		DataSource dataSource = DataSource.get("log");
		timerGrid.setDataSource(dataSource);
		
		timerGrid.setFetchOperation("fetch");
		
		timerGrid.setShowFilterEditor(true);
		
		
		return timerGrid;
	}
	
	
}
