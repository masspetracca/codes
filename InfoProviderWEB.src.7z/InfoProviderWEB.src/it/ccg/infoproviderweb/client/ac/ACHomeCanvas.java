package it.ccg.infoproviderweb.client.ac;

import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Label;

public class ACHomeCanvas extends Canvas {
	
	public ACHomeCanvas() {
		this.setWidth100();
		this.setHeight100();
		
		this.addChild(new Label("<nobr><em>[Select a section on the left]</em></nobr>"));
	}

}
