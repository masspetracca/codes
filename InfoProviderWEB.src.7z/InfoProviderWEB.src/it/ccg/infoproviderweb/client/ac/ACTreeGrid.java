package it.ccg.infoproviderweb.client.ac;


import com.smartgwt.client.types.TreeModelType;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.grid.CellFormatter;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.tab.Tab;
import com.smartgwt.client.widgets.tree.Tree;
import com.smartgwt.client.widgets.tree.TreeGrid;
import com.smartgwt.client.widgets.tree.TreeGridField;
import com.smartgwt.client.widgets.tree.TreeNode;

public class ACTreeGrid extends TreeGrid {
	
	public ACTreeGrid() {
		super();
		
		this.setWidth("17%");  
		this.setShowConnectors(true);  
		this.setShowResizeBar(true);
        
        Tree data = new Tree();  
        data.setModelType(TreeModelType.CHILDREN);
        
        TreeNode rootNode = new TreeNode("root");
        data.setRoot(rootNode);
        
        TreeNode homeNode = new TreeNode("Home");
        data.add(homeNode, rootNode);
        
        TreeNode timerNode = new TreeNode("Scheduler");
        data.add(timerNode, homeNode);
        
        TreeNode servicesNode = new TreeNode("Provider manager");
        data.add(servicesNode, homeNode);
        
        TreeNode reautersNode = new TreeNode("Reuters");
        data.add(reautersNode, servicesNode);
        
        TreeNode bloombergNode = new TreeNode("Bloomberg");
        data.add(bloombergNode, servicesNode);
        
        TreeNode logNode = new TreeNode("Log");
        data.add(logNode, homeNode);
        
        TreeNode monitoringNode = new TreeNode("Monitor");
        data.add(monitoringNode, homeNode);
        
        /*TreeNode consoleNode = new TreeNode("Console");
        data.add(consoleNode, homeNode);*/
        
        
        
        this.setData(data);  
          
        TreeGridField treeGridField = new TreeGridField("Navigation");  
        treeGridField.setCellFormatter(new CellFormatter() {  
            public String format(Object value, ListGridRecord record, int rowNum, int colNum) {  
                return record.getAttribute("name");  
            }  
        });
        
        this.setFields(treeGridField);
        
        this.addRecordClickHandler(new RecordClickHandler() {
			
			@Override
			public void onRecordClick(RecordClickEvent event) {
				
				if(event.getRecord().getAttributeAsString("name").equalsIgnoreCase("Home")) {
					Canvas canvas = new ACHomeCanvas();
					ACSection.setMainCanvas(canvas);
					
					Tab tab = ACSection.getTab();
			        tab.setTitle("Home");
			        ACSection.getTabSet().updateTab(tab, canvas);
				}
				else if(event.getRecord().getAttributeAsString("name").equalsIgnoreCase("Scheduler")) {
					Canvas canvas = new ACSchedulerCanvas();
					ACSection.setMainCanvas(canvas);
					
					Tab tab = ACSection.getTab();
			        tab.setTitle("Scheduler");
			        ACSection.getTabSet().updateTab(tab, canvas);
				}
				else if(event.getRecord().getAttributeAsString("name").equalsIgnoreCase("Provider management")) {
					Canvas canvas = new ACProviderManagmentCanvas();
					ACSection.setMainCanvas(canvas);
					
					Tab tab = ACSection.getTab();
			        tab.setTitle("Provider management");
			        ACSection.getTabSet().updateTab(tab, canvas);
				}
				else if(event.getRecord().getAttributeAsString("name").equalsIgnoreCase("Reuters")) {
					Canvas canvas = new ACReutersCanvas();
					ACSection.setMainCanvas(canvas);
					
					Tab tab = ACSection.getTab();
			        tab.setTitle("Reuters");
			        ACSection.getTabSet().updateTab(tab, canvas);
				}
				else if(event.getRecord().getAttributeAsString("name").equalsIgnoreCase("Bloomberg")) {
					Canvas canvas = new Canvas();
					ACSection.setMainCanvas(canvas);
					
					Tab tab = ACSection.getTab();
			        tab.setTitle("Bloomberg");
			        ACSection.getTabSet().updateTab(tab, canvas);
				}
				else if(event.getRecord().getAttributeAsString("name").equalsIgnoreCase("Log")) {
					Canvas canvas = new ACLogCanvas();
					ACSection.setMainCanvas(canvas);
					
					Tab tab = ACSection.getTab();
			        tab.setTitle("Log");
			        ACSection.getTabSet().updateTab(tab, canvas);
				}
				else if(event.getRecord().getAttributeAsString("name").equalsIgnoreCase("Monitor")) {
					Canvas canvas = new ACMonitorCanvas();
					ACSection.setMainCanvas(canvas);
					
					Tab tab = ACSection.getTab();
			        tab.setTitle("Monitor");
			        ACSection.getTabSet().updateTab(tab, canvas);
				}
				else if(event.getRecord().getAttributeAsString("name").equalsIgnoreCase("Console")) {
					Canvas canvas = new ACConsoleCanvas();
					ACSection.setMainCanvas(canvas);
					
					Tab tab = ACSection.getTab();
			        tab.setTitle("Console");
			        ACSection.getTabSet().updateTab(tab, canvas);
				}
				else {
					
				}
				
			}
			
		});
	}
	

}
