package it.ccg.infoproviderweb.client.ac;



import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import com.google.gwt.core.client.JavaScriptObject;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.VisibilityMode;
import com.smartgwt.client.util.JSOHelper;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.CheckboxItem;
import com.smartgwt.client.widgets.form.fields.DateTimeItem;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.fields.events.ChangedEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangedHandler;
import com.smartgwt.client.widgets.form.validator.RegExpValidator;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.SectionStack;
import com.smartgwt.client.widgets.layout.SectionStackSection;
import com.smartgwt.client.widgets.layout.VLayout;

public class ACSchedulerCanvas extends Canvas {
	
	private ListGrid timerListGrid;
	
	
	public ACSchedulerCanvas() {
		super();
		this.setWidth100();
		this.setHeight100();
		this.setLeft(10);
		
		
		// grid section
        timerListGrid = this.createTimerListGrid();
        timerListGrid.setHeight("65%");
        
        SectionStackSection timerGridSectionStackSection = new SectionStackSection("Active timers");
        timerGridSectionStackSection.setItems(timerListGrid);
        timerGridSectionStackSection.setExpanded(true);
        timerGridSectionStackSection.setResizeable(false);
        timerGridSectionStackSection.setCanCollapse(false);
        // grid section
		
        
        // add timer section
        final VLayout addTimerDynamicFormLayout = this.createAddTimerFormLayout();
		
        SectionStackSection addTimerSectionStackSection = new SectionStackSection("Add new timer");
        addTimerSectionStackSection.setItems(addTimerDynamicFormLayout);
        addTimerSectionStackSection.setExpanded(true);
        addTimerSectionStackSection.setResizeable(false);
        // add timer section
        
        
        // start now section
        SectionStackSection startBatchSectionStackSection = new SectionStackSection("Execute batch");
        
        final VLayout startBatchDynamicFormLayout = this.createStartBatchFormLayout();
        VLayout startBatchLayout = new VLayout();
        startBatchLayout.addMember(startBatchDynamicFormLayout);
        //startBatchLayout.setLayoutBottomMargin(10);
        
        startBatchSectionStackSection.setItems(startBatchLayout);
        startBatchSectionStackSection.setExpanded(false);
        startBatchSectionStackSection.setResizeable(false);
        startBatchSectionStackSection.setCanCollapse(true);
        // start now section
        
        
        SectionStack sectionStack = new SectionStack();
        sectionStack.setWidth100();
        sectionStack.setHeight100();
        sectionStack.setVisibilityMode(VisibilityMode.MULTIPLE);  
        sectionStack.setAnimateSections(true);
        
        sectionStack.setSections(timerGridSectionStackSection, addTimerSectionStackSection, startBatchSectionStackSection);
        
        
        this.addChild(sectionStack);
		
	}
	
	
	
	private ListGrid createTimerListGrid() {
		ListGrid timerGrid = new ListGrid();
		
		DataSource dataSource = DataSource.get("timer");
		timerGrid.setDataSource(dataSource);
		
		/*int timerGridWidth = 0;
		DataSourceField[] fields = timerGrid.getDataSource().getFields();
		for(DataSourceField field : fields) {
			timerGridWidth += field.getLength();
		}
		timerGrid.setWidth(timerGridWidth);*/
		
		timerGrid.setAutoFetchData(true);
		timerGrid.setCanRemoveRecords(true);
		
		
		timerGrid.setFetchOperation("fetch");
		timerGrid.setUpdateOperation("update");
		timerGrid.setRemoveOperation("remove");
		
		
		return timerGrid;
	}
	
	
	private VLayout createAddTimerFormLayout() {
		final DynamicForm dynamicForm = new DynamicForm();
		
		final DataSource timerDataSource = DataSource.get("timer");
		//dynamicForm.setDataSource(timerDataSource);
		
		
		
		// setto i valori type
		/*timerDataSource.performCustomOperation("fetchTimerTypes", new Record(), new DSCallback() {
			
			@Override
			public void execute(DSResponse response, Object rawData, DSRequest request) {
				
				Record[] data = response.getData();
				
				Map<String, String> valueMap = new HashMap<String, String>();
				
				for(Record record : data) {
					valueMap.put(record.getAttribute("type"), record.getAttribute("type"));
				}
				
				DataSourceField typeField = timerDataSource.getField("type");
				
				
				typeField.setValueMap(valueMap);
				
			}
		}, new DSRequest());*/
		
		

		// name text item
	 	TextItem nameTextItem = new TextItem("name"); 
	 	nameTextItem.setType("text");
	 	nameTextItem.setRequired(true);
	 	nameTextItem.setTitle("Name"); 
	 	
	 	// start date item
        final DateTimeItem startDateTimeItem = new DateTimeItem("startDateTime"); 
        startDateTimeItem.setType("datetime");
        startDateTimeItem.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATETIME);
        startDateTimeItem.setRequired(true);
        startDateTimeItem.setTitle("Start date time");
        
        // interval text item
        final TextItem intervalTextItem = new TextItem("interval");
        intervalTextItem.setRequired(false);
        intervalTextItem.setTitle("Interval");
        intervalTextItem.disable();
        RegExpValidator regExpValidator = new RegExpValidator("^[0-9]*d-[0-9]*h-[0-9]*m$");
        regExpValidator.setErrorMessage("Interval value must match pattern \'Nd-Nh-Nm\'");
        intervalTextItem.setValidators(regExpValidator);
        intervalTextItem.setHint("<nobr>Nd-Nh-Nm</nobr>"); 
        
        
        
        // isSingle Checkbox
        final CheckboxItem isSingleCheckboxItem = new CheckboxItem("isSingle");
        isSingleCheckboxItem.setType("boolean");
        isSingleCheckboxItem.setTitle("Single action timer");
        isSingleCheckboxItem.setDefaultValue(true);
        isSingleCheckboxItem.addChangedHandler(new ChangedHandler() {
			
			@Override
			public void onChanged(ChangedEvent event) {
				if(isSingleCheckboxItem.getValueAsBoolean()) {
					intervalTextItem.disable();
					intervalTextItem.setRequired(false);
				}
				else {
					intervalTextItem.enable();
					intervalTextItem.setRequired(true);
				}
			}
		});
        
        // type select item
        final SelectItem providerSelectItem = new SelectItem("provider");
        providerSelectItem.setType("enum");
        providerSelectItem.setRequired(true);
        providerSelectItem.setTitle("Provider");
        LinkedHashMap<String, String> providerSelectItemValueMap = new LinkedHashMap<String, String>();
        providerSelectItemValueMap.put("Bloomberg", "Bloomberg");
        providerSelectItemValueMap.put("Reuters", "Reuters");
        providerSelectItem.setValueMap(providerSelectItemValueMap);
	
        // batch select item
        final SelectItem batchSelectItem = new SelectItem("batchName");
        batchSelectItem.setType("enum");
        batchSelectItem.setRequired(true);
        batchSelectItem.setTitle("Batch name");
        //batchSelectItem.setDefaultValue("<nobr><em>[Select a timer type]</em></nobr>");
        
        providerSelectItem.addChangedHandler(new ChangedHandler() {
			
			@Override
			public void onChanged(ChangedEvent event) {
				
				DSRequest dsRequest = new DSRequest();
				Map<String,String> params = new HashMap<String, String>();
				params.put("provider", providerSelectItem.getValueAsString());
				dsRequest.setParams(params);
				
				// setto i valori batch
				timerDataSource.performCustomOperation("fetchBatches", new Record(), new DSCallback() {
					
					@Override
					public void execute(DSResponse response, Object rawData, DSRequest request) {
						
						Record[] data = response.getData();
						
						LinkedHashMap<String, String> valueMap = new LinkedHashMap<String, String>();
						
						for(Record record : data) {
							valueMap.put(record.getAttributeAsString("batchName"), record.getAttributeAsString("batchName"));
						}
						
						batchSelectItem.setValueMap(valueMap);
					}
				}, dsRequest);
				
			}
		});
	    
	        
		dynamicForm.setItems(nameTextItem, startDateTimeItem, isSingleCheckboxItem, intervalTextItem, providerSelectItem, batchSelectItem);
		
		
		// buttons
        final IButton addButton = new IButton();
        addButton.setTitle("Add");
        addButton.setHeight(25);
        addButton.setWidth(60);
        addButton.setAlign(Alignment.CENTER);
        addButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(!dynamicForm.validate()) {
        			return;
        		}
				
				//
				Date startDateTime =  startDateTimeItem.getValueAsDate();
				long startDateTimeMillis = startDateTime.getTime();
				
				long currentTimeMillis = System.currentTimeMillis();
				
				if(startDateTimeMillis < currentTimeMillis) {
					
					SC.say("Start date time must be greater than current date time.");
					
					return;
				}
				
				
				Record record = dynamicForm.getValuesAsRecord();
				
				//
				if(!isSingleCheckboxItem.getValueAsBoolean()) {
					String intervalString = intervalTextItem.getValueAsString();
					String[] components = intervalString.split("-");
					long daysInMillis = (Long.parseLong((components[0].substring(0, components[0].length() - 1))))*24*60*60*1000;
					long hoursInMillis = (Long.parseLong((components[1].substring(0, components[1].length() - 1))))*60*60*1000;
					long minutesInMillis = (Long.parseLong((components[2].substring(0, components[2].length() - 1))))*60*1000;
					
					long totalMillis = daysInMillis + hoursInMillis + minutesInMillis;
					
					
					
					JavaScriptObject javaScriptObject = record.getJsObj();
					JSOHelper.setAttribute(javaScriptObject, "interval", totalMillis);
					
					record.setJsObj(javaScriptObject);
				}
				
				
				DSRequest dsRequest = new DSRequest();
				dsRequest.setWillHandleError(true);
				
				timerListGrid.addData(record, new DSCallback() {
					
					@SuppressWarnings("rawtypes")
					@Override
					public void execute(DSResponse response, Object rawData, DSRequest request) {
						
						if(response.getStatus() != 0) {
							String errorMessage = new String();
							
							Map errorMap = response.getErrors();
							Set keySet = errorMap.keySet();
							
							for(Object key : keySet) {
								errorMessage += ((Map)errorMap.get(key)).get("errorMessage") + "<br>";
							}
							
							SC.say(errorMessage);
						}
						
					}
				}, dsRequest);
				
				
				
				dynamicForm.reset();
				
			}
		});
        
        final IButton cancelButton = new IButton();
        cancelButton.setTitle("Cancel");
        cancelButton.setHeight(25);
        cancelButton.setWidth(60);
        cancelButton.setAlign(Alignment.CENTER);
        cancelButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				dynamicForm.reset();
				
			}
		});
        
        
        
        HLayout hButtonLayout = new HLayout();  
        hButtonLayout.setMembersMargin(15);
        //hLayout.setAutoHeight();
        hButtonLayout.setLayoutTopMargin(10);
        hButtonLayout.setLayoutLeftMargin(240);
        hButtonLayout.addMember(cancelButton);  
        hButtonLayout.addMember(addButton);
        // buttons
        
        
        VLayout vLayout = new VLayout();
        vLayout.addMember(dynamicForm);
        vLayout.addMember(hButtonLayout);
        vLayout.setLayoutBottomMargin(10);
		
		
		
		return vLayout;
	}
	
	
	private VLayout createStartBatchFormLayout() {
		
		final DynamicForm dynamicForm = new DynamicForm();
		
		final DataSource timerDataSource = DataSource.get("timer");
		
		new DynamicForm();
		
        // type select item
        final SelectItem providerSelectItem = new SelectItem("provider");
        providerSelectItem.setType("enum");
        providerSelectItem.setRequired(true);
        providerSelectItem.setTitle("Provider");
        LinkedHashMap<String, String> providerSelectItemValueMap = new LinkedHashMap<String, String>();
        providerSelectItemValueMap.put("Bloomberg", "Bloomberg");
        providerSelectItemValueMap.put("Reuters", "Reuters");
        providerSelectItem.setValueMap(providerSelectItemValueMap);
	
        // batch select item
        final SelectItem batchSelectItem = new SelectItem("batchName");
        batchSelectItem.setType("enum");
        batchSelectItem.setRequired(true);
        batchSelectItem.setTitle("Batch name");
        //batchSelectItem.setDefaultValue("<nobr><em>[Select a timer type]</em></nobr>");
        
        providerSelectItem.addChangedHandler(new ChangedHandler() {
			
			@Override
			public void onChanged(ChangedEvent event) {
				
				DSRequest dsRequest = new DSRequest();
				Map<String,String> params = new HashMap<String, String>();
				params.put("provider", providerSelectItem.getValueAsString());
				dsRequest.setParams(params);
				
				// setto i valori batch
				timerDataSource.performCustomOperation("fetchBatches", new Record(), new DSCallback() {
					
					@Override
					public void execute(DSResponse response, Object rawData, DSRequest request) {
						
						Record[] data = response.getData();
						
						LinkedHashMap<String, String> valueMap = new LinkedHashMap<String, String>();
						
						for(Record record : data) {
							valueMap.put(record.getAttributeAsString("batchName"), record.getAttributeAsString("batchName"));
						}
						
						batchSelectItem.setValueMap(valueMap);
					}
				}, dsRequest);
				
			}
		});
        
        dynamicForm.setItems(providerSelectItem, batchSelectItem);
		
        
		// button
		HLayout buttonsLayout = new HLayout();
		
		IButton startBatchButton = new IButton("Start batch");
		startBatchButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				

				if(!dynamicForm.validate()) {
        			return;
        		}
				
				RPCRequest rpcRequest = new RPCRequest();
				rpcRequest.setActionURL("servlet/ExecuteBatch");
				
				Map<String,String> params = new HashMap<String, String>();
				params.put("provider", providerSelectItem.getValueAsString());
				params.put("batchName", batchSelectItem.getValueAsString());
				rpcRequest.setParams(params);
				
				RPCManager.sendRequest(rpcRequest, new RPCCallback() {
					
					public void execute(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						@SuppressWarnings("unchecked")
						Map<String, Object> data = response.getAttributeAsMap("data");
						
						String status = (String)data.get("status");
						String msg = (String)data.get("msg");
						
						if(status.equalsIgnoreCase("0")) {
							SC.say("Execute batch info", "Info: " + msg);
						}
						else if(status.equalsIgnoreCase("-1")) {
							SC.say("Execute batch info", "Error" + msg);
						}
						
					}
					
				});
				
				
				dynamicForm.reset();
				
			}
			
		});
		
		buttonsLayout.addMember(startBatchButton);
		
		buttonsLayout.setLayoutTopMargin(10);
		buttonsLayout.setLayoutLeftMargin(240);
		
		// button
		
		
		
		
		VLayout layout = new VLayout();
		layout.addMember(dynamicForm);
		layout.addMember(buttonsLayout);
		
		
		
		return layout;
	}

}
