package it.ccg.infoproviderweb.client.ac;



import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.tab.Tab;
import com.smartgwt.client.widgets.tab.TabSet;

public class ACSection extends Canvas {
	
	final private ACTreeGrid treeGrid = new ACTreeGrid();
	
	private static TabSet tabSet;
	private static Tab tab;
	private static Canvas mainCanvas;
	
	
	public ACSection() {
		super();
		this.setHeight100();
		this.setWidth100();
		
		HLayout hLayout = new HLayout();
		hLayout.setWidth100();
		hLayout.setHeight100();
		
		
		// initial canvas into tabset
		mainCanvas = new ACHomeCanvas();
		
		// tab set ----------------------------------------------------------------------
		tabSet = new TabSet();
        tab = new Tab("Home");
        tab.setPane(mainCanvas);
        tabSet.setTabs(tab);
        // ------------------------------------------------------------------------------
		
        
		hLayout.setMembers(treeGrid, tabSet);
		
		this.addChild(hLayout);
	}




	public static Canvas getMainCanvas() {
		return mainCanvas;
	}


	public static void setMainCanvas(Canvas mainCanvas) {
		ACSection.mainCanvas = mainCanvas;
	}




	public static TabSet getTabSet() {
		return tabSet;
	}




	public static void setTabSet(TabSet tabSet) {
		ACSection.tabSet = tabSet;
	}




	public static Tab getTab() {
		return tab;
	}




	public static void setTab(Tab tab) {
		ACSection.tab = tab;
	}

}
