package it.ccg.infoproviderweb.client.ac;

import com.smartgwt.client.widgets.Canvas;

public class ACBloombergCanvas extends Canvas {

}
