package it.ccg.infoproviderweb.client;


import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.RPCTransport;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.LinkItem;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwtpower.client.widgets.BatchUploader;


public class ImportWindow extends Window {
	
	
	public static ImportWindow getInstance(ListGrid priceGrid) {
		final ImportWindow importWindow = new ImportWindow(priceGrid);
		
		importWindow.addCloseClickHandler(new CloseClickHandler() {
			
			@Override
			public void onCloseClick(CloseClickEvent event) {
				 
				 importWindow.destroy();
			}
		});
		
		return importWindow;
	}
	
	
	public ImportWindow(ListGrid priceGrid) {
		
		this.setWidth(600);
		this.setHeight(300);
		this.setAlign(Alignment.CENTER);
		
		this.setTitle("Select File to import...");
		this.setShowMinimizeButton(false);
		this.setIsModal(true);
		this.setShowModalMask(true);
		this.centerInPage();
		this.setCanDragReposition(true);  
		this.setCanDragResize(true);  
		this.setKeepInParentRect(true);
		
		final DataSource dataSource = priceGrid.getDataSource();
		
		
		Label label = new Label();
		label.setHeight(30);  
		label.setPadding(10);
		label.setMargin(10);
		label.setWidth100();
		label.setWrap(false);  
		label.setIcon("icons/userinfo.png");
		label.setContents("Learn how to correctly format your input file with this example.");
		label.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				RPCRequest rpcRequest = new RPCRequest();
				rpcRequest.setHttpMethod("POST");
				// Sto dicendo al client di aprire un hidden frame dal quale generare la richiesta in POST
				rpcRequest.setTransport(RPCTransport.HIDDENFRAME);
				String filePath = "templates/instr-example.csv";
				rpcRequest.setActionURL("servlet/GenericFileDownload?filePath=" + filePath);
				
				RPCManager.sendRequest(rpcRequest);
				
			}
		});
		
		LinkItem downloadExampleLink = new LinkItem();
		downloadExampleLink.setShowTitle(false);
		downloadExampleLink.setLinkTitle("<font color=\"005596\">Download example</font>");
		downloadExampleLink.addClickHandler(new com.smartgwt.client.widgets.form.fields.events.ClickHandler() {
			
			@Override
			public void onClick(com.smartgwt.client.widgets.form.fields.events.ClickEvent event) {
				RPCRequest rpcRequest = new RPCRequest();
				rpcRequest.setHttpMethod("POST");
				// Sto dicendo al client di aprire un hidden frame dal quale generare la richiesta in POST
				rpcRequest.setTransport(RPCTransport.HIDDENFRAME);
				String filePath = "templates/instr-example.csv";
				rpcRequest.setActionURL("servlet/GenericFileDownload?filePath=" + filePath);
				
				RPCManager.sendRequest(rpcRequest);
			}
			
		});
		
		DynamicForm dynamicForm = new DynamicForm();
		dynamicForm.setHeight(30);  
		dynamicForm.setPadding(10);
		dynamicForm.setMargin(10);
		dynamicForm.setItems(downloadExampleLink);
		
		HLayout labelHLayout = new HLayout();
		labelHLayout.setShowEdges(true);
		labelHLayout.setMembers(label, dynamicForm);
		
		
		BatchUploader batchUploader = new BatchUploader();  
		batchUploader.setWidth("100%"); 
		batchUploader.setHeight("100%");
		batchUploader.setMargin(10);
		batchUploader.setAlign(Alignment.CENTER);
		batchUploader.setUploadDataSource(dataSource);
		 
		 
		VLayout vLayout = new VLayout();
		vLayout.setMargin(10);
		vLayout.setHeight(200);
		vLayout.setMembersMargin(20);
		vLayout.setAlign(Alignment.CENTER);
		vLayout.setWidth("100%");
		vLayout.addMember(labelHLayout);
		vLayout.addMember(batchUploader);
		 
		this.addItem(vLayout);
	 
	 
		this.draw();
		
	}
	

}
