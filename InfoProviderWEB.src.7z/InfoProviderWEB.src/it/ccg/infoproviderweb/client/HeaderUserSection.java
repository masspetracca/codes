package it.ccg.infoproviderweb.client;



import it.ccg.infoproviderweb.client.data.UserData;

import java.util.List;
import java.util.Map;

import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.LinkItem;
import com.smartgwt.client.widgets.form.fields.events.ClickEvent;
import com.smartgwt.client.widgets.form.fields.events.ClickHandler;
import com.smartgwt.client.widgets.layout.VLayout;


public class HeaderUserSection extends Canvas {
	
	private LinkItem accountLink = new LinkItem();
	
	private Window accountWindow = new Window();
	private LinkItem logoutLink = new LinkItem();
	private LinkItem manageAccountLink = new LinkItem();
	
	private LinkItem smartGwtConsoleLink = new LinkItem();
	
	
	
	
	public HeaderUserSection(final MainLayout su) {
		
		this.setWidth("10%");
		
		
		DynamicForm dynamicForm = new DynamicForm();
		dynamicForm.setItems(accountLink);
		
		dynamicForm.setTop(10);
		
		this.addChild(dynamicForm);
		
		
		this.initAccountLink();
		this.initLogoutLink();
		this.initManageAccountLink();
		this.initAccountWindow();
		
		this.initSmartGwtConsoleLink();
		
	}
	
	
	private void initAccountLink() {
		
		accountLink.setShowTitle(false);
		
		accountLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				accountWindow.show();
			}
			
		});
		
		
		List<String> currentUserRolesList = UserData.getCurrentUserData().getUserRolesList();
		
		String rolesString = "";
		for(String role : currentUserRolesList) {
			rolesString += role + ", ";
		}
		rolesString = rolesString.substring(0, rolesString.length() - 2);
		
		//
		accountLink.setLinkTitle("<font color=\"005596\"><b>" + UserData.getCurrentUserData().getName() + " " + UserData.getCurrentUserData().getSurname() + "</b> " + "(" + rolesString + ")"+"</font>");
		
	}
	
	
	private void initLogoutLink() {
		logoutLink.setShowTitle(false);
		logoutLink.setLinkTitle("<font color=\"005596\">Logout</font>");
		
		logoutLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				RPCRequest rpcRequest = new RPCRequest();
				
				
				rpcRequest.setActionURL("Logout");
				
				RPCManager.sendRequest(rpcRequest, new RPCCallback() {
					
					@Override
					public void execute(RPCResponse response, Object rawData, RPCRequest request) {
						
						@SuppressWarnings("unchecked")
						Map<Object, Object> httpHeader = response.getHttpHeaders();
						
						
						Object location = httpHeader.get("Location");
						
						//com.google.gwt.user.client.Window.Location.assign("/InfoProviderWEB/login.html");
						com.google.gwt.user.client.Window.Location.assign((String)location);
						
						
						//com.google.gwt.user.client.Window.Location.reload();
						
					}
				});
				
			}
			
		});
	}
	
	
	private void initManageAccountLink() {
		manageAccountLink.setShowTitle(false);
		manageAccountLink.setLinkTitle("<font color=\"005596\">Manage profile</font>");
		
		manageAccountLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				// TODO Auto-generated method stub
				
			}
		});
	}
	

	private void initAccountWindow() {
		
		accountWindow.setID("AccountMenuWindow");
		
		accountWindow.setWidth(170);
		accountWindow.setHeight(105);
		accountWindow.setMembersMargin(5);
		accountWindow.setTop(45);
		accountWindow.setShadowSoftness(10);  
		accountWindow.setShadowOffset(10); 
		accountWindow.setHeaderStyle("formattedWindowHeader");
		accountWindow.setBorder("formattedWindowHeader"); 
		
		accountWindow.setShowCloseButton(true);
		accountWindow.setShowMinimizeButton(false);
		accountWindow.setShowShadow(true);  
		accountWindow.setShowEdges(false);
		accountWindow.setCanDragReposition(false);
		accountWindow.setCanDragResize(false);
		
		accountWindow.setBackgroundColor("FAFAFA");
		accountWindow.setBorder("1px solid #c0c0c0");

		
		DynamicForm manageAccountDynamicForm = new DynamicForm();
		manageAccountDynamicForm.setItems(manageAccountLink);
		
		DynamicForm smartGwtConsoleLinkDynamicForm = new DynamicForm();
		smartGwtConsoleLinkDynamicForm.setItems(smartGwtConsoleLink);
		
		DynamicForm logoutLinkDynamicForm = new DynamicForm();
		logoutLinkDynamicForm.setItems(logoutLink);
		
		VLayout vLayout = new VLayout();
		vLayout.setWidth100();
		vLayout.setTop(22);
		
		vLayout.setMembers(/*manageAccountDynamicForm,*/logoutLinkDynamicForm, smartGwtConsoleLinkDynamicForm);
		
		
		accountWindow.addChild(vLayout);
		
		
		accountWindow.hide();
	}


	public Window getAccountWindow() {
		
		return accountWindow;
	}
	
	

	
	private void initSmartGwtConsoleLink() {
		
		smartGwtConsoleLink.setShowTitle(false);
		
		smartGwtConsoleLink.setLinkTitle("<font color=\"005596\">SmartGwt Console</font>");
		
		if(!UserData.getCurrentUserData().getUserRolesList().contains("admin")) {
			smartGwtConsoleLink.setVisible(false);
		}
		
		
		smartGwtConsoleLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				SC.showConsole();
			}
			
		});
		
	}
	

}
