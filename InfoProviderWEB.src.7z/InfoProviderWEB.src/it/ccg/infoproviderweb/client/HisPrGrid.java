package it.ccg.infoproviderweb.client;


import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.DataSourceField;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.ListGridFieldType;
import com.smartgwt.client.widgets.grid.CellFormatter;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;


public class HisPrGrid extends ListGrid {
	
	
	public HisPrGrid(String gridId) {
		super();
		super.setID(gridId);
	}
	
	
	public HisPrGrid(String gridId, String width) {
		super();
		super.setID(gridId);
		this.setWidth(width);
	}
	
	
	public HisPrGrid(String gridId, String width, int instrId) {
		
		super();
		super.setID(gridId);
		this.setWidth(width);
		
		this.setAlternateRecordStyles(true);
		
		
		this.setDataSource(DataSource.getDataSource("hisPr.instrHis"));
		
		this.setFetchOperation("fetchInstrHis");
		
		
		Criteria criteria = new Criteria("instrId", Integer.toString(instrId));
		this.setInitialCriteria(criteria);
		this.setAutoFetchData(true);
		
		this.setFilterEditorCriteria(criteria);
		this.setShowFilterEditor(true);
		
		
		// default DataSourceField properties
		this.setDSFieldsDefaultProperties();
		
		// I set detail=false for each DataSourceField i want to see at startup, detail=false for others
		String[] fieldsNames = {"priceDate", "closingPrice"};
		this.showFieldsList(fieldsNames);
		
		// map each DataSourceField with a ListGridField
		this.mapDSFieldsWithLGFields();
		
		//default ListGridField properties
		this.setLGFieldsDefaultProperties();
		
		// date fields format
		String[] dateFields = {"priceDate"};
		this.setDateFieldsFormat(dateFields);
		
	}
	
	
	
	private void setDSFieldsDefaultProperties() {
		DataSource datasource = this.getDataSource();
		DataSourceField[] dsFields = datasource.getFields();
		
		for(DataSourceField dsField : dsFields) {
			
		}
	}
	
	
	private void showFieldsList(String[] fieldsNames) {
		DataSource datasource = this.getDataSource();
		DataSourceField[] dsFields = datasource.getFields();
		
		for(DataSourceField dsField : dsFields) {
			dsField.setAttribute("detail", true);
			
			for(String fieldName : fieldsNames) {
				if(dsField.getName().equalsIgnoreCase(fieldName)) {
					dsField.setAttribute("detail", false);
					
					continue;
				}
			}
		}
	}
	
	
	
	private void mapDSFieldsWithLGFields() {
		DataSource datasource = this.getDataSource();
		DataSourceField[] dsFields = datasource.getFields();
		
		ListGridField[] lgFields = new ListGridField[dsFields.length];
		for(int i=0; i<lgFields.length; i++) {
			ListGridField lgField = new ListGridField();
			lgField.setName(dsFields[i].getName());
			lgField.setTitle(dsFields[i].getTitle());
			
			lgFields[i] = lgField;
		}
		
		
		this.setFields(lgFields);
	}
	
	
	private void setLGFieldsDefaultProperties() {
		ListGridField[] lgFields = this.getAllFields();
		
		for(ListGridField lgField : lgFields) {
			lgField.setAlign(Alignment.LEFT);
		}
	}
	
	
	private void setDateFieldsFormat(String[] dataFieldsNames) {
		ListGridField[] lgFields = this.getAllFields();
		
		for(ListGridField lgField : lgFields) {
			for(String fieldName : dataFieldsNames) {
				if(lgField.getName().equalsIgnoreCase(fieldName)) {
					//lgField.setType(ListGridFieldType.DATE);
					
					lgField.setCellFormatter(new CellFormatter() {
						
						@Override
						public String format(Object value, ListGridRecord record, int rowNum, int colNum) {
							if(value != null) {
								String expiry = value.toString();
								String year = expiry.substring(0, 4);
							    String month = expiry.substring(4, 6);
							    String day = expiry.substring(6, 8);
							    
							    return day + "/" + month + "/" + year;
							}
							
							else return "";
						}
						
					});
					
					continue;
				}
			}
		}
	}
	

}

