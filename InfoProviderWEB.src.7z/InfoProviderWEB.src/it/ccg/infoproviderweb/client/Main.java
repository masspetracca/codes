package it.ccg.infoproviderweb.client;


import it.ccg.infoproviderweb.client.data.UserData;

import java.util.List;
import java.util.Map;

import com.google.gwt.core.client.EntryPoint;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;


public class Main implements EntryPoint {

	@Override
	public void onModuleLoad() {
		
		RPCRequest rpcRequest = new RPCRequest();
		rpcRequest.setActionURL("servlet/UserInfo");
		
		RPCManager.sendRequest(rpcRequest, new RPCCallback() {
			@SuppressWarnings("unchecked")
			public void execute(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				Map<String, Object> data = response.getAttributeAsMap("data");
				
				String name = (String)data.get("name");
				String surname = (String)data.get("surname");
				List<String> userRolesList = (List<String>)data.get("roles");
				
				UserData.setCurrentUserData(new UserData(name, surname, userRolesList));
				
				
				MainLayout.createInstance();
				
			}

		});
		
	}
	

}
