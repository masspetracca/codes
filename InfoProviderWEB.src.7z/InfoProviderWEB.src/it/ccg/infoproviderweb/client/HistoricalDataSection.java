package it.ccg.infoproviderweb.client;



import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.layout.HLayout;

public class HistoricalDataSection extends Canvas {
	
	
	private HLayout gridsLayout = new HLayout();
	
	private HisInfoGrid infoGrid = new HisInfoGrid("infoGrid");
	private HisPrGrid hisPrGrid = new HisPrGrid("hisPrGrid");
	
	
	public static HistoricalDataSection getInstance() {
		HistoricalDataSection historicalDataSection = new HistoricalDataSection();

		historicalDataSection.gridsLayout.addMember(HisInfoGrid.getInstance("infoGrid", "70%"), 0);
		historicalDataSection.gridsLayout.addMember(new HisPrGrid("hisPrGrid", "30%"), 1);
		
		
		return historicalDataSection;
	}
	
	
	
	public HistoricalDataSection() {
		super();
		this.setID("HistoricalDataSection");
		
		this.setHeight100();
		this.setWidth100();
		
		this.gridsLayout.setHeight("100%");
		this.gridsLayout.setWidth("100%");

		this.gridsLayout.setMembersMargin(10);
		
		this.addChild(gridsLayout);
	}
	
	

	public HLayout getGridsLayout() {
		return gridsLayout;
	}


	public void setGridsLayout(HLayout gridsLayout) {
		this.gridsLayout = gridsLayout;
	}



	public HisInfoGrid getInfoGrid() {
		return infoGrid;
	}



	public void setInfoGrid(HisInfoGrid infoGrid) {
		this.infoGrid = infoGrid;
	}



	public HisPrGrid getHisPrGrid() {
		return hisPrGrid;
	}



	public void setHisPrGrid(HisPrGrid hisPrGrid) {
		this.hisPrGrid = hisPrGrid;
	}
	
	
}
