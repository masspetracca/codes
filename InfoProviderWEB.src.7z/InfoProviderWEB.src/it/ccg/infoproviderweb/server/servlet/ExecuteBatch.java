package it.ccg.infoproviderweb.server.servlet;

import it.ccg.infoprovider.server.bean.business.BloombergBatchBeanLocal;
import it.ccg.infoprovider.server.bean.business.ReutersBatchBeanLocal;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isomorphic.datasource.DSResponse;
import com.isomorphic.rpc.RPCManager;
import com.isomorphic.rpc.RPCResponse;

/**
 * Servlet implementation class ExecuteBatch
 */
public class ExecuteBatch extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	@EJB
	private BloombergBatchBeanLocal bloombergBatchBeanLocal;
	
	@EJB
	private ReutersBatchBeanLocal reutersBatchBeanLocal;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ExecuteBatch() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Creo l'oggetto RPC per la gestione SmartGWT dei parametri della servlet
		RPCManager rpcManager = null;
		try {
			rpcManager = new RPCManager(request, response);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		RPCResponse rpcResponse = new RPCResponse();
		
		// creo una map per la risposta
		Map<String, Object> responseData = new HashMap<String, Object>();
		
		try {
			
			String providerValue = request.getParameter("provider");
			String batchNameValue = request.getParameter("batchName");
			
			if(providerValue == null || batchNameValue == null) {
				
				// TODO
			}
			
			if(providerValue.equalsIgnoreCase("Bloomberg")) {
				if(batchNameValue.equalsIgnoreCase("currencyDataDownload")) {
					this.bloombergBatchBeanLocal.currencyDataDownload();
					
					responseData.put("status", "0");
					responseData.put("msg", "Batch \'" + batchNameValue + "\' successfully executed.");
				}
				else if(batchNameValue.equalsIgnoreCase("bondRatingDataDownload")) {
					this.bloombergBatchBeanLocal.bondRatingDataDownload();
					
					responseData.put("status", "0");
					responseData.put("msg", "Batch \'" + batchNameValue + "\' successfully executed.");
				}
				else {
					
					responseData.put("status", "-1");
					responseData.put("msg", "Batch \'" + batchNameValue + "\' doesn't exist.");
				}
			}
			else if(providerValue.equalsIgnoreCase("Reuters")) {
				if(batchNameValue.equalsIgnoreCase("bondInterestRatesBatch")) {
					this.reutersBatchBeanLocal.bondInterestRatesBatch();
					
					responseData.put("status", "0");
					responseData.put("msg", "Batch \'" + batchNameValue + "\' successfully executed.");
				}
				/*else if(batchNameValue.equalsIgnoreCase("bondRatingDataDownload")) {
					this.bloombergBatchBeanLocal.bondRatingDataDownload();
					
					responseData.put("status", "0");
					responseData.put("msg", "");
				}*/
				else {
					
					responseData.put("status", "-1");
					responseData.put("msg", "Batch \'" + batchNameValue + "\' doesn't exist.");
				}
			}
			else {
				
				responseData.put("status", "-1");
				responseData.put("msg", "Provider \'" + providerValue + "\' doesn't exist.");
				
			}
			
		}
		catch(Exception e) {
			Throwable su = e;
			while(su != null) {
				su.printStackTrace();
				
				su = su.getCause();
			}
			
			responseData.put("status", "-1");
			responseData.put("msg", e.toString());
			
			
		}
		finally {
			// creo una response e la popolo con con i parametri di risposta
			rpcResponse.setData(responseData);
			
			
			// restituzione del risultato
			try {
				rpcManager.send(rpcResponse);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
