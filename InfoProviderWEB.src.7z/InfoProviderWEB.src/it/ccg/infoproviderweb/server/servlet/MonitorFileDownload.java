package it.ccg.infoproviderweb.server.servlet;




import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.service.system.Role;
import it.ccg.infoprovider.server.util.LogLine;
import it.ccg.infoprovider.server.util.LogReader;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isomorphic.log.Logger;

/**
 * Servlet implementation class LogFile
 */
public class MonitorFileDownload extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	private static Logger logger = new Logger("it.ccg.infoproviderweb.server");
	
	private PrintWriter out;
	
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MonitorFileDownload() {
        super();
        
        this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    
       
	 /**
     * @see HttpServlet#HttpServlet()
     */


    protected void doWork(HttpServletRequest request, HttpServletResponse response) {
    	
    	logger.info(new StandardLogMessage(this.currentUser, "Monitor file download."));
    	
    	String neededRole = Role.ADMIN;
		
    	
    	// TODO 
    	// ServletFilter
    	if(request.isUserInRole(neededRole)) {
    		
    		try {
    			
    			this.out = response.getWriter();
    			
    			String fileName = request.getParameter("fileName");
    			
    			
    			out.println(this.getHtmlLog(fileName));
    			
    			

    		}
    		catch (Exception e) {
    			//Loggo sul log utente
    			logger.error(new StandardLogMessage(this.currentUser, e.toString()));
    			
    			StackTraceElement[] elements = e.getStackTrace();
    			for(StackTraceElement element : elements) {
    				logger.error(new StandardLogMessage(this.currentUser, element.toString()));
    			}
    			
    		}
    		
    	}
    	else{
    		logger.error(new StandardLogMessage(this.currentUser, "User \'" + this.currentUser  + "\' not in role \'" + neededRole + "\'."));
    	}


	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doWork(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doWork(request, response);
	}
	

	private String getHtmlLog(String fileName) throws Exception {
		
		String htmlPage = new String();
		htmlPage += "<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">" + "\n";
		
		//
    	LogReader logReader = new LogReader(fileName);
    	List<LogLine> log = logReader.getLog();
    	
    	if(log.size() > 0) {
    		
    		String htmlTable = "<table class=\"log\">";
    		
	    	for(LogLine logLine : log) {
	    		String textColor = "style=\"color:";
	    		
	    		if(logLine.getType().trim().equalsIgnoreCase("INFO")) {
	    			
	    			textColor += "#000000";
	    		}
	    		else if(logLine.getType().trim().equalsIgnoreCase("WARN")) {
	    			
	    			textColor += "#B17A0F";
	    		}
	    		else if(logLine.getType().trim().equalsIgnoreCase("ERROR")) {
	    			
	    			textColor += "#FF0000";
	    		}
	    		else if(logLine.getType().trim().equalsIgnoreCase("DEBUG")) {
	    			
	    			textColor += "#2569d0";
	    		}
	    		else {
	    			
	    			textColor += "#000000";
	    		}
	    		
	    		textColor+="\"";
	    		
	    		htmlTable+="<tr>" + "\n";
	    		
	    		htmlTable+="<td class=\"logDateTime\" " + textColor+">" + logLine.getDateTime() + "</td>" + "\n";
	    		htmlTable+="<td class=\"logType\" " + textColor+">" + logLine.getType() + "</td>" + "\n";
	    		htmlTable+="<td class=\"logClassMethod\" " + textColor+">" + logLine.getClassMethod() + "</td>" + "\n";
	    		htmlTable+="<td class=\"logUser\" " + textColor+">" + logLine.getUser() + "</td>" + "\n";
	    		htmlTable+="<td class=\"logMessage\" " + textColor+">" + logLine.getMessage() + "</td>" + "\n";
	    		
	    		htmlTable+="</tr>" + "\n";
	    	}
	    	
	    	htmlTable += "</table>" + "\n";
	    	
	    	htmlPage += htmlTable + "\n";
    	}
    	else {
	    	
	    	htmlPage += "No available messages for this log." + "\n";
	    }
    	
    	return htmlPage;
	}
	

}
