package it.ccg.infoproviderweb.server.servlet.security;

//import it.ccg.pamp.server.security.PwdManagerLocal;

import java.io.IOException;
import java.util.HashMap;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isomorphic.log.Logger;
import com.isomorphic.rpc.RPCManager;
import com.isomorphic.rpc.RPCRequest;
import com.isomorphic.rpc.RPCResponse;

/**
 * Servlet implementation class ChangePassword
 */
public class ChangePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//@EJB PwdManagerLocal pwmanager;

	protected void doWork(HttpServletRequest request, HttpServletResponse response) {

		/*//Logger
		Logger log = new Logger(it.ccg.pamp.server.servlet.loginlogout.ChangePassword.class.getName());
		String logMessage = "User: " + request.getUserPrincipal().getName() + "| OperationName: ChangePassword"; 

		//Creo l'oggetto RPC per la gestione SmartGWT dei parametri della servlet
		RPCManager rpc = null;		
		try {
			rpc = new RPCManager(request, response);
		} catch (Exception rpcException) {
			System.out.println("Error creating RPCManager: "+rpcException.getMessage());
			System.out.println(rpcException.getStackTrace());
		}

		//Ottengo gli oggetti di richiesta e di risposta
		RPCRequest rpcRequest = rpc.getRequest();
		RPCResponse rpcResponse = new RPCResponse();

		// creo un hashmap per la risposta
		HashMap<String, String> responseParams = new HashMap<String, String>();

		

		try {
			//Parametri di ingresso
			String user = request.getParameter("USER");
			String oldPassword = request.getParameter("OLDPW");
			String newPassword = request.getParameter("NEWPW");
			
			

			//QUI VERRA RICHIAMATO IL METODO PER LA CHANGE PW. COME PARAMETRI USER, OLDPW, NEWPW	
			pwmanager.changeUserPassword(user, oldPassword, newPassword);

			//Popolo il parametro di risposta con una risposta positiva
			responseParams.put("RESULT", "0");

			//Loggo sul log utente
			log.info(logMessage);

		} catch (Exception e) {
			System.out.println("Servlet RPC error:");
			e.printStackTrace();
			

			//Popolo il parametro con una risposta negativa e restituisco il messaggio di errore
			String errorMessage = "Error changing password.";
			
			if(e.getMessage().startsWith("TOO"))
				errorMessage = "Account locked error.<br /> The account is now locked after 3 unsuccessful trials. Please wait 30 minutes to get it unlocked.";
				else if(e.getMessage().startsWith("USER"))
					errorMessage = "User not found.";
				else if(e.getMessage().startsWith("OLD"))
					errorMessage = "Old password not valid.";
				else if(e.getMessage().startsWith("PROBLEMS"))
					errorMessage = "Connection error. Please contact the server administrator.";
		
			
			responseParams.put("ERRORMESSAGE", errorMessage);
			responseParams.put("RESULT", "ERROR");

			//Loggo sul log utente
			log.error(logMessage);

		}

		// creo una response e la popolo con con i parametri di risposta
		rpcResponse.setData(responseParams);

		// restituzione del risultato
		try {
			rpc.send(rpcRequest,rpcResponse);
		} catch (Exception rpcException) {
			System.out.println("Error creating response: "+rpcException.getMessage());
			System.out.println(rpcException.getStackTrace().toString());
		}*/



	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doWork(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doWork(request, response);
	}


}