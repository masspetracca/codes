package it.ccg.infoproviderweb.server.servlet.security;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

public class LoginWrapper extends HttpServletResponseWrapper {

	String originalRedirect;

	public LoginWrapper(HttpServletResponse response) {
		super(response);
	}

	@Override
	public void sendRedirect(String location) throws IOException {
		// just store location, don�t send redirect to avoid
		// committing response
		originalRedirect = location;
	}

	// use this method to send redirect after modifying response
	public void sendMyRedirect() throws IOException {
		super.sendRedirect(originalRedirect);
	}
	
	public void sendMyRedirect(String newLocation) throws IOException {
		super.sendRedirect(newLocation);
	}

}
