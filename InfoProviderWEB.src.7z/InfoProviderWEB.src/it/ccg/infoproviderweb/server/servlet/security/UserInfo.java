package it.ccg.infoproviderweb.server.servlet.security;

import it.ccg.infoprovider.server.bean.eao.UserEAOLocal;
import it.ccg.infoprovider.server.bean.entity.User;

import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isomorphic.log.Logger;
import com.isomorphic.rpc.RPCManager;
import com.isomorphic.rpc.RPCResponse;


public class UserInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger logger = new Logger("it.ccg.infoproviderweb.server.servlet.security.UserInfo");
	
	
	@EJB
	private UserEAOLocal userEAOLocal;
	
	
	
	private static String[] availableRoles = {"user","visitor","admin","manager"};
       
    
    public UserInfo() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			//Creo l'oggetto RPC per la gestione SmartGWT dei parametri della servlet
			RPCManager rpcManager = new RPCManager(request, response);
			
			
			RPCResponse rpcResponse = new RPCResponse();
			
			// creo una map per la risposta
			Map<String, Object> responseData = new HashMap<String, Object>();
			
			
			Principal principal = request.getUserPrincipal();
			String currentUser = principal.getName();
			
			
			List<User> userList = userEAOLocal.fetchByUserName(currentUser);
			
			if(userList.size() != 1) {
				logger.error("ERROR");
				
				throw new Exception();
			}
			
			String name = userList.get(0).getName();
			String surname = userList.get(0).getSurname();
			
			
			List<String> rolesList = new ArrayList<String>();
			
			for(String role : availableRoles) {
				if(request.isUserInRole(role)) {
					rolesList.add(role);
				}
			}
			
			
			responseData.put("name", name);
			responseData.put("surname", surname);
			
			responseData.put("roles", rolesList);
			

			// creo una response e la popolo con con i parametri di risposta
			rpcResponse.setData(responseData);
			
			
			// restituzione del risultato
			rpcManager.send(rpcResponse);
			
			
			logger.debug("User data successfully fetched.");
			
		}
		catch (Exception e) {
			Throwable su = e;
			while(su != null) {
				su.printStackTrace();
				
				su = su.getCause();
			}
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
