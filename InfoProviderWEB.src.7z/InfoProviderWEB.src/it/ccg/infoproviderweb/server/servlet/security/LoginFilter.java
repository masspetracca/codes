package it.ccg.infoproviderweb.server.servlet.security;



import java.io.IOException;

import javax.naming.NamingException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import com.ibm.websphere.security.WSSecurityException;
import com.ibm.websphere.security.auth.WSLoginFailedException;
import com.ibm.websphere.security.auth.WSSubject;

/**
 * Servlet Filter implementation class LoginFilter
 */
public class LoginFilter implements Filter {

	@Override
	public void destroy() {

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// create wrapper
		String userName = (request.getParameter("j_username") != null && request.getParameter("j_username") != "") ? request.getParameter("j_username").trim():null;
		String password = (request.getParameter("j_password") != null && request.getParameter("j_password") != "") ? request.getParameter("j_password").trim():null;
		LoginWrapper myRes = new LoginWrapper((HttpServletResponse) response);
		chain.doFilter(request, myRes);
		// post login actions here
		Throwable t = WSSubject.getRootLoginException();
		if (t != null) {
			t = determineCause(t);
			Cookie c;
            //javax.naming.AuthenticationException: LDAP 49 INVALID CREDENTIALS
            //javax.naming.OperationNotSupportedException: LDAP 53 ACCOUNT LOCKED
			if (t instanceof javax.naming.AuthenticationException){
			 c = new Cookie("loginError", "Invalid credential error.<br /> After 3 wrong trials the account will be locked. To obtain a new password please contact the helpdesk.");
			}
			else if (t instanceof javax.naming.OperationNotSupportedException){
			 c = new Cookie("loginError", "Account locked error.<br /> The account is now locked after 3 unsuccessful trials. Please wait 30 minutes to get it unlocked.");//
			}
			else{
			 c = new Cookie("loginError", "Authentication failed.");
			}
			
			c.setMaxAge(-1);
			myRes.addCookie(c);
			myRes.sendMyRedirect("loginError.jsp");
		} else {
			if (userName.equals("") || password.equals("")) {
				myRes.sendMyRedirect("loginError.jsp");
			}
			else{
				// authentication successful, remove the cookie
				Cookie c = new Cookie("loginError", "");
				c.setMaxAge(0);
				myRes.addCookie(c);
				myRes.sendMyRedirect("index.html");
			}
		}
		// now it is safe to send redirect
		 
	}

	public Throwable determineCause(Throwable e) {
		Throwable rootEx = e, tempEx = null;
		// keep looping until there are no more embedded
		// WSLoginFailedException or WSSecurityException exceptions
		while (true) {
			if (e instanceof WSLoginFailedException) {
				tempEx = ((WSLoginFailedException) e).getCause();
			} else if (e instanceof WSSecurityException) {
				tempEx = ((WSSecurityException) e).getCause();
			} else if (e instanceof NamingException) {
				// check for Ldap embedded exception
				tempEx = ((NamingException) e).getRootCause();
			} else {
				// this is the root from the WebSphere
				// Application Server perspective
				return rootEx;
			}
			if (tempEx != null) {
				// we have nested exception, check it
				rootEx = tempEx;
				e = tempEx;
				continue;
			} else {
				// the cause was null, return parent
				return rootEx;
			}
		} // while
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}
}
