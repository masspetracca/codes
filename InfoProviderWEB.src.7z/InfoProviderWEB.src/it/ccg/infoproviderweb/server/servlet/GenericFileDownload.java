package it.ccg.infoproviderweb.server.servlet;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isomorphic.log.Logger;

/**
 * Servlet implementation class GenericFileDownload
 */
public class GenericFileDownload extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	Logger logger = new Logger(GenericFileDownload.class);
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GenericFileDownload() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doWork(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doWork(request, response);
	}
	
	
	
	protected void doWork(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			// Nome del file
			String filePath = request.getParameter("filePath").toString();
			
			//Recupero il fle per il download
			File file = new File(filePath);
			int length = 0;
			ServletOutputStream op = response.getOutputStream();
			response.setContentType("application/zip");
			response.setContentLength((int)file.length());
			response.setHeader("Content-Disposition","attachment; filename=\"" + file.getName() + "\"");
			byte[] bbuf = new byte[1024];
			DataInputStream in = new DataInputStream(new FileInputStream(file));

			while ((in != null) && ((length = in.read(bbuf)) != -1)) {
				op.write(bbuf, 0, length);
			}

			in.close();
			op.flush();
			op.close();
			
			
	
		}
		catch(Exception e) {
			e.printStackTrace();
			
			logger.error(e.toString());
		}
		
	}
	
	

}
