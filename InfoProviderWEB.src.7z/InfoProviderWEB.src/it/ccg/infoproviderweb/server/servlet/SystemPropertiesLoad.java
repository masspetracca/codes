package it.ccg.infoproviderweb.server.servlet;



import it.ccg.infoprovider.server.service.system.SystemProperties;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class PropertyRefresh
 */
public class SystemPropertiesLoad extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	private PrintWriter out;
	
	
	private static Logger logger =  Logger.getLogger("it.ccg.infoproviderweb.server");
	
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SystemPropertiesLoad() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    
    protected void doWork(HttpServletRequest request, HttpServletResponse response) {
    	
    	try {
			this.out = response.getWriter();
		} catch (IOException e) {
			e.printStackTrace();
			
			logger.error("Error creating \'out\' object.");
		}
    	
    	
    	
		try {
			SystemProperties.loadProperties();
		} catch(Exception e) {
			e.printStackTrace();
			
			logger.error("Error getting properties.");
		}
    	
    	
		out.println("Properties successfully loaded!");
		out.println();
		out.println();
		
    	
    	String rootPath = System.getProperty("user.install.root");
    	
    	FileReader fileReader = null;
		try {
			fileReader = new FileReader(rootPath + "/properties/infoprovider.system.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader bufferedReader = new BufferedReader(fileReader);    
    	try {
			String line = bufferedReader.readLine();
			
			while(line != null) {
				out.println(line);
				
				line = bufferedReader.readLine();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    }
    
    
    
    
    
    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doWork(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doWork(request, response);
	}

}
