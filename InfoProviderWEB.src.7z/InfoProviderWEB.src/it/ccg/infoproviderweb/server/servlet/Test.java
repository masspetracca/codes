package it.ccg.infoproviderweb.server.servlet;

import it.ccg.infoprovider.server.bean.entity.User;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.Principal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isomorphic.rpc.RPCManager;
import com.isomorphic.rpc.RPCResponse;

/**
 * Servlet implementation class Test
 */
public class Test extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	private PrintWriter out;
	
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Test() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    
    protected void doWork(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	this.out = response.getWriter();
    	
		try {
    		System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!  -  " + new Timestamp(System.currentTimeMillis()));
    		
    		
    		//Creo l'oggetto RPC per la gestione SmartGWT dei parametri della servlet
			RPCManager rpcManager = new RPCManager(request, response);
			
			
			RPCResponse rpcResponse = new RPCResponse();
			
			// creo una map per la risposta
			Map<String, Object> responseData = new HashMap<String, Object>();
			
			
			responseData.put("testMessage", new Timestamp(System.currentTimeMillis()).toString());
			
			
			// creo una response e la popolo con con i parametri di risposta
			rpcResponse.setData(responseData);
			
			
			// restituzione del risultato
			rpcManager.send(rpcResponse);
		
		}
		catch(Exception e) {
			
		}
		
		
    		
		// wait 5s
		long t0 = new Date().getTime();
		while((new Date().getTime() - t0) < (5*1000)) {
			
		}
    	
	}
    
    
    public static void dispatch(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException{
		

		//Utilizzo ibm_security_logout e faccio il forward verso la pagina di login
		String dispatchURL = "servlet/";
		
		
		RequestDispatcher dispatcher =  httpServletRequest.getSession().getServletContext().getRequestDispatcher(dispatchURL);
	    try {
			dispatcher.forward(httpServletRequest, httpServletResponse);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("DISPATCHED!! - new flow created!");
		
	}
    
    
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doWork(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doWork(request, response);
	}
	
	

}
