package it.ccg.infoproviderweb.server.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isomorphic.rpc.RPCManager;
import com.isomorphic.servlet.IDACall;
import com.isomorphic.servlet.RequestContext;

/**
 * Servlet implementation class RealTimeLogIdaCall
 */
public class _RealTimeLogIdaCall extends IDACall {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public _RealTimeLogIdaCall() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    
    public void processRequest(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		
		RequestContext context;
		try {
			context = RequestContext.instance(this, request, response);
			
			RPCManager rpc = new RPCManager(request, response);
			rpc.setAuthenticated(true);
			rpc.setUserRoles("manager,user,admin");
			processRPCTransaction(rpc, context);
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	} 
	
    
    

}
