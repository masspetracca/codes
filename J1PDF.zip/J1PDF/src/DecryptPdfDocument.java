

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import java.io.FileOutputStream;
import java.io.IOException;

public class DecryptPdfDocument {

    static String owner = "owner";
    static String original = "password-protected.pdf";
    static String destination = "provaDecrPT.pdf";

    public static void main(String... args) throws IOException, DocumentException {
        PdfReader reader = new PdfReader(original, owner.getBytes());
        PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(destination));

        stamper.close();
    }
}
