import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
 
/**
 * This class is used to read an existing
 *  pdf file using iText jar.
 * @author codesjava
 */
public class PDFReader {
	public PDFReader(String ArrayString) {
	String ArrString = " ";
	//public static void main(String args[]){
    try {
	//Create PdfReader instance.
	PdfReader pdfReader = new PdfReader("./resources/prova.pdf");
 
	//Get the number of pages in pdf.
	int pages = pdfReader.getNumberOfPages(); 
 
	//Iterate the pdf through pages.
	for(int i=1; i<=pages; i++) { 
	  //Extract the page content using PdfTextExtractor.
	  String pageContent = 
	  	PdfTextExtractor.getTextFromPage(pdfReader, i);
 
	  //Print the page content on console.
	  System.out.println("Content on Page "
	  		              + i + ": " + pageContent);
	  
	  ArrString += i + ": " + pageContent;
      }
	 //*EFOR
	  ArrayString = ArrString;
 
      //Close the PdfReader.
      pdfReader.close();
    } catch (Exception e) {
	e.printStackTrace();
    }
  }


	
}