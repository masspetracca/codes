import java.io.FileNotFoundException;

import com.itextpdf.text.DocumentException;

public class MainPDF {

	public static void main(String[] args) throws FileNotFoundException, DocumentException {
		String ArrString = " ";
		PDFReader(ArrString);
		EncryptPdfDocument();
	}


	private static void PDFReader(String ArrString) {
		PDFReader pdfr = new PDFReader(ArrString);
		
	}
	
	private static void EncryptPdfDocument() throws FileNotFoundException, DocumentException {
		EncryptPdfDocument epdfd = new EncryptPdfDocument();
	}

	
}
