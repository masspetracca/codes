package jwt.ejb.bean;

import javax.ejb.Stateless;
  
@Stateless
public class SearchItem implements SearchItemRemote,SearchItemLocal {
   public SearchItem() {
   
   }
}