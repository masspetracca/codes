package jwt.ejb.bean;

public interface SearchItemRemote {

}
