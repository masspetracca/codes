package jwt.ejb.bean;

public interface SearchItemLocal {

}
