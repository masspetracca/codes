package stateless.sessionbean;

public interface Hello {

}
