package stateless.beanclass;

import javax.ejb.Remote;
import javax.ejb.Stateless;

import businessInterface.Hello;

@Stateless
@Remote(Hello.class)
public class HelloBean implements Hello{
    public String sayHello(){
        return "Hello Boss";
    }

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return getMessage();
	}
}