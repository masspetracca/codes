package businessInterface;

import javax.ejb.Stateful;

/* Adds callback listener to bean class */
@Stateful
public class MyBean{
    private int x;
    public int m1(){
		return x;}
}