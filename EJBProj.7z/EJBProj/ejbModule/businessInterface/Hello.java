package businessInterface;

import javax.ejb.Remote;

@Remote
public interface Hello{
    public String getMessage();
}