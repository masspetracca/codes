package callbackBeanClass;

import javax.ejb.PrePassivate;

/* Callback method defined inside a Listener class*/
public class CustomCallBack{
    @PrePassivate public void customCall(Object obj){
        // Statements
    }
}