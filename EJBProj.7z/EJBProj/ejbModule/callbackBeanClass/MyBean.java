package callbackBeanClass;

import javax.annotation.PreDestroy;
import javax.ejb.Stateful;

@Stateful
public class MyBean{
    private int x;
    public int m1(){
		return x;}
    @PreDestroy
    void call(){}
}