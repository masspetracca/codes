package com.caveofprogramming.designpatterns.demo1.view;

public interface LoginListener {
	public void loginPerformed(LoginFormEvent event);
}
