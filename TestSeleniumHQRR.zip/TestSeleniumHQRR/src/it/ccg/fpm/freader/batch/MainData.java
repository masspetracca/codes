package it.ccg.fpm.freader.batch;

import java.io.IOException;

import org.dom4j.DocumentException;

public class MainData {
	/**
	 * Main DataFile
	 * @throws IOException 
	 * @throws DocumentException 
	 */
	//public MainData(int returnCode) throws IOException, DocumentException {
		// TODO Auto-generated constructor stub
	
	private static  int returnCode;	  
	  public static void main(String[] args) throws Exception {
		  System.out.println("Inizio esecuzione <MAIN DATA>");
		//Filter and load files *.txt //CCGPBatchProperties.txt
		  GetFiles(returnCode);
		  if (returnCode == 0) { 
			  //Load Data File
			  //DataFileCompleto(returnCode);
			  DataFileCompletoPamp(returnCode);
		  }
		  
		  if (returnCode == 0) {
		 //Parser XML
			 DomParser(returnCode);
		  }
		  
		  
		  if (returnCode != 0) {
			 System.out.println("Errore nella fase  <DataFile> - verificare !");
		 }
		  System.out.println("Fine esecuzione <MAIN>");
	  }


	private static void DomParser(int returnCode) throws DocumentException, IOException {
		DomParser dom = new DomParser();
		
	}


	private static void Errore() {
		// TODO Auto-generated method stub
		System.exit(1);
	}


	private static void LoadReq() {
		// TODO Auto-generated method stub
		
	}


	private static void GetFiles(int returnCode) throws IOException {
		GetFiles gf = new GetFiles(); 		
	}
	private static void DataFileCompleto(int returnCode) throws IOException {
		DataFileCompleto dfc = new DataFileCompleto(); 		
	}
	private static void DataFileCompletoPamp(int returnCode) throws IOException {
		DataFileCompleto dfc = new DataFileCompleto(); 		
	}
//	private static void DataFileValues() throws IOException {
//		DataFileValues dfv = new DataFileValues();
//	}
	private static void GetProperties() throws IOException {
		PropertyFiles pf = new PropertyFiles();		
	}

//	private static void ResultDb2() throws IOException {
//		ResultDb2 resdb2 = new ResultDb2();
//	}
}



