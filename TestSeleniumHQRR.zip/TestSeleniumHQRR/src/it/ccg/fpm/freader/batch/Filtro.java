package it.ccg.fpm.freader.batch;

import java.io.File;
import java.io.FilenameFilter;

class Filtro implements FilenameFilter {
	 public boolean accept(File pathname) {
		 return pathname.getName().toLowerCase().endsWith(".out");
	 }

	@Override
	public boolean accept(File dir, String name) {
		// TODO Auto-generated method stub
		return false;
	}
}
