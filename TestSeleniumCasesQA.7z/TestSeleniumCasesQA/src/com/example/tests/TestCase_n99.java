package com.example.tests;


import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverBackedSelenium;
import org.openqa.selenium.firefox.*;

import com.thoughtworks.selenium.Selenium;

public class TestCase_n99 {

	WebDriver driver;
	Selenium selenium;

	@BeforeMethod
	public void startSelenium() {
		driver = new FirefoxDriver();
		selenium = new WebDriverBackedSelenium(driver, "http://localhost:9080/InternalCom/index.html");
	}

	@AfterMethod
	public void stopSelenium() {
		driver.close();
	}

	@Test
	public void testCase_n99() {
		selenium.open("/InternalCom/index.html?sc_selenium=true<!--url iniziale -->");
		// selenium.waitForElementClickable("scLocator=//IButton[ID=\"isc_IButton_0\"]/<!--tasto insert -pre -->");
		selenium.click("scLocator=//IButton[ID=\"isc_IButton_0\"]/<!--tasto insert-->");
		// selenium.waitForElementClickable("scLocator=//IButton[ID=\"isc_IButton_1\"]/<!--tasto cancel - pre -->");
		selenium.click("scLocator=//IButton[ID=\"isc_IButton_1\"]/<!--tasto cancel -->");
		// selenium.waitForElementClickable("scLocator=//DynamicForm[ID=\"isc_DynamicForm_0\"]/item[name=isc_ComboBoxItem_0||title=Section||value=Generic%20communication||index=3||Class=ComboBoxItem]/[icon='picker']<!--sel Combo Section -pre -->");
		selenium.click("scLocator=//DynamicForm[ID=\"isc_DynamicForm_0\"]/item[name=isc_ComboBoxItem_0||title=Section||value=Generic%20communication||index=3||Class=ComboBoxItem]/[icon='picker']<!--sel Combo Section -->");
		// selenium.waitForElementClickable("scLocator=//IButton[ID=\"isc_IButton_1\"]/<!--sel De.check - Enabled -pre -->");
		selenium.click("scLocator=//IButton[ID=\"isc_IButton_1\"]/<!--sel De.check - Enabled  -->");
		// selenium.waitForElementClickable("scLocator=//DynamicForm[ID=\"isc_DynamicForm_0\"]/item[name=isc_CheckboxItem_0||title=Enabled||value=true||index=4||Class=CheckboxItem]/textbox<!--sel Check - Enabled -pre -->");
		selenium.click("scLocator=//DynamicForm[ID=\"isc_DynamicForm_0\"]/item[name=isc_CheckboxItem_0||title=Enabled||value=true||index=4||Class=CheckboxItem]/textbox<!--sel Check - Enabled  -->");
	}

}
