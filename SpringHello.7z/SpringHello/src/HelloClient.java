import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.cglib.proxy.Factory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class HelloClient  
{
    private static BeanFactory factory;

	public static void main(String args[]) throws Exception

    {
        try
        {
        System.out.println("point1");

        Resource  res = new ClassPathResource("hello.xml");
        System.out.println("point2");

		setFactory(new XmlBeanFactory(res));
        System.out.println("point3");

         //Hello bean1 = (Hello)Factory.getBean("Hello");

         //String s = bean1.sayhello("Joe");

         //System.out.println(s);

        }catch(Exception e1){System.out.println(""+e1);}
    }

	public static BeanFactory getFactory() {
		return factory;
	}

	public static void setFactory(BeanFactory factory) {
		HelloClient.factory = factory;
	}
}