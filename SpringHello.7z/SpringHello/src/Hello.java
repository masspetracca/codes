public interface Hello
{
      public String sayhello(String a);
}