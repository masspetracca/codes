
public class Helloimpl implements Hello
{
      private String greeting;

      public Helloimpl()
      {
      }
      public Helloimpl(String a)
      {
          greeting=a;
      } 
      public String sayhello(String s)
      {
           return greeting+s;
      }
      public void setGreeting(String a)
      {
           greeting=a;
      }

}