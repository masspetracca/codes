package com.javawebtutor.spring;
 
public class HelloBean {
    private String message;
 
    public void setMessage(String message) {
        this.message = message;
    }
 
    public void displayMessage() {
        System.out.println(message);
    }
 
}