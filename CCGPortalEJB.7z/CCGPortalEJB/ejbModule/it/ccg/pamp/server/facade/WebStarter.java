package it.ccg.pamp.server.facade;

import it.ccg.pamp.server.appint.ImportFromFileLocal;
import it.ccg.pamp.server.bus.BondBatchLocal;
import it.ccg.pamp.server.bus.ChartBuilderLocal;
import it.ccg.pamp.server.bus.StarterLocal;
import it.ccg.pamp.server.eao.ActionLogEAOLocal;
import it.ccg.pamp.server.eao.NotifyEAOLocal;
import it.ccg.pamp.server.entities.Scheduler;
import it.ccg.pamp.server.entities.User;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.SchedulerException;
import it.ccg.pamp.server.exceptions.UserException;
import it.ccg.pamp.server.loggers.LockerInterceptor;
import it.ccg.pamp.server.utils.SendMailLocal;
import it.ccg.pamp.server.utils.StradMinMarSimContainer;

import java.util.HashMap;
import java.util.LinkedHashMap;

import javax.annotation.security.DeclareRoles;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.interceptor.Interceptors;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class WebStarter
 */
@Stateless
@DeclareRoles({ "user", "admin", "manager", "visitor", "causer", "ccpamanagement", "supervisor"})
@RolesAllowed({ "user" })
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NEVER)
public class WebStarter implements WebStarterLocal {

	@EJB
	StarterLocal starter;

	@EJB
	BondBatchLocal bondbatch;

	@EJB
	ActionLogEAOLocal actionlog;

	@EJB
	ChartBuilderLocal chartbuilder;

	@EJB
	NotifyEAOLocal notifyEAO;
	
	@EJB
	ImportFromFileLocal fileImport;

	
	@EJB
	SendMailLocal mail;
	
	final static String generalErrorString = "General Error Occurred";
	final static String dataNotValidString = "Error: connection problems";
	final static String dataNotAvailableString = "Error: input data not available";

	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");

	@Override
	@RolesAllowed("manager")
	public void approveSubmittedMarginsAndGroups() throws UserException {
		starter.approveSubmittedMarginsAndGroups();
	}

	@Override
	@RolesAllowed("manager")
	public void approveSingleEquityInstrument(int instrid) throws UserException {
		starter.approveSingleEquityInstrument(instrid);
	}

	@Override
	public void startMakeAnalysis() throws UserException {
		starter.startMakeAnalysis();
	}

	@Override
	@RolesAllowed({ "user", "admin", "manager", "visitor", "causer", "ccpamanagement", "supervisor" })
	public LinkedHashMap<String,String> fetchUserInfo(String userName) throws UserException {
		try {
			return starter.fetchUserInfo(userName);
		} catch (DataNotValidException e) {
			userLog.error(dataNotValidString+".", e);
			throw new UserException(dataNotValidString);
		}
	}
	
	@Override
	@RolesAllowed({ "user", "admin", "manager", "visitor", "causer", "ccpamanagement", "supervisor" })
	public void updateUserInfo(LinkedHashMap<String,String> userValueMap, String userName) throws UserException {
		try {
			starter.updateUserInfo(userValueMap, userName);
		} catch (DataNotValidException e) {
			userLog.error(dataNotValidString+".", e);
			throw new UserException(dataNotValidString);
		}
	}
	
	@Override
	public void createGroupAndComponents(LinkedHashMap<String, String> groupValues, String grCompList) throws UserException {
		try {
			starter.createGroupAndComponents(groupValues, grCompList);
		} catch (DataNotValidException e) {
			userLog.error(dataNotValidString+".", e);
			throw new UserException(dataNotValidString);
		} 
	}

	@Override
	public String generateGroupName() throws UserException {
		try {
			return starter.generateGroupName();
		} catch (DataNotValidException e) {
			userLog.error(dataNotValidString+".", e);
			throw new UserException(dataNotValidString);
		} 
	}

	@Override
	public void recallEqsFromApproval() throws UserException {
		starter.recallEqsFromApproval();
	}

	@Override
	public void calcSimulation(int instrID) throws UserException {
		starter.calcSimulation(instrID);
	}

	@Override
	public void prepareSimulation(int instrID, int calcWindow) throws UserException {
		starter.prepareSimulation(instrID, calcWindow);
	}

	@Override
	public int fromSimConftoConf(int instrID) throws UserException {
		return starter.fromSimConftoConf(instrID);
	}

	@Override
	public void populateSimVariations(int instrID) throws UserException {
		starter.populateSimVariations(instrID);
	}

	@Override
	public void startSingleEquityMargin(int instrid) throws UserException {
		starter.startSingleEquityMargin(instrid);
	}

	@Override
	public void submitEqsForApproval() throws UserException {
		starter.submitEqsForApproval();
	}

	@Override
	@RolesAllowed("manager")
	public void approveSubmittedMarginsStraddlesMinimumMarginsAndGroups() throws UserException {
		starter.approveSubmittedMarginsStraddlesMinimumMarginsAndGroups();
	}

	@Override
	@RolesAllowed("manager")
	public void approveSingleEquityDerivativeInstrument(int instrid) throws UserException {
		starter.approveSingleEquityDerivativeInstrument(instrid);
	}

	@Override
	public void recallEqDerivativesFromApproval() throws UserException {
		starter.recallEqDerivativesFromApproval();
	}

	@Override
	public StradMinMarSimContainer straddleMinMarSim4CorpAct(int instrID, int multiplier, double k, String working, double spotpriceDouble) throws UserException {
		try {
			return starter.straddleMinMarSim4CorpAct(instrID, multiplier, k, working, spotpriceDouble);
		} catch (Exception e) {
			userLog.error(generalErrorString+".", e);
			throw new UserException(generalErrorString);
		}
	}

	@Override
	public void startSingleEquityDerivativeMargin(int instrid) throws UserException {
		starter.startSingleEquityDerivativeMargin(instrid);
	}

	@Override
	public void startSingleMinMarBatch(int instrID) throws UserException {
		starter.startSingleMinMarBatch(instrID);
	}

	@Override
	public void startSingleEquityDerivativeStraddle(int instrID) throws UserException {
		starter.startSingleEquityDerivativeStraddle(instrID);
	}

	@Override
	public void submitEqDerivativesForApproval() throws UserException {
		starter.submitEqDerivativesForApproval();
	}

	@Override
	@RolesAllowed("manager")
	public void approveElectricDerivativeSubmittedMarginsAndGroups() throws UserException {
		starter.approveElectricDerivativeSubmittedMarginsAndGroups();
	}

	@Override
	public void recallElectricDerivativesFromApproval() throws UserException {
		starter.recallElectricDerivativesFromApproval();
	}

	@Override
	public void submitElectricDerivativesForApproval() throws UserException {
		starter.submitElectricDerivativesForApproval();
	}

	@Override
	public void submitBondsForApproval() throws UserException {
		starter.submitBondsForApproval();
	}

	@Override
	@RolesAllowed("manager")
	public void approveBonds() throws UserException {
		starter.approveBonds();
	}

	@Override
	public void recallBondsFromApproval() throws UserException {
		starter.recallBondsFromApproval();
	}

	@Override
	public void submitInflationBondsForApproval() throws UserException {
		starter.submitInflationBondsForApproval();
	}

	@Override
	public void recallInflationBondsFromApproval() throws UserException {
		starter.recallInflationBondsFromApproval();
	}

	@Override
	@RolesAllowed("manager")
	public void approveInflationBonds() throws UserException {
		starter.approveInflationBonds();
	}

	@Override
	public String mainRenderergetOutput_path() {
		return starter.mainRenderergetOutput_path();
	}

	@Override
	public String mainRendererlaunchReport(String batchId) throws UserException {
		try {
			return starter.mainRendererlaunchReport(batchId);
		} catch (Exception e) {
			userLog.error(generalErrorString+".", e);
			throw new UserException(generalErrorString);
		}
	}

	@Override
	public String hpdTransferCash(boolean delta) throws UserException {
		try {
			return starter.hpdTransferCash(delta);
		} catch (DataNotValidException e) {
			userLog.error(dataNotValidString+".", e);
			throw new UserException(dataNotValidString);
		}
	}

	@Override
	public String hpdtransferFutures(boolean delta) throws UserException {
		try {
			return starter.hpdtransferFutures(delta);
		} catch (DataNotValidException e) {
			userLog.error(dataNotValidString+".", e);
			throw new UserException(dataNotValidString);
		}
	}

	@Override
	public String hpdtransferOptions(boolean delta) throws UserException {
		try {
			return starter.hpdtransferOptions(delta);
		} catch (DataNotValidException e) {
			userLog.error(dataNotValidString+".", e);
			throw new UserException(dataNotValidString);
		}
	}

	@Override
	@PermitAll
	public void schedRefreshAll() throws UserException {
		try {
			starter.schedRefreshAll();
		} catch (DataNotValidException e) {
			userLog.error(dataNotValidString+".", e);
			throw new UserException(dataNotValidString);
		}
	}

	@Override
	public void schedStart(String prcName) throws UserException {
		try {
			starter.schedStart(prcName);
		} catch (DataNotValidException e) {
			userLog.error(dataNotValidString+".", e);
			throw new UserException(dataNotValidString);
		} catch (SchedulerException e) {
			throw new UserException("Scheduler already started");
		}
	}

	@Override
	public void schedStop(String prcName) throws UserException {
		try {
			starter.schedStop(prcName);
		} catch (DataNotValidException e) {
			userLog.error(dataNotValidString+".", e);
			throw new UserException(dataNotValidString);
		}
	}

	@Override
	public Scheduler findSchedulerByPrimaryKey(int prcId) throws UserException {
		try {
			return starter.findSchedulerByPrimaryKey(prcId);
		} catch (DataNotValidException e) {
			userLog.error(dataNotValidString+".", e);
			throw new UserException(dataNotValidString);
		}
	}

	@Override
	@PermitAll
	public String syncronizeWorkingMargins() throws UserException {
		try {
			return starter.syncronizeWorkingMargins();
		} catch (DataNotValidException e) {
			userLog.error(dataNotValidString+".", e);
			throw new UserException(dataNotValidString);
		}
	}

	@Override
	@PermitAll
	public String getHistPriceChart(int instrId) throws UserException {
		try {
			return chartbuilder.getHistPriceChart(instrId);
		} catch (Exception e) {
			userLog.error(generalErrorString+".", e);
			throw new UserException(generalErrorString);
		}
	}

	@Override
	@PermitAll
	public String getDerivativeHistPriceChart(int instrId) throws UserException {
		try {
			return chartbuilder.getDerivativeHistPriceChart(instrId);
		} catch (Exception e) {
			userLog.error(generalErrorString+".", e);
			throw new UserException(generalErrorString);
		}
	}

	@Override
	@PermitAll
	public String getInterestRateChart() throws UserException {
		try {
			return chartbuilder.getInterestRateChart();
		} catch (Exception e) {
			userLog.error(generalErrorString+".", e);
			throw new UserException(generalErrorString);
		}
	}

	@Override
	@PermitAll
	public String getVariationChart(int instrId) throws UserException {
		try {
			return chartbuilder.getVariationChart(instrId);
		} catch (Exception e) {
			userLog.error(generalErrorString+".", e);
			throw new UserException(generalErrorString);
		}
	}

	@Override
	@PermitAll
	public String getVolatilityChart(int instrId) throws UserException {
		try {
			return chartbuilder.getVolatilityChart(instrId);
		} catch (Exception e) {
			userLog.error(generalErrorString+".", e);
			throw new UserException(generalErrorString);
		}
	}

	@Override
	@PermitAll
	public User findOrCreateUser(String username) throws UserException {
		try {
			return starter.findOrCreateUser(username);
		} catch (Exception e) {
			userLog.error(generalErrorString+".", e);
			throw new UserException(generalErrorString);
		}
	}

	@Override
	public void checkQueue() throws UserException {
		starter.checkQueue();
	}

	@Override
	@Interceptors(LockerInterceptor.class)
	public void startUpdateClassMarginFromBackTest(String[] classIDStringArr, String justIfGreater) throws UserException {
		userLog.info("Update class margins from back test procedure started");
		try {
			bondbatch.updateClassMarginFromBackTest(classIDStringArr, justIfGreater);
			userLog.info("Update class margins from back test procedure successfully completed");
			
			try {
				actionlog.add("Update class margins from back test procedure successfully completed");
			} catch (DataNotValidException e2) {
				userLog.error("", e2);
			}

		} catch (DataNotValidException e) {
			userLog.error("Database error. Update class margins from back test procedure terminated.", e);
			try {
				actionlog.add("Database error. Update class margins from back test procedure terminated.");
			} catch (DataNotValidException e1) {
				userLog.error("", e1);
			}

			throw new UserException("Error: connection problems");
		} catch (DataNotAvailableException e) {
			userLog.error("Error: input data not available. Update class margins from back test procedure terminated.", e);

			try {
				actionlog.add("Error: input data not available. Update class margins from back test procedure terminated.");
			} catch (DataNotValidException e1) {
				userLog.error("", e1);
			}

			throw new UserException("Error: input data not available ");
		}

	}
	
	@Override
	@Interceptors({ LockerInterceptor.class })
	public HashMap<String, String> startcheckEquitiesBeforeApproval() throws UserException {
		return starter.startcheckEquitiesBeforeApproval();
	}
		
	
	@Override
	@Interceptors({ LockerInterceptor.class })
	public void startFixSuspectedEqMargins(HashMap<String, String> eqmarmap) throws UserException{ 
		starter.startFixSuspectedEqMargins(eqmarmap);
	}


	@Override
	@Interceptors(LockerInterceptor.class)
	public int startReplicateConfOnAllCurveNodes(int instrID,String listName) throws UserException {
		userLog.info("Replicate confidence on all curve nodes procedure started");
		int updrows=0;
		try {
			updrows=bondbatch.replicateConfOnAllCurveNodes(instrID, listName);
			userLog.info("Replicate confidence on all curve nodes procedure successfully completed, "+updrows+" confidence rows updated");
			
			try {
				actionlog.add("Replicate confidence on all curve nodes procedure successfully completed, "+updrows+" confidence rows updated");
			} catch (DataNotValidException e2) {
				userLog.error("", e2);
			}
		} catch (DataNotValidException e) {
			userLog.error("Database error. Replicate confidence on all curve nodes procedure terminated.", e);
			try {
				actionlog.add("Database error. Replicate confidence on all curve nodes procedure terminated.");
			} catch (DataNotValidException e1) {
				userLog.error("", e1);
			}

			throw new UserException("Error: connection problems");
		}
		
		return updrows;
		
	}
	
	@Override
	public void startMakeAnalysisForBondAndHaircut() throws UserException {
		starter.startMakeAnalysisForBondAndHaircut();
	}
	
	@Override
	public void submitHaircutsForApproval() throws UserException {
		starter.submitHaircutForApproval();
	}
	
	@Override
	public void recallHaircutsFromApproval() throws UserException {
		starter.recallHaircutFromApproval();
	}
	
	@Override
	@RolesAllowed("manager")
	public void approveHairCuts() throws UserException {
		starter.approveHaircuts();
	}
	
	
	@Override
	public void startMakeAnalysisForOeKBHaircut() throws UserException {
		starter.startMakeAnalysisForOeKBHaircut();
	}
	/*
	@Override
	@RolesAllowed({"user", "causer"})
	@Interceptors(LockerInterceptor.class)
	public void loadFile(String fileName, int importType, boolean overWrite, String divisCode) throws UserException {
		System.out.println("PRIMA DEL LANCIO DEL LOAD");
		starter.startHistoricalPricesImportFile(importType, overWrite);
		System.out.println("DOPO DEL LANCIO DEL LOAD");
	}
	*/
}
