package it.ccg.pamp.server.facade;
import it.ccg.pamp.server.entities.Scheduler;
import it.ccg.pamp.server.entities.User;
import it.ccg.pamp.server.exceptions.UserException;
import it.ccg.pamp.server.utils.StradMinMarSimContainer;

import java.util.HashMap;
import java.util.LinkedHashMap;

import javax.ejb.Local;

@Local
public interface WebStarterLocal {

	public abstract void approveInflationBonds() throws UserException;

	public abstract void recallInflationBondsFromApproval() throws UserException;

	public abstract void submitInflationBondsForApproval() throws UserException;

	public abstract void recallBondsFromApproval() throws UserException;

	public abstract void approveBonds() throws UserException;

	public abstract void submitBondsForApproval() throws UserException;

	public abstract void submitElectricDerivativesForApproval() throws UserException;

	public abstract void recallElectricDerivativesFromApproval() throws UserException;

	public abstract void approveElectricDerivativeSubmittedMarginsAndGroups() throws UserException;

	public abstract void submitEqDerivativesForApproval() throws UserException;

	public abstract void startSingleEquityDerivativeStraddle(int instrID) throws UserException;

	public abstract void startSingleMinMarBatch(int instrID) throws UserException;

	public abstract void startSingleEquityDerivativeMargin(int instrid) throws UserException;

	public abstract StradMinMarSimContainer straddleMinMarSim4CorpAct(int instrID, int multiplier, double k, String working, double spotpriceDouble) throws UserException;

	public abstract void recallEqDerivativesFromApproval() throws UserException;

	public abstract void approveSingleEquityDerivativeInstrument(int instrid) throws UserException;

	public abstract void approveSubmittedMarginsStraddlesMinimumMarginsAndGroups() throws UserException;

	public abstract void submitEqsForApproval() throws UserException;

	public abstract void startSingleEquityMargin(int instrid) throws UserException;

	public abstract void populateSimVariations(int instrID) throws UserException;

	public abstract int fromSimConftoConf(int instrID) throws UserException;

	public abstract void prepareSimulation(int instrID, int calcWindow) throws UserException;

	public abstract void calcSimulation(int instrID) throws UserException;

	public abstract void recallEqsFromApproval() throws UserException;

	public abstract void createGroupAndComponents(LinkedHashMap<String, String> groupValues, String grCompList) throws UserException;
	
	public String generateGroupName() throws UserException;

	public abstract void startMakeAnalysis() throws UserException;

	public abstract void approveSingleEquityInstrument(int instrid) throws UserException;

	public abstract void approveSubmittedMarginsAndGroups() throws UserException;

	public abstract Scheduler findSchedulerByPrimaryKey(int prcId) throws UserException;

	public abstract void schedStop(String prcName) throws UserException;

	public abstract void schedStart(String prcName) throws UserException;

	public abstract void schedRefreshAll() throws UserException;

	public abstract String hpdtransferOptions(boolean delta) throws UserException;

	public abstract String hpdtransferFutures(boolean delta) throws UserException;

	public abstract String hpdTransferCash(boolean delta) throws UserException;

	public abstract String mainRendererlaunchReport(String batchId) throws UserException;

	public abstract String mainRenderergetOutput_path() throws UserException;

	public abstract String getVolatilityChart(int instrId) throws UserException;

	public abstract String getVariationChart(int instrId) throws UserException;

	public abstract String getInterestRateChart() throws UserException;

	public abstract String getDerivativeHistPriceChart(int instrId) throws UserException;

	public abstract String getHistPriceChart(int instrId) throws UserException;
	
	public abstract String syncronizeWorkingMargins() throws UserException;

	public abstract void checkQueue() throws UserException;

	public abstract User findOrCreateUser(String username) throws UserException;

	public abstract void startUpdateClassMarginFromBackTest(String[] classIDStringArr, String justIfGreater) throws UserException;

	public abstract void startFixSuspectedEqMargins(HashMap<String, String> eqmarmap) throws UserException;

	public abstract HashMap<String, String> startcheckEquitiesBeforeApproval() throws UserException;
	
	public abstract LinkedHashMap<String,String> fetchUserInfo(String userName) throws UserException;
	
	public abstract void updateUserInfo(LinkedHashMap<String,String> userValueMap, String userName) throws UserException;

	 int startReplicateConfOnAllCurveNodes(int instrID, String listName) throws UserException;

	public abstract void submitHaircutsForApproval() throws UserException;

	void startMakeAnalysisForBondAndHaircut() throws UserException;

	void recallHaircutsFromApproval() throws UserException;

	void approveHairCuts() throws UserException;

	void startMakeAnalysisForOeKBHaircut() throws UserException;
	
	/*public abstract void loadFile(String fileName, int importType, boolean overWrite, String divisCode) throws UserException;*/
	

}
