package it.ccg.pamp.server.appint.stressTestOeKB;

import it.ccg.pamp.server.eao.stressTest.StressTestHistPriceEAOLocal;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.StressTestHistPricesReadyToExp;

import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class OeKBPAMPUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class OeKBPAMPUnit implements OeKBPAMPUnitLocal {

	@EJB
	private StressTestHistPriceEAOLocal stressTestHPEAO;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	
	public void updateStressTestHPSentStatusAfterExport(Vector<StressTestHistPricesReadyToExp> stressTestHisPrToExpVect) throws DataNotValidException {
		
		for (StressTestHistPricesReadyToExp stressTestHisPrToExp : stressTestHisPrToExpVect) {
			
			int instrId = stressTestHisPrToExp.getStressTestHP().getPk().getInstrId();
			
			int stId = stressTestHisPrToExp.getStressTestHP().getPk().getStId();
			String scenario = stressTestHisPrToExp.getStressTestHP().getPk().getScenario();
			
			
			StressTestHistPrice stressTestHP = stressTestHPEAO.findByPrimaryKey(instrId, scenario, stId);
			stressTestHP.setSent("T");
			stressTestHP.setUpdDate(GenericTools.systemDate());
			stressTestHP.setUpdType("U");
			stressTestHP.setUpdUsr("System");
			  
			stressTestHPEAO.update(stressTestHP);
			
		}
		appIntLog.info("sent status updated for "+stressTestHisPrToExpVect.size() + " cash stressed prices ");
		
		//TODO
		//scrittura risultati del test su pamp
	}

}
