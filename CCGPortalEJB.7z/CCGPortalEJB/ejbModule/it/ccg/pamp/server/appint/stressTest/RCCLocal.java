package it.ccg.pamp.server.appint.stressTest;
import javax.ejb.Local;

@Local
public interface RCCLocal {

}
