package it.ccg.pamp.server.appint.backTest;

import it.ccg.pamp.server.eao.backTest.RiskEngineClassTableEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestCgcls00fEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestCgpri00fEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestCgvolai00fEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestMtspriceEAOLocal;
import it.ccg.pamp.server.eao.stressTestOeKB.StressTestRePrcEAOLocal;
import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.IntracsLog;
import it.ccg.pamp.server.entities.backTest.RiskEngineClassTable;
import it.ccg.pamp.server.entities.stressTest.StressTestMtsprice;
import it.ccg.pamp.server.exceptions.InstrumentNotAvailableOnClearingException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.HistoricalPriceToExport;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BackTestReUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class BackTestReUnit implements BackTestReUnitLocal {

	@EJB
	private RiskEngineClassTableEAOLocal reClassStressedPriceEAO;
	
	@EJB
	private StressTestRePrcEAOLocal stressTestRePrcEAO;
	
	@EJB
	private StressTestMtspriceEAOLocal stressTestMtsPriceEAO;
	
	@EJB
	private StressTestCgpri00fEAOLocal stressTestCgpri00f;
	
	@EJB
	private StressTestCgvolai00fEAOLocal stressTestCgvolai00f;
	
	final String prgName = "PAMPBTXP";
	
	final String lastExecutor = "buffoni";
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");	
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void histPriceExport(Vector<HistoricalPriceToExport> histPricesReadyToExpVect) throws Exception {
		
		for (HistoricalPriceToExport histPricesReadyToExp:histPricesReadyToExpVect ) {
			
			if (histPricesReadyToExp.getInstrument().getDivisCode().equalsIgnoreCase("E")) {
				this.equityCashExport(histPricesReadyToExp);
			} else {
				this.equityDerivativesExport(histPricesReadyToExp);
			}
		}
	}
	
	
	public void equityCashExport(HistoricalPriceToExport histPricesReadyToExp) throws Exception {
		
		// classCode PAMP - strumento di partenza
		String classCode = histPricesReadyToExp.getInstrument().getClassCode();
					
		// prezzo da esportare
		BigDecimal closePr = histPricesReadyToExp.getHistoricalPrice().getClosepr();
		
		// instrId PAMP
		int instrId = histPricesReadyToExp.getInstrument().getInstrId();
		
		//appIntLog.info("INIZIO CICLO SULLA TRASCODIFICA");
		
		for (InstrIdTrascode transcodedInstr:histPricesReadyToExp.getInstrIdTC()) {
		
			// classCode Instracs - strumento di arrivo
			String sicCode = transcodedInstr.getPk().getSicInstr();
			
			String sicInstrType = transcodedInstr.getPk().getSicInstrTy();
		
			//cerco sulla tabella dei margini stressati per classcode e type (cptype)
			
			RiskEngineClassTable reClassPrice = reClassStressedPriceEAO.findByPrimaryKey(sicCode, sicInstrType);
		
			// se ci sono record su intracs corrispondenti allo strumento da esportare lo faccio, se ne manca anche solo uno si stoppa la procedura
			if (reClassPrice!=null) {
				
				//prendo il numero di cifre decimali per arrotondare il prezzo dalla colonna COPEDT
				int decDigits = Integer.parseInt(reClassPrice.getCopedt());
				
				//appIntLog.info("arrotondo lo stressato"+closePrSt+" di "+decDigits+" cifre");
				//arrotondo lo stressato
				closePr = closePr.setScale(decDigits, RoundingMode.HALF_EVEN);
				
				//setto il prezzo stressato nel campo CUICLP
				reClassPrice.setCuiclp(closePr);
				
				String strClosePr = closePr.toString().replace(".", ",");
				
				strClosePr = GenericTools.padding(strClosePr, 11,true);
				
				//appIntLog.info("setto anche il prezzo come sottostante sul campo CPRTUC (padding: "+strClosePrSt+")");
				
				//setto anche il prezzo come sottostante sul campo CPRTUC
				reClassPrice.setCprtuc(strClosePr);
				
				appIntLog.info("Price exported on Risk Engine for PAMP instrId "+instrId+" (code: "+classCode+") - Updated instrument "+sicCode+" (type: "+sicInstrType+") price: "+closePr);
				
				//appIntLog.info("LOG x paola"); 
				IntracsLog intracsLog = new IntracsLog();
				
				intracsLog.setlFile("CGCLS00F");
				intracsLog.setlProg(prgName);
				intracsLog.setlStat("U");
				
				
				intracsLog.setlUser(lastExecutor.toUpperCase());
				
				intracsLog.setLogDt1(reClassPrice.logCgcls00f());
				
				//stressTestRePrcEAO.writeLogProcedure(intracsLog);
			
			} else {
			
				appIntLog.error("Instrument not available on Risk Engine for PAMP instrId "+instrId+" (code: "+classCode+") - Risk Engine instrument code: "+sicCode+" (product type: "+sicInstrType+")");
				//throw new InstrumentNotAvailableOnClearingException(instrId,classCode,"Cash");
			}
		}
	}
	
	public void equityDerivativesExport(HistoricalPriceToExport histPricesReadyToExp) throws Exception {
		
		// prezzo da esportare (� quello del sottostante)
		BigDecimal closePr = histPricesReadyToExp.getHistoricalPrice().getClosepr();
		
		String classCode = histPricesReadyToExp.getInstrument().getClassCode();
		
		int instrId = histPricesReadyToExp.getInstrument().getInstrId();
		
		/*---------------INIZIO EXPORT PREZZI SOTTOSTANTI SU TABELLA CLASSI (RE)--------------*/
		
		//scorro tutte le eventuali trascodifiche per applicare a tutte il prezzo del sottostante
		for (InstrIdTrascode transcodedInstr:histPricesReadyToExp.getInstrIdTC()) {
		
			String sicCode = transcodedInstr.getPk().getSicInstr();
			
			String sicInstrType = transcodedInstr.getPk().getSicInstrTy();
			
			RiskEngineClassTable reClassPrice = reClassStressedPriceEAO.findByPrimaryKey(histPricesReadyToExp.getInstrument().getClassCode(), transcodedInstr.getPk().getSicInstrTy());
	
			// se ci sono record su intracs corrispondenti allo strumento da esportare lo faccio, se ne manca anche solo uno si stoppa la procedura
			if (reClassPrice!=null) {
				
				//prendo il numero di cifre decimali per arrotondare il prezzo dalla colonna COPEDT
				int decDigits = Integer.parseInt(reClassPrice.getCopedt());
				
				//arrotondo il prezzo
				closePr = closePr.setScale(decDigits, RoundingMode.HALF_EVEN);
				
				//setto il prezzo del sottostante nel campo CUICLP
				reClassPrice.setCuiclp(closePr);
				
				String strClosePr = closePr.toString().replace(".", ",");
				
				strClosePr = GenericTools.padding(strClosePr, 11,true);
				
				//appIntLog.info("setto anche il prezzo come sottostante sul campo CPRTUC (padding: "+strClosePrSt+")");
				
				//setto anche il prezzo come sottostante sul campo CPRTUC
				reClassPrice.setCprtuc(strClosePr);
				
				appIntLog.info("Underlying price exported on Risk Engine for PAMP instrId "+instrId+" (code: "+classCode+") - Clearing system updated instrument code: "+sicCode+" (type: "+sicInstrType+"); price: "+closePr);
				
				//appIntLog.info("LOG x paola"); 
				IntracsLog intracsLog = new IntracsLog();
				
				intracsLog.setlFile("CGCLS0SF");
				intracsLog.setlProg(prgName);
				intracsLog.setlStat("U");
				
				
				intracsLog.setlUser(lastExecutor.toUpperCase());
				
				intracsLog.setLogDt1(reClassPrice.logCgcls00f());
				
				//stressTestRePrcEAO.writeLogProcedure(intracsLog);
			
			} else {
			
				appIntLog.error("Instrument not available on Risk Engine for PAMP instrId "+instrId+" (code: "+classCode+") - Risk Engine instrument code: "+sicCode+" (product type: "+sicInstrType+")");
				//throw new InstrumentNotAvailableOnClearingException(instrId,classCode,"Cash");
			}
		}
		
		if (histPricesReadyToExp.getRectifiedClass().length>0)
			appIntLog.info("Starting export to option rectified classes");
		
		//scorro tutte le eventuali classi rettificate per applicare anche ad esse il prezzo del sottostante
		for (InstrIdTrascode transcodedInstr:histPricesReadyToExp.getRectifiedClass()) {
		
			String sicCode = transcodedInstr.getPk().getSicInstr();
			
			String sicInstrType = transcodedInstr.getPk().getSicInstrTy();
			
			RiskEngineClassTable reClassPrice = reClassStressedPriceEAO.findByPrimaryKey(histPricesReadyToExp.getInstrument().getClassCode(), transcodedInstr.getPk().getSicInstrTy());
	
			// se ci sono record su intracs corrispondenti allo strumento da esportare lo faccio, se ne manca anche solo uno si stoppa la procedura
			if (reClassPrice!=null) {
				
				//prendo il numero di cifre decimali per arrotondare il prezzo dalla colonna COPEDT
				int decDigits = Integer.parseInt(reClassPrice.getCopedt());
				
				//arrotondo il prezzo
				closePr = closePr.setScale(decDigits, RoundingMode.HALF_EVEN);
				
				//setto il prezzo del sottostante nel campo CUICLP
				reClassPrice.setCuiclp(closePr);
				
				String strClosePr = closePr.toString().replace(".", ",");
				
				strClosePr = GenericTools.padding(strClosePr, 11,true);
				
				//appIntLog.info("setto anche il prezzo come sottostante sul campo CPRTUC (padding: "+strClosePrSt+")");
				
				//setto anche il prezzo come sottostante sul campo CPRTUC
				reClassPrice.setCprtuc(strClosePr);
				
				appIntLog.info("Underlying price exported on Risk Engine for PAMP instrId "+instrId+" (code: "+classCode+") - Updated rectified class code: "+sicCode+" (type: "+sicInstrType+"); price: "+closePr);
				
				//appIntLog.info("LOG x paola"); 
				IntracsLog intracsLog = new IntracsLog();
				
				intracsLog.setlFile("CGCLS0SF");
				intracsLog.setlProg(prgName);
				intracsLog.setlStat("U");
				
				
				intracsLog.setlUser(lastExecutor.toUpperCase());
				
				intracsLog.setLogDt1(reClassPrice.logCgcls00f());
				
				//stressTestRePrcEAO.writeLogProcedure(intracsLog);
			
			} else {
			
				appIntLog.error("Instrument not available on Risk Engine for PAMP instrId "+instrId+" (code: "+classCode+") - Risk Engine instrument code: "+sicCode+" (product type: "+sicInstrType+")");
				//throw new InstrumentNotAvailableOnClearingException(instrId,classCode,"Cash");
			}
		}
		/*------------FINE PARTE SOTTOSTANTI----------------*/
		
		/*------------ INIZIO OPERAZIONI SUL DERIVATO --------------*/
		
		int removedFutures = stressTestCgpri00f.removeAll();
		int removedOption = stressTestCgvolai00f.removeAll();
		appIntLog.info(removedFutures+" future stressed prices removed on Clearing system");
		appIntLog.info(removedOption+" option stressed volatilities removed on Clearing system");
		
		for (InstrIdTrascode transcodedInstr:histPricesReadyToExp.getInstrIdTC()) {
		
			// classCode Instracs - strumento di arrivo
			String sicCode = transcodedInstr.getPk().getSicInstr();
			
			String sicInstrType = transcodedInstr.getPk().getSicInstrTy();
		
			//cerco sulla tabella dei margini stressati per classcode e type (cptype)
			
			RiskEngineClassTable reClassPrice = reClassStressedPriceEAO.findByPrimaryKey(sicCode, sicInstrType);
		
			// se ci sono record su intracs corrispondenti allo strumento da esportare lo faccio, se ne manca anche solo uno si stoppa la procedura
			if (reClassPrice!=null) {
				
				//prendo il numero di cifre decimali per arrotondare il prezzo dalla colonna COPEDT
				int decDigits = Integer.parseInt(reClassPrice.getCopedt());
				
				//appIntLog.info("arrotondo lo stressato"+closePrSt+" di "+decDigits+" cifre");
				//arrotondo lo stressato
				closePr = closePr.setScale(decDigits, RoundingMode.HALF_EVEN);
				
				//setto il prezzo stressato nel campo CUICLP
				reClassPrice.setCuiclp(closePr);
				
				String strClosePr = closePr.toString().replace(".", ",");
				
				strClosePr = GenericTools.padding(strClosePr, 11,true);
				
				//appIntLog.info("setto anche il prezzo come sottostante sul campo CPRTUC (padding: "+strClosePrSt+")");
				
				//setto anche il prezzo come sottostante sul campo CPRTUC
				reClassPrice.setCprtuc(strClosePr);
				
				appIntLog.info("Stressed price exported on Clearing system for PAMP instrId "+instrId+" (code: "+classCode+") - Clearing system updated instrument code: "+sicCode+" (type: "+sicInstrType+"); price: "+closePr);
				
				//appIntLog.info("LOG x paola"); 
				IntracsLog intracsLog = new IntracsLog();
				
				intracsLog.setlFile("CGCLS0SF");
				intracsLog.setlProg(prgName);
				intracsLog.setlStat("U");
				
				
				intracsLog.setlUser(lastExecutor.toUpperCase());
				
				intracsLog.setLogDt1(reClassPrice.logCgcls00f());
				
				//stressTestRePrcEAO.writeLogProcedure(intracsLog);
			
			} else {
			
				appIntLog.error("Instrument not available on Risk Engine for PAMP instrId "+instrId+" (code: "+classCode+") - Risk Engine instrument code: "+sicCode+" (product type: "+sicInstrType+")");
				//throw new InstrumentNotAvailableOnClearingException(instrId,classCode,"Cash");
			}
		}
	}
	

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void histBondPriceExport(Vector<HistoricalPriceToExport> histPricesReadyToExpVect) throws Exception {
		
		for (HistoricalPriceToExport histPricesReadyToExp:histPricesReadyToExpVect ) {
			
			// classCode PAMP - strumento di partenza
			String classCode = histPricesReadyToExp.getInstrument().getClassCode();
			
			BigDecimal priceDate = new BigDecimal(GenericTools.shortDateFormatAsLong(histPricesReadyToExp.getHistoricalPrice().getPk().getPricedate()));
			
			// prezzo stressato da esportare
			BigDecimal closePr = histPricesReadyToExp.getHistoricalPrice().getClosepr();
			
			// instrId PAMP
			int instrId = histPricesReadyToExp.getInstrument().getInstrId();
			
			//appIntLog.info("INIZIO CICLO SULLA TRASCODIFICA");
			
			// classCode Instracs - strumento di arrivo
			String isinCode = histPricesReadyToExp.getInstrument().getIsinCode();
				
			
			//cerco sulla tabella dei prezzi  per ISINCODE
			StressTestMtsprice reMtsPrice = stressTestMtsPriceEAO.findByPrimaryKey(isinCode);
				
			// se ci sono record su intracs corrispondenti allo strumento da esportare lo faccio, se ne manca anche solo uno si stoppa la procedura
			if (reMtsPrice!=null) {
					
				//prendo il numero di cifre decimali per arrotondare il prezzo dalla colonna COPEDT
				//int decDigits = Integer.parseInt(reClassPrice.getCopedt());
				
				//appIntLog.info("arrotondo lo stressato"+closePrSt+" di "+decDigits+" cifre");
				//arrotondo lo stressato
				//closePrSt = closePrSt.setScale(decDigits, RoundingMode.HALF_EVEN);
				//appIntLog.info("stressato arrotondato: "+closePrSt);
				
				//appIntLog.info("setto il prezzo: "+closePrSt);
				//setto il prezzo stressato nel campo CUICLP
				//reClassPrice.setCuiclp(closePrSt);
				//reMtsPrice.setPDataR(priceDate);
				reMtsPrice.setPPrice(closePr);
				
				String strClosePr = closePr.toString().replace(".", ",");
				
				strClosePr = GenericTools.padding(strClosePr, 11,true);
				
				//appIntLog.info("setto anche il prezzo come sottostante sul campo CPRTUC (padding: "+strClosePrSt+")");
				
				//setto anche il prezzo come sottostante sul campo CPRTUC
				//reClassPrice.setCprtuc(strClosePr);
				
				appIntLog.info("Stressed price exported on Clearing system for PAMP instrId "+instrId+" (code: "+classCode+") - Clearing system updated ISIN code: "+isinCode+" ; price: "+closePr);
				
				//appIntLog.info("LOG x paola"); 
				IntracsLog intracsLog = new IntracsLog();
				
				intracsLog.setlFile("MTSPRICE");
				intracsLog.setlProg(prgName);
				intracsLog.setlStat("U");
				
				
				intracsLog.setlUser(lastExecutor.toUpperCase());
				
				//intracsLog.setLogDt1(reClassPrice.logCgcls00f());
				 
				stressTestRePrcEAO.writeLogProcedure(intracsLog);
				
					
			} else {
				
				appIntLog.error("Instrument not available on Risk Engine for PAMP instrId "+instrId+" (code: "+classCode+") - Risk Engine instrument code: "+isinCode);
				//throw new InstrumentNotAvailableOnClearingException(instrId,classCode,"Cash");
			}
					
		}
		
	}
	
	

}
