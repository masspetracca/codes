package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.Cgcls00fEAOLocal;
import it.ccg.pamp.server.eao.IntracsLogEAOLocal;
import it.ccg.pamp.server.eao.TfpgrpEAOLocal;
import it.ccg.pamp.server.eao.TlForx1EAOLocal;
import it.ccg.pamp.server.entities.Cgcls00f;
import it.ccg.pamp.server.entities.IntracsLog;
import it.ccg.pamp.server.entities.Tfpgrp;
import it.ccg.pamp.server.entities.TlForx1;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.ReadyToExpGroupHistory;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class GCEINTRACSUnit
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class GCEINTRACSUnit implements  GCEINTRACSUnitLocal {

	@EJB
	private Cgcls00fEAOLocal cgcls00fEAO;
	
	@EJB
	private GCEPAMPUnitLocal gcePampUnit;

	@EJB
	private TlForx1EAOLocal tfForxEAO;
	
	@EJB
	private TfpgrpEAOLocal tfpgrpEAO;

	@EJB
	private IntracsLogEAOLocal intracsLogEAO;

	
	final String prgName = "PAMPGRXP";
	
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");


	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void exportPampGroupsToIntracs(List<ReadyToExpGroupHistory> readyToExpGroupHistory) throws DataNotValidException, DataNotAvailableException {
		
		// preparo la trascodifica delle currency
		List<TlForx1> tfForxList = tfForxEAO.fetch();
		
		// se non trova la lista di valute per qualsiasi motivo blocca
		if (tfForxList==null||tfForxList.size()==0) {
			throw new DataNotAvailableException("No Transcoded currencies found in the Risk Engine currency table");
		}
		
		
		int groupCount = 0;
		
		int lastExportedGroupId = 0;
		
		//per ogni record da esportare eseguo l'incrocio su intracs
		for (ReadyToExpGroupHistory grHist: readyToExpGroupHistory) {
			
			String logOperation = "A";
			
			if (!grHist.getGrStatus().equalsIgnoreCase("D")) {
				String reCurrency = null;
				
				for (TlForx1 cur:tfForxList) {
					if (cur.getFeDesc().substring(0,3).equalsIgnoreCase(grHist.getCurrency())) {
						reCurrency = cur.getFeCurr();
						break;
					}
				}
				
				
				//String reCurrency  = tfForxMap.get(grHist.getCurrency());
				
				//se non c'� corrispondenza con le valute blocca
				if (reCurrency == null) {
					throw new DataNotAvailableException("Transcoded currency not found for the Risk Engine currency " + reCurrency);
				}
				
				Tfpgrp intracsGrPr = tfpgrpEAO.findByPrimaryKey(grHist.getGroupName()); 
				
				String intracsGrValuesString = "";
				
				if (intracsGrPr==null) {
					//store
					Tfpgrp newIntracsGrPr = new Tfpgrp();
					
					appIntLog.info("inserting group "+grHist.getGroupName()+" ("+grHist.getSicInstrType()+") - "+grHist.getGrCoeff());
					
					newIntracsGrPr.setGGroup(grHist.getGroupName());
					newIntracsGrPr.setGDesc(GenericTools.padding(grHist.getGroupName(), 40)+grHist.getSicInstrType());
					newIntracsGrPr.setGCorr(grHist.getGrCoeff());
					newIntracsGrPr.setGAddDt(new BigDecimal(GenericTools.shortDateFormatAsLong(GenericTools.systemDate())));
					newIntracsGrPr.setGChgDt(new BigDecimal(GenericTools.shortDateFormatAsLong(GenericTools.systemDate())));
					newIntracsGrPr.setGSGrp(reCurrency);
					
					tfpgrpEAO.store(newIntracsGrPr);
					
					intracsGrValuesString+=grHist.getGroupName();
					intracsGrValuesString+=GenericTools.padding(grHist.getGroupName(), 40)+grHist.getSicInstrType();
					intracsGrValuesString+=grHist.getGrCoeff();
					intracsGrValuesString+=new BigDecimal(GenericTools.shortDateFormatAsLong(GenericTools.systemDate()));
					intracsGrValuesString+=new BigDecimal(GenericTools.shortDateFormatAsLong(GenericTools.systemDate()));
					intracsGrValuesString+=reCurrency;
					
					
				} else {
					//update;
					appIntLog.info("updating group "+grHist.getGroupName()+" ("+grHist.getSicInstrType()+") - "+grHist.getGrCoeff());
					
					intracsGrPr.setGCorr(grHist.getGrCoeff());
					intracsGrPr.setGChgDt(new BigDecimal(GenericTools.shortDateFormatAsLong(GenericTools.systemDate())));
					
					logOperation = "U";
					
					intracsGrValuesString+=intracsGrPr.getGGroup();
					intracsGrValuesString+=intracsGrPr.getGDesc();
					intracsGrValuesString+=grHist.getGrCoeff();
					intracsGrValuesString+=intracsGrPr.getGAddDt();
					intracsGrValuesString+=new BigDecimal(GenericTools.shortDateFormatAsLong(GenericTools.systemDate()));
					intracsGrValuesString+=reCurrency;
				}
				
				
				//TODO per modifiche Paola
				//this.storeGroup(grHist.getGroupName(),,grHist.getSicInstrType(),grHist.getGrCoeff(),reCurrency);
				
				//scrittura log PAOLA
				IntracsLog intracsLog = new IntracsLog();
				
				intracsLog.setlFile("TFPGRP");
				intracsLog.setlProg(prgName);
				intracsLog.setlStat(logOperation);
				intracsLog.setlUser(grHist.getLastExecutor());
				intracsLog.setLogDt1(intracsGrValuesString);
				
				intracsLogEAO.store(intracsLog);
				
				
				groupCount++;
			} else {
				appIntLog.info("group "+grHist.getGroupName()+" ("+grHist.getSicInstrType()+") has been disabled on Pamp System and will not be updated");
			}
		}
		
		// terminati gli update su intracs torno su PAMP per settare a sent = True i gruppi inviati
		String strGroup = "1 group ";
		if (groupCount>1) {
			strGroup = groupCount+" groups ";
		} else if (groupCount==0) {
			strGroup = "No groups ";
		}
		
		
		
		appIntLog.info(strGroup+"exported to Clearing system");

		gcePampUnit.updateGroupHistorySentStatusAfterExport(readyToExpGroupHistory);
	}
	
	
	public void storeGroup(String grName, String sicType, BigDecimal coeff, String currency) throws DataNotValidException, DataNotAvailableException {
		
		Tfpgrp intracsGrPr = tfpgrpEAO.findByPrimaryKey(grName); 
		
		if (intracsGrPr==null) {
			//store
			Tfpgrp newIntracsGrPr = new Tfpgrp();
			
			appIntLog.info("inserting group "+grName+"("+sicType+") - correlation: "+coeff);
			
			newIntracsGrPr.setGGroup(grName);
			newIntracsGrPr.setGDesc(GenericTools.padding(grName, 40)+sicType);
			newIntracsGrPr.setGCorr(coeff);
			newIntracsGrPr.setGAddDt(new BigDecimal(GenericTools.shortDateFormatAsLong(GenericTools.systemDate())));
			newIntracsGrPr.setGChgDt(new BigDecimal(GenericTools.shortDateFormatAsLong(GenericTools.systemDate())));
			newIntracsGrPr.setGSGrp(currency);
			
			tfpgrpEAO.store(newIntracsGrPr);
			
			
		} else {
			//update;
			appIntLog.info("updating group "+grName+"("+sicType+") - "+coeff);
			
			intracsGrPr.setGCorr(coeff);
			intracsGrPr.setGChgDt(new BigDecimal(GenericTools.shortDateFormatAsLong(GenericTools.systemDate())));
		}
		
	}
	
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void exportPampGroupAndComponentsHistoryToIntracs(List<ReadyToExpGroupHistory> readyToExpGroupHistory) throws DataNotValidException/*, DataNotAvailableException*/  {
		
		Cgcls00f[] intracsClassArray = cgcls00fEAO.fetch();
		
		int compCount = 0;
		
		int compRemoved = 0;
		
		int lastExportedGroupId = 0;
		
		int intracsCount = 0;
		
		int groupCount = 0;
		
		LinkedHashMap<String, String> intracsClassMap = new LinkedHashMap<String, String>();
		
		String lastExecutor = "";
		
		//appIntLog.info("Sto leggendo dalla tabella delle classi per creare hashMap");
		
		//ciclo su INTRACS prendendo TUTTI i record
		for (Cgcls00f intracsClass:intracsClassArray) {
			
			//String groupNameToUpdate = "";
			
			
			
			// setto il nome del gruppo di default
			String defaultGrName = intracsClass.getDefaultGrpName();
			
			// setto la chiave intracs
			String intracsKey = intracsClass.getPk().getCclass()+"|"+intracsClass.getCptype();
			
			//appIntLog.info("Chiave classi: "+intracsKey);
			
			String matchFound  = "Match found for instrument "+intracsClass.getPk().getCclass()+" (product type: "+intracsClass.getCptype()+")";
			
			/*
			if (!storedDefGrpMap.containsKey(defaultGrName)) {
				//this.storeGroup(defaultGrName,intracsClass.getPk().getCofCod(),new BigDecimal(1),intracsClass.getCcur());
			}
			
			storedDefGrpMap.put(defaultGrName, defaultGrName);*/
			
			//setto il nuovo gruppo col suo valore originale cos� � sicuramente valorizzato
			String intracsNewGroup = intracsClass.getCgroup();
			
						
			
			//appIntLog.info("Inizio l'incrocio col vettore di record da esportare");
			//per ogni record da esportare eseguo l'incrocio su RE
			for (ReadyToExpGroupHistory grHist: readyToExpGroupHistory) {
				
				lastExecutor = grHist.getLastExecutor();
				
				String pampKey = grHist.getSicClassCode()+"|"+grHist.getSicInstrType();
				
				
				
				//se il gruppo � diverso dall'ultimo analizzato allora cambio variabili di appoggio e incremento il contatore gruppi
				if (lastExportedGroupId!=grHist.getGrId()/*&&intracsCount==0*/) {
				
					lastExportedGroupId = grHist.getGrId();
					groupCount++;
				}
				
				//appIntLog.info("Chiave vettore: "+pampKey+" Chiave classi: "+intracsKey);
				
				//se la coppia classCode/cofCod PAMP corrisponde a quella incontrata su RE
				if (intracsKey.equalsIgnoreCase(pampKey)) {
				
					appIntLog.info(matchFound);
					
					String grStatusLog = "Instrument "+grHist.getSicClassCode()+" (product type: "+grHist.getSicInstrType()+ ") is belonging to the ";
					
					//se il gruppo � disabilitato porto a default altrimenti nome nuovo gruppo
					if (grHist.getGrStatus().equalsIgnoreCase("D")) {
						intracsNewGroup = defaultGrName;
						grStatusLog += "disabled group "+grHist.getGroupName()+". It will be assigned to the default group "+defaultGrName+" during the export";
						//appIntLog.info("gruppo disabilitato: setto in memoria il valore di default "+defaultGrName);
					} else {
						intracsNewGroup = grHist.getGroupName();
						grStatusLog += "group "+grHist.getGroupName()+". It will be assigned to the group "+intracsNewGroup+" during the export";
						//appIntLog.info("gruppo abilitato: setto in memoria il valore "+intracsNewGroup);
					}
					appIntLog.info(grStatusLog);
					
					break;
				} 
				
			}
			
			//appIntLog.info("Popolo HashMap-->chiave: "+intracsKey+"; valore: "+intracsNewGroup);
			
			intracsClassMap.put(intracsKey,intracsNewGroup); 
			
			
			/*//se � diverso il nome del gruppo ma sono nella riga del componente faccio invece l'update sul nome del gruppo
			if (!intracsGroupName.equalsIgnoreCase(groupNameToUpdate)) {
				
				intracsClass.setCgroup(groupNameToUpdate);
				intracsClass.setCchgdt(new BigDecimal(GenericTools.systemDateLongFormat()));
				
				//se il vecchio nome del gruppo equivale al nome di default
				if (!intracsGroupName.equalsIgnoreCase(defaultGrName)) {
					appIntLog.info("Instrument "+intracsClass.getPk().getCclass()+" (type: "+intracsClass.getCptype()+") removed from group "+intracsGroupName+" and assigned to default group "+intracsClass.getDefaultGrpName());
					compRemoved++;
					compCount++;
				} else if (!groupNameToUpdate.equalsIgnoreCase("")){
					appIntLog.info("Instrument "+intracsClass.getPk().getCclass()+" (type: "+intracsClass.getCptype()+") added to group "+groupNameToUpdate);
					compCount++;
				}
				
				IntracsLog intracsLog = new IntracsLog();
				
				intracsLog.setlFile("CGCLS00F");
				intracsLog.setlProg(prgName);
				intracsLog.setlStat("U");
				intracsLog.setlUser(lastExecutor);
				intracsLog.setLogDt1(intracsClass.logCgcls00f());
				
				intracsLogEAO.store(intracsLog);
				
			}
			
			intracsCount++;*/
			
			//TODO
			//scrittura log PAOLA
			
		}
		
		//appIntLog.info("Sto leggendo dalla tabella delle classi per settare EFFETTIVAMENTE il nome del gruppo");
		
		for (Cgcls00f intracsClass:intracsClassArray) {
			
			String intracsGroupName = intracsClass.getCgroup();
			
			String intracsKey = intracsClass.getPk().getCclass()+"|"+intracsClass.getCptype();
			
			String defaultGrName = intracsClass.getDefaultGrpName();
			
			String newGroupName = intracsClassMap.get(intracsKey);
			
			String log = "Instrument "+intracsClass.getPk().getCclass()+" (type: "+intracsClass.getCptype()+") removed from ";
			
			if (intracsGroupName.equalsIgnoreCase(defaultGrName)) {
				log += "default ";
			}
			
			log += "group "+intracsGroupName;
			
			
			//appIntLog.info("confronto tra il nome attuale del gruppo e quello proveniente dalla hashMap--> act: "+intracsGroupName+"; new: "+newGroupName);
			
			//se � diverso il nome del gruppo faccio l'update sul nome del gruppo
			if (!newGroupName.equalsIgnoreCase(intracsGroupName)) {
				
				//appIntLog.info(intracsClass.getCnsv().length());
				
				intracsClass.setCgroup(intracsClassMap.get(intracsKey));
				intracsClass.setCchgdt(new BigDecimal(GenericTools.systemDateLongFormat()));
				
				//se il nuovo nome del gruppo equivale al nome di default
				if (newGroupName.equalsIgnoreCase(defaultGrName)) {
					log += " and assigned to default group "+defaultGrName;
					compRemoved++;
					compCount++;
				} else { //if (!newGroupName.equalsIgnoreCase("")){
					log += " and assigned to group "+newGroupName;
					//appIntLog.info("Instrument "+intracsClass.getPk().getCclass()+" (type: "+intracsClass.getCptype()+") added to group "+intracsClassMap.get(intracsKey));
					compCount++;
				}
				
				appIntLog.info(log);
				
				IntracsLog intracsLog = new IntracsLog();
				
				intracsLog.setlFile("CGCLS00F");
				intracsLog.setlProg(prgName);
				intracsLog.setlStat("U");
				intracsLog.setlUser(lastExecutor);
				intracsLog.setLogDt1(intracsClass.logCgcls00f());
				
				intracsLogEAO.store(intracsLog);
				
			}
			
			intracsCount++;
		}
		
		
		
		// terminati gli update su intracs torno su PAMP per settare a sent = True i gruppi inviati
		String log = "";
		String strGroupComps = " components";
		
		String strRemovedGroupComps = " instruments";
		
		String strGroups = "groups";
		
		if (groupCount==1) {
			strGroups = "group";
		}
		
		if (compCount==0) {
			log = "No record updated on Risk Engine. All the components already belong to the exported "+strGroups;
			
			appIntLog.info(log);
			
		} else {
		
			// pezzetto di frase del log (gruppi) 
			strGroups = groupCount +" "+strGroups;
			
			//pezzetto sui componenti
			if (compCount==1) {
				strGroupComps = " component";
			}
			
			strGroupComps = compCount +strGroupComps;
			
			
			log = strGroupComps+ " of "+strGroups+" updated on Risk Engine; ";
			
			
			if (compRemoved==0) {
				strRemovedGroupComps = " No instrument removed ";
			}
			
			if (compRemoved==1) {
				strRemovedGroupComps = " 1 instrument removed ";
			}
			
			if (compRemoved>1) {
				strRemovedGroupComps = " "+compRemoved+" instruments removed ";
			}
			
			strRemovedGroupComps+="from the groups belonging to on Risk Engine table before the export";
			
			log += strRemovedGroupComps;
			
			
			appIntLog.info(log);
		}

		//gcePampUnit.updateGroupHistorySentStatusAfterExport(readyToExpGroupHistory);
	}
	
}
