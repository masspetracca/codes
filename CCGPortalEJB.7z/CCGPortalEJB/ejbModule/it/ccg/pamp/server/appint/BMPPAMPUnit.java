package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.ClassMarginHistoryEAOLocal;
import it.ccg.pamp.server.entities.ClassMarginHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.ReadyToExpClassMarginHistory;

import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BMPPAMPUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class BMPPAMPUnit implements  BMPPAMPUnitLocal {

	@EJB
	private ClassMarginHistoryEAOLocal clMarHisEAO;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");

        
	public void updateClassMarginHistorySentStatusAfterExport(Vector<ReadyToExpClassMarginHistory> readyClassMarHistVec) throws DataNotValidException {
		
		for (ReadyToExpClassMarginHistory readyClassMarHist : readyClassMarHistVec) {

			
			  ClassMarginHistory clMarHist= clMarHisEAO.findByPrimaryKey(readyClassMarHist.getClMarHist().getPk().getClassId(),readyClassMarHist.getClMarHist().getPk().getIniVDate());
			  clMarHist.setSent("T");
			  clMarHist.setUpdDate(GenericTools.systemDate());
			  clMarHist.setUpdType("U"); 
			  clMarHist.setUpdUsr("System");
			  
			  clMarHisEAO.logUpdate(clMarHist);
			
		}
		appIntLog.info(readyClassMarHistVec.size() + " bond class historical margins sent status updated");
		

	}

}
