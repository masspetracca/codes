package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.Ccgptas00fEAOLocal;
import it.ccg.pamp.server.eao.HistoricalPricesEAOLocal;
import it.ccg.pamp.server.eao.InstrumentEAOLocal;
import it.ccg.pamp.server.entities.Ccgptas00f;
import it.ccg.pamp.server.entities.HistoricalPrices;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.GregorianCalendar;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class IRD
 */
@Stateless
public class IRD implements  IRDLocal {

	private static final long serialVersionUID = 1L;
	@EJB private HistoricalPricesEAOLocal hisPr=null;
	@EJB private InstrumentEAOLocal instr=null;
	@EJB private Ccgptas00fEAOLocal ccgptas=null;

	
	private int total;
	private int failed;
	private int updated;
	
	public int getTotal() {
		return total;
	}
	
	public void setTotal(int total) {
		this.total = total;
	}
	
	public int getUpdated() {
		return updated;
	}
	
	public void setUpdated(int updated) {
		this.updated = updated;
	}
	
	public int getFailed() {
		return failed;
	}
	
	public void setFailed(int failed) {
		this.failed = failed;
	}
	
	
	public IRD() {
    }
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	
	
	/*---------------------------- scarico tassi di interesse------------------------------*/
	
	public String transferInterestRate() throws DataNotValidException {
		setTotal(0);
		setUpdated(0);
		setFailed(0);
		String startMessage = "###### Import of interest Rates from Clearing System started";
		appIntLog.info(startMessage);
		
		Instrument[] instrument = instr.getByDivisCode("B");
		
		for (Instrument instr:instrument) {
			try {
				transferInterestRate(instr, total, failed, updated);
			} catch (Exception e) {
				String error = "Error happened on INSTRID "+instr.getInstrId()+" (IR Node: "+instr.getIrNode()+")";
				appIntLog.debug(error+"\n"+e.getMessage()+"\n"+e.getStackTrace());
			}
		}
		
		total = failed + updated;
		
		String message = "###### Import of Interest Rates from Clearing System finished";
		if (updated==0&&failed==0) {
			message+=" with no effects";
		}
		if (updated>0) {
			message += ": found "+instrument.length+" financial instruments, "+updated+"/"+total+" records successfully updated";
		}
		if (failed>0) {
			if (updated>0) {
				message += ",";
			} else {
				message += ": found "+instrument.length+" financial instruments, ";
			}
			message += failed+" records have not been imported";
		}
		//appIntLog.info(message);
		//actlog.add(message);
		
		return message;
	}
	
	
	
	public void transferInterestRate(Instrument instr, Integer total, Integer failed, Integer updated) throws DataNotValidException {
		int date;
    	int year; 
		int month;
		int day;
		GregorianCalendar cal;
		cal = new GregorianCalendar(1900,0,1);
		Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
		
		/*if (delta) {
			--prendo su HistoricalPrices la data pi� grande per quell'instrId-- 
			
			if (historicalPrices.length>0) {
				lastDate = historicalPrices[0].getPk().getPricedate();
			}
		} else {
			hisPr.removeByInstrId(instr.getIrNode());
		}*/
		
		/*recupero classCode e marketCode da instrument*/
		
		if(instr.getIrNode()==null)
			throw new DataNotValidException("INSTRID "+instr.getInstrId()+": IRNode null value not valid");
		
		String error = "Found INSTRID "+instr.getInstrId()+" (Ir Node: "+instr.getIrNode()+", Date: ";
		String instrNotInClearing ="INSTRID "+instr.getInstrId()+" (Ir Node: "+instr.getIrNode()+") not in INFO system";
		
		
		
		Ccgptas00f ccgptas00f = ccgptas.findByIrNode(instr.getIrNode());
		
		
		
		HistoricalPrices[] historicalPrices = hisPr.findByInstrId(instr.getIrNode());
		if (historicalPrices.length>0) {
			lastDate = historicalPrices[0].getPk().getPricedate();
		}
		//se non ho tassi da scaricare
		if (ccgptas00f==null) {
			appIntLog.warn(instrNotInClearing);
		} else {
			/*Conversione date da long a timestamp*/
			date = (int) ccgptas00f.getSt0Data();
			year = Integer.parseInt(Integer.toString(date).substring(0,4));
			month = Integer.parseInt(Integer.toString(date).substring(4, 6))-1;
			day = Integer.parseInt(Integer.toString(date).substring(6, 8));
			Timestamp convertedDate = new Timestamp(new GregorianCalendar(year,month,day).getTimeInMillis());
			//se la data che sto passando
			if (convertedDate.after(lastDate)) {
				if (!(ccgptas00f.getSt0Tas()== null || ccgptas00f.getSt0Tas().doubleValue()<0.000001)) {
					hisPr.add((int)ccgptas00f.getSt0Day(), convertedDate, ccgptas00f.getSt0Tas(), "E");
					updated++;
				} else {
					appIntLog.warn(error+date+") with Null or 0 value for Interest Rate");
					failed++;
				}
			total++;
			} else {
				appIntLog.warn("Date not in PAMP System: "+convertedDate.toString().substring(0, 10));
			}
		}
		setTotal(total.intValue());
		setUpdated(updated.intValue());
		setFailed(failed.intValue());
	}
	
}
