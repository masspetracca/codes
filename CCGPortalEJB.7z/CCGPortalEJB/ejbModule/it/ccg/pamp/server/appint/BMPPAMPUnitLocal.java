package it.ccg.pamp.server.appint;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.ReadyToExpClassMarginHistory;

import java.util.Vector;

import javax.ejb.Local;

@Local
public interface BMPPAMPUnitLocal {
	public void updateClassMarginHistorySentStatusAfterExport(Vector<ReadyToExpClassMarginHistory> readyClassMarHistVec) throws DataNotValidException;
}
