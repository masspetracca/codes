package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.InstrIdTrascodeEAOLocal;
import it.ccg.pamp.server.eao.InstrumentEAOLocal;
import it.ccg.pamp.server.eao.MarginHistoryEAOLocal;
import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.MarginHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.utils.InstrIdTrascodePlus;
import it.ccg.pamp.server.utils.NotSyncPampIntracs;
import it.ccg.pamp.server.utils.NumberOfErrorForCMCBatch;
import it.ccg.pamp.server.utils.ReadyToExpMarginHistory;

import java.math.BigDecimal;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class AMP
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class AMP implements  AMPLocal {

	@EJB
	private MarginHistoryEAOLocal marHisEAO ;
	
	@EJB
	private InstrumentEAOLocal instrEAO;
	
	@EJB
	private InstrIdTrascodeEAOLocal instrTrancodeEAO;

	@EJB
	private CMCLocal cmcEAO;

	
	@EJB
	private AMPINTRACSUnitLocal ampintracsunit;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	public AMP() {
	}

	

	
	
	@Override
	public void readIntracs() throws DataNotValidException {
			
		cmcEAO.checkDataPAMPVsIntracs(new NumberOfErrorForCMCBatch(0));
		
		
	}

	
	@Override
	public Vector<ReadyToExpMarginHistory> getMarginHistoryReadyToExp() throws DataNotValidException, InstrumentDataNotAvailableException {

		Vector<ReadyToExpMarginHistory> readymarghistvec = new Vector<ReadyToExpMarginHistory>();

		MarginHistory[] marHisToExp = marHisEAO.getMarHisToExport();

		for (MarginHistory mHis : marHisToExp) {

			int instrId = mHis.getPk().getInstrId();
			Instrument instr = instrEAO.findByPrimaryKey(instrId);
			if (instr == null) {
				throw new InstrumentDataNotAvailableException(instrId, "No instruments found with this instrID");
			}

			/*BigDecimal propMinMar = mHis.getMinMargin();
			String classCode = instr.getClassCode();*/

			// recupero dalla tabella di transcodifica
			InstrIdTrascode[] instrIdTC = instrTrancodeEAO.getSicInstr(instrId);
			if (instrIdTC.length == 0) {
				throw new InstrumentDataNotAvailableException(instrId, "No INTRACS instruments linked to this PAMP instrID");
			}
			
			Vector<InstrIdTrascodePlus> instrtcplusvec= new Vector<InstrIdTrascodePlus>();
			
			for (InstrIdTrascode instrTC : instrIdTC) {
				String sicInstrType = instrTC.getPk().getSicInstrTy();
				
				
				// se option (O)
				//abbiamo aggiunto anche la F perk� vogliamo aggiornare il minimo del sottostante anche in questo caso
				if (sicInstrType.equalsIgnoreCase("O")||sicInstrType.equalsIgnoreCase("F")) {
					
						int optInstrId=instrTC.getPk().getInstrId();
						
						// prendo l'underlying di quello strumento
						
						Instrument derivInstr=instrEAO.findByPrimaryKey(optInstrId);
						
						if (derivInstr.getUndInstrId() == null) {
							throw new InstrumentDataNotAvailableException(derivInstr.getInstrId(), "no underlying instruments defined for the equity derivative instrument");
						}
						int undInstrId = derivInstr.getUndInstrId();
						Instrument undInstr = instrEAO.findByPrimaryKey(undInstrId);
						if (undInstr == null) {
							throw new InstrumentDataNotAvailableException(instrId, "No underlying instruments found for instrID: "+optInstrId);
						}

						//############################
						BigDecimal multiplier=derivInstr.getMult();
						
						BigDecimal cashminmar=null;
								
						int instrID= derivInstr.getInstrId();
								
						

						if (mHis == null) {
							throw new InstrumentDataNotAvailableException(instrID, "Margin History not available");

						}
								
						if(multiplier!=null){
							
							if(mHis.getMinMargin()!=null)
								cashminmar=mHis.getMinMargin().divide(multiplier, 3, BigDecimal.ROUND_CEILING);
							/*else
								throw new InstrumentDataNotAvailableException(instrID, "No minimum margins available");*/
							
						}
						/*
						else{
							throw new InstrumentDataNotAvailableException(instrID, "No multipliers available for this Derivative");
							
						}
						*/
						
						if(cashminmar==null)
							instrtcplusvec.add(new InstrIdTrascodePlus(instrTC,undInstrId));
						else{
						// Recupero la soglia massima di variazione del margine ammessa per quel
						// derivato
						BigDecimal marTh = undInstr.getMarginTh();

						// trascodifica per andare a leggere su SIC il derivato
						InstrIdTrascode[] instrIdTCUND = instrTrancodeEAO.getSicInstr(undInstrId);
			
						instrtcplusvec.add(new InstrIdTrascodePlus(instrTC, cashminmar, marTh, instrIdTCUND,undInstrId));
						}
						
				}
				
				else{
					if (!sicInstrType.equalsIgnoreCase("I"))
						instrtcplusvec.add(new InstrIdTrascodePlus(instrTC));
				}
				
				
				
			}

			readymarghistvec.add(new ReadyToExpMarginHistory(mHis, instr, instrtcplusvec));

		}
		
		String toBeExported = "";
		
		if (marHisToExp.length==0||marHisToExp==null) {
			toBeExported = "No historical margins found to export";
		} else {
			toBeExported = marHisToExp.length+" historical margins ready to be exported";
		}
		
		appIntLog.info(toBeExported);

		return readymarghistvec;
	}

	


	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void export() throws Exception {
		
		//this.readIntracs();

		Vector<ReadyToExpMarginHistory> readymarghistoexp = this.getMarginHistoryReadyToExp();

		if (readymarghistoexp.size()>0) {
		
			ampintracsunit.exportPampMarginHistoryToIntracs(readymarghistoexp);
		}

	}
	
	//lancio austria
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void exportOeKB() throws Exception {
		
		//this.readIntracs();

		Vector<ReadyToExpMarginHistory> readymarghistoexp = this.getMarginHistoryReadyToExp();
		
		if (readymarghistoexp.size()>0) {
			
			ampintracsunit.exportOeKBPampMarginHistoryToRiskEngine(readymarghistoexp);
				
		}

	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public Vector<NotSyncPampIntracs> checkPampIntracs() throws DataNotValidException, InstrumentDataNotAvailableException {
		Vector<ReadyToExpMarginHistory> checkmargvec= this.getMarginHistoryToCheck();
		return ampintracsunit.checkPampMarginHistoryOnIntracs(checkmargvec);
		
	}
	

	public Vector<ReadyToExpMarginHistory> getMarginHistoryToCheck() throws DataNotValidException, InstrumentDataNotAvailableException {

		Vector<ReadyToExpMarginHistory> readymarghistvec = new Vector<ReadyToExpMarginHistory>();

		MarginHistory[] marHisToCheckSync = marHisEAO.getMarHisNotSync();

		for (MarginHistory mHis : marHisToCheckSync) {

			int instrId = mHis.getPk().getInstrId();
			Instrument instr = instrEAO.findByPrimaryKey(instrId);
			if (instr == null) {
				throw new InstrumentDataNotAvailableException(instrId, "No instruments found with this instrID");
			}

			/*BigDecimal propMinMar = mHis.getMinMargin();
			String classCode = instr.getClassCode();*/

			// recupero dalla tabella di transcodifica
			InstrIdTrascode[] instrIdTC = instrTrancodeEAO.getSicInstr(instrId);
			if (instrIdTC.length == 0) {
				throw new InstrumentDataNotAvailableException(instrId, "No INTRACS instruments linked to this PAMP instrID");
			}
			
			Vector<InstrIdTrascodePlus> instrtcplusvec= new Vector<InstrIdTrascodePlus>();
			
			for (InstrIdTrascode instrTC : instrIdTC) {
								
				if (!instrTC.getPk().getSicInstrTy().equalsIgnoreCase("I"))
					instrtcplusvec.add(new InstrIdTrascodePlus(instrTC));
				
			}

			readymarghistvec.add(new ReadyToExpMarginHistory(mHis, instr, instrtcplusvec));

		}

		appIntLog.info(marHisToCheckSync.length + " Margin History ready to be checked");

		return readymarghistvec;
	}

	
	
	
	
	/*public Vector<NotSyncPampIntracs> checkPampMarginHistoryOnIntracs(Vector<ReadyToExpMarginHistory> readymarghistvec) throws DataNotValidException, InstrumentDataNotAvailableException, LargeThresoldMarginException {
		
		
		
		Vector<NotSyncPampIntracs> notSyncInstrVec=new Vector<NotSyncPampIntracs>(); 
		
		
		//scostamento massimo ammesso tra i valori su intracs e i valori su pamp
		BigDecimal scostamentoMassimo=new BigDecimal(0.0001);

		for (ReadyToExpMarginHistory readymarghist : readymarghistvec) {
			
			
			MarginHistory mHis = readymarghist.getMarhist();

			Instrument instr = readymarghist.getInstr();
			

			

			BigDecimal pampMar = mHis.getMargin();
			BigDecimal pampMinMar = mHis.getMinMargin();
			BigDecimal pampStraddle = mHis.getStraddle();

			Vector<InstrIdTrascodePlus> instrIdTCplus = readymarghist.getInstrtcplusvec();
			if(instrIdTCplus.isEmpty()) notSyncInstrVec.add(new NotSyncPampIntracs(mHis, "No INTRACS margins for this PAMP MarginHistory"));

			for (InstrIdTrascodePlus instrTCplus : instrIdTCplus) {
				InstrIdTrascode instrTC = instrTCplus.getInstrTC();
				Cgcls00f cgc = cgcls00fEAO.findByPrimaryKey(instrTC.getPk().getSicInstr(), instrTC.getPk().getSicInstrTy());
				String classCode = instrTC.getPk().getSicInstr(); // instr.getClassCode();
				if (cgc != null) {
					
					BigDecimal intracsMargin=cgc.getCmrgni();
					BigDecimal intracsMinMargin=cgc.getCminrt();
					
					String sicInstrType = instrTC.getPk().getSicInstrTy();
					//double delta = getDelta(oldMar.doubleValue(), propMar.doubleValue());

					
						//Prima di tutto a prescindere dal tipo si controlla il margine
						if(pampMar.subtract(intracsMargin).abs().compareTo(scostamentoMassimo)==1){
							notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS margin and PAMP margin are different"));
							continue;
							
						}
						
						if(sicInstrType.equalsIgnoreCase("F")) {
							Hfsrat2 hfsrat = hfsrat2EAO.findByFClass(classCode);
							
							if(hfsrat==null){
								if(pampStraddle!=null){
									notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS straddle null, PAMP straddle not null"));
									continue;
								}
									
							}
							else{
								if(pampStraddle==null){
									notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS straddle not null, PAMP straddle null"));
									continue;
								}
								else 
									if(pampStraddle.subtract(hfsrat.getFssprd()).abs().compareTo(scostamentoMassimo)==1){
										notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS straddle and PAMP straddle are different"));
										continue;
									}
								}
							
						}

						
						if (sicInstrType.equalsIgnoreCase("O")) {
							
							if(intracsMinMargin==null){
								if(pampMinMar!=null){
									notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS minmargin null, PAMP minmargin not null"));
									continue;
								}
									
							}
							else{
								if(pampMinMar==null){
									notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS minmargin not null, PAMP minmargin null"));
									continue;
								}
								else 
									if(pampMinMar.subtract(intracsMinMargin).abs().compareTo(scostamentoMassimo)==1){
										notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS minmargin and PAMP minmargin are different"));
										continue;
									}
							}
							
						}

					

				}

				else {

					notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "No INTRACS margins for this transcoded pamp instrument"));
					
				}

			}

		}

		appIntLog.info(notSyncInstrVec.size() + " Instruments not synchronized");
		return notSyncInstrVec;
		

	}*/
	
}


