package it.ccg.pamp.server.appint;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.ReadyToExpGroupHistory;

import java.util.List;

import javax.ejb.Local;

@Local
public interface GCELocal {
	public List<ReadyToExpGroupHistory> getGroupsReadyToExp() throws DataNotValidException;
	
	public List<ReadyToExpGroupHistory> getGroupsAndComponentsReadyToExp() throws DataNotValidException;
	
	public void export() throws Exception;
}
