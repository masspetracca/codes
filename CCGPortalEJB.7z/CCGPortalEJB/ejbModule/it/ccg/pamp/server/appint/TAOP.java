package it.ccg.pamp.server.appint;

import java.math.BigDecimal;
import java.util.List;
import java.util.Vector;

import it.ccg.pamp.server.eao.BondClassEAOLocal;
import it.ccg.pamp.server.eao.ClassIdTrascodeEAOLocal;
import it.ccg.pamp.server.eao.ClassMarginHistoryEAOLocal;
import it.ccg.pamp.server.eao.IntraClassOffsetHistoryEAOLocal;
import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.entities.ClassIdTrascode;
import it.ccg.pamp.server.entities.ClassMarginHistory;
import it.ccg.pamp.server.entities.InterclassOffsetHistory;
import it.ccg.pamp.server.entities.IntraclassOffsetHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.BondClassDataNotAvailableException;
import it.ccg.pamp.server.utils.ClassIdTrascodePlus;
import it.ccg.pamp.server.utils.NumberOfErrorForCMCBatch;
import it.ccg.pamp.server.utils.ReadyToExpClassMarginHistory;
import it.ccg.pamp.server.utils.ReadyToExpIntraClassOffsetHistory;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TAOP
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class TAOP implements  TAOPLocal {

	@EJB
	private IntraClassOffsetHistoryEAOLocal clTraHisEAO ;
	
	@EJB
	private BondClassEAOLocal bondClassEAO;
	
	@EJB
	private ClassIdTrascodeEAOLocal classTrancodeEAO;

	@EJB
	private CMCLocal cmcEAO;

	@EJB
	private TAOPINTRACSUnitLocal taopIntracsUnit;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	public TAOP() {
	}
	
	@Override
	public void readIntracs() throws DataNotValidException {
				
		cmcEAO.checkClassMarginDataPAMPVsIntracs(new NumberOfErrorForCMCBatch(0));
		
		// ############################################################################
	}
	
	public Vector<ReadyToExpIntraClassOffsetHistory> getIntraClassOffsetHistoryReadyToExp() throws DataNotValidException, BondClassDataNotAvailableException {

		Vector<ReadyToExpIntraClassOffsetHistory> readyIntraClassOffsetHistVec = new Vector<ReadyToExpIntraClassOffsetHistory>();

		BigDecimal marTh = new BigDecimal(10000);
		
		
		List<IntraclassOffsetHistory> clTraHisToExp = clTraHisEAO.getIntraClassOffsetHistoryToExport();

		// ciclo su lista di intraclass storiche da esportare
		for (IntraclassOffsetHistory clTraHis : clTraHisToExp) {

			int classId = clTraHis.getPk().getClassId();
			
			BondClass bondClass = bondClassEAO.findByPrimaryKey(classId);
			
			//verifico che la classe su cui sto andando ad operare effettivamente esista ancora su PMPTCLASS
			if (bondClass==null) {

				throw new BondClassDataNotAvailableException(classId, "No INTRACS bond class linked to this PAMP classId");
			} else {
				// recupero dalla tabella di transcodifica
				List<ClassIdTrascode> classIdTC = classTrancodeEAO.getSicClassId(classId);
				
				if (classIdTC.size() == 0) {
					throw new BondClassDataNotAvailableException(classId, "No INTRACS bond class linked to this PAMP classId");
				}
				
				Vector<ClassIdTrascodePlus> classTcVect= new Vector<ClassIdTrascodePlus>();
			
				for (ClassIdTrascode classTC : classIdTC) {
					
					classTcVect.add(new ClassIdTrascodePlus(classTC));
				}
					
				readyIntraClassOffsetHistVec.add(new ReadyToExpIntraClassOffsetHistory(clTraHis, bondClass, classTcVect));
			}
			
		}

		appIntLog.info(clTraHisToExp.size() + " Bond intraclass ready to be exported");
		
		return readyIntraClassOffsetHistVec;
	}
	

	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void export() throws Exception {
		
		//TODO
		//this.readIntracs();

		Vector<ReadyToExpIntraClassOffsetHistory> readyIntraClassOffsetHistToExp = this.getIntraClassOffsetHistoryReadyToExp();

		taopIntracsUnit.exportPampIntraClassOffsetHistoryToIntracs(readyIntraClassOffsetHistToExp);

	}

}
