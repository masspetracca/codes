package it.ccg.pamp.server.appint.stressTest;

import java.sql.Timestamp;
import java.util.List;

import it.ccg.pamp.server.eao.HistoricalPricesEAOLocal;
import it.ccg.pamp.server.eao.IndexWeightEAOLocal;
import it.ccg.pamp.server.eao.InstrumentEAOLocal;
import it.ccg.pamp.server.entities.IndexWeight;
import it.ccg.pamp.server.entities.IndexWeightPK;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.Ipindx1;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class IWDPAMPUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class IWDPAMPUnit implements  IWDPAMPUnitLocal {

	@EJB private IndexWeightEAOLocal pampIndexWeightEAO;
    @EJB private InstrumentEAOLocal instrumentEAO; 

	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");

	public void importIntracsIdxWeights(List<Ipindx1> readyIndexWeightToDownload) throws DataNotValidException, DataNotAvailableException {
		
		String indexToRemove = "";
		
		Integer idxId = null;
		
		int weightCount = 0;
		
		//per ogni indice presente su intracs procedo alla rimozione del corrispettivo su PAMP
		for (Ipindx1 intracsIdxWei:readyIndexWeightToDownload) {
			
			String intracsIndexClassCode = intracsIdxWei.getpK().getXClass();
			
			String intracsComponentClassCode = intracsIdxWei.getpK().getXSymbl();
			
			
			
			// se l'indice intracs � diverso dalla variabile di appoggio allora lo devo cercare e rimuoverne i componenti su PMPTIDXWEI altrimenti li aggiungo soltanto
			if (!intracsIndexClassCode.equalsIgnoreCase(indexToRemove)) {
				
				// vado a cercare sull'anagrafica l'instrid di quell'indice
				Instrument pampIndex = instrumentEAO.getByClassCodeAndDivisCode(intracsIndexClassCode, "X");
				
				if (pampIndex!=null) {
				
					//setto la variabile spia sul valore dell'indice appena trovato
					indexToRemove = intracsIndexClassCode;
				
					idxId = pampIndex.getInstrId();
							
					// rimuovo su PMPTIDXWEI in base all'Id dell'indice
					int removedIdx = pampIndexWeightEAO.removeByIndexId(idxId);
	    			
					String componentString = "component";
					
					if (removedIdx>1) {
						componentString = "components";
					}
					
					appIntLog.info("removed "+removedIdx+" "+componentString+" for index "+intracsIndexClassCode+" on PAMP System");
				
				}
				
			} 
			
			if (!indexToRemove.equalsIgnoreCase("")) {
				//aggiungo su pamp
				 				
				// vado a cercare sull'anagrafica l'instrid di quel componente
				Instrument instrComp = instrumentEAO.getByClassCodeAndDivisCode(intracsComponentClassCode, "E");
					
				if (instrComp!=null) {
					
	    			int idxComponentInstrId = instrComp.getInstrId();
	    				
	    			IndexWeightPK pampIdxWeiPK = new IndexWeightPK();
	    				
	    			pampIdxWeiPK.setIdxId(idxId);
	    			pampIdxWeiPK.setInstrId(idxComponentInstrId);
	    				
	    			IndexWeight pampIdxWei = new IndexWeight();
	    			
	    			long outShare = intracsIdxWei.getXShare();
	    			long dividend = intracsIdxWei.getXShareN();
	    			// converto la data da int a timestamp
	    			Timestamp pampIdxWeiDate = GenericTools.convertDateFromIntToTimestamp(intracsIdxWei.getXADate());
	    			
	    			pampIdxWei.setPk(pampIdxWeiPK);
	    			pampIdxWei.setDividend(dividend);
	    			pampIdxWei.setOutshare(outShare);
	    				
	    			pampIdxWei.setDate(pampIdxWeiDate);
	    				
	    			//aggiungo su PAMP
	    			pampIndexWeightEAO.store(pampIdxWei);
	    			appIntLog.info("Downloaded index weight for index "+idxId+"("+intracsIndexClassCode+") - instrument id "+idxComponentInstrId+" (code: "+instrComp.getClassCode()+"), dividend: "+dividend+", outshare: "+outShare);
	    			weightCount++;
				} else {
					//appIntLog.warn("Instrument "+intracsIdxWei.getpK().getXSymbl().trim()+" is not enabled in Pamp System");
					throw new DataNotAvailableException("Instrument "+intracsIdxWei.getpK().getXSymbl().trim()+" is not enabled in Pamp System");
				}
			}
		}
	}

}
