package it.ccg.pamp.server.appint;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import it.ccg.pamp.server.eao.CalendarEAOLocal;
import it.ccg.pamp.server.eao.Cgcalmk00fEAOLocal;
import it.ccg.pamp.server.eao.MarketTrascodeEAOLocal;
import it.ccg.pamp.server.entities.Calendar;
import it.ccg.pamp.server.entities.CalendarPK;
import it.ccg.pamp.server.entities.Cgcalmk00f;
import it.ccg.pamp.server.entities.MarketTrascode;
import it.ccg.pamp.server.utils.GenericTools;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MDD
 */
@Stateless
public class MDD implements  MDDLocal {

	private static final long serialVersionUID = 1L;
	
	@EJB private MarketTrascodeEAOLocal mktTrascode=null;
	@EJB private Cgcalmk00fEAOLocal cgcalmk00f=null;
	@EJB private CalendarEAOLocal calendar=null;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	public String marketDatesDownload() {
		int totalMktDates = 0;
		int totalMarketCode = 0;
		
		String logMessage = "market dates from Clearing System market date calendar downloaded for";
		
		try {
			int countDate = 0;
			
			//rimuovo tutte le date di calendario maggiori del giorno antecedente la data di sistema
			Timestamp sysDate = GenericTools.systemDate();
			calendar.removeByMarketDate(GenericTools.previousDate(sysDate));
			
			
			
			// cerco sulla tabella di trascodifica dei mercati 
			List<MarketTrascode> mktTrascodeList = mktTrascode.fetch();
			totalMarketCode = mktTrascodeList.size();
			
			// costruisco la data antecedente alla data di sistema in formato long
    		String yesterday = GenericTools.previousDate(sysDate).toString();
    		long lastMarketDate = Long.parseLong(yesterday.substring(0,4)+yesterday.substring(5,7)+yesterday.substring(8,10));
    		
        	//per ciascun mercato vado a prendermi tutte le date successive alla data di sistema
			for (MarketTrascode mktTrascode:mktTrascodeList) {
				
				List<Cgcalmk00f> cgcCalMk00fList = cgcalmk00f.findDatesByMarketCode(mktTrascode.getPk().getSicMarket(),lastMarketDate);
				totalMktDates = cgcCalMk00fList.size();
				
				// per ogni data vado a scrivere sulla nostra calendar
				for (Cgcalmk00f cgcCalMk00f:cgcCalMk00fList) {
					
					
					// converto da long a timestamp la data da scaricare
					int clearingMarketDate = (int) cgcCalMk00f.getPk().getChDate();
					int year = Integer.parseInt(Integer.toString(clearingMarketDate).substring(0,4));
					int month = Integer.parseInt(Integer.toString(clearingMarketDate).substring(4, 6))-1;
					int day = Integer.parseInt(Integer.toString(clearingMarketDate).substring(6, 8));
					Timestamp pampMarketDate = new Timestamp(new GregorianCalendar(year,month,day).getTimeInMillis());
					
					//setto l'oggetto calendario
					Calendar cal = new Calendar();
					CalendarPK calPk = new CalendarPK();
					calPk.setDate(pampMarketDate);
					calPk.setMarketCode(mktTrascode.getPk().getMarketCode());
					cal.setPk(calPk);
					
					//store sulla calendar
					calendar.store(cal);
					
				}
				appIntLog.info(totalMktDates+" "+logMessage+" market code: "+mktTrascode.getPk().getMarketCode());
			}
		
			
		} catch (Exception e) {
			
		}
		logMessage = (totalMktDates*totalMarketCode)+" "+logMessage+" "+totalMarketCode+" markets";
		appIntLog.info(logMessage);
		return logMessage;	
	}
}
