package it.ccg.pamp.server.appint.stressTest;
import java.util.Vector;

import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.utils.StressTestDerivativesHistPricesReadyToExp;
import it.ccg.pamp.server.utils.StressTestHistPricesReadyToExp;
import it.ccg.pamp.server.utils.StressTestIndexPricesReadyToExp;

import javax.ejb.Local;

@Local
public interface ESTHPLocal {
	
	public Vector<StressTestHistPricesReadyToExp> getStressTestCashPricesReadyToExp(int stId, String scenario) throws DataNotValidException, InstrumentDataNotAvailableException;
	
	public Vector<StressTestIndexPricesReadyToExp> getStressTestIndexPricesReadyToExp(int stId, String scenario) throws DataNotValidException, InstrumentDataNotAvailableException;
	
	public Vector<StressTestDerivativesHistPricesReadyToExp> getStressTestDerivativesHistPricesReadyToExp(int stId, String scenario) throws DataNotAvailableException,DataNotValidException, InstrumentDataNotAvailableException;
	
	public Vector<StressTestHistPricesReadyToExp> getStressTestBondsReadyToExp(int stId, String scenario) throws DataNotValidException, InstrumentDataNotAvailableException;
	
	
	
	/*public void exportStressedHistPrices(int stId, String scenario) throws Exception;
	
	public void exportStressedDerivativesHistPrices(int stId, String scenario) throws Exception;*/
	
	//public void exportStressTest(int stId, String scenario) throws Exception;
	public void exportBondStressTest(StressTest lastStressTest, String scenario) throws Exception;
	
	public void exportStressTest(StressTest lastStressTest, String scenario) throws Exception;
}
