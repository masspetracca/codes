package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.Mtsmgnf92fEAOLocal;
import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.entities.InterclassOffsetHistory;
import it.ccg.pamp.server.entities.Mtsmgnf92f;
import it.ccg.pamp.server.exceptions.BondClassDataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.LargeThresoldMarginException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.ReadyToExpInterClassOffsetHistory;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TEOPINTRACSUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class TEOPINTRACSUnit implements  TEOPINTRACSUnitLocal {

	@EJB
	private Mtsmgnf92fEAOLocal mtsmgnf92fEAO;
		
	@EJB
	private TEOPPAMPUnitLocal teopPamp;

	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void exportPampInterClassOffsetHistoryToIntracs(Vector<ReadyToExpInterClassOffsetHistory> readyInterClassOffsetHistVec) throws DataNotValidException, BondClassDataNotAvailableException, LargeThresoldMarginException {
		
		MathContext mc=new MathContext(4, RoundingMode.HALF_EVEN);
		
		for (ReadyToExpInterClassOffsetHistory readyInterClassOffsetHist : readyInterClassOffsetHistVec) {

			InterclassOffsetHistory clTerHis = readyInterClassOffsetHist.getClTerHist();

			BondClass bndClass1 = readyInterClassOffsetHist.getBondClass1();
			BondClass bndClass2 = readyInterClassOffsetHist.getBondClass2();
			
			String pampClassId1 = Integer.toString(bndClass1.getClassId());
			String pampClassId2 = Integer.toString(bndClass2.getClassId());
			
			if (bndClass1.getClassId()<10) {
				pampClassId1 = "0"+pampClassId1;
			}
			if (bndClass2.getClassId()<10) {
				pampClassId2 = "0"+pampClassId2;
			}
			
			// Recupero la soglia massima di variazione del margine ammessa
			//TODO mettere campo su PMPTCLASS
			BigDecimal marTh = new BigDecimal(10000);
			
			// Recupero l'offset proposto di una classe pronto x l'export
			BigDecimal propOffset = clTerHis.getOff();
			
			Mtsmgnf92f mts = mtsmgnf92fEAO.findByPrimaryKey(pampClassId1,pampClassId2);
			
			
			// se c'� un record x quella classe procedo con l'export
			if (mts != null) {
				// vecchio margine su intracs
				BigDecimal oldOffset = mts.getF92intridp();
				
				//margin coeff x il quale moltiplicare il nostro proposto
				//BigDecimal marginCoef=classTC.getMarCf();
				
				//margine proposto che effettivamente sar� esportato
				BigDecimal roundedPropOffset = propOffset.round(mc);//multiply(marginCoef,mc);
				
				// delta per comparazione con la soglia massima di tolleranza
				BigDecimal delta = this.getDelta(oldOffset, roundedPropOffset);

				// se il delta <= della soglia stabilita per quella classe
				// procedo all'update

				if (marTh==null || marTh.compareTo(delta)>=0) {
					
					appIntLog.info("Export bond interclass offset values for classId1:" + pampClassId1 + " (classDesc: " + bndClass1.getClassDesc().trim()+ "), classId2:" + pampClassId2 + " (classDesc: " + bndClass2.getClassDesc().trim()+ ") - VALUES: Old bond intraclass offset: " + oldOffset
							+ "; New bond interclass offset: " + roundedPropOffset);
					
					
					
					//setto il nuovo offset
					mts.setF92intridp(roundedPropOffset);
					
				} else {
					String deltaPerc = GenericTools.percentValue(delta, new MathContext(4));
					String marThPerc = GenericTools.percentValue(marTh, new MathContext(4));
					throw new LargeThresoldMarginException(clTerHis.getPk().getClassId1(), bndClass1.getClassDesc(), oldOffset, propOffset, deltaPerc, marThPerc,"O");
				}

			}
			//se invece non ci sono record scateno un eccezione
			else {
				String exceptionTxt = "No bond interaclass offsets available on the Clearing system for classId1: " + bndClass1.getClassId() +" (classDesc: " + bndClass1.getClassDesc().trim()+ "), classId2: "+bndClass2.getClassId()+" (classDesc: " + bndClass2.getClassDesc().trim()+ ")";
				throw new BondClassDataNotAvailableException(bndClass1.getClassId(),bndClass2.getClassId(), exceptionTxt);

			}

			/*Vector<ClassIdTrascodePlus> classIdTCplus = readyInterClassOffsetHist.getClassTcPlusVec();
			
			for (ClassIdTrascodePlus classTCplus : classIdTCplus) {
				
				ClassIdTrascode classTC = classTCplus.getClTrascode();
				
				//conversione necessaria perch� il campo su quella tabella � di tipo stringa
				String sicClassId = classTC.getPk().getSicClassId();//Integer.toString(clMarHis.getPk().getClassId());
				String pampClassId = Integer.toString(classTC.getPk().getClassId());
				
				
				//cerco per chiave sulla mtsmgnf91fEAO passando il classId
				Mtsmgnf92f mts = mtsmgnf92fEAO.findByPrimaryKey(Integer.toString(bndClass1.getClassId()),Integer.toString(bndClass2.getClassId()));
								
				
				// se c'� un record x quella classe procedo con l'export
				if (mts != null) {
					// vecchio margine su intracs
					BigDecimal oldOffset = mts.getF92intridp();
					
					//margin coeff x il quale moltiplicare il nostro proposto
					//BigDecimal marginCoef=classTC.getMarCf();
					
					//margine proposto che effettivamente sar� esportato
					BigDecimal roundedPropOffset = propOffset.round(mc);//multiply(marginCoef,mc);
					
					// delta per comparazione con la soglia massima di tolleranza
					BigDecimal delta = this.getDelta(oldOffset, roundedPropOffset);

					// se il delta <= della soglia stabilita per quella classe
					// procedo all'update

					if (marTh==null || marTh.compareTo(delta)>=0) {
						
						appIntLog.info("Export bond intraclass offset values for classId1:" + pampClassId + " (classDesc: " + bndClass1.getClassDesc()+ ") - VALUES: Old bond intraclass offset: " + oldOffset
								+ "; New bond intraclass offset: " + roundedPropOffset);
						
						
						
						//setto il nuovo margine
						mts.setF92intridp(roundedPropOffset);
						
					} else {
						String deltaPerc = GenericTools.percentValue(delta, new MathContext(4));
						String marThPerc = GenericTools.percentValue(marTh, new MathContext(4));
						throw new LargeThresoldMarginException(clTerHis.getPk().getClassId1(), bndClass1.getClassDesc(), oldOffset, propOffset, deltaPerc, marThPerc,"O");
					}

				}
				//se invece non ci sono record scateno un eccezione
				else {

					throw new InstrumentDataNotAvailableException(classTC.getPk().getClassId(), "No bond intraclass offsets available on the Clearing system for class Id: " + classTC.getPk().getClassId()
							+ " (classDesc: " + bndClass1.getClassDesc().trim()+ ")");

				}

			}
*/
		}

		appIntLog.info(readyInterClassOffsetHistVec.size() + " bond interclass offset history exported to INTRACS");
		
		//update dello status dei margini su PMPTCLMARH
		teopPamp.updateInterClassOffsetHistorySentStatusAfterExport(readyInterClassOffsetHistVec);

	}
	
	@TransactionAttribute(TransactionAttributeType.NEVER)
	public BigDecimal getDelta(BigDecimal oldOffset, BigDecimal propOffset) {
		BigDecimal delta = (oldOffset.subtract(propOffset)).divide(oldOffset,8,RoundingMode.HALF_EVEN);
		return delta.abs();
	}


}
