package it.ccg.pamp.server.appint;


import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.utils.NotSyncPampIntracs;
import it.ccg.pamp.server.utils.ReadyToExpMarginHistory;

import java.util.Vector;

import javax.ejb.Local;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

@Local
public interface AMPLocal {
	public abstract void readIntracs() throws DataNotValidException;

	public abstract Vector<ReadyToExpMarginHistory> getMarginHistoryReadyToExp() throws DataNotValidException, InstrumentDataNotAvailableException;

	
	@TransactionAttribute(TransactionAttributeType.NEVER)
	public abstract void export() throws Exception;
	
	@TransactionAttribute(TransactionAttributeType.NEVER)
	public abstract void exportOeKB() throws Exception;

	
	public Vector<NotSyncPampIntracs> checkPampIntracs() throws DataNotValidException, InstrumentDataNotAvailableException ;
}
