package it.ccg.pamp.server.appint.stressTestOeKB;

import it.ccg.pamp.server.appint.stressTest.ESTHPINTRACSUnitLocal;
import it.ccg.pamp.server.eao.InstrIdTrascodeEAOLocal;
import it.ccg.pamp.server.eao.InstrumentEAOLocal;
import it.ccg.pamp.server.eao.SchedulerEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestHistPriceEAOLocal;
import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.utils.StressTestHistPricesReadyToExp;

import java.util.List;
import java.util.Vector;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ESTHP
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class OeKBSTP implements  OeKBSTPLocal {

	@EJB
	private StressTestHistPriceEAOLocal stHPEAO ;
	
	@EJB
	private InstrumentEAOLocal instrEAO;
	
	@EJB
	private InstrIdTrascodeEAOLocal instrTrancodeEAO;
	
	@EJB
	private OeKBReUnitLocal oeKbReUnit;
	
	@EJB
	private SchedulerEAOLocal scheduler;
	
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "PAMP";
		}
	}
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public Vector<StressTestHistPricesReadyToExp> getStressTestCashPricesReadyToExp(int stId, String scenario) throws DataNotValidException, InstrumentDataNotAvailableException {

		//recupero dalla tabella dei prezzi stressati tutti i prezzi su cui voglio effettuare lo stress test x tipologia di scenario
		List<StressTestHistPrice> stressTestCashPrToExpList = stHPEAO.getStressTestHistPriceToExport(stId, scenario);
		
		//creo un'oggettone di appoggio che conterr� ogni istanza di tipo StressTestHistPrice e una stringa che identifica il classCode dello strumento 
		Vector<StressTestHistPricesReadyToExp> stressTestHistPricesReadyToExpVect = new Vector<StressTestHistPricesReadyToExp>();
		
		String toBeExported = "No equity cash or bond stressed prices found to export";
		
		if (!(stressTestCashPrToExpList == null || stressTestCashPrToExpList.size() == 0)) {
			
			//int batchId = 146;
			
			/*if (scenario.equalsIgnoreCase("D")) {
				
				batchId = 123;
				
			}*/
			
		
			String lastExecutor = userString();//scheduler.getLastExecutor(batchId);
			
			
			int foundToExport = 0;
			
			int eqFoundToExport = 0;
			
			int bondFoundToExport = 0;
			// per ogni prezzo stressato da esportare vado a prendere sulla instrument il classCode che mi servir� per incrociare su intracs
			for (StressTestHistPrice stressTestHistPrice:stressTestCashPrToExpList) {
				
				// cerco lo strumento sull'anagrafica
				Instrument instr = instrEAO.findByPrimaryKey(stressTestHistPrice.getPk().getInstrId());
				
				if (instr==null) {
					throw new InstrumentDataNotAvailableException(stressTestHistPrice.getPk().getInstrId(), "No instrument found for instrId: "+stressTestHistPrice.getPk().getInstrId());
				} else {
					if (instr.getDivisCode().equalsIgnoreCase("E")/*||(instr.getDivisCode().equalsIgnoreCase("O"))*/) {
					
						// recupero dalla tabella di transcodifica
						InstrIdTrascode[] instrIdTC = instrTrancodeEAO.getSicInstr(instr.getInstrId());
								
						// se vuota blocco altrimenti aggiungo alla lista tutti gli eventuali trascodificati relativi allo strumento di cui l'indice � sottostante
						if (instrIdTC.length == 0) {
							throw new InstrumentDataNotAvailableException(instr.getInstrId(), "No Risk Engine instruments linked to this PAMP instrument id");
						} 
											
						//creo una nuova istanza dell'oggettone con tutto il prezzo stressato e il parametro del classcode e le eventuali transcodifiche su cui esportare il prezzo stressato
						StressTestHistPricesReadyToExp stressedHPReadyToExport = new StressTestHistPricesReadyToExp(stressTestHistPrice, instr, instrIdTC, lastExecutor);
					
						//aggiungo l'oggettone al vettore
						stressTestHistPricesReadyToExpVect.add(stressedHPReadyToExport);
						
						/*parte conteggi*/
						foundToExport++;
						
						/*if (instr.getDivisCode().equalsIgnoreCase("E")) {
							eqFoundToExport++;
						} else {
							bondFoundToExport++;
						}*/
					}
				}
			}
			if (foundToExport>0) {
				
				/*String eqString = "";
				String bndString = "";
				
				if (eqFoundToExport>0) {
					
					eqString = eqFoundToExport +" equity cash";
				}
				
				if (bondFoundToExport>0) {
					
					bndString = " and "+ bondFoundToExport +" equity bond";
				}*/
				
				
				/*("+eqString+bndString+")*/
				
				toBeExported = foundToExport+" equity cash stressed prices ready to be exported";
			}
		}
		
		appIntLog.info(toBeExported);
		
		return stressTestHistPricesReadyToExpVect;
	}
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void exportStressTest(StressTest lastStressTest, String scenario) throws Exception {
		
		String strScenario = "Increasing";
		
		if (scenario.equalsIgnoreCase("D")) {
			
			strScenario = "Decreasing";
			
		}
		
		int stId = lastStressTest.getStId();
		
		String stNote = lastStressTest.getNote();
		
		appIntLog.info("Exporting values related to stress test no. "+stId+" - "+stNote+" ("+strScenario+" scenario)");
		
		
		// prima preparo equity ed esporto
		Vector<StressTestHistPricesReadyToExp> stressTestHistPricesReadyToExpVect = this.getStressTestCashPricesReadyToExp(stId, scenario);
				
		
		if (stressTestHistPricesReadyToExpVect.size()>0) {
		
			oeKbReUnit.stressTestHistPriceExport(stressTestHistPricesReadyToExpVect);
		
		}
			
	}
	
	
	
}
