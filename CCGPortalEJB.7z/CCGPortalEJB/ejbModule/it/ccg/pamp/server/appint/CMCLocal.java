package it.ccg.pamp.server.appint;
import java.math.BigDecimal;

import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.NumberOfErrorForCMCBatch;

import javax.ejb.Local;

@Local
public interface CMCLocal {
	public boolean compareBigDecimals(BigDecimal pampValue, BigDecimal reValue);
	public String checkDataPAMPVsIntracs(NumberOfErrorForCMCBatch numberOfErrorForCMCBatch) throws DataNotValidException;
	public String checkClassMarginDataPAMPVsIntracs(NumberOfErrorForCMCBatch numberOfErrorForCMCBatch) throws DataNotValidException;
	public String checkInterClassOffsetDataPAMPVsIntracs(NumberOfErrorForCMCBatch numberOfErrorForCMCBatch) throws DataNotValidException;
}
