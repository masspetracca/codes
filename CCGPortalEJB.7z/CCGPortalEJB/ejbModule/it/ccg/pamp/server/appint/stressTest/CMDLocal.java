package it.ccg.pamp.server.appint.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface CMDLocal {

	public String clearingMemberDownload(String scenario, StressTest stressTest) throws DataNotValidException, DataNotAvailableException;
	
}
