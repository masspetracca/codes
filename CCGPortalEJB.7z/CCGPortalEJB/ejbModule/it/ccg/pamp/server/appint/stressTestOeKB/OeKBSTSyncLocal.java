package it.ccg.pamp.server.appint.stressTestOeKB;
import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.exceptions.NoPortfolioException;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface OeKBSTSyncLocal {
	
	public void stressTestSync(String scenario, StressTest lastStressTest) throws DataNotValidException,NoPortfolioException;

}
