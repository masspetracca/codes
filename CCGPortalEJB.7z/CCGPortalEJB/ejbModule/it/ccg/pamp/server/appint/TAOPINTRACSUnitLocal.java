package it.ccg.pamp.server.appint;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.exceptions.LargeThresoldMarginException;
import it.ccg.pamp.server.utils.ReadyToExpIntraClassOffsetHistory;

import java.math.BigDecimal;
import java.util.Vector;

import javax.ejb.Local;

@Local
public interface TAOPINTRACSUnitLocal {
	public void exportPampIntraClassOffsetHistoryToIntracs(Vector<ReadyToExpIntraClassOffsetHistory> readyIntraClassOffsetHistVec) throws DataNotValidException, InstrumentDataNotAvailableException, LargeThresoldMarginException;
	public BigDecimal getDelta(BigDecimal oldOffset, BigDecimal propOffset);
}
