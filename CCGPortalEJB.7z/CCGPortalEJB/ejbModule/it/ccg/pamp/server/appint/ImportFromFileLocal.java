package it.ccg.pamp.server.appint;
import java.io.File;
import java.io.IOException;

import it.ccg.pamp.server.exceptions.FileFormatNotSupportedException;
import it.ccg.pamp.server.exceptions.PropertyException;
import it.ccg.pamp.server.exceptions.UserException;

import javax.ejb.Local;

@Local
public interface ImportFromFileLocal {
	
	//public void loadFile(String fileName, int importType, boolean overWrite, String divisCode) throws UserException/*FileFormatNotSupportedException, PropertyException, IOException*/;
	
	public String loadFile(int importType, boolean overWrite) throws Exception;

}
