package it.ccg.pamp.server.appint;


import java.math.BigDecimal;
import java.util.List;
import java.util.Vector;

import it.ccg.pamp.server.eao.ClassIdTrascodeEAOLocal;
import it.ccg.pamp.server.eao.BondClassEAOLocal;
import it.ccg.pamp.server.eao.ClassMarginHistoryEAOLocal;
import it.ccg.pamp.server.entities.ClassMarginHistory;
import it.ccg.pamp.server.entities.ClassIdTrascode;
import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.utils.ClassIdTrascodePlus;
import it.ccg.pamp.server.utils.InstrIdTrascodePlus;
import it.ccg.pamp.server.utils.NumberOfErrorForCMCBatch;
import it.ccg.pamp.server.utils.ReadyToExpClassMarginHistory;


import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BMP
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class BMP implements  BMPLocal {

	@EJB
	private ClassMarginHistoryEAOLocal clMarHisEAO ;
	
	@EJB
	private BondClassEAOLocal bondClassEAO;
	
	@EJB
	private ClassIdTrascodeEAOLocal classTrancodeEAO;

	@EJB
	private CMCLocal cmcEAO;

	
	
	@EJB
	private BMPINTRACSUnitLocal bmpIntracsUnit;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	public BMP() {
	}
	
	@Override
	public void readIntracs() throws DataNotValidException {
				
		cmcEAO.checkClassMarginDataPAMPVsIntracs(new NumberOfErrorForCMCBatch(0));
		
		// ############################################################################
	}
	
	public Vector<ReadyToExpClassMarginHistory> getClassMarginHistoryReadyToExp() throws DataNotValidException, InstrumentDataNotAvailableException {

		Vector<ReadyToExpClassMarginHistory> readyClassMarHistVec = new Vector<ReadyToExpClassMarginHistory>();

		BigDecimal marTh = new BigDecimal(10000);
		
		
		List<ClassMarginHistory> clMarHisToExp = clMarHisEAO.getClassMarHisToExport();

		// ciclo su lista di margini storici da esportare
		for (ClassMarginHistory clMarHis : clMarHisToExp) {

			int classId = clMarHis.getPk().getClassId();
			
			BondClass bondClass = bondClassEAO.findByPrimaryKey(classId);
			
			//verifico che la classe su cui sto andando ad operare effettivamente esista ancora su PMPTCLASS
			if (bondClass==null) {

				throw new InstrumentDataNotAvailableException(classId, "No Clearing bond class linked to this PAMP classId");
			} else {
				// recupero dalla tabella di transcodifica
				/*TODO transcodifica disabilitata ma riabilitabile al volo in caso di necessit� o richiesta */
				/*List<ClassIdTrascode> classIdTC = classTrancodeEAO.getSicClassId(classId);
				
				if (classIdTC.size() == 0) {
					throw new InstrumentDataNotAvailableException(classId, "No INTRACS bond class linked to this PAMP classId");
				}
				
				Vector<ClassIdTrascodePlus> classTcVect= new Vector<ClassIdTrascodePlus>();
			
				for (ClassIdTrascode classTC : classIdTC) {
					
					classTcVect.add(new ClassIdTrascodePlus(classTC));
				}*/
				Vector<ClassIdTrascodePlus> classTcVect= new Vector<ClassIdTrascodePlus>();
				readyClassMarHistVec.add(new ReadyToExpClassMarginHistory(clMarHis, bondClass, classTcVect));
			}
			
		}
		
		String toBeExported = "";
		
		if (clMarHisToExp.size()==0||clMarHisToExp==null) {
			toBeExported = "No bond class historical margins found to export";
		} else {
			toBeExported = clMarHisToExp.size()+" bond class historical margins ready to be exported";
		}
		
		appIntLog.info(toBeExported);
		
		return readyClassMarHistVec;
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void export() throws Exception {
		
		//this.readIntracs();

		Vector<ReadyToExpClassMarginHistory> readyClMargHisToExp = this.getClassMarginHistoryReadyToExp();

		if (readyClMargHisToExp.size()>0) {
			bmpIntracsUnit.exportPampClassMarginHistoryToIntracs(readyClMargHisToExp);
		}
	}
	
	
}
