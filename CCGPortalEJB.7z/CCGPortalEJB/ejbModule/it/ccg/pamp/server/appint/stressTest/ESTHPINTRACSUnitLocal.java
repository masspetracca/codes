package it.ccg.pamp.server.appint.stressTest;
import it.ccg.pamp.server.utils.StressTestDerivativesHistPricesReadyToExp;
import it.ccg.pamp.server.utils.StressTestHistPricesReadyToExp;
import it.ccg.pamp.server.utils.StressTestIndexPricesReadyToExp;

import java.util.Vector;

import javax.ejb.Local;

@Local
public interface ESTHPINTRACSUnitLocal {
	
	public void stressTestHistPriceExport(Vector<StressTestHistPricesReadyToExp> stressTestHisPrToExp) throws Exception;
	
	public void stressTestDerivativesHistPriceExport(Vector<StressTestDerivativesHistPricesReadyToExp> stressTestDerivativesHisPrToExpVect) throws Exception;
	
	public void stressTestIndexPricesExport(Vector<StressTestIndexPricesReadyToExp> stressTestIndexPricesReadyToExp) throws Exception;
	
	public void stressTestBondPricesExport(Vector<StressTestHistPricesReadyToExp> stressTestBondPrToExpVect) throws Exception;
}
