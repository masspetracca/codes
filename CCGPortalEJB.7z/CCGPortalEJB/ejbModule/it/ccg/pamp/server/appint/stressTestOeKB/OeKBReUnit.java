package it.ccg.pamp.server.appint.stressTestOeKB;

import it.ccg.pamp.server.eao.IntracsLogEAOLocal;
import it.ccg.pamp.server.eao.stressTestOeKB.OeKBReClassEAOLocal;
import it.ccg.pamp.server.eao.stressTestOeKB.StressTestRePrcEAOLocal;
import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.IntracsLog;
import it.ccg.pamp.server.entities.stressTestOeKB.OeKBReClass;
import it.ccg.pamp.server.exceptions.InstrumentNotAvailableOnClearingException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.StressTestHistPricesReadyToExp;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ESTHPINTRACSUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class OeKBReUnit implements  OeKBReUnitLocal {

	@EJB
	private OeKBPAMPUnitLocal oekbPamp;

	@EJB
	private OeKBReClassEAOLocal reClassStressedPriceEAO;
	
	@EJB
	private StressTestRePrcEAOLocal stressTestRePrcEAO;
	
	final String prgName = "PAMPSTXP";
	
	@EJB
	private IntracsLogEAOLocal intracsLogEAO;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	
	/**********************************************************************************************************/
	/****************************************PARTE CASH********************************************************/
	/**********************************************************************************************************/
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void stressTestHistPriceExport(Vector<StressTestHistPricesReadyToExp> stressTestHisPrToExpVect) throws Exception {
	
		//lancio procedura di sincronizzazione clone
		stressTestRePrcEAO.cloneClassTable();
		
		Timestamp stDate = null;
		
		int stId  = 0;
		
		String lastExecutor = "";
		
		String scenario = "";
		
		//appIntLog.info("INIZIO CICLO SULL'OGGETTONE");
		
		for (StressTestHistPricesReadyToExp stressTestHisPrToExp : stressTestHisPrToExpVect) {
			
			if (stId==0) {
			
				stDate = stressTestHisPrToExp.getStressTestHP().getPriceDate();
				
				stId  = stressTestHisPrToExp.getStressTestHP().getPk().getStId();
				
				lastExecutor = stressTestHisPrToExp.getLastExecutor();
				
				scenario = stressTestHisPrToExp.getStressTestHP().getPk().getScenario();
			
			}
			
			// classCode PAMP - strumento di partenza
			String classCode = stressTestHisPrToExp.getInstrument().getClassCode();
			
			// prezzo stressato da esportare
			BigDecimal closePrSt = stressTestHisPrToExp.getStressTestHP().getClosePrSt();
			
			// instrId PAMP
			int instrId = stressTestHisPrToExp.getInstrument().getInstrId();
			
			//appIntLog.info("INIZIO CICLO SULLA TRASCODIFICA");
			
			for (InstrIdTrascode transcodedInstr:stressTestHisPrToExp.getInstrIdTC()) {
			
				// classCode Instracs - strumento di arrivo
				String sicCode = transcodedInstr.getPk().getSicInstr();
				
				String sicInstrType = transcodedInstr.getPk().getSicInstrTy();
			
				//cerco sulla tabella dei margini stressati per classcode e type (cptype)
				
				OeKBReClass reClassStressedPrice = reClassStressedPriceEAO.findByPrimaryKey(sicCode, sicInstrType);
			
				// se ci sono record su intracs corrispondenti allo strumento da esportare lo faccio, se ne manca anche solo uno si stoppa la procedura
				if (reClassStressedPrice!=null) {
					
					//prendo il numero di cifre decimali per arrotondare il prezzo dalla colonna COPEDT
					int decDigits = Integer.parseInt(reClassStressedPrice.getCopedt());
					
					//appIntLog.info("arrotondo lo stressato"+closePrSt+" di "+decDigits+" cifre");
					//arrotondo lo stressato
					closePrSt = closePrSt.setScale(decDigits, RoundingMode.HALF_EVEN);
					//appIntLog.info("stressato arrotondato: "+closePrSt);
					
					//appIntLog.info("setto il prezzo: "+closePrSt);
					//setto il prezzo stressato nel campo CUICLP
					reClassStressedPrice.setCuiclp(closePrSt);
					
					String strClosePrSt = closePrSt.toString().replace(".", ",");
					
					strClosePrSt = GenericTools.padding(strClosePrSt, 11,true);
					
					//appIntLog.info("setto anche il prezzo come sottostante sul campo CPRTUC (padding: "+strClosePrSt+")");
					
					//setto anche il prezzo come sottostante sul campo CPRTUC
					reClassStressedPrice.setCprtuc(strClosePrSt);
					
					appIntLog.info("Stressed price exported on Risk Engin for PAMP instrId "+instrId+" (code: "+classCode+") - Clearing system updated instrument code: "+sicCode+" (type: "+sicInstrType+"); price: "+closePrSt);
					
					//appIntLog.info("LOG x paola"); 
					IntracsLog intracsLog = new IntracsLog();
					
					intracsLog.setlFile("CGCLS0SF");
					intracsLog.setlProg(prgName);
					intracsLog.setlStat("U");
					
					
					intracsLog.setlUser(lastExecutor.toUpperCase());
					
					intracsLog.setLogDt1(reClassStressedPrice.logCgcls00f());
					//appIntLog.info("prima della store LOG x paola"); 
					stressTestRePrcEAO.writeLogProcedure(intracsLog);
					//appIntLog.info("prima della store LOG x paola");
					
					
				
				} else {
				
					appIntLog.error("Instrument not available on Risk Engine for PAMP instrId "+instrId+" (code: "+classCode+") - Risk Engine instrument code: "+sicCode+" (product type: "+sicInstrType+")");
					throw new InstrumentNotAvailableOnClearingException(instrId,classCode,"Cash");
				}
			}
			
			
		}
		
		//lancio procedura di esecuzione stress test
		stressTestRePrcEAO.startReStressTestProcedure(stDate,stId,scenario);
		
		appIntLog.info(stressTestHisPrToExpVect.size() + " cash stressed prices exported to Risk Engine");

		oekbPamp.updateStressTestHPSentStatusAfterExport(stressTestHisPrToExpVect);
		
	}

	
}
