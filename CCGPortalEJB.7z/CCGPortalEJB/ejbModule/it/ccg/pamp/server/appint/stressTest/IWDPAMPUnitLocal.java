package it.ccg.pamp.server.appint.stressTest;
import it.ccg.pamp.server.entities.Ipindx1;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface IWDPAMPUnitLocal {

	public void importIntracsIdxWeights(List<Ipindx1> readyIndexWeightToDownload) throws DataNotValidException, DataNotAvailableException;
	
}
