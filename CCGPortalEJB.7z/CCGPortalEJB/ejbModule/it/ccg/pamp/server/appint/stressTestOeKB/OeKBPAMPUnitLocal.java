package it.ccg.pamp.server.appint.stressTestOeKB;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.StressTestHistPricesReadyToExp;

import java.util.Vector;

import javax.ejb.Local;

@Local
public interface OeKBPAMPUnitLocal {

	public void updateStressTestHPSentStatusAfterExport(Vector<StressTestHistPricesReadyToExp> stressTestHisPrToExpVect) throws DataNotValidException;
	
}
