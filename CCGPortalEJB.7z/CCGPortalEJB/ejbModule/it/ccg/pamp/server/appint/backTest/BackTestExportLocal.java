package it.ccg.pamp.server.appint.backTest;
import it.ccg.pamp.server.utils.HistoricalPriceToExport;

import java.sql.Timestamp;
import java.util.Vector;

import javax.ejb.Local;

@Local
public interface BackTestExportLocal {
	
	public Vector<HistoricalPriceToExport> getFilterDate(int maxDays, String division) throws Exception;
	
	public void exportPrice(int maxDays, String division) throws Exception;

}
