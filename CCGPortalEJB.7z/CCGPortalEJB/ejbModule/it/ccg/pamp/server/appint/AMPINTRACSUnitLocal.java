package it.ccg.pamp.server.appint;
import java.math.BigDecimal;
import java.util.Vector;

import it.ccg.pamp.server.entities.MarginHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.exceptions.LargeThresoldMarginException;
import it.ccg.pamp.server.exceptions.PropertyException;
import it.ccg.pamp.server.utils.InstrIdTrascodePlus;
import it.ccg.pamp.server.utils.NotSyncPampIntracs;
import it.ccg.pamp.server.utils.ReadyToExpMarginHistory;

import javax.ejb.Local;

@Local
public interface AMPINTRACSUnitLocal {
	public BigDecimal getDelta(BigDecimal oldMargin, BigDecimal propMargin);
	
	public void writeUnderlayerMinMar(InstrIdTrascodePlus instrTCplus, MarginHistory marHis) throws DataNotValidException, InstrumentDataNotAvailableException, LargeThresoldMarginException;
	
	public void exportPampMarginHistoryToIntracs(Vector<ReadyToExpMarginHistory> readymarghistvec) throws DataNotValidException, InstrumentDataNotAvailableException, LargeThresoldMarginException;
	
	public void exportOeKBPampMarginHistoryToRiskEngine(Vector<ReadyToExpMarginHistory> readymarghistvec) throws DataNotValidException, InstrumentDataNotAvailableException, LargeThresoldMarginException, PropertyException;
	
	public Vector<NotSyncPampIntracs> checkPampMarginHistoryOnIntracs(Vector<ReadyToExpMarginHistory> readymarghistvec) throws DataNotValidException, InstrumentDataNotAvailableException;
}
