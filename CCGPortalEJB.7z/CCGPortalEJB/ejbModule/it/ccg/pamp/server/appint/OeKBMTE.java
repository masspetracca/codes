package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.MarginHistoryEAOLocal;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.PropertyException;
import it.ccg.pamp.server.properties.PropertiesEAOLocal;
import it.ccg.pamp.server.utils.FTPUpload;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.WorkingMarginToExport;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.MathContext;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class OeKBMTE
 */
@Stateless
public class OeKBMTE implements OeKBMTELocal {

	@EJB
	private MarginHistoryEAOLocal marHisEAO;
	
	@EJB
	private PropertiesEAOLocal properties;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	//final String propertyPath = System.getProperty("user.install.root")+"/properties/pamp.properties";
	
	final MathContext mc = new MathContext(5);
	
	public String createTxtFile() throws DataNotValidException, IOException, PropertyException {
		
		List<WorkingMarginToExport> workMarginListSize = marHisEAO.getWorkingMargins();
		
		String strReturn = "";
		
		//Properties prop = new Properties();
		 
		//prop.load(new FileInputStream(propertyPath));
		
		if (workMarginListSize.size()==0) {
			strReturn = "No working margins found to build report";
		} else {
			String record = "records";
			
			if (workMarginListSize.size()==1) {
				record = "record";
			}
			
			String rootDirectory = "";
			
			if (System.getProperty("user.install.root")!=null)
				rootDirectory = System.getProperty("user.install.root");
			
			//System.out.println("default root path: "+rootDirectory);
			
			if (rootDirectory.substring(rootDirectory.length()-4).equalsIgnoreCase("/bin")) {
				rootDirectory = rootDirectory.substring(0,rootDirectory.length()-4);
			}
			
			//System.out.println("new default root path: "+rootDirectory);
			
			appIntLog.info(workMarginListSize.size()+" "+record+" found");
			
			String curDate = Long.toString(GenericTools.systemDateLongFormat());
			
			rootDirectory += properties.getPropertyMap().get("spoolFileDir");
			
			String fileName = "MARGINRATES"+curDate+".txt";
			
			String fileLocation = rootDirectory+fileName;
			
			appIntLog.info("local report path: "+rootDirectory);
			
			// creates the file
			File file = new File(fileLocation);
						
		    file.createNewFile(); 

		    // creates a FileWriter Object
		    FileWriter writer = new FileWriter(file); 
		    
		    // Writes the content to the file
		    /*String txtHead = "ISINCODE;WORKING MARGIN";
			writer.write(txtHead+"\n");*/
			
			int counter = 0;
			
			//23072012
			// set the first row to currentDate 
			String txtLine = curDate+"\n";
			writer.write(txtLine);
			
			for (WorkingMarginToExport workMar:workMarginListSize) {
				counter++;
				txtLine = workMar.getIsinCode()+";"+GenericTools.formatNumber(workMar.getMargin(),5);
				if (counter<workMarginListSize.size()) {
					txtLine+="\n";
				}
				writer.write(txtLine);
			}
			
			
			//23072012
			// set the last row to the total record count 
			writer.write("\n"+workMarginListSize.size());
			
			writer.flush();
			writer.close();
			
			appIntLog.info(fileName+" created on local enviroment and ready to be uploaded via FTP");
			
			boolean exportOk = true;
			
			//Upload FTP
			try {
				appIntLog.info("Starting FTP upload");
				FTPUpload.upload(file, fileName, properties.getPropertyMap());
				//FTPUpload ftp = new FTPUpload(file, fileName);
				appIntLog.info("FTP upload completed");
			} catch (Exception e) {
				appIntLog.error("Error occurred during the FTP upload: "+e.getMessage());
				e.printStackTrace();
				exportOk = false;
			}
			
			//Upload SFTP
			
			/*
			try {
				SFTPUpload sftp = new SFTPUpload();
				sftp.uploadFile(new FileInputStream(file), fileName);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			*/
			if (exportOk) {
				strReturn = "New file named "+fileName+" has been created on PAMP System and uploaded via FTP";
			} else {
				strReturn = "New file named "+fileName+" has been created on PAMP System but an error occurred during the FTP upload";
			}
		}
		return strReturn;
	}
	

}
