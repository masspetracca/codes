package it.ccg.pamp.server.appint.stressTest;
import java.util.List;

import it.ccg.pamp.server.entities.Ipindx1;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface IWDLocal {
	//public String synchronizeAllIdxWeight() throws DataNotValidException, DataNotAvailableException;
	public void indexDownload() throws Exception;
	public List<Ipindx1> getIdxWeiReadyToDownload() throws DataNotValidException, DataNotAvailableException;
}
