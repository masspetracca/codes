package it.ccg.pamp.server.appint.stressTest;

import it.ccg.pamp.server.eao.Cpsrss1EAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestCgcls00fEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestCgpri00fEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestCgvolai00fEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestMtspriceEAOLocal;
import it.ccg.pamp.server.entities.Cpsrss1;
import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.stressTest.StressTestCgcls00f;
import it.ccg.pamp.server.entities.stressTest.StressTestCgpri00f;
import it.ccg.pamp.server.entities.stressTest.StressTestCgpri00fPK;
import it.ccg.pamp.server.entities.stressTest.StressTestCgvolai00f;
import it.ccg.pamp.server.entities.stressTest.StressTestCgvolai00fPK;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;
import it.ccg.pamp.server.entities.stressTest.StressTestMtsprice;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentNotAvailableOnClearingException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.OptionShift;
import it.ccg.pamp.server.utils.StressTestDerivativesHistPricesReadyToExp;
import it.ccg.pamp.server.utils.StressTestHistPricesReadyToExp;
import it.ccg.pamp.server.utils.StressTestIndexDerivTranscode;
import it.ccg.pamp.server.utils.StressTestIndexPricesReadyToExp;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ESTHPINTRACSUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class ESTHPINTRACSUnit implements  ESTHPINTRACSUnitLocal {

	@EJB
	private ESTHPPAMPUnitLocal esthPamp;

	@EJB
	private Cpsrss1EAOLocal cpsrss1EAO;

	@EJB
	private StressTestCgpri00fEAOLocal stressTestCgpri00f;
	
	@EJB
	private StressTestCgcls00fEAOLocal stressTestCgcls00fEAO;
	
	@EJB
	private StressTestMtspriceEAOLocal stressTestMtsPriceEAO;
	
	@EJB
	private StressTestCgvolai00fEAOLocal stressTestCgvolai00f;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	
	/**********************************************************************************************************/
	/****************************************PARTE CASH********************************************************/
	/**********************************************************************************************************/
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void stressTestHistPriceExport(Vector<StressTestHistPricesReadyToExp> stressTestHisPrToExpVect) throws Exception {
	
		for (StressTestHistPricesReadyToExp stressTestHisPrToExp : stressTestHisPrToExpVect) {
			
			// classCode PAMP - strumento di partenza
			String classCode = stressTestHisPrToExp.getInstrument().getClassCode();
			
			// prezzo stressato da esportare
			BigDecimal closePrSt = stressTestHisPrToExp.getStressTestHP().getClosePrSt();
			
			// instrId PAMP
			int instrId = stressTestHisPrToExp.getInstrument().getInstrId();
			
			
			for (InstrIdTrascode transcodedInstr:stressTestHisPrToExp.getInstrIdTC()) {
			
				// classCode Instracs - strumento di arrivo
				String sicCode = transcodedInstr.getPk().getSicInstr();
				
				String sicInstrType = transcodedInstr.getPk().getSicInstrTy();
			
				//cerco sulla tabella dei margini stressati per data e isinCode
				StressTestCgcls00f intracsEquityStressedPrice = stressTestCgcls00fEAO.findByPrimaryKey(sicCode, sicInstrType);
			
				// se ci sono record su intracs corrispondenti allo strumento da esportare lo faccio, se ne manca anche solo uno si stoppa la procedura
				if (intracsEquityStressedPrice!=null) {
					//prendo il numero di cifre decimali per arrotondare il prezzo dalla colonna COPEDT
					int decDigits = Integer.parseInt(intracsEquityStressedPrice.getCopedt());
					//arrotondo lo stressato
					closePrSt = closePrSt.setScale(decDigits, RoundingMode.HALF_EVEN);
					
					//setto il prezzo stressato nel campo CUICLP
					intracsEquityStressedPrice.setCuiclp(closePrSt);
					
					String strClosePrSt = closePrSt.toString().replace(".", ",");
					
					strClosePrSt = GenericTools.padding(strClosePrSt, 11,true);
					
					//setto anche il prezzo come sottostante sul campo CPRTUC
					intracsEquityStressedPrice.setCprtuc(strClosePrSt);
					appIntLog.info("Stressed price exported on Clearing system for PAMP instrId "+instrId+" (code: "+classCode+") - Clearing system updated instrument code: "+sicCode+" (type: "+sicInstrType+"); price: "+closePrSt);
				} else {
					appIntLog.error("Price not available on Clearing system for PAMP instrId "+instrId+" (code: "+classCode+") - Clearing system instrument code: "+sicCode+"; type: "+sicInstrType+") ");
					throw new InstrumentNotAvailableOnClearingException(instrId,classCode,"Cash");
				}
			}	
		}
		
		appIntLog.info(stressTestHisPrToExpVect.size() + " cash stressed prices exported to Clearing system");

		esthPamp.updateStressTestHPSentStatusAfterExport(stressTestHisPrToExpVect);
		
	}
	
	
	/**********************************************************************************************************/
	/****************************************PARTE BOND********************************************************/
	/**********************************************************************************************************/
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void stressTestBondPricesExport(Vector<StressTestHistPricesReadyToExp> stressTestBondPrToExpVect) throws Exception {
	
		for (StressTestHistPricesReadyToExp stressTestBondPrToExp : stressTestBondPrToExpVect) {
			
			// classCode PAMP - strumento di partenza
			String classCode = stressTestBondPrToExp.getInstrument().getClassCode();
			
			// prezzo srressato da esportare
			BigDecimal closePrSt = stressTestBondPrToExp.getStressTestHP().getClosePrSt();
			
			// instrId PAMP
			int instrId = stressTestBondPrToExp.getInstrument().getInstrId();
			
			String isinCode = stressTestBondPrToExp.getInstrument().getIsinCode();
			
			String sicCode = classCode;
			
			String sicInstrType = stressTestBondPrToExp.getInstrument().getInstrType();
			
			/*
			for (InstrIdTrascode transcodedInstr:stressTestBondPrToExp.getInstrIdTC()) {
			
				
				// classCode Instracs - strumento di arrivo
				String sicCode = transcodedInstr.getPk().getSicInstr();
				
				String sicInstrType = transcodedInstr.getPk().getSicInstrTy();
			*/
				//cerco sulla tabella dei prezzi stressati dei bond isinCode
				StressTestMtsprice intracsBondStressedPrice = stressTestMtsPriceEAO.findByPrimaryKey(isinCode);
			
				// se ci sono record su intracs corrispondenti allo strumento da esportare lo faccio, se ne manca anche solo uno si stoppa la procedura
				if (intracsBondStressedPrice!=null) {
					intracsBondStressedPrice.setPPrice(closePrSt);
					appIntLog.info("Bond stressed price exported on Clearing system for PAMP instrId "+instrId+" (code: "+classCode+") - Clearing system updated instrument code: "+sicCode+" (type: "+sicInstrType+"); price: "+closePrSt);
				} else {
					appIntLog.error("Bond price not available on Clearing system for PAMP instrId "+instrId+" (code: "+classCode+") - Clearing system instrument code: "+sicCode+"; type: "+sicInstrType+") ");
					throw new InstrumentNotAvailableOnClearingException(instrId,classCode,"Cash");
				}
			//}	
		}
		
		appIntLog.info(stressTestBondPrToExpVect.size() + " bond stressed prices exported to Clearing system");

		esthPamp.updateStressTestHPSentStatusAfterExport(stressTestBondPrToExpVect);
		
	}
	
	
	/**********************************************************************************************************/
	/************************************PARTE INDICI SOTTOSTANTI**********************************************/
	/**********************************************************************************************************/
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void stressTestIndexPricesExport(Vector<StressTestIndexPricesReadyToExp> stressTestIndexPricesReadyToExpVec) throws Exception {
	
		
		//ciclo sulla struttura dati
		for (StressTestIndexPricesReadyToExp stressTestIdxHisPrToExp : stressTestIndexPricesReadyToExpVec) {
			
			//info sull'indice
			int indexInstrId = stressTestIdxHisPrToExp.getIndexInstrument().getInstrId();
			String indexClassCode = stressTestIdxHisPrToExp.getIndexInstrument().getClassCode();
			
			// prezzo srressato da esportare
			BigDecimal indexClosePrSt = stressTestIdxHisPrToExp.getStressTestHP().getClosePrSt();
			
			//lista dei derivati di cui l'indice � sottostante
			Vector<StressTestIndexDerivTranscode> stressTestDerivativesHisPrToExpList = stressTestIdxHisPrToExp.getIdxDerTranscode();
			
			for (StressTestIndexDerivTranscode derInstrTrsCod: stressTestDerivativesHisPrToExpList) {
			
				//info sul derivato
				
				// instrId pamp - strumento derivato di partenza
				int derInstrId = derInstrTrsCod.getDerInstrument().getInstrId();
				
				// classCode PAMP - strumento derivato di partenza
				String derClassCode = derInstrTrsCod.getDerInstrument().getClassCode();
				
				//InstrIdTrascode transcodedDerInstr = new InstrIdTrascode();
				
				String instrTypeForException = "";
				
				for (InstrIdTrascode transcodedDerInstr : derInstrTrsCod.getInstrIdTC()) {
				
					// classCode Instracs - strumento di arrivo
					String sicCode = transcodedDerInstr.getPk().getSicInstr();
					
					// instrType Instracs - strumento di arrivo					
					String sicInstrType = transcodedDerInstr.getPk().getSicInstrTy();
				
					if (sicInstrType.equalsIgnoreCase("F")) {
						instrTypeForException = "Future";
					} else {
						instrTypeForException = "Option";
					}
					
					// cerco sulla tabella dei margini la riga di ogni trascodifica del derivato
					StressTestCgcls00f intracsDerivativeUnderlyingStressedPrice = stressTestCgcls00fEAO.findByPrimaryKey(sicCode, sicInstrType);
										
					// se ci sono record su intracs corrispondenti allo strumento da esportare lo faccio, se ne manca anche solo uno si stoppa la procedura
					if (intracsDerivativeUnderlyingStressedPrice!=null) {
						int decDigits = Integer.parseInt(intracsDerivativeUnderlyingStressedPrice.getCopedt());
						//arrotondo lo stressato
						indexClosePrSt = indexClosePrSt.setScale(decDigits, RoundingMode.HALF_EVEN);
						
						//setto il prezzo stressato nel campo CUICLP
						intracsDerivativeUnderlyingStressedPrice.setCuiclp(indexClosePrSt);
						
						String strIdxClosePrSt = indexClosePrSt.toString().replace(".", ",");
						
						strIdxClosePrSt = GenericTools.padding(strIdxClosePrSt, 11,true);
						
						//setto anche il prezzo come sottostante sul campo CPRTUC
						intracsDerivativeUnderlyingStressedPrice.setCprtuc(strIdxClosePrSt);
						
						appIntLog.info("Index stressed value exported on Clearing system for instrId "+derInstrId+" (code: "+derClassCode+") - Clearing system updated instrument code: "+sicCode+"; type: "+sicInstrType+"; value: "+indexClosePrSt);
					} else {
						appIntLog.error("Index value not available on Clearing system for PAMP instrId "+derInstrId+" (code: "+derClassCode+") - Clearing system instrument code: "+sicCode+"; type: "+sicInstrType+") ");
						throw new InstrumentNotAvailableOnClearingException(derInstrId,derClassCode,instrTypeForException);
					}
				}
				
			}
		}
		
		appIntLog.info(stressTestIndexPricesReadyToExpVec.size() + " index stressed prices exported to Clearing system");

		esthPamp.updateStressTestIndexSentStatusAfterExport(stressTestIndexPricesReadyToExpVec);
		
	}
	
	
	/**********************************************************************************************************/
	/****************************************PARTE DERIVATIVES*************************************************/
	/**********************************************************************************************************/
	
	/*@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void stressTestDerivativesHistPriceExport(Vector<StressTestDerivativesHistPricesReadyToExp> stressTestDerivativesHisPrToExpVect) throws Exception {
	
		int countFuture = 0;
		
		int countOption = 0;
		
		for (StressTestDerivativesHistPricesReadyToExp stressTestDerHisPrToExp : stressTestDerivativesHisPrToExpVect) {
			
			//pricedate del prezzo da modificare in formato Date
			Date priceDate = Date.valueOf(stressTestDerHisPrToExp.getStressTestDerHP().getPriceDate().toString().substring(0,10));
			
			// instrId PAMP - strumento di partenza
			int instrId = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getInstrId();
			
			// classCode PAMP - strumento di partenza
			String classCode = stressTestDerHisPrToExp.getInstr().getClassCode();
			
			//instrId PAMP - strumento di partenza
			String isinCode = stressTestDerHisPrToExp.getInstr().getIsinCode();
			
			//pc
			String pc = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getPc();
			
			
			boolean isOption = false;
			
			if ((pc.equalsIgnoreCase("C") || pc.equalsIgnoreCase("P"))) {
				isOption = true;
			}
			
			//expiry
			
			int expiry = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getExpiry();
			
			BigDecimal strike = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getStrike();
			
			long longDate = (long) Integer.parseInt(priceDate.toString().replaceAll("-", ""));
			
			String optionLog = "pc: "+pc+"; strike: "+strike+" expiry: "+expiry;
			
			// scorro la transcodifica
			for (InstrIdTrascode transcodedInstr:stressTestDerHisPrToExp.getInstrIdTC()) {
			
				String sicInstrTy = transcodedInstr.getPk().getSicInstrTy();
				
				// se il pc � F vuol dire che lo strumento � un future (instrtype = 'F' o 'FO') 
				if (!isOption && sicInstrTy.equalsIgnoreCase("F")) {

					//-------leggo su CPSRSS1 
					Cpsrss1 cps = cpsrss1EAO.findByPrimaryKey(transcodedInstr.getPk().getSicInstr(), expiry, new BigDecimal(0), "", longDate);
					
					String clearingIsinCode = cps.getHCusip();
					
					//prezzo stressato
					BigDecimal closePrSt = stressTestDerHisPrToExp.getStressTestDerHP().getClosePrSt();
					
					// ripeter� l'operazione per ogni isin transcodificato
					StressTestCgpri00f intracsFutureStressedPrice = stressTestCgpri00f.findByPrimaryKey(priceDate, clearingIsinCode);
					
					// se ci sono record su intracs corrispondenti allo strumento da esportare lo faccio
					if (intracsFutureStressedPrice!=null) {
											
						intracsFutureStressedPrice.setPrPric(closePrSt);
						appIntLog.info("Future stressed price exported for instrId:"+instrId+" (code: "+transcodedInstr.getPk().getSicInstr()+", type:"+sicInstrTy+") - date: "+priceDate+"; expiry: "+expiry);
						
						countFuture++;
						
					} else {
						appIntLog.error("Future instrument not available on Clearing system for instrId:"+instrId+" (code: "+transcodedInstr.getPk().getSicInstr()+") - date: "+priceDate);
						throw new InstrumentNotAvailableOnClearingException(instrId,classCode,"Future");
					}
				
					
					
				} else if (isOption && sicInstrTy.equalsIgnoreCase("O")) { // il pc � P (put) o C (call) quindi � un'opzione
					
					//volatilit�
					BigDecimal impVolaSt = stressTestDerHisPrToExp.getStressTestDerHP().getImpVola();
					
					//-------leggo su CPSRSS1 
					Cpsrss1 cps = cpsrss1EAO.findByPrimaryKey(transcodedInstr.getPk().getSicInstr(), expiry, strike, pc, longDate);
					
					String clearingIsinCode = cps.getHCusip();
					// ripeter� l'operazione per ogni isin transcodificato
					StressTestCgvolai00f intracsOptionStressedVola = stressTestCgvolai00f.findByPrimaryKey(priceDate, clearingIsinCode);
									
					if (intracsOptionStressedVola!=null) {
						
										
						//setto la nuova volatilit� stressata per l'option
						intracsOptionStressedVola.setSrVola(impVolaSt);
						appIntLog.info("Option stressed volatility exported for instrId: "+instrId+" (code: "+transcodedInstr.getPk().getSicInstr()+") - date: "+priceDate+" "+optionLog);
						
						countOption++;
						
					} else {
						appIntLog.error("Option instrument not available on Clearing system for instrId: "+instrId+" (code: "+classCode+") - date: "+priceDate+" "+optionLog);
						throw new InstrumentNotAvailableOnClearingException(instrId,classCode,"Option");
					} 
					
				}
			}	
		}
		
		appIntLog.info(countFuture + " derivative stressed prices and "+countOption+" volality exported to Clearing system");

		esthPamp.updateStressTestDerHPSentStatusAfterExport(stressTestDerivativesHisPrToExpVect);
		
	}*/
	
	
	/*@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void stressTestDerivativesHistPriceExport(Vector<StressTestDerivativesHistPricesReadyToExp> stressTestDerivativesHisPrToExpVect) throws Exception {
	
		int countFuture = 0;
		
		int countOption = 0;
		
		int lastInstrId = 0;
		
		
		// pezzo per l'export sulla tabella delle classi dei prezzi dei sottostanti per futures e option
		for (StressTestDerivativesHistPricesReadyToExp stressTestDerHisPrToExp : stressTestDerivativesHisPrToExpVect) {
			
			StressTestHistPrice undStressedPrice = stressTestDerHisPrToExp.getUndCashStressTestHP();
			
			if (undStressedPrice!=null) {
				BigDecimal cashPriceSt = undStressedPrice.getClosePrSt();
			
				if (lastInstrId!=stressTestDerHisPrToExp.getInstr().getInstrId()) {
					
					lastInstrId = stressTestDerHisPrToExp.getInstr().getInstrId();
					
					
					// scorro la transcodifica per applicare il prezzo del sottostante sulla tabella delle classi
					for (InstrIdTrascode transcodedInstr:stressTestDerHisPrToExp.getInstrIdTC()) {
					
						String sicInstrType = transcodedInstr.getPk().getSicInstrTy();
						
						String sicCode = transcodedInstr.getPk().getSicInstr();
						
						StressTestCgcls00f intracsEquityStressedPrice = stressTestCgcls00fEAO.findByPrimaryKey(sicCode, sicInstrType);
						
						if (intracsEquityStressedPrice!=null) {
						
							//prendo il numero di cifre decimali per arrotondare il prezzo dalla colonna COPEDT
							int decDigits = Integer.parseInt(intracsEquityStressedPrice.getCopedt());
							//arrotondo lo stressato
							cashPriceSt = cashPriceSt.setScale(decDigits, RoundingMode.HALF_EVEN);
							
							//setto il prezzo stressato nel campo CUICLP
							intracsEquityStressedPrice.setCuiclp(cashPriceSt);
							
							String strClosePrSt = cashPriceSt.toString().replace(".", ",");
							
							strClosePrSt = GenericTools.padding(strClosePrSt, 11,true);
							
							//setto anche il prezzo come sottostante sul campo CPRTUC
							intracsEquityStressedPrice.setCprtuc(strClosePrSt);
							
							appIntLog.info("underlying stressed price for instrId "+lastInstrId+" (code: "+sicCode+"; type: "+sicInstrType+") exported - new underlying price: "+cashPriceSt);
						
						} else {
							appIntLog.warn("No class found on Clearing system for instrId "+lastInstrId+" (code: "+sicCode+"; type: "+sicInstrType+")");
						}
					}
				}	
			}
		}
		
		
		int removedFutures = stressTestCgpri00f.removeAll();
		int removedOption = stressTestCgvolai00f.removeAll();
		appIntLog.error(removedFutures+" future stressed prices removed on Clearing system");
		appIntLog.error(removedOption+" option stressed volatilities removed on Clearing system");
		
		String lastPc = "";
		
		for (StressTestDerivativesHistPricesReadyToExp stressTestDerHisPrToExp : stressTestDerivativesHisPrToExpVect) {
			
			StressTestHistPrice undStressedPrice = stressTestDerHisPrToExp.getUndCashStressTestHP();
			
			//pricedate del prezzo da modificare in formato Date
			Timestamp tmStpDate = stressTestDerHisPrToExp.getStressTestDerHP().getPriceDate();
			Date priceDate = Date.valueOf(tmStpDate.toString().substring(0,10));
			
			Instrument instr = stressTestDerHisPrToExp.getInstr();
			
			// instrId PAMP - strumento di partenza
			int instrId = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getInstrId();
			
			String scenario = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getScenario();
			
			// classCode PAMP - strumento di partenza
			String classCode = stressTestDerHisPrToExp.getInstr().getClassCode();
			
			//pc
			String pc = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getPc();
			
			
			//prezzo originale
			BigDecimal closePr = null;
			
			//prezzo stressato
			BigDecimal closePrSt = null;
			
			//delta
			BigDecimal deltaPrice = null;
			
			
			boolean isOption = false;
			
			if ((pc.equalsIgnoreCase("C") || pc.equalsIgnoreCase("P"))) {
				isOption = true;
				
				//prezzo cash
				closePr = undStressedPrice.getClosePr();
				
				//prezzo stressato cash
				closePrSt = undStressedPrice.getClosePrSt();
				
			} else {
				//prezzo originale future
				closePr = stressTestDerHisPrToExp.getStressTestDerHP().getClosePr();
				
				//prezzo stressato future
				closePrSt = stressTestDerHisPrToExp.getStressTestDerHP().getClosePrSt();
						
			}
			
			
			
			if (!lastPc.equalsIgnoreCase(pc)) {
				String futOrOption = "###### Starting the ";
				if (!isOption) {
					futOrOption += "future stressed prices ";
				} else {
					futOrOption += "option stressed volatilities ";
				}
				futOrOption += "export ###### ";
				appIntLog.info(futOrOption);
				
				lastPc = pc;
			}
			
			//delta
			deltaPrice = closePrSt.subtract(closePr);
			
			// scorro la transcodifica
			for (InstrIdTrascode transcodedInstr:stressTestDerHisPrToExp.getInstrIdTC()) {
			
				String sicInstrTy = transcodedInstr.getPk().getSicInstrTy();
				
				String sicCode = transcodedInstr.getPk().getSicInstr();
								
								
				// se il pc � F vuol dire che lo strumento � un future (instrtype = 'F' o 'FO') 
				if (!isOption && sicInstrTy.equalsIgnoreCase("F")) {
					
					BigDecimal variation = deltaPrice.divide(closePr,8, RoundingMode.HALF_EVEN);
					
					countFuture++;
					
					this.setFuture(instr,sicCode,sicInstrTy,tmStpDate,deltaPrice,scenario,variation);
					
				} else if (isOption && sicInstrTy.equalsIgnoreCase("O")) { // il pc � P (put) o C (call) quindi � un'opzione
					
					countOption++;
					
					BigDecimal volaCoeff = stressTestDerHisPrToExp.getVolaCoeff();
					
					//*********************************Da inserire dentro il For delle  classi rettificate per le option*************************************
					
					appIntLog.info("SicCode = "+sicCode);
					
					List<Cpsrss1> cpsrssList = cpsrss1EAO.findOptionsBySymblAndDate(sicCode, tmStpDate);

					if (cpsrssList == null || cpsrssList.size() == 0)
						throw new InstrumentDataNotAvailableException(instrId, "No options available for classcode: " + sicCode + " and histupdday: " + tmStpDate + " on the clearing system");

					String lasputcall = "";
					long lastexpiry = 0;
					boolean firsttime = true;

					Vector<Cpsrss1> parziale = new Vector<Cpsrss1>();

					
					for (Cpsrss1 cps : cpsrssList) {

						if (firsttime) {
							parziale.add(cps);
							lasputcall = cps.getPk().getHPc();
							lastexpiry = cps.getPk().getHExpir();
							firsttime = false;
						} else {
							// siamo sempre nella stessa scadenza e stesso putcall
							// quindi continuo ad inserire nel parziale le scadenze
							if (lasputcall.equalsIgnoreCase(cps.getPk().getHPc()) && lastexpiry == cps.getPk().getHExpir()) {
								parziale.add(cps);
							}
							// vuol dire che c'� un salto quindi provvedo a fare i
							// calcoli sul parziale e quindi a svuotarlo e a mettere
							// la cps corrente
							else {

								// tramite questo metodo ricavo di quanto vanno shiftate le volatility
								
								OptionShift optshift = this.getIndiciSPStressatiENormali(parziale, closePrSt, closePr, scenario);

								for (int i = 0; i < parziale.size(); i++) {

									StressTestCgvolai00f intracsOptionStressedVola = new StressTestCgvolai00f();
									StressTestCgvolai00fPK intracsOptionStressedVolaPK = new StressTestCgvolai00fPK();
									
									int index = Math.min(Math.max(i + optshift.getShiftIndex(), 0), parziale.size() - 1);

									intracsOptionStressedVolaPK.setSrDate(priceDate);
									intracsOptionStressedVolaPK.setSrIsin(parziale.get(i).getHCusip());
									
									BigDecimal impVolaSt = parziale.get(index).getHImpvl().multiply(volaCoeff);
									
									intracsOptionStressedVola.setPk(intracsOptionStressedVolaPK);
									intracsOptionStressedVola.setSrVola(impVolaSt);
									
									stressTestCgvolai00f.store(intracsOptionStressedVola);
									appIntLog.info("Stressed volatility exported on Clearing system for PAMP instrId "+instrId+" (code: "+classCode+") - Clearing system updated instrument code: "+sicCode+" (type: "+sicInstrTy+"); expiry: "+parziale.get(i).getPk().getHExpir()+"; put/call: "+parziale.get(i).getPk().getHPc()+"; strike: "+parziale.get(i).getPk().getHStrik()+"; isinCode: "+parziale.get(i).getHCusip()+"; stressed volatility: "+impVolaSt);
									
								}

								parziale.clear();
								parziale.add(cps);
								lasputcall = cps.getPk().getHPc();
								lastexpiry = cps.getPk().getHExpir();
							}

						}

					}

					if (!parziale.isEmpty()) {
						// tramite questo metodo ricavo di quanto vanno
						// shiftate le volatility
						OptionShift optshift = this.getIndiciSPStressatiENormali(parziale, closePrSt, closePr, scenario);

						for (int i = 0; i < parziale.size(); i++) {

							StressTestCgvolai00f intracsOptionStressedVola = new StressTestCgvolai00f();//stressTestCgvolai00f.findByPrimaryKey(priceDate, clearingIsinCode);
							StressTestCgvolai00fPK intracsOptionStressedVolaPK = new StressTestCgvolai00fPK();
							
							int index = Math.min(Math.max(i + optshift.getShiftIndex(), 0), parziale.size() - 1);

							intracsOptionStressedVolaPK.setSrDate(priceDate);
							intracsOptionStressedVolaPK.setSrIsin(parziale.get(i).getHCusip());
							
							BigDecimal impVolaSt = parziale.get(index).getHImpvl().multiply(volaCoeff);
							
							intracsOptionStressedVola.setPk(intracsOptionStressedVolaPK);
							intracsOptionStressedVola.setSrVola(impVolaSt);
							
							stressTestCgvolai00f.store(intracsOptionStressedVola);
							appIntLog.info("Stressed volatility exported on Clearing system for PAMP instrId "+instrId+" (code: "+classCode+") - Clearing system updated instrument code: "+sicCode+" (type: "+sicInstrTy+"); expiry: "+parziale.get(i).getPk().getHExpir()+"; put/call: "+parziale.get(i).getPk().getHPc()+"; strike: "+parziale.get(i).getPk().getHStrik()+"; isinCode: "+parziale.get(i).getHCusip()+"; stressed volatility: "+impVolaSt);

						}

						parziale.clear();
					}

					// ******************************************************************************************************************************
					
				}			
			}
		}
		
		appIntLog.info(countFuture + " derivative stressed prices and "+countOption+" volality exported to Clearing system");

		esthPamp.updateStressTestDerHPSentStatusAfterExport(stressTestDerivativesHisPrToExpVect);
	}*/
	
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void stressTestDerivativesHistPriceExport(Vector<StressTestDerivativesHistPricesReadyToExp> stressTestDerivativesHisPrToExpVect) throws Exception {
	
		int countFuture = 0;
		
		int countOption = 0;
		
		int countRectFuture = 0;
		
		int countRectOption = 0;
		
		int lastInstrId = 0;
		
		String lastPC = "";
		
				
		// pezzo per l'export sulla tabella delle classi dei prezzi dei sottostanti per futures e option
		for (StressTestDerivativesHistPricesReadyToExp stressTestDerHisPrToExp : stressTestDerivativesHisPrToExpVect) {
			
			StressTestHistPrice undStressedPrice = stressTestDerHisPrToExp.getUndCashStressTestHP();
			
			if (undStressedPrice!=null) {
				BigDecimal cashPriceSt = undStressedPrice.getClosePrSt();
			
				if (lastInstrId!=stressTestDerHisPrToExp.getInstr().getInstrId()) {
					
					lastInstrId = stressTestDerHisPrToExp.getInstr().getInstrId();
					
					// scorro la transcodifica per applicare il prezzo del sottostante sulla tabella delle classi
					for (InstrIdTrascode transcodedInstr:stressTestDerHisPrToExp.getInstrIdTC()) {
					
						String sicInstrType = transcodedInstr.getPk().getSicInstrTy();
						
						String sicCode = transcodedInstr.getPk().getSicInstr();
						
						String stExport = transcodedInstr.getStExport();
						
						StressTestCgcls00f intracsEquityStressedPrice = stressTestCgcls00fEAO.findByPrimaryKey(sicCode, sicInstrType);
						
						if ((stExport.equalsIgnoreCase("A") || stExport.equalsIgnoreCase("C")) && intracsEquityStressedPrice!=null) {
						//if (intracsEquityStressedPrice!=null) {
							//prendo il numero di cifre decimali per arrotondare il prezzo dalla colonna COPEDT
							int decDigits = Integer.parseInt(intracsEquityStressedPrice.getCopedt());
							//arrotondo lo stressato
							cashPriceSt = cashPriceSt.setScale(decDigits, RoundingMode.HALF_EVEN);
							
							//setto il prezzo stressato nel campo CUICLP
							intracsEquityStressedPrice.setCuiclp(cashPriceSt);
							
							String strClosePrSt = cashPriceSt.toString().replace(".", ",");
							
							strClosePrSt = GenericTools.padding(strClosePrSt, 11,true);
							
							//setto anche il prezzo come sottostante sul campo CPRTUC
							intracsEquityStressedPrice.setCprtuc(strClosePrSt);
							
							appIntLog.info("underlying stressed price for instrId "+lastInstrId+" (code: "+sicCode+"; type: "+sicInstrType+") exported - new underlying price: "+cashPriceSt);
						
						} else {
							appIntLog.warn("No class found on Clearing system for instrId "+lastInstrId+" (code: "+sicCode+"; type: "+sicInstrType+")");
						}
					}
					
					// scorro la transcodifica per applicare il prezzo del sottostante sulla tabella delle classi
					for (InstrIdTrascode rectifiedClass:stressTestDerHisPrToExp.getRectifiedClassArray()) {
					
						String sicInstrType = rectifiedClass.getPk().getSicInstrTy();
						
						String sicCode = rectifiedClass.getPk().getSicInstr();
						
						String stExport = rectifiedClass.getStExport();
						
						StressTestCgcls00f intracsEquityStressedPrice = stressTestCgcls00fEAO.findByPrimaryKey(sicCode, sicInstrType);
						
						if ((stExport.equalsIgnoreCase("A") || stExport.equalsIgnoreCase("C")) && intracsEquityStressedPrice!=null) {
						//if (intracsEquityStressedPrice!=null) {
						
							//prendo il numero di cifre decimali per arrotondare il prezzo dalla colonna COPEDT
							int decDigits = Integer.parseInt(intracsEquityStressedPrice.getCopedt());
							//arrotondo lo stressato
							cashPriceSt = cashPriceSt.setScale(decDigits, RoundingMode.HALF_EVEN);
							
							//setto il prezzo stressato nel campo CUICLP
							intracsEquityStressedPrice.setCuiclp(cashPriceSt);
							
							String strClosePrSt = cashPriceSt.toString().replace(".", ",");
							
							strClosePrSt = GenericTools.padding(strClosePrSt, 11,true);
							
							//setto anche il prezzo come sottostante sul campo CPRTUC
							intracsEquityStressedPrice.setCprtuc(strClosePrSt);
							
							appIntLog.info("underlying stressed price for instrId "+lastInstrId+" (code: "+sicCode+"; type: "+sicInstrType+") exported - new underlying price: "+cashPriceSt);
						
						} else {
							appIntLog.warn("No class found on Clearing system for instrId "+lastInstrId+" (code: "+sicCode+"; type: "+sicInstrType+")");
						}
					}
				}	
			}
		}
		
		
		int removedFutures = stressTestCgpri00f.removeAll();
		int removedOption = stressTestCgvolai00f.removeAll();
		appIntLog.info(removedFutures+" future stressed prices removed on Clearing system");
		appIntLog.info(removedOption+" option stressed volatilities removed on Clearing system");
		
		lastInstrId = 0;
		
		for (StressTestDerivativesHistPricesReadyToExp stressTestDerHisPrToExp : stressTestDerivativesHisPrToExpVect) {
			
			StressTestHistPrice undStressedPrice = stressTestDerHisPrToExp.getUndCashStressTestHP();
			
			//pricedate del prezzo da modificare in formato Date
			Timestamp tmStpDate = stressTestDerHisPrToExp.getStressTestDerHP().getPriceDate();
			Date priceDate = Date.valueOf(tmStpDate.toString().substring(0,10));
			
			Instrument instr = stressTestDerHisPrToExp.getInstr();
			
			// instrId PAMP - strumento di partenza
			int instrId = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getInstrId();
			
			String scenario = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getScenario();
			
			// classCode PAMP - strumento di partenza
			String classCode = stressTestDerHisPrToExp.getInstr().getClassCode();
			
			int expiry = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getExpiry();
			
			//pc
			String pc = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getPc();
			
			BigDecimal strike = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getStrike();
			
			BigDecimal stVola = stressTestDerHisPrToExp.getStressTestDerHP().getImpVolaSt();
			
			//prezzo originale
			BigDecimal closePr = null;
			
			//prezzo stressato
			BigDecimal closePrSt = null;
			
			//delta
			BigDecimal deltaPrice = null;
			
			//start Variation
			BigDecimal variation = new BigDecimal(0);
			
			String isinCode = stressTestDerHisPrToExp.getStressTestDerHP().getCode();
			
			boolean isOption = false;
			
			if ((pc.equalsIgnoreCase("C") || pc.equalsIgnoreCase("P"))) {
				isOption = true;
				
				//prezzo cash
				closePr = undStressedPrice.getClosePr();
				
				//prezzo stressato cash
				closePrSt = undStressedPrice.getClosePrSt();
				
			} else {
				//prezzo originale future
				closePr = stressTestDerHisPrToExp.getStressTestDerHP().getClosePr();
				
				//prezzo stressato future
				closePrSt = stressTestDerHisPrToExp.getStressTestDerHP().getClosePrSt();
						
			}
			
			//delta
			deltaPrice = closePrSt.subtract(closePr);
			
			//variation
			if (closePr.compareTo(new BigDecimal(0))!=0) {
				variation = deltaPrice.divide(closePr,8, RoundingMode.HALF_EVEN);
			} else {
				appIntLog.warn("Found close price value equals to zero for instrId "+instr.getInstrId()+" - variation and stressed price have been set to zero");
			}
			
			
			/*if (!lastPc.equalsIgnoreCase(pc)) {
				String futOrOption = "###### Starting the ";
				if (!isOption) {
					futOrOption += "future stressed prices ";
				} else {
					futOrOption += "option stressed volatilities ";
				}
				futOrOption += "export ###### ";
				appIntLog.info(futOrOption);
				
				lastPc = pc;
			}*/
			
			//delta
			//deltaPrice = closePrSt.subtract(closePr);
			
			String exportLog = "";
			
			// scorro la transcodifica standard
			for (InstrIdTrascode transcodedInstr:stressTestDerHisPrToExp.getInstrIdTC()) {
			
				String sicInstrTy = transcodedInstr.getPk().getSicInstrTy();
				
				String sicCode = transcodedInstr.getPk().getSicInstr();
				
				String stExport = transcodedInstr.getStExport();
				
				if (stExport.equalsIgnoreCase("A")) {
				
					// se il pc � F vuol dire che lo strumento � un future (instrtype = 'F' o 'FO') 
					if (!isOption && sicInstrTy.equalsIgnoreCase("F")) {
						
						countFuture++;
						
						//Cpsrss1 intracsPriceSeries = cpsrss1EAO.findByPrimaryKey(sicCode, expiry, new BigDecimal(0), "", GenericTools.shortDateFormatAsLong(tmStpDate));
						
						//String clearingIsinCode = intracsPriceSeries.getHCusip();
						
						exportLog = "Stressed price exported on Clearing system for PAMP instrId "+instr.getInstrId()+" - Clearing system updated instrument code: "+sicCode+" (type: "+sicInstrTy+"); expiry: "+expiry+"; isinCode: "+isinCode+"; stressed price: "+closePrSt;
						
						this.exportFuturePrice(closePrSt, isinCode, tmStpDate, exportLog);
						
						
					} else if (isOption && sicInstrTy.equalsIgnoreCase("O")) { // il pc � P (put) o C (call) quindi � un'opzione
						
						countOption++;
						
						//Cpsrss1 intracsPriceSeries = cpsrss1EAO.findByPrimaryKey(sicCode, expiry, strike, pc, GenericTools.shortDateFormatAsLong(tmStpDate));
						
						//String clearingIsinCode = intracsPriceSeries.getHCusip();
						
						//appIntLog.info("Stressed volatility exported on Clearing system for PAMP instrId "+instrId+" (code: "+classCode+") - Clearing system updated instrument code: "+sicCode+" (type: "+sicInstrTy+"); expiry: "+expiry+"; put/call: "+pc+"; strike: "+strike+"; isinCode: "+clearingIsinCode+"; stressed volatility: "+stVola);
						exportLog = "Stressed volatility exported on Clearing system for PAMP instrId "+instrId+" (code: "+classCode+") - Clearing system updated instrument code: "+sicCode+" (type: "+sicInstrTy+"); expiry: "+expiry+"; put/call: "+pc+"; strike: "+strike+"; isinCode: "+isinCode+"; stressed volatility: "+stVola;
						this.exportOptionVolatility(stVola, isinCode, tmStpDate, exportLog);
					}
				}
			}
			
			if ((instrId!=lastInstrId) || (instrId==lastInstrId && !pc.equalsIgnoreCase(lastPC) && !pc.equalsIgnoreCase("P"))) {
				
				// scorro la transcodifica delle rettificate IN QUESTA SITUAZIONE DEVO STRESSARE UTILIZZANDO I DATI DI INTRACS 
				for (InstrIdTrascode rectifiedClass:stressTestDerHisPrToExp.getRectifiedClassArray()) {
				
					String sicInstrTy = rectifiedClass.getPk().getSicInstrTy();
					
					String sicCode = rectifiedClass.getPk().getSicInstr();
					
					String stExport = rectifiedClass.getStExport();
					
					if (stExport.equalsIgnoreCase("A")) {
						// se il pc � F vuol dire che lo strumento � un future (instrtype = 'F' o 'FO') 
						if (!isOption && sicInstrTy.equalsIgnoreCase("F")) {
							
							//cerco sui prezzi per prendere gli ISINCODE
							List<Cpsrss1> intracsPriceSeriesList = cpsrss1EAO.findFuturesBySymblAndDate(sicCode, tmStpDate);
								
							if (intracsPriceSeriesList.size()>0) {
								
								for (Cpsrss1 intracsPriceSeries:intracsPriceSeriesList) {
													
									BigDecimal stressedPrice = null;
									
									//se il prezzo sulla serie Intracs NON � vuoto e NON � zero
									if (intracsPriceSeries.getHClose()!= null && intracsPriceSeries.getHClose().compareTo(new BigDecimal(0))>0) {
										//in base allo scenario aggiungo o sottraggo
										if (scenario.equalsIgnoreCase("I")||scenario.equalsIgnoreCase("D")) {
											if (instr.getDerHist().equalsIgnoreCase("F")) {
												stressedPrice = intracsPriceSeries.getHClose().add(deltaPrice);
											} else {
												stressedPrice = intracsPriceSeries.getHClose().multiply(new BigDecimal(1).add(variation));
											}
										} else {
											throw new DataNotValidException("Stress test scenario "+scenario+" is not supported");
										}
										
										countFuture++;
										
										countRectFuture++;
										
										exportLog = "Stressed price exported on Clearing system for rectified class "+sicCode+" (type: "+sicInstrTy+") of PAMP instrId "+instr.getInstrId()+" - Added stressed price: "+stressedPrice+" for isinCode: "+intracsPriceSeries.getHCusip();
										this.exportFuturePrice(stressedPrice, intracsPriceSeries.getHCusip(), tmStpDate, exportLog);
										
									} else {
										appIntLog.warn("Price value on Clearing system null or equal to zero for instrId "+instr.getInstrId()+" (code: "+sicCode+") - date: "+priceDate);
										//throw new InstrumentNotAvailableOnClearingException(instr.getInstrId(),sicCode,"Future");
									}
								}
							}
						} else if (isOption && sicInstrTy.equalsIgnoreCase("O")) { // il pc � P (put) o C (call) quindi � un'opzione
						
							BigDecimal volaCoeff = stressTestDerHisPrToExp.getVolaCoeff();
							
							//*********************************Da inserire dentro il For delle  classi rettificate per le option*************************************
							
							List<Cpsrss1> cpsrssList = cpsrss1EAO.findOptionsBySymblAndDate(sicCode, tmStpDate);
		
							if (cpsrssList == null || cpsrssList.size() == 0)
								appIntLog.warn("No options available for for instrId "+instr.getInstrId()+" (code: "+sicCode+") - date: "+priceDate);
								//throw new InstrumentDataNotAvailableException(instrId, "No options available for classcode: " + sicCode + " and histupdday: " + tmStpDate + " on the clearing system");
								
							String lastPutCall = "";
							long lastExpiry = 0;
							boolean firstTime = true;
							
							Vector<Cpsrss1> parziale = new Vector<Cpsrss1>();
							
							for (Cpsrss1 cps : cpsrssList) {
		
								if (firstTime) {
									parziale.add(cps);
									lastPutCall = cps.getPk().getHPc();
									lastExpiry = cps.getPk().getHExpir();
									firstTime = false;
								} else {
									// siamo sempre nella stessa scadenza e stesso putcall
									// quindi continuo ad inserire nel parziale le scadenze
									if (lastPutCall.equalsIgnoreCase(cps.getPk().getHPc()) && lastExpiry == cps.getPk().getHExpir()) {
										parziale.add(cps);
									}
									// vuol dire che c'� un salto quindi provvedo a fare i
									// calcoli sul parziale e quindi a svuotarlo e a mettere
									// la cps corrente
									else {
		
										// tramite questo metodo ricavo di quanto vanno shiftate le volatility
										OptionShift optShift = this.getIndiciSPStressatiENormali(parziale, closePrSt, closePr, scenario);
		
										for (int i = 0; i < parziale.size(); i++) {
		
											int index = Math.min(Math.max(i + optShift.getShiftIndex(), 0), parziale.size() - 1);
		
											BigDecimal impVolaSt = parziale.get(index).getHImpvl().multiply(volaCoeff);
											
											countOption++;
											countRectOption++;
											
											exportLog = "Stressed volatility exported on Clearing system for rectified class "+sicCode+" (type: "+sicInstrTy+") of PAMP instrId "+instrId+" (code: "+classCode+") - Added stressed volatility: "+impVolaSt+" for isinCode: "+parziale.get(i).getHCusip();
											this.exportOptionVolatility(impVolaSt, parziale.get(i).getHCusip(), tmStpDate, exportLog);
										}
		
										parziale.clear();
										parziale.add(cps);
										lastPutCall = cps.getPk().getHPc();
										lastExpiry = cps.getPk().getHExpir();
									}
		
								}
		
							}
		
							if (!parziale.isEmpty()) {
								// tramite questo metodo ricavo di quanto vanno
								// shiftate le volatility
								OptionShift optshift = this.getIndiciSPStressatiENormali(parziale, closePrSt, closePr, scenario);
		
								for (int i = 0; i < parziale.size(); i++) {
		
									int index = Math.min(Math.max(i + optshift.getShiftIndex(), 0), parziale.size() - 1);
		
									BigDecimal impVolaSt = parziale.get(index).getHImpvl().multiply(volaCoeff);
									
									countOption++;
									countRectOption++;
									
									exportLog = "Stressed volatility exported on Clearing system for rectified class "+sicCode+" (type: "+sicInstrTy+") of PAMP instrId "+instrId+" (code: "+classCode+") - Added stressed volatility: "+impVolaSt+" for isinCode: "+parziale.get(i).getHCusip();
									this.exportOptionVolatility(impVolaSt, parziale.get(i).getHCusip(), tmStpDate, exportLog);
								}
		
								parziale.clear();
							}
	
						// ******************************************************************************************************************************
						}	
					}
				}
				
			}
			
			lastInstrId = instrId;
			lastPC = pc;
			
		}
		
		appIntLog.info(countFuture + " futures stressed prices ("+countRectFuture+" for rectified classes) and "+countOption+" option volatility ("+countRectOption+" for rectified classes) exported to Clearing system");

		esthPamp.updateStressTestDerHPSentStatusAfterExport(stressTestDerivativesHisPrToExpVect);
	}
	
	
	/*public void setFuture(Instrument instr, String sicCode, String sicInstrType, Timestamp priceDate, BigDecimal deltaPrice, String scenario, BigDecimal variation) throws DataNotValidException, InstrumentNotAvailableOnClearingException {
		
		//-------leggo su CPSRSS1 
		List<Cpsrss1> intracsPriceSeriesList = cpsrss1EAO.findFuturesBySymblAndDate(sicCode, priceDate);
		
		Date prDate = Date.valueOf(priceDate.toString().substring(0,10));
		
		if (intracsPriceSeriesList.size()>0) {
			
			for (Cpsrss1 intracsPriceSeries:intracsPriceSeriesList) {
			
				int expiry = (int) intracsPriceSeries.getPk().getHExpir();
				
				//prezzo preso da Intracs che sar� utilizzato per l'export finale
				BigDecimal intracsPrice = intracsPriceSeries.getHClose();
			
				//isinCode preso da Intracs per essere sicuro di utilizzare quello dell'oggetto trascodificato
				String clearingIsinCode = intracsPriceSeries.getHCusip();
			
				BigDecimal stressedPrice = null;
			
				//se il prezzo sulla serie NON � vuoto e NON � zero
				if (intracsPrice!= null && intracsPrice.compareTo(new BigDecimal(0))!=0) {
					//in base allo scenario aggiungo o sottraggo
					if (scenario.equalsIgnoreCase("I")||scenario.equalsIgnoreCase("D")) {
						if (instr.getDerHist().equalsIgnoreCase("F")) {
							stressedPrice = intracsPrice.add(deltaPrice);
						} else {
							stressedPrice = intracsPrice.multiply(new BigDecimal(1).add(variation));
						}
					} else {
						throw new DataNotValidException("Stress test scenario "+scenario+" is not supported");
					}
				} else {
					appIntLog.warn("Price value on Clearing system null or equal to zero for instrId "+instr.getInstrId()+" (code: "+sicCode+") - date: "+prDate);
					throw new InstrumentNotAvailableOnClearingException(instr.getInstrId(),sicCode,"Future");
				}
			
			
				//prendo il valore massimo tra lo stessato e 0.000001 per evitare valori negativi
				stressedPrice = new BigDecimal(Math.max(stressedPrice.doubleValue(),0.000001)).setScale(8, RoundingMode.HALF_EVEN);
			
									
				// scrivo sulla serie Future
				StressTestCgpri00f intracsFutureStressedPrice = new StressTestCgpri00f();//stressTestCgpri00f.findByPrimaryKey(priceDate, clearingIsinCode);
				
				StressTestCgpri00fPK intracsFutureStressedPricePK = new StressTestCgpri00fPK();
				
				intracsFutureStressedPricePK.setPrIsin(clearingIsinCode);
				intracsFutureStressedPricePK.setPrDate(prDate);
				
				intracsFutureStressedPrice.setPk(intracsFutureStressedPricePK);
				intracsFutureStressedPrice.setPrPric(stressedPrice);
				
				stressTestCgpri00f.store(intracsFutureStressedPrice);
				appIntLog.info("Stressed price exported on Clearing system for PAMP instrId "+instr.getInstrId()+" - Clearing system updated instrument code: "+sicCode+" (type: "+sicInstrType+"); expiry: "+expiry+"; isinCode: "+clearingIsinCode+"; stressed price: "+stressedPrice);
				
			}	
		} else {
			appIntLog.warn("No price series available on Clearing system for instrId "+instr.getInstrId()+" (code: "+sicCode+" - future) - date: "+priceDate);
			//TODO
			//throw new InstrumentNotAvailableOnClearingException(instrId,classCode,"Future");
		}
	}*/
	
	public void exportFuturePrice(BigDecimal stressedPrice, String isinCode, Timestamp priceDate, String log) throws DataNotValidException, InstrumentNotAvailableOnClearingException {
		
		// formato data per I400DTAST.CGPRI00F
		Date prDate = Date.valueOf(priceDate.toString().substring(0,10));
		
		//prendo il valore massimo tra lo stessato e 0.000001 per evitare valori negativi
		stressedPrice = new BigDecimal(Math.max(stressedPrice.doubleValue(),0.000001)).setScale(8, RoundingMode.HALF_EVEN);
			
		// scrivo sulla serie Future
		StressTestCgpri00f intracsFutureStressedPrice = new StressTestCgpri00f();//stressTestCgpri00f.findByPrimaryKey(priceDate, clearingIsinCode);
				
		StressTestCgpri00fPK intracsFutureStressedPricePK = new StressTestCgpri00fPK();
				
		//isincode preso da intracs
		intracsFutureStressedPricePK.setPrIsin(isinCode);
		intracsFutureStressedPricePK.setPrDate(prDate);
				
		intracsFutureStressedPrice.setPk(intracsFutureStressedPricePK);
		intracsFutureStressedPrice.setPrPric(stressedPrice);
				
		stressTestCgpri00f.store(intracsFutureStressedPrice);
		appIntLog.info(log);
	}
	
	public void exportOptionVolatility(BigDecimal stressedVola, String isinCode, Timestamp priceDate, String log) throws DataNotValidException, InstrumentNotAvailableOnClearingException {
		
		// formato data per I400DTAST.CGPRI00F
		Date prDate = Date.valueOf(priceDate.toString().substring(0,10));
		
		StressTestCgvolai00f intracsOptionStressedVola = new StressTestCgvolai00f();
		StressTestCgvolai00fPK intracsOptionStressedVolaPK = new StressTestCgvolai00fPK();
		
		intracsOptionStressedVolaPK.setSrDate(prDate);
		intracsOptionStressedVolaPK.setSrIsin(isinCode);
		
						
		intracsOptionStressedVola.setPk(intracsOptionStressedVolaPK);
		intracsOptionStressedVola.setSrVola(stressedVola);
		
		stressTestCgvolai00f.store(intracsOptionStressedVola);
		appIntLog.info(log);
	}
	
	
	
	
	
	//Metodo per calcolare lo shift dato un insieme di strike price relativi ad una stessa Put/Call e scadenza	
	private OptionShift getIndiciSPStressatiENormali(Vector<Cpsrss1> parziale, BigDecimal modprice, BigDecimal normprice, String scenario) {

			int normSPindex = 0;
			int modSPindex = 0;

			BigDecimal normdelta = null;
			BigDecimal normstrk = null;
			BigDecimal moddelta = null;
			BigDecimal modstrk = null;

			for (int i = 0; i < parziale.size(); i++) {

				Cpsrss1 curcp = parziale.get(i);

				// se il normdelta � uguale a null vuol dire che sono appena entrato
				// e quindi setto l'indice al primo elemento e
				// la differenza
				if (normdelta == null) {
					normSPindex = i;
					normdelta = normprice.subtract(curcp.getPk().getHStrik()).abs();
					normstrk = curcp.getPk().getHStrik();
				}
				// altrimenti controllo che la nuova differenza sia minore
				// dell'ultima trovata in valore assoluto,
				else {
					// se lo � aggiorno l'indice ed il delta
					if (normprice.subtract(curcp.getPk().getHStrik()).abs().compareTo(normdelta) <= 0) {
						normdelta = normprice.subtract(curcp.getPk().getHStrik()).abs();
						normSPindex = i;
						normstrk = curcp.getPk().getHStrik();
					}
					// altrimenti proseguo
				}

				// se il moddelta � uguale a null vuol dire che sono appena entrato
				// e quindi setto l'indice al primo elemento e
				// la differenza
				if (moddelta == null) {
					modSPindex = i;
					moddelta = modprice.subtract(curcp.getPk().getHStrik()).abs();
					modstrk = curcp.getPk().getHStrik();
				}
				// altrimenti controllo che la nuova differenza sia minore
				// dell'ultima trovata in valore assoluto,
				else {
					// se lo � aggiorno l'indice ed il delta
					if (modprice.subtract(curcp.getPk().getHStrik()).abs().compareTo(moddelta) <= 0) {
						moddelta = modprice.subtract(curcp.getPk().getHStrik()).abs();
						modSPindex = i;
						modstrk = curcp.getPk().getHStrik();
					}
					// altrimenti proseguo
				}

			}

			if (parziale.size() != 0) {
				Cpsrss1 curcp = parziale.get(0);

				appIntLog.info("################### Scenario: " + scenario + " - Symbol: " + curcp.getPk().getHSymbl().trim() + " - PC: " + curcp.getPk().getHPc() + " - EXP: " + curcp.getPk().getHExpir()
						+ " - Strike prices: " + parziale.size() + " ####################");
			}

			else {
				appIntLog.info("################### Partial vector empty ####################");
			}

			appIntLog.info("Price " + normprice + " Stressed Price " + modprice);
			appIntLog.info("ATM Strike " + normstrk + " Stressed ATM Strike " + modstrk);

			int indexdif = normSPindex - modSPindex;
			appIntLog.info("Shifting delta: " + indexdif);

			return new OptionShift(indexdif, normSPindex, modSPindex);

		}
	
		
}
