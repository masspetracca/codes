package it.ccg.pamp.server.appint;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.BondClassDataNotAvailableException;
import it.ccg.pamp.server.utils.ReadyToExpIntraClassOffsetHistory;

import java.util.Vector;

import javax.ejb.Local;

@Local
public interface TAOPLocal {
	public void readIntracs() throws DataNotValidException;
	public Vector<ReadyToExpIntraClassOffsetHistory> getIntraClassOffsetHistoryReadyToExp() throws DataNotValidException, BondClassDataNotAvailableException;
	public void export() throws Exception;
}
