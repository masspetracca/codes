package it.ccg.pamp.server.appint;
import javax.ejb.Local;

@Local
public interface MDDLocal {
	public String marketDatesDownload();
}
