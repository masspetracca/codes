package it.ccg.pamp.server.appint.stressTest;

import it.ccg.pamp.server.eao.stressTest.StressTestDerivativeHistPriceEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestHistPriceEAOLocal;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.StressTestDerivativesHistPricesReadyToExp;
import it.ccg.pamp.server.utils.StressTestHistPricesReadyToExp;
import it.ccg.pamp.server.utils.StressTestIndexPricesReadyToExp;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ESTHPPAMPUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class ESTHPPAMPUnit implements  ESTHPPAMPUnitLocal {

	@EJB
	private StressTestHistPriceEAOLocal stressTestHPEAO;
	
	@EJB
	private StressTestDerivativeHistPriceEAOLocal stressTestDerHPEAO;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");

       
	public void updateStressTestHPSentStatusAfterExport(Vector<StressTestHistPricesReadyToExp> stressTestHisPrToExpVect) throws DataNotValidException {
		
		for (StressTestHistPricesReadyToExp stressTestHisPrToExp : stressTestHisPrToExpVect) {
			
			int instrId = stressTestHisPrToExp.getStressTestHP().getPk().getInstrId();
			
			int stId = stressTestHisPrToExp.getStressTestHP().getPk().getStId();
			String scenario = stressTestHisPrToExp.getStressTestHP().getPk().getScenario();
			
			
			StressTestHistPrice stressTestHP = stressTestHPEAO.findByPrimaryKey(instrId, scenario, stId);
			stressTestHP.setSent("T");
			stressTestHP.setUpdDate(GenericTools.systemDate());
			stressTestHP.setUpdType("U");
			stressTestHP.setUpdUsr("System");
			  
			stressTestHPEAO.update(stressTestHP);
			
		}
		appIntLog.info("sent status updated for "+stressTestHisPrToExpVect.size() + " cash stressed prices ");
	}
	
	
	public void updateStressTestBondSentStatusAfterExport(Vector<StressTestHistPricesReadyToExp> stressTestBondToExpVect) throws DataNotValidException {
		
		for (StressTestHistPricesReadyToExp stressTestBondToExp : stressTestBondToExpVect) {
			
			int instrId = stressTestBondToExp.getStressTestHP().getPk().getInstrId();
			
			int stId = stressTestBondToExp.getStressTestHP().getPk().getStId();
			String scenario = stressTestBondToExp.getStressTestHP().getPk().getScenario();
			
			
			
			StressTestHistPrice stressTestHP = stressTestHPEAO.findByPrimaryKey(instrId, scenario, stId);
			stressTestHP.setSent("T");
			stressTestHP.setUpdDate(GenericTools.systemDate());
			stressTestHP.setUpdType("U");
			stressTestHP.setUpdUsr("System");
			  
			stressTestHPEAO.update(stressTestHP);
			
		}
		appIntLog.info("sent status updated for "+stressTestBondToExpVect.size() + " bond stressed prices ");
	}

	public void updateStressTestIndexSentStatusAfterExport(Vector<StressTestIndexPricesReadyToExp> stressTestIndexPricesReadyToExpVec) throws DataNotValidException {
		
		for (StressTestIndexPricesReadyToExp stressTestIdxHisPrToExp : stressTestIndexPricesReadyToExpVec) {
			
			int instrId = stressTestIdxHisPrToExp.getStressTestHP().getPk().getInstrId();
			
			int stId = stressTestIdxHisPrToExp.getStressTestHP().getPk().getStId();
			String scenario = stressTestIdxHisPrToExp.getStressTestHP().getPk().getScenario();
			
			
			StressTestHistPrice stressTestHP = stressTestHPEAO.findByPrimaryKey(instrId, scenario, stId);
			stressTestHP.setSent("T");
			stressTestHP.setUpdDate(GenericTools.systemDate());
			stressTestHP.setUpdType("U");
			stressTestHP.setUpdUsr("System");
			  
			stressTestHPEAO.update(stressTestHP);
			
		}
		appIntLog.info("sent status updated for "+stressTestIndexPricesReadyToExpVec.size() + " index stressed prices ");
	}
	
	
	public void updateStressTestDerHPSentStatusAfterExport(Vector<StressTestDerivativesHistPricesReadyToExp> stressTestDerivativesHisPrToExpVect) throws DataNotValidException {
		
		int total = 0;
		
		List<Integer> lastInstrId = new ArrayList<Integer>();
		
		for (StressTestDerivativesHistPricesReadyToExp stressTestDerHisPrToExp : stressTestDerivativesHisPrToExpVect) {
			
			int instrId = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getInstrId();
			
			
			
			int stId = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getStId();
			String scenario = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getScenario();
			/*int prgExp  = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getExpiry();
			String pc = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getPc();
			BigDecimal strike = stressTestDerHisPrToExp.getStressTestDerHP().getPk().getStrike();*/
			
			/*StressTestDerivativeHistPrice stressTestDerHP = stressTestDerHPEAO.findByPrimaryKey(instrId, prgExp, scenario, stId, pc, strike);
			stressTestDerHP.setSent("T");
			stressTestDerHP.setUpdDate(GenericTools.systemDate());
			stressTestDerHP.setUpdType("U");
			stressTestDerHP.setUpdUsr("System");*/
			
			if (!lastInstrId.contains(instrId)) {
			
				int updated = stressTestDerHPEAO.updateSentStatusAfterExport(instrId, stId, scenario);
			
				total += updated;
				
				lastInstrId.add(instrId);
			
			}
			
		}
		appIntLog.info("sent status updated for "+total+ " derivative stressed prices and volatilities");
		

	}

}
