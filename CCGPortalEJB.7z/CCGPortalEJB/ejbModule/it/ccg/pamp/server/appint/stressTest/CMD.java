package it.ccg.pamp.server.appint.stressTest;

import it.ccg.pamp.server.eao.stressTest.Cgmbr00fEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestMemberEAOLocal;
import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestMember;
import it.ccg.pamp.server.entities.stressTest.StressTestMemberPK;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.MemberToSync;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class CMD
 */
@Stateless
public class CMD implements CMDLocal {

	@EJB
	private Cgmbr00fEAOLocal intracsMember;
	
	@EJB
	private StressTestMemberEAOLocal stMemberStatsEAO;

	private final Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	
	public String clearingMemberDownload(String scenario, StressTest stressTest) throws DataNotValidException, DataNotAvailableException {
		
		LinkedHashMap<Integer, Vector<BigDecimal>> marginCompositionMap = new LinkedHashMap<Integer, Vector<BigDecimal>>();
		
		// cerco su Intracs i membri da scaricare in base al comparto se MTS
		if (stressTest.getDivisCode().equalsIgnoreCase("O")) {
			marginCompositionMap = intracsMember.getMarginComposition();
			
		}
		
		// cerco su Intracs i membri da scaricare in base al comparto
		List<MemberToSync> memberToSyncList = intracsMember.getMemberToSync(stressTest.getDivisCode());
		
		int dwnlMbr = 0;
		
		
		// per ogni membro da scaricare
		for (MemberToSync member:memberToSyncList) {
			
			StressTestMemberPK memberStatPK = new StressTestMemberPK();
			StressTestMember memberStat = new StressTestMember();
			
			// setto le colonne in chiave
			memberStatPK.setMbrId(member.getMbrId());
			memberStatPK.setScenario(scenario);
			memberStatPK.setStId(stressTest.getStId());
			
			// setto le altre colonne
			memberStat.setPk(memberStatPK);
			
			memberStat.setMbrDesc(member.getGenMbrName());
			memberStat.setCnrMmar(member.getClientInitialMargin());
			memberStat.setCStrMar(member.getClientCashCall());
			memberStat.setHnrMmar(member.getFirmInitialMargin());
			memberStat.setHStrMar(member.getFirmCashCall());
			memberStat.setHistUpdDay(stressTest.getLstHistDat());
			memberStat.setMia(member.getMia());
			
			// NCE = CASH CALL TERZI + CASH CALL PROPRIO
			BigDecimal nce = new BigDecimal(0);
			
			//SE CASH CALL TERZI > 0 ALLORA NCE = CASH CALL PROPRIO
			if (member.getClientCashCall().signum()==1) {
				nce = member.getFirmCashCall();
			} else {
				nce = member.getClientCashCall().add(member.getFirmCashCall());
			}
			
			//SE NCE > 0 ALLORA RISETTO A ZERO
			if (nce.signum()==1)
				nce = new BigDecimal(0);
			
			String values = "client cash call: "+member.getClientCashCall()+", firm cash call: "+member.getFirmCashCall()+" nce: "+nce+", mia: "+member.getMia();
			
			memberStat.setNce(nce);
			
			BigDecimal mtmMargin = new BigDecimal(0);
			BigDecimal ordinaryMargin = new BigDecimal(0);
			
			if (stressTest.getDivisCode().equalsIgnoreCase("O")) {
				//entro solo se c'� corrispondenza tra il membro in download e quello salvato nella mappa
				if (marginCompositionMap.get(member.getMbrId())!=null) {
					//nuova parte per storicizzare la composizione del margine nel caso di stress test MTS
					ordinaryMargin = marginCompositionMap.get(member.getMbrId()).get(0);
					mtmMargin = marginCompositionMap.get(member.getMbrId()).get(1);
				}
			}
			
			memberStat.setOrdMargin(ordinaryMargin);
			memberStat.setMtmMargin(mtmMargin);
			
			//store
			stMemberStatsEAO.store(memberStat);
			
			appIntLog.info("member "+member.getGenMbrName()+" statistic synchronized for stress test Id "+stressTest.getStId()+" ("+GenericTools.scenarioDesc(scenario)+" scenario) - "+values);
			
			dwnlMbr++;
			
		}
		
		return dwnlMbr+" synchronized from Risk Engine to Pamp System";
	}
	

}
