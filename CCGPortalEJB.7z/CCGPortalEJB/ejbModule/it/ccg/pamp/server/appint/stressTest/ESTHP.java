package it.ccg.pamp.server.appint.stressTest;

import it.ccg.pamp.server.eao.InstrIdTrascodeEAOLocal;
import it.ccg.pamp.server.eao.InstrumentEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestDerivativeHistPriceEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestHistPriceEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestSetupEAOLocal;
import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestDerivativeHistPrice;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;
import it.ccg.pamp.server.entities.stressTest.StressTestSetup;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.utils.StressTestDerivativesHistPricesReadyToExp;
import it.ccg.pamp.server.utils.StressTestHistPricesReadyToExp;
import it.ccg.pamp.server.utils.StressTestIndexDerivTranscode;
import it.ccg.pamp.server.utils.StressTestIndexPricesReadyToExp;

import java.math.BigDecimal;
import java.util.List;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ESTHP
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class ESTHP implements  ESTHPLocal {

	@EJB
	private StressTestHistPriceEAOLocal stHPEAO ;
	
	@EJB
	private StressTestDerivativeHistPriceEAOLocal stDerHPEAO;
	
	@EJB
	private StressTestSetupEAOLocal stSetupEAO;
	
	@EJB
	private InstrumentEAOLocal instrEAO;
	
	@EJB
	private InstrIdTrascodeEAOLocal instrTrancodeEAO;
	
	@EJB
	private ESTHPINTRACSUnitLocal esthpIntracsUnit;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public Vector<StressTestHistPricesReadyToExp> getStressTestCashPricesReadyToExp(int stId, String scenario) throws DataNotValidException, InstrumentDataNotAvailableException {

		//recupero dalla tabella dei prezzi stressati tutti i prezzi su cui voglio effettuare lo stress test x tipologia di scenario
		List<StressTestHistPrice> stressTestCashPrToExpList = stHPEAO.getStressTestHistPriceToExport(stId, scenario);
		
		//creo un'oggettone di appoggio che conterr� ogni istanza di tipo StressTestHistPrice e una stringa che identifica il classCode dello strumento 
		Vector<StressTestHistPricesReadyToExp> stressTestHistPricesReadyToExpVect = new Vector<StressTestHistPricesReadyToExp>();
		
		String toBeExported = "No equity cash stressed prices found to export";
		
		if (stressTestCashPrToExpList == null || stressTestCashPrToExpList.size() == 0) {
			
			appIntLog.info(toBeExported);
			
		} else {
			int foundToExport = 0;
			// per ogni prezzo stressato da esportare vado a prendere sulla instrument il classCode che mi servir� per incrociare su intracs
			for (StressTestHistPrice stressTestHistPrice:stressTestCashPrToExpList) {
				
				// cerco lo strumento sull'anagrafica
				Instrument instr = instrEAO.findByPrimaryKey(stressTestHistPrice.getPk().getInstrId());
				
				if (instr==null) {
					throw new InstrumentDataNotAvailableException(stressTestHistPrice.getPk().getInstrId(), "No instrument found for instrId: "+stressTestHistPrice.getPk().getInstrId());
				} else {
					if (instr.getDivisCode().equalsIgnoreCase("E")) {
					
						// recupero dalla tabella di transcodifica
						InstrIdTrascode[] instrIdTC = instrTrancodeEAO.getSicInstr(instr.getInstrId());
							
						// se vuota blocco altrimenti aggiungo alla lista tutti gli eventuali trascodificati relativi allo strumento di cui l'indice � sottostante
						if (instrIdTC.length == 0) {
							throw new InstrumentDataNotAvailableException(instr.getInstrId(), "No INTRACS instruments linked to this PAMP instrID");
						} 
											
						//creo una nuova istanza dell'oggettone con tutto il prezzo stressato e il parametro del classcode e le eventuali transcodifiche su cui esportare il prezzo stressato
						StressTestHistPricesReadyToExp stressedHPReadyToExport = new StressTestHistPricesReadyToExp(stressTestHistPrice, instr, instrIdTC);
					
						//aggiungo l'oggettone al vettore
						stressTestHistPricesReadyToExpVect.add(stressedHPReadyToExport);
						
						foundToExport++;
					} else {
						appIntLog.warn("instrId "+stressTestHistPrice.getPk().getInstrId()+" excluded from export: division not allowed (found :"+instr.getDivisCode()+"; required: E)");
					}
				}
			}
			if (foundToExport>0) {
				toBeExported = foundToExport+" cash stressed prices ready to be exported";
			}
			appIntLog.info(toBeExported);
			
		} 
		
		return stressTestHistPricesReadyToExpVect;
	}
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public Vector<StressTestIndexPricesReadyToExp> getStressTestIndexPricesReadyToExp(int stId, String scenario) throws DataNotValidException, InstrumentDataNotAvailableException {

		//recupero dalla tabella dei prezzi stressati tutti i prezzi su cui voglio effettuare lo stress test x tipologia di scenario
		List<StressTestHistPrice> stressTestIndexHisPrToExpList = stHPEAO.getStressTestHistPriceToExport(stId, scenario);
		
		//creo un'oggettone di appoggio che conterr� ogni istanza di tipo StressTestHistPrice e una stringa che identifica il classCode dello strumento 
		Vector<StressTestIndexPricesReadyToExp> stressTestIndexPricesReadyToExpVect = new Vector<StressTestIndexPricesReadyToExp>();
		
		String toBeExported = "";
		
		if (stressTestIndexHisPrToExpList == null || stressTestIndexHisPrToExpList.size() == 0) {
			toBeExported = "No index stressed prices found to export";
			appIntLog.info(toBeExported);
			
		} else {
			int foundToExport = 0;
			// per ogni prezzo stressato da esportare vado a prendere sulla instrument il classCode che mi servir� per incrociare su intracs
			for (StressTestHistPrice stressTestHistPrice:stressTestIndexHisPrToExpList) {
				
				// cerco lo strumento sull'anagrafica
				Instrument indexInstr = instrEAO.findByPrimaryKey(stressTestHistPrice.getPk().getInstrId());
				
				if (indexInstr.getDivisCode().equalsIgnoreCase("X")) {
					
					//vado a cercare tutti i derivati per i quali quell'indice � sottostante
					Instrument[] derInstrIndexIsUnderlying = instrEAO.getInstrumentByDivisCodeAndUndInstrId("D", indexInstr.getInstrId());
					
					if (derInstrIndexIsUnderlying.length>0) {
					
						foundToExport++;
						
						Vector<StressTestIndexDerivTranscode> idxDerVec = new Vector<StressTestIndexDerivTranscode>();
						
						for (Instrument derinstr: derInstrIndexIsUnderlying) {
						
							// recupero dalla tabella di transcodifica
							InstrIdTrascode[] derInstrIdTC = instrTrancodeEAO.getSicInstr(derinstr.getInstrId());
							
							// se vuota blocco altrimenti aggiungo alla lista tutti gli eventuali trascodificati relativi allo strumento di cui l'indice � sottostante
							if (derInstrIdTC.length == 0) {
								throw new InstrumentDataNotAvailableException(stressTestHistPrice.getPk().getInstrId(), "No INTRACS instruments linked to this PAMP instrID");
							} else {	
								idxDerVec.add(new StressTestIndexDerivTranscode(derinstr,derInstrIdTC)); 
							}
						}
						
						//creo una nuova istanza dell'oggettone con tutto il prezzo stressato x quell'indice, lo strumento di quell'indice e la lista di derivati di cui � sottostante con relative transcodifiche su cui esportare il prezzo stressato
						StressTestIndexPricesReadyToExp stressedIndexPriceReadyToExport = new StressTestIndexPricesReadyToExp(stressTestHistPrice, indexInstr, idxDerVec);
							
						//aggiungo l'oggettone al vettore
						stressTestIndexPricesReadyToExpVect.add(stressedIndexPriceReadyToExport);
					} else {
						toBeExported = "No index stressed prices found to export for instrId "+indexInstr.getInstrId()+" (code: "+indexInstr.getClassCode()+")";
						appIntLog.info(toBeExported);
					}
				}
			}
			
			toBeExported = foundToExport+" index stressed prices ready to be exported";
			appIntLog.info(toBeExported);
		}	
		
		return stressTestIndexPricesReadyToExpVect;
	}
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public Vector<StressTestHistPricesReadyToExp> getStressTestBondsReadyToExp(int stId, String scenario) throws DataNotValidException, InstrumentDataNotAvailableException {

		//recupero dalla tabella dei prezzi stressati tutti i prezzi su cui voglio effettuare lo stress test x tipologia di scenario
		List<StressTestHistPrice> stressTestBondPrToExpList = stHPEAO.getStressTestHistPriceToExport(stId, scenario);
		
		//creo un'oggettone di appoggio che conterr� ogni istanza di tipo StressTestHistPrice e una stringa che identifica il classCode dello strumento 
		Vector<StressTestHistPricesReadyToExp> stressedBondsReadyToExpVect = new Vector<StressTestHistPricesReadyToExp>();
		
		String toBeExported = "No bond stressed prices found to export";
		
		if (stressTestBondPrToExpList == null || stressTestBondPrToExpList.size() == 0) {
			
			appIntLog.info(toBeExported);
			
		} else {
			int foundToExport = 0;
			// per ogni prezzo stressato da esportare vado a prendere sulla instrument il classCode che mi servir� per incrociare su intracs
			for (StressTestHistPrice stressTestHistPrice:stressTestBondPrToExpList) {
				
				// cerco lo strumento sull'anagrafica
				Instrument instr = instrEAO.findByPrimaryKey(stressTestHistPrice.getPk().getInstrId());
				
				if (instr==null) {
					throw new InstrumentDataNotAvailableException(stressTestHistPrice.getPk().getInstrId(), "No instrument found for instrId: "+stressTestHistPrice.getPk().getInstrId());
				} else {
					if (instr.getDivisCode().equalsIgnoreCase("O")||instr.getDivisCode().equalsIgnoreCase("I")) {
						
						/*TODO
						// recupero dalla tabella di transcodifica
						InstrIdTrascode[] instrIdTC = instrTrancodeEAO.getSicInstr(instr.getInstrId());
							
						// se vuota blocco altrimenti aggiungo alla lista tutti gli eventuali trascodificati relativi allo strumento di cui l'indice � sottostante
						if (instrIdTC.length == 0) {
							throw new InstrumentDataNotAvailableException(instr.getInstrId(), "No INTRACS instruments linked to this PAMP instrID");
						} 
											
						//creo una nuova istanza dell'oggettone con tutto il prezzo stressato e il parametro del classcode e le eventuali transcodifiche su cui esportare il prezzo stressato
						*/
						StressTestHistPricesReadyToExp stressedBondReadyToExport = new StressTestHistPricesReadyToExp(stressTestHistPrice, instr, null/*instrIdTC*/);
					
						//aggiungo l'oggettone al vettore
						stressedBondsReadyToExpVect.add(stressedBondReadyToExport);
						
						foundToExport++;
					} else {
						appIntLog.warn("instrId "+stressTestHistPrice.getPk().getInstrId()+" excluded from export: division not allowed (found :"+instr.getDivisCode()+"; required: O,I)");
					}
				}
			}
			if (foundToExport>0) {
				toBeExported = foundToExport+" bond stressed prices ready to be exported";
			}
			
			appIntLog.info(toBeExported);
			
		} 
		
		return stressedBondsReadyToExpVect;
	}
	
	
	/*@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public Vector<StressTestDerivativesHistPricesReadyToExp> getStressTestDerivativesHistPricesReadyToExp(int stId, String scenario) throws DataNotValidException, InstrumentDataNotAvailableException {

		//recupero dalla tabella dei prezzi stressati tutti i prezzi su cui voglio effettuare lo stress test x tipologia di scenario
		List<StressTestDerivativeHistPrice> stressTestDerivativesHisPrToExpList = stDerHPEAO.getStressTestDerivativeHistPriceToExport(stId, scenario);
		
		//creo un'oggettone di appoggio che conterr� ogni istanza di tipo StressTestHistPrice e una stringa che identifica il classCode dello strumento 
		Vector<StressTestDerivativesHistPricesReadyToExp> stressTestDerivativesHistPricesReadyToExpVect = new Vector<StressTestDerivativesHistPricesReadyToExp>();
		
		String toBeExported = "";
		
		if (stressTestDerivativesHisPrToExpList == null || stressTestDerivativesHisPrToExpList.size() == 0) {
			
			toBeExported = "No derivatives stressed prices and volatilities found to export";
			appIntLog.info(toBeExported);
		} else {
			
			int countFuture = 0;
			int countOption = 0;
			int countInstrument = 0;
			
			int lastInstrId = 0;
			Instrument instr = null;
			String lastPc = "";
			
			// per ogni prezzo stressato da esportare vado a prendere sulla instrument il classCode che mi servir� per incrociare su intracs
			for (StressTestDerivativeHistPrice stressTestDerivativesHistPrice:stressTestDerivativesHisPrToExpList) {
				
				if (stressTestDerivativesHistPrice.getPk().getPc().equalsIgnoreCase("P")||stressTestDerivativesHistPrice.getPk().getPc().equalsIgnoreCase("C")) {
					countOption++;
				} else {
					countFuture++;
				}
				
				// cerco le info strumento solo se � cambiato l'instrId spia
				if (!(stressTestDerivativesHistPrice.getPk().getInstrId()==lastInstrId && stressTestDerivativesHistPrice.getPk().getPc().equalsIgnoreCase(lastPc))) {
					// cerco lo strumento sull'anagrafica
					
					instr = instrEAO.findByPrimaryKey(stressTestDerivativesHistPrice.getPk().getInstrId());
					
					if (instr==null) {
						throw new InstrumentDataNotAvailableException(stressTestDerivativesHistPrice.getPk().getInstrId(), "No instrument found for instrId "+stressTestDerivativesHistPrice.getPk().getInstrId());
					} else {
					
						Integer undInstrId = instr.getUndInstrId();
						
						Instrument undInstr =  instrEAO.findByPrimaryKey(undInstrId);
						
						if (undInstr==null) {
							throw new InstrumentDataNotAvailableException(stressTestDerivativesHistPrice.getPk().getInstrId(), "No underlyng instrument found for instrId "+stressTestDerivativesHistPrice.getPk().getInstrId());
						} 
						
						String undInstrType = undInstr.getInstrType();	
							
						StressTestSetup stSetup = stSetupEAO.findByPrimaryKey(undInstrType);
						if (stSetup == null) {
							throw new InstrumentDataNotAvailableException(instr.getInstrId(), "No stress test setting available for instrument type " + undInstrType);
						}
						
						BigDecimal volaCoeff = stSetup.getVolaCoeff();
						
						countInstrument++;
						lastInstrId = instr.getInstrId();
						lastPc = stressTestDerivativesHistPrice.getPk().getPc();
						//trascodifica strumento
						InstrIdTrascode[] instrIdTC = instrTrancodeEAO.getSicInstr(lastInstrId);
						
						// se vuota blocco altrimenti aggiungo alla lista tutti gli eventuali trascodificati relativi allo strumento di cui l'indice � sottostante
						if (instrIdTC.length == 0) {
							throw new InstrumentDataNotAvailableException(instr.getInstrId(), "No INTRACS instruments linked to this PAMP instrID");
						} 
						
						// parte sottostante cash
						StressTestHistPrice stressTestCashPrToExp = null;
							
						//recupero dalla tabella dei prezzi stressati tutti i prezzi su cui voglio effettuare lo stress test x tipologia di scenario
						stressTestCashPrToExp = stHPEAO.findByPrimaryKey(undInstrId, scenario, stId);
							
						//creo una nuova istanza dell'oggettone con tutto il prezzo stressato e il parametro del classcode
						StressTestDerivativesHistPricesReadyToExp stressedDerHPReadyToExport = new StressTestDerivativesHistPricesReadyToExp(stressTestDerivativesHistPrice, instr, instrIdTC,stressTestCashPrToExp,volaCoeff);
						
						//aggiungo l'oggettone al vettore
						stressTestDerivativesHistPricesReadyToExpVect.add(stressedDerHPReadyToExport);
					}
				}
				
			}
			toBeExported = countInstrument+" stressed equity derivatives are ready to be exported";
			appIntLog.info(toBeExported);
			
		} 
		
		return stressTestDerivativesHistPricesReadyToExpVect;
	}*/
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public Vector<StressTestDerivativesHistPricesReadyToExp> getStressTestDerivativesHistPricesReadyToExp(int stId, String scenario) throws DataNotAvailableException, DataNotValidException, InstrumentDataNotAvailableException {

		//recupero dalla tabella dei prezzi stressati tutti i prezzi su cui voglio effettuare lo stress test x tipologia di scenario
		List<StressTestDerivativeHistPrice> stressTestDerivativesHisPrToExpList = stDerHPEAO.getStressTestDerivativeHistPriceToExport(stId, scenario);
		
		//creo un'oggettone di appoggio che conterr� ogni istanza di tipo StressTestHistPrice e una stringa che identifica il classCode dello strumento 
		Vector<StressTestDerivativesHistPricesReadyToExp> stressTestDerivativesHistPricesReadyToExpVect = new Vector<StressTestDerivativesHistPricesReadyToExp>();
		
		String toBeExported = "";
		
		if (stressTestDerivativesHisPrToExpList == null || stressTestDerivativesHisPrToExpList.size() == 0) {
			toBeExported = "No equity derivative stressed prices and volatilities found to export";
		} else {
			
			int countFuture = 0;
			int countOption = 0;
			int countInstrument = 0;
			int countRectified = 0;
			
			int lastInstrId = 0;
			String lastUndInstrType = "";
			
			Instrument instr = null;
			Instrument undInstr = null;
			
			StressTestSetup stSetup = null;
			BigDecimal volaCoeff = null;
			
			InstrIdTrascode[] instrIdTC = null;
			InstrIdTrascode[] rectifiedClassesArray = null;
			
			StressTestHistPrice stressTestCashPrToExp = null;
			
						
			// per ogni prezzo stressato da esportare vado a prendere sulla instrument il classCode che mi servir� per incrociare su intracs
			for (StressTestDerivativeHistPrice stressTestDerivativesHistPrice:stressTestDerivativesHisPrToExpList) {
				
				if (stressTestDerivativesHistPrice.getPk().getPc().equalsIgnoreCase("P")||stressTestDerivativesHistPrice.getPk().getPc().equalsIgnoreCase("C")) {
					countOption++;
				} else {
					countFuture++;
				}
				
				// cerco le info strumento solo se � cambiato l'instrId spia
				if (lastInstrId!=stressTestDerivativesHistPrice.getPk().getInstrId()) {
					
					// cerco lo strumento sull'anagrafica
					instr = instrEAO.findByPrimaryKey(stressTestDerivativesHistPrice.getPk().getInstrId());
					
					if (instr==null) {
						throw new InstrumentDataNotAvailableException(stressTestDerivativesHistPrice.getPk().getInstrId(), "No instrument found for instrId "+stressTestDerivativesHistPrice.getPk().getInstrId());
					} 
					
					
					// cerco lo strumento sottostante
					if (instr.getUndInstrId() == null) {
						throw new InstrumentDataNotAvailableException(instr.getInstrId(), "no underlying instruments defined for the equity derivative instrument");
					}
					undInstr =  instrEAO.findByPrimaryKey(instr.getUndInstrId());
						
					if (undInstr==null) {
						throw new InstrumentDataNotAvailableException(stressTestDerivativesHistPrice.getPk().getInstrId(), "No underlyng instrument found for instrId "+stressTestDerivativesHistPrice.getPk().getInstrId());
					} 
					
					if (!lastUndInstrType.equalsIgnoreCase(undInstr.getInstrType())) {
						// cerco il settings dello strumento							
						stSetup = stSetupEAO.findByPrimaryKey(undInstr.getInstrType());
					
						if (stSetup == null) {
							throw new DataNotAvailableException("No stress test setting available for instrument type " + undInstr.getInstrType());
						}
						
						volaCoeff = stSetup.getVolaCoeff();
						
						lastUndInstrType = undInstr.getInstrType();
					}
						
					//trascodifica strumento (SOLO STRUMENTI CENSITI IN PAMP)
					instrIdTC = instrTrancodeEAO.getSicInstrStoredInPamp(instr.getInstrId());
						
					// se vuota blocco altrimenti aggiungo alla lista tutti gli eventuali trascodificati relativi allo strumento di cui l'indice � sottostante
					if (instrIdTC.length == 0) {
						throw new InstrumentDataNotAvailableException(instr.getInstrId(), "No INTRACS instruments linked to this PAMP instrID");
					} 
						
					//trascodifica strumento (CERCO LE CLASSI RETTIFICATE)
					rectifiedClassesArray = instrTrancodeEAO.getRectifiedClasses(instr.getInstrId());
					
					countRectified += rectifiedClassesArray.length;
					
					/*if (rectifiedClassesArray.length == 0) {
						appIntLog.info("No INTRACS rectified instruments for PAMP instrument id "+instr.getInstrId()+" (code: "+instr.getClassCode()+")");
					}*/
						
					//recupero dalla tabella dei prezzi stressati quello relativo al sottostante
					stressTestCashPrToExp = stHPEAO.findByPrimaryKey(undInstr.getInstrId(), scenario, stId);
				
					/*if (stressTestCashPrToExp==null) {
						throw new DataNotAvailableException("No stressed price for the underlying instrument undInstrId "+undInstr.getInstrId()+" (code: "+undInstr.getClassCode()+")");
					}*/
					
					//aggiorno la variabile spia
					lastInstrId = instr.getInstrId();
					
					//incremento contatore di strumenti
					countInstrument++;
				}	
				
				//creo una nuova istanza dell'oggettone con tutto il prezzo stressato e il parametro del classcode
				//StressTestDerivativesHistPricesReadyToExp stressedDerHPReadyToExport = new StressTestDerivativesHistPricesReadyToExp(stressTestDerivativesHistPrice, instr, instrIdTC,stressTestCashPrToExp,volaCoeff);
				
				StressTestDerivativesHistPricesReadyToExp stressedDerHPReadyToExport = new StressTestDerivativesHistPricesReadyToExp(stressTestDerivativesHistPrice, instr, instrIdTC, rectifiedClassesArray, stressTestCashPrToExp,volaCoeff);
				
				//aggiungo l'oggettone al vettore
				stressTestDerivativesHistPricesReadyToExpVect.add(stressedDerHPReadyToExport);
				
				
			}
			
			String strRectClass = "";
			
			if (countRectified>0) {
				strRectClass = " and "+countRectified+" rectified classes";
			}
			
			toBeExported = (countFuture+countOption)+" stressed records ("+countFuture+" futures and "+countOption+" options) for "+countInstrument+" equity derivative instruments"+strRectClass+" are ready to be exported.";
					
		} 
		appIntLog.info(toBeExported);
		return stressTestDerivativesHistPricesReadyToExpVect;
	}
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void exportStressTest(StressTest lastStressTest, String scenario) throws Exception {
		
		String strScenario = "Increasing";
		
		if (scenario.equalsIgnoreCase("D")) {
			
			strScenario = "Decreasing";
			
		}
		
		int stId = lastStressTest.getStId();
		
		String stNote = lastStressTest.getNote();
		
		appIntLog.info("Exporting values related to stress test no. "+stId+" - "+stNote+" ("+strScenario+" scenario)");
		
		
		// prima preparo equity ed esporto
		Vector<StressTestHistPricesReadyToExp> stressTestHistPricesReadyToExpVect = this.getStressTestCashPricesReadyToExp(stId, scenario);
				
		
		if (stressTestHistPricesReadyToExpVect.size()>0) {
		
			esthpIntracsUnit.stressTestHistPriceExport(stressTestHistPricesReadyToExpVect);
		
		}
		
		
		// poi preparo derivati ed esporto
		Vector<StressTestDerivativesHistPricesReadyToExp> stressTestDerivativesHistPricesReadyToExpVect = this.getStressTestDerivativesHistPricesReadyToExp(stId, scenario);
		
		if (stressTestDerivativesHistPricesReadyToExpVect.size()>0) {
		
			esthpIntracsUnit.stressTestDerivativesHistPriceExport(stressTestDerivativesHistPricesReadyToExpVect);
		
		}
		
		
		//poi preparo gli indici ed esporto
		Vector<StressTestIndexPricesReadyToExp> stressTestIndexPricesReadyToExpVec = this.getStressTestIndexPricesReadyToExp(stId, scenario);
		
		if (stressTestIndexPricesReadyToExpVec.size()>0) {
			esthpIntracsUnit.stressTestIndexPricesExport(stressTestIndexPricesReadyToExpVec);
		}
		
		/*
		//poi preparo i Bond ed esporto
		Vector<StressTestHistPricesReadyToExp> stressTestBondsReadyToExpVec = this.getStressTestBondsReadyToExp(stId, scenario);
		
		if (stressTestBondsReadyToExpVec.size()>0) {
			esthpIntracsUnit.stressTestBondPricesExport(stressTestBondsReadyToExpVec);
		}*/
		
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void exportBondStressTest(StressTest lastStressTest, String scenario) throws Exception {
		
		String strScenario = "Increasing";
		
		if (scenario.equalsIgnoreCase("D")) {
			
			strScenario = "Decreasing";
			
		}
		
		int stId = lastStressTest.getStId();
		
		String stNote = lastStressTest.getNote();
		
		appIntLog.info("Exporting values related to stress test no. "+stId+" - "+stNote+" ("+strScenario+" scenario)");
		
		
		//preparo i Bond ed esporto
		Vector<StressTestHistPricesReadyToExp> stressTestBondsReadyToExpVec = this.getStressTestBondsReadyToExp(stId, scenario);
		
		if (stressTestBondsReadyToExpVec.size()>0) {
			esthpIntracsUnit.stressTestBondPricesExport(stressTestBondsReadyToExpVec);
		}
		
	}
	
}
