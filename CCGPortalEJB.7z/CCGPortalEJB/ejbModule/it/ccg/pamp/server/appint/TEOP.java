package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.BondClassEAOLocal;
import it.ccg.pamp.server.eao.ClassIdTrascodeEAOLocal;
import it.ccg.pamp.server.eao.InterClassOffsetHistoryEAOLocal;
import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.entities.ClassIdTrascode;
import it.ccg.pamp.server.entities.InterclassOffsetHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.utils.ClassIdTrascodePlus;
import it.ccg.pamp.server.utils.NumberOfErrorForCMCBatch;
import it.ccg.pamp.server.utils.ReadyToExpInterClassOffsetHistory;

import java.math.BigDecimal;
import java.util.List;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TEOP
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class TEOP implements  TEOPLocal {

	@EJB
	private InterClassOffsetHistoryEAOLocal clTerHisEAO ;
	
	@EJB
	private BondClassEAOLocal bondClassEAO;
	
	@EJB
	private ClassIdTrascodeEAOLocal classTrancodeEAO;

	@EJB
	private CMCLocal cmcEAO;

	@EJB
	private TEOPINTRACSUnitLocal teopIntracsUnit;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	public TEOP() {
	}
	
	@Override
	public void readIntracs() throws DataNotValidException {
				
		cmcEAO.checkClassMarginDataPAMPVsIntracs(new NumberOfErrorForCMCBatch(0));
		
		// ############################################################################
	}
	
	public Vector<ReadyToExpInterClassOffsetHistory> getInterClassOffsetHistoryReadyToExp() throws DataNotValidException, InstrumentDataNotAvailableException {

		Vector<ReadyToExpInterClassOffsetHistory> readyInterClassOffsetHistVec = new Vector<ReadyToExpInterClassOffsetHistory>();

		BigDecimal marTh = new BigDecimal(10000);
		
		
		List<InterclassOffsetHistory> clTerHisToExp = clTerHisEAO.getInterClassOffsetHistoryToExport();

		// ciclo su lista di margini storici da esportare
		for (InterclassOffsetHistory clTraHis : clTerHisToExp) {

			int classId1 = clTraHis.getPk().getClassId1();
			
			BondClass bondClass1 = bondClassEAO.findByPrimaryKey(classId1);
			
			int classId2 = clTraHis.getPk().getClassId2();
			
			BondClass bondClass2 = bondClassEAO.findByPrimaryKey(classId2);
			
			//verifico che la classe su cui sto andando ad operare effettivamente esista ancora su PMPTCLASS
			if (bondClass1==null) {
				throw new InstrumentDataNotAvailableException(classId1, "No INTRACS bond class linked to this PAMP classId");
			} else if (bondClass2==null) {
				throw new InstrumentDataNotAvailableException(classId2, "No INTRACS bond class linked to this PAMP classId");
			}	else {
				// recupero dalla tabella di transcodifica
				/*List<ClassIdTrascode> classIdTC = classTrancodeEAO.getSicClassId(classId1);
				
				if (classIdTC.size() == 0) {
					throw new InstrumentDataNotAvailableException(classId1, "No INTRACS bond class linked to this PAMP classId");
				}
				
				Vector<ClassIdTrascodePlus> classTcVect= new Vector<ClassIdTrascodePlus>();
			
				for (ClassIdTrascode classTC : classIdTC) {
					
					classTcVect.add(new ClassIdTrascodePlus(classTC));
				}*/
					
				readyInterClassOffsetHistVec.add(new ReadyToExpInterClassOffsetHistory(clTraHis, bondClass1, bondClass2/*,classTcVect*/));
			}
			
		}

		appIntLog.info(clTerHisToExp.size() + " Class Margin History ready to be exported");
		
		return readyInterClassOffsetHistVec;
	}
	

	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void export() throws Exception {
		
		//this.readIntracs();

		Vector<ReadyToExpInterClassOffsetHistory> readyInterClassOffsetHistToExp = this.getInterClassOffsetHistoryReadyToExp();

		teopIntracsUnit.exportPampInterClassOffsetHistoryToIntracs(readyInterClassOffsetHistToExp);

	}

}
