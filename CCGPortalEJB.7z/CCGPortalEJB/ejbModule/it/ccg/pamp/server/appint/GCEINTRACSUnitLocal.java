package it.ccg.pamp.server.appint;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.ReadyToExpGroupHistory;

import java.util.List;

import javax.ejb.Local;

@Local
public interface GCEINTRACSUnitLocal {
	
	public void exportPampGroupsToIntracs(List<ReadyToExpGroupHistory> readyToExpGroupHistory) throws DataNotValidException, DataNotAvailableException;
	
	public void exportPampGroupAndComponentsHistoryToIntracs(List<ReadyToExpGroupHistory> readyToExpGroupHistory) throws DataNotValidException;

}
