package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.GroupHistoryEAOLocal;
import it.ccg.pamp.server.entities.GroupHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.ReadyToExpGroupHistory;
import it.ccg.pamp.server.utils.ReadyToExpMarginHistory;

import java.util.List;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class GCEPAMPUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class GCEPAMPUnit implements  GCEPAMPUnitLocal {

	@EJB
	private GroupHistoryEAOLocal groupHistoryEAO;
	
	

	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");

    
    
	public void updateGroupHistorySentStatusAfterExport(List<ReadyToExpGroupHistory> exportedGroupHistoryList) throws DataNotValidException {
		
		int groupCount = 0;
		int disabledGroupCount = 0;
		
		int lastExportedGroupId = 0;
		
		for (ReadyToExpGroupHistory expGrHistory : exportedGroupHistoryList) {

			if (lastExportedGroupId!=expGrHistory.getGrId()) {
				
				 GroupHistory grHistory = groupHistoryEAO.findByPrimaryKey(expGrHistory.getGrId(),expGrHistory.getIniVDate());
				 grHistory.setSent("T");
				 grHistory.setUpdDate(GenericTools.systemDate());
				 grHistory.setUpdType("U"); 
				 grHistory.setUpdUsr("System");
				  
				 groupHistoryEAO.update(grHistory);
				 
				 lastExportedGroupId = expGrHistory.getGrId();
				 if (expGrHistory.getGrStatus().equalsIgnoreCase("E")) {
					 groupCount++;
				 } else {
					 disabledGroupCount++;
				 }	 
			}
		}
		
		String sentStatusUpdatedString = "Sent status updated for ";
		
		if (groupCount>0) {
			sentStatusUpdatedString += groupCount+" exported ";
			if (groupCount>1) {
				sentStatusUpdatedString +="groups";
			} else {
				sentStatusUpdatedString +="group";
			}
		} else {
			if (disabledGroupCount>0) {
				sentStatusUpdatedString += disabledGroupCount+" disabled ";
				if (disabledGroupCount>1) {
					sentStatusUpdatedString +="groups";
				} else {
					sentStatusUpdatedString +="group";
				}
			}
		}
		
		if (groupCount>0 && disabledGroupCount>0) {
			sentStatusUpdatedString += " and "+disabledGroupCount+" disabled ";
			if (disabledGroupCount>1) {
				sentStatusUpdatedString +="groups";
			} else {
				sentStatusUpdatedString +="group";
			}
		}
		
		appIntLog.info(sentStatusUpdatedString);
		

	}

}
