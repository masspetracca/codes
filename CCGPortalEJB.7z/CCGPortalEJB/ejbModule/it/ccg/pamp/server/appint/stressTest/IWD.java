package it.ccg.pamp.server.appint.stressTest;

import it.ccg.pamp.server.eao.Ipindx1EAOLocal;
import it.ccg.pamp.server.entities.Ipindx1;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.log4j.Logger;

/**
 * INDEX WEIGHT DOWNLOAD
 */
@Stateless
public class IWD implements  IWDLocal {

    @EJB private Ipindx1EAOLocal intracsIndexWeightEAO;
    @EJB private IWDPAMPUnitLocal iwdPampUnit;
    
    
    Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
    
    
    /*@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public String synchronizeAllIdxWeight() throws DataNotValidException, DataNotAvailableException {
    
    	// cerco su intracs tutti i pesi presenti
    	List<String> ipindxClassList = intracsIndexWeightEAO.findDistinctIndexClassList();
    	
    	int indexFound = 0;
    	int weightCount = 0;
    	// se non ci sono pesi su intracs avviso e fermo tutto
    	if (ipindxClassList.size()==0) {
    		
    		appIntLog.info("No index weight to download found on Clearing System");
    		return "No index weight to download found on Clearing System";
    	} else {
    		indexFound = ipindxClassList.size();
    		appIntLog.info(ipindxClassList.size()+" index to download found on Clearing system");
    		//per ogni indice presente su intracs procedo alla rimozione del corrispettivo su PAMP
    		for (String ipindxClass:ipindxClassList) {
    			
    			// vado a cercare sull'anagrafica l'instrid di quell'indice
    			if (instrumentEAO.getByClassCodeAndDivisCode(ipindxClass, "X")!=null) {
    				
    				int idxId = instrumentEAO.getByClassCodeAndDivisCode(ipindxClass, "X").getInstrId();
    			
    				// rimuovo su pamp
	    			int removedIdx = pampIndexWeightEAO.removeByIndexId(idxId);
	    			
	    			appIntLog.info("removed "+removedIdx+" weight/s for index "+ipindxClass.trim()+" on PAMP System");
	    			
	    			//cerco tutti i componenti su intracs per aggiungerli su pamp
	    			List<Ipindx1> ipIndx1List = intracsIndexWeightEAO.findByIndexClass(ipindxClass);
	    			
	    			appIntLog.info(ipIndx1List.size()+" index weight for index "+ipindxClass+" ready to download on PAMP System");
	    			
	    			for (Ipindx1 ipIndx1:ipIndx1List) {
	    				
	    				// vado a cercare sull'anagrafica l'instrid di quel componente
	    				Instrument instr = instrumentEAO.getByClassCodeAndDivisCode(ipIndx1.getpK().getXSymbl().trim(), "E");
	    				
	    				if (instr!=null) {
	    				
		    				int idxWeiInstrId = instr.getInstrId();
		    				
		    				IndexWeightPK pampIdxWeiPK = new IndexWeightPK();
		    				
		    				pampIdxWeiPK.setIdxId(idxId);
		    				pampIdxWeiPK.setInstrId(idxWeiInstrId);
		    				
		    				IndexWeight pampIdxWei = new IndexWeight();
		    				
		    				long outShare = ipIndx1.getXShare();
		    				long dividend = ipIndx1.getXShareN();
		    				
		    				pampIdxWei.setPk(pampIdxWeiPK);
		    				pampIdxWei.setDividend(dividend);
		    				pampIdxWei.setOutshare(outShare);
		    				
		    				// converto la data da int a timestamp
		    				Timestamp pampIdxWeiDate = GenericTools.convertDateFromIntToTimestamp(ipIndx1.getXADate());
		    				
		    				pampIdxWei.setDate(pampIdxWeiDate);
		    				
		    				//aggiungo su PAMP
		    				pampIndexWeightEAO.store(pampIdxWei);
		    				appIntLog.info("Downloaded index weight for index "+idxId+"("+ipindxClass.trim()+") - instrument id "+idxWeiInstrId+" (code: "+instr.getClassCode()+"), dividend: "+dividend+", outshare: "+outShare);
		    				weightCount++;
	    				} else {
	    					throw new DataNotAvailableException("Instrument "+ipIndx1.getpK().getXSymbl().trim()+" is not enabled in Pamp System");
	    				}
	    			}
    			}
    		}
    		
    		String index = "index";
    		
    		if (indexFound>1) {
    			index = "indices";
    		}
    		return weightCount+" weight rows associated to "+indexFound+" "+index+" downloaded from Clearing System to Pamp System";
    	}
    }	
    */
    
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public List<Ipindx1> getIdxWeiReadyToDownload() throws DataNotValidException, DataNotAvailableException {
    
    	// cerco su intracs tutti i pesi presenti
    	//List<String> ipindxClassList = intracsIndexWeightEAO.findDistinctIndexClassList();
    	List<Ipindx1> ipindxList = intracsIndexWeightEAO.fetch();
    	
    	int indexFound = 0;
    	int weightCount = 0;
    	
    	// se non ci sono pesi su intracs avviso e fermo tutto
    	if (ipindxList.size()==0) {
    		appIntLog.info("No index weight to download found on Clearing System");
    	} else {
    		
    		appIntLog.info(ipindxList.size()+" index components ready to be downloaded from Clearing system to Pamp");
    		
    	}
    	return ipindxList;
    }	
    
    
    
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void indexDownload() throws Exception {
		
		List<Ipindx1> readyIndexWeightsToDownload = this.getIdxWeiReadyToDownload();

		if (readyIndexWeightsToDownload.size()>0) {
		
			iwdPampUnit.importIntracsIdxWeights(readyIndexWeightsToDownload);
		}

	}
    
}
