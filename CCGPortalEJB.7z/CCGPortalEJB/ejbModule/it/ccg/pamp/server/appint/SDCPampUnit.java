package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.BondClassEAOLocal;
import it.ccg.pamp.server.eao.BondHistoryClassEAOLocal;
import it.ccg.pamp.server.eao.InstrtypeTranscodeEAOLocal;
import it.ccg.pamp.server.eao.InstrumentEAOLocal;
import it.ccg.pamp.server.eao.MarketEAOLocal;
import it.ccg.pamp.server.eao.MarketTrascodeEAOLocal;
import it.ccg.pamp.server.eao.RiskCommitteeEAOLocal;
import it.ccg.pamp.server.entities.BondHistoryClass;
import it.ccg.pamp.server.entities.Cgcls00f;
import it.ccg.pamp.server.entities.InstrtypeTranscode;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.MarketTrascode;
import it.ccg.pamp.server.entities.RiskCommittee;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BatchMapUtility;
import it.ccg.pamp.server.utils.BondToSync;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.OeKBSubTypeMap;
import it.ccg.pamp.server.utils.PampInstrument;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;
import org.apache.openjpa.lib.log.Log;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class SDCPampUnit implements  SDCPampUnitLocal {

	@EJB
	private InstrtypeTranscodeEAOLocal pampinstrTypeTrancodeEAO;

	@EJB
	private InstrumentEAOLocal pampinstrEAO;
	
	@EJB
	private RiskCommitteeEAOLocal riskcomEAO;

	@EJB
	private MarketEAOLocal marketEAO;
	
	@EJB
	private BondHistoryClassEAOLocal bondHistoryClassEAO;
	
	@EJB
	private MarketTrascodeEAOLocal marketTrascodeEAO;
	
	@EJB
	private BondClassEAOLocal bondClassEAO;

	//private final LinkedHashMap<String><String> instrTypeMap = 
	
	private final Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");

	private final String choosenDivisCode = "E";
	
	final LinkedHashMap<String,String> subTypeTrascodedMap = OeKBSubTypeMap.trascodedSubTypeMap();
	
	
	public String upsertInstrumentsOnPamp(List<Cgcls00f> cgcls00fList, LinkedHashMap<String, String> tfForxMap, String marketCode) throws DataNotValidException, DataNotAvailableException {

		
		// strumenti che sono su PMPTINSTR
		List<Instrument> pampInstrumentList = pampinstrEAO.getAllByDivisCode(choosenDivisCode);

		// disabilito tutti
		// pampinstrEAO.updateStatusToDisable(choosenDivisCode);

		// popolo una hashmap contenente gli instrid degli strumenti presenti
		// sulla pamp ed indicizzata tramite classcode ed instrtype dello
		// strumento
		LinkedHashMap<String, PampInstrument> pmpinstrhashmap = new LinkedHashMap<String, PampInstrument>();

		// scorro sugli strumenti PAMP
		for (Instrument pampInstrument : pampInstrumentList) {
			
			pmpinstrhashmap.put(pampInstrument.getClassCode() + "|" + pampInstrument.getInstrType(), new PampInstrument(pampInstrument.getInstrId(), false));

		}

		// parametri RE da memorizzare
		String reClassCode = "";
		String reInstrType = "";
		String reDesc = "";
		// String reDivisCode = "E";
		String reCurrency = "";
		String reIsinCode = "";
		BigDecimal reMult = null;
		int reDaysToSettle = 0;

		// CFI code per Austria
		String reCFICode = "";
		String reSubType = "";
		String reSegment = "";
		
		// String reNotFoundString = "";

		int reInstrumentNumber = cgcls00fList.size();
		int reInstrNotFoundInPAMP = 0;
		String strREinstrFoundInPAMP = "";

		RiskCommittee riskcom  = riskcomEAO.findLast();
		
		if (riskcom==null) {
			appIntLog.warn("No motivation to be assigned to the instruments found.");
		} else {
			appIntLog.info("All new instruments will be sinchronized setting the last risk committee found: "+riskcom.getRcDesc());
		}
		
		
		// scorro tutti gli strumenti del RISK ENGINE
		for (Cgcls00f cgcls00f : cgcls00fList) {

			// parametri RISK ENGINE da usare per la ricerca e l'eventuale
			// inserimento su PAMP
			reClassCode = cgcls00f.getPk().getCclass();
			reInstrType = cgcls00f.getCptype();
			reDesc = cgcls00f.getCdesc();
			reCurrency = cgcls00f.getCcur();
			reIsinCode = cgcls00f.getCucusp();
			reDaysToSettle = cgcls00f.getCodays();
			reMult = cgcls00f.getCmultf();
						
			reCFICode = cgcls00f.getCnsym();
			
			String process = "F";
			
			//verifico la consistenza del CFICode per verificare se le prime due lettere del CFI code corrispondono ad uno strumento di tipo Equity
			if (reCFICode.length()>2) {
				if (OeKBSubTypeMap.cfiCodeList.contains(reCFICode.substring(0,2))) { 
					process = "T";
				}
				//metto da parte il CFICode per trascodificarlo
				reSubType = reCFICode.substring(0,2);
			}
			
			//subtype di default
			String pampSubType = "A";
			
			//appIntLog.info("Subtype set to default value: "+pampSubType);
			
			//appIntLog.info("Starting to search the trascoded value for the original value: "+reSubType);
			
			//cerco nella mappa di trascodifica dei Subtype a quale subtype PAMP corrisponde il valore in ingresso
			if (!(subTypeTrascodedMap.get(reSubType)==null || subTypeTrascodedMap.get(reSubType).equalsIgnoreCase(""))) {
				
				pampSubType = subTypeTrascodedMap.get(reSubType);
				
				appIntLog.info("Instrument subtype transcoded from value \""+reSubType+"\" to value \""+pampSubType+"\"");
			}
			
			//appIntLog.info("Transcoding ended");
			
			/*
			//lista mercati trascodificati
			List<MarketTrascode> marketTrascodeList = new ArrayList<MarketTrascode>();
			
			//se il mercato INTRACS dello strumento che sto scorrendo � diverso dall'ultimo trovato allora effettuo una nuova trascodifica del nome del mercato
			//per prendere quello corretto su PAMP
			//marketTrascodeList = marketTrascodeEAO.getMarketTrsCodeBySicMarketCode(cgcls00f.getCexch1().toString());
			
			if (marketTrascodeList!=null) {
			
				for (MarketTrascode mktTrsc:marketTrascodeList) {
					if (marketEAO.findByPrimaryKey(mktTrsc.getPk().getMarketCode()) == null) {
						throw new DataNotAvailableException("Risk engine market " + mktTrsc.getPk().getSicMarket() + " is not available on Pamp, please check.");
					}
					lastMarket = cgcls00f.getCexch1().toString();
				}
			}*/
			
			//TODO
			/*if (marketEAO.findByPrimaryKey(cgcls00f.getCexch1().toString()) == null) {
				throw new DataNotAvailableException("Risk engine market " + cgcls00f.getCexch1().toString() + " is not available on Pamp, please check.");
			}*/
		

			String reCurrencyMap = tfForxMap.get(reCurrency);

			//controllo valuta
			if (reCurrencyMap != null) {
				reCurrency = reCurrencyMap;
			} else {
				throw new DataNotAvailableException("Transcoded currency not found for Risk Engine currency " + reCurrency);
			}

			// trascodifica tipo strumento
			InstrtypeTranscode trsCodedInstrType = pampinstrTypeTrancodeEAO.getSingleTrsCodeBySicInstrType(reInstrType);

			if (trsCodedInstrType == null) {
				throw new DataNotAvailableException("No transcoded instrument type found for Risk Engine instrument type " + reInstrType);
			}

			String trsInstrType = trsCodedInstrType.getPk().getInstrType();
			if (trsInstrType == null)
				throw new DataNotValidException("Instrument type transcode not available for type: " + reInstrType);

			// INSTR.TYPE del risk engine non deve essere diverso da E (equity) e B (bond) NB: Bond non � pi� utilizzato 
			if ( ! (reInstrType.equalsIgnoreCase("E") || reInstrType.equalsIgnoreCase("B")) ) {
				// REDivisCode = "D";
				throw new DataNotValidException("Derivative instrument not accepted in this phase");
			}

			if (cgcls00f.getClpres()!=null) {
				reSegment = cgcls00f.getClpres();
			}
			
			
			
			
			// new Instrument instance to use into INSERT or UPDATE procedure
			Instrument instr = new Instrument();

			// search the source instrument (RISK Engine) into the hash map containing PAMP instruments
			PampInstrument pmpinstr = pmpinstrhashmap.get(reClassCode + "|" + trsInstrType);

			// if the instance is NOT null, then the Risk Engine record has been matched in PAMP System
			// the correct operation is UPDATE
			if (pmpinstr != null) {
				
				// set a flag to identify the record as being on Risk Engine
				pmpinstr.setOnRiskEng(true);

				instr = pampinstrEAO.findByPrimaryKey(pmpinstr.getInstrID());

				if (instr == null)
					throw new DataNotAvailableException("INSTRID " + pmpinstr.getInstrID() + ": No financial instruments related to the instrument ID");

				//The operation has not effect to the STATUS field
				
				//instr.setStatus("E");
				instr.setInstrName(reDesc);
				instr.setDelDays(Integer.toString(reDaysToSettle));
				instr.setIsinCode(reIsinCode);
				instr.setCurrency(reCurrency);
				instr.setMult(reMult);
				
				instr.setInstrType(trsInstrType);
				instr.setInstrStype(pampSubType);
				
				instr.setSgmCode(reSegment);
				
				// nuova modifica austria 02/07
				instr.setBloombCode(reCFICode);
				
				instr.setProcess(process);
				
				instr.setUpdType("U");
				instr.setUpdDate(GenericTools.systemDate());
				instr.setUpdUsr("System");

				appIntLog.info("Risk Engine instrument having code " + reClassCode + " and type " + reInstrType + " FOUND in PAMP: Pamp instrument synchronized and enabled");
			}
			// else it means Risk Engine doesn't exist and it have to be created as new in PAMP
			// the correct operation is UPDATE
			else {

				reInstrNotFoundInPAMP++;
				appIntLog.info("Risk Engine instrument having code " + reClassCode + " and type " + reInstrType + " NOT FOUND in PAMP: new instrument created in Pamp system");
				// lo devo aggiungere usando i valori di RE e valori di default
				// per tutte quelle colonne non coperte da RE
				instr.setInstrName(reDesc);
				instr.setClassCode(reClassCode);
				instr.setDelDays(Integer.toString(reDaysToSettle));
				instr.setIsinCode(reIsinCode);
				instr.setDivisCode("E");
				instr.setInstrType(trsInstrType);
				instr.setInstrStype(pampSubType);
				instr.setCurrency(reCurrency);
				instr.setDerHist("F");
				instr.setMult(reMult);
				instr.setStatus("E");
				instr.setSgmCode(reSegment);
				
				// nuova modifica austria 02/07
				instr.setBloombCode(reCFICode);
				instr.setProcess(process);
				
				if(riskcom!=null){
					instr.setRcCode(riskcom.getRcCode());
				}
				
				
				instr.setMarketCode(marketCode);

				pampinstrEAO.store(instr);

			}
		}

		// alla fine del ciclo degli strumenti del riskengine
		Collection<PampInstrument> pampinstrcoll = pmpinstrhashmap.values();

		Instrument instr = new Instrument();
		// gli strumenti della hashmap che non sono stati coinvolti nel ciclo
		// precedente vanno disabilitati
		// in quanto non essendo su risk engine non vanno usati
		for (PampInstrument pmpins : pampinstrcoll) {

			if (!pmpins.isOnRiskEng()) {
				instr = pampinstrEAO.findByPrimaryKey(pmpins.getInstrID());

				if (instr == null)
					throw new DataNotAvailableException("INSTRID " + pmpins.getInstrID() + ": No financial instruments related to the instrument ID");

				if (!instr.getStatus().equalsIgnoreCase("D")) {
					instr.setStatus("D");

					instr.setUpdType("U");
					instr.setUpdDate(GenericTools.systemDate());
					instr.setUpdUsr("System");

					appIntLog.info("Pamp instrument having InstrID "+pmpins.getInstrID()+" NOT FOUND among the Risk Engine instruments will be UPDATED TO DISABLED");
				}
				else{
					
					appIntLog.info("Pamp instrument having InstrID "+pmpins.getInstrID()+" NOT FOUND among the Risk Engine instruments was ALREADY DISABLED and will NOT be UPDATED");
					
				}

			}

		}

		// appIntLog.info("Risk Engine-PAMP synchronization procedure successfully completed");

		int reInstrFoundInPAMP = reInstrumentNumber - reInstrNotFoundInPAMP;

		// parte riepilogativa con conteggi di tutti i confronti effettuati
		String returnString = "";
		if (reInstrFoundInPAMP == 0) {
			returnString = "No Risk Engine financial instruments contained in PAMP instrument table; ";
		} else {
			returnString = reInstrFoundInPAMP + " of " + reInstrumentNumber + " financial instruments contained both in Risk Engine and PAMP tables have been synchronized; ";
		}

		if (reInstrNotFoundInPAMP != 0) {
			returnString += reInstrNotFoundInPAMP + " of " + reInstrumentNumber + " financial instruments contained in Risk Engine but not in PAMP have been created";
		} else {
			returnString += "all Risk Engine financial instruments contained in PAMP instrument table";
		}
		// appIntLog.info(returnString);

		return returnString;

	}
	
	public String upsertBondInstrumentsOnPamp(List<BondToSync> bondToSyncList) throws DataNotValidException, DataNotAvailableException {

		//appIntLog.info(bondToSyncList.size()+" bond instruments found on RE System");
		
		// strumenti che sono su PMPTINSTR
		List<Instrument> pampInstrumentList = pampinstrEAO.getAllByDivisCode("O");

		// disabilito tutti
		// pampinstrEAO.updateStatusToDisable(choosenDivisCode);

		// popolo una hashmap contenente gli instrid degli strumenti presenti
		// sulla pamp ed indicizzata tramite isinCode ed instrsubtype dello
		// strumento
		LinkedHashMap<String, PampInstrument> pmpinstrhashmap = new LinkedHashMap<String, PampInstrument>();

		// scorro sugli strumenti PAMP
		for (Instrument pampInstrument : pampInstrumentList) {

			pmpinstrhashmap.put(pampInstrument.getIsinCode() + "|" + pampInstrument.getInstrStype(), new PampInstrument(pampInstrument.getInstrId(), false));

		}

		String reClassId = "";
		
		// String reNotFoundString = "";

		int reInstrumentNumber = 0;
		int reInstrNotFoundInPAMP = 0;
		
		RiskCommittee riskcom  = riskcomEAO.findLast();
		
		String lastIsinCode = "";
		
		LinkedHashMap<String,Instrument> classIdZeroMap = new LinkedHashMap<String, Instrument>();
		
		// scorro tutti gli strumenti del RISK ENGINE
		for (BondToSync bondToSync : bondToSyncList) {

			if (!bondToSync.getIsinCode().equalsIgnoreCase(lastIsinCode)) {
				
				lastIsinCode = bondToSync.getIsinCode();
				
				boolean changeBondHistoryClass = false;
				
				reClassId = bondToSync.getBndClassId();
				
				//se l'oggetto da sincronizzare ha un numero di classe valido e quella classe � esistente nella tabelle delle classi PAMP  
				if (!reClassId.equalsIgnoreCase("") && bondClassEAO.findByPrimaryKey(Integer.parseInt(reClassId))!=null) {
				
					reInstrumentNumber++;
					
					Instrument instr = new Instrument();
					
					if (marketEAO.findByPrimaryKey(bondToSync.getMarket()) == null) {
						throw new DataNotAvailableException("Market " + bondToSync.getMarket() + " not available on Pamp, please check.");
					}
					
					// cerco lo strumento del RISK Engine sulla hashmap contenente gli
					// strumenti della pamp
					PampInstrument pmpinstr = pmpinstrhashmap.get(bondToSync.getIsinCode() + "|" + bondToSync.getInstrSubType());
		
					// se questo � diverso da null vuol dire che lo strumento del risk
					// engine � presente sulla PAMP
					// e quindi procedo all'update
					if (pmpinstr != null) {
						// setto che questo elemento � presente su risk engine
						pmpinstr.setOnRiskEng(true);
		
						instr = pampinstrEAO.findByPrimaryKey(pmpinstr.getInstrID());
		
						if (instr == null)
							throw new DataNotAvailableException("INSTRID " + pmpinstr.getInstrID() + ": No financial instruments related to the instrument ID");
						
						instr.setInstrName(bondToSync.getDescription());
						instr.setCurrency(bondToSync.getCurrency());
						instr.setDivType(bondToSync.getCouponType());
						instr.setExpiry(bondToSync.getExpiry());
						instr.setCoupFreq(new BigDecimal(bondToSync.getCouponFreq()));
						instr.setYield(bondToSync.getCouponInterest());
						instr.setCoupNextDt(bondToSync.getCoupNextDate());
						instr.setDuration(bondToSync.getDuration());
						
						// se l'ultima classe dello strumento � diversa dalla nuova
						if (instr.getBndClassId()!=Integer.parseInt(reClassId))
							changeBondHistoryClass = true;
						
						instr.setBndClassId(Integer.parseInt(reClassId));
						instr.setMarketCode(bondToSync.getMarket());
						instr.setClassCode(bondToSync.getIsinCode());
						instr.setIsinCode(bondToSync.getIsinCode());
						instr.setStatus("E");
						instr.setDelDays(Integer.toString(0));
						instr.setMult(bondToSync.getLastPrice());
						
						// data di riferimento duration
						instr.setMktLstDate(bondToSync.getDurRefDate());
											
						instr.setUpdType("U");
						instr.setUpdDate(GenericTools.systemDate());
						instr.setUpdUsr("System");
						
						if (Integer.parseInt(reClassId)==0)
							classIdZeroMap.put(lastIsinCode,instr);
						
						appIntLog.info("Risk Engine instrument having isinCode: "+bondToSync.getIsinCode()+", code " + bondToSync.getIsinCode() + " and type " + instr.getInstrType() + " (class: "+instr.getBndClassId()+") FOUND in PAMP: Pamp instrument synchronized and enabled");
					}
					// altrimenti dovr� creare sulla pamp lo strumento contenuto nel
					// RISK engine
					else {
		
						reInstrNotFoundInPAMP++;
						appIntLog.info("Risk Engine instrument having isinCode: "+bondToSync.getIsinCode() + " and type " + bondToSync.getInstrType() + " (class: "+bondToSync.getBndClassId()+") NOT FOUND in PAMP: new instrument created in Pamp system");
						// lo devo aggiungere usando i valori di RE e valori di default
						// per tutte quelle colonne non coperte da RE
	
						instr.setInstrName(bondToSync.getDescription());
						instr.setCurrency(bondToSync.getCurrency());
						instr.setDivType(bondToSync.getCouponType());
						instr.setExpiry(bondToSync.getExpiry());
						instr.setCoupFreq(new BigDecimal(bondToSync.getCouponFreq()));
						instr.setYield(bondToSync.getCouponInterest());
						instr.setCoupNextDt(bondToSync.getCoupNextDate());
						instr.setDuration(bondToSync.getDuration());
						
						//Controllo rimosso perch� essendo uno strumento totalmente nuovo non ha 
						//una classe di appartenenza quindi va per frza scritto il record del cambiamento classe.
						//if (instr.getBndClassId()!=Integer.parseInt(reClassId))
						changeBondHistoryClass = true;
						
						instr.setBndClassId(Integer.parseInt(reClassId));
						instr.setMarketCode(bondToSync.getMarket());
						instr.setClassCode(bondToSync.getIsinCode());
						instr.setIsinCode(bondToSync.getIsinCode());
						instr.setStatus("E");
						instr.setDelDays(Integer.toString(0));
						instr.setMult(bondToSync.getLastPrice());
						instr.setInstrType(bondToSync.getInstrType());
						instr.setInstrStype(bondToSync.getInstrSubType());
						
						// data di riferimento duration
						instr.setMktLstDate(bondToSync.getDurRefDate());
	
						if (bondToSync.getInstrSubType().equalsIgnoreCase("BTPi")) {
							instr.setDivisCode("I");
						} else {
							instr.setDivisCode("O");
						}
						
						instr.setDerHist("F");
						
						
						
						if(riskcom!=null){
							instr.setRcCode(riskcom.getRcCode());
						}
						
						if (Integer.parseInt(reClassId)==0)
							classIdZeroMap.put(lastIsinCode,instr);
						
						pampinstrEAO.store(instr);
		
					}
					
					//se la classe � cambiata scrivo sulla tabella dello storico delle classi per memorizzare il cambiamento
					if (changeBondHistoryClass) {
						//vedo se esiste gi� un cambio classe per quel giorno						
						BondHistoryClass bondHistoryClass = bondHistoryClassEAO.findByPrimaryKey(instr.getInstrId(), GenericTools.systemDateMidNight());
						
						appIntLog.info("Updating class history for isinCode: "+bondToSync.getIsinCode() +"(instrId "+instr.getInstrId()+ ") and type " + bondToSync.getInstrType() + " - new class: "+bondToSync.getBndClassId()+"; duration: "+bondToSync.getDuration());
						
						//se esiste faccio l'update per quella riga (cos� evito la chiave duplicata)
						if (bondHistoryClass!=null) {
							bondHistoryClass.setClassId(instr.getBndClassId());
							bondHistoryClass.setDuration(instr.getDuration());
						} else {
							bondHistoryClassEAO.add(instr.getInstrId(), GenericTools.systemDateMidNight(), instr.getDuration(), instr.getBndClassId());
						}
					}
					
				} else {
					String log = "Unable to synchronize the code "+bondToSync.getIsinCode();
					if (reClassId.equalsIgnoreCase("")) {
						log += " because it doesn't belong to any class on RE system";
					} else {
						log += " because it belongs to the class "+reClassId+" that is not present on PAMP system";						
					}
					
					appIntLog.info(log);
					//throw new DataNotAvailableException("Bond Class "+reClassId+" not present on PAMP system");
				}
			}
		}

		// alla fine del ciclo degli strumenti del riskengine
		Collection<PampInstrument> pampinstrcoll = pmpinstrhashmap.values();

		Instrument instr = new Instrument();
		// gli strumenti della hashmap che non sono stati coinvolti nel ciclo
		// precedente vanno disabilitati
		// in quanto non essendo su risk engine non vanno usati
		for (PampInstrument pmpins : pampinstrcoll) {

			if (!pmpins.isOnRiskEng()) {
				instr = pampinstrEAO.findByPrimaryKey(pmpins.getInstrID());

				if (instr == null)
					throw new DataNotAvailableException("INSTRID " + pmpins.getInstrID() + ": No financial instruments related to the instrument ID");

				if (!instr.getStatus().equalsIgnoreCase("D")) {
					instr.setStatus("D");

					instr.setUpdType("U");
					instr.setUpdDate(GenericTools.systemDate());
					instr.setUpdUsr("System");

					appIntLog.info("Pamp instrument having InstrID "+pmpins.getInstrID()+" NOT FOUND among the Risk Engine instruments will be UPDATED TO DISABLED");
				}
				else{
					
					appIntLog.info("Pamp instrument having InstrID "+pmpins.getInstrID()+" NOT FOUND among the Risk Engine instruments was ALREADY DISABLED and will NOT be UPDATED");
					
				}

			}

		}

		// appIntLog.info("Risk Engine-PAMP synchronization procedure successfully completed");

		String returnString = "";
		
		if (reInstrumentNumber>0) {
		
			int reInstrFoundInPAMP = reInstrumentNumber - reInstrNotFoundInPAMP;
	
			// parte riepilogativa con conteggi di tutti i confronti effettuati
			
			if (reInstrFoundInPAMP == 0) {
				returnString = "No Risk Engine financial instruments contained in PAMP instrument table; ";
			} else {
				returnString = reInstrFoundInPAMP + " of " + reInstrumentNumber + " financial instruments contained both in Risk Engine and PAMP tables have been synchronized; ";
			}
	
			if (reInstrNotFoundInPAMP != 0) {
				returnString += reInstrNotFoundInPAMP + " of " + reInstrumentNumber + " financial instruments contained in Risk Engine but not in PAMP have been created";
			} else {
				returnString += "all Risk Engine financial instruments were just contained in PAMP instrument table";
			}
		} else {
			
			returnString = "No instruments found to synchronize from Risk Engine to PAMP";
			
		}
		
		
		String classIdZeroString = "";
		

		if (classIdZeroMap.size()>0) {
			classIdZeroString = "\nNOTE: the following instruments have been assigned to class 0, as is on the Remote System: ";
			
			Set<String> isinCodeSet = classIdZeroMap.keySet();
			
			for (String isin:isinCodeSet)
				classIdZeroString += "\n"+isin;
			
			classIdZeroString += "\nPlease manually update these records on Pamp Static Data panel.";
			
			returnString += classIdZeroString;
		}
		
		
		return returnString;

	}
	
	
}
