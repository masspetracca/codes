package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.Mtsmgnf91fEAOLocal;
import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.entities.ClassIdTrascode;
import it.ccg.pamp.server.entities.ClassMarginHistory;
import it.ccg.pamp.server.entities.IntraclassOffsetHistory;
import it.ccg.pamp.server.entities.Mtsmgnf90f;
import it.ccg.pamp.server.entities.Mtsmgnf91f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.exceptions.LargeThresoldMarginException;
import it.ccg.pamp.server.utils.ClassIdTrascodePlus;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.ReadyToExpClassMarginHistory;
import it.ccg.pamp.server.utils.ReadyToExpIntraClassOffsetHistory;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TAOPINTRACSUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class TAOPINTRACSUnit implements  TAOPINTRACSUnitLocal {

	@EJB
	private Mtsmgnf91fEAOLocal mtsmgnf91fEAO;
		
	@EJB
	private TAOPPAMPUnitLocal taopPamp;

	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void exportPampIntraClassOffsetHistoryToIntracs(Vector<ReadyToExpIntraClassOffsetHistory> readyIntraClassOffsetHistVec) throws DataNotValidException, InstrumentDataNotAvailableException, LargeThresoldMarginException {
		
		MathContext mc=new MathContext(4, RoundingMode.HALF_EVEN);
		
		for (ReadyToExpIntraClassOffsetHistory readyIntraClassOffsetHist : readyIntraClassOffsetHistVec) {

			IntraclassOffsetHistory clTraHis = readyIntraClassOffsetHist.getClTraHist();

			BondClass bndClass = readyIntraClassOffsetHist.getBondClass();
			
			
			// Recupero la soglia massima di variazione del margine ammessa
			//TODO mettere campo su PMPTCLASS
			BigDecimal offsetTh = new BigDecimal(10000);
			
			// Recupero l'offset proposto di una classe pronto x l'export
			BigDecimal propOffset = clTraHis.getOff();
			

			Vector<ClassIdTrascodePlus> classIdTCplus = readyIntraClassOffsetHist.getClassTcPlusVec();

			for (ClassIdTrascodePlus classTCplus : classIdTCplus) {
				
				ClassIdTrascode classTC = classTCplus.getClTrascode();
				
				//conversione necessaria perch� il campo su quella tabella � di tipo stringa
				String sicClassId = classTC.getPk().getSicClassId();//Integer.toString(clMarHis.getPk().getClassId());
				String pampClassId = Integer.toString(classTC.getPk().getClassId());
				
				
				//cerco per chiave sulla mtsmgnf91fEAO passando il classId
				Mtsmgnf91f mts = mtsmgnf91fEAO.findByPrimaryKey(Integer.parseInt(sicClassId));
				
				
				// se c'� un record x quella classe procedo con l'export
				if (mts != null) {
					// vecchio intra offset su intracs
					BigDecimal oldOffset = mts.getF91intridp();
					
					//margin coeff x il quale moltiplicare il nostro proposto
					//BigDecimal marginCoef=classTC.getMarCf();
					
					//intra offset proposto che effettivamente sar� esportato
					BigDecimal roundedPropOffset = propOffset.round(mc);//multiply(marginCoef,mc);
					
					// delta per comparazione con la soglia massima di tolleranza
					BigDecimal delta = this.getDelta(oldOffset, roundedPropOffset);

					// se il delta <= della soglia stabilita per quella classe
					// procedo all'update

					if (offsetTh==null || offsetTh.compareTo(delta)>=0) {
						
						appIntLog.info("Export bond intraclass offset values for classId:" + pampClassId + " (classDesc: " + bndClass.getClassDesc()+ ") - VALUES: Old bond intraclass offset: " + oldOffset
								+ "; New bond intraclass offset: " + roundedPropOffset);
						
						//setto il nuovo offset
						mts.setF91intridp(roundedPropOffset);
						
					} else {
						String deltaPerc = GenericTools.percentValue(delta, new MathContext(4));
						String marThPerc = GenericTools.percentValue(offsetTh, new MathContext(4));
						throw new LargeThresoldMarginException(clTraHis.getPk().getClassId(), bndClass.getClassDesc(), oldOffset, propOffset, deltaPerc, marThPerc,"O");
					}

				}
				//se invece non ci sono record scateno un eccezione
				else {

					throw new InstrumentDataNotAvailableException(classTC.getPk().getClassId(), "No bond intraclass offsets available on the Clearing system for class Id: " + classTC.getPk().getClassId()
							+ " (classDesc: " + bndClass.getClassDesc().trim()+ ")");

				}

			}

		}

		appIntLog.info(readyIntraClassOffsetHistVec.size() + " bond intraclass offset history exported to INTRACS");
		
		//update dello status dei margini su PMPTCLMARH
		taopPamp.updateIntraClassOffsetHistorySentStatusAfterExport(readyIntraClassOffsetHistVec);

	}
	
	@TransactionAttribute(TransactionAttributeType.NEVER)
	public BigDecimal getDelta(BigDecimal oldOffset, BigDecimal propOffset) {
		BigDecimal delta = (oldOffset.subtract(propOffset)).divide(oldOffset,8,RoundingMode.HALF_EVEN);
		return delta.abs();
	}

}
