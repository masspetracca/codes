package it.ccg.pamp.server.appint;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface IRDLocal {
	public String transferInterestRate() throws DataNotValidException;
	public void transferInterestRate(Instrument instr, Integer total, Integer failed, Integer updated) throws DataNotValidException;
}
