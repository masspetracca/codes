package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.Ccgdur00fEAOLocal;
import it.ccg.pamp.server.eao.Cgcls00fEAOLocal;
import it.ccg.pamp.server.eao.MarketEAOLocal;
import it.ccg.pamp.server.eao.TlForx1EAOLocal;
import it.ccg.pamp.server.entities.Cgcls00f;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.utils.BondToSync;

import java.util.LinkedHashMap;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;




/*#############################################################################
#########################STATIC DATA CONSISTENCY CHECK#########################
##############################################################################*/
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class SDC implements  SDCLocal {
	
	/*@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;*/

	/*@EJB
	private InstrtypeTranscodeEAOLocal instrTypeTrancodeEAO;
	*/
	@EJB
	private Cgcls00fEAOLocal cgcls00fEAO ;
	
	@EJB
	private Ccgdur00fEAOLocal ccgDur00fEAO;
	
	/*@EJB
	private InstrumentEAOLocal instrEAO;
	*/
	@EJB
	private TlForx1EAOLocal tfForxEAO;
	
	/*@EJB
	private InstrumentEAOLocal pampinstrEAO;
	*/
	
	@EJB
	private MarketEAOLocal marketEAO;
	
	@EJB
	SDCPampUnitLocal sdcpmpunit;
	
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");

	

	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public String starter() throws Exception {
		
		String returnString = "";
		
		//salvo la lista di strumenti da sincronizzare dal RE
		List<Cgcls00f> cgcls00fList = cgcls00fEAO.getCgcls00fForSync();
		
		if (cgcls00fList.size()==0) {
		
			returnString = "No Risk Engine instrument found";
			
		} else {
			
			if (marketEAO.findLastMarket()==null) {
				throw new DataNotAvailableException("No market exists on PAMP - Please create at least one market before starting the synchronization");
			} else {
			
				//mappa valute
				LinkedHashMap<String,String> tfForxMap = tfForxEAO.transcodeCurrency();
				
				//lancio sync
				returnString = sdcpmpunit.upsertInstrumentsOnPamp(cgcls00fList, tfForxMap,marketEAO.findLastMarket().getMarketCode());
			}
		}
		
		appIntLog.info(returnString);
		
		return returnString;
		
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public String startBondSync() throws Exception {
		
		String returnString = "";
		
		List<BondToSync> bondToSyncList = ccgDur00fEAO.getBondToSync();
		
		if (bondToSyncList.size()==0) {
		
			returnString = "No Risk Engine bond instrument found";
			
		} else {
			//CurrencyTrascode currTrscode= new CurrencyTrascode();
			//LinkedHashMap<String,String> tfForxMap = currTrscode.getCurrencyHashMap();
			//LinkedHashMap<String,String> tfForxMap = tfForxEAO.transcodeCurrency();
			returnString = sdcpmpunit.upsertBondInstrumentsOnPamp(bondToSyncList);
		}
		
		appIntLog.info(returnString);
		
		return returnString;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
