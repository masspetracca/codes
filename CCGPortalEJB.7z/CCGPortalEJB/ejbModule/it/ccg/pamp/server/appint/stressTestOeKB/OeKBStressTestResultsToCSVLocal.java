package it.ccg.pamp.server.appint.stressTestOeKB;
import java.io.File;

import javax.ejb.Local;

@Local
public interface OeKBStressTestResultsToCSVLocal  {
	
	public File createCsvFile() throws Exception;

}
