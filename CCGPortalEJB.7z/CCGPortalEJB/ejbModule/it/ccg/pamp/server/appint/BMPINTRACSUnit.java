package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.Mtsmgnf90fEAOLocal;
import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.entities.ClassMarginHistory;
import it.ccg.pamp.server.entities.Mtsmgnf90f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.exceptions.LargeThresoldMarginException;
import it.ccg.pamp.server.utils.ClassIdTrascodePlus;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.ReadyToExpClassMarginHistory;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BMPIntracsUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class BMPINTRACSUnit implements  BMPINTRACSUnitLocal {

	@EJB
	private Mtsmgnf90fEAOLocal mtsmgnf90fEAO;
		
	@EJB
	private BMPPAMPUnitLocal bmpPamp;

	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	final MathContext mc=new MathContext(8, RoundingMode.HALF_EVEN);

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void exportPampClassMarginHistoryToIntracs(Vector<ReadyToExpClassMarginHistory> readyClassMarHistVec) throws DataNotValidException, InstrumentDataNotAvailableException, LargeThresoldMarginException {
		
		
		
		for (ReadyToExpClassMarginHistory readyClassMarHist : readyClassMarHistVec) {

			ClassMarginHistory clMarHis = readyClassMarHist.getClMarHist();

			BondClass bndClass = readyClassMarHist.getBondClass();
			
			
			// Recupero la soglia massima di variazione del margine ammessa
			//TODO mettere campo su PMPTCLASS????
			BigDecimal marTh = new BigDecimal(10000);
			
			// Recupero il margine proposto di una classe pronto x l'export
			BigDecimal propMar = clMarHis.getMargin();
			

			Vector<ClassIdTrascodePlus> classIdTCplus = readyClassMarHist.getClassTcPlusVec();

			/*for (ClassIdTrascodePlus classTCplus : classIdTCplus) {
				
				ClassIdTrascode classTC = classTCplus.getClTrascode();
			*/	
				//conversione necessaria perch� il campo su quella tabella � di tipo stringa
				String sicClassId = Integer.toString(bndClass.getClassId());//classTC.getPk().getSicClassId();
				String pampClassId = Integer.toString(bndClass.getClassId());//Integer.toString(classTC.getPk().getClassId());
				
				
				//cerco per chiave sulla mtsmgnf90fEAO passando il classId
				//Mtsmgnf90f mts = mtsmgnf90fEAO.findByPrimaryKey(clMarHis.getPk().getClassId());
				Mtsmgnf90f mts = mtsmgnf90fEAO.findByPrimaryKey(Integer.parseInt(sicClassId));
				
				
				// se c'� un record x quella classe procedo con l'export
				if (mts != null) {
					// vecchio margine su intracs
					BigDecimal oldMar = mts.getF90inmargi();
					
					//margin coeff x il quale moltiplicare il nostro proposto
					//BigDecimal marginCoef=classTC.getMarCf();
					
					//margine proposto che effettivamente sar� esportato
					BigDecimal roundedPropMar = propMar.round(mc);//propMar.multiply(marginCoef,mc);
					
					// delta per comparazione con la soglia massima di tolleranza
					BigDecimal delta = this.getDelta(oldMar, roundedPropMar);

					// se il delta <= della soglia stabilita per quella classe
					// procedo all'update
					
					if (marTh==null || marTh.compareTo(delta)>=0) {
						
						appIntLog.info("Export bond class margin values for classId:" + pampClassId + " (classDesc: " + bndClass.getClassDesc()+ ") - VALUES: Old bond class margin: " + oldMar
								+ "; New bond class margin: " + roundedPropMar);
						
						
						
						//setto il nuovo margine
						mts.setF90inmargi(roundedPropMar);
						
					} else {
						String deltaPerc = GenericTools.percentValue(delta, new MathContext(4));
						String marThPerc = GenericTools.percentValue(marTh, new MathContext(4));
						throw new LargeThresoldMarginException(clMarHis.getPk().getClassId(), bndClass.getClassDesc(), oldMar, propMar, deltaPerc, marThPerc);
					}

				}
				//se invece non ci sono record scateno un eccezione
				else {

					throw new InstrumentDataNotAvailableException(/*classTC.getPk().getClassId()*/bndClass.getClassId(), "No bond class margins available on the Clearing system for class Id: " + pampClassId//classTC.getPk().getClassId()
							+ " (classDesc: " + bndClass.getClassDesc().trim()+ ")");

				}

			//}

		}

		appIntLog.info(readyClassMarHistVec.size() + " bond class historical margins exported to Clearing system");
		
		//update dello status dei margini su PMPTCLMARH
		bmpPamp.updateClassMarginHistorySentStatusAfterExport(readyClassMarHistVec);

	}
	
	@TransactionAttribute(TransactionAttributeType.NEVER)
	public BigDecimal getDelta(BigDecimal oldMargin, BigDecimal propMargin) {
		BigDecimal delta = (oldMargin.subtract(propMargin)).divide(oldMargin,8,RoundingMode.HALF_EVEN);
		return delta.abs();
	}

}
