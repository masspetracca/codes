package it.ccg.pamp.server.appint;
import java.io.IOException;

import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.PropertyException;

import javax.ejb.Local;

@Local
public interface OeKBMTELocal {
	public String createTxtFile() throws DataNotValidException, IOException, PropertyException;
}
