package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.HistoricalPricesEAOLocal;
import it.ccg.pamp.server.eao.InstrumentEAOLocal;
import it.ccg.pamp.server.entities.HistoricalPrices;
import it.ccg.pamp.server.entities.HistoricalPricesPK;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.FileFormatNotSupportedException;
import it.ccg.pamp.server.exceptions.HeaderNotValidException;
import it.ccg.pamp.server.exceptions.KeyNotFoundException;
import it.ccg.pamp.server.properties.PropertiesEAOLocal;
import it.ccg.pamp.server.utils.GenericTools;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Vector;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.format.CellDateFormatter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
/**
 * Session Bean implementation class ImportFromFile
 */
@Stateless
public class ImportFromFile implements ImportFromFileLocal {

	@EJB
	private PropertiesEAOLocal properties;
	
	@EJB
	private InstrumentEAOLocal instrumentEAO;
	
	@EJB
	private HistoricalPricesEAOLocal histPricesEAO;
	
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	final String dateSeparator = "";
		
	final static String rootPath = System.getProperty("user.install.root")+"/import/";
	
	final static String importedPath = rootPath+"imported/";
	
	final static String rejectedPath = rootPath+"rejected/";
	
	final static String tempPath = rootPath+"temp/";
	
	final static String[] importTypeArr = new String[] {"Static data","Price series"};
	
	final static String[] dateSeparatorArray = new String[] {"-","/"};
	
	final static String[] multipleDivisCode = new String[] {"E","Y"};
	
	static HashMap<String, String> propertyMap = new HashMap<String, String>(); 
	 
	
	public String loadFile(int importType, boolean overWrite) throws Exception {
		
		//try {
			
			propertyMap = properties.getPropertyMap();
			
			this.moveFileToTempDir();
			
			File tempDir = new File(tempPath);
			
			int countFile = 0;
			
			List<File> fileList = new ArrayList<File>();
			
			if (tempDir.exists() && tempDir.isDirectory()) {
				
				File[] tempDirList = tempDir.listFiles();
				
				for (File file:tempDirList) {
								
					if (file.isFile()) {
					
						String fileName = file.getName();
					
						//File file = new File(rootPath+fileName);
				
						String rejected = rejectedPath+fileName;
						String fileExtension = fileName.substring(fileName.lastIndexOf(".")+1);
				
						// file extension check
						if (! (fileExtension.equalsIgnoreCase("zip") || fileExtension.equalsIgnoreCase("xlsx") || fileExtension.equalsIgnoreCase("xls"))) {
							
							// lo rimuovo dalla directory e mando in errore perch� il formato non � consentito
							file.renameTo(new File(rejected));
							
							throw new FileFormatNotSupportedException(fileExtension);
							
						}
						
						String divisionString = "DIVISION: ";
						
						if (multipleDivisCode.length>1)
							divisionString = "DIVISIONS: ";
						
						for(String divisCode : multipleDivisCode)
							divisionString += GenericTools.getWholeDivisCode(divisCode)+", ";
						
						divisionString = divisionString.substring(0,divisionString.length()-2);
						
							
						if (fileExtension.equalsIgnoreCase("xlsx") || fileExtension.equalsIgnoreCase("xls"))
							log.info("Starting to read "+fileName+" - IMPORT TYPE: "+importTypeArr[importType]+"; "+divisionString+"; OVERWRITE EXISTING RECORDS: "+overWrite);
												
			
						// se � un file zip
						if (fileExtension.equalsIgnoreCase("zip")) {
						
				            byte[] buf = new byte[1024];
				            
				            ZipInputStream zipInputStream = null;
				            
				            ZipEntry compressedFile;
				            
				            //lo sposto dentro temp
				            zipInputStream = new ZipInputStream(new FileInputStream(tempPath+fileName));
				            
				            compressedFile = zipInputStream.getNextEntry();
				            
				            int countCompressed = 0;
				            
				            while (compressedFile != null) {
				            	//passo al successivo
				                compressedFile = zipInputStream.getNextEntry();
				                countCompressed++;
				            }
				            zipInputStream.close();
				            
				            zipInputStream = new ZipInputStream(new FileInputStream(tempPath+fileName));
				            compressedFile = zipInputStream.getNextEntry();
				            
				            
				            String strFile = "file";
				            
				            if (countCompressed>1)
				            	strFile += "s";
				            
				            log.info("Extracting archive "+fileName+" containing "+countCompressed+" "+strFile);
				            
				            //ciclo nel file zip e vedo se contiene file xls
				            while (compressedFile != null) { 
				                //for each entry to be extracted
				                String entryName = compressedFile.getName();
				                
				                if (entryName.indexOf("/")>0)
				                	entryName = entryName.substring(entryName.indexOf("/")+1);
				                
				                log.info("Found file "+entryName);
				                
				                int n;
				                
				                FileOutputStream fileOutputStream;
				                File newFile = new File(tempPath+entryName);
				                
				                String directory = newFile.getParent();
				                
				                if(directory == null) {
				                	if(newFile.isDirectory())
				                        break;
				                }
				                
				                String newFileExtension = newFile.getName().substring(newFile.getName().lastIndexOf(".")+1);
				                
				                // compressedfile extension check -- se positivo aggiungo alla lista
				        		if (newFileExtension.equalsIgnoreCase("xlsx") || newFileExtension.equalsIgnoreCase("xls")) {
				        			fileList.add(newFile);
				        			log.info("File "+compressedFile+" enqueued");
				        		} else {
				        			// chiudo lo zip, lo sposto nella cartella dei NON importati e poi mando in errore 
				        			zipInputStream.close();
				        			file.renameTo(new File(rejected));
				        			
				        			this.moveToRejectedDirectory();
				        			
				        			throw new FileFormatNotSupportedException(newFileExtension+"---"+newFile.getName());
				        		}
				                
				        		// estraggo nella cartella temporanea da dove andr�
				                fileOutputStream = new FileOutputStream(tempPath+entryName);             
			
				                while ((n = zipInputStream.read(buf, 0, 1024)) > -1)
				                    fileOutputStream.write(buf, 0, n);
			
				                fileOutputStream.close();
				                
				                //chiudo l'entry appena letta
				                zipInputStream.closeEntry();
				                
				                //passo al successivo
				                compressedFile = zipInputStream.getNextEntry();
			
				            }
				            
				            // chiudo lo zip
				            zipInputStream.close();
				            log.info("Archive "+fileName+" closed");
				        
						
						} else {
							fileList.add(file);
						}
				
						
					
					}
				}	
			}	
			
			int totFiles = fileList.size();
			// scorro la lista di file excel da aprire
			
			String report = "";
					
			for (File f:fileList) {
				countFile++;
				log.info("Processing file "+f.getName()+" ("+countFile+"/"+totFiles+")");
				//report += "File "+f.getName()+"\n";
				try {
					report += this.openAndManageExcelFile(f,importType, overWrite, multipleDivisCode)+"\n";
				} catch (Exception e) {
					//log.error(e.getMessage());//throw new Exception();
					this.moveToRejectedDirectory();
					throw new Exception(e.getMessage());
				}
				log.info("File "+f.getName()+" successfully processed");
				
				//rinomino il file e lo sposto dentro la directory degli importati
				//rimuovendo tutti i file eventualmente estratti 
				this.renameAndCopyFile(f, importType);
			}
	
		return report;
}
	
	
	
	/*public String openAndManageExcelFile(File file, int importType, boolean overWrite, String[] multipleDivisCode) throws Exception {
		
		String report = "";
		
		String fileString = "File "+file.getName();
		
		if (!file.exists()) {
			this.moveToRejectedDirectory();
			throw new FileNotFoundException();
		}
		
		String defaultHeader = "";
		
		String defaultKeyString = "";
		
		String[] defaultKeyArray = new String[] {""};
		
		// apro il file e controllo la prima riga
		Workbook woorkBook;
		
		//try {
			switch (importType) {
			
				case 0: //static data
					defaultHeader =  properties.getPropertyMap().get("headerStaticDataString");
					defaultKeyString = properties.getPropertyMap().get("staticDataKeyString");
					defaultKeyArray = defaultKeyString.split(",");
					break;
				case 1: //price series
					defaultHeader = properties.getPropertyMap().get("headerPriceString");
					defaultKeyString = properties.getPropertyMap().get("priceSeriesKeyString");
					defaultKeyArray = defaultKeyString.split(",");
					break;
			}
			
			String[] defaultHeaderArray = defaultHeader.split(",");
			
			//Apro il file
			woorkBook = Workbook.getWorkbook(file);
			Sheet[] arrSheet = woorkBook.getSheets();
			Sheet sheet = arrSheet[0];
			
			int keyPosition = 0;
			int tmstpPosition = 0;
			int bigDecPosition = 0;
			int statusPosition = 0;
			
			String keyString = "";
			
			boolean keyFound = false;
			
			List<String> xlsHeaderList = new ArrayList<String>();
			
			// Leggo l'intestazione del file e verifico che combaci (le colonne possono essere anche messe in ordine diverso)
			for (int column = 0; column < sheet.getColumns(); column++) {
				Cell cell = sheet.getCell(column, 0);
				
				// vedo se esistono le chiavi
				// cerco che sia presente almeno una delle possibili chiavi
				for (String key:defaultKeyArray) {
					if (cell.getContents().equalsIgnoreCase(key)) {
						//xlsHeaderList.add(cell.getContents());
						keyPosition = column;
						keyString = key;
						keyFound = true;
						break;
					} 
				}
				
				//scorro l'header di default
				for (String defHeader:defaultHeaderArray) {
					// se la colonna xls � uguale a una delle stringhe di default
					if (cell.getContents().equalsIgnoreCase(defHeader))
						xlsHeaderList.add(cell.getContents());
						//se sto importando i prezzi memorizzo la posizione del campo numerico e del campo data
						if (importType==1) {
							//se contiene DATE
							if (cell.getContents().contains("PRICEDATE")) {
								tmstpPosition = column;
							}
							if (cell.getContents().contains("CLOSEPR")) {
								bigDecPosition = column;
							}
							if (cell.getContents().contains("STATUS")) {
								statusPosition = column;
							}
							
						}
				}
				
			}
			
			if (!keyFound) {
				this.moveToRejectedDirectory();
				throw new KeyNotFoundException(file.getName(),defaultKeyString);//eccezione se non c'� neanche una delle chiavi previste
			}
			
			
			boolean instrFound = false;
			
			String keyValueLog = "";
			
			
			//confronto dimensioni
			if (defaultHeaderArray.length>xlsHeaderList.size()) {
				// numero di colonne non pu� mai essere minore quello atteso (pu� eventualmente essere maggiore)
				this.moveToRejectedDirectory();
				throw new HeaderNotValidException(file.getName(),defaultHeader, xlsHeaderList.size());//eccezione se header trovato � pi� piccolo
			} else {
				
				// se l'header � stato validato
						
				boolean vectorExists = false;
				
				LinkedHashMap<String, Vector<HistoricalPrices>> rowHashMap = new LinkedHashMap<String, Vector<HistoricalPrices>>();
				
				String atPosition = "";
				
				//ciclo su ogni riga per andarmi a salvare un vettore di IDENTIFICATORI e un vettore di righe
				for (int row = 1; row < sheet.getRows(); row++) {
					
					Vector<HistoricalPrices> xlsRowVector = new Vector<HistoricalPrices>();
					
					String xlsKey = "";
					String xlsCells = "";
					
					HistoricalPrices hp = new HistoricalPrices();
					HistoricalPricesPK hpPK = new HistoricalPricesPK();
					
					
					// ciclo su ogni colonna per leggere i valori di ogni riga
					for (int column = 0; column < sheet.getColumns(); column++) {
						
						
						
						atPosition = "at this position: row "+row+" - column "+(column+1);
						
						Cell cell = sheet.getCell(column, row);
						
						String cellString = cell.getContents();
						
						if (column == keyPosition) {						
							xlsKey = cellString;//cell.getContents();
							
							if (xlsKey==null||xlsKey.equalsIgnoreCase(""))
								throw new Exception("null value not allowed for keyn column "+keyString.toUpperCase()+" "+atPosition);
							
							// cerco nella mappa x vedere se il record � gi� esistente
							if (rowHashMap.get(xlsKey)==null) {
								vectorExists = false;
							} else {
								xlsRowVector = rowHashMap.get(xlsKey);
								vectorExists = true;
							}
							
						}
						
						// controllo sulla validit� della data
						if (column == tmstpPosition) {
							
							if (cellString==null||cellString.equalsIgnoreCase(""))
								throw new Exception("null value not allowed "+atPosition+" - expected date (YYYY-MM-DD)");
							
							//try {
								//System.out.println("Data: "+cellString+"--------");
								Timestamp tmstp = GenericTools.convertStringDateToTimestamp(cellString, dateSeparatorArray, "yyyy-MM-dd");
								hpPK.setPriceDate(tmstp);
								hp.setPk(hpPK);
							} catch (Exception e) {
								System.out.println(e.getMessage());
								throw new Exception(e.getMessage());
							}
						}
						
						// controllo sulla validit� del valore numerico decimale
						if (column == bigDecPosition) {
							// replace per sicurezza dell'eventuale separatore decimale (se la colonna � settata come formato numerico)
							//if (cell.getType().toString().equalsIgnoreCase("Number"))
							if (cellString==null||cellString.equalsIgnoreCase(""))
								throw new Exception("null value not allowed "+atPosition+" - expected number");
							
							cellString = cellString.replace(",", ".");
							
							// controllo sul segno
							if (cellString.equalsIgnoreCase("0") || cellString.startsWith("-"))
								throw new Exception("Found negative or zero value "+atPosition+" - expected positive number");
							try {
								
								BigDecimal bigDec = new BigDecimal(cellStringcell.getContents());
								
								hp.setClosepr(bigDec);
								
							} catch (Exception e) {
								throw new Exception("Unconvertible format for value "+cellString+ " "+atPosition+" - expected number");
							}
						}
						
						if (column==statusPosition) {
							boolean setDefStatus = false;
							String statusLogMessage = "Status will be set to default value (E)"; 
							// status null o vuoto viene settato di default
							if (cellString==null || cellString.equals("")) {
								log.warn("status field not set "+atPosition+" - "+statusLogMessage);
								setDefStatus = true;
							}
							// status pi� lungo di un carattere
							if (!setDefStatus && cellString.length()>1)
								log.warn("status length not allowed "+atPosition+" - "+statusLogMessage);
								setDefStatus = true;
							
							//status diverso dai due valori consentiti	
							if (!setDefStatus && !cellString.equalsIgnoreCase("D") && !cellString.equalsIgnoreCase("E"))
								log.warn("status value not allowed "+atPosition+" - "+statusLogMessage);
								setDefStatus = true;
							
							//setto il valore dello status
							if (setDefStatus)
								cellString = "E";
							
							hp.setStatus(cellString);
								
						}
							
						
						// cerco nella mappa x vedere se il record � gi� esistente
						if (rowHashMap.get(xlsKey)==null) {
							vectorExists = false;
						} else {
							xlsRowVector = rowHashMap.get(xlsKey);
							vectorExists = true;
						}
							
						// aggiungo alla lista di celle
						xlsCells += cellString+";";
					}
					
					//xlsStringVector.add(xlsCells.substring(0,xlsCells.length()-1));
					xlsRowVector.add(hp);
					
					// se il vettore non esiste per la chiave in esame allora aggiungo un nuovo elemento alla mappa
					if (!vectorExists)	
						rowHashMap.put(xlsKey, xlsRowVector);
				}
					
				int totalRecords = sheet.getRows()-1;
				
				int importedRecords = 0;
					
				Set<String> mapKeySet = rowHashMap.keySet();
				
				// carico gli strumenti da pamp filtrando per division code 
				Instrument[] arrPampInstrument = instrumentEAO.getByMultipleDivisCode(multipleDivisCode);
				
				for (String keyValue:mapKeySet) {
				
					instrFound = false;
					
					keyValueLog = keyValue;
					
					int instrId = 0; 
					
					//per ogni IDENTIFICATORE cerco l'esistenza sulla static data
					for (Instrument pampInstr:arrPampInstrument) {
						
						// reflection per richiamare dinamicamente il giusto metodo in base alla chiave
						Method method = pampInstr.getClass().getMethod("get"+keyString, null);
						Object o = method.invoke(pampInstr,null);
						
						//se esiste lo strumento
						if (keyValue.equalsIgnoreCase(o.toString())) {
							instrId = pampInstr.getInstrId();
							
							//Vector<String> mapVector = rowHashMap.get(keyValue);
							Vector<HistoricalPrices> mapVector = rowHashMap.get(keyValue);
								
							switch (importType) {
								case 0:
										
									for (String row:mapVector) {
										// update dei valori sulla static data									
									}
									break;
								case 1:
									
									// vedo se lo strumento ha gi� una serie storica
									HistoricalPrices[] pampHistPriceArr = histPricesEAO.findByInstrId(instrId);
									
									String seriesDetailString = "No hist. price series found for "+keyString+": "+keyValue;
									
									String seriesStartingDate = null;
									String seriesEndDate = null;
									
									if (pampHistPriceArr.length!=0) {
										seriesStartingDate = GenericTools.shortDateFormat(pampHistPriceArr[pampHistPriceArr.length-1].getPk().getPricedate());
										seriesEndDate = GenericTools.shortDateFormat(pampHistPriceArr[0].getPk().getPricedate());
										seriesDetailString = "Found "+pampHistPriceArr.length+" prices for "+keyString+": "+keyValue+" - starting from "+seriesStartingDate+" to "+seriesEndDate;
									}
									
									log.info(seriesDetailString);
									
									LinkedHashMap<Timestamp, HistoricalPrices> pampHistPriceMap = new LinkedHashMap<Timestamp, HistoricalPrices>();
									
									for (HistoricalPrices pampHistPr:pampHistPriceArr) {
										pampHistPriceMap.put(pampHistPr.getPk().getPricedate(), pampHistPr);
									}
									
									int countRow = 0;
									
									for (HistoricalPrices row:mapVector) {
										
										countRow++;
										
										// setto l'instrId
										row.getPk().setInstrId(instrId);
										
										String recordString = "Record "+countRow+"/"+totalRecords;
										
										String operation = "processed with no effects";
										
										Timestamp priceDate = row.getPk().getPricedate();
										BigDecimal closePr = row.getClosepr();
										String status = row.getStatus();
										
										String valuesLogString =  keyString+": "+keyValue+"; values: "+priceDate+", "+closePr+", "+status;
										
										// se non trova gi� un record con quella data lo aggiunge sicuramente
										if (pampHistPriceMap.get(priceDate)==null) {
											try {
												histPricesEAO.store(row);
												importedRecords++;
											} catch (Exception e) {
												throw new Exception(e.getMessage());
											}
											operation = "successfully added";
											
										} else {
											// altrimenti fa l'update soltanto in caso di flag OVERWRITE attivo
											if (overWrite) {
																							
												boolean priceChanged = false;
												boolean statusChanged = false;
												operation += " (same price and status)";
												
												//check sul prezzo
												if(pampHistPriceMap.get(priceDate).getClosepr().compareTo(closePr)!=0)
													priceChanged = true;
												
												//check sullo status
												if(!pampHistPriceMap.get(priceDate).getStatus().equalsIgnoreCase(status))
													statusChanged = true;
												
												try {
													if (priceChanged||statusChanged) {
														operation = "successfully overwritten";
														histPricesEAO.update(instrId, priceDate, closePr, status);
														importedRecords++;
													}
																										
												} catch (Exception e) {
													throw new Exception(e.getMessage());
												}
											} else {
												operation = "already existing on historical price series";
												throw new Exception(fileString+" - "+recordString+" "+operation+" - "+valuesLogString);
											}
										}
											
										
										log.info(recordString+" "+operation+" - "+valuesLogString);
										
										
									}
									break;
							}
							// break sulla lista di strumenti e passo alla successiva
							instrFound = true;
							break;
						} 
						
						int keyInt;
						
						if (o instanceof String) {
							o.toString();
						} else if (o instanceof Integer) {
							keyInt = ((Integer) o).intValue();
						} else {
							
							throw new ClassCastException();
							
						}
					}
					
				}
			}			
				 
			// se c'� ALMENO un set di prezzi per cui non esiste lo strumento
			if (importType==1 && !instrFound)  {	
				// elimino il file dalla cartella
				this.moveToRejectedDirectory();
				
				throw new DataNotAvailableException("No instrument found for "+keyString+" "+keyValueLog);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} /*catch (BiffException e) {
			e.printStackTrace();
		} catch (PropertyException e1) {
			e1.printStackTrace();
		} catch (DataNotValidException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			
			e.printStackTrace();
		}
			
		report+= "";	
		return report;	
	}*/
	
	public String importStaticData(Workbook workBook, String fileName, int keyPosition,String keyString, boolean overWrite) {
		return "";
	}
	
	
	public String importHistPriceSeries(Workbook workBook, String fileName,int keyPosition,String keyString, boolean overWrite) throws Exception {
		
		int tmstpPosition = 0;
		int bigDecPosition = 0;
		int statusPosition = 0;
		
		String fileString = "File "+fileName;
		
		String report = "";
		
		List<String> xlsHeaderList = new ArrayList<String>();
		
		xlsHeaderList.add(keyString.toUpperCase());
		
		Sheet sheet = workBook.getSheetAt(0);
		
		String defaultHeader = properties.getPropertyMap().get("headerPriceString");
		String[] defaultHeaderArray =  defaultHeader.split(",");
		
		int headerFoundCnt = 0; 
		
		Row firstRow = sheet.getRow(0);
		
		int maxColumnIndex = firstRow.getLastCellNum();
		
		for (int column = 0; column < maxColumnIndex; column++) {
			
			Cell cell = firstRow.getCell(column);
		
			//scorro l'header di default
			for (String defHeader:defaultHeaderArray) {
				// se la colonna xls � uguale a una delle stringhe di default
				
				String cellValue = cell.getStringCellValue();
				
				if (cellValue.equalsIgnoreCase(defHeader)) {
					xlsHeaderList.add(cellValue);
					//se contiene DATE
					if (cellValue.equalsIgnoreCase("PRICEDATE")) {
						tmstpPosition = column;
					}
					if (cellValue.equalsIgnoreCase("CLOSEPR")) {
						bigDecPosition = column;
					}
					if (cellValue.equalsIgnoreCase("STATUS")) {
						statusPosition = column;
					}
					
					headerFoundCnt++;
					
				} 
			}
		}	
		
		int totalRecords = sheet.getLastRowNum();
		int importedRecords = 0;
		int overwrittenRecords = 0;
		int notChangedRecords = 0;
		
		//confronto dimensioni
		if (defaultHeaderArray.length!=headerFoundCnt) {
			// numero di colonne non pu� mai essere minore quello atteso (pu� eventualmente essere maggiore)
			this.moveToRejectedDirectory();
			throw new HeaderNotValidException(fileName,defaultHeader, defaultHeaderArray.length);//eccezione se header trovato � pi� piccolo
		} else {
				
			// se l'header � stato validato
			boolean vectorExists = false;
				
			LinkedHashMap<String, Vector<HistoricalPrices>> fileRowsHashMap = new LinkedHashMap<String, Vector<HistoricalPrices>>();
			
			for (int row = 1; row < sheet.getLastRowNum()+1; row++) {
				
				String xlsKey = "";
				
				Vector<HistoricalPrices> xlsRowVector = new Vector<HistoricalPrices>();
				
				HistoricalPrices hp = new HistoricalPrices();
				HistoricalPricesPK hpPK = new HistoricalPricesPK();
				
				Row currentRow = sheet.getRow(row);
				
				// ciclo su ogni colonna per leggere i valori di ogni riga
				for (int column = 0; column < maxColumnIndex; column++) {
					
					boolean foundNull = false;
					
					String nullValue = "null value not allowed for "+xlsHeaderList.get(column)+" ";
					String atPosition = "at this position: row "+row+" - column "+(column+1);
					nullValue +=atPosition; 
					
					Cell cell = currentRow.getCell(column);
					
					String cellContent = "";
					
					boolean statusNull = false;
					
					// giochino per aggirare l'eccezione sul null dello status
					if (column==statusPosition && cell==null) {
						Cell appoCell = currentRow.createCell(row, column);
						appoCell.setCellValue("E");
						statusNull = true;
						cell = appoCell;
						
					
					}	
					
					if (cell!=null) {
						//controllo sui tipi di cella
						
						if (cell.getCellType()!= 1 && HSSFDateUtil.isCellDateFormatted(cell)) {
							
							String dateFmt = cell.getCellStyle().getDataFormatString().replaceAll(";@", "");
							
							Date cellDate = HSSFDateUtil.getJavaDate(cell.getNumericCellValue());
							
							cellContent = new CellDateFormatter(dateFmt).format(cellDate);
							
							
						} else {
							switch (cell.getCellType()) {
								case 0:
									cellContent = Double.toString(cell.getNumericCellValue());
									break;
								case 1:
									cellContent = cell.getStringCellValue();
									break;
							}
						}
						
						//setto lo status a null per permettere all'algoritmo di loggare;
						if (statusNull)
							cellContent="";
						
						if (cellContent==null||cellContent.equalsIgnoreCase(""))
							foundNull=true;
						
						// controlli su colonne obbligatorie
						if (column == keyPosition) {
							nullValue +=" for key column "+keyString.toUpperCase();
							
							if (!foundNull) {
								xlsKey = cellContent;
								if (keyString.equalsIgnoreCase("INSTRID")) {
									Double appoKey = Double.parseDouble(xlsKey);
									xlsKey = Integer.toString(appoKey.intValue());
									
								}
								
								// verifico per la chiave se � gi� stata memorizzata
								
								if (fileRowsHashMap.get(xlsKey)==null) {
									vectorExists = false;
									//System.out.println("chiave non ancora memorizzata per il valore: "+xlsKey);
								} else {
									xlsRowVector = fileRowsHashMap.get(xlsKey);
									//System.out.println("chiave gi� memorizzata - richiamo il vettore di dimensione "+xlsRowVector.size());
									vectorExists = true;
								}
							}
						}
						
						if (column == tmstpPosition) {
							nullValue +=" - expected date (YYYY-MM-DD)";
							// prova conversione data
							if (!foundNull) {
								Timestamp tmstp = GenericTools.convertStringDateToTimestamp(cellContent, dateSeparatorArray, "yyyy-MM-dd","for "+xlsHeaderList.get(column)+" "+atPosition);
								hpPK.setPriceDate(tmstp);
								hp.setPk(hpPK);
							}
						}	
						
						if (column == bigDecPosition) {
							nullValue +=" - expected number";
							if (!foundNull) {
								
								cellContent = cellContent.replace(",", ".");
								
								if (cellContent.equalsIgnoreCase("0") || cellContent.startsWith("-"))
									throw new Exception(fileString+" - Found negative or zero value "+atPosition+" - expected positive number for "+xlsHeaderList.get(column));
								
								try {
									BigDecimal bigDec = new BigDecimal(cellContent);
									hp.setClosepr(bigDec);
								} catch (Exception e) {
									throw new Exception(fileString+" - Unconvertible format for value \""+cellContent+"\" "+atPosition+" - expected number for "+xlsHeaderList.get(column));
								}
							}
						}
						
						if (column==statusPosition) {
							boolean setDefStatus = false;
							String statusLogMessage = "Status will be set to default value (E)"; 
							
							// status null o vuoto viene settato di default
							if (cellContent==null || cellContent.equals("")) {
								log.warn(fileString+" - status field not set "+atPosition+" - "+statusLogMessage);
								setDefStatus = true;
								foundNull = false;
							}
							
							// status pi� lungo di un carattere
							if (!setDefStatus && cellContent.length()>1) {
								log.warn(fileString+" - status length not allowed "+atPosition+" - "+statusLogMessage);
								setDefStatus = true;
							}
								
							//status diverso dai due valori consentiti	
							if (!setDefStatus && !cellContent.equalsIgnoreCase("D") && !cellContent.equalsIgnoreCase("E")) {
								log.warn(fileString+" - status value not allowed "+atPosition+" - "+statusLogMessage);
								setDefStatus = true;
							}
							
							//setto il valore dello status
							if (setDefStatus)
								cellContent = "E";
							
							hp.setStatus(cellContent);
						}
					} else {
						foundNull = true;
					}
					
					if (foundNull)
						throw new Exception(nullValue);
					
					
				}
				
				// aggiungo al vettore di righe l'oggetto appena costruito	
				xlsRowVector.add(hp);
				
				// se il vettore non esiste per la chiave in esame allora aggiungo un nuovo elemento alla mappa
				if (!vectorExists)	{
					//System.out.println("INSTRID: "+xlsKey+": - righe: "+xlsRowVector.size());
					fileRowsHashMap.put(xlsKey, xlsRowVector);
				}
				
			}
			
			Set<String> mapKeySet = fileRowsHashMap.keySet();
			
			
			
			// carico gli strumenti da pamp filtrando per division code 
			Instrument[] arrPampInstrument = instrumentEAO.getByMultipleDivisCode(multipleDivisCode);
			
			List<Instrument> pampInstrFoundList = new ArrayList<Instrument>();
			
			boolean instrNotFound = true;
			
			List<String> keyNotFoundList = new ArrayList<String>();
			
			//per ogni IDENTIFICATORE cerco l'esistenza sulla static data
			for (String keyValue:mapKeySet) {
				instrNotFound = true;
				
				for (Instrument pampInstr:arrPampInstrument) {
						
					// reflection per richiamare dinamicamente il giusto metodo in base alla chiave
					Method method = pampInstr.getClass().getMethod("get"+keyString, null);
					
					Object o = method.invoke(pampInstr,null);
									
					
					//se esiste lo strumento mi fermo
					if (keyValue.equalsIgnoreCase(o.toString())) {
						pampInstrFoundList.add(pampInstr);
						instrNotFound = false;
						break;
					}
				}
				if (instrNotFound)
					keyNotFoundList.add(keyValue);
			}
						
			// se c'� ALMENO un set di prezzi per cui non esiste lo strumento
			if (keyNotFoundList.size()>0)  {	
				// elimino il file dalla cartella
				this.moveToRejectedDirectory();
				
				String keyListString = "";
				
				for (String key:keyNotFoundList)
					keyListString += key+", ";
				
				keyListString = keyListString.substring(0,keyListString.length()-2);
				
				throw new DataNotAvailableException(fileString+" - No instrument found for "+keyString+" "+keyListString);
			}
			
			//System.out.println(pampInstrFoundList.size());
			
			String[] keyArr = new String[mapKeySet.size()];
			
			int counter = 0;
			
			//memorizzo in un array di appoggio i valori chiave da utilizzare nelle insert
			for (String keyValue:mapKeySet) {
				keyArr[counter] = keyValue;
				counter++;
			}
			
							
			int instrId = 0; 
			
			counter = 0;
			
			int instrTotalRecords = 0;
			
			//per ogni IDENTIFICATORE cerco l'esistenza sulla static data
			for (Instrument pampInstr:pampInstrFoundList) {
					
				/*// reflection per richiamare dinamicamente il giusto metodo in base alla chiave
				Method method = pampInstr.getClass().getMethod("get"+keyString, null);
				Object o = method.invoke(pampInstr,null);
				*/
				//arrivato allo strumento mi fermo
				//if (keyValue.equalsIgnoreCase(o.toString())) {
				
				instrId = pampInstr.getInstrId();
				
				Vector<HistoricalPrices> mapVector = fileRowsHashMap.get(keyArr[counter]);
				
				instrTotalRecords = mapVector.size();
						
				// vedo se lo strumento ha gi� una serie storica
				HistoricalPrices[] pampHistPriceArr = histPricesEAO.findByInstrId(instrId);
				
				String seriesDetailString = "No hist. price series found for "+keyString+": "+keyArr[counter];
				
				String seriesStartingDate = null;
				String seriesEndDate = null;
				
				if (pampHistPriceArr.length!=0) {
					seriesStartingDate = GenericTools.shortDateFormat(pampHistPriceArr[pampHistPriceArr.length-1].getPk().getPricedate());
					seriesEndDate = GenericTools.shortDateFormat(pampHistPriceArr[0].getPk().getPricedate());
					seriesDetailString = "Found "+pampHistPriceArr.length+" prices for "+keyString+": "+keyArr[counter]+" - starting from "+seriesStartingDate+" to "+seriesEndDate;
				}
					
				log.info(seriesDetailString);
				
				LinkedHashMap<Timestamp, HistoricalPrices> pampHistPriceMap = new LinkedHashMap<Timestamp, HistoricalPrices>();
				
				for (HistoricalPrices pampHistPr:pampHistPriceArr) {
					pampHistPriceMap.put(pampHistPr.getPk().getPricedate(), pampHistPr);
				}
				
				int countRow = 0;
				
				log.info(instrTotalRecords+" records ready to be imported for "+keyString+" "+keyArr[counter]);
				
				for (HistoricalPrices row:mapVector) {
					
					countRow++;
					
					// setto l'instrId
					row.getPk().setInstrId(instrId);
					
					String recordString = "Record "+countRow+"/"+instrTotalRecords;
					
					String operation = "processed with no effects";
					
					Timestamp priceDate = row.getPk().getPricedate();
					BigDecimal closePr = row.getClosepr();
					String status = row.getStatus();
					
					String valuesLogString =  keyString+": "+keyArr[counter]+"; values: "+priceDate+", "+closePr+", "+status;
					
					// se non trova gi� un record con quella data lo aggiunge sicuramente
					if (pampHistPriceMap.get(priceDate)==null) {
						try {
							histPricesEAO.store(row);
							importedRecords++;
						} catch (Exception e) {
							throw new Exception(e.getMessage());
						}
						operation = "successfully added";
						
					} else {
						// altrimenti fa l'update soltanto in caso di flag OVERWRITE attivo
						if (overWrite) {
																		
							boolean priceChanged = false;
							boolean statusChanged = false;
							operation += " (same price and status)";
							
							//check sul prezzo
							if(pampHistPriceMap.get(priceDate).getClosepr().compareTo(closePr)!=0)
								priceChanged = true;
							
							//check sullo status
							if(!pampHistPriceMap.get(priceDate).getStatus().equalsIgnoreCase(status))
								statusChanged = true;
							
							try {
								if (priceChanged||statusChanged) {
									operation = "successfully overwritten";
									
									histPricesEAO.update(instrId, priceDate, closePr, status);
									importedRecords++;
									overwrittenRecords++;
								} else {
									notChangedRecords++;
								}
																					
							} catch (Exception e) {
								throw new Exception(e.getMessage());
							}
						} else {
							operation = "already exists on historical price series";
							throw new Exception(fileString+" - "+recordString+" "+operation+" - "+valuesLogString);
						}
					}
					
					log.info(recordString+" "+operation+" - "+valuesLogString);
				}
				counter++;
			}	
		}
		String importedString = "";
		String overWrittenString = "";
		String notChangedString = "";
		
		switch (importedRecords) {
			case 0: 
				importedString = "no new records found to be imported";
				break;
			case 1:
				importedString = "1/"+totalRecords+" has been imported";
				break;
			default:
				importedString = importedRecords+"/"+totalRecords+" records have been imported";
		}
		
		if (overWrite) {
			/*switch (overwrittenRecords) {
				case 0: 
					overWrittenString = "no records have been overwritten";
					break;
				case 1:
					overWrittenString = "1/"+totalRecords+" has been overwritten";
					break;
				default:
					overWrittenString = overwrittenRecords have been overwritten";
			}*/
			overWrittenString = "("+overwrittenRecords+" overwritten)";
			if (overwrittenRecords>0)
				importedString+=" "+overWrittenString;
			
			switch (notChangedRecords) {
				case 0: 
					notChangedString = "no records have been updated";
					break;
				case 1:
					notChangedString = "1/"+totalRecords+" has not been overwritten";
					break;
				default:
					notChangedString = notChangedRecords+" have not been overwritten";
			}
			
			if (importedRecords>0)
				importedString+=" and "+notChangedString;
			
		}
		
		return fileString+" - "+importedString;
	}
	
	
	/*public String importHistPriceSeries(Workbook workBook, String fileName,int keyPosition,String keyString, boolean overWrite) throws Exception {
		
		int tmstpPosition = 0;
		int bigDecPosition = 0;
		int statusPosition = 0;
		
		String fileString = "File "+fileName;
		
		String report = "";
		
		List<String> xlsHeaderList = new ArrayList<String>();
		
		Sheet[] arrSheet = workBook.getSheets();
		Sheet sheet = arrSheet[0];
		
		String defaultHeader = properties.getPropertyMap().get("headerPriceString");
		String[] defaultHeaderArray =  defaultHeader.split(",");
		
		int headerFoundCnt = 0; 
		
		for (int column = 0; column < sheet.getColumns(); column++) {
			Cell cell = sheet.getCell(column, 0);
		
			//scorro l'header di default
			for (String defHeader:defaultHeaderArray) {
				// se la colonna xls � uguale a una delle stringhe di default
				
				if (cell.getContents().equalsIgnoreCase(defHeader)) {
					xlsHeaderList.add(cell.getContents());
					//se contiene DATE
					if (cell.getContents().equalsIgnoreCase("PRICEDATE")) {
						tmstpPosition = column;
					}
					if (cell.getContents().equalsIgnoreCase("CLOSEPR")) {
						bigDecPosition = column;
					}
					if (cell.getContents().equalsIgnoreCase("STATUS")) {
						statusPosition = column;
					}
					
					headerFoundCnt++;
					
				} 
			}
		}	
		
		int totalRecords = sheet.getRows()-1;
		int importedRecords = 0;
		int overwrittenRecords = 0;
		int notChangedRecords = 0;
		
		//confronto dimensioni
		if (defaultHeaderArray.length!=headerFoundCnt) {
			// numero di colonne non pu� mai essere minore quello atteso (pu� eventualmente essere maggiore)
			this.moveToRejectedDirectory();
			throw new HeaderNotValidException(fileName,defaultHeader, defaultHeaderArray.length);//eccezione se header trovato � pi� piccolo
		} else {
				
			// se l'header � stato validato
			boolean vectorExists = false;
				
			LinkedHashMap<String, Vector<HistoricalPrices>> fileRowsHashMap = new LinkedHashMap<String, Vector<HistoricalPrices>>();
				
			//ciclo su ogni riga per andarmi a salvare un vettore di IDENTIFICATORI e un vettore di righe
			for (int row = 1; row < sheet.getRows(); row++) {
					
				Vector<HistoricalPrices> xlsRowVector = new Vector<HistoricalPrices>();
				
				String xlsKey = "";
								
				HistoricalPrices hp = new HistoricalPrices();
				HistoricalPricesPK hpPK = new HistoricalPricesPK();
				
				
				// ciclo su ogni colonna per leggere i valori di ogni riga
				for (int column = 0; column < sheet.getColumns(); column++) {
					
					boolean foundNull = false;
					
					String nullValue = "null value not allowed ";
					String atPosition = "at this position: row "+row+" - column "+(column+1);
					nullValue +=atPosition; 
					
					Cell cell = sheet.getCell(column, row);
						
					String cellContent = cell.getContents();
					
					if (cellContent==null||cellContent.equalsIgnoreCase(""))
						foundNull=true;
					
					// controlli su colonne obbligatorie
					if (column == keyPosition) {
						nullValue +=" for key column "+keyString.toUpperCase();
						
						if (!foundNull) {
							xlsKey = cellContent;
							// verifico per la chiave se � gi� stata memorizzata
							if (fileRowsHashMap.get(cellContent)==null) {
								vectorExists = false;
							} else {
								xlsRowVector = fileRowsHashMap.get(cellContent);
								vectorExists = true;
							}
						}
					}
					
					if (column == tmstpPosition) {
						nullValue +=" - expected date (YYYY-MM-DD)";
						// prova conversione data
						if (!foundNull) {
							Timestamp tmstp = GenericTools.convertStringDateToTimestamp(cellContent, dateSeparatorArray, "yyyy-MM-dd");
							hpPK.setPriceDate(tmstp);
							hp.setPk(hpPK);
						}
					}	
					
					if (column == bigDecPosition) {
						nullValue +=" - expected number";
						if (!foundNull) {
							
							cellContent = cellContent.replace(",", ".");
							
							if (cellContent.equalsIgnoreCase("0") || cellContent.startsWith("-"))
								throw new Exception(fileString+" - Found negative or zero value "+atPosition+" - expected positive number");
							
							try {
								BigDecimal bigDec = new BigDecimal(cellContent);
								hp.setClosepr(bigDec);
							} catch (Exception e) {
								throw new Exception(fileString+" - Unconvertible format for value "+cellContent+ " "+atPosition+" - expected number");
							}
						}
					}
					
					if (column==statusPosition) {
						boolean setDefStatus = false;
						String statusLogMessage = "Status will be set to default value (E)"; 
						
						// status null o vuoto viene settato di default
						if (cellContent==null || cellContent.equals("")) {
							log.warn(fileString+" - status field not set "+atPosition+" - "+statusLogMessage);
							setDefStatus = true;
							foundNull = false;
						}
						
						// status pi� lungo di un carattere
						if (!setDefStatus && cellContent.length()>1) {
							log.warn(fileString+" - status length not allowed "+atPosition+" - "+statusLogMessage);
							setDefStatus = true;
						}
							
						//status diverso dai due valori consentiti	
						if (!setDefStatus && !cellContent.equalsIgnoreCase("D") && !cellContent.equalsIgnoreCase("E")) {
							log.warn(fileString+" - status value not allowed "+atPosition+" - "+statusLogMessage);
							setDefStatus = true;
						}
						
						//setto il valore dello status
						if (setDefStatus)
							cellContent = "E";
						
						hp.setStatus(cellContent);
					}
					
					if (foundNull)
						throw new Exception(nullValue);
					
				}
				
				// aggiungo al vettore di righe l'oggetto appena costruito	
				xlsRowVector.add(hp);
					
				// se il vettore non esiste per la chiave in esame allora aggiungo un nuovo elemento alla mappa
				if (!vectorExists)	
					fileRowsHashMap.put(xlsKey, xlsRowVector);
			}
			
			Set<String> mapKeySet = fileRowsHashMap.keySet();
			
			// carico gli strumenti da pamp filtrando per division code 
			Instrument[] arrPampInstrument = instrumentEAO.getByMultipleDivisCode(multipleDivisCode);
			
			List<Instrument> pampInstrFoundList = new ArrayList<Instrument>();
			
			boolean instrNotFound = true;
			
			List<String> keyNotFoundList = new ArrayList<String>();
			
			//per ogni IDENTIFICATORE cerco l'esistenza sulla static data
			for (String keyValue:mapKeySet) {
				
				instrNotFound = true;
				
				for (Instrument pampInstr:arrPampInstrument) {
						
					// reflection per richiamare dinamicamente il giusto metodo in base alla chiave
					Method method = pampInstr.getClass().getMethod("get"+keyString, null);
					Object o = method.invoke(pampInstr,null);
						
					//se esiste lo strumento mi fermo
					if (keyValue.equalsIgnoreCase(o.toString())) {
						pampInstrFoundList.add(pampInstr);
						instrNotFound = false;
						break;
					}
				}
				if (instrNotFound)
					keyNotFoundList.add(keyValue);
			}
						
			// se c'� ALMENO un set di prezzi per cui non esiste lo strumento
			if (keyNotFoundList.size()>0)  {	
				// elimino il file dalla cartella
				this.moveToRejectedDirectory();
				
				String keyListString = "";
				
				for (String key:keyNotFoundList)
					keyListString += key+", ";
				
				keyListString = keyListString.substring(0,keyListString.length()-2);
				
				throw new DataNotAvailableException(fileString+" - No instrument found for "+keyString+" "+keyListString);
			}
			
			//dopo averli validati inizio importazione
			for (String keyValue:mapKeySet) {
			
				int instrId = 0; 
				
				//per ogni IDENTIFICATORE cerco l'esistenza sulla static data
				for (Instrument pampInstr:pampInstrFoundList) {
						
					// reflection per richiamare dinamicamente il giusto metodo in base alla chiave
					Method method = pampInstr.getClass().getMethod("get"+keyString, null);
					Object o = method.invoke(pampInstr,null);
					
					//arrivato allo strumento mi fermo
					//if (keyValue.equalsIgnoreCase(o.toString())) {
					
					instrId = pampInstr.getInstrId();
							
					Vector<HistoricalPrices> mapVector = fileRowsHashMap.get(keyValue);
							
					// vedo se lo strumento ha gi� una serie storica
					HistoricalPrices[] pampHistPriceArr = histPricesEAO.findByInstrId(instrId);
					
					String seriesDetailString = "No hist. price series found for "+keyString+": "+keyValue;
					
					String seriesStartingDate = null;
					String seriesEndDate = null;
					
					if (pampHistPriceArr.length!=0) {
						seriesStartingDate = GenericTools.shortDateFormat(pampHistPriceArr[pampHistPriceArr.length-1].getPk().getPricedate());
						seriesEndDate = GenericTools.shortDateFormat(pampHistPriceArr[0].getPk().getPricedate());
						seriesDetailString = "Found "+pampHistPriceArr.length+" prices for "+keyString+": "+keyValue+" - starting from "+seriesStartingDate+" to "+seriesEndDate;
					}
						
					log.info(seriesDetailString);
					
					LinkedHashMap<Timestamp, HistoricalPrices> pampHistPriceMap = new LinkedHashMap<Timestamp, HistoricalPrices>();
					
					for (HistoricalPrices pampHistPr:pampHistPriceArr) {
						pampHistPriceMap.put(pampHistPr.getPk().getPricedate(), pampHistPr);
					}
					
					int countRow = 0;
									
					for (HistoricalPrices row:mapVector) {
						
						countRow++;
						
						// setto l'instrId
						row.getPk().setInstrId(instrId);
						
						String recordString = "Record "+countRow+"/"+totalRecords;
						
						String operation = "processed with no effects";
						
						Timestamp priceDate = row.getPk().getPricedate();
						BigDecimal closePr = row.getClosepr();
						String status = row.getStatus();
						
						String valuesLogString =  keyString+": "+keyValue+"; values: "+priceDate+", "+closePr+", "+status;
						
						// se non trova gi� un record con quella data lo aggiunge sicuramente
						if (pampHistPriceMap.get(priceDate)==null) {
							try {
								histPricesEAO.store(row);
								importedRecords++;
							} catch (Exception e) {
								throw new Exception(e.getMessage());
							}
							operation = "successfully added";
							
						} else {
							// altrimenti fa l'update soltanto in caso di flag OVERWRITE attivo
							if (overWrite) {
																			
								boolean priceChanged = false;
								boolean statusChanged = false;
								operation += " (same price and status)";
								
								//check sul prezzo
								if(pampHistPriceMap.get(priceDate).getClosepr().compareTo(closePr)!=0)
									priceChanged = true;
								
								//check sullo status
								if(!pampHistPriceMap.get(priceDate).getStatus().equalsIgnoreCase(status))
									statusChanged = true;
								
								try {
									if (priceChanged||statusChanged) {
										operation = "successfully overwritten";
										
										histPricesEAO.update(instrId, priceDate, closePr, status);
										importedRecords++;
										overwrittenRecords++;
									} else {
										notChangedRecords++;
									}
																						
								} catch (Exception e) {
									throw new Exception(e.getMessage());
								}
							} else {
								operation = "already exists on historical price series";
								throw new Exception(fileString+" - "+recordString+" "+operation+" - "+valuesLogString);
							}
						}
						
						log.info(recordString+" "+operation+" - "+valuesLogString);
					}
				}	
			}
		}
		String importedString = "";
		String overWrittenString = "";
		String notChangedString = "";
		
		switch (importedRecords) {
			case 0: 
				importedString = "no new records found to be imported";
				break;
			case 1:
				importedString = "1/"+totalRecords+" has been imported";
				break;
			default:
				importedString = importedRecords+"/"+totalRecords+" records have been imported";
		}
		
		if (overWrite) {
			switch (overwrittenRecords) {
				case 0: 
					overWrittenString = "no records have been overwritten";
					break;
				case 1:
					overWrittenString = "1/"+totalRecords+" has been overwritten";
					break;
				default:
					overWrittenString = overwrittenRecords have been overwritten";
			}
			overWrittenString = "("+overwrittenRecords+" overwritten)";
			if (overwrittenRecords>0)
				importedString+=" "+overWrittenString;
			
			switch (notChangedRecords) {
				case 0: 
					notChangedString = "no records have been updated";
					break;
				case 1:
					notChangedString = "1/"+totalRecords+" has not been overwritten";
					break;
				default:
					notChangedString = notChangedRecords+" have not been overwritten";
			}
			
			if (importedRecords>0)
				importedString+=" and "+notChangedString;
			
		}
		
		return fileString+" - "+importedString;
	}*/

	
	
	public String openAndManageExcelFile(File file, int importType, boolean overWrite, String[] multipleDivisCode) throws Exception {
		
		String report = "";
		
		if (!file.exists()) {
			this.moveToRejectedDirectory();
			throw new FileNotFoundException();
		}
		
		String defaultHeader = "";
		String defaultKeyString = "";
		String[] defaultKeyArray = new String[] {""};
		
		switch (importType) {
		
			case 0: //static data
				defaultKeyString = properties.getPropertyMap().get("staticDataKeyString");
				defaultKeyArray = defaultKeyString.split(",");
				break;
			case 1: //price series
				defaultHeader = properties.getPropertyMap().get("headerPriceString");
				defaultKeyString = properties.getPropertyMap().get("priceSeriesKeyString");
				defaultKeyArray = defaultKeyString.split(",");
				break;
		}
		
		FileInputStream fis = new FileInputStream(file);
		
		
		//String[] defaultHeaderArray = defaultHeader.split(",");
			
		// apro il file per verificare l'intestazione sulla prima riga
		
		// vecchia Libreria
		//Workbook workBook = Workbook.getWorkbook(file);
		
		Workbook workBook = WorkbookFactory.create(fis);
		
		
		/*Sheet[] arrSheet = workBook.getSheets();
		Sheet sheet = arrSheet[0];*/
		
		Sheet sheet = workBook.getSheetAt(0);
			
		int keyPosition = 0;
		String keyString = "";
		boolean keyFound = false;
		
		/*for (int column = 0; column < sheet.getColumns(); column++) {
			Cell cell = sheet.getCell(column, 0);
			
			// vedo se esistono le chiavi
			// cerco che sia presente almeno una delle possibili chiavi
			for (String key:defaultKeyArray) {
				if (cell.getContents().equalsIgnoreCase(key)) {
					
					keyPosition = column;
					keyString = key;
					keyFound = true;
					break;
				} 
			}
		}*/
		
		//System.out.println(sheet.getTopRow());
		
		Row firstRow = sheet.getRow(0);
		
		int maxColumnIndex = firstRow.getLastCellNum();
		
		for (int column = 0; column < maxColumnIndex; column++) {
			Cell cell = firstRow.getCell(column);
			
			// vedo se esistono le chiavi
			// cerco che sia presente almeno una delle possibili chiavi
			for (String key:defaultKeyArray) {
				if (cell.getStringCellValue().equalsIgnoreCase(key)) {
					
					keyPosition = column;
					keyString = key;
					keyFound = true;
					break;
				} 
			}
		}
		
		//workBook.close();
		if (!keyFound) {
			this.moveToRejectedDirectory();
			throw new KeyNotFoundException(file.getName(),defaultKeyString);//eccezione se non c'� neanche una delle chiavi previste
		}
		
		if (importType==0)
			report = this.importStaticData(workBook,file.getName(),keyPosition,keyString,overWrite);
		if (importType==1)
			report = this.importHistPriceSeries(workBook,file.getName(),keyPosition,keyString,overWrite);
		
		return report;
		
	}
		
		
	
	
	
	public void moveFileToTempDir() throws DataNotAvailableException {
		
		File rootDir = new File(rootPath);
		
		if (rootDir.exists() && rootDir.isDirectory()) {
		
			File[] rootDirList = rootDir.listFiles();
			
			int countFile = 0;
			
			long lastModified = 0;
			
			File fileToMove = new File("");
			
			//System.out.println("ho trovato "+rootDirList.length+" files dentro "+rootPath);
			
			//per ogni elemento della root sposto nella sottocartella temp
			for (File rootFile:rootDirList) {
				// se non � una directory 
				if (!rootFile.isDirectory()) {
					countFile++;
					if (lastModified==0 || rootFile.lastModified()<lastModified) {
						fileToMove = rootFile;
						lastModified = rootFile.lastModified();
					}
				}
			} 
			
			//System.out.println("File to move: "+fileToMove);
			
			//lo rimuovo spostandolo nella cartella temp
			fileToMove.renameTo(new File(tempPath+fileToMove.getName()));
			log.info(fileToMove.getName()+" moved from the root to \"temp\" directory");
			

			if(countFile==0)
				throw new DataNotAvailableException("No file found in root directory");
			
		} else {
			log.error("########## "+rootDir+" is not a dir");
		}
	}
	
	
	public void renameAndCopyFile(File file, int importType) {
		
		String prefix = "";
		
		switch (importType) {
			case 0:
				prefix = "ST_";
				break;
			case 1:
				prefix = "PRC_";
				break;
		}

		File rootDir = new File(tempPath);
		
		if (rootDir.exists() && rootDir.isDirectory()) {
		
			File[] rootDirList = rootDir.listFiles();
			
			prefix += Long.toString(GenericTools.systemDateLongFormat())+GenericTools.systemTime();
			
			// sposto il file nella cartella degli importati in quella data
			file.renameTo(new File(importedPath+prefix+file.getName()));
			
			log.info("File "+file.getName()+" moved into the \"imported\" file directory");
			
			
			//per ogni elemento di temp cerco eventuali ALTRI file
			for (File rootFile:rootDirList) {
				String fileNameExtension = rootFile.getName().substring(rootFile.getName().lastIndexOf(".")+1);
				// se non � una directory ed � un file zip
				if (!rootFile.isDirectory() && fileNameExtension.equalsIgnoreCase("zip")) {
						rootFile.delete();
						log.info(rootFile.getName()+" removed from the \"temp\" directory");
				}
			}
		}
		
		
	}
	
	
	public void moveToRejectedDirectory() {
		
		File rootDir = new File(/*rootPath*/tempPath);
		
		if (rootDir.exists() && rootDir.isDirectory()) {
		
			File[] rootDirList = rootDir.listFiles();
			
			int countZip = 0;
			
			//per ogni elemento della root cerco eventuali zip
			for (File rootFile:rootDirList) {
				
				String rootFileNameExtension = rootFile.getName().substring(rootFile.getName().lastIndexOf(".")+1);
				
				// se � un file zip lo copio tra i rejected
				if (rootFileNameExtension.equalsIgnoreCase("zip")) {
					
					countZip++;
					
					/*File subDir = new File(rejectedPath+GenericTools.shortDateFormatAsLong(GenericTools.systemDate()));
					
					subDir.mkdir();*/
					
					//rootFile.renameTo(new File(rejectedPath+GenericTools.shortDateFormatAsLong(GenericTools.systemDate())+"/"+rootFile.getName()));
					rootFile.renameTo(new File(rejectedPath+rootFile.getName()));
					log.info("File "+rootFile.getName()+" moved into the \"rejected\" file directory");
				}
			}
			
			//per ogni elemento della root cerco eventuali ALTRI file
			for (File rootFile:rootDirList) {
			
				// se non � una directory 
				if (!rootFile.isDirectory()) {
					
					//lo rimuovo se ho trovato almeno uno zip perch� vuol dire che ho importato un archivio e ho gi� spostato quello
					if (countZip>0) {
						rootFile.delete();
						log.info(rootFile.getName()+" removed from the \"temp\" directory");
					}  else {
						// lo sposto perch� ho tentato di importare un file singolo
						/*File subDir = new File(rejectedPath+GenericTools.shortDateFormatAsLong(GenericTools.systemDate()));
					
						subDir.mkdir();
					
						rootFile.renameTo(new File(rejectedPath+GenericTools.shortDateFormatAsLong(GenericTools.systemDate())+"/"+rootFile.getName()));*/
						rootFile.renameTo(new File(rejectedPath+rootFile.getName()));
						log.info("File "+rootFile.getName()+" moved into the \"rejected\" file directory");
					}
				}
			}
		}
	}
	
	public static void main(String[] args) throws Exception, FileNotFoundException, IOException {
		ImportFromFile i = new ImportFromFile();
		i.loadFile(1, true);
	}
	
	
}
