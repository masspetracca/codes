package it.ccg.pamp.server.appint;
import java.sql.Timestamp;
import java.util.List;

import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface HPDEAOLocal {
	//public int transfer(String divisCode, boolean delta, boolean foAsFutures) throws DataNotValidException;
	//public int transfer(Instrument instr, boolean delta, boolean foAsFutures) throws DataNotValidException;
	/**
   * @author Francesco Nelli
   * <p>
   * procedure built to download the cash historical prices series from INTRACS to PAMP system 
   * <p>
   * Limitation: If the historical prices series is too long, it could be possible an internal server time out error
   *
   * @param delta - <i>true</i> the procedure will download prices only from the last date present in historical prices data, <i>false</i> the procedure will download ALL historical prices data for each instrument
   * @return the message with the outcome of the procedure 
   */
	public String transferCash(boolean delta) throws DataNotValidException;
	public void transferCash(Instrument instr, boolean delta, List<Timestamp> calendList, Integer total, Integer failed, Integer updated) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * procedure built to download the futures historical prices series from INTRACS to PAMP system 
	   * <p>
	   * Limitation: If the historical prices series is too long, it could be possible an internal server time out error
	   *
	   * @param delta - <i>true</i> the procedure will download prices only from the last date present in historical prices data, <i>false</i> the procedure will download ALL historical prices data for each instrument
	   * @return the message with the outcome of the procedure 
	   */
	public String transferFutures(boolean delta) throws DataNotValidException;
	public void transferFutures(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * procedure built to download the index historical prices series from INTRACS to PAMP system 
	   * <p>
	   * Limitation: If the historical prices series is too long, it could be possible an internal server time out error
	   *
	   * @param delta - <i>true</i> the procedure will download prices only from the last date present in historical prices data, <i>false</i> the procedure will download ALL historical prices data for each instrument
	   * @return the message with the outcome of the procedure 
	   */
	public String transferIndex(boolean delta) throws DataNotValidException;
	public void transferIndex(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException;
	
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * procedure built to download the options historical prices series from INTRACS to PAMP system 
	   * <p>
	   * Limitation: If the historical prices series is too long, it could be possible an internal server time out error
	   *
	   * @param delta - <i>true</i> the procedure will download prices only from the last date present in historical prices data, <i>false</i> the procedure will download ALL historical prices data for each instrument
	   * @return the message with the outcome of the procedure 
	   */
	public String transferOptions(boolean delta) throws DataNotValidException;
	public void transferOptions(Instrument instr, boolean delta, List<Timestamp> calendList, Integer total, Integer failed, Integer updated) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * procedure built to download the inflation bonds historical prices series from INTRACS to PAMP system 
	   * <p>
	   * Limitation: If the historical prices series is too long, it could be possible an internal server time out error
	   *
	   * @param delta - <i>true</i> the procedure will download prices only from the last date present in historical prices data, <i>false</i> the procedure will download ALL historical prices data for each instrument
	   * @return the message with the outcome of the procedure 
	   */
	public String transferBonds(boolean delta) throws DataNotValidException;
	public void transferBonds(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * procedure built to download the historical prices series of instruments which have the derivatives history field value setted on 'T' from INTRACS to PAMP system 
	   * <p>
	   * Limitation: If the historical prices series is too long, it could be possible an internal server time out error
	   *
	   * @param delta - <i>true</i> the procedure will download prices only from the last date present in historical prices data, <i>false</i> the procedure will download ALL historical prices data for each instrument
	   * @return the message with the outcome of the procedure 
	   */
	public String transferCashFromFutures(boolean delta) throws DataNotValidException;
	public void transferCashFromFutures(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException;
	
	public String transferComparables(boolean delta) throws DataNotValidException;
	public void transferComparables(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException;
	
	public String transferCurrency(boolean delta) throws DataNotValidException;
	public void transferCurrency(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException;
	
	public String transferInterestRates(boolean delta) throws DataNotValidException;
	public void transferInterestRates(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException;
}
