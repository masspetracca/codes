package it.ccg.pamp.server.appint;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.ReadyToExpMarginHistory;

import java.util.Vector;

import javax.ejb.Local;

@Local
public interface AMPPAMPUnitLocal {
	public void updateMarginHistorySentStatusAfterExport(Vector<ReadyToExpMarginHistory> readymarghistvec) throws DataNotValidException;
}
