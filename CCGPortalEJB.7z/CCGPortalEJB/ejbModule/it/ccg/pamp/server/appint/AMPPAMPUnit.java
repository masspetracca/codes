package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.MarginHistoryEAOLocal;
import it.ccg.pamp.server.entities.MarginHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.ReadyToExpMarginHistory;

import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class AMPPAMPUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class AMPPAMPUnit implements  AMPPAMPUnitLocal {
	
	@EJB
	private MarginHistoryEAOLocal marHisEAO;
	
	

	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");

    
    
	public void updateMarginHistorySentStatusAfterExport(Vector<ReadyToExpMarginHistory> readymarghistvec) throws DataNotValidException {
		
		for (ReadyToExpMarginHistory readymarghist : readymarghistvec) {

			
			  MarginHistory marghist=marHisEAO.findByPrimaryKey(readymarghist.getMarhist().getPk().getInstrId(),readymarghist.getMarhist().getPk().getIniVDate());
			  marghist.setSent("T");
			  marghist.setUpdDate(GenericTools.systemDate());
			  marghist.setUpdType("U"); marghist.setUpdUsr("System");
			  
			  marHisEAO.logUpdate(marghist);
			
		}
		appIntLog.info(readymarghistvec.size() + " MarginHistory sent status updated");
		

	}

}
