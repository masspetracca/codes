package it.ccg.pamp.server.appint.backTest;

import it.ccg.pamp.server.eao.CalendarEAOLocal;
import it.ccg.pamp.server.eao.DerivativesHistoricalPriceEAOLocal;
import it.ccg.pamp.server.eao.HistoricalPricesEAO;
import it.ccg.pamp.server.eao.HistoricalPricesEAOLocal;
import it.ccg.pamp.server.eao.InstrIdTrascodeEAOLocal;
import it.ccg.pamp.server.eao.InstrumentEAOLocal;
import it.ccg.pamp.server.entities.DerivativesHistoricalPrice;
import it.ccg.pamp.server.entities.HistoricalPrices;
import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.HistoricalPriceToExport;
import it.ccg.pamp.server.utils.StressTestHistPricesReadyToExp;

import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class backTestExport
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class BackTestExport implements BackTestExportLocal {

	@EJB
	private HistoricalPricesEAOLocal histPriceEAO ;
	
	@EJB
	private DerivativesHistoricalPriceEAOLocal derHistPriceEAO ;
	
	@EJB
	private InstrumentEAOLocal instrEAO;
	
	@EJB
	private InstrIdTrascodeEAOLocal instrTranscodeEAO;
	
	@EJB
	private CalendarEAOLocal calendarEAO;
	
	@EJB
	private BackTestReUnitLocal backTestReUnit;
	
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public Vector<HistoricalPriceToExport> getFilterDate(int maxDays, String division) throws Exception {
	
		String divisionAcronymous = GenericTools.getWholeDivisCode(division);
		
		//numero di giorni massimo per i quali tornare indietro (prendere dalla setup???)
		//int maxDays = 4;
		
		//mercato di riferimento per l'utilizzo delle date se ne ho pi� di uno
		String mainMarket = "MTA";
		
		String dateInconstencyMsg = "Back test procedure will use the default market ("+mainMarket+") dates";
		
		// prendo la lista di mercati del comparto
		List<String> equityMarketCodeList = instrEAO.findMarketCodeList(division);
		
		//eccezione se non ci sono mercati validi per quel comparto
		if (equityMarketCodeList==null)
			throw new DataNotAvailableException("No available market found in "+divisionAcronymous+" division");
		
		Vector<Timestamp> appoDate = new Vector<Timestamp>();
		
		String lastMarket = "";
		
		//inizio a ciclare sulla calendar per prendermi le N date pi� recenti
		external:for (String marketCode:equityMarketCodeList) {
			
			LinkedHashMap<Timestamp,Integer> calendarMap = calendarEAO.getPreviousCalendarDateByDayAndMarketCode(GenericTools.systemDateMidNight(),marketCode,maxDays);
			
			//se il vettore di appoggio date � vuoto allora lo riempo
			if (appoDate.size()==0) {
				Set<Timestamp> keySet = calendarMap.keySet();
				
				for (Timestamp keyDate:keySet) {
					appoDate.add(keyDate);
				}
				
			} else {
				//ciclo nel vettore di appoggio per vedere se le date tra un mercato e l'altro sono diverse - va avanti finch� sono uguali e si ferma subito se sono diverse
				for (Timestamp dateToCheck:appoDate) {
					if (calendarMap.get(dateToCheck)==null) {
						appIntLog.warn("Date inconstency between "+marketCode+" and "+lastMarket+ "markets - "+dateInconstencyMsg);
						break external;
					}
				}
			}
				
			lastMarket = marketCode;
			
		}
		
		Timestamp refDate = appoDate.get(maxDays-1);
		
		//inizio costruzione oggettone x record da esportare
		//creo un'oggettone di appoggio che conterr� ogni istanza di tipo HistPrice e una stringa che identifica il classCode dello strumento 
		Vector<HistoricalPriceToExport> histPricesReadyToExpVect = new Vector<HistoricalPriceToExport>();
		
		Instrument[] instrArr = null;
		
		if (division.equalsIgnoreCase("E")) {
			//instrArr = instrEAO.getCash();
			String[] multipleDivisCode = new String[] {"E","D"};
			instrArr = instrEAO.getByMultipleDivisCode(multipleDivisCode);
		}
		
		if (division.equalsIgnoreCase("O"))
			instrArr = new Instrument[instrEAO.getInflationBonds().size()];
			instrEAO.getInflationBonds().toArray(instrArr);
		
		String toBeExported = "No equity cash or bond stressed prices found to export";
		
		int foundToExport = 0;
		
		if (instrArr.length==0) {
			throw new DataNotAvailableException("No active cash found to search related price history");
		} else {
				
			//cerco per ogni strumento il suo prezzo al giorno corrispondente
			for (Instrument instr:instrArr) {
				
				boolean isDerivative = false;
				
				HistoricalPrices histPrice = null;
				
				DerivativesHistoricalPrice[] derHistPriceArr = null;
				
				Instrument underlyingInstr = null;				
				//recupero dalle tabelle dei prezzi il record di cui voglio effettuare l'export
				
				//se � derivato valorizzo sia il prezzo del sottostante che la sua serie
				if (instr.getDivisCode().equalsIgnoreCase("D")) {
					isDerivative = true;
					derHistPriceArr = derHistPriceEAO.findByInstrIdAndDate(instr.getInstrId(), refDate);
					underlyingInstr = instrEAO.findByPrimaryKey(instr.getUndInstrId());
					histPrice = histPriceEAO.findByPrimaryKey(underlyingInstr.getInstrId(), refDate);
				} else {
					histPrice = histPriceEAO.findByPrimaryKey(instr.getInstrId(), refDate);
				}
				
				String noPriceFound = "No price series found for instrument "+instr.getInstrName()+" (instrId: "+instr.getInstrId()+") on date "+GenericTools.shortDateFormat(refDate);
				
				// se � derivato check doppio sia sulla serie del derivato che sul sottostante altrimenti solo sottostante
				if (isDerivative) {
					// se non ho storico del derivato vado avanti di un giorno
					if (derHistPriceArr.length==0) {
						derHistPriceArr = derHistPriceEAO.findByInstrIdAfterDate(instr.getInstrId(), refDate);
						if (derHistPriceArr.length==0) {
							appIntLog.warn(noPriceFound+" - using the first date available: "+GenericTools.shortDateFormat(histPrice.getPk().getPricedate()));
						} else {
							appIntLog.warn("No historical price series available for instrument "+instr.getInstrName()+" (instrId: "+instr.getInstrId()+")");
							//throw new DataNotAvailableException("No historical price series available for instrument "+instr.getInstrName()+" (instrId: "+instr.getInstrId()+")");
						}
					}
					
					String noUnderlyingPriceFound = "No underlying price series found for instrument "+underlyingInstr.getInstrName()+" (instrId: "+underlyingInstr.getInstrId()+") on date "+GenericTools.shortDateFormat(refDate);
					
					if (histPrice==null) {
						histPrice = histPriceEAO.findAfterDate(underlyingInstr.getInstrId(), refDate);
						if (histPrice!=null) {
							appIntLog.warn(noPriceFound+" - using the first date available: "+GenericTools.shortDateFormat(histPrice.getPk().getPricedate()));
						} else {
							appIntLog.warn(noUnderlyingPriceFound);
							//throw new DataNotAvailableException("No historical price series available for instrument "+instr.getInstrName()+" (instrId: "+instr.getInstrId()+")");
						}
					}
				} else {
					if (histPrice==null) {
						histPrice = histPriceEAO.findAfterDate(instr.getInstrId(), refDate);
						if (histPrice!=null) {
							appIntLog.warn(noPriceFound+" - using the first date available: "+GenericTools.shortDateFormat(histPrice.getPk().getPricedate()));
						} else {
							appIntLog.warn("No historical price series available for instrument "+instr.getInstrName()+" (instrId: "+instr.getInstrId()+")");
							//throw new DataNotAvailableException("No historical price series available for instrument "+instr.getInstrName()+" (instrId: "+instr.getInstrId()+")");
						}
					}
				}
				
				InstrIdTrascode[] instrIdTC = null;
				
				InstrIdTrascode[] rectifiedClassArray = null;
				
				// trascodifica soltanto nel caso MTA
				if (!division.equalsIgnoreCase("O")) {
					// recupero dalla tabella di transcodifica
					instrIdTC = instrTranscodeEAO.getSicInstr(instr.getInstrId());
					
					//trascodifica strumento (CERCO LE CLASSI RETTIFICATE)
					rectifiedClassArray = instrTranscodeEAO.getRectifiedClasses(instr.getInstrId());
					
					// se vuota blocco altrimenti aggiungo alla lista tutti gli eventuali trascodificati relativi allo strumento di cui l'indice � sottostante
					if (instrIdTC.length == 0) {
						throw new InstrumentDataNotAvailableException(instr.getInstrId(), "No Risk Engine instruments linked to this PAMP instrument id");
					}
				}
									
				//creo una nuova istanza dell'oggettone con tutto il prezzo stressato e il parametro del classcode e le eventuali transcodifiche su cui esportare il prezzo stressato
				HistoricalPriceToExport hpReadyToExport = new HistoricalPriceToExport(histPrice, derHistPriceArr, instr, underlyingInstr, instrIdTC, rectifiedClassArray,refDate);
			
				//aggiungo l'oggettone al vettore
				histPricesReadyToExpVect.add(hpReadyToExport);
				
				/*parte conteggi*/
				foundToExport++;
				
				
			}
		}
	
		if (foundToExport>0) {
			
			toBeExported = foundToExport+" equity cash stressed prices ready to be exported";
		}
			
		appIntLog.info(toBeExported);
		
		return histPricesReadyToExpVect;
		
 
		
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void exportPrice(int maxDays, String division) throws Exception {
	
		// preparo vettore ed esporto
		Vector<HistoricalPriceToExport> histPricesReadyToExpVect = this.getFilterDate(maxDays, division);
		
		appIntLog.info("Exporting back test values");
		
		if (histPricesReadyToExpVect.size()>0) {
			
			if (division.equalsIgnoreCase("E"))
				backTestReUnit.histPriceExport(histPricesReadyToExpVect);
			if (division.equalsIgnoreCase("O"))
				backTestReUnit.histBondPriceExport(histPricesReadyToExpVect);
			
		}
	
	}	
}
