package it.ccg.pamp.server.appint.backTest;
import it.ccg.pamp.server.utils.HistoricalPriceToExport;

import java.util.Vector;

import javax.ejb.Local;

@Local
public interface BackTestReUnitLocal {
	
	public void histPriceExport(Vector<HistoricalPriceToExport> histPricesReadyToExpVect) throws Exception;
	
	public void histBondPriceExport(Vector<HistoricalPriceToExport> histPricesReadyToExpVect) throws Exception;

}
