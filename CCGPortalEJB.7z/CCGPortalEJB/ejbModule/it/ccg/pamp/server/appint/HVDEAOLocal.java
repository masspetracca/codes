package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface HVDEAOLocal {

	public int transfer(String divisCode, boolean delta) throws DataNotValidException;

	public int transfer(int instrId, boolean delta) throws DataNotValidException;

}