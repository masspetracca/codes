package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.ClassMarginHistoryEAOLocal;
import it.ccg.pamp.server.eao.IntraClassOffsetHistoryEAOLocal;
import it.ccg.pamp.server.entities.ClassMarginHistory;
import it.ccg.pamp.server.entities.IntraclassOffsetHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.ReadyToExpClassMarginHistory;
import it.ccg.pamp.server.utils.ReadyToExpIntraClassOffsetHistory;

import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TAOPPAMPUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class TAOPPAMPUnit implements  TAOPPAMPUnitLocal {

	@EJB
	private IntraClassOffsetHistoryEAOLocal clTraHisEAO;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");

        
	public void updateIntraClassOffsetHistorySentStatusAfterExport(Vector<ReadyToExpIntraClassOffsetHistory> readyIntraClassOffsetHistVec) throws DataNotValidException {
		
		for (ReadyToExpIntraClassOffsetHistory readyIntraClassOffsetHist : readyIntraClassOffsetHistVec) {

			
			  IntraclassOffsetHistory clTraHist= clTraHisEAO.findByPrimaryKey(readyIntraClassOffsetHist.getClTraHist().getPk().getClassId(),readyIntraClassOffsetHist.getClTraHist().getPk().getIniVDate());
			  clTraHist.setSent("T");
			  clTraHist.setUpdDate(GenericTools.systemDate());
			  clTraHist.setUpdType("U"); 
			  clTraHist.setUpdUsr("System");
			  
			  clTraHisEAO.logUpdate(clTraHist);
			
		}
		appIntLog.info(readyIntraClassOffsetHistVec.size() + " Bond intraclass offset history sent status updated");
		

	}

}
