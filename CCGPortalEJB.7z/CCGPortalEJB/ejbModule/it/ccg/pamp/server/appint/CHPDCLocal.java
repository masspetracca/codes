package it.ccg.pamp.server.appint;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface CHPDCLocal {
	public String equityCashPriceDateConsistency() throws DataNotValidException;
}	
