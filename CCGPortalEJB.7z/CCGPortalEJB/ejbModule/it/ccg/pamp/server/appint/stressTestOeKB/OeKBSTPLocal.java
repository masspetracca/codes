package it.ccg.pamp.server.appint.stressTestOeKB;
import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.utils.StressTestHistPricesReadyToExp;

import java.util.Vector;

import javax.ejb.Local;

@Local
public interface OeKBSTPLocal {

	public Vector<StressTestHistPricesReadyToExp> getStressTestCashPricesReadyToExp(int stId, String scenario) throws DataNotValidException, InstrumentDataNotAvailableException;
	
	public void exportStressTest(StressTest lastStressTest, String scenario) throws Exception;
	
}
