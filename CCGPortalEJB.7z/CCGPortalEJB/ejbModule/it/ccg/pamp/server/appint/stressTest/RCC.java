package it.ccg.pamp.server.appint.stressTest;

import it.ccg.pamp.server.eao.Cpsrss1EAOLocal;
import it.ccg.pamp.server.eao.InstrIdTrascodeEAOLocal;
import it.ccg.pamp.server.eao.InstrumentEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestCgcls00fEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestSetupEAOLocal;
import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.entities.Cgcls00f;
import it.ccg.pamp.server.entities.ClassMarginHistory;
import it.ccg.pamp.server.entities.Cpsrss1;
import it.ccg.pamp.server.entities.Hfsrat2;
import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.InterclassOffsetHistory;
import it.ccg.pamp.server.entities.IntraclassOffsetHistory;
import it.ccg.pamp.server.entities.MarginHistory;
import it.ccg.pamp.server.entities.Mtsmgnf90f;
import it.ccg.pamp.server.entities.Mtsmgnf91f;
import it.ccg.pamp.server.entities.Mtsmgnf92f;
import it.ccg.pamp.server.entities.stressTest.StressTestCgcls00f;
import it.ccg.pamp.server.entities.stressTest.StressTestSetup;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.NumberOfErrorForCMCBatch;
import it.ccg.pamp.server.utils.PAMPinstruments;
import it.ccg.pamp.server.utils.PampRounder;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RCC
 */
@Stateless
public class RCC implements  RCCLocal {

	@EJB
	private InstrumentEAOLocal instrEAO;
	
	@EJB
	private InstrIdTrascodeEAOLocal instrIdTranscodeEAO;
	
	@EJB
	private Cpsrss1EAOLocal cpsrss1fEAO;
	
	@EJB
	private StressTestSetupEAOLocal stSetupEAO;
	
	
	private final Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public String checkDataPAMPVsIntracs(NumberOfErrorForCMCBatch numberOfErrorForCMCBatch) throws DataNotValidException {
		
		String sicInstrType = "";
		String instrType = "";
		String classCode = "";
		String sicClassCode = "";
		String isinCode = "";
		Timestamp stDate = null;
		
		String instrOnlyInPamp = "The following financial instruments are present on PAMP System but not on RE System: ";
		
		String instrOnlyInRE = "The following financial instruments are present on RE System but not on PAMP System: ";
		
		String instrInREAndPamp = "The following financial instruments are present both on RE System and on PAMP System: ";
		
		
		List<PAMPinstruments> PAMPinstrumentsList = new ArrayList<PAMPinstruments>();
		
		
		// ############################################################################
		
		Integer instrId = null;
		
		Integer lastInstrId = null;
		
		Instrument instr = new Instrument();
		
		StressTestSetup stSetup = null;
		
		LinkedHashMap<String,Timestamp> stDateMap = new LinkedHashMap<String, Timestamp>();
		
		// prendo tutti gli strumenti trascodificati
		InstrIdTrascode[] instrIdTrsCodeArr = instrIdTranscodeEAO.fetch();
		
		for (InstrIdTrascode instrIdTC:instrIdTrsCodeArr) {			
			boolean exportable = true;
			
			//Scrivo info utili per il log
			sicInstrType = instrIdTC.getPk().getSicInstrTy();
			sicClassCode = instrIdTC.getPk().getSicInstr();
							
			//se l'instrId � diverso dalla variabile di appoggio allora cerco info sulla instrumento			
			if (instrIdTC.getPk().getInstrId()!= lastInstrId) {
				
				instr = instrEAO.findByPrimaryKey(instrId);
				
				isinCode = instr.getIsinCode();
				instrType = instr.getInstrType();
			
				
				//se non trovo l'instrType inserito nella mappa delle date di stress verificate lo aggiungo
				if (stDateMap.get(sicInstrType)==null) {
				
					stSetup = stSetupEAO.findByPrimaryKey(instrType);
				
					stDate = stSetup.getHistUpdDay();
					
					stDateMap.put(sicInstrType, stDate);
					
				}
				
				//valorizzo variabile di appoggio
				lastInstrId = instrIdTC.getPk().getInstrId();
				
			}
			
			if(!instrIdTC.getStExport().equalsIgnoreCase("A")) {
				exportable = false;
			}
				
			PAMPinstruments pampInstr =  new PAMPinstruments(instrId, classCode, instrType, sicClassCode, sicInstrType, isinCode, stDate, exportable);	
					
			PAMPinstrumentsList.add(pampInstr);
		}	
			
		
		// ############################################################################
		// strumenti che sono sulla tabella dei prezzi INTRACS 
		//
		
		List<Timestamp> stDateList = new ArrayList<Timestamp>(stDateMap.values()) ;
		
		List<String> sicTypeList = new ArrayList<String>(stDateMap.keySet());
		
		LinkedHashMap<String, Cpsrss1> cpsrss1Map = new LinkedHashMap<String, Cpsrss1>();
		
		//ciclo per ogni data di stress prevista
		for (int i=0;i<stDateMap.size();i++) {
			
			//cerco filtrando su Intracs per stress test date e type
			List<Cpsrss1> cpsrss1List = cpsrss1fEAO.findByDateAndSicType(stDateList.get(i),sicTypeList.get(i));
			
			String hSymbl = "";
			
			//ciclo su Cpsrss1
			for (Cpsrss1 cpsrss1:cpsrss1List) {
				
				if (!cpsrss1.getPk().getHSymbl().equalsIgnoreCase(hSymbl)) {
				
					hSymbl = cpsrss1.getPk().getHSymbl();
					
					cpsrss1Map.put(hSymbl+"|"+cpsrss1.getHOfcod(),cpsrss1);
					
				}
				
			}
			
		}
		
		// inizio a scorrere l'oggettone x vedere quelli che sono su PAMP e non su SIC e segnalare quelli che ha trovato da entrambe le parti e le differenze
		for (PAMPinstruments pampInstr:PAMPinstrumentsList) {
			
			//se l'oggetto PAMP non � presente nella mappa INTRACS allora vuol dire che c'� differenza 
			//altrimenti lo strumento � sincronizzato
			if (cpsrss1Map.get(pampInstr.getSicClassCode()+"|"+pampInstr.getSicInstrType())!=null) {
				
				instrInREAndPamp += "instrId: "+pampInstr.getInstrId()+" - code: "+pampInstr.getSicClassCode()+" (type: "+pampInstr.getSicInstrType()+")";
				
				instrInREAndPamp+="\n";
				
				//riduco l'hashmap di quella riga
				cpsrss1Map.remove(pampInstr.getSicClassCode()+"|"+pampInstr.getSicInstrType());
			} else {

				instrOnlyInPamp+= "instrId: "+pampInstr.getInstrId()+" - code: "+pampInstr.getSicClassCode()+" (type: "+pampInstr.getSicInstrType()+")";;
				
				//devo informare se assente perch� non c'� sincro o perch� non � uno strumento esportabile
				if (!pampInstr.getExportable()) {
					instrOnlyInPamp+= "NOTE: this financial instrument is not required in stress test procedure and may not be sychronized";
				}
				
				instrOnlyInPamp+="\n";
				
			}
		}
		
		//tutti quelli rimasti nella hash map sono automaticamente mancanti
		
		//scorro la mappa
		List<Cpsrss1> cpsrssOnlyIntracs = new ArrayList<Cpsrss1>(cpsrss1Map.values());
		
		for (Cpsrss1 cps:cpsrssOnlyIntracs) {
			
			instrInREAndPamp += "code: "+cps.getPk().getHSymbl()+" (type: "+cps.getHOfcod()+")\n";
			
		}
		
		return "";
		
	}	
}
