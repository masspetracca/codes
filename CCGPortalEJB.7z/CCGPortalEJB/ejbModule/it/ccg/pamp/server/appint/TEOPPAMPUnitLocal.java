package it.ccg.pamp.server.appint;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.ReadyToExpInterClassOffsetHistory;

import java.util.Vector;

import javax.ejb.Local;

@Local
public interface TEOPPAMPUnitLocal {
	public void updateInterClassOffsetHistorySentStatusAfterExport(Vector<ReadyToExpInterClassOffsetHistory> readyInterClassOffsetHistVec) throws DataNotValidException;
}
