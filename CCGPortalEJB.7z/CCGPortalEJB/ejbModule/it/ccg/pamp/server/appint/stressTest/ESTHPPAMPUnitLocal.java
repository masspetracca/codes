package it.ccg.pamp.server.appint.stressTest;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.StressTestDerivativesHistPricesReadyToExp;
import it.ccg.pamp.server.utils.StressTestHistPricesReadyToExp;
import it.ccg.pamp.server.utils.StressTestIndexPricesReadyToExp;

import java.util.Vector;

import javax.ejb.Local;

@Local
public interface ESTHPPAMPUnitLocal {
	
	public void updateStressTestHPSentStatusAfterExport(Vector<StressTestHistPricesReadyToExp> stressTestHisPrToExpVect) throws DataNotValidException;
	
	public void updateStressTestDerHPSentStatusAfterExport(Vector<StressTestDerivativesHistPricesReadyToExp> stressTestDerivativesHisPrToExpVect) throws DataNotValidException;
	
	public void updateStressTestIndexSentStatusAfterExport(Vector<StressTestIndexPricesReadyToExp> stressTestIndexPricesReadyToExpVec) throws DataNotValidException;
	
	public void updateStressTestBondSentStatusAfterExport(Vector<StressTestHistPricesReadyToExp> stressTestBondToExpVect) throws DataNotValidException;
	
}
