package it.ccg.pamp.server.appint;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import it.ccg.pamp.server.eao.CalendarEAOLocal;
import it.ccg.pamp.server.eao.HistoricalPricesEAOLocal;
import it.ccg.pamp.server.eao.InstrumentEAOLocal;
import it.ccg.pamp.server.entities.Cpsrss1;
import it.ccg.pamp.server.entities.HistoricalPrices;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class CHPDC
 */
@Stateless
public class CHPDC implements  CHPDCLocal {

	@EJB private InstrumentEAOLocal instr=null;
	@EJB private CalendarEAOLocal calend=null;
	@EJB private HistoricalPricesEAOLocal hisPr=null;
	
	
	
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	/**
	   * @author nelli
	   * <p>
	   * procedure built to check the historical prices series consistency vs calendar in PAMP system 
	   * <p>
	   * Limitation: If the historical prices series is too long, it could be possible an internal server time out error
	   *
	   * @return the message with the outcome of the procedure 
	   */
	
	
	
	public String equityCashPriceDateConsistency() throws DataNotValidException {
		
		GregorianCalendar cal = new GregorianCalendar(1900,0,1);
		Timestamp firstDate = new Timestamp(cal.getTimeInMillis());
		Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
		
		String calendarEmptyError = "No dates avalaible for this marketCode: ";
		
		String msgBody = "";
			
		Instrument[] instrument = instr.getCash();
		
		int totalMissing = 0;
		
		int withoutHistory = 0;
		
		boolean recordNotFound = false;
		
		if (instrument.length>0) {
			
			appIntLog.info(instrument.length+" equity cash financial instruments ready to been checked");
			
			for (Instrument instr:instrument) {
				int instrDateMissing = 0;
				/*recupero instrId, classCode e marketCode da instrument*/ 
				int instrId = instr.getInstrId();
				String classCode = instr.getClassCode();
				String marketCode = instr.getMarketCode();
				String dateMissing = "";
				String instrIdString = "instrId "+instrId+" (classCode: "+classCode+")";
				
				appIntLog.info("Starting check for "+instrIdString);
				
				/*prendo su HistoricalPrices la prima e l'ultima data per ogni instrId*/ 
				HistoricalPrices[] historicalPricesArray = hisPr.findByInstrId(instrId);
				
				//costruisco una lista di timestamp che popolo soltanto nel caso in cui ci sia almeno un prezzo storico per lo strumento
				List<Timestamp> historicalPriceDatesList = new ArrayList<Timestamp>();  
			
				if (historicalPricesArray.length>0) {
					String histPricesLogString = historicalPricesArray.length+" historical prices found for "+instrIdString;
					
					for (HistoricalPrices histPrice:historicalPricesArray) {
						historicalPriceDatesList.add(histPrice.getPk().getPricedate());
					}
					
					lastDate = historicalPricesArray[0].getPk().getPricedate();
										
					if (historicalPricesArray.length>1) {
						firstDate = historicalPricesArray[historicalPricesArray.length-1].getPk().getPricedate();
						histPricesLogString += " - first date: "+firstDate.toString().substring(0,10)+"; last date: "+lastDate.toString().substring(0,10);
					} else {
						firstDate = lastDate;
						histPricesLogString += " - first and last date: "+lastDate.toString().substring(0,10);
					}
					
					appIntLog.info(histPricesLogString);
					
					
					//cerco su PMPTCALEND per MARKETCODE e DATE INIZIO/FINE
					/*  solo se ho almeno un record di prezzo storico*/
					List<Timestamp> calendDateList = calend.getListDateByStartEndDate(marketCode,firstDate,lastDate);
				
					if (calendDateList.size()==0) {
						appIntLog.warn(calendarEmptyError+marketCode);
						// se non trova date sul calendario
						msgBody += calendarEmptyError+marketCode+" and first date "+firstDate+" and last date "+lastDate+"\n\n";
						
					} else {
						dateMissing = "";
						// ciclo sullo storico dei prezzi		
						for (Timestamp calDate:calendDateList) {
							/*se la data di calendario � contenuta tra quelle dello storico allora non c'� buco altrimenti warning*/
							if (!historicalPriceDatesList.contains(calDate)) {
								dateMissing += "Price date is missing in PAMP Historical prices series table: "+calDate.toString().substring(0, 10)+"\n\n";
								//scrivo sul log che c'� un buco tra le date
								
								appIntLog.warn("Price date is missing in PAMP Historical prices series table: "+calDate.toString().substring(0, 10)+" for instrument Id "+instrId+" ("+classCode+")");
								instrDateMissing++;
							}
						}	
					}
					if (instrDateMissing>0) {
						appIntLog.info(instrDateMissing+" missing price date for "+instrIdString);
						msgBody = instrDateMissing+" missing price date for "+instrIdString;
						msgBody+="\n\n"+dateMissing;
					} else {
						appIntLog.info("No missing price date for "+instrIdString);
					}
				} else {
					// se non trova storico dei prezzi
					appIntLog.warn("No historical prices found for "+instrIdString);
					msgBody += "No historical prices found for "+instrIdString+"\n\n";
					withoutHistory++;
				}
				//aggiungo al contatore generale quelli del singolo strumento
				totalMissing+=instrDateMissing;
			}
			
		} else {
			// se non trova strumenti
			appIntLog.warn("No equity cash financial instruments found. Check stopped.");
			msgBody = "No equity cash financial instruments found. Check stopped.";
			recordNotFound = true;
		}
		
		
		//scrittura testo di ritorno per corpo del messaggio
		if (!recordNotFound) {
		
			String headMsgBody = "Check of equity financial instruments price dates consistency finished: ";
			if (totalMissing>0) {
				headMsgBody+= totalMissing+" inconsistency found\n\n";
				if (withoutHistory>0) {
					headMsgBody+= withoutHistory+" financial instruments without history found\n\n";
				}
			} else {
				headMsgBody+=" all instrument are consistent with the calendar";
			}
			
			msgBody = headMsgBody+"\n\n"+msgBody;
		}
		
		return msgBody;
	}
	
}
