package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.GroupHistoryEAOLocal;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.ReadyToExpGroupHistory;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class GCE
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class GCE implements  GCELocal {

	@EJB
	private GroupHistoryEAOLocal groupHistoryEAO;
	
	@EJB
	private GCEINTRACSUnitLocal gceIntracsunit;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	
	
	@Override
	public List<ReadyToExpGroupHistory> getGroupsAndComponentsReadyToExp() throws DataNotValidException {

		//lista di gruppi e componenti pronti per l'export
		List<ReadyToExpGroupHistory> groupHisToExp = groupHistoryEAO.getGroupHistoryToExport(2);

		int groupCount = 0;
		
		int lastExportedGroupId = 0;
		
		for (ReadyToExpGroupHistory grHistory : groupHisToExp) {
			
			if (lastExportedGroupId!=grHistory.getGrId()) {
				
				lastExportedGroupId = grHistory.getGrId();
				groupCount++;
			}
			
		}
		
		String toBeExported = "";
		
		//stringa riepilogativa
		if (groupHisToExp.size()==0) {
			toBeExported = "No group found to export";
		} else {
			if (groupCount==1) {
				toBeExported = groupCount+" group ";
			} else {
				toBeExported = groupCount+" groups ";
			}
			
			toBeExported+= "containing ";
			
			if (groupHisToExp.size()==1) {
				toBeExported+= "1 component ";
			} else {
				toBeExported+= groupHisToExp.size()+" components ";
			}
			
			toBeExported += "ready to be exported";
		}
		
		appIntLog.info(toBeExported);

		return groupHisToExp;
	}
	
	
	@Override
	public List<ReadyToExpGroupHistory> getGroupsReadyToExp() throws DataNotValidException {

		//lista di gruppi e componenti pronti per l'export
		List<ReadyToExpGroupHistory> groupHisToExp = groupHistoryEAO.getGroupHistoryToExport(1);

		int groupCount = 0;
		
		int lastExportedGroupId = 0;
		
		for (ReadyToExpGroupHistory grHistory : groupHisToExp) {

			if (lastExportedGroupId!=grHistory.getGrId()) {
				
				lastExportedGroupId = grHistory.getGrId();
				groupCount++;
			}
			
		}
		
		String toBeExported = "";
		
		//stringa riepilogativa
		if (groupHisToExp.size()==0) {
			toBeExported = "No group found to export";
		} else {
			if (groupCount==1) {
				toBeExported = groupCount+" group ready to be exported";
			} else {
				toBeExported = groupCount+" groups ready to be exported";
			}
		}
		
		appIntLog.info(toBeExported);

		return groupHisToExp;
	}

	


	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void export() throws Exception {
		
		List<ReadyToExpGroupHistory> readyGroupsToExp = this.getGroupsReadyToExp();
		
		List<ReadyToExpGroupHistory> readyGroupsAndComponentsToExp = this.getGroupsAndComponentsReadyToExp();

		if (readyGroupsAndComponentsToExp.size()>0) {
		
			gceIntracsunit.exportPampGroupsToIntracs(readyGroupsToExp);
			
			gceIntracsunit.exportPampGroupAndComponentsHistoryToIntracs(readyGroupsAndComponentsToExp);
			
			
			
		}

	}
	
}
