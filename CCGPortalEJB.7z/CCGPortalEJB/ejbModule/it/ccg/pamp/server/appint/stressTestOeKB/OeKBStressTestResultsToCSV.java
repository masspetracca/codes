package it.ccg.pamp.server.appint.stressTestOeKB;

import it.ccg.pamp.server.eao.stressTest.StressTestEAOLocal;
import it.ccg.pamp.server.eao.stressTest.StressTestSetupEAOLocal;
import it.ccg.pamp.server.eao.stressTestOeKB.OeKBStressTestResultEAOLocal;
import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestSetup;
import it.ccg.pamp.server.entities.stressTestOeKB.OeKBStressTestResult;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.properties.PropertiesEAOLocal;
import it.ccg.pamp.server.utils.GenericTools;

import java.io.File;
import java.io.FileWriter;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class OeKBStressTestResultsToCSV
 */
@Stateless
public class OeKBStressTestResultsToCSV implements OeKBStressTestResultsToCSVLocal {

	@EJB
	private PropertiesEAOLocal properties;
	
	@EJB
	private StressTestSetupEAOLocal stSetupEAO;
	
	@EJB
	private OeKBStressTestResultEAOLocal oekbstResultEAO;
	
	@EJB
	private StressTestEAOLocal stEAO;
	
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	public File createCsvFile() throws Exception {
		
		//funzione gi� predisposta per leggere dalla setup l'eventuale range temporale entro cui tornare indietro per la ricerca
		
		
		int monthsAgo = 3;
		
		List<StressTest> stList = stEAO.fetch();
		
		File csvFile = null;
		
		if (stList==null||stList.size()==0) {
			throw new DataNotAvailableException("No stress test executed");
		} else {
			String stString = "stress tests";
			String recordString = "records";
			
			//data di blocco
			Timestamp firstStDate = GenericTools.getPastDateForMonthsAgo(stList.get(0).getLstHistDat(), monthsAgo);
			
			StressTestSetup stSetup = null;
			
			if (stSetupEAO.fetchStressTestSetupsByDivisCode(stList.get(0).getDivisCode())!=null && stSetupEAO.fetchStressTestSetupsByDivisCode(stList.get(0).getDivisCode()).size()>0)
				stSetup = stSetupEAO.fetchStressTestSetupsByDivisCode(stList.get(0).getDivisCode()).get(0);
			
			
			boolean warn = false;
			
			if (stSetup==null || (Integer) stSetup.getLstMntRep()==null || stSetup.getLstMntRep()==0) {
				warn = true;
			} else {
				monthsAgo = stSetup.getLstMntRep();
			}
			
			String monthStr = "month";
			if (monthsAgo>1)
				monthStr +="s";
			
			String lookBackStr = "Looking back the member statistics back for the period of "+monthsAgo+" months";
			
			if (warn) { 
				lookBackStr = "No look back period found on stress stest settings, using the default period of "+monthsAgo+" months";
				appIntLog.warn(lookBackStr);
			} else {
				appIntLog.info(lookBackStr);
			}
				
			//contatore stress test
			int counter = 0;
			
			// conto tutti gli stressTest da utilizzare per il log
			for (StressTest st:stList) {
				if (st.getLstHistDat().compareTo(firstStDate)>=0) {
					counter++;
				} else {
					break;
				}
			}
			
			// memorizzo lo stress test id da cui startare la ricerca sulla PMPTSTRES
			int firstStId = stList.get(counter-1).getStId();
			
			int lastStId = stList.get(0).getStId();
			
			if (counter==1)
				stString = "stress test";
			
			
			String rootDirectory = "";
			
			//directory di sistema dove salvare il file per lo scarico da pamp
			if (System.getProperty("user.install.root")!=null) {
				rootDirectory = System.getProperty("user.install.root");
			} else {
				throw new Exception("unable to locate the root directory.");
			}
			
			if (rootDirectory.substring(rootDirectory.length()-4).equalsIgnoreCase("/bin"))
				rootDirectory = rootDirectory.substring(0,rootDirectory.length()-4);
				
			rootDirectory += properties.getPropertyMap().get("spoolFileDir");	
			
			
			appIntLog.info(counter+" "+stString+" found from "+GenericTools.shortDateFormat(firstStDate)+" (stress test id "+firstStId+") to "+GenericTools.shortDateFormat(stList.get(0).getLstHistDat())+ " (stress test id "+lastStId+")");
			
			// cerco sulla PMPTSTRES a partire dallo STID pi� piccolo
			List<OeKBStressTestResult> oekbstResultsList = oekbstResultEAO.findBetweenStIdInterval(firstStId, lastStId);
			
			if (oekbstResultsList==null||oekbstResultsList.size()==0) {
				throw new DataNotAvailableException("No member statistics found for the selected period");
			} else {
				if (oekbstResultsList.size()==1)
					recordString = "record";
			
				appIntLog.info(oekbstResultsList.size()+" "+recordString+" found");
				
				//data di sistema in formato stringa per dare un nome al file
				String curDate = Long.toString(GenericTools.systemDateLongFormat());
				
				
				String fileName = "STRESULTS"+curDate+".csv";
				
				String fileLocation = rootDirectory+fileName;
				
				//appIntLog.info("local report path: "+rootDirectory);
				
				// creates the file
				csvFile = new File(fileLocation);
							
			    csvFile.createNewFile(); 
	
			    // creates a FileWriter Object
			    FileWriter writer = new FileWriter(csvFile); 
			    
			    // Writes the content to the file
			    /*String txtHead = "ISINCODE;WORKING MARGIN";
				writer.write(txtHead+"\n");*/
				
				counter = 0;
				
				//23072012
				// set the first row to currentDate 
				String txtLine = properties.getPropertyMap().get("stMbrFileHeader")/*.replaceAll(",",";")*/;
				writer.write(txtLine+"\n");
				
				for (OeKBStressTestResult stResult:oekbstResultsList) {
					counter++;
					txtLine = stResult.stResultRow();
					if (counter<oekbstResultsList.size()) {
						txtLine+="\n";
					}
					writer.write(txtLine/*.replaceAll(",",";")*/);
				}
				
				
				//23072012
				// set the last row to the total record count 
				//writer.write("\n"+oekbstResultsList.size());
				
				writer.flush();
				writer.close();
				
				appIntLog.info(fileName+" generated by PAMP System");
				
				/* PARTE FTP opzionale 
				boolean exportOk = true;
				
				//Upload FTP
				try {
					appIntLog.info("Starting FTP upload");
					FTPUpload.upload(csvFile, fileName, properties.getPropertyMap());
					//FTPUpload ftp = new FTPUpload(file, fileName);
					appIntLog.info("FTP upload completed");
				} catch (Exception e) {
					appIntLog.error("Error occurred during the FTP upload: "+e.getMessage());
					e.printStackTrace();
					exportOk = false;
				}
				
				
				if (exportOk) {
					strLog = "New file named "+fileName+" has been created on PAMP System and uploaded via FTP";
				} else {
					strLog = "New file named "+fileName+" has been created on PAMP System but an error occurred during the FTP upload";
				}
				**/
			}
		}
		return csvFile;
	}

}
