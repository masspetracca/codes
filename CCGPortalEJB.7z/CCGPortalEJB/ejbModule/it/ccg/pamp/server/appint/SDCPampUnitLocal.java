package it.ccg.pamp.server.appint;
import it.ccg.pamp.server.entities.Cgcls00f;
import it.ccg.pamp.server.entities.WMtsprc0hf;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondToSync;

import java.util.LinkedHashMap;
import java.util.List;

import javax.ejb.Local;

@Local
public interface SDCPampUnitLocal {
	
	public String upsertInstrumentsOnPamp(List<Cgcls00f> cgcls00fList,LinkedHashMap<String,String> tfForxMap, String marketCode) throws DataNotValidException, DataNotAvailableException;
	
	public String upsertBondInstrumentsOnPamp(List<BondToSync> bondToSyncList) throws DataNotValidException, DataNotAvailableException;
}
