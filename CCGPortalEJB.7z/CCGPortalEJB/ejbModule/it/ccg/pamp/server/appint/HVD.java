package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.CalendarEAOLocal;
import it.ccg.pamp.server.eao.Ccgpvis30fEAOLocal;
import it.ccg.pamp.server.eao.HistoricalVolSeriesEAOLocal;
import it.ccg.pamp.server.eao.InstrumentEAOLocal;
import it.ccg.pamp.server.entities.Ccgpvis30f;
import it.ccg.pamp.server.entities.HistoricalVolSeries;
import it.ccg.pamp.server.entities.HistoricalVolSeriesPK;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class HVD implements HVDEAOLocal {
	private static final long serialVersionUID = 1L;
	@EJB private HistoricalVolSeriesEAOLocal hisVol=null;
	@EJB private InstrumentEAOLocal instr=null;
	@EJB private Ccgpvis30fEAOLocal ccgpvis=null;
	@EJB private CalendarEAOLocal calend=null;
	
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	public int transfer(String divisCode, boolean delta) throws DataNotValidException {
		int counter=0;
		Instrument[] instrument = (Instrument[]) instr.getByDivisCode(divisCode);
		for (int i=0;i<instrument.length;i++) {
			try {
				counter+=transfer(instrument[i].getInstrId(), delta);
			} catch (Exception e) {
				String error = "Error happened on INSTRID "+instrument[i].getInstrId()+" (Code: "+instrument[i].getClassCode();
				appIntLog.debug(error+"\n"+e.getMessage()+"\n"+e.getStackTrace());
			}
		}
		return counter;
	}
	
	
	/* (non Javadoc)
	 * @see it.ccg.pamp.server.appint.HVDEAOLocal#transfer(int, boolean)
	 */
	/* (non Javadoc)
	 * @see it.ccg.pamp.server.appint.HVDEAORemote#transfer(int, boolean)
	 */
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public int transfer(int instrId, boolean delta) throws DataNotValidException {
		int counter=0;

		boolean primo = true;
		GregorianCalendar cal;
		cal = new GregorianCalendar(1900,0,1);
		Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
		
		if (!delta) {
			hisVol.removeByInstrId(instrId);
		}
			
		/*recupero classCode e marketCode da instrument*/ 
		Instrument instrument = (Instrument) instr.findByPrimaryKey(instrId);
		String v3class = instrument.getClassCode();
		String error = "Error happened on INSTRID "+instrId+" (Code: "+v3class+" Date:";
		String marketCode = instrument.getMarketCode();
		/*scarico la lista di cpsrss2*/
		Ccgpvis30f[] ccgpvis30f = (Ccgpvis30f[]) ccgpvis.findByV3class(v3class);
		List<Timestamp> dates = calend.getListDate(marketCode);
		Timestamp tmstpDate;
		Timestamp[] arrDates = new Timestamp[dates.size()];
		dates.toArray(arrDates);
		int[] expiry = new int[6];
		String[] isinCode = new String[6];
		BigDecimal[] vOlim = new BigDecimal[6];
		int[] prgEx = new int[6];
		String pc = "";
		BigDecimal strike = new BigDecimal(0);
		for (int i=0; i<ccgpvis30f.length;i++) {
			//Conversione date da long a timestamp
			
			tmstpDate = GenericTools.convertDateFromIntToTimestamp((int) ccgpvis30f[i].getPk().getV3dtarif());
			if (dates.contains(tmstpDate)) {
				if (ccgpvis30f[i].getPk().getV3strik() != null) {
					//settaggio dei sei parametri di scadenza
					prgEx[0] = ccgpvis30f[i].getV3prgex1().intValue();
					prgEx[1] = ccgpvis30f[i].getV3prgex2().intValue();
					prgEx[2] = ccgpvis30f[i].getV3prgex3().intValue();
					prgEx[3] = ccgpvis30f[i].getV3prgex4().intValue();
					prgEx[4] = ccgpvis30f[i].getV3prgex5().intValue();
					prgEx[5] = ccgpvis30f[i].getV3prgex6().intValue();
					
					expiry[0] = ccgpvis30f[i].getV3expir1().intValue();
					expiry[1] = ccgpvis30f[i].getV3expir2().intValue();
					expiry[2] = ccgpvis30f[i].getV3expir3().intValue();
					expiry[3] = ccgpvis30f[i].getV3expir4().intValue();
					expiry[4] = ccgpvis30f[i].getV3expir5().intValue();
					expiry[5] = ccgpvis30f[i].getV3expir6().intValue();
					
					vOlim[0] = ccgpvis30f[i].getV3volim1();
					vOlim[1] = ccgpvis30f[i].getV3volim2();
					vOlim[2] = ccgpvis30f[i].getV3volim3();
					vOlim[3] = ccgpvis30f[i].getV3volim4();
					vOlim[4] = ccgpvis30f[i].getV3volim5();
					vOlim[5] = ccgpvis30f[i].getV3volim6();
					
					//settaggio dei sei isinCode
					isinCode[0] = ccgpvis30f[i].getPk().getV3cusip1();
					isinCode[1] = ccgpvis30f[i].getPk().getV3cusip2();
					isinCode[2] = ccgpvis30f[i].getPk().getV3cusip3();
					isinCode[3] = ccgpvis30f[i].getPk().getV3cusip4();
					isinCode[4] = ccgpvis30f[i].getPk().getV3cusip5();
					isinCode[5] = ccgpvis30f[i].getPk().getV3cusip6();
					
					pc = ccgpvis30f[i].getPk().getV3pc();
					strike = ccgpvis30f[i].getPk().getV3strik();
					if (delta) {
						if (primo) {
							//prendo su HistoricalVolSeries la data pi� grande per quell'instrId
							HistoricalVolSeries[] historicalVolSeries = hisVol.findByInstrId(instrId);
							if (historicalVolSeries!=null) {
								lastDate = historicalVolSeries[0].getPk().getVolaDate();
							}
							primo = false;
						}
					}
					if (delta) {
						if (tmstpDate.after(lastDate)) {
							for (int j=0;j<prgEx.length;j++) {
								HistoricalVolSeries histVolSeries = new HistoricalVolSeries();
								HistoricalVolSeriesPK histVolSeriesPk = new HistoricalVolSeriesPK();
								histVolSeriesPk.setInstrId(instrId);
								histVolSeriesPk.setVolaDate(tmstpDate);
								histVolSeriesPk.setPc(pc);
								histVolSeriesPk.setStrike(strike);
								histVolSeries.setStatus("E");
								if (prgEx[j]!=0) {
									histVolSeriesPk.setProgExp(prgEx[j]);
									histVolSeriesPk.setIsinCode(isinCode[j]);
									histVolSeries.setVola(vOlim[j]);
									histVolSeries.setExpiry(expiry[j]);
									histVolSeries.setPk(histVolSeriesPk);
									hisVol.store(histVolSeries);
								}
							}
						}
					} else {
						for (int j=0;j<isinCode.length;j++) {
							HistoricalVolSeries histVolSeries = new HistoricalVolSeries();
							HistoricalVolSeriesPK histVolSeriesPk = new HistoricalVolSeriesPK();
							histVolSeriesPk.setInstrId(instrId);
							histVolSeriesPk.setVolaDate(tmstpDate);
							histVolSeriesPk.setPc(pc);
							histVolSeriesPk.setStrike(strike);
							histVolSeries.setStatus("E");
							if (prgEx[j]!=0) {
								histVolSeriesPk.setProgExp(prgEx[j]);
								histVolSeriesPk.setIsinCode(isinCode[j]);
								histVolSeries.setVola(vOlim[j]);
								histVolSeries.setExpiry(expiry[j]);
								histVolSeries.setPk(histVolSeriesPk);
								hisVol.store(histVolSeries);
							}
						}
					}
					counter++;
				} else {
					appIntLog.warn(error+ccgpvis30f[i].getPk().getV3dtarif()+") - Null value found for Strike in this position");
					//throw new NullData(error+ccgpvis30f[i].getPk().getV3dtarif()+") - Null value found for Strike in this position");
				}
			}
		}
		return counter;
	}
}
