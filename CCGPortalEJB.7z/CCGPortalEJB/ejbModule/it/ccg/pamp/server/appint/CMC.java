package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.BondClassEAOLocal;
import it.ccg.pamp.server.eao.Cgcls00fEAOLocal;
import it.ccg.pamp.server.eao.ClassMarginHistoryEAOLocal;
import it.ccg.pamp.server.eao.Hfsrat2EAOLocal;
import it.ccg.pamp.server.eao.InstrIdTrascodeEAOLocal;
import it.ccg.pamp.server.eao.InstrumentEAOLocal;
import it.ccg.pamp.server.eao.InterClassOffsetHistoryEAOLocal;
import it.ccg.pamp.server.eao.IntraClassOffsetHistoryEAOLocal;
import it.ccg.pamp.server.eao.MarginHistoryEAOLocal;
import it.ccg.pamp.server.eao.Mtsmgnf90fEAOLocal;
import it.ccg.pamp.server.eao.Mtsmgnf91fEAOLocal;
import it.ccg.pamp.server.eao.Mtsmgnf92fEAOLocal;
import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.entities.Cgcls00f;
import it.ccg.pamp.server.entities.ClassMarginHistory;
import it.ccg.pamp.server.entities.Hfsrat2;
import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.InterclassOffsetHistory;
import it.ccg.pamp.server.entities.IntraclassOffsetHistory;
import it.ccg.pamp.server.entities.MarginHistory;
import it.ccg.pamp.server.entities.Mtsmgnf90f;
import it.ccg.pamp.server.entities.Mtsmgnf91f;
import it.ccg.pamp.server.entities.Mtsmgnf92f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.NumberOfErrorForCMCBatch;
import it.ccg.pamp.server.utils.PAMPinstruments;
import it.ccg.pamp.server.utils.PampRounder;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class CMC
 */
@Stateless
public class CMC implements  CMCLocal {

	@EJB
	private MarginHistoryEAOLocal marHisEAO ;
	
	@EJB
	private ClassMarginHistoryEAOLocal clMarHisEAO;
	
	@EJB
	private IntraClassOffsetHistoryEAOLocal traHisEAO;
	
	@EJB
	private InterClassOffsetHistoryEAOLocal terHisEAO;
	
	@EJB
	private InstrumentEAOLocal instrEAO;
	
	@EJB
	private BondClassEAOLocal bndClassEAO;
	
	@EJB
	private InstrIdTrascodeEAOLocal instrTrancodeEAO;
	
	@EJB
	private Cgcls00fEAOLocal cgcls00fEAO ;
	
	@EJB
	private Mtsmgnf90fEAOLocal mtsmgnf90fEAO;
	
	@EJB
	private Mtsmgnf91fEAOLocal mtsmgnf91fEAO;
	
	@EJB
	private Mtsmgnf92fEAOLocal mtsmgnf92fEAO;
	
	@EJB
	private Hfsrat2EAOLocal hfsrat2EAO;
	
	
	
	private final MathContext mathC = new MathContext(4,RoundingMode.HALF_EVEN);
	
	private final BigDecimal cashMinMarTv = new BigDecimal(1).divide(new BigDecimal(1000));
	
	private final Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public String checkDataPAMPVsIntracs(NumberOfErrorForCMCBatch numberOfErrorForCMCBatch) throws DataNotValidException {
		
		String sicInstrType = "";
		String instrType = "";
		String classCode = "";
		String sicClassCode = "";
		
		int PAMPmarNotFound = 0;
		int PAMPstraNotFound = 0;
		int REmarNotFound = 0;
		int REstraNotFound = 0;
		int inconsistentMargins = 0;
		int inconsistentStraddles = 0;
		//BigDecimal roundDigit = new BigDecimal(0.0001);
		
		List<PAMPinstruments> PAMPinstrumentsList = new ArrayList<PAMPinstruments>();
		
		
		// ############################################################################
		// strumenti che sono sulla MARHIS
		List<Instrument> instrumentList = instrEAO.getInstrumentInMarHis();
		
		// ############################################################################
		// strumenti che sono su INTRACS (margini e straddle)
		//ottieni margini e margini minimi
		Cgcls00f[] arrCgcls00f = cgcls00fEAO.fetch();
		
		//ottieni offset degli straddle
		List<Hfsrat2> arrHfsrat2 = hfsrat2EAO.fetch();
		
		String lastDivisCode = "";
		
		BigDecimal marRoundTv = null;
		BigDecimal minMarRoundTv = null;
		BigDecimal straRoundTv = null;
		
		
		for (Instrument instr:instrumentList) {
			
			MarginHistory marHis = marHisEAO.getLastSentMargin(instr.getInstrId());
			
			
			
			BigDecimal margin = marHis.getMargin();
			BigDecimal minMargin = marHis.getMinMargin();
			BigDecimal straddle = marHis.getStraddle();
			
			instrType = instr.getInstrType();
			classCode = instr.getClassCode();
			
			// tramite transcodifica mi costruisco l'oggettone con tutti i campi che mi servono per iniziare la fase di confronto
			
			InstrIdTrascode[] idTranscode = instrTrancodeEAO.getSicInstr(instr.getInstrId());
			for (InstrIdTrascode trsInstr:idTranscode) {
				
				sicInstrType = trsInstr.getPk().getSicInstrTy();
				sicClassCode = trsInstr.getPk().getSicInstr();
				
				if (!instr.getDivisCode().equals(lastDivisCode)) {
					//Setup setup = setupEAO.findByPrimaryKey(instr.getDivisCode());
					lastDivisCode = instr.getDivisCode();
					//marRoundTv = setup.getMarRoundTv();
					//minMarRoundTv = setup.getMinRoundTv();
					//straRoundTv = setup.getStrRoundTv();
				}
				
				
				BigDecimal marCoeff = trsInstr.getMarCf();
				BigDecimal minMarCoeff = trsInstr.getMinMarCf();
				BigDecimal straddleCoeff = trsInstr.getStraddleCf();
				
				
				if (margin!=null) {
					//System.out.println("InstrId: "+instr.getInstrId()+" - PAMP margin:"+margin);
					//margin=PampRounder.round(margin.multiply(marCoeff), "N", marRoundTv.divide(new BigDecimal(100)));
					//System.out.println("PRIMA"+margin.multiply(marCoeff,new MathContext(8)));
					//margin=PampRounder.round(margin.multiply(marCoeff,new MathContext(8)), "N", roundDigit);
					margin = margin.multiply(marCoeff,mathC);
					//System.out.println("DOPO"+margin+"---"+marCoeff);
					//System.out.println("InstrId: "+instr.getInstrId()+" - PAMPROUNDER margin:"+margin+" - coeff: "+marCoeff+" - marRoundTv: "+marRoundTv);
				}
				
				if (minMargin!=null) {
					//System.out.println("InstrId: "+instr.getInstrId()+" - PAMP minMargin:"+minMargin);
					
					if (sicInstrType.equalsIgnoreCase("C")) {
						minMarRoundTv = cashMinMarTv;
					}
					
					//minMargin=PampRounder.round(minMargin.multiply(minMarCoeff), "N", minMarRoundTv);
					//minMargin=PampRounder.round(minMargin.multiply(minMarCoeff), "N", roundDigit);
					minMargin=minMargin.multiply(minMarCoeff,mathC);
					//System.out.println("InstrId: "+instr.getInstrId()+" - PAMPROUNDER minMargin:"+minMargin+" - coeff: "+minMarCoeff+" - minMarRoundTv: "+minMarRoundTv);
				}
				
				if (straddle!=null) {
					//System.out.println("InstrId: "+instr.getInstrId()+" - PAMP straddle:"+straddle);
					//straddle=PampRounder.round(straddle.multiply(straddleCoeff), "N", straRoundTv);
					//straddle=PampRounder.round(straddle.multiply(straddleCoeff), "N", roundDigit);
					straddle=straddle.multiply(straddleCoeff,mathC);
					//System.out.println("InstrId: "+instr.getInstrId()+" - PAMPROUNDER straddle:"+straddle+" - coeff: "+straddleCoeff+" - straRoundTv: "+straRoundTv);
				}
				
				
				PAMPinstruments pampInstr = new PAMPinstruments(instr.getInstrId(),classCode,instrType,sicClassCode,sicInstrType,margin,minMargin,straddle,instr.getMinMarType(),instr.getStraType());
				//System.out.println("PAMP INSTRUMENTS: "+instr.getInstrId()+","+classCode+","+instrType+","+sicClassCode+","+sicInstrType+","+margin+","+minMargin+","+straddle+","+instr.getStraType());
				PAMPinstrumentsList.add(pampInstr);
			}
			
		}
		
		String instrInPAMPnotInREMar = "";
		String instrInPAMPnotInREStra = "";
		String instrInREnotInPAMPMar = "";
		String instrInREnotInPAMPStra = "";
		String marginValueDiff="";
		String straddleValueDiff="";
		
		
		String cgcClassCode = "";
		String cgcInstrType = "";
		
		boolean foundInCGCMargin = true;
		boolean foundInCGCStraddle = true;
		
		boolean inconsistentREMargin = false;
		boolean inconsistentREMinMargin = false;
		
		// inizio a scorrere l'oggettone x vedere quelli che sono su PAMP e non su SIC e segnalare le differenze per quelli che trova da entrambe le parti
		for (PAMPinstruments pampInstr:PAMPinstrumentsList) {
			
			sicInstrType = pampInstr.getSicInstrType();
			sicClassCode = pampInstr.getSicClassCode();
			/*String straType = "";
			
			if (pampInstr.getStraType()!=null) {
				straType = pampInstr.getStraType();
			}*/
			
			String pampInstrDesc = "InstrId: "+pampInstr.getInstrId()+" ("+sicClassCode+" / "+sicInstrType+")";
			
			String PAMPmarginValue = "null";
			String PAMPminMarginValue = "null";
			String PAMPstraddleValue = "null";
			
			BigDecimal margin = pampInstr.getMargin();
			
			if (margin!=null) {
				PAMPmarginValue = margin.toString();
			} 
			
			BigDecimal minMargin = null;
			if (pampInstr.getMinMargin()!=null) {
				minMargin = pampInstr.getMinMargin();
				PAMPminMarginValue = minMargin.toString();
			}
			
			BigDecimal straddle = null;
			if (pampInstr.getStraddle()!=null) {
				straddle = pampInstr.getStraddle();
				PAMPstraddleValue = straddle.toString();
			}
			
			
			// scorro su SIC e verifico se per classCode e diviscode c'� corrispondenza
			for (Cgcls00f cgcls00f:arrCgcls00f) {
				
				String CGCmarginValue = "null";
				String CGCminMarginValue = "null";
				
				
				cgcClassCode  = cgcls00f.getPk().getCclass();
				cgcInstrType = cgcls00f.getPk().getCofCod();
				
				BigDecimal cgcMargin = null;
				
				if (cgcls00f.getCmrgni()!=null) {
					cgcMargin = cgcls00f.getCmrgni().round(mathC);
					CGCmarginValue = cgcMargin.toString();
				}
				
				BigDecimal cgcMinMargin = null;
				
				if (cgcls00f.getCminrt()!=null) {
					cgcMinMargin = cgcls00f.getCminrt().round(mathC);
					CGCminMarginValue = cgcMinMargin.toString();
				}
				
				// se NON c'� corrispondenza
				if (!(sicClassCode.equalsIgnoreCase(cgcClassCode) && sicInstrType.equalsIgnoreCase(cgcInstrType))) {
					// quelli che sono su pamp ma non su sic
					
					foundInCGCMargin = false;
					inconsistentREMargin = false;
					inconsistentREMinMargin = false;
				} else {
					// verifico le eventuali differenze su Margine (SEMPRE) e Margine Minimo (eventuale)
					foundInCGCMargin = true;
					
					//confronti sul margine
					if (!compareBigDecimals(margin,cgcMargin)) {
						inconsistentREMargin = true;
						// se c'� inconsistenza sul margine allora completo la stringa
						marginValueDiff += pampInstrDesc+"---> PAMP margin: "+PAMPmarginValue+" vs. RE margin: "+CGCmarginValue;
					}
					
					//confronti sul margine minimo
					if (!compareBigDecimals(minMargin,cgcMinMargin))  {
						inconsistentREMinMargin = true;
						String minMarginDiff = "PAMP min. margin: "+PAMPminMarginValue+" vs. RE min. margin: "+CGCminMarginValue;
						// se c'� inconsistenza sul margine allora proseguo la stringa
						if (inconsistentREMargin) {
							marginValueDiff += "; "+minMarginDiff;
						} else {
							marginValueDiff += pampInstrDesc+"---> "+minMarginDiff;
						}
					}
					//fine margine minimo
				
					if (inconsistentREMargin||inconsistentREMinMargin) {
						// finisco la stringa e vado a capo
						marginValueDiff +="\n";
						inconsistentMargins++;
					}
					break;
				}
			}
			
			//se dopo aver ciclato dentro CGCLS00F non ho trovato nulla allora incremento di uno il contatore dei non trovati
			if (!foundInCGCMargin) {
				instrInPAMPnotInREMar += pampInstrDesc+"\n";
				PAMPmarNotFound++;
			}
			
			// se ho un tipo di straType che implica il confronto sugli straddle allora lo eseguo
			if (pampInstr.getStraType()!=null && !pampInstr.getStraType().equalsIgnoreCase("") && !pampInstr.getStraType().equalsIgnoreCase("N")) {
				
				//ciclo sulla tabella degli straddle
				for (Hfsrat2 hfsrat2:arrHfsrat2) {
					String CGCstraddleValue = "null";
					String hfsrClassCode  = hfsrat2.getFClass();
					BigDecimal hfsrStraddle1 = hfsrat2.getFnsprd();
					
					if (hfsrat2.getFnsprd()!=null) {
						hfsrStraddle1 = hfsrat2.getFnsprd();
						CGCstraddleValue = hfsrStraddle1.toString();
					}
					
										
					if (!sicClassCode.equalsIgnoreCase(hfsrClassCode)) {
						// quelli che sono su pamp ma non su sic
						foundInCGCStraddle = false;
						
					} else {
						foundInCGCStraddle = true;
						
						// verifico le differenze
						if (!compareBigDecimals(straddle,hfsrStraddle1)) {
							straddleValueDiff += pampInstrDesc+"--->  PAMP Straddle: "+PAMPstraddleValue+" vs. RE Straddle: "+CGCstraddleValue+"\n"; 
							inconsistentStraddles++;
						}
						break;
					} 
				}
				
				if (!foundInCGCStraddle) {
					instrInPAMPnotInREStra += pampInstrDesc+"\n";
					PAMPstraNotFound++;
				}
			}
		}
		
		boolean foundInPAMPMargin = false;
		
		// inizio a scorrere i margini su SIC x vedere quelli che sono su SIC e non su PAMP
		for (Cgcls00f cgcls00f:arrCgcls00f) {
			cgcClassCode  = cgcls00f.getPk().getCclass();
			cgcInstrType = cgcls00f.getPk().getCofCod();
			
			if (!(cgcClassCode.equalsIgnoreCase("") && cgcInstrType.equalsIgnoreCase(""))) {
				foundInPAMPMargin = false;
				for (PAMPinstruments pampInstr:PAMPinstrumentsList) {
					sicInstrType = pampInstr.getSicInstrType();
					sicClassCode = pampInstr.getSicClassCode();
					
					if ((cgcClassCode.equalsIgnoreCase(sicClassCode) && cgcInstrType.equalsIgnoreCase(sicInstrType))) {
						//sono su sic ma non su pamp (margini)
						foundInPAMPMargin = true;
						break;
					}
				}
				
				if (!foundInPAMPMargin) {
					instrInREnotInPAMPMar += cgcClassCode+" (type "+cgcInstrType+")\n";
					REmarNotFound++;
				}
			}
			
		}
		
		boolean foundInPAMPStraddle = false;
		
		// inizio a scorrere gli straddle su SIC x vedere quelli che sono su SIC e non su PAMP
		for (Hfsrat2 hfsrat2:arrHfsrat2) {
			
			String hfsrClassCode  = hfsrat2.getFClass();
			foundInPAMPStraddle = false;
			
			for (PAMPinstruments pampInstr:PAMPinstrumentsList) {
				sicClassCode = pampInstr.getSicClassCode();
				if (hfsrClassCode.equalsIgnoreCase(sicClassCode)) {
					// quelli che sono su sic ma non su pamp (straddle)
					foundInPAMPStraddle = true;
					break;
				}
			}
			
			if (!foundInPAMPStraddle) {
				instrInREnotInPAMPStra += hfsrClassCode+"\n";
				REstraNotFound++;
			}
			
		}
		
		
		String PAMPnotInREMarTitle = "The following financial instruments are contained in PAMP but not in Risk Engine margin table";
		String PAMPnotInREStraTitle = "The following financial instruments are contained in PAMP but not in Risk Engine straddle table";
		String REnotInPAMPMarTitle = "The following financial instruments are contained in Risk Engine margin table but not in PAMP";
		String REnotInPAMPStraTitle = "The following financial instruments are contained in Risk Engine straddle table but not in PAMP";
		String marginDiffTitle = "The following financial instruments have inconsistent margins values";
		String straddleDiffTitle = "The following financial instruments have inconsistent straddles values";
		
		String returnString = "";
		
		// parte riepilogativa con conteggi di tutti i confronti effettuati
		
		if (PAMPmarNotFound>0) {
			PAMPnotInREMarTitle+= " ("+PAMPmarNotFound+" found):\n";
			instrInPAMPnotInREMar = PAMPnotInREMarTitle+instrInPAMPnotInREMar+"\n";
			appIntLog.warn(instrInPAMPnotInREMar);
			returnString+=instrInPAMPnotInREMar;
		} else {
			PAMPnotInREMarTitle = "All financial instruments in PAMP margin table are contained in Risk Engine table\n\n";
			appIntLog.info(PAMPnotInREMarTitle);
			returnString+=PAMPnotInREMarTitle;
		}
		
		
		
		
		if (PAMPstraNotFound>0) {
			PAMPnotInREStraTitle+= " ("+PAMPstraNotFound+" found):\n";
			instrInPAMPnotInREStra = PAMPnotInREStraTitle+instrInPAMPnotInREStra+"\n";
			appIntLog.warn(instrInPAMPnotInREStra);
			returnString+=instrInPAMPnotInREStra;
		} else {
			PAMPnotInREStraTitle = "All financial instruments in PAMP straddle table are contained in Risk Engine table\n\n";
			appIntLog.info(PAMPnotInREStraTitle);
			returnString+=PAMPnotInREStraTitle;
		}
		
		
		if (REmarNotFound>0) {
			REnotInPAMPMarTitle+= " ("+REmarNotFound+" found):\n";
			instrInREnotInPAMPMar = REnotInPAMPMarTitle+instrInREnotInPAMPMar+"\n";
			appIntLog.warn(instrInREnotInPAMPMar);
			returnString+=instrInREnotInPAMPMar;
		} else {
			REnotInPAMPMarTitle = "All financial instruments in Risk Engine margin table are contained in PAMP table\n\n";
			appIntLog.info(REnotInPAMPMarTitle);
			returnString+=REnotInPAMPMarTitle;
		}
		
		if (REstraNotFound>0) {
			REnotInPAMPStraTitle+= " ("+REstraNotFound+" found):\n";
			instrInREnotInPAMPStra = REnotInPAMPStraTitle+instrInREnotInPAMPStra+"\n";
			appIntLog.warn(instrInREnotInPAMPStra);
			returnString+=instrInREnotInPAMPStra;
		} else {
			REnotInPAMPStraTitle = "All financial instruments in Risk Engine straddle table are contained in PAMP table\n\n";
			appIntLog.info(REnotInPAMPStraTitle);
			returnString+=REnotInPAMPStraTitle;
		}
		
		if (inconsistentMargins>0) {
			marginDiffTitle+= " ("+inconsistentMargins+" found):\n";
			marginValueDiff = marginDiffTitle+marginValueDiff+"\n";
			appIntLog.warn(marginValueDiff);
			returnString+=marginValueDiff;
		} else {
			marginDiffTitle = "No inconsistent margin values found between PAMP and Risk Engine margin table\n\n";
			appIntLog.info(marginDiffTitle);
			returnString+=marginDiffTitle;
		}
		
		if (inconsistentStraddles>0) {
			straddleDiffTitle+= " ("+inconsistentStraddles+" found):\n";
			straddleValueDiff = straddleDiffTitle+straddleValueDiff+"\n";
			appIntLog.warn(straddleValueDiff);
			returnString+=straddleValueDiff;
		} else {
			straddleDiffTitle = "No inconsistent straddle values found between PAMP and Risk Engine straddle table\n\n";
			appIntLog.info(straddleDiffTitle);
			returnString+=straddleDiffTitle;
		}
		int numberOfError = PAMPmarNotFound+PAMPstraNotFound+REmarNotFound+REstraNotFound+inconsistentMargins+inconsistentStraddles;		
		numberOfErrorForCMCBatch.setNumberOfError(numberOfError);
		
		return returnString;
		
		// ############################################################################
	}

	
	
	public String checkClassMarginDataPAMPVsIntracs(NumberOfErrorForCMCBatch numberOfErrorForCMCBatch) throws DataNotValidException {
		
		int classId = 0;
		String sicClassId = "";
		//Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
		int PAMPclMarNotFound = 0;
		int REclMarNotFound = 0;
		int inconsistentMargins = 0;
		//BigDecimal roundDigit = new BigDecimal(0.0001);
		
		List<PAMPinstruments> PAMPinstrumentsList = new ArrayList<PAMPinstruments>();
		
		
		// ############################################################################
		// classi che sono sulla CLMARHIS
		List<BondClass> bondClassList = bndClassEAO.getBondClassInClassMarHis();
		
		// ############################################################################
		// strumenti che sono su INTRACS (class margin)
		List<Mtsmgnf90f> mtsmgnf90fList = mtsmgnf90fEAO.fetch();

		
		for (BondClass bondClass:bondClassList) {
			
			
			ClassMarginHistory clMarHis = clMarHisEAO.getLastSentClassMargin(bondClass.getClassId());
						
			BigDecimal classMargin = clMarHis.getMargin();
			
			classId = bondClass.getClassId();
			
			
			// tramite transcodifica mi costruisco l'oggettone con tutti i campi che mi servono per iniziare la fase di confronto
			
			//List<ClassIdTrascode> classIdTranscodeList = classTrancodeEAO.getSicClassId(classId);
			
			/*for (ClassIdTrascode classIdTranscode:classIdTranscodeList) {
				
				sicClassId = classIdTranscode.getPk().getSicClassId();
				
				BigDecimal marCoeff = classIdTranscode.getMarCf();
			}*/
			
			/*if (classMargin!=null && roundDigit!=null) {
				//classMargin=PampRounder.round(classMargin.multiply(marCoeff), "N", roundDigit);
				classMargin = classMargin.multiply(marCoeff,mathC);
			}*/

			sicClassId = Integer.toString(bondClass.getClassId());
			
			PAMPinstruments pampInstr = new PAMPinstruments(bondClass.getClassId(),sicClassId,bondClass.getClassDesc(),classMargin);
			PAMPinstrumentsList.add(pampInstr);
			
		}
		
		String instrInPAMPnotInREClassMar = "";
		
		String instrInREnotInPAMPClassMar = "";
		
		String classMarginValueDiff="";
		
		
		String mtsClassId = "";
		
		boolean foundInMTSClassMargin = true;
		
		boolean inconsistentREClassMargin = false;
		
		// inizio a scorrere l'oggettone x vedere quelli che sono su PAMP e non su SIC e segnalare le differenze per quelli che trova da entrambe le parti
		for (PAMPinstruments pampInstr:PAMPinstrumentsList) {
			
			sicClassId = pampInstr.getSicClassId();
			
			String pampInstrDesc = "ClassId: "+pampInstr.getClassId()+" ("+pampInstr.getClassDesc()+")";
			
			String PAMPclassMarginValue = "null";
			
			if (pampInstr.getClassMargin()!=null) {
				PAMPclassMarginValue = pampInstr.getClassMargin().round(mathC).toString();
			} 
			
			// scorro su SIC e verifico se per classCode e diviscode c'� corrispondenza
			for (Mtsmgnf90f mtsmgnf90f:mtsmgnf90fList) {
				
				String MTSclassMarginValue = "null";
								
				
				mtsClassId  = mtsmgnf90f.getF90cdclass();
				
				BigDecimal mtsClassMargin = null;
				
				if (mtsmgnf90f.getF90inmargi()!=null) {
					mtsClassMargin = mtsmgnf90f.getF90inmargi().round(mathC);
					MTSclassMarginValue = mtsClassMargin.toString();
				}
				
								
				// se NON c'� corrispondenza
				if (!(sicClassId.equalsIgnoreCase(mtsClassId))) {
					// quelli che sono su pamp ma non su sic
					
					foundInMTSClassMargin = false;
					inconsistentREClassMargin = false;
				
				} else {
					// verifico le eventuali differenze sul Margine (SEMPRE)
					foundInMTSClassMargin = true;
					
					//confronti sul margine
					if (!compareBigDecimals(pampInstr.getClassMargin().round(mathC),mtsClassMargin)) {
						inconsistentREClassMargin = true;
						// se c'� inconsistenza sul class margin allora completo la stringa
						classMarginValueDiff += pampInstrDesc+"---> PAMP class margin: "+PAMPclassMarginValue+" vs. RE class margin: "+MTSclassMarginValue;
						classMarginValueDiff +="\n";
						inconsistentMargins++;
					}
					break;
				}
			}
			
			//se dopo aver ciclato dentro MTSMGNF90F non ho trovato nulla allora incremento di uno il contatore dei non trovati
			if (!foundInMTSClassMargin) {
				instrInPAMPnotInREClassMar += pampInstrDesc+"\n";
				PAMPclMarNotFound++;
			}
			
		}
		
		boolean foundInPAMPClassMargin = false;
		
		// inizio a scorrere i margini su SIC x vedere quelli che sono su SIC e non su PAMP
		for (Mtsmgnf90f mtsmgnf90f:mtsmgnf90fList) {
			mtsClassId  = mtsmgnf90f.getF90cdclass();
			
			if (!mtsClassId.equalsIgnoreCase("")) {
				foundInPAMPClassMargin = false;
				for (PAMPinstruments pampInstr:PAMPinstrumentsList) {
					sicClassId = pampInstr.getSicClassId();
					
					if ((mtsClassId.equalsIgnoreCase(sicClassId))) {
						//sono su sic ma non su pamp (margini)
						foundInPAMPClassMargin = true;
						break;
					}
				}
				
				if (!foundInPAMPClassMargin) {
					instrInREnotInPAMPClassMar += "RE classId: "+mtsClassId+"\n";
					REclMarNotFound++;
				}
			}
			
		}
		
		String PAMPnotInREClMarTitle = "The following bond classes are contained in PAMP but not in Risk Engine bond class margin table";
		
		String REnotInPAMPClMarTitle = "The following bond classes are contained in Risk Engine bond class margin table but not in PAMP";
		
		String classMarginDiffTitle = "The following bond classes have inconsistent margins values";
		
		String returnString = "";
		
		// parte riepilogativa con conteggi di tutti i confronti effettuati
		
		if (PAMPclMarNotFound>0) {
			PAMPnotInREClMarTitle+= " ("+PAMPclMarNotFound+" found):\n";
			instrInPAMPnotInREClassMar = PAMPnotInREClMarTitle+instrInPAMPnotInREClassMar+"\n";
			appIntLog.warn(instrInPAMPnotInREClassMar);
			returnString+=instrInPAMPnotInREClassMar;
		} else {
			PAMPnotInREClMarTitle = "All bond classes in PAMP bond class margin table are contained in Risk Engine table\n\n";
			appIntLog.info(PAMPnotInREClMarTitle);
			returnString+=PAMPnotInREClMarTitle;
		}
		
		if (REclMarNotFound>0) {
			REnotInPAMPClMarTitle+= " ("+REclMarNotFound+" found):\n";
			instrInREnotInPAMPClassMar = REnotInPAMPClMarTitle+instrInREnotInPAMPClassMar+"\n";
			appIntLog.warn(instrInREnotInPAMPClassMar);
			returnString+=instrInREnotInPAMPClassMar;
		} else {
			REnotInPAMPClMarTitle = "All bond classes in Risk Engine bond class margin table are contained in PAMP table\n\n";
			appIntLog.info(REnotInPAMPClMarTitle);
			returnString+=REnotInPAMPClMarTitle;
		}
		
		if (inconsistentMargins>0) {
			classMarginDiffTitle+= " ("+inconsistentMargins+" found):\n";
			classMarginValueDiff = classMarginDiffTitle+classMarginValueDiff+"\n";
			appIntLog.warn(classMarginValueDiff);
			returnString+=classMarginValueDiff;
		} else {
			classMarginDiffTitle = "No inconsistent bond class margin values found between PAMP and Risk Engine bond class margin table\n\n";
			appIntLog.info(classMarginDiffTitle);
			returnString+=classMarginDiffTitle;
		}
		
		
		int numberOfError = PAMPclMarNotFound+REclMarNotFound+inconsistentMargins;		
		numberOfErrorForCMCBatch.setNumberOfError(numberOfError);
		
		return returnString;
		
		// ############################################################################
	}
	
	
	public String checkIntraClassOffsetDataPAMPVsIntracs(NumberOfErrorForCMCBatch numberOfErrorForCMCBatch) throws DataNotValidException {
		
		int classId = 0;
		String sicClassId = "";
		
		int PAMPintraClassNotFound = 0;
		int REintraClassNotFound = 0;
		int inconsistentOffsets = 0;
		BigDecimal roundDigit = new BigDecimal(0.0001);
		
		List<PAMPinstruments> PAMPinstrumentsList = new ArrayList<PAMPinstruments>();
		
		// ############################################################################
		// classi che sono sulla CLTRAH
		
		List<BondClass> bondClassListInTraHis = bndClassEAO.getBondClassInTraHis();
		
		// ############################################################################
		// strumenti che sono su INTRACS (intraclass offsets)
		List<Mtsmgnf91f> mtsmgnf91fList = mtsmgnf91fEAO.fetch();

		
		for (BondClass bondClass:bondClassListInTraHis) {
			
			classId = bondClass.getClassId();
			
			IntraclassOffsetHistory clTraHis = traHisEAO.getLastSentIntraClassOffset(classId);
			
			
			
			BigDecimal intraClassOffset = clTraHis.getOff();
			
			
			
			/*TODO transcodifica disabilitata ma riabilitabile al volo in caso di necessit� o richiesta */
			
			// tramite transcodifica mi costruisco l'oggettone con tutti i campi che mi servono per iniziare la fase di confronto
			
			//List<ClassIdTrascode> classIdTranscodeList = classTrancodeEAO.getSicClassId(classId);
			
			/*for (ClassIdTrascode classIdTranscode:classIdTranscodeList) {
				
				sicClassId = classIdTranscode.getPk().getSicClassId();
				
				BigDecimal marCoeff = classIdTranscode.getMarCf();
				
				
				
			}*/
			
			//sicClassId = classIdTranscode.getPk().getSicClassId();
			
			/*if (intraClassOffset!=null && roundDigit!=null) {
				//intraClassOffset=PampRounder.round(intraClassOffset.multiply(marCoeff), "N", roundDigit);
				intraClassOffset = intraClassOffset.multiply(marCoeff,mathC);
			}*/

			sicClassId = Integer.toString(classId);
			
			PAMPinstruments pampInstr = new PAMPinstruments(classId,sicClassId,bondClass.getClassDesc(),intraClassOffset,true);
			PAMPinstrumentsList.add(pampInstr);
			
		}
		
		String instrInPAMPnotInREIntraClassOff = "";
		
		String instrInREnotInPAMPIntraClassOff = "";
		
		String intraClassOffsetValueDiff="";
		
		String mtsClassId = "";
		
		boolean foundInMTSIntraClassoffset = true;
		
		boolean inconsistentREIntraClassoffset = false;
		
		// inizio a scorrere l'oggettone x vedere quelli che sono su PAMP e non su SIC e segnalare le differenze per quelli che trova da entrambe le parti
		for (PAMPinstruments pampInstr:PAMPinstrumentsList) {
			
			sicClassId = pampInstr.getSicClassId();
			
			String pampInstrDesc = "ClassId: "+pampInstr.getClassId()+" ("+pampInstr.getClassDesc()+")";
			
			String PAMPintraClassOffsetValue = "null";
			
			if (pampInstr.getClassMargin()!=null) {
				
				PAMPintraClassOffsetValue = pampInstr.getIntraClassOffset().round(mathC).toString();
			} 
			
			// scorro su SIC e verifico se per classCode e diviscode c'� corrispondenza
			for (Mtsmgnf91f mtsmgnf91f:mtsmgnf91fList) {
				
				String MTSinterClassoffsetValue = "null";
								
				
				mtsClassId  = mtsmgnf91f.getF91cdclass();
				
				BigDecimal mtsInterClassOffset = null;
				
				if (mtsmgnf91f.getF91intridi()!=null) {
					mtsInterClassOffset = mtsmgnf91f.getF91intridi().round(mathC);
					MTSinterClassoffsetValue = mtsInterClassOffset.toString();
				}
				
				// se NON c'� corrispondenza
				if (!(sicClassId.equalsIgnoreCase(mtsClassId))) {
					// quelli che sono su pamp ma non su sic
					
					foundInMTSIntraClassoffset = false;
					inconsistentREIntraClassoffset = false;
				
				} else {
					// verifico le eventuali differenze sul Margine (SEMPRE)
					foundInMTSIntraClassoffset = true;
					
					//confronti sull'intraclassoffset
					if (!compareBigDecimals(pampInstr.getIntraClassOffset().round(mathC),mtsInterClassOffset)) {
						inconsistentREIntraClassoffset = true;
						// se c'� inconsistenza sul class margin allora completo la stringa
						intraClassOffsetValueDiff += pampInstrDesc+"---> PAMP intraclass offset: "+PAMPintraClassOffsetValue+" vs. RE intraclass offset: "+MTSinterClassoffsetValue;
						intraClassOffsetValueDiff +="\n";
						inconsistentOffsets++;
					}
					break;
				}
			}
			
			//se dopo aver ciclato dentro MTSMGNF90F non ho trovato nulla allora incremento di uno il contatore dei non trovati
			if (!foundInMTSIntraClassoffset) {
				instrInPAMPnotInREIntraClassOff += pampInstrDesc+"\n";
				PAMPintraClassNotFound++;
			}
			
		}
		
		boolean foundInPAMPIntraClassOffset = false;
		
		// inizio a scorrere i margini su SIC x vedere quelli che sono su SIC e non su PAMP
		for (Mtsmgnf91f mtsmgnf91f:mtsmgnf91fList) {
			mtsClassId  = mtsmgnf91f.getF91cdclass();
			
			if (!mtsClassId.equalsIgnoreCase("")) {
				foundInPAMPIntraClassOffset = false;
				for (PAMPinstruments pampInstr:PAMPinstrumentsList) {
					sicClassId = pampInstr.getSicClassId();
					
					if ((mtsClassId.equalsIgnoreCase(sicClassId))) {
						//sono su sic ma non su pamp (intraclass)
						foundInPAMPIntraClassOffset = true;
						break;
					}
				}
				
				if (!foundInPAMPIntraClassOffset) {
					instrInREnotInPAMPIntraClassOff += "RE classId: "+mtsClassId+"\n";
					REintraClassNotFound++;
				}
			}
			
		}
		
		String PAMPnotInREIntraClassOffsetTitle = "The following bond classes are contained in PAMP but not in Risk Engine bond intraclass offsets table";
		
		String REnotInPAMPIntraClassOffsetTitle = "The following bond classes are contained in Risk Engine bond intraclass offsets table but not in PAMP";
		
		String intraClassOffsetDiffTitle = "The following bond intraclasses have inconsistent offsets values";
		
		String returnString = "";
		
		// parte riepilogativa con conteggi di tutti i confronti effettuati
		
		if (PAMPintraClassNotFound>0) {
			PAMPnotInREIntraClassOffsetTitle+= " ("+PAMPintraClassNotFound+" found):\n";
			instrInPAMPnotInREIntraClassOff = PAMPnotInREIntraClassOffsetTitle+instrInPAMPnotInREIntraClassOff+"\n";
			appIntLog.warn(instrInPAMPnotInREIntraClassOff);
			returnString+=instrInPAMPnotInREIntraClassOff;
		} else {
			PAMPnotInREIntraClassOffsetTitle = "All bond classes in PAMP bond intraclass offsets table are contained in Risk Engine table\n\n";
			appIntLog.info(PAMPnotInREIntraClassOffsetTitle);
			returnString+=PAMPnotInREIntraClassOffsetTitle;
		}
		
		if (REintraClassNotFound>0) {
			REnotInPAMPIntraClassOffsetTitle+= " ("+REintraClassNotFound+" found):\n";
			instrInREnotInPAMPIntraClassOff = REnotInPAMPIntraClassOffsetTitle+instrInREnotInPAMPIntraClassOff+"\n";
			appIntLog.warn(instrInREnotInPAMPIntraClassOff);
			returnString+=instrInREnotInPAMPIntraClassOff;
		} else {
			REnotInPAMPIntraClassOffsetTitle = "All bond classes in Risk Engine bond intraclass offsets table are contained in PAMP table\n\n";
			appIntLog.info(REnotInPAMPIntraClassOffsetTitle);
			returnString+=REnotInPAMPIntraClassOffsetTitle;
		}
		
		if (inconsistentOffsets>0) {
			intraClassOffsetDiffTitle+= " ("+inconsistentOffsets+" found):\n";
			intraClassOffsetValueDiff = intraClassOffsetDiffTitle+intraClassOffsetValueDiff+"\n";
			appIntLog.warn(intraClassOffsetValueDiff);
			returnString+=intraClassOffsetValueDiff;
		} else {
			intraClassOffsetDiffTitle = "No inconsistent bond intraclass offsets values found between PAMP and Risk Engine bond intraclass offsets table\n\n";
			appIntLog.info(intraClassOffsetDiffTitle);
			returnString+=intraClassOffsetDiffTitle;
		}
		
		
		int numberOfError = PAMPintraClassNotFound+REintraClassNotFound+inconsistentOffsets;		
		numberOfErrorForCMCBatch.setNumberOfError(numberOfError);
		
		return returnString;
		
		// ############################################################################
	}
	
	
	public String checkInterClassOffsetDataPAMPVsIntracs(NumberOfErrorForCMCBatch numberOfErrorForCMCBatch) throws DataNotValidException {
		
		int bondClassId = 0;
		String sicClassId1 = "";
		String sicClassId2 = "";
		
		int PAMPinterClassNotFound = 0;
		int REinterClassNotFound = 0;
		int inconsistentOffsets = 0;
		BigDecimal roundDigit = new BigDecimal(0.0001);
		
		List<PAMPinstruments> PAMPinstrumentsList = new ArrayList<PAMPinstruments>();
		
		// ############################################################################
		// classi che sono sulla CLTRAH
		
		List<BondClass> bondClassListInTerHis = bndClassEAO.getBondClassInTerHis();
		
		// ############################################################################
		// strumenti che sono su INTRACS (interclass offsets)
		List<Mtsmgnf92f> mtsmgnf92fList = mtsmgnf92fEAO.fetch();

		Vector<Integer> classIdCoupleVec = new Vector<Integer>();
		
		for (BondClass bondClass:bondClassListInTerHis) {
			
			bondClassId = bondClass.getClassId();
		
			classIdCoupleVec.add(bondClassId);
		}
		
		// scorro sul vettore di coppie di classi per creare tutti gli ipotetici abbinamenti
		for (int i=0;i<classIdCoupleVec.size();i++) {
			
			//classe 1
			String bondClassDesc1 = bondClassListInTerHis.get(i).getClassDesc();
			
			for (int j=i+1;j<classIdCoupleVec.size();j++) {
				//classe 2
				String bondClassDesc2 = bondClassListInTerHis.get(j).getClassDesc();
				
				//vado alla ricerca dell'ultimo offset inviato per quella coppia di classi
				InterclassOffsetHistory clTerHis = terHisEAO.getLastSentInterClassOffset(classIdCoupleVec.get(i),classIdCoupleVec.get(j));
				
				if (clTerHis!=null) {
					BigDecimal interClassOffset = clTerHis.getOff();
					//controllo sul valore dell'offset	
					if (interClassOffset!=null && roundDigit!=null) {
						interClassOffset=PampRounder.round(interClassOffset, "N", roundDigit);
						interClassOffset=interClassOffset.round(mathC);
					}
					//aggiunta sull'oggettone
					PAMPinstruments pampInstr = new PAMPinstruments(classIdCoupleVec.get(i),classIdCoupleVec.get(j),bondClassDesc1,bondClassDesc2,interClassOffset);
					PAMPinstrumentsList.add(pampInstr);
				}
			}
		}
		
		
		String instrInPAMPnotInREInterClassOff = "";
		
		String instrInREnotInPAMPInterClassOff = "";
		
		String interClassOffsetValueDiff="";
		
		String mtsClassId1 = "";
		String mtsClassId2 = "";
		
		boolean foundInMTSInterClassoffset = true;
		
		boolean inconsistentREInterClassoffset = false;
		
		// inizio a scorrere l'oggettone x vedere quelli che sono su PAMP e non su SIC e segnalare le differenze per quelli che trova da entrambe le parti
		for (PAMPinstruments pampInstr:PAMPinstrumentsList) {
			
			sicClassId1 = Integer.toString(pampInstr.getClassId1());
			sicClassId2 = Integer.toString(pampInstr.getClassId2());
			
			String pampInstrDesc = "ClassId1: "+pampInstr.getClassId1()+" ("+pampInstr.getClassDesc1()+") - ClassId2: "+pampInstr.getClassId2()+" ("+pampInstr.getClassDesc2()+")";
			
			String PAMPinterClassOffsetValue = "null";
			
			if (pampInstr.getInterClassOffset()!=null) {
				
				PAMPinterClassOffsetValue = pampInstr.getInterClassOffset().round(mathC).toString();
			} 
			
			// scorro su SIC e verifico se per classCode e diviscode c'� corrispondenza
			for (Mtsmgnf92f mtsmgnf92f:mtsmgnf92fList) {
				
				String MTSinterClassoffsetValue = "null";
								
				
				mtsClassId1  = mtsmgnf92f.getPk().getF92cdclas1();
				mtsClassId2  = mtsmgnf92f.getPk().getF92cdclas2();
				
				BigDecimal mtsInterClassOffset = null;
				
				if (mtsmgnf92f.getF92intridp()!=null) {
					mtsInterClassOffset = mtsmgnf92f.getF92intridp().round(mathC);
					MTSinterClassoffsetValue = mtsInterClassOffset.toString();
				}
				
				// se NON c'� corrispondenza
				if (!(sicClassId1.equalsIgnoreCase(mtsClassId1) && !(sicClassId2.equalsIgnoreCase(mtsClassId2)))) {
					// quelli che sono su pamp ma non su sic
					
					foundInMTSInterClassoffset = false;
					inconsistentREInterClassoffset = false;
				
				} else {
					// verifico le eventuali differenze sull'offset (SEMPRE)
					foundInMTSInterClassoffset = true;
					//confronti sul margine
					if (!compareBigDecimals(pampInstr.getInterClassOffset().round(mathC),mtsInterClassOffset)) {
						inconsistentREInterClassoffset = true;
						// se c'� inconsistenza sull'offset allora completo la stringa
						interClassOffsetValueDiff += pampInstrDesc+"---> PAMP interclass offset: "+PAMPinterClassOffsetValue+" vs. RE interclass offset: "+MTSinterClassoffsetValue;
						interClassOffsetValueDiff +="\n";
						inconsistentOffsets++;
					}
					break;
				}
			}
			
			//se dopo aver ciclato dentro MTSMGNF92F non ho trovato nulla allora incremento di uno il contatore dei non trovati
			if (!foundInMTSInterClassoffset) {
				instrInPAMPnotInREInterClassOff += pampInstrDesc+"\n";
				PAMPinterClassNotFound++;
			}
			
		}
		
		boolean foundInPAMPInterClassOffset = false;
		
		// inizio a scorrere gli offset su SIC x vedere quelli che sono su SIC e non su PAMP
		for (Mtsmgnf92f mtsmgnf92f:mtsmgnf92fList) {
			mtsClassId1  = mtsmgnf92f.getPk().getF92cdclas1();
			
			if (!mtsClassId1.equalsIgnoreCase("")) {
				foundInPAMPInterClassOffset = false;
				for (PAMPinstruments pampInstr:PAMPinstrumentsList) {
					sicClassId1 = pampInstr.getSicClassId();
					
					if (mtsClassId1.equalsIgnoreCase(sicClassId1)&& mtsClassId2.equalsIgnoreCase(sicClassId2)) {
						//sono su sic ma non su pamp (offset)
						foundInPAMPInterClassOffset = true;
						break;
					}
				}
				
				if (!foundInPAMPInterClassOffset) {
					instrInREnotInPAMPInterClassOff += "RE classId: "+mtsClassId1+"\n";
					REinterClassNotFound++;
				}
			}
			
		}
		
		String PAMPnotInREInterClassOffsetTitle = "The following bond classes are contained in PAMP but not in Risk Engine bond interclass offsets table";
		
		String REnotInPAMPInterClassOffsetTitle = "The following bond classes are contained in Risk Engine bond interclass offsets table but not in PAMP";
		
		String interClassOffsetDiffTitle = "The following bond interclasses have inconsistent offsets values";
		
		String returnString = "";
		
		// parte riepilogativa con conteggi di tutti i confronti effettuati
		
		if (PAMPinterClassNotFound>0) {
			PAMPnotInREInterClassOffsetTitle+= " ("+PAMPinterClassNotFound+" found):\n";
			instrInPAMPnotInREInterClassOff = PAMPnotInREInterClassOffsetTitle+instrInPAMPnotInREInterClassOff+"\n";
			appIntLog.warn(instrInPAMPnotInREInterClassOff);
			returnString+=instrInPAMPnotInREInterClassOff;
		} else {
			PAMPnotInREInterClassOffsetTitle = "All bond classes in PAMP bond interclass offsets table are contained in Risk Engine table\n\n";
			appIntLog.info(PAMPnotInREInterClassOffsetTitle);
			returnString+=PAMPnotInREInterClassOffsetTitle;
		}
		
		if (REinterClassNotFound>0) {
			REnotInPAMPInterClassOffsetTitle+= " ("+REinterClassNotFound+" found):\n";
			instrInREnotInPAMPInterClassOff = REnotInPAMPInterClassOffsetTitle+instrInREnotInPAMPInterClassOff+"\n";
			appIntLog.warn(instrInREnotInPAMPInterClassOff);
			returnString+=instrInREnotInPAMPInterClassOff;
		} else {
			REnotInPAMPInterClassOffsetTitle = "All bond classes in Risk Engine bond interclass offsets table are contained in PAMP table\n\n";
			appIntLog.info(REnotInPAMPInterClassOffsetTitle);
			returnString+=REnotInPAMPInterClassOffsetTitle;
		}
		
		if (inconsistentOffsets>0) {
			interClassOffsetDiffTitle+= " ("+inconsistentOffsets+" found):\n";
			interClassOffsetValueDiff = interClassOffsetDiffTitle+interClassOffsetValueDiff+"\n";
			appIntLog.warn(interClassOffsetValueDiff);
			returnString+=interClassOffsetValueDiff;
		} else {
			interClassOffsetDiffTitle = "No inconsistent bond interclass offsets values found between PAMP and Risk Engine bond interclass offsets table\n\n";
			appIntLog.info(interClassOffsetDiffTitle);
			returnString+=interClassOffsetDiffTitle;
		}
		
		
		int numberOfError = PAMPinterClassNotFound+REinterClassNotFound+inconsistentOffsets;		
		numberOfErrorForCMCBatch.setNumberOfError(numberOfError);
		
		return returnString;
		
		// ############################################################################
	}
	
	
	
	public boolean compareBigDecimals(BigDecimal pampValue, BigDecimal reValue) {
		
		if ((pampValue==null||pampValue.compareTo(new BigDecimal(0))==0)&&reValue==null) {
			return true;  
		}
		
		if ( (pampValue!=null&&reValue==null) || (pampValue==null&&reValue!=null)) {
			return false;
		} 
		
		if (pampValue.compareTo(reValue)==0) {
			return true;
		} 
			
		return false;
		
	}
	
	
	
	
	
	
	
	
	

}
