package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.CalendarEAOLocal;
import it.ccg.pamp.server.eao.Cgcls00fEAOLocal;
import it.ccg.pamp.server.eao.Cpsrss1EAOLocal;
import it.ccg.pamp.server.eao.DerivativesHistoricalPriceEAOLocal;
import it.ccg.pamp.server.eao.HistoricalPricesEAOLocal;
import it.ccg.pamp.server.eao.InfoProviderHisprEAOLocal;
import it.ccg.pamp.server.eao.InfoProviderInstrEAOLocal;
import it.ccg.pamp.server.eao.InstrumentEAOLocal;
import it.ccg.pamp.server.eao.WMtsprc0hfEAOLocal;
import it.ccg.pamp.server.eao.Tcoccyf00fEAOLocal;
import it.ccg.pamp.server.entities.Cgcls00f;
import it.ccg.pamp.server.entities.Cpsrss1;
import it.ccg.pamp.server.entities.DerivativesHistoricalPrice;
import it.ccg.pamp.server.entities.HistoricalPrices;
import it.ccg.pamp.server.entities.InfoProviderHispr;
import it.ccg.pamp.server.entities.InfoProviderInstr;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.WMtsprc0hf;
import it.ccg.pamp.server.entities.Tcoccyf00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;
/**
 * prompts for and reads an array of integers from the standard
 * input.  Repeatedly prompts for an integer, then asks the user if
 * s/he is done.  This repeats until the user is done, or until the
 * maximum number of integers is reached.  If the user enters characters
 * that are not integer format, the method will ask him/her to try
 * again.  
 * <p>
 * Limitation: If the user answers the "are you done?" question with
 * any character but a lower-case 'n', it is considered a yes.
 *
 * @param inputArray the array into which the integers are read
 * @return the number of integers read
 */
@Stateless
public class HPD implements  HPDEAOLocal {

    private static final long serialVersionUID = 1L;
	@EJB private HistoricalPricesEAOLocal hisPr=null;
	@EJB private DerivativesHistoricalPriceEAOLocal derivativesHP=null;
	@EJB private InstrumentEAOLocal instr=null;
	@EJB private Cpsrss1EAOLocal cpsrss=null;
	@EJB private Cgcls00fEAOLocal intracsClassEAO=null;
	@EJB private CalendarEAOLocal calend=null;
	@EJB private WMtsprc0hfEAOLocal mtsprc0hfEAO=null;
	@EJB private Tcoccyf00fEAOLocal tcoccyf00fEAO=null;
	@EJB private InfoProviderInstrEAOLocal infoProvInstrEAO=null;
	@EJB private InfoProviderHisprEAOLocal infoProvHisprEAO=null;
	
	private int total;
	private int failed;
	private int updated;
	private LinkedHashMap<Integer,Integer> dateLMap = new LinkedHashMap<Integer,Integer>();
		
	public int getTotal() {
		return total;
	}
	
	public void setTotal(int total) {
		this.total = total;
	}
	
	public int getUpdated() {
		return updated;
	}
	
	public void setUpdated(int updated) {
		this.updated = updated;
	}
	
	public int getFailed() {
		return failed;
	}
	
	public void setFailed(int failed) {
		this.failed = failed;
	}
	
	public void setDateLMap(int instrId, int lastHPDate) {
		this.dateLMap.put(instrId, lastHPDate);
	}
	
	
	public HPD() {
    }
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	
	public String logMessage(int updated) {
		
		return ": "+updated+" records successfully imported";
		
	}
	
	public String checkMaxDate() throws DataNotValidException {
		//leggo linked hash map x verificare la consistenza delle date 
		Set<Integer> keySet = dateLMap.keySet();
		String instrList = "";
		int maximumDate = 0;
		
		
		//prendo la data massima tra tutti gli strumenti scaricati
		for (Integer key:keySet) {
			int keyDate = dateLMap.get(key);
			if (keyDate>maximumDate) {
				maximumDate = keyDate;
			}
		}
		
		//ciclo su tutti gli strumenti scaricati
		for (Integer key:keySet) {
			int keyDate = dateLMap.get(key);
			//segnalo tutti gli strumenti che non sono stati scaricati fino alla data massima perch� la LORO data massima era pi� piccola
			if (keyDate<maximumDate) {
				//scrivo;
				instrList += instr.findByPrimaryKey(key).getInstrName()+" (instrId: "+key+" - classCode: "+instr.findByPrimaryKey(key).getClassCode()+"); ";
			}
		}
		
		if (!instrList.equals("")) {
			instrList = "the following instruments may be not updated to the latest requested date: "+instrList.substring(0,instrList.length()-2);
		}
		return instrList;
	}
	
	/*---------------------------- parte CASH------------------------------*/
	
	/**
	   * @author nelli
	   * <p>
	   * procedure built to download the historical prices series from INTRACS to PAMP system 
	   * <p>
	   * Limitation: If the historical prices series is too long, it could be possible an internal server time out error
	   *
	   * @param delta - <i>true</i> the procedure will download prices only from the last date present in historical prices data, <i>false</i> the procedure will download ALL historical prices data for each instrument
	   * @return the message with the outcome of the procedure 
	   */
	
	
	public String transferCash(boolean delta) throws DataNotValidException {
		setTotal(0);
		setUpdated(0);
		setFailed(0);
		this.dateLMap.clear();
		
		
		
		/*
		 * instr.getCash() carica dalla tabella degli strumenti soltanto quelli che corrispondono su INTRACS a instrtype = 'C' 
		 * (applichiamo quindi una transcodifica per passare da PAMP.INSTRTYPE a INTRACS.INSTRTYPE)
		 */
		Instrument[] instrument = instr.getCash();
		
		String currentMarket = "";
		List<Timestamp> calendDateList = new ArrayList<Timestamp>();
		
		for (Instrument instr:instrument) {
			try {
				//se la variabile di appoggio del mercato � diversa dal mercato a cui appartiene lo strumento allora me lo metto da parte e ricarico la lista del calendario
				if (!currentMarket.equalsIgnoreCase(instr.getMarketCode())) {
					calendDateList = calend.getListDate(instr.getMarketCode());
					currentMarket = instr.getMarketCode();
				}
				transferCash(instr, delta, calendDateList, total, failed, updated);
				
			} catch (Exception e) {
				String error = "Error happened on INSTRID "+instr.getInstrId()+" (Code: "+instr.getClassCode()+")";
				appIntLog.error(error+"\n"+e.getMessage()+"\n"+e.getStackTrace().toString());
			}
		}
		
		total = failed + updated;
		
		String message = "Import of Eq. Cash historical price series completed";
		
		if (updated==0&&failed==0) {
			message+=" with no effects";
		}
		/*if (updated>0) {
			message += ": found "+instrument.length+" financial instruments, "+updated+"/"+total+" records successfully imported";
		}
		if (failed>0) {
			if (updated>0) {
				message += ", ";
			} else {
				message += ": found "+instrument.length+" financial instruments, ";
			}
			message += failed+" records have not been imported";
		}*/
		
		message += this.logMessage(updated);
		
		if (!checkMaxDate().equalsIgnoreCase("")) {
			appIntLog.warn(checkMaxDate());
			message += "\n\nNote: "+checkMaxDate();
		}
		
		return message;
	}
	
	
	public void transferCash(Instrument instr, boolean delta, List<Timestamp> calendDateList, Integer total, Integer failed, Integer updated) throws DataNotValidException {
		int date;
    	int year; 
		int month;
		int day;
		
		int lastHPDate = 0;	
		GregorianCalendar cal = new GregorianCalendar(1900,0,1);
		Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
		int instrId = instr.getInstrId();
		if (delta) {
			/*prendo su HistoricalPrices la data pi� grande per quell'instrId*/ 
			HistoricalPrices[] historicalPrices = hisPr.findByInstrIdForDownload(instrId);
			if (historicalPrices.length>0) {
				lastDate = historicalPrices[0].getPk().getPricedate();
			}
		} else {
			hisPr.removeByInstrId(instrId);
		}
		
		/*recupero classCode e marketCode da instrument*/ 
		String hSymbl = instr.getClassCode();
		//String marketCode = instr.getMarketCode();
		
		//predispngo stringhe di errore/warning
		String error = "Found INSTRID "+instrId+" (Code: "+hSymbl+", Date: ";
		String instrNotInClearing = "INSTRID "+instrId+" (Code: "+hSymbl+") - No new historical prices series avalaible in INFO system";
		
		//cerco su INTRACS per INSTR.CLASSCODE e INSTRTYPE = 'C'
		/*  se sto trasferendo da un certo punto in poi, devo assicurarmi che la data
		 *  in questione sia successiva a quella da cui voglio iniziare a scaricare altrimenti scarico senza problemi
		*/
		long cpsrss1Date =  (long) Integer.parseInt(lastDate.toString().substring(0,4)+lastDate.toString().substring(5,7)+lastDate.toString().substring(8,10));
		Cpsrss1[] cpsrss1 = (Cpsrss1[]) cpsrss.findCashBySymbl(hSymbl,cpsrss1Date);
		
		if (cpsrss1.length==0) {
			appIntLog.warn(instrNotInClearing);
			lastHPDate = (int) cpsrss1Date;
		} else {
			//carico tutte le date presenti sul calendario PAMP
			//List<Timestamp> calendDateList = calend.getListDate(marketCode);
					
			// ciclo su INSTRACS		
			for (Cpsrss1 clearing:cpsrss1) {
				/*Conversione date da long a timestamp della data presente su INTRACS*/
				date = (int) clearing.getPk().getHDate();
				if (date>lastHPDate) {
					lastHPDate = date;
				}
				/*year = Integer.parseInt(Integer.toString(date).substring(0,4));
				month = Integer.parseInt(Integer.toString(date).substring(4, 6))-1;
				day = Integer.parseInt(Integer.toString(date).substring(6, 8));
				Timestamp convertedDate = new Timestamp(new GregorianCalendar(year,month,day).getTimeInMillis());*/
				//TODO GenericTools.convertDateFromIntToTimestamp(date);
				Timestamp convertedDate = GenericTools.convertDateFromIntToTimestamp(date);
				
				// verifico se la data appena convertita � presente sulla Lista
				if (calendDateList.contains(convertedDate)) {
					
					// controllo che la colonna del prezzo non sia vuota o di valore zero
					if (!(clearing.getHClose()== null || clearing.getHClose().doubleValue()<0.000001)) {
						hisPr.add(instrId, convertedDate, clearing.getHClose(), "E");
						appIntLog.info("Downloaded historical price for instrId "+instrId+" (Code: "+hSymbl+"); date: "+convertedDate.toString().substring(0, 10)+"; price: "+clearing.getHClose());
						updated++;
					}
					
					// il prezzo da scaricare � vuoto o zero - il sistema avvisa del problema e passa al record successivo senza scaricare il prezzo in questione
					else {
						appIntLog.warn(error+convertedDate.toString().substring(0, 10)+") with Null or 0 value for Close Price");
						failed++;
					}
				total++;
				
				// la data non � presente sul calendario PAMP - il sistema avvisa della sua assenza e passa al record successivo
				} else {
					appIntLog.warn("Price date is not in PAMP calendar: "+convertedDate.toString().substring(0, 10)+" for instrument Id "+instrId+" ("+hSymbl+")");
					failed++;
				}
			}

		}
		setDateLMap(instrId,lastHPDate);
		setTotal(total.intValue());
		setUpdated(updated.intValue());
		setFailed(failed.intValue());
	}
	
	/*---------------------------- parte FUTURES------------------------------*/
	public String transferFutures(boolean delta) throws DataNotValidException {
		setTotal(0);
		setUpdated(0);
		setFailed(0);
		this.dateLMap.clear();
		Instrument[] instrument = instr.getFutures();
		
		//Ciclo sui futures (type F o FO)
		for (Instrument instr:instrument) {
			try {
				transferFutures(instr, delta, total, failed, updated);
			} catch (Exception e) {
				String error = "Error happened on INSTRID "+instr.getInstrId()+" (Code: "+instr.getClassCode();
				appIntLog.error(error+"\n"+e.getMessage()+"\n"+e.getStackTrace());
			}
		}
		total = failed + updated;
		
		String message = "Import of Eq. Derivatives historical price series (futures financial instruments) completed";
		if (updated==0&&failed==0) {
			message+=" with no effects";
		}
		if (updated>0) {
			message += ": found "+instrument.length+" financial instruments, "+updated+"/"+total+" records successfully imported";
		}
		/*if (failed>0) {
			if (updated>0) {
				message += ", ";
			} else {
				message += ": found "+instrument.length+" financial instruments, ";
			}
			message += failed+" records have not been imported";
		}*/
		
		message += this.logMessage(updated);
		
		if (!checkMaxDate().equalsIgnoreCase("")) {
			message += "\n\nNote: "+checkMaxDate();
		}
		
		return message;
	}
	
	public void transferFutures(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException {
		int date;
    	int year; 
		int month;
		int day;
		int lastHPDate = 0;	
		GregorianCalendar cal;
		cal = new GregorianCalendar(1900,0,1);
		Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
		int instrId = instr.getInstrId();
		if (delta) {
			/*prendo su DerivativesHistoricalPrices la data pi� grande per quell'instrId*/ 
			DerivativesHistoricalPrice[] derivatives = derivativesHP.findByInstrIdAndPc(instrId,"F");
			if (derivatives.length>0) {
				lastDate = derivatives[0].getPk().getPriceDate();
			}
		} else {
			derivativesHP.removeByInstrIdAndPc(instrId,"F");
		}
		
		
		
		/*recupero classCode e marketCode dello strumento*/ 
		String hSymbl = instr.getClassCode();
		String marketCode = instr.getMarketCode();
		
		String error = "Found INSTRID "+instrId+" (Code: "+hSymbl+", Date: ";
		String instrNotInClearing ="INSTRID "+instrId+" (Code: "+hSymbl+") - No new historical prices series avalaible in INFO system";
		
		//cerco su INTRACS per INSTR.CLASSCODE e INSTRTYPE = 'F'
		/*  se sto trasferendo da un certo punto in poi, devo assicurarmi che la data
		 *  in questione sia successiva a quella da cui voglio iniziare a scaricare altrimenti scarico senza problemi
		*/
		long cpsrss1Date = (long) Integer.parseInt(lastDate.toString().substring(0,4)+lastDate.toString().substring(5,7)+lastDate.toString().substring(8,10));
		Cpsrss1[] cpsrss1 = (Cpsrss1[]) cpsrss.findFuturesBySymbl(hSymbl,cpsrss1Date);
		
		if (cpsrss1.length==0) {
			appIntLog.warn(instrNotInClearing);
			lastHPDate = (int) cpsrss1Date;
		} else {
			BigDecimal zero = new BigDecimal(0);
			//carico tutte le date presenti sul calendario PAMP
			List<Timestamp> calendDateList = calend.getListDate(marketCode);
			// ciclo su INSTRACS
			for (Cpsrss1 clearing:cpsrss1) {
				/*Conversione date da long a timestamp*/
				date = (int) clearing.getPk().getHDate();
				
				if (date>lastHPDate) {
					lastHPDate = date;
				}
				
				year = Integer.parseInt(Integer.toString(date).substring(0,4));
				month = Integer.parseInt(Integer.toString(date).substring(4, 6))-1;
				day = Integer.parseInt(Integer.toString(date).substring(6, 8));
				cal = new GregorianCalendar(year,month,day);
				
				Timestamp convertedDate = new Timestamp(cal.getTimeInMillis());
				int expiry = (int) clearing.getPk().getHExpir();
				
				// verifico se la data appena convertita � presente sulla Lista
				if (calendDateList.contains(convertedDate)) {
					
					// controllo che la colonna del prezzo non sia vuota o minore di zero
					if (!(clearing.getHClose()== null || clearing.getHClose().doubleValue()<0.000000)) {
						derivativesHP.add(instrId, convertedDate,"F", zero, expiry, clearing.getHCusip(), "E", zero,clearing.getHClose());
						// se per� � uguale a zero d� un warning
						if (clearing.getHClose().doubleValue()==0.0) {
							appIntLog.warn(error+convertedDate.toString().substring(0, 10)+") with 0 value for Close Price");
						}
						appIntLog.info("Downloaded historical price for instrId "+instrId+" (Code: "+hSymbl+"); date: "+convertedDate.toString().substring(0, 10)+"; price: "+clearing.getHClose()+"; expiry: "+expiry);
						updated++;
					} else {
						// il prezzo da scaricare � vuoto o minore di zero - il sistema avvisa della problema e passa al record successivo senza scaricare il prezzo in questione
						appIntLog.warn(error+convertedDate.toString().substring(0, 10)+") with Null or negative value for Close Price");
						failed++;
					}
				total++;
				} else {
					
					// la data non � presente sul calendario PAMP - il sistema avvisa della sua assenza e passa al record successivo
					appIntLog.warn("Price date is not in PAMP calendar: "+convertedDate.toString().substring(0, 10)+" for instrument Id "+instrId+" ("+hSymbl+")");
					failed++;
				}
			}
		}
		setDateLMap(instrId,lastHPDate);
		setTotal(total.intValue());
		setUpdated(updated.intValue());
		setFailed(failed.intValue());
		 
	}
	/*---------------------------- parte FUTURES/CASH------------------------------*/
	public String transferCashFromFutures(boolean delta) throws DataNotValidException {
		setTotal(0);
		setUpdated(0);
		setFailed(0);
		this.dateLMap.clear();
		
		Instrument[] instrument = instr.getCashAndIndex(); // scarico sia i cash che gli index
		
		//Ciclo sugli index (type F)
		for (Instrument instr:instrument) {
			try {
				transferCashFromFutures(instr, delta, total, failed, updated);
			} catch (Exception e) {
				String error = "Error happened on INSTRID "+instr.getInstrId()+" (Code: "+instr.getClassCode()+")";
				appIntLog.error(error+"\n"+e.getMessage()+"\n"+e.getStackTrace());
			}
		}
		total = failed + updated;
		
		String message = "Import of cash financial instruments historical price series completed";
		if (updated==0&&failed==0) {
			message+=" with no effects";
		}
		/*if (updated>0) {
			message += ": found "+instrument.length+" financial instruments, "+updated+"/"+total+" records successfully imported";
		}
		if (failed>0) {
			if (updated>0) {
				message += ", ";
			} else {
				message += ": found "+instrument.length+" financial instruments, ";
			}
			message += failed+" records have not been imported";
		}*/
		
		message += this.logMessage(updated);
		
		if (!checkMaxDate().equalsIgnoreCase("")) {
			message += "\n\nNote: "+checkMaxDate();
		}
		
		return message;
	}
	
	
	
	public void transferCashFromFutures(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException {
		int date;
    	int year; 
		int month;
		int day;
		int lastHPDate = 0;	
		GregorianCalendar cal;
		cal = new GregorianCalendar(1900,0,1);
		Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
		int instrId = instr.getInstrId();
		if (delta) {
			/*prendo su HistoricalPrices la data pi� grande per quell'instrId*/ 
			HistoricalPrices[] historicalPrices = hisPr.findByInstrIdForDownload(instrId);
			if (historicalPrices.length>0) {
				lastDate = historicalPrices[0].getPk().getPricedate();
			}
		} else {
			hisPr.removeByInstrId(instrId);
		}
		
		/*recupero classCode e marketCode dello strumento*/ 
		String hSymbl = instr.getClassCode();
		String marketCode = instr.getMarketCode();
		
		String error = "Found INSTRID "+instrId+" (Code: "+hSymbl+", Date: ";
		String instrNotInClearing ="INSTRID "+instrId+" (Code: "+hSymbl+") - No new historical prices series avalaible in INFO system";
		
		//cerco su INTRACS per INSTR.CLASSCODE e INSTRTYPE = 'F'
		/*  se sto trasferendo da un certo punto in poi, devo assicurarmi che la data
		 *  in questione sia successiva a quella da cui voglio iniziare a scaricare altrimenti scarico senza problemi
		*/
		long cpsrss1Date =  (long) Integer.parseInt(lastDate.toString().substring(0,4)+lastDate.toString().substring(5,7)+lastDate.toString().substring(8,10));
		Cpsrss1[] cpsrss1 = (Cpsrss1[]) cpsrss.findCashFromFuturesBySymbl(hSymbl, cpsrss1Date);
		
		if (cpsrss1.length==0) {
			appIntLog.warn(instrNotInClearing);
			lastHPDate = (int) cpsrss1Date;
		} else {
			
			//carico tutte le date presenti sul calendario PAMP
			List<Timestamp> calendDateList = calend.getListDate(marketCode);
			// ciclo su INSTRACS
			
			for (Cpsrss1 clearing:cpsrss1) {
				/*Conversione date da long a timestamp*/
				date = (int) clearing.getPk().getHDate();
				/*if (date>lastHPDate) {
					lastHPDate = date;
					toWrite = true;//posso scrivere l'index
				}*/
				
				
				//se la data che sto leggendo su intracs � maggiore dell'ultima data letta posso scrivere l'index
				if (date>lastHPDate) {
					lastHPDate = date;
					
					year = Integer.parseInt(Integer.toString(date).substring(0,4));
					month = Integer.parseInt(Integer.toString(date).substring(4, 6))-1;
					day = Integer.parseInt(Integer.toString(date).substring(6, 8));
					cal = new GregorianCalendar(year,month,day);
				
					Timestamp convertedDate = new Timestamp(cal.getTimeInMillis());
					//int expiry = (int) clearing.getPk().getHExpir();
				
					// verifico se la data appena convertita � presente sulla Lista
					if (calendDateList.contains(convertedDate)) {
						BigDecimal closePrice = clearing.getHUclpr();
						
						// controllo se posso scrivere questo record e che la colonna del prezzo non sia vuota o minore di zero
						if (!(closePrice == null || closePrice.doubleValue()<0.000000)) {
							//derivativesHP.add(instrId, convertedDate,"F", zero, expiry, clearing.getHCusip(), "E", zero,closePrice);
							hisPr.add(instrId, convertedDate, closePrice, "E");
							// se per� � uguale a zero d� un warning
							if (closePrice.doubleValue()==0.0) {
								appIntLog.warn(error+convertedDate.toString().substring(0, 10)+") with 0 value for Close Price");
							}
							
							appIntLog.info("Downloaded historical price for instrId "+instrId+" (Code: "+hSymbl+"); date: "+convertedDate.toString().substring(0, 10)+"; price: "+closePrice);
							updated++;
						} else {
							// il prezzo da scaricare � vuoto o minore di zero - il sistema avvisa della problema e passa al record successivo senza scaricare il prezzo in questione
							appIntLog.warn(error+convertedDate.toString().substring(0, 10)+") with Null or negative value for Close Price");
							failed++;
						}
					total++;
					} else {
						// la data non � presente sul calendario PAMP - il sistema avvisa della sua assenza e passa al record successivo
						appIntLog.warn("Price date is not in PAMP calendar: "+convertedDate.toString().substring(0, 10)+" for instrument Id "+instrId+" ("+hSymbl+")");
						failed++;
					}
				}
			}
		}
		setDateLMap(instrId,lastHPDate);
		setTotal(total.intValue());
		setUpdated(updated.intValue());
		setFailed(failed.intValue());
		 
	}
	
	
	/*---------------------------- parte INDEX------------------------------*/
	public String transferIndex(boolean delta) throws DataNotValidException {
		setTotal(0);
		setUpdated(0);
		setFailed(0);
		this.dateLMap.clear();
		Instrument[] instrument = instr.getIndexToSync();
		
		//Ciclo sugli index (type I)
		for (Instrument instr:instrument) {
			try {
				transferIndex(instr, delta, total, failed, updated);
			} catch (Exception e) {
				String error = "Error happened on INSTRID "+instr.getInstrId()+" (Code: "+instr.getClassCode()+")";
				appIntLog.error(error+"\n"+e.getMessage()+"\n"+e.getStackTrace());
			}
		}
		total = failed + updated;
		
		String message = "Import of index historical value series completed";
		if (updated==0&&failed==0) {
			message+=" with no effects";
		}
		if (updated>0) {
			message += ": found "+instrument.length+" financial instruments, "+updated+"/"+total+" records successfully imported";
		}
		if (failed>0) {
			if (updated>0) {
				message += ", ";
			} else {
				message += ": found "+instrument.length+" financial instruments, ";
			}
			message += failed+" records have not been imported";
		}
		
		message += this.logMessage(updated);
		
		if (!checkMaxDate().equalsIgnoreCase("")) {
			message += "\n\nNote: "+checkMaxDate();
		}
		
		return message;
	}
	
	
	
	public void transferIndex(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException {
		int date;
    	int year; 
		int month;
		int day;
		int lastHPDate = 0;	
		GregorianCalendar cal;
		cal = new GregorianCalendar(1900,0,1);
		Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
		int instrId = instr.getInstrId();
		if (delta) {
			/*prendo su DerivativesHistoricalPrices la data pi� grande per quell'instrId*/ 
			HistoricalPrices[] historicalPrices = hisPr.findByInstrIdForDownload(instrId);
			if (historicalPrices.length>0) {
				lastDate = historicalPrices[0].getPk().getPricedate();
			}
		} else {
			hisPr.removeByInstrId(instrId);
		}
		
		boolean takeUndClosePr = true;
		
		if (!instr.getDerHist().equalsIgnoreCase("T")) {
			takeUndClosePr = false;
		}
		
		/*recupero classCode e marketCode dello strumento*/ 
		String hSymbl = instr.getClassCode();
		String marketCode = instr.getMarketCode();
		
		String error = "Found INSTRID "+instrId+" (Code: "+hSymbl+", Date: ";
		String instrNotInClearing ="INSTRID "+instrId+" (Code: "+hSymbl+") - No new index historical value series avalaible in INFO system";
		
		//cerco su INTRACS per INSTR.CLASSCODE e INSTRTYPE = 'F'
		/*  se sto trasferendo da un certo punto in poi, devo assicurarmi che la data
		 *  in questione sia successiva a quella da cui voglio iniziare a scaricare altrimenti scarico senza problemi
		*/
		long cpsrss1Date =  (long) Integer.parseInt(lastDate.toString().substring(0,4)+lastDate.toString().substring(5,7)+lastDate.toString().substring(8,10));
		Cpsrss1[] cpsrss1 = (Cpsrss1[]) cpsrss.findIndexBySymbl(hSymbl,cpsrss1Date);
		
		if (cpsrss1.length==0) {
			appIntLog.warn(instrNotInClearing);
			lastHPDate = (int) cpsrss1Date;
		} else {
			
			//carico tutte le date presenti sul calendario PAMP
			List<Timestamp> calendDateList = calend.getListDate(marketCode);
			// ciclo su INSTRACS
			
			for (Cpsrss1 clearing:cpsrss1) {
				/*Conversione date da long a timestamp*/
				date = (int) clearing.getPk().getHDate();
				/*if (date>lastHPDate) {
					lastHPDate = date;
					toWrite = true;//posso scrivere l'index
				}*/
				
				
				//se la data che sto leggendo su intracs � maggiore dell'ultima data letta posso scrivere l'index
				if (date>lastHPDate) {
					lastHPDate = date;
					
					year = Integer.parseInt(Integer.toString(date).substring(0,4));
					month = Integer.parseInt(Integer.toString(date).substring(4, 6))-1;
					day = Integer.parseInt(Integer.toString(date).substring(6, 8));
					cal = new GregorianCalendar(year,month,day);
				
					Timestamp convertedDate = new Timestamp(cal.getTimeInMillis());
					
					// verifico se la data appena convertita � presente sulla Lista
					if (calendDateList.contains(convertedDate)) {
						BigDecimal closePrice = clearing.getHUclpr();
						if (!takeUndClosePr) {
							closePrice = clearing.getHClose();
						}
						// controllo se posso scrivere questo record e che la colonna del prezzo non sia vuota o minore di zero
						if (!(closePrice == null || closePrice.doubleValue()<0.000000)) {
							//derivativesHP.add(instrId, convertedDate,"F", zero, expiry, clearing.getHCusip(), "E", zero,closePrice);
							hisPr.add(instrId, convertedDate, closePrice, "E");
							// se per� � uguale a zero d� un warning
							if (closePrice.doubleValue()==0.0) {
								appIntLog.warn(error+convertedDate.toString().substring(0, 10)+") with 0 value for value series");
							}
							
							appIntLog.info("Downloaded index historical value series for instrId "+instrId+" (Code: "+hSymbl+"); date: "+convertedDate.toString().substring(0, 10)+"; price: "+closePrice);
							updated++;
						} else {
							// il prezzo da scaricare � vuoto o minore di zero - il sistema avvisa della problema e passa al record successivo senza scaricare il prezzo in questione
							appIntLog.warn(error+convertedDate.toString().substring(0, 10)+") with Null or negative value for value series");
							failed++;
						}
					total++;
					} else {
						
						// la data non � presente sul calendario PAMP - il sistema avvisa della sua assenza e passa al record successivo
						appIntLog.warn("Price date is not in PAMP calendar: "+convertedDate.toString().substring(0, 10)+" for instrument Id "+instrId+" ("+hSymbl+")");
						failed++;
					}
				}
			}
		}
		setDateLMap(instrId,lastHPDate);
		setTotal(total.intValue());
		setUpdated(updated.intValue());
		setFailed(failed.intValue());
		 
	}	
	
/*---------------------------- parte OPTION------------------------------*/
	
	public String transferOptions(boolean delta) throws DataNotValidException {
		setTotal(0);
		setUpdated(0);
		setFailed(0);
		this.dateLMap.clear();
		Instrument[] instrument = instr.getOptions();
		
		String currentMarket = "";
		List<Timestamp> calendDateList = new ArrayList<Timestamp>();
		
		for (Instrument instr:instrument) {
			try {
				if (!currentMarket.equalsIgnoreCase(instr.getMarketCode())) {
					calendDateList = calend.getListDate(instr.getMarketCode());
					currentMarket = instr.getMarketCode();
				}
				transferOptions(instr, delta, calendDateList, total, failed, updated);
			} catch (Exception e) {
				String error = "Error happened on INSTRID "+instr.getInstrId()+" (Code: "+instr.getClassCode()+")";
				appIntLog.error(error+"\n"+e.getMessage()+"\n"+e.getStackTrace());
			}
		}
		
		total = failed + updated;
		String message = "Import of Eq. Derivatives Historical price series (options financial instruments) completed";
		if (updated==0&&failed==0) {
			message+=" with no effects";
		}
		/*if (updated>0) {
			message += ": found "+instrument.length+" financial instruments, "+updated+"/"+total+" records successfully imported";
		}
		if (failed>0) {
			if (updated>0) {
				message += ", ";
			} else {
				message += ": found "+instrument.length+" financial instruments, ";
			}
			message += failed+" records have not been imported";
		}*/
		
		message += this.logMessage(updated);

		if (!checkMaxDate().equalsIgnoreCase("")) {
			message += "\n\nNote: "+checkMaxDate();
		}
		
		return message;
	}
	
	public void transferOptions(Instrument instr, boolean delta, List<Timestamp> calendDateList, Integer total, Integer failed, Integer updated) throws DataNotValidException {
				
		int date;
    	int year; 
		int month;
		int day;
		int lastHPDate = 0;	
		GregorianCalendar cal;
		cal = new GregorianCalendar(1900,0,1);
		Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
		int instrId = instr.getInstrId();
		if (delta) {
			/*prendo su HistoricalPrices la data pi� grande per quell'instrId*/ 
			DerivativesHistoricalPrice[] derivatives = derivativesHP.findByInstrIdAndPc(instrId,"O");
			if (derivatives.length>0) {
				lastDate = derivatives[0].getPk().getPriceDate();
				System.out.println("lastDate: "+lastDate);
			}
		} else {
			derivativesHP.removeByInstrIdAndPc(instrId,"O");
		}
		
		/*recupero classCode e marketCode da instrument*/ 
		String hSymbl = instr.getClassCode();
		String marketCode = instr.getMarketCode();
		String error = "Found INSTRID "+instrId+" (Code: "+hSymbl+", Date: ";
		String instrNotInClearing ="INSTRID "+instrId+" (Code: "+hSymbl+") - No new historical prices series avalaible in INFO system";
		
		//cerco su INTRACS per INSTR.CLASSCODE e INSTRTYPE = 'O'
		/*  se sto trasferendo da un certo punto in poi, devo assicurarmi che la data
		 *  in questione sia successiva a quella da cui voglio iniziare a scaricare altrimenti scarico senza problemi
		*/
		
		long cpsrss1Date = (long) Integer.parseInt(lastDate.toString().substring(0,4)+lastDate.toString().substring(5,7)+lastDate.toString().substring(8,10));
		Cpsrss1[] cpsrss1 = (Cpsrss1[]) cpsrss.findOptionsBySymbl(hSymbl,cpsrss1Date);
		
		if (cpsrss1.length==0) {
			appIntLog.warn(instrNotInClearing);
			lastHPDate = (int) cpsrss1Date;
		} else {
			//carico tutte le date presenti sul calendario PAMP
			//List<Timestamp> calendDateList = calend.getListDate(marketCode);
			//ciclo su INTRACS
			for (Cpsrss1 clearing:cpsrss1) {
				/*Conversione date da long a timestamp*/
				date = (int) clearing.getPk().getHDate();
				if (date>lastHPDate) {
					lastHPDate = date;
				}
				year = Integer.parseInt(Integer.toString(date).substring(0,4));
				month = Integer.parseInt(Integer.toString(date).substring(4, 6))-1;
				day = Integer.parseInt(Integer.toString(date).substring(6, 8));
				cal = new GregorianCalendar(year,month,day);
				Timestamp convertedDate = new Timestamp(cal.getTimeInMillis());
				int expiry = (int) clearing.getPk().getHExpir();
				
				// verifico se la data appena convertita � presente sulla Lista
				if (calendDateList.contains(convertedDate)) {
					
					// controllo che la colonna del prezzo non sia vuota o minore di zero
					if (!(clearing.getHClose()== null || clearing.getHClose().doubleValue()<0.000000)) {
						derivativesHP.add(instrId, convertedDate,clearing.getPk().getHPc(), clearing.getPk().getHStrik(), expiry, clearing.getHCusip(), "E", clearing.getHImpvl().divide(new BigDecimal(100)),clearing.getHClose());
						// se per� � uguale a zero d� un warning
						if (clearing.getHClose().doubleValue()==0.0) {
							appIntLog.warn(error+convertedDate.toString().substring(0, 10)+") with 0 value for Close Price");
						}
						appIntLog.info("Downloaded historical price for instrId "+instrId+" (Code: "+hSymbl+"); date: "+convertedDate.toString().substring(0, 10)+"; price: "+clearing.getHClose()+"; expiry: "+expiry+"; strike: "+clearing.getPk().getHStrik());
						updated++;
					} else {
						// il prezzo da scaricare � vuoto o minore di zero - il sistema avvisa della problema e passa al record successivo senza scaricare il prezzo in questione
						appIntLog.warn(error+convertedDate.toString().substring(0, 10)+") with Null or negative value for Close Price");
						failed++;
					}
					total++;
				} else {
					// la data non � presente sul calendario PAMP - il sistema avvisa della sua assenza e passa al record successivo
					appIntLog.warn("Price date is not in PAMP calendar: "+convertedDate.toString().substring(0, 10)+" for instrument Id "+instrId+" ("+hSymbl+")");
					failed++;
				}
			}
		}
		setDateLMap(instrId,lastHPDate);
		setTotal(total.intValue());
		setUpdated(updated.intValue());
		setFailed(failed.intValue());
	}
	
	
/*---------------------------- parte BONDS------------------------------*/
	
	public String transferBonds(boolean delta) throws DataNotValidException {
		setTotal(0);
		setUpdated(0);
		setFailed(0);
		this.dateLMap.clear();
		List<Instrument> instrument = instr.getInflationBonds();
		
		for (Instrument instr:instrument) {
			try {
				transferBonds(instr, delta, total, failed, updated);
			} catch (Exception e) {
				String error = "Error happened on INSTRID "+instr.getInstrId()+" (Code: "+instr.getClassCode()+")";
				appIntLog.error(error+"\n"+e.getMessage()+"\n"+e.getStackTrace());
			}
		}
		
		total = failed + updated;
		String message = "Import of Bond historical price series completed";
		if (updated==0&&failed==0) {
			message+=" with no effects";
		}
		/*if (updated>0) {
			message += ": found "+instrument.size()+" financial instruments, "+updated+"/"+total+" records successfully imported";
		}
		if (failed>0) {
			if (updated>0) {
				message += ", ";
			} else {
				message += ": found "+instrument.size()+" financial instruments, ";
			}
			message += failed+" records have not been imported";
		}*/
		
		message += this.logMessage(updated);

		if (!checkMaxDate().equalsIgnoreCase("")) {
			message += "\n\nNote: "+checkMaxDate();
		}
		
		return message;
	}
	
	public void transferBonds(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException {
		int date;
    	int year; 
		int month;
		int day;
		int lastHPDate = 0;	
		GregorianCalendar cal = new GregorianCalendar(1900,0,1);
		Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
		int instrId = instr.getInstrId();
		
		if (delta) {
			/*prendo su HistoricalPrices la data pi� grande per quell'instrId*/ 
			HistoricalPrices[] arrHistPrices = hisPr.findByInstrId(instrId);
			if (arrHistPrices.length>0) {
				lastDate = arrHistPrices[0].getPk().getPricedate();
			}
		} else {
			hisPr.removeByInstrId(instrId);
		}
		
		/*recupero classCode, isinCode e marketCode da instrument*/ 
		String hSymbl = instr.getClassCode();
		String marketCode = instr.getMarketCode();
		String isinCode = instr.getIsinCode();
		
		//predispngo stringhe di errore/warning
		String error = "Found INSTRID "+instrId+" (Code: "+hSymbl+", Date: ";
		String instrNotInClearing ="INSTRID "+instrId+" (Code: "+hSymbl+") - No new historical prices series avalaible in INFO system";
		
		//cerco su INTRACS per INSTR.ISINCODE
		/*  se sto trasferendo da un certo punto in poi, devo assicurarmi che la data
		 *  in questione sia successiva a quella da cui voglio iniziare a scaricare altrimenti scarico senza problemi
		*/
		long pDataR =  (long) Integer.parseInt(lastDate.toString().substring(0,4)+lastDate.toString().substring(5,7)+lastDate.toString().substring(8,10));
		List<WMtsprc0hf> wMtsprc0hfList = mtsprc0hfEAO.findByIsinCode(isinCode, pDataR);
		
		if (wMtsprc0hfList.size()==0) {
			appIntLog.warn(instrNotInClearing);
			lastHPDate = (int) pDataR;
		} else {
			//carico tutte le date presenti sul calendario PAMP
			List<Timestamp> calendDateList = calend.getListDate(marketCode);
			// ciclo su INSTRACS		
			for (WMtsprc0hf mtsprc0hf:wMtsprc0hfList) {
				//Conversione date da long a timestamp della data presente su INTRACS
				date = (int) mtsprc0hf.getPk().getPDataR();
				if (date>lastHPDate) {
					lastHPDate = date;
				}
				year = Integer.parseInt(Integer.toString(date).substring(0,4));
				month = Integer.parseInt(Integer.toString(date).substring(4, 6))-1;
				day = Integer.parseInt(Integer.toString(date).substring(6, 8));
				Timestamp convertedDate = new Timestamp(new GregorianCalendar(year,month,day).getTimeInMillis());
				
				// verifico se la data appena convertita � presente sulla Lista
				if (calendDateList.contains(convertedDate)) {
					
					// controllo che la colonna del prezzo non sia vuota o di valore zero
					if (!(mtsprc0hf.getpPrice()== null || mtsprc0hf.getpPrice().doubleValue()<0.000001)) {
						hisPr.add(instrId, convertedDate, mtsprc0hf.getpPrice(), "E");
						appIntLog.info("Downloaded historical price for instrId "+instrId+" (Code: "+hSymbl+"); date: "+convertedDate.toString().substring(0, 10)+"; price: "+mtsprc0hf.getpPrice());
						updated++;
					}
					
					// il prezzo da scaricare � vuoto o zero - il sistema avvisa del problema e passa al record successivo senza scaricare il prezzo in questione
					else {
						appIntLog.warn(error+convertedDate.toString().substring(0, 10)+") with Null or 0 value for Close Price");
						failed++;
					}
				total++;
				
				// la data non � presente sul calendario PAMP - il sistema avvisa della sua assenza e passa al record successivo
				} else {
					appIntLog.warn("Price date is not in PAMP calendar: "+convertedDate.toString().substring(0, 10)+" for instrument Id "+instrId+" ("+hSymbl+")");
					failed++;
				}
			}
			//dateLMap.put(instrId, lastHPDate);
		}
		setDateLMap(instrId,lastHPDate);
		setTotal(total.intValue());
		setUpdated(updated.intValue());
		setFailed(failed.intValue());
	}
	
	/*-----------------------parte tassi di cambio------------------*/
	public String transferCurrency(boolean delta) throws DataNotValidException {
		setTotal(0);
		setUpdated(0);
		setFailed(0);
		this.dateLMap.clear();
		Instrument[] arrInstrument = instr.getCurrencies();
		
		for (Instrument instr:arrInstrument) {
			try {
				transferCurrency(instr, delta, total, failed, updated);
			} catch (Exception e) {
				String error = "Error happened on INSTRID "+instr.getInstrId()+" (Code: "+instr.getClassCode()+")";
				appIntLog.error(error+"\n"+e.getMessage()+"\n"+e.getStackTrace());
			}
		}
		
		total = failed + updated;
		String message = "Import of Currency historical change value series completed";
		if (updated==0&&failed==0) {
			message+=" with no effects";
		}
		/*if (updated>0) {
			message += ": found "+arrInstrument.length+" currencies, "+updated+"/"+total+" records successfully imported";
		}
		if (failed>0) {
			if (updated>0) {
				message += ", ";
			} else {
				message += ": found "+arrInstrument.length+" currencies, ";
			}
			message += failed+" records have not been imported";
		}*/
		
		message += this.logMessage(updated);

		if (!checkMaxDate().equalsIgnoreCase("")) {
			message += "\n\nNote: "+checkMaxDate();
		}
		
		return message;
	}
	
	public void transferCurrency(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException {
		
		long date;
    	int lastHPDate = 0;	
		
    	//define a default starting date
    	GregorianCalendar cal = new GregorianCalendar(1900,0,1);
		Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
		
		int instrId = instr.getInstrId();
		
		// if the flag DELTA is active
		if (delta) {
			/*get the most recent price date from INSTRID historical price series*/ 
			HistoricalPrices[] historicalPrices = hisPr.findByInstrIdForDownload(instrId);
			if (historicalPrices.length>0) {
				lastDate = historicalPrices[0].getPk().getPricedate();
			}
		} else {
			// remove ALL the historical price series 
			hisPr.removeByInstrId(instrId);
		}
		
		/*recupero bloombergCode e marketCode da instrument*/ 
		String currencyCode = instr.getClassCode();
		String marketCode = instr.getMarketCode();
		
		//predispngo stringhe di errore/warning
		String error = "Found INSTRID "+instrId+" (Code: "+currencyCode+", Date: ";
		String instrNotInClearing = "INSTRID "+instrId+" (Code: "+currencyCode+") - No new historical change value series avalaible in INFO system";
		
		//cerco su INTRACS per INSTR.CLASSCODE e INSTRTYPE = 'C'
		/*  se sto trasferendo da un certo punto in poi, devo assicurarmi che la data
		 *  in questione sia successiva a quella da cui voglio iniziare a scaricare altrimenti scarico senza problemi
		*/
		
		//cerco sull'anagrafica Reuters per RicCode
		InfoProviderInstr infoProvInstr = infoProvInstrEAO.findCurrencyByClassCode(currencyCode);
		
		if (infoProvInstr==null) {
			appIntLog.warn("No currency found on Info Provider static data for this code: "+currencyCode);
		} else {
			//cerco su SISTEMA REUTERS per INSTR.INSTRID sullo storico dei prezzi
			//  se sto trasferendo da un certo punto in poi, devo assicurarmi che la data
			//  in questione sia successiva a quella da cui voglio iniziare a scaricare altrimenti scarico senza problemi
			
			//long intracsDate =  GenericTools.shortDateFormatAsLong(lastDate);
			
			List<InfoProviderHispr> infoProvHistPricesList = infoProvHisprEAO.findByInstrIdAfterDate(infoProvInstr.getInstrId(),GenericTools.shortDateFormatAsLong(lastDate));
			
			if (infoProvHistPricesList.size()==0) {
				appIntLog.warn(instrNotInClearing);
				lastHPDate = (int) GenericTools.shortDateFormatAsLong(lastDate);
			} else {
			//carico tutte le date presenti sul calendario PAMP
				//List<Timestamp> calendDateList = calend.getListDate(marketCode);
						
				// ciclo su SISTEMA REUTERS		
				for (InfoProviderHispr infoProvHistPrice:infoProvHistPricesList) {
									
					if (infoProvHistPrice.getPk().getPriceDate() > lastHPDate) {
						lastHPDate = infoProvHistPrice.getPk().getPriceDate();
					}
					
					// verifico se la data appena convertita � presente sulla Lista
					//if (calendDateList.contains(GenericTools.convertDateFromIntToTimestamp(infoProvHistPrice.getPk().getPriceDate()))) {
						
						// controllo che la colonna del prezzo non sia vuota o di valore zero
						if (!(infoProvHistPrice.getClosePr()== null || infoProvHistPrice.getClosePr().doubleValue()<0.000001)) {
							hisPr.add(instrId, GenericTools.convertDateFromIntToTimestamp(infoProvHistPrice.getPk().getPriceDate()), infoProvHistPrice.getClosePr().divide(new BigDecimal(100)), "E");
							appIntLog.info("Downloaded change value for instrId "+instrId+" (Code: "+currencyCode+"); date: "+GenericTools.convertDateFromIntToString(infoProvHistPrice.getPk().getPriceDate())+"; change value: "+infoProvHistPrice.getClosePr());
							updated++;
						}
						
						// il prezzo da scaricare � vuoto o zero - il sistema avvisa del problema e passa al record successivo senza scaricare il prezzo in questione
						else {
							appIntLog.warn(error+infoProvHistPrice.getPk().getPriceDate()+") with Null or 0 price");
							failed++;
						}
					total++;

				}
				//dateLMap.put(instrId, lastHPDate);
			}
		}
		setDateLMap(instrId,lastHPDate);
		setTotal(total.intValue());
		setUpdated(updated.intValue());
		setFailed(failed.intValue());
		
		/*long intracsDate =  GenericTools.shortDateFormatAsLong(lastDate);
		
		List<Tcoccyf00f> intracsCurrList = tcoccyf00fEAO.findAfterDateByBlomCode(intracsDate, currencyCode);
		
		if (intracsCurrList.size()==0) {
			appIntLog.warn(instrNotInClearing);
			lastHPDate = intracsDate;
		} else {
			//carico tutte le date presenti sul calendario PAMP
			//List<Timestamp> calendDateList = calend.getListDate(marketCode);
					
			// ciclo su INSTRACS		
			for (Tcoccyf00f intracsCurr:intracsCurrList) {
				Conversione date da long a timestamp della data presente su INTRACS
				date = intracsCurr.getPk().getCcyData().longValue();
				if (date>lastHPDate) {
					lastHPDate = date;
				}
				year = Integer.parseInt(Integer.toString(date).substring(0,4));
				month = Integer.parseInt(Integer.toString(date).substring(4, 6))-1;
				day = Integer.parseInt(Integer.toString(date).substring(6, 8));
				Timestamp convertedDate = GenericTools.convertDateFromIntToTimestamp((int) date);
				//new Timestamp(new GregorianCalendar(year,month,day).getTimeInMillis());
								
				// verifico se la data appena convertita � presente sulla Lista
				//if (calendDateList.contains(convertedDate)) {
					
					// controllo che la colonna del prezzo non sia vuota o di valore zero
					if (!(intracsCurr.getCcyVal()== null || intracsCurr.getCcyVal().doubleValue()<0.000001)) {
						
						BigDecimal reciproco = new BigDecimal(1).divide(intracsCurr.getCcyVal(), new MathContext(5));
						
						if (intracsCurr.getPk().getCcyBlom().equalsIgnoreCase("JPYEUR")) {
							reciproco = reciproco.multiply(new BigDecimal(100));  
						}
						
						hisPr.add(instrId, convertedDate, reciproco, "E");
						appIntLog.info("Downloaded change value for instrId "+instrId+" (Code: "+currencyCode+"); date: "+convertedDate.toString().substring(0, 10)+"; change value: "+reciproco);
						updated++;
					}
					
					// il prezzo da scaricare � vuoto o zero - il sistema avvisa del problema e passa al record successivo senza scaricare il prezzo in questione
					else {
						appIntLog.warn(error+convertedDate.toString().substring(0, 10)+") with Null or 0 value for change value");
						failed++;
					}
				total++;
				
				// la data non � presente sul calendario PAMP - il sistema avvisa della sua assenza e passa al record successivo
				//} else {
				//	appIntLog.warn("Change value date is not in PAMP calendar: "+convertedDate.toString().substring(0, 10)+" for instrument Id "+instrId+" ("+currCode+")");
				//	failed++;
				//}
			}
			//dateLMap.put(instrId, lastHPDate);
		}
		setDateLMap(instrId,(int) lastHPDate);
		setTotal(total.intValue());
		setUpdated(updated.intValue());
		setFailed(failed.intValue());*/
	}
	
	
	//-----------------------parte reuters------------------
	public String transferInterestRates(boolean delta) throws DataNotValidException {
		setTotal(0);
		setUpdated(0);
		setFailed(0);
		this.dateLMap.clear();
		Instrument[] arrInstrument = instr.getInterestRates();
		
		for (Instrument instr:arrInstrument) {
			try {
				transferInterestRates(instr, delta, total, failed, updated);
			} catch (Exception e) {
				String error = "Error happened on INSTRID "+instr.getInstrId()+" (Code: "+instr.getInstrName()+")";
				appIntLog.error(error+"\n"+e.getMessage()+"\n"+e.getStackTrace());
			}
		}
		
		total = failed + updated;
		String message = "Import of Interest rates historical value series completed";
		if (updated==0&&failed==0) {
			message+=" with no effects";
		}
		/*if (updated>0) {
			message += ": found "+arrInstrument.length+" interest rates, "+updated+"/"+total+" records successfully imported";
		}
		if (failed>0) {
			if (updated>0) {
				message += ", ";
			} else {
				message += ": found "+arrInstrument.length+" interest rates, ";
			}
			message += failed+" records have not been imported";
		}*/
		
		message += this.logMessage(updated);

		if (!checkMaxDate().equalsIgnoreCase("")) {
			message += "\n\nNote: "+checkMaxDate();
		}
		
		return message;
	}
	
	public void transferInterestRates(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException {
		
		
			int lastHPDate = 0;	
			GregorianCalendar cal = new GregorianCalendar(1900,0,1);
			Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
			
			int instrId = instr.getInstrId();
			if (delta) {
				//prendo su HistoricalPrices la data pi� grande per quell'instrId 
				HistoricalPrices[] historicalPrices = hisPr.findByInstrIdForDownload(instrId);
				if (historicalPrices.length>0) {
					lastDate = historicalPrices[0].getPk().getPricedate();
				}
			} else {
				hisPr.removeByInstrId(instrId);
			}
			
			
			//recupero ricCode e marketCode da instrument
			String ricCode = instr.getRicCode();
			String marketCode = instr.getMarketCode();
			
			//predispngo stringhe di errore/warning
			String error = "Found INSTRID "+instrId+" (Code: "+ricCode+", Date: ";
			String instrNotInClearing = "INSTRID "+instrId+" (Code: "+ricCode+") - No new interest rates historical value series avalaible in INFO system";
			
			//cerco sull'anagrafica Reuters per RicCode
			InfoProviderInstr infoProvInstr = infoProvInstrEAO.findByRicCode(ricCode);
			
			if (infoProvInstr==null) {
				appIntLog.warn("No instrument found on Reuters static data for this code: "+ricCode);
			} else {
				//cerco su SISTEMA REUTERS per INSTR.INSTRID sullo storico dei prezzi
				//  se sto trasferendo da un certo punto in poi, devo assicurarmi che la data
				//  in questione sia successiva a quella da cui voglio iniziare a scaricare altrimenti scarico senza problemi
				
			
				//long intracsDate =  GenericTools.shortDateFormatAsLong(lastDate);
				
				List<InfoProviderHispr> infoProvHistPricesList = infoProvHisprEAO.findByInstrIdAfterDate(infoProvInstr.getInstrId(),GenericTools.shortDateFormatAsLong(lastDate));
				
				if (infoProvHistPricesList.size()==0) {
					appIntLog.warn(instrNotInClearing);
					lastHPDate = (int) GenericTools.shortDateFormatAsLong(lastDate);
				} else {
				//carico tutte le date presenti sul calendario PAMP
					//List<Timestamp> calendDateList = calend.getListDate(marketCode);
							
					// ciclo su SISTEMA REUTERS		
					for (InfoProviderHispr infoProvHistPrice:infoProvHistPricesList) {
										
						if (infoProvHistPrice.getPk().getPriceDate() > lastHPDate) {
							lastHPDate = infoProvHistPrice.getPk().getPriceDate();
						}
						
						// verifico se la data appena convertita � presente sulla Lista
						//if (calendDateList.contains(GenericTools.convertDateFromIntToTimestamp(infoProvHistPrice.getPk().getPriceDate()))) {
							
							// controllo che la colonna del prezzo non sia vuota o di valore zero
							if (!(infoProvHistPrice.getClosePr()== null || infoProvHistPrice.getClosePr().doubleValue()<0.000001)) {
								hisPr.add(instrId, GenericTools.convertDateFromIntToTimestamp(infoProvHistPrice.getPk().getPriceDate()), infoProvHistPrice.getClosePr().divide(new BigDecimal(100)), "E");
								appIntLog.info("Downloaded interestRatePrices for instrId "+instrId+" (Code: "+ricCode+"); date: "+GenericTools.convertDateFromIntToString(infoProvHistPrice.getPk().getPriceDate())+"; change value: "+infoProvHistPrice.getClosePr());
								updated++;
							}
							
							// il prezzo da scaricare � vuoto o zero - il sistema avvisa del problema e passa al record successivo senza scaricare il prezzo in questione
							else {
								appIntLog.warn(error+infoProvHistPrice.getPk().getPriceDate()+") with Null or 0 price");
								failed++;
							}
						total++;
						
						// la data non � presente sul calendario PAMP - il sistema avvisa della sua assenza e passa al record successivo
						/*} else {
							appIntLog.warn("Price date is not in PAMP calendar: "+infoProvHistPrice.getPk().getPriceDate()+" for instrument Id "+instrId+" ("+ricCode+")");
							failed++;
						}*/
					}
					//dateLMap.put(instrId, lastHPDate);
				}
			}
			setDateLMap(instrId,lastHPDate);
			setTotal(total.intValue());
			setUpdated(updated.intValue());
			setFailed(failed.intValue());
		
	}
	
	//-----------------------parte reuters------------------
	public String transferComparables(boolean delta) throws DataNotValidException {
		setTotal(0);
		setUpdated(0);
		setFailed(0);
		this.dateLMap.clear();
		Instrument[] arrInstrument = instr.getComparables();
		
		for (Instrument instr:arrInstrument) {
			try {
				transferComparables(instr, delta, total, failed, updated);
			} catch (Exception e) {
				String error = "Error happened on INSTRID "+instr.getInstrId()+" (Code: "+instr.getInstrName()+")";
				appIntLog.error(error+"\n"+e.getMessage()+"\n"+e.getStackTrace());
			}
		}
		
		total = failed + updated;
		String message = "Import of comparables historical price series completed";
		if (updated==0&&failed==0) {
			message+=" with no effects";
		}
		/*if (updated>0) {
			message += ": found "+arrInstrument.length+" interest rates, "+updated+"/"+total+" records successfully imported";
		}
		if (failed>0) {
			if (updated>0) {
				message += ", ";
			} else {
				message += ": found "+arrInstrument.length+" interest rates, ";
			}
			message += failed+" records have not been imported";
		}*/
		
		message += this.logMessage(updated);

		if (!checkMaxDate().equalsIgnoreCase("")) {
			message += "\n\nNote: "+checkMaxDate();
		}
		
		return message;
	}
	
	public void transferComparables(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException {
		
		
			int lastHPDate = 0;	
			GregorianCalendar cal = new GregorianCalendar(1900,0,1);
			Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
			
			int instrId = instr.getInstrId();
			if (delta) {
				//prendo su HistoricalPrices la data pi� grande per quell'instrId 
				HistoricalPrices[] historicalPrices = hisPr.findByInstrIdForDownload(instrId);
				if (historicalPrices.length>0) {
					lastDate = historicalPrices[0].getPk().getPricedate();
				}
			} else {
				hisPr.removeByInstrId(instrId);
			}
			
			
			//recupero ricCode e marketCode da instrument
			String classCode = instr.getClassCode();
			
			//predispngo stringhe di errore/warning
			String error = "Found INSTRID "+instrId+" (Code: "+classCode+", Date: ";
			String instrNotInClearing = "INSTRID "+instrId+" (Code: "+classCode+") - No new interest rates historical value series avalaible in INFO system";
			
			//cerco sull'anagrafica Reuters per RicCode
			InfoProviderInstr infoProvInstr = infoProvInstrEAO.findByRicCode(classCode);
			
			if (infoProvInstr==null) {
				appIntLog.warn("No instrument found on Reuters static data for this code: "+classCode);
			} else {
				//cerco su SISTEMA REUTERS per INSTR.INSTRID sullo storico dei prezzi
				//  se sto trasferendo da un certo punto in poi, devo assicurarmi che la data
				//  in questione sia successiva a quella da cui voglio iniziare a scaricare altrimenti scarico senza problemi
				
				List<InfoProviderHispr> infoProvHistPricesList = infoProvHisprEAO.findByInstrIdAfterDate(infoProvInstr.getInstrId(),GenericTools.shortDateFormatAsLong(lastDate));
				
				if (infoProvHistPricesList.size()==0) {
					appIntLog.warn(instrNotInClearing);
					lastHPDate = (int) GenericTools.shortDateFormatAsLong(lastDate);
				} else {
				//carico tutte le date presenti sul calendario PAMP
					//List<Timestamp> calendDateList = calend.getListDate(marketCode);
							
					// ciclo su SISTEMA REUTERS		
					for (InfoProviderHispr infoProvHistPrice:infoProvHistPricesList) {
										
						if (infoProvHistPrice.getPk().getPriceDate() > lastHPDate) {
							lastHPDate = infoProvHistPrice.getPk().getPriceDate();
						}
						
						// verifico se la data appena convertita � presente sulla Lista
						//if (calendDateList.contains(GenericTools.convertDateFromIntToTimestamp(infoProvHistPrice.getPk().getPriceDate()))) {
							
							// controllo che la colonna del prezzo non sia vuota o di valore zero
							if (!(infoProvHistPrice.getClosePr()== null || infoProvHistPrice.getClosePr().doubleValue()<0.000001)) {
								hisPr.add(instrId, GenericTools.convertDateFromIntToTimestamp(infoProvHistPrice.getPk().getPriceDate()), infoProvHistPrice.getClosePr()/*.divide(new BigDecimal(100))*/, "E");
								appIntLog.info("Downloaded historical price for instrId "+instrId+" (Code: "+classCode+"); date: "+GenericTools.convertDateFromIntToString(infoProvHistPrice.getPk().getPriceDate())+"; price: "+infoProvHistPrice.getClosePr());
								updated++;
							}
							
							// il prezzo da scaricare � vuoto o zero - il sistema avvisa del problema e passa al record successivo senza scaricare il prezzo in questione
							else {
								appIntLog.warn(error+infoProvHistPrice.getPk().getPriceDate()+") with Null or 0 price");
								failed++;
							}
						total++;
						
						// la data non � presente sul calendario PAMP - il sistema avvisa della sua assenza e passa al record successivo
						/*} else {
							appIntLog.warn("Price date is not in PAMP calendar: "+infoProvHistPrice.getPk().getPriceDate()+" for instrument Id "+instrId+" ("+ricCode+")");
							failed++;
						}*/
					}
					//dateLMap.put(instrId, lastHPDate);
				}
			}
			setDateLMap(instrId,lastHPDate);
			setTotal(total.intValue());
			setUpdated(updated.intValue());
			setFailed(failed.intValue());
		
	}
	
	
	public String transferCashOekB(boolean delta) throws DataNotValidException {
		setTotal(0);
		setUpdated(0);
		setFailed(0);
		this.dateLMap.clear();
		/*
		 * instr.getCash() carica dalla tabella degli strumenti soltanto quelli che corrispondono su INTRACS a instrtype = 'C' 
		 * (applichiamo quindi una transcodifica per passare da PAMP.INSTRTYPE a INTRACS.INSTRTYPE)
		 */
		Instrument[] instrument = instr.getCash();
		
		String currentMarket = "";
		List<Timestamp> calendDateList = new ArrayList<Timestamp>();
		
		for (Instrument instr:instrument) {
			try {
				if (!currentMarket.equalsIgnoreCase(instr.getMarketCode())) {
					calendDateList = calend.getListDate(instr.getMarketCode());
					currentMarket = instr.getMarketCode();
				}
				transferCash(instr, delta, calendDateList, total, failed, updated);
			} catch (Exception e) {
				String error = "Error happened on INSTRID "+instr.getInstrId()+" (Code: "+instr.getClassCode()+")";
				appIntLog.error(error+"\n"+e.getMessage()+"\n"+e.getStackTrace().toString());
			}
		}
		
		total = failed + updated;
		
		String message = "Import of Eq. Cash historical price series completed";
		if (updated==0&&failed==0) {
			message+=" with no effects";
		}
		/*if (updated>0) {
			message += ": found "+instrument.length+" financial instruments, "+updated+"/"+total+" records successfully imported";
		}
		if (failed>0) {
			if (updated>0) {
				message += ", ";
			} else {
				message += ": found "+instrument.length+" financial instruments, ";
			}
			message += failed+" records have not been imported";
		}*/
		
		message += this.logMessage(updated);
		
		
		if (!checkMaxDate().equalsIgnoreCase("")) {
			appIntLog.warn(checkMaxDate());
			message += "\n\nNote: "+checkMaxDate();
		}
		
		
		return message;
	}
	
	
	public void transferCashOekB(Instrument instr, boolean delta, Integer total, Integer failed, Integer updated) throws DataNotValidException {
		int date;
    	int year; 
		int month;
		int day;
		
		int lastHPDate = 0;	
		GregorianCalendar cal = new GregorianCalendar(1900,0,1);
		Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
		int instrId = instr.getInstrId();
		if (delta) {
			/*prendo su HistoricalPrices la data pi� grande per quell'instrId*/ 
			HistoricalPrices[] historicalPrices = hisPr.findByInstrIdForDownload(instrId);
			if (historicalPrices.length>0) {
				lastDate = historicalPrices[0].getPk().getPricedate();
			}
		} else {
			hisPr.removeByInstrId(instrId);
		}
		
		/*recupero classCode e marketCode da instrument*/ 
		String cClass = instr.getClassCode();
		String marketCode = instr.getMarketCode();
		
		//predispngo stringhe di errore/warning
		String error = "Found INSTRID "+instrId+" (Code: "+cClass+", Date: ";
		String instrNotInClearing = "INSTRID "+instrId+" (Code: "+cClass+") - No new historical prices series avalaible in INFO system";
		
		//cerco su INTRACS per INSTR.CLASSCODE e CPTYPE = 'E'
		long cpsrss1Date =  (long) Integer.parseInt(lastDate.toString().substring(0,4)+lastDate.toString().substring(5,7)+lastDate.toString().substring(8,10));
		Cgcls00f[] cgcls00fsArr = intracsClassEAO.findOeKbCashByClassAndLastDate(cClass,cpsrss1Date);
		
		if (cgcls00fsArr.length==0) {
			appIntLog.warn(instrNotInClearing);
			lastHPDate = (int) cpsrss1Date;
		} else {
			//carico tutte le date presenti sul calendario PAMP
			List<Timestamp> calendDateList = calend.getListDate(marketCode);
					
			// ciclo su INSTRACS		
			for (Cgcls00f clearing:cgcls00fsArr) {
				/*Conversione date da long a timestamp della data presente su INTRACS*/
				date = (int) clearing.getCprcdt().longValue();
				if (date>lastHPDate) {
					lastHPDate = date;
				}
				year = Integer.parseInt(Integer.toString(date).substring(0,4));
				month = Integer.parseInt(Integer.toString(date).substring(4, 6))-1;
				day = Integer.parseInt(Integer.toString(date).substring(6, 8));
				Timestamp convertedDate = new Timestamp(new GregorianCalendar(year,month,day).getTimeInMillis());
				//TODO GenericTools.convertDateFromIntToTimestamp(date);
				
				// verifico se la data appena convertita � presente sulla Lista
				if (calendDateList.contains(convertedDate)) {
					
					// controllo che la colonna del prezzo non sia vuota o di valore zero
					if (!(clearing.getCuiclp()== null || clearing.getCuiclp().doubleValue()<0.000001)) {
						hisPr.add(instrId, convertedDate, clearing.getCuiclp(), "E");
						appIntLog.info("Downloaded historical price for instrId "+instrId+" (Code: "+cClass+"); date: "+convertedDate.toString().substring(0, 10)+"; price: "+clearing.getCuiclp());
						updated++;
					}
					
					// il prezzo da scaricare � vuoto o zero - il sistema avvisa del problema e passa al record successivo senza scaricare il prezzo in questione
					else {
						appIntLog.warn(error+convertedDate.toString().substring(0, 10)+") with Null or 0 value for Close Price");
						failed++;
					}
				total++;
				
				// la data non � presente sul calendario PAMP - il sistema avvisa della sua assenza e passa al record successivo
				} else {
					appIntLog.warn("Price date is not in PAMP calendar: "+convertedDate.toString().substring(0, 10)+" for instrument Id "+instrId+" ("+cClass+")");
					failed++;
				}
			}
			//dateLMap.put(instrId, lastHPDate);
		}
		setDateLMap(instrId,lastHPDate);
		setTotal(total.intValue());
		setUpdated(updated.intValue());
		setFailed(failed.intValue());
	}
	
	
	

	
	
	
	/*
	public int transfer(String divisCode, boolean delta,boolean foAsFutures) throws DataNotValidException {
		int counter=0;
		Instrument[] instrument = instr.getByDivisCode(divisCode);
		
		for (Instrument instr:instrument) {
			try {
				counter+=transfer(instr, delta, foAsFutures);
			} catch (Exception e) {
				String error = "Error happened on INSTRID "+instr.getInstrId()+" (Code: "+instr.getClassCode()+")";
				appIntLog.debug(error+"\n"+e.getMessage()+"\n"+e.getStackTrace());
			}
		}
		actlog.add("Historical Prices series updated for "+counter+" financial instruments");
		int failed = instrument.length-counter;
		String message = "Import finished: ";
		String message1 = "";
		String message2 = "";
		
		if (counter>0) {
			message1 += "updated "+counter+"/"+instrument.length+" financial instruments";
		}
		if (failed>0) {
			if (counter>0) {
				message2 += ",";
			} else {
				message2 += "operation";
			}
			message2 += " failed for "+failed+" financial instruments";
		}
		appIntLog.info(message+message1+message2);
		return counter;
	}
	
	public int transfer(Instrument instr, boolean delta, boolean foAsFutures) throws DataNotValidException {
		int counter=0;
		int date;
		int year; 
		int month;
		int day;
		GregorianCalendar cal;
		cal = new GregorianCalendar(1900,0,1);
		Timestamp lastDate = new Timestamp(cal.getTimeInMillis());
		int instrId = instr.getInstrId();
		if (delta) {
			prendo su HistoricalPrices la data pi� grande per quell'instrId 
			HistoricalPrices[] historicalPrices = hisPr.findByInstrId(instrId);
			if (historicalPrices.length>0) {
				lastDate = historicalPrices[0].getPk().getPricedate();
			}
		} else {
			hisPr.removeByInstrId(instrId);
		}
		
		recupero classCode e marketCode da instrument 
		boolean isCash = false;
		boolean isFuture = false;
		boolean isOption = false;
		
		String hSymbl = instr.getClassCode();
		String marketCode = instr.getMarketCode();
		String error = "Found INSTRID "+instrId+" (Code: "+hSymbl+", Date: ";
		String instrType = instr.getInstrType();
		
		if (instrType.equals("C")||instrType.equals("ETF"))	{
			instrType= "C";
			isCash = true;
		} else if (instrType.equals("F")) {
			instrType = "F";
			isFuture = true;
		} else if (instrType.equals("O")) {
			instrType = "O";
			isOption = true;
		} else if (instrType.equals("FO")) {
			if (foAsFutures) {
				instrType = "F";
			} else {
				instrType = "O";
			}
		}
		scarico la lista di cpsrss1
		Cpsrss1[] cpsrss1 = (Cpsrss1[]) cpsrss.findBySymbl(hSymbl,instrType);
		List<Timestamp> dates = calend.getListDate(marketCode);
		Timestamp convertedDate;
		Timestamp[] arrDates = new Timestamp[dates.size()];
		dates.toArray(arrDates);
		int failed = 0;
		BigDecimal zero = new BigDecimal(0);
		for (Cpsrss1 clearing:cpsrss1) {
			Conversione date da log a timestamp
			date = (int) clearing.getPk().getHDate();
			year = Integer.parseInt(Integer.toString(date).substring(0,4));
			month = Integer.parseInt(Integer.toString(date).substring(4, 6))-1;
			day = Integer.parseInt(Integer.toString(date).substring(6, 8));
			cal = new GregorianCalendar(year,month,day);
			convertedDate = new Timestamp(cal.getTimeInMillis());
			int expiry = (int) clearing.getPk().getHExpir();
			if (dates.contains(convertedDate)) {
				if (!(clearing.getHClose()== null || clearing.getHClose().doubleValue()<0.000001)) {
					if (delta) {
						if (convertedDate.after(lastDate)) {
							if (isCash) hisPr.add(instrId, convertedDate, clearing.getHClose(), "E");
							if (isFuture) derivativesHP.add(instrId, convertedDate,"F", zero, expiry, clearing.getHCusip(), "E", zero,clearing.getHClose());
							if (isOption) derivativesHP.add(instrId, convertedDate,"O", new BigDecimal(clearing.getPk().getHStrik()), expiry, clearing.getHCusip(), "E", clearing.getHImpvl().divide(new BigDecimal(100)),clearing.getHClose());
						}
					} else {
						if (isCash) hisPr.add(instrId, convertedDate, clearing.getHClose(), "E");
						if (isFuture) derivativesHP.add(instrId, convertedDate,"F", zero, expiry, clearing.getHCusip(), "E", zero,clearing.getHClose());
						if (isOption) derivativesHP.add(instrId, convertedDate,"O", new BigDecimal(clearing.getPk().getHStrik()), expiry, clearing.getHCusip(), "E", clearing.getHImpvl().divide(new BigDecimal(100)),clearing.getHClose());
					}
					counter++;
				} else {
					appIntLog.warn(error+clearing.getPk().getHDate()+") with Null or 0 value for Close Prices");
					failed++;
					//throw new NullData(error+cpsrss1[i].getPk().getHDate()+") with Null or 0 value for Close Prices");
				}
			}
			
		}
		int total = failed + counter;
		String message = "Import of Historical Prices series finished";
		String message1 = "";
		String message2 = "";
		if (counter==0&&failed==0) {
			message1 +=" with no financial instruments updated "; 
		} else {
			message1 += ": updated "+counter+"/"+total+" financial instruments";
		}
		if (failed>0) {
			if (counter>0) {
				message2 += ",";
			} else {
				message2 += ": operation";
			}
			message2 += " failed for "+failed+" financial instruments";
		}
		appIntLog.info(message+message1+message2);
		actlog.add(message+message1+message2);
		return counter;
	}
	*/
}
