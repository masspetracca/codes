package it.ccg.pamp.server.appint;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.utils.ReadyToExpInterClassOffsetHistory;

import java.util.Vector;

import javax.ejb.Local;

@Local
public interface TEOPLocal {
	public void readIntracs() throws DataNotValidException;
	public Vector<ReadyToExpInterClassOffsetHistory> getInterClassOffsetHistoryReadyToExp() throws DataNotValidException, InstrumentDataNotAvailableException;
	public void export() throws Exception;
}
