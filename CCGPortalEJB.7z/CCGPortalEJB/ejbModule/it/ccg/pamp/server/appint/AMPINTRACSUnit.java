package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.Cgcls00fEAOLocal;
import it.ccg.pamp.server.eao.Hfsrat2EAOLocal;
import it.ccg.pamp.server.eao.MarginExportLogEAOLocal;
import it.ccg.pamp.server.entities.Cgcls00f;
import it.ccg.pamp.server.entities.Hfsrat2;
import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.MarginHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.exceptions.LargeThresoldMarginException;
import it.ccg.pamp.server.exceptions.PropertyException;
import it.ccg.pamp.server.properties.PropertiesEAOLocal;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.InstrIdTrascodePlus;
import it.ccg.pamp.server.utils.NotSyncPampIntracs;
import it.ccg.pamp.server.utils.ReadyToExpMarginHistory;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class AMPUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class AMPINTRACSUnit implements  AMPINTRACSUnitLocal {

	@EJB
	private Cgcls00fEAOLocal cgcls00fEAO;
	@EJB
	private Hfsrat2EAOLocal hfsrat2EAO;
	
	@EJB
	private AMPPAMPUnitLocal amppamp;
	
	@EJB
	private PropertiesEAOLocal properties;
	
	@EJB
	private MarginExportLogEAOLocal marginExportLog;
	

	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void exportPampMarginHistoryToIntracs(Vector<ReadyToExpMarginHistory> readymarghistvec) throws DataNotValidException, InstrumentDataNotAvailableException, LargeThresoldMarginException {
		
		MathContext mc=new MathContext(8, RoundingMode.HALF_EVEN);
		
		//BigDecimal sysDate = 
		
		for (ReadyToExpMarginHistory readymarghist : readymarghistvec) {

			MarginHistory mHis = readymarghist.getMarhist();

			Instrument instr = readymarghist.getInstr();
			int instrId = instr.getInstrId();
			
			// Recupero la soglia massima di variazione del margine ammessa
			BigDecimal marTh = instr.getMarginTh();
			
			BigDecimal propMar = mHis.getMargin();
			BigDecimal propMinMar = mHis.getMinMargin();
			BigDecimal straddle = mHis.getStraddle();

			Vector<InstrIdTrascodePlus> instrIdTCplus = readymarghist.getInstrtcplusvec();

			for (InstrIdTrascodePlus instrTCplus : instrIdTCplus) {
				InstrIdTrascode instrTC = instrTCplus.getInstrTC();
				
				Cgcls00f cgc = cgcls00fEAO.findByPrimaryKey(instrTC.getPk().getSicInstr(), instrTC.getPk().getSicInstrTy());
				String classCode = instrTC.getPk().getSicInstr(); // instr.getClassCode();
				
				
				if (cgc != null) {
					BigDecimal oldMar = cgc.getCmrgni();
					String sicInstrType = instrTC.getPk().getSicInstrTy();
					BigDecimal marginCoef=instrTC.getMarCf();
					
					//BigDecimal roundedPropMar = PampRounder.round(propMar.multiply(marginCoef,mc), "N", roundDigit);
					BigDecimal roundedPropMar = propMar.multiply(marginCoef,mc);
					BigDecimal delta = this.getDelta(oldMar, roundedPropMar);

					// se il delta <= della soglia stabilita per quell' instrId
					// procedo all'update

					if (marTh==null || marTh.compareTo(delta)>=0) {
						
						appIntLog.info("Export margin values for instrId:" + instrId + " (classCode: " + classCode + " type: " + sicInstrType + ") - VALUES: Old margin: " + oldMar
								+ "; New margin: " + roundedPropMar);
						
						
						
						//cgc.setCmrgni(PampRounder.round(propMar.multiply(marginCoef), "N", setup.getMarRoundTv().divide(new BigDecimal(100))));
						cgc.setCmrgni(roundedPropMar);
						cgc.setCchgdt(new BigDecimal(GenericTools.systemDateLongFormat()));
						
						
						// se future (F) faccio anche l'update degli
						// straddle
						if (sicInstrType.equalsIgnoreCase("F")) {
							if (straddle != null) {
								
								BigDecimal straddleCoef=instrTC.getStraddleCf();
								
								
								Hfsrat2 hfsrat = hfsrat2EAO.findByFClass(classCode);
								if (hfsrat != null) {
									appIntLog.info("Export straddle values for instrId:" + instrId + " (classCode: " + classCode + " type: " + sicInstrType + ") - VALUES: Old straddle: "
											+ hfsrat.getFssprd() + "; New straddle: " + straddle);
									
									
									//BigDecimal straddleapprox=PampRounder.round(straddle.multiply(straddleCoef), "N", roundDigit);
									BigDecimal straddleapprox=straddle.multiply(straddleCoef,mc);
									hfsrat.setFssprd(straddleapprox);
									hfsrat.setFnsprd(straddleapprox);
									hfsrat.setFchgdt(new BigDecimal(GenericTools.systemDateLongFormat()));
								}
								else{
									//se non troviamo un corrispondente straddle all'interno di intracs dobbiamo stoppare l'intera procedura
									throw new InstrumentDataNotAvailableException(instrId,"No straddles available for this instrid on Clearing system table");
									
								}
								
							} else {
								appIntLog.warn("Straddle not available for instrId:" + instrId + " (classCode: " + classCode + " type: " + sicInstrType + ")");
							}
						}

						// se option (O) o future (F) faccio l'update di margine e margine
						// minimo
						if (sicInstrType.equalsIgnoreCase("O")||sicInstrType.equalsIgnoreCase("F")) {

							if (propMinMar != null) {
								
								BigDecimal minMarCoef= instrTC.getMinMarCf();

								appIntLog.info("Export minimum margin values for instrId:" + instrId + " (classCode: " + classCode + " type: " + sicInstrType
										+ ") - VALUES: Old minimum margin: " + cgc.getCminrt() + "; New minimum margin: " + propMinMar);

								
								//BigDecimal minmarapprox=PampRounder.round(propMinMar.multiply(minMarCoef), "N", roundDigit);
								BigDecimal minmarapprox=propMinMar.multiply(minMarCoef,mc);
								cgc.setCminrt(minmarapprox);
								cgc.setCchgdt(new BigDecimal(GenericTools.systemDateLongFormat()));

								this.writeUnderlayerMinMar(instrTCplus, mHis);
							} else {
								appIntLog.warn("Minimum margin not available for instrId:" + instrId + " (classCode: " + classCode + ")");
							}
						}

					} else {
						String deltaPerc = GenericTools.percentValue(delta, new MathContext(4));
						String marThPerc = GenericTools.percentValue(marTh, new MathContext(4));
						throw new LargeThresoldMarginException(instrId, classCode, instrTC.getPk().getSicInstrTy().trim(), oldMar, propMar, deltaPerc, marThPerc);
					}

				}

				else {

					throw new InstrumentDataNotAvailableException(instrTC.getPk().getInstrId(), "No margins available on the Clearing system for instrument Id: " + instrTC.getPk().getInstrId()
							+ " (classCode: " + instrTC.getPk().getSicInstr().trim() + " type: " + instrTC.getPk().getSicInstrTy().trim() + ")");

				}

			}

		}

		appIntLog.info(readymarghistvec.size() + " historical margins exported to Clearing system");

		amppamp.updateMarginHistorySentStatusAfterExport(readymarghistvec);

	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void exportOeKBPampMarginHistoryToRiskEngine(Vector<ReadyToExpMarginHistory> readymarghistvec) throws DataNotValidException, InstrumentDataNotAvailableException, LargeThresoldMarginException, PropertyException {
		
		BigDecimal sysDate = new BigDecimal(GenericTools.systemDateLongFormat());
		
		MathContext mc=new MathContext(8, RoundingMode.HALF_EVEN);
		
		for (ReadyToExpMarginHistory readymarghist : readymarghistvec) {

			MarginHistory mHis = readymarghist.getMarhist();

			Instrument instr = readymarghist.getInstr();
			int instrId = instr.getInstrId();
			
			// Recupero la soglia massima di variazione del margine ammessa
			BigDecimal marTh = instr.getMarginTh();
			
			BigDecimal propMar = mHis.getMargin();
			//BigDecimal propMinMar = mHis.getMinMargin();
			//BigDecimal straddle = mHis.getStraddle();

			Vector<InstrIdTrascodePlus> instrIdTCplus = readymarghist.getInstrtcplusvec();

			for (InstrIdTrascodePlus instrTCplus : instrIdTCplus) {
				InstrIdTrascode instrTC = instrTCplus.getInstrTC();
				
				//Cgcls00f cgc = cgcls00fEAO.getREInstrumentsForOeKBMarginExport(instrTC.getPk().getSicInstr(), instrTC.getPk().getSicInstrTy());
				
				// carico il record dalla tabella di destinazione
				Cgcls00f cgc = cgcls00fEAO.getREInstrumentsForOeKBMarginExport(instrTC.getPk().getSicInstr());
				
				String classCode = instrTC.getPk().getSicInstr();
				
				
				if (cgc != null) {
					
					BigDecimal oldMar = cgc.getCmrgni();
					String sicInstrType = instrTC.getPk().getSicInstrTy();
					BigDecimal marginCoef=instrTC.getMarCf();
					
					BigDecimal roundedPropMar = propMar.multiply(marginCoef,mc);
					BigDecimal delta = this.getDelta(oldMar, roundedPropMar);

					// se il delta <= della soglia stabilita per quell' instrId
					// procedo all'update

					if (marTh==null || marTh.compareTo(delta)>=0) {
						
						appIntLog.info("Export margin values for instrId:" + instrId + " (classCode: " + classCode + " type: " + sicInstrType + ") - VALUES: Old margin: " + oldMar + "; New margin: " + roundedPropMar);
						
						cgc.setCmrgni(roundedPropMar);
						cgc.setCchgdt(sysDate);
						// se future (F) faccio anche l'update degli
						// straddle
						/*if (sicInstrType.equalsIgnoreCase("F")) {
							if (straddle != null) {
								
								BigDecimal straddleCoef=instrTC.getStraddleCf();
								
								
								Hfsrat2 hfsrat = hfsrat2EAO.findByFClass(classCode);
								if (hfsrat != null) {
									appIntLog.info("Export straddle values for instrId:" + instrId + " (classCode: " + classCode + " type: " + sicInstrType + ") - VALUES: Old straddle: "
											+ hfsrat.getFssprd() + "; New straddle: " + straddle);
									
									
									//BigDecimal straddleapprox=PampRounder.round(straddle.multiply(straddleCoef), "N", roundDigit);
									BigDecimal straddleapprox=straddle.multiply(straddleCoef,mc);
									hfsrat.setFssprd(straddleapprox);
									hfsrat.setFnsprd(straddleapprox);
								}
								else{
									//se non troviamo un corrispondente straddle all'interno di intracs dobbiamo stoppare l'intera procedura
									throw new InstrumentDataNotAvailableException(instrId,"No straddles available for this instrid on Clearing system table");
									
								}
								
							} else {
								appIntLog.warn("Straddle not available for instrId:" + instrId + " (classCode: " + classCode + " type: " + sicInstrType + ")");
							}
						}

						// se option (O) o future (F) faccio l'update di margine e margine
						// minimo
						if (sicInstrType.equalsIgnoreCase("O")||sicInstrType.equalsIgnoreCase("F")) {

							if (propMinMar != null) {
								
								BigDecimal minMarCoef= instrTC.getMinMarCf();

								appIntLog.info("Export minimum margin values for instrId:" + instrId + " (classCode: " + classCode + " type: " + sicInstrType
										+ ") - VALUES: Old minimum margin: " + cgc.getCminrt() + "; New minimum margin: " + propMinMar);

								
								//BigDecimal minmarapprox=PampRounder.round(propMinMar.multiply(minMarCoef), "N", roundDigit);
								BigDecimal minmarapprox=propMinMar.multiply(minMarCoef,mc);
								cgc.setCminrt(minmarapprox);

								this.writeUnderlayerMinMar(instrTCplus, mHis);
							} else {
								appIntLog.warn("Minimum margin not available for instrId:" + instrId + " (classCode: " + classCode + ")");
							}
						}*/

					} else {
						String deltaPerc = GenericTools.percentValue(delta, new MathContext(4));
						String marThPerc = GenericTools.percentValue(marTh, new MathContext(4));
						throw new LargeThresoldMarginException(instrId, classCode, instrTC.getPk().getSicInstrTy().trim(), oldMar, propMar, deltaPerc, marThPerc);
					}

				}

				else {

					throw new InstrumentDataNotAvailableException(instrTC.getPk().getInstrId(), "No margins available on the Clearing system for instrument Id: " + instrTC.getPk().getInstrId()
							+ " (classCode: " + instrTC.getPk().getSicInstr().trim() + " type: " + instrTC.getPk().getSicInstrTy().trim() + ")");

				}

			}

		}

		appIntLog.info(readymarghistvec.size() + " historical margins exported to Clearing system");
		
		//loggare la fine del batch su Risk Engine
		//marginExportLog.upsert(new MarginExportLog("Y",GenericTools.systemDateLongFormat(),GenericTools.systemTime(),"",properties.getPropertyMap().get("defaultAS400User")));
		
		amppamp.updateMarginHistorySentStatusAfterExport(readymarghistvec);

	}
	
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * it.ccg.pamp.server.appint.prova#writeUnderlayerMinMar(it.ccg.pamp.server
	 * .utils.InstrIdTrascodePlus, it.ccg.pamp.server.entities.MarginHistory)
	 */

	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public void writeUnderlayerMinMar(InstrIdTrascodePlus instrTCplus, MarginHistory marHis) throws DataNotValidException, InstrumentDataNotAvailableException, LargeThresoldMarginException {
		BigDecimal sysDate = new BigDecimal(GenericTools.systemDateLongFormat());
		
		// prendo l'underlaying di quello strumento
		
		int undInstrId = instrTCplus.getUndInstrId();

		// MinimumMargin minMar = minMarEAO.findByPrimaryKey(optInstrId);

		// funzione per il calcolo del minMar per quel cash
		// BigDecimal cashMinMar = eqcalcEAO.getCashMinMargin(minMar,
		// instrEAO.findByPrimaryKey(instrId));
		BigDecimal cashMinMar = instrTCplus.getCashMinMar();// eqcalcEAO.getCashMinMarginFromMarginHistory(marHis,
															// instrEAO.findByPrimaryKey(optInstrId));

		if (cashMinMar != null) {

			// trascodifica per andare a leggere su SIC il derivato
			InstrIdTrascode[] instrIdTCUND = instrTCplus.getInstrIdTCUND();
			for (InstrIdTrascode instrTCUND : instrIdTCUND) {

				Cgcls00f cgc = cgcls00fEAO.findByPrimaryKey(instrTCUND.getPk().getSicInstr(), instrTCUND.getPk().getSicInstrTy());

				if (cgc != null) {

					appIntLog.info("Export min margin values for underlaying instrId:" + undInstrId + " (classCode: " + instrTCUND.getPk().getSicInstr().trim() + " type: "
							+ instrTCUND.getPk().getSicInstrTy().trim() + ") - VALUES: Old min margin: " + cgc.getCminrt() + "; New min margin: " + cashMinMar);
					cgc.setCminrt(cashMinMar);
					cgc.setCchgdt(sysDate);
				}
				else{
					//se non troviamo un corrispondente minmargin all'interno di intracs dobbiamo stoppare l'intera procedura
					throw new InstrumentDataNotAvailableException(undInstrId,"No straddles available for this underliying instrid on Clearing system table");
					
				}

			}
		} else {
			appIntLog.warn("Minimum margin not available for instrId:" + undInstrId +" please check the multiplier or the minimum margin of the historical margin on PAMP");
		}

	}

	@TransactionAttribute(TransactionAttributeType.NEVER)
	public BigDecimal getDelta(BigDecimal oldMargin, BigDecimal propMargin) {
		BigDecimal delta = (oldMargin.subtract(propMargin)).divide(oldMargin,8,RoundingMode.HALF_EVEN);
		return delta.abs();
		//return new BigDecimal(10000);
	}

	public Vector<NotSyncPampIntracs> checkPampMarginHistoryOnIntracs(Vector<ReadyToExpMarginHistory> readymarghistvec) throws DataNotValidException, InstrumentDataNotAvailableException{

		Vector<NotSyncPampIntracs> notSyncInstrVec = new Vector<NotSyncPampIntracs>();

		// scostamento massimo ammesso tra i valori su intracs e i valori su
		// pamp
		BigDecimal scostamentoMassimo = new BigDecimal(0.0001);

		for (ReadyToExpMarginHistory readymarghist : readymarghistvec) {

			MarginHistory mHis = readymarghist.getMarhist();

			//Instrument instr = readymarghist.getInstr();

			BigDecimal pampMar = mHis.getMargin();
			BigDecimal pampMinMar = mHis.getMinMargin();
			BigDecimal pampStraddle = mHis.getStraddle();

			Vector<InstrIdTrascodePlus> instrIdTCplus = readymarghist.getInstrtcplusvec();
			if (instrIdTCplus.isEmpty())
				notSyncInstrVec.add(new NotSyncPampIntracs(mHis, "No INTRACS margins for this PAMP MarginHistory"));

			for (InstrIdTrascodePlus instrTCplus : instrIdTCplus) {
				InstrIdTrascode instrTC = instrTCplus.getInstrTC();
				Cgcls00f cgc = cgcls00fEAO.findByPrimaryKey(instrTC.getPk().getSicInstr(), instrTC.getPk().getSicInstrTy());
				String classCode = instrTC.getPk().getSicInstr(); // instr.getClassCode();
				if (cgc != null) {

					BigDecimal intracsMargin = cgc.getCmrgni();
					BigDecimal intracsMinMargin = cgc.getCminrt();

					String sicInstrType = instrTC.getPk().getSicInstrTy();
					// double delta = getDelta(oldMar.doubleValue(),
					// propMar.doubleValue());

					// Prima di tutto a prescindere dal tipo si controlla il
					// margine
					if (pampMar.subtract(intracsMargin).abs().compareTo(scostamentoMassimo) == 1) {
						notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS margin: " + intracsMargin + " and PAMP margin:" + pampMar + " are different"));
						continue;

					}

					if (sicInstrType.equalsIgnoreCase("F")) {
						Hfsrat2 hfsrat = hfsrat2EAO.findByFClass(classCode);

						if (hfsrat == null) {
							if (pampStraddle != null) {
								notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS straddle null, PAMP straddle not null"));
								continue;
							}

						} else {
							if (pampStraddle == null) {
								notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS straddle not null, PAMP straddle null"));
								continue;
							} else if (pampStraddle.subtract(hfsrat.getFssprd()).abs().compareTo(scostamentoMassimo) == 1) {
								notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS straddle: " + hfsrat.getFssprd() + " and PAMP straddle: " + pampStraddle + " are different"));
								continue;
							}
						}

					}

					if (sicInstrType.equalsIgnoreCase("O")) {

						if (intracsMinMargin == null) {
							if (pampMinMar != null) {
								notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS minmargin null, PAMP minmargin not null"));
								continue;
							}

						} else {
							if (pampMinMar == null) {
								notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS minmargin not null, PAMP minmargin null"));
								continue;
							} else if (pampMinMar.subtract(intracsMinMargin).abs().compareTo(scostamentoMassimo) == 1) {
								notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "INTRACS minmargin: " + intracsMinMargin + " and PAMP minmargin: " + pampMinMar + " are different"));
								continue;
							}
						}

					}

				}

				else {

					notSyncInstrVec.add(new NotSyncPampIntracs(mHis, instrTC, "No INTRACS margins for this transcoded pamp instrument"));

				}

			}

		}

		appIntLog.info(notSyncInstrVec.size() + " Instruments not synchronized");
		return notSyncInstrVec;

	}

}
