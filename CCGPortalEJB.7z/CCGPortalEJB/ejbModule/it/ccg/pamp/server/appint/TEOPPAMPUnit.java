package it.ccg.pamp.server.appint;

import it.ccg.pamp.server.eao.InterClassOffsetHistoryEAOLocal;
import it.ccg.pamp.server.entities.InterclassOffsetHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.ReadyToExpInterClassOffsetHistory;

import java.util.Vector;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TEOPPAMPUnit
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class TEOPPAMPUnit implements  TEOPPAMPUnitLocal {

	@EJB
	private InterClassOffsetHistoryEAOLocal clTerHisEAO;
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");

        
	public void updateInterClassOffsetHistorySentStatusAfterExport(Vector<ReadyToExpInterClassOffsetHistory> readyInterClassOffsetHistVec) throws DataNotValidException {
		
		for (ReadyToExpInterClassOffsetHistory readyInterClassOffsetHist : readyInterClassOffsetHistVec) {

			
			  InterclassOffsetHistory clTerHist= clTerHisEAO.findByPrimaryKey(readyInterClassOffsetHist.getClTerHist().getPk().getClassId1(),readyInterClassOffsetHist.getClTerHist().getPk().getClassId2(),readyInterClassOffsetHist.getClTerHist().getPk().getIniVDate());
			  clTerHist.setSent("T");
			  clTerHist.setUpdDate(GenericTools.systemDate());
			  clTerHist.setUpdType("U"); 
			  clTerHist.setUpdUsr("System");
			  
			  clTerHisEAO.logUpdate(clTerHist);
			
		}
		appIntLog.info(readyInterClassOffsetHistVec.size() + " Bond interclass offset history sent status updated");
		

	}

}
