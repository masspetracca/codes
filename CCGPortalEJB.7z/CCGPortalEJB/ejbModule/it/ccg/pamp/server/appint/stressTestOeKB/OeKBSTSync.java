package it.ccg.pamp.server.appint.stressTestOeKB;

import it.ccg.pamp.server.eao.stressTestOeKB.OeKBReStResultEAOLocal;
import it.ccg.pamp.server.eao.stressTestOeKB.OeKBStressTestResultEAOLocal;
import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.entities.stressTestOeKB.OeKBStressTestResult;
import it.ccg.pamp.server.entities.stressTestOeKB.OeKBStressTestResultPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.NoPortfolioException;
import it.ccg.pamp.server.utils.OeKBReMembers;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class OeKBSTSync
 */
@Stateless
public class OeKBSTSync implements OeKBSTSyncLocal {

	@EJB
	private OeKBStressTestResultEAOLocal pampStressTestResultEAO;
	
	@EJB
	private OeKBReStResultEAOLocal reStressTestResultEAO;
	
	
	Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
	
	
	public void stressTestSync(String scenario, StressTest lastStressTest) throws DataNotValidException, NoPortfolioException {
		
		//cerco l'ultimo stress test scaricato per lo scenario in esame
		int lastStId = pampStressTestResultEAO.findLastStId(scenario);
		
		//se sto al primo stress test
		/*if (lastStId==0)
			lastStId = lastStressTest.getStId();*/
		
		List<OeKBReMembers> reStressTestResultList = new ArrayList<OeKBReMembers>();
		
		//if (lastStId > 0) {
		
			// cerco sulla tabella del risk engine tutti quelli maggiori di quello stress test Id
			reStressTestResultList = reStressTestResultEAO.findFromLastStressTestId(lastStId, scenario);
			
		//} else {
			
			//prende tutto
			//reStressTestResultList = reStressTestResultEAO.fetch();
			
		//}
		
		int count = 0;
		
		String strLog = "No new stress test records found on Risk Engine - last stId: "+lastStId;
		
		if (reStressTestResultList.size()>0) {
		
			//scarico
			
			for (OeKBReMembers oekbRes:reStressTestResultList) {
				
				if (oekbRes.getPfolioId()==null||oekbRes.getPfolioId().equalsIgnoreCase("")) {
					throw new NoPortfolioException("No member position found on risk engine");
				}
				
				OeKBStressTestResult pampStressTestRes = new OeKBStressTestResult();
				
				OeKBStressTestResultPK pK = new OeKBStressTestResultPK();
				
				pK.setScenario(oekbRes.getTipo());
				pK.setStId(oekbRes.getStId());
				pK.setUMbr(oekbRes.getUmbr().longValue());
				pK.setUAcCt(oekbRes.getUacCt());
				pK.setUSGrp(oekbRes.getUsGrp());
				pK.setUSubAc(oekbRes.getUsubAc());
				pK.setUGcm(oekbRes.getUgcm().longValue());
				
				
				pampStressTestRes.setPk(pK);
				
				pampStressTestRes.setPFolioId(oekbRes.getPfolioId());
				
				
				pampStressTestRes.setDataMrg(oekbRes.getDataMrg());
				pampStressTestRes.setTransId(oekbRes.getUtrnId());
				pampStressTestRes.setUMargin(oekbRes.getUreq());
				pampStressTestRes.setUmbrDesc(oekbRes.getMbrDesc());
				pampStressTestRes.setUgcmDesc(oekbRes.getUgcMbrDesc());
				pampStressTestRes.setSubAccDesc(oekbRes.getSubAccDesc());				
				
				pampStressTestResultEAO.store(pampStressTestRes);
				
				appIntLog.info("Stress test result for member "+oekbRes.getUmbr().longValue()+ " ("+oekbRes.getMbrDesc()+") synchronized on Pamp system");
				
				count++;
				
			}
			
			strLog = count + " stress test records found on Risk Engine and synchronized on Pamp System";
		}
		
		appIntLog.info(strLog);
		
	}
	
	
}
