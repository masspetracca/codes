package it.ccg.pamp.server.exceptions;

public class HeaderNotValidException extends Exception {

	private static final long serialVersionUID = 1L;

	public HeaderNotValidException(String fileName, String fileHeader, int headerSize) {
		super("No valid header found in "+fileName+" - Required header: ["+fileHeader+"] but only "+headerSize+" valid fields found. The procedure will be stopped and the file deleted");
	}

}
