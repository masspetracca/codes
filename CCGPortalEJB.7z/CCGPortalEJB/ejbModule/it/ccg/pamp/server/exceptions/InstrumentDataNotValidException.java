package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class InstrumentDataNotValidException extends Exception {


	private static final long serialVersionUID = 1L;

	public InstrumentDataNotValidException(int instrID, String message) {
		super("Data not valid for instrID: "+instrID+": "+message);
		
	}

	
	
}
