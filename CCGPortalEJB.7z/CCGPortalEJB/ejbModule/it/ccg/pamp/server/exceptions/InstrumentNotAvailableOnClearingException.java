package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback = true)
public class InstrumentNotAvailableOnClearingException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	public InstrumentNotAvailableOnClearingException(int instrId, String classCode, String instrType) {
		super(instrType+" instrument not available on Clearing system stressed price table - instrument Id: "+instrId+"; instrument code: "+classCode);
		
	}
	
}
