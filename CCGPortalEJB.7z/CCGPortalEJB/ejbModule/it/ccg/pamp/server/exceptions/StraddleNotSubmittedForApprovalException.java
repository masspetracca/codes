package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback = true)
public class StraddleNotSubmittedForApprovalException extends Exception {

	
	public StraddleNotSubmittedForApprovalException(int instrID){
		super("Straddle of the instrument: "+instrID+" is not submitted for approval");
		
	}

	
}
