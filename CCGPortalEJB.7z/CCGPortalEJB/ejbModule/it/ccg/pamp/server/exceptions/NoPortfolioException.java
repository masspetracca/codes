package it.ccg.pamp.server.exceptions;


public class NoPortfolioException extends Exception {

	public NoPortfolioException(String message)  {
		super("Data not available: "+message);
	}

}
