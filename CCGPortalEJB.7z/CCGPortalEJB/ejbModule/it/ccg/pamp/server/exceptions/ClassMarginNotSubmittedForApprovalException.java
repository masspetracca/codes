package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)

public class ClassMarginNotSubmittedForApprovalException extends Exception {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7084396255862085412L;

	public ClassMarginNotSubmittedForApprovalException(int classID){
		super("Class Margin for class: "+classID+" is not submitted for approval");
	}

}
