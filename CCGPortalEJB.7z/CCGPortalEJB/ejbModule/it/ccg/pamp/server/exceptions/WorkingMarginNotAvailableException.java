package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;


@ApplicationException(rollback=true)

public class WorkingMarginNotAvailableException extends Exception {

	private static final long serialVersionUID = 2089674892072829688L;

	public WorkingMarginNotAvailableException(int instrID) {
		super("Working margin not available for InstrID: "+instrID+": Please change the propose field to Change");
	}

	public WorkingMarginNotAvailableException(int instrID, String type) {
		super("Working "+type+" not available for InstrID: "+instrID+": Please change the propose field to Change");
	}
	
	
	public WorkingMarginNotAvailableException(String idtype,int id, String type) {
		super("Working "+type+" not available for InstrID: "+id+": Please change the propose field to Change");
	}
	
	
	public WorkingMarginNotAvailableException(int id1,int id2) {
		super("Working Interclass not available for classID1: "+id1+" and classID2: "+id2+". Please change the propose field to Change");
	}
}