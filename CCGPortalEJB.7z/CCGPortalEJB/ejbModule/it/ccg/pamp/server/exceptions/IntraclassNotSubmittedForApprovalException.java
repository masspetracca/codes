package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)

public class IntraclassNotSubmittedForApprovalException extends Exception{

	
	public IntraclassNotSubmittedForApprovalException(int classID){
		super("Intraclass offset for the class: "+classID+" is not submitted for approval");
		
		
	}
}
