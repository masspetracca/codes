package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback = true)
public class NullData extends Exception {
 
	private static final long serialVersionUID = 1L;
	String errorMessage; 
	public NullData() {
		super();
		errorMessage = "NullDataException";
	}
	
	public NullData(String msg) {
		super(msg);
		errorMessage = msg;
	}
	
	public String toString() {
		return errorMessage;
	}
}
