package it.ccg.pamp.server.exceptions;

import it.ccg.pamp.server.entities.Instrument;

import javax.ejb.ApplicationException;

@ApplicationException(rollback = true)
public class BigDecimalException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4049860721230529923L;

	public BigDecimalException(Instrument instr, int nv, int periodo, String funzione, Exception e, String note) {

		super("INSTRID " + instr.getInstrId() + ": Error calculating the " + funzione + " for holding period " + nv + " and period " + periodo + " (" + note + ") " + " ---> " + e.getMessage());

	}

	public BigDecimalException(Instrument instr, String funzione, Exception e, String note) {

		super("INSTRID " + instr.getInstrId() + ": Error calculating the " + funzione + " (" + note + ") " + " ---> " + e.getMessage());

	}

	public BigDecimalException(Instrument instr, String funzione, String note) {

		super("INSTRID " + instr.getInstrId() + ": Error calculating the " + funzione + " (" + note + ")");

	}

	public BigDecimalException(Instrument instr1, Instrument instr2, String funzione, String note) {

		super("Instrument couple: " + instr1.getInstrId() + " - " + instr2.getInstrId() + ": Error calculating the " + funzione + " (" + note + ")");

	}

	public BigDecimalException(Instrument instr1, Instrument instr2, int nv, int periodo, String funzione, Exception e, String note) {

		super("Instrument couple: " + instr1.getInstrId() + " - " + instr2.getInstrId() + ": Error calculating the " + funzione + " for holding period " + nv + " and period " + periodo + " (" + note + ") " + " ---> " + e.getMessage());

	}

}
