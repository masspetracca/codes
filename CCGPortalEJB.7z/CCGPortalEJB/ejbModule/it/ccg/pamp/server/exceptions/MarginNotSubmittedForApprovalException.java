package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class MarginNotSubmittedForApprovalException extends Exception{

	
	public MarginNotSubmittedForApprovalException(int instrID){
		super("Margin of the instrument: "+instrID+" is not submitted for approval");
	}
	
	
	public MarginNotSubmittedForApprovalException(int instrID, int month){
		super("Electric Margin of the instrument: "+instrID+" and month "+month+" is not submitted for approval");
	}
	
}
