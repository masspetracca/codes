package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

import it.ccg.pamp.server.entities.Group;


@ApplicationException(rollback=true)
public class GroupNotSubmittedForApprovalException extends Exception {

	
	
	
	public GroupNotSubmittedForApprovalException(Group gr){
		super("Group "+gr.getGrName()+" (grID: "+gr.getGrId()+") is not submitted for approval");

	}

	

}
