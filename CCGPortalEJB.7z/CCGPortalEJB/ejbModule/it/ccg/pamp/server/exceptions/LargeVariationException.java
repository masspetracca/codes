package it.ccg.pamp.server.exceptions;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.ejb.ApplicationException;
@ApplicationException(rollback = true)
public class LargeVariationException extends Exception {



	public LargeVariationException(int instrID,int nv, Timestamp currdate, BigDecimal currprice, Timestamp precdate, BigDecimal precprice ) {
		super("Variation too large (suspected invalid price) for instrID "+instrID+" and holding period "+nv+" - "+"Days involved: "+currdate+" (Close price "+currprice+") and "+precdate+" (Close price "+precprice+")");
		
	}

	

}