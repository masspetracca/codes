package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class FileFormatNotSupportedException extends Exception {

	private static final long serialVersionUID = 1L;

	public FileFormatNotSupportedException(String format) {
		super("File format: "+format+" not supported: the procedure will be stopped and the file deleted");
		
	}


}
