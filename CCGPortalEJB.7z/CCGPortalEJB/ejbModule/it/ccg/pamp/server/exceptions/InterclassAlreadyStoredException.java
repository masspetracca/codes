package it.ccg.pamp.server.exceptions;

import java.sql.Timestamp;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class InterclassAlreadyStoredException extends Exception{


	/**
	 * 
	 */
	private static final long serialVersionUID = -6077977414676085286L;

	public InterclassAlreadyStoredException(int classID1,int classID2, Timestamp inivdate) {
		super("An Interclass history for the class couple: "+classID1+" - "+ classID2+" with inivdate: "+inivdate+" has been already stored. Probably a submitted margin parameter has a wrong initial validity date.");
		
		
	}
}
