package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;


@ApplicationException(rollback=true)

public class InstrumentDataNotAvailableException extends Exception {



	public InstrumentDataNotAvailableException(int instrID,String message) {
		super("Data not available for instrID "+instrID+": "+message);
	}

	public InstrumentDataNotAvailableException(int instrID,String message, boolean isClass) {
		super("Data not available for ClassID "+instrID+": "+message);
	}

}
