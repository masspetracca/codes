package it.ccg.pamp.server.exceptions;

import it.ccg.pamp.server.utils.TruncateBigDecimal;



import java.math.BigDecimal;

import javax.ejb.ApplicationException;

@ApplicationException(rollback = true)
public class LargeThresoldMarginException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public LargeThresoldMarginException(int instrId,String classCode,String instrType, BigDecimal oldMargin, BigDecimal propMargin, String deltaPerc, String marThPerc) {
		
		super("Exceeded margin threshold between old and proposed margin - instrId: "+instrId+" (classCode: "+classCode+", instrType: "+instrType+") - VALUES: Old margin: "+new TruncateBigDecimal(oldMargin).getNewMargin()+"; New margin: "+new TruncateBigDecimal(propMargin).getNewMargin()+"; delta: "+deltaPerc+"; Maximum tolerance: "+marThPerc);
				
	}
	
	public LargeThresoldMarginException(int classId,String classDesc, BigDecimal oldMargin, BigDecimal propMargin, String deltaPerc, String marThPerc) {
		
		super("too large threshold between old and proposed class margin - classId: "+classId+" (classDesc: "+classDesc+") - VALUES: Old class margin: "+new TruncateBigDecimal(oldMargin).getNewMargin()+"; New class margin: "+new TruncateBigDecimal(propMargin).getNewMargin()+"; delta: "+deltaPerc+"; Maximum tolerance: "+marThPerc);
				
	}
	
	public LargeThresoldMarginException(int classId,String classDesc, BigDecimal oldOffset, BigDecimal propOffset, String deltaPerc, String marThPerc, String offset) {
		
		super("Exceeded margin threshold between old and proposed bond class margin - classId: "+classId+" (classDesc: "+classDesc+") - VALUES: Old class margin: "+new TruncateBigDecimal(oldOffset).getNewMargin()+"; New class margin: "+new TruncateBigDecimal(propOffset).getNewMargin()+"; delta: "+deltaPerc+"; Maximum tolerance: "+marThPerc);
				
	}
	
}
