package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback = true)
public class BondClassDataNotAvailableException extends Exception{

	private static final long serialVersionUID = -2736963600842793601L;

		public BondClassDataNotAvailableException(int classID, String message) {
			super("Data not available for classID " + classID + ": " + message);

		}
		
		public BondClassDataNotAvailableException(int classID1, int classID2, String message) {
			super("Data not available for classID1 " + classID1 + ", classID2 " + classID2 +": " + message);

		}

	
}
