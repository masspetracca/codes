package it.ccg.pamp.server.exceptions;

public class KeyNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public KeyNotFoundException(String fileName, String keyArray) {
		super("No valid key found in "+fileName+" - allowed keys: ["+keyArray+"]. The procedure will be stopped and the file deleted");
	}

}
