package it.ccg.pamp.server.exceptions;

import java.sql.Timestamp;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class IntraclassAlreadyStoredException extends Exception{


	/**
	 * 
	 */
	private static final long serialVersionUID = -6077977414676085286L;

	public IntraclassAlreadyStoredException(int classID, Timestamp inivdate) {
		super("An Intraclass history for the class: "+classID+" with inivdate: "+inivdate+" has been already stored. Probably a submitted margin parameter has a wrong initial validity date.");
		
		
	}
}