package it.ccg.pamp.server.exceptions;

import java.sql.Timestamp;

import javax.ejb.ApplicationException;


@ApplicationException(rollback=true)


public class GroupHistoryAlreadyStored extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7452986255320255476L;

	public GroupHistoryAlreadyStored(int groupID, Timestamp inivdate){
		
		super("A Group history for the group: "+groupID+" with inivdate: "+inivdate+" has been already stored. Probably a submitted margin parameter has a wrong initial validity date.");
		
		
	}

}
