package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)

public class InterclassNotSubmittedForApprovalException extends Exception{

	private static final long serialVersionUID = -2330914325940451784L;

	public InterclassNotSubmittedForApprovalException(int classID1, int classID2){
		super("Interclass offset for the class couple: "+classID1+" - "+classID2+" is not submitted for approval");
		
		
	}
}
