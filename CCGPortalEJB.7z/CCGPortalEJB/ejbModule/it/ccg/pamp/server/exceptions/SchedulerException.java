package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback = true)
public class SchedulerException extends Exception {
	public SchedulerException(String message) {
		super(message+" already started");
		
	}
	
}
