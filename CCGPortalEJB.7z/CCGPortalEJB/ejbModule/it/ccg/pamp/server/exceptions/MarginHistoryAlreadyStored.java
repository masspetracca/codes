package it.ccg.pamp.server.exceptions;

import java.sql.Timestamp;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class MarginHistoryAlreadyStored extends Exception{

	
	public MarginHistoryAlreadyStored(int instrID, Timestamp inivdate){
		super("A Margin history for the instrument: "+instrID+" with inivdate: "+inivdate+" has been already stored. Probably a submitted margin parameter has a wrong initial validity date.");
	}
	
	
	public MarginHistoryAlreadyStored(int instrID,int month, Timestamp inivdate){
		super("An ElectricMargin history for the instrument: "+instrID+" and month "+month+" with inivdate: "+inivdate+" has been already stored. Probably a submitted electric margin parameter has a wrong initial validity date. ");
	}
}
