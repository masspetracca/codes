package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback = true)
public class MathException extends Exception {


	private static final long serialVersionUID = 1L;

	public MathException(org.apache.commons.math.MathException exc) {
		super(exc.getMessage());
		this.setStackTrace(exc.getStackTrace());
	}

}
