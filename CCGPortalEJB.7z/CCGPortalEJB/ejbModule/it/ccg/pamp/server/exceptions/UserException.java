package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class UserException extends Exception {

	public UserException(String message) {
		super(message);
		
	}

}
