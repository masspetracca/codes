package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)


public class StatisticException  extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2927856302909333918L;

	public StatisticException(String message) {
		super(message);
		}

	
	
	
	
	
}
