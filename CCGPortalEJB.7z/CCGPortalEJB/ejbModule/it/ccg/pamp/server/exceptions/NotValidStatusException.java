package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;


@ApplicationException(rollback=true)

public class NotValidStatusException extends Exception {

	

	
	public NotValidStatusException(int instrid, String wrongParam, String status, String note) {
		
		super("INSTRID "+instrid+": "+wrongParam+" status ("+status+") not valid the procedure will be aborted --> "+note);
		
	}
	
	public NotValidStatusException(int instrid, String wrongParam, String status) {
		
		super("INSTRID "+instrid+": "+wrongParam+" status ("+status+") not valid the procedure will be aborted ");
		
	}
	
	public NotValidStatusException(int instrid, String wrongParam, String status, boolean isClass) {
		
		super("CLASSID "+instrid+": "+wrongParam+" status ("+status+") not valid the procedure will be aborted ");
		
	}

}
