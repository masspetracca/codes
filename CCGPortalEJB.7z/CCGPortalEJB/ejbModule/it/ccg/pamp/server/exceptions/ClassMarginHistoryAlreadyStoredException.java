package it.ccg.pamp.server.exceptions;

import java.sql.Timestamp;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class ClassMarginHistoryAlreadyStoredException extends Exception {

	

	private static final long serialVersionUID = -9219301461244694846L;

	public ClassMarginHistoryAlreadyStoredException(int classID, Timestamp inivdate){
		super("A Class Margin history for the class: "+classID+" with inivdate: "+inivdate+" has been already stored. Probably a submitted class margin parameter has a wrong initial validity date.");
		
	}


}
