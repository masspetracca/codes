package it.ccg.pamp.server.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback = true)
public class RemoveFailedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RemoveFailedException(String message) {
		super(message);
	}


}
