package it.ccg.pamp.server.loggers;

public class ApplicationInterfaceLogger {

}
