package it.ccg.pamp.server.loggers;

import javax.ejb.Stateless;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

import org.apache.log4j.Logger;

@Stateless
public class TechLoggerInterceptor {
	@AroundInvoke
	public Object log(InvocationContext ctx) throws Exception {
		long start = System.currentTimeMillis();
		String methodName = ctx.getMethod().getName();
		String className = ctx.getTarget().getClass().toString();
		String param=" - Parameters: ";
		if (ctx.getParameters().length> 0) {
			for (Object params: ctx.getParameters()) {
				param += params+", ";
			}
			if (param == null)
				ctx.setParameters(new String[] { "default" });
		}
		try {
			return ctx.proceed();
		} catch (Exception e) {
			throw e;
		} finally {
			long time = System.currentTimeMillis() - start;
			Logger techLog = Logger.getLogger("it.ccg.pamp.server.log.TechLog");
			// non stampa se � un EAO
			techLog.debug("Invocation of method "+className.substring(6) +"."+ methodName + " took " + time + "ms"+param.substring(0, param.length()-2));
		}
	}

}