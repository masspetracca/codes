package it.ccg.pamp.server.schedulers;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.SchedulerException;

import java.util.Vector;

import javax.ejb.Local;
import javax.ejb.Timer;

@Local
public interface SchedulerBeanLocal {
	
	public void metodoTimeout(Timer timer);
	
	public void stop(String prcName) throws DataNotValidException;
	
	public void stop() throws DataNotValidException;
	
	public void start() throws DataNotValidException, SchedulerException;
	
	public void start(String prcName) throws DataNotValidException, SchedulerException;
	
	public void refreshAll() throws DataNotValidException;
	
	public String getActiveTimer() throws DataNotValidException;
	
	public Vector<Integer> getEnqueuedMessages() throws DataNotValidException;
	 
   	public abstract void launchBatch(int batchId, String user) throws DataNotValidException;

	public abstract void launchMultiBatch(Vector<Integer> schedVec, String user) throws DataNotValidException;

	public abstract void stopWithoutUPD(String prcName) throws DataNotValidException;
    
}
