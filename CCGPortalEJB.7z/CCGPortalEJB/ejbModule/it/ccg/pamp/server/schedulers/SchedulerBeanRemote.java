package it.ccg.pamp.server.schedulers;

import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Remote;

@Remote
public interface SchedulerBeanRemote {
	
	public void stop(String prcName) throws DataNotValidException;
	public void stop() throws DataNotValidException;
	/*public void start() throws DataNotValidException, SchedulerException;
	public void start(String prcName) throws DataNotValidException, SchedulerException;*/
	
	public String getActiveTimer() throws DataNotValidException;
	
}

