package it.ccg.pamp.server.schedulers;

import it.ccg.pamp.server.eao.CalendarEAOLocal;
import it.ccg.pamp.server.eao.SchedulerEAOLocal;
import it.ccg.pamp.server.entities.Scheduler;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.SchedulerException;
import it.ccg.pamp.server.utils.GenericTools;

import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSSecurityException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.InitialContext;

import org.apache.log4j.Logger;


/**
 * Session Bean implementation class SchedulerBean
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class SchedulerBean implements  SchedulerBeanLocal, SchedulerBeanRemote {
	
	@EJB private SchedulerEAOLocal schedulerEAO;
	@EJB private CalendarEAOLocal calend;
	
	private Connection connection;
	
	private Session session;
	
	@Resource
    private ConnectionFactory connectionFactory;
	
	@Resource
    private Destination destination;
		
	@Resource TimerService timerservice;
	@Resource SessionContext ctx;
	 
	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	@Timeout
    public void metodoTimeout(Timer timer) {

    	userLog.info("Started schedule "+timer.getInfo().toString());
    	
    	String prcName = timer.getInfo().toString();
    	
    	try {
    		Scheduler sched = schedulerEAO.findByPrcName(timer.getInfo().toString());
    		//se non esiste pi� sul DB il timer viene stoppato
    		if (sched==null) {
    			stopWithoutUPD(timer.getInfo().toString());
    			userLog.error("Schedule "+timer.getInfo().toString()+" not on DB");
    			return;
    		}
    		
    		//verifica su calendar se OGGI � una data di mercato
    		if (sched.getAtMktDate().equalsIgnoreCase("F")||(sched.getAtMktDate().equalsIgnoreCase("T")&& calend.isMarketDate())) {
    			
    			//Esco in caso la schedulazione sia mensile ma questo non sia il giorno giusto per l'esecuzione
    			int fixedDateDay = Integer.parseInt(sched.getFixedTime().toString().substring(8, 10));
    			int systemDateDay = Integer.parseInt(GenericTools.systemDate().toString().substring(8,10));
    			
    			
    			
    			if (sched.getFrequency().equalsIgnoreCase("M") && !(fixedDateDay==systemDateDay)) {
    				return; 
    			}
    			
    			//recupero l'identit� di chi ha settato lo scheduler o lo ha modificato per ultimo
    			String user=sched.getUpdUsr();
    			
    			//eseguo la procedura 			
    			launchBatch(sched.getBatchId(), user);

    			
    			//Se la frquenza � One SHOT disabilito lo scheduler altrimenti lo abilito
    			if (sched.getFrequency().equalsIgnoreCase("O")) {
    				schedulerEAO.disableScheduler(sched.getPrcId());
    			} else {
    				schedulerEAO.enableScheduler(sched.getPrcId());
    			}
    		}
    		
    		// se � diverso da null significa che l'ora � cambiata o deve cambiare
    		if (GenericTools.delayRestartAfterOrBeforeChangingTime(0)!=null) {
    			
    			this.stop(prcName);
    			
    			int hours = 24;
    			
    			// verifico se � il giorno prima del cambio dell'ora (SABATO)
    			if (GenericTools.delayRestartAfterOrBeforeChangingTime(0)!=0) {
    				// devo stoppare lo scheduler � startarlo con incremento di GenericTools.delayRestartAfterOrBeforeChangingTime(0) ore invece che 24
    				
    				hours += GenericTools.delayRestartAfterOrBeforeChangingTime(0);
    				
    			}
    		
    			/*// se invece � il giorno del CAMBIO (DOMENICA)
    			else if (GenericTools.delayRestartAfterOrBeforeChangingTime(1)==0) {
    				// devo stoppare lo scheduler � startarlo con normale incremento a 24
    				hours += GenericTools.delayRestartAfterOrBeforeChangingTime(0);
    			}*/
    			
    			this.start(prcName, 24+hours);
    		}
    		
    	} catch (Exception e) {
    		try {
    			stopWithoutUPD(timer.getInfo().toString());
    		} catch (Exception exc) {
    			userLog.error("Error while stopping "+timer.getInfo().toString()+" procedure - "+exc.getMessage());
    		}
    	}
    }
	
	public void stop(String prcName) throws DataNotValidException {
    	for (Object obj : timerservice.getTimers()) {
    		Timer timer = (Timer) obj;
    		String scheduled = (String) timer.getInfo();
    		userLog.info("timer to stop: "+timer.getInfo());
    		if (scheduled.equals(prcName)) {
    			timer.cancel();
    			int prcId = schedulerEAO.findByPrcName(prcName).getPrcId();
    			schedulerEAO.disableScheduler(prcId);
    			userLog.info("procedure "+scheduled+" stopped");
    		}
    	}
    }
	
	@Override
	public void stopWithoutUPD(String prcName) throws DataNotValidException {
    	for (Object obj : timerservice.getTimers()) {
    		Timer timer = (Timer) obj;
    		String scheduled = (String) timer.getInfo();
    		userLog.info("timer to stop: "+timer.getInfo());
    		if (scheduled.equals(prcName)) {
    			timer.cancel();
    			int prcId = schedulerEAO.findByPrcName(prcName).getPrcId();
    			schedulerEAO.disableSchedulerWithoutUPD(prcId);
    			userLog.info("procedure "+scheduled+" stopped");
    		}
    	}
    }
    
    public void stop() throws DataNotValidException {
    	for (Object obj : timerservice.getTimers()) {
    		Timer timer = (Timer) obj;
    		String timerName = (String) timer.getInfo();
    		timer.cancel();
    		userLog.info("procedure "+timerName+" stopped");
    		
    	}
    	schedulerEAO.disableAll();
    }
    
    
    
    public void start() throws DataNotValidException, SchedulerException {
    	Scheduler[] disabledScheduler = schedulerEAO.getDisabledSchedulers();
    	for (Scheduler sched:disabledScheduler) {
    		start(sched.getPrcName());
    	}
    }
    
    
    public void start(String prcName) throws DataNotValidException, SchedulerException {
    	
    	Scheduler sched = schedulerEAO.findByPrcName(prcName);
    	//se la tabella degli scheduler non � vuota
    	if (sched!=null) {
    		    		    		    		
    		Date initialExpiration = new Date();
    		//verifico se il timer da lanciare � gi� attivo
			for (Object obj : timerservice.getTimers()) {
	    		Timer timer = (Timer) obj;
	    		String scheduled = (String) timer.getInfo();
	    		if (scheduled.equalsIgnoreCase(prcName)) {
	    			throw new SchedulerException(prcName);
	    		}
	    	}
    		
			schedulerEAO.update(sched.getPrcId());
			
			initialExpiration= new Date(sched.getFixedTime().getTime());
			
			if(sched.getFrequency().equals("M")||sched.getFrequency().equals("D")) {
				//giornaliera o mensile
				timerservice.createTimer(initialExpiration,60000*60*24,sched.getPrcName());
				
			} else {
				
				//se � one shot
				timerservice.createTimer(initialExpiration,sched.getPrcName());
				//timerservice.createTimer(initialExpiration,6000*2,sched.getPrcName());
				
			}
		}
    }
    
    public void start(String prcName, int hours) throws DataNotValidException, SchedulerException {
    	
    	Scheduler sched = schedulerEAO.findByPrcName(prcName);
    	//se la tabella degli scheduler non � vuota
    	if (sched!=null) {
    		    		    		    		
    		Date initialExpiration = new Date();
    		//verifico se il timer da lanciare � gi� attivo
			for (Object obj : timerservice.getTimers()) {
	    		Timer timer = (Timer) obj;
	    		String scheduled = (String) timer.getInfo();
	    		if (scheduled.equalsIgnoreCase(prcName)) {
	    			throw new SchedulerException(prcName);
	    		}
	    	}
    		
			schedulerEAO.update(sched.getPrcId());
			
			initialExpiration= new Date(sched.getFixedTime().getTime());
			
			if(sched.getFrequency().equals("M")||sched.getFrequency().equals("D")) {
				//giornaliera o mensile
				timerservice.createTimer(initialExpiration,60000*60*hours,sched.getPrcName());
				
			} else {
				
				//se � one shot
				timerservice.createTimer(initialExpiration,sched.getPrcName());
				//timerservice.createTimer(initialExpiration,6000*2,sched.getPrcName());
				
			}
		}
    }
     
    @Override
	public void launchBatch(int batchId, String user) throws DataNotValidException {

    	String batch = Integer.toString(batchId);
    
    	
    	userLog.info("System is enqueuing the batch "+batchId);
    	
    	
    	MessageProducer producer = null;
        TextMessage txtMsg = null;
         
		try {
			producer = session.createProducer(destination);
			
			txtMsg = session.createTextMessage(); 
			txtMsg.setText(batch);
			
			
			txtMsg.setStringProperty("user", user);
			
			
			producer.send(txtMsg); 
			userLog.info("System enqueued the batch "+batchId+" scheduled by "+user);

		
			schedulerEAO.updateSchedulerExecution(batchId);
			
		} catch (Exception e) {
			throw new DataNotValidException(e.getMessage());
		}
    }
    
    
    @Override
	public void launchMultiBatch(Vector<Integer> schedVec, String user) throws DataNotValidException {
    	
    	for(Integer batchId:schedVec){
    		this.launchBatch(batchId,user);
    	}
    }
    
    public Vector<Integer> getEnqueuedMessages() throws DataNotValidException {
    	Vector<Integer> queueMessages =new Vector<Integer>();
    	
    	QueueConnectionFactory qcf = null;
    	QueueConnection  connection = null;
    	Queue queue=null;
    	InitialContext initC;
    	try {
    		initC = new InitialContext();
	    	qcf = (QueueConnectionFactory) initC.lookup("jms/MDBStarterCF");
	    	queue = (Queue) initC.lookup("jms/MDBStarter");
    	} catch (Exception e) {
    		userLog.error("Error getting JMS context - " +e.getMessage());
    	} 
    	
    	String userString = "System";
    	if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			userString = ctx.getCallerPrincipal().getName().toString();
    	} 
		try {
			
			connection = qcf.createQueueConnection(); 
			QueueSession session = connection.createQueueSession(false,Session.AUTO_ACKNOWLEDGE); 
			
		    QueueBrowser queueBrowser = session.createBrowser(queue);
		                                                                          
		    // start the connection
		    connection.start();
		                                                                          
		    // browse the messages
		    Enumeration e = queueBrowser.getEnumeration();
		    		                                                                          
		    // count number of messages
		    while (e.hasMoreElements()) {
		    	Message message = (Message) e.nextElement();
		    	
		    	if (!(message instanceof TextMessage)) {
		    		continue;
	    		} 
		    	
		    	TextMessage textMessage = (TextMessage) message;

		    	queueMessages.add(Integer.parseInt(textMessage.getText()));
		    }
		    
		                              
		    // close the queue connection
			session.close();
			connection.close();
			
			return queueMessages;
		} catch (Exception e) {
			//e.printStackTrace();
			throw new DataNotValidException(e.getMessage());
		}
    }
    
    public void refreshAll() throws DataNotValidException {
    	//setto tutti gli scheduler su disabilitato
    	try {
    		schedulerEAO.disableAllWithoutUPD();
    	} catch (Exception e) {
    		userLog.error("unable to disable schedulers");
    	}
    	
    	//riattivo solo gli scheduler corrispondenti ad un timer attivo
    	for (Object obj : timerservice.getTimers()) {
			Timer timer = (Timer) obj;
    		String activeTimer = (String) timer.getInfo();
    		//userLog.info("refreshing "+activeTimer);
    		Scheduler sched = schedulerEAO.findByPrcName(activeTimer);
    		//se esiste uno scheduler su DB con quel nome allora lo aggiorno
    		if (sched!=null) {
    			schedulerEAO.enableSchedulerWithoutUPD(sched.getPrcId());
    			
    		} else {
	    		stopWithoutUPD(activeTimer);
    		}
    		/*for (int i=0;i<10000;i++) {
        		if (i==9999) {
        			userLog.info(activeTimer +" enabled: "+sched.getEnabled());
        		}
        	}*/
    	}
    	
	}
        
    public String getActiveTimer() throws DataNotValidException {
	    String activeT = "";
		int counter = 0;
	    for (Object obj : timerservice.getTimers()) {
			Timer timer = (Timer) obj;
			activeT += (String) timer.getInfo()+", ";
			counter++;
		}
	    if (counter==0) {
	    	activeT = "No schedule enabled";
	    }
		return activeT;
    }
    
    /**
     * Creates the connection.
     */
    @PostConstruct
    public void makeConnection() {
        try {
            connection = connectionFactory.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        } catch(JMSSecurityException jmse){
        	jmse.printStackTrace();
        } catch (Throwable t) {
        	userLog.error("TimerBean.makeConnection: Exception: " + t.getMessage());
        }
    }
    
    /**
     * Closes the connection.
     */
    @PreDestroy
    public void endConnection() throws RuntimeException {
        if (session != null) {
            try {
            	session.close();
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
    }
    
}
