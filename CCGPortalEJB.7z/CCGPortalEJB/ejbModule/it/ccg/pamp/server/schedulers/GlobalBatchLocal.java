package it.ccg.pamp.server.schedulers;
import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.Timer;
import javax.ejb.TimerService;

@Local

public interface GlobalBatchLocal {
	public void metodoTimeout(Timer timer);
	public TimerService getTimerService();
}
