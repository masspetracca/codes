package it.ccg.pamp.server.schedulers;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

/**
 * Session Bean implementation class GlobalBatch
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class GlobalBatch implements  GlobalBatchLocal {

	@Resource
	TimerService timerservice;
	
    public GlobalBatch() {
        // TODO Auto-generated constructor stub
    }
    
    @Override
    public TimerService getTimerService() {
    	return this.timerservice;
    }
    
    @Override
    @Timeout
    public void metodoTimeout(Timer timer) {
    	
    	//scheduler.add("prova", "T", 10, null, null, getSystemDate());
    	//
    }

}
