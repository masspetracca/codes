package it.ccg.pamp.server.utils;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class ReadyToExpGroupHistory {

	private int grId;
	
	private Timestamp iniVDate;
	
	private String groupName;
	
	private BigDecimal grCoeff;
	
	private String grStatus;
	
	private int instrId;
	
	private String sicClassCode;
	
	private String sicInstrType;
	
	private String currency;
	
	private String lastExecutor;
	
	
	public ReadyToExpGroupHistory() {
		super();
	}
	
	public ReadyToExpGroupHistory(int grId, Timestamp iniVDate, String groupName, BigDecimal grCoeff, String grStatus, int instrId, String sicClassCode, String sicInstrType, String currency, String lastExecutor) {
		super();
		this.grId = grId;
		this.iniVDate = iniVDate;
		this.groupName = groupName;
		this.grCoeff = grCoeff;
		this.grStatus = grStatus;
		this.instrId = instrId;
		this.sicClassCode = sicClassCode;
		this.sicInstrType = sicInstrType;
		this.currency = currency;
		this.lastExecutor = lastExecutor.toUpperCase();
	}

	public int getGrId() {
		return grId;
	}

	public void setGrId(int grId) {
		this.grId = grId;
	}

	public Timestamp getIniVDate() {
		return iniVDate;
	}

	
	public void setIniVDate(Timestamp iniVDate) {
		this.iniVDate = iniVDate;
	}
	
	public String getGroupName() {
		//return (sicInstrType+groupName).substring(0,3);
		int len = 3;
		if (groupName.length()<3) {
			len = groupName.length();
		}
		
		return groupName.substring(0,len);
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public BigDecimal getGrCoeff() {
		return grCoeff;
	}

	public void setGrCoeff(BigDecimal grCoeff) {
		this.grCoeff = grCoeff;
	}

	public int getInstrId() {
		return instrId;
	}

	public void setInstrId(int instrId) {
		this.instrId = instrId;
	}

	public String getSicClassCode() {
		return sicClassCode;
	}

	public void setSicClassCode(String sicClassCode) {
		this.sicClassCode = sicClassCode;
	}

	public String getSicInstrType() {
		return sicInstrType;
	}

	public String getCurrency() {
		return currency;
	}
	
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public void setSicInstrType(String sicInstrType) {
		this.sicInstrType = sicInstrType;
	}

	public void setGrStatus(String grStatus) {
		this.grStatus = grStatus;
	}

	public String getGrStatus() {
		return grStatus;
	}

	public void setLastExecutor(String lastExecutor) {
		this.lastExecutor = lastExecutor.toUpperCase();
	}

	public String getLastExecutor() {
		return lastExecutor.toUpperCase();
	}
	
}
