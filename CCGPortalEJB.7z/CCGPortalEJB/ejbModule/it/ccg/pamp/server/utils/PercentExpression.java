package it.ccg.pamp.server.utils;

import java.math.BigDecimal;
import java.math.MathContext;

public class PercentExpression {
	
	private String percent;
	
	public PercentExpression() {
		super();
	}
	
	public PercentExpression(BigDecimal decimal, int decimalDigits) {
		super();
		MathContext mathC = new MathContext(decimalDigits);
		this.percent = decimal.multiply(new BigDecimal(100)).abs().round(mathC).toString()+"%";
	}
	
	public PercentExpression(Double decimal, int decimalDigits) {
		super();
		MathContext mathC = new MathContext(decimalDigits);
		this.percent = (new BigDecimal(decimal)).multiply(new BigDecimal(100)).abs().round(mathC).toString()+"%";
	}

	public void setPercent(String percent) {
		this.percent = percent;
	}

	public String getPercent() {
		return percent;
	}
	
	
}
