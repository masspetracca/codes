package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

public class Expiry {
	
	private BigDecimal ro;
	private BigDecimal deltaro;
	private BigDecimal frazAnno;
	private BigDecimal nuovaFrazAnno;
	private int irNode;
	private int scadenza;

	public Expiry() {
		super();
	}

	public Expiry(BigDecimal ro, BigDecimal deltaro, BigDecimal frazAnno, BigDecimal nuovaFrazAnno, int irNode, int scadenza) {
		super();
		this.ro = ro;
		this.deltaro = deltaro;
		this.frazAnno = frazAnno;
		this.nuovaFrazAnno = nuovaFrazAnno;
		this.irNode = irNode;
		this.scadenza = scadenza;
	}

	public int getIrNode() {
		return irNode;
	}

	public void setIrNode(int irNode) {
		this.irNode = irNode;
	}

	public int getScadenza() {
		return scadenza;
	}

	public void setScadenza(int scadenza) {
		this.scadenza = scadenza;
	}

	public BigDecimal getRo() {
		return ro;
	}

	public void setRo(BigDecimal ro) {
		this.ro = ro;
	}

	public BigDecimal getDeltaro() {
		return deltaro;
	}

	public void setDeltaro(BigDecimal deltaro) {
		this.deltaro = deltaro;
	}

	public BigDecimal getFrazAnno() {
		return frazAnno;
	}

	public void setFrazAnno(BigDecimal frazAnno) {
		this.frazAnno = frazAnno;
	}

	public BigDecimal getNuovaFrazAnno() {
		return nuovaFrazAnno;
	}

	public void setNuovaFrazAnno(BigDecimal nuovaFrazAnno) {
		this.nuovaFrazAnno = nuovaFrazAnno;
	}
	
	
	

}
