package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.Instrument;

import java.math.BigDecimal;

public class CurveNode {

	
	
	Instrument instr;
	
	BigDecimal deltaYield;

	public CurveNode() {
		super(); 
		
	}

	public CurveNode(Instrument instr, BigDecimal deltaYield) {
		super();
		this.instr = instr;
		this.deltaYield = deltaYield;
	}

	public Instrument getInstr() {
		return instr;
	}

	public void setInstr(Instrument instr) {
		this.instr = instr;
	}

	public BigDecimal getDeltaYield() {
		return deltaYield;
	}

	public void setDeltaYield(BigDecimal deltaYield) {
		this.deltaYield = deltaYield;
	}

	@Override
	public String toString() {
		return "CurveNode: instr=" + instr.getInstrId() + ", duration=" + instr.getDuration() + ", deltaYield=" + deltaYield ;
	}
	
	
	
	
	

	
	
	
	
	
	
}
