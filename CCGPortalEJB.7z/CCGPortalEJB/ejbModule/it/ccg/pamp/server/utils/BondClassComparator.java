package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.BondClass;


import java.util.Comparator;

public class BondClassComparator implements	Comparator {

		
		public int compare(Object object1, Object object2) {
			BondClass bc1= (BondClass) object1;
			BondClass bc2= (BondClass) object2;
		
			return bc1.getClassId()-bc2.getClassId();	
		}

}
