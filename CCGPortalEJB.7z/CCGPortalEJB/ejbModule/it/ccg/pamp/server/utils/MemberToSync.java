package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

public class MemberToSync {

	private int mbrId;
	private int genMbrId;
	private String mbrCode;
	private String genMbrCode;
	private String mbrName;
	private String genMbrName;
	private String currency;
	private BigDecimal mia;
	private BigDecimal clientCashCall;
	private BigDecimal clientInitialMargin;
	private BigDecimal firmCashCall;
	private BigDecimal firmInitialMargin;
	
	
	public MemberToSync() {
		
	}

	public int getMbrId() {
		return mbrId;
	}

	public void setMbrId(int mbrId) {
		this.mbrId = mbrId;
	}

	public int getGenMbrId() {
		return genMbrId;
	}

	public void setGenMbrId(int genMbrId) {
		this.genMbrId = genMbrId;
	}

	public String getMbrCode() {
		return mbrCode;
	}

	public void setMbrCode(String mbrCode) {
		this.mbrCode = mbrCode;
	}

	public String getGenMbrCode() {
		return genMbrCode;
	}

	public void setGenMbrCode(String genMbrCode) {
		this.genMbrCode = genMbrCode;
	}

	public String getMbrName() {
		return mbrName;
	}

	public void setMbrName(String mbrName) {
		this.mbrName = mbrName;
	}

	public String getGenMbrName() {
		return genMbrName;
	}

	public void setGenMbrName(String genMbrName) {
		this.genMbrName = genMbrName;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public BigDecimal getMia() {
		return mia;
	}

	public void setMia(BigDecimal mia) {
		if (mia==null) {
			mia = new BigDecimal(0);
		}
		this.mia = mia;
	}
	
	public BigDecimal getClientCashCall() {
		return clientCashCall;
	}

	public void setClientCashCall(BigDecimal clientCashCall) {
		if (clientCashCall==null) {
			clientCashCall = new BigDecimal(0);
		}
		this.clientCashCall = clientCashCall;
	}

	public BigDecimal getClientInitialMargin() {
		return clientInitialMargin;
	}

	public void setClientInitialMargin(BigDecimal clientInitialMargin) {
		if (clientInitialMargin==null) {
			clientInitialMargin = new BigDecimal(0);
		}
		this.clientInitialMargin = clientInitialMargin;
	}

	public BigDecimal getFirmCashCall() {
		return firmCashCall;
	}

	public void setFirmCashCall(BigDecimal firmCashCall) {
		if (firmCashCall==null) {
			firmCashCall = new BigDecimal(0);
		}
		this.firmCashCall = firmCashCall;
	}

	public BigDecimal getFirmInitialMargin() {
		return firmInitialMargin;
	}

	public void setFirmInitialMargin(BigDecimal firmInitialMargin) {
		if (firmInitialMargin==null) {
			firmInitialMargin = new BigDecimal(0);
		}
		this.firmInitialMargin = firmInitialMargin;
	}
	
}
