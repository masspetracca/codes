package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.HistoricalPricesRett;
import it.ccg.pamp.server.entities.MarginHistory;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class VariationChartObject {
	
	
	
	private String priceDate;
	private BigDecimal rettifiedPrice;
	private BigDecimal margin;
	private BigDecimal lastMargin;
	private List<BigDecimal> variationsList = new ArrayList<BigDecimal>();
	private final MathContext mathC= new MathContext(4);
	
	
	public VariationChartObject() {
		super();
	}
	
	
	public static List<VariationChartObject> crateStringForChart(HistoricalPricesRett[] arrHistoricalPricesRett, MarginHistory[] arrMarginHistory, Integer[] arrActiveDelta) {
		
		// lunghezze margini e prezzi rettificati
		int hisPrRettLength =  arrHistoricalPricesRett.length;
		int marHisLength =  arrMarginHistory.length;
		
    	//array di margini lungo quanto i prezzi rettificati 
    	BigDecimal[] arrMargin = new BigDecimal[hisPrRettLength];
    	
    	int deltaLength =  arrActiveDelta.length;
    	int maximumActiveDelta = arrActiveDelta[deltaLength-1];
    	
    	BigDecimal lastMargin = null;
    	
    	if (marHisLength>0) {
    		lastMargin = arrMarginHistory[marHisLength-1].getMargin();
    	}
    	
    	int marHisPos=0;
    	int hisprPos=0;
    	int deltaPos=0;
    	
    	// popolo l'array dei margini 
    	for (marHisPos=0;marHisPos<marHisLength;marHisPos++) {
    		
    		for(hisprPos=0;hisprPos<hisPrRettLength;hisprPos++) {
    			if ((arrHistoricalPricesRett[hisprPos].getPk().getPriceDate().compareTo(arrMarginHistory[marHisPos].getPk().getIniVDate())<0)) {
    				break;
    			} else {
    				arrMargin[hisprPos] = arrMarginHistory[marHisPos].getMargin();
    			}
    		}
    	}
    	
    	List<VariationChartObject> varChartStringList = new ArrayList<VariationChartObject>(); 
    	
    	// popolo la stringa finale con data, prezzo rettificato
    	for(hisprPos=0;hisprPos<hisPrRettLength-maximumActiveDelta;hisprPos++) {
    		VariationChartObject varChartObject = new VariationChartObject();
    		
    		varChartObject.setPriceDate(arrHistoricalPricesRett[hisprPos].getPk().getPriceDate());
    		varChartObject.setRettifiedPrice(arrHistoricalPricesRett[hisprPos].getClosePrRet());
    		
    		// se il margine in quella posizione non � vuoto allora aggiungo pure il valore del margine
    		
    		if (arrMargin[hisprPos]!=null) {
    			varChartObject.setMargin(arrMargin[hisprPos]);
    		} else {
    			varChartObject.setMargin(null);
			}
    		
    		// aggiungo pure il last margin  
    		varChartObject.setLastMargin(lastMargin);
    		
    		//variazioni
    		for (deltaPos=0;deltaPos<deltaLength;deltaPos++) {
    			try{
	    			if ((hisprPos+maximumActiveDelta)<=hisPrRettLength){
	    				int nextHisprRett = hisprPos+arrActiveDelta[deltaPos];
	    				varChartObject.setVariationsList(arrHistoricalPricesRett[hisprPos].getClosePrRet(),arrHistoricalPricesRett[nextHisprRett].getClosePrRet());	
	    			}
    			} catch(Exception e){
        			e.printStackTrace();
        		}
    		}
    		varChartStringList.add(varChartObject);
    	}
    	
    	return varChartStringList;
    }
	
	


	public String getPriceDate() {
		return priceDate;
	}


	public void setPriceDate(Timestamp priceDate) {
		String priceDateString = priceDate.toString().substring(0, 10);
		this.priceDate = priceDateString;
	}


	public BigDecimal getRettifiedPrice() {
		return rettifiedPrice;
	}


	public void setRettifiedPrice(BigDecimal rettifiedPrice) {
		this.rettifiedPrice = rettifiedPrice;
	}


	public BigDecimal getMargin() {
		return margin;
	}


	public void setMargin(BigDecimal margin) {
		if (margin!=null) {
			margin.round(mathC);
			this.margin = margin.multiply(new BigDecimal(100));
		} else {
			this.margin = null;
		}
	}


	public void setLastMargin(BigDecimal lastMargin) {
		if (lastMargin!=null) {
			lastMargin.round(mathC);
			this.lastMargin = lastMargin.multiply(new BigDecimal(100));
		} else {
			this.lastMargin = null;
		}
	}


	public BigDecimal getLastMargin() {
		return lastMargin;
	}


	public void setVariationsList(BigDecimal curHispRett,BigDecimal nextHisPrRett) {
		BigDecimal variation = nextHisPrRett.subtract(curHispRett).divide(curHispRett, mathC);
		this.variationsList.add(variation.multiply(new BigDecimal(100)));
	}


	public List<BigDecimal> getVariationsList() {
		return variationsList;
	}
	

}
