package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;
import java.util.List;

import javax.ejb.SessionContext;

import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;
import org.apache.log4j.Logger;

public class GenericTools {

	static Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	

	public static String userString(SessionContext ctx) throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}

	public static Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());

		return now;
	}

	public static Timestamp systemDateMidNight() {
		int year = Integer.parseInt(shortSysDateFormat().substring(0,4));
		int month = Integer.parseInt(shortSysDateFormat().substring(5,7))-1;
		int day = Integer.parseInt(shortSysDateFormat().substring(8));
		GregorianCalendar cal = new GregorianCalendar(year,month,day);
		Timestamp now = new Timestamp(cal.getTimeInMillis());

		return now;
	}
	
	public static Timestamp getPastDateForMonthsAgo(Timestamp startingDate, int monthsAgo) {
		
		String lstDateStr = startingDate.toString().substring(0,10);
		
		int year = Integer.parseInt(lstDateStr.split("-")[0]);
		
		int month = Integer.parseInt(lstDateStr.split("-")[1]);
		
		int day = Integer.parseInt(lstDateStr.split("-")[2]);
		
		month = month-monthsAgo;
		
		// se il mese diventa negativo allora per ottenere il suo valore incremento di 12 la variabile e torno indietro di un anno 
		if (month<0) {
			month += 12;
			year--;
		}
		
		Timestamp theDate = new Timestamp(new GregorianCalendar(year,month-1,day).getTimeInMillis());
		
		return theDate;
		
	}
	
	public static long systemDateLongFormat() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		
		return shortDateFormatAsLong(now);
	}
	
	public static long systemTime() {

		String sysTime = systemDate().toString().substring(11, 19);
		long time = Integer.parseInt(sysTime.replaceAll(":", ""));
		
		return time;
	}
		
	public static Integer delayRestartAfterOrBeforeChangingTime(int days) {
		
		GregorianCalendar cal = new GregorianCalendar();
		
		Integer ret  = null;
		
		boolean isAfterOrBeforeChangingTime = false;
		
		cal.add(GregorianCalendar.DATE, -days);
		
		// se days = 0 significa che vedo se oggi � sabato per sapere se QUESTA sera cambier� l'orario
		// se days = 1 significa che vedo se oggi � domenica per sapere se STANOTTE � cambiato l'orario
		
		if (cal.get(GregorianCalendar.DAY_OF_WEEK) == GregorianCalendar.SATURDAY) {
					
			boolean isOctoberOrMarch = false;
			boolean nextWeekIsStillOctoberOrMarch = false;
			
			// controllo se il giorno in questione � ottobre o marzo
			if (cal.get(GregorianCalendar.MONTH) == GregorianCalendar.OCTOBER || cal.get(GregorianCalendar.MONTH) == GregorianCalendar.MARCH)
				isOctoberOrMarch = true;
			
			//torno indietro del parametro DAYS utilizzato (se � uno perch� mi serve per sapere se SABATO prossimo � ancora ottobre o marzo)
			// e incremento il calendario di sette giorni
			cal.add(GregorianCalendar.DATE, -days+7);
		
			// vedo se fra sette giorni � ancora marzo o ottobre
			if (cal.get(GregorianCalendar.MONTH) == GregorianCalendar.OCTOBER || cal.get(GregorianCalendar.MONTH) == GregorianCalendar.MARCH)
				nextWeekIsStillOctoberOrMarch = true;
		
			// se � L'ULTIMO sabato di ottobre o marzo (attualmente � marzo e ottobre ma fra sette giorni no) 
			if (isOctoberOrMarch && !nextWeekIsStillOctoberOrMarch) {
				isAfterOrBeforeChangingTime = true;
			}
		}
		
		if (days==0 && isAfterOrBeforeChangingTime) {
			if (cal.MONTH == GregorianCalendar.OCTOBER) {
				ret = 1;
			} else {
				ret = -1;
			}
		} else if (days==1 && isAfterOrBeforeChangingTime) {
			ret =  0;
		}
		
		return ret;
		
	}
	
	public static String shortSysDateFormat() {
		return systemDate().toString().substring(0, 10);
	}

	public static boolean isBissextileYear(int todayYear) {
		int startingYear = 2012;
		GregorianCalendar cal = new GregorianCalendar();

		boolean isBissextile = false;
		if (todayYear >= startingYear) {
			for (int i = 0; i < 11; i++) {
				if (todayYear == startingYear + (4 * i)) {
					isBissextile = true;
				}
			}
		}

		return isBissextile;
	}

	public static String cardinal(int n) {
		String number="";
		if ((n==11||n==12||n==13)) {
			number=n+"th";
		} else {
			for (int i=0;i<n+1;i++) {
				if ((n-i)==1) {
					number=n+"st";
				} else if ((n-i)==2) {
					number=n+"nd";
				} else if ((n-i)==3) {
					number=n+"rd";
				} else {
					number=n+"th";
				}
				break;
			}
		}		
		return number;
		
	}
	
	public static String padding(String startingStr, int fieldLen) {
		String outputString = startingStr;

		/*
		 * System.out.println("startingStr: "+startingStr.length());
		 * System.out.println("fieldLen: "+fieldLen);
		 * System.out.println("spazi: "+(fieldLen-(startingStr.length()+1)));
		 */

		for (int i = 0; i < fieldLen - (startingStr.length() + 1); i++) {
			outputString += " ";
		}

		return outputString;
	}
	
	public static String paddingForDecimal(String startingStr, int fieldLen) {
		String outputString = startingStr;

		/*
		 * System.out.println("startingStr: "+startingStr.length());
		 * System.out.println("fieldLen: "+fieldLen);
		 * System.out.println("spazi: "+(fieldLen-(startingStr.length()+1)));
		 */

		for (int i = 0; i < fieldLen - (startingStr.length() + 1); i++) {
			outputString += "0";
		}

		return outputString;
	}

	public static String padding(String startingStr, int fieldLen, boolean reverse) {
		String outputString = startingStr;

		/*
		 * System.out.println("startingStr: "+startingStr.length());
		 * System.out.println("fieldLen: "+fieldLen);
		 * System.out.println("spazi: "+(fieldLen-(startingStr.length()+1)));
		 */

		if (!reverse) {
			for (int i = 0; i < fieldLen - (startingStr.length() + 1); i++) {
				outputString += " ";
			}
		} else {
			String spazio = "";
			for (int i = 0; i < fieldLen - startingStr.length(); i++) {
				spazio += " ";
			}
			outputString = spazio + outputString;
		}

		return outputString;
	}

	public static String scenarioDesc(String scenarioAcronymous) {

		String scenario = "increasing";

		if (scenarioAcronymous.equalsIgnoreCase("d")) {
			scenario = "decreasing";
		} else if (scenarioAcronymous.equalsIgnoreCase("0")) {
			scenario = "resetting";
		}

		return scenario;
	}

	public static String shortDateFormat(Timestamp fullDate) {
		return fullDate.toString().substring(0, 10);
	}

	public static long shortDateFormatAsLong(Timestamp fullDate) {
		String date = fullDate.toString().substring(0, 4) + fullDate.toString().substring(5, 7) + fullDate.toString().substring(8, 10);
		Long dateAsLong = Long.parseLong(date);
		return dateAsLong;
	}

	public static Timestamp convertDateFromIntToTimestamp(int dateToConvert) throws DataNotValidException {

		if (Integer.toString(dateToConvert).length() == 8) {

			String year = Integer.toString(dateToConvert).substring(0, 4);
			String month = Integer.toString(dateToConvert).substring(4, 6);
			String day = Integer.toString(dateToConvert).substring(6, 8);

			GregorianCalendar cal = new GregorianCalendar(Integer.parseInt(year), Integer.parseInt(month) - 1, Integer.parseInt(day));

			Timestamp dateToReturn = new Timestamp(cal.getTimeInMillis());

			return dateToReturn;
		} else {
			throw new DataNotValidException("Date " + dateToConvert + " unconvertible to Timestamp format");
		}

	}
	
	public static List<String> arrayToList(String[] arrayString) {
		
		List<String> returnList = new ArrayList<String>();

		for (String str:arrayString) {
			returnList.add(str);
		}
		
		return returnList;
	}
	
	@SuppressWarnings("deprecation")
	public static Timestamp convertStringDateToTimestamp(String dateToConvert,String[] validSeparators, String entryFormat,String atPosition) throws Exception {
		
		boolean defaultFormat = true;
		
		String originalDate = dateToConvert;
		
		String exceptionMsg = "Date "+originalDate+" not valid "+atPosition+". ";
		
		String defaultDateString = "";
		
		if (!(entryFormat==null || entryFormat.toUpperCase().equalsIgnoreCase("YYYY-MM-DD") || entryFormat.equalsIgnoreCase("")))
			defaultFormat = false;
		
		// se il formato non � di default e non contiene Y o D o M
		if (!defaultFormat) {
			if (!(entryFormat.toUpperCase().contains("Y")||entryFormat.toUpperCase().contains("M")||entryFormat.toUpperCase().contains("D"))) 
				//eccezione sul formato
				throw new Exception("Date format "+entryFormat+" not allowed "+atPosition+" - expected \"YYYY-MM-DD\" format");
		}
		
		// valori di default
		int yearStart = 0;
		int yearEnd = 4;
		int yearDigits = 4;
		
		int monthStart = 4;
		int monthEnd = 6;
		
		int dayStart = 6;
		int dayEnd = 8;
		
		//lunghezza formato
		int formatLength = 0;
		int dateToConvertLength = 0;
		
		boolean separatorFound = false;
		String separator = "";
		
		int year = 0;
		
		int month = 0;
		
		int day  = 0;
		
		// se c'� un qualsiasi separatore lo elimino
		//if (!(separatorArray==null || separatorArray.equalsIgnoreCase(""))) {
		if (validSeparators.length!=0) {
			for (String sep:validSeparators) {
				if (dateToConvert.indexOf(sep)>0) {
					separatorFound = true;
					separator = sep;
					break;
				}
			}
			
			if (!separatorFound)
				throw new Exception("Valid date separators not found "+atPosition);
			
			// se � un separatore di formato inglese lo converto
			if (separator.equalsIgnoreCase("-")) {
				dateToConvert = dateToConvert.replaceAll(separator, "/");
				entryFormat = entryFormat.replaceAll(separator,"/");
				separator = "/";
			} else {
				//eccezione sul formato
				throw new Exception("Date separator \""+separator+"\" not allowed "+atPosition+" - expected \"-\"");
			}
			
			// lunghezza formato e data puliti dai separatori
			dateToConvertLength = dateToConvert.length();
			formatLength = entryFormat.length();
			
			// memorizzo le posizioni delle diverse parti del formato
			yearStart = entryFormat.toUpperCase().indexOf("Y");
			yearEnd = entryFormat.toUpperCase().lastIndexOf("Y")+1;
			yearDigits = (yearEnd-yearStart);
			
			monthStart = entryFormat.toUpperCase().indexOf("M");
			monthEnd = entryFormat.toUpperCase().lastIndexOf("M")+1;
			
			dayStart = entryFormat.toUpperCase().indexOf("D");
			dayEnd = entryFormat.toUpperCase().lastIndexOf("D")+1;
			
			String DLchars = "char";
			
			if (dateToConvertLength>1)
				DLchars = "chars";
			
			DLchars = dateToConvertLength+" "+DLchars;
			
			String formatChars = "char";
			
			if (formatLength>1)
				formatChars = "chars";
			
			formatChars = formatLength+" "+formatChars;
			
			//confronto lunghezze
			if (formatLength!=dateToConvertLength) 
				throw new Exception(exceptionMsg+"Date length ("+DLchars+") is different than format length ("+formatChars+")");
			
			defaultDateString = dateToConvert.substring(monthStart,monthEnd)+dateToConvert.substring(dayStart,dayEnd);
			
			// se l'anno ha due cifre lo forzo a 4
			String yearStr = dateToConvert.substring(yearStart,yearEnd);
			
			if (yearDigits==2) 
				yearStr =  "20"+yearStr;
			
				defaultDateString = yearStr+defaultDateString;
			
				year = Integer.parseInt(defaultDateString.substring(0,4));
				
				GregorianCalendar appoCalendar = new GregorianCalendar();
				
				month = Integer.parseInt(defaultDateString.substring(4,6));
				
				if (month>12)
					throw new Exception(exceptionMsg+"Month value greater than the maximum - found "+month+" but maximum allowed is 12");
					
				day = Integer.parseInt(defaultDateString.substring(6,8));
				
				int maxDay = 30;
				
				String leapYearExc = "";
				
				switch (month) {
				
					case 1:
					case 3:
					case 5:
					case 7:
					case 8:
					case 10:
					case 12:
						maxDay = 31;
						break;
					case 2:
						maxDay = 28;
						leapYearExc = " - "+year+" is not a leap year";
						if (appoCalendar.isLeapYear(year))
							maxDay = 29;
						
						break;
				}	
				
				if (day>maxDay)
					throw new Exception(exceptionMsg+"Day value not allowed for month "+month+" - found "+day+" but maximum allowed is "+maxDay+leapYearExc);
			
			
			// formatto la data secondo l'ordine YYYY-MM-DD
			SimpleDateFormat dateFormat = new SimpleDateFormat(entryFormat);
			dateToConvert = dateFormat.format(new Date(dateToConvert));
			
			// pulisco formato e data dal separatore '/'
			entryFormat = entryFormat.replaceAll(separator,"");
			dateToConvert = dateToConvert.replaceAll(separator, "");
			
			
			
		}
		
		
			
			GregorianCalendar cal = new GregorianCalendar(year, month-1, day);

			Timestamp dateToReturn = new Timestamp(cal.getTimeInMillis());

			return dateToReturn;
		
	}
	
	/*@SuppressWarnings("deprecation")
	public static Timestamp convertStringDateToTimestamp(String dateToConvert,String[] separatorArray, String entryFormat) throws Exception {

		boolean defaultFormat = true;
		
		String defaultDateString = "";
		
		System.out.println("---entro dentro il metodo");
		
		if (!(entryFormat==null || entryFormat.equalsIgnoreCase("YYYYMMDD") || entryFormat.equalsIgnoreCase(""))) 
			defaultFormat = false;
		
		String firstFormatChar = "";
		
		int yearStart = 0;
		int yearEnd = 4;
		int yearDigits = 4;
		
		int monthStart = 4;
		int monthEnd = 6;
		
		
		int dayStart = 6;
		int dayEnd = 8;
		
		//lunghezza formato
		int formatLength = 0;
		
		System.out.println("formato---"+defaultFormat);
		
		//se non � DEFAULT vedo con cosa inizia il formato
		if (!defaultFormat) {
			//firstFormatChar = entryFormat.substring(0,1);
			// se non inizia con alcuna delle tre lettere possibili
			//System.out.println("prima lettera formato---"+defaultFormat);
			if (!(entryFormat.contains("Y")||entryFormat.contains("M")||entryFormat.contains("D"))) { 
				//eccezione sul formato
				throw new Exception("The supplied date format is not allowed - "+entryFormat);
			}
					
			yearStart = entryFormat.toUpperCase().indexOf("Y");
			yearEnd = entryFormat.toUpperCase().lastIndexOf("Y")+1;
			yearDigits = (yearEnd-yearStart);
			
			monthStart = entryFormat.toUpperCase().indexOf("M");
			monthEnd = entryFormat.toUpperCase().lastIndexOf("M")+1;
			
			dayStart = entryFormat.toUpperCase().indexOf("D");
			dayEnd = entryFormat.toUpperCase().lastIndexOf("D")+1;
			
			System.out.println("position: "+dayStart+" "+dayEnd+"----"+monthStart+" "+monthEnd+"-------"+yearStart+" "+yearEnd);
			
			
			formatLength = entryFormat.length();
			System.out.println("formatLength: "+formatLength);
		
		} else {
			formatLength = 8;
		}
		
		boolean separatorFound = false;
		String separator = "";
		
		System.out.println("separatorArray.length: "+separatorArray.length);
		
		// se c'� un qualsiasi separatore lo elimino
		//if (!(separatorArray==null || separatorArray.equalsIgnoreCase(""))) {
		if (separatorArray.length!=0) {
			for (String sep:separatorArray) {
				if (dateToConvert.indexOf(sep)>0) {
					separatorFound = true;
					separator = sep;
					break;
				}
			}
			System.out.println("separatorFound: "+separatorFound);
			if (!separatorFound)
				throw new Exception("Valid date separators not found");
			
			System.out.println("separator char: "+separator);
			
			if (separator.equalsIgnoreCase("-"))
				dateToConvert = dateToConvert.replaceAll(separator, "/");
		
			SimpleDateFormat dateFormat = new SimpleDateFormat(entryFormat);
			System.out.println("dateToConvert: "+dateToConvert);
			dateToConvert = dateFormat.format(new Date(dateToConvert));
			
			formatLength = entryFormat.replaceAll(separator,"").length();
			System.out.println("formatLength: "+formatLength);
			
			dateToConvert = dateToConvert.replaceAll(separator, "");
			System.out.println("dateToConvert: "+dateToConvert);
			
			System.out.println("formatLength: "+formatLength);
		}
	
		// lunghezza data pulita
		int dateToConvertLength = dateToConvert.length();
	
		//confronto lunghezze
		if (formatLength!=dateToConvertLength) 
			throw new Exception("Date length is different than format length - "+dateToConvertLength + "vs"+ formatLength);
		
		//ricostruisco la stringa in base al formato di default se non lo � gi�
		// formato di default YYYYMMDD
		if (!defaultFormat) {
			
			//eventualmente aggiungo 20 se l'anno � di due cifre
			String yearStr = dateToConvert.substring(yearStart,yearEnd);
			if (yearDigits==2) 
				yearStr =  "20"+yearStr;
			
			System.out.println("yearStr: "+yearStr);
			System.out.println(dateToConvert.substring(monthStart,monthEnd));
			defaultDateString = yearStr+dateToConvert.substring(monthStart,monthEnd)+dateToConvert.substring(dayStart,dayEnd);
			System.out.println("defaultDateString: "+defaultDateString);
		} else {
			defaultDateString = dateToConvert;
		}
		
		int year = Integer.parseInt(defaultDateString.substring(0,4));
		System.out.println("year: "+year);
		
		int month = Integer.parseInt(defaultDateString.substring(4,6));
		System.out.println("month: "+month);
		if (month>12)
			throw new Exception("Month value not valid: found "+month);
			
		int day = Integer.parseInt(defaultDateString.substring(6,8));
		
		System.out.println("day: "+day);
		
		int maxDay = 30;
		
		switch (month) {
		
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				maxDay = 31;
				break;
			case 2:
				maxDay = 29;
				break;
		}	
		
		if (day>maxDay)
			throw new Exception("Day value not valid: found "+day+" for month "+month);
		
		GregorianCalendar cal = new GregorianCalendar(year, month-1, day);

		Timestamp dateToReturn = new Timestamp(cal.getTimeInMillis());

		return dateToReturn;
		

	}
	*/
	
	
	
	public static Timestamp convertDateFromStringToTimestamp(String dateToConvert) throws DataNotValidException {

		if (dateToConvert.length() == 10) {
			
			String[] date = dateToConvert.split("/");
			
			int year = /*2000+*/Integer.parseInt(date[2]);//dateToConvert.substring(7, 10);
			int month = Integer.parseInt(date[1]);
			int day = Integer.parseInt(date[0]);

			GregorianCalendar cal = new GregorianCalendar(year, month-1, day);

			Timestamp dateToReturn = new Timestamp(cal.getTimeInMillis());

			return dateToReturn;
		} else {
			throw new DataNotValidException("Date " + dateToConvert + " unconvertible to Timestamp format");
		}

	}
	
	public static String convertDateFromIntToString(int dateToConvert) throws DataNotValidException {

		if (Integer.toString(dateToConvert).length() == 8) {

			Timestamp timestamp = convertDateFromIntToTimestamp(dateToConvert);
			
			String dateToReturn = shortDateFormat(timestamp);
			
			return dateToReturn;
		} else {
			throw new DataNotValidException("Date " + dateToConvert + " unconvertible to Timestamp format");
		}

	}
	
	public static Timestamp previousDate(Timestamp today) {

		int todayYear = Integer.parseInt(today.toString().substring(0, 4));
		int todayMonth = Integer.parseInt(today.toString().substring(5, 7));
		int todayDay = Integer.parseInt(today.toString().substring(8, 10));

		int yesterdayYear = todayYear;
		int yesterdayMonth = todayMonth;
		int yesterdayDay = todayDay - 1;

		GregorianCalendar calendar = new GregorianCalendar();

		if (todayDay == 1) {
			yesterdayDay = 30;
			yesterdayMonth--;
			switch (todayMonth) {
			case 1:// torno indietro di un anno e di un mese se il mese �
					// gennaio
				yesterdayYear = yesterdayYear--;
				yesterdayMonth = 12;
				yesterdayDay = 31;
				break;
			case 3:// caso in cui il mese � febbraio
				yesterdayDay = 28;
				if (calendar.isLeapYear(todayYear)) {
					yesterdayDay = 29;
				}
				break;
			case 2:
			case 4:
			case 6:
			case 9:
			case 11:// caso in cui il mese precedente ha 31 giorni
				yesterdayDay = 31;
				break;
			}
		}

		Timestamp yesterday = new Timestamp(new GregorianCalendar(yesterdayYear, yesterdayMonth - 1, yesterdayDay).getTimeInMillis());
		return yesterday;
	}

	public static String shortDateFormat() {
		return systemDate().toString().substring(0, 19);
	}

	public static String getStringDate() {
		// Prendo la data di oggi
		Date today = Calendar.getInstance().getTime();
		// Creo il date formatter
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-dd-MM-hh.mm.ss");
		// Creo una stringa rappresentante la data con il formato che vogliamo
		String folderName = formatter.format(today);
		return folderName;
	}

	public static Double roundValue(Double value, MathContext mathC) {
		BigDecimal rounded = new BigDecimal(value);
		return rounded.round(mathC).doubleValue();
	}

	public static String percentValue(BigDecimal value, MathContext mathC) {
		BigDecimal rounded = value.round(mathC).multiply(new BigDecimal(100));
		return rounded.toString() + "%";
	}

	public static String convertStringAcronymous(String acronymous, int dataType) {
		String fullWord = "";
		switch (dataType) {
		case 0:// tipo booleano T/F
			fullWord = "true";
			if (acronymous.equalsIgnoreCase("F")) {
				fullWord = "false";
			}
			break;
		case 1:// tipo stringa varType
			fullWord = "percentual";
			if (acronymous.equalsIgnoreCase("L")) {
				fullWord = "logarithmic";
			}
			break;
		case 2:// tipo stringa roundingType
			fullWord = "Nearest";
			if (acronymous.equalsIgnoreCase("C")) {
				fullWord = "Ceiling";
			} else if (acronymous.equalsIgnoreCase("F")) {
				fullWord = "Floor";
			}
			break;
		case 3:// tipo stringa roundingType
			fullWord = "Standard";
			if (acronymous.equalsIgnoreCase("C")) {
				fullWord = "Pearson";
			} else if (acronymous.equalsIgnoreCase("D")) {
				fullWord = "Div-Undiv";
			}
			break;
		case 4:// tipo stringa extrValues
			fullWord = "average between highest and second highest module";
			if (acronymous.equalsIgnoreCase("H")) {
				fullWord = "highest module";
			} else if (acronymous.equalsIgnoreCase("S")) {
				fullWord = "second highest module";
			}
			break;
		}

		return fullWord;
	}

	
	public static String scenarioFromAcronymous(String acronymous) {
		String scenario = "Decrease";
		
		if (acronymous.equalsIgnoreCase("I")) {
			scenario = "Increase";
		}
		if (acronymous.equalsIgnoreCase("0")) {
			scenario = "Day 0";
		}
		
		return scenario;
	}
	
	public static String accountFromAcronymous(String acronymous) throws DataNotValidException {
		String account = "Client";
		
		if (acronymous.equalsIgnoreCase("F")) {
			account = "Firm";
		} else if (acronymous.equalsIgnoreCase("C")) {
			account = "Client";
		} else {
			throw new DataNotValidException("Account acronymous not valid: "+acronymous);
		}
				
		return account;
	}
	
	
	public static String formatNumber(BigDecimal theNumber) {
		DecimalFormat df = new DecimalFormat("###,##0.00");
		DecimalFormatSymbols dfs= new DecimalFormatSymbols();
		dfs.setDecimalSeparator(',');
		df.setDecimalFormatSymbols(dfs);
		NumberFormat formatter = df;
		
		if (theNumber.compareTo(new BigDecimal(0))==0) {
			return "0";
		} else {
			return formatter.format(theNumber);
		}
	}
	
	public static String formatNumber(BigDecimal theNumber,int digits) {
		String decForm = "###,##0.";
		for (int i=0;i<digits;i++) {
			decForm += "0";
		}
		DecimalFormat df = new DecimalFormat(decForm);
		DecimalFormatSymbols dfs= new DecimalFormatSymbols();
		dfs.setDecimalSeparator('.');
		df.setDecimalFormatSymbols(dfs);
		NumberFormat formatter = df;
		
		if (theNumber.compareTo(new BigDecimal(0))==0) {
			return "0";
		} else {
			return formatter.format(theNumber);
		}
	}
	
	public static String convertIntegerAcronymous(int acronymous, int dataType) {
		String fullWord = "";
		switch (dataType) {
		case 0:// tipo stringa extrValues
			fullWord = "all variations";
			if (acronymous == -1) {
				fullWord = "negative variations";
			} else if (acronymous == 1) {
				fullWord = "positive variations";
			}
			break;
		case 1:// tipo stringa strExtrValues
			fullWord = "all variations";
			if (acronymous == 0) {
				fullWord = "highest module";
			} else if (acronymous == 1) {
				fullWord = "second highest module";
			}
			break;
		}
		return fullWord;
	}

	public static String getWholeDivisCode(String divisCode) {
		String fullName = "equity cash";

		if (divisCode.equalsIgnoreCase("ED")) {
			fullName = "eq. cash/eq. derivatives";
		}
		if (divisCode.equalsIgnoreCase("D")) {
			fullName = "equity derivatives";
		} else if (divisCode.equalsIgnoreCase("B")) {
			fullName = "interest rates";
		} else if (divisCode.equalsIgnoreCase("X")) {
			fullName = "index";
		} else if (divisCode.equalsIgnoreCase("L")) {
			fullName = "electricity derivatives";
		} else if (divisCode.equalsIgnoreCase("O")) {
			fullName = "bond";
		} else if (divisCode.equalsIgnoreCase("C")) {
			fullName = "forex";
		} else if (divisCode.equalsIgnoreCase("Y")) {
			fullName = "comparables";
		}
		
		
		return fullName;
	}

	public static String getAndLogStatErrorMessage(Logger userLog, int instrID, int nv, int periodo, String funzione, DescriptiveStatistics stats, Exception e) {

		String errmessage = "INSTRID " + instrID + ": Error calculating the " + funzione + " for holding period " + nv + " and period " + periodo + " ---> " + e.getMessage();

		userLog.error(errmessage);
		userLog.error("Values contained by the descriptive statistic");
		for (double val : stats.getValues()) {
			userLog.error(val);
		}

		return errmessage;
	}

	public static String getAndLogStatErrorMessage(Logger userLog, int instrID, int nv, int periodo, String funzione, DescriptiveStatistics stats, String note) {

		String errmessage = "INSTRID " + instrID + ": Error calculating the " + funzione + " for holding period " + nv + " and period " + periodo + " ---> " + note;

		userLog.error(errmessage);
		userLog.error("Values contained by the descriptive statistic");
		for (double val : stats.getValues()) {
			userLog.error(val);
		}

		return errmessage;
	}

	public static String getAndLogStatErrorMessage(Logger userLog, int instrID, int nv, String funzione, DescriptiveStatistics stats, String note) {

		String errmessage = "INSTRID " + instrID + ": Error calculating the " + funzione + " for holding period " + nv + " ---> " + note;

		userLog.error(errmessage);
		userLog.error("Values contained by the descriptive statistic");
		for (double val : stats.getValues()) {
			userLog.error(val);
		}

		return errmessage;
	}

	public static void infiniteStatWarnMessage(Logger userLog, int instrID, int nv, int periodo, String funzione, DescriptiveStatistics stats) {

		String errmessage = "INSTRID " + instrID + ": the result of the " + funzione + " function for holding period " + nv + " and period " + periodo
				+ " is NaN or infinite and it won't be stored on DB";

		userLog.warn(errmessage);

	}

	/**
	 * Controllo sulla soglia massima raggiungibile dal valore
	 * 
	 * @param userLog
	 * @param instrID
	 * @param nv
	 * @param periodo
	 * @param tipoVar
	 * @param daControllare
	 * @param numDecimaliAmmessi
	 * @param nomeCampo
	 * @return
	 */
	public static BigDecimal checkCap(Logger userLog, int instrID, int nv, int periodo, String tipoVar, BigDecimal daControllare, int numDecimaliAmmessi, String nomeCampo) {

		double soglia = Math.pow(10.00, numDecimaliAmmessi);

		BigDecimal restituito = null;

		if (daControllare.doubleValue() >= soglia) {

			double newFieldValue = soglia - 1;
			userLog.warn("INSTRID " + instrID + ": value of the field " + nomeCampo + " for holding period " + nv + " period " + periodo + " and tipovar " + tipoVar
					+ " is greater than the threshold " + soglia + " (" + daControllare + ") and will be set to a value of " + newFieldValue);

			restituito = new BigDecimal(newFieldValue);

		}

		else {
			restituito = daControllare;

		}

		return restituito;

	}

	/**
	 * Controllo sulla soglia massima raggiungibile dal valore
	 * 
	 * @param userLog
	 * @param instrID
	 * @param nv
	 * @param periodo
	 * @param tipoVar
	 * @param daControllare
	 * @param numDecimaliAmmessi
	 * @param nomeCampo
	 * @return
	 */
	public static BigDecimal checkCap(Logger userLog, int instrID1, int instrID2, int nv, int periodo, String tipoVar, BigDecimal daControllare, int numDecimaliAmmessi,
			String nomeCampo) {

		double soglia = Math.pow(10.00, numDecimaliAmmessi);

		BigDecimal restituito = null;

		if (daControllare.doubleValue() >= soglia) {

			double newFieldValue = soglia - 1;
			userLog.warn("INSTRID1 " + instrID1 + " INSTRID2 " + instrID2 + ": value of the field " + nomeCampo + " for holding period " + nv + " period " + periodo + " and tipovar "
					+ tipoVar + " is greater than the threshold " + soglia + " (" + daControllare + ") and will be set to a value of " + newFieldValue);

			restituito = new BigDecimal(newFieldValue);

		}

		else {
			restituito = daControllare;

		}

		return restituito;

	}

	public static boolean isOverCap(double daControllare, int numDecimaliAmmessi) {

		double soglia = Math.pow(10.00, numDecimaliAmmessi);

		boolean overcap = false;

		if (daControllare >= soglia)
			overcap = true;

		return overcap;

	}

	public static String array2String(String[] stringarr) {

		String stringafinale = "{";

		for (String mini : stringarr) {

			stringafinale += mini += ",";

		}
		if (stringafinale.endsWith(",")) {
			stringafinale = stringafinale.substring(0, stringafinale.length() - 1) + "}";
		} else
			stringafinale += "}";

		return stringafinale;

	}

	public static String intarray2String(int[] stringarr) {

		String stringafinale = "{";

		for (int mini : stringarr) {

			stringafinale += mini + ",";

		}
		if (stringafinale.endsWith(",")) {
			stringafinale = stringafinale.substring(0, stringafinale.length() - 1) + "}";
		} else
			stringafinale += "}";

		return stringafinale;

	}

	public static String[] string2Array(String stringona) throws DataNotValidException {

		if (stringona == null || (stringona.length() < 2 || !(stringona.startsWith("{") && stringona.endsWith("}")))) {
			throw new DataNotValidException("String structure (" + stringona + ") not valid");
		}

		stringona = stringona.substring(1, stringona.length() - 1);

		String[] stringarr = stringona.split(",");

		return stringarr;

	}

	public static int[] string2IntArray(String stringona) throws DataNotValidException {

		if (stringona == null || (stringona.length() < 2 || !(stringona.startsWith("{") && stringona.endsWith("}")))) {
			throw new DataNotValidException("String structure not valid");
		}

		stringona = stringona.substring(1, stringona.length() - 1);

		String[] stringarr = stringona.split(",");

		int[] intarr = new int[stringarr.length];

		for (int i = 0; i < stringarr.length; i++) {
			intarr[i] = Integer.parseInt(stringarr[i]);
		}

		return intarr;

	}

	public static boolean contains(String[] methodarr, String method) {

		for (String methcur : methodarr) {
			if (methcur.equalsIgnoreCase(method))
				return true;
		}

		return false;
	}

	public static BigDecimal getLinearInterpolation(BigDecimal x0, BigDecimal y0, BigDecimal x1, BigDecimal y1, BigDecimal x) {

		BigDecimal linearInterpolation = null;

		BigDecimal mNum = y1.subtract(y0);
		BigDecimal mDen = x1.subtract(x0);

		BigDecimal l = x.subtract(x0).multiply(mNum.divide(mDen, 8, RoundingMode.HALF_EVEN));

		linearInterpolation = y0.add(l, new MathContext(8, RoundingMode.HALF_EVEN));

		//userLog.info("X0: " + x0 + " Y0: " + y0 + " | X1: " + x1 + " Y1: " + y1 + " | X: " + x + " -------> " + linearInterpolation);

		return linearInterpolation;
	}

	/**
	 * Metodo per ottenere i giorni mancanti al prossimo stacco di cedola basato
	 * su 30/360
	 * 
	 * @param settlDate
	 * @param nextCouponDate
	 * @return
	 * @throws DataNotValidException
	 */
	public static int getDaysToNextCouponBase30360(GregorianCalendar settlDate, GregorianCalendar nextCouponDate) throws DataNotValidException {

		int days = 0;

		if (settlDate.after(nextCouponDate)) {
			throw new DataNotValidException("The settlement date is after the nextCouponDate");
		}

		if (settlDate.get(GregorianCalendar.DAY_OF_MONTH) == 31) {
			settlDate.set(GregorianCalendar.DAY_OF_MONTH, 30);
		}

		GregorianCalendar settlDateRett = new GregorianCalendar(settlDate.get(GregorianCalendar.YEAR), settlDate.get(GregorianCalendar.MONTH),
				(settlDate.get(GregorianCalendar.DAY_OF_MONTH) == 31 ? 30 : settlDate.get(GregorianCalendar.DAY_OF_MONTH)));

		if (settlDateRett.get(GregorianCalendar.YEAR) == nextCouponDate.get(GregorianCalendar.YEAR)) {

			if (settlDateRett.get(GregorianCalendar.MONTH) == nextCouponDate.get(GregorianCalendar.MONTH)) {
				days = nextCouponDate.get(GregorianCalendar.DAY_OF_MONTH) - settlDateRett.get(GregorianCalendar.DAY_OF_MONTH);
			}

			else {
				days = (30 - settlDateRett.get(GregorianCalendar.DAY_OF_MONTH))
						+ ((nextCouponDate.get(GregorianCalendar.MONTH) - settlDateRett.get(GregorianCalendar.MONTH) - 1) * 30)
						+ nextCouponDate.get(GregorianCalendar.DAY_OF_MONTH);
			}

		}

		else {
			GregorianCalendar ultimoDellAnno = new GregorianCalendar(settlDateRett.get(GregorianCalendar.YEAR), 11, 30);

			if (settlDateRett.get(GregorianCalendar.MONTH) == ultimoDellAnno.get(GregorianCalendar.MONTH)) {
				days = ultimoDellAnno.get(GregorianCalendar.DAY_OF_MONTH) - settlDateRett.get(GregorianCalendar.DAY_OF_MONTH);
			}

			else {
				days = (30 - settlDateRett.get(GregorianCalendar.DAY_OF_MONTH))
						+ ((ultimoDellAnno.get(GregorianCalendar.MONTH) - settlDateRett.get(GregorianCalendar.MONTH) - 1) * 30)
						+ ultimoDellAnno.get(GregorianCalendar.DAY_OF_MONTH);
			}

			days = days + ((nextCouponDate.get(GregorianCalendar.YEAR) - settlDateRett.get(GregorianCalendar.YEAR) - 1) * 360)
					+ (nextCouponDate.get(GregorianCalendar.DAY_OF_MONTH) + ((nextCouponDate.get(GregorianCalendar.MONTH)) * 30));

		}

		return days;

	}
	
	
	
	/**
	 * Metodo per ottenere i giorni mancanti al prossimo stacco di cedola basato
	 * su actual/actual
	 * 
	 * @param settlDate
	 * @param nextCouponDate
	 * @return
	 * @throws DataNotValidException
	 */
	public static int getDaysToNextCouponBaseActualActual(GregorianCalendar settlDate, GregorianCalendar nextCouponDate) throws DataNotValidException {

		
		return GenericTools.getDaysBetween2Dates(nextCouponDate, settlDate);

	}

	
	
	public static int getDaysBetween2Dates(GregorianCalendar recentDate, GregorianCalendar oldDate){
		
		
		GregorianCalendar recentDateRett= new GregorianCalendar(recentDate.get(GregorianCalendar.YEAR), recentDate.get(GregorianCalendar.MONTH), recentDate.get(GregorianCalendar.DAY_OF_MONTH), 0, 0, 0);

		GregorianCalendar oldDateRett= new GregorianCalendar(oldDate.get(GregorianCalendar.YEAR), oldDate.get(GregorianCalendar.MONTH), oldDate.get(GregorianCalendar.DAY_OF_MONTH), 0, 0, 0);
		
		return (int) ( (recentDateRett.getTimeInMillis() - oldDateRett.getTimeInMillis()) / (1000 * 60 * 60 * 24));
	}
	
	
	

	public static int getNumberOfCoupons2Maturity(Timestamp maturityDate, GregorianCalendar nextCouponDate, int bondFrequency) {

		GregorianCalendar maturityDay = new GregorianCalendar();
		maturityDay.setTimeInMillis(maturityDate.getTime());

		
		/*
		 * int saltomesi=12/bondFrequency;
		 * 
		 * 
		 * int numcoup=1;
		 * 
		 * 
		 * for(GregorianCalendar gc=maturityDay;
		 * gc.after(nextCD);gc.add(GregorianCalendar.MONTH, -saltomesi)){
		 * numcoup++; }
		 */

		int numcoup = 0;

		if (nextCouponDate.get(GregorianCalendar.YEAR) == maturityDay.get(GregorianCalendar.YEAR)) {
			numcoup = (nextCouponDate.get(GregorianCalendar.MONTH) == maturityDay.get(GregorianCalendar.MONTH) ? 1 : 2);
		} else {
			int numyear = maturityDay.get(GregorianCalendar.YEAR) - nextCouponDate.get(GregorianCalendar.YEAR);

			numcoup = numyear * bondFrequency;

			numcoup += (nextCouponDate.get(GregorianCalendar.MONTH) == maturityDay.get(GregorianCalendar.MONTH) ? 1 : (nextCouponDate.get(GregorianCalendar.MONTH) > maturityDay
					.get(GregorianCalendar.MONTH)) ? 0 : 2);
		}

		return numcoup;

	}

	public static String getNameFromLastString(int fieldLenght, String lastString, String prefix) throws DataNotValidException  {

		String nextname = "";
		fieldLenght-=1;

		if (lastString == null || lastString.trim().equalsIgnoreCase("")) {
			lastString = "0";

			for (int i = 1; i < fieldLenght; i++) {
				lastString += "0";
			}

		}
		else{
			lastString=lastString.substring(1, lastString.length());
			
		}
		
		if(lastString.length()!=fieldLenght){
			throw new DataNotValidException("The last string lenght is different from the fieldlenght parameter requested "+fieldLenght+1);
		}
		
		
		
		String[] alfanumarr = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S",
				"T", "U", "V", "W", "X", "Y", "Z" };

		for (int suc = fieldLenght; suc > 0; suc--) {

			String cara = lastString.substring(suc - 1, suc);

			if (cara.equalsIgnoreCase("Z")) {
				nextname = "0" + nextname;
				continue;
			} else {
				for (int i = 0; i < alfanumarr.length - 1; i++) {

					if (alfanumarr[i].equalsIgnoreCase(cara)) {
						
						nextname = alfanumarr[i + 1] + nextname;
						break;
					}

				}

				
				break;
			}

		}
		
		

		return prefix+lastString.substring(0, lastString.length()-nextname.length())+nextname;
	}

	
	
	public static GregorianCalendar getNextCouponDate(GregorianCalendar maturityDate, GregorianCalendar settlementDate, int bondFreq) throws DataNotValidException{
		
		GregorianCalendar nextCD= new GregorianCalendar(maturityDate.get(GregorianCalendar.YEAR), maturityDate.get(GregorianCalendar.MONTH), maturityDate.get(GregorianCalendar.DAY_OF_MONTH), 0, 0, 0);
		
		if(maturityDate.before(settlementDate)){
			throw new DataNotValidException("The maturity date is before the settlement date");
		}
		
		while(nextCD.after(settlementDate)){
			nextCD.add(GregorianCalendar.MONTH, -12/bondFreq);
		}
		
		nextCD.add(GregorianCalendar.MONTH, 12/bondFreq);
		
		return nextCD;
	}
	
	
	
	
	
	
}
