package it.ccg.pamp.server.utils;

import java.math.BigDecimal;



public class OeKBReMembers {
	
	private String pFolioId;
	
	private BigDecimal uMbr;
	
	private String uAcCt;
	
	private String uSubAc;
	
	private String uSGrp;
	
	private BigDecimal uGcm;
	
	private String tipo;
	
	private String stId;
	
	private BigDecimal dataMrg;

	private BigDecimal uTrnId;

	private BigDecimal uReq;
	
	private String mbrDesc;
	
	private String ugcMbrDesc;
	
	private String subAccDesc;

	public OeKBReMembers() {
		
	}
	
	public String getPfolioId() {
		return pFolioId.trim();
	}

	public void setPfolioId(String pFolioId) {
		this.pFolioId = pFolioId;
	}

	public BigDecimal getUmbr() {
		return uMbr;
	}

	public void setUmbr(BigDecimal uMbr) {
		this.uMbr = uMbr;
	}

	public String getUacCt() {
		return uAcCt.trim();
	}

	public void setUacCt(String uAcCt) {
		this.uAcCt = uAcCt;
	}

	public String getUsubAc() {
		return uSubAc;
	}

	public void setUsubAc(String uSubAc) {
		this.uSubAc = uSubAc;
	}

	public String getUsGrp() {
		return uSGrp.trim();
	}

	public void setUsGrp(String uSGrp) {
		this.uSGrp = uSGrp;
	}

	public BigDecimal getUgcm() {
		return uGcm;
	}

	public void setUgcm(BigDecimal uGcm) {
		this.uGcm = uGcm;
	}

	public String getTipo() {
		return tipo.trim();
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getStId() {
		return Integer.parseInt(stId.trim());
	}

	public void setStId(String stId) {
		this.stId = stId;
	}

	public BigDecimal getDataMrg() {
		return dataMrg;
	}

	public void setDataMrg(BigDecimal dataMrg) {
		this.dataMrg = dataMrg;
	}

	public BigDecimal getUtrnId() {
		return uTrnId;
	}

	public void setUtrnId(BigDecimal uTrnId) {
		this.uTrnId = uTrnId;
	}

	public BigDecimal getUreq() {
		return uReq;
	}

	public void setUreq(BigDecimal uReq) {
		this.uReq = uReq;
	}

	public String getMbrDesc() {
		return mbrDesc.trim();
	}

	public void setMbrDesc(String mbrDesc) {
		this.mbrDesc = mbrDesc;
	}

	public String getUgcMbrDesc() {
		return ugcMbrDesc.trim();
	}

	public void setUgcMbrDesc(String ugcMbrDesc) {
		this.ugcMbrDesc = ugcMbrDesc;
	}
	
	public String getSubAccDesc() {
		return subAccDesc;
	}

	public void setSubAccDesc(String subAccDesc) {
		this.subAccDesc = subAccDesc;
	}
	
	@Override
	public String toString() {
		return "umbr: "+this.uMbr+" - uacct: "+this.uAcCt+" - usubact: "+this.uSubAc+" - usgrp: "+this.uSGrp+" - ugcm: "+this.uGcm+" - scenario: "+this.tipo+" - stid: "+this.stId;
	}

}
