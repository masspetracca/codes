package it.ccg.pamp.server.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.TreeSet;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.ibm.ws.objectManager.Iterator;

public class SFTPUpload {
/*	
	private final Properties prop = new Properties();
	private final static String propertyPath = System.getProperty("user.install.root")+"/properties/ftpConfig.properties";
	
	private JSch jsch;
	private Session session;
	private ChannelSftp sftpChannel;
	
	private static final String SERVER_URL_PROP_NAME ="hostName";
	private static final String USER_PROP_NAME ="ftpUser";
	private static final String PWD_PROP_NAME = "password";
	private static final String WORKING_DIR_DOWN_PROP_NAME = "reutersWorkingDirDown";
	private static final String WORKING_DIR_UP_PROP_NAME = "testWorkingDirUP";
	private final static int UPLOAD = 1;
	private final static int DOWNLOAD = 2;
	
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public SFTPUpload() throws Exception {
		try {
			log.debug("load properties");
			prop.load(new FileInputStream(propertyPath));
		} catch (FileNotFoundException e) {
			log.error(e.getMessage());
			throw e;
		} catch (IOException e) {
			log.error(e.getMessage());
			throw e;
		}
	}
	
	*//**
	 * Method that open sftp connection
	 * @throws Exception
	 *//*
	private void openConnection(String directory) throws Exception {
		
		try{
		jsch = new JSch();
		session = jsch.getSession(prop.getProperty(SFTPUpload.USER_PROP_NAME), prop.getProperty(SFTPUpload.SERVER_URL_PROP_NAME));
		session.setPassword(prop.getProperty(SFTPUpload.PWD_PROP_NAME));
		
		 * Ignore host key
		 
		Properties config = new Properties(); 
		config.put("StrictHostKeyChecking", "no");
		session.setConfig(config);

		session.connect();
		
		sftpChannel = (ChannelSftp) session.openChannel("sftp");
		sftpChannel.connect();
		log.debug("sftpChannel connected");
		sftpChannel.cd(directory);
		if (sftpChannel.isConnected()){
			log.debug("connectd");
		}else{
			log.error("Connection refused");
			throw new Exception("Connection to "+prop.getProperty(SFTPUpload.SERVER_URL_PROP_NAME) +" refused");
		}
		}catch(JSchException ex){
			log.error(ex.getMessage());
			throw ex;
		}
	}
	
	*//**
	 * Method that close sftp connection
	 * @throws Exception
	 *//*
	private void closeConnection() throws Exception {
		log.debug("in closeConnection() throws Exception");
		log.debug("I'm closing the channel");
		sftpChannel.exit();
		log.debug("I'm disconnecting from session");
		if (session.isConnected()) 
			session.disconnect();
		//end if
		log.debug("everything went well");
		sftpChannel=null;
		session = null;
		jsch=null;
		log.debug("everything is ready for GC");
	}
	
	
	public boolean uploadFile(FileInputStream inFile, String fileName) throws Exception {
		log.debug("in boolean uploadFile(FileInputStream inFile,String fileName) throws Exception");
		try {
			log.debug("open connection");
			this.openConnection(prop.getProperty(SFTPUpload.WORKING_DIR_UP_PROP_NAME));
			log.debug("connection openend");
			log.debug(sftpChannel.pwd());
			sftpChannel.put(inFile, fileName);
			return true;
		} catch (SftpException e) {
			log.error(e.getMessage());
			throw e;
		}finally{
			this.closeConnection();
		}
	}
	
	
	
	public void downloadFile(String fileName, FileOutputStream out) throws Exception {
		log.debug("in void downloadFile(String fileName, FileOutputStream out) throws Exception");
		try {
			log.debug("open connection");
			this.openConnection(prop.getProperty(SFTPUpload.WORKING_DIR_DOWN_PROP_NAME));
			log.debug("connection openend");
			sftpChannel.get(fileName, out);
		} catch (SftpException e) {
			log.error(e.getMessage());
			throw e;
		}finally{
			this.closeConnection();
		}
	}

	
	public void downloadLatestFile(FileOutputStream out) throws Exception {
		log.debug("in void downloadLatestFile(FileOutputStream out) throws Exception");
		try {
			log.debug("open connection");
			this.openConnection(prop.getProperty(SFTPUpload.WORKING_DIR_DOWN_PROP_NAME));
			log.debug("connection openend");
			log.debug("instantiate a treeset to order FTPFile");
			TreeSet<ChannelSftp.LsEntry> ordainedFile = new TreeSet<ChannelSftp.LsEntry>(new CompareChannelSftpLsEntryFileTime());
			log.debug("treeset instantiated");
			Vector<ChannelSftp.LsEntry> fiels = sftpChannel.ls(".");
			Iterator<ChannelSftp.LsEntry> it = fiels.iterator();
			
			 * check if the actual list's file is a csv..if yes I add to tree  
			 
			while (it.hasNext()){
				ChannelSftp.LsEntry entry = (LsEntry) it.next();
				if (entry.getFilename().endsWith(".csv"))
					ordainedFile.add(entry);
			}
			log.debug("latest file on FTPFolder: "+ordainedFile.last().getFilename());
				
			log.debug("get latest file");
			sftpChannel.get(ordainedFile.last().getFilename(), out);
		} catch (IOException e) {
			log.error(e.getMessage());
			throw e;
		}finally{
			this.closeConnection();
		}
	}

	
	public boolean fileIsPrenset(String fileName) throws Exception {
		log.debug("in boolean fileIsPrenset(String fileName)");
		try {
			log.debug("open connection");
			this.openConnection(prop.getProperty(SFTPUpload.WORKING_DIR_DOWN_PROP_NAME));
			log.debug("connection openened");
			Vector<ChannelSftp.LsEntry> fiels = sftpChannel.ls(".");
			Iterator<ChannelSftp.LsEntry> it = fiels.iterator();
			while (it.hasNext()){
				ChannelSftp.LsEntry entry = (LsEntry) it.next();
				if (entry.getFilename().equals(fileName))
					return true;
			}
		} catch (SftpException e) {
			log.error(e.getMessage());
			throw e;
		}finally{
			this.closeConnection();
		}
		return false;
	}*/
}
