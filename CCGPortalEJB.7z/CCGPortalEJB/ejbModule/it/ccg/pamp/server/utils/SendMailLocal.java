package it.ccg.pamp.server.utils;

import java.io.File;

import it.ccg.pamp.server.exceptions.PropertyException;


public interface SendMailLocal {
	public void sendMail(String userFrom, String userTo[], String[] userCC, String msgSubject,String msgBody,File[] attachments, int notifyId);
}
