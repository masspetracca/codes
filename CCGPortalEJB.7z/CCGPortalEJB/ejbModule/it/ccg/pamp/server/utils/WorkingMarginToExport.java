package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

public class WorkingMarginToExport {
	
	private String isinCode;
	
	public String getIsinCode() {
		return isinCode;
	}

	public void setIsinCode(String isinCode) {
		if (isinCode.trim().equalsIgnoreCase("")||isinCode==null) {
			this.isinCode = "#N/A";
		} else {
			this.isinCode = isinCode;
		}
	}

	public BigDecimal getMargin() {
		return margin;
	}

	public void setMargin(BigDecimal margin) {
		this.margin = margin;
	}

	private BigDecimal margin;

}
