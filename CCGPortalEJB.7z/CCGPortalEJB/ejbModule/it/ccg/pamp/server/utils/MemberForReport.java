package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

public class MemberForReport {

	private int rank;
	
	private String scenario;
	
	private int stId;
	
	private int mbrId;
	
	private int gMbrId;
	
	private String mbrDesc;
	
	private BigDecimal firmInitialMargin;
	
	private BigDecimal clientInitialMargin;
	
	private BigDecimal firmCashcall;
	
	private BigDecimal clientCashCall;
	
	private BigDecimal nce;
	
	private BigDecimal cum;
	
	private BigDecimal rCum;
	
	private BigDecimal globalSum;
	
	private int nceCount;
	
	private int mbrCount;
	
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public String getScenario() {
		return scenario;
	}
	public void setScenario(String scenario) {
		this.scenario = scenario;
	}
	public int getStId() {
		return stId;
	}
	public void setStId(int stId) {
		this.stId = stId;
	}
	public int getMbrId() {
		return mbrId;
	}
	public void setMbrId(int mbrId) {
		this.mbrId = mbrId;
	}
	public String getMbrDesc() {
		return mbrDesc;
	}
	public void setMbrDesc(String mbrDesc) {
		this.mbrDesc = mbrDesc;
	}
	public BigDecimal getFirmInitialMargin() {
		return firmInitialMargin;
	}
	public void setFirmInitialMargin(BigDecimal firmInitialMargin) {
		this.firmInitialMargin = firmInitialMargin;
	}
	public BigDecimal getClientInitialMargin() {
		return clientInitialMargin;
	}
	public void setClientInitialMargin(BigDecimal clientInitialMargin) {
		this.clientInitialMargin = clientInitialMargin;
	}
	public BigDecimal getFirmCashcall() {
		return firmCashcall;
	}
	public void setFirmCashcall(BigDecimal firmCashcall) {
		this.firmCashcall = firmCashcall;
	}
	public BigDecimal getClientCashCall() {
		return clientCashCall;
	}
	public void setClientCashCall(BigDecimal clientCashCall) {
		this.clientCashCall = clientCashCall;
	}
	public BigDecimal getNce() {
		return nce;
	}
	public void setNce(BigDecimal nce) {
		this.nce = nce;
	}
	public BigDecimal getCum() {
		return cum;
	}
	public void setCum(BigDecimal cum) {
		this.cum = cum;
	}
	public BigDecimal getRcum() {
		return rCum;
	}
	public void setRcum(BigDecimal rCum) {
		this.rCum = rCum;
	}
	public BigDecimal getGlobalSum() {
		return globalSum;
	}
	public void setGlobalSum(BigDecimal globalSum) {
		this.globalSum = globalSum;
	}
	public void setgMbrId(int gMbrId) {
		this.gMbrId = gMbrId;
	}
	public int getgMbrId() {
		return gMbrId;
	}
	
	public int getNceCount() {
		return nceCount;
	}
	public void setNceCount(int nceCount) {
		this.nceCount = nceCount;
	}
	public int getMbrCount() {
		return mbrCount;
	}
	public void setMbrCount(int mbrCount) {
		this.mbrCount = mbrCount;
	}
	
	
	
}
