package it.ccg.pamp.server.utils;

public class OptionShift {

	private int shiftIndex, normATMIndex, stressATMIndex;

	public OptionShift() {
		super();
	}

	public OptionShift(int shiftIndex, int normATMIndex, int stressATMIndex) {
		super();
		this.shiftIndex = shiftIndex;
		this.normATMIndex = normATMIndex;
		this.stressATMIndex = stressATMIndex;
	}

	public int getShiftIndex() {
		return shiftIndex;
	}

	public void setShiftIndex(int shiftIndex) {
		this.shiftIndex = shiftIndex;
	}

	public int getNormATMIndex() {
		return normATMIndex;
	}

	public void setNormATMIndex(int normATMIndex) {
		this.normATMIndex = normATMIndex;
	}

	public int getStressATMIndex() {
		return stressATMIndex;
	}

	public void setStressATMIndex(int stressATMIndex) {
		this.stressATMIndex = stressATMIndex;
	}

	
	
	
}
