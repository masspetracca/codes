package it.ccg.pamp.server.utils;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class HistoricalPricesForBonds {
private static final long serialVersionUID = 1L;
	
	private int irNode;
	private Timestamp priceDate;
	private BigDecimal closePrice;
	private String irNodeDesc;
		private BigDecimal ave20;
		private BigDecimal ave250;
		private BigDecimal stDev20;
		private BigDecimal stDev250;
	
	
	public HistoricalPricesForBonds() {
		super();
	}
	
	public HistoricalPricesForBonds(int irNode,String irNodeDesc, Timestamp priceDate, BigDecimal closePrice, BigDecimal ave20, BigDecimal ave250, BigDecimal stDev20, BigDecimal stDev250) {
		super();
		this.irNode = irNode;
		this.irNodeDesc = irNodeDesc;
		this.priceDate = priceDate;
		this.closePrice = closePrice;
		this.ave20 = ave20;
		this.ave250 = ave250;
		this.stDev20 = stDev20;
		this.stDev250 = stDev250;
	}
	
	public int getIrNode() {
		return irNode;
	}

	public void setIrNode(int irNode) {
		this.irNode = irNode;
	}

	public String getIrNodeDesc() {
		return irNodeDesc;
	}

	public void setIrNodeDesc(String irNodeDesc) {
		this.irNodeDesc = irNodeDesc;
	}
	
	public Timestamp getPriceDate() {
		return priceDate;
	}

	public void setPriceDate(Timestamp priceDate) {
		this.priceDate = priceDate;
	}

	public BigDecimal getClosePrice() {
		return closePrice;
	}

	public void setClosePrice(BigDecimal closePrice) {
		this.closePrice = closePrice;
	}

	public BigDecimal getAve20() {
		return ave20;
	}

	public void setAve20(BigDecimal ave20) {
		this.ave20 = ave20;
	}

	public BigDecimal getAve250() {
		return ave250;
	}

	public void setAve250(BigDecimal ave250) {
		this.ave250 = ave250;
	}

	public BigDecimal getStDev20() {
		return stDev20;
	}

	public void setStDev20(BigDecimal stDev20) {
		this.stDev20 = stDev20;
	}

	public BigDecimal getStDev250() {
		return stDev250;
	}

	public void setStDev250(BigDecimal stDev250) {
		this.stDev250 = stDev250;
	}
	


}
