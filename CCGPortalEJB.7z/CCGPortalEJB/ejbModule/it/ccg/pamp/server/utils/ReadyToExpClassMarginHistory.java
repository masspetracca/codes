package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.entities.ClassMarginHistory;

import java.util.Vector;

public class ReadyToExpClassMarginHistory {
	private ClassMarginHistory clMarHist;
	private BondClass bondClass;
	private Vector<ClassIdTrascodePlus> classTcPlusVec;
	
	
	
	
	public ReadyToExpClassMarginHistory() {
		super();
	}




	public ReadyToExpClassMarginHistory(ClassMarginHistory clMarHist, BondClass bondClass, Vector<ClassIdTrascodePlus> classTcPlusVec) {
		super();
		this.clMarHist = clMarHist;
		this.bondClass = bondClass;
		this.classTcPlusVec = classTcPlusVec;
	}




	public ClassMarginHistory getClMarHist() {
		return clMarHist;
	}




	public void setClMarHist(ClassMarginHistory clMarHist) {
		this.clMarHist = clMarHist;
	}




	public BondClass getBondClass() {
		return bondClass;
	}




	public void setBondClass(BondClass bondClass) {
		this.bondClass = bondClass;
	}




	public Vector<ClassIdTrascodePlus> getClassTcPlusVec() {
		return classTcPlusVec;
	}




	public void setClassTcPlusVec(Vector<ClassIdTrascodePlus> classTcPlusVec) {
		this.classTcPlusVec = classTcPlusVec;
	}
}
