package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

public class BondDeltaYield {

	BigDecimal stressedIR;
	BigDecimal normalIR;
	
	
	
	public BondDeltaYield() {
		super();
	
	}

	public BondDeltaYield(BigDecimal stressedIR, BigDecimal normalIR) {
		super();
		this.stressedIR = stressedIR;
		this.normalIR = normalIR;
	}

	public BigDecimal getStressedIR() {
		return stressedIR;
	}

	public void setStressedIR(BigDecimal stressedIR) {
		this.stressedIR = stressedIR;
	}

	public BigDecimal getNormalIR() {
		return normalIR;
	}

	public void setNormalIR(BigDecimal normalIR) {
		this.normalIR = normalIR;
	}
	

	
	
	
}
