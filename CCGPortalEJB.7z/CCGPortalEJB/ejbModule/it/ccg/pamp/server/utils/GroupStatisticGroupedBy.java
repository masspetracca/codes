package it.ccg.pamp.server.utils;

import java.io.Serializable;
import java.math.BigDecimal;

public class GroupStatisticGroupedBy implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int instrId1, instrId2;
	private BigDecimal correl;
	private BigDecimal pearson;
	private BigDecimal divundiv;
	private int histDays;
	
	public GroupStatisticGroupedBy(int instrId1, int instrId2, BigDecimal correl,BigDecimal pearson,BigDecimal divundiv,int histDays) {
		super();
		this.setInstrId1(instrId1);
		this.setInstrId2(instrId2);
		this.setCorrel(correl);
		this.setPearson(pearson);
		this.setDivundiv(divundiv);
		this.setHistDays(histDays);
		//this.setID = setID;
	}

	public void setInstrId1(int instrId1) {
		this.instrId1 = instrId1;
	}

	public int getInstrId1() {
		return instrId1;
	}

	public void setInstrId2(int instrId2) {
		this.instrId2 = instrId2;
	}

	public int getInstrId2() {
		return instrId2;
	}

	public void setCorrel(BigDecimal correl) {
		this.correl = correl;
	}

	public BigDecimal getCorrel() {
		return correl;
	}

	public void setPearson(BigDecimal pearson) {
		this.pearson = pearson;
	}

	public BigDecimal getPearson() {
		return pearson;
	}

	public void setDivundiv(BigDecimal divundiv) {
		this.divundiv = divundiv;
	}

	public BigDecimal getDivundiv() {
		return divundiv;
	}

	public void setHistDays(int histDays) {
		this.histDays = histDays;
	}

	public int getHistDays() {
		return histDays;
	}

	@Override
	public String toString() {
		return "GroupStatistic: instrId1=" + instrId1 + ", instrId2=" + instrId2 + ", correl=" + correl + ", pearson=" + pearson + ", divundiv=" + divundiv + ", histDays=" + histDays;
	}
	
	
	
	
	
}
