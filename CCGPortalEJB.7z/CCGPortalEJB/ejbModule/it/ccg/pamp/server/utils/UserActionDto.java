package it.ccg.pamp.server.utils;

import java.io.Serializable;
import java.util.GregorianCalendar;

public class UserActionDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4489040638694850101L;
	
	private String user;
	private String action;
	private GregorianCalendar actionDate;
	private String stringActionDate;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public GregorianCalendar getActionDate() {
		return actionDate;
	}
	public void setActionDate(GregorianCalendar actionDate) {
		this.actionDate = actionDate;
	}
	public String getStringActionDate() {
		return stringActionDate;
	}
	public void setStringActionDate(String stringActionDate) {
		this.stringActionDate = stringActionDate;
	}
}
