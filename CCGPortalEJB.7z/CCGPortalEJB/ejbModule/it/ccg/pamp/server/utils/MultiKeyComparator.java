package it.ccg.pamp.server.utils;

import java.util.Comparator;

public class MultiKeyComparator implements Comparator<MultiKey> {

	@Override
	public int compare(MultiKey mk1, MultiKey mk2) {
		int nv1=(Integer) mk1.getKey(0);
		int per1= (Integer) mk1.getKey(1);
		
		int nv2=(Integer) mk2.getKey(0);
		int per2= (Integer) mk2.getKey(1);
		
		int diffnv=nv1-nv2;
		
		if(diffnv!=0) return diffnv;
		else{
			int diffper=per1-per2;
			return diffper;
		}
	}

}
