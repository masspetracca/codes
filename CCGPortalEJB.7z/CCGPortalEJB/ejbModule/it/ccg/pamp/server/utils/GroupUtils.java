package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.eao.GroupEAOLocal;
import it.ccg.pamp.server.entities.Group;
import it.ccg.pamp.server.entities.GroupComponent;
import it.ccg.pamp.server.entities.GroupComponentPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class GroupUtils
 */
@Stateless
public class GroupUtils implements GroupUtilsLocal {
	
	@EJB
	GroupEAOLocal groupeao;

    /**
     * Default constructor. 
     */
    public GroupUtils() {
      
    }

    
public  boolean isAlreadyStored(Set<Integer> group) throws DataNotValidException{
	
	
	/*######################### da sostituire con il group fetch quando funzionante 
		Group[] storedGroups= new Group[1];
	
		Group grone= new Group();
		
		ArrayList<GroupComponent> grcomparr= new ArrayList<GroupComponent>();
		
		GroupComponent grcmp1= new GroupComponent();
		
		GroupComponentPK grcmp1pk= new GroupComponentPK();
		grcmp1pk.setInstrId(10008);
		
		grcmp1.setPk(grcmp1pk);

		grcomparr.add(grcmp1);

		
		GroupComponent grcmp2= new GroupComponent();
		GroupComponentPK grcmp2pk= new GroupComponentPK();
		grcmp2pk.setInstrId(10011);
		grcmp2.setPk(grcmp2pk);
		
		grcomparr.add(grcmp2);
		
		grone.setGroupComponent(grcomparr);
		
		storedGroups[0]=grone;
	 ############################################################*/
		
		
		
		Group[] storedGroups= groupeao.fetch();
		
		if (storedGroups==null) throw new DataNotValidException("Error retrieving groups");
		
		else{
		//scorro tutti i gruppi salvati
		for (Group saved:storedGroups){
			
			List<GroupComponent> groupstoredcomplist=saved.getGroupComponent();
			
			//se il gruppo corrente non ha la stessa dimensione di quello passato in arg passo al successivo
			if(groupstoredcomplist.size()!= group.size()) continue;
			
			//altrimenti comincio a scorrere i componenti per vedere se corrispondono
			else{
				
				boolean gruppouguale=true;

				//prendo i componenti del gruppo salvato
				for(GroupComponent gcstored: groupstoredcomplist){
					boolean presente= false;
					
					
					//scorro gli elementi del gruppo passato in argomento
					for(Integer instrid:group){
						
						//se trovo la corrispondenza lo segnalo e passo al componente successivo
						if(gcstored.getPk().getInstrId()== instrid.intValue()) {
							presente=true;
							break;
						}
						
						
					}
					
					if(!presente){
						gruppouguale= false;
						break;
					}
				}
				
				if(gruppouguale) return true;
				
			}
			
			
		}
		
		}
		
		
		//se ho scorso tutti i gruppi salvati senza averne trovato uno uguale a quello in arg ritorno false
		return false;
		
		
		
		
	}
    
}
