package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.BondClass;

import java.util.Arrays;

import java.util.Vector;

public class BondClassCouple {
	
	private int classID1, classID2;

	public BondClassCouple() {
		super();
		
	}

	public BondClassCouple(int classID1, int classID2) {
		super();
		this.classID1 = classID1;
		this.classID2 = classID2;
	}

	public int getClassID1() {
		return classID1;
	}

	public void setClassID1(int classID1) {
		this.classID1 = classID1;
	}

	public int getClassID2() {
		return classID2;
	}

	public void setClassID2(int classID2) {
		this.classID2 = classID2;
	}

	@SuppressWarnings("unchecked")
	public static Vector<BondClassCouple> getBondClassCouples(BondClass[] bondclassarr){
		
		Vector<BondClassCouple> bccvec= new Vector<BondClassCouple>();
		
		Arrays.sort(bondclassarr,new BondClassComparator());
		
		for(int a=0; a<bondclassarr.length; a++){
			
			for(int b=a+1 ; b<bondclassarr.length; b++){
		
				
					
					
					int classID1=bondclassarr[a].getClassId();
					int classID2=bondclassarr[b].getClassId();
					
					
					BondClassCouple ci= new BondClassCouple(classID1, classID2);
					//System.out.println("Couple  classID1 "+ classID1+" classID2 "+ classID2);
					bccvec.add(ci);
					
				
				
			}
		
		}
		
		return bccvec;
	}
	
	

}
