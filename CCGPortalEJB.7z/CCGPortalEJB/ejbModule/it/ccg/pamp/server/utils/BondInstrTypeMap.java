package it.ccg.pamp.server.utils;

import java.util.LinkedHashMap;

public class BondInstrTypeMap {

	
	private static LinkedHashMap<String,String> bondInstrTypeMap = new LinkedHashMap<String, String>();
	
	
	
	public static LinkedHashMap<String,String> getBondInstrTypeMap() {
		
		//LinkedHashMap<String,String> bondInstrTypeMap = new LinkedHashMap<String, String>();
		
		bondInstrTypeMap.put("BTPi", "BTPi");
		bondInstrTypeMap.put("BOT", "GOVIES");
		bondInstrTypeMap.put("CTP", "GOVIES");
		bondInstrTypeMap.put("CCT", "GOVIES");
		bondInstrTypeMap.put("CTZ", "GOVIES");
		bondInstrTypeMap.put("RET", "RET");
		
		return bondInstrTypeMap;
	}
	
	
	
	
	
}
