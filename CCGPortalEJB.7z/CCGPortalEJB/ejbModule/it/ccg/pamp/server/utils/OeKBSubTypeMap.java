package it.ccg.pamp.server.utils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/*
 *  OeKB Map for instrument subtype transocde
 * 
 */

public class OeKBSubTypeMap {
	
	// STOCKS
	final static String[] stockTranscodeArray = new String[] {"EC","EF","EP","ER","ES","EV","EM"};
	
	// BONDS
	final static String[] bondTranscodeArray = new String[] {"DB","DC","DM","DT","DW","DY"};
	
	// WARRANTS
	final static String[] warrantTranscodeArray = new String[] {"RW"};
	
	// RIGHTS
	final static String[] rightsTranscodeArray = new String[] {"RA","RM","RP","RS"};
	
	// ETF --> FUNDS
	final static String[] exchangeTradedFundTranscodeArray = new String[] {"EU"};
	
	// INV. FUNDS
	//final static String[] investmentFundTranscodeArray = new String[] {"MR"};
	
	// OTHER
	final static String[] otherTranscodeArray = new String[] {"MR","MM"};
	
	// New CFI Code list in which add the STOCK subtypes 
	public static List<String> cfiCodeList = new ArrayList<String>();
	
	// PAMP TRANSCODE 
	static String stockType = "A";
	static String bondType = "B";
	static String warrantType = "W";
	static String rightsType = "R";
	static String exchangeType = "ETF";
	static String othersType = "D";
	//static String othersType = "D";
	
	public static LinkedHashMap<String,String> trascodedSubTypeMap() {
		
		LinkedHashMap<String,String> trascodedSubTypeMap = new LinkedHashMap<String, String>();
			
		for (String originalString: stockTranscodeArray) {
			trascodedSubTypeMap.put(originalString, stockType);
			cfiCodeList.add(originalString);
		}
		
		for (String originalString: bondTranscodeArray) {
			trascodedSubTypeMap.put(originalString, bondType);
		}
		
		for (String originalString: warrantTranscodeArray) {
			trascodedSubTypeMap.put(originalString, warrantType);
		}
		
		for (String originalString: rightsTranscodeArray) {
			trascodedSubTypeMap.put(originalString, rightsType);
		}
		
		for (String originalString: exchangeTradedFundTranscodeArray) {
			trascodedSubTypeMap.put(originalString, exchangeType);
		}
		
		/*for (String originalString: investmentFundTranscodeArray) {
			trascodedSubTypeMap.put(originalString, investmentType);
		}*/
		
		for (String originalString: otherTranscodeArray) {
			trascodedSubTypeMap.put(originalString, othersType);
		}
		
		return trascodedSubTypeMap;
		
	}

}
