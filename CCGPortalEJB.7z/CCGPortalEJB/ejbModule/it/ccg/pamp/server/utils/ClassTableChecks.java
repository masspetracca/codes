package it.ccg.pamp.server.utils;

import java.io.Serializable;
import java.math.BigDecimal;

public class ClassTableChecks implements Serializable {
	private static final long serialVersionUID = 1L;

	private BigDecimal maxChgDateCheck;
	
	private BigDecimal groupCheck;
	
	private BigDecimal priceCheck;
	
	private BigDecimal marginCheck;
	
	public ClassTableChecks() {
		super();
	}
	
	public ClassTableChecks(BigDecimal maxChgDateCheck,BigDecimal groupCheck,BigDecimal priceCheck,BigDecimal marginCheck) {
		super();
		this.maxChgDateCheck = maxChgDateCheck;
		this.groupCheck = groupCheck;
		this.priceCheck = priceCheck;
		this.marginCheck = marginCheck;
	}
	
	public BigDecimal getMaxChgDateCheck() {
		return maxChgDateCheck;
	}

	public void setMaxChgDateCheck(BigDecimal maxChgDateCheck) {
		this.maxChgDateCheck = maxChgDateCheck;
	}

	public BigDecimal getGroupCheck() {
		return groupCheck;
	}

	public void setGroupCheck(BigDecimal groupCheck) {
		this.groupCheck = groupCheck;
	}

	public BigDecimal getPriceCheck() {
		return priceCheck;
	}

	public void setPriceCheck(BigDecimal priceCheck) {
		this.priceCheck = priceCheck;
	}

	public BigDecimal getMarginCheck() {
		return marginCheck;
	}

	public void setMarginCheck(BigDecimal marginCheck) {
		this.marginCheck = marginCheck;
	}
	
}
