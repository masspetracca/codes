package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.eao.NotifyUserEAOLocal;
import it.ccg.pamp.server.eao.UserEAOLocal;
import it.ccg.pamp.server.exceptions.PropertyException;
import it.ccg.pamp.server.properties.PropertiesEAOLocal;

import java.io.File;
import java.io.FileInputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;


@Stateless
public class SendMail implements SendMailLocal {
	private static final long serialVersionUID = 1L;
	
	@EJB 
	private UserEAOLocal userEAO;
	
	@EJB 
	private NotifyUserEAOLocal notUserEAO;
	
	@EJB 
	private PropertiesEAOLocal properties;
	
	/*public String from = "pampmailer@ccg.it";
	public String fromName = "PAMP SYSTEM";*/
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public void sendMail(String userFrom, String[] userTo, String[] userCC, String msgSubject,String msgBody,File[] attachments, int notifyId) {
		
		HashMap<String,String> propertyMap = new HashMap<String,String>();
		
		try {
			propertyMap = properties.getPropertyMap();
		} catch (PropertyException e) {
			e.getMessage();
		}
		String from = propertyMap.get("mailAddress");
		String fromName = propertyMap.get("mailAlias");
		
		String environmentName = "";
		
		//nome dell'ambiente
		if (propertyMap.get("environment")!=null)
			environmentName = propertyMap.get("environment");
		
		List<InternetAddress> ccList = new ArrayList<InternetAddress>();
		List<InternetAddress> userToList = new ArrayList<InternetAddress>(); 
		
		try {
			if (userFrom!=null) {
				from = userEAO.findByPrimaryKey(userFrom).getEmail();
				fromName = userEAO.findByPrimaryKey(userFrom).getSurName().trim()+","+userEAO.findByPrimaryKey(userFrom).getName().trim();
			}
			
			List<UserToNotify> notUsrList = new ArrayList<UserToNotify>();
			
			if (userTo!=null) {
				notUsrList = notUserEAO.getUserToNotifyListByUserNameAndNotifyId(userTo,notifyId);
			} else { 
				notUsrList = notUserEAO.getUserToNotifyListByNotifyId(notifyId);
			}
			
			boolean containsErrors = false;
			
			// controllo che la notifica contenga le tre parole chiave 
			if (msgSubject.contains("PAMP Alerter") || msgSubject.toLowerCase().contains("error") || msgSubject.toLowerCase().contains("failed") || msgSubject.toLowerCase().contains("terminated") || msgBody.toLowerCase().contains("error") || msgBody.toLowerCase().contains("failed") || msgBody.toLowerCase().contains("terminated")) {
				containsErrors = true;
			}
			
			// ciclo su tutti gli utenti che possono ricevere la notifica
			for (UserToNotify notUsr:notUsrList) {
				InternetAddress ia = new InternetAddress(notUsr.getEmail());
				//mail a tutti quelli che hanno la notifica abilitata e, in caso di errore, anche agli utenti che hanno abilitata solo la modifica dell'errore 
				if (notUsr.getNotify().equalsIgnoreCase("T") || (notUsr.getNotify().equalsIgnoreCase("E") && containsErrors)) {
					userToList.add(ia);
				} 
			}
			
			
		} catch (Exception e) {
			log.warn(e.getMessage());
		}
			
		if (userToList.size()>0) {
			//se c'� almeno un destinatario controllo la presenza di eventuali CC e creo la loro lista
			if (userCC!=null) {
				for (String cc:userCC) {
					try {
						if (userEAO.findByPrimaryKey(cc).getNotify().equalsIgnoreCase("T")) {
							InternetAddress ia;
							ia = new InternetAddress(userEAO.findByPrimaryKey(cc).getEmail());
							ccList.add(ia);
						} 
					} catch (Exception e) {
						log.warn(e.getMessage());
					}
				}
			}
		}
		
		Properties properties = new Properties();
		properties.put("mail.smtp.host", propertyMap.get("mail.smtp.host")); 
		properties.put("mail.smtp.port", propertyMap.get("mail.smtp.port"));
		Session session = Session.getDefaultInstance(properties, null);
		
		/*Properties mailProps = new Properties();
		 
		try {
			System.out.println("default property path: "+rootDirectory+propertyPath);
			mailProps.load(new FileInputStream(rootDirectory+propertyPath));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		Session session = Session.getDefaultInstance(mailProps, null);
		*/
		
		try {
			MimeMessage message = new MimeMessage(session);
			//mittente
			message.setFrom(new InternetAddress(from.trim(),fromName));
			
			//destinatario/destinatari ed eventuali cc
			InternetAddress[] usrToArray = new InternetAddress[userToList.size()];
			message.setRecipients(Message.RecipientType.TO, userToList.toArray(usrToArray));
			
			if (ccList.size()>0) {
				InternetAddress[] ccArray = new InternetAddress[ccList.size()];
				message.setRecipients(Message.RecipientType.CC, ccList.toArray(ccArray));
			}
			
			//oggetto e data
			message.setSubject(msgSubject);
			message.setSentDate(new Date());	
			
			// testo del messaggio
			MimeBodyPart messagePart = new MimeBodyPart();
			
			messagePart.setContent(this.htmlBody(msgBody, environmentName), "text/html");
			//messagePart.setText(msgBody);
			Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messagePart);
			
           
			// eventuali allegati
			if (attachments!=null) {
				for (File att:attachments) {
					MimeBodyPart attachmentPart = new MimeBodyPart();
					FileDataSource fileDataSource = new FileDataSource(att) {
					@Override
		            public String getContentType() {
						return "application/octet-stream";
					}
					};
					attachmentPart.setDataHandler(new DataHandler(fileDataSource));
					attachmentPart.setFileName(att.getName());
		            multipart.addBodyPart(attachmentPart);
				}
			}
             
            message.setContent(multipart);
            Transport.send(message);
            
		} catch (Exception e) {
			log.warn(e.getMessage());
		}
	}
	
	public String htmlBody(String msgBody, String environment) throws UnknownHostException {
		
		InetAddress thisIp =InetAddress.getLocalHost();
		
		if (!environment.equalsIgnoreCase(""))
			environment = " - Environment: <span class=\"host\">"+environment+"</span>";
			
		String host ="<br><br>Host System: <span class=\"host\">"+thisIp.getHostAddress()+"</span>"+environment+"<br>";
		
		String style = "<style>"+
						"body {"+
						"font-family: Arial;"+
						"font-size: 10pt;"+
						"}"+
						".host {"+
						"font-weight:bold"+
						"}"+
						"</style>";
		
		msgBody = "<p class=\"msgBody\">"+msgBody+"</p>";
		
		String htmlCode = style + msgBody + host;
		
		return htmlCode;
			
	}
}
