package it.ccg.pamp.server.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class PampRounder {
	/*Dove RoundingType= {"N" (nearest), "C" (ceiling), "F" (floor)}
	esempio rounding con N
	Return( RoundingPrecision*Round(value/RoundingPrecision))*/
	
	public static BigDecimal round(BigDecimal value, String roundingType, BigDecimal roundingPrecision){
		BigDecimal rounded=null;
				
		if(roundingType.equalsIgnoreCase("N"))
			rounded= value.divide(roundingPrecision, 0, RoundingMode.HALF_EVEN);
		
		if(roundingType.equalsIgnoreCase("C"))
			rounded= value.divide(roundingPrecision, 0, RoundingMode.CEILING);
		
		if(roundingType.equalsIgnoreCase("F"))
			rounded= value.divide(roundingPrecision, 0, RoundingMode.FLOOR);
		
		BigDecimal result=rounded.multiply(roundingPrecision);
		
	//	System.out.println("Rounder:   "+value+" ----> "+result);
		
		return result;
	}
	
	
	public static BigDecimal freqround(BigDecimal value, BigDecimal roundingPrecision){
		BigDecimal rounded=null;
				
		if(value.compareTo(new BigDecimal(0))==0)
			rounded=roundingPrecision.negate();
		else{
		if(value.compareTo(new BigDecimal(0))>0)
			rounded= value.divide(roundingPrecision, 0, RoundingMode.CEILING);
		else
			rounded= value.divide(roundingPrecision, 0, RoundingMode.FLOOR);
		}
		BigDecimal result=rounded.multiply(roundingPrecision);
		
	//	System.out.println("Rounder:   "+value+" ----> "+result);
		
		return result;
	}
	
	

}
