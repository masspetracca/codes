package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.entities.IntraclassOffsetHistory;

import java.util.Vector;

public class ReadyToExpIntraClassOffsetHistory {
	private IntraclassOffsetHistory clTraHist;
	private BondClass bondClass;
	private Vector<ClassIdTrascodePlus> classTcPlusVec;
	
	
	
	
	public ReadyToExpIntraClassOffsetHistory() {
		super();
		}




	public ReadyToExpIntraClassOffsetHistory(IntraclassOffsetHistory clTraHist, BondClass bondClass, Vector<ClassIdTrascodePlus> classTcPlusVec) {
		super();
		this.clTraHist = clTraHist;
		this.bondClass = bondClass;
		this.classTcPlusVec = classTcPlusVec;
	}
	
	
	public IntraclassOffsetHistory getClTraHist() {
		return clTraHist;
	}




	public void setClTraHist(IntraclassOffsetHistory clTraHist) {
		this.clTraHist = clTraHist;
	}




	public BondClass getBondClass() {
		return bondClass;
	}




	public void setBondClass(BondClass bondClass) {
		this.bondClass = bondClass;
	}




	public Vector<ClassIdTrascodePlus> getClassTcPlusVec() {
		return classTcPlusVec;
	}




	public void setClassTcPlusVec(Vector<ClassIdTrascodePlus> classTcPlusVec) {
		this.classTcPlusVec = classTcPlusVec;
	}
	
}
