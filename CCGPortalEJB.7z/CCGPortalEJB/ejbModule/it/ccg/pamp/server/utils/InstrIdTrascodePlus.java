package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

import it.ccg.pamp.server.entities.InstrIdTrascode;

public class InstrIdTrascodePlus {
	private InstrIdTrascode instrTC;
	private BigDecimal cashMinMar;
	private BigDecimal marTh;
	private InstrIdTrascode[] instrIdTCUND;
	private int undInstrId;
	


	public InstrIdTrascodePlus(InstrIdTrascode instrTC, BigDecimal cashMinMar, BigDecimal marTh, InstrIdTrascode[] instrIdTCUND, int undInstrId) {
		super();
		this.instrTC = instrTC;
		this.cashMinMar = cashMinMar;
		this.marTh = marTh;
		this.instrIdTCUND = instrIdTCUND;
		this.undInstrId = undInstrId;
	}

	public InstrIdTrascodePlus(InstrIdTrascode instrTC) {
		super();
		this.instrTC = instrTC;
	}
	
	

	public InstrIdTrascodePlus(InstrIdTrascode instrTC, int undInstrId) {
		super();
		this.instrTC = instrTC;
		this.undInstrId = undInstrId;
	}

	public InstrIdTrascode getInstrTC() {
		return instrTC;
	}

	public void setInstrTC(InstrIdTrascode instrTC) {
		this.instrTC = instrTC;
	}

	public BigDecimal getCashMinMar() {
		return cashMinMar;
	}

	public void setCashMinMar(BigDecimal cashMinMar) {
		this.cashMinMar = cashMinMar;
	}

	public BigDecimal getMarTh() {
		return marTh;
	}

	public void setMarTh(BigDecimal marTh) {
		this.marTh = marTh;
	}

	public InstrIdTrascode[] getInstrIdTCUND() {
		return instrIdTCUND;
	}

	public void setInstrIdTCUND(InstrIdTrascode[] instrIdTCUND) {
		this.instrIdTCUND = instrIdTCUND;
	}

	public int getUndInstrId() {
		return undInstrId;
	}

	public void setUndInstrId(int undInstrId) {
		this.undInstrId = undInstrId;
	}

	
	
	
	
	
	
	

}
