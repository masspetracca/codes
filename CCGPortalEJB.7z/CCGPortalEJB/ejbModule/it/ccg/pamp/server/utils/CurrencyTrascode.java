package it.ccg.pamp.server.utils;

import java.util.LinkedHashMap;

public class CurrencyTrascode {

	private LinkedHashMap<String,String> currencyHashMap;
	
	public CurrencyTrascode() {
		currencyHashMap=new LinkedHashMap<String,String>();
		currencyHashMap.put("IT","LIT");
		currencyHashMap.put("US","USD");
		currencyHashMap.put("EU","EUR");
		currencyHashMap.put("GB","GBP");
		currencyHashMap.put("NO","NOK");
		currencyHashMap.put("SE","SEK");
		currencyHashMap.put("CH","CHF");
		currencyHashMap.put("DK","DKK");
		currencyHashMap.put("CA","CAD");
		currencyHashMap.put("JP","JPY");
		currencyHashMap.put("IS","ISK");
		currencyHashMap.put("CZ","CZK");
		currencyHashMap.put("HU","HUF");
		currencyHashMap.put("RO","RON");
		currencyHashMap.put("AT","ATS");
		currencyHashMap.put("TR","TRY");

	}

	public LinkedHashMap<String, String> getCurrencyHashMap() {
		return currencyHashMap;
	}

	public void setCurrencyHashMap(LinkedHashMap<String, String> currencyHashMap) {
		this.currencyHashMap = currencyHashMap;
	}

}
