package it.ccg.pamp.server.utils;

public class MethodResult {
	private String division;
	private boolean successful;
	private String description;
	
	
	
	public MethodResult() {
		super();
	}



	public MethodResult(String division, boolean successful, String description) {
		super();
		this.division = division;
		this.successful = successful;
		this.description = description;
	}



	public String getDivision() {
		return division;
	}



	public void setDivision(String division) {
		this.division = division;
	}



	public boolean isSuccessful() {
		return successful;
	}



	public void setSuccessful(boolean successful) {
		this.successful = successful;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	
	
	
	

}
