package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.Variation;

import java.math.BigDecimal;

public class VariationPLUS {
	
	private BigDecimal closePrice, previousClosePrice;
	
	private Variation  variation;

	public VariationPLUS() {
		super();
	}

	public VariationPLUS(BigDecimal closePrice, BigDecimal previousClosePrice, Variation variation) {
		super();
		this.closePrice = closePrice;
		this.previousClosePrice = previousClosePrice;
		this.variation = variation;
	}

	public BigDecimal getClosePrice() {
		return closePrice;
	}

	public void setClosePrice(BigDecimal closePrice) {
		this.closePrice = closePrice;
	}

	public BigDecimal getPreviousClosePrice() {
		return previousClosePrice;
	}

	public void setPreviousClosePrice(BigDecimal previousClosePrice) {
		this.previousClosePrice = previousClosePrice;
	}

	public Variation getVariation() {
		return variation;
	}

	public void setVariation(Variation variation) {
		this.variation = variation;
	}
	
	
	

}
