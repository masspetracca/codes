package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

public class Cgmmkt00fJoined {

	private BigDecimal mexMem; 
	private BigDecimal mkgcmid;
	private String expr1 = "F";
	private String expr2 = "C"; 
	private String mFMnam;
	private String mMnem4;
	private int firstMkmktid;
	
	public Cgmmkt00fJoined() {
		super();
	}
	
	public Cgmmkt00fJoined(BigDecimal mexMem, BigDecimal mkgcmid, String expr1, String expr2, String mFMnam, String mMnem4, int firstMkmktid) {
		super();
		this.mexMem = mexMem;
		this.mkgcmid = mkgcmid;
		this.expr1 = expr1;
		this.expr2 = expr2;
		this.mFMnam = mFMnam;
		this.mMnem4 = mMnem4;
		this.firstMkmktid = firstMkmktid;
	}

	public BigDecimal getMexMem() {
		return mexMem;
	}

	public void setMexMem(BigDecimal mexMem) {
		this.mexMem = mexMem;
	}

	public BigDecimal getMkgcmid() {
		return mkgcmid;
	}

	public void setMkgcmid(BigDecimal mkgcmid) {
		this.mkgcmid = mkgcmid;
	}

	public String getExpr1() {
		return expr1;
	}

	public void setExpr1(String expr1) {
		this.expr1 = expr1;
	}

	public String getExpr2() {
		return expr2;
	}

	public void setExpr2(String expr2) {
		this.expr2 = expr2;
	}

	public String getmFMnam() {
		return mFMnam;
	}

	public void setmFMnam(String mFMnam) {
		this.mFMnam = mFMnam;
	}

	public String getmMnem4() {
		return mMnem4;
	}

	public void setmMnem4(String mMnem4) {
		this.mMnem4 = mMnem4;
	}

	public int getFirstMkmktid() {
		return firstMkmktid;
	}

	public void setFirstMkmktid(int firstMkmktid) {
		this.firstMkmktid = firstMkmktid;
	}
	
}
