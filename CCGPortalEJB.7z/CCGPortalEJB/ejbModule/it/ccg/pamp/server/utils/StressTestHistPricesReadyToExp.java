package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;

public class StressTestHistPricesReadyToExp {

	private StressTestHistPrice stressTestHP;
	
	private Instrument instrument;
	
	private InstrIdTrascode[] instrIdTC;
	
	private String lastExecutor;
	
	public StressTestHistPricesReadyToExp() {
		super();
	}
	
	public StressTestHistPricesReadyToExp(StressTestHistPrice stressedHP, Instrument instrument, InstrIdTrascode[] instrIdTC) {
		super();
		this.stressTestHP = stressedHP;
		this.instrument = instrument;
		this.instrIdTC = instrIdTC;
		
	}
	
	public StressTestHistPricesReadyToExp(StressTestHistPrice stressedHP, Instrument instrument, InstrIdTrascode[] instrIdTC, String lastExecutor) {
		super();
		this.stressTestHP = stressedHP;
		this.instrument = instrument;
		this.instrIdTC = instrIdTC;
		this.lastExecutor = lastExecutor;
		
	}
	

	public StressTestHistPrice getStressTestHP() {
		return stressTestHP;
	}

	public void setStressTestHP(StressTestHistPrice stressTestHP) {
		this.stressTestHP = stressTestHP;
	}

	public Instrument getInstrument() {
		return instrument;
	}

	public void setInstrument(Instrument instrument) {
		this.instrument = instrument;
	}

	public void setInstrIdTC(InstrIdTrascode[] instrIdTC) {
		this.instrIdTC = instrIdTC;
	}

	public InstrIdTrascode[] getInstrIdTC() {
		return instrIdTC;
	}

	public void setLastExecutor(String lastExecutor) {
		this.lastExecutor = lastExecutor;
	}

	public String getLastExecutor() {
		return lastExecutor;
	}

}
