package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.Vector;

public class BondCouple {

	private int instrID1, instrID2, classID1, classID2;

	public BondCouple() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BondCouple(int instrID1, int instrID2, int classID1, int classID2) {
		super();
		this.instrID1 = instrID1;
		this.instrID2 = instrID2;
		this.classID1 = classID1;
		this.classID2 = classID2;
	}

	public int getInstrID1() {
		return instrID1;
	}

	public void setInstrID1(int instrID1) {
		this.instrID1 = instrID1;
	}

	public int getInstrID2() {
		return instrID2;
	}

	public void setInstrID2(int instrID2) {
		this.instrID2 = instrID2;
	}

	public int getClassID1() {
		return classID1;
	}

	public void setClassID1(int classID1) {
		this.classID1 = classID1;
	}

	public int getClassID2() {
		return classID2;
	}

	public void setClassID2(int classID2) {
		this.classID2 = classID2;
	}

	public static Vector<BondCouple> getBondCouplesForSameList(Instrument[] instrarr) throws DataNotValidException {
		// BondClassComponent[] bondclasscompArr=null;
		Vector<BondCouple> corinstrvec = new Vector<BondCouple>();

		for (int a = 0; a < instrarr.length; a++) {

			for (int b = a + 1; b < instrarr.length; b++) {

				if (instrarr[a].getListName() == null) {
					throw new DataNotValidException("INSTRID " + instrarr[a].getInstrId() + ": I.R. Curve name not defined for this instrument, please specify one");
				}

				if (instrarr[b].getListName() == null) {
					throw new DataNotValidException("INSTRID " + instrarr[b].getInstrId() + ": I.R. Curve name not defined for this instrument, please specify one");
				}

				if (instrarr[a].getListName().trim().equalsIgnoreCase(instrarr[b].getListName().trim())) {
					int instrID1 = instrarr[a].getInstrId();
					int instrID2 = instrarr[b].getInstrId();

					int classID1 = instrarr[a].getBndClassId();
					int classID2 = instrarr[b].getBndClassId();

					BondCouple ci = new BondCouple(instrID1, instrID2, classID1, classID2);
					// System.out.println("Couple "+ instrID1 +" - "+instrID2
					// +" classID1 "+ classID1+" classID2 "+ classID2);
					corinstrvec.add(ci);

				}

			}

		}

		return corinstrvec;
	}
	
	
	
	public static Vector<BondCouple> getBondCouplesNOList(Instrument[] instrarr) throws DataNotValidException {
		// BondClassComponent[] bondclasscompArr=null;
		Vector<BondCouple> corinstrvec = new Vector<BondCouple>();

		for (int a = 0; a < instrarr.length; a++) {

			for (int b = a + 1; b < instrarr.length; b++) {

				
					int instrID1 = instrarr[a].getInstrId();
					int instrID2 = instrarr[b].getInstrId();

					int classID1 = instrarr[a].getBndClassId();
					int classID2 = instrarr[b].getBndClassId();

					BondCouple ci = new BondCouple(instrID1, instrID2, classID1, classID2);
					// System.out.println("Couple "+ instrID1 +" - "+instrID2
					// +" classID1 "+ classID1+" classID2 "+ classID2);
					corinstrvec.add(ci);

				

			}

		}

		return corinstrvec;
	}
	
	
	

	public static Vector<BondCouple> getBondCouplesForSameList(Instrument[] instrBondClassarr1, Instrument[] instrBondClassarr2) throws DataNotValidException {
		// BondClassComponent[] bondclasscompArr=null;
		Vector<BondCouple> corinstrvec = new Vector<BondCouple>();

		for (int a = 0; a < instrBondClassarr1.length; a++) {

			for (int b = 0; b < instrBondClassarr2.length; b++) {

				if (instrBondClassarr1[a].getListName() == null) {
					throw new DataNotValidException("INSTRID " + instrBondClassarr1[a].getInstrId() + ": I.R. Curve name not defined for this instrument, please specify one");
				}

				if (instrBondClassarr2[b].getListName() == null) {
					throw new DataNotValidException("INSTRID " + instrBondClassarr2[b].getInstrId() + ": I.R. Curve name not defined for this instrument, please specify one");
				}

				if (instrBondClassarr1[a].getListName().trim().equalsIgnoreCase(instrBondClassarr2[b].getListName().trim())) {
					int instrID1 = instrBondClassarr1[a].getInstrId();
					int instrID2 = instrBondClassarr2[b].getInstrId();

					int classID1 = instrBondClassarr1[a].getBndClassId();
					int classID2 = instrBondClassarr2[b].getBndClassId();

					BondCouple ci = new BondCouple(instrID1, instrID2, classID1, classID2);
					// System.out.println("Couple "+ instrID1 +" - "+instrID2
					// +" classID1 "+ classID1+" classID2 "+ classID2);
					corinstrvec.add(ci);

				}

			}

		}

		return corinstrvec;
	}

	public static Vector<BondCouple> getBondCouplesNOList(Instrument[] instrBondClassarr1, Instrument[] instrBondClassarr2) throws DataNotValidException {
		// BondClassComponent[] bondclasscompArr=null;
		Vector<BondCouple> corinstrvec = new Vector<BondCouple>();

		for (int a = 0; a < instrBondClassarr1.length; a++) {

			for (int b = 0; b < instrBondClassarr2.length; b++) {

				int instrID1 = instrBondClassarr1[a].getInstrId();
				int instrID2 = instrBondClassarr2[b].getInstrId();

				int classID1 = instrBondClassarr1[a].getBndClassId();
				int classID2 = instrBondClassarr2[b].getBndClassId();

				BondCouple ci = new BondCouple(instrID1, instrID2, classID1, classID2);
				// System.out.println("Couple "+ instrID1 +" - "+instrID2
				// +" classID1 "+ classID1+" classID2 "+ classID2);
				corinstrvec.add(ci);

			}

		}

		return corinstrvec;
	}

}
