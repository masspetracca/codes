package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

public class MemberMarginComposition {

	private int genMbrId;
	private BigDecimal ordinaryMargin;
	private BigDecimal mtmMargin;
	
	public MemberMarginComposition() {
		
	}

	public int getGenMbrId() {
		return genMbrId;
	}

	public void setGenMbrId(String genMbrId) {
		this.genMbrId = Integer.parseInt(genMbrId);
	}

	public BigDecimal getOrdinaryMargin() {
		return ordinaryMargin;
	}

	public void setOrdinaryMargin(BigDecimal ordinaryMargin) {
		this.ordinaryMargin = ordinaryMargin;
	}
	
	public BigDecimal getMtmMargin() {
		return mtmMargin;
	}

	public void setMtmMargin(BigDecimal mtmMargin) {
		this.mtmMargin = mtmMargin;
	}
	
}
