package it.ccg.pamp.server.utils;

public class ArrayTools {
	
	public static boolean contains(Integer[] intarr, int num){
		for (int cur: intarr){
			
			if(cur==num) return true;
			
		}
		
		return false;
		
		
		
	}

}
