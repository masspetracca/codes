package it.ccg.pamp.server.utils;

public class NumberOfErrorForCMCBatch {
	
	private int numberOfError;
	
	public NumberOfErrorForCMCBatch() {
		super();
	}
	
	public NumberOfErrorForCMCBatch(int numberOfError) {
		super();
		this.numberOfError = numberOfError;
	}

	public void setNumberOfError(int numberOfError) {
		this.numberOfError = numberOfError;
	}

	public int getNumberOfError() {
		return numberOfError;
	}

}
