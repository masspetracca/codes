package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

public class SuspectedEqMargins {
	
	private int instrID;
	private BigDecimal fixedMargin;
	
	public SuspectedEqMargins() {
		super();
	
	}

	public SuspectedEqMargins(int instrID, BigDecimal fixedMargin) {
		super();
		this.instrID = instrID;
		this.fixedMargin = fixedMargin;
	}

	public int getInstrID() {
		return instrID;
	}

	public void setInstrID(int instrID) {
		this.instrID = instrID;
	}

	public BigDecimal getFixedMargin() {
		return fixedMargin;
	}

	public void setFixedMargin(BigDecimal fixedMargin) {
		this.fixedMargin = fixedMargin;
	}
	
	
	
	
	

}
