package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.ClassIdTrascode;



public class ClassIdTrascodePlus {
	
	
	public ClassIdTrascodePlus() {
		super();
	}
	
	private ClassIdTrascode clTrascode;
	
	public ClassIdTrascodePlus(ClassIdTrascode clTrascode) {
		super();
		this.clTrascode = clTrascode;
	}
	
	public ClassIdTrascode getClTrascode() {
		return clTrascode;
	}

	public void setClTrascode(ClassIdTrascode clTrascode) {
		this.clTrascode = clTrascode;
	}
	
}
