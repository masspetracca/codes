package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

public class StradMinMarSimContainer {
	
	
	BigDecimal derMar;
	BigDecimal spotPrice;
	BigDecimal minMar;
	BigDecimal straddle;
	BigDecimal modPrice;
	BigDecimal modMinMar;
	BigDecimal modStraddle;
	
	public StradMinMarSimContainer() {
		super();
		this.derMar = new BigDecimal(0);
		this.spotPrice = new BigDecimal(0);
		this.minMar = new BigDecimal(0);
		this.straddle = new BigDecimal(0);
		this.modPrice = new BigDecimal(0);
		this.modMinMar = new BigDecimal(0);
		this.modStraddle = new BigDecimal(0);
	}

	public StradMinMarSimContainer(BigDecimal derMar, BigDecimal spotPrice, BigDecimal minMar, BigDecimal straddle, BigDecimal modPrice, BigDecimal modMinMar, BigDecimal modStraddle) {
		super();
		this.derMar = derMar;
		this.spotPrice = spotPrice;
		this.minMar = minMar;
		this.straddle = straddle;
		this.modPrice = modPrice;
		this.modMinMar = modMinMar;
		this.modStraddle = modStraddle;
	}

	public BigDecimal getDerMar() {
		return derMar;
	}

	public void setDerMar(BigDecimal derMar) {
		this.derMar = derMar;
	}

	public BigDecimal getSpotPrice() {
		return spotPrice;
	}

	public void setSpotPrice(BigDecimal spotPrice) {
		this.spotPrice = spotPrice;
	}

	public BigDecimal getMinMar() {
		return minMar;
	}

	public void setMinMar(BigDecimal minMar) {
		this.minMar = minMar;
	}

	public BigDecimal getStraddle() {
		return straddle;
	}

	public void setStraddle(BigDecimal straddle) {
		this.straddle = straddle;
	}

	public BigDecimal getModPrice() {
		return modPrice;
	}

	public void setModPrice(BigDecimal modPrice) {
		this.modPrice = modPrice;
	}

	public BigDecimal getModMinMar() {
		return modMinMar;
	}

	public void setModMinMar(BigDecimal modMinMar) {
		this.modMinMar = modMinMar;
	}

	public BigDecimal getModStraddle() {
		return modStraddle;
	}

	public void setModStraddle(BigDecimal modStraddle) {
		this.modStraddle = modStraddle;
	}

	@Override
	public String toString() {
		return "derMar=" + derMar + ", spotPrice=" + spotPrice + ", minMar=" + minMar + ", straddle=" + straddle + ", modPrice=" + modPrice + ", modMinMar=" + modMinMar
				+ ", modStraddle=" + modStraddle;
	}
	
	
	
	
}
