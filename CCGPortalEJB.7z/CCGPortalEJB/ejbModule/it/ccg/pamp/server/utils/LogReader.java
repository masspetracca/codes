package it.ccg.pamp.server.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class LogReader implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private final String rootdir="logs/pamp/";
	
	//private final String rootdir="C:/nelli/";
	
	private String date;
	
	private String msgType;
	
	private String msgText;
	
	private List<LogReader> logList;
	
	public LogReader() {
		super();
	}
	
	public LogReader(String fileName, int rowNumber, boolean reverseOrder) throws Exception {
		super();
		this.logList = readLogFile(fileName,rowNumber,reverseOrder);
	}
	
	public LogReader(String fileName, int lastDays, Timestamp fromDate, Timestamp toDate, String fromTime, String toTime, String onlyMsgType, int maxRowNumber, boolean reverseOrder) throws Exception {
		super();
		if (lastDays==0&&fromDate==null&&toDate==null&&fromTime==null&&toTime==null&&onlyMsgType==null) {
			this.logList = readLogFile(fileName,maxRowNumber,reverseOrder);
		} else {
			this.logList = readLogFile(fileName,lastDays, fromDate, toDate, fromTime, toTime, onlyMsgType, maxRowNumber,reverseOrder);
		}
	}
	
	public List<LogReader> readLogFile(String fileName,int rowNumber, boolean reverseOrder) throws Exception {
		List<LogReader> logReaderList = new ArrayList<LogReader>();
		
		int stackTraceLimit = 1;
		int countStackTraceLines=0;
		
		//leggo dal file
		FileReader fr = new FileReader(rootdir+fileName+".log");  
		BufferedReader in = new BufferedReader(fr);    
    	String linea = in.readLine();
    	//String lastMsgType = "";
    	
    	/*//inizio a scorrere
    	while ((linea!=null)) {
    		
    		LogReader logReader = new LogReader(); 
    		
    		// se trovo almeno un "|" significa che � la prima riga di ogni evento
    		// altrimenti vuol dire che sono sceso nella seconda riga del messaggio precedente
    		if (linea.indexOf("|")>0) {
    			//azzero il contatore dello stackTrace
    			countStackTraceLines = 0;
    			
    			String[] arrLog = linea.split("\\|");
    			
    			// data
    			logReader.setDate(arrLog[0]);
		    	
    			//tipo messaggio
    			logReader.setMsgType(arrLog[1].trim());
		    	
    			
    			String msgText = "";
    			if (arrLog[arrLog.length-1]!=null) {
    				msgText = arrLog[arrLog.length-1];
    			}
    			// testo messaggio
    			logReader.setMsgText(msgText);
		    	
    			//aggiungo alla lista
    			logReaderList.add(logReader);
		    	
    			//ultimo tipo messaggio
    			lastMsgType = arrLog[1].trim();
	    	} else {
	    		
	    		// data vuota perch� � la seconda riga
	    		logReader.setDate("");
		    	
	    		//tipo messaggio settato con l'ultimo visto
	    		logReader.setMsgType(lastMsgType);
		    	
	    		//testo messaggio settato con l'ultimo valore della linea
	    		logReader.setMsgText(linea);
	    		
	    		//
	    		if (lastMsgType.equalsIgnoreCase("ERROR")) {
	    			if (countStackTraceLines<stackTraceLimit) {
	    				logReaderList.add(logReader);
	    			}
	    			countStackTraceLines++;
	    		} else {
	    			logReaderList.add(logReader);
	    		}
	    			
	    		
	    		if (logReaderList.size()>0) {
	    			rowNumber++;
	    		}
    		}
    		
    		
    		linea = in.readLine();
	    }*/
    	
    	
    	String msgText = "";
		
		String date = "";
		
		String msgType = "";
    	
		boolean fullLog = false;
		
    	//inizio a scorrere
    	while ((linea!=null)) {
    		
    		//inizializzo nuovo oggetto LogReader
    		LogReader logReader = new LogReader(); 
    		
    		// se trovo almeno un "|" significa che � la prima riga di ogni evento
    		if (linea.indexOf("|")>0) {
    			
    			//azzero il contatore dello stackTrace
    			countStackTraceLines = 0;
    			
    			//splitto la riga per memorizzarne le parti che mi interessano
    			String[] arrLog = linea.split("\\|");
    			
    			int len = arrLog.length;
    			
    			date = arrLog[0].trim();
    			
    			msgType = arrLog[1].trim();
    			
    			//controllo immediatamente il contenuto del messaggio
    			if (!(arrLog[len-1]==null && arrLog[len-1].equalsIgnoreCase(""))) {
    				msgText = arrLog[arrLog.length-1];
    			} 
    			
    			//nei casi diversi da ERROR considero la riga SEMPRE stampabile
    			if (!msgType.equalsIgnoreCase("ERROR")) {
    				fullLog = true;
    			}
    			
    		} else {
    			//solo nel caso di messaggio di errore mi predispongo per andare eventualmente a leggere le righe successive che non hanno il |
    			if (msgType.equalsIgnoreCase("ERROR") && (countStackTraceLines<stackTraceLimit) && !fullLog) {
    				
    				//in questo caso il testo del messaggio � l'intera linea
    				msgText = linea;
    				
    				// data
        			logReader.setDate(date);
        	    	
        			//tipo messaggio
        			logReader.setMsgType(msgType);
        	    	
        			// testo messaggio
        			logReader.setMsgText(msgText);
        			
        			//la riga � ora completa
        			fullLog = true;
    				
        			//incremento le righe di stackTrace gi� stampate
    				countStackTraceLines++;
    			}
    		}
    		
    		if (fullLog) {
	    		// data
				logReader.setDate(date);
		    	
				//tipo messaggio
				logReader.setMsgType(msgType);
		    	
				// testo messaggio
				logReader.setMsgText(msgText);
	    		
				//aggiungo alla lista
				logReaderList.add(logReader);
    		}
	    	
    		//azzero variabili per altro giro
			msgText = "";
			fullLog = false;
    	    		
    		linea = in.readLine();
	    }
    	
    	
    	
    	
    	
    	
    	fr.close();
    	
    	List<LogReader> newList = new ArrayList<LogReader>();
    	
    	if (!reverseOrder) {
	    	for (int i=Math.max(0,logReaderList.size()-rowNumber);i<logReaderList.size();i++) {
	    		newList.add(logReaderList.get(i));
	    	}
		} else {
			for (int i=logReaderList.size()-1;i>Math.max(-1,logReaderList.size()-1-rowNumber);i--) {
	    		newList.add(logReaderList.get(i));
	    	}
		}
    	
    	return newList;
	}
	
	
	public List<LogReader> readLogFile(String fileName,int lastDays, Timestamp fromDate, Timestamp toDate, String fromTime, String toTime, String onlyMsgType, int rowNumber, boolean reverseOrder) throws Exception {
		
		List<LogReader> logReaderList = new ArrayList<LogReader>();
		List<String> fileList = new ArrayList<String>();
		fileName+=".log";
				
    	
    	String dateForFileName ="";
    	int rowCounter=0;
		
    	//-----------CASO 1: lista dei file DEGLI ULTIMI n GIORNI da consultare-----------
    	
    	if (lastDays>0) {
    		fileList.add(fileName);
    		for (int i=0;i<lastDays;i++) {
    			dateForFileName = LogReaderFunctions.getDateForFileName(i+1);
    			fileList.add(fileName+"."+dateForFileName+".log");
    		}
    	}
    	
    	//-----------CASO 2: lista dei file DAL GIORNO x AL GIORNO y da consultare-----------
    	
    	if (fromDate!=null) {
    		//se la data di destinazione � vuota allora assumo come data finale la data di sistema e si ritorna al caso 1
    		if (toDate==null) {
    			toDate = GenericTools.systemDate();
    			fileList.add(fileName);
    			int dayDiff = LogReaderFunctions.dayDiff(fromDate, toDate);
        		for (int i=0;i<dayDiff;i++) {
        			dateForFileName = LogReaderFunctions.getDateForFileName(i+1);
        			fileList.add(fileName+"."+dateForFileName+".log");
        		}
    		} else {
    			
    			//conteggio la differenza tra toDate e fromDate
    			int dayDiff = LogReaderFunctions.dayDiff(fromDate, toDate);
    			//popolo la lista con l'array di date ottenuto
    			String startDate = fromDate.toString().substring(0,10);
    			// il nome del file sar� allora fileName.YYYY-MM.DD.log
    			fileList.add(fileName+"."+startDate);
    			for (int i=0;i<dayDiff;i++) {
    				String nextDate = LogReaderFunctions.giveMeNextDate(fromDate.toString().substring(0,10));
    				startDate = nextDate;
    				fileList.add(fileName+"."+startDate+".log");
    			}
    		}
    	}
    	
    	//se lastDays==0 && fromDate==null vuol dire che voglio SOLO il log di oggi, tutto oppure solo un determinato range orario
    	if (lastDays==0 && fromDate==null) {
    		fileList.add(fileName);
    	}
    	
    	int stackTraceLimit = 10;
		int countStackTraceLines=0;
    	
		boolean isExceptionRow = false;
		
		String lastMsgType = "";
		
		// INIZIO LA LETTURA DAL/DAI FILE
    	for (String file:fileList) {
    		File filePath = new File(rootdir+file);
    		if (filePath.isFile()) {
    			FileReader fr = new FileReader(rootdir+file);    
    			BufferedReader in = new BufferedReader(fr);    
	    		String linea = in.readLine();
	    		while ((linea!=null)) {
	    			
	    			LogReader logReader = new LogReader(); 
	    			
	    			if (linea.indexOf("|")>0) {
	    				isExceptionRow = false;//vuol dire che non ci sono eccezioni e posso quindi splittare per "|" e settare le propriet� del mio oggetto
	    				countStackTraceLines = 0;
		    			
	    				String[] arrLog = linea.split("\\|");//
		    			logReader.setMsgText(arrLog[arrLog.length-1].trim());
		    			logReader.setDate(arrLog[0].trim());
		    			logReader.setMsgType(arrLog[1].trim());
		    			lastMsgType = arrLog[1].trim();
			    	} else {
	    				if (countStackTraceLines<=stackTraceLimit) {
	    					isExceptionRow = true;	// altrimenti setto soltanto l'eccezione
	    					logReader.setMsgText(linea);
	    					logReader.setDate("");
	    			    	logReader.setMsgType("");
	    			    	
	    			    	countStackTraceLines++;
	    	    		}
			    		logReader.setDate("");
				    	logReader.setMsgType(lastMsgType);
				    	logReader.setMsgText(linea);
		    			if (lastMsgType.equalsIgnoreCase("ERROR") && (countStackTraceLines<=stackTraceLimit)) {
			    			countStackTraceLines++;
			    			isExceptionRow = true;
			    		} 
			    		//logReaderList.add(logReader);
			    		
			    	}
	    			
	    			boolean timeRangeIsValid = false;
	    			
	    			if (fromTime!=null&&!isExceptionRow) {
		    			String appoLong = linea.substring(11, 19).replace(":", ""); //mi creo una stringa di appoggio con gli orari presenti su ogni riga
	    				long startingTime = (long) Integer.parseInt(fromTime);
	    				
	    				if (appoLong.substring(0,1).equalsIgnoreCase("0")) {	// se � un'orario antecedente alle 10:00:00 allora tronco lo zero iniziale---> es. 07:43:00------>7:43:00
	    					appoLong = appoLong.substring(1);
	    				}
	    				
	    				long fileTime = (long) Integer.parseInt(appoLong);	// converto 7:43:00-------->74300
	    				
	    				if (toTime==null) {
	    					toTime = "235959";	// se non ho settato l'orario di fine allora prendo di default le 23:59:59 di quel giorno
	    				}
	    				
	    				long endingTime = (long) Integer.parseInt(toTime);
	    				
	    				if (fileTime>startingTime && fileTime<endingTime) {
	    					timeRangeIsValid = true;
	    				}
	    			}
    				
    				boolean isMsgTypeChoosen = false;
    				boolean allMsgTypeChoosen = true;
    				
    				if (onlyMsgType!=null && (logReader.getMsgType().equalsIgnoreCase(onlyMsgType))) {
    					isMsgTypeChoosen = true; // verifico il tipo di messaggio
    				}
    				
    				if (onlyMsgType!=null && !onlyMsgType.equalsIgnoreCase("INFO")) {
    					
    					if (onlyMsgType.equalsIgnoreCase("WARNING")) {
    						if (logReader.getMsgType().equalsIgnoreCase(onlyMsgType) || logReader.getMsgType().equalsIgnoreCase("ERROR")) {
    							isMsgTypeChoosen = true; // verifico il tipo di messaggio
    						}
    					}
    					
    					if (onlyMsgType.equalsIgnoreCase("ERROR")) {
    						if (logReader.getMsgType().equalsIgnoreCase(onlyMsgType)) {
    							isMsgTypeChoosen = true; // verifico il tipo di messaggio
    						}
    					}
    					allMsgTypeChoosen = false;
    				} 
	    			
	    			//controllo sul numero di righe
	    			//if ( (rowNumber>0&&rowCounter<rowNumber) || rowNumber==0) {
					//	CONTROLLO SU ORARI E TIPI DI MESSAGGIO -- 
					 //* se ho un orario di partenza E quella riga � compresa nel timerange 
					 
		    		if ( ((fromTime!=null && timeRangeIsValid) || fromTime==null) && (allMsgTypeChoosen || isMsgTypeChoosen) ) {
	    				logReaderList.add(logReader);
						rowCounter++;
	    			
			    	} else {
	    				break;
	    			}
	    			linea = in.readLine();
	    			
	    		}
	    		
	    		fr.close();
    		} 
    	}

    	for (int log=0;log<logReaderList.size();log++) {
    		if (logReaderList.get(log).getDate().equalsIgnoreCase("")&&logReaderList.get(log).getMsgText().equalsIgnoreCase("")) {
    			logReaderList.remove(log);
    		}
    	}
    	
    	/*TODO
    	 * leggere tutte le righe di log e prendere solo le prime N in senso ascendente o discendente oppure leggere solo le prime N righe del log e mostrarle in senso ascendente o discendente??? 
    	 * 
    	*/
    	
    	List<LogReader> newList = new ArrayList<LogReader>();
    	
    	if (rowNumber==0) {
    		rowNumber = logReaderList.size()+1;
    	}
    	
    	if (!reverseOrder) {
	    	for (int i=Math.max(0,logReaderList.size()-rowNumber);i<logReaderList.size();i++) {
	    		newList.add(logReaderList.get(i));
	    	}
    	} else {
    		for (int i=logReaderList.size()-1;i>Math.max(-1,logReaderList.size()-1-rowNumber);i--) {
	    		newList.add(logReaderList.get(i));
	    	}
    	}
    	
    	
    	
		return newList;
	}
	
	
	
	
	
	
	
	/*public String getDateForFileName(int lastDays) {
		String prevDate="";
		String sysDate = GenericTools.systemDate().toString();
		int todayYear = Integer.parseInt(sysDate.substring(0,4));
		int todayMonth = Integer.parseInt(sysDate.substring(5,7));
		int todayDay = Integer.parseInt(sysDate.substring(8,10));
		
    	GregorianCalendar calendar = new GregorianCalendar();
    	
    	int daysOfPrevMonth = 30; //numero base dei giorni del mese
    	
    	// se il giorno di oggi � minore del numero massimo di giorni richiesto
    	if (todayDay<=lastDays) {
    		
    		switch (todayMonth) {
    			case 1: case 2:	case 4: case 6: case 9: case 11:
    				if (todayMonth==1) {
	    				todayYear = todayYear-1; //torno indietro di un anno e di un mese se il mese � gennaio
	        			todayMonth = 12;
    				}
        			daysOfPrevMonth = 31;
    				break;
    			case 3:
    				daysOfPrevMonth = 28;
    				if (calendar.isLeapYear(todayYear)) {
    					daysOfPrevMonth = 29;
    				} 
    				break;
    			case 2:	case 4: case 6: case 9: case 11:
    				daysOfPrevMonth = 31;
    				break;
    		}
    		
    		todayDay = (todayDay+daysOfPrevMonth - lastDays);
			todayMonth = todayMonth-1;
    	
    	} else {
    		todayDay = (todayDay - lastDays);
    	}
    	
    	String day = Integer.toString(todayDay);
    	
    	if (todayDay<10) {
			day = "0"+todayDay;
		}
    	
    	String month = Integer.toString(todayMonth);
		
    	if (todayMonth<10) {
			month = "0"+todayMonth;
		}
    	
    	prevDate = Integer.toString(todayYear)+"-"+month+"-"+day;
		return prevDate;
	}
	
	
	public String giveMeNextDate(Timestamp fromDate) {
		
		int startDateDay = Integer.parseInt(fromDate.toString().substring(8,10));
		int startDateMonth = Integer.parseInt(fromDate.toString().substring(5,7));
		int startDateYear = Integer.parseInt(fromDate.toString().substring(0,4));
		
		GregorianCalendar calendar = new GregorianCalendar();
		
		int nextDateDay = 0;
		int nextDateMonth = 0;
		int nextDateYear = startDateYear;
    	
		// switch sui mesi dell'anno
		
		switch (startDateMonth) {
			// per ogni mese con 31 giorni verifico che il mese corrente non sia dicembre; 
			//se � dicembre faccio scattare l'incremento sull'anno altrimenti solo sul mese
			case 1: case 3:	case 5: case 7: case 8: case 10: case 12:
				if (startDateDay==31) {
					nextDateDay = 1;
					if (startDateMonth!=12) {
						nextDateMonth++;
					} else {
						nextDateMonth = 1;
						nextDateYear++;
					}
				} else {
					nextDateDay = startDateDay + 1;
				}
			break;
			
			// se il mese � febbraio faccio il controllo sul 28 o sul 29
			case 2:
				int februaryLastDay = 28;
				
				//anno bisestile
				if (calendar.isLeapYear(startDateYear)) {
					februaryLastDay = 29;
				}
				
				if (startDateDay==februaryLastDay) {
					nextDateDay = 1;
					nextDateMonth++;
				} else {
					nextDateDay = startDateDay + 1;
				}
				
			break;
			
			// per i mesi restanti faccio il controllo sul 30
			default:
				if (startDateDay==30) {
					nextDateDay = 1;
					nextDateMonth++;
				} else {
					nextDateDay = startDateDay + 1;
				}
		}
    	 
		String nextDay = Integer.toString(nextDateDay);
		String nextMonth = Integer.toString(nextDateMonth);
		String nextYear = Integer.toString(nextDateYear);
		
		if (nextDateDay<10) {
			nextDay = "0"+nextDay;
		}
		if (nextDateMonth<10) {
			nextMonth = "0"+nextMonth;
		}
		
    	String nextDate = nextYear+"-"+nextMonth+"-"+nextDay;
    	    	
		return nextDate;
	}
	
	public int dayDiff(Timestamp startDate,Timestamp toDate) {
		
		int startDateDay = Integer.parseInt(startDate.toString().substring(8,10));
		int startDateMonth = Integer.parseInt(startDate.toString().substring(5,7));
		int startDateYear = Integer.parseInt(startDate.toString().substring(0,4));
		
		int toDateDay = Integer.parseInt(toDate.toString().substring(8,10));
		int toDateMonth = Integer.parseInt(toDate.toString().substring(5,7));
		int toDateYear = Integer.parseInt(toDate.toString().substring(0,4));
		
		int dayDiff = 0;
		int monthDiff = 0;
		int yearDiff = 0;
		
		// controllo se l'anno di destinazione � successivo a quello di partenza
		if (toDateYear>startDateYear) {
			yearDiff = toDateYear  - startDateYear;	//es. startDate = 25/12/2010; toDate = 14/02/2011 ----> yearDiff = 1;
			
			if (toDateMonth < startDateMonth) {
				yearDiff = yearDiff - 1; //es. startDate = 25/12/2010; toDate = 14/02/2011 ----> yearDiff = 0;
				monthDiff = (12 - startDateMonth) + toDateMonth; //es. startDate = 25/12/2010; toDate = 14/02/2011 ----> monthDiff = 2;
			}
			if (toDateDay < startDateDay) {
				monthDiff = monthDiff - 1; //es. startDate = 25/12/2010; toDate = 14/02/2011 ----> monthDiff = 1;
			}
			
		} else {
			//se sono nello stesso anno faccio il controllo se il mese di destinazione � successivo a quello di partenza
			if (toDateMonth > startDateMonth) {
				monthDiff = toDateMonth  - startDateMonth; //es. startDate = 25/01/2010; toDate = 14/02/2011 ----> monthDiff = 1;
				if (toDateDay < startDateDay) {
					monthDiff = monthDiff - 1; //es. startDate = 25/01/2010; toDate = 14/02/2011 ----> monthDiff = 0;
				}
			}
		}
		
		dayDiff = (yearDiff*365)+(monthDiff*30)+1; //es. startDate = 25/12/2010; toDate = 14/02/2012 ----> totalDayDiff = [(1*365)+(1*30)+1)] = 396 ; 
		// per ora manca la differenza in giorno che c'� tra il 25 gennaio e il 14 febbraio
		
		Timestamp feb28th = new Timestamp(new GregorianCalendar(28,1,toDateYear).getTimeInMillis());
		
		//se nell'intervallo di tempo c'� un anno bisestile incremento di 1 giorno x ogni anno bisestile presente
		GregorianCalendar calendar = new GregorianCalendar();
		for (int i=0;i<yearDiff;i++) {
			if (calendar.isLeapYear(startDateYear+i)) {
				dayDiff++;
			}
		}
		
		if (calendar.isLeapYear(toDateYear) && toDate.compareTo(feb28th)<=0) {
			dayDiff--; // se l'anno di destinazione � bisestile e la data finale � ANTECEDENTE o UGUALE al 28 febbraio allora tolgo il giorno appena messo
		}
		
		//se la differenza in mesi � maggiore di zero allora
		if (monthDiff>0) {
			//incremento di un mese in tutti i casi eccetto dicembre
			if (startDateMonth!=12) {
				startDateMonth = startDateMonth+1;
			} else {
				//infatti se � dicembre riparto da gennaio (1) 
				startDateMonth = 1;
			}
		}
		
		int daysOfMonth = 30; // giorni base di un mese
		
		//completo la differenza in giorni che c'� tra startDate e il toDate verificando nei diversi mesi cosa aggiungere
		switch (startDateMonth) {
			case 1: case 3: case 5: case 7: case 8: case 10: case 12:
				daysOfMonth = 31; // mesi da 31 gg
				break;
			case 2:
	    		daysOfMonth = 28; // febbraio
				break;
		}
		
		dayDiff += daysOfMonth - startDateDay + toDateDay; 	////es. startDate = 25/01/2011; toDate = 14/02/2011 -----> 31-25+14 = 20; *resta escluso il giorno di partenza 
		 
		
		//se voglio comprendere anche il giorno di partenza
		//TODO
		dayDiff++;
		
		return dayDiff;
	}*/
	
	
	
	
	
	public void setDate(String date) {
		this.date = date.replaceAll(",", ".");
	}

	public String getDate() {
		return date.trim();
	}

	public void setMsgType(String msgType) {
		if (msgType.equalsIgnoreCase("WARN")) {
			msgType = "WARNING";
		}
		this.msgType = msgType;
	}

	public String getMsgType() {
		return msgType.trim();
	}

	public void setMsgText(String msgText) {
		this.msgText = msgText.trim();
	}

	public String getMsgText() {
		return msgText.trim();
	}

	public void setLogList(LogReader log) {
		this.logList.add(log) ;
	}
	
	public List<LogReader> getLogReaderList() {
		return logList;
	}
	
}
