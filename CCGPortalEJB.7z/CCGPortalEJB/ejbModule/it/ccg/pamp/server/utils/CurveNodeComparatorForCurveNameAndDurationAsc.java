package it.ccg.pamp.server.utils;

import java.util.Comparator;

/**
 * Comparatore che permette ordinamento dei nodi delle curve per nome curva  e duration
 * @author lamanna
 *
 */
public class CurveNodeComparatorForCurveNameAndDurationAsc implements	Comparator {

		
		public int compare(Object object1, Object object2) {
			CurveNode bc1= (CurveNode) object1;
			CurveNode bc2= (CurveNode) object2;
			
			int ritorno=bc1.getInstr().getDuration().compareTo(bc2.getInstr().getDuration());
		
			return ritorno;	
		}

}
