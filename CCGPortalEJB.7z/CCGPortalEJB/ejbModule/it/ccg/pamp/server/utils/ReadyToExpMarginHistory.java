package it.ccg.pamp.server.utils;

import java.util.Vector;

import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.MarginHistory;

public class ReadyToExpMarginHistory {
	
	private MarginHistory marhist;
	private Instrument instr;
	private Vector<InstrIdTrascodePlus> instrtcplusvec;
	
	
	
	
	public ReadyToExpMarginHistory() {
		super();
		}




	public ReadyToExpMarginHistory(MarginHistory marhist, Instrument instr, Vector<InstrIdTrascodePlus> instrtcplusvec) {
		super();
		this.marhist = marhist;
		this.instr = instr;
		this.instrtcplusvec = instrtcplusvec;
	}




	public MarginHistory getMarhist() {
		return marhist;
	}




	public void setMarhist(MarginHistory marhist) {
		this.marhist = marhist;
	}




	public Instrument getInstr() {
		return instr;
	}




	public void setInstr(Instrument instr) {
		this.instr = instr;
	}




	public Vector<InstrIdTrascodePlus> getInstrtcplusvec() {
		return instrtcplusvec;
	}




	public void setInstrtcplusvec(Vector<InstrIdTrascodePlus> instrtcplusvec) {
		this.instrtcplusvec = instrtcplusvec;
	}
	
	
	
	
	
	
	
	

}
