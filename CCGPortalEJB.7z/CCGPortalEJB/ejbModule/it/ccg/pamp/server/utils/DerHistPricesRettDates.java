package it.ccg.pamp.server.utils;

import java.io.Serializable;
import java.sql.Timestamp;

public class DerHistPricesRettDates implements Serializable {
	private static final long serialVersionUID = 1L;
	private Timestamp firstDate, lastDate;
	private int countDate;
	
	public DerHistPricesRettDates() {
		super();
	}
	
	public DerHistPricesRettDates(Timestamp firstDate, Timestamp lastDate) {
		super();
		this.firstDate = firstDate;
		this.lastDate = lastDate;
		//this.countDate = countDate;
	
	}

	public Timestamp getFirstDate() {
		return firstDate;
	}

	public void setFirstDate(Timestamp firstDate) {
		this.firstDate = firstDate;
	}

	public Timestamp getLastDate() {
		return lastDate;
	}

	public void setLastDate(Timestamp lastDate) {
		this.lastDate = lastDate;
	}
	
	public int getCountDate() {
		return countDate;
	}

	public void setCountDate(int countDate) {
		this.countDate = countDate;
	}
}
