package it.ccg.pamp.server.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.log4j.Logger;


public class FTPUpload {
	
	/*public FTPUpload(File localFile,String fileName) throws Exception {
		this.upload(localFile,fileName);
	}*/
	
	public static void upload(File localFile,String fileName, HashMap<String,String> propertyMap) throws Exception {
	    
		Logger appIntLog = Logger.getLogger("it.ccg.pamp.server.log.AppInt");
		
			
		
		//String propertyPath = System.getProperty("user.install.root")+"/properties/pamp.properties";
		
		//Properties prop = new Properties();
				 
		//prop.load(new FileInputStream(propertyPath));
		 
		String hostName =  propertyMap.get("FTPhostName");//prop.getProperty("hostName");
		String ftpUser = propertyMap.get("FTPuser");//prop.getProperty("FTPUser");
		String password =  propertyMap.get("FTPpassword");//prop.getProperty("FTPpassword");
		String ftpDirectory = propertyMap.get("FTPuploadDir");//prop.getProperty("FTPuploadDir");
		
		
		System.out.println(ftpUser+"-"+password);
		
		InputStream in = null;
		
		FTPClient ftp = new FTPClient();
		
		ftp.connect(hostName);
		
		ftp.login(ftpUser, password);
	 
		//ftp.setSoTimeout(15*1000);
		
		ftp.setFileType(FTP.BINARY_FILE_TYPE);
		
		
		ftp.changeWorkingDirectory(ftpDirectory);
	 
		appIntLog.info("remote report path: "+ftpDirectory);
		
		//InetAddress ia = InetAddress.getByName(hostName);
		
		//ftp.enterRemoteActiveMode(ia, 21);
		
		//TODO commentata il 12/07 per austria
		//ftp.enterLocalActiveMode();
		
		
		     
		
		//System.out.println("Received Reply from FTP Connection:" + ftp.getReplyString());
	 
		//appIntLog.info("Received Reply from " +hostName+":" + ftp.getReplyString());
		
		if(FTPReply.isPositiveCompletion(ftp.getReplyCode())){
								 
			File f1 = localFile;
			in = new FileInputStream(f1);
	 
			ftp.storeFile(fileName,in);
			
		} else {
			throw new Exception("Unable to connect to "+hostName+" - error "+ftp.getReplyCode());
		}
	 
		ftp.logout();
		ftp.disconnect();
	}

}


