package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.Variation;

import java.util.Comparator;

public class VariationDescComparator implements Comparator {

	
	public int compare(Object object1, Object object2) {
	Variation var1= (Variation) object1;
	Variation var2= (Variation) object2;
	
	return var2.getVariat().abs().compareTo(var1.getVariat().abs());	
	}

}
