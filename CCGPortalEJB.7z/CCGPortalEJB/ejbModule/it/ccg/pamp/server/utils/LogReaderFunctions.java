package it.ccg.pamp.server.utils;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class LogReaderFunctions {

	public LogReaderFunctions() {
		super();
	}

	
	public static String getDateForFileName(int lastDays) {
		String prevDate="";
		String sysDate = GenericTools.systemDate().toString();
		int todayYear = Integer.parseInt(sysDate.substring(0,4));
		int todayMonth = Integer.parseInt(sysDate.substring(5,7));
		int todayDay = Integer.parseInt(sysDate.substring(8,10));
		
    	GregorianCalendar calendar = new GregorianCalendar();
    	
    	int daysOfPrevMonth = 30; //numero base dei giorni del mese
    	
    	// se il giorno di oggi � minore del numero massimo di giorni richiesto
    	if (todayDay<=lastDays) {
    		
    		switch (todayMonth) {
    			case 1: case 2:	case 4: case 6: case 9: case 11:
    				if (todayMonth==1) {
	    				todayYear = todayYear-1; //torno indietro di un anno e di un mese se il mese � gennaio
	        			todayMonth = 12;
    				}
        			daysOfPrevMonth = 31;
    				break;
    			case 3:
    				daysOfPrevMonth = 28;
    				if (calendar.isLeapYear(todayYear)) {
    					daysOfPrevMonth = 29;
    				} 
    				break;
    			//case 2:	case 4: case 6: case 9: case 11:
    			//	daysOfPrevMonth = 31;
    			//	break;
    		}
    		
    		todayDay = (todayDay+daysOfPrevMonth - lastDays);
			todayMonth = todayMonth-1;
    	
    	} else {
    		todayDay = (todayDay - lastDays);
    	}
    	
    	String day = Integer.toString(todayDay);
    	
    	if (todayDay<10) {
			day = "0"+todayDay;
		}
    	
    	String month = Integer.toString(todayMonth);
		
    	if (todayMonth<10) {
			month = "0"+todayMonth;
		}
    	
    	prevDate = Integer.toString(todayYear)+"-"+month+"-"+day;
		return prevDate;
	}
	
	public static String giveMeNextDate(String fromDate) {
		
		int startDateDay = Integer.parseInt(fromDate.substring(8,10));
		int startDateMonth = Integer.parseInt(fromDate.substring(5,7));
		int startDateYear = Integer.parseInt(fromDate.substring(0,4));
		
		GregorianCalendar calendar = new GregorianCalendar();
		
		int nextDateDay = 0;
		int nextDateMonth = 0;
		int nextDateYear = startDateYear;
    	
		// switch sui mesi dell'anno
		
		switch (startDateMonth) {
			// per ogni mese con 31 giorni verifico che il mese corrente non sia dicembre; 
			//se � dicembre faccio scattare l'incremento sull'anno altrimenti solo sul mese
			case 1: case 3:	case 5: case 7: case 8: case 10: case 12:
				if (startDateDay==31) {
					nextDateDay = 1;
					if (startDateMonth!=12) {
						nextDateMonth++;
					} else {
						nextDateMonth = 1;
						nextDateYear++;
					}
				} else {
					nextDateDay = startDateDay + 1;
				}
			break;
			
			// se il mese � febbraio faccio il controllo sul 28 o sul 29
			case 2:
				int februaryLastDay = 28;
				
				//anno bisestile
				if (calendar.isLeapYear(startDateYear)) {
					februaryLastDay = 29;
				}
				
				if (startDateDay==februaryLastDay) {
					nextDateDay = 1;
					nextDateMonth++;
				} else {
					nextDateDay = startDateDay + 1;
				}
				
			break;
			
			// per i mesi restanti faccio il controllo sul 30
			default:
				if (startDateDay==30) {
					nextDateDay = 1;
					nextDateMonth++;
				} else {
					nextDateDay = startDateDay + 1;
				}
		}
    	 
		String nextDay = Integer.toString(nextDateDay);
		String nextMonth = Integer.toString(nextDateMonth);
		String nextYear = Integer.toString(nextDateYear);
		
		if (nextDateDay<10) {
			nextDay = "0"+nextDay;
		}
		if (nextDateMonth<10) {
			nextMonth = "0"+nextMonth;
		}
		
    	String nextDate = nextYear+"-"+nextMonth+"-"+nextDay;
    	    	
		return nextDate;
	}
	
	public static int dayDiff(Date startDate,Date toDate) {
		
		int startDateDay = Integer.parseInt(startDate.toString().substring(8,10));
		int startDateMonth = Integer.parseInt(startDate.toString().substring(5,7));
		int startDateYear = Integer.parseInt(startDate.toString().substring(0,4));
		
		int toDateDay = Integer.parseInt(toDate.toString().substring(8,10));
		int toDateMonth = Integer.parseInt(toDate.toString().substring(5,7));
		int toDateYear = Integer.parseInt(toDate.toString().substring(0,4));
		
		int dayDiff = 0;
		int monthDiff = 0;
		int yearDiff = 0;
		
		// controllo se l'anno di destinazione � successivo a quello di partenza
		if (toDateYear>startDateYear) {
			yearDiff = toDateYear  - startDateYear;	//es. startDate = 25/12/2010; toDate = 14/02/2011 ----> yearDiff = 1;
			
			if (toDateMonth < startDateMonth) {
				yearDiff = yearDiff - 1; //es. startDate = 25/12/2010; toDate = 14/02/2011 ----> yearDiff = 0;
				monthDiff = (12 - startDateMonth) + toDateMonth; //es. startDate = 25/12/2010; toDate = 14/02/2011 ----> monthDiff = 2;
			}
			if (toDateDay < startDateDay) {
				monthDiff = monthDiff - 1; //es. startDate = 25/12/2010; toDate = 14/02/2011 ----> monthDiff = 1;
			}
			
		} else {
			//se sono nello stesso anno faccio il controllo se il mese di destinazione � successivo a quello di partenza
			if (toDateMonth > startDateMonth) {
				monthDiff = toDateMonth  - startDateMonth; //es. startDate = 25/01/2010; toDate = 14/02/2011 ----> monthDiff = 1;
				if (toDateDay < startDateDay) {
					monthDiff = monthDiff - 1; //es. startDate = 25/01/2010; toDate = 14/02/2011 ----> monthDiff = 0;
				}
			}
		}
		
		dayDiff = (yearDiff*365)+(monthDiff*30)+1; //es. startDate = 25/12/2010; toDate = 14/02/2012 ----> totalDayDiff = [(1*365)+(1*30)+1)] = 396 ; 
		// per ora manca la differenza in giorno che c'� tra il 25 gennaio e il 14 febbraio
		
		Timestamp feb28th = new Timestamp(new GregorianCalendar(28,1,toDateYear).getTimeInMillis());
		
		//se nell'intervallo di tempo c'� un anno bisestile incremento di 1 giorno x ogni anno bisestile presente
		GregorianCalendar calendar = new GregorianCalendar();
		for (int i=0;i<yearDiff;i++) {
			if (calendar.isLeapYear(startDateYear+i)) {
				dayDiff++;
			}
		}
		
		if (calendar.isLeapYear(toDateYear) && toDate.compareTo(feb28th)<=0) {
			dayDiff--; // se l'anno di destinazione � bisestile e la data finale � ANTECEDENTE o UGUALE al 28 febbraio allora tolgo il giorno appena messo
		}
		
		//se la differenza in mesi � maggiore di zero allora
		if (monthDiff>0) {
			//incremento di un mese in tutti i casi eccetto dicembre
			if (startDateMonth!=12) {
				startDateMonth = startDateMonth+1;
			} else {
				//infatti se � dicembre riparto da gennaio (1) 
				startDateMonth = 1;
			}
		}
		
		int daysOfMonth = 30; // giorni base di un mese
		
		//completo la differenza in giorni che c'� tra startDate e il toDate verificando nei diversi mesi cosa aggiungere
		switch (startDateMonth) {
			case 1: case 3: case 5: case 7: case 8: case 10: case 12:
				daysOfMonth = 31; // mesi da 31 gg
				break;
			case 2:
	    		daysOfMonth = 28; // febbraio
				break;
		}
		
		dayDiff += daysOfMonth - startDateDay + toDateDay; 	////es. startDate = 25/01/2011; toDate = 14/02/2011 -----> 31-25+14 = 20; *resta escluso il giorno di partenza 
		 
		
		//se voglio comprendere anche il giorno di partenza
		//TODO
		dayDiff++;
		
		return dayDiff;
	}
	
	
	
	
}
