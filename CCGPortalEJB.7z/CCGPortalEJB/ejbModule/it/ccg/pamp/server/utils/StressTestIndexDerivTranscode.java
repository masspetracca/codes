package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;


public class StressTestIndexDerivTranscode {

	private Instrument derInstrument;
	
	private InstrIdTrascode[] instrIdTC;
	
	
	public StressTestIndexDerivTranscode() {
		super();
	}
	
	
	public StressTestIndexDerivTranscode(Instrument derInstrument, InstrIdTrascode[] instrIdTC) {
		super();
		this.derInstrument = derInstrument;
		this.instrIdTC = instrIdTC;
	}
	
	public Instrument getDerInstrument() {
		return derInstrument;
	}

	public void setDerInstrument(Instrument derInstrument) {
		this.derInstrument = derInstrument;
	}

	public InstrIdTrascode[] getInstrIdTC() {
		return instrIdTC;
	}

	public void setInstrIdTC(InstrIdTrascode[] instrIdTC) {
		this.instrIdTC = instrIdTC;
	}
	
	
	
}
