package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.stressTest.StressTestDerivativeHistPrice;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;

public class StressTestDerivativesHistPricesReadyToExp {

	private StressTestDerivativeHistPrice stressTestDerHP;
	
	private Instrument instr;
	
	private InstrIdTrascode[] instrIdTC;
	
	private InstrIdTrascode[] rectifiedClassArray;
	
	private StressTestHistPrice undCashStressTestHP;
	
	private BigDecimal volaCoeff;
	
	
	
	public StressTestDerivativesHistPricesReadyToExp() {
		super();
	}
	
	/*public StressTestDerivativesHistPricesReadyToExp(StressTestDerivativeHistPrice stressedDerHP, Instrument instr, InstrIdTrascode[] instrIdTC, StressTestHistPrice undCashStressTestHP, BigDecimal volaCoeff) {
		super();
		this.stressTestDerHP = stressedDerHP;
		this.instr = instr;
		this.instrIdTC = instrIdTC;
		this.undCashStressTestHP = undCashStressTestHP;
		this.volaCoeff = volaCoeff;
	}*/

	public StressTestDerivativesHistPricesReadyToExp(StressTestDerivativeHistPrice stressedDerHP, Instrument instr, InstrIdTrascode[] instrIdTC, InstrIdTrascode[] rectifiedClassArray, StressTestHistPrice undCashStressTestHP, BigDecimal volaCoeff) {
		super();
		this.stressTestDerHP = stressedDerHP;
		this.instr = instr;
		this.instrIdTC = instrIdTC;
		this.undCashStressTestHP = undCashStressTestHP;
		this.rectifiedClassArray = rectifiedClassArray;
		this.volaCoeff = volaCoeff;
	}
	
	public StressTestDerivativeHistPrice getStressTestDerHP() {
		return stressTestDerHP;
	}

	public void setStressTestDerHP(StressTestDerivativeHistPrice stressTestDerHP) {
		this.stressTestDerHP = stressTestDerHP;
	}

	public Instrument getInstr() {
		return instr;
	}

	public void setInstr(Instrument instr) {
		this.instr = instr;
	}

	public void setInstrIdTC(InstrIdTrascode[] instrIdTC) {
		this.instrIdTC = instrIdTC;
	}

	public InstrIdTrascode[] getInstrIdTC() {
		return instrIdTC;
	}
	
	public void setRectifiedClassArray(InstrIdTrascode[] rectifiedClassArray) {
		this.rectifiedClassArray = rectifiedClassArray;
	}

	public InstrIdTrascode[] getRectifiedClassArray() {
		return rectifiedClassArray;
	}
	
	public void setUndCashStressTestHP(StressTestHistPrice undCashStressTestHP) {
		this.undCashStressTestHP = undCashStressTestHP;
	}

	public StressTestHistPrice getUndCashStressTestHP() {
		return undCashStressTestHP;
	}

	public void setVolaCoeff(BigDecimal volaCoeff) {
		this.volaCoeff = volaCoeff;
	}

	public BigDecimal getVolaCoeff() {
		return volaCoeff;
	}
	
}
