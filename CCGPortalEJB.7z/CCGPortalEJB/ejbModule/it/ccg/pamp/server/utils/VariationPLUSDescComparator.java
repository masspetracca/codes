package it.ccg.pamp.server.utils;

import java.util.Comparator;

public class VariationPLUSDescComparator implements Comparator {

	
	public int compare(Object object1, Object object2) {
	VariationPLUS var1= (VariationPLUS) object1;
	VariationPLUS var2= (VariationPLUS) object2;
	
	return var2.getVariation().getVariat().abs().compareTo(var1.getVariation().getVariat().abs());	
	}

}