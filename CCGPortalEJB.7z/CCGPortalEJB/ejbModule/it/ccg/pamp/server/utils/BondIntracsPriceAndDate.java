package it.ccg.pamp.server.utils;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;



public class BondIntracsPriceAndDate implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Timestamp priceDate;
	
	private BigDecimal closePr;
	
	public BondIntracsPriceAndDate() {
		super();
	}
	
	public BondIntracsPriceAndDate(Timestamp priceDate, BigDecimal closePr) {
		super();
		this.priceDate = priceDate;
		this.closePr = closePr;
	}
	
	public Timestamp getPriceDate() {
		return priceDate;
	}

	public void setPriceDate(Timestamp priceDate) {
		this.priceDate = priceDate;
	}

	public BigDecimal getClosePr() {
		return closePr;
	}

	public void setClosePr(BigDecimal closePr) {
		this.closePr = closePr;
	}

}
