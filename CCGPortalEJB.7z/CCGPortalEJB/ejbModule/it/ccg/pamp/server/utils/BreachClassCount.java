package it.ccg.pamp.server.utils;

public class BreachClassCount {
	
	private int classID,breach;

	public BreachClassCount() {
		super();
		
	}

	public BreachClassCount(int classID, int breach) {
		super();
		this.classID = classID;
		this.breach = breach;
	}

	public int getClassID() {
		return classID;
	}

	public void setClassID(int classID) {
		this.classID = classID;
	}

	public int getBreach() {
		return breach;
	}

	public void setBreach(int breach) {
		this.breach = breach;
	}
	
	

}
