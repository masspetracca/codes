package it.ccg.pamp.server.utils;

import java.sql.Timestamp;

import it.ccg.pamp.server.entities.Instrument;

public class BondBTInstrumentError {
	private Instrument instr;
	private VariationPLUS var;
	private boolean histClassChangeAvailable;
	private Timestamp firstClassChangeAvailable;

	public BondBTInstrumentError() {
		super();
	}

	public BondBTInstrumentError(Instrument instr, boolean histClassChangeAvailable) {
		super();
		this.instr = instr;
		this.histClassChangeAvailable = histClassChangeAvailable;
	}

	

	public BondBTInstrumentError(Instrument instr, VariationPLUS var, boolean histClassChangeAvailable, Timestamp firstClassChangeAvailable) {
		super();
		this.instr = instr;
		this.var = var;
		this.histClassChangeAvailable = histClassChangeAvailable;
		this.firstClassChangeAvailable = firstClassChangeAvailable;
	}

	public Instrument getInstr() {
		return instr;
	}

	public void setInstr(Instrument instr) {
		this.instr = instr;
	}

	public VariationPLUS getVar() {
		return var;
	}

	public void setVar(VariationPLUS var) {
		this.var = var;
	}

	public boolean isHistClassChangeAvailable() {
		return histClassChangeAvailable;
	}

	public void setHistClassChangeAvailable(boolean histClassChangeAvailable) {
		this.histClassChangeAvailable = histClassChangeAvailable;
	}
	
	
	
	public Timestamp getFirstClassChangeAvailable() {
		return firstClassChangeAvailable;
	}

	public void setFirstClassChangeAvailable(Timestamp firstClassChangeAvailable) {
		this.firstClassChangeAvailable = firstClassChangeAvailable;
	}

	@Override
	public String toString() {
		
		String totale="InstrID "+instr.getInstrId()+" ISINCODE "+instr.getIsinCode()+" Market "+instr.getMarketCode()+" - ";
		
		if(this.isHistClassChangeAvailable()){
			totale+="Variation in date "+var.getVariation().getPk().getPriceDate()+" can't be associated to a class as it's before or equal the first change class date "+firstClassChangeAvailable;
		}
		else{
			totale+="No class changes available for this instrument";
		}
		
		return totale;
	}
	
	
	

}
