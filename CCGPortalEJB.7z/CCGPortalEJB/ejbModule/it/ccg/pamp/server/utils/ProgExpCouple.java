package it.ccg.pamp.server.utils;

import java.util.Arrays;
import java.util.Vector;

public class ProgExpCouple {
	
	private int progexp1, progexp2;

	public ProgExpCouple(int progexp1, int progexp2) {
		super();
		this.progexp1 = progexp1;
		this.progexp2 = progexp2;
	}

	public int getProgexp1() {
		return progexp1;
	}

	public void setProgexp1(int progexp1) {
		this.progexp1 = progexp1;
	}

	public int getProgexp2() {
		return progexp2;
	}

	public void setProgexp2(int progexp2) {
		this.progexp2 = progexp2;
	}
	
	
	public static Vector<ProgExpCouple> findCouples(Integer[] progexparr){
		Vector<ProgExpCouple> progexpcouples= new Vector<ProgExpCouple>();
		
		
		Arrays.sort(progexparr);
    	
    	for (int i = 0; i < progexparr.length - 1; i++) {
			int progexp1= progexparr[i];

			for (int j = i + 1; j < progexparr.length; j++) {
				int progexp2 = progexparr[j];
				
				progexpcouples.add(new ProgExpCouple(progexp1, progexp2));
				
				
			}
			
    	}
    	
    	return progexpcouples;
		
		
	}
	

}
