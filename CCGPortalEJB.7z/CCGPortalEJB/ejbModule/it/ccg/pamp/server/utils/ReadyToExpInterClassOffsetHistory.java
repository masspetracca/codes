package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.entities.InterclassOffsetHistory;

import java.util.Vector;

public class ReadyToExpInterClassOffsetHistory {
	private InterclassOffsetHistory clTerHist;
	private BondClass bondClass1;
	private BondClass bondClass2;
	//private Vector<ClassIdTrascodePlus> classTcPlusVec;
	
	
	
	
	public ReadyToExpInterClassOffsetHistory() {
		super();
		}




	public ReadyToExpInterClassOffsetHistory(InterclassOffsetHistory clTraHist, BondClass bondClass1, BondClass bondClass2/*, Vector<ClassIdTrascodePlus> classTcPlusVec*/) {
		super();
		this.clTerHist = clTraHist;
		this.bondClass1 = bondClass1;
		this.bondClass2 = bondClass2;
		//this.classTcPlusVec = classTcPlusVec;
	}
	
	
	public InterclassOffsetHistory getClTerHist() {
		return clTerHist;
	}




	public void setClTerHist(InterclassOffsetHistory clTerHist) {
		this.clTerHist = clTerHist;
	}




	public BondClass getBondClass1() {
		return bondClass1;
	}




	public void setBondClass1(BondClass bondClass1) {
		this.bondClass1 = bondClass1;
	}
	
	public BondClass getBondClass2() {
		return bondClass2;
	}




	public void setBondClass2(BondClass bondClass2) {
		this.bondClass2 = bondClass2;
	}




	/*public Vector<ClassIdTrascodePlus> getClassTcPlusVec() {
		return classTcPlusVec;
	}




	public void setClassTcPlusVec(Vector<ClassIdTrascodePlus> classTcPlusVec) {
		this.classTcPlusVec = classTcPlusVec;
	}*/
}
