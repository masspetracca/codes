package it.ccg.pamp.server.utils;


import it.ccg.pamp.server.entities.Group;

import java.util.Comparator;

public class GroupComparator implements	Comparator {

		
		public int compare(Object object1, Object object2) {
			Group bc1= (Group) object1;
			Group bc2= (Group) object2;
		
			return bc1.getGrName().compareTo(bc2.getGrName());	
		}

}