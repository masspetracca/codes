package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class BondToSync {
	
	  
	private String isinCode;
	private String description;
	private String currency;
	private String couponType;
	private Timestamp expiry;
	private Integer couponFreq;
	private BigDecimal couponInterest;
	private Timestamp coupNextDate;
	private BigDecimal duration;
	private String bndClassId;
	private String compart;
	private BigDecimal lastPrice;
	private Timestamp durRefDate;
	
	private String market;
	private String instrType;
	private String instrSubType;
	
	

	public BondToSync() {
	}
	
	public String getIsinCode() {
		return isinCode;
	}

	public void setIsinCode(String isinCode) {
		this.isinCode = isinCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCouponType() {
		return couponType;
	}

	public void setCouponType(String couponType) {
		this.couponType = couponType;
	}

	public Timestamp getExpiry() {
		return expiry;
	}

	public void setExpiry(String expiry) throws NumberFormatException, DataNotValidException {
		this.expiry = GenericTools.convertDateFromIntToTimestamp(Integer.parseInt(expiry));
	}

	
	public Integer getCouponFreq() {
		return couponFreq;
	}

	public void setCouponFreq(String couponFreq) {
		if (!couponFreq.equalsIgnoreCase("00")) {
			this.couponFreq = 12/Integer.parseInt(couponFreq);
		} else {
			this.couponFreq = 0;
		}
	}

	public BigDecimal getCouponInterest() {
		return couponInterest;
	}

	public void setCouponInterest(BigDecimal couponInterest) {
		this.couponInterest = couponInterest;
	}

	public Timestamp getCoupNextDate() {
		return coupNextDate;
	}

	public void setCoupNextDate(String coupNextDate) throws NumberFormatException, DataNotValidException {
		if (Integer.parseInt(coupNextDate)>0) {
			this.coupNextDate = GenericTools.convertDateFromIntToTimestamp(Integer.parseInt(coupNextDate));
		} else {
			this.coupNextDate = GenericTools.convertDateFromIntToTimestamp(19000101);
		}
	}

	public BigDecimal getDuration() {
		return duration;
	}

	public void setDuration(BigDecimal duration) {
		this.duration = duration;
	}

	public String getBndClassId() {
		return bndClassId.trim();
	}

	public void setBndClassId(String bndClassId) {
		this.bndClassId = bndClassId;
	}

	public String getCompart() {
		return compart;
	}

	public void setCompart(String compart) {
		this.compart = compart;
		
		if(compart.equalsIgnoreCase("BOT") || compart.equalsIgnoreCase("CCT") || compart.equalsIgnoreCase("CTZ") || compart.equalsIgnoreCase("BTP") || compart.equalsIgnoreCase("BTi")) {
			this.market = "MTS";
			
			if (compart.equalsIgnoreCase("BTi")) {
				this.instrType = "GOVIES";
				this.instrSubType = "BTPi";
			} else {
				this.instrType = "GOVIES";
				this.instrSubType = compart;
			}
			
		} else {
			this.market = "RET";
			this.instrType = "RET";
			this.instrSubType = "RET";
		}
		
		
	}
	
	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getInstrType() {
		return instrType;
	}

	public void setInstrType(String instrType) {
		this.instrType = instrType;
	}

	public String getInstrSubType() {
		return instrSubType;
	}

	public void setInstrSubType(String instrSubType) {
		this.instrSubType = instrSubType;
	}

	public void setLastPrice(BigDecimal lastPrice) {
		this.lastPrice = lastPrice;
	}

	public BigDecimal getLastPrice() {
		return lastPrice;
	}
	
	public Timestamp getDurRefDate() {
		return durRefDate;
	}

	public void setDurRefDate(long durRefDate) throws NumberFormatException, DataNotValidException {
		if (durRefDate>0) {
			this.durRefDate = GenericTools.convertDateFromIntToTimestamp((int) durRefDate);
		} else {
			this.durRefDate = GenericTools.convertDateFromIntToTimestamp(19000101);
		}
	}
	
	

}
