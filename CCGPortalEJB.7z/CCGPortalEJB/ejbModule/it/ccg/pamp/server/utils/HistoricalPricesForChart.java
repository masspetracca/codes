package it.ccg.pamp.server.utils;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class HistoricalPricesForChart implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int instrId;
	private Timestamp priceDate;
	private BigDecimal closePrice;
	private BigDecimal closePriceRet;
	private String caType;
	private BigDecimal caValue;
	private BigDecimal kCoeff;
	
	
	public HistoricalPricesForChart() {
		super();
	}
	
	public HistoricalPricesForChart(int instrId,Timestamp priceDate, BigDecimal closePrice, BigDecimal closePriceRet, String caType, BigDecimal caValue, BigDecimal kCoeff) {
		super();
		this.instrId = instrId;
		this.priceDate = priceDate;
		this.closePrice = closePrice;
		this.closePriceRet = closePriceRet;
		this.caType = caType;
		this.caValue = caValue;
		this.kCoeff = kCoeff;
	
	}
	
	public int getInstrId() {
		return instrId;
	}

	public void setInstrId(int instrId) {
		this.instrId = instrId;
	}

	public Timestamp getPriceDate() {
		return priceDate;
	}

	public void setPriceDate(Timestamp priceDate) {
		this.priceDate = priceDate;
	}

	public BigDecimal getClosePrice() {
		return closePrice;
	}

	public void setClosePrice(BigDecimal closePrice) {
		this.closePrice = closePrice;
	}

	public BigDecimal getClosePriceRet() {
		return closePriceRet;
	}

	public void setClosePriceRet(BigDecimal closePriceRet) {
		this.closePriceRet = closePriceRet;
	}

	public String getCaType() {
		return caType;
	}

	public void setCaType(String caType) {
		this.caType = caType;
	}
	
	public BigDecimal getCaValue() {
		return caValue;
	}

	public void setCaValue(BigDecimal caValue) {
		this.caValue = caValue;
	}

	public BigDecimal getKCoeff() {
		return kCoeff;
	}

	public void setKCoeff(BigDecimal kCoeff) {
		this.kCoeff = kCoeff;
	}

	
}
