package it.ccg.pamp.server.utils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Vector;

import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;

public class StressTestIndexPricesReadyToExp {

	private StressTestHistPrice stressTestHP;
	
	private Instrument indexInstrument;
	
	private Vector<StressTestIndexDerivTranscode> idxDerTranscode;
	
	public StressTestIndexPricesReadyToExp() {
		super();
	}
	
	public StressTestIndexPricesReadyToExp(StressTestHistPrice stressedHP, Instrument indexInstrument, Vector<StressTestIndexDerivTranscode> idxDerTranscode) {
		super();
		this.stressTestHP = stressedHP;
		this.indexInstrument = indexInstrument;
		this.idxDerTranscode = idxDerTranscode;
		
	}

	public StressTestHistPrice getStressTestHP() {
		return stressTestHP;
	}

	public void setStressTestHP(StressTestHistPrice stressTestHP) {
		this.stressTestHP = stressTestHP;
	}

	public Instrument getIndexInstrument() {
		return indexInstrument;
	}

	public void setIndexInstrument(Instrument indexInstrument) {
		this.indexInstrument = indexInstrument;
	}

	public void setIdxDerTranscode(Vector<StressTestIndexDerivTranscode> idxDerTranscode) {
		this.idxDerTranscode = idxDerTranscode;
	}

	public Vector<StressTestIndexDerivTranscode> getIdxDerTranscode() {
		return idxDerTranscode;
	}

	
	
}
