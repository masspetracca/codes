package it.ccg.pamp.server.utils;

public class Scenario {
	String scenCode;
	String scenDesc;
	
	public Scenario(String scenCode, String scenDesc) {
		super();
		this.scenCode = scenCode;
		this.scenDesc = scenDesc;
	}
	
	
	public String getScenCode() {
		return scenCode;
	}

	

	public String getScenDesc() {
		return scenDesc;
	}

	public void setScenDesc(String scenDesc) {
		this.scenDesc = scenDesc;
	}


}
