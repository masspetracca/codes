package it.ccg.pamp.server.utils;

import java.io.Serializable;
import java.math.BigDecimal;

public class ExpCorrGroupedBy implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int progExp1, progExp2;
	private int nv, nDaysPer;
	private BigDecimal correl;
	private BigDecimal pearson;
	private BigDecimal divundiv;
	private int histDays;
	
	public ExpCorrGroupedBy(int progExp1, int progExp2, BigDecimal correl,BigDecimal pearson,BigDecimal divundiv,int histDays,int nv,int nDaysPer) {
		super();
		this.setProgExp1(progExp1);
		this.setProgExp2(progExp2);
		this.setCorrel(correl);
		this.setPearson(pearson);
		this.setDivundiv(divundiv);
		this.setHistDays(histDays);
		this.setNv(nv);
		this.setNDaysPer(nDaysPer);
	}

	public void setProgExp1(int progExp1) {
		this.progExp1 = progExp1;
	}

	public int getProgExp1() {
		return progExp1;
	}

	public void setProgExp2(int progExp2) {
		this.progExp2 = progExp2;
	}

	public int getProgExp2() {
		return progExp2;
	}

	public void setCorrel(BigDecimal correl) {
		this.correl = correl;
	}

	public BigDecimal getCorrel() {
		return correl;
	}

	public void setPearson(BigDecimal pearson) {
		this.pearson = pearson;
	}

	public BigDecimal getPearson() {
		return pearson;
	}

	public void setDivundiv(BigDecimal divundiv) {
		this.divundiv = divundiv;
	}

	public BigDecimal getDivundiv() {
		return divundiv;
	}

	public void setHistDays(int histDays) {
		this.histDays = histDays;
	}

	public int getHistDays() {
		return histDays;
	}
	
	public void setNv(int nv) {
		this.nv = nv;
	}

	public int getNv() {
		return nv;
	}
	
	public void setNDaysPer(int nDaysPer) {
		this.nDaysPer = nDaysPer;
	}

	public int getNDaysPer() {
		return nDaysPer;
	}

	@Override
	public String toString() {
		return "Expiration Correlation: progExp1=" + progExp1 + ", progExp2=" + progExp2 + ", holding period=" + nv + ", nDaysPer=" + nDaysPer + ", correl=" + correl + ", pearson=" + pearson + ", divundiv=" + divundiv
				+ ", histDays=" + histDays;
	}
	
	
	
}

