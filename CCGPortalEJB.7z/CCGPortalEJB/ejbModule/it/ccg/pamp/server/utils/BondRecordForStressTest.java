package it.ccg.pamp.server.utils;

import java.io.Serializable;
import java.math.BigDecimal;

public class BondRecordForStressTest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String isinCode;
	
	private String description;
	
	private int scadenza;
	
	private int dataPrCedola;
	
	private BigDecimal cedola;
	
	private BigDecimal price;
	
	private BigDecimal duration;
	
	public BondRecordForStressTest() {
		super();
	}
	
	public BondRecordForStressTest(String isinCode, String description, String scadenza, String dataPrCedola, BigDecimal cedola, BigDecimal price, BigDecimal duration) {
		super();
		this.isinCode = isinCode;
		this.description = description;
		this.scadenza = Integer.parseInt(scadenza);
		this.dataPrCedola = Integer.parseInt(dataPrCedola);
		this.cedola = cedola;
		this.price = price;
		this.duration = duration;
	}
	
	public String getIsinCode() {
		return isinCode;
	}

	public void setIsinCode(String isinCode) {
		this.isinCode = isinCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getScadenza() {
		return scadenza;
	}

	public void setScadenza(int scadenza) {
		this.scadenza = scadenza;
	}

	public int getDataPrCedola() {
		return dataPrCedola;
	}

	public void setDataPrCedola(int dataPrCedola) {
		this.dataPrCedola = dataPrCedola;
	}

	public BigDecimal getCedola() {
		return cedola;
	}

	public void setCedola(BigDecimal cedola) {
		this.cedola = cedola;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getDuration() {
		return duration;
	}

	public void setDuration(BigDecimal duration) {
		this.duration = duration;
	}
	
}
