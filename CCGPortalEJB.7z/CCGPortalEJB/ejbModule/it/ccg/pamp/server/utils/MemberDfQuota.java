package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

public class MemberDfQuota {

	private int genMbrId;
	private BigDecimal dfQuota;
	
	public MemberDfQuota() {
		
	}
	
	public int getGenMbrId() {
		return genMbrId;
	}

	public void setGenMbrId(int genMbrId) {
		this.genMbrId = genMbrId;
	}

	public BigDecimal getDfQuota() {
		return dfQuota;
	}

	public void setDfQuota(BigDecimal dfQuota) {
		this.dfQuota = dfQuota;
	}
	
}
