package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

public class MaxYearVar {
	
	private int month;
	private BigDecimal maxvar;
	
	

	public MaxYearVar() {
		super();
		
	}
	public MaxYearVar(int month, BigDecimal maxvar) {
		super();
		this.month = month;
		this.maxvar = maxvar;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public BigDecimal getMaxvar() {
		return maxvar;
	}
	public void setMaxvar(BigDecimal maxvar) {
		this.maxvar = maxvar;
	}
	
	
	
	

}
