package it.ccg.pamp.server.utils;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

public class Correlation {

	private Timestamp priceDate;
	
	private BigDecimal variation1;
	
	private BigDecimal variation2;
	
	private BigDecimal[] arrVariation1;
	
	private BigDecimal[] arrVariation2;
	
	public Correlation() {
		super();
	}
	
	public Correlation(Timestamp priceDate, BigDecimal variation1, BigDecimal variation2) {
		super();
		this.priceDate = priceDate;
		this.variation1 = variation1;
		this.variation2 = variation2;
		
	}
	
	public static Correlation setCorrelationArray(List<Correlation> correlationList) {
		
		Correlation corrArray = new Correlation();
		
		int i=0;
		
		corrArray.setPriceDate(correlationList.get(0).getPriceDate());
		
		BigDecimal[] arrVariation1 = new BigDecimal[correlationList.size()];
		BigDecimal[] arrVariation2 = new BigDecimal[correlationList.size()];
		
		for (Correlation corr:correlationList) {
			arrVariation1[i] = corr.getVariation1();
			arrVariation2[i] = corr.getVariation2();
			i++;
		}
		
		corrArray.setArrVariation1(arrVariation1);
		corrArray.setArrVariation2(arrVariation2);
		
		return corrArray;
		
	}
	

	
	public Timestamp getPriceDate() {
		return priceDate;
	}

	public void setPriceDate(Timestamp priceDate) {
		this.priceDate = priceDate;
	}

	public BigDecimal getVariation1() {
		return variation1;
	}

	public void setVariation1(BigDecimal variation1) {
		this.variation1 = variation1;
	}
	
	public BigDecimal getVariation2() {
		return variation2;
	}

	public void setVariation2(BigDecimal variation2) {
		this.variation2 = variation2;
	}

	public BigDecimal[] getArrVariation1() {
		return arrVariation1;
	}

	public void setArrVariation1(BigDecimal[] arrVariation1) {
		this.arrVariation1 = arrVariation1;
	}

	public BigDecimal[] getArrVariation2() {
		return arrVariation2;
	}

	public void setArrVariation2(BigDecimal[] arrVariation2) {
		this.arrVariation2 = arrVariation2;
	}

}
