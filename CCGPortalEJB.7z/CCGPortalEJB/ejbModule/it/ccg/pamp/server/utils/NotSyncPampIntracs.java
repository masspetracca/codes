package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.MarginHistory;

public class NotSyncPampIntracs {
	
	private MarginHistory pampMarginHistory;
	private InstrIdTrascode instrTC;
	private String description;
	
	
	
	public NotSyncPampIntracs() {
		super();
	}

	public NotSyncPampIntracs(MarginHistory pampMarginHistory, String description) {
		super();
		this.pampMarginHistory = pampMarginHistory;
		this.description = description;
	}



	public NotSyncPampIntracs(MarginHistory pampMarginHistory, InstrIdTrascode instrTC, String description) {
		super();
		this.pampMarginHistory = pampMarginHistory;
		this.instrTC = instrTC;
		this.description = description;
	}

	public MarginHistory getPampMarginHistory() {
		return pampMarginHistory;
	}

	public void setPampMarginHistory(MarginHistory pampMarginHistory) {
		this.pampMarginHistory = pampMarginHistory;
	}

	public InstrIdTrascode getInstrTC() {
		return instrTC;
	}

	public void setInstrTC(InstrIdTrascode instrTC) {
		this.instrTC = instrTC;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		if(instrTC==null){
			return "PAMP Instrument ID: "+this.getPampMarginHistory().getPk().getInstrId()+"  InivDate: "+this.getPampMarginHistory().getPk().getIniVDate()+": "+this.getDescription();
			
		}
		else{
			return "PAMP Instrument ID: "+this.getPampMarginHistory().getPk().getInstrId()+"  InivDate: "+this.getPampMarginHistory().getPk().getIniVDate()+"   -  Clearing system (INTRACS): Instrument ID: " + instrTC.getPk().getInstrId()
				+ " classCode: " + instrTC.getPk().getSicInstr().trim()+" type: "+instrTC.getPk().getSicInstrTy()+": "+this.getDescription();
			
			
		}
		
		
	}
	
	
	
	
	
	
	

}
