package it.ccg.pamp.server.utils;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class PAMPinstruments {
private static final long serialVersionUID = 1L;
	
	private int instrId;
	private String classCode;
	private String instrType;
	private String sicClassCode;
	private String sicInstrType;
	private BigDecimal margin;
	private BigDecimal minMargin;
	private BigDecimal straddle;
	private String minMarType;
	private String straType;
	private int classId;
	private String sicClassId;
	private String classDesc;
	private BigDecimal classMargin;
	private BigDecimal intraClassOffset;
	private BigDecimal interClassOffset;
	private int classId1;
	private int classId2;
	private String classDesc1;
	private String classDesc2;
	private Timestamp stDate;
	private String isinCode;
	private boolean exportable;
	
	
	public PAMPinstruments() {
		super();
	}
	
	public PAMPinstruments(int instrId, String classCode, String instrType, String sicClassCode, String sicInstrType, BigDecimal margin, BigDecimal minMargin, BigDecimal straddle, String minMarType,String straType) {
		super();
		this.instrId = instrId;
		this.classCode = classCode;
		this.instrType = instrType;
		this.sicClassCode = sicClassCode;
		this.sicInstrType = sicInstrType;
		this.margin = margin;
		this.minMargin = minMargin;
		this.straddle = straddle;
		this.minMarType = minMarType;
		this.straType = straType;
	}
	
	public PAMPinstruments(int classId, String sicClassId, String classDesc,BigDecimal classMargin) {
		super();
		this.classId = classId;
		this.sicClassId = sicClassId;
		this.classDesc = classDesc;
		this.classMargin = classMargin;
	}
	
	
	public PAMPinstruments(int classId, String sicClassId, String classDesc,BigDecimal offset, boolean isIntraClass) {
		super();
		this.classId = classId;
		this.sicClassId = sicClassId;
		this.classDesc = classDesc;
		this.intraClassOffset = offset;
	}
	
	public PAMPinstruments(int classId1, int classId2, String classDesc1, String classDesc2,BigDecimal offset) {
		super();
		this.classId1 = classId1;
		this.classId2 = classId2;
		this.classDesc1 = classDesc1;
		this.classDesc2 = classDesc2;
		this.interClassOffset = offset;
		
	}
	
	public PAMPinstruments(int instrId, String classCode, String instrType, String sicClassCode, String sicInstrType, String isinCode, Timestamp stDate, boolean exportable) {
		super();
		this.instrId = instrId;
		this.classCode = classCode;
		this.instrType = instrType;
		this.sicClassCode = sicClassCode;
		this.sicInstrType = sicInstrType;
		this.stDate = stDate;
		this.isinCode = isinCode;
		this.exportable = exportable;
	}
	

	public int getInstrId() {
		return instrId;
	}

	public void setInstrId(int instrId) {
		this.instrId = instrId;
	}

	public String getClassCode() {
		return classCode;
	}

	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}

	public String getInstrType() {
		return instrType;
	}

	public void setInstrType(String instrType) {
		this.instrType = instrType;
	}

	public String getSicClassCode() {
		return sicClassCode;
	}

	public void setSicClassCode(String sicClassCode) {
		this.sicClassCode = sicClassCode;
	}

	public String getSicInstrType() {
		return sicInstrType;
	}

	public void setSicInstrType(String sicInstrType) {
		this.sicInstrType = sicInstrType;
	}

	public BigDecimal getMargin() {
		return margin;
	}

	public void setMargin(BigDecimal margin) {
		this.margin = margin;
	}
	
	public BigDecimal getMinMargin() {
		return minMargin;
	}

	public void setMinMargin(BigDecimal minMargin) {
		this.minMargin = minMargin;
	}

	public BigDecimal getStraddle() {
		return straddle;
	}

	public void setStraddle(BigDecimal straddle) {
		this.straddle = straddle;
	}
	
	public String getMinMarType() {
		return minMarType;
	}
	
	public void setMinMarType(String minMarType) {
		this.minMarType = minMarType;
	}

	public String getStraType() {
		return straType;
	}	

	public void setStraType(String straType) {
		this.straType = straType;
	}

	public int getClassId() {
		return classId;
	}

	public void setClassId(int classId) {
		this.classId = classId;
	}

	public String getSicClassId() {
		return sicClassId;
	}

	public void setSicClassId(String sicClassId) {
		this.sicClassId = sicClassId;
	}

	public String getClassDesc() {
		return classDesc;
	}

	public void setClassDesc(String classDesc) {
		this.classDesc = classDesc;
	}

	public BigDecimal getClassMargin() {
		return classMargin;
	}

	public void setClassMargin(BigDecimal classMargin) {
		this.classMargin = classMargin;
	}
	
	public BigDecimal getIntraClassOffset() {
		return intraClassOffset;
	}

	public void setIntraClassOffset(BigDecimal intraClassOffset) {
		this.intraClassOffset = intraClassOffset;
	}
	
	public BigDecimal getInterClassOffset() {
		return interClassOffset;
	}

	public void setInterClassOffset(BigDecimal interClassOffset) {
		this.interClassOffset = interClassOffset;
	}

	public int getClassId1() {
		return classId1;
	}

	public void setClassId1(int classId1) {
		this.classId1 = classId1;
	}

	public int getClassId2() {
		return classId2;
	}

	public void setClassId2(int classId2) {
		this.classId2 = classId2;
	}

	public String getClassDesc1() {
		return classDesc1;
	}

	public void setClassDesc1(String classDesc1) {
		this.classDesc1 = classDesc1;
	}

	public String getClassDesc2() {
		return classDesc2;
	}

	public void setClassDesc2(String classDesc2) {
		this.classDesc2 = classDesc2;
	}

	public void setStDate(Timestamp stDate) {
		this.stDate = stDate;
	}

	public Timestamp getStDate() {
		return stDate;
	}

	public void setIsinCode(String isinCode) {
		this.isinCode = isinCode;
	}

	public String getIsinCode() {
		return isinCode;
	}
	
	public void setExportable(boolean exportable) {
		this.exportable = exportable;
	}

	public boolean getExportable() {
		return exportable;
	}
	
}
