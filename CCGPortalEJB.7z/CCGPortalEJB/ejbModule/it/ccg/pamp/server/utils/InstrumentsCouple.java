package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.GroupComponent;
import it.ccg.pamp.server.entities.SetComponent;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;

import java.util.LinkedHashMap;
import java.util.Vector;

public class InstrumentsCouple {
	
	private int instrID1, instrID2, setID;

	public InstrumentsCouple() {
		super();
	}
	
	public InstrumentsCouple(int instrID1, int instrID2, int setID) {
		super();
		this.instrID1 = instrID1;
		this.instrID2 = instrID2;
		this.setID = setID;
	}

	public int getInstrID1() {
		return instrID1;
	}

	public void setInstrID1(int instrID1) {
		this.instrID1 = instrID1;
	}

	public int getInstrID2() {
		return instrID2;
	}

	public void setInstrID2(int instrID2) {
		this.instrID2 = instrID2;
	}

	public int getSetID() {
		return setID;
	}

	public void setSetID(int setID) {
		this.setID = setID;
	}
	
	public Vector<InstrumentsCouple> getInstrumentCouple(it.ccg.pamp.server.entities.Set seten,LinkedHashMap<String, String> instrtypehash) throws DataNotAvailableException {
		
		Vector<InstrumentsCouple> corinstrvec= new Vector<InstrumentsCouple>();
		if(seten.getSetComponent()==null)
			throw new DataNotAvailableException("No components available for  set: "+ seten.getSetId()+" ( name: "+seten.getSetName()+")");
			
		SetComponent[] setcomparr=	new SetComponent[seten.getSetComponent().size()];
		seten.getSetComponent().toArray(setcomparr);
		
		for(int a=0; a<setcomparr.length; a++){
			
			for(int b=0; b<setcomparr.length; b++){
		
				if(a!=b){
					
					String instrtypeA= setcomparr[a].getInstr().getInstrType();
					String intracsInstrTypeA= instrtypehash.get(instrtypeA);				
					
					if(intracsInstrTypeA==null)throw new DataNotAvailableException("Instrument type "+instrtypeA+" not found on the Risk Engine");
					
					
					String instrtypeB= setcomparr[b].getInstr().getInstrType();
					String intracsInstrTypeB= instrtypehash.get(instrtypeB);
					if(intracsInstrTypeB==null)throw new DataNotAvailableException("Instrument type "+instrtypeB+" not found on the Risk Engine");
					
					//se non hanno lo stesso instrtype su intracs non vanno tenuti in considerazione per un eventuale gruppo e passo avanti
					if(!intracsInstrTypeA.equalsIgnoreCase(intracsInstrTypeB)) continue;
					
					
					InstrumentsCouple ci= new InstrumentsCouple(setcomparr[a].getPk().getInstrId(),setcomparr[b].getPk().getInstrId(), seten.getSetId());
					//System.out.println("Couple "+ setcomparr[a].getPk().getInstrId() +" - "+setcomparr[b].getPk().getInstrId() +" in set "+ seten.getSetId());
					corinstrvec.add(ci);
					
				}
				
			}
		
		}
			
		return corinstrvec;
	}
	
	public Vector<InstrumentsCouple> getInstrumentCouple(it.ccg.pamp.server.entities.Set seten) throws DataNotAvailableException {
		
		Vector<InstrumentsCouple> corinstrvec= new Vector<InstrumentsCouple>();
		if(seten.getSetComponent()==null)
			throw new DataNotAvailableException("No components available for  set: "+ seten.getSetId()+" ( name: "+seten.getSetName()+")");
			
		SetComponent[] setcomparr=	new SetComponent[seten.getSetComponent().size()];
		seten.getSetComponent().toArray(setcomparr);
		
		for(int a=0; a<setcomparr.length; a++){
			
			for(int b=0; b<setcomparr.length; b++){
		
				if(a!=b){
					
					InstrumentsCouple ci= new InstrumentsCouple(setcomparr[a].getPk().getInstrId(),setcomparr[b].getPk().getInstrId(), seten.getSetId());
					
					corinstrvec.add(ci);
					
				}
				
			}
		
		}
			
		return corinstrvec;
	}
	
	public  Vector<InstrumentsCouple> getInstrumentCouple(it.ccg.pamp.server.entities.Group groupen) {
			
		Vector<InstrumentsCouple> corinstrvec= new Vector<InstrumentsCouple>();
			
		GroupComponent[] arrGrComponent = new GroupComponent[groupen.getGroupComponent().size()];
		groupen.getGroupComponent().toArray(arrGrComponent);
			
		for(int a=0; a<arrGrComponent.length; a++){
			for(int b=0; b<arrGrComponent.length; b++){
		
				if(a!=b){
					
					InstrumentsCouple ci= new InstrumentsCouple(arrGrComponent[a].getPk().getInstrId(),arrGrComponent[b].getPk().getInstrId(), -groupen.getGrId());
					
					corinstrvec.add(ci);
				}
			}
		}
		return corinstrvec;
	}
}