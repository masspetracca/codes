package it.ccg.pamp.server.utils;

public class CountNvVar {
	
	int nv, count;

	public CountNvVar() {
		super();
		
	}

	public CountNvVar(int nv, int count) {
		super();
		this.nv = nv;
		this.count = count;
	}

	public int getNv() {
		return nv;
	}

	public void setNv(int nv) {
		this.nv = nv;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	

}
