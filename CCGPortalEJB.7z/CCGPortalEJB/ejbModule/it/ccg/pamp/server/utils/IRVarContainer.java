package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.Variation;

import java.util.Vector;

public class IRVarContainer {
	
	
	private int instrID;
	private int[] countarr;
	private Vector<Variation> actualvars;
	
	public IRVarContainer() {
		super();
		
	}

	public IRVarContainer(int instrID, int[] countarr, Vector<Variation> actualvars) {
		super();
		this.instrID = instrID;
		this.countarr = countarr;
		this.actualvars = actualvars;
	}

	public int getInstrID() {
		return instrID;
	}

	public void setInstrID(int instrID) {
		this.instrID = instrID;
	}

	public int[] getCountarr() {
		return countarr;
	}

	public void setCountarr(int[] countarr) {
		this.countarr = countarr;
	}

	public Vector<Variation> getActualvars() {
		return actualvars;
	}

	public void setActualvars(Vector<Variation> actualvars) {
		this.actualvars = actualvars;
	}
	
	
	
	
	
	

}
