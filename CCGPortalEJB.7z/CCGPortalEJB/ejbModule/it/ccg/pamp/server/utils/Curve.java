package it.ccg.pamp.server.utils;

import java.util.Vector;

public class Curve {
	
	private String curveName, scenario;
	private Vector<CurveNode> nodesVec;
	
	
	
	
	
	public Curve() {
		super();
	}

	public Curve(String curveName, String scenario, Vector<CurveNode> nodesVec) {
		super();
		this.curveName = curveName;
		this.scenario = scenario;
		this.nodesVec = nodesVec;
	}

	public String getCurveName() {
		return curveName;
	}

	public void setCurveName(String curveName) {
		this.curveName = curveName;
	}

	public String getScenario() {
		return scenario;
	}

	public void setScenario(String scenario) {
		this.scenario = scenario;
	}

	public Vector<CurveNode> getNodesVec() {
		return nodesVec;
	}

	public void setNodesVec(Vector<CurveNode> nodesVec) {
		this.nodesVec = nodesVec;
	}

	@Override
	public String toString() {
		return "Curve: curveName=" + curveName + ", scenario=" + scenario;
	}
	
	
	


	

}
