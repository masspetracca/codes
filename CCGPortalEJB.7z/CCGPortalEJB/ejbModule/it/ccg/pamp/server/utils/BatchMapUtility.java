package it.ccg.pamp.server.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Vector;


public class BatchMapUtility {

	/****************************
	 *   JOB CATEGORY ARRAYS	*
	 ****************************/
	
	final static Integer[] computationJobsArray = new Integer[] {1,2,3,5,6,7,8,15,16,26,30,31,40,41,50,51,65,138,139,141,142,143,172,181,189};
	
	final static Integer[] approvalJobsArray = new Integer[] {11,12,14,17,28,29,38,39,45,52,53,54,62,63,64,178,179,180};
	
	final static Integer[] alerterJobsArray = new Integer[] {129,148,153,161,168,169};
	
	final static Integer[] priceDownloadJobsArray = new Integer[] {18,19,20,21,23,24,25,37,57,59,134,175,176,183};
	
	final static Integer[] synchroJobsArray = new Integer[] {46,60,67,70,126,128,132,137,184};
	
	final static Integer[] exportJobsArray = new Integer[] {22,66,68,69};
	
	final static Integer[] stressTestJobsArray = new Integer[] {122,123,125,133,149,150,151,152,154,155,156,157,158,159,160,162,163,164,165,166,167,185,187};
	
	final static Integer[] refreshJobsArray = new Integer[] {140,147,173,174,182};
	
	final static Integer[] globalBatchArray = new Integer[] {1000,1002,1010,1011,1012,1013,1014};
	
	final static Integer[] globalOEKBBatchArray = new Integer[] {3000};
	
	final static Integer[] oekbJobsArray = new Integer[] {130,131};
	
	final static Integer[] oeKBStressTestJobsArray = new Integer[] {144,145,146,188};
	
	final static Integer[] reportJobsArray = new Integer[] {170,171};
	
	final static Integer[] analysysArray = new Integer[] {13,177,190};
	
	/***************************
	 * JOB STATIC DECLARATIONS *
	 ***************************/
	
	static int index_historical_prices_download = 37;
	static int interest_rates_price_download = 21;
	static int equities_historical_prices_download = 18;
	static int futures_historical_prices_download = 19;
	static int options_historical_prices_download = 20;
	static int bond_historical_prices_download = 57;
	static int transferCashFromFutures = 59;
	static int currencyHistPriceDownload = 134;
	static int comparableHistPriceDownload = 183;
	
	static int index_variation_batch = 40;
	static int indexWeightSync = 126;
	
	static int equities_margin_computation = 1;
	static int bond_margin_computation = 2;
	static int inflation_bond_margin_computation = 50;
	static int equity_derivatives_margin_computation = 3;
	static int equities_groups_computation = 6;
	static int equity_Derivatives_Groups_Computation = 7;
	static int future_straddle_computation = 8;
	static int option_minimum_margin_computation = 5;
	
	static int make_Analysis = 13;
	static int make_Analysis_Bond_Haircut = 177;
	
	static int update_equitiesGroup = 15;
	static int update_equityderivativesGroup = 16;
	
	static int eqSubmitForApproval = 11;
	static int haircutSubmitForApproval = 178;
	
	static int eqApproveAll = 14;
	static int globalNotify = 129;
	
	static int refreshEQMatQueries = 140;
	static int refreshBondMatQueries = 147;
	static int refreshComparableMatQueries = 173;
	static int refreshEqStressTestMatQueries = 174;
	
	static int bond_inter_intra_class = 41;
	static int inflation_bond_inter_intra_class = 51;
	static int bond_back_test = 143;
	static int bondglobalNotify = 148;
	static int bondInstrSync = 132;
	
	static int autoEqStressTestPrc = 162;
	static int stressTestEnvBatchesPart1 = 149;
	static int eqInitialMemberDownload = 150; 
	static int stressTestEnvBatchesPart2 = 151;
	static int decreaseScenarioExport = 123;
	static int stressTestEnvBatchesPart3 = 152;
	static int eqDecreaseMemberDownload = 156;
	static int increaseScenarioExport = 122;
	static int eqIncreaseMemberDownload = 155;
	static int stressTestGlobalNotify = 153;
	static int memberStats = 154;
	static int defFundAlerter = 168;
	static int sept11thAlerter = 169;
	static int autoBondStressTestPrc = 163; 
	static int stressTestBondEnvBatchesPart1 = 158; 
	static int bndInitialMemberDownload = 157; 
	static int stressTestBondEnvBatchesPart2 = 159; 
	static int bondDecreaseScenarioExport = 167;
	static int stressTestBondEnvBatchesPart3 = 160;  
	static int bndDecreaseMemberDownload = 164; 
	static int bondIncreaseScenarioExport = 166;
	static int bndIncreaseMemberDownload = 165; 
	static int bondStressTestGlobalNotify = 161;
	
	static int ir_node_curve_refresh = 182;
	static int dtQuotaSync = 184;
	static int eqBoResetSentStatus = 185;
	static int eqDerResetSentStatus = 187;
	static int oekbStressTestResultCsv = 188;
	
	
	
	/***********************************************
	 *               BATCH ARRAYS                  *
	 *  Put into the arrays the required jobs      *
	 *  in correct order to build a complete batch *
	 **********************************************/
	
	final static Integer[] equityGlobalBatch = new Integer[] {index_historical_prices_download,equities_historical_prices_download,transferCashFromFutures,futures_historical_prices_download,options_historical_prices_download,indexWeightSync,index_variation_batch,equities_margin_computation,equity_derivatives_margin_computation,equities_groups_computation,equity_Derivatives_Groups_Computation,update_equitiesGroup,update_equityderivativesGroup,make_Analysis,future_straddle_computation,option_minimum_margin_computation,make_Analysis,refreshEQMatQueries,globalNotify};
	final static Integer[] bondGlobalBatch  = new Integer[] {bondInstrSync,bond_historical_prices_download,bond_margin_computation,inflation_bond_margin_computation,bond_inter_intra_class,inflation_bond_inter_intra_class,bond_back_test,make_Analysis,refreshBondMatQueries,bondglobalNotify};
	
	final static Integer[] eqStressTestGlobalBatch  = new Integer[] {autoEqStressTestPrc,stressTestEnvBatchesPart1,eqInitialMemberDownload,stressTestEnvBatchesPart2,decreaseScenarioExport,stressTestEnvBatchesPart3,eqDecreaseMemberDownload,stressTestEnvBatchesPart1,stressTestEnvBatchesPart2,increaseScenarioExport,stressTestEnvBatchesPart3,eqIncreaseMemberDownload,stressTestGlobalNotify,memberStats,defFundAlerter,sept11thAlerter};
	final static Integer[] bondStressTestGlobalBatch  = new Integer[] {autoBondStressTestPrc,stressTestBondEnvBatchesPart1,bndInitialMemberDownload,stressTestBondEnvBatchesPart2,bondDecreaseScenarioExport,stressTestBondEnvBatchesPart3,bndDecreaseMemberDownload,stressTestBondEnvBatchesPart1,stressTestBondEnvBatchesPart2,bondIncreaseScenarioExport,stressTestBondEnvBatchesPart3,bndIncreaseMemberDownload,bondStressTestGlobalNotify,dtQuotaSync,memberStats,defFundAlerter,sept11thAlerter,refreshEqStressTestMatQueries};
	final static Integer[] equityStressTestPAMPvsIntracsBatch = new Integer[] {eqBoResetSentStatus,eqDerResetSentStatus,stressTestEnvBatchesPart1,eqInitialMemberDownload,stressTestEnvBatchesPart2,decreaseScenarioExport,stressTestEnvBatchesPart3,eqDecreaseMemberDownload,stressTestEnvBatchesPart1,stressTestEnvBatchesPart2,increaseScenarioExport,stressTestEnvBatchesPart3,eqIncreaseMemberDownload,stressTestGlobalNotify,memberStats,defFundAlerter,sept11thAlerter};
	final static Integer[] bondStressTestPAMPvsIntracsBatch = new Integer[] {eqBoResetSentStatus,stressTestBondEnvBatchesPart1,bndInitialMemberDownload,stressTestBondEnvBatchesPart2,bondDecreaseScenarioExport,stressTestBondEnvBatchesPart3,bndDecreaseMemberDownload,stressTestBondEnvBatchesPart1,stressTestBondEnvBatchesPart2,bondIncreaseScenarioExport,stressTestBondEnvBatchesPart3,bndIncreaseMemberDownload,bondStressTestGlobalNotify,dtQuotaSync,memberStats,defFundAlerter,sept11thAlerter,refreshEqStressTestMatQueries};
	
	
	final static Integer[] oekbEquityGlobalBatch  = new Integer[] {equities_historical_prices_download,transferCashFromFutures,index_historical_prices_download,equities_margin_computation,make_Analysis,eqSubmitForApproval,eqApproveAll,globalNotify};
	final static Integer[] importGlobalBatch  = new Integer[] {stressTestBondEnvBatchesPart1,index_historical_prices_download,equities_historical_prices_download,transferCashFromFutures,futures_historical_prices_download,options_historical_prices_download,indexWeightSync,bondInstrSync,bond_historical_prices_download,currencyHistPriceDownload,interest_rates_price_download,comparableHistPriceDownload,ir_node_curve_refresh};
	
	//final static Integer[] autoReportGenerationGlobalBatch  = new Integer[] {reportGeneration};
	
	/***********************************************
	 *               JOB HASH MAP                  *
	 *  A pre-built map called from Async Starter  *
	 *  to obtain the right job category 		   *
	 **********************************************/
	
	public static LinkedHashMap<Integer,Integer> jobMap() {
		
		LinkedHashMap<Integer,Integer> jobMap = new LinkedHashMap<Integer, Integer>();
			
		for (Integer id:computationJobsArray) {
			jobMap.put(id,0);
		}
		
		for (Integer id:approvalJobsArray) {
			jobMap.put(id,1);
		}
		
		for (Integer id:alerterJobsArray) {
			jobMap.put(id,2);
		}
		
		for (Integer id:priceDownloadJobsArray) {
			jobMap.put(id,3);
		}
		
		for (Integer id:synchroJobsArray) {
			jobMap.put(id,4);
		}
		
		for (Integer id:exportJobsArray) {
			jobMap.put(id,5);
		}
		
		for (Integer id:stressTestJobsArray) {
			jobMap.put(id,6);
		}
		
		for (Integer id:refreshJobsArray) {
			jobMap.put(id,7);
		}
		
		for (Integer id:globalBatchArray) {
			jobMap.put(id,8);
		}
		
		for (Integer id:globalOEKBBatchArray) {
			jobMap.put(id,9);
		}
		
		for (Integer id:oekbJobsArray) {
			jobMap.put(id,10);
		}
		
		for (Integer id:oeKBStressTestJobsArray) {
			jobMap.put(id,11);
		}
		for (Integer id:reportJobsArray) {
			jobMap.put(id,12);
		}
		for (Integer id:analysysArray) {
			jobMap.put(id,13);
		}
		
		return jobMap;
		
	}
	
	/***********************************************
	 *               BATCH VECTOR                  *
	 *  A vector built starting from an entering   *
	 *  batch Id to enque the right job sequence   *
	 *   		   								   *
	 **********************************************/
	
	public static Vector<Integer> batchQueueVector(int batchId) {
		
		List<Integer> batchQueue = new ArrayList<Integer>();
		
		switch (batchId) {
		
			case 1000:
				batchQueue = Arrays.asList(equityGlobalBatch);
				break;
			case 1002:
				batchQueue = Arrays.asList(bondGlobalBatch);
				break;
			case 1010:
				batchQueue = Arrays.asList(eqStressTestGlobalBatch);
				break;
			case 1011:
				batchQueue = Arrays.asList(bondStressTestGlobalBatch);
				break;
			case 1012:
				batchQueue = Arrays.asList(importGlobalBatch);
				break;
			case 1013:
				batchQueue = Arrays.asList(equityStressTestPAMPvsIntracsBatch);
				break;
			case 1014:
				batchQueue = Arrays.asList(bondStressTestPAMPvsIntracsBatch);
				break;
			/*case 2000:
				batchQueue = Arrays.asList(autoReportGenerationGlobalBatch);*/	
			case 3000:
				batchQueue = Arrays.asList(oekbEquityGlobalBatch);
		}
		
		Vector<Integer> queueVect = new Vector<Integer>();
		
		for (Integer batchInt:batchQueue) {
			queueVect.add(batchInt);
		}
		
		//Collections.copy(queueVect, batchQueue);
				
		return queueVect;
	}
}
