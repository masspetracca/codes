package it.ccg.pamp.server.utils;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.Set;

import javax.ejb.Local;

@Local
public interface GroupUtilsLocal {
	
	public  boolean isAlreadyStored(Set<Integer> group) throws DataNotValidException;

}
