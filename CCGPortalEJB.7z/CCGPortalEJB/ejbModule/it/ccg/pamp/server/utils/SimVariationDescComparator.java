package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.SimulationVariation;


import java.util.Comparator;

public class SimVariationDescComparator  implements Comparator {

	
	public int compare(Object object1, Object object2) {
	SimulationVariation var1= (SimulationVariation) object1;
	SimulationVariation var2= (SimulationVariation) object2;
	
	return var2.getVariat().abs().compareTo(var1.getVariat().abs());	
	}

}