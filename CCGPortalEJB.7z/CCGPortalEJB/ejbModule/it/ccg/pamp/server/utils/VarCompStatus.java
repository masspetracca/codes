package it.ccg.pamp.server.utils;

import java.sql.Timestamp;

public class VarCompStatus {
	private boolean varCompIsEnabled;
	private Timestamp lastCompHPRDate;
	public VarCompStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
	public VarCompStatus(boolean varCompIsEnabled, Timestamp lastCompHPRDate) {
		super();
		this.varCompIsEnabled = varCompIsEnabled;
		this.lastCompHPRDate = lastCompHPRDate;
	}
	public boolean isVarCompIsEnabled() {
		return varCompIsEnabled;
	}
	public void setVarCompIsEnabled(boolean varCompIsEnabled) {
		this.varCompIsEnabled = varCompIsEnabled;
	}
	public Timestamp getLastCompHPRDate() {
		return lastCompHPRDate;
	}
	public void setLastCompHPRDate(Timestamp lastCompHPRDate) {
		this.lastCompHPRDate = lastCompHPRDate;
	}
	
	
	
}
