package it.ccg.pamp.server.utils;


public class BondClassCouplePar {
	private static final long serialVersionUID = 1L;
	private int nv;
	private int nDaysPer;
	
	public BondClassCouplePar(int nv,int nDaysPer) {
		super();
		this.setNv(nv);
		this.setNDaysPer(nDaysPer);
	}

	public void setNv(int nv) {
		this.nv = nv;
	}

	public int getNv() {
		return nv;
	}

	public void setNDaysPer(int nDaysPer) {
		this.nDaysPer= nDaysPer;
	}
	
	public int getNDaysPer() {
		return nDaysPer;
	}
}
