package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;
import it.ccg.pamp.server.entities.stressTest.StressTestStatistic;

import java.util.Vector;

public class BondStressTestResults {

	private Vector<StressTestHistPrice> stHistPriceVec;
	private Vector<StressTestStatistic> stStatVec;

	public BondStressTestResults() {
		super();
		
	}

	public BondStressTestResults(Vector<StressTestHistPrice> stHistPriceVec, Vector<StressTestStatistic> stStatVec) {
		super();
		this.stHistPriceVec = stHistPriceVec;
		this.stStatVec = stStatVec;
	}

	public Vector<StressTestHistPrice> getStHistPriceVec() {
		return stHistPriceVec;
	}

	public void setStHistPriceVec(Vector<StressTestHistPrice> stHistPriceVec) {
		this.stHistPriceVec = stHistPriceVec;
	}

	public Vector<StressTestStatistic> getStStatVec() {
		return stStatVec;
	}

	public void setStStatVec(Vector<StressTestStatistic> stStatVec) {
		this.stStatVec = stStatVec;
	}

}
