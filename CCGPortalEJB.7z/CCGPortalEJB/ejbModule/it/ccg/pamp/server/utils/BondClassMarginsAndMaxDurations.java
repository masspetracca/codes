package it.ccg.pamp.server.utils;

import java.io.Serializable;
import java.math.BigDecimal;

public class BondClassMarginsAndMaxDurations implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int classId;
	private BigDecimal maxModDur;
	private BigDecimal userMargin;
	private BigDecimal workingMargin;
	
	public BondClassMarginsAndMaxDurations() {
		super();
	}
	
	public BondClassMarginsAndMaxDurations(int classId, BigDecimal maxModDur, BigDecimal userMargin, BigDecimal workingMargin) {
		super();
		this.classId = classId;
		this.maxModDur = maxModDur;
		this.userMargin = userMargin;
		this.workingMargin = workingMargin;
	}

	public int getClassId() {
		return classId;
	}

	public void setClassId(int classId) {
		this.classId = classId;
	}

	public BigDecimal getMaxModDur() {
		return maxModDur;
	}

	public void setMaxModDur(BigDecimal maxModDur) {
		this.maxModDur = maxModDur;
	}

	public BigDecimal getUserMargin() {
		return userMargin;
	}

	public void setUserMargin(BigDecimal userMargin) {
		this.userMargin = userMargin;
	}

	public BigDecimal getWorkingMargin() {
		return workingMargin;
	}

	public void setWorkingMargin(BigDecimal workingMargin) {
		this.workingMargin = workingMargin;
	}	

}
