package it.ccg.pamp.server.utils;

public class PampInstrument {
	
	int instrID;
	boolean onRiskEng;
	
	
	public PampInstrument() {
		super();
	}


	public PampInstrument(int instrID, boolean foundOnRiskEng) {
		super();
		this.instrID = instrID;
		this.onRiskEng = foundOnRiskEng;
	}


	public int getInstrID() {
		return instrID;
	}


	public void setInstrID(int instrID) {
		this.instrID = instrID;
	}


	public boolean isOnRiskEng() {
		return onRiskEng;
	}


	public void setOnRiskEng(boolean foundOnRiskEng) {
		this.onRiskEng = foundOnRiskEng;
	}
	
	
	

}
