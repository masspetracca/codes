package it.ccg.pamp.server.utils;

import java.io.Serializable;
import java.math.BigDecimal;

public class MarginCustomObj implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private int instrId;
	
	private String propose;
	
	private BigDecimal userMargin;
	
	private int undInstrId;
	
	private BigDecimal undUserMargin;
	
	
	public MarginCustomObj() {
		super();
	}


	public int getInstrId() {
		return instrId;
	}


	public void setInstrId(int instrId) {
		this.instrId = instrId;
	}


	public String getPropose() {
		return propose;
	}


	public void setPropose(String propose) {
		this.propose = propose;
	}


	public BigDecimal getUserMargin() {
		return userMargin;
	}


	public void setUserMargin(BigDecimal userMargin) {
		this.userMargin = userMargin;
	}


	public int getUndInstrId() {
		return undInstrId;
	}


	public void setUndInstrId(int undInstrId) {
		this.undInstrId = undInstrId;
	}
	
	public BigDecimal getUndUserMargin() {
		return undUserMargin;
	}


	public void setUndUserMargin(BigDecimal undUserMargin) {
		this.undUserMargin = undUserMargin;
	}

}
