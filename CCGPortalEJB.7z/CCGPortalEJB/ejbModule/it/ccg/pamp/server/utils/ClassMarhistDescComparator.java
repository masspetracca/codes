package it.ccg.pamp.server.utils;


import it.ccg.pamp.server.entities.ClassMarginHistory;

import java.util.Comparator;

public class ClassMarhistDescComparator implements	Comparator {

		
		public int compare(Object object1, Object object2) {
			ClassMarginHistory bc1= (ClassMarginHistory) object1;
			ClassMarginHistory bc2= (ClassMarginHistory) object2;
		
			return bc2.getPk().getIniVDate().compareTo(bc1.getPk().getIniVDate());	
		}

}


