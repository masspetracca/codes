package it.ccg.pamp.server.utils;

import java.math.BigDecimal;


public class BondClassStatisticGroupedBy {
	private static final long serialVersionUID = 1L;
	private int instrId1, instrId2;
	private BigDecimal correl;
	private BigDecimal pearson;
	private BigDecimal divundiv;
	private int histDays;
	
	public BondClassStatisticGroupedBy(int instrId1, int instrId2, BigDecimal correl,BigDecimal pearson,BigDecimal divundiv,int histDays) {
		super();
		this.setInstrId1(instrId1);
		this.setInstrId2(instrId2);
		this.setCorrel(correl);
		this.setPearson(pearson);
		this.setDivundiv(divundiv);
		this.setHistDays(histDays);
	}
	
	public int getInstrId1() {
		return instrId1;
	}
	public void setInstrId1(int instrId1) {
		this.instrId1 = instrId1;
	}
	public int getInstrId2() {
		return instrId2;
	}
	public void setInstrId2(int instrId2) {
		this.instrId2 = instrId2;
	}
	public BigDecimal getCorrel() {
		return correl;
	}
	public void setCorrel(BigDecimal correl) {
		this.correl = correl;
	}
	public BigDecimal getPearson() {
		return pearson;
	}
	public void setPearson(BigDecimal pearson) {
		this.pearson = pearson;
	}
	public BigDecimal getDivundiv() {
		return divundiv;
	}
	public void setDivundiv(BigDecimal divundiv) {
		this.divundiv = divundiv;
	}
	public int getHistDays() {
		return histDays;
	}
	public void setHistDays(int histDays) {
		this.histDays = histDays;
	}
}
