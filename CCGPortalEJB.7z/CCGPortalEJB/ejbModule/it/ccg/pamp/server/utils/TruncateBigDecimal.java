package it.ccg.pamp.server.utils;

import java.math.BigDecimal;

public class TruncateBigDecimal {
	
	private static final long serialVersionUID = 1L;
	private String newMargin;
	
	public TruncateBigDecimal(BigDecimal bigD) {
		super();
		this.newMargin = truncateBigDecimal(bigD);
	}
	
	public String truncateBigDecimal (BigDecimal bigD) {
		
		String margin = bigD.toString();
		String integer = margin.substring(0,margin.indexOf("."));
		String decimal = margin.substring(margin.indexOf(".")+1);
		int counter = 0;
		
		for (int i=decimal.length();i>0;i--) {
			if (i<3) {
				if (decimal.substring(i-1,i).equals("0")) {
					counter++;
				} 
				if (i==1 || (!decimal.substring(i-1,i).equals("0"))) {
					break;
				}
			} else {
				if ( decimal.substring(i-1).equals("0") || decimal.substring(i-2,i-1).equals("0") || i<3) {
					counter++;
				} else {
					break;
				}
			}
		}
		
		String newMargin = integer+"."+decimal.substring(0,decimal.length()-counter);
		return newMargin;
	}

	public void setNewMargin(String newMargin) {
		this.newMargin = newMargin;
	}

	public String getNewMargin() {
		return newMargin;
	}
}
