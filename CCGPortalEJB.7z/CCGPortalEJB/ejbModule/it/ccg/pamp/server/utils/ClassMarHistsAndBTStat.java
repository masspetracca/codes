package it.ccg.pamp.server.utils;

import it.ccg.pamp.server.entities.ClassMarginHistory;
import it.ccg.pamp.server.entities.backTest.BackTestStatistic;

import java.util.List;

public class ClassMarHistsAndBTStat {
	
	private List<ClassMarginHistory> clmarhistarr;
	private BackTestStatistic btStat;
	
	public ClassMarHistsAndBTStat() {
		super();
	}

	public ClassMarHistsAndBTStat(List<ClassMarginHistory> clmarhistarr, BackTestStatistic btStat) {
		super();
		this.clmarhistarr = clmarhistarr;
		this.btStat = btStat;
	}

	public List<ClassMarginHistory> getClmarhistarr() {
		return clmarhistarr;
	}

	public void setClmarhistarr(List<ClassMarginHistory> clmarhistarr) {
		this.clmarhistarr = clmarhistarr;
	}

	public BackTestStatistic getBtStat() {
		return btStat;
	}

	public void setBtStat(BackTestStatistic btStat) {
		this.btStat = btStat;
	}
	
	
	
	

}
