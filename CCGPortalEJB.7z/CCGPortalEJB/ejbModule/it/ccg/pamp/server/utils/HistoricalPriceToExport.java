package it.ccg.pamp.server.utils;

import java.sql.Timestamp;

import it.ccg.pamp.server.entities.DerivativesHistoricalPrice;
import it.ccg.pamp.server.entities.HistoricalPrices;
import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.Instrument;

public class HistoricalPriceToExport {

	private HistoricalPrices historicalPrice;
	
	private DerivativesHistoricalPrice[] derHistoricalPriceArr;
		
	private Instrument instrument;
	
	private Instrument underlyingInstrument;
		
	private InstrIdTrascode[] instrIdTC;
	
	private InstrIdTrascode[] rectifiedClass;
	
	private Timestamp refDate;
		
	
	public HistoricalPriceToExport() {
		super();
	}
		
		public HistoricalPriceToExport(HistoricalPrices histPrice, DerivativesHistoricalPrice[] derHistoricalPriceArr, Instrument instrument, Instrument underlyingInstrument, InstrIdTrascode[] instrIdTC, InstrIdTrascode[] rectifiedClass, Timestamp refDate) {
			super();
			this.historicalPrice = histPrice;
			this.setDerHistoricalPriceArr(derHistoricalPriceArr);
			this.instrument = instrument;
			this.underlyingInstrument = underlyingInstrument;
			this.instrIdTC = instrIdTC;
			this.rectifiedClass = rectifiedClass;
			this.refDate = refDate;
		}
		
		

		public HistoricalPrices getHistoricalPrice() {
			return historicalPrice;
		}

		public void setHistoricalPrice(HistoricalPrices historicalPrice) {
			this.historicalPrice = historicalPrice;
		}

		public void setDerHistoricalPriceArr(DerivativesHistoricalPrice[] derHistoricalPriceArr) {
			this.derHistoricalPriceArr = derHistoricalPriceArr;
		}

		public DerivativesHistoricalPrice[] getDerHistoricalPriceArr() {
			return derHistoricalPriceArr;
		}

		public Instrument getInstrument() {
			return instrument;
		}

		public void setInstrument(Instrument instrument) {
			this.instrument = instrument;
		}
		
		public Instrument getUnderlyingInstrument() {
			return underlyingInstrument;
		}

		public void setUnderlyingInstrument(Instrument underlyingInstrument) {
			this.underlyingInstrument = underlyingInstrument;
		}

		public void setInstrIdTC(InstrIdTrascode[] instrIdTC) {
			this.instrIdTC = instrIdTC;
		}

		public InstrIdTrascode[] getInstrIdTC() {
			return instrIdTC;
		}
		
		public void setRectifiedClass(InstrIdTrascode[] rectifiedClass) {
			this.rectifiedClass = rectifiedClass;
		}

		public InstrIdTrascode[] getRectifiedClass() {
			return rectifiedClass;
		}
		
		public void setRefDate(Timestamp refDate) {
			this.refDate = refDate;
		}

		public Timestamp getRefDate() {
			return refDate;
		}

}
