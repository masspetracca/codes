package it.ccg.pamp.server.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;


public class ZipCreator {

	private String zipFullPath;
	
	public ZipCreator() {
		super();
	}
	
	public ZipCreator(List<String> fileListToZip, String zipFileName, String outputPath) {
		super();
		this.createZipFile(fileListToZip, zipFileName,outputPath);
	}
	
	

	public void createZipFile(List<String> fileListToZip, String zipFileName, String outputPath) {
		
		// directory scelta per la scrittura dello zip
		String zipFileRoot = outputPath+"/";
		
		// Creo un buffer
		byte[] buf = new byte[1024];
		
		try {
		    
			//creo lo zip
		   
		    ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipFileRoot+zipFileName+".zip"));
		   
		    // Comprimo i files
		    for (String filename: fileListToZip) {
		    	  	
		    	FileInputStream in = new FileInputStream(filename);
		         // prendo il path di ogni file da comprimere
		    	String[] arrFilePath = filename.split("/");
		    	out.putNextEntry(new ZipEntry(arrFilePath[arrFilePath.length-1]));
	
		        // Trasferisco i bytes dal file allo ZIP
		        int len;
		        while ((len = in.read(buf)) > 0) {
		            out.write(buf, 0, len);
		        }
	
		        // Chiudo il giro
		        out.closeEntry();
		        in.close();
		        
		    }
		    
		    // setto il percorso completo dello zip
		    this.setZipFullPath(zipFileName+".zip");
		    
		    // cancello tutti file appena zippati dalla cartella che li conteneva
		    this.deleteCompressedFile(fileListToZip);
		   
		    out.close();
		} catch (IOException e) {
			
		}
	}
	
	public void deleteCompressedFile(List<String> filesToDelete) {
		
		for (String fileStr:filesToDelete) {
			try {
				File file = new File(fileStr);
				file.delete();
			} catch (Exception e) {
				
			}
		}
		
	}

	public void setZipFullPath(String zipFullPath) {
		this.zipFullPath = zipFullPath;
	}

	public String getZipFullPath() {
		return zipFullPath;
	}
	
}
