package it.ccg.pamp.server.bus;
import java.util.LinkedHashMap;
import java.util.Vector;

import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.exceptions.BigDecimalException;
import it.ccg.pamp.server.exceptions.BondClassDataNotAvailableException;
import it.ccg.pamp.server.exceptions.ClassMarginHistoryAlreadyStoredException;
import it.ccg.pamp.server.exceptions.ClassMarginNotSubmittedForApprovalException;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.exceptions.InterclassAlreadyStoredException;
import it.ccg.pamp.server.exceptions.InterclassNotSubmittedForApprovalException;
import it.ccg.pamp.server.exceptions.IntraclassAlreadyStoredException;
import it.ccg.pamp.server.exceptions.IntraclassNotSubmittedForApprovalException;
import it.ccg.pamp.server.exceptions.LargeVariationException;
import it.ccg.pamp.server.exceptions.NotValidStatusException;
import it.ccg.pamp.server.exceptions.StatisticException;
import it.ccg.pamp.server.exceptions.WorkingMarginNotAvailableException;
import it.ccg.pamp.server.utils.BondBTInstrumentError;
import it.ccg.pamp.server.utils.BondClassCouple;
import it.ccg.pamp.server.utils.ClassMarHistsAndBTStat;

import javax.ejb.Local;

@Local
public interface BondBatchLocal {
	//public void exeBondBatch(Instrument instr) throws InstrumentDataNotAvailableException, InstrumentDataNotValidException, DataNotValidException, DataNotAvailableException, LargeVariationException, StatisticException;
	
	
	
	
	public void calcClassMargin(BondClass bondclass) throws DataNotValidException, DataNotAvailableException, InstrumentDataNotAvailableException, LargeVariationException, StatisticException, BigDecimalException;
	
	
	public void eraseOldEquitiesData() throws DataNotValidException ;
	
	public void submitBondsForApproval() throws DataNotValidException, InstrumentDataNotAvailableException, NotValidStatusException, DataNotAvailableException, WorkingMarginNotAvailableException;
	
	public void recallBondSubmission() throws DataNotValidException, InstrumentDataNotAvailableException;
	
	public void approveBonds() throws DataNotValidException, ClassMarginHistoryAlreadyStoredException, ClassMarginNotSubmittedForApprovalException, IntraclassNotSubmittedForApprovalException, IntraclassAlreadyStoredException, InterclassNotSubmittedForApprovalException, InterclassAlreadyStoredException;
	
	
	//public void approveIntraInterclass() throws DataNotValidException, IntraclassNotSubmittedForApprovalException, IntraclassAlreadyStoredException, InterclassNotSubmittedForApprovalException, InterclassAlreadyStoredException;
	public void calcNodeAndInterpolatedNodeMargins() throws DataNotValidException, DataNotAvailableException, InstrumentDataNotAvailableException, LargeVariationException, StatisticException, BigDecimalException;

	public abstract void calcBackTestBondBatch(BondClass bondclass, int btid, LinkedHashMap<Integer, ClassMarHistsAndBTStat> classMarHisAndBTStatHashMap, Vector<BondBTInstrumentError> btinstrerrvec) throws DataNotValidException, DataNotAvailableException, InstrumentDataNotAvailableException,
			LargeVariationException;


	public abstract void calcIntraClassBatch(BondClass bondclass) throws DataNotValidException, DataNotAvailableException, InstrumentDataNotAvailableException;


	public abstract void eraseOldInterIntraData(String divisCode) throws DataNotValidException;


	public abstract void calcInterClassBatch(BondClassCouple bc, String divisCode) throws DataNotValidException, DataNotAvailableException, InstrumentDataNotAvailableException,
			BondClassDataNotAvailableException;


	public void updateClassMarginFromBackTest(String[] classIDArr, String justIfGreater) throws DataNotValidException, DataNotAvailableException;


	public int replicateConfOnAllCurveNodes(int instrID,String listName) throws DataNotValidException;


	void removeOldBackTestBreaches() throws DataNotValidException;


	void calcAndStoreBackTestClassStats(LinkedHashMap<Integer, ClassMarHistsAndBTStat> classMarHisAndBTStatHashMap) throws DataNotValidException;


	void sortAndUpdateBTBreach(int classID) throws DataNotValidException;


	
}
