package it.ccg.pamp.server.bus;
import java.sql.Timestamp;
import java.util.HashMap;

import it.ccg.pamp.server.entities.ClassHaircut;
import it.ccg.pamp.server.entities.ClassMargin;
import it.ccg.pamp.server.entities.ElecMargin;
import it.ccg.pamp.server.entities.Group;
import it.ccg.pamp.server.entities.InterclassOffset;
import it.ccg.pamp.server.entities.IntraclassOffset;
import it.ccg.pamp.server.entities.Margin;
import it.ccg.pamp.server.entities.MinimumMargin;
import it.ccg.pamp.server.entities.Straddle;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface GeneralCalcUnitLocal {
	public  void analysisMargin(Margin marg,Timestamp analysisDate,HashMap<String, String> diviscodeHash) throws DataNotValidException, DataNotAvailableException;
	
	public void analysisStraddle(Straddle strad,Timestamp analysisDate) throws DataNotValidException, DataNotAvailableException;
	
	public void analysisMinMargin(MinimumMargin minmar,Timestamp analysisDate) throws DataNotValidException, DataNotAvailableException;
	
	public Group analysisGroup(Group group,Timestamp analysisDate)throws DataNotValidException, DataNotAvailableException;
	
	public void analysisClassMargin(ClassMargin classmarg,Timestamp analysisDate) throws DataNotValidException, DataNotAvailableException;
	
	public void analysisIntraClassOffset(IntraclassOffset intraclass,Timestamp analysisDate) throws DataNotValidException, DataNotAvailableException;
	public void analysisInterClassOffset(InterclassOffset interclass,Timestamp analysisDate) throws DataNotValidException, DataNotAvailableException ;
	
	public void analysisElecMargin(ElecMargin elecmarg, Timestamp analysisDate) throws DataNotValidException, DataNotAvailableException;

	public abstract void analysisClassHaircut(ClassHaircut classHairCut, Timestamp analysisDate) throws DataNotValidException, DataNotAvailableException;
	

}
