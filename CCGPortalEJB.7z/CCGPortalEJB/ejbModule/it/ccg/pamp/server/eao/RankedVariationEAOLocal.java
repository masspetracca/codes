package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.RankedVariation;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface RankedVariationEAOLocal {
	
	public RankedVariation[] fetch() throws DataNotValidException;
	
	public RankedVariation[] findByInstrId(int instrId) throws DataNotValidException;
	
	public List<RankedVariation> findByInstrIdOrderByVar(int instrId) throws DataNotValidException;

	public List<RankedVariation> findPosOrNegOrAllRankedVarByInstrIdAndNDaysPerAndMode(int instrId, int nDaysPer, int mode, int posOrNegOrAll,int[] nvArr) throws DataNotValidException;
	
	public RankedVariation[] fetchWithMode1() throws DataNotValidException;
	
	public RankedVariation[] findByInstrIdAndNvAndRank(int instrId, int nv, int rank) throws DataNotValidException;
	
	public List<String> printRankedVariations(int instrId, int nv) throws DataNotValidException;
	
	public RankedVariation findByPrimaryKey(int instrId, int nv, int nDaysPer, int rank, String varType, int mode) throws DataNotValidException;
	
	public void add(int instrId, int nv, int nDaysPer, int rank, String varType, int mode, Timestamp priceDate, BigDecimal variat, String status) throws DataNotValidException;
	
	public void store(RankedVariation rankedVariation) throws DataNotValidException;
	
	public void update(int instrId, int nv, int nDaysPer, int rank, String varType, int mode, Timestamp priceDate, BigDecimal variat, String status) throws DataNotValidException;
	
	public void update(RankedVariation rankVariation) throws DataNotValidException;
	
	public void remove(int instrId, int nv, int nDaysPer, int rank, String varType, int mode) throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
	public int removeByMode(int Mode) throws DataNotValidException;
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException;
	
	public void remove(RankedVariation rankVariation) throws DataNotValidException;
	
	public int transferMode1inMode2() throws DataNotValidException;
	
	public void transferMode1To2() throws DataNotValidException;
	
	public void transferMode1To2ByDivision(List<String> divisCodeList) throws DataNotValidException;
	
}
