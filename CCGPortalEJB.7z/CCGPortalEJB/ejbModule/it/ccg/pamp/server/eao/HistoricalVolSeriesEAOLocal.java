package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.HistoricalVolSeries;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.ejb.Local;

@Local
public interface HistoricalVolSeriesEAOLocal {
	public HistoricalVolSeries[] fetch() throws DataNotValidException;
	public HistoricalVolSeries findByPrimaryKey(int instrId, Timestamp volaDate, int progExp, String pc, BigDecimal strike,String isinCode) throws DataNotValidException;
	public HistoricalVolSeries[] findByInstrId(int instrId) throws DataNotValidException;
	public void add(int instrId, Timestamp volaDate, int progExp, String pc, BigDecimal strike, String status, BigDecimal vola, int expiry,String isinCode) throws DataNotValidException;
	public void store(HistoricalVolSeries historicalVolSeries) throws DataNotValidException;
	public void update(int instrId, Timestamp volaDate, int progExp, String pc, BigDecimal strike, String status, BigDecimal vola, int expiry,String isinCode) throws DataNotValidException; 
	public void update(HistoricalVolSeries histVolSeries) throws DataNotValidException;
	public void remove(int instrId, Timestamp volaDate, int progExp, String pc, BigDecimal strike,String isinCode) throws DataNotValidException;
	public int removeByInstrId(int instrId) throws DataNotValidException;
	public void remove(HistoricalVolSeries histVolSeries) throws DataNotValidException;
}	
