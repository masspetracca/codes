package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Ccgdur00f;
import it.ccg.pamp.server.entities.Ccgdur00fPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondToSync;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class Ccgdur00fEAO
 */
@Stateless
public class Ccgdur00fEAO implements Ccgdur00fEAOLocal {

	@PersistenceContext(unitName="STDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public List<Ccgdur00f> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllCcgdur00f");
    		List<Ccgdur00f> ccgdur00fList = query.getResultList();
    		return ccgdur00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Ccgdur00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	//@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<Ccgdur00f> getCcgdur00fByDate(Timestamp priceDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCcgdur00fByDate");
    		query.setParameter("", new BigDecimal(GenericTools.shortDateFormatAsLong(priceDate)));
    		List<Ccgdur00f> ccgdur00fList = query.getResultList();
    		return ccgdur00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Ccgdur00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<BondToSync> getBondToSync() throws DataNotValidException {
		Query query = null;
		
		String sqlString = "SELECT D.EBM_CTYP AS ISINCODE, "+
							"D.EBM_DESCR AS DESCRIPTION, "+ 
							"N.MCURR AS CURRENCY, "+ 
							"EBM_COUP_T AS COUPONTYPE, "+
							"D.EBM_COUP_F AS COUPONFREQ, "+
							"D.EBM_FC_DAT AS COUPNEXTDATE, "+
							"N.MDURATIO AS DURATION, "+
							"N.MCLASSE AS BNDCLASSID, "+
							"D.EBM_BOND_C AS COMPART, "+
							"S.PPRICE AS LASTPRICE, "+
							"S.PDATAR AS DURREFDATE, "+
							"D.EBM_MAT_DT AS EXPIRY, "+
							"EBM_FC_RAT AS COUPONINTEREST "+
				
							"FROM EBMPRDPL3 AS D "+
							"INNER JOIN "+ 
							"(SELECT DISTINCT M.MBISIN,M.MDURATIO,M.MCLASSE,M.MCURR FROM MTSMGNF30F M ) AS N ON D.EBM_CTYP=N.MBISIN "+
							"INNER JOIN MTSPRICE S ON S.PISINC=D.EBM_CTYP "+
					
							/*"WHERE D.EBM_CTYP LIKE 'IT%' "+
							"AND D.EBM_MKT_CD='0004' "+*/
							
							"WHERE D.EBM_MKT_CD='0004' "+
					
							"ORDER BY D.EBM_CTYP";
		
   			try {
    			query =  em.createNativeQuery(sqlString,BondToSync.class);
    		}  catch (Exception e) {
    			e.getStackTrace();
    		}
    			
    		List<BondToSync> bondToSyncList = query.getResultList();
    		
    		return bondToSyncList;
    }
	
	//@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public Ccgdur00f findByPrimaryKey(String isinCode, BigDecimal numCed, Timestamp priceDate) throws DataNotValidException {
		try {
			Ccgdur00fPK pK = new Ccgdur00fPK();
			pK.setD0isinco(isinCode);
			pK.setD0numced(numCed);
			pK.setD0dtacal(new BigDecimal(GenericTools.shortDateFormatAsLong(priceDate)));
			Ccgdur00f ccgdur00f = (Ccgdur00f) em.find(Ccgdur00f.class,pK);
			return ccgdur00f;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Ccgdur00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Ccgdur00f> findByNumCed(BigDecimal numCed) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getCcgdur00fByNumCed");
			query.setParameter("numCed",numCed);
			List<Ccgdur00f> ccgdur00fList = query.getResultList();
    		return ccgdur00fList;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Ccgdur00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	

}
