package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.QueueStatus;
import it.ccg.pamp.server.entities.ReportRefresh;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.*;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ReportRefreshEAO
 */
@Stateless
public class ReportRefreshEAO implements  ReportRefreshEAOLocal {
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
		
	public void store() throws DataNotValidException {
		try {
			ReportRefresh repRef = new ReportRefresh();
			repRef.setRepDate(GenericTools.systemDate());
			repRef.setUpdDate(GenericTools.systemDate());
			repRef.setUpdType(updType);
			repRef.setUpdUsr(userString());
			em.persist(repRef);
			log.debug("Added new report refresh");
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new report refresh - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
