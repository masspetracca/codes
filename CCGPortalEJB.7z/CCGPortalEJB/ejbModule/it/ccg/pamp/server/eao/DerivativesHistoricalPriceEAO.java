package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.DerivativesHistoricalPrice;
import it.ccg.pamp.server.entities.DerivativesHistoricalPricePK;
import it.ccg.pamp.server.entities.HistoricalPrices;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class DerivativesHistoricalPriceEAO
 */
@Stateless
public class DerivativesHistoricalPriceEAO implements  DerivativesHistoricalPriceEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	
	public DerivativesHistoricalPrice[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllDerivativesHisPr");
    		List<DerivativesHistoricalPrice> derivativesHistoricalPrice = query.getResultList();
    		DerivativesHistoricalPrice[] arrDerivativesHistoricalPrice = new DerivativesHistoricalPrice[derivativesHistoricalPrice.size()];
    		return derivativesHistoricalPrice.toArray(arrDerivativesHistoricalPrice);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching historical price series historical price series - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPrice[] findByInstrIdAfterDate(int instrId, Timestamp priceDate) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getDerHistByInstrIdAfterDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("priceDate", priceDate);
    		query.setMaxResults(1);
    		List<HistoricalPrices> historicalPricesList = query.getResultList();
    		DerivativesHistoricalPrice[] derHistArr = new DerivativesHistoricalPrice[historicalPricesList.size()];
    		historicalPricesList.toArray(derHistArr);
    		return derHistArr;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching next derivative historical price - instrId: "+instrId+"; date: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPrice findByPrimaryKey(int instrId, Timestamp priceDate, String pc, BigDecimal strike, int expiry, String code) throws DataNotValidException {
		try {
			DerivativesHistoricalPricePK pK = new DerivativesHistoricalPricePK();
			pK.setInstrId(instrId);
			pK.setPriceDate(priceDate);
			pK.setPc(pc);
			pK.setStrike(strike);
			pK.setExpiry(expiry);
			pK.setCode(code);
			DerivativesHistoricalPrice derivativesHistoricalPrice = (DerivativesHistoricalPrice) em.find(DerivativesHistoricalPrice.class,pK);
    		return derivativesHistoricalPrice;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching derivative historical price series - instrId: "+instrId+"; priceDate:"+priceDate+"; pc: "+pc+"; strike: "+strike+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPrice[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDerivativesHPByInstrId");
    		query.setParameter("instrId", instrId);
    		query.setParameter("strike", new BigDecimal(0));
    		List<DerivativesHistoricalPrice> derivativesHistoricalPrice = query.getResultList();
    		DerivativesHistoricalPrice[] arrDerivativesHistoricalPrice = new DerivativesHistoricalPrice[derivativesHistoricalPrice.size()];
    		return derivativesHistoricalPrice.toArray(arrDerivativesHistoricalPrice);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching derivative historical price series - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPrice[] findByInstrIdAndPc(int instrId, String pc) throws DataNotValidException {
		Query query = null;
    	try {
    		if (pc.equalsIgnoreCase("F")) {
				query = em.createNamedQuery("getDerivativesHPFuturesByInstrId");
			} else {
				query = em.createNamedQuery("getDerivativesHPOptionsByInstrId");
			}
			query.setParameter("instrId", instrId);
    		List<DerivativesHistoricalPrice> derivativesHistoricalPrice = query.getResultList();
    		DerivativesHistoricalPrice[] arrDerivativesHistoricalPrice = new DerivativesHistoricalPrice[derivativesHistoricalPrice.size()];
    		return derivativesHistoricalPrice.toArray(arrDerivativesHistoricalPrice);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching derivative historical price series - instrId: "+instrId+"; pc:"+pc+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int getTimeWindow(int instrId, Timestamp firstDate, Timestamp lastDate) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getDerHPbyTimeWindow");
    		query.setParameter("instrId", instrId);
    		query.setParameter("firstDate", firstDate);
    		query.setParameter("lastDate", lastDate);
    		Long counter = (Long) query.getSingleResult();
    		return counter.intValue();
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last derivative historical price - instrId: "+instrId+"; time window: "+firstDate+ " - "+lastDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPrice findBeforeDate(int instrId, Timestamp priceDate) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getDerHPBeforeLastDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("priceDate", priceDate);
    		query.setMaxResults(1);
    		List<DerivativesHistoricalPrice> derHistoricalPricesList = query.getResultList();
    		if (derHistoricalPricesList.size()>0) {
    			return derHistoricalPricesList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last derivative historical price - instrId: "+instrId+"; date: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPrice findLastDateByInstrument(Instrument instr) throws DataNotValidException {
		Query query = null;
		String pc = "F";
		
		if (instr.getInstrType().equalsIgnoreCase("O")) {
			pc = "P";
		}
		try {
			
			
			query = em.createNamedQuery("getDerivativesHPByInstrIdAndPc");
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("pc", pc);
    		query.setMaxResults(1);
    		List<DerivativesHistoricalPrice> derHistoricalPricesList = query.getResultList();
    		if (derHistoricalPricesList.size()>0) {
    			return derHistoricalPricesList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last derivative historical price - instrId: "+instr.getInstrId()+"; pc: "+pc+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPrice[] findByInstrIdAndDate(int instrId, Timestamp lastDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDerivativesByInstrIdAndDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("lastDate", lastDate);
    		List<DerivativesHistoricalPrice> derivativesHistoricalPrices = query.getResultList();
    		DerivativesHistoricalPrice[] arrDerivativesHistoricalPrice = new DerivativesHistoricalPrice[derivativesHistoricalPrices.size()];
    		return derivativesHistoricalPrices.toArray(arrDerivativesHistoricalPrice);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching derivative historical price series - instrId: "+instrId+"; date: "+lastDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPrice[] findFutureByInstrIdAndDate(int instrId, Timestamp lastDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getFutureByInstrIdAndDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("lastDate", lastDate);
    		List<DerivativesHistoricalPrice> derivativesHistoricalPrices = query.getResultList();
    		DerivativesHistoricalPrice[] arrDerivativesHistoricalPrice = new DerivativesHistoricalPrice[derivativesHistoricalPrices.size()];
    		return derivativesHistoricalPrices.toArray(arrDerivativesHistoricalPrice);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Futures historical price series - instrId: "+instrId+"; date: "+lastDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPrice[] findOptionByInstrIdAndDate(int instrId, Timestamp lastDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getOptionByInstrIdAndDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("lastDate", lastDate);
    		List<DerivativesHistoricalPrice> derivativesHistoricalPrices = query.getResultList();
    		DerivativesHistoricalPrice[] arrDerivativesHistoricalPrice = new DerivativesHistoricalPrice[derivativesHistoricalPrices.size()];
    		return derivativesHistoricalPrices.toArray(arrDerivativesHistoricalPrice);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Options historical price series - instrId: "+instrId+"; date: "+lastDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, Timestamp priceDate, String pc, BigDecimal strike, int expiry, String code, String status, BigDecimal impVola, BigDecimal closePr) throws DataNotValidException {
		try {
			DerivativesHistoricalPrice derivativesHistoricalPrice = new DerivativesHistoricalPrice();
			DerivativesHistoricalPricePK pK = new DerivativesHistoricalPricePK();
			pK.setInstrId(instrId);
			pK.setPriceDate(priceDate);
			pK.setPc(pc);
			pK.setStrike(strike);
			pK.setExpiry(expiry);
			pK.setCode(code);
			derivativesHistoricalPrice.setPk(pK);
			derivativesHistoricalPrice.setStatus(status);
			derivativesHistoricalPrice.setClosePr(closePr);
			derivativesHistoricalPrice.setImpVola(impVola);
			derivativesHistoricalPrice.setUpdType(updType);
			derivativesHistoricalPrice.setUpdDate(GenericTools.systemDate());
			derivativesHistoricalPrice.setUpdUsr(userString());
			em.persist(derivativesHistoricalPrice);
			log.debug("Added new derivative historical price series - instrId: "+instrId+"; priceDate:"+priceDate+"; pc: "+pc+"; strike: "+strike+"; expiry: "+expiry+"; code: "+code+"; closePr: "+closePr);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new derivative historical price series - instrId: "+instrId+"; priceDate:"+priceDate+"; pc: "+pc+"; strike: "+strike+"; expiry: "+expiry+"; code: "+code+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(DerivativesHistoricalPrice derivativesHistoricalPrice) throws DataNotValidException {
		try {
			derivativesHistoricalPrice.setUpdType(updType);
			derivativesHistoricalPrice.setUpdDate(GenericTools.systemDate());
			derivativesHistoricalPrice.setUpdUsr(userString());
			em.persist(derivativesHistoricalPrice);
			log.debug("Added new derivative historical price series - instrId: "+derivativesHistoricalPrice.getPk().getInstrId()+"; priceDate:"+derivativesHistoricalPrice.getPk().getPriceDate()+"; pc: "+derivativesHistoricalPrice.getPk().getPc()+"; strike: "+derivativesHistoricalPrice.getPk().getStrike()+"; expiry: "+derivativesHistoricalPrice.getPk().getExpiry()+"; code: "+derivativesHistoricalPrice.getPk().getCode()+"; closePr: "+derivativesHistoricalPrice.getClosePr());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new derivative historical price series - instrId: "+derivativesHistoricalPrice.getPk().getInstrId()+"; priceDate:"+derivativesHistoricalPrice.getPk().getPriceDate()+"; pc: "+derivativesHistoricalPrice.getPk().getPc()+"; strike: "+derivativesHistoricalPrice.getPk().getStrike()+"; expiry: "+derivativesHistoricalPrice.getPk().getExpiry()+"; code: "+derivativesHistoricalPrice.getPk().getCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public void restore(int updId) throws DataNotValidException {
		Query query = null;	
		try {
			query = em.createNamedQuery("getDerHPArchByUpdId");
    		query.setParameter("updId", updId);
    		DerivativesHistoricalPriceArchive derHpArchive = (DerivativesHistoricalPriceArchive) query.getSingleResult();
    		DerivativesHistoricalPrice derHistoricalPrices = findByPrimaryKey(derHpArchive.getInstrId(),derHpArchive.getPriceDate(),derHpArchive.getPc(),derHpArchive.getStrike(),derHpArchive.getExpiry(),derHpArchive.getCode());
    		boolean notExists = false;
    		if (derHistoricalPrices==null) {
    			derHistoricalPrices = new DerivativesHistoricalPrice();
    			DerivativesHistoricalPricePK pK = new DerivativesHistoricalPricePK();
    			pK.setInstrId(derHpArchive.getInstrId());
    			pK.setPriceDate(derHpArchive.getPriceDate());
    			pK.setPc(derHpArchive.getPc());
    			pK.setStrike(derHpArchive.getStrike());
    			pK.setExpiry(derHpArchive.getExpiry());
    			pK.setCode(derHpArchive.getCode());
    			derHistoricalPrices.setPk(pK);
    			notExists = true;
    		}
    		derHistoricalPrices.setClosePr(derHpArchive.getClosePr());
    		derHistoricalPrices.setStatus(derHpArchive.getStatus());
    		derHistoricalPrices.setImpVola(derHpArchive.getImpVola());
    		derHistoricalPrices.setUpdType("U");
    		derHistoricalPrices.setUpdDate(GenericTools.systemDate());
    		derHistoricalPrices.setUpdUsr(derHpArchive.getUpdUsr());
    		if (notExists) {
    			store(derHistoricalPrices);
    		}
			log.debug("derivative Historical Price restored - instrId: "+derHpArchive.getInstrId()+"; priceDate: "+derHpArchive.getPriceDate()+"; closePr: "+derHpArchive.getClosePr());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error restoring derivative Historical Prices from archive - updId: "+updId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
	public void update(int instrId, Timestamp priceDate, String pc, BigDecimal strike, int expiry, String code, String status, BigDecimal closePr, BigDecimal impVola) throws DataNotValidException {
		try {
			DerivativesHistoricalPrice derivativesHistoricalPrice = findByPrimaryKey(instrId, priceDate, pc, strike, expiry, code);
			derivativesHistoricalPrice.setStatus(status);
			derivativesHistoricalPrice.setClosePr(closePr);
			derivativesHistoricalPrice.setImpVola(impVola);
			derivativesHistoricalPrice.setUpdType("U");
			derivativesHistoricalPrice.setUpdDate(GenericTools.systemDate());
			derivativesHistoricalPrice.setUpdUsr(userString());
			log.debug("derivative historical price series updated - instrId: "+instrId+"; priceDate:"+priceDate+"; pc: "+pc+"; strike: "+strike+"; expiry: "+expiry+"; code: "+code+"; closePr: "+closePr);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating derivative historical price series - instrId: "+instrId+"; priceDate:"+priceDate+"; pc: "+pc+"; strike: "+strike+"; expiry: "+expiry+"; code: "+code+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(DerivativesHistoricalPrice derivativesHP) throws DataNotValidException {
		try {
			DerivativesHistoricalPrice derivativesHistoricalPrice = findByPrimaryKey(derivativesHP.getPk().getInstrId(),derivativesHP.getPk().getPriceDate(),derivativesHP.getPk().getPc(),derivativesHP.getPk().getStrike(), derivativesHP.getPk().getExpiry(), derivativesHP.getPk().getCode());
			derivativesHistoricalPrice.setUpdType("U");
			derivativesHistoricalPrice.setUpdDate(GenericTools.systemDate());
			derivativesHistoricalPrice.setUpdUsr(userString());
			log.debug("derivative historical price series updated - instrId: "+derivativesHP.getPk().getInstrId()+"; priceDate:"+derivativesHP.getPk().getPriceDate()+"; pc: "+derivativesHP.getPk().getPc()+"; strike: "+derivativesHP.getPk().getStrike()+"; expiry: "+derivativesHP.getPk().getExpiry()+"; code: "+derivativesHP.getPk().getCode()+"; closePr: "+derivativesHP.getClosePr());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating derivative historical price series - instrId: "+derivativesHP.getPk().getInstrId()+"; priceDate:"+derivativesHP.getPk().getPriceDate()+"; pc: "+derivativesHP.getPk().getPc()+"; strike: "+derivativesHP.getPk().getStrike()+"; expiry: "+derivativesHP.getPk().getExpiry()+"; code: "+derivativesHP.getPk().getCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	 
	public void remove(int instrId, Timestamp priceDate, String pc, BigDecimal strike, int expiry, String code) throws DataNotValidException {
		try {
			DerivativesHistoricalPrice derivativesHistoricalPrice = findByPrimaryKey(instrId, priceDate, pc, strike, expiry, code);
			em.remove(derivativesHistoricalPrice);
			log.debug("derivative historical price series removed - instrId: "+instrId+"; priceDate:"+priceDate+"; pc: "+pc+"; strike: "+strike+"; expiry: "+expiry+"; code: "+code);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing derivative historical price series - instrId: "+instrId+"; priceDate:"+priceDate+"; pc: "+pc+"; strike: "+strike+"; expiry: "+expiry+"; code: "+code+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteDerivativesHPByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" derivative historical price series removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing derivative historical price series - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrIdAndPc(int instrId, String pc) throws DataNotValidException {
		try {
			Query query = null;
			if (pc.equalsIgnoreCase("F")) {
				query = em.createNamedQuery("deleteFutures");
			} else {
				query = em.createNamedQuery("deleteOptions");
			}
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug(result+" derivative historical price series removed - instrId: "+instrId+"; pc: "+pc);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing derivative historical price series - instrId: "+instrId+"; pc: "+pc+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(DerivativesHistoricalPrice derivativesHP) throws DataNotValidException {
		remove(derivativesHP.getPk().getInstrId(),derivativesHP.getPk().getPriceDate(),derivativesHP.getPk().getPc(),derivativesHP.getPk().getStrike(), derivativesHP.getPk().getExpiry(), derivativesHP.getPk().getCode());
	}
	
	/*public void backup(DerivativesHistoricalPrice derHistPrices) throws DataNotValidException {
		try {
			DerivativesHistoricalPriceArchive derHpX = new DerivativesHistoricalPriceArchive();
			derHpX.setCode(derHistPrices.getPk().getCode());
			derHpX.setExpiry(derHistPrices.getPk().getExpiry());
			derHpX.setInstrId(derHistPrices.getPk().getInstrId());
			derHpX.setPc(derHistPrices.getPk().getPc());
			derHpX.setPriceDate(derHistPrices.getPk().getPriceDate());
			derHpX.setStrike(derHistPrices.getPk().getStrike());
			derHpX.setClosePr(derHistPrices.getClosePr());
			derHpX.setStatus(derHistPrices.getStatus());
			derHpX.setImpVola(derHistPrices.getImpVola());
			derHpX.setUpdType("D");
			derHpX.setUpdDate(GenericTools.systemDate());
			derHpX.setUpdUsr(userString());
			em.persist(derHpX);
			log.debug("derivative historical price backuped - instrId: "+derHistPrices.getPk().getInstrId()+"; priceDate: "+derHistPrices.getPk().getPriceDate()+"; closePr: "+derHistPrices.getClosePr());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error backuping derivative historical price from archive - instrId: "+derHistPrices.getPk().getInstrId()+"; priceDate: "+derHistPrices.getPk().getPriceDate()+"; closePr: "+derHistPrices.getClosePr()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
}
