package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.SimulationVariation;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.ejb.Local;

@Local
public interface SimulationVariationEAOLocal {
	public SimulationVariation[] fetchAllSimVar() throws DataNotValidException;
	public SimulationVariation[] fetchSimDerVar() throws DataNotValidException;
	public SimulationVariation[] fetchSimVar() throws DataNotValidException;
	
	public SimulationVariation findByPrimaryKey(int instrId, int prgExp, int nv, Timestamp priceDate, String varType) throws DataNotValidException;

	public SimulationVariation[] findByInstrIdAndVarTypeAndNv(Instrument instr, String varType,int nv) throws DataNotValidException;
	public SimulationVariation[] findByInstrIdAndVarTypeAndNvAndDate(Instrument instr, String varType,int nv, Timestamp startDate, Timestamp endDate) throws DataNotValidException;

	//public Variation[] findByDateInterval(Timestamp startDate, Timestamp endDate) throws DataNotValidException;

	//public SimulationVariation[] getFixedVariations(Instrument instr, int nv, int period, Timestamp lastDate, String varType) throws DataNotValidException;
	public SimulationVariation[] fetchWithHp(Instrument instr) throws DataNotValidException;
	
	public int getSizeByInstrId(Instrument instr) throws DataNotValidException;
	public int getSizeByInstrIdAndNvAndTh(Instrument instr, int nv, BigDecimal th) throws DataNotValidException;
	public int getSizeByInstrIdAndNv(Instrument instr, int nv) throws DataNotValidException;
	public int getSizeByInstrIdAndVarTypeAndNv(Instrument instr, String varType, int nv) throws DataNotValidException;
	public BigDecimal getExtremeValues(Instrument instr, int nv, String varType, int period, int exclude, int n, int choose) throws DataNotValidException;
	public Timestamp getOldestDateByInstrId(Instrument instr) throws DataNotValidException;
	public Timestamp getLatestDateByInstrId(Instrument instr) throws DataNotValidException;

	public void store(SimulationVariation simulationVariation) throws DataNotValidException;
	public void store(Variation variation) throws DataNotValidException;
	public void add(int instrId, int prgExp, int nv, Timestamp priceDate, String varType, BigDecimal variat, BigDecimal oVariat) throws DataNotValidException;

	public void update(int instrId, int prgExp, int nv, Timestamp priceDate, String varType, BigDecimal variat, BigDecimal oVariat) throws DataNotValidException;
	public void update(SimulationVariation simDerVar) throws DataNotValidException; 
	public void logUpdate(SimulationVariation simVar) throws DataNotValidException;
	
	public void remove(int instrId, int prgExp, int nv, Timestamp priceDate, String varType) throws DataNotValidException;
	public void remove(SimulationVariation simVar) throws DataNotValidException; 
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException; 
	public int removeByInstrId(Instrument instr) throws DataNotValidException;
}
