package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.MarginLimit;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;

import javax.ejb.Local;

@Local
public interface MarginLimitEAOLocal {
	
	public MarginLimit[] fetch() throws DataNotValidException;
	
	public MarginLimit findByPrimaryKey(String instrType, String instrStype) throws DataNotValidException;
	
	public BigDecimal getMarginLimit(int instrId) throws DataNotValidException;
	
	public BigDecimal getSuperiorMarginLimit(int instrId) throws DataNotValidException;
	
	public BigDecimal getDefaultMarginLimit(int instrId) throws DataNotValidException;
	
	public void add(String instrType, String instrStype, BigDecimal infLim, BigDecimal supLim, BigDecimal defMar, BigDecimal buffer, String actBuffer, int perBuff) throws DataNotValidException;
	
	public void store(MarginLimit marginLimit) throws DataNotValidException;
	
	public void update(String instrType, String instrStype, BigDecimal infLim, BigDecimal supLim, BigDecimal defMar, BigDecimal buffer, String actBuffer, int perBuff) throws DataNotValidException;
	
	public void update(MarginLimit marLimit) throws DataNotValidException;
	
	public void remove(String instrType, String instrStype) throws DataNotValidException;
	
	public void remove(MarginLimit marLimit) throws DataNotValidException;
}
