package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.BondHistoryClass;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface BondHistoryClassEAOLocal {
	
	public List<BondHistoryClass> fetch() throws DataNotValidException;
	
	public List<BondHistoryClass> findByInstrId(int instrId) throws DataNotValidException;
	
	public BondHistoryClass findByPrimaryKey(int instrId, Timestamp date) throws DataNotValidException;
	
	public void add(int instrId, Timestamp date, BigDecimal duration, int classId) throws DataNotValidException;
	
	public void store(BondHistoryClass bndHistClass) throws DataNotValidException;
	
	public void update(int instrId, Timestamp date, BigDecimal duration, int classId) throws DataNotValidException;
	
	public void remove(int instrId, Timestamp date) throws DataNotValidException;

}
