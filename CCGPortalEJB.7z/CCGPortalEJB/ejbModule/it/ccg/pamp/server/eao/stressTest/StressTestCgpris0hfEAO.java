package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.stressTest.StressTestCgpri00f;
import it.ccg.pamp.server.entities.stressTest.StressTestCgpris0hf;
import it.ccg.pamp.server.entities.stressTest.StressTestCgpris0hfPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.ibm.xml.soapsec.token.TokenResult.Generic;

/**
 * Session Bean implementation class StressTestCgpris0hfEAO
 */
@Stateless
public class StressTestCgpris0hfEAO implements  StressTestCgpris0hfEAOLocal {

	@PersistenceContext(unitName="STDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<StressTestCgpris0hf> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSTCgpris0hf");
    		List<StressTestCgpris0hf> stressTestCgpris0hfList = query.getResultList();
    		return stressTestCgpris0hfList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from StressTestCgpris0hf - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public StressTestCgpris0hf findByPrimaryKey (Timestamp lDate, String lSymbl, String lOfCod) throws DataNotValidException {
		Query query = null;
    	try {
    		StressTestCgpris0hfPK pK = new StressTestCgpris0hfPK();
    		
    		pK.setLDtaEl(new BigDecimal(GenericTools.shortDateFormatAsLong(lDate)));
    		pK.setLSymbl(lSymbl);
    		pK.setLOfCod(lOfCod);
    		    		
    		StressTestCgpris0hf stressTestCgpris0hf = (StressTestCgpris0hf) em.find(StressTestCgpris0hf.class, pK);
    		
    		return stressTestCgpris0hf;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from StressTestCgpris0hf - date: "+lDate+"; symbol: "+lSymbl+"; type: "+lOfCod+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(StressTestCgpris0hf stressTestCgpris0hf) throws DataNotValidException {
		try {
			em.persist(stressTestCgpris0hf);
			log.debug("Added new stressed price - date: "+stressTestCgpris0hf.getPk().getLDtaEl()+"; symbol: "+stressTestCgpris0hf.getPk().getLSymbl()+"; code: "+stressTestCgpris0hf.getPk().getLOfCod());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stressed price - date: "+stressTestCgpris0hf.getPk().getLDtaEl()+"; symbol: "+stressTestCgpris0hf.getPk().getLSymbl()+"; code: "+stressTestCgpris0hf.getPk().getLOfCod()+"; - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public int removeAll() throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteAllSTCgpris0hf");
			int result = query.executeUpdate();
			log.debug(result+" stressed price on RE System removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stressed prices removed on RE System - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
