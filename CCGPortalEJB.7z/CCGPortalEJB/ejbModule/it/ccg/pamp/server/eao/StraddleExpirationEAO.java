package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.StraddleExpiration;
import it.ccg.pamp.server.entities.StraddleExpirationPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StraddleExpirationEAO
 */
@Stateless
public class StraddleExpirationEAO implements  StraddleExpirationEAOLocal {

	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	public StraddleExpiration[] fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllStraddleExpiration");
    		List<StraddleExpiration> straddleExpiration = query.getResultList();
    		StraddleExpiration[] arrStreddleExpiration = new StraddleExpiration[straddleExpiration.size()];
    		return straddleExpiration.toArray(arrStreddleExpiration);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Straddle Expirations - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public StraddleExpiration findByPrimaryKey(int instrId, int progExp) throws DataNotValidException  {
		try {
			StraddleExpirationPK pK = new StraddleExpirationPK();
			pK.setInstrId(instrId);
			pK.setProgExp(progExp);
			StraddleExpiration straddleExpiration = (StraddleExpiration) em.find(StraddleExpiration.class,pK);
			return straddleExpiration;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Straddle Expiration - instrId: "+instrId+"; progExp: "+progExp+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public StraddleExpiration[] getStreddleExpByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getStraddleExpirationByInstrId");
    		query.setParameter("instrId", instrId);
    		List<StraddleExpiration> straddleExpiration = query.getResultList();
    		StraddleExpiration[] arrStreddleExpiration = new StraddleExpiration[straddleExpiration.size()];
    		return straddleExpiration.toArray(arrStreddleExpiration);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Straddle Expirations by instrId - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, int progExp, int irNode, int nv, int nDaysPer, int progExpMnt) throws DataNotValidException {
		try {
			StraddleExpiration straddleExpiration = new StraddleExpiration();
			StraddleExpirationPK pK = new StraddleExpirationPK();
			pK.setInstrId(instrId);
			pK.setProgExp(progExp);
			straddleExpiration.setPk(pK);
			straddleExpiration.setIrNode(irNode);
			straddleExpiration.setNv(nv);
			straddleExpiration.setNDaysPer(nDaysPer);
			straddleExpiration.setUpdType(updType);
			straddleExpiration.setUpdUsr(userString());
			straddleExpiration.setUpdDate(GenericTools.systemDate());
			straddleExpiration.setProgExpMnt(progExpMnt);
			em.persist(straddleExpiration);
			log.debug("Added new Straddle Expiration - instrId: "+instrId+"; progExp: "+progExp+"; irNode: "+irNode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Straddle Expiration - instrId: "+instrId+"; progExp: "+progExp+" - "+e.getMessage()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(StraddleExpiration straddleExpiration) throws DataNotValidException {
		try {
			straddleExpiration.setUpdType(updType);
			straddleExpiration.setUpdUsr(userString());
			straddleExpiration.setUpdDate(GenericTools.systemDate());
			em.persist(straddleExpiration);
			log.debug("Added new Straddle Expiration - instrId: "+straddleExpiration.getPk().getInstrId()+"; progExp: "+straddleExpiration.getPk().getProgExp()+"; irNode: "+straddleExpiration.getIrNode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Straddle Expiration - instrId: "+straddleExpiration.getPk().getInstrId()+"; progExp: "+straddleExpiration.getPk().getProgExp()+" - "+e.getMessage()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, int progExp, int irNode, int nv, int nDaysPer, int progExpMnt) throws DataNotValidException {
		try {
			StraddleExpiration straddleExpiration = findByPrimaryKey(instrId,progExp);
			straddleExpiration.setIrNode(irNode);
			straddleExpiration.setNv(nv);
			straddleExpiration.setNDaysPer(nDaysPer);
			straddleExpiration.setUpdType("U");
			straddleExpiration.setUpdUsr(userString());
			straddleExpiration.setUpdDate(GenericTools.systemDate());
			straddleExpiration.setProgExpMnt(progExpMnt);
			log.debug("Updated new Streddle Expiration - instrId: "+instrId+"; progExp: "+progExp);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Streddle Expiration - instrId: "+instrId+"; progExp: "+progExp+" - "+e.getMessage()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(StraddleExpiration straddleExpiration) throws DataNotValidException {
		try {
			StraddleExpiration straddleExp = findByPrimaryKey(straddleExpiration.getPk().getInstrId(),straddleExpiration.getPk().getProgExp());
			straddleExp.setUpdType("U");
			straddleExp.setUpdUsr(userString());
			straddleExp.setUpdDate(GenericTools.systemDate());
			straddleExp.setProgExpMnt(straddleExpiration.getProgExpMnt());
			log.debug("Updated new Straddle Expiration - instrId: "+straddleExpiration.getPk().getInstrId()+"; progExp: "+straddleExpiration.getPk().getProgExp());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Straddle Expiration - instrId: "+straddleExpiration.getPk().getInstrId()+"; progExp: "+straddleExpiration.getPk().getProgExp()+" - "+e.getMessage()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, int progExp) throws DataNotValidException {
		try {
			StraddleExpiration streddleExp = findByPrimaryKey(instrId,progExp);
			em.remove(streddleExp);
			log.debug("Straddle Expiration removed - instrId: "+instrId+"; progExp: "+progExp);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Straddle Expiration - instrId: "+instrId+"; progExp: "+progExp+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteStraddleExpirationByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Straddle Expirations removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Straddle Expirations - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(StraddleExpiration streddleExp) throws DataNotValidException {
		remove(streddleExp.getPk().getInstrId(),streddleExp.getPk().getProgExp());
	}
}
