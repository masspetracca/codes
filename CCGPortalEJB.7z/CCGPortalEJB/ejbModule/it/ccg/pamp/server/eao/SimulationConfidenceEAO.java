package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.SimulationConfidence;
import it.ccg.pamp.server.entities.SimulationConfidencePK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class SimulationConfidenceEAO
 */
@Stateless
public class SimulationConfidenceEAO implements  SimulationConfidenceEAOLocal {
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public SimulationConfidence[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSimulationConfidence");
    		query.setParameter("updUsr", userString());
    		List<SimulationConfidence> simulationConfidence = query.getResultList();
    		SimulationConfidence[] arrSimulationConfidence = new SimulationConfidence[simulationConfidence.size()];
    		return simulationConfidence.toArray(arrSimulationConfidence);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Simulation Confidences - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	 
	public SimulationConfidence findByPrimaryKey(int instrId, int nDaysPer, int nv, int uncev) throws DataNotValidException {
		try {
			SimulationConfidencePK pK = new SimulationConfidencePK();
			pK.setInstrId(instrId);
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			pK.setUncev(uncev);
			pK.setUpdUsr(userString());
			SimulationConfidence simulationConfidence= (SimulationConfidence) em.find(SimulationConfidence.class,pK);
    		return simulationConfidence;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Simulation Confidence - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; uncev: "+uncev+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationConfidence find(int instrId, int nDaysPer, int nv) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSimulationConfidence");
    		query.setParameter("instrId", instrId);
    		query.setParameter("nDaysPer", nDaysPer);
    		query.setParameter("nv", nv);
    		query.setParameter("updUsr", userString());
			SimulationConfidence simulationConfidence= (SimulationConfidence) query.getSingleResult();
    		return simulationConfidence;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Simulation Confidence - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationConfidence[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSimulationConfidenceByInstrId");
    		query.setParameter("instrId", instrId);
    		query.setParameter("updUsr", userString());
    		List<SimulationConfidence> simulationConfidence = query.getResultList();
    		SimulationConfidence[] arrSimulationConfidence = new SimulationConfidence[simulationConfidence.size()];
    		return simulationConfidence.toArray(arrSimulationConfidence);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Simulation Confidence - instrId: "+instrId+"; user: "+userString()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActiveDelta(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getActiveDeltaForSimConf");
    		query.setParameter("instrId", instrId);
    		query.setParameter("updUsr", userString());
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active delta for Simulation Confidences - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActivePeriods(int instrId, int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getActivePeriodsForSimConf");
    		query.setParameter("instrId", instrId);
    		query.setParameter("delta", delta);
    		query.setParameter("updUsr", userString());
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active periods for Simulation Confidences - instrId: "+instrId+"; delta: "+delta+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getEnabledPeriods(int instrId, int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledPeriodsForSimConf");
    		query.setParameter("instrId", instrId);
    		query.setParameter("delta", delta);
    		query.setParameter("updUsr", userString());
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled periods for Simulation Confidences - instrId: "+instrId+"; delta: "+delta+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void add(int instrId, int nDaysPer, int nv, int uncev, String status, BigDecimal confidence, int uncevSel, BigDecimal covPerc) throws DataNotValidException {
		try {
			SimulationConfidence simulationConfidence = new SimulationConfidence();
			SimulationConfidencePK pK = new SimulationConfidencePK();
			pK.setInstrId(instrId);
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			pK.setUncev(uncev);
			pK.setUpdUsr(userString());
			simulationConfidence.setPk(pK);
			simulationConfidence.setStatus(status);
			simulationConfidence.setConfidence(confidence);
			simulationConfidence.setUncevSel(uncevSel);
			simulationConfidence.setCovPerc(covPerc);
			simulationConfidence.setUpdType("C");
			simulationConfidence.setUpdDate(GenericTools.systemDate());
			em.persist(simulationConfidence);
			log.debug("Added new Simulation Confidence - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; uncev: "+uncev);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Simulation Confidence - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; uncev: "+uncev+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(SimulationConfidence simulationConfidence) throws DataNotValidException {
		try {
			SimulationConfidencePK pK = new SimulationConfidencePK();
			pK.setInstrId(simulationConfidence.getPk().getInstrId());
			pK.setNDaysPer(simulationConfidence.getPk().getNDaysPer());
			pK.setNv(simulationConfidence.getPk().getNv());
			pK.setUncev(simulationConfidence.getPk().getUncev());
			pK.setUpdUsr(userString());
			simulationConfidence.setPk(pK);
			simulationConfidence.setUpdType("C");
			simulationConfidence.setUpdDate(GenericTools.systemDate());
			em.persist(simulationConfidence);
			log.debug("Added new Simulation Confidence - instrId: "+simulationConfidence.getPk().getInstrId()+"; nDaysPer: "+simulationConfidence.getPk().getNDaysPer()+"; holding period: "+simulationConfidence.getPk().getNv()+"; uncev: "+simulationConfidence.getPk().getUncev());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Simulation Confidence - instrId: "+simulationConfidence.getPk().getInstrId()+"; nDaysPer: "+simulationConfidence.getPk().getNDaysPer()+"; holding period: "+simulationConfidence.getPk().getNv()+"; uncev: "+simulationConfidence.getPk().getUncev()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, int nDaysPer, int nv, int uncev, String status, BigDecimal confidence, int uncevSel, BigDecimal covPerc) throws DataNotValidException {
		try {	
			SimulationConfidence simulationConfidence = findByPrimaryKey(instrId,nDaysPer,nv,uncev);
			simulationConfidence.setStatus(status);
			simulationConfidence.setConfidence(confidence);
			simulationConfidence.setUncevSel(uncevSel);
			simulationConfidence.setCovPerc(covPerc);
			simulationConfidence.setUpdType("U");
			simulationConfidence.setUpdDate(GenericTools.systemDate());
			log.debug("Simulation Confidence updated - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; uncev: "+uncev);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Simulation Confidence - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; uncev: "+uncev+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(SimulationConfidence simulationConf) throws DataNotValidException {
		try {
			SimulationConfidence simulationConfidence = findByPrimaryKey(simulationConf.getPk().getInstrId(),simulationConf.getPk().getNDaysPer(),simulationConf.getPk().getNv(),simulationConf.getPk().getUncev());
			simulationConfidence.setUpdDate(GenericTools.systemDate());
			simulationConfidence.setUpdType("U");
			log.debug("Simulation Confidence updated - instrId: "+simulationConf.getPk().getInstrId()+"; nDaysPer: "+simulationConf.getPk().getNDaysPer()+"; holding period: "+simulationConf.getPk().getNv()+"; uncev: "+simulationConf.getPk().getUncev());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Simulation Confidence - instrId: "+simulationConf.getPk().getInstrId()+"; nDaysPer: "+simulationConf.getPk().getNDaysPer()+"; holding period: "+simulationConf.getPk().getNv()+"; uncev: "+simulationConf.getPk().getUncev()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, int nDaysPer, int nv, int uncev) throws DataNotValidException {
		try {
			SimulationConfidence simulationConfidence = findByPrimaryKey(instrId,nDaysPer,nv,uncev);
			em.remove(simulationConfidence);
			log.debug("Simulation Confidence removed - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; uncev: "+uncev);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Simulation Confidence - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; uncev: "+uncev+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteSimulationConfidenceByInstrId");
			query.setParameter("instrId", instrId);
			query.setParameter("updUsr", userString());
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Simulation Confidence removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Simulation Confidence - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(SimulationConfidence simulationConf) throws DataNotValidException {
		remove(simulationConf.getPk().getInstrId(),simulationConf.getPk().getNDaysPer(),simulationConf.getPk().getNv(),simulationConf.getPk().getUncev());
	}
	
}
