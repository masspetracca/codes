package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.stressTest.StressTestMaustl00h;
import it.ccg.pamp.server.entities.stressTest.StressTestMaustl00hPK;
//import it.ccg.pamp.server.entities.stressTest.StressTestMaustl00hfPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StressTestMaustl00hEAO
 */
@Stateless
public class StressTestMaustl00hEAO implements  StressTestMaustl00hEAOLocal {

	@PersistenceContext(unitName="STDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<StressTestMaustl00h> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllStressTestMaustl00h");
    		List<StressTestMaustl00h> StressTestMaustl00hList = query.getResultList();
    		return StressTestMaustl00hList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from StressTestMaustl00h - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public StressTestMaustl00h findByPrimaryKey (int memberId, Timestamp ctrDate, Timestamp settlDate, String account, String subAccount, String isinCode) throws DataNotValidException {
		try {
    		StressTestMaustl00hPK pK = new StressTestMaustl00hPK();
    		
    		pK.setUDMbr(new BigDecimal(memberId));
    		pK.setUDAcct(account);
    		pK.setUDSub(subAccount);
    		pK.setUCusip(isinCode);
    		pK.setUEDate(new BigDecimal(GenericTools.shortDateFormatAsLong(ctrDate)));
    		pK.setUSDate(new BigDecimal(GenericTools.shortDateFormatAsLong(settlDate)));
    		    		
    		StressTestMaustl00h stressTestMaustl00h = (StressTestMaustl00h) em.find(StressTestMaustl00h.class, pK);
    		
    		return stressTestMaustl00h;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from StressTestMaustl00h - memberId: "+memberId+"; isinCode: "+isinCode+"; account: "+account+"; subAccount: "+subAccount+"; contract date: "+GenericTools.shortDateFormat(ctrDate)+"; settlement date: "+GenericTools.shortDateFormat(settlDate)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
