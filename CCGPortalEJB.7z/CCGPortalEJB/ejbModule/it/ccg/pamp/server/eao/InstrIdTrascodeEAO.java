package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.entities.InstrIdTrascodePK;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class InstrIdTrascodeEAO
 */
@Stateless
public class InstrIdTrascodeEAO implements  InstrIdTrascodeEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public InstrIdTrascode[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllInstrIdTrascode");
    		List<InstrIdTrascode> instrtypeTranscode = query.getResultList();
    		InstrIdTrascode[] arrFutClassTypeTrascode = new InstrIdTrascode[instrtypeTranscode.size()];
    		return instrtypeTranscode.toArray(arrFutClassTypeTrascode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from InstrIdTrascode - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InstrIdTrascode[] getSicInstr(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSicInstr");
    		query.setParameter("instrId", instrId);
    		List<InstrIdTrascode> instrIdTrascode = query.getResultList();
    		InstrIdTrascode[] arrFutClassTypeTrascode = new InstrIdTrascode[instrIdTrascode.size()];
    		return instrIdTrascode.toArray(arrFutClassTypeTrascode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from InstrIdTrascode - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InstrIdTrascode[] getSicInstrStoredInPamp(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		String sqlString = "SELECT T.INSTRID,T.SICINSTR,T.SICINSTRTY,T.MARCF,T.MINMARCF,T.STRADDLECF,T.STEXPORT,T.UPDTYPE,T.UPDUSR,T.UPDDATE FROM PMPTTRSINS T ";
    		sqlString += "INNER JOIN PMPTINSTR I ON I.INSTRID = T.INSTRID AND I.CLASSCODE = T.SICINSTR ";
    		sqlString += "WHERE T.INSTRID = "+instrId+" ";
    		
    		    		
    		query =  em.createNativeQuery(sqlString,InstrIdTrascode.class);
    		List<InstrIdTrascode> instrIdTrascodeList = query.getResultList();
    		InstrIdTrascode[] arrInstrIdTrascode = new InstrIdTrascode[instrIdTrascodeList.size()];
    		return instrIdTrascodeList.toArray(arrInstrIdTrascode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from InstrIdTrascode - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public InstrIdTrascode[] getRectifiedClasses(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		String sqlString = "SELECT T.INSTRID,T.SICINSTR,T.SICINSTRTY,T.MARCF,T.MINMARCF,T.STRADDLECF,T.STEXPORT,T.UPDTYPE,T.UPDUSR,T.UPDDATE FROM PMPTTRSINS T ";
    		sqlString += "INNER JOIN PMPTINSTR I ON I.INSTRID = T.INSTRID AND I.CLASSCODE != T.SICINSTR ";
    		sqlString += "WHERE T.INSTRID = "+instrId+" AND I.STATUS IN ('E','U') ";
    		
    		    		
    		query =  em.createNativeQuery(sqlString,InstrIdTrascode.class);
    		List<InstrIdTrascode> instrIdTrascodeList = query.getResultList();
    		InstrIdTrascode[] arrInstrIdTrascode = new InstrIdTrascode[instrIdTrascodeList.size()];
    		return instrIdTrascodeList.toArray(arrInstrIdTrascode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from InstrIdTrascode - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public InstrIdTrascode[] getSicInstrByIdAndType(int instrId, String instrType) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSicInstrByIdAndType");
    		query.setParameter("instrId", instrId);
    		query.setParameter("instrType", instrType);
    		List<InstrIdTrascode> instrIdTrascode = query.getResultList();
    		InstrIdTrascode[] arrFutClassTypeTrascode = new InstrIdTrascode[instrIdTrascode.size()];
    		return instrIdTrascode.toArray(arrFutClassTypeTrascode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from InstrIdTrascode - instrId: "+instrId+"; instrType: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InstrIdTrascode[] getInstrId(String sicInstr) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrId");
    		query.setParameter("sicInstr", sicInstr);
    		List<InstrIdTrascode> instrIdTrascode = query.getResultList();
    		InstrIdTrascode[] arrFutClassTypeTrascode = new InstrIdTrascode[instrIdTrascode.size()];
    		return instrIdTrascode.toArray(arrFutClassTypeTrascode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from InstrIdTrascode - sicInstr: "+sicInstr+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InstrIdTrascode findByPrimaryKey(int instrId, String sicInstr) throws DataNotValidException {
		try {
			InstrIdTrascodePK pK = new InstrIdTrascodePK();
			pK.setInstrId(instrId);			
			pK.setSicInstr(sicInstr);
			InstrIdTrascode instrIdTrascode = (InstrIdTrascode) em.find(InstrIdTrascode.class,pK);
    		return instrIdTrascode;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from InstrIdTrascode - instrId: "+instrId+"; sicInstr: "+sicInstr+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
