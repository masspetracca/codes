package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.ElecStatistic;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;

@Local
public interface ElecStatisticEAOLocal {
	
	public List<ElecStatistic> fetch() throws DataNotValidException;
	
	public List<ElecStatistic> fetchWithMode1() throws DataNotValidException;
	
	public List<ElecStatistic> findByInstrId(int instrId) throws DataNotValidException;
	
	public ElecStatistic findByPrimaryKey(int instrId, String varType,int mode, int month) throws DataNotValidException;
	
	public void add(int instrId, String varType, int mode, int month, int active, BigDecimal average, int cntMaxEvnt, 
		BigDecimal max, int maxYear, BigDecimal min, String status, BigDecimal stDev) throws DataNotValidException;
	
	public void store(ElecStatistic elecStatistic) throws DataNotValidException;
	
	public void update(int instrId, String varType, int mode, int month, int active, BigDecimal average, int cntMaxEvnt, 
			BigDecimal max, int maxYear, BigDecimal min, String status, BigDecimal stDev) throws DataNotValidException;
	
	public void update(ElecStatistic elecStatistic) throws DataNotValidException; 
	
	public void remove(int instrId, String varType, int mode, int month) throws DataNotValidException;
	
	public int removeByMonth(int month) throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
	public int removeByMode(int mode) throws DataNotValidException;
	
	public void remove(ElecStatistic elecStatistic) throws DataNotValidException;
	
	public void transferMode1To2() throws DataNotValidException;
}
