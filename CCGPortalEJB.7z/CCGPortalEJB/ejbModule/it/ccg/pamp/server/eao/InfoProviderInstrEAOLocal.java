package it.ccg.pamp.server.eao;
import java.util.List;

import it.ccg.pamp.server.entities.InfoProviderInstr;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface InfoProviderInstrEAOLocal {
	
	public List<InfoProviderInstr> fetch() throws DataNotValidException;
	public InfoProviderInstr findByRicCode(String ricCode) throws DataNotValidException;
	public InfoProviderInstr findCurrencyByClassCode(String currencyCode) throws DataNotValidException;
	
}
