package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.DerivativesHistoricalPriceRett;
import it.ccg.pamp.server.entities.HistoricalPrices;
import it.ccg.pamp.server.entities.HistoricalPricesPK;
import it.ccg.pamp.server.entities.HistoricalPricesRett;
import it.ccg.pamp.server.entities.HistoricalPricesRettPK;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.HistPricesRettDates;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class HistoricalPricesRettEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class HistoricalPricesRettEAO implements  HistoricalPricesRettEAOLocal {
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	@SuppressWarnings("unchecked")
	public HistoricalPricesRett[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllHPR");
    		List<HistoricalPricesRett> historicalPricesRett = query.getResultList();
    		HistoricalPricesRett[] arrHistoricalPricesRett = new HistoricalPricesRett[historicalPricesRett.size()];
    		return historicalPricesRett.toArray(arrHistoricalPricesRett);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices Rettified - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public HistoricalPricesRett findByPrimaryKey(int instrId, Timestamp priceDate) throws DataNotValidException {
		try {
			HistoricalPricesRettPK pK = new HistoricalPricesRettPK();
			pK.setInstrId(instrId);
			pK.setPriceDate(priceDate);
    		HistoricalPricesRett historicalPricesRett = (HistoricalPricesRett) em.find(HistoricalPricesRett.class,pK);
    		return historicalPricesRett;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Rettified historical prices - instrId: "+instrId+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int getTimeWindow(int instrId, Timestamp firstDate, Timestamp lastDate) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getHPRetTimeWindow");
    		query.setParameter("instrId", instrId);
    		query.setParameter("firstDate", firstDate);
    		query.setParameter("lastDate", lastDate);
    		Long counter = (Long) query.getSingleResult();
    		return counter.intValue();
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last Resttified historical price - instrId: "+instrId+"; time window: "+firstDate+ " - "+lastDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public HistoricalPricesRett[] findJustBeforeDate(int instrId, Timestamp nearDate) throws DataNotValidException {
		Query query = null;
		try {
			String date = nearDate.toString().substring(0, 10);
    		int year = Integer.parseInt(date.substring(0,4));
    		int month = Integer.parseInt(date.substring(5,7))-1;
    		int day = Integer.parseInt(date.substring(8))+1;
    		GregorianCalendar cal = new GregorianCalendar(year,month,day);
    		Timestamp beforeDate = new Timestamp(cal.getTimeInMillis());
			query = em.createNamedQuery("getHPRetfindJustBeforeDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("nearDate", beforeDate);
    		query.setMaxResults(1);
    		List<HistoricalPricesRett> historicalPricesRett = query.getResultList();
    		HistoricalPricesRett[] arrHistoricalPricesRett = new HistoricalPricesRett[historicalPricesRett.size()];
    		return historicalPricesRett.toArray(arrHistoricalPricesRett);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Rettified historical prices before this date: "+nearDate+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalPricesRett findBeforeLastDate(int instrId, Timestamp lastDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPRetBeforeLastDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("lastDate", lastDate);
    		query.setMaxResults(1);
    		List<HistoricalPricesRett> historicalPricesRettList = query.getResultList();
    		if (historicalPricesRettList.size()>0) {
    			return historicalPricesRettList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices Rettified before the last date - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public HistoricalPricesRett findLastDate() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPRLastDate");
    		query.setMaxResults(1);
    		List<HistoricalPricesRett> historicalPricesRett = query.getResultList();
    		return historicalPricesRett.get(0);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices Rettified last date - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalPricesRett findFirstDate() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPRFirstDate");
    		query.setMaxResults(1);
    		List<HistoricalPricesRett> historicalPricesRett = query.getResultList();
    		return historicalPricesRett.get(0);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices Rettified first date - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public HistoricalPricesRett findLastDateByInstrument(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPRLastDateByInstr");
    		query.setParameter("instrId", instrId);
    		List<HistoricalPricesRett> historicalPricesRettList = query.getResultList();
    		if (historicalPricesRettList.size()>0) {
    			return historicalPricesRettList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices last date: instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalPricesRett findFirstDateByInstrument(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPRFirstDateByInstr");
    		query.setParameter("instrId", instrId);
    		List<HistoricalPricesRett> historicalPricesRettList = query.getResultList();
    		if (historicalPricesRettList.size()>0) {
    			return historicalPricesRettList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices first date: instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistPricesRettDates findFirstAndLastDateByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPRFirstAndLastDateByInstrId");
    		query.setParameter("instrId", instrId);
    		query.setMaxResults(1);
    		List<HistPricesRettDates> histPricesRettDate = query.getResultList();
    		if (histPricesRettDate.size()>0) {
    			return histPricesRettDate.get(0);
    		} else {
    			return null;
    		}
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices Rettified first and last date for instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistPricesRettDates findFirstAndLastDateByClassId(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPRFirstAndLastDateByClassId");
    		query.setParameter("classId", classId);
    		query.setMaxResults(1);
    		List<HistPricesRettDates> histPricesRettDate = query.getResultList();
    		if (histPricesRettDate.size()>0) {
    			return histPricesRettDate.get(0);
    		} else {
    			return null;
    		}
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices Rettified first and last date for classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistPricesRettDates findFirstAndLastDateByClassId1AndClassId2(int classId1, int classId2) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPRFirstAndLastDateByClassId1AndClassId2");
    		query.setParameter("classId1", classId1);
    		query.setParameter("classId2", classId2);
    		query.setMaxResults(1);
    		List<HistPricesRettDates> histPricesRettDate = query.getResultList();
    		if (histPricesRettDate.size()>0) {
    			return histPricesRettDate.get(0);
    		} else {
    			return null;
    		}
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices Rettified first and last date for classId1: "+classId1+" and classId2: "+classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalPricesRett[] findJustAfterDate(int instrId, Timestamp nearDate) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getHPRetfindJustAfterDate");
    		String date = nearDate.toString().substring(0, 10);
    		int year = Integer.parseInt(date.substring(0,4));
    		int month = Integer.parseInt(date.substring(5,7))-1;
    		int day = Integer.parseInt(date.substring(8))-1;
    		GregorianCalendar cal = new GregorianCalendar(year,month,day);
    		Timestamp afterDate = new Timestamp(cal.getTimeInMillis());
			query.setParameter("instrId", instrId);
    		query.setParameter("nearDate", afterDate);
    		query.setMaxResults(1);
    		List<HistoricalPricesRett> historicalPricesRett = query.getResultList();
    		HistoricalPricesRett[] arrHistoricalPricesRett = new HistoricalPricesRett[historicalPricesRett.size()];
    		return historicalPricesRett.toArray(arrHistoricalPricesRett);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Rettified historical prices after this date: "+nearDate+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}	

	public HistoricalPricesRett[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPRetByInstrId");
    		query.setParameter("instrId", instrId);
    		List<HistoricalPricesRett> historicalPricesRett = query.getResultList();
    		HistoricalPricesRett[] arrHistoricalPricesRett = new HistoricalPricesRett[historicalPricesRett.size()];
    		return historicalPricesRett.toArray(arrHistoricalPricesRett);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices Rettified - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalPricesRett[] findByInstrIdAndDate(int instrId, Timestamp firstDate, Timestamp lastDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPRetByInstrIdAnddate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("firstDate", firstDate);
    		query.setParameter("lastDate", lastDate);
    		List<HistoricalPricesRett> historicalPricesRett = query.getResultList();
    		HistoricalPricesRett[] arrHistoricalPricesRett = new HistoricalPricesRett[historicalPricesRett.size()];
    		return historicalPricesRett.toArray(arrHistoricalPricesRett);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Price between dates: "+firstDate+" AND "+lastDate+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, Timestamp priceDate, BigDecimal closePrRet, String status) throws DataNotValidException {
		try {
			HistoricalPricesRett historicalPricesRett = new HistoricalPricesRett();
			HistoricalPricesRettPK pK = new HistoricalPricesRettPK();
			pK.setInstrId(instrId);
			pK.setPriceDate(priceDate);
			historicalPricesRett.setPk(pK);
			historicalPricesRett.setClosePrRet(closePrRet);
			historicalPricesRett.setStatus(status);
			historicalPricesRett.setUpdDate(GenericTools.systemDate());
			historicalPricesRett.setUpdType(updType);
			historicalPricesRett.setUpdUsr(userString());
			em.persist(historicalPricesRett);
			log.debug("Added new Rettified historical prices - instrId: "+instrId+"; priceDate: "+priceDate+"; closePrRett: "+closePrRet);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Rettified historical prices - instrId: "+instrId+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	

	public void store(HistoricalPricesRett historicalPricesRett) throws DataNotValidException {
		try {
			historicalPricesRett.setUpdDate(GenericTools.systemDate());
			historicalPricesRett.setUpdType(updType);
			historicalPricesRett.setUpdUsr(userString());
			em.persist(historicalPricesRett);
			log.debug("Added new Rettified historical prices - instrId: "+historicalPricesRett.getPk().getInstrId()+"; priceDate: "+historicalPricesRett.getPk().getPriceDate()+"; closePrRett: "+historicalPricesRett.getClosePrRet());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Rettified historical prices - instrId: "+historicalPricesRett.getPk().getInstrId()+"; priceDate: "+historicalPricesRett.getPk().getPriceDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, Timestamp priceDate, BigDecimal closePrRet, String status) throws DataNotValidException {
		try {
			HistoricalPricesRett historicalPricesRett = findByPrimaryKey(instrId,priceDate);
			historicalPricesRett.setClosePrRet(closePrRet);
			historicalPricesRett.setStatus(status);
			historicalPricesRett.setUpdDate(GenericTools.systemDate());
			historicalPricesRett.setUpdType("U");
			historicalPricesRett.setUpdUsr(userString());
			log.debug("Rettified historical prices updated - instrId: "+instrId+"; priceDate: "+priceDate+"; closePrRett: "+closePrRet);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Rettified historical prices - instrId: "+instrId+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	} 
	}
	
	public void update(HistoricalPricesRett histPricesRett) throws DataNotValidException {
		try {
			log.debug("Rettified historical prices updated - instrId: "+histPricesRett.getPk().getInstrId()+"; priceDate: "+histPricesRett.getPk().getPriceDate()+"; closePrRett: "+histPricesRett.getClosePrRet());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Rettified historical prices - instrId: "+histPricesRett.getPk().getInstrId()+"; priceDate: "+histPricesRett.getPk().getPriceDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, Timestamp priceDate) throws DataNotValidException {
		try {
			HistoricalPricesRett historicalPricesRett = findByPrimaryKey(instrId,priceDate);
			em.remove(historicalPricesRett);
			log.debug("Rettified historical prices removed - instrId: "+instrId+"; priceDate: "+priceDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Rettified historical prices - instrId: "+instrId+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	} 
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteHPrettByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Rettified historical prices removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Rettified historical prices - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	} 
	}
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteHPrettByEnabledInstrId");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" Rettified Historical prices related to not enabled instruments removed - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing rettified historical prices related to not enabled instruments removed - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(HistoricalPricesRett histPricesRett) throws DataNotValidException {
		remove(histPricesRett.getPk().getInstrId(),histPricesRett.getPk().getPriceDate());
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	
	public void flush() {
		em.flush();
	}
}
