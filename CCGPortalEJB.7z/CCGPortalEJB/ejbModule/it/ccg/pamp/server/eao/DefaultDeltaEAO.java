package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.DefaultDelta;
import it.ccg.pamp.server.entities.DefaultDeltaPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.MarginCustomObj;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.ibm.ObjectQuery.crud.util.Array;

/**
 * Session Bean implementation class DefaultDeltaEAO
 */
@Stateless
public class DefaultDeltaEAO implements  DefaultDeltaEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	@SuppressWarnings("unchecked")
	public DefaultDelta[] fetch() {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllDefDelta");
    		List<DefaultDelta> defaultDelta = query.getResultList();
    		DefaultDelta[] arrDefaultDelta = new DefaultDelta[defaultDelta.size()];
    		return defaultDelta.toArray(arrDefaultDelta);
    	} catch (Exception e) {
    		return null;
    	}
	}
	
	public Integer[] getActiveDelta(String instrType) {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getActiveDefDelta");
    		query.setParameter("instrType", instrType);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		return null;
    	}
	}
	
	public List<Integer> getActiveDeltaMultipleDivisions(String divisions) {
		
		Query query = null;
		
		String divisionList = "";
		
		for (int i=0;i<divisions.length();i++) {
			divisionList += "'"+divisions.toUpperCase().charAt(i)+"',";
		}
		
		divisionList = divisionList.substring(0,divisionList.length()-1);
		
		String sqlString = "SELECT DISTINCT T.NV "+
							"FROM PMPTDELTDF T "+
							"WHERE T.DSTATUS = 'E' "+
							"AND EXISTS "+
							"(SELECT * FROM PMPTINSTR I "+
							"WHERE T.INSTRTYPE = I.INSTRTYPE "+
							"AND I.STATUS NOT IN ('D','X') "+
							"AND I.DIVISCODE IN ("+divisionList+")) ";
		
		List<Integer> nvList = new ArrayList<Integer>();
		
		try {
			query =  em.createNativeQuery(sqlString,Integer.class);
		}  catch (Exception e) {
			e.getStackTrace();
		}
			
		nvList = query.getResultList();
		
		return nvList;
    }
	
	public DefaultDelta[] findByInstrType(String instrType) {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDefDeltaByInstrType");
    		query.setParameter("instrType", instrType);
    		List<DefaultDelta> defaultDeltaList = query.getResultList();
    		DefaultDelta[] arrDefaultDelta = new DefaultDelta[defaultDeltaList.size()];
    		return defaultDeltaList.toArray(arrDefaultDelta);
    	} catch (Exception e) {
    		return null;
    	}
	}
	
	public DefaultDelta findByPrimaryKey(String instrType, int nv) {
		try {
			DefaultDeltaPK pK = new DefaultDeltaPK();
			pK.setInstrType(instrType);
			pK.setNv(nv);
			DefaultDelta defaultDelta = em.find(DefaultDelta.class,pK);
    		return defaultDelta;
    	} catch (Exception e) {
    		return null;
    	}
	}
}
