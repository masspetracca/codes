package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.SimulationStatistics;
import it.ccg.pamp.server.entities.SimulationStatisticsPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class InstrumentStatisticEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class SimulationStatisticsEAO implements  SimulationStatisticsEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public SimulationStatistics[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSimStat");
    		query.setParameter("updUsr", userString());
    		List<SimulationStatistics> simulationStatistics = query.getResultList();
    		SimulationStatistics[] arrSimulationStatistics = new SimulationStatistics[simulationStatistics.size()];
    		return simulationStatistics.toArray(arrSimulationStatistics);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument Statistics - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationStatistics[] fetchWithMode1() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSimStatWithMode1");
    		query.setParameter("updUsr", userString());
    		List<SimulationStatistics> simulationStatistics = query.getResultList();
    		SimulationStatistics[] arrSimulationStatistics = new SimulationStatistics[simulationStatistics.size()];
    		return simulationStatistics.toArray(arrSimulationStatistics);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument Statistics with mode 1 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationStatistics findByPrimaryKey(int instrId, int nv, int nDaysPer, String varType,int mode) throws DataNotValidException {
		try {
			SimulationStatisticsPK pK = new SimulationStatisticsPK();
			pK.setInstrId(instrId);
			pK.setNv(nv);
			pK.setNdaysPer(nDaysPer);
			pK.setVarType(varType);
			pK.setMode(mode);
			pK.setUpdUsr(userString());
			SimulationStatistics simulationStatistics = (SimulationStatistics) em.find(SimulationStatistics.class,pK);
    		return simulationStatistics;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument Statistic - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void add(int instrId, int nv, int nDaysPer, String varType, int mode, int active, BigDecimal stDev, BigDecimal average, BigDecimal asy, BigDecimal kurtosis,
		BigDecimal perf, BigDecimal perYear, BigDecimal nDays, BigDecimal volaDay, BigDecimal eventsIn, BigDecimal eventsOut,
		BigDecimal normMar, BigDecimal normMarCov, BigDecimal normMarSd, BigDecimal maxMargin, BigDecimal maxMarSd, BigDecimal maxMarCov, BigDecimal mathMar,
		BigDecimal mathMarSd, BigDecimal mathMarCov, BigDecimal minMar, BigDecimal minMarSd, BigDecimal minMarCov, BigDecimal aveMar, BigDecimal aveMarSd,
		BigDecimal aveMarCov, BigDecimal currMarSd, BigDecimal currMarCov) throws DataNotValidException {
		
		try {
			SimulationStatistics simulationStatistics = new SimulationStatistics();
			SimulationStatisticsPK pK = new SimulationStatisticsPK();
			pK.setInstrId(instrId);
			pK.setNv(nv);
			pK.setNdaysPer(nDaysPer);
			pK.setVarType(varType);
			pK.setMode(mode);
			pK.setUpdUsr(userString());
			simulationStatistics.setPk(pK);
			simulationStatistics.setActive(active);
			simulationStatistics.setStDev(stDev);
			simulationStatistics.setAverage(average);
			simulationStatistics.setAsy(asy);
			simulationStatistics.setKurtosis(kurtosis);
			simulationStatistics.setPerf(perf);
			simulationStatistics.setPerYear(perYear);
			simulationStatistics.setNDays(nDays);
			simulationStatistics.setVolaDay(volaDay);
			simulationStatistics.setEventsIn(eventsIn);
			simulationStatistics.setEventsOut(eventsOut);
			simulationStatistics.setNormMar(normMar);
			simulationStatistics.setNormMarCov(normMarCov);
			simulationStatistics.setNormMarSd(normMarSd);
			simulationStatistics.setMaxMargin(maxMargin);
			simulationStatistics.setMaxMarSd(maxMarSd);
			simulationStatistics.setMaxMarCov(maxMarCov);
			simulationStatistics.setMathMar(mathMarCov);
			simulationStatistics.setMathMarSd(mathMarSd);
			simulationStatistics.setMathMarCov(mathMarSd);
			simulationStatistics.setMinMar(minMar);
			simulationStatistics.setMinMarSd(minMarSd);
			simulationStatistics.setMinMarCov(minMarCov);
			simulationStatistics.setAveMar(aveMar);
			simulationStatistics.setAveMarSd(aveMarSd);
			simulationStatistics.setAveMarCov(aveMarCov);
			simulationStatistics.setCurrMarSd(currMarSd);
			simulationStatistics.setCurrMarCov(currMarCov);
			simulationStatistics.setUpdType("C");
			simulationStatistics.setUpdDate(GenericTools.systemDate());
			em.persist(simulationStatistics);
			log.debug("Added new Instrument Statistic - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Instrument Statistic - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public void store(SimulationStatistics simulationStatistics) throws DataNotValidException {
		try {
			SimulationStatisticsPK pK = new SimulationStatisticsPK();
			pK.setInstrId(simulationStatistics.getPk().getInstrId());
			pK.setNv(simulationStatistics.getPk().getNv());
			pK.setNdaysPer(simulationStatistics.getPk().getNDaysPer());
			pK.setVarType(simulationStatistics.getPk().getVarType());
			pK.setMode(simulationStatistics.getPk().getMode());
			pK.setUpdUsr(userString());
			simulationStatistics.setPk(pK);
			simulationStatistics.setUpdType("C");
			simulationStatistics.setUpdDate(GenericTools.systemDate());
			em.persist(simulationStatistics);
			log.debug("Added new Instrument Statistic - instrId: "+simulationStatistics.getPk().getInstrId()+"; holding period: "+simulationStatistics.getPk().getNv()+"; nDaysPer: "+simulationStatistics.getPk().getNDaysPer()+"; varType: "+simulationStatistics.getPk().getVarType()+"; mode: "+simulationStatistics.getPk().getMode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Instrument Statistic - instrId: "+simulationStatistics.getPk().getInstrId()+"; holding period: "+simulationStatistics.getPk().getNv()+"; nDaysPer: "+simulationStatistics.getPk().getNDaysPer()+"; varType: "+simulationStatistics.getPk().getVarType()+"; mode: "+simulationStatistics.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, int nv, int nDaysPer, String varType, int mode, int active, BigDecimal stDev, BigDecimal average, BigDecimal asy, BigDecimal kurtosis,
			BigDecimal perf, BigDecimal perYear, BigDecimal nDays, BigDecimal volaDay, BigDecimal eventsIn, BigDecimal eventsOut,
			BigDecimal normMar, BigDecimal normMarCov, BigDecimal normMarSd, BigDecimal maxMargin, BigDecimal maxMarSd, BigDecimal maxMarCov, BigDecimal mathMar,
			BigDecimal mathMarSd, BigDecimal mathMarCov, BigDecimal minMar, BigDecimal minMarSd, BigDecimal minMarCov, BigDecimal aveMar, BigDecimal aveMarSd,
			BigDecimal aveMarCov, BigDecimal currMarSd, BigDecimal currMarCov) throws DataNotValidException {
		try {
			SimulationStatistics simulationStatistics = findByPrimaryKey(instrId, nv, nDaysPer, varType, mode);
			simulationStatistics.setActive(active);
			simulationStatistics.setStDev(stDev);
			simulationStatistics.setAverage(average);
			simulationStatistics.setAsy(asy);
			simulationStatistics.setKurtosis(kurtosis);
			simulationStatistics.setPerf(perf);
			simulationStatistics.setPerYear(perYear);
			simulationStatistics.setNDays(nDays);
			simulationStatistics.setVolaDay(volaDay);
			simulationStatistics.setEventsIn(eventsIn);
			simulationStatistics.setEventsOut(eventsOut);
			simulationStatistics.setNormMar(normMar);
			simulationStatistics.setNormMarCov(normMarCov);
			simulationStatistics.setNormMarSd(normMarSd);
			simulationStatistics.setMaxMargin(maxMargin);
			simulationStatistics.setMaxMarSd(maxMarSd);
			simulationStatistics.setMaxMarCov(maxMarCov);
			simulationStatistics.setMathMar(mathMarCov);
			simulationStatistics.setMathMarSd(mathMarSd);
			simulationStatistics.setMathMarCov(mathMarSd);
			simulationStatistics.setMinMar(minMar);
			simulationStatistics.setMinMarSd(minMarSd);
			simulationStatistics.setMinMarCov(minMarCov);
			simulationStatistics.setAveMar(aveMar);
			simulationStatistics.setAveMarSd(aveMarSd);
			simulationStatistics.setAveMarCov(aveMarCov);
			simulationStatistics.setCurrMarSd(currMarSd);
			simulationStatistics.setCurrMarCov(currMarCov);
			simulationStatistics.setUpdType("U");
			simulationStatistics.setUpdDate(GenericTools.systemDate());
			log.debug("Instrument Statistic updated - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Instrument Statistic - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(SimulationStatistics simStat) throws DataNotValidException {
		try {
			SimulationStatistics simulationStatistics = findByPrimaryKey(simStat.getPk().getInstrId(), simStat.getPk().getNv(), simStat.getPk().getNDaysPer(), simStat.getPk().getVarType(), simStat.getPk().getMode());
			simulationStatistics.setUpdType("U");
			simulationStatistics.setUpdDate(GenericTools.systemDate());
			log.debug("Instrument Statistic updated - instrId: "+simStat.getPk().getInstrId()+"; holding period: "+simStat.getPk().getNv()+"; nDaysPer: "+simStat.getPk().getNDaysPer()+"; varType: "+simStat.getPk().getVarType()+"; mode: "+simStat.getPk().getMode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Instrument Statistic - instrId: "+simStat.getPk().getInstrId()+"; holding period: "+simStat.getPk().getNv()+"; nDaysPer: "+simStat.getPk().getNDaysPer()+"; varType: "+simStat.getPk().getVarType()+"; mode: "+simStat.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, int nv, int nDaysPer, String varType, int mode) throws DataNotValidException {
		try {
			SimulationStatistics simulationStatistics = findByPrimaryKey(instrId, nv, nDaysPer, varType, mode);
			em.remove(simulationStatistics);
			log.debug("Instrument Statistic removed - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Instrument Statistic - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteSimStatByInstrId");
			query.setParameter("instrId", instrId);
			query.setParameter("updUsr", userString());
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Simulation Statistics removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Simulation Statistic - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public int removeByEnabledInstrId(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteInstrumentStatByEnabledInstrId");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" enabled Instrument Statistics removed - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing enabled Instrument Statistic - divisCode: "+divisCode);
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
	public int removeByMode(int mode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteSimStatByMode");
			query.setParameter("mode", mode);
			query.setParameter("updUsr", userString());
			int result = query.executeUpdate();
			log.debug(result+" Simulation Statistics removed - mode: "+mode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Simulation Statistic - mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(SimulationStatistics simStatistic) throws DataNotValidException {
		remove(simStatistic.getPk().getInstrId(), simStatistic.getPk().getNv(), simStatistic.getPk().getNDaysPer(), simStatistic.getPk().getVarType(), simStatistic.getPk().getMode());
	}	
	
	public int transferMode1inMode2() throws DataNotValidException {
		SimulationStatistics[] arrSimulationStatistics = fetchWithMode1();
		int i=0;
		try {
			for (SimulationStatistics simStat: arrSimulationStatistics) {
				SimulationStatisticsPK pK = new SimulationStatisticsPK();
				SimulationStatistics simulationStatistics = new SimulationStatistics();
				pK.setInstrId(simStat.getPk().getInstrId());
				pK.setNdaysPer(simStat.getPk().getNDaysPer());
				pK.setNv(simStat.getPk().getNv());
				pK.setVarType(simStat.getPk().getVarType());
				pK.setMode(2);
				simulationStatistics.setPk(pK);
				simulationStatistics.setActive(simStat.getActive());
				simulationStatistics.setStDev(simStat.getStDev());
				simulationStatistics.setAverage(simStat.getAverage());
				simulationStatistics.setAsy(simStat.getAsy());
				simulationStatistics.setKurtosis(simStat.getKurtosis());
				simulationStatistics.setPerf(simStat.getPerf());
				simulationStatistics.setPerYear(simStat.getPerYear());
				simulationStatistics.setNDays(simStat.getNDays());
				simulationStatistics.setVolaDay(simStat.getVolaDay());
				simulationStatistics.setEventsIn(simStat.getEventsIn());
				simulationStatistics.setEventsOut(simStat.getEventsOut());
				simulationStatistics.setNormMar(simStat.getNormMar());
				simulationStatistics.setNormMarCov(simStat.getNormMarCov());
				simulationStatistics.setNormMarSd(simStat.getNormMarSd());
				simulationStatistics.setMaxMargin(simStat.getMaxMargin());
				simulationStatistics.setMaxMarSd(simStat.getMaxMarSd());
				simulationStatistics.setMaxMarCov(simStat.getMaxMarCov());
				simulationStatistics.setMathMar(simStat.getMathMar());
				simulationStatistics.setMathMarSd(simStat.getMathMarSd());
				simulationStatistics.setMathMarCov(simStat.getMathMarCov());
				simulationStatistics.setMinMar(simStat.getMinMar());
				simulationStatistics.setMinMarSd(simStat.getMinMarSd());
				simulationStatistics.setMinMarCov(simStat.getMinMarCov());
				simulationStatistics.setAveMar(simStat.getAveMar());
				simulationStatistics.setAveMarSd(simStat.getAveMarSd());
				simulationStatistics.setAveMarCov(simStat.getAveMarCov());
				simulationStatistics.setCurrMarSd(simStat.getCurrMarSd());
				simulationStatistics.setCurrMarCov(simStat.getCurrMarCov());
				store(simulationStatistics);
				i++;
			}
			log.debug(i+" Instrument Statistics transferred from mode 1 to 2");
			return i;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error transferring Instrument Statistics from mode 1 to 2 - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
}

