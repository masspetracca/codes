package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Group;
import it.ccg.pamp.server.entities.GroupComponent;
import it.ccg.pamp.server.entities.SetComponent;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.security.UserServiceBeanLocal;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Vector;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class GroupEAO
 */
@Stateless
public class GroupEAO implements  GroupEAOLocal {
	
	@EJB private GroupComponentEAOLocal grComp=null;
	//@EJB private UserServiceBeanLocal userService=null;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	public Group[] fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllGroups");
    		List<Group> group = query.getResultList();
    		Group[] arrGroup = new Group[group.size()];
    		return group.toArray(arrGroup);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Groups - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Group findByPrimaryKey(int grId) throws DataNotValidException  {
		try {
			Group group = (Group) em.find(Group.class,grId);
    		return group;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group - groupId: "+grId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Group[] findEnabledGroups() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllEnabledGroups");
    		List<Group> groupList = query.getResultList();
    		Group[] arrGroup = new Group[groupList.size()];
    		for (Group group:groupList) {
    			GroupComponent[] arrGrComp = grComp.findByGroupId(group.getGrId());
    			List<GroupComponent> grC = new ArrayList<GroupComponent>();
    			for (GroupComponent groupComp:arrGrComp) {
    				grC.add(groupComp);
    			}
    			group.setGroupComponent(grC);
    		}
    		return groupList.toArray(arrGroup);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled Groups - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Group[] findEnabledGroupsByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getEnabledGroupsByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Group> groupList = query.getResultList();
    		Group[] arrGroup = new Group[groupList.size()];
    		for (Group group:groupList) {
    			GroupComponent[] arrGrComp = grComp.findByGroupId(group.getGrId());
    			List<GroupComponent> grC = new ArrayList();
    			for (GroupComponent groupComp:arrGrComp) {
    				grC.add(groupComp);
    			}
    			group.setGroupComponent(grC);
    		}
    		return groupList.toArray(arrGroup);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled Groups by divisCode - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Group[] findEnabledRealGroupsByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getEnabledRealGroupsByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Group> groupList = query.getResultList();
    		Group[] arrGroup = new Group[groupList.size()];
    		for (Group group:groupList) {
    			GroupComponent[] arrGrComp = grComp.findByGroupId(group.getGrId());
    			List<GroupComponent> grC = new ArrayList();
    			for (GroupComponent groupComp:arrGrComp) {
    				grC.add(groupComp);
    			}
    			group.setGroupComponent(grC);
    		}
    		return groupList.toArray(arrGroup);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled Groups by divisCode - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Group[] findActiveGroups() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllActiveGroups");
    		List<Group> group = query.getResultList();
    		Group[] arrGroup = new Group[group.size()];
    		return group.toArray(arrGroup);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active Groups - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Group[] findActiveGroupsByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getActiveGroupsByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Group> group = query.getResultList();
    		Group[] arrGroup = new Group[group.size()];
    		return group.toArray(arrGroup);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active Groups - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Group[] findProposedGroups() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllProposedGroups");
    		List<Group> group = query.getResultList();
    		Group[] arrGroup = new Group[group.size()];
    		return group.toArray(arrGroup);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching proposed Groups - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Group[] findProposedGroupsByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getProposedGroupsByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Group> group = query.getResultList();
    		Group[] arrGroup = new Group[group.size()];
    		return group.toArray(arrGroup);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching proposed Groups - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(String grName, Timestamp iniVDate, Timestamp endVDate, Timestamp sendDate, int rcCode, String comment, String status,
			BigDecimal userCoeff, BigDecimal crCoeff, int crNv, String crVarType, int crNDaysPer, Timestamp anDate, BigDecimal anCoeff, int anNDaysPer, int anNv, String anVarType, String propose, 
			BigDecimal propCoeff, String approval, String crLog, String anLog, String propLog, List<GroupComponent> groupComponentList) throws DataNotValidException {
		
		Group group = new Group();
		try {
			group.setGrName(grName);
			group.setIniVDate(iniVDate);
			group.setEndVDate(endVDate);
			group.setSendDate(sendDate);
			group.setRcCode(rcCode);
			group.setComment(comment);
			group.setStatus(status);
			group.setUserCoeff(userCoeff);
			group.setCrCoeff(crCoeff);
			group.setCrNv(crNv);
			group.setCrVarType(crVarType);
			group.setCrNDaysPer(crNDaysPer);
			group.setAnDate(anDate);
			group.setAnCoeff(anCoeff);
			group.setAnNDaysPer(anNDaysPer);
			group.setAnNv(anNv);
			group.setAnVarType(anVarType);
			group.setPropose(propose);
			group.setPropCoeff(propCoeff);
			group.setApproval(approval);
			group.setCrLog(crLog);
			group.setAnLog(anLog);
			group.setPropLog(propLog);
			group.setUpdType("C");
			group.setUpdDate(GenericTools.systemDate());
			group.setUpdUsr(userString());
			em.persist(group);
			for (GroupComponent grC:groupComponentList) {
				grC.getPk().setGrId(group.getGrId());
				grComp.store(grC);
			}
			log.debug("Added new Group - groupName: "+grName+"; curCoeff: "+crCoeff);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Group - grName: "+grName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(Group group) throws DataNotValidException {
		try {
			group.setUpdType(updType);
			group.setUpdDate(GenericTools.systemDate());
			group.setUpdUsr(userString());
			List<GroupComponent> groupComponentList = group.getGroupComponent(); 
			group.setGroupComponent(new ArrayList<GroupComponent>());
			em.persist(group);
			for (GroupComponent grC:groupComponentList) {
				grC.getPk().setGrId(group.getGrId());
				grComp.store(grC);
			}
			log.debug("Added new Group - groupName: "+group.getGrName()+"; curCoeff: "+group.getCrCoeff());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding Groups - groupName: "+group.getGrName()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void createGroupAndComponents(LinkedHashMap<String, String> groupValues, String grCompList) throws DataNotValidException {
		Query query = null;
    	
		try {
    		String strSync = "";
    		
    		    String columnList = "GRNAME,INIVDATE,ENDVDATE,SENDDATE,COMMENT,STATUS,CRVARTYPE,APPROVAL,ANVARTYPE,PROPOSE,CRLOG,DIVISCODE,RCCODE,USERCOEFF,CRCOEFF,CRNV,CRNDAYSPER,ANNDAYSPER,ANNV";
    			
    		    String[] arrColumns = columnList.split(",");
    		    
    		    String valueList = "";
    		    
    		    String grName = groupValues.get("GRNAME");
    		    
    		    for (int i=0;i<arrColumns.length;i++) {
    		    
    		    	if (i<12) {
    		    		valueList += "'"+groupValues.get(arrColumns[i])+"',";
    		    	} else {
    		    		valueList += groupValues.get(arrColumns[i])+",";
    		    	}
    		    	
    		    }
	    		
    		    valueList = valueList.substring(0,valueList.length()-1);
    		    
	    		String sqlInsert = "INSERT INTO PMPTGROUP ("+columnList+",UPDDATE,UPDUSR,UPDTYPE) VALUES ("+valueList+",'"+GenericTools.systemDate()+"','"+userString()+"','C')";
	    		
	    		//System.out.println(sqlInsert);
	    		
	    		query = em.createNativeQuery(sqlInsert);
	    		int stored = query.executeUpdate();
	    		
	    		log.debug("New pseudo group named "+grName+" stored");
	    		
	    		
	    		
	    		
	    		String[] grCompArray = grCompList.split(",");
	    		
	    		
	    		
	    		for (String gc:grCompArray) {
	    			
	    			int grCmp = Integer.parseInt(gc);
	    			sqlInsert = "INSERT INTO PMPTGRCMP (INSTRID,GRID,UPDDATE,UPDUSR,UPDTYPE) ";
	    			sqlInsert += "SELECT "+grCmp+", GRID,'"+GenericTools.systemDate()+"','"+userString()+"','C' FROM PMPTGROUP WHERE GRNAME = '"+grName+"'";
	    			
	    			query = em.createNativeQuery(sqlInsert);
	    			
	    			stored = query.executeUpdate();
	    			log.debug("New group component added to the pseudo group named "+grName+" stored");
	    		}
	    		//System.out.println(sqlInsert);
	    		
	    		
	    		

    	  		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding pseudo group and related components - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void setName(Group group) throws DataNotValidException {
		try {
			Group gr = findByPrimaryKey(group.getGrId());
			String grName = "Group";
			if (group.getGrId()>999 && group.getGrId()<10000) {
				grName += group.getGrId();
			} else if (group.getGrId()>99 && group.getGrId()<1000) {
				grName += "0"+group.getGrId();
			} else if (group.getGrId()>9 && group.getGrId()<100) {
				grName += "00"+group.getGrId();
			} else if (group.getGrId()<10) {
				grName += "000"+group.getGrId();
			}
			gr.setGrName(group.getGrName());
		} catch (Exception e) {
			log.debug("Error setting name to group: "+group.getGrId());
    		throw new DataNotValidException("Error setting name to group: "+group.getGrId());
		}
	}
	
	public void update(int grId, String grName, Timestamp iniVDate, Timestamp endVDate, Timestamp sendDate, int rcCode, String comment, String status,
		BigDecimal userCoeff, BigDecimal crCoeff, int crNv, String crVarType, int crNDaysPer, Timestamp anDate, BigDecimal anCoeff, int anNDaysPer, int anNv, String anVarType, String propose, 
		BigDecimal propCoeff, String approval, String crLog, String anLog, String propLog) throws DataNotValidException  {
		
		Group group = findByPrimaryKey(grId);
		try {
			group.setGrName(grName);
			group.setIniVDate(iniVDate);
			group.setEndVDate(endVDate);
			group.setSendDate(sendDate);
			group.setRcCode(rcCode);
			group.setComment(comment);
			group.setStatus(status);
			group.setUserCoeff(userCoeff);
			group.setCrCoeff(crCoeff);
			group.setCrNv(crNv);
			group.setCrVarType(crVarType);
			group.setCrNDaysPer(crNDaysPer);
			group.setAnDate(anDate);
			group.setAnCoeff(anCoeff);
			group.setAnNDaysPer(anNDaysPer);
			group.setAnNv(anNv);
			group.setAnVarType(anVarType);
			group.setPropose(propose);
			group.setPropCoeff(propCoeff);
			group.setApproval(approval);
			group.setCrLog(crLog);
			group.setAnLog(anLog);
			group.setPropLog(propLog);
			group.setUpdType("U");
			group.setUpdDate(GenericTools.systemDate());
			group.setUpdUsr(userString());
			log.debug("Group updated - groupId: "+grId+"; crCoeff: "+crCoeff);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Group - groupId: "+grId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(Group group) throws DataNotValidException {
		try {
			Group gr = findByPrimaryKey(group.getGrId());
			gr.setUpdType("U");
			gr.setUpdDate(GenericTools.systemDate());
			gr.setUpdUsr(userString());
			log.debug("Group updated - groupId: "+group.getGrId()+"; crCoeff: "+group.getCrCoeff());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Group - groupId: "+group.getGrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void logUpdate(Group group) throws DataNotValidException {
		try {
			update(group);
			//log.debug("Group updated - groupId: "+group.getGrId()+"; crCoeff: "+group.getCrCoeff());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Group - groupId: "+group.getGrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int grId) throws DataNotValidException {
		try {	
			Group group = findByPrimaryKey(grId);
			em.remove(group);
			log.debug("Removed Group  - groupId: "+group.getGrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Group - groupId: "+grId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeProposedGroup() throws DataNotValidException {
		Query query = null;
		try {
			Group[] proposed = findProposedGroups();
			query = em.createNamedQuery("deleteProposedGroup");
			int result = query.executeUpdate();
			log.debug(result+" proposed Groups removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing proposed Groups - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeProposedGroupByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
		try {
			//Group[] proposed = findProposedGroups();
			query = em.createNamedQuery("deleteProposedGroupByDivisCode");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" proposed Groups removed for diviscode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing proposed Groups for divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(Group group) throws DataNotValidException {
		remove(group.getGrId());
	}
	
	
	
	
	@Override
	public String getNewForcedGroupName() throws DataNotValidException{
		
		//recupero i gruppi su db
		Group[] grouparr = this.fetch();
		String groupPrefix="B";
		int nameLenght=3;
		
		
		//e inserisco i nomi in un vector dal quale filtro i gruppi che non hanno il gruppo prefisso selezionato
		Vector<String> groupnamesvec=new Vector<String>();
		for(Group g:grouparr){
			if(g.getGrName().startsWith(groupPrefix)){
			groupnamesvec.add(g.getGrName());
			}
		}
		
		Collections.sort(groupnamesvec);
		
		String groupname =  GenericTools.getNameFromLastString(nameLenght, "",groupPrefix);
		
		
		//e poi cerca il primo buco disponibile
		for (int i = 0; i < groupnamesvec.size(); i++) {
			//se il primo della lista risulta essere gi� dopo l'inizializzato allora tengo il group name inizializzato
			if(i==0&&(groupname.compareTo(groupnamesvec.elementAt(i))<0)){
				break;
			}
			
			String groupcur = groupnamesvec.elementAt(i);

			groupname = GenericTools.getNameFromLastString(nameLenght, groupcur,groupPrefix);

			if (i == groupnamesvec.size() - 1 || !(groupname.equalsIgnoreCase(groupnamesvec.elementAt(i + 1)))) {
				break;
			}

		}
		
		return groupname;
		
	
		
	}
}
