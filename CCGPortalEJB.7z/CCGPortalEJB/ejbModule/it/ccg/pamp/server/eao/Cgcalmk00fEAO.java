package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Cgcalmk00f;
import it.ccg.pamp.server.entities.Cgcalmk00fPK;
import it.ccg.pamp.server.entities.Cpsrss1;
import it.ccg.pamp.server.entities.Cpsrss1PK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class Cgcalmk00fEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class Cgcalmk00fEAO implements  Cgcalmk00fEAOLocal {

	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	public List<Cgcalmk00f> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllCgcalmk00f");
    		List<Cgcalmk00f> cgcalmk00fList = query.getResultList();
    		return cgcalmk00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Clearing calendar - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Cgcalmk00f> findDatesByMarketCode(String marketCode, long marketDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCgcalmk00fByMarketCode");
    		query.setParameter("marketCode", marketCode);
    		query.setParameter("lastDate", marketDate);
    		List<Cgcalmk00f> cgcalmk00fList = query.getResultList();
    		return cgcalmk00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Clearing calendar - marketCode: "+marketCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Cgcalmk00f> findDatesByMarketDate(long marketDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCgcalmk00fByMarketDate");
    		query.setParameter("marketDate", marketDate);
    		List<Cgcalmk00f> cgcalmk00fList = query.getResultList();
    		return cgcalmk00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Clearing calendar - marketDate: "+marketDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
