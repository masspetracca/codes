package it.ccg.pamp.server.eao;
import java.util.Set;

import it.ccg.pamp.server.entities.GroupComponent;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local//local
public interface GroupComponentEAOLocal {
	
	public GroupComponent[] fetch() throws DataNotValidException;
	
	public GroupComponent[] findByGroupId(int grId) throws DataNotValidException;
	
	public GroupComponent findByPrimaryKey(int grId, int instrId) throws DataNotValidException;
	
	public boolean existsGroupByInstrIdList(Set<Integer> instrIdList) throws DataNotValidException;
	
	public boolean existsGroupByInstrIdListNotPseudo(Set<Integer> instrIdList) throws DataNotValidException;
	
	public void add(int grId,int instrId) throws DataNotValidException;
	
	public void store(GroupComponent groupComponent) throws DataNotValidException;
	
	public int update(int grId,int instrId) throws DataNotValidException;
	
	public void remove(int grId,int instrId) throws DataNotValidException;
	
	public int removeByGrId(int grId) throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
	public void remove(GroupComponent groupComponent) throws DataNotValidException;
}
