package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.BondClassStatistic;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;

import javax.ejb.Local;

@Local
public interface BondClassStatisticEAOLocal {
	
	/*METODI DI RICERCA*/
	public BondClassStatistic[] fetch() throws DataNotValidException;
	
	public BondClassStatistic[] fetchWithMode1() throws DataNotValidException;
	
	public BondClassStatistic findByPrimaryKey(int instrId1, int instrId2, int nDaysPer, int nv, int mode) throws DataNotValidException;
	
	public BondClassStatistic[] findByInstrId(int instrId) throws DataNotValidException;
	
	public Integer[] getDistinctInstrId1() throws DataNotValidException;
	
	public BondClassStatistic[] findByInstrIdEither(int instrId1,int instrId2) throws DataNotValidException;
	
	public BondClassStatistic getIntraClassMinimum(int classId, String corrType) throws DataNotValidException;
	
	public BondClassStatistic getInterClassMinimum(int classId1, int classId2, String corrType) throws DataNotValidException;
		
	/*METODI DI INSERIMENTO*/
	
	public void add(int instrId1, int instrId2, int nDaysPer, int nv, int mode, int classId1, int classId2, BigDecimal correl, BigDecimal pearson, BigDecimal divundiv, int histDays, String status) throws DataNotValidException;
	
	public void store(BondClassStatistic bondClassStatistic) throws DataNotValidException;
	
	public void update(int instrId1, int instrId2, int nDaysPer, int nv, int mode, int classId1, int classId2, BigDecimal correl, BigDecimal pearson, BigDecimal divundiv, int histDays, String status) throws DataNotValidException;
	
	public void update(BondClassStatistic bondClassStatistic) throws DataNotValidException;
	
	/*METODI DI RIMOZIONE*/
	
	public void remove(BondClassStatistic bondClassStatistic) throws DataNotValidException;
	
	public void remove(int instrId1, int instrId2, int nDaysPer, int nv, int mode) throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
	public int removeCurrentStatistics() throws DataNotValidException;
	
	public int removeByMode(int mode) throws DataNotValidException;
	
	public int removeStatsOfDisabledClassesByDivisCodeAndMode1(String divisCode) throws DataNotValidException;
	
	public int removeStatsByClassIdAndMode1(int classId1, int classId2) throws DataNotValidException;
	
	public int removeByModeAndDivisCode(int mode,String divisCode) throws DataNotValidException;
	//public int transferMode1inMode2() throws DataNotValidException;
	
	public void transferMode1To2() throws DataNotValidException;
}
