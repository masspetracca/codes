package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Widget;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface WidgetEAOLocal {
	public Widget[] fetch() throws DataNotValidException;
}
