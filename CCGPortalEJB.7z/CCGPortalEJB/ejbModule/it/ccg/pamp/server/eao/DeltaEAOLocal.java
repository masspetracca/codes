package it.ccg.pamp.server.eao;


import javax.ejb.Local;

@Local
public interface DeltaEAOLocal {
	public Integer[] fetch();
}
