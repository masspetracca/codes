package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.FrequencyDistribution;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;

import javax.ejb.Local;

@Local
public interface FrequencyDistributionEAOLocal {
	public FrequencyDistribution[] fetch() throws DataNotValidException; 
	public FrequencyDistribution findByPrimaryKey(int instrId, int nv, int nDaysPer, String varType, int interval) throws DataNotValidException;
	public FrequencyDistribution[] findByInstrId(int instrId) throws DataNotValidException;
	public void add(int instrId, int nv, int nDaysPer, String varType, int interval, BigDecimal freq, BigDecimal cumFreq, int count) throws DataNotValidException;
	public void store(FrequencyDistribution frequencyDistribution) throws DataNotValidException;
	public void update(int instrId, int nv, int nDaysPer, String varType, int interval, BigDecimal freq, BigDecimal cumFreq, int count) throws DataNotValidException;
	public void update(FrequencyDistribution frequencyDistribution) throws DataNotValidException;
	public void remove(int instrId, int nv, int nDaysPer, String varType, int interval) throws DataNotValidException;
	public int removeByInstrId(int instrId) throws DataNotValidException;
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException;
	public void remove(FrequencyDistribution frequencyDistribution) throws DataNotValidException;
}
