package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestCgpris0hf;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface StressTestCgpris0hfEAOLocal {

	public List<StressTestCgpris0hf> fetch() throws DataNotValidException;
	
	public StressTestCgpris0hf findByPrimaryKey (Timestamp lDate, String lSymbl, String lOfCod) throws DataNotValidException;
	
	public void store(StressTestCgpris0hf stressTestCgpris0hf) throws DataNotValidException;
	
	public int removeAll() throws DataNotValidException;
	
}
