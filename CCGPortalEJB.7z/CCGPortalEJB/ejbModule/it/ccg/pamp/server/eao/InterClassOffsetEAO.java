package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.InterclassOffset;
import it.ccg.pamp.server.entities.InterclassOffsetPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class InterclassOffsetEAO
 */
@Stateless
public class InterClassOffsetEAO implements  InterClassOffsetEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public String userString = "System";
	public String updType = "C";
	
	public InterclassOffset[] fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllInterclassOffset");
    		List<InterclassOffset> interclassOffset = query.getResultList();
    		InterclassOffset[] arrInterclassOffset = new InterclassOffset[interclassOffset.size()];
    		return interclassOffset.toArray(arrInterclassOffset);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Interclass Offsets - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public InterclassOffset findByPrimaryKey(int classId1, int classId2) throws DataNotValidException {
		try {
			InterclassOffsetPK pK = new InterclassOffsetPK();
			pK.setClassId1(classId1);
			pK.setClassId2(classId2);
			InterclassOffset interclassOffset1 = (InterclassOffset) em.find(InterclassOffset.class,pK);
			if (interclassOffset1!=null) {
				return interclassOffset1;
			} else {
				pK.setClassId1(classId2);
				pK.setClassId2(classId1);
				InterclassOffset interclassOffset2 = (InterclassOffset) em.find(InterclassOffset.class,pK);
				if (interclassOffset2!=null) {
					return interclassOffset2;
				} else {
					return null;
				}
			}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Interclass Offset - classId1: "+classId1+"; classId2: "+classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
	public InterclassOffset findByPrimaryKey(int classId1, int classId2) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getInterclassOffsetByPrimaryKey");
    		query.setParameter("classId1",classId1);
    		query.setParameter("classId2",classId2);
    		List<InterclassOffset> interclassOffset = query.getResultList();
    		if (interclassOffset.size()>0) {
    			return interclassOffset.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled Interclass Offsets - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InterclassOffset[] findEnabledInterclassOffset() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllEnabledInterclassOffset");
    		List<InterclassOffset> interclassOffset = query.getResultList();
    		InterclassOffset[] arrInterclassOffset = new InterclassOffset[interclassOffset.size()];
    		return interclassOffset.toArray(arrInterclassOffset);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled Interclass Offsets - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InterclassOffset[] getEnabledInterclassOffsetByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getEnabledInterclassOffsetByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<InterclassOffset> interclassOffset = query.getResultList();
    		InterclassOffset[] arrInterclassOffset = new InterclassOffset[interclassOffset.size()];
    		return interclassOffset.toArray(arrInterclassOffset);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled Interclass Offsets - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InterclassOffset[] findActiveInterclassOffset() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllActiveInterclassOffset");
    		List<InterclassOffset> interclassOffset = query.getResultList();
    		InterclassOffset[] arrInterclassOffset = new InterclassOffset[interclassOffset.size()];
    		return interclassOffset.toArray(arrInterclassOffset);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active Interclass Offsets - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActiveDeltaForInterclass(int classId1, int classId2) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getActiveDeltaForInterclassOffset");
    		query.setParameter("classId1",classId1);
    		query.setParameter("classId2",classId2);
    		List<Integer> activeDeltaList = query.getResultList();
    		Integer[] arrActiveDelta = new Integer[activeDeltaList.size()];
    		activeDeltaList.toArray(arrActiveDelta);
    		return arrActiveDelta;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active delta for Interclass Offset - classId1: "+classId1+"; classId2: "+classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActivePeriodsForInterclass(int classId1, int classId2, int crNv) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getActivePeriodsForInterclassOffset");
    		query.setParameter("classId1",classId1);
    		query.setParameter("classId2",classId2);
    		query.setParameter("crNv",crNv);
    		List<Integer> activePeriodsList = query.getResultList();
    		Integer[] arrActivePeriods = new Integer[activePeriodsList.size()];
    		activePeriodsList.toArray(arrActivePeriods);
    		return arrActivePeriods;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active periods for Interclass Offset - classId1: "+classId1+"; classId2: "+classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InterclassOffset[] findProposedInterclassOffset() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllProposedInterclassOffset");
    		List<InterclassOffset> interclassOffset = query.getResultList();
    		InterclassOffset[] arrInterclassOffset = new InterclassOffset[interclassOffset.size()];
    		return interclassOffset.toArray(arrInterclassOffset);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching proposed Interclass Offsets - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	
	public void add(int classId1, int classId2, Timestamp anDate, Timestamp anFrstHisD, int anInstrId1, int anInstrId2, Timestamp anLastHisD, String anLog,
		int anNDaysPer, int anNv, BigDecimal anOff, String approval, String comment, Timestamp crFrstHisD, int crInstrId1, int crInstrId2, Timestamp crLastHisD,
		String crLog, int crNDaysPer, int crNv, BigDecimal crOff, String custom, Timestamp endVDate, Timestamp iniVDate, String propLog, BigDecimal propOff,
		String propose, int rcCode, Timestamp sendDate, String status, String susp, BigDecimal userOff) throws DataNotValidException {
		
		try {
			InterclassOffsetPK pK = new InterclassOffsetPK();
			InterclassOffset interclassOffset = new InterclassOffset();
			pK.setClassId1(classId1);
			pK.setClassId2(classId2);
			interclassOffset.setPk(pK);
			interclassOffset.setAnDate(anDate);
			interclassOffset.setAnFrstHisD(anFrstHisD);
			interclassOffset.setAnInstrId1(anInstrId1);
			interclassOffset.setAnInstrId2(anInstrId2);
			interclassOffset.setAnLastHisD(anLastHisD);
			interclassOffset.setAnLog("a");
			interclassOffset.setAnNDaysPer(anNDaysPer);
			interclassOffset.setAnNv(anNv);
			interclassOffset.setAnOff(anOff);
			interclassOffset.setApproval(approval);
			interclassOffset.setComment(comment);
			interclassOffset.setCrFrstHisD(crFrstHisD);
			interclassOffset.setCrInstrId1(crInstrId1);
			interclassOffset.setCrInstrId2(crInstrId2);
			interclassOffset.setCrLastHisD(crLastHisD);
			interclassOffset.setCrLog(crLog);
			interclassOffset.setCrNDaysPer(crNDaysPer);
			interclassOffset.setCrNv(crNv);
			interclassOffset.setCrOff(crOff);
			interclassOffset.setCustom(custom);
			interclassOffset.setEndVDate(endVDate);
			interclassOffset.setIniVDate(iniVDate);
			interclassOffset.setPropLog(propLog);
			interclassOffset.setPropOff(propOff);
			interclassOffset.setPropose(propose);
			interclassOffset.setRcCode(rcCode);
			interclassOffset.setSendDate(sendDate);
			interclassOffset.setStatus(status);
			interclassOffset.setSusp(susp);
			interclassOffset.setUserOff(userOff);
					
			interclassOffset.setUpdDate(GenericTools.systemDate());
			interclassOffset.setUpdUsr(userString());
			interclassOffset.setUpdType(updType);
					
			em.persist(interclassOffset);
			log.debug("Added new Interclass offset - classId1: "+classId1+"; classId2: "+classId2);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Interclass Offset - classId1: "+classId1+"; classId2: "+classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(InterclassOffset interclassOffset) throws DataNotValidException {
		try {
			interclassOffset.setUpdType(updType);
			interclassOffset.setUpdDate(GenericTools.systemDate());
			interclassOffset.setUpdUsr(userString());
			em.persist(interclassOffset);
			log.debug("Added new Interclass offset - classId1: "+interclassOffset.getPk().getClassId1()+"; classId2: "+interclassOffset.getPk().getClassId2());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Interclass Offset - classId1: "+interclassOffset.getPk().getClassId1()+"; classId2: "+interclassOffset.getPk().getClassId2()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int classId1, int classId2, Timestamp anDate, Timestamp anFrstHisD, int anInstrId1, int anInstrId2, Timestamp anLastHisD, String anLog,
		int anNDaysPer, int anNv, BigDecimal anOff, String approval, String comment, Timestamp crFrstHisD, int crInstrId1, int crInstrId2, Timestamp crLastHisD,
		String crLog, int crNDaysPer, int crNv, BigDecimal crOff, String custom, Timestamp endVDate, Timestamp iniVDate, String propLog, BigDecimal propOff,
		String propose, int rcCode, Timestamp sendDate, String status, String susp, BigDecimal userOff) throws DataNotValidException {
		
		try {
			InterclassOffset interclassOffset = findByPrimaryKey(classId1,classId2);
			interclassOffset.setAnDate(anDate);
			interclassOffset.setAnFrstHisD(anFrstHisD);
			interclassOffset.setAnInstrId1(anInstrId1);
			interclassOffset.setAnInstrId2(anInstrId2);
			interclassOffset.setAnLastHisD(anLastHisD);
			interclassOffset.setAnLog(anLog);
			interclassOffset.setAnNDaysPer(anNDaysPer);
			interclassOffset.setAnNv(anNv);
			interclassOffset.setAnOff(anOff);
			interclassOffset.setApproval(approval);
			interclassOffset.setComment(comment);
			interclassOffset.setCrFrstHisD(crFrstHisD);
			interclassOffset.setCrInstrId1(crInstrId1);
			interclassOffset.setCrInstrId2(crInstrId2);
			interclassOffset.setCrLastHisD(crLastHisD);
			interclassOffset.setCrLog(crLog);
			interclassOffset.setCrNDaysPer(crNDaysPer);
			interclassOffset.setCrNv(crNv);
			interclassOffset.setCrOff(crOff);
			interclassOffset.setCustom(custom);
			interclassOffset.setEndVDate(endVDate);
			interclassOffset.setIniVDate(iniVDate);
			interclassOffset.setPropLog(propLog);
			interclassOffset.setPropOff(propOff);
			interclassOffset.setPropose(propose);
			interclassOffset.setRcCode(rcCode);
			interclassOffset.setSendDate(sendDate);
			interclassOffset.setStatus(status);
			interclassOffset.setSusp(susp);
			interclassOffset.setUserOff(userOff);
			interclassOffset.setUpdDate(GenericTools.systemDate());
			interclassOffset.setUpdUsr(userString());
			interclassOffset.setUpdType("U");
			
			log.debug("Interclass offset updated - classId1: "+classId1+"; classId2: "+classId2);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Interclass Offset - classId1: "+classId1+"; classId2: "+classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(InterclassOffset interclassOffset) throws DataNotValidException {
		try {
			log.debug("Interclass offset updated - classId1: "+interclassOffset.getPk().getClassId1()+"; classId2: "+interclassOffset.getPk().getClassId2());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Interclass Offset - classId1: "+interclassOffset.getPk().getClassId1()+"; classId2: "+interclassOffset.getPk().getClassId2()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("resetInterClassOffset");
			query.setParameter(1, divisCode);
			query.setParameter(2, GenericTools.systemDate());
			query.setParameter(3, userString());
			int result = query.executeUpdate();
			log.info(result+" interclass offsets updated to disabled status - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating interclass offsets to disabled status - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public int updateStatusToDisabledForDisabledClasses(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("disableInterClassOffsetOfDisabledClasses");
			query.setParameter(1, divisCode);
			query.setParameter(2, GenericTools.systemDate());
			query.setParameter(3, userString());
			int result = query.executeUpdate();
			log.info(result+" interclass offsets updated to disabled status - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating interclass offsets to disabled status - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void remove(int classId1,int classId2) throws DataNotValidException {
		try {
			InterclassOffset interclassOffset = findByPrimaryKey(classId1,classId2);
			em.remove(interclassOffset);
			log.debug("Interclass offset removed - classId1: "+classId1+"; classId2: "+classId2);
		}  catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Interclass Offset - classId1: "+classId1+"; classId2: "+classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(InterclassOffset interclassOffset) throws DataNotValidException {
		remove(interclassOffset.getPk().getClassId1(),interclassOffset.getPk().getClassId1());
	}

}
