package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Ccgptas00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class Ccgptas00fEAO
 */
@Stateless
public class Ccgptas00fEAO implements  Ccgptas00fEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	public Ccgptas00f[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllCcgptas00f");
    		List<Ccgptas00f> ccgptas00f = query.getResultList();
    		Ccgptas00f[] arrCcgptas00f = new Ccgptas00f[ccgptas00f.size()];
    		return ccgptas00f.toArray(arrCcgptas00f);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Ccgptas00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Ccgptas00f findByIrNode(int irNode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCcgptas00fByIrNode");
    		query.setParameter("irNode", (long)irNode);
    		List<Ccgptas00f> ccgptas00f = query.getResultList();
    		if (ccgptas00f.size()>0) {
    			return ccgptas00f.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Ccgptas00f - irNode: "+irNode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Ccgptas00f findByPrimaryKey(int irNode, long date) throws DataNotValidException {
		try {
			/*Ccgptas00fPK pK = new Ccgptas00fPK();
			pK.setSt0Day(irNode);			
			pK.setSt0Data(date);*/
			Ccgptas00f ccgptas00f = (Ccgptas00f) em.find(Ccgptas00f.class,irNode);
    		return ccgptas00f;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Ccgptas00f - irNode: "+irNode+"; date: "+date+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
}
