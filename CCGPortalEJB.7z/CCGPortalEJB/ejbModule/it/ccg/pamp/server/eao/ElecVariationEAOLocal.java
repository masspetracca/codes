package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.ElecVariation;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface ElecVariationEAOLocal {
	
	public List<ElecVariation> fetchAllElecVar() throws DataNotValidException;
	
	public ElecVariation findByPrimaryKey(int instrId, Timestamp priceDate, String varType) throws DataNotValidException;
	
	public BigDecimal getAvgElecVarByInstrIdAndMonth(int instrId, int year, int month) throws DataNotValidException;
	
	public BigDecimal getMaxElecVarByInstrIdAndMonth(int instrId, int month) throws DataNotValidException;
	
	public List<ElecVariation> getElecVarByMonthAndVarType(int month, String varType) throws DataNotValidException;
	
	public List<ElecVariation> getElecVarByMonthAndVarType(int instrId, int month, String varType) throws DataNotValidException;
	
	public void add(int instrId, Timestamp priceDate, String varType, BigDecimal closePr, BigDecimal punAve, int punMonth, int punYear, String status, BigDecimal variat) throws DataNotValidException;
	
	public void store(ElecVariation elVariation) throws DataNotValidException;
	
	public void update(int instrId, Timestamp priceDate, String varType, BigDecimal closePr, BigDecimal punAve, int punMonth, int punYear, String status, BigDecimal variat) throws DataNotValidException;
	
	public void remove(int instrId, Timestamp priceDate, String varType) throws DataNotValidException;
	
	public void remove(ElecVariation elecVar) throws DataNotValidException;
	
	public int removeByEnabledInstrId() throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;

}
