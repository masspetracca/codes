package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Ccgdur00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondToSync;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface Ccgdur00fEAOLocal {

	public List<Ccgdur00f> fetch() throws DataNotValidException;
	
	public List<Ccgdur00f> getCcgdur00fByDate(Timestamp priceDate) throws DataNotValidException;
	
	public Ccgdur00f findByPrimaryKey(String isinCode, BigDecimal numCed, Timestamp priceDate) throws DataNotValidException;
	
	public List<BondToSync> getBondToSync() throws DataNotValidException;
	
	public List<Ccgdur00f> findByNumCed(BigDecimal numCed) throws DataNotValidException;
	
}
