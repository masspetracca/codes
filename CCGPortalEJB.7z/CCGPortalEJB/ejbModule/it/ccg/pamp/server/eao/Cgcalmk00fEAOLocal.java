package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Cgcalmk00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface Cgcalmk00fEAOLocal {
	public List<Cgcalmk00f> fetch() throws DataNotValidException;
	public List<Cgcalmk00f> findDatesByMarketCode(String marketCode,long marketDate) throws DataNotValidException;
	public List<Cgcalmk00f> findDatesByMarketDate(long marketDate) throws DataNotValidException;
}
