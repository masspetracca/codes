package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.InstrChangeTrack;
import it.ccg.pamp.server.entities.Margin;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class InstrChangeTrackEAO
 */
@Stateless
public class InstrChangeTrackEAO implements InstrChangeTrackEAOLocal {
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}

	@Override
	public InstrChangeTrack findByPrimaryKey(int instrId) throws DataNotValidException {
		try {
			InstrChangeTrack instrchtrack = (InstrChangeTrack) em.find(InstrChangeTrack.class,instrId);
    		return instrchtrack;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching intrument change track - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	@Override
	public void store(InstrChangeTrack instrchtrack) throws DataNotValidException {
		try {
			instrchtrack.setUpdtype(updType);
			instrchtrack.setUpddate(GenericTools.systemDate());
			instrchtrack.setUpdusr(userString());
			em.persist(instrchtrack);
			log.debug("Added new Margin - instrId: "+instrchtrack.getInstrid());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new intrument change track - instrId: "+instrchtrack.getInstrid()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	
	
	

}
