package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.IntraclassOffset;
import it.ccg.pamp.server.entities.IntraclassOffsetHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;
import javax.persistence.Query;

@Local
public interface IntraClassOffsetHistoryEAOLocal {
	public IntraclassOffsetHistory[] fetch() throws DataNotValidException;
	public IntraclassOffsetHistory getLastSentIntraClassOffset(int classId) throws DataNotValidException;
	public IntraclassOffsetHistory findByPrimaryKey(int classId, Timestamp iniVDate) throws DataNotValidException;
	public IntraclassOffsetHistory[] findEnabledIntraclassOffsetHistory() throws DataNotValidException;
	public IntraclassOffsetHistory getCurrentIntraclassOffsetHistory(int classId) throws DataNotValidException;
	public IntraclassOffsetHistory[] findActiveIntraclassOffsetHistory() throws DataNotValidException; 
	public Integer[] getActiveDeltaForIntraclassOffsetHistory(int classId) throws DataNotValidException;
	public Integer[] getActivePeriodsForIntraclassOffsetHistory(int classId, int crNv) throws DataNotValidException;
	public IntraclassOffsetHistory[] findProposedIntraclassOffsetHistory() throws DataNotValidException; 
	public List<IntraclassOffsetHistory> getIntraClassOffsetHistoryToExport() throws DataNotValidException;
	
	public void add(int classId, Timestamp iniVDate, Timestamp anDate, BigDecimal anOff, Timestamp apprDate, String approvedBy, String comment, Timestamp endVDate,
			String log, BigDecimal off, int rcCode, Timestamp sendDate, String sent, String susp, String status) throws DataNotValidException;
	
	public void store(IntraclassOffsetHistory intraclassOffsetHistory) throws DataNotValidException;
	public void store(IntraclassOffset intraclassOffset) throws DataNotValidException;
	
	public void logUpdate(IntraclassOffsetHistory intraclassOffsetHistory) throws DataNotValidException;
	
	public void update(int classId, Timestamp iniVDate, Timestamp anDate, BigDecimal anOff, Timestamp apprDate, String approvedBy, String comment, Timestamp endVDate,
			String log, BigDecimal off, int rcCode, Timestamp sendDate, String sent, String susp, String status) throws DataNotValidException;
	
	public void update(IntraclassOffsetHistory intraclassOffsetHistory) throws DataNotValidException;
	
	public void remove(int classId, Timestamp iniVDate) throws DataNotValidException;
	public int removeIntraClassOffsetByClass(int classId) throws DataNotValidException;
	public void remove(IntraclassOffsetHistory intraclassOffsetHistory) throws DataNotValidException;
}