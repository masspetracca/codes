package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.MarginCover;
import it.ccg.pamp.server.entities.MarginCoverPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MarginCoverEAO
 */
@Stateless
public class MarginCoverEAO implements  MarginCoverEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public String userString = "System";
	public String updType = "C";
	
	
	@SuppressWarnings("unchecked")
	public MarginCover[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllMarginCover");
    		List<MarginCover> marginCover = query.getResultList();
    		MarginCover[] arrMarginCover = new MarginCover[marginCover.size()];
    		return marginCover.toArray(arrMarginCover);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Margin Covers - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public MarginCover[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMarginCoverByInstrId");
    		query.setParameter("instrId", instrId);
    		List<MarginCover> marginCover = query.getResultList();
    		MarginCover[] arrMarginCover = new MarginCover[marginCover.size()];
    		return marginCover.toArray(arrMarginCover);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Margin Covers - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public MarginCover findByPrimaryKey(int instrId, int nDaysPer, int nv) throws DataNotValidException {
		try {
			MarginCoverPK pK = new MarginCoverPK();
			pK.setInstrId(instrId);
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			MarginCover marginCover = em.find(MarginCover.class,pK);
    		return marginCover;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Margin Cover - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void add(int instrId, int nDaysPer, int nv, BigDecimal propMarCov, BigDecimal propMarSd, BigDecimal matDMarSd, BigDecimal matDMarCov, BigDecimal mathMarCov, BigDecimal mathMarSd) throws DataNotValidException {
		try {
			MarginCover marginCover = new MarginCover();
			MarginCoverPK pK = new MarginCoverPK();
			pK.setInstrId(instrId);
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			marginCover.setPk(pK);
			marginCover.setPropMarCov(propMarCov);
			marginCover.setPropMarSd(propMarSd);
			marginCover.setMatDMarSd(matDMarSd);
			marginCover.setMatDMarCov(matDMarCov);
			marginCover.setMathMarCov(mathMarCov);
			marginCover.setMathMarSd(mathMarSd);
			marginCover.setUpdDate(GenericTools.systemDate());
			marginCover.setUpdType(updType);
			marginCover.setUpdUsr(userString());
			em.persist(marginCover);
			log.debug("Added new Margin Cover - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Margin Cover - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(MarginCover marginCover) throws DataNotValidException {
		try {
			marginCover.setUpdType(updType);
			marginCover.setUpdDate(GenericTools.systemDate());
			marginCover.setUpdUsr(userString());
			//System.out.println(marginCover.toString());
			em.persist(marginCover);
			log.debug("Added new Margin Cover - instrId: "+marginCover.getPk().getInstrId()+"; nDaysPer: "+marginCover.getPk().getNDaysPer()+"; holding period: "+marginCover.getPk().getNv());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Margin Cover - instrId: "+marginCover.getPk().getInstrId()+"; nDaysPer: "+marginCover.getPk().getNDaysPer()+"; holding period: "+marginCover.getPk().getNv()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, int nDaysPer, int nv, BigDecimal propMarCov, BigDecimal propMarSd, BigDecimal matDMarSd, BigDecimal matDMarCov, BigDecimal mathMarCov, BigDecimal mathMarSd) throws DataNotValidException {
		try {
			MarginCover marginCover = findByPrimaryKey(instrId,nDaysPer, nv);
		
			marginCover.setPropMarCov(propMarCov);
			marginCover.setPropMarSd(propMarSd);
			marginCover.setMatDMarSd(matDMarSd);
			marginCover.setMatDMarCov(matDMarCov);
			marginCover.setMathMarCov(mathMarCov);
			marginCover.setMathMarSd(mathMarSd);
			marginCover.setUpdDate(GenericTools.systemDate());
			marginCover.setUpdType("U");
			marginCover.setUpdUsr(userString());
			log.debug("Margin Cover updated - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Margin Cover - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(MarginCover marCover) throws DataNotValidException {
		try {	
			log.debug("Margin Cover updated - instrId: "+marCover.getPk().getInstrId()+"; nDaysPer: "+marCover.getPk().getNDaysPer()+"; holding period: "+marCover.getPk().getNv());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Margin Cover - instrId: "+marCover.getPk().getInstrId()+"; nDaysPer: "+marCover.getPk().getNDaysPer()+"; holding period: "+marCover.getPk().getNv()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void logUpdate(MarginCover marCover) throws DataNotValidException {
		try {	
			/*MarginCover marginCover = findByPrimaryKey(marCover.getPk().getInstrId(),marCover.getPk().getNDaysPer(),marCover.getPk().getNv());
			marginCover.setPropMarCov(marCover.getPropMarCov());
			marginCover.setPropMarSd(marCover.getPropMarSd());
			marginCover.setMatDMarSd(marCover.getMatDMarSd());
			marginCover.setMatDMarCov(marCover.getMatDMarCov());
			marginCover.setMathMarCov(marCover.getMathMarCov());
			marginCover.setMathMarSd(marCover.getMathMarSd());*/
			log.debug("Margin Cover updated - instrId: "+marCover.getPk().getInstrId()+"; nDaysPer: "+marCover.getPk().getNDaysPer()+"; holding period: "+marCover.getPk().getNv());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Margin Cover - instrId: "+marCover.getPk().getInstrId()+"; nDaysPer: "+marCover.getPk().getNDaysPer()+"; holding period: "+marCover.getPk().getNv()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, int nDaysPer, int nv) throws DataNotValidException {
		try {
			MarginCover marginCover = findByPrimaryKey(instrId,nDaysPer, nv);
			em.remove(marginCover);
			log.debug("Margin Cover removed - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Margin Cover - instrId: "+instrId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteMarginCoverByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Margin Cover removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Margin Cover - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteMarginCoverByEnabledInstrId");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" Margin Cover removed - instruments with divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing Margin Cover - instruments with divisCode: "+divisCode+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	public void remove(MarginCover marCover) throws DataNotValidException {
		remove(marCover.getPk().getInstrId(),marCover.getPk().getNDaysPer(),marCover.getPk().getNv());
	}

}
