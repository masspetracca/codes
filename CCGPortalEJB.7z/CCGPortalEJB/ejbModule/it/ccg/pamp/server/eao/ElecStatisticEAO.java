package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ElecStatistic;
import it.ccg.pamp.server.entities.ElecStatisticPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ElecStatisticEAO
 */
@Stateless
public class ElecStatisticEAO implements  ElecStatisticEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	
	
	public List<ElecStatistic> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllElecStatistics");
    		List<ElecStatistic> elecStatisticList = query.getResultList();
    		return elecStatisticList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives statistics - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<ElecStatistic> fetchWithMode1() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllElecStatisticsWithMode1");
    		List<ElecStatistic> elecStatisticList = query.getResultList();
    		return elecStatisticList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives statistics with mode 1 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ElecStatistic> findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getElecStatisticsByInstrId");
    		query.setParameter("instrId", instrId);
    		List<ElecStatistic> elecStatisticList = query.getResultList();
    		return elecStatisticList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives statistics - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<String> printElecStatistics(int instrId) throws DataNotValidException {
		
		List<ElecStatistic> elecStatisticList = this.findByInstrId(instrId);
		
		String elecStLog = "";
		
		List<String> elecStatsForLog = new ArrayList<String>();
		
		MathContext mc = new MathContext(2);
		
		int counter = 0;
		
		for (ElecStatistic elecStat:elecStatisticList) {
		
				elecStLog = "";
				
				elecStLog += "Month: "+elecStat.getPk().getMonth()+"; ";
				elecStLog += "Standard Deviation: "+GenericTools.roundValue(elecStat.getStDev().doubleValue(),mc)+"; ";
				elecStLog += "Average variation (ABS): "+elecStat.getAverage().round(mc)+"; ";
				elecStLog += "Number of times this month had the max value: "+elecStat.getCntMaxEvnt()+"; ";
				elecStLog += "Year in which this margin was the max value: "+elecStat.getMaxYear()+"; ";
				elecStLog += "Min variation (ABS): "+GenericTools.percentValue(elecStat.getMin(),mc);
				elecStLog += "Max variation (ABS): "+GenericTools.percentValue(elecStat.getMax(),mc);
				
				
				elecStatsForLog.add(elecStLog);
		}
		
		return elecStatsForLog;
	}
	
	
	public ElecStatistic findByPrimaryKey(int instrId, String varType,int mode, int month) throws DataNotValidException {
		try {
			ElecStatisticPK pK = new ElecStatisticPK();
			pK.setInstrId(instrId);
			pK.setVarType(varType);
			pK.setMode(mode);
			pK.setMonth(month);
			ElecStatistic elecStatistic = (ElecStatistic) em.find(ElecStatistic.class,pK);
    		return elecStatistic;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives statistic - instrId: "+instrId+"; varType: "+varType+"; mode: "+mode+"; month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	public void add(int instrId, String varType, int mode, int month, int active, BigDecimal average, int cntMaxEvnt, 
		BigDecimal max, int maxYear, BigDecimal min, String status, BigDecimal stDev) throws DataNotValidException {
		
		try {
			ElecStatistic elecStatistic = new ElecStatistic();
			ElecStatisticPK pK = new ElecStatisticPK();

			pK.setInstrId(instrId);
			pK.setVarType(varType);
			pK.setMode(mode);
			pK.setMonth(month);	
			
			elecStatistic.setPk(pK);
			
			elecStatistic.setActive(active);
			elecStatistic.setAverage(average);
			elecStatistic.setCntMaxEvnt(cntMaxEvnt);
			elecStatistic.setMax(max);
			elecStatistic.setMaxYear(maxYear);
			elecStatistic.setMin(min);
			elecStatistic.setStatus(status);			
			elecStatistic.setStDev(stDev);
						
			elecStatistic.setUpdDate(GenericTools.systemDate());
			elecStatistic.setUpdType(updType);
			elecStatistic.setUpdUsr(userString());
			
			em.persist(elecStatistic);
			
			log.debug("Added new electricity derivatives statistic - instrId: "+instrId+"; varType: "+varType+"; mode: "+mode+"; month: "+month);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new electricity derivatives statistic - instrId: "+instrId+"; varType: "+varType+"; mode: "+mode+"; month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public void store(ElecStatistic elecStatistic) throws DataNotValidException {
		try {

			elecStatistic.setUpdDate(GenericTools.systemDate());
			elecStatistic.setUpdType(updType);
			elecStatistic.setUpdUsr(userString());
			
			em.persist(elecStatistic);
			
			log.debug("Added new electricity derivatives statistic - instrId: "+elecStatistic.getPk().getInstrId()+"; varType: "+elecStatistic.getPk().getVarType()+"; mode: "+elecStatistic.getPk().getMode()+"; month: "+elecStatistic.getPk().getMonth());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new electricity derivatives statistic - instrId: "+elecStatistic.getPk().getInstrId()+"; varType: "+elecStatistic.getPk().getVarType()+"; mode: "+elecStatistic.getPk().getMode()+"; month: "+elecStatistic.getPk().getMonth()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void update(int instrId, String varType, int mode, int month, int active, BigDecimal average, int cntMaxEvnt, 
			BigDecimal max, int maxYear, BigDecimal min, String status, BigDecimal stDev) throws DataNotValidException {
		try {
			
			ElecStatistic elecStatistic = this.findByPrimaryKey(instrId, varType, mode, month);
			
			elecStatistic.setActive(active);
			elecStatistic.setAverage(average);
			elecStatistic.setCntMaxEvnt(cntMaxEvnt);
			elecStatistic.setMax(max);
			elecStatistic.setMaxYear(maxYear);
			elecStatistic.setMin(min);
			elecStatistic.setStatus(status);			
			elecStatistic.setStDev(stDev);
						
			elecStatistic.setUpdDate(GenericTools.systemDate());
			elecStatistic.setUpdType("U");
			elecStatistic.setUpdUsr(userString());
			
			log.debug("Electricity derivatives statistic updated - instrId: "+instrId+"; varType: "+varType+"; mode: "+mode+"; month: "+month);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating electricity derivatives statistic - instrId: "+instrId+"; varType: "+varType+"; mode: "+mode+"; month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(ElecStatistic elecStatistic) throws DataNotValidException {
		try {
			log.debug("Electricity derivatives statistic updated - - instrId: "+elecStatistic.getPk().getInstrId()+"; varType: "+elecStatistic.getPk().getVarType()+"; mode: "+elecStatistic.getPk().getMode()+"; month: "+elecStatistic.getPk().getMonth());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating electricity derivatives statistic - instrId: "+elecStatistic.getPk().getInstrId()+"; varType: "+elecStatistic.getPk().getVarType()+"; mode: "+elecStatistic.getPk().getMode()+"; month: "+elecStatistic.getPk().getMonth()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, String varType, int mode, int month) throws DataNotValidException {
		try {
			ElecStatistic elecStatistic = this.findByPrimaryKey(instrId, varType, mode, month);
			em.remove(elecStatistic);
			log.debug("Electricity derivatives statistic - instrId: "+instrId+"; varType: "+varType+"; mode: "+mode+"; month: "+month);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing electricity derivatives statistic - instrId: "+instrId+"; varType: "+varType+"; mode: "+mode+"; month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public int removeByMonth(int month) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteElecStatisticsByMonth");
			query.setParameter("month", month);
			int result = query.executeUpdate();
			log.debug(result+" electricity derivatives statistics removed for month "+month);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing electricity derivatives statistics for month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteElecStatisticsByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug(result+" electricity derivatives statistics removed - instrId: "+instrId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing electricity derivatives statistics - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByMode(int mode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteElecStatisticsByMode");
			query.setParameter("mode", mode);
			int result = query.executeUpdate();
			log.debug(result+" Instrument Statistic - mode: "+mode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing electricity derivatives statistics - mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(ElecStatistic elecStatistic) throws DataNotValidException {
		this.remove(elecStatistic.getPk().getInstrId(), elecStatistic.getPk().getVarType(), elecStatistic.getPk().getMode(), elecStatistic.getPk().getMonth());
	}
	
	public void transferMode1To2() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("deleteMode2FromElecStats");
    		query.executeUpdate();
    		
    		query = em.createNativeQuery("INSERT INTO PMPTELSTAT (INSTRID,VARTYPE,MODE,MONTH,ACTIVE,AVERAGE,CNTMAXEVNT,MAX,MAXYEAR,MIN,STATUS,STDEV,UPDDATE,UPDTYPE,UPDUSR) " +
			"SELECT INSTRID,VARTYPE,2,MONTH,ACTIVE,AVERAGE,CNTMAXEVNT,MAX,MAXYEAR,MIN,STATUS,STDEV,'"+GenericTools.systemDate()+"','C','"+userString()+"' FROM PMPTELSTAT WHERE MODE=1");
    		query.executeUpdate();
    		
    		log.debug("transfer of electricity derivatives statistics from mode 1 to 2 has been completed");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring electricity derivatives statistics from mode 1 to 2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
}
