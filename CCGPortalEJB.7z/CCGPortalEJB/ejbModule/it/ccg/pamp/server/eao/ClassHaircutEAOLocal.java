package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.ClassHaircut;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface ClassHaircutEAOLocal {
	
	public List<ClassHaircut> fetch() throws DataNotValidException;
	
	public ClassHaircut findByPrimaryKey(int classId) throws DataNotValidException;
	
	public List<ClassHaircut> findEnabledHaircutClass() throws DataNotValidException;
	
	public List<ClassHaircut> findEnabledHaircutClassByDivisCode(String divisCode) throws DataNotValidException;
	
	public boolean noHaircutSubmittedForApproval() throws DataNotValidException;
	
	public void add(int classId, BigDecimal anCap, BigDecimal anCover, Timestamp anDate, BigDecimal anFloor, Timestamp anFrstHisD, BigDecimal anHct, Timestamp anLastHisD,
		String anLog, BigDecimal anMargin, BigDecimal anMult, int anNDaysPer, int anNodeId, String anNodes, int anNv, BigDecimal anRlHct,
		String approval, String comment, BigDecimal crCap, BigDecimal crCover, BigDecimal crFloor, Timestamp crFrstHisD, BigDecimal crHct, Timestamp crLastHisD,
		String crLog, BigDecimal crMargin, BigDecimal crMult, int crNDaysPer, int crNodeId, String crNodes, int crNv, BigDecimal crRlHct,
		String custom, String divisCode, Timestamp endVDate, Timestamp iniVDate, BigDecimal propHct, String propLog, String propose, int rcCode,
		Timestamp sendDate, String status, String susp, BigDecimal userHct,BigDecimal anAddend, BigDecimal crAddend) throws DataNotValidException;
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException;
	
	public void update(int classId, BigDecimal anCap, BigDecimal anCover, Timestamp anDate, BigDecimal anFloor, Timestamp anFrstHisD, BigDecimal anHct, Timestamp anLastHisD,
		String anLog, BigDecimal anMargin, BigDecimal anMult, int anNDaysPer, int anNodeId, String anNodes, int anNv, BigDecimal anRlHct,
		String approval, String comment, BigDecimal crCap, BigDecimal crCover, BigDecimal crFloor, Timestamp crFrstHisD, BigDecimal crHct, Timestamp crLastHisD,
		String crLog, BigDecimal crMargin, BigDecimal crMult, int crNDaysPer, int crNodeId, String crNodes, int crNv, BigDecimal crRlHct,
		String custom, String divisCode, Timestamp endVDate, Timestamp iniVDate, BigDecimal propHct, String propLog, String propose, int rcCode,
		Timestamp sendDate, String status, String susp, BigDecimal userHct,BigDecimal anAddend, BigDecimal crAddend) throws DataNotValidException;
	
	public void store(ClassHaircut classHaircut) throws DataNotValidException;
	
	public void remove(int classId) throws DataNotValidException;
	
	public void remove(ClassHaircut classHaircut) throws DataNotValidException;

}
