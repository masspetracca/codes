package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.DefaultFundRegister;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface DefaultFundRegisterEAOLocal {

	public List<DefaultFundRegister> fetch() throws DataNotValidException;
	
	public List<DefaultFundRegister> getDefFundRegByIniVDate(Timestamp dfIniVDate) throws DataNotValidException;
	
	public List<DefaultFundRegister> getDefFundRegByDefType(String dfType) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * returns the first def. fund available before the entry initial validity date 
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param iniVDate - the initial validity date to use in filter
	   * @throws DataNotValidException;
	   * @return  the def. fund entity or the occurred exception 
	   */
	public DefaultFundRegister getLastDefFundRegByDfIniVDate(Timestamp dfInivDate) throws DataNotValidException;
	
	public DefaultFundRegister getLastDefFundRegByDfIniVDateAndType(Timestamp dfInivDate, String type) throws DataNotValidException;
	
	public DefaultFundRegister findByPrimaryKey(String dfType, Timestamp dfIniVDate) throws DataNotValidException;
	
	public void add(String dfType, Timestamp dfIniVDate, String comment, BigDecimal dfValue) throws DataNotValidException;
	
	public void store(DefaultFundRegister defaultFundRegister) throws DataNotValidException;
	
	public void update(String dfType, Timestamp dfIniVDate, String comment, BigDecimal dfValue) throws DataNotValidException;
	
	public void update(DefaultFundRegister defaultFundRegister) throws DataNotValidException;
	
	public void remove(String dfType, Timestamp dfIniVDate) throws DataNotValidException;
	
	
}
