package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.InfoProviderHispr;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class InfoProviderHisprEAO
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class InfoProviderHisprEAO implements InfoProviderHisprEAOLocal {

	@PersistenceContext(unitName="INFOP", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public List<InfoProviderHispr> findByInstrIdAfterDate(int instrId, long priceDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("findByInstrIdAfterDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("priceDate", (int) priceDate);
    		List<InfoProviderHispr> infoProvHisprList = query.getResultList();
    		return infoProvHisprList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices - instrId: "+instrId+"; date: "+GenericTools.convertDateFromIntToTimestamp((int)priceDate)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
