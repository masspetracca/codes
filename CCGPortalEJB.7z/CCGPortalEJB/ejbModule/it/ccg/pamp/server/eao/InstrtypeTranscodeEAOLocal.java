package it.ccg.pamp.server.eao;
import java.util.LinkedHashMap;

import it.ccg.pamp.server.entities.InstrtypeTranscode;
import it.ccg.pamp.server.entities.InstrtypeTranscodePK;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface InstrtypeTranscodeEAOLocal {

	public InstrtypeTranscode[] fetch() throws DataNotValidException;
	
	public InstrtypeTranscode[] getTrsCodeByInstrType(String instrType) throws DataNotValidException;
	
	public InstrtypeTranscode[] getTrsCodeBySicInstrType(String sicInstrTy) throws DataNotValidException;
	
	public InstrtypeTranscode getSingleTrsCodeBySicInstrType(String sicInstrTy) throws DataNotValidException;
	
	public InstrtypeTranscode findByPrimaryKey(String instrType, String sicInstrTy) throws DataNotValidException;
	
	public LinkedHashMap<String, String> getTypeTrascodeMap() throws DataNotValidException;
	
}
