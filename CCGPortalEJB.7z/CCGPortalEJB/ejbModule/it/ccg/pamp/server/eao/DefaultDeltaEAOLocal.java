package it.ccg.pamp.server.eao;
import java.util.List;

import it.ccg.pamp.server.entities.DefaultDelta;

import javax.ejb.Local;

@Local
public interface DefaultDeltaEAOLocal {
	public DefaultDelta[] fetch();
	
	public Integer[] getActiveDelta(String instrType);
	
	public List<Integer> getActiveDeltaMultipleDivisions(String divisions);
	
	public DefaultDelta[] findByInstrType(String instrType);
	
	public DefaultDelta findByPrimaryKey(String instrType, int nv);
}
