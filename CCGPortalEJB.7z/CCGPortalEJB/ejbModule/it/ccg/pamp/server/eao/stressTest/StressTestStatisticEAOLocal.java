package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestStatistic;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface StressTestStatisticEAOLocal {

	public List<StressTestStatistic> fetch() throws DataNotValidException; 
	
	public StressTestStatistic findByPrimaryKey(int instrId, String scenario, int stId) throws DataNotValidException;
	
	public List<StressTestStatistic> findByInstrIdAndScenario(int instrId, int stId) throws DataNotValidException;
	
	public void add(int instrId, String scenario, int stId, int extrN, String hp, int extrNv, int extrS, BigDecimal extrRes,
		BigDecimal marRes, BigDecimal stDevRes, BigDecimal scRes, Timestamp histUpdDay, String log, String choosenFun,
		String marDer, String marLog, String marProp, BigDecimal marUsed, int nDaysPer, BigDecimal stDev) throws DataNotValidException;
	
	public void store(StressTestStatistic stressTestStatistic) throws DataNotValidException;
	
	public void update(int instrId, String scenario, int stId, int extrN, String hp, int extrNv, int extrS, BigDecimal extrRes,
		BigDecimal marRes, BigDecimal stDevRes, BigDecimal scRes, Timestamp histUpdDay, String log, String choosenFun,
		String marDer, String marLog, String marProp, BigDecimal marUsed, int nDaysPer, BigDecimal stDev) throws DataNotValidException;
	
	public void update(StressTestStatistic stressTestStatistic) throws DataNotValidException;
	
	public void remove(int instrId, String scenario, int stId) throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
	public void remove(StressTestStatistic stressTestStatistic) throws DataNotValidException;
	
}
