package it.ccg.pamp.server.eao;
import java.util.List;

import it.ccg.pamp.server.entities.Set;
import it.ccg.pamp.server.entities.SetComponent;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface SetEAOLocal {
	public Set[] fetch() throws DataNotValidException;
	public Set findByPrimaryKey(int setId) throws DataNotValidException;
	public Set[] findByDivisCode(String divisCode) throws DataNotValidException;
	public Set[] findEnabledByDivisCode(String divisCode) throws DataNotValidException;
	public void add(String setName, String status, String divisCode, String note, List<SetComponent> setComponentList) throws DataNotValidException;
	public void store(Set set) throws DataNotValidException;
	public void update(int setId, String setName, String status, String divisCode, String note) throws DataNotValidException;
	public void update(Set st) throws DataNotValidException;
	public void remove(Set st) throws DataNotValidException;
}
