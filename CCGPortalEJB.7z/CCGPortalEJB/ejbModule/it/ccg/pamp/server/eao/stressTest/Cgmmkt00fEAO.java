package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.stressTest.StressTestCgmmkt00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.Cgmmkt00fJoined;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

/**
 * Session Bean implementation class Cgmmkt00fEAO
 */
@Stateless
public class Cgmmkt00fEAO implements  Cgmmkt00fEAOLocal {

	@PersistenceContext(unitName="STDS", type=PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	public List<StressTestCgmmkt00f> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllCgmmkt00f");
    		List<StressTestCgmmkt00f> cgmmkt00fList = query.getResultList();
    		return cgmmkt00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgmmkt00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Cgmmkt00fJoined> joinCgmmkt01lwithCgmbr00f() throws DataNotValidException {
		Query query = null;
    	try {
    		String strQuery = "SELECT MBR.MEXMEM AS MEXMEM, MKT.MKGCMID AS MKGCMID, 'F' AS EXPR1, 'C' AS EXPR2, MBR.MFMNAM AS MFMNAM, MBR.MMNEM4 AS MMNEM4, MAX(MKT.MKMKTID) AS firstMkmktid FROM CGMMKT00F MKT ";
			strQuery += "INNER JOIN CGMBR00F MBR ON MKT.MKMBRID = MBR.MEXMEM ";
			strQuery +=	"GROUP BY MBR.MEXMEM, MKT.MKGCMID, MBR.MFMNAM, MBR.MMNEM4";
    	    		
    		query = em.createNativeQuery(strQuery,Cgmmkt00fJoined.class);
    		List<Cgmmkt00fJoined> cgmmkt00fList = query.getResultList();
    		return cgmmkt00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgmbr00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public void update() throws DataNotValidException{
		Query query = null;
    	try {
    		query = em.createNativeQuery("UPDATE MMKT00F SET MKGRGC = 'ciao'");
    		query.executeUpdate();
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgmbr00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
}
