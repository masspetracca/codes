package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.Mtsmgnf90f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class Mtsmgnf90fEAO
 */
@Stateless
public class Mtsmgnf90fEAO implements  Mtsmgnf90fEAOLocal {

	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<Mtsmgnf90f> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllMtsmgnf90f");
    		List<Mtsmgnf90f> mtsmgnf90fList = query.getResultList();
    		return mtsmgnf90fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsmgnf90f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Mtsmgnf90f> getMtsmgnf90fNotinClMarHis() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMtsmgnf90fNotinClMarHis");
    		query.setParameter("systemDate", GenericTools.systemDate());
    		List<Mtsmgnf90f> mtsmgnf90fList = query.getResultList();
    		return mtsmgnf90fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsmgnf90f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Mtsmgnf90f findByPrimaryKey(int f90cdclass) throws DataNotValidException {
		try {
			String classId = "0";
			
			if (f90cdclass<10) {
				classId+=Integer.toString(f90cdclass);
			} else {
				classId = Integer.toString(f90cdclass);
			}
			Mtsmgnf90f mtsmgnf90f = (Mtsmgnf90f) em.find(Mtsmgnf90f.class,classId);
    		return mtsmgnf90f;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsmgnf90f - f90cdclass: "+f90cdclass+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public void update(int f90cdclass, BigDecimal f90inmargi) throws DataNotValidException {
		try {
			Mtsmgnf90f mtsmgnf90f = findByPrimaryKey(f90cdclass);
			mtsmgnf90f.setF90inmargi(f90inmargi);
			log.debug("Mtsmgnf90f updated - f90cdclass: "+f90cdclass+"; new margin: "+f90inmargi);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Mtsmgnf90f - f90cdclass: "+f90cdclass+"; f90inmargi: "+f90inmargi+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
}
