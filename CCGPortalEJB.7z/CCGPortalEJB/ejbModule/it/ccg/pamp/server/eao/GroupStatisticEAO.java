package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.GroupStatistic;
import it.ccg.pamp.server.entities.GroupStatisticPK;
import it.ccg.pamp.server.entities.InstrumentStatistic;
import it.ccg.pamp.server.entities.InstrumentStatisticPK;
import it.ccg.pamp.server.entities.Setup;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.GroupStatisticGroupedBy;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.SqlResultSetMapping;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class GroupStatisticEAO
 */
@Stateless
public class GroupStatisticEAO implements  GroupStatisticEAOLocal {

	@EJB private SetupEAOLocal setupEAO;
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public GroupStatistic[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllGroupStat");
    		List<GroupStatistic> groupStatistic = query.getResultList();
    		GroupStatistic[] arrGroupStatistic = new GroupStatistic[groupStatistic.size()];
    		return groupStatistic.toArray(arrGroupStatistic);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Statistics - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupStatistic[] fetchWithMode1() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllGroupStatWithMode1");
    		List<GroupStatistic> groupStatistic = query.getResultList();
    		GroupStatistic[] arrGroupStatistic = new GroupStatistic[groupStatistic.size()];
    		return groupStatistic.toArray(arrGroupStatistic);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Statistics with mode 1 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupStatistic findByPrimaryKey(int instrId1, int instrId2, int nDaysPer, int nv, String varType, int mode, int setId) throws DataNotValidException {
		try {
			GroupStatisticPK pK = new GroupStatisticPK();
			pK.setInstrId1(instrId1);
			pK.setInstrId2(instrId2);
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			pK.setVarType(varType);
			pK.setMode(mode);
			pK.setSetId(setId);
			GroupStatistic groupStatistic = (GroupStatistic) em.find(GroupStatistic.class,pK);
    		return groupStatistic;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Statistics - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; varType: "+varType+"; mode: "+mode+"; setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupStatistic[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getGSByInstrId");
    		query.setParameter("instrId", instrId);
    		List<GroupStatistic> groupStatistic = query.getResultList();
    		GroupStatistic[] arrGroupStatistic = new GroupStatistic[groupStatistic.size()];
    		return groupStatistic.toArray(arrGroupStatistic);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Statistics - instrId1: "+instrId+" OR instrId2: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupStatistic[] findBySetId(int setId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getGSBySetId");
    		query.setParameter("setId", setId);
    		List<GroupStatistic> groupStatistic = query.getResultList();
    		GroupStatistic[] arrGroupStatistic = new GroupStatistic[groupStatistic.size()];
    		return groupStatistic.toArray(arrGroupStatistic);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Statistics - setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupStatisticGroupedBy[] getEnabledMinCorrel(BigDecimal threshold, String corrType, int setId) throws DataNotValidException  {
		Query query = null;
    	try {
    		if (corrType.equals("C")) {
    			query = em.createNamedQuery("getMinCorrel");
    		} else if (corrType.equals("P")) {
    			query = em.createNamedQuery("getMinPearson");
    		} else if (corrType.equals("D")) {
    			query = em.createNamedQuery("getMinDivundiv");
    		}
    		Setup setup = setupEAO.findByPrimaryKey("E");
    		
    		query.setParameter("threshold", threshold);
    		query.setParameter("setId", setId);
    		query.setParameter("histDays", setup.getHisMinGr());
    		List<GroupStatisticGroupedBy> groupStatistic = query.getResultList();
    		GroupStatisticGroupedBy[] arrGroupStatistic = new GroupStatisticGroupedBy[groupStatistic.size()];
    		return groupStatistic.toArray(arrGroupStatistic);    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled minimum correlation - threshold: "+threshold+"; correlationType: "+corrType+"; setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getDistinctInstrId1() throws DataNotValidException  {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDistinctInstrId1");
    		List<Integer> instrId1 = query.getResultList();
    		Integer[] arrInstrId1 = new Integer[instrId1.size()];
    		return instrId1.toArray(arrInstrId1);    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching instrId list - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupStatistic[] findByInstrIdEither(int instrId1,int instrId2) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getGSByInstrIdEither");
    		query.setParameter("instrId1", instrId1);
    		query.setParameter("instrId2", instrId2);
    		List<GroupStatistic> groupStatistic = query.getResultList();
    		GroupStatistic[] arrGroupStatistic = new GroupStatistic[groupStatistic.size()];
    		return groupStatistic.toArray(arrGroupStatistic);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Statistics - instrId1: "+instrId1+"; instrId2: "+instrId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	

	public void add(int instrId1, int instrId2, int nDaysPer, int nv, String varType, int mode, int setId, int active, BigDecimal correl,
			BigDecimal pearson, BigDecimal divundiv, BigDecimal slope, BigDecimal relPerf, BigDecimal trackerr, int histDays, String status, String divisCode) throws DataNotValidException {
		
		try {
			GroupStatistic groupStatistic = findByPrimaryKey(instrId1, instrId2, nDaysPer, nv, varType,mode,setId);
			groupStatistic = new GroupStatistic();
			GroupStatisticPK pK = new GroupStatisticPK();
			
			pK.setInstrId1(instrId1);
			pK.setInstrId2(instrId2);
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			pK.setVarType(varType);
			pK.setMode(mode);
			pK.setSetId(setId);
			groupStatistic.setPk(pK);
			
			groupStatistic.setActive(active);
			groupStatistic.setCorrel(correl);
			groupStatistic.setPearson(pearson);
			groupStatistic.setDivundiv(divundiv);
			groupStatistic.setSlope(slope);
			groupStatistic.setRelperf(relPerf);
			groupStatistic.setTrackerr(trackerr);
			groupStatistic.setHistdays(histDays);
			groupStatistic.setStatus(status);
			groupStatistic.setDivisCode(divisCode);
			groupStatistic.setUpdDate(GenericTools.systemDate());
			groupStatistic.setUpdType(updType);
			groupStatistic.setUpdUsr(userString());
			em.persist(groupStatistic);
			log.debug("Added new Group Statistic - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; varType: "+varType+"; mode: "+mode+"; setId: "+setId+"; correl: "+correl+"; divundiv: "+divundiv+"; pearson: "+pearson);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Group Statistic - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; varType: "+varType+"; mode: "+mode+"; setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(GroupStatistic groupStatistic) throws DataNotValidException {
		try {
			groupStatistic.setUpdDate(GenericTools.systemDate());
			groupStatistic.setUpdType(updType);
			groupStatistic.setUpdUsr(userString());
			em.persist(groupStatistic);
			log.debug("Added new Group Statistic - instrId1: "+groupStatistic.getPk().getInstrId1()+"; instrId2: "+groupStatistic.getPk().getInstrId2()+"; nDaysPer: "+groupStatistic.getPk().getNDaysPer()+"; nv: "+groupStatistic.getPk().getNv()+"; varType: "+groupStatistic.getPk().getVarType()+"; mode: "+groupStatistic.getPk().getMode()+"; setId: "+groupStatistic.getPk().getSetId()+"; correl: "+groupStatistic.getCorrel()+"; divundiv: "+groupStatistic.getDivundiv()+"; pearson: "+groupStatistic.getPearson());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Group Statistic - instrId1: "+groupStatistic.getPk().getInstrId1()+"; instrId2: "+groupStatistic.getPk().getInstrId2()+"; nDaysPer: "+groupStatistic.getPk().getNDaysPer()+"; nv: "+groupStatistic.getPk().getNv()+"; varType: "+groupStatistic.getPk().getVarType()+"; mode: "+groupStatistic.getPk().getMode()+"; setId: "+groupStatistic.getPk().getSetId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId1, int instrId2, int nDaysPer, int nv, String varType, int mode, int setId, int active, 
			BigDecimal correl, BigDecimal pearson, BigDecimal divundiv, BigDecimal slope, BigDecimal relPerf, 
			BigDecimal trackerr, int histDays, String status, String divisCode) throws DataNotValidException {
		
		try {	
			GroupStatistic groupStatistic = findByPrimaryKey(instrId1, instrId2, nDaysPer, nv, varType,mode,setId);
		
			groupStatistic.setActive(active);
			groupStatistic.setCorrel(correl);
			groupStatistic.setPearson(pearson);
			groupStatistic.setDivundiv(divundiv);
			groupStatistic.setSlope(slope);
			groupStatistic.setRelperf(relPerf);
			groupStatistic.setTrackerr(trackerr);
			groupStatistic.setHistdays(histDays);
			groupStatistic.setStatus(status);
			groupStatistic.setDivisCode(divisCode);
			groupStatistic.setUpdDate(GenericTools.systemDate());
			groupStatistic.setUpdType("U");
			groupStatistic.setUpdUsr(userString());
			log.debug("Group Statistic updated - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; varType: "+varType+"; mode: "+mode+"; setId: "+setId+"; correl: "+correl+"; divundiv: "+divundiv+"; pearson: "+pearson);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Group Statistic - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; varType: "+varType+"; mode: "+mode+"; setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(GroupStatistic grStatistic) throws DataNotValidException {
		try {
			log.debug("Group Statistic updated - instrId1: "+grStatistic.getPk().getInstrId1()+"; instrId2: "+grStatistic.getPk().getInstrId2()+"; nDaysPer: "+grStatistic.getPk().getNDaysPer()+"; holding period: "+grStatistic.getPk().getNv()+"; varType: "+grStatistic.getPk().getVarType()+"; mode: "+grStatistic.getPk().getMode()+"; setId: "+grStatistic.getPk().getSetId()+"; correl: "+grStatistic.getCorrel()+"; divundiv: "+grStatistic.getDivundiv()+"; pearson: "+grStatistic.getPearson());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating new Group Statistic - instrId1: "+grStatistic.getPk().getInstrId1()+"; instrId2: "+grStatistic.getPk().getInstrId2()+"; nDaysPer: "+grStatistic.getPk().getNDaysPer()+"; holding period: "+grStatistic.getPk().getNv()+"; varType: "+grStatistic.getPk().getVarType()+"; mode: "+grStatistic.getPk().getMode()+"; setId: "+grStatistic.getPk().getSetId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public void remove(int instrId1, int instrId2, int nDaysPer, int nv, String varType, int mode, int setId) throws DataNotValidException {
		try {
			GroupStatistic groupStatistic = findByPrimaryKey(instrId1, instrId2, nDaysPer, nv, varType, mode, setId);
			em.remove(groupStatistic);
			log.debug("Group Statistic removed - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; varType: "+varType+"; mode: "+mode+"; setId: "+setId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Group Statistic - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; varType: "+varType+"; mode: "+mode+"; setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(GroupStatistic groupStatistic) throws DataNotValidException {
		remove(groupStatistic.getPk().getInstrId1(), groupStatistic.getPk().getInstrId2(), groupStatistic.getPk().getNDaysPer(), groupStatistic.getPk().getNv(), groupStatistic.getPk().getVarType(), groupStatistic.getPk().getMode(), groupStatistic.getPk().getSetId());
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteGSByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Group Statistic removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Group Statistic - instrId1: "+instrId+" OR instrId2: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public int removeCurrentStatistics() throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteCurrentStatistics");
			int result = query.executeUpdate();
			log.debug(result+" current Group Statistics removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing current Group Statistic - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeCurrentStatisticsByDivisCode(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			//query = em.createNamedQuery("deleteCurrentStatisticsByDivisCode");
			query = em.createNamedQuery("deleteCurrentStatisticsByDiviscodeAndMode");
			query.setParameter(1, divisCode);
			int result = query.executeUpdate();
			log.debug(result+" current Group Statistics removed for divisCode: "+divisCode+"; mode: 1");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing current Group Statistic - for divisCode: "+divisCode+"; mode: 1 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeStatisticBySetId(int setId, int mode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteStatisticBySetId");
			query.setParameter("setId", setId);
			query.setParameter("mode", mode);
			int result = query.executeUpdate();
			log.debug(result+" Group Statistic removed - mode: "+mode+"; setId: "+setId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Group Statistic - mode: "+mode+"; setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public int removeStatisticFromGroup() throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteStatisticFromGroup");
			int result = query.executeUpdate();
			log.debug(result+" Group Statistic removed from group");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Group Statistic from group - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public int removeStatisticFromGroupByDivisCode(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteStatisticFromGroupByDivisCode");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" Group Statistic removed from group for divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Group Statistic from group - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public int removeByMode(int mode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteGroupStatByMode");
			query.setParameter("mode", mode);
			int result = query.executeUpdate();
			log.debug(result+" Group Statistic removed - mode: "+mode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Group Statistic - mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public void transferMode1To2() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("deleteMode2forGrStats");
    		query.executeUpdate();
    		query = em.createNativeQuery("INSERT INTO PMPTGRSTAT "+
    		"(INSTRID1,INSTRID2,NDAYSPER,NV,VARTYPE,MODE,ACTIVE,CORREL,PEARSON,DIVUNDIV,SLOPE,RELPERF,TRACKERR,HISTDAYS,SETID,STATUS,DIVISCODE,UPDDATE,UPDTYPE,UPDUSR) "+	
    		"SELECT INSTRID1,INSTRID2,NDAYSPER,NV,VARTYPE,2,ACTIVE,CORREL,PEARSON,DIVUNDIV,SLOPE,RELPERF,TRACKERR,HISTDAYS,SETID,STATUS,DIVISCODE,'"+GenericTools.systemDate()+"','C','"+userString()+"' FROM PMPTGRSTAT WHERE MODE=1");
    		//query = em.createNamedQuery("transferMode1to2forGrStats");
    		//query.setParameter(1, GenericTools.systemDate());
    		//query.setParameter(2, userString());
    		query.executeUpdate();
    		log.debug("transfer of group stats from mode 1 to 2 has been completed");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring Group Statistics from mode 1 to 2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int transferMode1inMode2() throws DataNotValidException {
		try {
			GroupStatistic[] arrGroupStatistic = fetchWithMode1();
			int i=0;
			for (GroupStatistic grStat:arrGroupStatistic) {
				GroupStatisticPK pK = new GroupStatisticPK();
				GroupStatistic groupStatistic = new GroupStatistic();
				pK.setInstrId1(grStat.getPk().getInstrId1());
				pK.setInstrId2(grStat.getPk().getInstrId2());
				pK.setNDaysPer(grStat.getPk().getNDaysPer());
				pK.setNv(grStat.getPk().getNv());
				pK.setSetId(grStat.getPk().getSetId());
				pK.setVarType(grStat.getPk().getVarType());
				pK.setMode(2);
				groupStatistic.setPk(pK);
				groupStatistic.setActive(grStat.getActive());
				groupStatistic.setCorrel(grStat.getCorrel());
				groupStatistic.setPearson(grStat.getPearson());
				groupStatistic.setDivundiv(grStat.getDivundiv());
				groupStatistic.setSlope(grStat.getSlope());
				groupStatistic.setRelperf(grStat.getRelPerf());
				groupStatistic.setTrackerr(grStat.getTrackerr());
				groupStatistic.setHistdays(grStat.getHistdays());
				groupStatistic.setStatus(grStat.getStatus());
				store(groupStatistic);
				i++;
			}
			log.debug(i+" Group Statistics transferred from mode 1 to 2");
			return i;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring Group Statistics from mode 1 to 2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
}

