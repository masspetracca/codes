package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.StraddleActivationDefault;
import it.ccg.pamp.server.entities.StraddleActivationDefaultPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StraddleActivationDefaultEAO
 */
@Stateless
public class StraddleActivationDefaultEAO implements  StraddleActivationDefaultEAOLocal {
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public StraddleActivationDefault[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllStrAct");
    		List<StraddleActivationDefault> straddleActivationDefault = query.getResultList();
    		StraddleActivationDefault[] arrStraddleActivationDefault = new StraddleActivationDefault[straddleActivationDefault.size()];
    		return straddleActivationDefault.toArray(arrStraddleActivationDefault);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Straddle - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public StraddleActivationDefault findByPrimaryKey(int nDaysPer, int nv) throws DataNotValidException {
		try {
			StraddleActivationDefaultPK pK = new StraddleActivationDefaultPK();
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			StraddleActivationDefault straddleActivationDefault = (StraddleActivationDefault) em.find(StraddleActivationDefault.class,pK);
    		return straddleActivationDefault;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Set Parameter - nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActiveDelta() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getActiveDeltaForStrAct");
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active delta for Set Parameters - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActivePeriods(int nv) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getActivePeriodsForStrAct");
    		query.setParameter("nv", nv);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active periods for Straddle - holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getEnabledPeriods(int nv) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledPeriodsForStrAct");
    		query.setParameter("nv", nv);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled periods for Set Parameters - holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int nDaysPer, int nv, String status) throws DataNotValidException {
		try {
			StraddleActivationDefault straddleActivationDefault = new StraddleActivationDefault();
			StraddleActivationDefaultPK pK = new StraddleActivationDefaultPK();
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			straddleActivationDefault.setPk(pK);
			straddleActivationDefault.setStatus(status);
			straddleActivationDefault.setUpdType(updType);
			straddleActivationDefault.setUpdDate(GenericTools.systemDate());
			straddleActivationDefault.setUpdUsr(userString());
			em.persist(straddleActivationDefault);
			log.debug("Added new Straddle Activation Default - nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Straddle Activation Default - nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(StraddleActivationDefault straddleActivationDefault) throws DataNotValidException {
		try {
			straddleActivationDefault.setUpdType(updType);
			straddleActivationDefault.setUpdDate(GenericTools.systemDate());
			straddleActivationDefault.setUpdUsr(userString());
			em.persist(straddleActivationDefault);
			log.debug("Added new Straddle Activation Default - nDaysPer: "+straddleActivationDefault.getPk().getNDaysPer()+"; holding period: "+straddleActivationDefault.getPk().getNv());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Straddle Activation Default - nDaysPer: "+straddleActivationDefault.getPk().getNDaysPer()+"; holding period: "+straddleActivationDefault.getPk().getNv()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int nDaysPer, int nv, String status) throws DataNotValidException {
		try {
			StraddleActivationDefault straddleActivationDefault = findByPrimaryKey(nDaysPer, nv);
			straddleActivationDefault.setStatus(status);
			straddleActivationDefault.setUpdType("U");
			straddleActivationDefault.setUpdDate(GenericTools.systemDate());
			straddleActivationDefault.setUpdUsr(userString());
			log.debug("Straddle Activation Default updated - nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error updating Straddle Activation Default - nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	public void remove(int nDaysPer, int nv) throws DataNotValidException {
		try {
			StraddleActivationDefault straddleActivationDefault = findByPrimaryKey(nDaysPer, nv);
			em.remove(straddleActivationDefault);
			log.debug("Straddle Activation Default - nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing new Straddle Activation Default - nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
		
	public void remove(StraddleActivationDefault straddleActivationDefault) throws DataNotValidException {
		remove(straddleActivationDefault.getPk().getNDaysPer(), straddleActivationDefault.getPk().getNv());
	}

}
