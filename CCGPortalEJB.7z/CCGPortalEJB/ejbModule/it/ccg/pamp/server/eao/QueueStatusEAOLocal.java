package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.QueueStatus;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface QueueStatusEAOLocal {
	public QueueStatus[] fetch() throws DataNotValidException;
	public QueueStatus[] getRunningBatchs() throws DataNotValidException; 
	public QueueStatus findByPrimaryKey(int id) throws DataNotValidException;
	public void add(int id, String status) throws DataNotValidException;
	public void store(QueueStatus queueStatus) throws DataNotValidException;
	public void update(int id, String status) throws DataNotValidException;
	public void upsert(int id, String status) throws DataNotValidException;
	public void updateToRunning(int id,int running) throws DataNotValidException;
	public void remove(int id) throws DataNotValidException;
	public void remove(QueueStatus queueStatus) throws DataNotValidException;
}
