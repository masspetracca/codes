package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ClassHaircut;
import it.ccg.pamp.server.entities.ClassHaircutHistory;
import it.ccg.pamp.server.entities.ClassHaircutHistoryPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class HaircutClassHistory
 */
@Stateless
public class ClassHaircutHistoryEAO implements ClassHaircutHistoryEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public List<ClassHaircutHistory> fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllClassHaircutHistory");
    		List<ClassHaircutHistory> classHaircutHistoryList = query.getResultList();
    		return classHaircutHistoryList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching all haircut class history - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ClassHaircutHistory findByPrimaryKey(int classId, Timestamp iniVDate) throws DataNotValidException {
		try {
			ClassHaircutHistoryPK pK = new ClassHaircutHistoryPK();
			
			pK.setClassId(classId);
			pK.setIniVDate(iniVDate);
			
			ClassHaircutHistory classHaircutHistory = (ClassHaircutHistory) em.find(ClassHaircutHistory.class,pK);
    		return classHaircutHistory;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching haircut class history - classId: "+classId+"; initial valid date: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ClassHaircutHistory getCurrentHaircut(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCurrentClassHaircut");
    		query.setParameter("classId", classId);
    		query.setParameter("systemDate", GenericTools.systemDate());
    		query.setMaxResults(1);
    		List<ClassHaircutHistory> haircutHistoryList = query.getResultList();
    		if (haircutHistoryList.size()>0) {
    			return haircutHistoryList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching current haircut - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int classId,Timestamp iniVDate,BigDecimal anCap,Timestamp anDate,BigDecimal anFloor,BigDecimal anHct,BigDecimal anMult,
		String anNodes,BigDecimal anRlHct,Timestamp apprDate,String approvedBy,String comment, Timestamp endVDate,BigDecimal hct,String log,
		int rcCode,Timestamp sendDate,String sent,String susp, BigDecimal anAddend) throws DataNotValidException {
		
		String logString = "classID: "+classId+"; initial valid date: "+iniVDate;
		
		try {
			ClassHaircutHistory classHaircutHistory = new ClassHaircutHistory();
			
			ClassHaircutHistoryPK pK = new ClassHaircutHistoryPK();
			
			pK.setClassId(classId);
			pK.setIniVDate(iniVDate);
			
			classHaircutHistory.setPk(pK);
			
			classHaircutHistory.setAnCap(anCap);
			classHaircutHistory.setAnDate(anDate);
			classHaircutHistory.setAnFloor(anFloor);
			classHaircutHistory.setAnHct(anHct);
			classHaircutHistory.setAnMult(anMult);
			classHaircutHistory.setAnNodes(anNodes);
			classHaircutHistory.setAnRlHct(anRlHct);
			
			classHaircutHistory.setApprDate(apprDate);
			classHaircutHistory.setApprovedBy(approvedBy);
			classHaircutHistory.setComment(comment);
			
			classHaircutHistory.setEndVDate(endVDate);
			
			classHaircutHistory.setHct(hct);
			classHaircutHistory.setLog(log);
						
			classHaircutHistory.setRcCode(rcCode);
			
			classHaircutHistory.setSendDate(sendDate);
			classHaircutHistory.setSent(sent);
			classHaircutHistory.setSusp(susp);
			classHaircutHistory.setAnAddend(anAddend);

			
			classHaircutHistory.setUpdDate(GenericTools.systemDate());
			classHaircutHistory.setUpdType(updType);
			classHaircutHistory.setUpdUsr(userString());
			
			em.persist(classHaircutHistory);
			userLog.debug("Added new haircut class history: "+logString);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new haircut class history - "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int classId,Timestamp iniVDate,BigDecimal anCap,Timestamp anDate,BigDecimal anFloor,BigDecimal anHct,BigDecimal anMult,
			String anNodes,BigDecimal anRlHct,Timestamp apprDate,String approvedBy,String comment, Timestamp endVDate,BigDecimal hct,String log,
			int rcCode,Timestamp sendDate,String sent,String susp, BigDecimal anAddend) throws DataNotValidException {
			
		String logString = "classID: "+classId+"; initial valid date: "+iniVDate;
		
		try {
			ClassHaircutHistory classHaircutHistory = this.findByPrimaryKey(classId,iniVDate);
			
			classHaircutHistory.setAnCap(anCap);
			classHaircutHistory.setAnDate(anDate);
			classHaircutHistory.setAnFloor(anFloor);
			classHaircutHistory.setAnHct(anHct);
			classHaircutHistory.setAnMult(anMult);
			classHaircutHistory.setAnNodes(anNodes);
			classHaircutHistory.setAnRlHct(anRlHct);
			
			classHaircutHistory.setApprDate(apprDate);
			classHaircutHistory.setApprovedBy(approvedBy);
			classHaircutHistory.setComment(comment);
			
			classHaircutHistory.setEndVDate(endVDate);
			
			classHaircutHistory.setHct(hct);
			classHaircutHistory.setLog(log);
						
			classHaircutHistory.setRcCode(rcCode);
			
			classHaircutHistory.setSendDate(sendDate);
			classHaircutHistory.setSent(sent);
			classHaircutHistory.setSusp(susp);
			
			classHaircutHistory.setUpdDate(GenericTools.systemDate());
			classHaircutHistory.setUpdType("U");
			classHaircutHistory.setUpdUsr(userString());
			classHaircutHistory.setAnAddend(anAddend);
			
			userLog.debug("Haircut class history updated: "+logString);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating haircut class history - "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(ClassHaircutHistory classHaircutHistory) throws DataNotValidException {
			
		String logString = "classID: "+classHaircutHistory.getPk().getClassId()+"; initial valid date: "+classHaircutHistory.getPk().getIniVDate();
		
		try {
						
			classHaircutHistory.setUpdDate(GenericTools.systemDate());
			classHaircutHistory.setUpdType(updType);
			classHaircutHistory.setUpdUsr(userString());
			
			em.persist(classHaircutHistory);
			userLog.debug("Added new haircut class history: "+logString);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new haircut class history - "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(ClassHaircut classHaircut) throws DataNotValidException {
		ClassHaircutHistory classHaircutHistory = new ClassHaircutHistory();
		ClassHaircutHistoryPK classHaircutHisPK = new ClassHaircutHistoryPK();
		
		classHaircutHisPK.setIniVDate(classHaircut.getIniVDate());
		classHaircutHisPK.setClassId(classHaircut.getClassId());
		classHaircutHistory.setPk(classHaircutHisPK);
		
		classHaircutHistory.setAnCap(classHaircut.getAnCap());
		classHaircutHistory.setAnDate(classHaircut.getAnDate());
		classHaircutHistory.setAnFloor(classHaircut.getAnFloor());
		classHaircutHistory.setAnHct(classHaircut.getAnHct());
		classHaircutHistory.setAnMult(classHaircut.getAnMult());
		classHaircutHistory.setAnAddend(classHaircut.getAnAddend());
		classHaircutHistory.setAnNodes(classHaircut.getAnNodes());
		classHaircutHistory.setAnRlHct(classHaircut.getAnRlHct());
		
		classHaircutHistory.setApprDate(GenericTools.systemDate());
		classHaircutHistory.setApprovedBy(userString());
		classHaircutHistory.setComment(classHaircut.getComment());
		
		classHaircutHistory.setEndVDate(classHaircut.getEndVDate());
		
		
		classHaircutHistory.setHct(classHaircut.getPropHct());
		
		
		classHaircutHistory.setRcCode(classHaircut.getRcCode());
		
		classHaircutHistory.setSendDate(classHaircut.getSendDate());
		classHaircutHistory.setSent("F");
		classHaircutHistory.setSusp(classHaircut.getSusp());
		
		
		classHaircutHistory.setLog(classHaircut.getPropLog());
		
		classHaircutHistory.setUpdDate(GenericTools.systemDate());
		classHaircutHistory.setUpdType(updType);
		classHaircutHistory.setUpdUsr(userString());
		
		
		this.store(classHaircutHistory);
	}
	
	public void remove(int classId, Timestamp iniVDate) throws DataNotValidException {
		
		String logString = "classID: "+classId+"; initial valid date: "+iniVDate;
		
		try {
			ClassHaircutHistory classHaircutHistory = this.findByPrimaryKey(classId,iniVDate);
			
			em.remove(classHaircutHistory);
			
			userLog.debug("Haircut class removed: "+logString);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing new haircut class - "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(ClassHaircutHistory classHaircutHistory) throws DataNotValidException {
		
		this.remove(classHaircutHistory.getPk().getClassId(),classHaircutHistory.getPk().getIniVDate());
	}

}
