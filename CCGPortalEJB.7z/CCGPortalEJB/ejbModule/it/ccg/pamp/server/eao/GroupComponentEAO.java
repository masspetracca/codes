package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.GroupComponent;
import it.ccg.pamp.server.entities.GroupComponentPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class GroupComponentEAO
 */
@Stateless//groupComp
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class GroupComponentEAO implements  GroupComponentEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public GroupComponent[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllGroupComp");
    		List<GroupComponent> groupComponent = query.getResultList();
    		GroupComponent[] arrGroupComponent = new GroupComponent[groupComponent.size()];
    		return groupComponent.toArray(arrGroupComponent);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Components - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupComponent[] findByGroupId(int grId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getGroupCompByGroupId");
    		query.setParameter("grId", grId);
    		List<GroupComponent> groupComponent = query.getResultList();
    		GroupComponent[] arrGroupComponent = new GroupComponent[groupComponent.size()];
    		return groupComponent.toArray(arrGroupComponent);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Components - groupId: "+grId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupComponent findByPrimaryKey(int grId, int instrId) throws DataNotValidException {
		try {
			GroupComponentPK pK = new GroupComponentPK();
			pK.setGrId(grId);
			pK.setInstrId(instrId);
			GroupComponent groupComponent = (GroupComponent) em.find(GroupComponent.class,pK);
    		return groupComponent;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Component - groupId: "+grId+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public boolean existsGroupByInstrIdList(Set<Integer> instrIdList) throws DataNotValidException {
		Query query = null;
		String subquery = "";

		for (int i:instrIdList) {
			subquery += i+",";
		}
		
		try {
			boolean found = false;
			query = em.createNamedQuery("getGroupByInstrIdList");
			query.setParameter("subquery", instrIdList);
			List<Long> groupComponent = query.getResultList();
			for (Long grIdList:groupComponent) {
				if (grIdList.intValue()==instrIdList.size()) {
					found = true;
					break;
				}
			}
			return found;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Component - arrInstrId: "+subquery.substring(0,subquery.length()-1)+" - "+e.getMessage()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public boolean existsGroupByInstrIdListNotPseudo(Set<Integer> instrIdList) throws DataNotValidException {
		Query query = null;
		String subquery = "";

		for (int i:instrIdList) {
			subquery += i+",";
		}
		
		try {
			boolean found = false;
			query = em.createNamedQuery("getGroupByInstrIdListNotPseudo");
			query.setParameter("subquery", instrIdList);
			List<Long> groupComponent = query.getResultList();
			for (Long grIdList:groupComponent) {
				if (grIdList.intValue()==instrIdList.size()) {
					found = true;
					break;
				}
			}
			return found;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Component - arrInstrId: "+subquery.substring(0,subquery.length()-1)+" - "+e.getMessage()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int grId,int instrId) throws DataNotValidException {
		try {
			GroupComponent groupComponent = new GroupComponent();
			GroupComponentPK pK = new GroupComponentPK();
			pK.setGrId(grId);
			pK.setInstrId(instrId);
			groupComponent.setPk(pK);
			groupComponent.setUpdDate(GenericTools.systemDate());
			groupComponent.setUpdType(updType);
			groupComponent.setUpdUsr(userString());
			em.persist(groupComponent);
			log.debug("Added new Group Component - groupId: "+grId+"; instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Group Component - groupId: "+grId+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(GroupComponent groupComponent) throws DataNotValidException {
		try {
			groupComponent.setUpdDate(GenericTools.systemDate());
			groupComponent.setUpdType(updType);
			groupComponent.setUpdUsr(userString());
			em.persist(groupComponent);
			log.debug("Added new Group Component - groupId: "+groupComponent.getPk().getGrId()+"; instrId: "+groupComponent.getPk().getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Group Component - groupId: "+groupComponent.getPk().getGrId()+"; instrId: "+groupComponent.getPk().getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int update(int grId,int instrId) throws DataNotValidException {
		try {
			GroupComponent groupComponent = findByPrimaryKey(0,instrId);
			int result = 0;
			if (groupComponent!=null) {
				Query query = null;
				query = em.createNamedQuery("updateGroupCompByInstrId");
				query.setParameter("instrId", instrId);
				query.setParameter("grId", grId);
				query.setParameter("updType", "U");
				query.setParameter("updDate", GenericTools.systemDate());
				query.setParameter("updUsr", userString());
				result = query.executeUpdate();
			}
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Group Component - groupId: "+grId+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int grId,int instrId) throws DataNotValidException {
		try {
			GroupComponent groupComponent = findByPrimaryKey(grId, instrId);
			em.remove(groupComponent);
			log.debug("Group Component removed - groupId: "+grId+"; instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Group Component - groupId: "+grId+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByGrId(int grId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteGroupCompByGrId");
			query.setParameter("grId", grId);
			int result = query.executeUpdate();
			log.debug(result+" Group Component removed - groupId: "+grId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Group Component  - groupId: "+grId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	 
	public int removeByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteGroupCompByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Group Component removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Group Component  - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(GroupComponent groupComponent) throws DataNotValidException {
		remove(groupComponent.getPk().getGrId(),groupComponent.getPk().getInstrId());
	}
}
