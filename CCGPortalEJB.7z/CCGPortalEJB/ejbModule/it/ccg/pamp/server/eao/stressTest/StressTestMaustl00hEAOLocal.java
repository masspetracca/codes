package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestMaustl00h;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface StressTestMaustl00hEAOLocal {
	
	public List<StressTestMaustl00h> fetch() throws DataNotValidException;
	
	public StressTestMaustl00h findByPrimaryKey (int memberId, Timestamp ctrDate, Timestamp settlDate, String account, String subAccount, String isinCode) throws DataNotValidException;
}
