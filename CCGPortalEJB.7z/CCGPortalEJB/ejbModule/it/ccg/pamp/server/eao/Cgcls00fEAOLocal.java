package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Cgcls00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.ClassTableChecks;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;
import javax.persistence.Query;

@Local
public interface Cgcls00fEAOLocal {
	public Cgcls00f[] fetch() throws DataNotValidException;
	
	public Cgcls00f[] getCGCNotinMarHis() throws DataNotValidException;
	
	public Cgcls00f[] findByCofCod(String cofCod) throws DataNotValidException;
	
	public List<Cgcls00f> findByCofCod(List<String> cofCodList) throws DataNotValidException;
	
	public Cgcls00f[] findOeKbCashByClassAndLastDate(String cClass, long lastDate) throws DataNotValidException;
	
	public List<Cgcls00f> getCgcls00fForSync() throws DataNotValidException;
	
	public List<Cgcls00f> reCgcList() throws DataNotValidException;
	
	public BigDecimal getPriceSum() throws DataNotValidException;
	
	public ClassTableChecks getInfoToCheck() throws DataNotValidException;
	
	public Cgcls00f getREInstrumentsForOeKBMarginExport(String cClass/*, String cpType*/) throws DataNotValidException;
	
	public Cgcls00f[] findByCClass(String cClass) throws DataNotValidException;
	
	public BigDecimal getMaxChangeDate() throws DataNotValidException;
	
	public Cgcls00f findByPrimaryKey(String cClass, String cofCod) throws DataNotValidException;
	
	public void update(String cClass, String cofCod, BigDecimal propMar, BigDecimal propMinMar) throws DataNotValidException;
	
	public void update(String cClass, String cofCod, BigDecimal propMar) throws DataNotValidException;
	
	public void updateCashMinMar(String cClass, String cofCod, BigDecimal propMinMar) throws DataNotValidException;
}	
