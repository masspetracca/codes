package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.AnalysisRegister;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class AnalysisRegisterEAO
 */
@Stateless
public class AnalysisRegisterEAO implements  AnalysisRegisterEAOLocal {

	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	
	
	public AnalysisRegister[] fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllAnReg");
    		List<AnalysisRegister> analysisRegister = query.getResultList();
    		AnalysisRegister[] arrAnalysisRegister = new AnalysisRegister[analysisRegister.size()];
    		return analysisRegister.toArray(arrAnalysisRegister);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Analysis - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public AnalysisRegister findByPrimaryKey(int anCode) throws DataNotValidException {
		try {
			AnalysisRegister analysisRegister = (AnalysisRegister) em.find(AnalysisRegister.class,anCode);
    		return analysisRegister;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Analysis - anCode: "+anCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public AnalysisRegister findLastAnalysis() throws DataNotValidException {
		try {
			AnalysisRegister[] analysisRegister = fetch();
    		return analysisRegister[0];
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last analysis - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(Timestamp anDate, String comment) throws DataNotValidException {
		try {
			AnalysisRegister analysisRegister = new AnalysisRegister();
			analysisRegister.setAnDate(anDate);
			analysisRegister.setComment(comment);
			analysisRegister.setUpdDate(GenericTools.systemDate());
			analysisRegister.setUpdType(updType);
			analysisRegister.setUpdUsr(userString());
			em.persist(analysisRegister);
			log.debug("Added new Analysis - anDate: "+anDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Analysis - anDate: "+anDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(AnalysisRegister analysisRegister) throws DataNotValidException {
		try {
			analysisRegister.setUpdDate(GenericTools.systemDate());
			analysisRegister.setUpdType(updType);
			analysisRegister.setUpdUsr(userString());
			em.persist(analysisRegister);
			log.debug("Added new Analysis - anDate: "+analysisRegister.getAnDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Analysis - anDate: "+analysisRegister.getAnDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int anCode, Timestamp anDate, String comment) throws DataNotValidException {
		try {
			AnalysisRegister analysisRegister = findByPrimaryKey(anCode);
			analysisRegister.setAnDate(anDate);
			analysisRegister.setComment(comment);
			analysisRegister.setUpdDate(GenericTools.systemDate());
			analysisRegister.setUpdType("U");
			analysisRegister.setUpdUsr(userString());
			log.debug("Updated Analysis "+anCode+" - anDate: "+anDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Analysis - anCode: "+anCode+"; anDate: "+anDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(AnalysisRegister analysisRegister) throws DataNotValidException {
		try {
			AnalysisRegister anRegister = findByPrimaryKey(analysisRegister.getAnCode());
			anRegister.setUpdDate(GenericTools.systemDate());
			anRegister.setUpdType("U");
			anRegister.setUpdUsr(userString());
			log.debug("Updated Analysis "+analysisRegister.getAnCode()+" - anDate: "+analysisRegister.getAnDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Analysis - anCode: "+analysisRegister.getAnCode()+"; anDate: "+analysisRegister.getAnDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int anCode) throws DataNotValidException {
		try {
			AnalysisRegister analysisRegister = findByPrimaryKey(anCode);
			em.remove(analysisRegister);
			log.debug("Removed Analysis "+anCode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Analysis - anCode: "+anCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(AnalysisRegister analysisRegister) throws DataNotValidException {
		remove(analysisRegister.getAnCode());
	}
}
