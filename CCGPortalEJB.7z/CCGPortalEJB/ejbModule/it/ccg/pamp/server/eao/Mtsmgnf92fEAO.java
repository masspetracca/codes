package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Mtsmgnf92fPK;
import it.ccg.pamp.server.entities.Mtsmgnf92f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class Mtsmgnf92fEAO
 */
@Stateless
public class Mtsmgnf92fEAO implements  Mtsmgnf92fEAOLocal {

	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<Mtsmgnf92f> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllMtsmgnf92f");
    		List<Mtsmgnf92f> mtsmgnf92fList = query.getResultList();
    		return mtsmgnf92fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsmgnf92f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Mtsmgnf92f> getMtsmgnf92fNotinClMarHis() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMtsmgnf92fNotinClMarHis");
    		query.setParameter("systemDate", GenericTools.systemDate());
    		List<Mtsmgnf92f> mtsmgnf92fList = query.getResultList();
    		return mtsmgnf92fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsmgnf92f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Mtsmgnf92f findByPrimaryKey(String f92cdclas1, String f92cdclas2) throws DataNotValidException {
		try {
			Mtsmgnf92fPK pK = new Mtsmgnf92fPK();
			pK.setF92cdclas1(f92cdclas1);			
			pK.setF92cdclas2(f92cdclas2);
			Mtsmgnf92f mtsmgnf92f = (Mtsmgnf92f) em.find(Mtsmgnf92f.class,pK);
    		return mtsmgnf92f;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsmgnf92f - f92cdclas1: "+f92cdclas1+"; f92cdclas2: "+f92cdclas2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public void update(String f92cdclas1, String f92cdclas2, BigDecimal f92intridp) throws DataNotValidException {
		try {
			Mtsmgnf92f mtsmgnf92f = findByPrimaryKey(f92cdclas1, f92cdclas2);
			mtsmgnf92f.setF92intridp(f92intridp);
			log.debug("Mtsmgnf92f updated - f92cdclas1: "+f92cdclas1+"; f92cdclas2: "+f92cdclas2+"; new offset: "+f92intridp);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Mtsmgnf92f - f92cdclas1: "+f92cdclas1+"; f92cdclas2: "+f92cdclas2+"; f92intridp: "+f92intridp+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
