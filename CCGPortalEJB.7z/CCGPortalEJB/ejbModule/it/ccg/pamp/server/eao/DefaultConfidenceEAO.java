package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.DefaultConfidence;
import it.ccg.pamp.server.entities.DefaultConfidencePK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class DefaultConfidenceEAO
 */
@Stateless
public class DefaultConfidenceEAO implements  DefaultConfidenceEAOLocal {
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	
	@SuppressWarnings("unchecked")
	public DefaultConfidence[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllDefConf");
    		List<DefaultConfidence> defaultConfidence = query.getResultList();
    		DefaultConfidence[] arrDefaultConfidence = new DefaultConfidence[defaultConfidence.size()];
    		return defaultConfidence.toArray(arrDefaultConfidence);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching default confidences - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActiveDelta(String instrType) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDefConfActiveDelta");
    		query.setParameter("instrType", instrType);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active delta for default confidences - instrType: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActivePeriods(String instrType, int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDefConfActivePeriods");
    		query.setParameter("instrType", instrType);
    		query.setParameter("delta", delta);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active periods for default confidences - instrType: "+instrType+"; delta: "+delta+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getEnabledPeriods(String instrType, int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDefConfEnabledPeriods");
    		query.setParameter("instrType", instrType);
    		query.setParameter("delta", delta);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled periods for default confidences - instrType: "+instrType+"; delta: "+delta+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DefaultConfidence[] findByInstrType(String instrType) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDefConfByInstrType");
    		query.setParameter("instrType", instrType);
    		List<DefaultConfidence> defaultConfidence = query.getResultList();
    		DefaultConfidence[] arrDefaultConfidence = new DefaultConfidence[defaultConfidence.size()];
    		return defaultConfidence.toArray(arrDefaultConfidence);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching default Confidences - instrType: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DefaultConfidence findByPrimaryKey(String instrType, int nDaysPer, int nv) throws DataNotValidException {
		try {
			DefaultConfidencePK pK = new DefaultConfidencePK();
			pK.setInstrType(instrType);
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			DefaultConfidence defaultConfidence = em.find(DefaultConfidence.class,pK);
    		return defaultConfidence;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching default confidence - instrType: "+instrType+"; nDaysPer: "+nDaysPer+"; holding period:"+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(String instrType, int nDaysPer, int nv, BigDecimal confidDf) throws DataNotValidException {
		try {
			DefaultConfidence defaultConfidence = new DefaultConfidence();
			DefaultConfidencePK pK = new DefaultConfidencePK();
			pK.setInstrType(instrType);
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			defaultConfidence.setPk(pK);
			defaultConfidence.setConfidDf(confidDf);
			defaultConfidence.setUpdType(updType);
			defaultConfidence.setUpdDate(GenericTools.systemDate());
			defaultConfidence.setUpdUsr(userString());
			em.persist(defaultConfidence);
			log.debug("Added new Default Confidence - instrType: "+instrType+"; nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new default Confidence - instrType: "+instrType+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(DefaultConfidence defaultConfidence) throws DataNotValidException {
		try {
			defaultConfidence.setUpdType(updType);
			defaultConfidence.setUpdDate(GenericTools.systemDate());
			defaultConfidence.setUpdUsr(userString());
			em.persist(defaultConfidence);
			log.debug("Added new Default Confidence - instrType: "+defaultConfidence.getPk().getInstrType()+"; nDaysPer: "+defaultConfidence.getPk().getNDaysPer()+"; holding period: "+defaultConfidence.getPk().getNv());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new default Confidence - instrType: "+defaultConfidence.getPk().getInstrType()+"; nDaysPer: "+defaultConfidence.getPk().getNDaysPer()+"; holding period: "+defaultConfidence.getPk().getNv()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(String instrType, int nDaysPer, int nv, BigDecimal confidDf) throws DataNotValidException {
		try {
			DefaultConfidence defaultConfidence = findByPrimaryKey(instrType,nDaysPer, nv);
			defaultConfidence.setConfidDf(confidDf);
			defaultConfidence.setUpdType("U");
			defaultConfidence.setUpdDate(GenericTools.systemDate());
			defaultConfidence.setUpdUsr(userString());
			log.debug("Updated Default Confidence - instrType: "+instrType+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+"; confDef: "+confidDf);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating default Confidence - instrType: "+instrType+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(DefaultConfidence defConfidence) throws DataNotValidException {
		try {
			DefaultConfidence defaultConfidence = findByPrimaryKey(defConfidence.getPk().getInstrType(),defConfidence.getPk().getNDaysPer(),defConfidence.getPk().getNv());
			defaultConfidence.setUpdType("U");
			defaultConfidence.setUpdDate(GenericTools.systemDate());
			defaultConfidence.setUpdUsr(userString());
			log.debug("Updated Default Confidence - instrType: "+defaultConfidence.getPk().getInstrType()+"; nDaysPer: "+defaultConfidence.getPk().getNDaysPer()+"; holding period: "+defaultConfidence.getPk().getNv()+"; confDef: "+defaultConfidence.getConfidDf());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error updating default Confidence - instrType: "+defConfidence.getPk().getInstrType()+"; nDaysPer: "+defConfidence.getPk().getNDaysPer()+"; holding period: "+defConfidence.getPk().getNv()+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	public void remove(String instrType, int nDaysPer, int nv) throws DataNotValidException {
		try {
			DefaultConfidence defaultConfidence = findByPrimaryKey(instrType,nDaysPer, nv);
			em.remove(defaultConfidence);
			log.debug("Removed Default Confidence - instrType: "+instrType+"; nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing default Confidence - instrType: "+instrType+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(DefaultConfidence defaultConfidence) throws DataNotValidException {
		remove(defaultConfidence.getPk().getInstrType(),defaultConfidence.getPk().getNDaysPer(),defaultConfidence.getPk().getNv());
	}
	
	public int removeByInstrType(String instrType) {
		Query query = null;
		query = em.createNamedQuery("deleteDefConfByInstrType");
		query.setParameter("instrType", instrType);
		int result = query.executeUpdate();
		return result;
	}
	
}
