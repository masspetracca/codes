package it.ccg.pamp.server.eao;
import java.util.LinkedHashMap;

import it.ccg.pamp.server.entities.User;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface UserEAOLocal {
	public User[] fetch() throws DataNotValidException;
	public User findByPrimaryKey(String userName) throws DataNotValidException;
	public User findOrCreateByPrimaryKey(String userName) throws DataNotValidException;
	public String getUserFullName(String userName) throws DataNotValidException;
	public void add(String userName, String name, String surName, String phoneNumb, String email, String notify, String userDesc) throws DataNotValidException; 
	public void createDefaultUser(String userName) throws DataNotValidException;
	public void store(User user) throws DataNotValidException;
	public void updateUserNotifyToTrue(String userName) throws DataNotValidException;
	public void updateUserNotifyToFalse(String userName) throws DataNotValidException;
	public LinkedHashMap<String,String> findUserInfoMap(String userName) throws DataNotValidException;
	public void update(String userName, String name, String surName, String phoneNumb, String email, String notify, String userDesc) throws DataNotValidException;
	public void update(User user) throws DataNotValidException;
	public void updateUserFromWeb(LinkedHashMap<String,String> userValueMap, String userName) throws DataNotValidException;
	public void remove(String userName) throws DataNotValidException;
	public void remove(User user) throws DataNotValidException;
}
