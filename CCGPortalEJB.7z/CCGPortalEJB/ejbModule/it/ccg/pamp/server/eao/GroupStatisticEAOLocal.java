package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.GroupStatistic;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GroupStatisticGroupedBy;

import java.math.BigDecimal;

import javax.ejb.Local;

@Local
public interface GroupStatisticEAOLocal {
	public GroupStatistic[] fetch() throws DataNotValidException;
	public GroupStatistic findByPrimaryKey(int instrId1, int instrId2, int nDaysPer, int nv, String varType, int mode, int setId) throws DataNotValidException;
	public GroupStatistic[] findByInstrId(int instrId) throws DataNotValidException;
	public GroupStatistic[] findBySetId(int setId) throws DataNotValidException;
	public GroupStatistic[] fetchWithMode1() throws DataNotValidException;
	public GroupStatisticGroupedBy[] getEnabledMinCorrel(BigDecimal threshold, String corrType, int setId) throws DataNotValidException;
	public Integer[] getDistinctInstrId1() throws DataNotValidException;
	public GroupStatistic[] findByInstrIdEither(int instrId1,int instrId2) throws DataNotValidException;
	
	public void add(int instrId1, int instrId2, int nDaysPer, int nv, String varType, int mode, int setId, int active, BigDecimal correl,
			BigDecimal pearson, BigDecimal divundiv, BigDecimal slope, BigDecimal relPerf, BigDecimal trackerr, int histDays, String status,String divisCode) throws DataNotValidException;
	public void store(GroupStatistic groupStatistic) throws DataNotValidException;
	
	public void update(int instrId1, int instrId2, int nDaysPer, int nv, String varType, int mode, int setId, int active, BigDecimal correl, 
			BigDecimal pearson, BigDecimal divundiv, BigDecimal slope, BigDecimal relPerf, BigDecimal trackerr, int histDays, String status, String divisCode) throws DataNotValidException;
	public void update(GroupStatistic grStatistic) throws DataNotValidException;
	 
	public void remove(int instrId1, int instrId2, int nDaysPer, int nv, String varType, int mode, int setId) throws DataNotValidException;
	public int removeByInstrId(int instrId) throws DataNotValidException;
	public void remove(GroupStatistic groupStatistic) throws DataNotValidException;
	public int removeCurrentStatistics() throws DataNotValidException;
	public int removeCurrentStatisticsByDivisCode(String divisCode) throws DataNotValidException;
	public int removeStatisticBySetId(int setId, int mode) throws DataNotValidException;
	public int removeStatisticFromGroup() throws DataNotValidException;
	public int removeStatisticFromGroupByDivisCode(String divisCode) throws DataNotValidException;
	public int removeByMode(int mode) throws DataNotValidException;
	public int transferMode1inMode2() throws DataNotValidException;
	public void transferMode1To2() throws DataNotValidException;
}
