package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPricePK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.CurveNode;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StressTestHistPriceEAO
 */
@Stateless
@SuppressWarnings("unchecked")
public class StressTestHistPriceEAO implements  StressTestHistPriceEAOLocal {

	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	public List<StressTestHistPrice> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllStressTestHistPrices");
    		List<StressTestHistPrice> stressTestHistPriceList = query.getResultList();
    		return stressTestHistPriceList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stressed prices - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public StressTestHistPrice findByPrimaryKey(int instrId, String scenario, int stId) throws DataNotValidException {
		try {
			StressTestHistPricePK pK = new StressTestHistPricePK();
			pK.setInstrId(instrId);
			pK.setStId(stId);
			pK.setScenario(scenario);
			StressTestHistPrice stressTestHistPrice = (StressTestHistPrice) em.find(StressTestHistPrice.class,pK);
    		return stressTestHistPrice;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stressed prices - instrId: "+instrId+"; stress test id: "+stId+"; scenario: "+scenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestHistPrice> getStressTestHistPricesByStId(int stId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestHistPricesByStId");
    		query.setParameter("stId", stId);
    		List<StressTestHistPrice> stressTestHistPriceList = query.getResultList();
    		return stressTestHistPriceList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stressed prices - stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer getLastStressTestId(String scenario) throws DataNotValidException {
		String strScenario = "increase";
		
		if (scenario.equalsIgnoreCase("d")) {
			strScenario = "decrease";
		}
		
		Query query = null;
    	try {
    		query = em.createNamedQuery("getLastStressTestId");
    		query.setParameter("scenario", scenario);
    		List<Integer> lastStressTestId = query.getResultList();
    		if (lastStressTestId.size()>0) {
    			return lastStressTestId.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last stress test id - scenario: "+strScenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestHistPrice> getStressTestHistPricesByStIdAndScenario(int stId, String scenario) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestHistPricesByStIdAndScenario");
    		query.setParameter("stId", stId);
    		query.setParameter("scenario", scenario);
    		List<StressTestHistPrice> stressTestHistPriceList = query.getResultList();
    		return stressTestHistPriceList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stressed prices - stress test id: "+stId+"; scenario: "+scenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public StressTestHistPrice getStressTestHistPricesByInstrIdAndScenario(int instrId, String scenario) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestHistPricesByInstrIdAndScenario");
    		query.setParameter("instrId", instrId);
    		query.setParameter("scenario", scenario);
    		List<StressTestHistPrice> stressTestHistPriceList = query.getResultList();
    		if (stressTestHistPriceList.size()>0) {
    			return stressTestHistPriceList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stressed prices - instrId: "+instrId+"; scenario: "+scenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<CurveNode> getStressTestHistPricesByScenarioAndCurveArr(String scenario, String[] arrIrCurve, int stId) throws DataNotValidException {
		
		String strScenario = "Increasing";
		if (strScenario.equalsIgnoreCase("D")) {
			strScenario = "Decreasing";
		}
		
		String irCurveStr = "";
		
		for (String irCurve:arrIrCurve) {
			irCurveStr += "'"+irCurve+"',";
		}
		
		irCurveStr = irCurveStr.substring(0,irCurveStr.length()-1);
		
		Query query = null;
    	try {
    		String sqlString = "SELECT I.LISTNAME AS CURVENAME, I.INSTRID, STHP.CLOSEPR AS PRICE, STHP.CLOSEPRST AS STRESSEDPRICE, MD.MODDUR AS DURATION FROM PMPTSTHISP STHP ";
    		sqlString += "INNER JOIN PMPTINSTR I ON I.INSTRID = STHP.INSTRID AND I.LISTNAME IN ("+irCurveStr+") AND DIVISCODE = 'B' ";
    		sqlString += "INNER JOIN PMPTMODDUR MD ON MD.INSTRID  = STHP.INSTRID ";
    		sqlString += "WHERE STHP.SCENARIO = '"+scenario+"' AND STHP.STID = "+stId+" ";
    		sqlString += "ORDER BY I.LISTNAME,STHP.INSTRID";
    		
    		    		
    		query =  em.createNativeQuery(sqlString,CurveNode.class);
    		List<CurveNode> curveList = query.getResultList();
    		
    		return curveList;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stressed prices by scenario and irCurve - scenario: "+strScenario+"; curve list: "+irCurveStr+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	public List<StressTestHistPrice> getStressTestHistPriceToExport(int stId, String scenario) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestHistPriceToExport");
    		query.setParameter("stId", stId);
    		query.setParameter("scenario", scenario);
    		List<StressTestHistPrice> stressTestHistPriceList = query.getResultList();
    		return stressTestHistPriceList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stressed prices ready to export stress test id: "+stId+"; scenario: "+scenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, Timestamp priceDate, int stId, String scenario, BigDecimal closePr, BigDecimal closePrSt, String log, int nDaysPer, String sent, String status) throws DataNotValidException {
		
		try {
			StressTestHistPrice stressTestHistPrice = new StressTestHistPrice();
			StressTestHistPricePK pK = new StressTestHistPricePK();
			
			pK.setInstrId(instrId);
			pK.setStId(stId);
			pK.setScenario(scenario);
			
			
			stressTestHistPrice.setPk(pK);
			stressTestHistPrice.setPriceDate(priceDate);
			stressTestHistPrice.setClosePr(closePr);
			stressTestHistPrice.setClosePrSt(closePrSt);
			stressTestHistPrice.setLog(log);
			stressTestHistPrice.setNDaysPer(nDaysPer);
			stressTestHistPrice.setSent(sent);
			stressTestHistPrice.setStatus(status);
			
			stressTestHistPrice.setUpdType(updType);
			stressTestHistPrice.setUpdDate(GenericTools.systemDate());
			stressTestHistPrice.setUpdUsr(userString());
			
			em.persist(stressTestHistPrice);
			userLog.debug("Added new stressed price - instrId: "+instrId+"; priceDate: "+priceDate+"; stress test id: "+stId+"; scenario: "+scenario+"; price: "+closePr+"; stressed price: "+closePrSt);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stressed price - instrId: "+instrId+"; priceDate: "+priceDate+"; stress test id: "+stId+"; scenario: "+scenario+"; price: "+closePr+"; stressed price: "+closePrSt+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(StressTestHistPrice stressTestHistPrice) throws DataNotValidException {
		
		try {
			stressTestHistPrice.setUpdType(updType);
			stressTestHistPrice.setUpdDate(GenericTools.systemDate());
			stressTestHistPrice.setUpdUsr(userString());
			em.persist(stressTestHistPrice);
			userLog.debug("Added new stressed price - instrId: "+stressTestHistPrice.getPk().getInstrId()+"; priceDate: "+stressTestHistPrice.getPriceDate()+"; stress test id: "+stressTestHistPrice.getPk().getStId()+"; scenario: "+stressTestHistPrice.getPk().getScenario()+"; price: "+stressTestHistPrice.getClosePr()+"; stressed price: "+stressTestHistPrice.getClosePrSt());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stressed price - instrId: "+stressTestHistPrice.getPk().getInstrId()+"; priceDate: "+stressTestHistPrice.getPriceDate()+"; stress test id: "+stressTestHistPrice.getPk().getStId()+"; scenario: "+stressTestHistPrice.getPk().getScenario()+"; price: "+stressTestHistPrice.getClosePr()+"; stressed price: "+stressTestHistPrice.getClosePrSt()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, Timestamp priceDate, int stId, String scenario, BigDecimal closePr, BigDecimal closePrSt, String log, int nDaysPer, String sent, String status) throws DataNotValidException {
		
		try {
			StressTestHistPrice stressTestHistPrice = this.findByPrimaryKey(instrId, scenario, stId);
			
			stressTestHistPrice.setClosePr(closePr);
			stressTestHistPrice.setClosePrSt(closePrSt);
			stressTestHistPrice.setLog(log);
			stressTestHistPrice.setNDaysPer(nDaysPer);
			stressTestHistPrice.setSent(sent);
			stressTestHistPrice.setStatus(status);
			
			stressTestHistPrice.setUpdType("U");
			stressTestHistPrice.setUpdDate(GenericTools.systemDate());
			stressTestHistPrice.setUpdUsr(userString());
			
			em.persist(stressTestHistPrice);
			userLog.debug("Updated stressed price - instrId: "+instrId+"; priceDate: "+priceDate+"; stress test id: "+stId+"; scenario: "+scenario+"; price: "+closePr+"; stressed price: "+closePrSt);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stressed price - instrId: "+instrId+"; priceDate: "+priceDate+"; stress test id: "+stId+"; scenario: "+scenario+"; price: "+closePr+"; stressed price: "+closePrSt+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(StressTestHistPrice stressTestHistPrice) throws DataNotValidException {
		
		try {
			userLog.debug("Updated stressed price - instrId: "+stressTestHistPrice.getPk().getInstrId()+"; priceDate: "+stressTestHistPrice.getPriceDate()+"; stress test id: "+stressTestHistPrice.getPk().getStId()+"; scenario: "+stressTestHistPrice.getPk().getScenario()+"; price: "+stressTestHistPrice.getClosePr()+"; stressed price: "+stressTestHistPrice.getClosePrSt());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stressed price - instrId: "+stressTestHistPrice.getPk().getInstrId()+"; priceDate: "+stressTestHistPrice.getPriceDate()+"; stress test id: "+stressTestHistPrice.getPk().getStId()+"; scenario: "+stressTestHistPrice.getPk().getScenario()+"; price: "+stressTestHistPrice.getClosePr()+"; stressed price: "+stressTestHistPrice.getClosePrSt()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, Timestamp priceDate, int stId, String scenario) throws DataNotValidException {
		try {
			StressTestHistPrice stressTestHistPrice = this.findByPrimaryKey(instrId, scenario, stId);
			em.remove(stressTestHistPrice);
			userLog.debug("Stressed price removed - instrId: "+instrId+"; priceDate: "+priceDate+"; stress test id: "+stId+"; scenario: "+scenario);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stressed price - instrId: "+instrId+"; priceDate: "+priceDate+"; stress test id: "+stId+"; scenario: "+scenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteStressTestHistPricesByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			userLog.debug(result+" stressed historical prices removed - instrId: "+instrId);
			return result;
		 	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stressed historical prices - instrId: "+instrId+";  - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public String resetEqBoStSentStatus(int stId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("resetEqBoStSentStatus");
			query.setParameter("lastStId", stId);
			int result = query.executeUpdate();
			userLog.debug(result+" stressed historical prices sent status resetted - stId: "+stId);
			return result+" stressed historical prices sent status resetted - stId: "+stId;
		 	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error resetting stressed historical prices sent status - stId: "+stId+";  - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(StressTestHistPrice stressTestHistPrice) throws DataNotValidException {
		this.remove(stressTestHistPrice.getPk().getInstrId(), stressTestHistPrice.getPriceDate(), stressTestHistPrice.getPk().getStId(), stressTestHistPrice.getPk().getScenario());
	}
	

}
