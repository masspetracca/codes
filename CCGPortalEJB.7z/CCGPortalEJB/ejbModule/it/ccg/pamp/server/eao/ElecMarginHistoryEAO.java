package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ElecMargin;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.Margin;
import it.ccg.pamp.server.entities.ElecMarginHistory;
import it.ccg.pamp.server.entities.ElecMarginHistoryPK;
import it.ccg.pamp.server.entities.MinimumMargin;
import it.ccg.pamp.server.entities.Straddle;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ElecMarginHistoryEAO
 */
@Stateless
public class ElecMarginHistoryEAO implements  ElecMarginHistoryEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger logging = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public String userString = "System";
	public String updType = "C";
	
	public List<ElecMarginHistory> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllElecMarHis");
    		List<ElecMarginHistory> elecMarginList = query.getResultList();
    		return elecMarginList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives margin history - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public ElecMarginHistory findByPrimaryKey(int instrId, int month, Timestamp iniVDate) throws DataNotValidException {
		try {
			ElecMarginHistoryPK pK = new ElecMarginHistoryPK();
			pK.setInstrId(instrId);
			pK.setIniVDate(iniVDate);
			pK.setMonth(month);
			ElecMarginHistory elecMarginHistory = (ElecMarginHistory) em.find(ElecMarginHistory.class,pK);
    		return elecMarginHistory;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives margin history - instrId: "+instrId+"; month: "+month+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ElecMarginHistory> findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getElecMarHisByInstrId");
    		query.setParameter("instrId", instrId);
    		List<ElecMarginHistory> elecMarginList = query.getResultList();
    		return elecMarginList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives margin history - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ElecMarginHistory[] getMarHisToExport() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getElecMarHisToExport");
    		query.setParameter("systemDate", GenericTools.systemDate());
    		List<ElecMarginHistory> marginHistory = query.getResultList();
    		ElecMarginHistory[] arrMarginHistory = new ElecMarginHistory[marginHistory.size()];
    		return marginHistory.toArray(arrMarginHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Margin Histories to Export - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ElecMarginHistory[] getMarHisNotSync() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getElecMarHisNotSync");
    		List<ElecMarginHistory> marginHistory = query.getResultList();
    		ElecMarginHistory[] arrMarginHistory = new ElecMarginHistory[marginHistory.size()];
    		return marginHistory.toArray(arrMarginHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Margin Histories to Export - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ElecMarginHistory[] getMarHisNotInCGC() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getElecMarHisNotInCGC");
    		query.setParameter("systemDate", GenericTools.systemDate());
    		List<ElecMarginHistory> marginHistory = query.getResultList();
    		ElecMarginHistory[] arrMarginHistory = new ElecMarginHistory[marginHistory.size()];
    		return marginHistory.toArray(arrMarginHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Margin Histories to Export - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ElecMarginHistory getCurrentMargin(int instrId, int month) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getElecDerCurrentMargin");
    		query.setParameter("instrId", instrId);
    		query.setParameter("month", month);
    		query.setMaxResults(1);
    		List<ElecMarginHistory> elecMarginList = query.getResultList();
    		if (elecMarginList.size()>0) {
    			return elecMarginList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last electricity derivatives margin history - instrId: "+instrId+"; month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ElecMarginHistory getLastSentMargin(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getElecDerLastSentMargin");
    		query.setParameter("instrId", instrId);
    		query.setMaxResults(1);
    		List<ElecMarginHistory> elecMarginList = query.getResultList();
    		if (elecMarginList.size()>0) {
    			return elecMarginList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last electricity derivatives sent margin history - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<ElecMarginHistory> getElecMarginByDateAsc(int instrId, Timestamp iniVDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getElecMarHisByInstrIdAsc");
    		query.setParameter("instrId", instrId);
    		query.setParameter("iniVDate", iniVDate);
    		List<ElecMarginHistory> elecMarginList = query.getResultList();
    		return elecMarginList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives margin history ordered by Date - instrId: "+instrId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	
	
	public void add(int instrId, int month, Timestamp iniVDate, BigDecimal anCover, Timestamp anDate, BigDecimal anMargin, BigDecimal anMinMar,
		BigDecimal anStraddle, Timestamp apprDate, String approvedBy, String comment, BigDecimal cover, Timestamp endVDate, String log,
		BigDecimal margin, BigDecimal minMargin, BigDecimal mul, int rcCode, Timestamp sendDate, String sent, BigDecimal straddle, String susp) throws DataNotValidException {
		
		try {
			ElecMarginHistory elecMarginHistory = new ElecMarginHistory();
			ElecMarginHistoryPK pK = new ElecMarginHistoryPK();
			pK.setInstrId(instrId);
			pK.setMonth(month);
			pK.setIniVDate(iniVDate);
			elecMarginHistory.setPk(pK);
			
			elecMarginHistory.setAnCover(anCover);
			elecMarginHistory.setAnDate(anDate);
			elecMarginHistory.setAnMargin(anMargin);
			elecMarginHistory.setAnMinMar(anMinMar);
			elecMarginHistory.setAnStraddle(anStraddle);
			
			elecMarginHistory.setApprDate(apprDate);
			elecMarginHistory.setApprovedBy(approvedBy);
						
			elecMarginHistory.setComment(comment);
			elecMarginHistory.setCover(cover);
			elecMarginHistory.setEndVDate(endVDate);
			elecMarginHistory.setLog(log);
			elecMarginHistory.setMargin(margin);
			elecMarginHistory.setMinMargin(minMargin);
			elecMarginHistory.setMul(mul);
			elecMarginHistory.setRcCode(rcCode);
			
			elecMarginHistory.setSendDate(sendDate);
			elecMarginHistory.setSent(sent);
			elecMarginHistory.setStraddle(anStraddle);
			elecMarginHistory.setSusp(susp);
			
			elecMarginHistory.setUpdDate(GenericTools.systemDate());
			elecMarginHistory.setUpdType(updType);
			elecMarginHistory.setUpdUsr(userString());
			
			em.persist(elecMarginHistory);
			logging.debug("Added new electricity derivative margin history - instrId: "+instrId+"; month: "+month+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new electricity derivative margin history - instrId: "+instrId+"; month: "+month+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(ElecMarginHistory elecMarginHistory) throws DataNotValidException {
		try {
			elecMarginHistory.setUpdDate(GenericTools.systemDate());
			elecMarginHistory.setUpdType(updType);
			elecMarginHistory.setUpdUsr(userString());
			em.persist(elecMarginHistory);
			logging.debug("Added new electricity derivative margin history - instrId: "+elecMarginHistory.getPk().getInstrId()+"; month: "+elecMarginHistory.getPk().getMonth()+"; iniVDate: "+elecMarginHistory.getPk().getIniVDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new electricity derivative margin history - instrId: "+"; month: "+elecMarginHistory.getPk().getMonth()+"; iniVDate: "+elecMarginHistory.getPk().getInstrId()+"; iniVDate: "+elecMarginHistory.getPk().getIniVDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	public void store(ElecMargin elecMargin) throws DataNotValidException {
		try {
			
			ElecMarginHistory elecMarginHistory = new ElecMarginHistory();
			ElecMarginHistoryPK pK = new ElecMarginHistoryPK();
			pK.setInstrId(elecMargin.getPk().getInstrId());
			pK.setMonth(elecMargin.getPk().getMonth());
			pK.setIniVDate(elecMargin.getIniVDate());
			elecMarginHistory.setPk(pK);
			
			elecMarginHistory.setAnCover(elecMargin.getAnCover());
			elecMarginHistory.setAnDate(elecMargin.getAnDate());
			elecMarginHistory.setAnMargin(elecMargin.getAnMargin());
			elecMarginHistory.setAnMinMar(elecMargin.getAnMinMar());
			
			elecMarginHistory.setApprDate(GenericTools.systemDate());
			elecMarginHistory.setApprovedBy(elecMargin.getApproval());
						
			elecMarginHistory.setComment(elecMargin.getComment());
			elecMarginHistory.setCover(elecMargin.getCrCover());
			elecMarginHistory.setEndVDate(elecMargin.getEndVDate());
			elecMarginHistory.setLog(elecMargin.getCrLog());
			elecMarginHistory.setMargin(elecMargin.getCrMargin());
			elecMarginHistory.setMinMargin(elecMargin.getCrMinMar());
			elecMarginHistory.setMul(new BigDecimal(0));
			elecMarginHistory.setRcCode(elecMargin.getRcCode());
			
			elecMarginHistory.setSendDate(elecMargin.getSendDate());
			elecMarginHistory.setSent("F");
			elecMarginHistory.setStraddle(new BigDecimal(0));
			elecMarginHistory.setSusp(elecMargin.getSusp());

			elecMarginHistory.setUpdDate(GenericTools.systemDate());
			elecMarginHistory.setUpdType(updType);
			elecMarginHistory.setUpdUsr(userString());
			store(elecMarginHistory);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new electricity derivatives margin history from electricity derivatives margin - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, int month, Timestamp iniVDate, BigDecimal anCover, Timestamp anDate, BigDecimal anMargin, BigDecimal anMinMar,
			BigDecimal anStraddle, Timestamp apprDate, String approvedBy, String comment, BigDecimal cover, Timestamp endVDate, String log,
			BigDecimal margin, BigDecimal minMargin, BigDecimal mul, int rcCode, Timestamp sendDate, String sent, BigDecimal straddle, String susp) throws DataNotValidException {
		
		try {
			ElecMarginHistory elecMarginHistory = this.findByPrimaryKey(instrId, month,iniVDate);
		
			elecMarginHistory.setAnCover(anCover);
			elecMarginHistory.setAnDate(anDate);
			elecMarginHistory.setAnMargin(anMargin);
			elecMarginHistory.setAnMinMar(anMinMar);
			elecMarginHistory.setAnStraddle(anStraddle);
			
			elecMarginHistory.setApprDate(apprDate);
			elecMarginHistory.setApprovedBy(approvedBy);
						
			elecMarginHistory.setComment(comment);
			elecMarginHistory.setCover(cover);
			elecMarginHistory.setEndVDate(endVDate);
			elecMarginHistory.setLog(log);
			elecMarginHistory.setMargin(margin);
			elecMarginHistory.setMinMargin(minMargin);
			elecMarginHistory.setMul(mul);
			elecMarginHistory.setRcCode(rcCode);
			
			elecMarginHistory.setSendDate(sendDate);
			elecMarginHistory.setSent(sent);
			elecMarginHistory.setStraddle(anStraddle);
			elecMarginHistory.setSusp(susp);
			
			elecMarginHistory.setUpdDate(GenericTools.systemDate());
			elecMarginHistory.setUpdType("U");
			elecMarginHistory.setUpdUsr(userString());

			logging.debug("Electricity derivatives margin history updated - instrId: "+instrId+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating electricity derivatives margin history - instrId: "+instrId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	public void update(ElecMarginHistory elecMarginHistory) throws DataNotValidException {
		try {
			logging.debug("Electricity derivatives margin history updated - instrId: "+elecMarginHistory.getPk().getInstrId()+"; month: "+elecMarginHistory.getPk().getMonth()+"; iniVDate: "+elecMarginHistory.getPk().getIniVDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating electricity derivatives margin history - instrId: "+elecMarginHistory.getPk().getInstrId()+"; month: "+elecMarginHistory.getPk().getMonth()+"; iniVDate: "+elecMarginHistory.getPk().getIniVDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, int month, Timestamp iniVDate) throws DataNotValidException {
		try {
			ElecMarginHistory elecMarginHistory = this.findByPrimaryKey(instrId, month, iniVDate);
			em.remove(elecMarginHistory);
			logging.debug("Electricity derivatives margin history removed - instrId: "+instrId+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing electricity derivatives margin history - instrId: "+instrId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteElecMarHisByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			logging.debug("InstrId: "+instrId+" - "+result+" electricity derivatives margin history removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing electricity derivatives margin history - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	public void remove(ElecMarginHistory elecMarHistory) throws DataNotValidException {
		this.remove(elecMarHistory.getPk().getInstrId(), elecMarHistory.getPk().getMonth(),elecMarHistory.getPk().getIniVDate());
	}

}
