package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Group;
import it.ccg.pamp.server.entities.GroupComponent;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.List;

import javax.ejb.Local;
//local
@Local
public interface GroupEAOLocal {
	
	public Group[] fetch() throws DataNotValidException;
	
	public Group findByPrimaryKey(int grId) throws DataNotValidException;
	
	public Group[] findEnabledGroups() throws DataNotValidException;
	
	public Group[] findEnabledGroupsByDivisCode(String divisCode) throws DataNotValidException;
	
	public Group[] findEnabledRealGroupsByDivisCode(String divisCode) throws DataNotValidException;
	
	public Group[] findProposedGroups() throws DataNotValidException;
	
	public Group[] findProposedGroupsByDivisCode(String divisCode) throws DataNotValidException;
	
	public Group[] findActiveGroups() throws DataNotValidException;
	
	public Group[] findActiveGroupsByDivisCode(String divisCode) throws DataNotValidException;
	
	public void add(String grName, Timestamp iniVDate, Timestamp endVDate, Timestamp sendDate, int rcCode, String comment, String status,
			BigDecimal userCoeff, BigDecimal crCoeff, int crNv, String crVarType, int crNDaysPer, Timestamp anDate, BigDecimal anCoeff, int anNDaysPer, int anNv, String anVarType, String propose, 
			BigDecimal propCoeff, String approval, String crLog, String anLog, String propLog, List<GroupComponent> groupComponentList) throws DataNotValidException;
	
	public void store(Group group) throws DataNotValidException;
	
	public void setName(Group group) throws DataNotValidException;
	
	public void update(int grId, String grName, Timestamp iniVDate, Timestamp endVDate, Timestamp sendDate, int rcCode, String comment, String status,
			BigDecimal userCoeff, BigDecimal crCoeff, int crNv, String crVarType, int crNDaysPer, Timestamp anDate, BigDecimal anCoeff, int anNDaysPer, int anNv, String anVarType, String propose, 
			BigDecimal propCoeff, String approval, String crLog, String anLog, String propLog) throws DataNotValidException;
	
	public void update(Group group) throws DataNotValidException;
	
	public void logUpdate(Group group) throws DataNotValidException;
	
	public void createGroupAndComponents(LinkedHashMap<String, String> groupValues, String grCompList) throws DataNotValidException;
	
	public void remove(int grId) throws DataNotValidException;
	
	public int removeProposedGroup() throws DataNotValidException;
	
	public int removeProposedGroupByDivisCode(String divisCode) throws DataNotValidException;
	
	public void remove(Group group) throws DataNotValidException;

	public abstract String getNewForcedGroupName() throws DataNotValidException;
}
