package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Batch;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface BatchEAOLocal {
	
	public Batch[] fetch() throws DataNotValidException;
	
	public Batch[] getRunningBatchs() throws DataNotValidException;
	
	public Batch findByPrimaryKey(int batchId) throws DataNotValidException;
	
	public void add(int batchId, String batchName, String batchCat, String divisCode, String status) throws DataNotValidException;
	
	public void store(Batch batch) throws DataNotValidException;
	
	public void update(int batchId, String batchName, String batchCat, String divisCode, String status) throws DataNotValidException;
	
	public void updateToRunning(int batchId, int running) throws DataNotValidException;
	
	public void remove(int batchId) throws DataNotValidException; 
	
	public void remove(Batch btch) throws DataNotValidException;
}
