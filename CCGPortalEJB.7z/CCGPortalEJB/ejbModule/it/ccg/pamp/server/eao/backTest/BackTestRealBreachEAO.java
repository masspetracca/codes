package it.ccg.pamp.server.eao.backTest;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import it.ccg.pamp.server.entities.backTest.BackTestRealBreach;
import it.ccg.pamp.server.entities.backTest.BackTestRealBreachPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BackTestRealBreahEAO
 */
@Stateless
public class BackTestRealBreachEAO implements BackTestRealBreachEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}

	public String userString = "System";
	public String updType = "C";
	
	
	
	public List<BackTestRealBreach> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllBackTestRealBreach");
    		List<BackTestRealBreach> backTestRealBreachListList = query.getResultList();
    		return backTestRealBreachListList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test real breach list - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	public List<BackTestRealBreach> getBackTestRealBreachByBtId(int btId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBackTestRealBreachByBtId");
    		query.setParameter("btId", btId);
    		List<BackTestRealBreach> backTestRealBreachList = query.getResultList();
    		return backTestRealBreachList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test real breach list - back test id: "+btId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<BackTestRealBreach> getBackTestRealBreachByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBackTestRealBreachByInstrId");
    		query.setParameter("instrId", instrId);
    		List<BackTestRealBreach> backTestBreachList = query.getResultList();
    		return backTestBreachList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test real breach list - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public BackTestRealBreach findByPrimaryKey(int btId, int classId, int instrId, Timestamp priceDate, int nv, String breachTy) throws DataNotValidException {
		try {
    		
			BackTestRealBreachPK pK = new BackTestRealBreachPK();
			
			pK.setBtId(btId);
			pK.setClassId(classId);
			pK.setPriceDate(priceDate);
			pK.setNv(nv);
			pK.setInstrId(instrId);
			pK.setBreachTy(breachTy);
			
			BackTestRealBreach backTestBreach = (BackTestRealBreach) em.find(BackTestRealBreach.class,pK);
    		
			return backTestBreach;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test real breach - backTestId: "+btId+"; holding period: "+nv+"; instrId: "+instrId+"; class: "+classId+"; price date: "+priceDate+"; breach type: "+breachTy+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void add(int btId, int classId, int instrId, Timestamp priceDate, int nv, String breachTy, BigDecimal margin, Timestamp marIvDate, BigDecimal variation, BigDecimal closePr, BigDecimal pClosePr) throws DataNotValidException {
		
		try {
			BackTestRealBreach backTestRealBreach = new BackTestRealBreach();
			
			BackTestRealBreachPK pK = new BackTestRealBreachPK();
			
			pK.setBtId(btId);
			pK.setClassId(classId);
			pK.setPriceDate(priceDate);
			pK.setNv(nv);
			pK.setInstrId(instrId);
			pK.setBreachTy(breachTy);
			
			backTestRealBreach.setPk(pK);
			
			backTestRealBreach.setMargin(margin);
			backTestRealBreach.setMarIvDate(marIvDate);
			backTestRealBreach.setVariation(variation);
			
			backTestRealBreach.setClPrice(closePr);
			backTestRealBreach.setPClPrice(pClosePr);
			
			backTestRealBreach.setUpdDate(GenericTools.systemDate());
			backTestRealBreach.setUpdType("C");
			backTestRealBreach.setUpdUsr(userString());
			
			em.persist(backTestRealBreach);
			
			userLog.debug("Added new back test real breach - backTestId: "+btId+"; holding period: "+nv+"; instrId: "+instrId+"; class: "+classId+"; price date: "+priceDate+"; breach type: "+breachTy);
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new back test real breach - backTestId: "+btId+"; holding period: "+nv+"; instrId: "+instrId+"; class: "+classId+"; price date: "+priceDate+"; breach type: "+breachTy+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	
	public void store(BackTestRealBreach backTestRealBreach) throws DataNotValidException {
		
		try {
			
			backTestRealBreach.setUpdDate(GenericTools.systemDate());
			backTestRealBreach.setUpdType("C");
			backTestRealBreach.setUpdUsr(userString());
			
			em.persist(backTestRealBreach);
			
			userLog.debug("Added new back test real breach - back test id: "+backTestRealBreach.getPk().getBtId()+"; holding period: "+backTestRealBreach.getPk().getNv()+"; instrId: "+backTestRealBreach.getPk().getInstrId()+"; class: "+backTestRealBreach.getPk().getClassId()+"; price date: "+backTestRealBreach.getPk().getPriceDate()+"; breach type: "+backTestRealBreach.getPk().getBreachTy());
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new back test real breach - back test id: "+backTestRealBreach.getPk().getBtId()+"; holding period: "+backTestRealBreach.getPk().getNv()+"; instrId: "+backTestRealBreach.getPk().getInstrId()+"; class: "+backTestRealBreach.getPk().getClassId()+"; price date: "+backTestRealBreach.getPk().getPriceDate()+"; breach type: "+backTestRealBreach.getPk().getBreachTy()+ " - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	
	public void update(int btId, int classId, int instrId, Timestamp priceDate, int nv, String breachTy, BigDecimal margin, Timestamp marIvDate, BigDecimal variation, BigDecimal closePr, BigDecimal pClosePr) throws DataNotValidException {
		
		try {
			BackTestRealBreach backTestRealBreach = this.findByPrimaryKey(btId, classId, instrId, priceDate, nv, breachTy);
			
			backTestRealBreach.setMargin(margin);
			backTestRealBreach.setMarIvDate(marIvDate);
			backTestRealBreach.setVariation(variation);
			
			backTestRealBreach.setClPrice(closePr);
			backTestRealBreach.setPClPrice(pClosePr);
			
			backTestRealBreach.setUpdDate(GenericTools.systemDate());
			backTestRealBreach.setUpdType("U");
			backTestRealBreach.setUpdUsr(userString());
			
			userLog.debug("Updated back test real breach - backTestId: "+btId+"; holding period: "+nv+"; instrId: "+instrId+"; class: "+classId+"; price date: "+priceDate+"; breach type: "+breachTy);
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating back test real breach - backTestId: "+btId+"; holding period: "+nv+"; instrId: "+instrId+"; class: "+classId+"; price date: "+priceDate+"; breach type: "+breachTy+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	
	public void remove(int btId, int classId, int instrId, Timestamp priceDate, int nv, String breachTy) throws DataNotValidException {
		
		try {
			BackTestRealBreach backTestRealBreach = this.findByPrimaryKey(btId, classId, instrId, priceDate, nv, breachTy);
			
			em.remove(backTestRealBreach);
			
			userLog.debug("Removed back test real breach - backTestId: "+btId+"; holding period: "+nv+"; instrId: "+instrId+"; class: "+classId+"; price date: "+priceDate+"; breach type: "+breachTy);
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing back test real breach - backTestId: "+btId+"; holding period: "+nv+"; instrId: "+instrId+"; class: "+classId+"; price date: "+priceDate+"; breach type: "+breachTy+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	
	public void remove(BackTestRealBreach backTestRealBreach) throws DataNotValidException {
		
		this.remove(backTestRealBreach.getPk().getBtId(),backTestRealBreach.getPk().getClassId(),backTestRealBreach.getPk().getInstrId(),backTestRealBreach.getPk().getPriceDate(),backTestRealBreach.getPk().getNv(),backTestRealBreach.getPk().getBreachTy());
		
	}
	

}
