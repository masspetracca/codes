package it.ccg.pamp.server.eao.backTest;
import it.ccg.pamp.server.entities.backTest.BackTestRealBreach;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface BackTestRealBreachEAOLocal {

	public List<BackTestRealBreach> fetch() throws DataNotValidException;
	
	public List<BackTestRealBreach> getBackTestRealBreachByBtId(int btId) throws DataNotValidException;
	
	public List<BackTestRealBreach> getBackTestRealBreachByInstrId(int instrId) throws DataNotValidException;
	
	public BackTestRealBreach findByPrimaryKey(int btId, int classId, int instrId, Timestamp priceDate, int nv, String breachTy) throws DataNotValidException;
	
	public void add(int btId, int classId, int instrId, Timestamp priceDate, int nv, String breachTy, BigDecimal margin, Timestamp marIvDate, BigDecimal variation, BigDecimal closePr, BigDecimal pClosePr) throws DataNotValidException;
	
	public void store(BackTestRealBreach backTestRealBreach) throws DataNotValidException;
	
	public void update(int btId, int classId, int instrId, Timestamp priceDate, int nv, String breachTy, BigDecimal margin, Timestamp marIvDate, BigDecimal variation, BigDecimal closePr, BigDecimal pClosePr) throws DataNotValidException;
	
	public void remove(int btId, int classId, int instrId, Timestamp priceDate, int nv, String breachTy) throws DataNotValidException;
	
	public void remove(BackTestRealBreach backTestRealBreach) throws DataNotValidException;
	
}
