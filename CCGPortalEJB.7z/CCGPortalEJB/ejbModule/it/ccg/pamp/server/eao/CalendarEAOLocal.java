package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Calendar;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.List;

import javax.ejb.Local;

@Local
public interface CalendarEAOLocal {
	
	public List<Calendar> fetch() throws DataNotValidException;
	
	public LinkedHashMap<Timestamp, String> getCalendarByMarketCode(String marketCode) throws DataNotValidException;
	
	public List<Timestamp> getListDate(String marketCode) throws DataNotValidException;
	
	public List<Timestamp> getListDateByStartEndDate(String marketCode,Timestamp firstDate,Timestamp lastDate) throws DataNotValidException;
	
	public boolean isMarketDate() throws DataNotValidException;
	
	public int getCalendarByStartEndDate(Timestamp firstDate,Timestamp lastDate) throws DataNotValidException;
	
	public Calendar getPreviousCalendarDateByDayAndMarketCode(Timestamp date, String[] marketCode, int daysNumber) throws DataNotValidException;
	
	public LinkedHashMap<Timestamp,Integer> getPreviousCalendarDateByDayAndMarketCode(Timestamp date, String marketCode, int daysNumber) throws DataNotValidException;
	
	public Calendar findByPrimaryKey(Timestamp date, String marketCode) throws DataNotValidException;
	
	public void add(Timestamp date, String marketCode) throws DataNotValidException;
	
	public void store(Calendar calendar) throws DataNotValidException;
	
	public void remove(Timestamp date, String marketCode) throws DataNotValidException;
	
	public void removeByMarketDate(Timestamp mktDate) throws DataNotValidException;
	
}
