package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestCgmmkt00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.Cgmmkt00fJoined;

import java.util.List;

import javax.ejb.Local;

@Local
public interface Cgmmkt00fEAOLocal {
	public List<StressTestCgmmkt00f> fetch() throws DataNotValidException;
	public List<Cgmmkt00fJoined> joinCgmmkt01lwithCgmbr00f() throws DataNotValidException;
	public void update() throws DataNotValidException;
}
