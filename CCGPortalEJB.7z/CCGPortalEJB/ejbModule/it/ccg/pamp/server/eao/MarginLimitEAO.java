package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.MarginLimit;
import it.ccg.pamp.server.entities.MarginLimitPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MarginLimitEAO
 */
@Stateless
public class MarginLimitEAO implements  MarginLimitEAOLocal {
	@EJB private InstrumentEAOLocal instrEAO;
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
		
	public MarginLimit[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllMarginLimit");
    		List<MarginLimit> marginLimit = query.getResultList();
    		MarginLimit[] arrMarginLimit = new MarginLimit[marginLimit.size()];
    		return marginLimit.toArray(arrMarginLimit);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Margin Limits - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public MarginLimit findByPrimaryKey(String instrType, String instrStype) throws DataNotValidException {
		try {
			MarginLimitPK pK = new MarginLimitPK();
			pK.setInstrType(instrType);
			pK.setInstrStype(instrStype);
			MarginLimit marginLimit = (MarginLimit) em.find(MarginLimit.class,pK);
    		return marginLimit;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Margin Limit - instrType: "+instrType+"; instrStype: "+instrStype+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BigDecimal getMarginLimit(int instrId) throws DataNotValidException {
		try {
			Instrument instr = instrEAO.findByPrimaryKey(instrId);
			if (instr != null) {
				MarginLimit marginLimit = findByPrimaryKey(instr.getInstrType(),instr.getInstrStype());
	    		if (marginLimit!=null) {
	    			return marginLimit.getInfLim();
	    		} else {
	    			return new BigDecimal(0);
	    		}
			} else {
    			return new BigDecimal(0);
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching inferior margin limit - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BigDecimal getSuperiorMarginLimit(int instrId) throws DataNotValidException {
		try {
			Instrument instr = instrEAO.findByPrimaryKey(instrId);
			if (instr != null) {
				MarginLimit marginLimit = findByPrimaryKey(instr.getInstrType(),instr.getInstrStype());
	    		if (marginLimit!=null) {
	    			return marginLimit.getSupLim();
	    		} else {
	    			return new BigDecimal(0);
	    		}
			} else {
    			return new BigDecimal(0);
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching superior margin limit - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BigDecimal getDefaultMarginLimit(int instrId) throws DataNotValidException {
		try {
			Instrument instr = instrEAO.findByPrimaryKey(instrId);
			if (instr != null) {
				MarginLimit marginLimit = findByPrimaryKey(instr.getInstrType(),instr.getInstrStype());
	    		if (marginLimit!=null) {
	    			return marginLimit.getDefMar();
	    		} else {
	    			return new BigDecimal(0);
	    		}
			} else {
    			return new BigDecimal(0);
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching default margin limit - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(String instrType, String instrStype, BigDecimal infLim, BigDecimal supLim, BigDecimal defMar, BigDecimal buffer, String actBuffer, int perBuff) throws DataNotValidException {
		try {
			MarginLimit marginLimit = findByPrimaryKey(instrType, instrStype);
			MarginLimitPK pK = new MarginLimitPK();
			pK.setInstrType(instrType);
			pK.setInstrStype(instrStype);
			marginLimit.setPk(pK);
			
			marginLimit.setInfLim(infLim);
			marginLimit.setSupLim(supLim);
			marginLimit.setDefMar(defMar);
			marginLimit.setMarBuff(buffer);
			marginLimit.setActBuff(actBuffer);
			marginLimit.setPerBuff(perBuff);
			
			marginLimit.setUpdType(updType);
			marginLimit.setUpdDate(GenericTools.systemDate());
			marginLimit.setUpdUsr(userString());
			em.persist(marginLimit);
			log.debug("Added new Margin Limit - instrType: "+instrType+"; instrStype: "+instrStype);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Margin Limit - instrType: "+instrType+"; instrStype: "+instrStype+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(MarginLimit marginLimit) throws DataNotValidException {
		try {
			marginLimit.setUpdType(updType);
			marginLimit.setUpdDate(GenericTools.systemDate());
			marginLimit.setUpdUsr(userString());
			em.persist(marginLimit);
			log.debug("Added new Margin Limit - instrType: "+marginLimit.getPk().getInstrType()+"; instrStype: "+marginLimit.getPk().getInstrStype());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Margin Limit - instrType: "+marginLimit.getPk().getInstrType()+"; instrStype: "+marginLimit.getPk().getInstrStype()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(String instrType, String instrStype, BigDecimal infLim, BigDecimal supLim, BigDecimal defMar, BigDecimal buffer, String actBuffer, int perBuff) throws DataNotValidException {
		try {	
			MarginLimit marginLimit = findByPrimaryKey(instrType, instrStype);
			marginLimit.setInfLim(infLim);
			marginLimit.setSupLim(supLim);
			marginLimit.setDefMar(defMar);

			marginLimit.setMarBuff(buffer);
			marginLimit.setActBuff(actBuffer);
			
			marginLimit.setPerBuff(perBuff);
			
			marginLimit.setUpdType("U");
			marginLimit.setUpdDate(GenericTools.systemDate());
			marginLimit.setUpdUsr(userString());

			log.debug("Margin Limit updated - instrType: "+instrType+"; instrStype: "+instrStype);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updated Margin Limit - instrType: "+instrType+"; instrStype: "+instrStype+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(MarginLimit marLimit) throws DataNotValidException {
		try {	
			MarginLimit marginLimit = findByPrimaryKey(marLimit.getPk().getInstrType(),marLimit.getPk().getInstrStype());
			marginLimit.setUpdType("U");
			marginLimit.setUpdDate(GenericTools.systemDate());
			marginLimit.setUpdUsr(userString());
			log.debug("Margin Limit updated - instrType: "+marLimit.getPk().getInstrType()+"; instrStype: "+marLimit.getPk().getInstrStype());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Margin Limit - instrType: "+marLimit.getPk().getInstrType()+"; instrStype: "+marLimit.getPk().getInstrStype()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(String instrType, String instrStype) throws DataNotValidException {
		try {
			MarginLimit marginLimit = findByPrimaryKey(instrType, instrStype);
			em.remove(marginLimit);
			log.debug("Margin Limit removed - instrType: "+instrType+"; instrStype: "+instrStype);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Margin Limit - instrType: "+instrType+"; instrStype: "+instrStype+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(MarginLimit marLimit) throws DataNotValidException {
		remove(marLimit.getPk().getInstrType(),marLimit.getPk().getInstrStype());
	}
}
