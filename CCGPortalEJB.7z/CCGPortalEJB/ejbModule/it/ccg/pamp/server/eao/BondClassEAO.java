package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ClassEAO
 */
@Stateless
public class BondClassEAO implements  BondClassEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public BondClass[] fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllClass");
    		List<BondClass> classList = query.getResultList();
    		BondClass[] arrClass = new BondClass[classList.size()];
    		return classList.toArray(arrClass);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Classes - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BondClass findByPrimaryKey(int classId) throws DataNotValidException {
		try {
			BondClass cl = (BondClass) em.find(BondClass.class,classId);
    		return cl;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Class - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BondClass[] findEnabledBondClass() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllEnabledClass");
    		List<BondClass> classList = query.getResultList();
    		BondClass[] arrClass = new BondClass[classList.size()];
    		return classList.toArray(arrClass);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Enabled Classes - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<BondClass> getBondClassInClassMarHis() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBondClassInClassMarHis");
    		List<BondClass> classList = query.getResultList();
    		return classList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond classes stored into bond class margin history table  - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<BondClass> getBondClassInTraHis() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBondClassInTraHis");
    		List<BondClass> classList = query.getResultList();
    		return classList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond classes stored into bond intraclass offset history table  - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<BondClass> getBondClassInTerHis() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBondClassInTerHis");
    		List<BondClass> classList = query.getResultList();
    		return classList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond classes stored into bond interclass offset history table  - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BondClass[] findEnabledBondClassByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getEnabledClassByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<BondClass> classList = query.getResultList();
    		BondClass[] arrClass = new BondClass[classList.size()];
    		return classList.toArray(arrClass);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled bond classes - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(String classDesc, String status, String divisCode) throws DataNotValidException {
		try {
			BondClass cl = new BondClass();
			cl.setClassDesc(classDesc);
			cl.setStatus(status);
			cl.setUpdDate(GenericTools.systemDate());
			cl.setUpdType(updType);
			cl.setUpdUsr(userString());
			cl.setDivisCode(divisCode);
			em.persist(cl);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Bond Class - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(BondClass cl) throws DataNotValidException {
		try {
			cl.setUpdDate(GenericTools.systemDate());
			cl.setUpdType(updType);
			cl.setUpdUsr(userString());
			em.persist(cl);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Class - classId: "+cl.getClassId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int classId, String classDesc, String status, String divisCode) throws DataNotValidException {
		try {
			BondClass cl = findByPrimaryKey(classId);
			cl.setClassDesc(classDesc);
			cl.setStatus(status);
			cl.setUpdDate(GenericTools.systemDate());
			cl.setUpdType("U");
			cl.setUpdUsr(userString());
			cl.setDivisCode(divisCode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Class - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(BondClass entryClass) throws DataNotValidException {
		try {
			BondClass cl = findByPrimaryKey(entryClass.getClassId());
			cl.setClassDesc(entryClass.getClassDesc());
			cl.setStatus(entryClass.getStatus());
			cl.setUpdDate(GenericTools.systemDate());
			cl.setUpdType("U");
			cl.setUpdUsr(userString());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Class - classId: "+entryClass.getClassId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int classId) throws DataNotValidException {
		try {
			BondClass cl = findByPrimaryKey(classId);
			em.remove(cl);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Class - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
			
	public void remove(BondClass cl) throws DataNotValidException {
		remove(cl.getClassId());
	}

}
