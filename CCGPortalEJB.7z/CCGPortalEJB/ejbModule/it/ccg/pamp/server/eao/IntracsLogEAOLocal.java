package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.IntracsLog;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface IntracsLogEAOLocal {
	
	public List<IntracsLog> fetch() throws DataNotValidException;
	
    public void store(IntracsLog log) throws DataNotValidException;
}
