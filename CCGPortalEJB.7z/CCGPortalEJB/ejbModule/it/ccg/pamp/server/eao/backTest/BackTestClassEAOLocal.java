package it.ccg.pamp.server.eao.backTest;


import it.ccg.pamp.server.entities.backTest.BackTestClass;
import it.ccg.pamp.server.exceptions.DataNotValidException;


import java.util.List;

import javax.ejb.Local;

@Local
public interface BackTestClassEAOLocal {
	
	public List<BackTestClass> fetchAll() throws DataNotValidException;
	public List<BackTestClass> fetchByClassIdList(int[] classIdArray) throws DataNotValidException;

}
