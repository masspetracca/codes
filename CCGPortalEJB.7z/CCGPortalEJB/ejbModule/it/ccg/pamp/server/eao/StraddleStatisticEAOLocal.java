package it.ccg.pamp.server.eao;
import java.math.BigDecimal;
import java.util.List;

import it.ccg.pamp.server.entities.StraddleStatistic;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface StraddleStatisticEAOLocal {
public StraddleStatistic[] fetch() throws DataNotValidException;
	
	public StraddleStatistic findByPrimaryKey(int instrId, int progExp1, int progExp2, int mode) throws DataNotValidException;
	
	public List<String> printStraddleStatistics(int instrId) throws DataNotValidException;
	
	public StraddleStatistic[] getStraddleStatsByInstrId(int instrId) throws DataNotValidException;
	public List<StraddleStatistic> getStraddleStatsByInstrIdAndMode1(int instrId) throws DataNotValidException;
	public StraddleStatistic getMaxMathStraddleByInstrId(int instrId) throws DataNotValidException;
	
	public void add(int instrId, int progExp1, int progExp2, int mode, BigDecimal riskFree1, BigDecimal expYearFr1, BigDecimal expDelRat1, BigDecimal riskFree2, BigDecimal expYearFr2, BigDecimal expDelRat2, BigDecimal closePr,
			BigDecimal margin, BigDecimal deltaStr, int mul, BigDecimal sprbidask, BigDecimal mathStr, BigDecimal ratio, BigDecimal riskFrVar1, BigDecimal riskFrVar2, BigDecimal finStr, BigDecimal currStr, BigDecimal ordMargin, BigDecimal undMargin ) throws DataNotValidException;
	
	public void store(StraddleStatistic straddleStatistic) throws DataNotValidException;
	
	public void update(int instrId, int progExp1, int progExp2, int mode, BigDecimal riskFree1, BigDecimal expYearFr1, BigDecimal expDelRat1, BigDecimal riskFree2, BigDecimal expYearFr2, BigDecimal expDelRat2, BigDecimal closePr,
		BigDecimal margin, BigDecimal deltaStr, int mul, BigDecimal sprbidask, BigDecimal mathStr, BigDecimal ratio, BigDecimal riskFrVar1, BigDecimal riskFrVar2, BigDecimal finStr, BigDecimal currStr, BigDecimal ordMargin, BigDecimal undMargin) throws DataNotValidException;
	
	public void update(StraddleStatistic straddleStatistic) throws DataNotValidException;
	
	public void remove(int instrId, int progExp1, int progExp2, int mode) throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
	public int removeByMode(int mode) throws DataNotValidException;
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException;
	
	public void remove(StraddleStatistic streddleStats) throws DataNotValidException;
	
	public void transferMode1To2() throws DataNotValidException;
	
}
