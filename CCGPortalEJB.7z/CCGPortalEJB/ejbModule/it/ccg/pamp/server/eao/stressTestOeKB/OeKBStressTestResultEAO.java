package it.ccg.pamp.server.eao.stressTestOeKB;

import it.ccg.pamp.server.entities.stressTestOeKB.OeKBStressTestResult;
import it.ccg.pamp.server.entities.stressTestOeKB.OeKBStressTestResultPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class OeKBStressTestResultEAO
 */
@Stateless
public class OeKBStressTestResultEAO implements OeKBStressTestResultEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public List<OeKBStressTestResult> fetch() throws DataNotValidException {
		Query query = null;		
    	try {
    	  	query = em.createNamedQuery("getAllOeKBStressTestResult");
	    	List<OeKBStressTestResult> stressTestResultList = query.getResultList();
	    	return stressTestResultList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test results - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
	    }
    }
   
	public OeKBStressTestResult findByPrimaryKey(int stId, String scenario, long uMbr, String uAcCt,  String uSGrp, String uSubAc, int uGcm) throws DataNotValidException {
		try {
			OeKBStressTestResultPK pK = new OeKBStressTestResultPK();
			
			pK.setStId(stId);
			pK.setScenario(scenario);
			pK.setUMbr(uMbr);
			pK.setUAcCt(uAcCt);
			pK.setUSGrp(uSGrp);
			pK.setUSubAc(uSubAc);
			pK.setUGcm(uGcm);
			
			OeKBStressTestResult stressTestResult = em.find(OeKBStressTestResult.class, pK);
	    	return stressTestResult;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test result - stress test id: "+stId+"; uMbr: "+uMbr+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
	    }
    }

	public List<OeKBStressTestResult> findByStId(int stId) throws DataNotValidException {
		Query query = null;		
    	try {
    	   	query = em.createNamedQuery("getOeKBStressTestResultByStId");
    	   	query.setParameter("stId", stId);	
    	   	List<OeKBStressTestResult> stressTestResultList = query.getResultList();
	    	return stressTestResultList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test results - stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
	    }
    }
	
	public List<OeKBStressTestResult> findBetweenStIdInterval(int firstStId,int lastStId) throws DataNotValidException {
		Query query = null;		
    	try {
    	   	query = em.createNamedQuery("getOeKBStressTestResultBetweenFirstAndLastStId");
    	   	query.setParameter("firstStId", firstStId);
    	   	query.setParameter("lastStId", lastStId);	
    	   	List<OeKBStressTestResult> stressTestResultList = query.getResultList();
	    	return stressTestResultList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test results between stress test id "+firstStId+" and last stress test id "+lastStId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
	    }
    }
	
	
	public List<OeKBStressTestResult> findByScenario(String scenario) throws DataNotValidException {
		Query query = null;		
    	try {
    	   	query = em.createNamedQuery("getOeKBStressTestResultByScenario");
    	   	query.setParameter("scenario", scenario);	
    	   	List<OeKBStressTestResult> stressTestResultList = query.getResultList();
	    	return stressTestResultList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test results - scenario: "+scenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
	    }
    }
	
	public List<OeKBStressTestResult> findByStIdAndScenario(int stId, String scenario) throws DataNotValidException {
		Query query = null;		
    	try {
    	   	query = em.createNamedQuery("getOeKBStressTestResultByStIdAndScenario");
    	   	query.setParameter("stId", stId);	
    	   	query.setParameter("scenario", scenario);	
    	   	List<OeKBStressTestResult> stressTestResultList = query.getResultList();
	    	return stressTestResultList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test results - stress test id = "+stId+"; scenario: "+scenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
	    }
    }
	
	public int findLastStId(String scenario) throws DataNotValidException {
		Query query = null;		
    	try {
    	   	query = em.createNamedQuery("getOeKBStressTestResultByScenario");
    	   	query.setParameter("scenario", scenario);	
    	   	List<OeKBStressTestResult> stressTestResultList = query.getResultList();
	    	int lastStId = 0;
    	   	if (stressTestResultList.size() > 0) {
	    		lastStId = stressTestResultList.get(0).getPk().getStId();
	    	}
    	   	
	    	return lastStId;
	    	
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test results - scenario: "+scenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
	    }
    }
	
	public void add(int stId, String scenario, long uMbr, String uAcCt,  String uSGrp, String uSubAc, BigDecimal dataMrg, BigDecimal transId, BigDecimal uMargin, String pFolioId) throws DataNotValidException {
			
		try {
			OeKBStressTestResult stressTestResult = new OeKBStressTestResult();
			
			OeKBStressTestResultPK pK = new OeKBStressTestResultPK();
			
			pK.setStId(stId);
			pK.setScenario(scenario);
			pK.setUMbr(uMbr);
			pK.setUAcCt(uAcCt);
			pK.setUSGrp(uSGrp);
			pK.setUSubAc(uSubAc);
			
			stressTestResult.setDataMrg(dataMrg);
			stressTestResult.setTransId(transId);
			
			stressTestResult.setPFolioId(pFolioId);
			
			stressTestResult.setUMargin(uMargin);
			
			em.persist(stressTestResult);
			log.debug("Added new stress test result - stId: "+stId+"; uMbr: "+uMbr);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test result - stress test id: "+stId+"; uMbr: "+uMbr+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
		
		
	public void store(OeKBStressTestResult stressTestResult) throws DataNotValidException {
		
		try {
			
			em.persist(stressTestResult);
			log.debug("Added new stress test result - stress test Id: "+stressTestResult.getPk().getStId()+"; uMbr: "+stressTestResult.getPk().getUMbr());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test result - stress test Id: "+stressTestResult.getPk().getStId()+"; uMbr: "+stressTestResult.getPk().getUMbr()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int stId, String scenario, long uMbr, String uAcCt,  String uSGrp, String uSubAc, int uGcm, BigDecimal dataMrg, BigDecimal transId, BigDecimal uMargin, String pFolioId) throws DataNotValidException {
		
		try {
			
			OeKBStressTestResult stressTestResult = this.findByPrimaryKey(stId, scenario, uMbr, uAcCt, uSGrp, uSubAc, uGcm);
			
			stressTestResult.setDataMrg(dataMrg);
			stressTestResult.setTransId(transId);
			stressTestResult.setUMargin(uMargin);
			
			stressTestResult.setPFolioId(pFolioId);
			
			log.debug("Updated stress test result - stId: "+stId+"; uMbr: "+uMbr);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stress test result - stId: "+stId+"; uMbr: "+uMbr+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(OeKBStressTestResult stressTestResult) throws DataNotValidException {
		
		OeKBStressTestResultPK pK = stressTestResult.getPk();
		
		this.remove(pK.getStId(), pK.getScenario(), pK.getUMbr(), pK.getUAcCt(), pK.getUSGrp(), pK.getUSGrp(), (int) pK.getUGcm());
			
	}
	
	public void remove(int stId, String scenario, long uMbr, String uAcCt,  String uSGrp, String uSubAc, int uGcm) throws DataNotValidException {
		
		try {
			
			OeKBStressTestResult stressTestResult = this.findByPrimaryKey(stId, scenario, uMbr, uAcCt, uSGrp, uSubAc, uGcm);
			
			em.remove(stressTestResult);
			
			log.debug("Removed stress test result - stId: "+stId+"; uMbr: "+uMbr);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test result - stId: "+stId+"; uMbr: "+uMbr+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
}
