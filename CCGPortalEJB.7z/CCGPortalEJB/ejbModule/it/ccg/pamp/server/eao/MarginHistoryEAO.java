package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.Margin;
import it.ccg.pamp.server.entities.MarginHistory;
import it.ccg.pamp.server.entities.MarginHistoryPK;
import it.ccg.pamp.server.entities.MinimumMargin;
import it.ccg.pamp.server.entities.Straddle;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondToSync;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.WorkingMarginToExport;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MarginHistoryEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class MarginHistoryEAO implements  MarginHistoryEAOLocal {

	@EJB
	MinimumMarginEAOLocal minMarEAO;
	@EJB
	StraddleEAOLocal straddleEAO;
	@EJB
	InstrumentEAOLocal instrEAO;

	@PersistenceContext(unitName = "PAMPUSE", type = PersistenceContextType.TRANSACTION)
	private EntityManager em;

	Logger logging = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;

	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}

	public String userString = "System";
	public String updType = "C";

	public MarginHistory[] fetch() throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getAllMarHis");
			List<MarginHistory> margin = query.getResultList();
			MarginHistory[] arrMarginHistory = new MarginHistory[margin.size()];
			return margin.toArray(arrMarginHistory);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching Margin Histories - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public MarginHistory findByPrimaryKey(int instrId, Timestamp iniVDate) throws DataNotValidException {
		try {
			MarginHistoryPK pK = new MarginHistoryPK();
			pK.setInstrid(instrId);
			pK.setInivdate(iniVDate);
			MarginHistory marginHistory = (MarginHistory) em.find(MarginHistory.class, pK);
			return marginHistory;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching Margin History - instrId: " + instrId + "; iniVDate: " + iniVDate + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public MarginHistory[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getMarHisByInstrId");
			query.setParameter("instrId", instrId);
			List<MarginHistory> marginHistory = query.getResultList();
			MarginHistory[] arrMarginHistory = new MarginHistory[marginHistory.size()];
			return marginHistory.toArray(arrMarginHistory);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching Margin Histories - instrId: " + instrId + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public MarginHistory[] findByClassId(int classId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getMarHisByClassId");
			query.setParameter("classId", classId);
			List<MarginHistory> marginHistory = query.getResultList();
			MarginHistory[] arrMarginHistory = new MarginHistory[marginHistory.size()];
			return marginHistory.toArray(arrMarginHistory);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching Margin Histories - classId: " + classId + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public MarginHistory[] getMarHisToExport() throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getMarHisToExport");
			query.setParameter("systemDate", GenericTools.systemDate());
			List<MarginHistory> marginHistory = query.getResultList();
			MarginHistory[] arrMarginHistory = new MarginHistory[marginHistory.size()];
			return marginHistory.toArray(arrMarginHistory);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching Margin Histories to Export - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	public List<WorkingMarginToExport> getWorkingMargins() throws DataNotValidException {
		Query query = null;
		
		String sqlString = "SELECT I.ISINCODE,M1.MARGIN FROM PMPTMARHIS M1 "+
						"INNER JOIN PMPTINSTR I "+
						"ON M1.INSTRID = I.INSTRID "+ 
						"WHERE M1.INSTRID IN "+
						"(SELECT I.INSTRID FROM PMPTINSTR I  "+
						"WHERE M1.INSTRID = I.INSTRID "+ 
						"AND I.STATUS = 'E' "+
						"AND I.DIVISCODE = 'E') "+
						"AND M1.SENT = 'T' "+
						"AND M1.SENDDATE <= NOW() "+
						"AND "+
						"(SELECT COUNT(M2.INSTRID) FROM PMPTMARHIS M2 "+
						"WHERE M2.INSTRID=M1.INSTRID "+ 
						"AND M2.sendDate<=NOW() "+
						"AND M2.iniVDate>M1.iniVDate)=0 "+
						"ORDER BY I.ISINCODE ";
		
		try {
			query =  em.createNativeQuery(sqlString,WorkingMarginToExport.class);
		}  catch (Exception e) {
			e.getStackTrace();
		}
			
		List<WorkingMarginToExport> workingMarginList = query.getResultList();
		
		return workingMarginList;
	}

	public MarginHistory[] getMarHisNotSync() throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getMarHisNotSync");
			List<MarginHistory> marginHistory = query.getResultList();
			MarginHistory[] arrMarginHistory = new MarginHistory[marginHistory.size()];
			return marginHistory.toArray(arrMarginHistory);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching Margin Histories to Export - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public MarginHistory[] getMarHisNotInCGC() throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getMarHisNotInCGC");
			query.setParameter("systemDate", GenericTools.systemDate());
			List<MarginHistory> marginHistory = query.getResultList();
			MarginHistory[] arrMarginHistory = new MarginHistory[marginHistory.size()];
			return marginHistory.toArray(arrMarginHistory);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching Margin Histories to Export - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public MarginHistory getCurrentMargin(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getCurrentMargin");
			query.setParameter("instrId", instrId);
			query.setMaxResults(1);
			List<MarginHistory> marginHistory = query.getResultList();
			if (marginHistory.size() > 0) {
				return marginHistory.get(0);
			} else {
				return null;
			}
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching last margin history - instrId: " + instrId + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public MarginHistory getFirstMarginNotSuspOrOneAvailable(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getCurrentMargin");
			query.setParameter("instrId", instrId);
			
			List<MarginHistory> marginHistory = query.getResultList();

			MarginHistory mhret = null;

			for (MarginHistory mh : marginHistory) {
				//se � la prima volta che entra
				if (mhret == null) {
					mhret = mh;
					if (mh.getSusp()==null||mh.getSusp().equalsIgnoreCase("F")) {
						mhret = mh;
						break;
					}
				} 
				//nei casi successivi
				else {
					if (mh.getSusp()==null||mh.getSusp().equalsIgnoreCase("F")) {
						mhret = mh;
						break;
					}
				}
			}

			return mhret;

		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching last margin history - instrId: " + instrId + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public MarginHistory getLastSentMargin(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getLastSentMargin");
			query.setParameter("instrId", instrId);
			query.setMaxResults(1);
			List<MarginHistory> marginHistory = query.getResultList();
			if (marginHistory.size() > 0) {
				return marginHistory.get(0);
			} else {
				return null;
			}
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching last margin history - instrId: " + instrId + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public MarginHistory[] getMarginByDateAsc(int instrId, Timestamp iniVDate) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getMarHisByInstrIdAsc");
			query.setParameter("instrId", instrId);
			query.setParameter("iniVDate", iniVDate);
			List<MarginHistory> marginHistory = query.getResultList();
			MarginHistory[] arrMarginHistory = new MarginHistory[marginHistory.size()];
			return marginHistory.toArray(arrMarginHistory);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching Margin Histories ordered by Date - instrId: " + instrId + "; iniVDate: " + iniVDate + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public MarginHistory getCurrentMarginByDate(int instrId, Timestamp iniVDate) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getMarHisByInstrIdAsc");
			query.setParameter("instrId", instrId);
			query.setParameter("iniVDate", iniVDate);
			List<MarginHistory> marginHistoryList = query.getResultList();
			if (marginHistoryList.size() > 0) {
				return marginHistoryList.get(0);
			} else {
				return null;
			}
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching Margin Histories ordered by Date - instrId: " + instrId + "; iniVDate: " + iniVDate + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void add(int instrId, Timestamp iniVDate, Timestamp endvDate, BigDecimal margin, BigDecimal cover, String sent, Timestamp sendDate, String approvedBy, Timestamp apprDate,
			BigDecimal anMinMar, BigDecimal anMargin, BigDecimal anCover, Timestamp anDate, int rcCode, String comment, int classId, String log, BigDecimal straddle, BigDecimal anStraddle,
			String susp, BigDecimal mul, BigDecimal anMarginBuffer, BigDecimal anNotBufferedMargin, String anCap) throws DataNotValidException {

		try {
			MarginHistory marginHistory = new MarginHistory();
			MarginHistoryPK pK = new MarginHistoryPK();
			pK.setInstrid(instrId);
			pK.setInivdate(iniVDate);
			marginHistory.setPk(pK);
			marginHistory.setEndVDate(endvDate);
			marginHistory.setMargin(margin);
			marginHistory.setCover(cover);
			marginHistory.setSent(sent);
			marginHistory.setSendDate(sendDate);
			marginHistory.setApprovedBy(approvedBy);
			marginHistory.setApprDate(apprDate);
			marginHistory.setAnMinMar(anMinMar);
			marginHistory.setAnMargin(anMargin);
			marginHistory.setAnCover(anCover);
			marginHistory.setAnDate(anDate);
			marginHistory.setRcCode(rcCode);
			marginHistory.setComment(comment);
			marginHistory.setClassId(classId);
			marginHistory.setLog(log);
			marginHistory.setAnStraddle(anStraddle);
			marginHistory.setStraddle(anStraddle);
			marginHistory.setSusp(susp);
			marginHistory.setMul(mul);
			marginHistory.setUpdDate(GenericTools.systemDate());
			marginHistory.setUpdType(updType);
			marginHistory.setUpdUsr(userString());
			if (instrEAO.findByPrimaryKey(instrId).getDivisCode().equalsIgnoreCase("D")) {
				marginHistory.setStraddle(straddle);
				marginHistory.setAnStraddle(anStraddle);
			}
			marginHistory.setAnMarginBuffer(anMarginBuffer);
			marginHistory.setAnNotBufferedMargin(anNotBufferedMargin);
			marginHistory.setAnCap(anCap);
			
			em.persist(marginHistory);
			logging.debug("Added new Margin History - instrId: " + instrId + "; iniVDate: " + iniVDate);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding new Margin History - instrId: " + instrId + "; iniVDate: " + iniVDate + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void store(MarginHistory marginHistory) throws DataNotValidException {
		try {
			marginHistory.setUpdDate(GenericTools.systemDate());
			marginHistory.setUpdType(updType);
			marginHistory.setUpdUsr(userString());
			em.persist(marginHistory);
			logging.debug("Added new Margin History - instrId: " + marginHistory.getPk().getInstrId() + "; iniVDate: " + marginHistory.getPk().getIniVDate());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding new Margin History - instrId: " + marginHistory.getPk().getInstrId() + "; iniVDate: "
					+ marginHistory.getPk().getIniVDate() + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void restore(MarginHistory marginHistory) throws DataNotValidException, SQLException {
		try {
			em.persist(marginHistory);
			logging.debug("Added new Margin History - instrId: " + marginHistory.getPk().getInstrId() + "; iniVDate: " + marginHistory.getPk().getIniVDate());
		} catch (Exception e) {
			/*
			 * if (e.getCause().equals(new SQLException())) { logging.warn(
			 * "duplicate key found for this Margin History - instrId: "
			 * +marginHistory.getPk().getInstrId()); } else {
			 */
			// DataNotValidException exc = new
			// DataNotValidException("Error adding new Margin History - instrId: "+marginHistory.getPk().getInstrId()+"; iniVDate: "+marginHistory.getPk().getIniVDate()+" - "+e.getMessage());
			SQLException sqlException = new SQLException("dgfgdf " + e.getMessage());
			sqlException.setStackTrace(e.getStackTrace());
			// exc.setStackTrace(e.getStackTrace());
			throw sqlException;
			// }
		}
	}

	public void store(Margin margin) throws DataNotValidException {
		try {
			MarginHistory marHis = new MarginHistory();

			MarginHistoryPK marHisPK = new MarginHistoryPK();
			marHisPK.setInivdate(margin.getInivDate());
			marHisPK.setInstrid(margin.getInstrId());
			marHis.setPk(marHisPK);
			marHis.setAnCover(margin.getAnCover());
			marHis.setAnDate(margin.getAnDate());
			marHis.setAnMargin(margin.getAnMargin());
			marHis.setAnMinMar(margin.getAnMinMar());
			marHis.setApprDate(GenericTools.systemDate());
			marHis.setApprovedBy(userString());
			marHis.setClassId(margin.getClassId());
			marHis.setComment(margin.getComment());
			marHis.setCover(margin.getPropCover());
			marHis.setEndVDate(margin.getEndvDate());
			marHis.setMargin(margin.getPropMargin());
			marHis.setMinMargin(margin.getPropMinMar());

			marHis.setRcCode(margin.getRcCode());
			marHis.setSendDate(margin.getSendDate());
			marHis.setSent("F");

			if (instrEAO.findByPrimaryKey(margin.getInstrId()).getMult() != null) {
				marHis.setMul(instrEAO.findByPrimaryKey(margin.getInstrId()).getMult());
			}
			marHis.setLog(margin.getPropLog());
			marHis.setSusp(margin.getSusp());
			marHis.setUpdDate(GenericTools.systemDate());
			marHis.setUpdType(updType);
			marHis.setUpdUsr(userString());
			
			marHis.setAnMarginBuffer(margin.getAnMarginBuffer());
			marHis.setAnNotBufferedMargin(margin.getAnNotBufferedMargin());
			marHis.setAnCap(margin.getAnCap());
			
			

			store(marHis);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding new Margin History from Margin - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void storeEqDerivatives(Margin margin, Straddle straddle, MinimumMargin minMar) throws DataNotValidException {
		try {
			MarginHistory marHis = new MarginHistory();
			MarginHistoryPK marHisPK = new MarginHistoryPK();
			marHisPK.setInivdate(margin.getInivDate());
			marHisPK.setInstrid(margin.getInstrId());
			marHis.setPk(marHisPK);
			marHis.setAnCover(margin.getAnCover());
			marHis.setAnDate(margin.getAnDate());
			marHis.setAnMargin(margin.getAnMargin());
			
			//buffer and cap params
			marHis.setAnNotBufferedMargin(margin.getAnNotBufferedMargin());
			marHis.setAnCap(margin.getAnCap());
			marHis.setAnMarginBuffer(margin.getAnMarginBuffer());
			

			marHis.setApprDate(GenericTools.systemDate());
			marHis.setApprovedBy(userString());
			marHis.setClassId(margin.getClassId());
			marHis.setComment(margin.getComment());
			marHis.setCover(margin.getPropCover());
			marHis.setEndVDate(margin.getEndvDate());
			marHis.setMargin(margin.getPropMargin());

			marHis.setRcCode(margin.getRcCode());
			marHis.setSendDate(margin.getSendDate());
			marHis.setSent("F");
			marHis.setLog(margin.getPropLog());
			if (straddle != null) {
				marHis.setStraddle(straddle.getPropStra());
				marHis.setAnStraddle(straddle.getAnStra());
			}
			if (minMar != null) {
				marHis.setMinMargin(minMar.getPropMinMar());
				marHis.setAnMinMar(minMar.getAnMinMar());
			}
			marHis.setUpdDate(GenericTools.systemDate());
			marHis.setUpdType(updType);
			marHis.setUpdUsr(userString());
			// TODO per ora lo prendiamo dall'anagrafica ma andr� recuperato
			// da un campo del margine che va ancora implementato che conterr�
			// il moltiplicatore utilizzato per quello strumento al momento del
			// calcolo
			Instrument instr = instrEAO.findByPrimaryKey(margin.getInstrId());
			marHis.setMul(instr.getMult());

			/*marHis.setNotBufferedMargin(margin.getNotBufferedMargin());
			marHis.setFlag1(margin.getFlag1());
			marHis.setFlag2(margin.getFlag2());
			marHis.setFlag3(margin.getFlag3());*/
			
			marHis.setSusp(margin.getSusp());
			store(marHis);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding new Margin History from Margin - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void storeByMarginAndMinMargin(Margin margin, MinimumMargin minMar) throws DataNotValidException {
		try {
			MarginHistory lastMarHis = this.getCurrentMargin(margin.getInstrId());

			MarginHistory marHis = new MarginHistory();
			MarginHistoryPK marHisPK = new MarginHistoryPK();

			marHisPK.setInivdate(minMar.getInivDate());
			marHisPK.setInstrid(margin.getInstrId());
			marHis.setPk(marHisPK);

			marHis.setRcCode(minMar.getRcCode());
			marHis.setSendDate(minMar.getSendDate());

			if (margin.getPropMinMar() != null) {
				marHis.setMinMargin(margin.getUserMinMar());
				// marHis.setAnMinMar(minMar.getAnMinMar());
			}

			marHis.setAnCover(lastMarHis.getAnCover());
			marHis.setAnDate(lastMarHis.getAnDate());
			marHis.setAnMargin(lastMarHis.getAnMargin());

			marHis.setApprDate(lastMarHis.getApprDate());
			marHis.setApprovedBy(lastMarHis.getApprovedBy());

			marHis.setClassId(lastMarHis.getClassId());
			marHis.setComment(lastMarHis.getComment());
			marHis.setCover(lastMarHis.getCover());
			marHis.setEndVDate(minMar.getEndvDate());
			marHis.setMargin(lastMarHis.getMargin());

			marHis.setSent("F");
			marHis.setLog(margin.getPropLog());
			
			marHis.setAnMarginBuffer(margin.getAnMarginBuffer());
			marHis.setAnNotBufferedMargin(margin.getAnNotBufferedMargin());
			marHis.setAnCap(margin.getAnCap());

			marHis.setUpdDate(GenericTools.systemDate());
			marHis.setUpdType(updType);
			marHis.setUpdUsr(userString());
			// TODO per ora lo prendiamo dall'anagrafica ma andr� recuperato
			// da un campo del margine che va ancora implementato che conterr�
			// il moltiplicatore utilizzato per quello strumento al momento del
			// calcolo
			// Instrument instr =
			// instrEAO.findByPrimaryKey(margin.getInstrId());
			marHis.setMul(lastMarHis.getMul());

			marHis.setSusp(lastMarHis.getSusp());
			store(marHis);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding new Margin History from Margin - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void update(int instrId, Timestamp iniVDate, Timestamp endvDate, BigDecimal margin, BigDecimal cover, BigDecimal minMargin, String sent, Timestamp sendDate, String approvedBy,
			Timestamp apprDate, BigDecimal anMinMar, BigDecimal anMargin, BigDecimal anCover, Timestamp anDate, int rcCode, String comment, int classId, String log, BigDecimal straddle,
			BigDecimal anStraddle, String susp, BigDecimal mul, BigDecimal anMarginBuffer, BigDecimal anNotBufferedMargin, String anCap) throws DataNotValidException {

		try {
			MarginHistory marginHistory = findByPrimaryKey(instrId, iniVDate);

			marginHistory.setEndVDate(endvDate);
			marginHistory.setMargin(margin);
			marginHistory.setCover(cover);
			marginHistory.setMinMargin(minMargin);
			marginHistory.setSent(sent);
			marginHistory.setSendDate(sendDate);
			marginHistory.setApprovedBy(approvedBy);
			marginHistory.setApprDate(apprDate);
			marginHistory.setAnMinMar(anMinMar);
			marginHistory.setAnMargin(anMargin);
			marginHistory.setAnCover(anCover);
			marginHistory.setAnDate(anDate);
			marginHistory.setRcCode(rcCode);
			marginHistory.setComment(comment);
			marginHistory.setClassId(classId);
			marginHistory.setLog(log);
			marginHistory.setMul(mul);
			if (instrEAO.findByPrimaryKey(instrId).getDivisCode().equalsIgnoreCase("D")) {
				marginHistory.setStraddle(straddle);
				marginHistory.setAnStraddle(anStraddle);
			}
			marginHistory.setSusp(susp);
			
			marginHistory.setAnMarginBuffer(anMarginBuffer);
			marginHistory.setAnNotBufferedMargin(anNotBufferedMargin);
			marginHistory.setAnCap(anCap);
			
			marginHistory.setUpdDate(GenericTools.systemDate());
			marginHistory.setUpdType("U");
			marginHistory.setUpdUsr(userString());
			logging.debug("Margin History updated - instrId: " + instrId + "; iniVDate: " + iniVDate);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error updating Margin History - instrId: " + instrId + "; iniVDate: " + iniVDate + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}

	}

	public void update(MarginHistory marHistory) throws DataNotValidException {
		try {
			MarginHistory marghist = this.findByPrimaryKey(marHistory.getPk().getInstrId(), marHistory.getPk().getIniVDate());
			marghist.setSent("T");
			marghist.setUpdDate(GenericTools.systemDate());
			marghist.setUpdType("U");
			marghist.setUpdUsr("System");
			logging.debug("Margin History updated - instrId: " + marHistory.getPk().getInstrId() + "; iniVDate: " + marHistory.getPk().getIniVDate());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error updating Margin History - instrId: " + marHistory.getPk().getInstrId() + "; iniVDate: " + marHistory.getPk().getIniVDate()
					+ " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void logUpdate(MarginHistory marHistory) throws DataNotValidException {
		try {
			// update(marHistory);
			logging.debug("Margin History updated - instrId: " + marHistory.getPk().getInstrId() + "; iniVDate: " + marHistory.getPk().getIniVDate());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error updating Margin History - instrId: " + marHistory.getPk().getInstrId() + "; iniVDate: " + marHistory.getPk().getIniVDate()
					+ " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void remove(int instrId, Timestamp iniVDate) throws DataNotValidException {
		try {
			MarginHistory marginHistory = findByPrimaryKey(instrId, iniVDate);
			em.remove(marginHistory);
			logging.debug("Margin History removed - instrId: " + instrId + "; iniVDate: " + iniVDate);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing Margin History - instrId: " + instrId + "; iniVDate: " + iniVDate + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}

	}

	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteMarHisByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			logging.debug("InstrId: " + instrId + " - " + result + " Margin History removed");
			return result;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing Margin History - instrId: " + instrId + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public int removeByClassId(int classId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteMarHisByClassId");
			query.setParameter("classId", classId);
			int result = query.executeUpdate();
			logging.debug(result + " Margin History removed - classId: " + classId);
			return result;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing Margin History - classId: " + classId + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void remove(MarginHistory marHistory) throws DataNotValidException {
		remove(marHistory.getPk().getInstrId(), marHistory.getPk().getIniVDate());
	}

}
