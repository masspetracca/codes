package it.ccg.pamp.server.eao.backTest;
import it.ccg.pamp.server.entities.backTest.BackTestBreach;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface BackTestBreachEAOLocal {

	public  void remove(BackTestBreach backTestBreach) throws DataNotValidException;

	public  void remove(int btId, int nv, int classId, int instrId, Timestamp pricedate) throws DataNotValidException;

	public  void update(int btId, int nv, int classId, int instrId, Timestamp pricedate, String divisCode, String log, String status, BigDecimal usrCov, BigDecimal usrMar, int usrDays, BigDecimal closePr, BigDecimal pClosePr, int usrBrch) throws DataNotValidException;

	public  void store(BackTestBreach backTestBreach) throws DataNotValidException;

	public  void add(int btId, int nv, int classId, int instrId, Timestamp pricedate, String divisCode, String log, String status, BigDecimal usrCov, BigDecimal usrMar, int usrDays, BigDecimal closePr, BigDecimal pClosePr, int usrBrch) throws DataNotValidException;

	public  BackTestBreach findByPrimaryKey(int btId, int nv, int classId, int instrId, Timestamp pricedate) throws DataNotValidException;

	public  List<BackTestBreach> getBackTestBreachByInstrId(int instrId) throws DataNotValidException;

	public  List<BackTestBreach> getBackTestBreachByBtId(int btId) throws DataNotValidException;
	
	public List<BackTestBreach> getBackTestBreachByClassIdOrderByUsrMar(int classId) throws DataNotValidException;

	public  List<BackTestBreach> getBackTestBreachByDivisCode(String divisCode) throws DataNotValidException;

	public void removeAll() throws DataNotValidException;
	
	public  List<BackTestBreach> fetchAllBackTestBreach() throws DataNotValidException;

	
	
}
