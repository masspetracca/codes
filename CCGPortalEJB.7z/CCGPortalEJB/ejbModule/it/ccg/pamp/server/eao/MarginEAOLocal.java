package it.ccg.pamp.server.eao;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import it.ccg.pamp.server.entities.Margin;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.MarginCustomObj;

import javax.ejb.Local;

@Local
public interface MarginEAOLocal {
public Margin[] fetch() throws DataNotValidException;
	
	public Margin[] getEnabledMargins() throws DataNotValidException;
	
	public Margin[] getEnabledMarginsByDivisCode(String divisCode) throws DataNotValidException;
	
	public Margin findByPrimaryKey(int instrId) throws DataNotValidException;
	
	public Margin[] findByClassId(int classId) throws DataNotValidException;
	
	public boolean noMarginSubmittedForApproval(String divisCode) throws DataNotValidException;
	
	public boolean noMarginSubmittedForApproval() throws DataNotValidException;
	
	public List<MarginCustomObj> getDerivativesWithUnderlyingMargins() throws DataNotValidException;
	
	public void add(int instrId, Timestamp inivDate, Timestamp endvDate, Timestamp sendDate, String status, 
		BigDecimal crMargin, BigDecimal crCover, int crNDaysPer, int crNv, String crVarType, BigDecimal anMargin, 
		BigDecimal anCover, int anNDaysPer, int anNv, String anVarType, BigDecimal userMargin, BigDecimal crMinMar, 
		BigDecimal anMinMar, BigDecimal userMinMar, Timestamp anDate, BigDecimal propCover, BigDecimal propMargin, 
		BigDecimal propMinMar, String approval, int rcCode, String comment, int classId, BigDecimal crNdMar, 
		BigDecimal anNdMar, String propose, String crLog, String anLog, String propLog, BigDecimal userCov, 
		BigDecimal rlMargin, Timestamp crFrstHisD, Timestamp anFrstHisD, Timestamp crLastHisD, 
	    Timestamp anLastHisD, String susp, String custom, String divisCode,BigDecimal currentMarginBuffer,  BigDecimal anMarginBuffer, 
	    BigDecimal currentNotBufferedMargin, BigDecimal anNotBufferedMargin, String currentCap, String anCap) throws DataNotValidException;
	
	public void store(Margin margin) throws DataNotValidException;
	
	public void updateCurMar(Margin margin) throws DataNotValidException;
	
	public void update(Margin mar) throws DataNotValidException;
	
	public void logUpdate(Margin mar) throws DataNotValidException;
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException;
	
	public void resetAllUserMinMar(String divisCode) throws DataNotValidException;
	
	public void resetAllCashUserMinMar() throws DataNotValidException;
	
	public void update(int instrId, Timestamp inivDate, Timestamp endvDate, Timestamp sendDate, String status, 
		BigDecimal crMargin, BigDecimal crCover, int crNDaysPer, int crNv, String crVarType, BigDecimal anMargin, 
		BigDecimal anCover, int anNDaysPer, int anNv, String anVarType, BigDecimal userMargin, BigDecimal crMinMar, 
		BigDecimal anMinMar, BigDecimal userMinMar, Timestamp anDate, BigDecimal propCover, BigDecimal propMargin, 
		BigDecimal propMinMar, String approval, int rcCode, String comment, int classId, BigDecimal crNdMar, 
		BigDecimal anNdMar, String propose, String crLog, String anLog, String propLog, BigDecimal userCov, 
		BigDecimal rlMargin, Timestamp crFrstHisD, Timestamp anFrstHisD, Timestamp crLastHisD, 
	    Timestamp anLastHisD, String susp, String custom, String divisCode, BigDecimal currentMarginBuffer,  BigDecimal anMarginBuffer, 
	    BigDecimal currentNotBufferedMargin, BigDecimal anNotBufferedMargin, String currentCap, String anCap) throws DataNotValidException;
	
	public void remove(int instrId) throws DataNotValidException;
	/* method removeByInstrId - removes from the persistence unit a list of Historical Prices objects by entering instrId parameters */
	
	public int removeByClassId(int classId) throws DataNotValidException;
	
	public void remove(Margin mar) throws DataNotValidException;
}
