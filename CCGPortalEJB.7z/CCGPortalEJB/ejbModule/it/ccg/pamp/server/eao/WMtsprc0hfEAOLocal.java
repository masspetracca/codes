package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.WMtsprc0hf;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondIntracsPriceAndDate;

import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface WMtsprc0hfEAOLocal {
	public List<WMtsprc0hf> fetch() throws DataNotValidException;
	
	public List<WMtsprc0hf> getWMtsprc0hfToSync() throws DataNotValidException;
	
	public BondIntracsPriceAndDate findBondLastPrice(Instrument instr) throws DataNotValidException;
	
	public BondIntracsPriceAndDate findWMtsprc0hfBeforeLastDate(Instrument instr, Timestamp prDate) throws DataNotValidException;
	
	public WMtsprc0hf findByPrimaryKey(String pIsinc, long dateR) throws DataNotValidException;
	
	public List<WMtsprc0hf> findByIsinCode(String isinCode, long hDate) throws DataNotValidException;
	
	public WMtsprc0hf findBeforeDate(Instrument instr, Timestamp prDate) throws DataNotValidException;
	
	public WMtsprc0hf findBeforeDate(Instrument instr) throws DataNotValidException;
}
