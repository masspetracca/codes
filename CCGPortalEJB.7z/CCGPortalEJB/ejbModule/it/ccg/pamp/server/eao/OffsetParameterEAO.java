package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.OffsetParameter;
import it.ccg.pamp.server.entities.OffsetParameterPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class OffsetParameterEAO
 */
@Stateless
public class OffsetParameterEAO implements  OffsetParameterEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public OffsetParameter[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllOffsetPar");
    		List<OffsetParameter> offsetParameter = query.getResultList();
    		OffsetParameter[] arrOffsetParameter = new OffsetParameter[offsetParameter.size()];
    		return offsetParameter.toArray(arrOffsetParameter);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Offset Parameters - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public OffsetParameter findByPrimaryKey(int nDaysPer, int nv) throws DataNotValidException {
		try {
			OffsetParameterPK pK = new OffsetParameterPK();
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			OffsetParameter offsetParameter = (OffsetParameter) em.find(OffsetParameter.class,pK);
    		return offsetParameter;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Offset Parameter - nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public OffsetParameter[] findByStatus(String pStatus) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getOffsetParByStatus");
    		query.setParameter("pStatus", pStatus);
    		List<OffsetParameter> offsetParameter = query.getResultList();
    		OffsetParameter[] arrOffsetParameter = new OffsetParameter[offsetParameter.size()];
    		return offsetParameter.toArray(arrOffsetParameter);
    	}  catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Offset Parameters - status: "+pStatus+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActiveDelta() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getActiveDeltaForOffsetPar");
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active delta for Offset Parameters - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActivePeriods(int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getActivePeriodsForOffsetPar");
    		query.setParameter("delta", delta);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active periods for Offset Parameters - delta: "+delta+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getEnabledPeriods(int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledPeriodsForOffsetPar");
    		query.setParameter("delta", delta);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled periods Offset Parameters - delta: "+delta+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int nDaysPer, int nv, String pStatus) throws DataNotValidException {
		try {
			OffsetParameter offsetParameter = new OffsetParameter();
			OffsetParameterPK pK = new OffsetParameterPK();
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			offsetParameter.setPK(pK);
			offsetParameter.setPStatus(pStatus);
			offsetParameter.setUpdType(updType);
			offsetParameter.setUpdDate(GenericTools.systemDate());
			offsetParameter.setUpdUsr(userString());
			em.persist(offsetParameter);
			log.debug("Added new Offset Parameter - nDaysPer: "+nDaysPer+"; holding period:"+nv+"; status: "+pStatus);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Offset Parameter - nDaysPer: "+nDaysPer+"; holding period:"+nv+"; status: "+pStatus+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(OffsetParameter offsetParameter) throws DataNotValidException {
		try {
			offsetParameter.setUpdType(updType);
			offsetParameter.setUpdDate(GenericTools.systemDate());
			offsetParameter.setUpdUsr(userString());
			em.persist(offsetParameter);
			log.debug("Added new Offset Parameter - nDaysPer: "+offsetParameter.getPk().getNDaysPer()+"; holding period:"+offsetParameter.getPk().getNv()+"; status: "+offsetParameter.getPStatus());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Offset Parameter - nDaysPer: "+offsetParameter.getPk().getNDaysPer()+"; holding period:"+offsetParameter.getPk().getNv()+"; status: "+offsetParameter.getPStatus()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int nDaysPer, int nv, String pStatus) throws DataNotValidException {
		try {
			OffsetParameter offsetParameter = findByPrimaryKey(nDaysPer, nv);
			offsetParameter.setPStatus(pStatus);
			offsetParameter.setUpdType("U");
			offsetParameter.setUpdDate(GenericTools.systemDate());
			offsetParameter.setUpdUsr(userString());
			log.debug("Offset Parameter updated - nDaysPer: "+nDaysPer+"; holding period:"+nv+"; status: "+pStatus);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Offset Parameter - nDaysPer: "+nDaysPer+"; holding period:"+nv+"; status: "+pStatus+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(OffsetParameter classParam) throws DataNotValidException {
		try {
			OffsetParameter offsetParameter = findByPrimaryKey(classParam.getPk().getNDaysPer(), classParam.getPk().getNv());
			offsetParameter.setUpdType("U");
			offsetParameter.setUpdDate(GenericTools.systemDate());
			offsetParameter.setUpdUsr(userString());
			log.debug("Offset Parameter updated - nDaysPer: "+offsetParameter.getPk().getNDaysPer()+"; holding period:"+classParam.getPk().getNv()+"; status: "+classParam.getPStatus());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Offset Parameter - nDaysPer: "+classParam.getPk().getNDaysPer()+"; holding period:"+classParam.getPk().getNv()+"; status: "+classParam.getPStatus()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int nDaysPer, int nv) throws DataNotValidException {
		try {
			OffsetParameter offsetParameter = findByPrimaryKey(nDaysPer, nv);
			em.remove(offsetParameter);
		}  catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Offset Parameter - nDaysPer: "+nDaysPer+"; holding period:"+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(OffsetParameter classParam) throws DataNotValidException {
		remove(classParam.getPk().getNDaysPer(), classParam.getPk().getNv());
	}
}
