package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.InstrtypeTranscode;
import it.ccg.pamp.server.entities.InstrtypeTranscodePK;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class InstrtypeTranscodeEAO
 */
@Stateless
public class InstrtypeTranscodeEAO implements  InstrtypeTranscodeEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public InstrtypeTranscode[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllTrsCode");
    		List<InstrtypeTranscode> instrtypeTranscode = query.getResultList();
    		InstrtypeTranscode[] arrInstrtypeTranscode = new InstrtypeTranscode[instrtypeTranscode.size()];
    		return instrtypeTranscode.toArray(arrInstrtypeTranscode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from InstrtypeTranscode - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InstrtypeTranscode[] getTrsCodeByInstrType(String instrType) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getTrsCodeByInstrType");
    		query.setParameter("instrType", instrType);
    		List<InstrtypeTranscode> instrTypeTranscode = query.getResultList();
    		InstrtypeTranscode[] arrInstrTypeTranscode = new InstrtypeTranscode[instrTypeTranscode.size()];
    		return instrTypeTranscode.toArray(arrInstrTypeTranscode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from InstrtypeTranscode - instrType: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InstrtypeTranscode[] getTrsCodeBySicInstrType(String sicInstrTy) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getTrsCodeBySicInstrType");
    		query.setParameter("sicInstrTy", sicInstrTy);
    		List<InstrtypeTranscode> instrTypeTranscode = query.getResultList();
    		InstrtypeTranscode[] arrInstrTypeTranscode = new InstrtypeTranscode[instrTypeTranscode.size()];
    		return instrTypeTranscode.toArray(arrInstrTypeTranscode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from InstrtypeTranscode - sicInstrType: "+sicInstrTy+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InstrtypeTranscode getSingleTrsCodeBySicInstrType(String sicInstrTy) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getTrsCodeBySicInstrType");
    		query.setParameter("sicInstrTy", sicInstrTy);
    		List<InstrtypeTranscode> instrTypeTranscodeList = query.getResultList();
    		if (instrTypeTranscodeList.size() > 0) {
    			return instrTypeTranscodeList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from InstrtypeTranscode - sicInstrType: "+sicInstrTy+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InstrtypeTranscode findByPrimaryKey(String instrType, String sicInstrTy) throws DataNotValidException {
		try {
			InstrtypeTranscodePK pK = new InstrtypeTranscodePK();
			pK.setInstrType(instrType);			
			pK.setSicInstrTy(sicInstrTy);
			InstrtypeTranscode instrTypeTranscode = (InstrtypeTranscode) em.find(InstrtypeTranscode.class,pK);
    		return instrTypeTranscode;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from InstrtypeTranscode - instrType: "+instrType+"; sicInstrTy: "+sicInstrTy+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public LinkedHashMap<String, String> getTypeTrascodeMap() throws DataNotValidException {
		
		InstrtypeTranscode[] arrTypeTrsc = this.fetch();

		LinkedHashMap<String, String> typeTrascodeMap = new LinkedHashMap<String, String>();
		
		for (InstrtypeTranscode instrType:arrTypeTrsc) {
			typeTrascodeMap.put(instrType.getPk().getInstrType(), instrType.getPk().getSicInstrTy());
		}
		
		return typeTrascodeMap;
	}
	
}
