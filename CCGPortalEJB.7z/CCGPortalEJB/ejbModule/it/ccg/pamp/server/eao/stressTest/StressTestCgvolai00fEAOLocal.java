package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestCgvolai00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

import javax.ejb.Local;

@Local
public interface StressTestCgvolai00fEAOLocal {
	
	public List<StressTestCgvolai00f> fetch() throws DataNotValidException;
	
	public StressTestCgvolai00f findByPrimaryKey (Date srDate, String srIsin) throws DataNotValidException;
	
	public void update(Date srDate, String srIsin, BigDecimal srVola) throws DataNotValidException;
	
	public void store(StressTestCgvolai00f stressTestCgvolai00f) throws DataNotValidException;
	
	public int removeAll() throws DataNotValidException;
	
}
