package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.InterclassOffset;
import it.ccg.pamp.server.entities.InterclassOffsetHistory;
import it.ccg.pamp.server.entities.InterclassOffsetHistoryPK;
import it.ccg.pamp.server.entities.IntraclassOffsetHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class InterclassOffsetHistoryEAO
 */
@Stateless
@SuppressWarnings("unchecked")
public class InterClassOffsetHistoryEAO implements InterClassOffsetHistoryEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger logging = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	
	public InterclassOffsetHistory[] fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllInterclassOffsetHistory");
    		List<InterclassOffsetHistory> interclassOffsetHistory = query.getResultList();
    		InterclassOffsetHistory[] arrInterclassOffsetHistory = new InterclassOffsetHistory[interclassOffsetHistory.size()];
    		return interclassOffsetHistory.toArray(arrInterclassOffsetHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Interclass Offsets History - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InterclassOffsetHistory getLastSentInterClassOffset(int classId1, int classId2) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getLastSentInterClassOffset");
    		query.setParameter("classId1", classId1);
    		query.setParameter("classId2", classId2);
    		query.setMaxResults(1);
    		List<InterclassOffsetHistory> interClassOffsetHistoryList = query.getResultList();
    		if (interClassOffsetHistoryList.size()>0) {
    			return interClassOffsetHistoryList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last interclass offset history - classId1: "+classId1+"; classId2: "+classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<InterclassOffsetHistory> getInterClassOffsetHistoryToExport() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInterClassOffsetHistoryToExport");
    		query.setParameter("systemDate", GenericTools.systemDate());
    		List<InterclassOffsetHistory> interClassOffsetHistoryList = query.getResultList();
    		return interClassOffsetHistoryList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching interclass offset history to export - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<InterclassOffsetHistory> findByClassId1OrClassId2(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("findByClassId1OrClassId2");
    		query.setParameter("classId", classId);
    		List<InterclassOffsetHistory> interClassOffsetHistoryList = query.getResultList();
    		return interClassOffsetHistoryList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching interclass offset history by classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InterclassOffsetHistory findByPrimaryKey(int classId1, int classId2, Timestamp iniVDate) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getInterclassOffsetHistoryByPrimaryKey");
    		query.setParameter("classId1",classId1);
    		query.setParameter("classId2",classId2);
    		query.setParameter("iniVDate",iniVDate);
    		List<InterclassOffsetHistory> interclassOffsetHistoryList= query.getResultList();
    		if (interclassOffsetHistoryList.size()>0) {
    			return interclassOffsetHistoryList.get(0);
    		} else {
    			return null;
    		}
    		
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled Interclass Offsets History - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InterclassOffsetHistory[] findEnabledInterclassOffsetHistory() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllEnabledInterclassOffsetHistory");
    		List<InterclassOffsetHistory> interclassOffsetHistory = query.getResultList();
    		InterclassOffsetHistory[] arrInterclassOffsetHistory = new InterclassOffsetHistory[interclassOffsetHistory.size()];
    		return interclassOffsetHistory.toArray(arrInterclassOffsetHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled Interclass Offsets History - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InterclassOffsetHistory getCurrentInterclassOffsetHistory(int classId1, int classId2) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCurrentInterclassOffsetHistory");
    		query.setParameter("classId1", classId1);
    		query.setParameter("classId2", classId2);
    		query.setMaxResults(1);
    		List<InterclassOffsetHistory> interclassOffsetHistory = query.getResultList();
    		if (interclassOffsetHistory.size()>0) {
    			return interclassOffsetHistory.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching current Interclass Offset History - classId1: "+classId1+"; classId2: "+classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InterclassOffsetHistory[] findActiveInterclassOffsetHistory() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllActiveInterclassOffsetHistory");
    		List<InterclassOffsetHistory> interclassOffsetHistory = query.getResultList();
    		InterclassOffsetHistory[] arrInterclassOffsetHistory = new InterclassOffsetHistory[interclassOffsetHistory.size()];
    		return interclassOffsetHistory.toArray(arrInterclassOffsetHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active Interclass Offsets History - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActiveDeltaForInterclassOffsetHistory(int classId1, int classId2) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getActiveDeltaForInterclassOffsetHistory");
    		query.setParameter("classId1",classId1);
    		query.setParameter("classId2",classId2);
    		List<Integer> activeDeltaList = query.getResultList();
    		Integer[] arrActiveDelta = new Integer[activeDeltaList.size()];
    		activeDeltaList.toArray(arrActiveDelta);
    		return arrActiveDelta;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active delta for Interclass Offset History - classId1: "+classId1+"; classId2: "+classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActivePeriodsForInterclassOffsetHistory(int classId1, int classId2, int crNv) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getActivePeriodsForInterclassOffsetHistory");
    		query.setParameter("classId1",classId1);
    		query.setParameter("classId2",classId2);
    		query.setParameter("crNv",crNv);
    		List<Integer> activePeriodsList = query.getResultList();
    		Integer[] arrActivePeriods = new Integer[activePeriodsList.size()];
    		activePeriodsList.toArray(arrActivePeriods);
    		return arrActivePeriods;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active periods for Interclass Offset History - classId1: "+classId1+"; classId2: "+classId2+"; crNv: "+crNv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InterclassOffsetHistory[] findProposedInterclassOffsetHistory() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllProposedInterclassOffsetHistory");
    		List<InterclassOffsetHistory> interclassOffsetHistory = query.getResultList();
    		InterclassOffsetHistory[] arrInterclassOffsetHistory = new InterclassOffsetHistory[interclassOffsetHistory.size()];
    		return interclassOffsetHistory.toArray(arrInterclassOffsetHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching proposed Interclass Offset History - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void add(int classId1, int classId2, Timestamp iniVDate, Timestamp anDate, BigDecimal anOff, Timestamp apprDate,String approvedBy, String comment,
		Timestamp endVDate, String log, BigDecimal off, int rcCode, Timestamp sendDate, String sent, String susp, String status) throws DataNotValidException {
		
		try {
			InterclassOffsetHistoryPK pK = new InterclassOffsetHistoryPK();
			pK.setClassId1(classId1);
			pK.setClassId2(classId2);
			pK.setIniVDate(iniVDate);
			InterclassOffsetHistory interclassOffsetHistory = new InterclassOffsetHistory();
			interclassOffsetHistory.setPk(pK);
			interclassOffsetHistory.setAnDate(anDate);
			interclassOffsetHistory.setAnOff(anOff);
			interclassOffsetHistory.setApprDate(apprDate);
			interclassOffsetHistory.setApprovedBy(approvedBy);
			interclassOffsetHistory.setComment(comment);
			interclassOffsetHistory.setEndVDate(endVDate);
			interclassOffsetHistory.setLog(log);
			interclassOffsetHistory.setOff(off);
			interclassOffsetHistory.setRcCode(rcCode);
			interclassOffsetHistory.setSendDate(sendDate);
			interclassOffsetHistory.setSent(sent);
			interclassOffsetHistory.setSusp(susp);			
			interclassOffsetHistory.setUpdDate(GenericTools.systemDate());
			interclassOffsetHistory.setUpdType(updType);
			interclassOffsetHistory.setUpdUsr(userString());
			interclassOffsetHistory.setStatus(status);
			
			em.persist(interclassOffsetHistory);
			logging.debug("Added new Interclass Offset History - classId1: "+classId1+"; classId2: "+classId2+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Interclass Offset History - classId1: "+classId1+"; classId2: "+classId2+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(InterclassOffsetHistory interclassOffsetHistory) throws DataNotValidException {
		try { 
			interclassOffsetHistory.setUpdDate(GenericTools.systemDate());
			interclassOffsetHistory.setUpdType(updType);
			interclassOffsetHistory.setUpdUsr(userString());
			em.persist(interclassOffsetHistory);
			logging.debug("Added new Interclass Offset History - classId1: "+interclassOffsetHistory.getPk().getClassId1()+"; classId2: "+interclassOffsetHistory.getPk().getClassId2()+"; iniVDate: "+interclassOffsetHistory.getPk().getIniVDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Interclass Offset History - classId1: "+interclassOffsetHistory.getPk().getClassId1()+"; classId2: "+interclassOffsetHistory.getPk().getClassId2()+"; iniVDate: "+interclassOffsetHistory.getPk().getIniVDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(InterclassOffset interclassOffset) throws DataNotValidException {
		try {
			InterclassOffsetHistoryPK pK = new InterclassOffsetHistoryPK();
			
			pK.setClassId1(interclassOffset.getPk().getClassId1());
			pK.setClassId2(interclassOffset.getPk().getClassId2());
			pK.setIniVDate(interclassOffset.getIniVDate());
			InterclassOffsetHistory interclassOffsetHistory = new InterclassOffsetHistory();
			interclassOffsetHistory.setPk(pK);
			
			interclassOffsetHistory.setEndVDate(interclassOffset.getEndVDate());
			interclassOffsetHistory.setOff(interclassOffset.getPropOff());
			interclassOffsetHistory.setSent("F");
			interclassOffsetHistory.setSendDate(interclassOffset.getSendDate());
			
			interclassOffsetHistory.setApprovedBy(userString());
			interclassOffsetHistory.setApprDate(GenericTools.systemDate());
			interclassOffsetHistory.setAnOff(interclassOffset.getAnOff());
			interclassOffsetHistory.setAnDate(interclassOffset.getAnDate());
			
			interclassOffsetHistory.setRcCode(interclassOffset.getRcCode());
			interclassOffsetHistory.setComment(interclassOffset.getComment());
			interclassOffsetHistory.setLog(interclassOffset.getPropLog());
			interclassOffsetHistory.setSusp(interclassOffset.getSusp());
			
			interclassOffsetHistory.setUpdDate(GenericTools.systemDate());
			interclassOffsetHistory.setUpdType(updType);
			interclassOffsetHistory.setUpdUsr(userString());
			//interclassOffsetHistory.setStatus(interclassOffset.getStatus());
			
			if (interclassOffset.getPropose().equalsIgnoreCase("C")) {

				interclassOffsetHistory.setStatus("E");
			}
			// se il propose � A settiamo lo stato dello storico a
			// enabled
			else if (interclassOffset.getPropose().equalsIgnoreCase("A")) {

				interclassOffsetHistory.setStatus("E");
			}
			// mentre se il propose � a D settiamo lo stato dello
			// storico a disabilitato
			else if (interclassOffset.getPropose().equalsIgnoreCase("D")) {

				interclassOffsetHistory.setStatus("D");
			}
			
			
			em.persist(interclassOffsetHistory);
			logging.debug("Added new Interclass Offset History - classId1: "+interclassOffsetHistory.getPk().getClassId1()+"; classId2: "+interclassOffsetHistory.getPk().getClassId2()+"; iniVDate: "+interclassOffsetHistory.getPk().getIniVDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Interclass Offset History - classId1: "+interclassOffset.getPk().getClassId1()+"; classId2: "+interclassOffset.getPk().getClassId2()+"; iniVDate: "+interclassOffset.getIniVDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void logUpdate(InterclassOffsetHistory interclassOffsetHistory) throws DataNotValidException {
		try {
			//update(marHistory);
			logging.debug("Interclass Offset History History updated - classId1: "+interclassOffsetHistory.getPk().getClassId1()+"; classId2: "+interclassOffsetHistory.getPk().getClassId2()+"; iniVDate: "+interclassOffsetHistory.getPk().getIniVDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Interclass Offset History - classId1: "+interclassOffsetHistory.getPk().getClassId1()+"; classId2: "+interclassOffsetHistory.getPk().getClassId2()+"; iniVDate: "+interclassOffsetHistory.getPk().getIniVDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int classId1, int classId2, Timestamp iniVDate, Timestamp anDate, BigDecimal anOff, Timestamp apprDate,String approvedBy, String comment,
			Timestamp endVDate, String log, BigDecimal off, int rcCode, Timestamp sendDate, String sent, String susp, String status) throws DataNotValidException {
		
		try {
			InterclassOffsetHistory interclassOffsetHistory = findByPrimaryKey(classId1, classId2, iniVDate);
			interclassOffsetHistory.setAnDate(anDate);
			interclassOffsetHistory.setAnOff(anOff);
			interclassOffsetHistory.setApprDate(apprDate);
			interclassOffsetHistory.setApprovedBy(approvedBy);
			interclassOffsetHistory.setComment(comment);
			interclassOffsetHistory.setEndVDate(endVDate);
			interclassOffsetHistory.setLog(log);
			interclassOffsetHistory.setOff(off);
			interclassOffsetHistory.setRcCode(rcCode);
			interclassOffsetHistory.setSendDate(sendDate);
			interclassOffsetHistory.setSent(sent);
			interclassOffsetHistory.setSusp(susp);
			interclassOffsetHistory.setUpdDate(GenericTools.systemDate());
			interclassOffsetHistory.setUpdType("U");
			interclassOffsetHistory.setUpdUsr(userString());
			interclassOffsetHistory.setStatus(status);
			
			logging.debug("Interclass Offset History updated - classId1: "+classId1+"; classId2: "+classId2+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Interclass Offset History - classId1: "+classId1+"; classId2: "+classId2+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(InterclassOffsetHistory interclassOffsetHistory) throws DataNotValidException {
		try {
			logging.debug("Interclass Offset History updated - classId1: "+interclassOffsetHistory.getPk().getClassId1()+"; classId2: "+interclassOffsetHistory.getPk().getClassId2()+"; iniVDate: "+interclassOffsetHistory.getPk().getIniVDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Interclass Offset History - classId1: "+interclassOffsetHistory.getPk().getClassId1()+"; classId2: "+interclassOffsetHistory.getPk().getClassId2()+"; iniVDate: "+interclassOffsetHistory.getPk().getIniVDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int classId1, int classId2, Timestamp iniVDate) throws DataNotValidException {
		try {
			InterclassOffsetHistory interclassOffsetHistory = findByPrimaryKey(classId1, classId2, iniVDate);
			em.remove(interclassOffsetHistory);
			logging.debug("Interclass Offset History removed - classId1: "+classId1+"; classId2: "+classId2+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Interclass Offset History - classId1: "+classId1+"; classId2: "+classId2+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeInterClassOffsetByClass(int classId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteTerHisByClassId");
			query.setParameter("classId", classId);
			int result = query.executeUpdate();
			logging.debug(result+" Interclass Offsets History removed - classId1: "+classId+" OR classId2: "+classId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Interclass Offsets History - classId1: "+classId+" OR classId2: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeInterClassOffsetByClassEither(int classId1, int classId2) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteTerHisByClassIdEither");
			query.setParameter("classId1", classId1);
			query.setParameter("classId2", classId2);
			int result = query.executeUpdate();
			logging.debug(result+" Interclass Offsets History removed - classId1: "+classId1+"; classId2: "+classId2);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Interclass Offsets History - classId1: "+classId1+"; classId2: "+classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(InterclassOffsetHistory interclassOffsetHistory) throws DataNotValidException {
		remove(interclassOffsetHistory.getPk().getClassId1(),interclassOffsetHistory.getPk().getClassId2(),interclassOffsetHistory.getPk().getIniVDate());
	}
}
