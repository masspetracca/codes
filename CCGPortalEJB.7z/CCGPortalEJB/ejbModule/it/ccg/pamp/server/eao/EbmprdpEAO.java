package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Ebmprdp;
import it.ccg.pamp.server.entities.EbmprdpPK;
import it.ccg.pamp.server.entities.Mtsmgnf34f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class EbmprdpEAO
 */
@Stateless
public class EbmprdpEAO implements  EbmprdpEAOLocal {

	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	public List<Ebmprdp> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllEbmprdp");
    		List<Ebmprdp> ebmprdpList = query.getResultList();
    		return ebmprdpList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond prices - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public Ebmprdp findByPrimaryKey(String ebmCtyp, String ebmMktCd) throws DataNotValidException {
		try {
			EbmprdpPK pK = new EbmprdpPK();
			
			pK.setEbmCtyp(ebmCtyp);
			pK.setEbmMktCd(ebmMktCd);
			
			Ebmprdp ebmprdp = (Ebmprdp) em.find(Ebmprdp.class,pK);
    		return ebmprdp;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond price - isinCode: "+ebmCtyp+"; market: "+ebmMktCd+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
