package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.StraddleActivationDefault;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface StraddleActivationDefaultEAOLocal {
	public StraddleActivationDefault[] fetch() throws DataNotValidException;
	public StraddleActivationDefault findByPrimaryKey(int nDaysPer, int nv) throws DataNotValidException;
	
	
	public Integer[] getActiveDelta() throws DataNotValidException;
	public Integer[] getActivePeriods(int nv) throws DataNotValidException;
	public Integer[] getEnabledPeriods(int nv) throws DataNotValidException;
	
	public void add(int nDaysPer, int nv, String status) throws DataNotValidException;
	public void store(StraddleActivationDefault straddleActivationDefault) throws DataNotValidException;
	
	public void update(int nDaysPer, int nv, String status) throws DataNotValidException;
		
	public void remove(int nDaysPer, int nv) throws DataNotValidException;
	public void remove(StraddleActivationDefault straddleActivationDefault) throws DataNotValidException;
}
