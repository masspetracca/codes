package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.stressTest.StressTestDerivativeHistPrice;
import it.ccg.pamp.server.entities.stressTest.StressTestDerivativeHistPricePK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StressTestDerivativeHistPriceEAO
 */
@Stateless
public class StressTestDerivativeHistPriceEAO implements  StressTestDerivativeHistPriceEAOLocal {

	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	public List<StressTestDerivativeHistPrice> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllStressTestDerivativeHistPrices");
    		List<StressTestDerivativeHistPrice> stressTestDerivativeHistPriceList = query.getResultList();
    		return stressTestDerivativeHistPriceList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stressed prices for derivatives - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	
	public StressTestDerivativeHistPrice findByPrimaryKey(int instrId, int expiry, String scenario, int stId, String pc, BigDecimal strike) throws DataNotValidException {
		try {
			StressTestDerivativeHistPricePK pK = new StressTestDerivativeHistPricePK();
			pK.setInstrId(instrId);
			pK.setExpiry(expiry);
			pK.setStId(stId);
			pK.setScenario(scenario);
			pK.setPc(pc);
			pK.setStrike(strike);
			StressTestDerivativeHistPrice stressTestDerivativeHistPrice = (StressTestDerivativeHistPrice) em.find(StressTestDerivativeHistPrice.class,pK);
    		return stressTestDerivativeHistPrice;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stressed prices for derivatives - instrId: "+instrId+"; expiry: "+expiry+"; stress test id: "+stId+"; scenario: "+scenario+"; pc: "+pc+"; strike: "+strike+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestDerivativeHistPrice> getStressTestHistPricesByStId(int stId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestDerivativeHistPricesByStId");
    		query.setParameter("stId", stId);
    		List<StressTestDerivativeHistPrice> stressTestDerivativeHistPriceList = query.getResultList();
    		return stressTestDerivativeHistPriceList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stressed prices for derivatives - stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Integer getLastStressTestId(String scenario) throws DataNotValidException {
		String strScenario = "increase";
		
		if (scenario.equalsIgnoreCase("d")) {
			strScenario = "decrease";
		}
		
		Query query = null;
    	try {
    		query = em.createNamedQuery("getLastDerivativeStressTestId");
    		query.setParameter("scenario", scenario);
    		List<Integer> lastStressTestId = query.getResultList();
    		if (lastStressTestId.size()>0) {
    			return lastStressTestId.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last stress test id - scenario: "+strScenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestDerivativeHistPrice> getStressTestDerivativeHistPricesByStIdAndScenario(int stId, String scenario) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestDerivativeHistPricesByStIdAndScenario");
    		query.setParameter("stId", stId);
    		query.setParameter("scenario", scenario);
    		List<StressTestDerivativeHistPrice> stressTestDerivativeHistPriceList = query.getResultList();
    		return stressTestDerivativeHistPriceList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stressed prices for derivatives - stress test id: "+stId+"; scenario: "+scenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<StressTestDerivativeHistPrice> getStressTestDerivativeHistPricesByInstrIdAndStIdAndScenario(int instrId, int stId, String scenario) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestDerivativeHistPricesByStIdAndScenario");
    		query.setParameter("instrId", instrId);
    		query.setParameter("stId", stId);
    		query.setParameter("scenario", scenario);
    		List<StressTestDerivativeHistPrice> stressTestDerivativeHistPriceList = query.getResultList();
    		return stressTestDerivativeHistPriceList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stressed prices for derivatives - instrId: "+instrId+"; stress test id: "+stId+"; scenario: "+scenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestDerivativeHistPrice> getStressTestDerivativeHistPriceToExport(int stId, String scenario) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestDerivativeHistPriceToExport");
    		query.setParameter("stId", stId);
    		query.setParameter("scenario", scenario);
    		List<StressTestDerivativeHistPrice> stressTestDerivativeHistPriceList = query.getResultList();
    		return stressTestDerivativeHistPriceList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stressed prices for derivatives ready to export - stress test id: "+stId+"; scenario: "+scenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, Timestamp priceDate, int expiry, int stId, String scenario, String pc, BigDecimal strike, BigDecimal closePr, BigDecimal closePrSt, int nDaysPer, BigDecimal impVola, String code, String log, String sent, String status, String atm, String atmSt, int shift, BigDecimal impVolaSt) throws DataNotValidException {
		
		try {
			StressTestDerivativeHistPrice stressTestDerivativeHistPrice = new StressTestDerivativeHistPrice();
			StressTestDerivativeHistPricePK pK = new StressTestDerivativeHistPricePK();
			
			pK.setInstrId(instrId);
			
			pK.setExpiry(expiry);
			pK.setStId(stId);
			pK.setScenario(scenario);
			pK.setPc(pc);
			pK.setStrike(strike);
			
			stressTestDerivativeHistPrice.setPk(pK);
			
			stressTestDerivativeHistPrice.setPriceDate(priceDate);
			stressTestDerivativeHistPrice.setClosePr(closePr);
			stressTestDerivativeHistPrice.setClosePrSt(closePrSt);
			stressTestDerivativeHistPrice.setNDaysPer(nDaysPer);
			stressTestDerivativeHistPrice.setImpVola(impVola);
			stressTestDerivativeHistPrice.setCode(code);
			stressTestDerivativeHistPrice.setLog(log);
			stressTestDerivativeHistPrice.setSent(sent);
			stressTestDerivativeHistPrice.setStatus(status);
			stressTestDerivativeHistPrice.setAtm(atm);
			stressTestDerivativeHistPrice.setAtmSt(atmSt);
			stressTestDerivativeHistPrice.setShift(shift);
			stressTestDerivativeHistPrice.setImpVolaSt(impVolaSt);
			
			stressTestDerivativeHistPrice.setUpdType(updType);
			stressTestDerivativeHistPrice.setUpdDate(GenericTools.systemDate());
			stressTestDerivativeHistPrice.setUpdUsr(userString());
			
			em.persist(stressTestDerivativeHistPrice);
			userLog.debug("Added new stressed price for derivatives - instrId: "+instrId+"; priceDate: "+priceDate+"; expiry: "+expiry+"; stress test id: "+stId+"; scenario: "+scenario+"; pc: "+pc+"; price: "+closePr+"; stressed price: "+closePrSt);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stressed price for derivatives - instrId: "+instrId+"; priceDate: "+priceDate+"; expiry: "+expiry+"; stress test id: "+stId+"; scenario: "+scenario+"; pc: "+pc+"; price: "+closePr+"; stressed price: "+closePrSt+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(StressTestDerivativeHistPrice stressTestDerivativeHistPrice) throws DataNotValidException {
		
		try {
			stressTestDerivativeHistPrice.setUpdType(updType);
			stressTestDerivativeHistPrice.setUpdDate(GenericTools.systemDate());
			stressTestDerivativeHistPrice.setUpdUsr(userString());
			em.persist(stressTestDerivativeHistPrice);
			userLog.debug("Added new stressed price for derivatives - instrId: "+stressTestDerivativeHistPrice.getPk().getInstrId()+"; priceDate: "+stressTestDerivativeHistPrice.getPriceDate()+"; stress test id: "+stressTestDerivativeHistPrice.getPk().getStId()+"; scenario: "+stressTestDerivativeHistPrice.getPk().getScenario()+"; price: "+stressTestDerivativeHistPrice.getClosePr()+"; stressed price: "+stressTestDerivativeHistPrice.getClosePrSt());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stressed price for derivatives - instrId: "+stressTestDerivativeHistPrice.getPk().getInstrId()+"; priceDate: "+stressTestDerivativeHistPrice.getPriceDate()+"; stress test id: "+stressTestDerivativeHistPrice.getPk().getStId()+"; scenario: "+stressTestDerivativeHistPrice.getPk().getScenario()+"; pc: "+stressTestDerivativeHistPrice.getPk().getPc()+"; price: "+stressTestDerivativeHistPrice.getClosePr()+"; stressed price: "+stressTestDerivativeHistPrice.getClosePrSt()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, Timestamp priceDate, int expiry, int stId, String scenario, String pc, BigDecimal strike, BigDecimal closePr, BigDecimal closePrSt, int nDaysPer, BigDecimal impVola, String code, String log, String sent, String status, String atm, String atmSt, int shift, BigDecimal impVolaSt) throws DataNotValidException {
		
		try {
			StressTestDerivativeHistPrice stressTestDerivativeHistPrice = this.findByPrimaryKey(instrId, expiry, scenario, stId, pc, strike);
			
			stressTestDerivativeHistPrice.setClosePr(closePr);
			stressTestDerivativeHistPrice.setClosePrSt(closePrSt);
			stressTestDerivativeHistPrice.setNDaysPer(nDaysPer);
			stressTestDerivativeHistPrice.setImpVola(impVola);
			stressTestDerivativeHistPrice.setCode(code);
			stressTestDerivativeHistPrice.setLog(log);
			stressTestDerivativeHistPrice.setSent(sent);
			stressTestDerivativeHistPrice.setStatus(status);
			stressTestDerivativeHistPrice.setAtm(atm);
			stressTestDerivativeHistPrice.setAtmSt(atmSt);
			stressTestDerivativeHistPrice.setShift(shift);
			stressTestDerivativeHistPrice.setImpVolaSt(impVolaSt);
			
			stressTestDerivativeHistPrice.setUpdType("U");
			stressTestDerivativeHistPrice.setUpdDate(GenericTools.systemDate());
			stressTestDerivativeHistPrice.setUpdUsr(userString());
			
			em.persist(stressTestDerivativeHistPrice);
			userLog.debug("Updated stressed price for derivatives - instrId: "+instrId+"; priceDate: "+priceDate+"; expiry: "+expiry+"; stress test id: "+stId+"; scenario: "+scenario+"; pc: "+pc+"; price: "+closePr+"; stressed price: "+closePrSt);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stressed price for derivatives - instrId: "+instrId+"; priceDate: "+priceDate+"; expiry: "+expiry+"; stress test id: "+stId+"; scenario: "+scenario+"; pc: "+pc+"; price: "+closePr+"; stressed price: "+closePrSt+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(StressTestDerivativeHistPrice stressTestDerivativeHistPrice) throws DataNotValidException {
		
		try {
			userLog.debug("Updated stressed price for derivatives - instrId: "+stressTestDerivativeHistPrice.getPk().getInstrId()+"; priceDate: "+stressTestDerivativeHistPrice.getPriceDate()+"; stress test id: "+stressTestDerivativeHistPrice.getPk().getStId()+"; scenario: "+stressTestDerivativeHistPrice.getPk().getScenario()+"; price: "+stressTestDerivativeHistPrice.getClosePr()+"; pc: "+stressTestDerivativeHistPrice.getPk().getPc()+"; stressed price: "+stressTestDerivativeHistPrice.getClosePrSt());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stressed price for derivatives - instrId: "+stressTestDerivativeHistPrice.getPk().getInstrId()+"; priceDate: "+stressTestDerivativeHistPrice.getPriceDate()+"; stress test id: "+stressTestDerivativeHistPrice.getPk().getStId()+"; scenario: "+stressTestDerivativeHistPrice.getPk().getScenario()+"; pc: "+stressTestDerivativeHistPrice.getPk().getPc()+"; price: "+stressTestDerivativeHistPrice.getClosePr()+"; stressed price: "+stressTestDerivativeHistPrice.getClosePrSt()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int updateSentStatusAfterExport(int instrId, int stId, String scenario) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("updateSentStatusAfterExport");
			query.setParameter("stId", stId);
			query.setParameter("instrId", instrId);
			query.setParameter("scenario", scenario);
			query.setParameter("sysDate", GenericTools.systemDate());
			int result = query.executeUpdate();
			userLog.debug(result+" stressed derivative historical prices updated - instrId: "+instrId+"; stId: "+stId+"; scenario: "+scenario);
			return result;
		 } catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updated derivative stressed historical prices - instrId: "+instrId+"; stId: "+stId+"; scenario: "+scenario+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteStressTestDerivativeHistPricesByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			userLog.debug(result+" stressed derivative historical prices removed - instrId: "+instrId);
			return result;
		 } catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing derivative stressed historical prices - instrId: "+instrId+";  - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public String resetEqDerStSentStatus(int stId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("resetEqDerStSentStatus");
			query.setParameter("lastStId", stId);
			int result = query.executeUpdate();
			userLog.debug(result+" stressed derivative historical prices sent status resetted - stId: "+stId);
			return result+" stressed derivative historical prices sent status resetted - stId: "+stId;
		 	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error resetting stressed derivative historical prices sent status - stId: "+stId+";  - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, Timestamp priceDate, int expiry, int stId, String scenario, String pc, BigDecimal strike) throws DataNotValidException {
		try {
			StressTestDerivativeHistPrice stressTestDerivativeHistPrice = this.findByPrimaryKey(instrId, expiry, scenario, stId, pc, strike);
			em.remove(stressTestDerivativeHistPrice);
			userLog.debug("Stressed price removed for derivatives - instrId: "+instrId+"; priceDate: "+priceDate+"; stress test id: "+stId+"; scenario: "+scenario+"; pc: "+pc);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stressed price for derivatives - instrId: "+instrId+"; priceDate: "+priceDate+"; stress test id: "+stId+"; scenario: "+scenario+"; pc: "+pc+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(StressTestDerivativeHistPrice stressTestDerivativeHistPrice) throws DataNotValidException {
		this.remove(stressTestDerivativeHistPrice.getPk().getInstrId(), stressTestDerivativeHistPrice.getPriceDate(), stressTestDerivativeHistPrice.getPk().getExpiry(), stressTestDerivativeHistPrice.getPk().getStId(), stressTestDerivativeHistPrice.getPk().getScenario(), stressTestDerivativeHistPrice.getPk().getPc(),stressTestDerivativeHistPrice.getPk().getStrike());
	}

}
