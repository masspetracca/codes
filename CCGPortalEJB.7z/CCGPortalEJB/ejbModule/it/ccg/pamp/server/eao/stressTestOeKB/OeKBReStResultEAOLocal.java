package it.ccg.pamp.server.eao.stressTestOeKB;

import it.ccg.pamp.server.entities.stressTestOeKB.OeKBReStResult;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.OeKBReMembers;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;

@Local
public interface OeKBReStResultEAOLocal {
	
	public List<OeKBReStResult> fetch() throws DataNotValidException;
	
	public OeKBReStResult findByPrimaryKey(String pFolioId, BigDecimal uMbr) throws DataNotValidException;
	
	public List<OeKBReMembers> findFromLastStressTestId(int lastStressTestId, String scenario) throws DataNotValidException;

}
