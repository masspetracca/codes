package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.entities.NodeCurve;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class NodeCurveEAO
 */
@Stateless
public class NodeCurveEAO implements NodeCurveEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public List<NodeCurve> fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllCurves");
    		List<NodeCurve> curveList = query.getResultList();
    		return curveList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching curves - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public NodeCurve findByPrimaryKey(String curveName) throws DataNotValidException {
		try {
			NodeCurve nodeCurve = (NodeCurve) em.find(NodeCurve.class,curveName);
    		return nodeCurve;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching curve - name: "+curveName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<NodeCurve> findEnabledCurves() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllEnabledCurves");
    		List<NodeCurve> curveList = query.getResultList();
    		return curveList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled curves - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public void add(String curveName, String curveDesc, String status, String divisCode) throws DataNotValidException {
		
		String logString = "name: "+curveName+"; description: "+curveDesc+"; status: "+status+"; division: "+divisCode;
		
		try {
			NodeCurve curve = new NodeCurve();
			curve.setCurveName(curveName);
			curve.setCurveDesc(curveDesc);
			curve.setStatus(status);
			curve.setDivisCode(divisCode);
			em.persist(curve);
			log.debug("Added new curve - "+logString);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new curve - "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(NodeCurve curve) throws DataNotValidException {
		
		String logString = "name: "+curve.getCurveName()+"; description: "+curve.getCurveDesc()+"; status: "+curve.getStatus()+"; division: "+curve.getDivisCode();
		
		try {
			curve.setUpdDate(GenericTools.systemDate());
			curve.setUpdType(updType);
			curve.setUpdUsr(userString());
			em.persist(curve);
			log.debug("Added new curve - "+logString);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new curve - "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(String curveName, String curveDesc, String status, String divisCode) throws DataNotValidException {
		String logString = curveName+" - description: "+curveDesc+"; status: "+status+"; division: "+divisCode;
		try {
			NodeCurve curve = this.findByPrimaryKey(curveName);
			curve.setCurveDesc(curveDesc);
			curve.setStatus(status);
			curve.setDivisCode(divisCode);
			curve.setUpdDate(GenericTools.systemDate());
			curve.setUpdType("U");
			curve.setUpdUsr(userString());
			log.debug("Updated curve "+logString);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating curve "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(String curveName) throws DataNotValidException {
		try {
			NodeCurve curve = this.findByPrimaryKey(curveName);
			em.remove(curve);
			log.debug("Curve "+curveName+" removed");
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing curve "+curveName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
			
	public void remove(NodeCurve curve) throws DataNotValidException {
		remove(curve.getCurveName());
	}
	
}
