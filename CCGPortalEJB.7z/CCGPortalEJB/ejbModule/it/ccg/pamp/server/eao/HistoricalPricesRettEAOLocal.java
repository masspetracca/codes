package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.HistoricalPricesRett;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.HistPricesRettDates;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.ejb.Local;

@Local
public interface HistoricalPricesRettEAOLocal {
public HistoricalPricesRett[] fetch() throws DataNotValidException;
	
	public HistoricalPricesRett findByPrimaryKey(int instrId, Timestamp priceDate) throws DataNotValidException;
	
	public HistoricalPricesRett[] findJustBeforeDate(int instrId, Timestamp nearDate) throws DataNotValidException;
	
	public HistoricalPricesRett findLastDate() throws DataNotValidException;
	
	public HistoricalPricesRett findFirstDate() throws DataNotValidException;
	
	public HistoricalPricesRett findBeforeLastDate(int instrId, Timestamp lastDate) throws DataNotValidException;
	
	public int getTimeWindow(int instrId, Timestamp firstDate, Timestamp lastDate) throws DataNotValidException;
	
	public HistPricesRettDates findFirstAndLastDateByInstrId(int instrId) throws DataNotValidException;
	
	public HistPricesRettDates findFirstAndLastDateByClassId(int classId) throws DataNotValidException;
	
	public HistoricalPricesRett findLastDateByInstrument(int instrId) throws DataNotValidException;
	
	public HistoricalPricesRett findFirstDateByInstrument(int instrId) throws DataNotValidException;
	
	public HistPricesRettDates findFirstAndLastDateByClassId1AndClassId2(int classId1,int classId2) throws DataNotValidException;
	
	public HistoricalPricesRett[] findJustAfterDate(int instrId, Timestamp nearDate) throws DataNotValidException;
	
	public HistoricalPricesRett[] findByInstrId(int instrId) throws DataNotValidException;
	
	public HistoricalPricesRett[] findByInstrIdAndDate(int instrId, Timestamp firstDate, Timestamp lastDate) throws DataNotValidException;
	
	public void add(int instrId, Timestamp priceDate, BigDecimal closePrRet, String status) throws DataNotValidException;
	
	public void store(HistoricalPricesRett historicalPricesRett) throws DataNotValidException;
	
	public void update(int instrId, Timestamp priceDate, BigDecimal closePrRet, String status) throws DataNotValidException;
	
	public void update(HistoricalPricesRett histPricesRett) throws DataNotValidException;
	
	public void remove(int instrId, Timestamp priceDate) throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
	public void remove(HistoricalPricesRett histPricesRett) throws DataNotValidException;
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException;
	
	public void flush();
}
