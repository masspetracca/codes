package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.MarginExportLog;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface MarginExportLogEAOLocal {

	public List<MarginExportLog> fetch() throws DataNotValidException;
	
    public void store(MarginExportLog marginExportLog) throws DataNotValidException;
    
    public void upsert(MarginExportLog marginExportLog) throws DataNotValidException;
	
}
