package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestMember;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface StressTestMemberEAOLocal {

	public List<StressTestMember> fetch() throws DataNotValidException;
	
	public StressTestMember findByPrimaryKey(int mbrId, String scenario, int stId) throws DataNotValidException;
	
	public List<StressTestMember> getStressTestMemberByMbrId(int mbrId) throws DataNotValidException;
	
	public List<StressTestMember> getStressTestMemberByStId(int stId) throws DataNotValidException;
	
	public List<StressTestMember> getStressTestMemberByScenario(String scenario) throws DataNotValidException;
	
	public List<StressTestMember> getStressTestMemberByMbrIdAndStId(int mbrId, int stId) throws DataNotValidException;
	
	public List<StressTestMember> getStressTestMemberByStIdAndScenario(int stId, String scenario) throws DataNotValidException;
	
	public List<StressTestMember> getStressTestMemberByMbrIdAndScenario(int mbrId, String scenario) throws DataNotValidException;
	
	public String getMemberReportForMail(String divisCode) throws DataNotValidException;
	
	public void add(int mbrId, String scenario, int stId, BigDecimal cnrMmar, BigDecimal cStrMar, String gMbrDesc, int gMbrId, Timestamp histUpdDay,
			BigDecimal hnrMmar, BigDecimal hStrMar, String log, String mbrDesc, BigDecimal nce, int nDaysPer, String nvVec, BigDecimal ordMargin, BigDecimal mtmMargin, BigDecimal mia) throws DataNotValidException;
	
	public void store(StressTestMember stressTestMember) throws DataNotValidException;
	
	public void update(int mbrId, String scenario, int stId, BigDecimal cnrMmar, BigDecimal cStrMar, String gMbrDesc, int gMbrId, Timestamp histUpdDay,
			BigDecimal hnrMmar, BigDecimal hStrMar, String log, String mbrDesc, BigDecimal nce, int nDaysPer, String nvVec, BigDecimal ordMargin, BigDecimal mtmMargin, BigDecimal mia) throws DataNotValidException;
	
	public void update(StressTestMember stressTestMember) throws DataNotValidException;
	
	public void remove(int mbrId, String scenario, int stId) throws DataNotValidException;
	
	public int removeByMbrId(int mbrId) throws DataNotValidException;
	
	public int removeByStId(int stId) throws DataNotValidException;
	
	public int removeByScenario(String scenario) throws DataNotValidException;
	
	public int removeByMbrIdAndStId(int mbrId, int stId) throws DataNotValidException;
	
	public int removeByMbrIdAndScenario(int mbrId, String scenario) throws DataNotValidException;
	
	public int removeByStIdAndScenario(int stId, String scenario) throws DataNotValidException;
	
	public void remove(StressTestMember stressTestMember) throws DataNotValidException;
	
}
