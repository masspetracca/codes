package it.ccg.pamp.server.eao.backTest;

import it.ccg.pamp.server.entities.backTest.BackTestBreach;
import it.ccg.pamp.server.entities.backTest.BackTestBreachPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.Correlation;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BackTestBreachEAO
 */
@Stateless
public class BackTestBreachEAO implements BackTestBreachEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}

	public String userString = "System";
	public String updType = "C";
	
	
	
	public List<BackTestBreach> fetchAllBackTestBreach() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllBackTestBreach");
    		List<BackTestBreach> backTestList = query.getResultList();
    		return backTestList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test breach list - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	public List<BackTestBreach> getBackTestBreachByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBackTestBreachByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<BackTestBreach> backTestBreachList = query.getResultList();
    		return backTestBreachList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test breach list - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<BackTestBreach> getBackTestBreachByBtId(int btId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBackTestBreachByBtId");
    		query.setParameter("btId", btId);
    		List<BackTestBreach> backTestBreachList = query.getResultList();
    		return backTestBreachList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test breach list - back test id: "+btId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<BackTestBreach> getBackTestBreachByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBackTestBreachByInstrId");
    		query.setParameter("instrId", instrId);
    		List<BackTestBreach> backTestBreachList = query.getResultList();
    		return backTestBreachList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test breach list - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public List<BackTestBreach> getBackTestBreachByClassIdOrderByUsrMar(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBackTestBreachByClassIdOrderByUsrMar");
    		query.setParameter("classId", classId);
    		List<BackTestBreach> backTestBreachList = query.getResultList();
    		return backTestBreachList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test breach list - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
	public List<BackTestBreach> getBackTestBreachByClassIdOrderByUsrMar(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		
    		String sqlString = "SELECT * FROM PMPTBTBRCH ";
    		
    		sqlString += " WHERE CLASSID = "+classId; 
    		sqlString += " ORDER BY ABS(USRMAR) DESC";
    		
    		query =  em.createNativeQuery(sqlString,BackTestBreach.class);
    		
    		List<BackTestBreach> backTestBreachList = query.getResultList();
    		
    		return backTestBreachList;
    	    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test breach list - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public BackTestBreach findByPrimaryKey(int btId, int nv, int classId, int instrId, Timestamp priceDate) throws DataNotValidException {
		try {
    		
			BackTestBreachPK pK = new BackTestBreachPK();
			
			pK.setBtId(btId);
			pK.setNv(nv);
			pK.setClassId(classId);
			pK.setInstrId(instrId);
			pK.setPriceDate(priceDate);
			
			BackTestBreach backTestBreach = (BackTestBreach) em.find(BackTestBreach.class,pK);
    		
			return backTestBreach;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test breach - backTestId: "+btId+"; holding period: "+nv+"; classId: "+classId+"; instrId: "+instrId+"; price date: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void add(int btId, int nv, int classId, int instrId, Timestamp priceDate, String divisCode, String log, String status, BigDecimal usrCov, BigDecimal usrMar, int usrDays, BigDecimal closePr, BigDecimal pClosePr, int usrBrch) throws DataNotValidException {
		
		try {
			BackTestBreach backTestBreach = new BackTestBreach();
			
			BackTestBreachPK pK = new BackTestBreachPK();
			
			pK.setBtId(btId);
			pK.setNv(nv);
			pK.setClassId(classId);
			pK.setInstrId(instrId);
			pK.setPriceDate(priceDate);
			
			backTestBreach.setPk(pK);
			
			backTestBreach.setDivisCode(divisCode);
			backTestBreach.setLog(log);
			backTestBreach.setStatus(status);
			
			backTestBreach.setUsrCov(usrCov);
			backTestBreach.setUsrMar(usrMar);
			backTestBreach.setUsrDays(usrDays);
			
			backTestBreach.setClPrice(closePr);
			backTestBreach.setPClPrice(pClosePr);
			
			backTestBreach.setUpdDate(GenericTools.systemDate());
			backTestBreach.setUpdType("C");
			backTestBreach.setUpdUsr(userString());
			
			backTestBreach.setUsrBrch(usrBrch);
			
			em.persist(backTestBreach);
			
			userLog.debug("Added new back test breach - back test id: "+btId+"; holding period: "+nv+"; classId: " +classId+"; instrId: "+instrId);
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new back test breach - back test id: "+btId+"; holding period: "+nv+"; classId: "+classId+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	
	public void store(BackTestBreach backTestBreach) throws DataNotValidException {
		
		try {
			
			backTestBreach.setUpdDate(GenericTools.systemDate());
			backTestBreach.setUpdType("C");
			backTestBreach.setUpdUsr(userString());
			
			em.persist(backTestBreach);
			
			userLog.debug("Added new back test breach - back test id: "+backTestBreach.getPk().getBtId()+"; holding period: "+backTestBreach.getPk().getNv()+"; classId: "+backTestBreach.getPk().getClassId()+"; instrId: "+backTestBreach.getPk().getInstrId());
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new back test breach - back test id: "+backTestBreach.getPk().getBtId()+"; holding period: "+backTestBreach.getPk().getNv()+"; classId: "+backTestBreach.getPk().getClassId()+"; instrId: "+backTestBreach.getPk().getInstrId()+ " - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	
	public void update(int btId, int nv, int classId, int instrId, Timestamp priceDate, String divisCode, String log, String status, BigDecimal usrCov, BigDecimal usrMar, int usrDays, BigDecimal closePr, BigDecimal pClosePr, int usrBrch) throws DataNotValidException {
		
		try {
			BackTestBreach backTestBreach = this.findByPrimaryKey(btId, nv, classId, instrId, priceDate);
			
			backTestBreach.setDivisCode(divisCode);
			backTestBreach.setLog(log);
			backTestBreach.setStatus(status);
			
			backTestBreach.setUsrCov(usrCov);
			backTestBreach.setUsrMar(usrMar);
			backTestBreach.setUsrDays(usrDays);
			
			backTestBreach.setClPrice(closePr);
			backTestBreach.setPClPrice(pClosePr);
			
			backTestBreach.setUpdDate(GenericTools.systemDate());
			backTestBreach.setUpdType("U");
			backTestBreach.setUpdUsr(userString());
			
			backTestBreach.setUsrBrch(usrBrch);
			
			userLog.debug("Updated back test breach - back test id: "+btId+"; holding period: "+nv+"; classId: " +classId+"; instrId: "+instrId);
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating back test breach - back test id: "+btId+"; holding period: "+nv+"; classId: "+classId+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	
	public void remove(int btId, int nv, int classId, int instrId, Timestamp priceDate) throws DataNotValidException {
		
		try {
			BackTestBreach backTestBreach = this.findByPrimaryKey(btId, nv, classId, instrId, priceDate);
			
			em.remove(backTestBreach);
			
			userLog.debug("Removed back test breach - back test id: "+btId+"; holding period: "+nv+"; classId: " +classId+"; instrId: "+instrId);
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing back test breach - back test id: "+btId+"; holding period: "+nv+"; classId: " +classId+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	
	public void remove(BackTestBreach backTestBreach) throws DataNotValidException {
		
		this.remove(backTestBreach.getPk().getBtId(),backTestBreach.getPk().getNv(),backTestBreach.getPk().getClassId(),backTestBreach.getPk().getInstrId(),backTestBreach.getPk().getPriceDate());
		
		//em.remove(backTestBreach);
		
	}
	
	public void removeAll() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("removeAllBreaches");
    		int i = query.executeUpdate();
    		userLog.debug(i+" back test breaches removed");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing all back test breaches - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
