package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ClassHaircut;
import it.ccg.pamp.server.entities.Margin;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class HaircutClassEAO
 */
@Stateless
public class ClassHaircutEAO implements ClassHaircutEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public List<ClassHaircut> fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllClassHaircut");
    		List<ClassHaircut> classHaircutList = query.getResultList();
    		return classHaircutList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching haircut classes - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ClassHaircut findByPrimaryKey(int classId) throws DataNotValidException {
		try {
			ClassHaircut classHaircut = (ClassHaircut) em.find(ClassHaircut.class,classId);
    		return classHaircut;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching haircut class - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ClassHaircut> findEnabledHaircutClass() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllEnabledClassHaircut");
    		List<ClassHaircut> classHaircutList = query.getResultList();
    		return classHaircutList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled haircut classes - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ClassHaircut> findEnabledHaircutClassByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getEnabledClassHaircutByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<ClassHaircut> classHaircutList = query.getResultList();
    		return classHaircutList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled haircut classes - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public boolean noHaircutSubmittedForApproval() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSubmittedForApprovalHaircut");
    		List<ClassHaircut> classHaircutList = query.getResultList();
    		if (classHaircutList.size()>0) {
    			return false;
    		} else {
    			return true;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching submitted margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int classId, BigDecimal anCap, BigDecimal anCover, Timestamp anDate, BigDecimal anFloor, Timestamp anFrstHisD, BigDecimal anHct, Timestamp anLastHisD,
		String anLog, BigDecimal anMargin, BigDecimal anMult, int anNDaysPer, int anNodeId, String anNodes, int anNv, BigDecimal anRlHct,
		String approval, String comment, BigDecimal crCap, BigDecimal crCover, BigDecimal crFloor, Timestamp crFrstHisD, BigDecimal crHct, Timestamp crLastHisD,
		String crLog, BigDecimal crMargin, BigDecimal crMult, int crNDaysPer, int crNodeId, String crNodes, int crNv, BigDecimal crRlHct,
		String custom, String divisCode, Timestamp endVDate, Timestamp iniVDate, BigDecimal propHct, String propLog, String propose, int rcCode,
		Timestamp sendDate, String status, String susp, BigDecimal userHct, BigDecimal anAddend, BigDecimal crAddend) throws DataNotValidException {
		
		String logString = "classID: "+classId+"; status: "+status+"; division: "+divisCode;
		
		try {
			ClassHaircut classHaircut = new ClassHaircut();
			
			classHaircut.setClassId(classId);
			
			classHaircut.setAnCap(anCap);
			classHaircut.setAnCover(anCover);
			classHaircut.setAnDate(anDate);
			classHaircut.setAnFloor(anFloor);
			classHaircut.setAnFrstHisD(anFrstHisD);
			classHaircut.setAnHct(anHct);
			classHaircut.setAnLastHisD(anLastHisD);
			classHaircut.setAnLog(anLog);
			classHaircut.setAnMargin(anMargin);
			classHaircut.setAnMult(anMult);
			classHaircut.setAnNDaysPer(anNDaysPer);
			classHaircut.setAnNodeId(anNodeId);
			classHaircut.setAnNodes(anNodes);
			classHaircut.setAnNv(anNv);
			classHaircut.setAnRlHct(anRlHct);
			
			classHaircut.setApproval(approval);
			classHaircut.setComment(comment);
			
			classHaircut.setCrCap(crCap);
			classHaircut.setCrCover(crCover);
			classHaircut.setCrFloor(crFloor);
			classHaircut.setCrFrstHisD(crFrstHisD);
			classHaircut.setCrHct(crHct);
			classHaircut.setCrLastHisD(crLastHisD);
			classHaircut.setCrLog(crLog);
			classHaircut.setCrMargin(crMargin);
			classHaircut.setCrMult(crMult);
			classHaircut.setCrNDaysPer(crNDaysPer);
			classHaircut.setCrNodeId(crNodeId);
			classHaircut.setCrNodes(crNodes);
			classHaircut.setCrNv(crNv);
			classHaircut.setCrRlHct(crRlHct);
			
			classHaircut.setCustom(custom);
			classHaircut.setDivisCode(divisCode);
			classHaircut.setEndVDate(endVDate);
			classHaircut.setIniVDate(iniVDate);
			classHaircut.setPropHct(propHct);
			classHaircut.setPropLog(propLog);
			classHaircut.setPropose(propose);
			classHaircut.setRcCode(rcCode);
			
			classHaircut.setSendDate(sendDate);
			classHaircut.setStatus(status);
			classHaircut.setSusp(susp);
			classHaircut.setUserHct(userHct);
			
			classHaircut.setUpdDate(GenericTools.systemDate());
			classHaircut.setUpdType(updType);
			classHaircut.setUpdUsr(userString());
			
			classHaircut.setAnAddend(anAddend);
			classHaircut.setCrAddend(crAddend);
			
			em.persist(classHaircut);
			log.debug("Added new haircut class: "+logString);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new haircut class - "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("resetClassHaircut");
			query.setParameter(1, divisCode);
			query.setParameter(2, GenericTools.systemDate());
			query.setParameter(3, userString());
			int result = query.executeUpdate();
			log.debug(result+" disabled margins to instrument disabled status - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating margin to disabled status due to instrument disabled status - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int classId, BigDecimal anCap, BigDecimal anCover, Timestamp anDate, BigDecimal anFloor, Timestamp anFrstHisD, BigDecimal anHct, Timestamp anLastHisD,
		String anLog, BigDecimal anMargin, BigDecimal anMult, int anNDaysPer, int anNodeId, String anNodes, int anNv, BigDecimal anRlHct,
		String approval, String comment, BigDecimal crCap, BigDecimal crCover, BigDecimal crFloor, Timestamp crFrstHisD, BigDecimal crHct, Timestamp crLastHisD,
		String crLog, BigDecimal crMargin, BigDecimal crMult, int crNDaysPer, int crNodeId, String crNodes, int crNv, BigDecimal crRlHct,
		String custom, String divisCode, Timestamp endVDate, Timestamp iniVDate, BigDecimal propHct, String propLog, String propose, int rcCode,
		Timestamp sendDate, String status, String susp, BigDecimal userHct, BigDecimal anAddend, BigDecimal crAddend) throws DataNotValidException {
			
		String logString = "classID: "+classId+"; status: "+status+"; division: "+divisCode;
		
		try {
			ClassHaircut classHaircut = this.findByPrimaryKey(classId);
			
			classHaircut.setAnCap(anCap);
			classHaircut.setAnCover(anCover);
			classHaircut.setAnDate(anDate);
			classHaircut.setAnFloor(anFloor);
			classHaircut.setAnFrstHisD(anFrstHisD);
			classHaircut.setAnHct(anHct);
			classHaircut.setAnLastHisD(anLastHisD);
			classHaircut.setAnLog(anLog);
			classHaircut.setAnMargin(anMargin);
			classHaircut.setAnMult(anMult);
			classHaircut.setAnNDaysPer(anNDaysPer);
			classHaircut.setAnNodeId(anNodeId);
			classHaircut.setAnNodes(anNodes);
			classHaircut.setAnNv(anNv);
			classHaircut.setAnRlHct(anRlHct);
			
			classHaircut.setApproval(approval);
			classHaircut.setComment(comment);
			
			classHaircut.setCrCap(crCap);
			classHaircut.setCrCover(crCover);
			classHaircut.setCrFloor(crFloor);
			classHaircut.setCrFrstHisD(crFrstHisD);
			classHaircut.setCrHct(crHct);
			classHaircut.setCrLastHisD(crLastHisD);
			classHaircut.setCrLog(crLog);
			classHaircut.setCrMargin(crMargin);
			classHaircut.setCrMult(crMult);
			classHaircut.setCrNDaysPer(crNDaysPer);
			classHaircut.setCrNodeId(crNodeId);
			classHaircut.setCrNodes(crNodes);
			classHaircut.setCrNv(crNv);
			classHaircut.setCrRlHct(crRlHct);
			
			classHaircut.setCustom(custom);
			classHaircut.setDivisCode(divisCode);
			classHaircut.setEndVDate(endVDate);
			classHaircut.setIniVDate(iniVDate);
			classHaircut.setPropHct(propHct);
			classHaircut.setPropLog(propLog);
			classHaircut.setPropose(propose);
			classHaircut.setRcCode(rcCode);
			
			classHaircut.setSendDate(sendDate);
			classHaircut.setStatus(status);
			classHaircut.setSusp(susp);
			classHaircut.setUserHct(userHct);
			
			classHaircut.setUpdDate(GenericTools.systemDate());
			classHaircut.setUpdType("U");
			classHaircut.setUpdUsr(userString());
			classHaircut.setAnAddend(anAddend);
			classHaircut.setCrAddend(crAddend);
			
			log.debug("Haircut class updated: "+logString);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating haircut class - "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(ClassHaircut classHaircut) throws DataNotValidException {
			
		String logString = "classID: "+classHaircut.getClassId()+"; status: "+classHaircut.getStatus()+"; division: "+classHaircut.getDivisCode();
		
		try {
						
			classHaircut.setUpdDate(GenericTools.systemDate());
			classHaircut.setUpdType(updType);
			classHaircut.setUpdUsr(userString());
			
			em.persist(classHaircut);
			log.debug("Added new haircut class: "+logString);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new haircut class - "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int classId) throws DataNotValidException {
		
		String logString = "classID: "+classId;
		
		try {
			ClassHaircut classHaircut = this.findByPrimaryKey(classId);
			
			em.remove(classHaircut);
			
			log.debug("Haircut class removed: "+logString);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing new haircut class - "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(ClassHaircut classHaircut) throws DataNotValidException {
		
		this.remove(classHaircut.getClassId());
	}
	
	
}
