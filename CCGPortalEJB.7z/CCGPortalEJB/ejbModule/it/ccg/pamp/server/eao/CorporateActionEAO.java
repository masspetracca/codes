package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.CorporateAction;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class CorporateActionEAO
 */
@Stateless
public class CorporateActionEAO implements  CorporateActionEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	
	@SuppressWarnings("unchecked")
	public CorporateAction[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllCA");
    		List<CorporateAction> corporateAction = query.getResultList();
    		CorporateAction[] arrCorporateAction = new CorporateAction[corporateAction.size()];
    		return corporateAction.toArray(arrCorporateAction);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Corporate Actions - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public CorporateAction findByPrimaryKey(int caId) throws DataNotValidException {
		try {
			CorporateAction corporateAction = (CorporateAction) em.find(CorporateAction.class,caId);
    		return corporateAction;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Corporate Action - caId: "+caId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public CorporateAction[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCorpAcByInstrId");
    		query.setParameter("instrId", instrId);
    		List<CorporateAction> corporateAction = query.getResultList();
    		CorporateAction[] arrCorporateAction = new CorporateAction[corporateAction.size()];
    		return corporateAction.toArray(arrCorporateAction);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Corporate Action -instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public CorporateAction findByInstrIdAndCaDate(int instrId,Timestamp caDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCorpAcByInstrIdAndCaDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("caDate", caDate);
    		List<CorporateAction> corporateActionList = query.getResultList();
    		return corporateActionList.get(0);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Corporate Action -instrId: "+instrId+"; caDate: "+caDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public CorporateAction findByInstrIdAndFrstExDate(int instrId,Timestamp frstExDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCorpAcByInstrIdAndFrstExDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("frstExDate", frstExDate);
    		List<CorporateAction> corporateActionList = query.getResultList();
    		if (corporateActionList.size()>0) {
    			return corporateActionList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Corporate Action -instrId: "+instrId+"; frstExDate: "+frstExDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void add(String caType, Timestamp frstExDate, int instrId, int oldInstrId, Timestamp caDate, BigDecimal caValue, BigDecimal kCoeff, String invK) throws DataNotValidException {
		try {
			CorporateAction corporateAction = new CorporateAction();
			//corporateAction.setCaid(caId);
			corporateAction.setCatype(caType);
			corporateAction.setFrstExDate(frstExDate);
			corporateAction.setInstrid(instrId);
			corporateAction.setOldInstrId(oldInstrId);
			corporateAction.setCaDate(caDate);
			corporateAction.setCaValue(caValue);
			corporateAction.setKCoeff(kCoeff);
			corporateAction.setInvK(invK);
			corporateAction.setUpdType(updType);
			corporateAction.setUpdDate(GenericTools.systemDate());
			corporateAction.setUpdUsr(userString());
			em.persist(corporateAction);
			log.debug("Added new Corporate Action for instrId: "+instrId+" - date: "+frstExDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Corporate Action for instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(CorporateAction corporateAction) throws DataNotValidException {
		try {
			corporateAction.setUpdType(updType);
			corporateAction.setUpdDate(GenericTools.systemDate());
			corporateAction.setUpdUsr(userString());
			em.persist(corporateAction);
			//log.debug("Added new Corporate Action - caId: "+corporateAction.getCaid());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Corporate Action for instrId: "+corporateAction.getInstrId()+": - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int caId, String caType, Timestamp frstExDate, int instrId, int oldInstrId, Timestamp caDate, BigDecimal caValue, BigDecimal kCoeff, String invK) throws DataNotValidException {
		CorporateAction corporateAction = findByPrimaryKey(caId);
		try {
			//corporateAction.setCaid(caId);
			corporateAction.setCatype(caType);
			corporateAction.setFrstExDate(frstExDate);
			corporateAction.setInstrid(instrId);
			corporateAction.setOldInstrId(oldInstrId);
			corporateAction.setCaDate(caDate);
			corporateAction.setCaValue(caValue);
			corporateAction.setKCoeff(kCoeff);
			corporateAction.setInvK(invK);
			corporateAction.setUpdType("U");
			corporateAction.setUpdDate(GenericTools.systemDate());
			corporateAction.setUpdUsr(userString());
			log.debug("Corporate Action updated - caId: "+caId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Corporate Action - caId: "+caId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(CorporateAction corpAc) throws DataNotValidException {
		try {
			CorporateAction corporateAction = findByPrimaryKey(corpAc.getCaid());
			corporateAction.setUpdType("U");
			corporateAction.setUpdDate(GenericTools.systemDate());
			corporateAction.setUpdUsr(userString());
			log.debug("Corporate Action updated - caId: "+corpAc.getCaid());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Corporate Action - caId: "+corpAc.getCaid()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int caId) throws DataNotValidException {
		try {
			CorporateAction corporateAction = findByPrimaryKey(caId);
			em.remove(corporateAction);
			log.debug("Corporate Action removed - caId: "+caId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Corporate Action - caId: "+caId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(CorporateAction corporateAction) throws DataNotValidException {
		remove(corporateAction.getCaid());
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteCorpAcByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Corporate Actions removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Corporate Action - instrId: "+instrId+"s - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void flush() {
		em.flush();
	}
}
