package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.stressTest.StressTestCgmbr00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.MemberMarginComposition;
import it.ccg.pamp.server.utils.MemberToSync;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Vector;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class Cgmbr00fEAO
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class Cgmbr00fEAO implements  Cgmbr00fEAOLocal {

	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="STDS", type=PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	public List<StressTestCgmbr00f> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllCgmbr00f");
    		List<StressTestCgmbr00f> cgmbr00fList = query.getResultList();
    		return cgmbr00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgmbr00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<MemberToSync> getMemberToSync(String divisCode) throws DataNotValidException {
		Query query = null;
    	
		//default per comparto equity
		String marketIdString = "2,3";
		
		if (divisCode.equalsIgnoreCase("O")) {
			marketIdString = "4,7";
		}
		
		try {
    		
    		String sqlString = "SELECT "+
						"CASE WHEN MS01.SMBR IS NOT NULL THEN MS01.SMBR ELSE MS02.SMBR END AS MBRID, "+ 
						"CASE WHEN MS01.SGMBR IS NOT NULL THEN MS01.SGMBR ELSE MS02.SGMBR END AS GENMBRID, "+
						"CASE WHEN MS01.SMNEM IS NOT NULL THEN MS01.SMNEM ELSE MS02.SMNEM END AS MBRCODE, "+ 
						"CASE WHEN MS01.SGCMCD IS NOT NULL THEN MS01.SGCMCD ELSE MS02.SGCMCD END AS GENMBRCODE, "+ 
						"MBR01.MFMNAM AS MBRNAME, MBR02.MFMNAM AS GENMBRNAME, "+ 
						"CASE WHEN MS01.SCURCD IS NOT NULL THEN MS01.SCURCD ELSE MS02.SCURCD END AS CURRENCY, "+
						"CASE WHEN MS01.SMIPIMP IS NOT NULL THEN MS01.SMIPIMP ELSE MS02.SMIPIMP END AS MIA, "+

						"-MS01.SCSHC AS CLIENTCASHCALL, "+
						"MS01.SINTM AS CLIENTINITIALMARGIN, "+
						"-MS02.SCSHC AS FIRMCASHCALL, "+
						"MS02.SINTM AS FIRMINITIALMARGIN "+

						"FROM CPSSTMS01 MS01 "+
					    "FULL OUTER JOIN CPSSTMS01 MS02 ON MS01.SMBR = MS02.SMBR AND MS01.SGMBR=MS02.SGMBR AND MS01.SACCT!=MS02.SACCT "+
					    "INNER JOIN CGMBR01L MBR01 ON (CASE WHEN MS01.SMBR IS NOT NULL THEN MS01.SMBR ELSE MS02.SMBR END) = MBR01.MEXMEM "+
					    "INNER JOIN CGMBR02L MBR02 ON (CASE WHEN MS01.SGMBR IS NOT NULL THEN MS01.SGMBR ELSE MS02.SGMBR END) = MBR02.MEXMEM "+
						"WHERE (CASE WHEN MS01.SMBR IS NOT NULL THEN MS01.SMBR ELSE MS02.SMBR END) > 1 "+ 

						"AND (CASE WHEN MS01.SMBR IS NOT NULL THEN MS01.SMBR ELSE MS02.SMBR END) "+
						"IN (SELECT MKT.MKMBRID FROM CGMMKT01L MKT WHERE MKT.MKMKTID IN ("+marketIdString+") AND MKT.MKSTATUS='A' AND MKT.MKSTS IN ('G','I')) "+
						"AND ((MS01.SMBR=MS02.SMBR AND MS01.SACCT='C' AND MS02.SACCT='F') "+
						"OR (MS01.SMBR IS NULL AND MS02.SACCT='F') "+
						"OR (MS02.SMBR IS NULL AND MS01.SACCT='C'))";

					
    		query =  em.createNativeQuery(sqlString,MemberToSync.class);
    		List<MemberToSync> cgmbr00fList = query.getResultList();
    		return cgmbr00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from RE member table - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public LinkedHashMap<Integer,Vector<BigDecimal>> getMarginComposition() throws DataNotValidException {
		Query query = null;
    	
		try {
    		
    		String sqlString = "SELECT "+
						"F54.F54MDGCM AS GENMBRID, "+ 
						"SUM(F54.F90MRGNRMB) AS ORDINARYMARGIN, "+
						"("+
						"SELECT SUM(MMGNMMTIS) FROM MTSMGNF30F "+ 
						"WHERE MDGCM = F54.F54MDGCM "+
						"AND ((MCDMBR<>MDGCM) OR (MCDMBR=MDGCM and MDACCT='C'))"+
						") AS MTMMARGIN "+ 
						
						"FROM MTSMGNF54F F54 "+
					    "WHERE (F54.F54CDMBR<>F54.F54MDGCM) OR (F54.F54MDGCM=F54.F54CDMBR AND F54.F54MDACCT='C') "+ 

						"GROUP BY F54.F54MDGCM";

			
			
    		query =  em.createNativeQuery(sqlString,MemberMarginComposition.class);
    		List<MemberMarginComposition> marginCompositionList = query.getResultList();
    		
    		LinkedHashMap<Integer, Vector<BigDecimal>> marginCompositionMap = new LinkedHashMap<Integer, Vector<BigDecimal>>();
    		
    		if (marginCompositionList.size()>0) {
    			
    			//costruisco una mappa per sveltire la ricerca successivamente e non dover fare una chiamata al DB per ciascun membro
    			for (MemberMarginComposition margComposition:marginCompositionList) {
    				Vector <BigDecimal> marginCompVector = new Vector<BigDecimal>();
    				marginCompVector.add(margComposition.getOrdinaryMargin());
    				marginCompVector.add(margComposition.getMtmMargin());
    				
    				marginCompositionMap.put(margComposition.getGenMbrId(), marginCompVector);
    			}
    			
    			return marginCompositionMap;
    			
    		} else {
    			return null;
    		}

    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from RE margin composition table - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
}
