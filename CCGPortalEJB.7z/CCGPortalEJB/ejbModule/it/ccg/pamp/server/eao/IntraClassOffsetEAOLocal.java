package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.IntraclassOffset;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.ejb.Local;

@Local
public interface IntraClassOffsetEAOLocal {

	public IntraclassOffset[] fetch() throws DataNotValidException;
	
	public IntraclassOffset findByPrimaryKey(int classId) throws DataNotValidException;
	
	public IntraclassOffset[] findEnabledIntraclassOffset() throws DataNotValidException;
	
	public IntraclassOffset[] findEnabledIntraclassOffsetByDivisCode(String divisCode) throws DataNotValidException;
	
	public Integer[] getActivePeriodsForBond(int classId, int crNv) throws DataNotValidException;
	
	public IntraclassOffset[] findProposedIntraclassOffset() throws DataNotValidException;
	
	public void add(int classId, Timestamp anDate, Timestamp anFrstHisD, int anInstrId1, int anInstrId2, Timestamp anLastHisD, String anLog,
			int anNDaysPer, int anNv, BigDecimal anOff, String approval, String comment, Timestamp crFrstHisD, int crInstrId1, int crInstrId2,
			Timestamp crLastHisD, String crLog, int crNDaysPer, int crNv, BigDecimal crOff, String custom, Timestamp endVDate, Timestamp iniVDate,
			String propLog, BigDecimal propOff, String propose, int rcCode, Timestamp sendDate, String status, String susp, BigDecimal userOff) throws DataNotValidException;
	
	public void store(IntraclassOffset IntraclassOffset) throws DataNotValidException;
	
	public void update(int classId, Timestamp anDate, Timestamp anFrstHisD, int anInstrId1, int anInstrId2, Timestamp anLastHisD, String anLog,
			int anNDaysPer, int anNv, BigDecimal anOff, String approval, String comment, Timestamp crFrstHisD, int crInstrId1, int crInstrId2,
			Timestamp crLastHisD, String crLog, int crNDaysPer, int crNv, BigDecimal crOff, String custom, Timestamp endVDate, Timestamp iniVDate,
			String propLog, BigDecimal propOff, String propose, int rcCode, Timestamp sendDate, String status, String susp, BigDecimal userOff) throws DataNotValidException;
	
	public void update(IntraclassOffset interclassOffset) throws DataNotValidException;
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException;
	
	public int updateStatusToDisabledForDisabledClasses(String divisCode) throws DataNotValidException;
	
	public void remove(int classId) throws DataNotValidException;
	
	public void remove(IntraclassOffset interclassOffset) throws DataNotValidException;
	
}
