package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Mtsmgnf92f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;

@Local
public interface Mtsmgnf92fEAOLocal {
	public List<Mtsmgnf92f> fetch() throws DataNotValidException;
	public List<Mtsmgnf92f> getMtsmgnf92fNotinClMarHis() throws DataNotValidException;
	public Mtsmgnf92f findByPrimaryKey(String f92cdclas1, String f92cdclas2) throws DataNotValidException;
	public void update(String f92cdclas1, String f92cdclas2, BigDecimal f92intridp) throws DataNotValidException;
}
