package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.QueueStatus;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class QueueStatusEAO
 */
@Stateless
public class QueueStatusEAO implements  QueueStatusEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	@SuppressWarnings("unchecked")
	public QueueStatus[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllBatches");
    		List<QueueStatus> queueStatus = query.getResultList();
    		QueueStatus[] arrQueueStatus = new QueueStatus[queueStatus.size()];
    		return queueStatus.toArray(arrQueueStatus);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Batches - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public QueueStatus[] getRunningBatchs() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getRunningBatches");
    		query.setParameter("running", 1);
    		List<QueueStatus> queueStatus = query.getResultList();
    		QueueStatus[] arrQueueStatus = new QueueStatus[queueStatus.size()];
    		return queueStatus.toArray(arrQueueStatus);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching running Batches - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public QueueStatus findByPrimaryKey(int id) throws DataNotValidException {
		try {
			QueueStatus queueStatus = (QueueStatus) em.find(QueueStatus.class,id);
    		return queueStatus;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Batch - batchId: "+id+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int id, String status) throws DataNotValidException {
		try {
			QueueStatus queueStatus = new QueueStatus();
			queueStatus.setId(id);
			queueStatus.setStatus(status);
			queueStatus.setUpdDate(GenericTools.systemDate());
			queueStatus.setUpdType(updType);
			queueStatus.setUpdUsr(userString());
			em.persist(queueStatus);
			log.debug("Added new Batch - batchId: "+id);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Batch - batchId: "+id+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(QueueStatus queueStatus) throws DataNotValidException {
		try {
			queueStatus.setUpdDate(GenericTools.systemDate());
			queueStatus.setUpdType(updType);
			queueStatus.setUpdUsr(userString());
			em.persist(queueStatus);
			log.debug("Added new Batch - batchId: "+queueStatus.getId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Batch - batchId: "+queueStatus.getId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int id, String status) throws DataNotValidException {
		try {
			QueueStatus queueStatus = findByPrimaryKey(id);
			queueStatus.setStatus(status);
			queueStatus.setUpdDate(GenericTools.systemDate());
			queueStatus.setUpdType("U");
			queueStatus.setUpdUsr(userString());
			log.debug("Batch updated - batchId: "+id+"; status:"+status);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Batch - batchId: "+id+"; status:"+status+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void upsert(int id, String status) throws DataNotValidException {
		try {
			QueueStatus queueStatus = findByPrimaryKey(id);
			if (queueStatus==null) {
				this.add(1, status);
			} else {
				this.update(id, status);
			}
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Batch - batchId: "+id+"; status:"+status+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void updateToRunning(int id,int running) throws DataNotValidException {
		try {
			QueueStatus queueStatus = findByPrimaryKey(id);
			queueStatus.setStatus("T");
			queueStatus.setUpdDate(GenericTools.systemDate());
			queueStatus.setUpdType("U");
			queueStatus.setUpdUsr(userString());
			log.debug("Batch updated to running - batchId: "+id+"; running: "+running);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Batch to running - batchId: "+id+"; running: "+running+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int id) throws DataNotValidException {
		try {
			QueueStatus queueStatus = findByPrimaryKey(id);
			em.remove(queueStatus);
			log.debug("Batch removed - batchId: "+id);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Batch - batchId: "+id+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(QueueStatus queueStatus) throws DataNotValidException {
		remove(queueStatus.getId());
	}

}
