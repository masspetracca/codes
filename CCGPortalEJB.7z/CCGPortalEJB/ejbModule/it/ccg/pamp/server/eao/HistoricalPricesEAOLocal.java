package it.ccg.pamp.server.eao;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import it.ccg.pamp.server.entities.HistoricalPrices;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.RemoveFailedException;
import it.ccg.pamp.server.utils.HistoricalPricesForBonds;
import it.ccg.pamp.server.utils.HistoricalPricesForChart;

import javax.ejb.Local;
import javax.persistence.Query;

@Local
public interface HistoricalPricesEAOLocal {
	
	public Timestamp findHPMaxDate() throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetchs all historical prices series data  
	   * <p>
	   * Limitation: none
	   *
	   * @param none
	   * @throws DataNotValidException;
	   * @return the list of historical prices data or the occurred exception 
	   */
	public HistoricalPrices[] fetch() throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetch historical prices series data of a certain instrument ID 
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param instrId - the instrument ID to use in filter
	   * @throws DataNotValidException;
	   * @return  the historical prices series data or the occurred exception 
	   */
	public HistoricalPrices[] findByInstrId(int instrId) throws DataNotValidException;
	
	public List<Timestamp> getLastNDays(int maxDays) throws DataNotValidException;
	
	public long countByInstrId(int instrId) throws DataNotValidException;
	
	public HistoricalPrices findLastDateByInstrument(int instrId) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * procedure built to download the futures historical prices series from INTRACS to PAMP system 
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param instrId - the instrument ID to use in filter
	   * @throws DataNotValidException;
	   * @return the historical prices series data or the occurred exception 
	   */
	public HistoricalPrices[] findByInstrIdForDownload(int instrId) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetch historical prices series data required to build the historical prices series chart of a certain instrument ID belonging to Equity Cash or Index divisions 
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param instrId - the instrument ID to use in filter
	   * @throws DataNotValidException;
	   * @return  the historical prices series data or the occurred exception 
	   */
	public List<HistoricalPricesForChart> getValuesForChart(int instrId) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches historical prices series data required to build the historical prices series chart of a certain instrument ID belonging to Bond divisions
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param instrId - the instrument ID to use in filter
	   * @throws DataNotValidException;
	   * @return  the historical prices series data or the occurred exception 
	   */
	public List<HistoricalPricesForBonds> getValuesForBondChart(int instrId) throws DataNotValidException;
	
	
	/* method fetchWithCa - returns a vector containing HistoricalPrices records joined with CorporateAction entity and filtered 
	 * by instrId and lastDate */
	public HistoricalPrices[] fetchWithCa(int instrId, Timestamp lastDate) throws DataNotValidException;
	
	public HistoricalPrices[] fetchWithVar(int instrId) throws DataNotValidException;
	
	public HistoricalPrices[] fetchWithHisVol(int instrId, int progExp) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches the last historical price of a certain instrument ID starting from a date
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param instrId - the instrument ID to use in filter
	   * @param dateRif - the starting date to use in filter
	   * @throws DataNotValidException;
	   * @return  the historical price record found or the occurred exception 
	   */
	public BigDecimal findLastPrice(int instrId, Timestamp dateRif) throws DataNotValidException;
	
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches the last historical price of a certain instrument ID starting from a date
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param instrId - the instrument ID to use in filter
	   * @param dateRif - the starting date to use in filter
	   * @throws DataNotValidException;
	   * @return  the historical price record found or the occurred exception 
	   */
	
	public HistoricalPrices findBeforeDate(int instrId, Timestamp priceDate) throws DataNotValidException;
	
	public HistoricalPrices findBeforeDate(int instrId) throws DataNotValidException;
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches the average historical price of a certain instrument ID within a certain date interval
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param instrId - the instrument ID to use in filter
	   * @param year - the year of date interval to use in filter
	   * @param month - the starting month to use in filter
	   * @throws DataNotValidException;
	   * @return  the average historical price found or the occurred exception 
	   */
	public BigDecimal findAvgPun(int instrId, int year, int month) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * counts the occurrences of a certain instrument ID within a certain date interval
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param instrId - the instrument ID to use in filter
	   * @param firstDate - the year of date interval to use in filter
	   * @param lastDate - the starting month to use in filter
	   * @throws DataNotValidException;
	   * @return  the number of found occurrences or the occurred exception 
	   */
	public int getTimeWindow(int instrId, Timestamp firstDate, Timestamp lastDate) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetchs a single historical price
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param instrId - the instrument ID to use in filter
	   * @param priceDate - the priceDate to use in filter
	   * @throws DataNotValidException;
	   * @return  the historical price record found or the occurred exception 
	   */
	public HistoricalPrices findByPrimaryKey(int instrId, Timestamp priceDate) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetchs the average historical price of a certain instrument ID within a certain date interval
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param instrId - the instrument ID to use in filter
	   * @param year - the year of date interval to use in filter
	   * @param month - the starting month to use in filter
	   * @throws DataNotValidException;
	   * @return  the average historical price found or the occurred exception 
	   */
	public void add(int instrId, Timestamp priceDate, BigDecimal closePr, String status) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * persists the Historical Prices object entered
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param historicalPrices - the object to persist
	   * @throws DataNotValidException;
	   */
	public void store(HistoricalPrices historicalPrices) throws DataNotValidException;
	
	//public void restore(int updId) throws DataNotValidException;
	
	/* method update - updates a Historical Prices object by entering parameters */
	/**
	   * @author Francesco Nelli
	   * <p>
	   * updates a persisting Historical Prices object by entering parameters
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param the keys to search the object and its other attributes to update
	   * @throws DataNotValidException;
	   */
	public void update(int instrId, Timestamp priceDate, BigDecimal closePr, String status) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * logs the update of the Historical Prices object entered
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param historicalPrices - the object to persist
	   * @throws DataNotValidException;
	   */
	public void update(HistoricalPrices histPrices) throws DataNotValidException;
	
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * deletes a persisting Historical Prices object using a key search
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param instrId - the instrument ID to use in filter
	   * @param priceDate - the priceDate to use in filter
	   * @throws DataNotValidException;
	   */
	public void remove(int instrId, Timestamp priceDate) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * deletes a persisting Historical Prices object searching by instrumentId
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param instrId - the instrument ID to use in filter
	   * @throws DataNotValidException;
	   * @return the number of deleted records or the occurred exception;
	   */
	/* method removeByInstrId - removes from the persistence unit a list of Historical Prices objects by entering instrId parameters */
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * logs the deletion of the Historical Prices object entered
	   * <p>
	   * 
	   * @Limitation none
	   *
	   * @param historicalPrices - the object to delete
	   * @throws DataNotValidException;
	   */
	public void remove(HistoricalPrices histPrices) throws DataNotValidException;
	
	public void flush();
	
	public HistoricalPrices[] fetchInInterval(int instrId, Timestamp lastDate,Timestamp firstDate) throws DataNotValidException;
	
	public HistoricalPrices findAfterDate(int instrId, Timestamp priceDate) throws DataNotValidException;
	
	//public void backup(HistoricalPrices histPrices) throws DataNotValidException;
}
