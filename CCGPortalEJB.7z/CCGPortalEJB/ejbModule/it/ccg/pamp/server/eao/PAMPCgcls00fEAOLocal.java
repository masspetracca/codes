package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.PAMPCgcls00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.ClassTableChecks;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;

@Local
public interface PAMPCgcls00fEAOLocal {

	public List<PAMPCgcls00f> fetch() throws DataNotValidException;
	
	public List<PAMPCgcls00f> findByCClass(String cClass) throws DataNotValidException;
	
	public List<PAMPCgcls00f> findByCofCod(List<String> cofCodList) throws DataNotValidException;
	
	public PAMPCgcls00f findByPrimaryKey(String cClass, String cofCod) throws DataNotValidException;
	
	public BigDecimal getMaxChangeDate() throws DataNotValidException;
	
	public BigDecimal getPriceSum() throws DataNotValidException;
	
	public ClassTableChecks getInfoToCheck() throws DataNotValidException;
	
	public String synchronizeTable() throws DataNotValidException;
	
}
