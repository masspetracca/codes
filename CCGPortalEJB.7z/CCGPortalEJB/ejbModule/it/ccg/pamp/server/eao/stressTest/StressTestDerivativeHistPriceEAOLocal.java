package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestDerivativeHistPrice;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface StressTestDerivativeHistPriceEAOLocal {

	public List<StressTestDerivativeHistPrice> fetch() throws DataNotValidException;
	
	public StressTestDerivativeHistPrice findByPrimaryKey(int instrId, int expiry, String scenario, int stId, String pc, BigDecimal strike) throws DataNotValidException;
	
	public List<StressTestDerivativeHistPrice> getStressTestHistPricesByStId(int stId) throws DataNotValidException;
	
	public List<StressTestDerivativeHistPrice> getStressTestDerivativeHistPricesByStIdAndScenario(int stId, String scenario) throws DataNotValidException;
	
	public Integer getLastStressTestId(String scenario) throws DataNotValidException;
	
	public List<StressTestDerivativeHistPrice> getStressTestDerivativeHistPricesByInstrIdAndStIdAndScenario(int instrId, int stId, String scenario) throws DataNotValidException;
	
	public List<StressTestDerivativeHistPrice> getStressTestDerivativeHistPriceToExport(int stId, String scenario) throws DataNotValidException;
	
	public void add(int instrId, Timestamp priceDate, int expiry, int stId, String scenario, String pc, BigDecimal strike, BigDecimal closePr, BigDecimal closePrSt, int nDaysPer, BigDecimal impVola, String code, String log, String sent, String status, String atm, String atmSt, int shift, BigDecimal impVolaSt) throws DataNotValidException;
	
	public void store(StressTestDerivativeHistPrice stressTestDerivativeHistPrice) throws DataNotValidException;
	
	public void update(int instrId, Timestamp priceDate, int expiry, int stId, String scenario, String pc, BigDecimal strike, BigDecimal closePr, BigDecimal closePrSt, int nDaysPer, BigDecimal impVola, String code, String log, String sent, String status, String atm, String atmSt, int shift, BigDecimal impVolaSt) throws DataNotValidException;
	
	public void update(StressTestDerivativeHistPrice stressTestDerivativeHistPrice) throws DataNotValidException;
	
	public int updateSentStatusAfterExport(int instrId, int stId, String scenario) throws DataNotValidException;
	
	public void remove(int instrId, Timestamp priceDate, int expiry, int stId, String scenario, String pc, BigDecimal strike) throws DataNotValidException;
	
	public String resetEqDerStSentStatus(int stId) throws DataNotValidException;
	
	public void remove(StressTestDerivativeHistPrice stressTestDerivativeHistPrice) throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
}
