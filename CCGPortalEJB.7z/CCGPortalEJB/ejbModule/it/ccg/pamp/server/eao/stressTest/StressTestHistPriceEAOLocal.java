package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.CurveNode;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface StressTestHistPriceEAOLocal {
	
	public List<StressTestHistPrice> fetch() throws DataNotValidException;
	
	public StressTestHistPrice findByPrimaryKey(int instrId, String scenario, int stId) throws DataNotValidException;
	
	public List<StressTestHistPrice> getStressTestHistPricesByStId(int stId) throws DataNotValidException;
	
	public List<StressTestHistPrice> getStressTestHistPricesByStIdAndScenario(int stId, String scenario) throws DataNotValidException;
	
	public StressTestHistPrice getStressTestHistPricesByInstrIdAndScenario(int instrId, String scenario) throws DataNotValidException;	
	
	public Integer getLastStressTestId(String scenario) throws DataNotValidException;
	
	public List<CurveNode> getStressTestHistPricesByScenarioAndCurveArr(String scenario, String[] arrIrCurve, int stId) throws DataNotValidException;
	
	public List<StressTestHistPrice> getStressTestHistPriceToExport(int stId, String scenario) throws DataNotValidException;
	
	public void add(int instrId, Timestamp priceDate, int stId, String scenario, BigDecimal closePr, BigDecimal closePrSt, String log, int nDaysPer, String sent, String status) throws DataNotValidException;
	
	public void store(StressTestHistPrice stressTestHistPrice) throws DataNotValidException;
	
	public void update(int instrId, Timestamp priceDate, int stId, String scenario, BigDecimal closePr, BigDecimal closePrSt, String log, int nDaysPer, String sent, String status) throws DataNotValidException;
	
	public void update(StressTestHistPrice stressTestHistPrice) throws DataNotValidException;
	
	public void remove(int instrId, Timestamp priceDate, int stId, String scenario) throws DataNotValidException;
	
	public String resetEqBoStSentStatus(int stId) throws DataNotValidException;
	
	public void remove(StressTestHistPrice stressTestHistPrice) throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
}
