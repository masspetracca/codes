package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.IntracsCgdff00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface IntracsCgdff00fEAOLocal {
	
	public List<IntracsCgdff00f> fetch() throws DataNotValidException;
	
}
 