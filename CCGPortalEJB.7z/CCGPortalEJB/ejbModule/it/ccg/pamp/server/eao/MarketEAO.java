package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Market;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MarketEAO
 */
@Stateless
public class MarketEAO implements  MarketEAOLocal {
		
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	public List<Market> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllMK");
    		List<Market> marketList = query.getResultList();
    		return marketList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Markets - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Market findByPrimaryKey(String marketCode) throws DataNotValidException {
		try {
			Market market = (Market) em.find(Market.class,marketCode);
    		return market;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Market - marketCode: "+marketCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Market findLastMarket() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getLastMarket");
    		List<Market> marketList = query.getResultList();
    		if (marketList.size()>0) {
    			return marketList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching the last market - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(String marketCode, String marketDesc, int index, String marketGrp) throws DataNotValidException {
		try {
			Market market = new Market();
			market.setMarketCode(marketCode);
			market.setMarketDesc(marketDesc);
			market.setUpdType(updType);
			market.setUpdDate(GenericTools.systemDate());
			market.setUpdUsr(userString());
			market.setIndex(index);
			market.setMarketGrp(marketGrp);
			em.persist(market);
			log.debug("Added new Market - marketCode: "+marketCode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Market - marketCode: "+marketCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(Market market) throws DataNotValidException {
		try {
			market.setUpdType(updType);
			market.setUpdDate(GenericTools.systemDate());
			market.setUpdUsr(userString());
			em.persist(market);
			log.debug("Added new Market - marketCode: "+market.getMarketCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Market - marketCode: "+market.getMarketCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(String marketCode, String marketDesc, int index, String marketGrp) throws DataNotValidException {
		try {
			Market market = findByPrimaryKey(marketCode);
			market.setMarketDesc(marketDesc);
			market.setUpdType("U");
			market.setUpdDate(GenericTools.systemDate());
			market.setUpdUsr(userString());
			market.setIndex(index);
			market.setMarketGrp(marketGrp);
			log.debug("Market updated - marketCode: "+marketCode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Market - marketCode: "+marketCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(Market mkt) throws DataNotValidException {
		try {
				
			log.debug("Market updated - marketCode: "+mkt.getMarketCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Market - marketCode: "+mkt.getMarketCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(Market mkt) throws DataNotValidException {
		try {
			Market market = findByPrimaryKey(mkt.getMarketCode());
			em.remove(market);
			log.debug("Market removed - marketCode: "+mkt.getMarketCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Market - marketCode: "+mkt.getMarketCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
