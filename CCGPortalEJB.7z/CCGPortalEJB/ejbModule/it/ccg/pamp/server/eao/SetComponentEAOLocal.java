package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.SetComponent;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;
import javax.persistence.Query;

@Local
public interface SetComponentEAOLocal {
	public SetComponent[] fetch() throws DataNotValidException;
	public SetComponent findByPrimaryKey(int setId, int instrId) throws DataNotValidException;
	public SetComponent[] findByInstrId(int instrId) throws DataNotValidException;
	public SetComponent[] findBySetId(int setId)throws DataNotValidException;
	public void add(int setId, int instrId) throws DataNotValidException;
	public void store(SetComponent setComponent) throws DataNotValidException;
	public void remove(int setId, int instrId) throws DataNotValidException;
	public int removeByInstrId(int instrId) throws DataNotValidException;
	public int removeBySetId(int setId) throws DataNotValidException;
	public void remove(SetComponent setComp) throws DataNotValidException;
}
