package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.GroupParameter;
import it.ccg.pamp.server.entities.SetParameter;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface GroupParameterEAOLocal {
	public GroupParameter[] fetch() throws DataNotValidException;
	public GroupParameter findByPrimaryKey(int grId, int nDaysPer, int nv) throws DataNotValidException;
	public GroupParameter[] findByGroupId(int grId) throws DataNotValidException;
	public GroupParameter[] fetchWithGroup(int grId) throws DataNotValidException;
	public Integer[] getActiveDelta(int grId) throws DataNotValidException;
	public Integer[] getActivePeriods(int grId, int delta) throws DataNotValidException;
	public Integer[] getEnabledPeriods(int grId, int delta) throws DataNotValidException;
	public void add(int nDaysPer, int nv, int grId, String pStatus) throws DataNotValidException;
	public void store(GroupParameter groupParameter) throws DataNotValidException;
	public void storeParametersFromSet(int grId, int setId) throws DataNotValidException;
	public void update(int grId,int nDaysPer, int nv, String pStatus) throws DataNotValidException;
	public void update(GroupParameter groupPar) throws DataNotValidException;
	public void logUpdate(GroupParameter groupPar) throws DataNotValidException;
	public void remove(int grId, int nDaysPer, int nv) throws DataNotValidException;
	public int removeByGrId(int grId) throws DataNotValidException;
	public void remove(GroupParameter groupParameter) throws DataNotValidException;
}
