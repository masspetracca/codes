package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface StressTestEAOLocal {
	
	public List<StressTest> fetch() throws DataNotValidException;
	
	public StressTest findByPrimaryKey(int stId) throws DataNotValidException;
	
	public int createAndReturnStressTestId(String divisCode, String launchMode) throws DataNotValidException;
	
	public StressTest findStressTestOrderByStId() throws DataNotValidException;
	
	public void add(String note, Timestamp lstHistDat, String divisCode) throws DataNotValidException;
	
	public void store(StressTest stressTest) throws DataNotValidException;
	
	public void update(int stId, Timestamp lstHistDat, String note, String divisCode) throws DataNotValidException;
	
	public void update(StressTest stressTest) throws DataNotValidException;
	
	public void renameStressTest() throws DataNotValidException;
	
	public void remove(int stId) throws DataNotValidException;
	
	public void remove(StressTest stressTest) throws DataNotValidException;
}
