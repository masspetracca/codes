package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.stressTest.StressTestCgpri00f;
import it.ccg.pamp.server.entities.stressTest.StressTestCgpri00fPK;
import it.ccg.pamp.server.entities.stressTest.StressTestCgvolai00f;
import it.ccg.pamp.server.entities.stressTest.StressTestCgvolai00fPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StressTestCgvolai00fEAO
 */
@Stateless
public class StressTestCgvolai00fEAO implements  StressTestCgvolai00fEAOLocal {

	@PersistenceContext(unitName="STDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<StressTestCgvolai00f> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSTCgvolai00f");
    		List<StressTestCgvolai00f> stressTestCgvolai00fList = query.getResultList();
    		return stressTestCgvolai00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from StressTestCgvolai00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	public StressTestCgvolai00f findByPrimaryKey (Date srDate, String srIsin) throws DataNotValidException {
		Query query = null;
    	try {
    		StressTestCgvolai00fPK pK = new StressTestCgvolai00fPK();
    		
    		pK.setSrDate(srDate);
    		pK.setSrIsin(srIsin);
    		    		
    		StressTestCgvolai00f stressTestCgvolai00f = (StressTestCgvolai00f) em.find(StressTestCgvolai00f.class, pK);
    		
    		return stressTestCgvolai00f;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from StressTestCgvolai00f - date: "+srDate+"; isinCode: "+srIsin+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public void update(Date srDate, String srIsin, BigDecimal srVola) throws DataNotValidException {
		try {
			StressTestCgvolai00f stressTestCgvolai00f = this.findByPrimaryKey(srDate, srIsin);
			stressTestCgvolai00f.setSrVola(srVola);
			log.debug("StressTestCgvolai00f updated - srDate: "+srDate+"; srIsin: "+srIsin+"; new srVola: "+srVola);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating StressTestCgvolai00f - srDate: "+srDate+"; srIsin: "+srIsin+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(StressTestCgvolai00f stressTestCgvolai00f) throws DataNotValidException {
		try {
			em.persist(stressTestCgvolai00f);
			log.debug("Added new StressTestCgpri00f - srDate: "+stressTestCgvolai00f.getPk().getSrDate()+"; srIsin: "+stressTestCgvolai00f.getPk().getSrIsin()+"; new srVola: "+stressTestCgvolai00f.getSrVola());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new StressTestCgpri00f - srDate: "+stressTestCgvolai00f.getPk().getSrDate()+"; srIsin: "+stressTestCgvolai00f.getPk().getSrIsin()+"; - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeAll() throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteAllSTCgvolai00f");
			int result = query.executeUpdate();
			log.debug(result+" future stressed price on RE System removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing future stressed price removed on RE System - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
