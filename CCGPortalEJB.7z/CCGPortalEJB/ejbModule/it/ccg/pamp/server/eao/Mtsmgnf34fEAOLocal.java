package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Mtsmgnf34f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface Mtsmgnf34fEAOLocal {
	public List<Mtsmgnf34f> fetch() throws DataNotValidException;
	public Mtsmgnf34f findByPrimaryKey(String pf34prd) throws DataNotValidException;
}
