package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.InfoProviderInstr;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class InfoProviderInstrEAO
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class InfoProviderInstrEAO implements InfoProviderInstrEAOLocal {

	@PersistenceContext(unitName="INFOP")
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public List<InfoProviderInstr> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("fetchReutersStaticData");
    		List<InfoProviderInstr> instrList = query.getResultList();
    		
    		return instrList;
    	   		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching instruments from Info Provider System - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InfoProviderInstr findByRicCode(String ricCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("findByRicCode");
    		query.setParameter("ricCode", ricCode);
    		List<InfoProviderInstr> instrList = query.getResultList();
    		if (instrList.size()==0) {
    			return null;
    		} else {
    			return instrList.get(0);
    		}
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching instruments from Info Provider System - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InfoProviderInstr findCurrencyByClassCode(String currencyCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("findCurrencyByClassCode");
    		query.setParameter("currencyCode", currencyCode);
    		List<InfoProviderInstr> instrList = query.getResultList();
    		if (instrList.size()==0) {
    			return null;
    		} else {
    			return instrList.get(0);
    		}
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching currencies from Info Provider System - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
