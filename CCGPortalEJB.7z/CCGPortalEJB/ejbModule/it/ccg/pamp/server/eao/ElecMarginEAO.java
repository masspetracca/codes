package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ElecMargin;
import it.ccg.pamp.server.entities.ElecMarginPK;
import it.ccg.pamp.server.entities.ElecStatistic;
import it.ccg.pamp.server.entities.ElecStatisticPK;
import it.ccg.pamp.server.entities.Margin;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ElecMarginEAO
 */
@Stateless
public class ElecMarginEAO implements  ElecMarginEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	
	
	public List<ElecMargin> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllElecMargins");
    		List<ElecMargin> elecMarginList = query.getResultList();
    		return elecMarginList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ElecMargin> getEnabledElecMargins() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllEnabledElecMargins");
    		List<ElecMargin> elecMarginList = query.getResultList();
    		return elecMarginList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled electricity derivatives margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ElecMargin> getEnabledElecMarginsByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllEnabledElecMarginsByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<ElecMargin> elecMarginList = query.getResultList();
    		return elecMarginList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled electricity derivatives margins - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<ElecMargin> findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getElecMarginsByInstrId");
    		query.setParameter("instrId", instrId);
    		List<ElecMargin> elecMarginList = query.getResultList();
    		return elecMarginList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives margins - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ElecMargin> findByMonth(int month) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getElecMarginsByMonth");
    		query.setParameter("month", month);
    		List<ElecMargin> elecMarginList = query.getResultList();
    		return elecMarginList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives margins - month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public ElecMargin findByPrimaryKey(int instrId, int month) throws DataNotValidException {
		try {
			ElecMarginPK pK = new ElecMarginPK();
			pK.setInstrId(instrId);
			pK.setMonth(month);
			ElecMargin elecMargin = (ElecMargin) em.find(ElecMargin.class,pK);
    		return elecMargin;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives margin - instrId: "+instrId+"; month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	public void add(int instrId, int month, BigDecimal anCover,	Timestamp anDate, Timestamp anFrstHisD, Timestamp anLastHisD, String anLog, BigDecimal anMargin, BigDecimal anMinMar,
			String anVarType, int anYear, String approval, String comment, BigDecimal crCover, Timestamp crFrstHisD,
			Timestamp crLastHisD, String crLog, BigDecimal crMargin, BigDecimal crMinMar, String crVarType, int crYear, String custom, String divisCode,
			Timestamp endVDate, Timestamp iniVDate, BigDecimal propCover, String propLog, BigDecimal propMargin, BigDecimal propMinMar, String propose,
			int rcCode, BigDecimal rlMargin, Timestamp sendDate, String status, String susp, Timestamp updDate, String updType, String updUsr,
			String userCh, BigDecimal userCov, BigDecimal userMargin, BigDecimal userMinMar) throws DataNotValidException {
		
		try {
			ElecMargin elecMargin = new ElecMargin();
			ElecMarginPK pK = new ElecMarginPK();

			pK.setInstrId(instrId);
			pK.setMonth(month);	
			
			elecMargin.setPk(pK);
			
			elecMargin.setAnCover(anCover);
			elecMargin.setAnDate(anDate);
			elecMargin.setAnFrstHisD(anFrstHisD);
			elecMargin.setAnLastHisD(anLastHisD);
			elecMargin.setAnLog(anLog);
			elecMargin.setAnMargin(anMargin);
			elecMargin.setAnMinMar(anMinMar);
			elecMargin.setAnVarType(anVarType);
			elecMargin.setAnYear(anYear);
			
			elecMargin.setApproval(approval);
			elecMargin.setComment(comment);
			
			elecMargin.setCrCover(crCover);
			elecMargin.setCrFrstHisD(crFrstHisD);
			elecMargin.setCrLastHisD(crLastHisD);
			elecMargin.setCrLog(crLog);
			elecMargin.setCrMargin(crMargin);
			elecMargin.setCrMinMar(crMinMar);
			elecMargin.setCrVarType(crVarType);
			elecMargin.setCrYear(crYear);
			
			elecMargin.setCustom(custom);
			elecMargin.setDivisCode(divisCode);
			elecMargin.setEndVDate(endVDate);
			elecMargin.setIniVDate(iniVDate);
			elecMargin.setPropCover(propCover);
			elecMargin.setPropLog(propLog);
			elecMargin.setPropMargin(propMargin);
			elecMargin.setPropMinMar(propMinMar);
			elecMargin.setPropose(propose);
			
			elecMargin.setRcCode(rcCode);
			elecMargin.setRlMargin(rlMargin);
			elecMargin.setSendDate(sendDate);
			elecMargin.setStatus(status);
			elecMargin.setSusp(susp);
			
			elecMargin.setUserCh(userCh);
			elecMargin.setUserCov(userCov);
			elecMargin.setUserMargin(userMargin);
			elecMargin.setUserMinMar(userMinMar);
			
			elecMargin.setUpdDate(GenericTools.systemDate());
			elecMargin.setUpdType(updType);
			elecMargin.setUpdUsr(userString());
			
			em.persist(elecMargin);
			
			log.debug("Added new electricity derivatives margin - instrId: "+instrId+"; month: "+month);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new electricity derivatives margin - instrId: "+instrId+"; month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public void store(ElecMargin elecMargin) throws DataNotValidException {
		try {

			elecMargin.setUpdDate(GenericTools.systemDate());
			elecMargin.setUpdType(updType);
			elecMargin.setUpdUsr(userString());
			
			em.persist(elecMargin);
			
			log.debug("Added new electricity derivatives margin - instrId: "+elecMargin.getPk().getInstrId()+"; month: "+elecMargin.getPk().getMonth());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new electricity derivatives margin - instrId: "+elecMargin.getPk().getInstrId()+"; month: "+elecMargin.getPk().getMonth()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void update(int instrId, int month, BigDecimal anCover,	Timestamp anDate, Timestamp anFrstHisD, Timestamp anLastHisD, String anLog, BigDecimal anMargin, BigDecimal anMinMar,
			String anVarType, int anYear, String approval, String comment, BigDecimal crCover, Timestamp crFrstHisD,
			Timestamp crLastHisD, String crLog, BigDecimal crMargin, BigDecimal crMinMar, String crVarType, int crYear, String custom, String divisCode,
			Timestamp endVDate, Timestamp iniVDate, BigDecimal propCover, String propLog, BigDecimal propMargin, BigDecimal propMinMar, String propose,
			int rcCode, BigDecimal rlMargin, Timestamp sendDate, String status, String susp, Timestamp updDate, String updType, String updUsr,
			String userCh, BigDecimal userCov, BigDecimal userMargin, BigDecimal userMinMar) throws DataNotValidException {
		
		try {
			
			ElecMargin elecMargin = this.findByPrimaryKey(instrId, month);
			
			elecMargin.setAnCover(anCover);
			elecMargin.setAnDate(anDate);
			elecMargin.setAnFrstHisD(anFrstHisD);
			elecMargin.setAnLastHisD(anLastHisD);
			elecMargin.setAnLog(anLog);
			elecMargin.setAnMargin(anMargin);
			elecMargin.setAnMinMar(anMinMar);
			elecMargin.setAnVarType(anVarType);
			elecMargin.setAnYear(anYear);
			
			elecMargin.setApproval(approval);
			elecMargin.setComment(comment);
			
			elecMargin.setCrCover(crCover);
			elecMargin.setCrFrstHisD(crFrstHisD);
			elecMargin.setCrLastHisD(crLastHisD);
			elecMargin.setCrLog(crLog);
			elecMargin.setCrMargin(crMargin);
			elecMargin.setCrMinMar(crMinMar);
			elecMargin.setCrVarType(crVarType);
			elecMargin.setCrYear(crYear);
			
			elecMargin.setCustom(custom);
			elecMargin.setDivisCode(divisCode);
			elecMargin.setEndVDate(endVDate);
			elecMargin.setIniVDate(iniVDate);
			elecMargin.setPropCover(propCover);
			elecMargin.setPropLog(propLog);
			elecMargin.setPropMargin(propMargin);
			elecMargin.setPropMinMar(propMinMar);
			elecMargin.setPropose(propose);
			
			elecMargin.setRcCode(rcCode);
			elecMargin.setRlMargin(rlMargin);
			elecMargin.setSendDate(sendDate);
			elecMargin.setStatus(status);
			elecMargin.setSusp(susp);
			
			elecMargin.setUserCh(userCh);
			elecMargin.setUserCov(userCov);
			elecMargin.setUserMargin(userMargin);
			elecMargin.setUserMinMar(userMinMar);
						
			elecMargin.setUpdDate(GenericTools.systemDate());
			elecMargin.setUpdType("U");
			elecMargin.setUpdUsr(userString());
			
			log.debug("Electricity derivatives margin updated - instrId: "+instrId+"; month: "+month);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating electricity derivatives margin - instrId: "+instrId+"; month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(ElecMargin elecMargin) throws DataNotValidException {
		try {
			log.debug("Electricity derivatives margin updated - - instrId: "+elecMargin.getPk().getInstrId()+"; month: "+elecMargin.getPk().getMonth());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating electricity derivatives margin - instrId: "+elecMargin.getPk().getInstrId()+"; month: "+elecMargin.getPk().getMonth()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, int month) throws DataNotValidException {
		try {
			ElecMargin elecMargin = this.findByPrimaryKey(instrId, month);
			em.remove(elecMargin);
			log.debug("Electricity derivatives margin - instrId: "+instrId+"; month: "+month);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing electricity derivatives margin - instrId: "+instrId+"; month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByMonth(int month) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteElecMarginByMonth");
			query.setParameter("month", month);
			int result = query.executeUpdate();
			log.debug(result+" electricity derivatives margins removed for month "+month);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing electricity derivatives margins for month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}	
	
	public void remove(ElecMargin elecMargin) throws DataNotValidException {
		this.remove(elecMargin.getPk().getInstrId(), elecMargin.getPk().getMonth());
	}

}
