package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ETFIncome;
import it.ccg.pamp.server.entities.FrequencyDistribution;
import it.ccg.pamp.server.entities.FrequencyDistributionPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class FrequencyDistributionEAO
 */
@Stateless

@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class FrequencyDistributionEAO implements  FrequencyDistributionEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	

	public FrequencyDistribution[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllFrequency");
    		List<FrequencyDistribution> frequencyDistribution = query.getResultList();
    		FrequencyDistribution[] arrFrequencyDistribution = new FrequencyDistribution[frequencyDistribution.size()];
    		return frequencyDistribution.toArray(arrFrequencyDistribution);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Frequency Distributions - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	 
	public FrequencyDistribution findByPrimaryKey(int instrId, int nv, int nDaysPer, String varType, int interval) throws DataNotValidException {
		try {
			FrequencyDistributionPK pK = new FrequencyDistributionPK();
			pK.setInstrId(instrId);
			pK.setNv(nv);
			pK.setNDaysPer(nDaysPer);
			pK.setVarType(varType);
			pK.setInterval(interval);
			FrequencyDistribution frequencyDistribution= (FrequencyDistribution) em.find(FrequencyDistribution.class,pK);
    		return frequencyDistribution;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Frequency Distribution - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; interval: "+interval+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public FrequencyDistribution[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getFrequencyByInstrId");
    		query.setParameter("instrId", instrId);
    		List<FrequencyDistribution> frequencyDistribution = query.getResultList();
    		FrequencyDistribution[] arrFrequencyDistribution = new FrequencyDistribution[frequencyDistribution.size()];
    		return frequencyDistribution.toArray(arrFrequencyDistribution);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Frequency Distribution - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, int nv, int nDaysPer, String varType, int interval, BigDecimal freq, BigDecimal cumFreq, int count) throws DataNotValidException {
		try {	
			FrequencyDistribution frequencyDistribution = new FrequencyDistribution();
			FrequencyDistributionPK pK = new FrequencyDistributionPK();
			pK.setInstrId(instrId);
			pK.setNv(nv);
			pK.setNDaysPer(nDaysPer);
			pK.setVarType(varType);
			pK.setInterval(interval);
			frequencyDistribution.setPk(pK);
			frequencyDistribution.setFreq(freq);
			frequencyDistribution.setCumFreq(cumFreq);
			frequencyDistribution.setCount(count);
			frequencyDistribution.setUpdDate(GenericTools.systemDate());
			frequencyDistribution.setUpdType(updType);
			frequencyDistribution.setUpdUsr(userString());
			em.persist(frequencyDistribution);
			log.debug("Added new Frequency Distribution - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; interval: "+interval+"; frequency: "+freq);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Frequency Distribution - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; interval: "+interval+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void store(FrequencyDistribution frequencyDistribution) throws DataNotValidException {
		try {
			frequencyDistribution.setUpdDate(GenericTools.systemDate());
			frequencyDistribution.setUpdType(updType);
			frequencyDistribution.setUpdUsr(userString());
			em.persist(frequencyDistribution);
			log.debug("Added new Frequency Distribution - instrId: "+frequencyDistribution.getPk().getInstrId()+"; holding period: "+frequencyDistribution.getPk().getNv()+"; nDaysPer: "+frequencyDistribution.getPk().getNDaysPer()+"; varType: "+frequencyDistribution.getPk().getVarYype()+"; interval: "+frequencyDistribution.getPk().getInterval()+"; frequency: "+frequencyDistribution.getFreq());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Frequency Distribution - instrId: "+frequencyDistribution.getPk().getInstrId()+"; holding period: "+frequencyDistribution.getPk().getNv()+"; nDaysPer: "+frequencyDistribution.getPk().getNDaysPer()+"; varType: "+frequencyDistribution.getPk().getVarYype()+"; interval: "+frequencyDistribution.getPk().getInterval()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, int nv, int nDaysPer, String varType, int interval, BigDecimal freq, BigDecimal cumFreq, int count) throws DataNotValidException {
		try {
			FrequencyDistribution frequencyDistribution = findByPrimaryKey(instrId,nv,nDaysPer,varType, interval);
			frequencyDistribution.setFreq(freq);
			frequencyDistribution.setCumFreq(cumFreq);
			frequencyDistribution.setCount(count);
			frequencyDistribution.setUpdDate(GenericTools.systemDate());
			frequencyDistribution.setUpdType("U");
			frequencyDistribution.setUpdUsr(userString());
			log.debug("Frequency Distribution updated - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; interval: "+interval+"; frequency: "+freq);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Frequency Distribution - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; interval: "+interval+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(FrequencyDistribution frequencyDistribution) throws DataNotValidException {
		try {
			log.debug("Frequency Distribution updated - instrId: "+frequencyDistribution.getPk().getInstrId()+"; holding period: "+frequencyDistribution.getPk().getNv()+"; nDaysPer: "+frequencyDistribution.getPk().getNDaysPer()+"; varType: "+frequencyDistribution.getPk().getVarYype()+"; interval: "+frequencyDistribution.getPk().getInterval()+"; frequency: "+frequencyDistribution.getFreq());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Frequency Distribution - instrId: "+frequencyDistribution.getPk().getInstrId()+"; holding period: "+frequencyDistribution.getPk().getNv()+"; nDaysPer: "+frequencyDistribution.getPk().getNDaysPer()+"; varType: "+frequencyDistribution.getPk().getVarYype()+"; interval: "+frequencyDistribution.getPk().getInterval()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, int nv, int nDaysPer, String varType, int interval) throws DataNotValidException {
		try {
			FrequencyDistribution frequencyDistribution = findByPrimaryKey(instrId,nv,nDaysPer,varType, interval);
			em.remove(frequencyDistribution);
			log.debug("Frequency Distribution removed - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; interval: "+interval);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Frequency Distribution - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; interval: "+interval+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteFrequencyByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Frequency Distribution removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Frequency Distribution - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteFrequencyByEnabledInstrId");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" Frequency Distributions related to disabled instruments removed - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing frequency fistributions related to disabled instruments - divisCode: "+divisCode+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	public void remove(FrequencyDistribution frequencyDistribution) throws DataNotValidException {
		remove(frequencyDistribution.getPk().getInstrId(), frequencyDistribution.getPk().getNv(),frequencyDistribution.getPk().getNDaysPer(),frequencyDistribution.getPk().getVarYype(),frequencyDistribution.getPk().getInterval());
	}

}
