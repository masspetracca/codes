package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Tfpgrp;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface TfpgrpEAOLocal {
	
	public List<Tfpgrp> fetch() throws DataNotValidException;
	
	public Tfpgrp findByPrimaryKey(String gGroup) throws DataNotValidException;
	
	public void store(Tfpgrp newIntracsGrPr) throws DataNotValidException;
	
}
