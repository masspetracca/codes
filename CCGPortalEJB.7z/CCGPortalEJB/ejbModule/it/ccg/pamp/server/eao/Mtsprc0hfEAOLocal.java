package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.Mtsprc0hf;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondIntracsPriceAndDate;

import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface Mtsprc0hfEAOLocal {
	public List<Mtsprc0hf> fetch() throws DataNotValidException;
	
	public List<Mtsprc0hf> getMtsprc0hfToSync() throws DataNotValidException;
	
	public BondIntracsPriceAndDate findBondLastPrice(Instrument instr) throws DataNotValidException;
	
	public BondIntracsPriceAndDate findMtsprc0hfBeforeLastDate(Instrument instr, Timestamp prDate) throws DataNotValidException;
	
	public Mtsprc0hf findByPrimaryKey(String pIsinc, long dateR) throws DataNotValidException;
	
	public List<Mtsprc0hf> findByIsinCode(String isinCode, long hDate) throws DataNotValidException;
	
	public Mtsprc0hf findBeforeDate(Instrument instr, Timestamp prDate) throws DataNotValidException;
	
	public Mtsprc0hf findBeforeDate(Instrument instr) throws DataNotValidException;
	
	
}
