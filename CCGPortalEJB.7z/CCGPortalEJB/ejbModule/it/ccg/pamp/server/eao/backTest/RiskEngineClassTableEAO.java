package it.ccg.pamp.server.eao.backTest;

import it.ccg.pamp.server.entities.backTest.RiskEngineClassTable;
import it.ccg.pamp.server.entities.backTest.RiskEngineClassTablePK;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RiskEngineClassTableEAO
 */
@Stateless
public class RiskEngineClassTableEAO implements RiskEngineClassTableEAOLocal {

	@PersistenceContext(unitName="STDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	//@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<RiskEngineClassTable> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllRiskEngineClassTable");
    		List<RiskEngineClassTable> riskEngineClassTable = query.getResultList();
    		return riskEngineClassTable;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<RiskEngineClassTable> getSTCgcls00fFutOpt(String cClass) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getRiskEngineClassTableFutOpt");
    		query.setParameter("cClass", cClass);
    		List<RiskEngineClassTable> riskEngineClassTableList = query.getResultList();
    		return riskEngineClassTableList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Risk Engine Class - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<RiskEngineClassTable> findByCClass(String cClass) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getRiskEngineClassTableByCClass");
    		query.setParameter("cClass", cClass);
    		List<RiskEngineClassTable> riskEngineClassTableList = query.getResultList();
    		return riskEngineClassTableList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Risk Engine Class - cClass: "+cClass+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<RiskEngineClassTable> findByCofCod(String cofCod) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getRiskEngineClassTableByCofCod");
    		query.setParameter("cofCod", cofCod);
    		List<RiskEngineClassTable> riskEngineClassTableList = query.getResultList();
    		return riskEngineClassTableList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Risk Engine Class - cofCod: "+cofCod+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public RiskEngineClassTable findByPrimaryKey(String cClass, String cofCod) throws DataNotValidException {
		try {
			RiskEngineClassTablePK pK = new RiskEngineClassTablePK();
			pK.setCclass(cClass);			
			pK.setCofCod(cofCod);
			RiskEngineClassTable riskEngineClassTable = (RiskEngineClassTable) em.find(RiskEngineClassTable.class,pK);
    		return riskEngineClassTable;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Risk Engine class - cClass: "+cClass+"; cofCod: "+cofCod+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
