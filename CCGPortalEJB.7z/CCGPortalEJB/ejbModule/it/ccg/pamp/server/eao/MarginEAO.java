package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.CorporateAction;
import it.ccg.pamp.server.entities.Margin;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondToSync;
import it.ccg.pamp.server.utils.MarginCustomObj;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MarginEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class MarginEAO implements  MarginEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public String userString = "System";
	public String updType = "C";
	
	
	public Margin[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllMargin");
    		List<Margin> margin = query.getResultList();
    		Margin[] arrMargin = new Margin[margin.size()];
    		return margin.toArray(arrMargin);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Margin[] getEnabledMargins() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllEnabledMargin");
    		List<Margin> margin = query.getResultList();
    		Margin[] arrMargin = new Margin[margin.size()];
    		return margin.toArray(arrMargin);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<MarginCustomObj> getDerivativesWithUnderlyingMargins() throws DataNotValidException {
		Query query = null;
		
		String sqlString = "SELECT M.INSTRID,M.PROPOSE, M.USERMARGIN, I.UNDINSTRID, M2.USERMARGIN AS UNDUSERMARGIN "+
							"FROM PMPTMAR M "+
							"INNER JOIN PMPTINSTR I "+
							"ON I.INSTRID = M.INSTRID "+
							"INNER JOIN PMPTMAR M2 "+
							"ON I.UNDINSTRID = M2.INSTRID "+
							"WHERE M.STATUS = 'E' AND M.PROPOSE = 'C' AND I.DIVISCODE = 'D' "+
							"ORDER BY I.UNDINSTRID";
		
		
   			try {
    			query =  em.createNativeQuery(sqlString,MarginCustomObj.class);
    		}  catch (Exception e) {
    			e.getStackTrace();
    		}
    			
    		List<MarginCustomObj> marginCustObjList = query.getResultList();
    		
    		return marginCustObjList;
    }
	
	
	public Margin[] getEnabledMarginsByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllEnabledMarginByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Margin> margin = query.getResultList();
    		Margin[] arrMargin = new Margin[margin.size()];
    		return margin.toArray(arrMargin);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled margins - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	public Margin findByPrimaryKey(int instrId) throws DataNotValidException {
		try {
			Margin margin = (Margin) em.find(Margin.class,instrId);
    		return margin;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching margin - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Margin[] findByClassId(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMarginByClassId");
    		query.setParameter("classId", classId);
    		List<Margin> margin = query.getResultList();
    		Margin[] arrMargin = new Margin[margin.size()];
    		return margin.toArray(arrMargin);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching margin - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public boolean noMarginSubmittedForApproval(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSubmitForApprovalMarginByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Margin> margin = query.getResultList();
    		if (margin.size()>0) {
    			return false;
    		} else {
    			return true;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching submitted margins - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public boolean noMarginSubmittedForApproval() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSubmitForApprovalMargins");
    		List<Margin> margin = query.getResultList();
    		if (margin.size()>0) {
    			return false;
    		} else {
    			return true;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching submitted margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, Timestamp inivDate, Timestamp endvDate, Timestamp sendDate, String status, 
		BigDecimal crMargin, BigDecimal crCover, int crNDaysPer, int crNv, String crVarType, BigDecimal anMargin, 
		BigDecimal anCover, int anNDaysPer, int anNv, String anVarType, BigDecimal userMargin, BigDecimal crMinMar, 
		BigDecimal anMinMar, BigDecimal userMinMar, Timestamp anDate, BigDecimal propCover, BigDecimal propMargin, 
		BigDecimal propMinMar, String approval, int rcCode, String comment, int classId, BigDecimal crNdMar, 
		BigDecimal anNdMar, String propose, String crLog, String anLog, String propLog, BigDecimal userCov, 
		BigDecimal rlMargin, Timestamp crFrstHisD, Timestamp anFrstHisD, Timestamp crLastHisD, 
	    Timestamp anLastHisD, String susp, String custom, String divisCode,  BigDecimal currentMarginBuffer,  BigDecimal anMarginBuffer, 
	    BigDecimal currentNotBufferedMargin, BigDecimal anNotBufferedMargin, String currentCap, String anCap) throws DataNotValidException {
		
		Margin margin = findByPrimaryKey(instrId);

		try {
			margin = new Margin();
			margin.setInstrId(instrId);
			margin.setInivDate(inivDate);
			margin.setEndvDate(endvDate);
			margin.setSendDate(sendDate);
			margin.setStatus(status);
			margin.setCrMargin(crMargin);
			margin.setCrCover(crCover);
			margin.setCrNDaysPer(crNDaysPer);
			margin.setCrNv(crNv);
			margin.setCrVarType(crVarType);
			margin.setAnMargin(anMargin);
			margin.setAnCover(anCover);
			margin.setAnNDaysPer(anNDaysPer);
			margin.setAnNv(anNv);
			margin.setAnVarType(anVarType);
			margin.setUserMargin(userMargin);
			margin.setCrMinMar(crMinMar);
			margin.setAnMinMar(anMinMar);
			margin.setUserMinMar(userMinMar);
			margin.setAnDate(anDate);
			margin.setPropCover(propCover);
			margin.setPropMargin(propMargin);
			margin.setPropMinMar(propMinMar);
			margin.setApproval(approval);
			margin.setRcCode(rcCode);
			margin.setComment(comment);
			margin.setClassId(classId);
			margin.setUpdType(updType);
			margin.setUpdDate(GenericTools.systemDate());
			margin.setUpdUsr(userString());
			margin.setClassId(classId);
			margin.setCrNdMar(crNdMar);
			margin.setAnNdMar(anNdMar);
			margin.setPropose(propose);
			margin.setCrLog(crLog);
			margin.setAnLog(anLog);
			margin.setPropLog(propLog);
			margin.setUserCov(userCov);
			margin.setRlMargin(rlMargin);
			margin.setCrFrstHisD(crFrstHisD);
			margin.setAnFrstHisD(anFrstHisD);
			margin.setCrLastHisD(crLastHisD);
			margin.setAnLastHisD(anLastHisD);
			margin.setSusp(susp);
			margin.setCustom(custom);
			margin.setDivisCode(divisCode);
			
			margin.setCurrentMarginBuffer(currentMarginBuffer);
			margin.setAnMarginBuffer(anMarginBuffer);
			margin.setCurrentNotBufferedMargin(currentNotBufferedMargin);
			margin.setAnNotBufferedMargin(anNotBufferedMargin);
			margin.setCurrentCap(currentCap);
			margin.setAnCap(anCap);
			
			em.persist(margin);
			log.debug("Added new Margin - instrid: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new margin - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(Margin margin) throws DataNotValidException {
		try {
			margin.setUpdType(updType);
			margin.setUpdDate(GenericTools.systemDate());
			margin.setUpdUsr(userString());
			em.persist(margin);
			log.debug("Added new Margin - instrId: "+margin.getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new margin - instrId: "+margin.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void updateCurMar(Margin margin) throws DataNotValidException {
		try {
			Margin margintoUpdate = findByPrimaryKey(margin.getInstrId());
			margintoUpdate.setCrMargin(margin.getCrMargin());
			margintoUpdate.setCrCover(margin.getCrCover());
			log.debug("Updated current margin - instrId: "+margin.getInstrId()+"; currentMargin: "+margin.getCrMargin());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating current margin - instrId:"+margin.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("resetMargin");
			query.setParameter(1, divisCode);
			query.setParameter(2, GenericTools.systemDate());
			query.setParameter(3, userString());
			int result = query.executeUpdate();
			log.debug(result+" disabled margins to instrument disabled status - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating margin to disabled status due to instrument disabled status - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, Timestamp inivDate, Timestamp endvDate, Timestamp sendDate, String status, 
		BigDecimal crMargin, BigDecimal crCover, int crNDaysPer, int crNv, String crVarType, BigDecimal anMargin, 
		BigDecimal anCover, int anNDaysPer, int anNv, String anVarType, BigDecimal userMargin, BigDecimal crMinMar, 
		BigDecimal anMinMar, BigDecimal userMinMar, Timestamp anDate, BigDecimal propCover, BigDecimal propMargin, 
		BigDecimal propMinMar, String approval, int rcCode, String comment, int classId, BigDecimal crNdMar, 
		BigDecimal anNdMar, String propose, String crLog, String anLog, String propLog, BigDecimal userCov, 
		BigDecimal rlMargin, Timestamp crFrstHisD, Timestamp anFrstHisD, Timestamp crLastHisD, 
	    Timestamp anLastHisD, String susp, String custom, String divisCode, BigDecimal currentMarginBuffer,  BigDecimal anMarginBuffer, 
	    BigDecimal currentNotBufferedMargin, BigDecimal anNotBufferedMargin, String currentCap, String anCap) throws DataNotValidException {
		
		try {
			Margin margin = findByPrimaryKey(instrId);
			margin.setInivDate(inivDate);
			margin.setEndvDate(endvDate);
			margin.setSendDate(sendDate);
			margin.setStatus(status);
			margin.setCrMargin(crMargin);
			margin.setCrCover(crCover);
			margin.setCrNDaysPer(crNDaysPer);
			margin.setCrNv(crNv);
			margin.setCrVarType(crVarType);
			margin.setAnMargin(anMargin);
			margin.setAnCover(anCover);
			margin.setAnNDaysPer(anNDaysPer);
			margin.setAnNv(anNv);
			margin.setAnVarType(anVarType);
			margin.setUserMargin(userMargin);
			margin.setCrMinMar(crMinMar);
			margin.setAnMinMar(anMinMar);
			margin.setUserMinMar(userMinMar);
			margin.setAnDate(anDate);
			margin.setPropCover(propCover);
			margin.setPropMargin(propMargin);
			margin.setPropMinMar(propMinMar);
			margin.setApproval(approval);
			margin.setRcCode(rcCode);
			margin.setComment(comment);
			margin.setClassId(classId);
			margin.setUpdType("U");
			margin.setUpdDate(GenericTools.systemDate());
			margin.setUpdUsr(userString());
			margin.setClassId(classId);
			margin.setCrNdMar(crNdMar);
			margin.setAnNdMar(anNdMar);
			margin.setPropose(propose);
			margin.setCrLog(crLog);
			margin.setAnLog(anLog);
			margin.setPropLog(propLog);
			margin.setUserCov(userCov);
			margin.setRlMargin(rlMargin);
			margin.setCrFrstHisD(crFrstHisD);
			margin.setAnFrstHisD(anFrstHisD);
			margin.setCrLastHisD(crLastHisD);
			margin.setAnLastHisD(anLastHisD);
			margin.setSusp(susp);
			margin.setCustom(custom);
			margin.setDivisCode(divisCode);
			
			margin.setCurrentMarginBuffer(currentMarginBuffer);
			margin.setAnMarginBuffer(anMarginBuffer);
			margin.setCurrentNotBufferedMargin(currentNotBufferedMargin);
			margin.setAnNotBufferedMargin(anNotBufferedMargin);
			margin.setCurrentCap(currentCap);
			margin.setAnCap(anCap);
			
			log.debug("Updated margin - instrId: "+margin.getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating margin - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(Margin mar) throws DataNotValidException {
		Margin margin = findByPrimaryKey(mar.getInstrId());
		try {
			margin.setUpdType("U");
			margin.setUpdDate(GenericTools.systemDate());
			margin.setUpdUsr(userString());
			log.debug("Updated margin - instrId: "+margin.getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating margin - instrId: "+margin.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void resetAllUserMinMar(String divisCode) throws DataNotValidException {
		Query query = null;
    	
		
		
    	try {
    		
    		query = em.createNativeQuery("UPDATE PMPTMAR SET USERMINMAR = 0, UPDUSR = '"+userString()+"', UPDTYPE = 'U', UPDDATE = '"+GenericTools.systemDate()+"' WHERE DIVISCODE ='"+divisCode+"' ");
    		
    		int reset = query.executeUpdate();
    		   		
    		log.debug("reset of "+reset+" "+GenericTools.getWholeDivisCode(divisCode)+" user minimum margins has been completed");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error resetting "+ GenericTools.getWholeDivisCode(divisCode)+" user minimum margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void resetAllCashUserMinMar() throws DataNotValidException {
		Query query = null;
    	
		String strQuery = "";
		
    	try {
    		strQuery = "UPDATE PMPTMAR SET USERMINMAR = 0, UPDUSR = '"+userString()+"', UPDTYPE = 'U', UPDDATE = '"+GenericTools.systemDate()+"' ";
    		strQuery += "WHERE DIVISCODE ='E' AND INSTRID NOT IN (SELECT UNDINSTRID FROM PMPTINSTR WHERE DIVISCODE = 'D' AND STATUS = 'E') ";
    		
    		query = em.createNativeQuery(strQuery);
    		int reset = query.executeUpdate();
    		   		
    		log.debug("reset of "+reset+" "+GenericTools.getWholeDivisCode("E")+" user minimum margins has been completed");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error resetting "+ GenericTools.getWholeDivisCode("E")+" user minimum margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void logUpdate(Margin mar) throws DataNotValidException {
		try {
			update(mar);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating margin - instrId: "+mar.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId) throws DataNotValidException {
		try {
			Margin margin = findByPrimaryKey(instrId);
			em.remove(margin);
			log.debug("Removed margin - instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing margin - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(Margin mar) throws DataNotValidException {
		remove(mar.getInstrId());
	}
	
	public int removeByClassId(int classId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteMarginByClassId");
			query.setParameter("classId", classId);
			int result = query.executeUpdate();
			log.debug(result+" margin removed - classId: "+classId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing margin - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
}
