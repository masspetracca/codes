package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.stressTest.StressTestMember;
import it.ccg.pamp.server.entities.stressTest.StressTestMemberPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.MemberForReport;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;


@Stateless
@SuppressWarnings("unchecked")
public class StressTestMemberEAO implements  StressTestMemberEAOLocal {

	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	public List<StressTestMember> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllStressTestMember");
    		List<StressTestMember> stressTestMemberList = query.getResultList();
    		return stressTestMemberList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	
	public StressTestMember findByPrimaryKey(int mbrId, String scenario, int stId) throws DataNotValidException {
		try {
			StressTestMemberPK pK = new StressTestMemberPK();
			
			pK.setMbrId(mbrId);
			pK.setScenario(scenario);
			pK.setStId(stId);
			
			StressTestMember stressTestStatistic = (StressTestMember) em.find(StressTestMember.class,pK);
    		return stressTestStatistic;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member statistic - memberId: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<StressTestMember> getStressTestMemberByMbrId(int mbrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestMemberByMbrId");
    		query.setParameter("mbrId", mbrId);
    		List<StressTestMember> stressTestMemberList = query.getResultList();
    		return stressTestMemberList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member - memberId: "+mbrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestMember> getStressTestMemberByStId(int stId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestMemberByStId");
    		query.setParameter("stId", stId);
    		List<StressTestMember> stressTestMemberList = query.getResultList();
    		return stressTestMemberList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member - stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestMember> getStressTestMemberByScenario(String scenario) throws DataNotValidException {
		Query query = null;
		
		try {
    		query = em.createNamedQuery("getStressTestMemberByScenario");
    		query.setParameter("scenario", scenario);
    		List<StressTestMember> stressTestMemberList = query.getResultList();
    		return stressTestMemberList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member - scenario: "+GenericTools.scenarioDesc(scenario)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestMember> getStressTestMemberByMbrIdAndStId(int mbrId, int stId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestMemberByMbrIdAndStId");
    		query.setParameter("mbrId", mbrId);
    		query.setParameter("stId", stId);
    		List<StressTestMember> stressTestMemberList = query.getResultList();
    		return stressTestMemberList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member statistic - memberId: "+mbrId+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestMember> getStressTestMemberByStIdAndScenario(int stId, String scenario) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestMemberByStIdAndScenario");
    		query.setParameter("stId", stId);
    		query.setParameter("scenario", scenario);
    		List<StressTestMember> stressTestMemberList = query.getResultList();
    		return stressTestMemberList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member statistic - stress test id: "+stId+"; scenario: "+GenericTools.scenarioDesc(scenario)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestMember> getStressTestMemberByMbrIdAndScenario(int mbrId, String scenario) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestMemberByMbrIdAndScenario");
    		query.setParameter("mbrId", mbrId);
    		query.setParameter("scenario", scenario);
    		List<StressTestMember> stressTestMemberList = query.getResultList();
    		return stressTestMemberList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member statistic - member id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
public String getMemberReportForMail(String divisCode) throws DataNotValidException {
		
		Query query = null;
    	
		try {
    		
			String sqlString =  "SELECT ROW_NUMBER() OVER(ORDER BY M.NCE ASC) AS RANK, "+ 
							    "M.SCENARIO, M.STID, M.MBRID, M.GMBRID, M.MBRDESC,M.HNRMMAR AS FIRMINITIALMARGIN, M.CNRMMAR AS CLIENTINITIALMARGIN, M.HSTRMAR AS FIRMCASHCALL, M.CSTRMAR AS CLIENTCASHCALL, M.NCE, "+
							    "(SELECT SUM(M1.NCE) FROM PMPTSTMBR M1 "+
								"WHERE M1.STID=M.STID AND M1.SCENARIO=M.SCENARIO AND M.NCE>=M1.NCE) AS CUM, "+
								"(SELECT SUM(M1.NCE) FROM PMPTSTMBR M1 "+
								"WHERE M1.STID=M.STID AND M1.SCENARIO=M.SCENARIO AND M.NCE<=M1.NCE) AS RCUM, "+
							    "(SELECT SUM(M1.NCE) FROM PMPTSTMBR M1 WHERE M1.STID=M.STID AND M1.SCENARIO=M.SCENARIO) AS GLOBALSUM "+
							    "FROM PMPTSTMBR M "+
							    "WHERE M.STID = (SELECT MAX(STID) FROM PMPTST WHERE DIVISCODE = '"+divisCode+"') "+
							    "AND M.SCENARIO <> '0' "+
							    "ORDER BY M.SCENARIO, M.NCE ASC";  
    		
    		query =  em.createNativeQuery(sqlString,MemberForReport.class);
    		List<MemberForReport> memberList = query.getResultList();

    		String html = "";
    		
    		if (memberList.size()>0) {
    		
    			String htmlHead = "<table align=\"center\" cellspacing=0 style=\"border:1px solid black; font-size:11px; font-family:Arial\">"+
    			"<thead style=\" background-color:#cecece;font-weight:bold\">"+
    			"<tr style=\"border:1px solid black\">"+
    			"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Member ID </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;text-align:center;\"> Member Description </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Stress test ID </th>"+
				//"<th> Scenario </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Home cash call </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Client cash call </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Home initial margin </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Client initial margin </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> ENC </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Cum</th>"+
				"<th style=\"border-bottom:1px solid black;width:80px;text-align:center;\"> Retro cum.</th>"+
				//"<th> Sum</th>"+
				"</tr>"+
				"</thead>";
    			
    			String lastScenario = "";
    			
    			for (MemberForReport member:memberList) {
    				
    				if (member.getScenario().equalsIgnoreCase(lastScenario)) {
    					html += "<tbody style=\"border-bottom:1px solid black;border-right:1px solid black; text-align:center\">";
    					html += "<tr>";
        				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black\"> "+member.getMbrId()+"</td>";
        				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;text-align:left\"> "+member.getMbrDesc()+"</td>";
        				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+member.getStId()+"</td>";
        				//html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.scenarioFromAcronymous(member.getScenario())+"</td>";
        				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.formatNumber(member.getFirmCashcall())+"</td>";
        				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.formatNumber(member.getClientCashCall())+"</td>";
        				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.formatNumber(member.getFirmInitialMargin())+"</td>";
        				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.formatNumber(member.getClientInitialMargin())+"</td>";
        				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.formatNumber(member.getNce())+"</td>";
        				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.formatNumber(member.getCum())+"</td>";
        				html += "<td style=\"border-bottom:1px solid black\"> "+GenericTools.formatNumber(member.getRcum())+"</td>";
        				//html += "<td style=\"border:1px solid black\"> "+GenericTools.formatNumber(member.getGlobalSum())+"</td>";
        				html += "</tr>";
    				} else {
    					if (!lastScenario.equalsIgnoreCase("")) {
    						html += "</table><br><br>";
    					}	
    					html += "<p style=\"font-family:Arial;font-size:14px;font-weight:bold;text-align:center\">Scenario: "+GenericTools.scenarioFromAcronymous(member.getScenario())+"</p>";
    					html +=htmlHead;
    					lastScenario = member.getScenario();	
    				}
					
    			
    			
    			}
    			
    			html += "</table>";

    		}
    		return html;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from member statistic table - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int mbrId, String scenario, int stId, BigDecimal cnrMmar, BigDecimal cStrMar, String gMbrDesc, int gMbrId, Timestamp histUpdDay,
			BigDecimal hnrMmar, BigDecimal hStrMar, String log, String mbrDesc, BigDecimal nce, int nDaysPer, String nvVec,BigDecimal ordMargin, BigDecimal mtmMargin, BigDecimal mia) throws DataNotValidException {
		
		try {
			StressTestMember stressTestMember = new StressTestMember();
			
			StressTestMemberPK pK = new StressTestMemberPK();
			
			pK.setMbrId(mbrId);
			pK.setScenario(scenario);
			pK.setStId(stId);
			
			stressTestMember.setPk(pK);
			
			stressTestMember.setCnrMmar(cnrMmar);
			stressTestMember.setCStrMar(cStrMar);
			stressTestMember.setGMbrDesc(gMbrDesc);
			stressTestMember.setGMbrId(gMbrId);
			stressTestMember.setHistUpdDay(histUpdDay);
			stressTestMember.setHnrMmar(hnrMmar);
			stressTestMember.setHStrMar(hStrMar);
			stressTestMember.setLog(log);
			stressTestMember.setMbrDesc(mbrDesc);
			stressTestMember.setNce(nce);
			stressTestMember.setNDaysPer(nDaysPer);
			stressTestMember.setNvVec(nvVec);
			stressTestMember.setOrdMargin(ordMargin);
			stressTestMember.setMtmMargin(mtmMargin);
			stressTestMember.setMia(mia);
			
			stressTestMember.setUpdType(updType);
			stressTestMember.setUpdDate(GenericTools.systemDate());
			stressTestMember.setUpdUsr(userString());
			
			em.persist(stressTestMember);
			userLog.debug("Added new stress test member statistic - member Id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test member statistic - member Id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(StressTestMember stressTestMember) throws DataNotValidException {
		
		try {
			
			stressTestMember.setUpdType(updType);
			stressTestMember.setUpdDate(GenericTools.systemDate());
			stressTestMember.setUpdUsr(userString());
			em.persist(stressTestMember);
			userLog.debug("Added new stress test member statistic - member id: "+stressTestMember.getPk().getMbrId()+"; scenario: "+GenericTools.scenarioDesc(stressTestMember.getPk().getScenario())+"; stress test id: "+stressTestMember.getPk().getStId());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test member statistic - member id: "+stressTestMember.getPk().getMbrId()+"; scenario: "+GenericTools.scenarioDesc(stressTestMember.getPk().getScenario())+"; stress test id: "+stressTestMember.getPk().getStId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int mbrId, String scenario, int stId, BigDecimal cnrMmar, BigDecimal cStrMar, String gMbrDesc, int gMbrId, Timestamp histUpdDay,
			BigDecimal hnrMmar, BigDecimal hStrMar, String log, String mbrDesc, BigDecimal nce, int nDaysPer, String nvVec, BigDecimal ordMargin, BigDecimal mtmMargin, BigDecimal mia) throws DataNotValidException {
		
		try {
			StressTestMember stressTestMember = this.findByPrimaryKey(mbrId, scenario, stId);
			
			stressTestMember.setCnrMmar(cnrMmar);
			stressTestMember.setCStrMar(cStrMar);
			stressTestMember.setGMbrDesc(gMbrDesc);
			stressTestMember.setGMbrId(gMbrId);
			stressTestMember.setHistUpdDay(histUpdDay);
			stressTestMember.setHnrMmar(hnrMmar);
			stressTestMember.setHStrMar(hStrMar);
			stressTestMember.setLog(log);
			stressTestMember.setMbrDesc(mbrDesc);
			stressTestMember.setNce(nce);
			stressTestMember.setNDaysPer(nDaysPer);
			stressTestMember.setNvVec(nvVec);
			stressTestMember.setOrdMargin(ordMargin);
			stressTestMember.setMtmMargin(mtmMargin);
			stressTestMember.setMia(mia);
			
			stressTestMember.setUpdType(updType);
			stressTestMember.setUpdDate(GenericTools.systemDate());
			stressTestMember.setUpdUsr(userString());
			
			userLog.debug("Updated stress test member statistic - member Id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stress test member statistic - member Id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(StressTestMember stressTestMember) throws DataNotValidException {
		
		try {
			userLog.debug("Updated stress test member statistic - member id: "+stressTestMember.getPk().getMbrId()+"; scenario: "+GenericTools.scenarioDesc(stressTestMember.getPk().getScenario())+"; stress test id: "+stressTestMember.getPk().getStId());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stress test member statistic - member id: "+stressTestMember.getPk().getMbrId()+"; scenario: "+GenericTools.scenarioDesc(stressTestMember.getPk().getScenario())+"; stress test id: "+stressTestMember.getPk().getStId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int mbrId, String scenario, int stId) throws DataNotValidException {
		try {
			StressTestMember stressTestMember = this.findByPrimaryKey(mbrId, scenario, stId);
			em.remove(stressTestMember);
			userLog.debug("Stress test member statistic removed - member Id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member statistic - member Id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId);
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByMbrId(int mbrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("removeStressTestMemberByMbrId");
			query.setParameter("mbrId", mbrId);
			int result = query.executeUpdate();
			userLog.debug(result+" stress test member removed - member id: "+mbrId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member - member id: "+mbrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByStId(int stId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("removeStressTestMemberByStId");
			query.setParameter("stId", stId);
			int result = query.executeUpdate();
			userLog.debug(result+" stress test member removed - stress test id: "+stId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member - stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByScenario(String scenario) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("removeStressTestMemberByScenario");
			query.setParameter("scenario", scenario);
			int result = query.executeUpdate();
			userLog.debug(result+" stress test member removed - scenario: "+GenericTools.scenarioDesc(scenario));
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member - scenario: "+GenericTools.scenarioDesc(scenario)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public int removeByMbrIdAndStId(int mbrId, int stId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("removeStressTestMemberByMbrIdAndStId");
			query.setParameter("mbrId", mbrId);
			query.setParameter("stId", stId);
			int result = query.executeUpdate();
			userLog.debug(result+" stress test member removed - member id: "+mbrId+"; stress test id: "+stId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member - member id: "+mbrId+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByMbrIdAndScenario(int mbrId, String scenario) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("removeStressTestMemberByMbrIdAndScenario");
			query.setParameter("mbrId", mbrId);
			query.setParameter("scenario", scenario);
			int result = query.executeUpdate();
			userLog.debug(result+" stress test member removed - member id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario));
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member - member id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByStIdAndScenario(int stId, String scenario) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("removeStressTestMemberByStIdAndScenario");
			query.setParameter("stId", stId);
			query.setParameter("scenario", scenario);
			int result = query.executeUpdate();
			userLog.debug(result+" stress test member removed - stress test id: "+stId+"; scenario: "+GenericTools.scenarioDesc(scenario));
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member - stress test id: "+stId+"; scenario: "+GenericTools.scenarioDesc(scenario)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void remove(StressTestMember stressTestMember) throws DataNotValidException {
		this.remove(stressTestMember.getPk().getMbrId(),stressTestMember.getPk().getScenario(),stressTestMember.getPk().getStId());
	}

}
