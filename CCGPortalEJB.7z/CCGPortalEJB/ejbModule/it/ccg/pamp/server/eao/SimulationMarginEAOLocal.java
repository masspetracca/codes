package it.ccg.pamp.server.eao;
import java.math.BigDecimal;

import it.ccg.pamp.server.entities.SimulationMargin;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface SimulationMarginEAOLocal {
	public SimulationMargin[] fetch() throws DataNotValidException;
	public SimulationMargin findByPrimaryKey(int instrId) throws DataNotValidException; 
	public void add(int instrId, BigDecimal margin, BigDecimal cover, int nDaysPer, int nV, String varType) throws DataNotValidException;
	public void store(SimulationMargin simMargin) throws DataNotValidException; 
	public void updateMargin(SimulationMargin simMargin) throws DataNotValidException;
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException;
	public void update(int instrId, BigDecimal margin, BigDecimal cover, int nDaysPer, int nV, String varType) throws DataNotValidException; 
	public void update(SimulationMargin simMar) throws DataNotValidException; 
	public void remove(int instrId) throws DataNotValidException;
	public void remove(SimulationMargin simMargin) throws DataNotValidException;
}
