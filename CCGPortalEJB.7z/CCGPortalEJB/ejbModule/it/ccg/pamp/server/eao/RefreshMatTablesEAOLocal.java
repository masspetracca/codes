package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface RefreshMatTablesEAOLocal {
	
	public String refreshEquitiesMaterializedQuery() throws DataNotValidException;
	
	public String refreshBondMaterializedQuery() throws DataNotValidException;
	
	public String refreshComparableMaterializedQuery() throws DataNotValidException;
	
	 public String refreshEqStressTestMaterializedQuery() throws DataNotValidException;
	
	public String refreshMaterializedQuery(String divisCode) throws DataNotValidException;
	
	public String refreshInterestRatesCurve() throws DataNotValidException;

}
