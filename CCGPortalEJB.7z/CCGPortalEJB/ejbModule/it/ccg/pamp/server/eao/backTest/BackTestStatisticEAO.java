package it.ccg.pamp.server.eao.backTest;

import it.ccg.pamp.server.entities.backTest.BackTestStatistic;
import it.ccg.pamp.server.entities.backTest.BackTestBreachPK;
import it.ccg.pamp.server.entities.backTest.BackTestStatisticPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BackTestStatisticEAO
 */
@Stateless
public class BackTestStatisticEAO implements BackTestStatisticEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}

	public String userString = "System";
	public String updType = "C";
	
	
	
	public List<BackTestStatistic> fetchAllBackTestStatistics() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllBackTestStatistics");
    		List<BackTestStatistic> backTestStatisticList = query.getResultList();
    		return backTestStatisticList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test statistics list - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	public List<BackTestStatistic> getBackTestStatisticsByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBackTestStatisticsByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<BackTestStatistic> backTestStatisticList = query.getResultList();
    		return backTestStatisticList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test statistics list - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<BackTestStatistic> getBackTestStatisticsByBtId(int btId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBackTestStatisticsByBtId");
    		query.setParameter("btId", btId);
    		List<BackTestStatistic> backTestStatisticList = query.getResultList();
    		return backTestStatisticList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test statistics list - back test id: "+btId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public BackTestStatistic findByPrimaryKey(int btId, int classId) throws DataNotValidException {
		try {
    		
			BackTestStatisticPK pK = new BackTestStatisticPK();
			
			pK.setBtId(btId);
			pK.setClassId(classId);
			
			BackTestStatistic backTestStatistic = (BackTestStatistic) em.find(BackTestStatistic.class,pK);
    		
			return backTestStatistic;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test statistic - backTestId: "+btId+"; classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void add(int btId, int classId, String divisCode, String log, int nDaysPer, int onDateBrch, BigDecimal onDateCov, String status, int wrkBrch, BigDecimal wrkCov, int nVars) throws DataNotValidException {
		
		try {
			BackTestStatistic backTestStatistic = new BackTestStatistic();
			
			BackTestStatisticPK pK = new BackTestStatisticPK();
			
			pK.setBtId(btId);
			pK.setClassId(classId);
			
			backTestStatistic.setPk(pK);
			
			backTestStatistic.setDivisCode(divisCode);
			backTestStatistic.setLog(log);
			backTestStatistic.setnDaysPer(nDaysPer);
			backTestStatistic.setOnDateBrch(onDateBrch);
			backTestStatistic.setOnDateCov(onDateCov);
			backTestStatistic.setStatus(status);
			
			backTestStatistic.setWrkBrch(wrkBrch);
			backTestStatistic.setWrkCov(wrkCov);
			
			backTestStatistic.setNvars(nVars);
			
			backTestStatistic.setUpdDate(GenericTools.systemDate());
			backTestStatistic.setUpdType("C");
			backTestStatistic.setUpdUsr(userString());
			
			em.persist(backTestStatistic);
			
			userLog.debug("Added new back test statistic - back test id: "+btId+"; classId: "+classId);
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new back test statistic - back test id: "+btId+"; classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	
	public void store(BackTestStatistic backTestStatistic) throws DataNotValidException {
		
		try {
			
			backTestStatistic.setUpdDate(GenericTools.systemDate());
			backTestStatistic.setUpdType("C");
			backTestStatistic.setUpdUsr(userString());
			
			em.persist(backTestStatistic);
			
			userLog.debug("Added new back test statistic - back test id: "+backTestStatistic.getPk().getBtId()+"; classId: "+backTestStatistic.getPk().getClassId());
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new back test statistic - back test id: "+backTestStatistic.getPk().getBtId()+"; classId: "+backTestStatistic.getPk().getClassId()+ " - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	
	public void update(int btId, int classId, String divisCode, String log, int nDaysPer, int onDateBrch, BigDecimal onDateCov, String status, int wrkBrch, BigDecimal wrkCov, int nVars) throws DataNotValidException {
		
		try {
			BackTestStatistic backTestStatistic = this.findByPrimaryKey(btId, classId);
			
			backTestStatistic.setDivisCode(divisCode);
			backTestStatistic.setLog(log);
			backTestStatistic.setnDaysPer(nDaysPer);
			backTestStatistic.setOnDateBrch(onDateBrch);
			backTestStatistic.setOnDateCov(onDateCov);
			backTestStatistic.setStatus(status);
			
			backTestStatistic.setWrkBrch(wrkBrch);
			backTestStatistic.setWrkCov(wrkCov);
			
			backTestStatistic.setNvars(nVars);

			
			backTestStatistic.setUpdDate(GenericTools.systemDate());
			backTestStatistic.setUpdType("U");
			backTestStatistic.setUpdUsr(userString());
			
			userLog.debug("Updated back test statistic - back test id: "+btId+"; classId: "+classId);
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating back test statistic - back test id: "+btId+"; classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	
	public void remove(int btId, int classId) throws DataNotValidException {
		
		try {
			BackTestStatistic backTestStatistic = this.findByPrimaryKey(btId, classId);
			
			em.remove(backTestStatistic);
			
			userLog.debug("Removed back test statistic - back test id: "+btId+"; classId: "+classId);
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing back test statistic - back test id: "+btId+"; classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	
	public void remove(BackTestStatistic backTestStatistic) throws DataNotValidException {
		
		this.remove(backTestStatistic.getPk().getBtId(),backTestStatistic.getPk().getClassId());
		
	}

}
