package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ETFIncome;
import it.ccg.pamp.server.entities.ETFIncomePK;
import it.ccg.pamp.server.entities.RankedVariation;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ETFIncomeEAO
 */
@Stateless
public class ETFIncomeEAO implements  ETFIncomeEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public ETFIncome[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllETF");
    		List<ETFIncome> etfIncome = query.getResultList();
    		ETFIncome[] arrETFIncome = new ETFIncome[etfIncome.size()];
    		return etfIncome.toArray(arrETFIncome);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching ETF Incomes - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ETFIncome findByPrimaryKey(int instrId, Timestamp incomeDate) throws DataNotValidException {
		try {
			ETFIncomePK pK = new ETFIncomePK();
			pK.setInstrId(instrId);
			pK.setIncomeDate(incomeDate);
			ETFIncome etfIncome = (ETFIncome) em.find(ETFIncome.class,pK);
    		return etfIncome;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching ETF Income - instrId: "+instrId+"; incomeDate: "+incomeDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ETFIncome[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getETFByInstrId");
    		query.setParameter("instrId", instrId);
    		List<ETFIncome> etfIncome = query.getResultList();
    		ETFIncome[] arrETFIncome = new ETFIncome[etfIncome.size()];
    		return etfIncome.toArray(arrETFIncome);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching ETF Incomes - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, Timestamp incomeDate, BigDecimal incomeValue, BigDecimal kRett) throws DataNotValidException {
		try {
			ETFIncome etfIncome = findByPrimaryKey(instrId, incomeDate);
			ETFIncomePK pK = new ETFIncomePK();
			pK.setInstrId(instrId);
			pK.setIncomeDate(incomeDate);
			etfIncome.setPk(pK);
			etfIncome.setIncomeValue(incomeValue);
			etfIncome.setKRett(kRett);
			etfIncome.setUpdType(updType);
			etfIncome.setUpdDate(GenericTools.systemDate());
			etfIncome.setUpdUsr(userString());
			em.persist(etfIncome);
			log.debug("Added new ETF Income - instrId: "+instrId+"; incomeDate: "+incomeDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new ETF Income - instrId: "+instrId+"; incomeDate: "+incomeDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(ETFIncome etfIncome) throws DataNotValidException {
		try {
			etfIncome.setUpdType(updType);
			etfIncome.setUpdDate(GenericTools.systemDate());
			etfIncome.setUpdUsr(userString());
			em.persist(etfIncome);
			log.debug("Added new ETF Income - instrId: "+etfIncome.getPk().getInstrId()+"; incomeDate: "+etfIncome.getPk().getIncomeDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new ETF Income - instrId: "+etfIncome.getPk().getInstrId()+"; incomeDate: "+etfIncome.getPk().getIncomeDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, Timestamp incomeDate, BigDecimal incomeValue, BigDecimal kRett) throws DataNotValidException {
		try {
			ETFIncome etfIncome = findByPrimaryKey(instrId, incomeDate);
			etfIncome.setIncomeValue(incomeValue);
			etfIncome.setKRett(kRett);
			etfIncome.setUpdType("U");
			etfIncome.setUpdDate(GenericTools.systemDate());
			etfIncome.setUpdUsr(userString());
			log.debug("ETF Income updated - instrId: "+instrId+"; incomeDate: "+incomeDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating ETF Income - instrId: "+instrId+"; incomeDate: "+incomeDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(ETFIncome etf) throws DataNotValidException {
		try {
			ETFIncome etfIncome = findByPrimaryKey(etf.getPk().getInstrId(), etf.getPk().getIncomeDate());
			etfIncome.setUpdType("U");
			etfIncome.setUpdDate(GenericTools.systemDate());
			etfIncome.setUpdUsr(userString());
			log.debug("ETF Income updated - instrId: "+etf.getPk().getInstrId()+"; incomeDate: "+etf.getPk().getIncomeDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating ETF Income - instrId: "+etf.getPk().getInstrId()+"; incomeDate: "+etf.getPk().getIncomeDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, Timestamp incomeDate) throws DataNotValidException {
		try {
			ETFIncome etfIncome = findByPrimaryKey(instrId, incomeDate);
			em.remove(etfIncome);
			log.debug("ETF Income removed - instrId: "+instrId+"; incomeDate: "+incomeDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing ETF Income - instrId: "+instrId+"; incomeDate: "+incomeDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteETFByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" ETF Income removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing ETF Income - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(ETFIncome etfIncome) throws DataNotValidException {
		remove(etfIncome.getPk().getInstrId(),etfIncome.getPk().getIncomeDate());
	}
	
}
