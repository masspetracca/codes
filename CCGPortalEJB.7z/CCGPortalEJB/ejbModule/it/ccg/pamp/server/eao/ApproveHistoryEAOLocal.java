package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.ApproveHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface ApproveHistoryEAOLocal {

	public List<ApproveHistory> fetch() throws DataNotValidException;
	
	public ApproveHistory findByPrimaryKey(int approveId) throws DataNotValidException;
	
	public void store(String divisCode, Timestamp apprDate) throws DataNotValidException;
	
}
