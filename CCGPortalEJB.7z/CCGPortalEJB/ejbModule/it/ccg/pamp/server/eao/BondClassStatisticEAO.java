package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.BondClassStatistic;
import it.ccg.pamp.server.entities.BondClassStatisticPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BondClassStatisticEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class BondClassStatisticEAO implements  BondClassStatisticEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public BondClassStatistic[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllBondClassStat");
    		List<BondClassStatistic> bondClassStatistic = query.getResultList();
    		BondClassStatistic[] arrBondClassStatistic = new BondClassStatistic[bondClassStatistic.size()];
    		return bondClassStatistic.toArray(arrBondClassStatistic);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Bond Class Statistics - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BondClassStatistic[] fetchWithMode1() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllBondClassStatWithMode1");
    		List<BondClassStatistic> bondClassStatistic = query.getResultList();
    		BondClassStatistic[] arrBondClassStatistic = new BondClassStatistic[bondClassStatistic.size()];
    		return bondClassStatistic.toArray(arrBondClassStatistic);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Bond Class Statistics with mode 1 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BondClassStatistic findByPrimaryKey(int instrId1, int instrId2, int nDaysPer, int nv, int mode) throws DataNotValidException {
		try {
			BondClassStatisticPK pK = new BondClassStatisticPK();
			pK.setInstrId1(instrId1);
			pK.setInstrid2(instrId2);
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			pK.setMode(mode);
			BondClassStatistic bondClassStatistic = (BondClassStatistic) em.find(BondClassStatistic.class,pK);
    		return bondClassStatistic;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Bond Class Statistics - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period:"+nv+"; mode:"+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BondClassStatistic[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBondClassStatisticByInstrId");
    		query.setParameter("instrId", instrId);
    		List<BondClassStatistic> bondClassStatistic = query.getResultList();
    		BondClassStatistic[] arrBondClassStatistic = new BondClassStatistic[bondClassStatistic.size()];
    		return bondClassStatistic.toArray(arrBondClassStatistic);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Bond Class Statistics - instrId1: "+instrId+" OR instrId2: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BondClassStatistic getIntraClassMinimum(int classId, String corrType) throws DataNotValidException  {
		Query query = null;
		String corrTypeName="";
    	try {
    		if (corrType.equals("C")) {
    			corrTypeName = "correl";
    			query = em.createNamedQuery("getIntraMinCorrelForBondClassStat");
    		} else if (corrType.equals("P")) {
    			corrTypeName = "pearson";
    			query = em.createNamedQuery("getIntraMinPearsonForBondClassStat");
    		} else if (corrType.equals("D")) {
    			corrTypeName = "divundiv";
    			query = em.createNamedQuery("getIntraMinDivundivForBondClassStat");
    		} else if (corrType.equals("H")) {
    			corrTypeName = "histdays";
    			query = em.createNamedQuery("getIntraMinHistDaysForBondClassStat");
    		}
    		query.setParameter("classId", classId);
    		query.setMaxResults(1);
    		List<BondClassStatistic> bondClassStatisticList = query.getResultList();
    		
    		if (bondClassStatisticList.size()>0) {
	    		BondClassStatistic bondClassStatistic = bondClassStatisticList.get(0);
	    		return bondClassStatistic;
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching intraClass minimum "+corrTypeName+" for Bond Class Statistics - classid: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BondClassStatistic getInterClassMinimum(int classId1, int classId2, String corrType) throws DataNotValidException  {
		Query query = null;
		String corrTypeName="";
    	try {
    		if (corrType.equals("C")) {
    			corrTypeName = "correl";
    			query = em.createNamedQuery("getInterMinCorrelForBondClassStat");
    		} else if (corrType.equals("P")) {
    			corrTypeName = "pearson";
    			query = em.createNamedQuery("getInterMinPearsonForBondClassStat");
    		} else if (corrType.equals("D")) {
    			corrTypeName = "divundiv";
    			query = em.createNamedQuery("getInterMinDivundivForBondClassStat");
    		} else if (corrType.equals("H")) {
    			corrTypeName = "histdays";
    			query = em.createNamedQuery("getInterMinHistDaysForBondClassStat");
    		}
    		query.setParameter("classId1", classId1);
    		query.setParameter("classId2", classId2);
    		query.setMaxResults(1);
    		List<BondClassStatistic> bondClassStatisticList = query.getResultList();
    		if (bondClassStatisticList.size()>0) {
	    		BondClassStatistic bondClassStatistic = bondClassStatisticList.get(0);
	    		return bondClassStatistic;
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching interClass minimum "+corrTypeName+" for Bond Class Statistics - classid1: "+classId1+"; classId2: "+classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}	
	
	public Integer[] getDistinctInstrId1() throws DataNotValidException  {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDistinctInstrId1ForBondClassStatistic");
    		List<Integer> instrId1 = query.getResultList();
    		Integer[] arrInstrId1 = new Integer[instrId1.size()];
    		return instrId1.toArray(arrInstrId1);    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching instrId1 list for Bond Class Statistics - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BondClassStatistic[] findByInstrIdEither(int instrId1,int instrId2) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBondClassStatisticByInstrIdEither");
    		query.setParameter("instrId1", instrId1);
    		query.setParameter("instrId2", instrId2);
    		List<BondClassStatistic> bondClassStatistic = query.getResultList();
    		BondClassStatistic[] arrBondClassStatistic = new BondClassStatistic[bondClassStatistic.size()];
    		return bondClassStatistic.toArray(arrBondClassStatistic);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Bond Class Statistics - instrId1: "+instrId1+"; instrId2: "+instrId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId1, int instrId2, int nDaysPer, int nv, int mode, int classId1, int classId2, BigDecimal correl, BigDecimal pearson, BigDecimal divundiv, int histDays, String status) throws DataNotValidException {
		try {
			BondClassStatistic bondClassStatistic = new BondClassStatistic();
			BondClassStatisticPK pK = new BondClassStatisticPK();
			pK.setInstrId1(instrId1);
			pK.setInstrid2(instrId2);
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			pK.setMode(mode);
			bondClassStatistic.setPk(pK);
			bondClassStatistic.setClassId1(classId1);
			bondClassStatistic.setClassId2(classId2);
			bondClassStatistic.setCorrel(correl);
			bondClassStatistic.setPearson(pearson);
			bondClassStatistic.setDivundiv(divundiv);
			bondClassStatistic.setHistdays(histDays);
			bondClassStatistic.setStatus(status);
			bondClassStatistic.setUpdDate(GenericTools.systemDate());
			bondClassStatistic.setUpdType(updType);
			bondClassStatistic.setUpdUsr(userString());
			em.persist(bondClassStatistic);
			log.debug("Added new Bond Class Statistic - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period:"+nv+"; mode:"+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding Bond Class Statistics - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period:"+nv+"; mode:"+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public void store(BondClassStatistic bondClassStatistic) throws DataNotValidException {
		try {
			bondClassStatistic.setUpdDate(GenericTools.systemDate());
			bondClassStatistic.setUpdType(updType);
			bondClassStatistic.setUpdUsr(userString());
			//System.out.println(bondClassStatistic.toString());
			em.persist(bondClassStatistic);
			log.debug("Added new Bond Class Statistic - instrId1: "+bondClassStatistic.getPk().getInstrId1()+"; instrId2: "+bondClassStatistic.getPk().getInstrId2()+"; nDaysPer: "+bondClassStatistic.getPk().getNDaysPer()+"; holding period:"+bondClassStatistic.getPk().getNv()+"; mode:"+bondClassStatistic.getPk().getMode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding Bond Class Statistics - instrId1: "+bondClassStatistic.getPk().getInstrId1()+"; instrId2: "+bondClassStatistic.getPk().getInstrId2()+"; nDaysPer: "+bondClassStatistic.getPk().getNDaysPer()+"; holding period:"+bondClassStatistic.getPk().getNv()+"; mode:"+bondClassStatistic.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId1, int instrId2, int nDaysPer, int nv, int mode, int classId1, int classId2, BigDecimal correl, BigDecimal pearson, BigDecimal divundiv, int histDays, String status) throws DataNotValidException {
		try {
			BondClassStatistic bondClassStatistic = findByPrimaryKey(instrId1, instrId2, nDaysPer, nv, mode);
			bondClassStatistic.setClassId1(classId1);
			bondClassStatistic.setClassId2(classId2);
			bondClassStatistic.setCorrel(correl);
			bondClassStatistic.setPearson(pearson);
			bondClassStatistic.setDivundiv(divundiv);
			bondClassStatistic.setHistdays(histDays);
			bondClassStatistic.setStatus(status);
			bondClassStatistic.setUpdDate(GenericTools.systemDate());
			bondClassStatistic.setUpdType("U");
			bondClassStatistic.setUpdUsr(userString());
			log.debug("Updated Bond Class Statistic - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period:"+nv+"; mode:"+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Bond Class Statistics - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period:"+nv+"; mode:"+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
		
	
	public void update(BondClassStatistic bondClassStatistic) throws DataNotValidException {
		try {
			log.debug("Updated Bond Class Statistic - instrId1: "+bondClassStatistic.getPk().getInstrId1()+"; instrId2: "+bondClassStatistic.getPk().getInstrId2()+"; nDaysPer: "+bondClassStatistic.getPk().getNDaysPer()+"; holding period:"+bondClassStatistic.getPk().getNv()+"; mode:"+bondClassStatistic.getPk().getMode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Bond Class Statistics - instrId1: "+bondClassStatistic.getPk().getInstrId1()+"; instrId2: "+bondClassStatistic.getPk().getInstrId2()+"; nDaysPer: "+bondClassStatistic.getPk().getNDaysPer()+"; holding period:"+bondClassStatistic.getPk().getNv()+"; mode:"+bondClassStatistic.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(BondClassStatistic bondClassStatistic) throws DataNotValidException {
		remove(bondClassStatistic.getPk().getInstrId1(),bondClassStatistic.getPk().getInstrId2(),bondClassStatistic.getPk().getNDaysPer(),bondClassStatistic.getPk().getNv(),bondClassStatistic.getPk().getMode());
	}
	
	public void remove(int instrId1, int instrId2, int nDaysPer, int nv, int mode) throws DataNotValidException {
		try {
			BondClassStatistic bondClassStatistic = findByPrimaryKey(instrId1, instrId2, nDaysPer, nv, mode);
			em.remove(bondClassStatistic);
			log.debug("Removed Bond Class Statistic - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period:"+nv+"; mode:"+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Bond Class Statistics - instrId1: "+instrId1+"; instrId2: "+instrId2+"; nDaysPer: "+nDaysPer+"; holding period:"+nv+"; mode:"+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteBondClassStatisticByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Bond Class Statistic removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Bond Class Statistics - instrId1: "+instrId+" OR instrId2:"+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeCurrentStatistics() throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteCurrentBondClassStatistic");
			int result = query.executeUpdate();
			log.debug(result+" Bond Class Statistic removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing current Bond Class Statistics - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByMode(int mode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteBondClassStatisticByMode");
			query.setParameter("mode", mode);
			int result = query.executeUpdate();
			log.debug(result+" Bond Class Statistics removed for mode:"+mode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Bond Class Statistics for mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByModeAndDivisCode(int mode,String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteBondClassStatisticByModeAndDivisCode");
			query.setParameter("mode", mode);
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			//log.debug(result+" Bond Class Statistics removed for mode:"+mode+" and divisCode \""+divisCode+"\"");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Bond Class Statistics for mode: "+mode+" and divisCode \""+divisCode+"\" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeStatsOfDisabledClassesByDivisCodeAndMode1(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("removeStatsOfDisabledClassesByDivisCodeAndMode1");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" bond class statistics of disabled classes removed for mode 1 and diviscode "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing bond class statistics of disabled classes for mode 1 and diviscode "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeStatsByClassIdAndMode1(int classId1, int classId2) throws DataNotValidException {
		
		String strQuery = "removeStatsByClassId1AndClassId2AndMode1";
		
		String classStrLog = "classId1: "+classId1+" and classId2: "+classId2;
		
		if (classId1==classId2) {
			strQuery = "removeStatsByClassIdAndMode1";
			classStrLog = "classId: "+classId1;
		}
		
		try {
			Query query = null;
			query = em.createNamedQuery(strQuery);
			query.setParameter("classId1", classId1);
			if (classId1!=classId2) {
				query.setParameter("classId2", classId2);
			}
			int result = query.executeUpdate();
			log.debug(result+" bond class statistics removed for mode 1 and "+classStrLog);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing bond class statistics for mode 1 and "+classStrLog+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void transferMode1To2() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("deleteMode2forBondClStats");
    		query.executeUpdate();
    		
    		query = em.createNativeQuery("INSERT INTO PMPTCLSTAT (INSTRID1,INSTRID2,NDAYSPER,NV,MODE,CORREL,PEARSON,DIVUNDIV,HISTDAYS,CLASSID1,CLASSID2,STATUS,UPDTYPE,UPDUSR,UPDDATE) " +
    				"SELECT INSTRID1,INSTRID2,NDAYSPER,NV,2,CORREL,PEARSON,DIVUNDIV,HISTDAYS,CLASSID1,CLASSID2,STATUS,'C','"+userString()+"','"+GenericTools.systemDate()+"' FROM PMPTCLSTAT WHERE MODE=1");
    	    		
    	    query.executeUpdate();
    		
    		log.debug("transfer of Bond Class Statistics from mode 1 to 2 has been completed");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring Bond Class Statistics from mode 1 to 2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public int transferMode1inMode2() throws DataNotValidException {
		try {
			BondClassStatistic[] arrBondClassStatistic = fetchWithMode1();
			int i=0;
			for (i=0;i<arrBondClassStatistic.length;i++) {
				BondClassStatisticPK pK = arrBondClassStatistic[i].getPk();
				pK.setMode(2);
				arrBondClassStatistic[i].setPk(pK);
				store(arrBondClassStatistic[i]);
			}
			log.debug(i+1+" Bond Class Statistic transferred from mode 1 to 2");
			return i+1;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error tranferring Bond Class Statistics from mode 1 to 2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
}
