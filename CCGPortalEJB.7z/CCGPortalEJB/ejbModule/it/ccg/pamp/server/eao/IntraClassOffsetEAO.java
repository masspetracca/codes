package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.IntraclassOffset;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class IntraclassOffsetEAO
 */
@Stateless
public class IntraClassOffsetEAO implements  IntraClassOffsetEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public IntraclassOffset[] fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllInterclassOffset");
    		List<IntraclassOffset> intraclassOffset = query.getResultList();
    		IntraclassOffset[] arrIntraclassOffset = new IntraclassOffset[intraclassOffset.size()];
    		return intraclassOffset.toArray(arrIntraclassOffset);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Intraclass Offsets - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public IntraclassOffset findByPrimaryKey(int classId) throws DataNotValidException {
		try {
			IntraclassOffset intraclassOffset = (IntraclassOffset) em.find(IntraclassOffset.class,classId);
    		return intraclassOffset;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Intraclass Offset - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public IntraclassOffset[] findEnabledIntraclassOffset() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllEnabledIntraclassOffset");
    		List<IntraclassOffset> intraclassOffset = query.getResultList();
    		IntraclassOffset[] arrIntraclassOffset = new IntraclassOffset[intraclassOffset.size()];
    		return intraclassOffset.toArray(arrIntraclassOffset);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled Intraclass Offsets - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public IntraclassOffset[] findEnabledIntraclassOffsetByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getEnabledIntraclassOffsetByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<IntraclassOffset> intraclassOffset = query.getResultList();
    		IntraclassOffset[] arrIntraclassOffset = new IntraclassOffset[intraclassOffset.size()];
    		return intraclassOffset.toArray(arrIntraclassOffset);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled Intraclass Offsets - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public IntraclassOffset[] findActiveIntraclassOffset() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllActiveIntraclassOffset");
    		List<IntraclassOffset> intraclassOffset = query.getResultList();
    		IntraclassOffset[] arrIntraclassOffset = new IntraclassOffset[intraclassOffset.size()];
    		return intraclassOffset.toArray(arrIntraclassOffset);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active Intraclass Offsets - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActiveDeltaForBond(int classId) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getActiveDeltaForIntraclassOffset");
    		query.setParameter("classId",classId);
    		List<Integer> activeDeltaList = query.getResultList();
    		Integer[] arrActiveDelta = new Integer[activeDeltaList.size()];
    		activeDeltaList.toArray(arrActiveDelta);
    		return arrActiveDelta;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active delta for Intraclass Offset - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActivePeriodsForBond(int classId, int crNv) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getActivePeriodsForIntraclassOffset");
    		query.setParameter("classId",classId);
    		query.setParameter("crNv",crNv);
    		List<Integer> activePeriodsList = query.getResultList();
    		Integer[] arrActivePeriods = new Integer[activePeriodsList.size()];
    		activePeriodsList.toArray(arrActivePeriods);
    		return arrActivePeriods;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active periods for Intraclass Offset - classId: "+classId+"; crNv: "+crNv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public IntraclassOffset[] findProposedIntraclassOffset() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllProposedIntraclassOffset");
    		List<IntraclassOffset> intraclassOffset = query.getResultList();
    		IntraclassOffset[] arrIntraclassOffset = new IntraclassOffset[intraclassOffset.size()];
    		return intraclassOffset.toArray(arrIntraclassOffset);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching proposed Intraclass Offset - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	
	public void add(int classId, Timestamp anDate, Timestamp anFrstHisD, int anInstrId1, int anInstrId2, Timestamp anLastHisD, String anLog,
			int anNDaysPer, int anNv, BigDecimal anOff, String approval, String comment, Timestamp crFrstHisD, int crInstrId1, int crInstrId2,
			Timestamp crLastHisD, String crLog, int crNDaysPer, int crNv, BigDecimal crOff, String custom, Timestamp endVDate, Timestamp iniVDate,
			String propLog, BigDecimal propOff, String propose, int rcCode, Timestamp sendDate, String status, String susp, BigDecimal userOff) throws DataNotValidException {
		
		try {
			IntraclassOffset intraclassOffset = new IntraclassOffset();
			
			intraclassOffset.setClassId(classId);
			intraclassOffset.setAnDate(anDate);
			intraclassOffset.setAnFrstHisD(anFrstHisD);
			intraclassOffset.setAnInstrId1(anInstrId1);
			intraclassOffset.setAnInstrId2(anInstrId2);
			intraclassOffset.setAnLastHisD(anLastHisD);
			intraclassOffset.setAnLog(anLog);
			intraclassOffset.setAnNDaysPer(anNDaysPer);
			intraclassOffset.setAnNv(anNv);
			intraclassOffset.setAnOff(anOff);
			intraclassOffset.setApproval(approval);
			intraclassOffset.setComment(comment);
			intraclassOffset.setCrFrstHisD(crFrstHisD);
			intraclassOffset.setCrInstrId1(crInstrId1);
			intraclassOffset.setCrInstrId2(crInstrId2);
			intraclassOffset.setCrLastHisD(crLastHisD);
			intraclassOffset.setCrLog(crLog);
			intraclassOffset.setCrNDaysPer(crNDaysPer);
			intraclassOffset.setCrNv(crNv);
			intraclassOffset.setCrOff(crOff);
			intraclassOffset.setEndVDate(endVDate);
			intraclassOffset.setIniVDate(iniVDate);
			intraclassOffset.setPropLog(propLog);
			intraclassOffset.setPropOff(propOff);
			intraclassOffset.setPropose(propose);
			intraclassOffset.setRcCode(rcCode);
			intraclassOffset.setSendDate(sendDate);
			intraclassOffset.setStatus(status);
			intraclassOffset.setSusp(susp);
			intraclassOffset.setUserOff(userOff);
			intraclassOffset.setUpdType(updType);
			intraclassOffset.setUpdDate(GenericTools.systemDate());
			intraclassOffset.setUpdUsr(userString());
			
			
			
			em.persist(intraclassOffset);
			log.debug("Added new Intraclass Offset - classId: "+classId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding Intraclass Offset - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(IntraclassOffset intraclassOffset) throws DataNotValidException {
		try {
			intraclassOffset.setUpdType(updType);
			intraclassOffset.setUpdDate(GenericTools.systemDate());
			intraclassOffset.setUpdUsr(userString());
			em.persist(intraclassOffset);
			log.debug("Added new Intraclass Offset - classId: "+intraclassOffset.getClassId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding Intraclass Offset - classId: "+intraclassOffset.getClassId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	} 
	}
	
	public void update(int classId, Timestamp anDate, Timestamp anFrstHisD, int anInstrId1, int anInstrId2, Timestamp anLastHisD, String anLog,
			int anNDaysPer, int anNv, BigDecimal anOff, String approval, String comment, Timestamp crFrstHisD, int crInstrId1, int crInstrId2,
			Timestamp crLastHisD, String crLog, int crNDaysPer, int crNv, BigDecimal crOff, String custom, Timestamp endVDate, Timestamp iniVDate,
			String propLog, BigDecimal propOff, String propose, int rcCode, Timestamp sendDate, String status, String susp, BigDecimal userOff) throws DataNotValidException {
		
		try {
			IntraclassOffset intraclassOffset = findByPrimaryKey(classId);
			intraclassOffset.setAnDate(anDate);
			intraclassOffset.setAnFrstHisD(anFrstHisD);
			intraclassOffset.setAnInstrId1(anInstrId1);
			intraclassOffset.setAnInstrId2(anInstrId2);
			intraclassOffset.setAnLastHisD(anLastHisD);
			intraclassOffset.setAnLog(anLog);
			intraclassOffset.setAnNDaysPer(anNDaysPer);
			intraclassOffset.setAnNv(anNv);
			intraclassOffset.setAnOff(anOff);
			intraclassOffset.setApproval(approval);
			intraclassOffset.setComment(comment);
			intraclassOffset.setCrFrstHisD(crFrstHisD);
			intraclassOffset.setCrInstrId1(crInstrId1);
			intraclassOffset.setCrInstrId2(crInstrId2);
			intraclassOffset.setCrLastHisD(crLastHisD);
			intraclassOffset.setCrLog(crLog);
			intraclassOffset.setCrNDaysPer(crNDaysPer);
			intraclassOffset.setCrNv(crNv);
			intraclassOffset.setCrOff(crOff);
			intraclassOffset.setEndVDate(endVDate);
			intraclassOffset.setIniVDate(iniVDate);
			intraclassOffset.setPropLog(propLog);
			intraclassOffset.setPropOff(propOff);
			intraclassOffset.setPropose(propose);
			intraclassOffset.setRcCode(rcCode);
			intraclassOffset.setSendDate(sendDate);
			intraclassOffset.setStatus(status);
			intraclassOffset.setSusp(susp);
			intraclassOffset.setUserOff(userOff);
			intraclassOffset.setUpdType("U");
			intraclassOffset.setUpdDate(GenericTools.systemDate());
			intraclassOffset.setUpdUsr(userString());
			log.debug("Intraclass Offset updated - classId: "+classId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Intraclass Offset - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	} 
	}
	
	public void update(IntraclassOffset intraclassOffset) throws DataNotValidException {
		try {
			log.debug("Intraclass Offset updated - classId: "+intraclassOffset.getClassId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Intraclass Offset - classId: "+intraclassOffset.getClassId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("resetIntraClassOffset");
			query.setParameter(1, divisCode);
			query.setParameter(2, GenericTools.systemDate());
			query.setParameter(3, userString());
			int result = query.executeUpdate();
			log.info(result+" intraclass offsets updated to disabled status - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating intraclass offsets to disabled status - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int updateStatusToDisabledForDisabledClasses(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("disableIntraClassOffsetOfDisabledClasses");
			query.setParameter(1, divisCode);
			query.setParameter(2, GenericTools.systemDate());
			query.setParameter(3, userString());
			int result = query.executeUpdate();
			log.info(result+" intraclass offsets updated to disabled status - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating intraclass offsets to disabled status - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int classId) throws DataNotValidException {
		try {	
			IntraclassOffset intraclassOffset = findByPrimaryKey(classId);
			em.remove(intraclassOffset);
			log.debug("Intraclass Offset removed - classId: "+classId);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing Intraclass Offset - classId: "+classId+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	public void remove(IntraclassOffset intraclassOffset) throws DataNotValidException {
		remove(intraclassOffset.getClassId());
	}

}
