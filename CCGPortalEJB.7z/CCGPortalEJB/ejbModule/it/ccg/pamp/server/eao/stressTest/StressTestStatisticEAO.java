package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.stressTest.StressTestSetup;
import it.ccg.pamp.server.entities.stressTest.StressTestStatistic;
import it.ccg.pamp.server.entities.stressTest.StressTestStatisticPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StressTestStatisticEAO
 */
@Stateless
public class StressTestStatisticEAO implements  StressTestStatisticEAOLocal {

	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	public List<StressTestStatistic> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllStressTestStatistics");
    		List<StressTestStatistic> stressTestStatisticList = query.getResultList();
    		return stressTestStatisticList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test statistics - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	
	public StressTestStatistic findByPrimaryKey(int instrId, String scenario, int stId) throws DataNotValidException {
		try {
			StressTestStatisticPK pK = new StressTestStatisticPK();
			
			pK.setInstrId(instrId);
			pK.setScenario(scenario);
			pK.setStId(stId);
			
			StressTestStatistic stressTestStatistic = (StressTestStatistic) em.find(StressTestStatistic.class,pK);
    		return stressTestStatistic;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test statistic - instrId: "+instrId+"; scenario: "+scenario+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<StressTestStatistic> findByInstrIdAndScenario(int instrId, int stId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestStatisticsByInstrIdAndStressTestId");
    		query.setParameter("instrId", instrId);
    		query.setParameter("stId", stId);
    		List<StressTestStatistic> stressTestStatisticList = query.getResultList();
    		return stressTestStatisticList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test statistics - instrId: "+instrId+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, String scenario, int stId, int extrN, String nvvec, int extrNv, int extrS, BigDecimal extrRes,
		BigDecimal marRes, BigDecimal stDevRes, BigDecimal scRes, Timestamp histUpdDay, String log, String choosenFun,
		String marDer, String marLog, String marProp, BigDecimal marUsed, int nDaysPer, BigDecimal stDev) throws DataNotValidException {
		
		try {
			StressTestStatistic stressTestStatistic = new StressTestStatistic();
			
			StressTestStatisticPK pK = new StressTestStatisticPK();
			
			pK.setInstrId(instrId);
			pK.setScenario(scenario);
			pK.setStId(stId);
			
			stressTestStatistic.setPk(pK);
			
			stressTestStatistic.setExtrN(extrN);
			stressTestStatistic.setNvvec(nvvec);
			stressTestStatistic.setExtrNv(extrNv);
			stressTestStatistic.setExtrS(extrS);
			stressTestStatistic.setExtrRes(extrRes);
			stressTestStatistic.setMarRes(marRes);
			stressTestStatistic.setStDevRes(stDevRes);
			stressTestStatistic.setScRes(scRes);
			stressTestStatistic.setHistUpdDay(histUpdDay);
			stressTestStatistic.setLog(log);
			stressTestStatistic.setChoosenFun(choosenFun);
			stressTestStatistic.setMarDer(marDer);
			stressTestStatistic.setMarLog(marLog);
			stressTestStatistic.setMarProp(marProp);
			stressTestStatistic.setMarUsed(marUsed);
			stressTestStatistic.setnDaysPer(nDaysPer);
			stressTestStatistic.setStDev(stDev);
									
			stressTestStatistic.setUpdType(updType);
			stressTestStatistic.setUpdDate(GenericTools.systemDate());
			stressTestStatistic.setUpdUsr(userString());
			
			em.persist(stressTestStatistic);
			userLog.debug("Added new stress test statistic - instrId: "+instrId+"; scenario: "+scenario+"; stress test id: "+stId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test statistic -  instrId: "+instrId+"; scenario: "+scenario+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(StressTestStatistic stressTestStatistic) throws DataNotValidException {
		
		try {
			System.out.println("-------------"+stressTestStatistic.toString());
			stressTestStatistic.setUpdType(updType);
			stressTestStatistic.setUpdDate(GenericTools.systemDate());
			stressTestStatistic.setUpdUsr(userString());
			em.persist(stressTestStatistic);
			userLog.debug("Added new stress test statistic - instrId: "+stressTestStatistic.getPk().getInstrId()+"; scenario: "+stressTestStatistic.getPk().getScenario()+"; stress test id: "+stressTestStatistic.getPk().getStId());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test statistic -  instrId: "+stressTestStatistic.getPk().getInstrId()+"; scenario: "+stressTestStatistic.getPk().getScenario()+"; stress test id: "+stressTestStatistic.getPk().getStId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, String scenario, int stId, int extrN, String nvvec, int extrNv, int extrS, BigDecimal extrRes,
		BigDecimal marRes, BigDecimal stDevRes, BigDecimal scRes, Timestamp histUpdDay, String log, String choosenFun,
		String marDer, String marLog, String marProp, BigDecimal marUsed, int nDaysPer, BigDecimal stDev) throws DataNotValidException {
		
		try {
			StressTestStatistic stressTestStatistic = this.findByPrimaryKey(instrId, scenario, stId);
			
			stressTestStatistic.setExtrN(extrN);
			stressTestStatistic.setNvvec(nvvec);
			stressTestStatistic.setExtrNv(extrNv);
			stressTestStatistic.setExtrS(extrS);
			stressTestStatistic.setExtrRes(extrRes);
			stressTestStatistic.setMarRes(marRes);
			stressTestStatistic.setStDevRes(stDevRes);
			stressTestStatistic.setScRes(scRes);
			stressTestStatistic.setHistUpdDay(histUpdDay);
			stressTestStatistic.setLog(log);
			stressTestStatistic.setChoosenFun(choosenFun);
			stressTestStatistic.setMarDer(marDer);
			stressTestStatistic.setMarLog(marLog);
			stressTestStatistic.setMarProp(marProp);
			stressTestStatistic.setMarUsed(marUsed);
			stressTestStatistic.setnDaysPer(nDaysPer);
			stressTestStatistic.setStDev(stDev);
						
			stressTestStatistic.setUpdType("U");
			stressTestStatistic.setUpdDate(GenericTools.systemDate());
			stressTestStatistic.setUpdUsr(userString());
			
			userLog.debug("Updated stress test statistic - instrId: "+instrId+"; scenario: "+scenario+"; stress test id: "+stId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stress test statistic - instrId: "+instrId+"; scenario: "+scenario+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(StressTestStatistic stressTestStatistic) throws DataNotValidException {
		
		try {
			userLog.debug("Updated stress test statistic - instrId: "+stressTestStatistic.getPk().getInstrId()+"; scenario: "+stressTestStatistic.getPk().getScenario()+"; stress test id: "+stressTestStatistic.getPk().getStId());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stress test statistic - instrId: "+stressTestStatistic.getPk().getInstrId()+"; scenario: "+stressTestStatistic.getPk().getScenario()+"; stress test id: "+stressTestStatistic.getPk().getStId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, String scenario, int stId) throws DataNotValidException {
		try {
			StressTestStatistic stressTestStatistic = this.findByPrimaryKey(instrId, scenario, stId);
			em.remove(stressTestStatistic);
			userLog.debug("Stress test statistic removed - instrId: "+instrId+"; scenario: "+scenario+"; stress test id: "+stId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test statistic - instrId: "+instrId+"; scenario: "+scenario+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteStressTestStatisticsByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			userLog.debug(result+" stress test statistics removed - instrId: "+instrId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test statistic - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(StressTestStatistic stressTestStatistic) throws DataNotValidException {
		this.remove(stressTestStatistic.getPk().getInstrId(),stressTestStatistic.getPk().getScenario(),stressTestStatistic.getPk().getStId());
	}

}
