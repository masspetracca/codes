package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestMemberStats;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface StressTestMemberStatsEAOLocal {

	public List<StressTestMemberStats> fetch() throws DataNotValidException;
	
	public StressTestMemberStats findByPrimaryKey(int mbrRank, int mbrId, String scenario, int stId) throws DataNotValidException;
	
	public List<StressTestMemberStats> getStressTestMemberStatsByMbrId(int mbrId) throws DataNotValidException;
	
	public List<StressTestMemberStats> getStressTestMemberStatsByStId(int stId) throws DataNotValidException;
	
	public List<StressTestMemberStats> getStressTestMemberStatsByScenario(String scenario) throws DataNotValidException;
	
	public List<StressTestMemberStats> getStressTestMemberStatsByRank(int mbrRank) throws DataNotValidException;
	
	public List<StressTestMemberStats> getStressTestMemberStatsByMbrIdAndStId(int mbrId, int stId) throws DataNotValidException;
	
	public List<StressTestMemberStats> getStressTestMemberStatsByStIdAndScenario(int stId, String scenario) throws DataNotValidException;
	
	public List<StressTestMemberStats> getStressTestMemberStatsByMbrIdAndScenario(int mbrId, String scenario) throws DataNotValidException;
	
	public String getMemberReportForMail(String divisCode) throws DataNotValidException;
	
	public void add(int mbrRank, int mbrId, String scenario, int stId, BigDecimal clientInitialMargin, BigDecimal clientCashCall, BigDecimal df, String gMbrDesc, int totalExposedFromTop, 
			Timestamp histUpdDay, BigDecimal firmInitialMargin, BigDecimal firmCashCall, int lastInDf, String log, String mbrDesc, BigDecimal nce, BigDecimal nceCum, 
			BigDecimal nceRetroCum, BigDecimal nceSum, int nDaysPer, String nvVec, int totExposedMembers, int totMembers, BigDecimal dfQuotaD, BigDecimal mtmMargin, BigDecimal ordMargin,BigDecimal mia, Timestamp defFundInivDate) throws DataNotValidException;
	
	public void update(int mbrRank, int mbrId, String scenario, int stId, BigDecimal clientInitialMargin, BigDecimal clientCashCall, BigDecimal df, String gMbrDesc, int totalExposedFromTop, 
			Timestamp histUpdDay, BigDecimal firmInitialMargin, BigDecimal firmCashCall, int lastInDf, String log, String mbrDesc, BigDecimal nce, BigDecimal nceCum, 
			BigDecimal nceRetroCum, BigDecimal nceSum, int nDaysPer, String nvVec, int totExposedMembers, int totMembers, BigDecimal dfQuotaD, BigDecimal mtmMargin, BigDecimal ordMargin,BigDecimal mia, Timestamp defFundInivDate) throws DataNotValidException;
	
	public void store(StressTestMemberStats stressTestMemberStats) throws DataNotValidException;
	
	public void update(StressTestMemberStats stressTestMemberStats) throws DataNotValidException;
	
	public void remove(int mbrRank, int mbrId, String scenario, int stId) throws DataNotValidException;
	
	public int removeByMbrId(int mbrId) throws DataNotValidException;
	
	public int removeByStId(int stId) throws DataNotValidException;
	
	public int removeByScenario(String scenario) throws DataNotValidException;
	
	public int removeByMbrIdAndStId(int mbrId, int stId) throws DataNotValidException;
	
	public int removeByMbrIdAndScenario(int mbrId, String scenario) throws DataNotValidException;
	
	public int removeByStIdAndScenario(int stId, String scenario) throws DataNotValidException;
	
	public void remove(StressTestMemberStats stressTestMemberStats) throws DataNotValidException;
	
}
