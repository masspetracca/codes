package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Calendar;
import it.ccg.pamp.server.entities.GroupStatistic;
import it.ccg.pamp.server.entities.GroupStatisticPK;
import it.ccg.pamp.server.entities.RankedVariation;
import it.ccg.pamp.server.entities.RankedVariationPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RankedVariationEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class RankedVariationEAO implements  RankedVariationEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public String userString = "System";
	public String updType = "C";
	
	@SuppressWarnings("unchecked")
	public RankedVariation[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllRankedVar");
    		List<RankedVariation> rankedVariation = query.getResultList();
    		RankedVariation[] arrRankedVariation = new RankedVariation[rankedVariation.size()];
    		return rankedVariation.toArray(arrRankedVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Ranked Variations - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public RankedVariation[] fetchWithMode1() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllRankedVarWithMode1");
    		List<RankedVariation> rankedVariation = query.getResultList();
    		RankedVariation[] arrRankedVariation = new RankedVariation[rankedVariation.size()];
    		return rankedVariation.toArray(arrRankedVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Ranked Variations with mode 1 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public RankedVariation[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getRankedVarByInstrId");
    		query.setParameter("instrId", instrId);
    		List<RankedVariation> rankedVariation = query.getResultList();
    		RankedVariation[] arrRankedVariation = new RankedVariation[rankedVariation.size()];
    		return rankedVariation.toArray(arrRankedVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Ranked Variations - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<RankedVariation> findByInstrIdAndNv(int instrId, int nv) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getRankedVarByInstrIdAndNv");
    		query.setParameter("instrId", instrId);
    		query.setParameter("nv", nv);
    		List<RankedVariation> rankedVariationList = query.getResultList();
    		return rankedVariationList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Ranked Variations - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<RankedVariation> findPosOrNegOrAllRankedVarByInstrIdAndNDaysPerAndMode(int instrId, int nDaysPer, int mode, int posOrNegOrAll,int[] nvArr) throws DataNotValidException {
		Query query = null;
		
		String strPosOrNegOrAll = "";
		String queryName = "";
		String sqlString = "SELECT * FROM PMPTRVAR WHERE INSTRID = "+instrId+" AND NDAYSPER = "+nDaysPer+" AND MODE = "+mode+ " AND NV IN(" ;
		
		for (int i:nvArr) {
			sqlString+=i+",";
		}
		
		sqlString = sqlString.substring(0,sqlString.length()-1);
		sqlString+= ")";
		
		switch (posOrNegOrAll) {
			case -1:
				queryName = "getNegativeRankedVarByInstrIdAndNDaysPerOrderByVar";
				sqlString+= " AND VARIAT < 0 ORDER BY ABS(VARIAT) DESC"; 
				strPosOrNegOrAll = "negative";
				break;
			case 0:
				queryName = "getAllRankedVarByInstrIdAndNDaysPerOrderByVar";
				sqlString+= " ORDER BY ABS(VARIAT) DESC"; 
				strPosOrNegOrAll = "all";
				break;
			case 1:
				queryName = "getPositiveRankedVarByInstrIdAndNDaysPerOrderByVar";
				sqlString+= " AND VARIAT > 0 ORDER BY ABS(VARIAT) DESC"; 
				strPosOrNegOrAll = "positive";
		}
    	
		try {
    		//query = em.createNamedQuery(queryName);
			query =  em.createNativeQuery(sqlString,RankedVariation.class);
			//query.setParameter("instrId", instrId);
    		//query.setParameter("nDaysPer", nDaysPer);
    		//query.setParameter("mode", mode);
    		List<RankedVariation> rankedVariationList = query.getResultList();
    		return rankedVariationList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+strPosOrNegOrAll+" ranked variations - instrId: "+instrId+"; period: "+nDaysPer+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<RankedVariation> findByInstrIdOrderByVar(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getRankedVarByInstrIdOrderByVar");
    		query.setParameter("instrId", instrId);
    		List<RankedVariation> rankedVariationList = query.getResultList();
    		return rankedVariationList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Ranked Variations - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<String> printRankedVariations(int instrId, int nv) throws DataNotValidException {
		
		List<RankedVariation> rankedVariationList = this.findByInstrIdAndNv(instrId,nv);
		
		List<String> rankedVarForLog = new ArrayList<String>();
		
		int lastNdaysPer = 0;
		
		int counter = 0;
		
		int maxRecordNumber = rankedVariationList.size();
		
		int maxNdaysPer = rankedVariationList.get(maxRecordNumber-1).getPk().getNDaysPer();
		
		String rVarLog = "";
		
		MathContext mc = new MathContext(2);
		
		for (RankedVariation rVar:rankedVariationList) {
							
			int thisRank = 0;
				
			String minOrMax = "Max";
				
				//Double rVariat = GenericTools.roundValue(rVar.getVariat().doubleValue(),new MathContext(2))*100;
			BigDecimal rVariat = rVar.getVariat().round(mc);
				
			thisRank = rVar.getPk().getRank();
				
				//se ndaysper non � pi� lo stesso della riga precedente allora vuol dire che � un'altra riga completa e posso fare l'ADD
			if (lastNdaysPer!=rVar.getPk().getNDaysPer()) {
				
						//escludo l'add sulla lista nel caso iniziale
						if (lastNdaysPer>0) {
							rankedVarForLog.add(rVarLog);
							rVarLog = "";
						}
										
						rVarLog += "HP: "+rVar.getPk().getNv()+"; ";
						rVarLog += "Period: "+rVar.getPk().getNDaysPer()+"; ";
						
					}
					
					// setto la stringa minOrMax in base al segno di thisRank e se � negativa la inverto
					if (thisRank<0) {
						minOrMax = "Min";
						thisRank = thisRank*-1;
					}
					
					//rVarLog += minOrMax+"Date"+thisRank+": "+rVar.getPricedate().toString().substring(0,10)+"; ";
					rVarLog += minOrMax+thisRank+": "+GenericTools.percentValue(rVariat, mc)+"s ("+rVar.getPricedate().toString().substring(0,10)+"); ";
					
					//setto ndaysper di appoggio uguale a quello che ho appena utilizzato;
					
					lastNdaysPer = rVar.getPk().getNDaysPer();
					
					counter++;
					//se ndaysper di appoggio � uguale a quello massimo e il counter � uguale al massimo delle righe che mi aspetto di leggere allora vuol dire che dopo non c'� pi� nulla e posso scrivere
					if (lastNdaysPer==maxNdaysPer && counter==maxRecordNumber) {
						rankedVarForLog.add(rVarLog);
					}
			}
		
		return rankedVarForLog;
	}
	
	
	public RankedVariation[] findByInstrIdAndNvAndRank(int instrId, int nv, int rank) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getRankedVarByInstrIdAndNvAndRank");
    		query.setParameter("instrId", instrId);
    		query.setParameter("nv", nv);
    		query.setParameter("rank", rank);
    		List<RankedVariation> rankedVariation = query.getResultList();
    		RankedVariation[] arrRankedVariation = new RankedVariation[rankedVariation.size()];
    		return rankedVariation.toArray(arrRankedVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Ranked Variations - instrId: "+instrId+"; holding period: "+nv+"; rank: "+rank+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public RankedVariation findByPrimaryKey(int instrId, int nv, int nDaysPer, int rank, String varType, int mode) throws DataNotValidException {
		try {
			RankedVariationPK pK = new RankedVariationPK();
			pK.setInstrId(instrId);
			pK.setNv(nv);
			pK.setNDaysPer(nDaysPer);
			pK.setRank(rank);
			pK.setVarType(varType);
			pK.setMode(mode);
			RankedVariation rankedVariation = (RankedVariation) em.find(RankedVariation.class,pK);
    		return rankedVariation;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Ranked Variation - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, int nv, int nDaysPer, int rank, String varType, int mode, Timestamp priceDate, BigDecimal variat, String status) throws DataNotValidException {
		try {
			RankedVariation rankedVariation = new RankedVariation();
			RankedVariationPK pK = new RankedVariationPK();
			pK.setInstrId(instrId);
			pK.setNv(nv);
			pK.setNDaysPer(nDaysPer);
			pK.setRank(rank);
			pK.setVarType(varType);
			pK.setMode(mode);
			rankedVariation.setPk(pK);
			rankedVariation.setPricedate(priceDate);
			rankedVariation.setVariat(variat);
			rankedVariation.setStatus(status);
			rankedVariation.setUpdDate(GenericTools.systemDate());
			rankedVariation.setUpdType(updType);
			rankedVariation.setUpdUsr(userString());
			em.persist(rankedVariation);
			log.debug("Added new Ranked Variation - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode+"; variat: "+variat);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Ranked Variation - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	

	public void store(RankedVariation rankedVariation) throws DataNotValidException {
		try {
			rankedVariation.setUpdDate(GenericTools.systemDate());
			rankedVariation.setUpdType(updType);
			rankedVariation.setUpdUsr(userString());
			em.persist(rankedVariation);
			log.debug("Added new Ranked Variation - instrId: "+rankedVariation.getPk().getInstrId()+"; holding period: "+rankedVariation.getPk().getNv()+"; nDaysPer: "+rankedVariation.getPk().getNDaysPer()+"; rank: "+rankedVariation.getPk().getRank()+"; varType: "+rankedVariation.getPk().getVarType()+"; mode: "+rankedVariation.getPk().getMode()+"; variat: "+rankedVariation.getVariat());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Ranked Variation - instrId: "+rankedVariation.getPk().getInstrId()+"; holding period: "+rankedVariation.getPk().getNv()+"; nDaysPer: "+rankedVariation.getPk().getNDaysPer()+"; rank: "+rankedVariation.getPk().getRank()+"; varType: "+rankedVariation.getPk().getVarType()+"; mode: "+rankedVariation.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public void update(int instrId, int nv, int nDaysPer, int rank, String varType, int mode, Timestamp priceDate, BigDecimal variat, String status) throws DataNotValidException {
		try {	
			RankedVariation rankedVariation = findByPrimaryKey(instrId, nv, nDaysPer, rank, varType, mode);
			rankedVariation.setPricedate(priceDate);
			rankedVariation.setVariat(variat);
			rankedVariation.setStatus(status);
			rankedVariation.setUpdDate(GenericTools.systemDate());
			rankedVariation.setUpdType("U");
			rankedVariation.setUpdUsr(userString());
			log.debug("Ranked Variation updated - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode+"; variat: "+variat);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Ranked Variation - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public void update(RankedVariation rankVariation) throws DataNotValidException {
		try {
			log.debug("Ranked Variation updated - instrId: "+rankVariation.getPk().getInstrId()+"; holding period: "+rankVariation.getPk().getNv()+"; nDaysPer: "+rankVariation.getPk().getNDaysPer()+"; rank: "+rankVariation.getPk().getRank()+"; varType: "+rankVariation.getPk().getVarType()+"; mode: "+rankVariation.getPk().getMode()+"; variat: "+rankVariation.getVariat());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Ranked Variation - instrId: "+rankVariation.getPk().getInstrId()+"; holding period: "+rankVariation.getPk().getNv()+"; nDaysPer: "+rankVariation.getPk().getNDaysPer()+"; rank: "+rankVariation.getPk().getRank()+"; varType: "+rankVariation.getPk().getVarType()+"; mode: "+rankVariation.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public void remove(int instrId, int nv, int nDaysPer, int rank, String varType, int mode) throws DataNotValidException {
		try {
			RankedVariation rankedVariation = findByPrimaryKey(instrId, nv, nDaysPer, rank, varType, mode);
			em.remove(rankedVariation);
			log.debug("Ranked Variation removed - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Ranked Variation - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteRankedVarByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Ranked Variation removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Ranked Variations - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteRankedVarByEnabledInstrId");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" Ranked Variations related to disabled instruments removed - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing ranked variations related to disabled instruments removed - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public int removeByMode(int mode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteRankedVarByMode");
			query.setParameter("mode", mode);
			int result = query.executeUpdate();
			log.debug(result+" Ranked Variation removed - mode: "+mode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Ranked Variations - mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public void remove(RankedVariation rankVariation) throws DataNotValidException {
		remove(rankVariation.getPk().getInstrId(), rankVariation.getPk().getNv(), rankVariation.getPk().getNDaysPer(), rankVariation.getPk().getRank(), rankVariation.getPk().getVarType(), rankVariation.getPk().getMode());
	}
	
	public void transferMode1To2() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("deleteMode2forRankVar");
    		query.executeUpdate();
    		query = em.createNativeQuery("INSERT INTO PMPTRVAR (INSTRID,NV,NDAYSPER,RANK,VARTYPE,PRICEDATE,VARIAT,MODE,STATUS,UPDDATE,UPDTYPE,UPDUSR) "+
    			"SELECT INSTRID,NV,NDAYSPER,RANK,VARTYPE,PRICEDATE,VARIAT,2,STATUS,'"+GenericTools.systemDate()+"','C','"+userString()+"' FROM PMPTRVAR WHERE MODE=1");
    	    /*query.setParameter(1,GenericTools.systemDate() );
    		query.setParameter(1, GenericTools.systemDate());
    		query.setParameter(2, userString());*/
    		query.executeUpdate();
    		log.debug("transfer of Ranked Variation from mode 1 to 2 has been completed");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring Ranked Variation from mode 1 to 2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void transferMode1To2ByDivision(List<String> divisCodeList) throws DataNotValidException {
		
		Query query = null;
		
		String strDivisCode = "";
		
		for (String divisCode:divisCodeList) {
			strDivisCode = "'"+divisCode+"',";
		}
		
		strDivisCode = strDivisCode.substring(0,strDivisCode.length()-1);
		String strSQLDivision = "(SELECT INSTRID FROM PMPTINSTR WHERE DIVISCODE IN ("+strDivisCode+"))";
		
		String strSQL = "DELETE FROM PMPTRVAR WHERE MODE = 2 AND INSTRID IN "+strSQLDivision;
		
    	try {
    		query = em.createNativeQuery(strSQL);
    		query.executeUpdate();
    		
    		strSQL = 	"INSERT INTO PMPTRVAR (INSTRID,NV,NDAYSPER,RANK,VARTYPE,PRICEDATE,VARIAT,MODE,STATUS,UPDDATE,UPDTYPE,UPDUSR) "+
    					"SELECT INSTRID,NV,NDAYSPER,RANK,VARTYPE,PRICEDATE,VARIAT,2,STATUS,'"+GenericTools.systemDate()+"','C','"+userString()+"' "+
    					"FROM PMPTRVAR WHERE MODE=1 AND INSTRID IN "+strSQLDivision;
    		
    		query = em.createNativeQuery(strSQL);
    	    query.executeUpdate();
    		log.debug("transfer of Ranked Variation from mode 1 to 2 has been completed for divisions "+strDivisCode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring Ranked Variation from mode 1 to 2 for divisions "+strDivisCode+"- "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public int transferMode1inMode2() throws DataNotValidException {
		try {
			RankedVariation[] arrRankedVariation = fetchWithMode1();
			int i=0;
			for (RankedVariation rankedVar:arrRankedVariation) {
				RankedVariationPK pK = new RankedVariationPK();
				RankedVariation rankedVariation = new RankedVariation();
				pK.setInstrId(rankedVar.getPk().getInstrId());
				pK.setNDaysPer(rankedVar.getPk().getNDaysPer());
				pK.setNv(rankedVar.getPk().getNv());
				pK.setRank(rankedVar.getPk().getRank());
				pK.setVarType(rankedVar.getPk().getVarType());
				pK.setMode(2);
				rankedVariation.setPk(pK);
				rankedVariation.setPricedate(rankedVar.getPricedate());
				rankedVariation.setVariat(rankedVar.getVariat());
				rankedVariation.setStatus(rankedVar.getStatus());
				store(rankedVariation);
				i++;
			}
			log.debug((i+1)+" Ranked Variation transferrd from mode 1 to 2");
			return i+1;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring Ranked Variations from mode 1 to 2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
}
