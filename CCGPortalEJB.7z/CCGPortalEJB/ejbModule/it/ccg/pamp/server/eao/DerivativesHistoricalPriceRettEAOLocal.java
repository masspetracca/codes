package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.DerivativesHistoricalPriceRett;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.DerHistPricesRettDates;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

@Local
public interface DerivativesHistoricalPriceRettEAOLocal {
	
	public DerivativesHistoricalPriceRett[] fetch() throws DataNotValidException;
	
	public DerivativesHistoricalPriceRett findByPrimaryKey(int instrId, Timestamp priceDate, int progExp) throws DataNotValidException;
	
	public DerivativesHistoricalPriceRett[] findByInstrIdAndExp(int instrId,  int prgExp) throws DataNotValidException;
	
	public DerivativesHistoricalPriceRett[] findJustBeforeDate(int instrId, Timestamp nearDate) throws DataNotValidException;
	
	public DerivativesHistoricalPriceRett findLastDate() throws DataNotValidException;
	
	public DerivativesHistoricalPriceRett findFirstDate() throws DataNotValidException;
	
	public DerHistPricesRettDates findFirstAndLastDateByInstrId(Instrument instr) throws DataNotValidException;
	
	public DerivativesHistoricalPriceRett findLastDateByInstrument(Instrument instr) throws DataNotValidException;
	
	public DerivativesHistoricalPriceRett findFirstDateByInstrument(Instrument instr) throws DataNotValidException;
	
	public List<DerivativesHistoricalPriceRett> findBeforeLastDate(int instrId, Timestamp lastDate) throws DataNotValidException;
	
	public Integer getExpiry(int instrId) throws DataNotValidException;
	
	public Integer getMaxPrg(int instrId) throws DataNotValidException;
	
	public DerivativesHistoricalPriceRett[] findJustAfterDate(int instrId, Timestamp nearDate) throws DataNotValidException;
	
	public DerivativesHistoricalPriceRett[] findByInstrId(int instrId) throws DataNotValidException;
	
	public DerivativesHistoricalPriceRett[] findByInstrIdForChart(int instrId) throws DataNotValidException;
	
	public DerivativesHistoricalPriceRett[] findByInstrIdAndDate(int instrId, Timestamp firstDate, Timestamp lastDate) throws DataNotValidException;
	
	public void add(int instrId, Timestamp priceDate, int progExp, BigDecimal closePrRet, BigDecimal impVola, String status) throws DataNotValidException;
	
	public void store(DerivativesHistoricalPriceRett derivativesHistoricalPricesRett) throws DataNotValidException;
	
	public void update(int instrId, Timestamp priceDate, int progExp, BigDecimal closePrRet, BigDecimal impVola, String status) throws DataNotValidException;
	
	public void update(DerivativesHistoricalPriceRett derivativesHPR) throws DataNotValidException;
	
	public void remove(int instrId, Timestamp priceDate, int progExp) throws DataNotValidException; 
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException;
	
	public void remove(DerivativesHistoricalPriceRett derivativesHPR) throws DataNotValidException;
	
	public void flush();
}
