package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.InterclassOffset;
import it.ccg.pamp.server.entities.InterclassOffsetHistory;
import it.ccg.pamp.server.entities.IntraclassOffsetHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface InterClassOffsetHistoryEAOLocal {
	public InterclassOffsetHistory[] fetch() throws DataNotValidException;
	
	public InterclassOffsetHistory findByPrimaryKey(int classId1, int classId2, Timestamp iniVDate) throws DataNotValidException;
	
	public InterclassOffsetHistory[] findEnabledInterclassOffsetHistory() throws DataNotValidException;
	
	public InterclassOffsetHistory getLastSentInterClassOffset(int classId1, int classId2) throws DataNotValidException;
	
	public List<InterclassOffsetHistory> findByClassId1OrClassId2(int classId) throws DataNotValidException;
	
	public List<InterclassOffsetHistory> getInterClassOffsetHistoryToExport() throws DataNotValidException;
	
	public InterclassOffsetHistory getCurrentInterclassOffsetHistory(int classId1, int classId2) throws DataNotValidException;
	
	public InterclassOffsetHistory[] findActiveInterclassOffsetHistory() throws DataNotValidException; 
	
	public InterclassOffsetHistory[] findProposedInterclassOffsetHistory() throws DataNotValidException;
	
	public Integer[] getActiveDeltaForInterclassOffsetHistory(int classId1, int classId2) throws DataNotValidException;
	
	public Integer[] getActivePeriodsForInterclassOffsetHistory(int classId1, int classId2, int crNv) throws DataNotValidException;
	
	public void add(int classId1, int classId2, Timestamp iniVDate, Timestamp anDate, BigDecimal anOff, Timestamp apprDate,String approvedBy, String comment,
			Timestamp endVDate, String log, BigDecimal off, int rcCode, Timestamp sendDate, String sent, String susp, String status) throws DataNotValidException;
	
	public void store(InterclassOffsetHistory interclassOffsetHistory) throws DataNotValidException;
	
	public void store(InterclassOffset interclassOffset) throws DataNotValidException;
	
	public void update(int classId1, int classId2, Timestamp iniVDate, Timestamp anDate, BigDecimal anOff, Timestamp apprDate,String approvedBy, String comment,
			Timestamp endVDate, String log, BigDecimal off, int rcCode, Timestamp sendDate, String sent, String susp, String status) throws DataNotValidException;
	
	public void update(InterclassOffsetHistory interclassOffsetHistory) throws DataNotValidException;
	
	public void logUpdate(InterclassOffsetHistory interclassOffsetHistory) throws DataNotValidException;
	
	public int removeInterClassOffsetByClass(int classId) throws DataNotValidException;
	
	public int removeInterClassOffsetByClassEither(int classId1, int classId2) throws DataNotValidException;
	
	public void remove(int classId1, int classId2, Timestamp iniVDate) throws DataNotValidException;
	
	public void remove(InterclassOffsetHistory interclassOffsetHistory) throws DataNotValidException;
}