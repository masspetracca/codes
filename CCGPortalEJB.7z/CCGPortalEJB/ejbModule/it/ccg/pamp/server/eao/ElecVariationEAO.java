package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ElecVariation;
import it.ccg.pamp.server.entities.ElecVariationPK;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.entities.VariationPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ElecVariationEAO
 */
@Stateless
public class ElecVariationEAO implements  ElecVariationEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	public Timestamp updDate = GenericTools.systemDate();
	public String userString = "System";
	public String updType = "C";
	
	public List<ElecVariation> fetchAllElecVar() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllElecVar");
    		List<ElecVariation> elecVariationList = query.getResultList();
    		return elecVariationList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives variations - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ElecVariation findByPrimaryKey(int instrId, Timestamp priceDate, String varType) throws DataNotValidException {
		try {
			ElecVariationPK pK = new ElecVariationPK();
			pK.setInstrId(instrId);
			pK.setPriceDate(priceDate);
			pK.setvarType(varType);
			
			ElecVariation elecVariation = (ElecVariation) em.find(ElecVariation.class,pK);
    		return elecVariation;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives variations - instrId: "+instrId+"; priceDate: "+priceDate+"; varType: "+varType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BigDecimal getAvgElecVarByInstrIdAndMonth(int instrId, int year, int month) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAVGElecVarByInstrIdAndYearAndMonth");
    		query.setParameter("instrId", instrId);
    		query.setParameter("year", year);
    		query.setParameter("month", month);
    		BigDecimal avgElecVariation = (BigDecimal) query.getSingleResult();
    		return avgElecVariation;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching average electricity derivatives variations - instrId: "+instrId+"; year: "+year+"; month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BigDecimal getMaxElecVarByInstrIdAndMonth(int instrId, int month) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMaxElecVarByInstrIdAndMonth");
    		query.setParameter("instrId", instrId);
    		query.setParameter("month", month);
    		BigDecimal avgElecVariation = (BigDecimal) query.getSingleResult();
    		return avgElecVariation;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching maximum electricity derivatives variations - instrId: "+instrId+"; month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ElecVariation> getElecVarByMonthAndVarType(int month, String varType) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getElecVarByMonthAndVarType");
    		query.setParameter("month", month);
    		query.setParameter("varType", varType);
    		List<ElecVariation> elecVariationList = query.getResultList();
    		return elecVariationList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives variations - month: "+month+"; varType: "+varType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ElecVariation> getElecVarByMonthAndVarType(int instrId, int month, String varType) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getElecVarByInstrIdAndMonthAndVarType");
    		query.setParameter("instrId", instrId);
    		query.setParameter("month", month);
    		query.setParameter("varType", varType);
    		List<ElecVariation> elecVariationList = query.getResultList();
    		return elecVariationList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching electricity derivatives variations - instrId: "+instrId+"; month: "+month+"; varType: "+varType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, Timestamp priceDate, String varType, BigDecimal closePr, BigDecimal punAve, int punMonth, int punYear, String status, BigDecimal variat) throws DataNotValidException {
		try {
			ElecVariation elecVariation = new ElecVariation();
			ElecVariationPK pK = new ElecVariationPK();
			pK.setInstrId(instrId);
			pK.setPriceDate(priceDate);
			pK.setvarType(varType);
			elecVariation.setClosePr(closePr);
			elecVariation.setPunAve(punAve);
			elecVariation.setPunMonth(punMonth);
			elecVariation.setPunYear(punYear);
			elecVariation.setStatus(status);
			elecVariation.setVariat(variat);
			elecVariation.setUpdDate(GenericTools.systemDate());
			elecVariation.setUpdType(updType);
			elecVariation.setUpdUsr(userString());
			em.persist(elecVariation);
			log.debug("Added new electricity derivatives variation - instrId: "+instrId+"; priceDate: "+priceDate+"; varType: "+varType+"; variation: "+variat);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new variation - instrId: "+instrId+"; priceDate: "+priceDate+"; varType: "+varType+"; variation: "+variat+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(ElecVariation elVariation) throws DataNotValidException {
		try {
			elVariation.setUpdDate(GenericTools.systemDate());
			elVariation.setUpdType(updType);
			elVariation.setUpdUsr(userString());
			em.persist(elVariation);
			log.debug("Added new electricity derivatives variation - instrId: "+elVariation.getPk().getInstrId()+"; priceDate: "+elVariation.getPk().getPriceDate()+"; varType: "+elVariation.getPk().getVarType()+"; variation: "+elVariation.getVariat());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new electricity derivatives variation - instrId: "+elVariation.getPk().getInstrId()+"; priceDate: "+elVariation.getPk().getPriceDate()+"; varType: "+elVariation.getPk().getVarType()+"; variation: "+elVariation.getVariat()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, Timestamp priceDate, String varType, BigDecimal closePr, BigDecimal punAve, int punMonth, int punYear, String status, BigDecimal variat) throws DataNotValidException {
		try {	
			ElecVariation elecVariation = this.findByPrimaryKey(instrId, priceDate,varType);
			elecVariation.setClosePr(closePr);
			elecVariation.setPunAve(punAve);
			elecVariation.setPunMonth(punMonth);
			elecVariation.setPunYear(punYear);
			elecVariation.setStatus(status);			
			elecVariation.setVariat(variat);
			elecVariation.setUpdDate(GenericTools.systemDate());
			elecVariation.setUpdType("U");
			elecVariation.setUpdUsr(userString());;
			log.debug("Electricity derivatives variation updated - instrId: "+instrId+"; priceDate: "+priceDate+"; varType: "+varType);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating electricity derivatives variation updated - instrId: "+instrId+"; priceDate: "+priceDate+"; varType: "+varType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, Timestamp priceDate, String varType) throws DataNotValidException {
		try {
			ElecVariation elecVariation = this.findByPrimaryKey(instrId, priceDate,varType);
			em.remove(elecVariation);
			log.debug("Electricity derivatives variation removed - instrId: "+instrId+"; priceDate: "+priceDate+"; varType: "+varType);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing electricity derivatives variation - instrId: "+instrId+"; priceDate: "+priceDate+"; varType: "+varType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(ElecVariation elecVar) throws DataNotValidException {
		remove(elecVar.getPk().getInstrId(), elecVar.getPk().getPriceDate(), elecVar.getPk().getVarType());
	}
	
	public int removeByEnabledInstrId() throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteAllElecVarByEnabledInstrId");
			int result = query.executeUpdate();
			log.debug(result+" Electricity variations related to disabled instruments removed - divisCode: L");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing electricity derivatives variations related to enabled - divisCode: L - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
		 
		try {
	    query = em.createNamedQuery("deleteElecVarByInstrId");
    	query.setParameter(1, instrId);
		int result = query.executeUpdate();
		log.debug(result+" electricity derivatives variations removed");
			return result;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing electricity derivatives variations - instrId: "+instrId+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	

}
