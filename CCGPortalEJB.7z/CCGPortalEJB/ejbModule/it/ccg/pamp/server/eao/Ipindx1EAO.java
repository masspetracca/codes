package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ClassMargin;
import it.ccg.pamp.server.entities.Ipindx1;
import it.ccg.pamp.server.entities.Ipindx1PK;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class Ipindx1EAO
 */
@Stateless
public class Ipindx1EAO implements  Ipindx1EAOLocal {

		@PersistenceContext(unitName="STDS", type=PersistenceContextType.TRANSACTION)
	    private EntityManager em;
		
		Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");

		public String updType = "C";
		
		@Resource
		SessionContext ctx;
		
		@PermitAll
		public String userString() throws DataNotValidException {
			if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
				return ctx.getCallerPrincipal().getName().toString();
			} else {
				return "System";
			}
		}
		
		public List<Ipindx1> fetch() throws DataNotValidException {
			Query query = null;
	    	try {							
	    		query = em.createNamedQuery("getAllIpindx1");
	    		List<Ipindx1> ipindx1List = query.getResultList();
	    		return ipindx1List;
	    	} catch (Exception e) {
	    		DataNotValidException exc = new DataNotValidException("Error fetching index weight on Intracs - "+e.getMessage());
	    		exc.setStackTrace(e.getStackTrace());
	    		throw exc;
	     	}
		}
		
		public Ipindx1 findByPrimaryKey(String xClass,String xSymbl) throws DataNotValidException {
			try {
				Ipindx1PK pK = new Ipindx1PK();
				pK.setXClass(xClass);
				pK.setXSymbl(xSymbl);
				Ipindx1 ipindx1 = (Ipindx1) em.find(Ipindx1.class,pK);
	    		return ipindx1;
	    	} catch (Exception e) {
	    		DataNotValidException exc = new DataNotValidException("Error fetching index weight on Intracs - index class: "+xClass+"; instrument class: "+xSymbl+"  - "+e.getMessage());
	    		exc.setStackTrace(e.getStackTrace());
	    		throw exc;
	     	}
		}
		
		public List<Ipindx1> findByIndexClass(String xClass) throws DataNotValidException {
			Query query = null;
			try {
				query = em.createNamedQuery("getIpindx1ByXClass");
				query.setParameter("xClass", xClass);
				List<Ipindx1> ipindx1List = query.getResultList();
	    		return ipindx1List;
	    	} catch (Exception e) {
	    		DataNotValidException exc = new DataNotValidException("Error fetching index weight on Intracs - index class: "+xClass+" - "+e.getMessage());
	    		exc.setStackTrace(e.getStackTrace());
	    		throw exc;
	     	}
		}
		
		public List<String> findDistinctIndexClassList() throws DataNotValidException {
			Query query = null;
			try {
				query = em.createNamedQuery("getDistinctXClass");
				List<String> indexClassList = query.getResultList();
	    		return indexClassList;
	    	} catch (Exception e) {
	    		DataNotValidException exc = new DataNotValidException("Error fetching index weight on Intracs - "+e.getMessage());
	    		exc.setStackTrace(e.getStackTrace());
	    		throw exc;
	     	}
		}
		
		public List<Ipindx1> findByInstrumentSymbl(String xSymbl) throws DataNotValidException {
			Query query = null;
			try {
				query = em.createNamedQuery("getIpindx1ByXSymbl");
				query.setParameter("xSymbl", xSymbl);
				List<Ipindx1> ipindx1List = query.getResultList();
	    		return ipindx1List;
	    	} catch (Exception e) {
	    		DataNotValidException exc = new DataNotValidException("Error fetching index weight on Intracs - instrument class: "+xSymbl+" - "+e.getMessage());
	    		exc.setStackTrace(e.getStackTrace());
	    		throw exc;
	     	}
		}

}
