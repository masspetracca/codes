package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ActionLog;
import it.ccg.pamp.server.entities.AnalysisRegister;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ActionLogEAO
 */
@Stateless
public class ActionLogEAO implements  ActionLogEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	
	
	public void add(String actDesc, String note) throws DataNotValidException {
		try {
			ActionLog actLog = new ActionLog();
			actLog.setActDesc(actDesc);
			actLog.setUpdUsr(userString());
			actLog.setActDate(GenericTools.systemDate());
			if (note!=null && note.length()>10000) {	
				note = note.substring(0, 9995);
			}
			actLog.setNote(note);
			actLog.setUpdDate(GenericTools.systemDate());
			actLog.setUpdType(updType);
			actLog.setUpdUsr(userString());
			em.persist(actLog);
			log.debug("Added new Action Log - actDesc: "+actDesc);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new log action - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(String actDesc) throws DataNotValidException {
		try {
			ActionLog actLog = new ActionLog();
			actLog.setActDesc(actDesc);
			actLog.setUpdUsr(userString());
			actLog.setActDate(GenericTools.systemDate());
			actLog.setUpdDate(GenericTools.systemDate());
			actLog.setUpdType(updType);
			actLog.setUpdUsr(userString());
			em.persist(actLog);
			log.debug("Added new Action Log - actDesc: "+actDesc);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new log action - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ActionLog> fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllLogs");
    		List<ActionLog> actLogList = query.getResultList();
    		return actLogList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching log actions - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	/*public void store(ActionLog actLog) throws DataNotValidException {
		try {
			em.persist(actLog);
			log.debug("Added new Action Log - actDesc: "+actLog.getActDesc());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new log action");
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
}
