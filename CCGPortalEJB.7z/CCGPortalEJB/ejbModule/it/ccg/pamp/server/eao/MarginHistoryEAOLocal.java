package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Margin;
import it.ccg.pamp.server.entities.MarginHistory;
import it.ccg.pamp.server.entities.MinimumMargin;
import it.ccg.pamp.server.entities.Straddle;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.WorkingMarginToExport;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.sql.SQLException;
import java.util.List;

import javax.ejb.Local;

@Local
public interface MarginHistoryEAOLocal {
	
	public String userString() throws DataNotValidException;
	
	public MarginHistory[] fetch() throws DataNotValidException;
	
	public MarginHistory findByPrimaryKey(int instrId, Timestamp iniVDate) throws DataNotValidException;
	
	public MarginHistory[] findByInstrId(int instrId) throws DataNotValidException;
	
	public MarginHistory[] findByClassId(int classId) throws DataNotValidException;
	
	public MarginHistory[] getMarginByDateAsc(int instrId, Timestamp iniVDate) throws DataNotValidException;
	
	public MarginHistory getCurrentMargin(int instrId) throws DataNotValidException;
	
	public MarginHistory getCurrentMarginByDate(int instrId, Timestamp iniVDate) throws DataNotValidException;
	
	public MarginHistory getLastSentMargin(int instrId) throws DataNotValidException;
	
	public List<WorkingMarginToExport> getWorkingMargins() throws DataNotValidException;
	
	public MarginHistory[] getMarHisToExport() throws DataNotValidException;
	
	public MarginHistory[] getMarHisNotSync() throws DataNotValidException;
	
	public MarginHistory[] getMarHisNotInCGC() throws DataNotValidException;
	
	public void add(int instrId, Timestamp iniVDate, Timestamp endvDate, BigDecimal cover, BigDecimal minMargin, String sent, 
		Timestamp sendDate, String approvedBy, Timestamp apprDate, BigDecimal anMinMar,BigDecimal anMargin, BigDecimal anCover, Timestamp anDate, 
		int rcCode, String comment, int classId, String log, BigDecimal straddle, BigDecimal anStraddle, String susp, BigDecimal mul, BigDecimal anMarginBuffer, BigDecimal anNotBufferedMargin, String anCap) throws DataNotValidException;
	
	public void store(MarginHistory marginHistory) throws DataNotValidException;
	
	public void store(Margin margin) throws DataNotValidException;
	
	public void restore(MarginHistory marginHistory) throws DataNotValidException,SQLException;
	
	public void storeEqDerivatives(Margin margin, Straddle straddle, MinimumMargin minMar) throws DataNotValidException;
	
	public void storeByMarginAndMinMargin(Margin margin, MinimumMargin minMar) throws DataNotValidException;
	
	public void update(int instrId, Timestamp iniVDate, Timestamp endvDate, BigDecimal margin, BigDecimal cover, BigDecimal minMargin, String sent, 
			Timestamp sendDate, String approvedBy, Timestamp apprDate, BigDecimal anMinMar,BigDecimal anMargin, BigDecimal anCover, Timestamp anDate, 
			int rcCode, String comment, int classId, String log, BigDecimal straddle, BigDecimal anStraddle, String susp, BigDecimal mul, BigDecimal anMarginBuffer, BigDecimal anNotBufferedMargin, String anCap) throws DataNotValidException;
	
	public void update(MarginHistory marHistory) throws DataNotValidException;
	
	public void logUpdate(MarginHistory marHistory) throws DataNotValidException;
	
	public void remove(int instrId, Timestamp iniVDate) throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
	public int removeByClassId(int classId) throws DataNotValidException;
	
	public void remove(MarginHistory marHistory) throws DataNotValidException;
	
	public MarginHistory getFirstMarginNotSuspOrOneAvailable(int instrId) throws DataNotValidException;
}
