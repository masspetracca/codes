package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.DefaultPeriod;
import it.ccg.pamp.server.entities.DefaultPeriodPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class DefaultPeriodEAO
 */
@Stateless
public class DefaultPeriodEAO implements  DefaultPeriodEAOLocal {
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	@SuppressWarnings("unchecked")
	public DefaultPeriod[] fetch() {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllDefPeriod");
    		List<DefaultPeriod> defaultPeriod = query.getResultList();
    		DefaultPeriod[] arrDefaultPeriod = new DefaultPeriod[defaultPeriod.size()];
    		return defaultPeriod.toArray(arrDefaultPeriod);
    	} catch (Exception e) {
    		return null;
    	}
	}
	
	public Integer[] getEnabledPeriods(String instrType) {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledDefPeriods");
    		query.setParameter("instrType", instrType);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		return null;
    	}
	}
	
	public Integer[] getActivePeriods(String instrType) {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getActiveDefPeriods");
    		query.setParameter("instrType", instrType);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		return null;
    	}
	}
	
	public DefaultPeriod[] findByInstrType(String instrType) {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDefPeriodByInstrType");
    		query.setParameter("instrType", instrType);
    		List<DefaultPeriod> defaultPeriodList = query.getResultList();
    		DefaultPeriod[] arrDefaultPeriod = new DefaultPeriod[defaultPeriodList.size()];
    		return defaultPeriodList.toArray(arrDefaultPeriod);
    	} catch (Exception e) {
    		return null;
    	}
	}
	
	public DefaultPeriod findByPrimaryKey(String instrType, int nDaysPer) {
		try {
			DefaultPeriodPK pK = new DefaultPeriodPK();
			pK.setInstrType(instrType);
			pK.setNDaysPer(nDaysPer);
			DefaultPeriod defaultPeriod = em.find(DefaultPeriod.class,pK);
    		return defaultPeriod;
    	} catch (Exception e) {
    		return null;
    	}
	}
}
