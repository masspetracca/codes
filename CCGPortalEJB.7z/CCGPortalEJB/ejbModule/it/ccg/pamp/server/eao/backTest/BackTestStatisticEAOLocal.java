package it.ccg.pamp.server.eao.backTest;
import it.ccg.pamp.server.entities.backTest.BackTestStatistic;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;

@Local
public interface BackTestStatisticEAOLocal {

	public List<BackTestStatistic> fetchAllBackTestStatistics() throws DataNotValidException;
	
	public List<BackTestStatistic> getBackTestStatisticsByDivisCode(String divisCode) throws DataNotValidException;
	
	public List<BackTestStatistic> getBackTestStatisticsByBtId(int btId) throws DataNotValidException;
	
	public BackTestStatistic findByPrimaryKey(int btId, int classId) throws DataNotValidException;
	
	public void add(int btId, int classId, String divisCode, String log, int nDaysPer, int onDateBrch, BigDecimal onDateCov, String status, int wrkBrch, BigDecimal wrkCov, int nVars) throws DataNotValidException;
	
	public void store(BackTestStatistic backTestStatistic) throws DataNotValidException;
	
	public void update(int btId, int classId, String divisCode, String log, int nDaysPer, int onDateBrch, BigDecimal onDateCov, String status, int wrkBrch, BigDecimal wrkCov, int nVars) throws DataNotValidException;
	
	public void remove(int btId, int classId) throws DataNotValidException;
	
	public void remove(BackTestStatistic backTestStatistic) throws DataNotValidException;
	
	
}
