package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.ElecMargin;
import it.ccg.pamp.server.entities.ElecMarginHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface ElecMarginHistoryEAOLocal {

	public List<ElecMarginHistory> fetch() throws DataNotValidException;
	
	public ElecMarginHistory findByPrimaryKey(int instrId, int month, Timestamp iniVDate) throws DataNotValidException;
	
	public List<ElecMarginHistory> findByInstrId(int instrId) throws DataNotValidException;
	
	public ElecMarginHistory[] getMarHisToExport() throws DataNotValidException;
	
	public ElecMarginHistory[] getMarHisNotSync() throws DataNotValidException;
	
	public ElecMarginHistory[] getMarHisNotInCGC() throws DataNotValidException;
	
	public ElecMarginHistory getCurrentMargin(int instrId, int month) throws DataNotValidException;
	
	public ElecMarginHistory getLastSentMargin(int instrId) throws DataNotValidException;
	
	public List<ElecMarginHistory> getElecMarginByDateAsc(int instrId, Timestamp iniVDate) throws DataNotValidException;
	
	public void add(int instrId, int month, Timestamp iniVDate, BigDecimal anCover, Timestamp anDate, BigDecimal anMargin, BigDecimal anMinMar,
		BigDecimal anStraddle, Timestamp apprDate, String approvedBy, String comment, BigDecimal cover, Timestamp endVDate, String log,
		BigDecimal margin, BigDecimal minMargin, BigDecimal mul, int rcCode, Timestamp sendDate, String sent, BigDecimal straddle, String susp) throws DataNotValidException;
	
	public void store(ElecMarginHistory elecMarginHistory) throws DataNotValidException;
	
	public void store(ElecMargin elecMargin) throws DataNotValidException;
	
	public void update(int instrId, int month, Timestamp iniVDate, BigDecimal anCover, Timestamp anDate, BigDecimal anMargin, BigDecimal anMinMar,
			BigDecimal anStraddle, Timestamp apprDate, String approvedBy, String comment, BigDecimal cover, Timestamp endVDate, String log,
			BigDecimal margin, BigDecimal minMargin, BigDecimal mul, int rcCode, Timestamp sendDate, String sent, BigDecimal straddle, String susp) throws DataNotValidException;
	
	public void update(ElecMarginHistory elecMarginHistory) throws DataNotValidException;
	
	public void remove(int instrId, int month, Timestamp iniVDate) throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
	public void remove(ElecMarginHistory elecMarHistory) throws DataNotValidException;	
	
}
