package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.SetParameter;
import it.ccg.pamp.server.entities.SetParameterPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class SetParameterEAO
 */
@Stateless
public class SetParameterEAO implements  SetParameterEAOLocal {
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	
	public SetParameter[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSetPar");
    		List<SetParameter> setParameter = query.getResultList();
    		SetParameter[] arrSetParameter = new SetParameter[setParameter.size()];
    		return setParameter.toArray(arrSetParameter);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Set Parameters - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SetParameter findByPrimaryKey(int nDaysPer, int nv, int setId) throws DataNotValidException {
		try {
			SetParameterPK pK = new SetParameterPK();
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			pK.setSetId(setId);
			SetParameter setParameter = (SetParameter) em.find(SetParameter.class,pK);
    		return setParameter;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Set Parameter - setId: "+setId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SetParameter[] findBySetId(int setId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSetParBySetId");
    		query.setParameter("setId", setId);
    		List<SetParameter> setParameter = query.getResultList();
    		SetParameter[] arrSetParameter = new SetParameter[setParameter.size()];
    		return setParameter.toArray(arrSetParameter);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Set Parameters - setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SetParameter[] fetchWithSets(int setId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSetParWithSets");
    		query.setParameter("setId", setId);
    		List<SetParameter> setParameter = query.getResultList();
    		SetParameter[] arrSetParameter = new SetParameter[setParameter.size()];
    		return setParameter.toArray(arrSetParameter);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Set Parameters with Sets - setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActiveDelta(int setId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getActiveDeltaForSetPar");
    		query.setParameter("setId", setId);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active delta for Set Parameters - setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActivePeriods(int setId, int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getActivePeriodsForSetPar");
    		query.setParameter("setId", setId);
    		query.setParameter("delta", delta);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active periods for Set Parameters - setId: "+setId+"; delta: "+delta+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getEnabledPeriods(int setId, int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledPeriodsForSetPar");
    		query.setParameter("setId", setId);
    		query.setParameter("delta", delta);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled periods for Set Parameters - setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int nDaysPer, int nv, int setId, String pStatus) throws DataNotValidException {
		try {
			SetParameter setParameter = new SetParameter();
			SetParameterPK pK = new SetParameterPK();
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			pK.setSetId(setId);
			setParameter.setPk(pK);
			setParameter.setPStatus(pStatus);
			setParameter.setUpdType(updType);
			setParameter.setUpdDate(GenericTools.systemDate());
			setParameter.setUpdUsr(userString());
			em.persist(setParameter);
			log.debug("Added new Set Parameter - setId: "+setId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Set Parameter - setId: "+setId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(SetParameter setParameter) throws DataNotValidException {
		try {
			setParameter.setUpdType(updType);
			setParameter.setUpdDate(GenericTools.systemDate());
			setParameter.setUpdUsr(userString());
			em.persist(setParameter);
			log.debug("Added new Set Parameter - setId: "+setParameter.getPk().getSetId()+"; nDaysPer: "+setParameter.getPk().getNDaysPer()+"; holding period: "+setParameter.getPk().getNv());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Set Parameter - setId: "+setParameter.getPk().getSetId()+"; nDaysPer: "+setParameter.getPk().getNDaysPer()+"; holding period: "+setParameter.getPk().getNv()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public void restore(int updId) throws DataNotValidException {
		Query query = null;	
		try {
			query = em.createNamedQuery("getSetParArchByUpdId");
    		query.setParameter("updId", updId);
    		SetParameterArchive setParArchive = (SetParameterArchive) query.getSingleResult();
    		SetParameter setParameter = findByPrimaryKey(setParArchive.getNDaysPer(),setParArchive.getNv(),setParArchive.getSetId());
    		boolean notExists = false;
    		if (setParameter==null) {
    			setParameter = new SetParameter();
    			SetParameterPK pK = new SetParameterPK();
    			pK.setNDaysPer(setParArchive.getNDaysPer());
    			pK.setNv(setParArchive.getNv());
    			pK.setSetId(setParArchive.getSetId());
    			setParameter.setPk(pK);
    			notExists = true;
    		}
    		setParameter.setPStatus(setParArchive.getPStatus());
			setParameter.setUpdType("U");
			setParameter.setUpdDate(GenericTools.systemDate());
			setParameter.setUpdUsr(setParArchive.getUpdUsr());
			if (notExists) {
    			store(setParameter);
    		}
			log.debug("Set Parameter restored - nDaysPer: "+setParArchive.getNDaysPer()+"; nv: "+setParArchive.getNv()+"; setParArchive: "+setParArchive.getSetId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error restoring Set Parameter from archive - updId: "+updId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
	public void update(int nDaysPer, int nv, int setId, String pStatus) throws DataNotValidException {
		try {
			SetParameter setParameter = findByPrimaryKey(nDaysPer, nv, setId);
			setParameter.setPStatus(pStatus);
			setParameter.setUpdType("U");
			setParameter.setUpdDate(GenericTools.systemDate());
			setParameter.setUpdUsr(userString());
			log.debug("Set Parameter updated - setId: "+setId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error updating Set Parameter - setId: "+setId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	public void update(SetParameter setParam) throws DataNotValidException {
		try {
			SetParameter setParameter = findByPrimaryKey(setParam.getPk().getNDaysPer(), setParam.getPk().getNv(), setParam.getPk().getSetId());
			setParameter.setUpdType("U");
			setParameter.setUpdDate(GenericTools.systemDate());
			setParameter.setUpdUsr(userString());
			log.debug("Set Parameter updated - setId: "+setParam.getPk().getSetId()+"; nDaysPer: "+setParam.getPk().getNDaysPer()+"; holding period: "+setParam.getPk().getNv());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error updating Set Parameter - setId: "+setParam.getPk().getSetId()+"; nDaysPer: "+setParam.getPk().getNDaysPer()+"; holding period: "+setParam.getPk().getNv()+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	public void remove(int nDaysPer, int nv, int setId) throws DataNotValidException {
		try {
			SetParameter setParameter = findByPrimaryKey(nDaysPer, nv, setId);
			em.remove(setParameter);
			log.debug("Set Parameter removed - setId: "+setId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing new Set Parameter - setId: "+setId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeBySetId(int setId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteSetParBySetId");
			query.setParameter("setId", setId);
			int result = query.executeUpdate();
			log.debug(result+" Set Parameters removed - setId: "+setId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Set Parameters - setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(SetParameter setParam) throws DataNotValidException {
		remove(setParam.getPk().getNDaysPer(), setParam.getPk().getNv(), setParam.getPk().getSetId());
	}
}
