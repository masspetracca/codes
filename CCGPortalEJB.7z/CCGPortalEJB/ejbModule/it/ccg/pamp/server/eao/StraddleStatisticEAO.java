package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.StraddleStatistic;
import it.ccg.pamp.server.entities.StraddleStatisticPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StraddleStatisticEAO
 */
@Stateless
public class StraddleStatisticEAO implements  StraddleStatisticEAOLocal {
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	public StraddleStatistic[] fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllStraddleStatistics");
    		List<StraddleStatistic> streddleExpiration = query.getResultList();
    		StraddleStatistic[] arrStreddleExpiration = new StraddleStatistic[streddleExpiration.size()];
    		return streddleExpiration.toArray(arrStreddleExpiration);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Straddle Statistics - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public StraddleStatistic findByPrimaryKey(int instrId, int progExp1, int progExp2, int mode) throws DataNotValidException  {
		try {
			StraddleStatisticPK pK = new StraddleStatisticPK();
			pK.setInstrId(instrId);
			pK.setProgExp1(progExp1);
			pK.setProgExp2(progExp2);
			pK.setMode(mode);
			StraddleStatistic straddleStats = (StraddleStatistic) em.find(StraddleStatistic.class,pK);
			return straddleStats;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Straddle Statistic - instrId: "+instrId+"; progExp1: "+progExp1+"; progExp2: "+progExp2+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<String> printStraddleStatistics(int instrId) throws DataNotValidException {
		
		List<StraddleStatistic> straddleStatisticArr = this.getStraddleStatsByInstrIdAndMode1(instrId);
		
		String straStLog = "";
		
		List<String> straStatsForLog = new ArrayList<String>();
		
		MathContext mc = new MathContext(4);
		
		for (StraddleStatistic straStat:straddleStatisticArr) {
			
			straStLog = "";
			
			straStLog += "Exp. Short: "+straStat.getPk().getProgExp1()+"; ";
			straStLog += "Exp. Long: "+straStat.getPk().getProgExp2()+"; ";
			straStLog += "IR Short: "+GenericTools.percentValue(straStat.getRiskFree1(),mc)+"; ";
			straStLog += "IR Long: "+GenericTools.percentValue(straStat.getRiskFree2(),mc)+"; ";
			straStLog += "Delta Straddle: "+straStat.getDeltaStr().round(mc)+"; ";
			straStLog += "Spread Bid/Ask: "+straStat.getSprbidask().round(mc)+"; ";
			straStLog += "Ratio Ord/Stra: "+straStat.getRatio().round(mc)+"; ";
			straStLog += "Straddle: "+straStat.getCurrStr().round(mc);
			
			straStatsForLog.add(straStLog);
			
		}
		return straStatsForLog;
	}
	
	
	public StraddleStatistic[] getStraddleStatsByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getStraddleStatisticsByInstrId");
    		query.setParameter("instrId", instrId);
    		List<StraddleStatistic> straddleStats = query.getResultList();
    		StraddleStatistic[] arrStreddleStatistic = new StraddleStatistic[straddleStats.size()];
    		return straddleStats.toArray(arrStreddleStatistic);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Straddle Statistics by instrId - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StraddleStatistic> getStraddleStatsByInstrIdAndMode1(int instrId) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getStraddleStatisticsByInstrIdAndMode1");
    		query.setParameter("instrId", instrId);
    		List<StraddleStatistic> straddleStatsList = query.getResultList();
    		if (straddleStatsList.size()>0) {
    			return straddleStatsList;
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Straddle Statistics by instrId - instrId: "+instrId+"; mode: 1 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public StraddleStatistic getMaxMathStraddleByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getMaxMathStraddle");
    		query.setParameter("instrId", instrId);
    		List<StraddleStatistic> straddleStats = query.getResultList();
    		//StraddleStatistic[] straddleStat = new StraddleStatistic[straddleStats.size()];
    		if (straddleStats.size()>0) {
    			return straddleStats.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Straddle Statistics by instrId - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, int progExp1, int progExp2, int mode, BigDecimal riskFree1, BigDecimal expYearFr1, BigDecimal expDelRat1, BigDecimal riskFree2, BigDecimal expYearFr2, BigDecimal expDelRat2, BigDecimal closePr,
		BigDecimal margin, BigDecimal deltaStr, int mul, BigDecimal sprbidask, BigDecimal mathStr, BigDecimal ratio, BigDecimal riskFrVar1, BigDecimal riskFrVar2, BigDecimal finStr, BigDecimal currStr, BigDecimal ordMargin, BigDecimal undMargin) throws DataNotValidException {
		
		try {
			StraddleStatistic straddleStatistic = new StraddleStatistic();
			StraddleStatisticPK pK = new StraddleStatisticPK();
			pK.setInstrId(instrId);
			pK.setProgExp1(progExp1);
			pK.setProgExp2(progExp2);
			pK.setMode(mode);
			straddleStatistic.setPk(pK);
			straddleStatistic.setRiskFree1(riskFree1);
			straddleStatistic.setExpYearFr1(expYearFr1);
			straddleStatistic.setExpDelRat1(expDelRat1);
			straddleStatistic.setRiskFree2(riskFree2);
			straddleStatistic.setExpYearFr2(expYearFr2);
			straddleStatistic.setExpDelRat2(expDelRat2);
			straddleStatistic.setClosePr(closePr);
			straddleStatistic.setMargin(margin);
			straddleStatistic.setDeltaStr(deltaStr);
			straddleStatistic.setMul(mul);
			straddleStatistic.setSprbidask(sprbidask);
			straddleStatistic.setMathStr(mathStr);
			straddleStatistic.setRatio(ratio);
			straddleStatistic.setRiskFrVar1(riskFrVar1);
			straddleStatistic.setRiskFrVar2(riskFrVar2);
			straddleStatistic.setFinStr(finStr);
			straddleStatistic.setCurrStr(currStr);
			straddleStatistic.setOrdMargin(ordMargin);
			straddleStatistic.setUndMargin(undMargin);
			straddleStatistic.setUpdDate(GenericTools.systemDate());
			straddleStatistic.setUpdType(updType);
			straddleStatistic.setUpdUsr(userString());
			em.persist(straddleStatistic);
			log.debug("Added new Straddle Statistic - instrId: "+instrId+"; progExp1: "+progExp1+"; progExp2: "+progExp2+"; mode: "+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Straddle Statistic - instrId: "+instrId+"; progExp1: "+progExp1+"; progExp2: "+progExp2+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(StraddleStatistic straddleStatistic) throws DataNotValidException {
		try {
			straddleStatistic.setUpdDate(GenericTools.systemDate());
			straddleStatistic.setUpdType(updType);
			straddleStatistic.setUpdUsr(userString());
			em.persist(straddleStatistic);
			log.debug("Added new Straddle Statistic - instrId: "+straddleStatistic.getPk().getInstrId()+"; progExp1: "+straddleStatistic.getPk().getProgExp1()+"; progExp2: "+straddleStatistic.getPk().getProgExp2()+"; mode: "+straddleStatistic.getPk().getMode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Streddle Statistic - instrId: "+straddleStatistic.getPk().getInstrId()+"; progExp1: "+straddleStatistic.getPk().getProgExp1()+"; progExp2: "+straddleStatistic.getPk().getProgExp2()+"; mode: "+straddleStatistic.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, int progExp1, int progExp2, int mode, BigDecimal riskFree1, BigDecimal expYearFr1, BigDecimal expDelRat1, BigDecimal riskFree2, BigDecimal expYearFr2, BigDecimal expDelRat2, BigDecimal closePr,
			BigDecimal margin, BigDecimal deltaStr, int mul, BigDecimal sprbidask, BigDecimal mathStr, BigDecimal ratio, BigDecimal riskFrVar1, BigDecimal riskFrVar2, BigDecimal finStr, BigDecimal currStr, BigDecimal ordMargin, BigDecimal undMargin) throws DataNotValidException {
		try {
			StraddleStatistic straddleStatistic = findByPrimaryKey(instrId,progExp1,progExp2,mode);
			straddleStatistic.setRiskFree1(riskFree1);
			straddleStatistic.setExpYearFr1(expYearFr1);
			straddleStatistic.setExpDelRat1(expDelRat1);
			straddleStatistic.setRiskFree2(riskFree2);
			straddleStatistic.setExpYearFr2(expYearFr2);
			straddleStatistic.setExpDelRat2(expDelRat2);
			straddleStatistic.setClosePr(closePr);
			straddleStatistic.setMargin(margin);
			straddleStatistic.setDeltaStr(deltaStr);
			straddleStatistic.setMul(mul);
			straddleStatistic.setSprbidask(sprbidask);
			straddleStatistic.setMathStr(mathStr);
			straddleStatistic.setRatio(ratio);
			straddleStatistic.setRiskFrVar1(riskFrVar1);
			straddleStatistic.setRiskFrVar2(riskFrVar2);
			straddleStatistic.setFinStr(finStr);
			straddleStatistic.setCurrStr(currStr);
			straddleStatistic.setOrdMargin(ordMargin);
			straddleStatistic.setUndMargin(undMargin);
			straddleStatistic.setUpdDate(GenericTools.systemDate());
			straddleStatistic.setUpdType("U");
			straddleStatistic.setUpdUsr(userString());
			log.debug("Updated Streddle Statistic - instrId: "+instrId+"; progExp1: "+progExp1+", progExp2: "+progExp2+"; mode: "+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Streddle Statistic - instrId: "+instrId+"; progExp1: "+progExp1+", progExp2: "+progExp2+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(StraddleStatistic straddleStatistic) throws DataNotValidException {
		try {
			log.debug("Updated Streddle Statistic - instrId: "+straddleStatistic.getPk().getInstrId()+"; progExp1: "+straddleStatistic.getPk().getProgExp1()+"; progExp2: "+straddleStatistic.getPk().getProgExp2()+"; mode: "+straddleStatistic.getPk().getMode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Streddle Expiration - instrId: "+straddleStatistic.getPk().getInstrId()+"; progExp1: "+straddleStatistic.getPk().getProgExp1()+"; progExp2: "+straddleStatistic.getPk().getProgExp2()+"; mode: "+straddleStatistic.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, int progExp1, int progExp2, int mode) throws DataNotValidException {
		try {
			StraddleStatistic streddleStats = findByPrimaryKey(instrId,progExp1, progExp2, mode);
			em.remove(streddleStats);
			log.debug("Straddle Statistic removed - instrId: "+instrId+"; progExp1: "+progExp1+"; progExp2: "+progExp2+"; mode: "+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Streddle Statistic - instrId: "+instrId+"; progExp1: "+progExp1+"; progExp2: "+progExp2+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteStraddleStatisticsByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Straddle Statistics removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Straddle Statistics - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteStraStatByEnabledInstrId");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" Straddle Statistics related to disabled instruments removed - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing straddle statistics related to disabled instruments - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByMode(int mode) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteStraddleStatisticsByMode");
			query.setParameter("mode", mode);
			int result = query.executeUpdate();
			log.debug(result+" Straddle Statistics removed - mode: "+mode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Straddle Statistics - mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(StraddleStatistic straddleStats) throws DataNotValidException {
		remove(straddleStats.getPk().getInstrId(),straddleStats.getPk().getProgExp1(),straddleStats.getPk().getProgExp2(),straddleStats.getPk().getMode());
	}
	
	public void transferMode1To2() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("deleteMode2forStrStats");
    		query.executeUpdate();
    		query = em.createNativeQuery("INSERT INTO PMPTSTRSTA " +
			"(INSTRID,RISKFREE1,EXPYEARFR1,EXPDELRAT1,RISKFREE2,EXPYEARFR2,EXPDELRAT2,CLOSEPR,MARGIN,DELTASTR,MUL,SPRBIDASK,MATHSTR,RATIO,PROGEXP1,PROGEXP2,RISKFRVAR1,RISKFRVAR2,FINSTR,CURRSTR,MODE,ORDMARGIN,UNDMARGIN,UPDDATE,UPDTYPE,UPDUSR) "+
			" (SELECT INSTRID,RISKFREE1,EXPYEARFR1,EXPDELRAT1,RISKFREE2,EXPYEARFR2,EXPDELRAT2,CLOSEPR,MARGIN,DELTASTR,MUL,SPRBIDASK,MATHSTR,RATIO,PROGEXP1,PROGEXP2,RISKFRVAR1,RISKFRVAR2,FINSTR,CURRSTR,2,ORDMARGIN,UNDMARGIN,'"+GenericTools.systemDate()+"','C','"+userString()+"' FROM PMPTSTRSTA WHERE MODE=1)");
    		/*query = em.createNamedQuery("transferMode1to2forStrStats");
    		query.setParameter(1, GenericTools.systemDate());
    		query.setParameter(2, userString());*/
    		query.executeUpdate();
    		log.debug("transfer of straddle stats from mode 1 to 2 has been completed");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring straddle Statistics from mode 1 to 2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
