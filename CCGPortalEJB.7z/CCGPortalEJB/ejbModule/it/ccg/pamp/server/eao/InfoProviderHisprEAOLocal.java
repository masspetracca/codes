package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.InfoProviderHispr;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface InfoProviderHisprEAOLocal {
	
	public List<InfoProviderHispr> findByInstrIdAfterDate(int instrId, long priceDate) throws DataNotValidException;

}
