package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.RiskCommittee;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;

import javax.ejb.Local;

@Local
public interface RiskCommitteeEAOLocal {
	public RiskCommittee[] fetch() throws DataNotValidException;
	public RiskCommittee findByPrimaryKey(int rcCode) throws DataNotValidException;
	public RiskCommittee findLast() throws DataNotValidException;
	public void add(Timestamp rcDate, String rcDesc) throws DataNotValidException;
	public void store(RiskCommittee riskCommittee) throws DataNotValidException;
	public void update(int rcCode, Timestamp rcDate, String rcDesc) throws DataNotValidException;
	public void update(RiskCommittee rskCommittee) throws DataNotValidException;
	public void remove(RiskCommittee rskCommittee) throws DataNotValidException;
}
