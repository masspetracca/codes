package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ETFIncome;
import it.ccg.pamp.server.entities.HistoricalVolSeries;
import it.ccg.pamp.server.entities.HistoricalVolSeriesPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class HistoricalVolSeriesEAO
 */
@Stateless
public class HistoricalVolSeriesEAO implements  HistoricalVolSeriesEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public String userString = "System";
	public String updType = "C";
	
	
	public HistoricalVolSeries[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllHisVol");
    		List<HistoricalVolSeries> historicalVolSeries = query.getResultList();
    		HistoricalVolSeries[] arrHistoricalVolSeries = new HistoricalVolSeries[historicalVolSeries.size()];
    		return historicalVolSeries.toArray(arrHistoricalVolSeries);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Volatility Series - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalVolSeries findByPrimaryKey(int instrId, Timestamp volaDate, int progExp, String pc, BigDecimal strike, String isinCode) throws DataNotValidException {
		try {
			HistoricalVolSeriesPK pK = new HistoricalVolSeriesPK();
			pK.setInstrId(instrId);
			pK.setVolaDate(volaDate);
			pK.setProgExp(progExp);
			pK.setPc(pc);
			pK.setStrike(strike);
			pK.setIsinCode(isinCode);
			HistoricalVolSeries historicalVolSeries = (HistoricalVolSeries) em.find(HistoricalVolSeries.class,pK);
    		return historicalVolSeries;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Volatility Series - instrId: "+instrId+"; volaDate:"+volaDate+"; progExp: "+progExp+"; pc: "+pc+"; strike: "+strike+"; isinCode: "+isinCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalVolSeries[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHisVolByInstrId");
    		query.setParameter("instrId", instrId);
    		List<HistoricalVolSeries> historicalVolSeries = query.getResultList();
    		HistoricalVolSeries[] arrHistoricalVolSeries = new HistoricalVolSeries[historicalVolSeries.size()];
    		return historicalVolSeries.toArray(arrHistoricalVolSeries);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Volatility Series - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, Timestamp volaDate, int progExp, String pc, BigDecimal strike, String status, BigDecimal vola, int expiry, String isinCode) throws DataNotValidException {
		try {
			HistoricalVolSeries historicalVolSeries = findByPrimaryKey(instrId, volaDate, progExp, pc, strike,isinCode);
			historicalVolSeries = new HistoricalVolSeries();
			HistoricalVolSeriesPK pK = new HistoricalVolSeriesPK();
			pK.setInstrId(instrId);
			pK.setVolaDate(volaDate);
			pK.setProgExp(progExp);
			pK.setPc(pc);
			pK.setStrike(strike);
			pK.setIsinCode(isinCode);
			historicalVolSeries.setPk(pK);
			historicalVolSeries.setStatus(status);
			historicalVolSeries.setVola(vola);
			historicalVolSeries.setExpiry(expiry);
			historicalVolSeries.setUpdType(updType);
			historicalVolSeries.setUpdDate(GenericTools.systemDate());
			historicalVolSeries.setUpdUsr(userString());
			em.persist(historicalVolSeries);
			log.debug("Added new Historical Volatility Series - instrId: "+instrId+"; volaDate:"+volaDate+"; progExp: "+progExp+"; pc: "+pc+"; strike: "+strike+"; isinCode: "+isinCode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Historical Volatility Series - instrId: "+instrId+"; volaDate:"+volaDate+"; progExp: "+progExp+"; pc: "+pc+"; strike: "+strike+"; isinCode: "+isinCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(HistoricalVolSeries historicalVolSeries) throws DataNotValidException {
		try {
			historicalVolSeries.setUpdType(updType);
			historicalVolSeries.setUpdDate(GenericTools.systemDate());
			historicalVolSeries.setUpdUsr(userString());
			em.persist(historicalVolSeries);
			log.debug("Added new Historical Volatility Series - instrId: "+historicalVolSeries.getPk().getInstrId()+"; volaDate:"+historicalVolSeries.getPk().getVolaDate()+"; progExp: "+historicalVolSeries.getPk().getProgExp()+"; pc: "+historicalVolSeries.getPk().getPc()+"; strike: "+historicalVolSeries.getPk().getStrike()+"; isinCode: "+historicalVolSeries.getPk().getIsinCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Historical Volatility Series - instrId: "+historicalVolSeries.getPk().getInstrId()+"; volaDate:"+historicalVolSeries.getPk().getVolaDate()+"; progExp: "+historicalVolSeries.getPk().getProgExp()+"; pc: "+historicalVolSeries.getPk().getPc()+"; strike: "+historicalVolSeries.getPk().getStrike()+"; isinCode: "+historicalVolSeries.getPk().getIsinCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, Timestamp volaDate, int progExp, String pc, BigDecimal strike, String status, BigDecimal vola, int expiry, String isinCode) throws DataNotValidException {
		try {
			HistoricalVolSeries historicalVolSeries = findByPrimaryKey(instrId, volaDate, progExp, pc, strike, isinCode);
			historicalVolSeries.setStatus(status);
			historicalVolSeries.setVola(vola);
			historicalVolSeries.setExpiry(expiry);
			historicalVolSeries.setUpdType("U");
			historicalVolSeries.setUpdDate(GenericTools.systemDate());
			historicalVolSeries.setUpdUsr(userString());
			log.debug("Historical Volatility Series updated - instrId: "+instrId+"; volaDate:"+volaDate+"; progExp: "+progExp+"; pc: "+pc+"; strike: "+strike+"; isinCode: "+isinCode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Historical Volatility Series - instrId: "+instrId+"; volaDate:"+volaDate+"; progExp: "+progExp+"; pc: "+pc+"; strike: "+strike+"; isinCode: "+isinCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(HistoricalVolSeries histVolSeries) throws DataNotValidException {
		try {
			HistoricalVolSeries historicalVolSeries = findByPrimaryKey(histVolSeries.getPk().getInstrId(),histVolSeries.getPk().getVolaDate(),histVolSeries.getPk().getProgExp(),histVolSeries.getPk().getPc(),histVolSeries.getPk().getStrike(),histVolSeries.getPk().getIsinCode());
			historicalVolSeries.setUpdType("U");
			historicalVolSeries.setUpdDate(GenericTools.systemDate());
			historicalVolSeries.setUpdUsr(userString());
			log.debug("Historical Volatility Series updated - instrId: "+historicalVolSeries.getPk().getInstrId()+"; volaDate:"+historicalVolSeries.getPk().getVolaDate()+"; progExp: "+historicalVolSeries.getPk().getProgExp()+"; pc: "+historicalVolSeries.getPk().getPc()+"; strike: "+historicalVolSeries.getPk().getStrike()+"; isinCode: "+historicalVolSeries.getPk().getIsinCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Historical Volatility Series - instrId: "+histVolSeries.getPk().getInstrId()+"; volaDate:"+histVolSeries.getPk().getVolaDate()+"; progExp: "+histVolSeries.getPk().getProgExp()+"; pc: "+histVolSeries.getPk().getPc()+"; strike: "+histVolSeries.getPk().getStrike()+"; isinCode: "+histVolSeries.getPk().getIsinCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	 
	public void remove(int instrId, Timestamp volaDate, int progExp, String pc, BigDecimal strike, String isinCode) throws DataNotValidException {
		try {
			HistoricalVolSeries historicalVolSeries = findByPrimaryKey(instrId, volaDate, progExp, pc, strike, isinCode);
			em.remove(historicalVolSeries);
			log.debug("Historical Volatility Series removed - instrId: "+instrId+"; volaDate:"+volaDate+"; progExp: "+progExp+"; pc: "+pc+"; strike: "+strike+"; isinCode: "+isinCode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Historical Volatility Series - instrId: "+instrId+"; volaDate:"+volaDate+"; progExp: "+progExp+"; pc: "+pc+"; strike: "+strike+"; isinCode: "+isinCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteHisVolByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Historical Volatility Series removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Historical Volatility Series - instrId: "+instrId+" "+e.getMessage()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(HistoricalVolSeries histVolSeries) throws DataNotValidException {
		remove(histVolSeries.getPk().getInstrId(),histVolSeries.getPk().getVolaDate(),histVolSeries.getPk().getProgExp(),histVolSeries.getPk().getPc(),histVolSeries.getPk().getStrike(),histVolSeries.getPk().getIsinCode());
	}	
}
