package it.ccg.pamp.server.eao;

import java.util.List;

import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.Mtsmgnf34f;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.entities.stressTest.StressTestMember;
import it.ccg.pamp.server.entities.stressTest.StressTestMemberPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondRecordForStressTest;
import it.ccg.pamp.server.utils.GenericTools;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StressTestMtsmgnf34fEAO
 */
@Stateless
public class Mtsmgnf34fEAO implements  Mtsmgnf34fEAOLocal {

	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	public List<Mtsmgnf34f> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllMtsmgnf34f");
    		List<Mtsmgnf34f> mtsmgnf34fList = query.getResultList();
    		return mtsmgnf34fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond prices - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public Mtsmgnf34f findByPrimaryKey(String pf34prd) throws DataNotValidException {
		try {
			Mtsmgnf34f mtsmgnf34f = (Mtsmgnf34f) em.find(Mtsmgnf34f.class,pf34prd);
    		return mtsmgnf34f;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond price - isinCode: "+pf34prd+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<BondRecordForStressTest> getBondRecordsForStressTest() throws DataNotValidException {
		  
		Query query = null;
    	try {
    		//String sqlString = "SELECT VAR2.INSTRID,VAR2.NV,VAR2.PRICEDATE,VAR2.VARTYPE,VAR2.VARIAT,VAR2.PRGEXP,VAR2.STATUS,VAR2.UPDTYPE,VAR2.UPDUSR,VAR2.UPDDATE FROM ";
    		String sqlString = "SELECT EBM_CTYP AS ISINCODE, EBM_BOND_C AS DESCRIPTION, EBM_MAT_DT AS SCADENZA, CPN_RT_DAT AS DATAPRCEDOLA,EBM_FC_RAT AS CEDOLA, PF_34MED AS PRICE, PF_34DUR AS DURATION ";
    		sqlString += "FROM MTSMGNF34F ";
    		sqlString += "INNER JOIN EBMPRDP ";
    		sqlString += "ON EBM_CTYP = PF_34PRD ";
    		sqlString += "WHERE EBM_MKT_CD = 004 ";
    		sqlString += "ORDER BY ISINCODE, SCADENZA";
    		//sqlString += "VAR2 ";
    		
    		//System.out.println(sqlString);
    		
    		query =  em.createNativeQuery(sqlString,BondRecordForStressTest.class);
    		List<BondRecordForStressTest> bondRecordsForStressTestList = query.getResultList();

   			return bondRecordsForStressTestList;
   			
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching the list of bonds - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	

}
