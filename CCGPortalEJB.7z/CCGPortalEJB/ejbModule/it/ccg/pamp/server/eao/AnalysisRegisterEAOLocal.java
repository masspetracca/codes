package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.AnalysisRegister;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;

import javax.ejb.Local;

@Local
public interface AnalysisRegisterEAOLocal {
	public AnalysisRegister[] fetch() throws DataNotValidException;
	public AnalysisRegister findByPrimaryKey(int anCode) throws DataNotValidException;
	public AnalysisRegister findLastAnalysis() throws DataNotValidException;
	public void add(Timestamp anDate, String comment) throws DataNotValidException;
	public void store(AnalysisRegister analysisRegister) throws DataNotValidException;
	public void update(int anCode, Timestamp anDate, String comment) throws DataNotValidException;
	public void update(AnalysisRegister analysisRegister) throws DataNotValidException;
	public void remove(int anCode) throws DataNotValidException;
	public void remove(AnalysisRegister analysisRegister) throws DataNotValidException;
}
