package it.ccg.pamp.server.eao;
import java.math.BigDecimal;
import java.util.List;

import it.ccg.pamp.server.entities.ExpirationCorrelation;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.ExpCorrGroupedBy;

import javax.ejb.Local;

@Local
public interface ExpirationCorrelationEAOLocal {
	public ExpirationCorrelation[] fetch() throws DataNotValidException;
	public ExpirationCorrelation findByPrimaryKey(int instrId, int progExp1, int progExp2, int nv, int nDaysPer, String varType, int mode) throws DataNotValidException;
	public ExpirationCorrelation[] findByInstrId(int instrId) throws DataNotValidException;
	public ExpCorrGroupedBy getEnabledMinCorrel(int instrId, String corrType) throws DataNotValidException;
	
	public List<String> printExpCorr(int instrId, String corrType) throws DataNotValidException;
	public List<ExpirationCorrelation> findByInstrIdAndNvAndNDaysPer(int instrId, int nv, int nDaysPer) throws DataNotValidException;
	public List<ExpirationCorrelation> findByInstrIdAndCorrType(int instrId, String corrType) throws DataNotValidException;
	
	public void add(int instrId, int progExp1, int progExp2, int nv, int nDaysPer, String varType, int mode, BigDecimal correl, BigDecimal pearson, BigDecimal divUnDiv, int histDays,  String status) throws DataNotValidException;
	public void store(ExpirationCorrelation expirationCorrelation) throws DataNotValidException;
	public void update(int instrId, int progExp1, int progExp2, int nv, int nDaysPer, String varType, int mode, BigDecimal correl, BigDecimal pearson, BigDecimal divUnDiv, int histDays,  String status) throws DataNotValidException;
	public void update(ExpirationCorrelation expirationCorrel) throws DataNotValidException; 
	
	public void remove(int instrId, int progExp1, int progExp2, int nv, int nDaysPer, String varType, int mode) throws DataNotValidException;
	public int removeByInstrId(int instrId) throws DataNotValidException;
	public void remove(ExpirationCorrelation expirationCorrel) throws DataNotValidException;
	
	public void transferMode1To2() throws DataNotValidException;
	
}
