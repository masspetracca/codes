package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Margin;
import it.ccg.pamp.server.entities.MinimumMargin;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MinimumMarginEAO
 */
@Stateless
public class MinimumMarginEAO implements  MinimumMarginEAOLocal {
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public String updType = "C";
	
	
	
	public MinimumMargin[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllMinMargin");
    		List<MinimumMargin> minimumMargin = query.getResultList();
    		MinimumMargin[] arrMinimumMargin = new MinimumMargin[minimumMargin.size()];
    		return minimumMargin.toArray(arrMinimumMargin);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching minimum margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public MinimumMargin[] getEnabledMinimumMargins() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllEnabledMinMargin");
    		List<MinimumMargin> minimumMargin = query.getResultList();
    		MinimumMargin[] arrMinimumMargin = new MinimumMargin[minimumMargin.size()];
    		return minimumMargin.toArray(arrMinimumMargin);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled minimum margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public MinimumMargin getMinMarginByUndInstrId(int undInstrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMinMarginByUndInstrId");
    		query.setParameter("undInstrId", undInstrId);
    		List<MinimumMargin> minimumMargin = query.getResultList();
    	//	MinimumMargin minimumMargin = (MinimumMargin) query.getSingleResult();
    		if(minimumMargin.size()==0) return null;
    		else
    		return minimumMargin.get(0);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled minimum margin - undInstrId: "+undInstrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public MinimumMargin[] getEnabledMinimumMarginsByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllEnabledMinMarginByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<MinimumMargin> minimumMargin = query.getResultList();
    		MinimumMargin[] arrMinimumMargin = new MinimumMargin[minimumMargin.size()];
    		return minimumMargin.toArray(arrMinimumMargin);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled minimum margins - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public MinimumMargin findByPrimaryKey(int instrId) throws DataNotValidException {
		try {
			MinimumMargin minMargin = (MinimumMargin) em.find(MinimumMargin.class,instrId);
    		return minMargin;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching minimum margin - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, Timestamp inivDate, Timestamp endvDate, Timestamp sendDate, String status, BigDecimal crMinMarM, BigDecimal anMinMar, 
		BigDecimal usrMinMar, Timestamp anDate, BigDecimal propMinMar, String propose, String approval, int rcCode, String comment, String crLog, String anLog, String propLog, String custom) throws DataNotValidException {
		
		try {
			MinimumMargin minMargin = new MinimumMargin();
			minMargin.setInivDate(inivDate);
			minMargin.setEndvDate(endvDate);
			minMargin.setSendDate(sendDate);
			minMargin.setStatus(status);
			minMargin.setCrMinMarM(crMinMarM);
			minMargin.setAnMinMar(anMinMar);
			minMargin.setUsrMinMar(usrMinMar);
			minMargin.setAnDate(anDate);
			minMargin.setPropMinMar(propMinMar);
			minMargin.setPropose(propose);
			minMargin.setApproval(approval);
			minMargin.setRcCode(rcCode);
			minMargin.setComment(comment);
			minMargin.setCrLog(crLog);
			minMargin.setAnLog(anLog);
			minMargin.setPropLog(propLog);
			minMargin.setUpdType(updType);
			minMargin.setUpdDate(GenericTools.systemDate());
			minMargin.setUpdUsr(userString());
			minMargin.setCustom(custom);
			em.persist(minMargin);
			log.debug("Added new Minimum Margin - instrid: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new minimum margin - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(MinimumMargin minMargin) throws DataNotValidException {
		try {
			minMargin.setUpdType(updType);
			minMargin.setUpdDate(GenericTools.systemDate());
			minMargin.setUpdUsr(userString());
			em.persist(minMargin);
			log.debug("Added new Minimum Margin - instrId: "+minMargin.getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new minimum margin - instrId: "+minMargin.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void updateCurMar(MinimumMargin minMargin) throws DataNotValidException {
		try {
			MinimumMargin minMarToUpdate = findByPrimaryKey(minMargin.getInstrId());
			//minMarToUpdate.setCrMinMar(margin.getCrMargin());
			//margintoUpdate.setCrCover(margin.getCrCover());
			log.debug("Updated current margin");
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating current margin - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("resetMinMargin");
			query.setParameter(1, divisCode);
			query.setParameter(2, GenericTools.systemDate());
			query.setParameter(3, userString());
			int result = query.executeUpdate();
			log.debug(result+" minimum margins updated to disabled status - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating minimum margins to disabled status - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, Timestamp inivDate, Timestamp endvDate, Timestamp sendDate, String status, BigDecimal crMinMarM, BigDecimal anMinMar, 
		BigDecimal usrMinMar, Timestamp anDate, BigDecimal propMinMar, String propose, String approval, int rcCode, String comment, String crLog, String anLog, String propLog, String custom) throws DataNotValidException {
		
		try {
			MinimumMargin minMargin = findByPrimaryKey(instrId);
			minMargin.setInivDate(inivDate);
			minMargin.setEndvDate(endvDate);
			minMargin.setSendDate(sendDate);
			minMargin.setStatus(status);
			minMargin.setCrMinMarM(crMinMarM);
			minMargin.setAnMinMar(anMinMar);
			minMargin.setUsrMinMar(usrMinMar);
			minMargin.setAnDate(anDate);
			minMargin.setPropMinMar(propMinMar);
			minMargin.setPropose(propose);
			minMargin.setApproval(approval);
			minMargin.setRcCode(rcCode);
			minMargin.setComment(comment);
			minMargin.setCrLog(crLog);
			minMargin.setAnLog(anLog);
			minMargin.setPropLog(propLog);
			minMargin.setUpdType("U");
			minMargin.setUpdDate(GenericTools.systemDate());
			minMargin.setUpdUsr(userString());
			minMargin.setCustom(custom);
			log.debug("Updated minimum margin - instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating minimum margin - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void update(MinimumMargin minMar) throws DataNotValidException {
		MinimumMargin minMargin = findByPrimaryKey(minMar.getInstrId());
		try {
			log.debug("Updated minimum margin - instrId: "+minMargin.getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating minimum margin - instrId: "+minMargin.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void logUpdate(MinimumMargin minMar) throws DataNotValidException {
		try {
			update(minMar);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating minimum margin - instrId: "+minMar.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId) throws DataNotValidException {
		try {
			MinimumMargin minMargin = findByPrimaryKey(instrId);
			em.remove(minMargin);
			log.debug("Removed Minimum margin - instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing minimum margin - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(MinimumMargin minMar) throws DataNotValidException {
		remove(minMar.getInstrId());
	}
}
