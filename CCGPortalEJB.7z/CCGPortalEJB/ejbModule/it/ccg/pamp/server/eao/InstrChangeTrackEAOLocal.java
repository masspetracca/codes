package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.InstrChangeTrack;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface InstrChangeTrackEAOLocal {

	public abstract void store(InstrChangeTrack instrchtrack) throws DataNotValidException;

	public abstract InstrChangeTrack findByPrimaryKey(int instrId) throws DataNotValidException;

}
