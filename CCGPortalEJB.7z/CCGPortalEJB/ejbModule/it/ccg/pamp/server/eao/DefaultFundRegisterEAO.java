package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.CorporateAction;
import it.ccg.pamp.server.entities.DefaultDelta;
import it.ccg.pamp.server.entities.DefaultFundRegister;
import it.ccg.pamp.server.entities.DefaultFundRegisterPK;
import it.ccg.pamp.server.entities.stressTest.StressTestStatistic;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class DefaultFundRegisterEAO
 */
@Stateless
@SuppressWarnings("unchecked")
public class DefaultFundRegisterEAO implements  DefaultFundRegisterEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public List<DefaultFundRegister> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllDefFundReg");
    		List<DefaultFundRegister> defaultFundRegisterList = query.getResultList();
    		return defaultFundRegisterList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching default fund registers - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<DefaultFundRegister> getDefFundRegByIniVDate(Timestamp dfIniVDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDefFundRegByDfIniVDate");
    		query.setParameter("dfIniVDate", dfIniVDate);
    		List<DefaultFundRegister> defaultFundRegisterList = query.getResultList();
    		return defaultFundRegisterList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching default fund registers - iniVDate: "+dfIniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<DefaultFundRegister> getDefFundRegByDefType(String dfType) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDefFundRegByDefType");
    		query.setParameter("dfType", dfType);
    		List<DefaultFundRegister> defaultFundRegisterList = query.getResultList();
    		return defaultFundRegisterList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching default fund registers - dfType: "+dfType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DefaultFundRegister findByPrimaryKey(String dfType, Timestamp dfIniVDate) throws DataNotValidException {
		try {
			DefaultFundRegisterPK pK = new DefaultFundRegisterPK();
			
			pK.setDfType(dfType);
			pK.setDfIniVDate(dfIniVDate);
			
			DefaultFundRegister defaultFundRegister = (DefaultFundRegister) em.find(DefaultFundRegister.class,pK);
    		return defaultFundRegister;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching default fund register - dfType: "+dfType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DefaultFundRegister getLastDefFundRegByDfIniVDate(Timestamp dfInivDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getLastDefFundRegByDfIniVDate");
    		query.setParameter("dfIniVdate", dfInivDate);
    		List<DefaultFundRegister> defaultFundRegisterList = query.getResultList();
    		
    		if (defaultFundRegisterList.size()>0) {
    			return defaultFundRegisterList.get(0);
    		} else {
    			return null;
    		}
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching default fund registers - dfInivDate: "+dfInivDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public DefaultFundRegister getLastDefFundRegByDfIniVDateAndType(Timestamp dfInivDate, String type) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getLastDefFundRegByDfIniVDateAndType");
    		query.setParameter("dfIniVdate", dfInivDate);
    		query.setParameter("dfType", type);
    		List<DefaultFundRegister> defaultFundRegisterList = query.getResultList();
    		
    		if (defaultFundRegisterList.size()>0) {
    			return defaultFundRegisterList.get(0);
    		} else {
    			return null;
    		}
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching default fund registers - dfInivDate: "+dfInivDate+"; type: "+type+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	
	
	public void add(String dfType, Timestamp dfIniVDate, String comment, BigDecimal dfValue) throws DataNotValidException {
		try {
			DefaultFundRegister defaultFundRegister = new DefaultFundRegister();
			DefaultFundRegisterPK pK = new DefaultFundRegisterPK();
			
			pK.setDfType(dfType);
			pK.setDfIniVDate(dfIniVDate);
			
			defaultFundRegister.setPk(pK);
			defaultFundRegister.setComment(comment);
			defaultFundRegister.setDfValue(dfValue);
			
			defaultFundRegister.setUpdType(updType);
			defaultFundRegister.setUpdDate(GenericTools.systemDate());
			defaultFundRegister.setUpdUsr(userString());
			
			em.persist(defaultFundRegister);
			log.debug("Added new default fund register: dfType: "+dfType+"; dfIniVDate: "+dfIniVDate+"; dfValue: "+dfValue);
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new default fund register - dfType: "+dfType+"; dfIniVDate: "+dfIniVDate+"; dfValue: "+dfValue+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(DefaultFundRegister defaultFundRegister) throws DataNotValidException {
		try {
					
			em.persist(defaultFundRegister);
			log.debug("Added new default fund register: dfType: "+defaultFundRegister.getPK().getDfType()+"; dfIniVDate: "+defaultFundRegister.getPK().getDfIniVDate()+"; dfValue: "+defaultFundRegister.getDfValue());
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new default fund register - dfType: "+defaultFundRegister.getPK().getDfType()+"; dfIniVDate: "+defaultFundRegister.getPK().getDfIniVDate()+"; dfValue: "+defaultFundRegister.getDfValue()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(String dfType, Timestamp dfIniVDate, String comment, BigDecimal dfValue) throws DataNotValidException {
		try {
			
			DefaultFundRegister defaultFundRegister = this.findByPrimaryKey(dfType, dfIniVDate);
			
			defaultFundRegister.setComment(comment);
			defaultFundRegister.setDfValue(dfValue);
			
			defaultFundRegister.setUpdType("U");
			defaultFundRegister.setUpdDate(GenericTools.systemDate());
			defaultFundRegister.setUpdUsr(userString());
			
			log.debug("Updated default fund register: dfType: "+dfType+"; dfIniVDate: "+dfIniVDate+"; dfValue: "+dfValue);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating default fund registers - dfType: "+dfType+"; dfIniVDate: "+dfIniVDate+"; dfValue: "+dfValue+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(DefaultFundRegister defaultFundRegister) throws DataNotValidException {
		
		try {
			log.debug("Updated default fund register: dfType: "+defaultFundRegister.getPK().getDfType()+"; dfIniVDate: "+defaultFundRegister.getPK().getDfIniVDate()+"; dfValue: "+defaultFundRegister.getDfValue());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating default fund register - dfType: "+defaultFundRegister.getPK().getDfType()+"; dfIniVDate: "+defaultFundRegister.getPK().getDfIniVDate()+"; dfValue: "+defaultFundRegister.getDfValue()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(String dfType, Timestamp dfIniVDate) throws DataNotValidException {
		try {
			DefaultFundRegister defaultFundRegister = this.findByPrimaryKey(dfType, dfIniVDate);
			em.remove(defaultFundRegister);
			log.debug("Default fund register removed - dfType: "+dfType+"; dfIniVDate: "+dfIniVDate);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing default fund register - dfType: "+dfType+"; dfIniVDate: "+dfIniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
}
