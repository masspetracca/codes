package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ClassMargin;
import it.ccg.pamp.server.entities.ClassMarginHistory;
import it.ccg.pamp.server.entities.MarginHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface ClassMarginHistoryEAOLocal {
public ClassMarginHistory[] fetch() throws DataNotValidException;
	
	public ClassMarginHistory findByPrimaryKey(int classId, Timestamp iniVDate) throws DataNotValidException;
	
	public ClassMarginHistory[] findByClassId(int classId) throws DataNotValidException; 
	
	public ClassMarginHistory getCurrentMargin(int classId) throws DataNotValidException;
	
	public ClassMarginHistory getLastMargin(int classId) throws DataNotValidException;
	
	public List<ClassMarginHistory> getCurrentClassMarginList(int classId) throws DataNotValidException;
	
	public ClassMarginHistory[] getMarginByDateAsc(int classId) throws DataNotValidException;
	
	public ClassMarginHistory getLastSentClassMargin(int classId) throws DataNotValidException;
	
	public List<ClassMarginHistory> getClassMarHisToExport() throws DataNotValidException;
	
	public void add(int classId, Timestamp iniVDate, Timestamp endvDate, BigDecimal margin, String sent, 
		Timestamp sendDate, String approvedBy, Timestamp apprDate, BigDecimal anMargin, Timestamp anDate, int rcCode,String log) throws DataNotValidException;
		
	public void store(ClassMarginHistory classMarginHistory) throws DataNotValidException;
	
	public void store(ClassMargin classMargin) throws DataNotValidException;
	
	public void logUpdate(ClassMarginHistory marHistory) throws DataNotValidException;
	
	public void update(int classId, Timestamp iniVDate, Timestamp endvDate, BigDecimal margin, String sent, 
		Timestamp sendDate, String approvedBy, Timestamp apprDate, BigDecimal anMargin, Timestamp anDate, int rcCode,String log) throws DataNotValidException;
		
	public void update(ClassMarginHistory classMarHistory) throws DataNotValidException;
	
	public void remove(int instrId, Timestamp iniVDate) throws DataNotValidException;
	
	public int removeByClassId(int classId) throws DataNotValidException;
	
	public void remove(ClassMarginHistory classMarHistory) throws DataNotValidException;
}
