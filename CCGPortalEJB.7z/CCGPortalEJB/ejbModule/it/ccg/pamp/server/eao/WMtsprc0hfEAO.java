package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Cgcls00f;
import it.ccg.pamp.server.entities.Cpsrss1;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.Mtsmgnf90f;
import it.ccg.pamp.server.entities.WMtsprc0hf;
import it.ccg.pamp.server.entities.WMtsprc0hfPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondIntracsPriceAndDate;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MtsprcohfEAO
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class WMtsprc0hfEAO implements  WMtsprc0hfEAOLocal {

	@PersistenceContext(unitName="DWHDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<WMtsprc0hf> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllWMtsprc0hf");
    		List<WMtsprc0hf> mtsprc0hfList = query.getResultList();
    		return mtsprc0hfList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsprc0hf - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<WMtsprc0hf> getWMtsprc0hfToSync() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getWMtsprc0hfToSync");
    		List<WMtsprc0hf> mtsprc0hfList = query.getResultList();
    		return mtsprc0hfList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsprc0hf - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<WMtsprc0hf> findByIsinCode(String isinCode, long hDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDWHInflationBondsByIsinCode");
    		query.setParameter("isinCode", isinCode);
    		query.setParameter("hDate", hDate);
    		List<WMtsprc0hf> mtsprc0hfList = query.getResultList();
    		return mtsprc0hfList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsprc0hf - isinCode: "+isinCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public BondIntracsPriceAndDate findBondLastPrice(Instrument instr) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getWMtsprc0hfLastPrice");
    		query.setParameter("isinCode", instr.getIsinCode());
    		List<WMtsprc0hf> mtsprc0hfList = query.getResultList();
    		if (mtsprc0hfList.size()>0) {
    			BigDecimal closePr = mtsprc0hfList.get(0).getpPrice();
    			Timestamp priceDate = GenericTools.convertDateFromIntToTimestamp((int) mtsprc0hfList.get(0).getPk().getPDataR());
    			BondIntracsPriceAndDate bond = new BondIntracsPriceAndDate(priceDate, closePr);
    			return bond;
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsprc0hf - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public WMtsprc0hf findByPrimaryKey(String pIsinc, long dateR) throws DataNotValidException {
		
    	try {
    		WMtsprc0hfPK pK = new WMtsprc0hfPK();
    		pK.setPDataR(dateR);
    		pK.setPIsinc(pIsinc);
    		WMtsprc0hf mtsprc0hf = (WMtsprc0hf) em.find(WMtsprc0hf.class, pK);
    		
    		return mtsprc0hf;
    	
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsprc0hf - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public BondIntracsPriceAndDate findWMtsprc0hfBeforeLastDate(Instrument instr, Timestamp prDate) throws DataNotValidException {
		
    	long dateR = GenericTools.shortDateFormatAsLong(prDate);
		
		Query query = null;
    	try {
    		query = em.createNamedQuery("getWMtsprc0hfBeforeLastDate");
    		query.setParameter("isinCode", instr.getIsinCode());
    		query.setParameter("dateR", dateR);
		
    		List<WMtsprc0hf> mtsprc0hfList = query.getResultList();
    		if (mtsprc0hfList.size()>0) {
    			BigDecimal closePr = mtsprc0hfList.get(0).getpPrice();
    			Timestamp priceDate = GenericTools.convertDateFromIntToTimestamp((int) mtsprc0hfList.get(0).getPk().getPDataR()); 
    			BondIntracsPriceAndDate bond = new BondIntracsPriceAndDate(priceDate, closePr);
    			return bond;
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsprc0hf - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public WMtsprc0hf findBeforeDate(Instrument instr, Timestamp prDate) throws DataNotValidException {
		
    	long dateR = GenericTools.shortDateFormatAsLong(prDate);
		
		Query query = null;
    	try {
    		query = em.createNamedQuery("getWMtsprc0hfBeforeLastDate");
    		query.setParameter("isinCode", instr.getIsinCode());
    		query.setParameter("pCompt", instr.getClassCode());
    		query.setParameter("dateR", dateR);
		
    		List<WMtsprc0hf> mtsprc0hfList = query.getResultList();
    		if (mtsprc0hfList.size()>0) {
    			return mtsprc0hfList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsprc0hf - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public WMtsprc0hf findBeforeDate(Instrument instr) throws DataNotValidException {
		
    	Query query = null;
    	try {
    		query = em.createNamedQuery("getWMtspByIsinAndComp");
    		query.setParameter("isinCode", instr.getIsinCode());
    		query.setParameter("pCompt", instr.getClassCode());
    				
    		List<WMtsprc0hf> mtsprc0hfList = query.getResultList();
    		if (mtsprc0hfList.size()>0) {
    			return mtsprc0hfList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsprc0hf - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
}
