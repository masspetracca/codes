package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.HaircutRealClass;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;

@Local
public interface HaircutRealClassEAOLocal {

	public List<HaircutRealClass> fetch() throws DataNotValidException;
	
	public HaircutRealClass findByPrimaryKey(int inc) throws DataNotValidException;
	
	public List<HaircutRealClass> findEnabledHaircutRealClass() throws DataNotValidException;
	
	public List<HaircutRealClass> findEnabledHaircutRealClassByDivisCode(String divisCode) throws DataNotValidException;
	
	public List<HaircutRealClass> findEnabledHaircutRealClassByClassId(int classId) throws DataNotValidException;
	
	public void add(BigDecimal cap, String classDesc, int classId, String divisCode, BigDecimal floor, BigDecimal mult, String status, BigDecimal addend) throws DataNotValidException;
	
	public void store(HaircutRealClass haircutRealClass) throws DataNotValidException;
	
	public void update(int inc,BigDecimal cap, String classDesc, int classId, String divisCode, BigDecimal floor, BigDecimal mult, String status, BigDecimal addend) throws DataNotValidException;
	
	public void remove(int inc) throws DataNotValidException;		
	
	public void remove(HaircutRealClass haircutRealClass) throws DataNotValidException;
	
}
