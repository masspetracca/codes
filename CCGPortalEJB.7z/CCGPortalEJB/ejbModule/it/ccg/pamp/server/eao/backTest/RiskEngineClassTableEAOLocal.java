package it.ccg.pamp.server.eao.backTest;
import it.ccg.pamp.server.entities.backTest.RiskEngineClassTable;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface RiskEngineClassTableEAOLocal {

	public List<RiskEngineClassTable> fetch() throws DataNotValidException;
	
	public List<RiskEngineClassTable> getSTCgcls00fFutOpt(String cClass) throws DataNotValidException;
	
	public List<RiskEngineClassTable> findByCClass(String cClass) throws DataNotValidException;
	
	public List<RiskEngineClassTable> findByCofCod(String cofCod) throws DataNotValidException;
	
	public RiskEngineClassTable findByPrimaryKey(String cClass, String cpType) throws DataNotValidException;
	
}
