package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Setup;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import javax.ejb.Local;

@Local
public interface SetupEAOLocal {
	public Setup[] fetch() throws DataNotValidException;
	
	public Setup findByPrimaryKey(String divisCode) throws DataNotValidException;
	public Setup findByPrimaryKeyNoTransaction(String divisCode) throws DataNotValidException;
	
	public String marginSetup (Setup setup,MathContext mathC);
	public String groupSetup (Setup setup,MathContext mathC);
	public String setupString(String divisCode, String toPrint, boolean toWrite) throws DataNotValidException;
	
	//public String oldSetupString(String divisCode, String toPrint) throws DataNotValidException;
	
	public String getMaxDate(String[] arrDivisCode) throws DataNotValidException;
	
	public void add(String divisCode, Timestamp hisfDate,Timestamp hislDate,String hisfDaten, String hislDaten,int hisMinMar,
		int hisMinGr,String marRoundTy, BigDecimal marRoundTv, BigDecimal etfTh, BigDecimal marMinCh, String realMarGt, String varType, int volaPer, BigDecimal groupTh, String grRoundTy, BigDecimal grRoundTv, String grCorrType, int posNegeVar,
		BigDecimal grMinCh,BigDecimal strMinCh,String strRoundTy,BigDecimal strRoundTv,int strPoneVar,BigDecimal minMarPerc, int strExtrVar, int hisMinStr, BigDecimal minMinch, String minRoundTy, BigDecimal minRoundTv, String strCorrTyp, String marCutHis, String marCutSusp,BigDecimal marTiedMin) throws DataNotValidException;
	
	public void store(Setup setup) throws DataNotValidException;
	
	public void updateMarginSettings(Setup setup) throws DataNotValidException;
	
	//public void restore(int updId) throws DataNotValidException;
	
	public void update(String divisCode, Timestamp hisfDate,Timestamp hislDate,String hisfDaten, String hislDaten,int hisMinMar,
		int hisMinGr,String marRoundTy, BigDecimal marRoundTv, BigDecimal etfTh, BigDecimal marMinCh, String realMarGt, String varType, int volaPer, BigDecimal groupTh, String grRoundTy, BigDecimal grRoundTv, String grCorrType, int posNegeVar,
		BigDecimal grMinCh,BigDecimal strMinCh,String strRoundTy,BigDecimal strRoundTv,int strPoneVar, BigDecimal minMarPerc, int strExtrVar, int hisMinStr, BigDecimal minMinch, String minRoundTy, BigDecimal minRoundTv, String strCorrTyp, String marCutHis, String marCutSusp, BigDecimal marTiedMin) throws DataNotValidException;
	
	public void update(Setup setUp) throws DataNotValidException;
	
	public void copy(String oldDivisCode,String newDivisCode) throws DataNotValidException;
	
	public void remove(Setup setUp) throws DataNotValidException;
	
	public void restore(Setup oldSetup) throws DataNotValidException;
}
