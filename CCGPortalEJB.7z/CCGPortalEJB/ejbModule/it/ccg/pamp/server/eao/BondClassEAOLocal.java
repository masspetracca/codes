package it.ccg.pamp.server.eao;
import java.util.List;

import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface BondClassEAOLocal {
	
	public BondClass[] fetch() throws DataNotValidException;
	
	public BondClass findByPrimaryKey(int classId) throws DataNotValidException;
	
	public BondClass[] findEnabledBondClass() throws DataNotValidException;
	
	public List<BondClass> getBondClassInClassMarHis() throws DataNotValidException;
	
	public List<BondClass> getBondClassInTraHis() throws DataNotValidException;
	
	public List<BondClass> getBondClassInTerHis() throws DataNotValidException;	
	
	public BondClass[] findEnabledBondClassByDivisCode(String divisCode) throws DataNotValidException;
	
	public void add(String classDesc, String status, String divisCode) throws DataNotValidException;
	
	public void store(BondClass cl) throws DataNotValidException;
	
	public void update(int classId, String classDesc, String status, String divisCode) throws DataNotValidException;
	
	public void update(BondClass cl) throws DataNotValidException;
	
	public void remove(int classId) throws DataNotValidException;
	
	public void remove(BondClass cl) throws DataNotValidException;
	
}
