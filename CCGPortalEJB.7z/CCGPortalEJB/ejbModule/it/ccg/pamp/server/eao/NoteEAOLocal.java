package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Note;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;

import javax.ejb.Local;

@Local
public interface NoteEAOLocal {
	public Note[] fetch() throws DataNotValidException;
	public Note findByPrimaryKey(int noteId, String owner) throws DataNotValidException;
	public Note[] findByInstrId(int instrId) throws DataNotValidException; 
	public void add(int noteId, String owner,String content, int instrId, Timestamp date, int xPos, int yPos, int xDim, int yDim, String shared, String closed) throws DataNotValidException;
	public void store(Note note) throws DataNotValidException;
	public void update(int noteId, String owner, String content, int instrId, Timestamp date, int xPos, int yPos, int xDim, int yDim, String shared, String closed) throws DataNotValidException;
	public void update(Note note) throws DataNotValidException;
	public void remove(int noteId, String owner) throws DataNotValidException;
	public int removeByInstrId(int instrId) throws DataNotValidException;
	public void remove(Note note) throws DataNotValidException;
}
