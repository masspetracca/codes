package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.ClassMargin;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.ejb.Local;

@Local
public interface ClassMarginEAOLocal {
public ClassMargin[] fetch() throws DataNotValidException;
	
	public ClassMargin findByPrimaryKey(int classId) throws DataNotValidException;
	
	public ClassMargin[] findEnabledClassMargin() throws DataNotValidException;
	
	public ClassMargin[] findEnabledClassMarginByDivisCode(String divisCode) throws DataNotValidException;
	
	public ClassMargin[] findActiveClassMargin() throws DataNotValidException;
	
	public Integer[] getActiveDeltaForBond(int classId1, int classId2) throws DataNotValidException;
	
	public Integer[] getActivePeriodsForBond(int classId1, int classId2, int nv) throws DataNotValidException;
	
	public ClassMargin[] findProposedClassMargin() throws DataNotValidException;
	
	public boolean noMarginSubmittedForApproval(String divisCode) throws DataNotValidException;
	
	public boolean noMarginSubmittedForApproval() throws DataNotValidException;
	
	public void add(int classId, BigDecimal anCover, Timestamp anDate, Timestamp anFrstHisD, Timestamp anLastHisD, String anLog,
			 BigDecimal anMargin, int anNDaysPer, int anNodeId, int anNv, String approval, String comment, BigDecimal crCover,
			 Timestamp crFrstHisD, Timestamp crLastHisD, String crLog, BigDecimal crMargin, int crNDaysPer, int crNodeId, int crNv,
			 String custom, Timestamp endVDate, Timestamp iniVDate, BigDecimal propCover, String propLog, BigDecimal propMargin,
			 String propose, int rcCode, Timestamp sendDate, String status, String susp, BigDecimal userCov, BigDecimal userMargin, String divisCode) throws DataNotValidException;
	
	public void store(ClassMargin clMar) throws DataNotValidException;
	
	public void update(int classId, BigDecimal anCover, Timestamp anDate, Timestamp anFrstHisD, Timestamp anLastHisD, String anLog,
			 BigDecimal anMargin, int anNDaysPer, int anNodeId, int anNv, String approval, String comment, BigDecimal crCover,
			 Timestamp crFrstHisD, Timestamp crLastHisD, String crLog, BigDecimal crMargin, int crNDaysPer, int crNodeId, int crNv,
			 String custom, Timestamp endVDate, Timestamp iniVDate, BigDecimal propCover, String propLog, BigDecimal propMargin,
			 String propose, int rcCode, Timestamp sendDate, String status, String susp, BigDecimal userCov, BigDecimal userMargin, String divisCode) throws DataNotValidException;
	
	public void update(ClassMargin classMargin) throws DataNotValidException; 
	
	public void remove(int classId) throws DataNotValidException; 
	
	public int removeProposedClassMargin() throws DataNotValidException;
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException;
	
	public void remove(ClassMargin bondClass) throws DataNotValidException;
}
