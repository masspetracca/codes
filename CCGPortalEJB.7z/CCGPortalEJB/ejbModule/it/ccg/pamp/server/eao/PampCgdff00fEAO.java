package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.IntracsCgdff00f;
import it.ccg.pamp.server.entities.PampCgdff00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.MemberDfQuota;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class PampCgdff00fEAO
 */
@Stateless
public class PampCgdff00fEAO implements PampCgdff00fEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	@EJB
	private IntracsCgdff00fEAOLocal reCgdff00fEAO;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public List<PampCgdff00f> fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllPampCgdff00f");
    		List<PampCgdff00f> recordList = query.getResultList();
    		return recordList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching RE def. fund list - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void removeAll() throws DataNotValidException {
		Query query = null;

		String strSQL = "DELETE FROM CGDFF00F";
		
    	try {
    		query = em.createNativeQuery(strSQL);
    		int deleted = query.executeUpdate();
    		log.debug(deleted+" records deleted from RE def. fund list");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error deleting records from RE def. fund list - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	
	public LinkedHashMap<Integer,BigDecimal> getDfQuota(String divisCode) throws DataNotValidException {
		Query query = null;
    	
		String dfdCod = "MDF";
		
		if (divisCode.equalsIgnoreCase("O"))
				dfdCod = "MMT";
		
		try {
    		
    		String sqlString = "SELECT "+
						"DFGCMID AS GENMBRID,"+ 
						"SUM(DFQUOTA) AS DFQUOTA "+
						"FROM CGDFF00F "+
					    "WHERE (DFSTATO=' ' OR DFSTATO='H') AND DFDFCOD IN ('"+dfdCod+"') "+ 

						"GROUP BY DFGCMID";

    		System.out.println(sqlString);
			
			
    		query =  em.createNativeQuery(sqlString,MemberDfQuota.class);
    		List<MemberDfQuota> memberDfQuotaList = query.getResultList();
    		
    		LinkedHashMap<Integer, BigDecimal> dfQuotaMap = new LinkedHashMap<Integer, BigDecimal>();
    		
    		if (memberDfQuotaList.size()>0) {
    			
    			//costruisco una mappa per sveltire la ricerca successivamente e non dover fare una chiamata al DB per ciascun membro
    			for (MemberDfQuota memberDfQuota:memberDfQuotaList) {
    				
    				dfQuotaMap.put(memberDfQuota.getGenMbrId(), memberDfQuota.getDfQuota());
    			}
    			
    			return dfQuotaMap;
    			
    		} else {
    			return null;
    		}

    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching member default fund quota - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public String synchronizeTable() throws DataNotValidException {
		Query query = null;
    	
		try {
    		
    		
    		String strSync = "";
    		
			query = em.createNativeQuery("DELETE FROM CGDFF00F");
    		
			int deleted = query.executeUpdate();
    		log.debug(deleted+" records deleted");
    		
    		List<IntracsCgdff00f> reCgdff00fList = reCgdff00fEAO.fetch();
    		
    		String columnList = "DFSTATO, DFDATEC, DFORAC, DFUSERC, DFDATEM, DFORAM, DFUSERM, DFDFCOD, DFMBRID, DFGCMID, "+
    							"DFMKTID, DFOLDQU, DFQUOTA, DFDREAL, DFDELTA, DFDATINI, DFDATFIN, DFPERCE, DFDATE";
    		
    		
    		
    		String sqlInsert = "";
    		
    		int stored = 0;
    		
    		for (IntracsCgdff00f reCgdff00f:reCgdff00fList) {
    			
    			Query query2 = null;
    			
    			sqlInsert = "INSERT INTO CGDFF00F ("+columnList+") VALUES ";
    			sqlInsert += "(";
	    		sqlInsert +="'"+reCgdff00f.getDfstato()+"',"+reCgdff00f.getDfdatec()+","+
	    					reCgdff00f.getDforac()+",'"+reCgdff00f.getDfuserc()+"',"+reCgdff00f.getDfdatem()+","+reCgdff00f.getDforam()+",'"+reCgdff00f.getDfuserm()+"',"+
	    					"'"+reCgdff00f.getDfdfcod()+"',"+reCgdff00f.getDfmbrid()+","+reCgdff00f.getDfgcmid()+","+reCgdff00f.getDfmktid()+","+reCgdff00f.getDfoldqu()+","+
	    					reCgdff00f.getDfquota()+","+reCgdff00f.getDfdreal()+","+reCgdff00f.getDfdelta()+","+reCgdff00f.getDfdatini()+","+reCgdff00f.getDfdatfin()+","+
	    					reCgdff00f.getDfperce()+","+reCgdff00f.getDfdate();
	    		sqlInsert += ")";
	    		
	    		query2 = em.createNativeQuery(sqlInsert);

	    		query2.executeUpdate();
    			
	    		stored++;
	    	}
    		
    		log.debug(stored+" records stored");
    		
    		strSync = stored+" records synchronized";
		
    		return strSync;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error synchronizing records from Risk Engine Cgdff00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
}
