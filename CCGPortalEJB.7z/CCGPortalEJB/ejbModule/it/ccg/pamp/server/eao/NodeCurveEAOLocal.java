package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.NodeCurve;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface NodeCurveEAOLocal {

	public List<NodeCurve> fetch() throws DataNotValidException;
	
	public NodeCurve findByPrimaryKey(String curveName) throws DataNotValidException;
	
	public List<NodeCurve> findEnabledCurves() throws DataNotValidException;
	
	public void add(String curveName, String curveDesc, String status, String divisCode) throws DataNotValidException;
	
	public void store(NodeCurve curve) throws DataNotValidException;
	
	public void update(String curveName, String curveDesc, String status, String divisCode) throws DataNotValidException;
	
	public void remove(String curveName) throws DataNotValidException;		
	
	public void remove(NodeCurve curve) throws DataNotValidException;
	
}
