package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Cpsrss1;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface Cpsrss1EAOLocal {
	public Cpsrss1[] fetch() throws DataNotValidException;
	
	public List<Cpsrss1> findByDateAndSicType(Timestamp priceDate, String hofCod) throws DataNotValidException;
	
	public List<Cpsrss1> findByDateSymblAndCode(Timestamp priceDate,String hSymbl, String hOfcod) throws DataNotValidException;
	
	public Cpsrss1[] findFuturesBySymbl(String hSymbl, long hDate) throws DataNotValidException;
	
	public Cpsrss1[] findIndexBySymbl(String hSymbl, long hDate) throws DataNotValidException;
	
	public Cpsrss1[] findCashBySymbl(String hSymbl, long hDate) throws DataNotValidException;
	
	public Cpsrss1[] findCashFromFuturesBySymbl(String hSymbl, long hDate) throws DataNotValidException;
	
	public Cpsrss1[] findOptionsBySymbl(String hSymbl, long hDate) throws DataNotValidException;
	
	public List<Cpsrss1> findOptionsBySymblAndDateAndExpiryAndPc(String hSymbl, long hDate,int expiry, String pc) throws DataNotValidException;
	
	public List<Cpsrss1> findFuturesBySymblAndDateAndExpiry(String hSymbl, long hDate,int expiry) throws DataNotValidException;
	
	public List<Cpsrss1> findOptionsBySymblAndDate(String hSymbl, Timestamp hDate) throws DataNotValidException;
	
	public List<Cpsrss1> findFuturesBySymblAndDate(String hSymbl, Timestamp hDate) throws DataNotValidException;
	
	public Cpsrss1 findByPrimaryKey(String hSymbl, long hExpir, BigDecimal hStrik, String hPc, long hDate) throws DataNotValidException;
}
