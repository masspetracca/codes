package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Batch;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BatchEAO
 */
@Stateless
public class BatchEAO implements  BatchEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	@SuppressWarnings("unchecked")
	public Batch[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllBatch");
    		List<Batch> batch = query.getResultList();
    		Batch[] arrBatch = new Batch[batch.size()];
    		return batch.toArray(arrBatch);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Batches - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Batch[] getRunningBatchs() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getRunningBatchs");
    		query.setParameter("running", 1);
    		List<Batch> batch = query.getResultList();
    		Batch[] arrBatch = new Batch[batch.size()];
    		batch.toArray(arrBatch);
    		return arrBatch;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching running Batches - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Batch findByPrimaryKey(int batchId) throws DataNotValidException {
		try {
			Batch batch = (Batch) em.find(Batch.class,batchId);
    		return batch;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Batch - batchId: "+batchId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int batchId, String batchName, String batchCat, String divisCode, String status) throws DataNotValidException {
		try {
			Batch batch = new Batch();
			batch.setBatchId(batchId);
			batch.setBatchName(batchName);
			batch.setBatchCat(batchCat);
			batch.setStatus(status);
			em.persist(batch);
			log.debug("Added new Batch - batchId: "+batchId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Batch - batchId: "+batchId+"; batch name: "+batchName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(Batch batch) throws DataNotValidException {
		try {
			em.persist(batch);
			log.debug("Added new Batch - batchId: "+batch.getBatchId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Batch - batchId: "+batch.getBatchId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int batchId, String batchName, String batchCat, String divisCode, String status) throws DataNotValidException {
		try {
			Batch batch = findByPrimaryKey(batchId);
			batch.setBatchName(batchName);
			batch.setBatchCat(batchCat);
			batch.setStatus(status);
			log.debug("Batch updated - batchId: "+batchId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Batch - batchId: "+batchId+"; batch name: "+batchName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void updateToRunning(int batchId,int running) throws DataNotValidException {
		try {
			Batch batch = findByPrimaryKey(batchId);
			batch.setRunning(running);
			log.debug("Batch updated to running - batchId: "+batchId+"; running: "+running);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Batch to running - batchId: "+batchId+"; running: "+running+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int batchId) throws DataNotValidException {
		try {
			Batch batch = findByPrimaryKey(batchId);
			em.remove(batch);
			log.debug("Batch removed - batchId: "+batchId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Batch - batchId: "+batchId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(Batch btch) throws DataNotValidException {
		remove(btch.getBatchId());
	}
}
