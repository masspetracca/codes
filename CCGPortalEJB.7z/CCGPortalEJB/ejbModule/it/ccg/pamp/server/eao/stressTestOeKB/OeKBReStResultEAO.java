package it.ccg.pamp.server.eao.stressTestOeKB;

import it.ccg.pamp.server.entities.stressTestOeKB.OeKBReStResult;
import it.ccg.pamp.server.entities.stressTestOeKB.OeKBReStResultPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.OeKBReMembers;

import java.math.BigDecimal;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class CalendarEAO
 */
@Stateless
@SuppressWarnings("unchecked")
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class OeKBReStResultEAO implements OeKBReStResultEAOLocal {
	
	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}

    
    
    public List<OeKBReStResult> fetch() throws DataNotValidException {
    	
    	try {
    	
	    	Query query = null;							
	    	query = em.createNamedQuery("getAllOeKBReStResult");
	    	List<OeKBReStResult> reStResultList = query.getResultList();
	    	return reStResultList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test results - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
	    }
    }
   
	public OeKBReStResult findByPrimaryKey(String pFolioId, BigDecimal uMbr) throws DataNotValidException {
		try {
			OeKBReStResultPK pK = new OeKBReStResultPK();
			
			pK.setPfolioId(pFolioId);
			pK.setUMbr(uMbr);
			
			OeKBReStResult OeKBReStResult = em.find(OeKBReStResult.class, pK);
	    	return OeKBReStResult;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test result - pFolioId: "+pFolioId+"; uMbr: "+uMbr+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
	    }
    }
	
	public List<OeKBReMembers> findFromLastStressTestId(int lastStressTestId, String scenario) throws DataNotValidException {
		
		Query query = null;
		
		try {
			
			String sql = "SELECT MREQ.UTRNID, MREQ.DATAMRG, MREQ.UREQ, MREQ.PFOLIOID, MREQ.UMBR, "+
						 "MREQ.UGCM, MREQ.UACCT, MREQ.USUBAC, MRG.T1SUBDES AS SUBACCDESC, MREQ.USGRP, MREQ.TIPO, MREQ.STID, "+
						 "MBR.MFMNAM AS MBRDESC, MBR2.MFMNAM AS UGCMBRDESC "+
						 "FROM CGMREQS00F MREQ "+
						 "INNER JOIN CGMBR00F MBR " +
						 "ON MREQ.UMBR = MBR.MEXMEM "+
						 "INNER JOIN CGMBR00F MBR2 "+
						 "ON MREQ.UGCM = MBR2.MEXMEM "+
						 "LEFT JOIN MRGSUBT1F MRG " +
						 "ON MREQ.UMBR = MRG.T1MBRCOD AND MRG.T1ACCOUNT = 'H' AND MREQ.USUBAC = MRG.T1SUBACT "+
						 "WHERE TIPO = '"+scenario+"' AND STID > '"+lastStressTestId+"' AND UREQ > 0 AND MREQ.UACCT = 'F' "+
						 "UNION "+
						 "SELECT MREQ.UTRNID, MREQ.DATAMRG, MREQ.UREQ, MREQ.PFOLIOID, MREQ.UMBR, "+
						 "MREQ.UGCM, MREQ.UACCT, MREQ.USUBAC, MRG.T1SUBDES AS SUBACCDESC, MREQ.USGRP, MREQ.TIPO, MREQ.STID, "+
						 "MBR.MFMNAM AS MBRDESC, MBR2.MFMNAM AS UGCMBRDESC "+
						 "FROM CGMREQS00F MREQ "+
						 "INNER JOIN CGMBR00F MBR " +
						 "ON MREQ.UMBR = MBR.MEXMEM "+
						 "INNER JOIN CGMBR00F MBR2 "+
						 "ON MREQ.UGCM = MBR2.MEXMEM "+
						 "LEFT JOIN MRGSUBT1F MRG " +
						 "ON MREQ.UMBR = MRG.T1MBRCOD AND MREQ.UACCT = MRG.T1ACCOUNT AND MREQ.USUBAC = MRG.T1SUBACT "+
						 "WHERE TIPO = '"+scenario+"' AND STID > '"+lastStressTestId+"' AND UREQ > 0 AND MREQ.UACCT = 'C' "+
						 "ORDER BY STID";
			
			query = em.createNativeQuery(sql, OeKBReMembers.class);
			
			List<OeKBReMembers> reStResultList = query.getResultList();
	    	
	    	return reStResultList;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test result on risk engine - stId: "+lastStressTestId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
	    }
    }
    

}
