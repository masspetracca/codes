package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.SimulationMargin;
import it.ccg.pamp.server.entities.SimulationMarginPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MarginEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class SimulationMarginEAO implements  SimulationMarginEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public SimulationMargin[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSimMargin");
    		query.setParameter("updUsr", userString());
    		List<SimulationMargin> simMargin = query.getResultList();
    		SimulationMargin[] arrSimMargin = new SimulationMargin[simMargin.size()];
    		return simMargin.toArray(arrSimMargin);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Simulation margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationMargin findByPrimaryKey(int instrId) throws DataNotValidException {
		try {
			SimulationMarginPK pK = new SimulationMarginPK();
			pK.setInstrId(instrId);
			pK.setUpdUsr(userString());
			SimulationMargin simMargin = (SimulationMargin) em.find(SimulationMargin.class,pK);
    		return simMargin;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Simulation Margin - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, BigDecimal margin, BigDecimal cover, int nDaysPer, int nV, String varType) throws DataNotValidException {
		SimulationMargin simMargin = new SimulationMargin();
		SimulationMarginPK pK = new SimulationMarginPK();

		try {
			pK.setInstrId(instrId);
			pK.setUpdUsr(userString());
			simMargin.setPk(pK);
			simMargin.setMargin(margin);
			simMargin.setCover(cover);
			simMargin.setNDaysPer(nDaysPer);
			simMargin.setNv(nV);
			simMargin.setVarType(varType);
			simMargin.setUpdType(updType);
			simMargin.setUpdDate(GenericTools.systemDate());
			em.persist(simMargin);
			log.debug("Added new Simulation Margin - instrid: "+instrId+"; user: "+userString());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Simulation Margin - instrId: "+instrId+"; user: "+userString()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(SimulationMargin simMargin) throws DataNotValidException {
		try {
			SimulationMarginPK pK = new SimulationMarginPK();
			pK.setInstrId(simMargin.getPk().getInstrId());
			pK.setUpdUsr(userString());
			simMargin.setPk(pK);
			simMargin.setUpdType(updType);
			simMargin.setUpdDate(GenericTools.systemDate());
			em.persist(simMargin);
			log.debug("Added new Simulation Margin - instrId: "+simMargin.getPk().getInstrId()+"; user: "+simMargin.getPk().getUpdUsr());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Simulation Margin - instrId: "+simMargin.getPk().getInstrId()+"; user: "+simMargin.getPk().getUpdUsr()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void updateMargin(SimulationMargin simMargin) throws DataNotValidException {
		try {
			SimulationMargin margintoUpdate = findByPrimaryKey(simMargin.getPk().getInstrId());
			margintoUpdate.setMargin(simMargin.getMargin());
			margintoUpdate.setCover(simMargin.getCover());
			log.debug("Updated current Simulation Margin");
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating current Simulation Margin - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("updateSimMarStatusToDisabled");
			query.setParameter("divisCode", divisCode);
			query.setParameter("updUsr", userString());
			int result = query.executeUpdate();
			log.debug(result+" Simulation Margin updated to disabled status - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Simulation Margin to disabled status - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, BigDecimal margin, BigDecimal cover, int nDaysPer, int nV, String varType) throws DataNotValidException {
		try {
			SimulationMargin simMargin = findByPrimaryKey(instrId);
			simMargin.setMargin(margin);
			simMargin.setCover(cover);
			simMargin.setNDaysPer(nDaysPer);
			simMargin.setNv(nV);
			simMargin.setVarType(varType);
			simMargin.setUpdType("U");
			simMargin.setUpdDate(GenericTools.systemDate());
			log.debug("Updated Simulation Margin - instrId: "+simMargin.getPk().getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Simulation Margin - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(SimulationMargin simMar) throws DataNotValidException {
		SimulationMargin simMargin = findByPrimaryKey(simMar.getPk().getInstrId());
		try {
			simMargin.setUpdType("U");
			simMargin.setUpdDate(GenericTools.systemDate());
			log.debug("Updated Simulation Margin - instrId: "+simMargin.getPk().getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Simulation Margin - instrId: "+simMargin.getPk().getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId) throws DataNotValidException {
		try {
			SimulationMargin simMargin = findByPrimaryKey(instrId);
			em.remove(simMargin);
			log.debug("Removed Simulation Margin - instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Simulation Margin - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public void remove(SimulationMargin simMargin) throws DataNotValidException {
		remove(simMargin.getPk().getInstrId());
	}
	
}

