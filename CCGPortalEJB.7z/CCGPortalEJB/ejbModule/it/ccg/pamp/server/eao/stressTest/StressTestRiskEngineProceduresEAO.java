package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Timestamp;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.ibm.as400.access.AS400;
import com.ibm.as400.access.AS400Message;
import com.ibm.as400.access.AS400SecurityException;
import com.ibm.as400.access.AS400Text;
import com.ibm.as400.access.ErrorCompletingRequestException;
import com.ibm.as400.access.ObjectDoesNotExistException;
import com.ibm.as400.access.ProgramCall;
import com.ibm.as400.access.ProgramParameter;
import com.ibm.as400.access.QSYSObjectPathName;

/**
 * Session Bean implementation class StressTestProcedureEAO
 */
@Stateless
public class StressTestRiskEngineProceduresEAO implements StressTestRiskEngineProceduresEAOLocal {
	
	private ProgramParameter parm1, parm2; 

	@PersistenceContext(unitName="STDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public void launchGiornoZero() throws DataNotValidException {
    
    	Query query = null;
    	try {
    		String sql = "CALL STRSTARTC0('010','010')";
    		
    		query =  em.createNativeQuery(sql);
	    	query.executeUpdate();

	    	//log.info("class table cloned");
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error cloning class table - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
    	
    }
	
	public void startReStressTestProcedure(Timestamp stressTestDate, int stId, String scenario) throws DataNotValidException {
	    
		//String stDate = GenericTools.shortDateFormat(stressTestDate).replaceAll("-", "");
		
		String stDate = GenericTools.shortSysDateFormat().replaceAll("-", "");
		
		String id = Integer.toString(stId);
		
    	Query query = null;
    	try {
    		//String sql = "DELETE FROM CGMGNPGH1L WHERE HGTYPE = 'IDNET' AND HGDATE = '20120301' ";//('"+stDate+"','"+id+"')";
    		
    		//query =  em.createNativeQuery(sql);
    		String sql = "CALL NCEMGSC000 ('"+stDate+"','"+id+"','"+scenario+"')";
    		
    		query =  em.createNativeQuery(sql);
	    	query.executeUpdate();

	    	log.info("Stress test procedure on Risk Engine started");
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error starting tress test procedure on Risk Engine - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
    	
    }


	@Override
	public String commandCallAs400(int processId, String divisCode) throws DataNotValidException {
		
		AS400 as400 = new AS400("10.0.40.10", "PAMPUSE", "ndapc1pfc");
//		ProfileTokenCredential ptc = new ProfileTokenCredential();
//		try {
//			ptc.setTokenExtended("PAMPUSE", "ndapc1pfc");
//			as400.setProfileToken(ptc);
//		} catch (PropertyVetoException e2) {
//			e2.printStackTrace();
//		} catch (AS400SecurityException e2) {
//			e2.printStackTrace();
//		}
		
		String[] paramArr = null;
		String prcName = "";
		
		
		switch (processId) {
			case 1:
				prcName = "Giorno Zero (Azzera Garanzie)";
				if (divisCode.equalsIgnoreCase("E")) {
					paramArr = new String[] {"015"};
				} else if (divisCode.equalsIgnoreCase("O")) {
					paramArr = new String[] {"050"};
				}
				break;
			case 2:
				prcName = "Giorno Uno (Prima Fase)";
				if (divisCode.equalsIgnoreCase("E")) {
					paramArr = new String[] {"020"};
				} else if (divisCode.equalsIgnoreCase("O")) {
					paramArr = new String[] {"060"};
				}
				break;	
			case 3:
				prcName = "Giorno Uno (Seconda Fase)";
				if (divisCode.equalsIgnoreCase("E")) {
					paramArr = new String[] {"040"};
				} else if (divisCode.equalsIgnoreCase("O")) {
					paramArr = new String[] {"070"};
				}
				break;
		}
		log.debug("procedure started: "+prcName);
		String msgListString = "";
		
		for (String param:paramArr) {
		
			AS400Text parmConverter = new AS400Text(3, as400);
			byte[] parm1Bytes = parmConverter.toBytes(param);
			byte[] parm2Bytes = parmConverter.toBytes(param);
			
			parm1 = new ProgramParameter(parm1Bytes);
			parm2 = new ProgramParameter(parm2Bytes);
			
			ProgramParameter[] parameterList = new ProgramParameter[2];
			parameterList[0] = parm1;
			parameterList[1] = parm2;
			
			ProgramCall cc = new ProgramCall(as400);
			
			QSYSObjectPathName programName = new QSYSObjectPathName("I400OBJST", "STRSTARTC0", "PGM");
			
			String programNamePath = programName.getPath();
			
			try {
				//LANCIO PROCEDURA
				cc.run(programNamePath, parameterList);
				
				AS400Message[] msgList = cc.getMessageList();
				
				for (AS400Message msg:msgList) {
					msgListString = msg.getText();
				}
				
			} catch (AS400SecurityException e) {
				e.printStackTrace();
			} catch (ErrorCompletingRequestException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ObjectDoesNotExistException e) {
				e.printStackTrace();
			} catch (PropertyVetoException e) {
				e.printStackTrace();
			}
			finally {
				as400.disconnectAllServices();
			}
		}	
		
		return msgListString;
	}

	
}
