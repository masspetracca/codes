package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Tfpgrp;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TfpgrpEAO
 */
@Stateless
public class TfpgrpEAO implements  TfpgrpEAOLocal {

	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
    
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public List<Tfpgrp> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllTfpgrp");
    		List<Tfpgrp> tfpgrpList = query.getResultList();
    		return tfpgrpList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Risk Engine group table - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Tfpgrp findByPrimaryKey(String gGroup) throws DataNotValidException {
		try {
			Tfpgrp tfpgrp = (Tfpgrp) em.find(Tfpgrp.class,gGroup);
    		return tfpgrp;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching group from Risk Engine table - group: "+gGroup+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(Tfpgrp newIntracsGrPr) throws DataNotValidException {
		try {
			em.persist(newIntracsGrPr);
			//logging.debug("Added new Group History - groupId: "+groupHistory.getPk().getGrId()+"; iniVDate: "+groupHistory.getPk().getIniVdate());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding group from Risk Engine table - group: "+newIntracsGrPr.getGGroup()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
}
