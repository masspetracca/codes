package it.ccg.pamp.server.eao.backTest;

import it.ccg.pamp.server.entities.backTest.BackTestSetup;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BackTestSetupEAO
 */
@Stateless
public class BackTestSetupEAO implements BackTestSetupEAOLocal {

	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	public List<BackTestSetup> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllBackTestSetups");
    		List<BackTestSetup> backTestSetupList = query.getResultList();
    		return backTestSetupList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test settings - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BackTestSetup fetchBackTestWithMaxDate(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("fetchBackTestWithMaxDate");
    		query.setParameter("divisCode",divisCode);
    		List<BackTestSetup> backTestSetupList = query.getResultList();
    		if (backTestSetupList.size()>0) {
    			return backTestSetupList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test settings - division: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<BackTestSetup> fetchBackTestSetupsByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("fetchBackTestSetupsByDivisCode");
    		query.setParameter("divisCode",divisCode);
    		List<BackTestSetup> backTestSetupList = query.getResultList();
    		return backTestSetupList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test settings - division: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BackTestSetup findByPrimaryKey(String instrType) throws DataNotValidException {
		try {
			BackTestSetup backTestSetup = (BackTestSetup) em.find(BackTestSetup.class,instrType);
    		return backTestSetup;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test settings - instrType: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
/*	public void add(String instrType, String disabVar, String divisCode, Timestamp histUpdDay, String histUpdLst, String nvVec, int period) throws DataNotValidException {
		
		try {
			BackTestSetup backTestSetup = new BackTestSetup();
			
			backTestSetup.setInstrType(instrType);
			backTestSetup.setDisabVar(disabVar);
			backTestSetup.setDivisCode(divisCode);
			backTestSetup.setHistUpdDay(histUpdDay);
			backTestSetup.setHistUpdLst(histUpdLst);
			backTestSetup.setNvVec(nvVec);
			backTestSetup.setPeriod(period);
			
			backTestSetup.setUpdType(updType);
			backTestSetup.setUpdDate(GenericTools.systemDate());
			backTestSetup.setUpdUsr(userString());
			
			em.persist(backTestSetup);
			userLog.debug("Added new stress test setting - instrType: "+instrType);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test setting -  instrType: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
	
	public void store(BackTestSetup backTestSetup) throws DataNotValidException {
		
		try {
			backTestSetup.setUpdType(updType);
			backTestSetup.setUpdDate(GenericTools.systemDate());
			backTestSetup.setUpdUsr(userString());
			em.persist(backTestSetup);
			userLog.debug("Added new stress test setting - instrType: "+backTestSetup.getInstrType());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test setting -  instrType: "+backTestSetup.getInstrType()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public void update(String instrType, String disabVar, String divisCode, Timestamp histUpdDay, String histUpdLst, String nvVec, int period) throws DataNotValidException {
		
		try {
			BackTestSetup backTestSetup = this.findByPrimaryKey(instrType);
			
			backTestSetup.setInstrType(instrType);
			backTestSetup.setDisabVar(disabVar);
			backTestSetup.setDivisCode(divisCode);
			backTestSetup.setHistUpdDay(histUpdDay);
			backTestSetup.setHistUpdLst(histUpdLst);
			backTestSetup.setNvVec(nvVec);
			backTestSetup.setPeriod(period);
			
			backTestSetup.setUpdType("U");
			backTestSetup.setUpdDate(GenericTools.systemDate());
			backTestSetup.setUpdUsr(userString());
			backTestSetup.setDivisCode(divisCode);
			
			userLog.debug("Updated stress test setting - instrType: "+instrType);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stress test setting - instrType: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
	public void update(BackTestSetup backTestSetup) throws DataNotValidException {
		
		try {
			userLog.debug("Updated stress test setting - instrType: "+backTestSetup.getInstrType());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stress test setting - instrType: "+backTestSetup.getInstrType()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(String instrType) throws DataNotValidException {
		try {
			BackTestSetup backTestSetup = this.findByPrimaryKey(instrType);
			em.remove(backTestSetup);
			userLog.debug("Stress test setting removed - divisCode: "+instrType);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test setting - divisCode: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(BackTestSetup backTestSetup) throws DataNotValidException {
		this.remove(backTestSetup.getInstrType());
	}
}
