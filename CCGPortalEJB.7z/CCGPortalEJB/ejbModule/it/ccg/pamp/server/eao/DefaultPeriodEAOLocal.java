package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.DefaultPeriod;

import javax.ejb.Local;

@Local
public interface DefaultPeriodEAOLocal {
	public DefaultPeriod[] fetch();
	public Integer[] getEnabledPeriods(String instrType);
	public DefaultPeriod[] findByInstrType(String instrType);
	public DefaultPeriod findByPrimaryKey(String instrType, int nDaysPer);
}
