package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.BondModifiedDuration;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondClassMarginsAndMaxDurations;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BondModifiedDurationEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class BondModifiedDurationEAO implements  BondModifiedDurationEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");

	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public BondModifiedDuration[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllBondModDur");
    		List<BondModifiedDuration> bondModifiedDuration = query.getResultList();
    		BondModifiedDuration[] arrBondModifiedDuration = new BondModifiedDuration[bondModifiedDuration.size()];
    		return bondModifiedDuration.toArray(arrBondModifiedDuration);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Bond Modified Duration - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BondModifiedDuration findByPrimaryKey(int instrId) throws DataNotValidException {
		try {
			BondModifiedDuration bondModifiedDuration = (BondModifiedDuration) em.find(BondModifiedDuration.class,instrId);
    		return bondModifiedDuration;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Bond Modified Duration - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<BondClassMarginsAndMaxDurations> getClassMarginsAndMaxDurationsList() throws DataNotValidException {
		  
		Query query = null;
    	try {
    		String sqlString = "SELECT M.CLASSID, MD.MODDUR AS MAXMODDUR, M.USERMARGIN, M.WORKMAR AS WORKINGMARGIN FROM PMPTMODDUR MD ";
    		sqlString += "INNER JOIN PMPTINSTR I ON I.INSTRID  = MD.INSTRID AND "; 
    		sqlString += "(SELECT COUNT(*) FROM PMPTMODDUR MD2 INNER  JOIN PMPTINSTR I2 ON I2.INSTRID  = MD2.INSTRID ";   
    		sqlString += "WHERE MD2.MODDUR > MD.MODDUR AND I2.BNDCLASSID = I.BNDCLASSID) = 0 ";
    		sqlString += "INNER JOIN PMPVCLMAR M ON M.CLASSID = I.BNDCLASSID ";
    		sqlString += "ORDER BY MAXMODDUR DESC";
    		
    		query =  em.createNativeQuery(sqlString,BondClassMarginsAndMaxDurations.class);
    		List<BondClassMarginsAndMaxDurations> classMarginsAndMaxDurationsList = query.getResultList();
    		
    		return classMarginsAndMaxDurationsList;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond class margins and related max durations - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public BigDecimal getDuration(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBondModDurByInstrId");
    		query.setParameter("instrId", instrId);
    		BigDecimal modDur = (BigDecimal) query.getSingleResult();
    		return modDur;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching duration field - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void setDuration(int instrId, BigDecimal modDur) throws DataNotValidException {
		try {
			BondModifiedDuration bondModifiedDuration = findByPrimaryKey(instrId);
			if (bondModifiedDuration!=null) {
				bondModifiedDuration.setModDur(modDur);
				bondModifiedDuration.setUpdDate(GenericTools.systemDate());
				bondModifiedDuration.setUpdType("U");
				bondModifiedDuration.setUpdUsr(userString());
				log.debug("Updated duration field - instrId: "+instrId);
			} else {
				bondModifiedDuration = new BondModifiedDuration();
				bondModifiedDuration.setInstrId(instrId);
				bondModifiedDuration.setModDur(modDur);
				store(bondModifiedDuration);
			}
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error setting duration field - instrId: "+instrId+"; modDur: "+modDur+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, BigDecimal modDur) throws DataNotValidException {
		try {
			BondModifiedDuration bondModifiedDuration = new BondModifiedDuration();
			bondModifiedDuration.setInstrId(instrId);
			bondModifiedDuration.setModDur(modDur);
			bondModifiedDuration.setUpdDate(GenericTools.systemDate());
			bondModifiedDuration.setUpdType("C");
			bondModifiedDuration.setUpdUsr(userString());
			em.persist(bondModifiedDuration);
			log.debug("Added new Bond Modified Duration - instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Bond Modified Duration - instrId: "+instrId+"; modDur: "+modDur+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(BondModifiedDuration bondModifiedDuration) throws DataNotValidException {
		try {
			bondModifiedDuration.setUpdDate(GenericTools.systemDate());
			bondModifiedDuration.setUpdType("C");
			bondModifiedDuration.setUpdUsr(userString());
			em.persist(bondModifiedDuration);
			log.debug("Added new Bond Modified Duration - instrId: "+bondModifiedDuration.getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Bond Modified Duration - instrId: "+bondModifiedDuration.getInstrId()+"; modDur: "+bondModifiedDuration.getModDur()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	public void remove(int instrId) throws DataNotValidException {
		try {
			BondModifiedDuration bondModifiedDuration = findByPrimaryKey(instrId);
			em.remove(bondModifiedDuration);
			log.debug("Bond Modified Duration removed - instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Bond Modified Duration - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void removeByClassId(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("deleteBondModDurByClassId");
    		query.setParameter("classId", classId);
			int removed = query.executeUpdate();
			log.debug(removed+" bond modified durations removed - classId: "+classId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing bond modified durations - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(BondModifiedDuration bondModifiedDuration) throws DataNotValidException {
		remove(bondModifiedDuration.getInstrId());
	}
}