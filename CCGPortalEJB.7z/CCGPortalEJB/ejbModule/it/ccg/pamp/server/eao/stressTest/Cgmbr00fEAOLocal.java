package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestCgmbr00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.MemberToSync;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Vector;

import javax.ejb.Local;

@Local
public interface Cgmbr00fEAOLocal {
	
	public List<StressTestCgmbr00f> fetch() throws DataNotValidException;
	
	public List<MemberToSync> getMemberToSync(String divisCode) throws DataNotValidException;
	
	public LinkedHashMap<Integer,Vector<BigDecimal>> getMarginComposition() throws DataNotValidException;
	
}
