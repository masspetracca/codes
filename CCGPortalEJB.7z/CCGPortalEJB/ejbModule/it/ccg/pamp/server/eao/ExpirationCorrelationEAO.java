package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ExpirationCorrelation;
import it.ccg.pamp.server.entities.ExpirationCorrelationPK;
import it.ccg.pamp.server.entities.Setup;
import it.ccg.pamp.server.entities.StraddleStatistic;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.ExpCorrGroupedBy;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.GroupStatisticGroupedBy;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ExpirationCorrelationEAO
 */
@Stateless
public class ExpirationCorrelationEAO implements  ExpirationCorrelationEAOLocal {
	@EJB private SetupEAOLocal setupEAO;
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	
	public ExpirationCorrelation[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllExpCorrel");
    		List<ExpirationCorrelation> expirationCorrelation = query.getResultList();
    		ExpirationCorrelation[] arrExpirationCorrelation = new ExpirationCorrelation[expirationCorrelation.size()];
    		return expirationCorrelation.toArray(arrExpirationCorrelation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Expiration Correlations - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<String> printExpCorr(int instrId, String corrType) throws DataNotValidException {
		
		List<ExpirationCorrelation> expCorrList = this.findByInstrIdAndCorrType(instrId, corrType);//findByInstrIdAndNvAndNDaysPer(instrId, nv, nDaysPer);
		
		String expCorrLog = "";
		
		List<String> expCorrListForLog = new ArrayList<String>();
		
		MathContext mc = new MathContext(4);
		
		int counter = 0;
		
		for (ExpirationCorrelation expCorr:expCorrList) {
			if (counter<10) {
				expCorrLog = "";
				
				expCorrLog += "Prog. Exp. 1: "+expCorr.getPk().getProgExp1()+"; ";
				expCorrLog += "Prog. Exp. 2: "+expCorr.getPk().getProgExp2()+"; ";
				expCorrLog += "Period (days): "+expCorr.getPk().getNDaysPer()+"; ";
				expCorrLog += "HP: "+expCorr.getPk().getNv()+"; ";
				expCorrLog += "Var. type: "+expCorr.getPk().getVarType()+"; ";
				expCorrLog += "Correlation: "+expCorr.getCorrel().round(mc)+"; ";
				expCorrLog += "Pearson: "+expCorr.getPearson().round(mc)+"; ";
				expCorrLog += "Div. undiv: "+expCorr.getDivUnDiv().round(mc)+"; ";
				expCorrLog += "Historical days: "+expCorr.getHistDays();
				
				expCorrListForLog.add(expCorrLog);
				counter++;
			} else {
				break;
			}
			
		}
		return expCorrListForLog;
	}
	
	public List<ExpirationCorrelation> findByInstrIdAndNvAndNDaysPer(int instrId, int nv, int nDaysPer) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getExpCorrByInstrIdAndNvAndNDaysPer");
    		query.setParameter("instrId", instrId);
    		query.setParameter("nv", nv);
    		query.setParameter("nDaysPer", nDaysPer);
    		List<ExpirationCorrelation> expirationCorrelationList = query.getResultList();
    		
    		return expirationCorrelationList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Expiration Correlations - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ExpirationCorrelation> findByInstrIdAndCorrType(int instrId, String corrType) throws DataNotValidException {
		Query query = null;
    	String queryName = "getExpCorrByInstrIdOrderByCorrel";
    	if (corrType.equalsIgnoreCase("P")) {
    		queryName = "getExpCorrByInstrIdOrderByPearson";
    	} else if (corrType.equalsIgnoreCase("D")) {
    		queryName = "getExpCorrByInstrIdOrderByDivUnDiv";
    	}
		
    	try {
    		query = em.createNamedQuery(queryName);
    		query.setParameter("instrId", instrId);
    		List<ExpirationCorrelation> expirationCorrelationList = query.getResultList();
    		
    		return expirationCorrelationList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Expiration Correlations - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ExpirationCorrelation findByPrimaryKey(int instrId, int progExp1, int progExp2, int nv, int nDaysPer, String varType, int mode) throws DataNotValidException {
		try {
			ExpirationCorrelationPK pK = new ExpirationCorrelationPK();
			pK.setInstrId(instrId);
			pK.setProgExp1(progExp1);
			pK.setProgExp2(progExp2);
			pK.setNv(nv);
			pK.setNDaysPer(nDaysPer);
			pK.setVarType(varType);
			pK.setMode(mode);
			ExpirationCorrelation expirationCorrelation = (ExpirationCorrelation) em.find(ExpirationCorrelation.class,pK);
    		return expirationCorrelation;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Expiration Correlations - instrId: "+instrId+"; progExp1:"+progExp1+"; progExp2: "+progExp2+"; nv: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ExpirationCorrelation[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getExpCorByInstrId");
    		query.setParameter("instrId", instrId);
    		List<ExpirationCorrelation> expirationCorrelation = query.getResultList();
    		ExpirationCorrelation[] arrExpirationCorrelation = new ExpirationCorrelation[expirationCorrelation.size()];
    		return expirationCorrelation.toArray(arrExpirationCorrelation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Expiration Correlations - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ExpCorrGroupedBy getEnabledMinCorrel(int instrId, String corrType) throws DataNotValidException  {
		Query query = null;
    	try {
    		if (corrType.equals("C")) {
    			query = em.createNamedQuery("getExpMinCorrel");
    		} else if (corrType.equals("P")) {
    			query = em.createNamedQuery("getExpMinPearson");
    		} else if (corrType.equals("D")) {
    			query = em.createNamedQuery("getExpMinDivundiv");
    		}
    		Setup setup = setupEAO.findByPrimaryKey("E");
    		
    		query.setParameter("instrId", instrId);
    		//query.setParameter("histDays", setup.getHisMinGr());
    		List<ExpCorrGroupedBy> expCorr = query.getResultList();
    		//ExpCorrGroupedBy[] arrExpCorr = new ExpCorrGroupedBy[expCorr.size()];
    		//return expCorr.toArray(arrExpCorr);
    		if (expCorr.size()>0) {
    			return expCorr.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled minimum correlation - correlationType: "+corrType+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, int progExp1, int progExp2, int nv, int nDaysPer, String varType, int mode, BigDecimal correl, BigDecimal pearson, BigDecimal divUnDiv, int histDays,  String status) throws DataNotValidException {
		try {
			ExpirationCorrelation expirationCorrelation = new ExpirationCorrelation();
			ExpirationCorrelationPK pK = new ExpirationCorrelationPK();
			pK.setInstrId(instrId);
			pK.setProgExp1(progExp1);
			pK.setProgExp2(progExp2);
			pK.setNv(nv);
			pK.setNDaysPer(nDaysPer);
			pK.setVarType(varType);
			pK.setMode(mode);
			expirationCorrelation.setPk(pK);
			expirationCorrelation.setCorrel(correl);
			expirationCorrelation.setPearson(pearson);
			expirationCorrelation.setDivundiv(divUnDiv);
			expirationCorrelation.setHistDays(histDays);
			expirationCorrelation.setStatus(status);
			expirationCorrelation.setUpdDate(GenericTools.systemDate());
			expirationCorrelation.setUpdType(updType);
			expirationCorrelation.setUpdUsr(userString());
			em.persist(expirationCorrelation);
			log.debug("Added new Expiration Correlation - instrId: "+instrId+"; progExp1:"+progExp1+"; progExp2: "+progExp2+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+"; correl: "+correl);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Expiration Correlation - instrId: "+instrId+"; progExp1:"+progExp1+"; progExp: "+progExp2+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(ExpirationCorrelation expirationCorrelation) throws DataNotValidException {
		try {
			expirationCorrelation.setUpdDate(GenericTools.systemDate());
			expirationCorrelation.setUpdType(updType);
			expirationCorrelation.setUpdUsr(userString());
			em.persist(expirationCorrelation);
			log.debug("Added new Expiration Correlation - instrId: "+expirationCorrelation.getPk().getInstrId()+"; progExp1:"+expirationCorrelation.getPk().getProgExp1()+"; progExp2: "+expirationCorrelation.getPk().getProgExp2()+"; holding period: "+expirationCorrelation.getPk().getNv()+"; nDaysPer: "+expirationCorrelation.getPk().getNDaysPer()+"; varType: "+expirationCorrelation.getPk().getVarType()+"; mode: "+expirationCorrelation.getPk().getMode()+"; correl: "+expirationCorrelation.getCorrel());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Expiration Correlation - instrId: "+expirationCorrelation.getPk().getInstrId()+"; progExp1:"+expirationCorrelation.getPk().getProgExp1()+"; progExp2: "+expirationCorrelation.getPk().getProgExp2()+"; holding period: "+expirationCorrelation.getPk().getNv()+"; nDaysPer: "+expirationCorrelation.getPk().getNDaysPer()+"; varType: "+expirationCorrelation.getPk().getVarType()+"; mode: "+expirationCorrelation.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, int progExp1, int progExp2, int nv, int nDaysPer, String varType, int mode, BigDecimal correl, BigDecimal pearson, BigDecimal divUnDiv, int histDays,  String status) throws DataNotValidException {
		try {
			ExpirationCorrelation expirationCorrelation = findByPrimaryKey(instrId, progExp1, progExp2, nv, nDaysPer, varType, mode);
			expirationCorrelation.setCorrel(correl);
			expirationCorrelation.setPearson(pearson);
			expirationCorrelation.setDivundiv(divUnDiv);
			expirationCorrelation.setHistDays(histDays);
			expirationCorrelation.setStatus(status);
			expirationCorrelation.setUpdDate(GenericTools.systemDate());
			expirationCorrelation.setUpdType("U");
			expirationCorrelation.setUpdUsr(userString());
			log.debug("Expiration Correlation updated - instrId: "+instrId+"; progExp1:"+progExp1+"; progExp2: "+progExp2+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+"; correl: "+correl);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Expiration Correlation - instrId: "+instrId+"; progExp1:"+progExp1+"; progExp2: "+progExp2+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(ExpirationCorrelation expirationCorrel) throws DataNotValidException {
		try {
			log.debug("Expiration Correlation updated - instrId: "+expirationCorrel.getPk().getInstrId()+"; progExp1:"+expirationCorrel.getPk().getProgExp1()+"; progExp2: "+expirationCorrel.getPk().getProgExp2()+"; holding period: "+expirationCorrel.getPk().getNv()+"; nDaysPer: "+expirationCorrel.getPk().getNDaysPer()+"; varType: "+expirationCorrel.getPk().getVarType()+"; mode: "+expirationCorrel.getPk().getMode()+"; correl: "+expirationCorrel.getCorrel());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Expiration Correlation - instrId: "+expirationCorrel.getPk().getInstrId()+"; progExp1:"+expirationCorrel.getPk().getProgExp1()+"; progExp2: "+expirationCorrel.getPk().getProgExp2()+"; holding period: "+expirationCorrel.getPk().getNv()+"; nDaysPer: "+expirationCorrel.getPk().getNDaysPer()+"; varType: "+expirationCorrel.getPk().getVarType()+"; mode: "+expirationCorrel.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	 
	public void remove(int instrId, int progExp1, int progExp2, int nv, int nDaysPer, String varType, int mode) throws DataNotValidException {
		try {
			ExpirationCorrelation expirationCorrelation = findByPrimaryKey(instrId, progExp1, progExp2, nv, nDaysPer, varType, mode);
			em.remove(expirationCorrelation);
			log.debug("Expiration Correlation removed - instrId: "+instrId+"; progExp1:"+progExp1+"; progExp2: "+progExp2+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Expiration Correlation - instrId: "+instrId+"; progExp1:"+progExp1+"; progExp2: "+progExp2+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteExpCorByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Expiration Correlation removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Expiration Correlation - instrId: "+instrId+" "+e.getMessage()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(ExpirationCorrelation expirationCorrel) throws DataNotValidException {
		remove(expirationCorrel.getPk().getInstrId(),expirationCorrel.getPk().getProgExp1(),expirationCorrel.getPk().getProgExp2(),expirationCorrel.getPk().getNv(),expirationCorrel.getPk().getNDaysPer(),expirationCorrel.getPk().getVarType(),expirationCorrel.getPk().getMode());
	}
	
	public void transferMode1To2() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("deleteExpCorrMode2");
    		query.executeUpdate();
    		
    		query = em.createNativeQuery("INSERT INTO PMPTEXPCOR (INSTRID,PROGEXP1,PROGEXP2,NDAYSPER,NV,VARTYPE,MODE,CORREL,PEARSON,DIVUNDIV,HISTDAYS,STATUS,UPDTYPE,UPDUSR,UPDDATE) " +
			"SELECT INSTRID,PROGEXP1,PROGEXP2,NDAYSPER,NV,VARTYPE,2,CORREL,PEARSON,DIVUNDIV,HISTDAYS,STATUS,'C','"+userString()+"','"+GenericTools.systemDate()+"' FROM PMPTEXPCOR WHERE MODE=1");
    		
    		query.executeUpdate();
    		log.debug("transfer of stats from mode 1 to 2 has been completed");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring Expiration correlation from mode 1 to 2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
}
