package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.RiskCommittee;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RiskCommitteeEAO
 */
@Stateless
public class RiskCommitteeEAO implements  RiskCommitteeEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public RiskCommittee[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllRiskCommittee");
    		List<RiskCommittee> riskCommittee = query.getResultList();
    		RiskCommittee[] arrRiskCommittee = new RiskCommittee[riskCommittee.size()];
    		return riskCommittee.toArray(arrRiskCommittee);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Risk Committees - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public RiskCommittee findLast() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getLastRiskCommittee");
    		List<RiskCommittee> riskCommitteeList = query.getResultList();
    		if (riskCommitteeList.size()>0) {
    			return riskCommitteeList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last Risk Committee - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public RiskCommittee findByPrimaryKey(int rcCode) throws DataNotValidException {
		try {
			RiskCommittee riskCommittee = (RiskCommittee) em.find(RiskCommittee.class,rcCode);
    		return riskCommittee;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Risk Committee - rcCode: "+rcCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(Timestamp rcDate, String rcDesc) throws DataNotValidException {
		try {
			RiskCommittee riskCommittee = new RiskCommittee();
			riskCommittee.setRcDate(rcDate);
			riskCommittee.setRcDesc(rcDesc);
			riskCommittee.setUpdType(updType);
			riskCommittee.setUpdDate(GenericTools.systemDate());
			riskCommittee.setUpdUsr(userString());
			em.persist(riskCommittee);
			log.debug("Added new Risk Committee - rcCode: "+riskCommittee.getRcCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Risk Committee - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(RiskCommittee riskCommittee) throws DataNotValidException {
		try {
			riskCommittee.setUpdType(updType);
			riskCommittee.setUpdDate(GenericTools.systemDate());
			riskCommittee.setUpdUsr(userString());
			em.persist(riskCommittee);
			log.debug("Added new Risk Committee - rcCode: "+riskCommittee.getRcCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Risk Committee - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int rcCode, Timestamp rcDate, String rcDesc) throws DataNotValidException {
		try {
			RiskCommittee riskCommittee = findByPrimaryKey(rcCode);
			riskCommittee.setRcDate(rcDate);
			riskCommittee.setRcDesc(rcDesc);
			riskCommittee.setUpdType("U");
			riskCommittee.setUpdDate(GenericTools.systemDate());
			riskCommittee.setUpdUsr(userString());
			log.debug("Risk Committee updated - rcCode: "+rcCode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Risk Committee - rcCode: "+rcCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(RiskCommittee rskCommittee) throws DataNotValidException {
		try {
			RiskCommittee riskCommittee = findByPrimaryKey(rskCommittee.getRcCode());
			riskCommittee.setUpdType("U");
			riskCommittee.setUpdDate(GenericTools.systemDate());
			riskCommittee.setUpdUsr(userString());
			log.debug("Risk Committee updated - rcCode: "+rskCommittee.getRcCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Risk Committee - rcCode: "+rskCommittee.getRcCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(RiskCommittee rskCommittee) throws DataNotValidException {
		try {
			RiskCommittee riskCommittee = findByPrimaryKey(rskCommittee.getRcCode());
			em.remove(riskCommittee);
			log.debug("Risk Committee removed - rcCode: "+rskCommittee.getRcCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Risk Committee - rcCode: "+rskCommittee.getRcCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
}
