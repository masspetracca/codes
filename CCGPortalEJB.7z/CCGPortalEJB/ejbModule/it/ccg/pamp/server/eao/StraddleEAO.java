package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Straddle;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StraddleEAO
 */
@Stateless
public class StraddleEAO implements  StraddleEAOLocal {
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public Straddle[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllStraddles");
    		List<Straddle> straddle = query.getResultList();
    		Straddle[] arrStraddle = new Straddle[straddle.size()];
    		return straddle.toArray(arrStraddle);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching straddles - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Straddle[] getEnabledStraddles() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllEnabledStraddles");
    		List<Straddle> straddle = query.getResultList();
    		Straddle[] arrStraddle = new Straddle[straddle.size()];
    		return straddle.toArray(arrStraddle);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled straddles - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Straddle[] getEnabledStraddlesByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllEnabledStraddlesByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Straddle> straddle = query.getResultList();
    		Straddle[] arrStraddle = new Straddle[straddle.size()];
    		return straddle.toArray(arrStraddle);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled straddles - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Straddle findByPrimaryKey(int instrId) throws DataNotValidException {
		try {
			Straddle straddle = (Straddle) em.find(Straddle.class,instrId);
    		return straddle;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching straddle - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Straddle findEnabledStraddleByInstrId(int instrId) throws DataNotValidException {
		try {
			Straddle straddle = (Straddle) em.find(Straddle.class,instrId);
    		if (straddle!=null && !straddle.getStatus().equalsIgnoreCase("X")) {
    			return straddle;
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching straddle - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
		
	
	public void add(int instrId, Timestamp inivDate, Timestamp endvDate, Timestamp sendDate, String status, BigDecimal crStraM, BigDecimal anStra, 
		BigDecimal usrStra, Timestamp anDate, BigDecimal propStra, int crMul, int anMul, int usrMul, BigDecimal crSpread, BigDecimal anSpread, BigDecimal usrSpread, 
		String propose, String approval, int rcCode, String comment, String crLog, String anLog, String propLog, int anNv, int crNv, int anNDaysPer, int crNDaysPer, 
		int anPrgExp1, int crPrgExp1, int anPrgExp2, int crPrgExp2, String anStrType, String crStrType, String custom) throws DataNotValidException {
		
		try {
			Straddle straddle = new Straddle();
			straddle.setInivDate(inivDate);
			straddle.setEndvDate(endvDate);
			straddle.setSendDate(sendDate);
			straddle.setStatus(status);
			straddle.setCrStraM(crStraM);
			straddle.setAnStra(anStra);
			straddle.setUsrStra(usrStra);
			straddle.setAnDate(anDate);
			straddle.setPropStra(propStra);
			straddle.setCrMul(crMul);
			straddle.setAnMul(anMul);
			straddle.setUsrMul(usrMul);
			straddle.setCrSpread(crSpread);
			straddle.setAnSpread(anSpread);
			straddle.setUsrSpread(usrSpread);
			straddle.setPropose(propose);
			straddle.setApproval(approval);
			straddle.setRcCode(rcCode);
			straddle.setComment(comment);
			straddle.setCrLog(crLog);
			straddle.setAnLog(anLog);
			straddle.setPropLog(propLog);
			straddle.setUpdType("U");
			straddle.setUpdDate(GenericTools.systemDate());
			straddle.setUpdUsr(userString());
			straddle.setAnNv(anNv);
			straddle.setCrNv(crNv);
			straddle.setAnNDaysPer(anNDaysPer);
			straddle.setCrNDaysPer(crNDaysPer);
			straddle.setAnPrgExp1(anPrgExp1);
			straddle.setCrPrgExp1(crPrgExp1);
			straddle.setAnPrgExp2(anPrgExp2);
			straddle.setCrPrgExp2(crPrgExp2);
			straddle.setAnStrType(anStrType);
			straddle.setCrStrType(crStrType);
			straddle.setCustom(custom);
			em.persist(straddle);
			log.debug("Added new straddle - instrid: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding straddle - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(Straddle straddle) throws DataNotValidException {
		try {
			straddle.setUpdType(updType);
			straddle.setUpdDate(GenericTools.systemDate());
			straddle.setUpdUsr(userString());
			em.persist(straddle);
			log.debug("Added new straddle - instrId: "+straddle.getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new straddle - instrId: "+straddle.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void updateCurMar(Straddle straddle) throws DataNotValidException {
		try {
			log.debug("Updated straddle for instrid: "+straddle.getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating straddle - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("resetStraddle");
			query.setParameter(1, divisCode);
			query.setParameter(2, GenericTools.systemDate());
			query.setParameter(3, userString());
			int result = query.executeUpdate();
			log.debug(result+" straddles updated to disabled status - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating straddles to disabled status - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, Timestamp inivDate, Timestamp endvDate, Timestamp sendDate, String status, BigDecimal crStraM, BigDecimal anStra, 
		BigDecimal usrStra, Timestamp anDate, BigDecimal propStra, int crMul, int anMul, int usrMul, BigDecimal crSpread, BigDecimal anSpread, BigDecimal usrSpread, 
		String propose, String approval, int rcCode, String comment, String crLog, String anLog, String propLog, int anNv, int crNv, int anNDaysPer, int crNDaysPer, 
		int anPrgExp1, int crPrgExp1, int anPrgExp2, int crPrgExp2, String anStrType, String crStrType, String custom) throws DataNotValidException {
		
		try {
			Straddle straddle = findByPrimaryKey(instrId);
			straddle.setInivDate(inivDate);
			straddle.setEndvDate(endvDate);
			straddle.setSendDate(sendDate);
			straddle.setStatus(status);
			straddle.setCrStraM(crStraM);
			straddle.setAnStra(anStra);
			straddle.setUsrStra(usrStra);
			straddle.setAnDate(anDate);
			straddle.setPropStra(propStra);
			straddle.setCrMul(crMul);
			straddle.setAnMul(anMul);
			straddle.setUsrMul(usrMul);
			straddle.setCrSpread(crSpread);
			straddle.setAnSpread(anSpread);
			straddle.setUsrSpread(usrSpread);
			straddle.setPropose(propose);
			straddle.setApproval(approval);
			straddle.setRcCode(rcCode);
			straddle.setComment(comment);
			straddle.setCrLog(crLog);
			straddle.setAnLog(anLog);
			straddle.setPropLog(propLog);
			straddle.setUpdType("U");
			straddle.setUpdDate(GenericTools.systemDate());
			straddle.setUpdUsr(userString());
			straddle.setAnNv(anNv);
			straddle.setCrNv(crNv);
			straddle.setAnNDaysPer(anNDaysPer);
			straddle.setCrNDaysPer(crNDaysPer);
			straddle.setAnPrgExp1(anPrgExp1);
			straddle.setCrPrgExp1(crPrgExp1);
			straddle.setAnPrgExp2(anPrgExp2);
			straddle.setCrPrgExp2(crPrgExp2);
			straddle.setAnStrType(anStrType);
			straddle.setCrStrType(crStrType);
			straddle.setCustom(custom);
			log.debug("Updated straddle - instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error straddle - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void update(Straddle stra) throws DataNotValidException {
		Straddle straddle = findByPrimaryKey(stra.getInstrId());
		try {
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating straddle - instrId: "+straddle.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void logUpdate(Straddle stra) throws DataNotValidException {
		
		/*straddle.setUpdType("U");
		straddle.setUpdDate(GenericTools.systemDate());
		straddle.setUpdUsr(userString());*/
		log.debug("Updated straddle - instrId: "+stra.getInstrId());
		/*try {
			update(stra);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating straddle - instrId: "+straddle.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}*/
	}
	
	public void remove(int instrId) throws DataNotValidException {
		try {
			Straddle straddle = findByPrimaryKey(instrId);
			em.remove(straddle);
			log.debug("Removed straddle - instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing straddle - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(Straddle straddle) throws DataNotValidException {
		remove(straddle.getInstrId());
	}
}
