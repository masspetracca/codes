package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.ElecMargin;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface ElecMarginEAOLocal {

	public List<ElecMargin> fetch() throws DataNotValidException;
	
	public List<ElecMargin> getEnabledElecMargins() throws DataNotValidException;

	public List<ElecMargin> getEnabledElecMarginsByDivisCode(String divisCode) throws DataNotValidException;
	
	public List<ElecMargin> findByInstrId(int instrId) throws DataNotValidException;
	
	public List<ElecMargin> findByMonth(int month) throws DataNotValidException;
	
	public ElecMargin findByPrimaryKey(int instrId, int month) throws DataNotValidException;
	
	public void add(int instrId, int month, BigDecimal anCover,	Timestamp anDate, Timestamp anFrstHisD, Timestamp anLastHisD, String anLog, BigDecimal anMargin,
		BigDecimal anMinMar, String anVarType, int anYear, String approval, String comment, BigDecimal crCover, Timestamp crFrstHisD,
		Timestamp crLastHisD, String crLog, BigDecimal crMargin, BigDecimal crMinMar, String crVarType, int crYear, String custom, String divisCode,
		Timestamp endVDate, Timestamp iniVDate, BigDecimal propCover, String propLog, BigDecimal propMargin, BigDecimal propMinMar, String propose,
		int rcCode, BigDecimal rlMargin, Timestamp sendDate, String status, String susp, Timestamp updDate, String updType, String updUsr,
		String userCh, BigDecimal userCov, BigDecimal userMargin, BigDecimal userMinMar) throws DataNotValidException;
	
	public void store(ElecMargin elecMargin) throws DataNotValidException; 
	
	public void update(int instrId, int month, BigDecimal anCover,	Timestamp anDate, Timestamp anFrstHisD, Timestamp anLastHisD, String anLog, BigDecimal anMargin,
		BigDecimal anMinMar, String anVarType, int anYear, String approval, String comment, BigDecimal crCover, Timestamp crFrstHisD,
		Timestamp crLastHisD, String crLog, BigDecimal crMargin, BigDecimal crMinMar, String crVarType, int crYear, String custom, String divisCode,
		Timestamp endVDate, Timestamp iniVDate, BigDecimal propCover, String propLog, BigDecimal propMargin, BigDecimal propMinMar, String propose,
		int rcCode, BigDecimal rlMargin, Timestamp sendDate, String status, String susp, Timestamp updDate, String updType, String updUsr,
		String userCh, BigDecimal userCov, BigDecimal userMargin, BigDecimal userMinMar) throws DataNotValidException;
	
	public void update(ElecMargin elecMargin) throws DataNotValidException;
	
	public void remove(int instrId, int month) throws DataNotValidException;
	
	public int removeByMonth(int month) throws DataNotValidException;
	
	public void remove(ElecMargin elecMargin) throws DataNotValidException;
	
}
