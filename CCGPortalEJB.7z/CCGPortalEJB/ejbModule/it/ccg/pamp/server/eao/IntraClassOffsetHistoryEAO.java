package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ClassMarginHistory;
import it.ccg.pamp.server.entities.IntraclassOffset;
import it.ccg.pamp.server.entities.IntraclassOffsetHistory;
import it.ccg.pamp.server.entities.IntraclassOffsetHistoryPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class IntraclassOffsetHistoryEAO
 */
@Stateless
public class IntraClassOffsetHistoryEAO implements  IntraClassOffsetHistoryEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger logging = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public IntraclassOffsetHistory[] fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllInterclassOffsetHistory");
    		List<IntraclassOffsetHistory> intraclassOffsetHistory = query.getResultList();
    		IntraclassOffsetHistory[] arrIntraclassOffsetHistory = new IntraclassOffsetHistory[intraclassOffsetHistory.size()];
    		return intraclassOffsetHistory.toArray(arrIntraclassOffsetHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Intraclass Offsets History - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public IntraclassOffsetHistory getLastSentIntraClassOffset(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getLastSentIntraClassOffset");
    		query.setParameter("classId", classId);
    		query.setMaxResults(1);
    		List<IntraclassOffsetHistory> intraClassOffsetHistoryList = query.getResultList();
    		if (intraClassOffsetHistoryList.size()>0) {
    			return intraClassOffsetHistoryList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last intraclass offset history - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public IntraclassOffsetHistory findByPrimaryKey(int classId,Timestamp iniVDate) throws DataNotValidException {
		try {
			IntraclassOffsetHistoryPK pK = new IntraclassOffsetHistoryPK();
			pK.setClassId(classId);
			pK.setIniVDate(iniVDate);
			IntraclassOffsetHistory intraclassOffsetHistory = (IntraclassOffsetHistory) em.find(IntraclassOffsetHistory.class,pK);
    		return intraclassOffsetHistory;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Intraclass Offset History - classId: "+classId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public IntraclassOffsetHistory[] findEnabledIntraclassOffsetHistory() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllEnabledIntraclassOffsetHistory");
    		List<IntraclassOffsetHistory> intraclassOffsetHistory = query.getResultList();
    		IntraclassOffsetHistory[] arrIntraclassOffsetHistory = new IntraclassOffsetHistory[intraclassOffsetHistory.size()];
    		return intraclassOffsetHistory.toArray(arrIntraclassOffsetHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled Intraclass Offsets History - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<IntraclassOffsetHistory> getIntraClassOffsetHistoryToExport() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getIntraClassOffsetHistoryToExport");
    		query.setParameter("systemDate", GenericTools.systemDate());
    		List<IntraclassOffsetHistory> intraClassOffsetHistoryList = query.getResultList();
    		return intraClassOffsetHistoryList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching intraclass offsets history to export - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public IntraclassOffsetHistory getCurrentIntraclassOffsetHistory(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCurrentIntraclassOffsetHistory");
    		query.setParameter("classId", classId);
    		query.setMaxResults(1);
    		List<IntraclassOffsetHistory> intraclassOffsetHistory = query.getResultList();
    		if (intraclassOffsetHistory.size()>0) {
    			return intraclassOffsetHistory.get(0);
    		} else {
    			return null;
    		}
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Current Intraclass Offsets History - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public IntraclassOffsetHistory[] findActiveIntraclassOffsetHistory() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllActiveIntraclassOffsetHistory");
    		List<IntraclassOffsetHistory> intraclassOffsetHistory = query.getResultList();
    		IntraclassOffsetHistory[] arrIntraclassOffsetHistory = new IntraclassOffsetHistory[intraclassOffsetHistory.size()];
    		return intraclassOffsetHistory.toArray(arrIntraclassOffsetHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active Intraclass Offsets History - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActiveDeltaForIntraclassOffsetHistory(int classId) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getActiveDeltaForIntraclassOffsetHistory");
    		query.setParameter("classId",classId);
    		List<Integer> activeDeltaList = query.getResultList();
    		Integer[] arrActiveDelta = new Integer[activeDeltaList.size()];
    		activeDeltaList.toArray(arrActiveDelta);
    		return arrActiveDelta;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active delta for Intraclass Offsets History - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActivePeriodsForIntraclassOffsetHistory(int classId, int crNv) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getActivePeriodsForIntraclassOffsetHistory");
    		query.setParameter("classId",classId);
    		query.setParameter("crNv",crNv);
    		List<Integer> activePeriodsList = query.getResultList();
    		Integer[] arrActivePeriods = new Integer[activePeriodsList.size()];
    		activePeriodsList.toArray(arrActivePeriods);
    		return arrActivePeriods;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching acive periods for Intraclass Offsets History - classId:"+classId+"; crNv: "+crNv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public IntraclassOffsetHistory[] findProposedIntraclassOffsetHistory() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllProposedIntraclassOffsetHistory");
    		List<IntraclassOffsetHistory> intraclassOffsetHistory = query.getResultList();
    		IntraclassOffsetHistory[] arrIntraclassOffsetHistory = new IntraclassOffsetHistory[intraclassOffsetHistory.size()];
    		return intraclassOffsetHistory.toArray(arrIntraclassOffsetHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching proposed Intraclass Offsets History - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
		
	public void add(int classId, Timestamp iniVDate, Timestamp anDate, BigDecimal anOff, Timestamp apprDate, String approvedBy, String comment, Timestamp endVDate,
		String log, BigDecimal off, int rcCode, Timestamp sendDate, String sent, String susp, String status) throws DataNotValidException {
		try {
			IntraclassOffsetHistoryPK pK = new IntraclassOffsetHistoryPK();
			pK.setClassId(classId);
			pK.setIniVDate(iniVDate);
			IntraclassOffsetHistory intraclassOffsetHistory = new IntraclassOffsetHistory();
			intraclassOffsetHistory.setPk(pK);
			intraclassOffsetHistory.setAnDate(anDate);
			intraclassOffsetHistory.setAnOff(anOff);
			intraclassOffsetHistory.setApprDate(apprDate);
			intraclassOffsetHistory.setApprovedBy(approvedBy);
			intraclassOffsetHistory.setComment(comment);
			intraclassOffsetHistory.setEndVDate(endVDate);
			intraclassOffsetHistory.setLog(log);
			intraclassOffsetHistory.setOff(off);
			intraclassOffsetHistory.setRcCode(rcCode);
			intraclassOffsetHistory.setSendDate(sendDate);
			intraclassOffsetHistory.setSent(sent);
			intraclassOffsetHistory.setSusp(susp);
			intraclassOffsetHistory.setUpdDate(GenericTools.systemDate());
			intraclassOffsetHistory.setUpdType(updType);
			intraclassOffsetHistory.setUpdUsr(userString());
			intraclassOffsetHistory.setStatus(status);
			
			em.persist(intraclassOffsetHistory);
			logging.debug("Added new Intraclass Offset History - classId: "+classId+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Intraclass Offset History - classId: "+classId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(IntraclassOffsetHistory intraclassOffsetHistory) throws DataNotValidException {
		try {
			em.persist(intraclassOffsetHistory);
			logging.debug("Added new Intraclass Offset History - classId: "+intraclassOffsetHistory.getPk().getClassId()+"; iniVDate: "+intraclassOffsetHistory.getPk().getIniVDate());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding new Intraclass Offset History - classId: "+intraclassOffsetHistory.getPk().getClassId()+"; iniVDate: "+intraclassOffsetHistory.getPk().getIniVDate()+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	
	public void store(IntraclassOffset intraclassOffset) throws DataNotValidException {
		try {
			IntraclassOffsetHistoryPK pK = new IntraclassOffsetHistoryPK();
			pK.setClassId(intraclassOffset.getClassId());
			pK.setIniVDate(intraclassOffset.getIniVDate());
			IntraclassOffsetHistory intraclassOffsetHistory = new IntraclassOffsetHistory();
			intraclassOffsetHistory.setPk(pK);
			
			intraclassOffsetHistory.setEndVDate(intraclassOffset.getEndVDate());
			intraclassOffsetHistory.setOff(intraclassOffset.getPropOff());
			intraclassOffsetHistory.setSent("F");
			intraclassOffsetHistory.setSendDate(intraclassOffset.getSendDate());
			
			intraclassOffsetHistory.setApprovedBy(userString());
			intraclassOffsetHistory.setApprDate(GenericTools.systemDate());
			intraclassOffsetHistory.setAnOff(intraclassOffset.getAnOff());
			intraclassOffsetHistory.setAnDate(intraclassOffset.getAnDate());
						
			intraclassOffsetHistory.setRcCode(intraclassOffset.getRcCode());
			intraclassOffsetHistory.setComment(intraclassOffset.getComment());
			intraclassOffsetHistory.setLog(intraclassOffset.getPropLog());
			intraclassOffsetHistory.setSusp(intraclassOffset.getSusp());
			
			intraclassOffsetHistory.setUpdDate(GenericTools.systemDate());
			intraclassOffsetHistory.setUpdType(updType);
			intraclassOffsetHistory.setUpdUsr(userString());
			
			if (intraclassOffset.getPropose().equalsIgnoreCase("C")) {

				intraclassOffsetHistory.setStatus("E");
			}
			// se il propose � A settiamo lo stato dello storico a
			// enabled
			else if (intraclassOffset.getPropose().equalsIgnoreCase("A")) {

				intraclassOffsetHistory.setStatus("E");
			}
			// mentre se il propose � a D settiamo lo stato dello
			// storico a disabilitato
			else if (intraclassOffset.getPropose().equalsIgnoreCase("D")) {

				intraclassOffsetHistory.setStatus("D");
			}
			
			
			//intraclassOffsetHistory.setStatus(intraclassOffset.getStatus());
			
			em.persist(intraclassOffsetHistory);
			logging.debug("Added new Intraclass Offset History - classId: "+intraclassOffsetHistory.getPk().getClassId()+"; iniVDate: "+intraclassOffsetHistory.getPk().getIniVDate());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding new Intraclass Offset History - classId: "+intraclassOffset.getClassId()+"; iniVDate: "+intraclassOffset.getIniVDate()+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	public void logUpdate(IntraclassOffsetHistory intraclassOffsetHistory) throws DataNotValidException {
		try {
			//update(marHistory);
			logging.debug("Intraclass Offset History History updated - instrId: "+intraclassOffsetHistory.getPk().getClassId()+"; iniVDate: "+intraclassOffsetHistory.getPk().getIniVDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Intraclass Offset History - instrId: "+intraclassOffsetHistory.getPk().getClassId()+"; iniVDate: "+intraclassOffsetHistory.getPk().getIniVDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void update(int classId, Timestamp iniVDate, Timestamp anDate, BigDecimal anOff, Timestamp apprDate, String approvedBy, String comment, Timestamp endVDate,
		String log, BigDecimal off, int rcCode, Timestamp sendDate, String sent, String susp, String status) throws DataNotValidException {
		
		try {
			IntraclassOffsetHistory intraclassOffsetHistory = findByPrimaryKey(classId, iniVDate);
			
			intraclassOffsetHistory.setEndVDate(endVDate);
			intraclassOffsetHistory.setAnDate(anDate);
			intraclassOffsetHistory.setAnOff(anOff);
			intraclassOffsetHistory.setApprDate(apprDate);
			intraclassOffsetHistory.setApprovedBy(approvedBy);
			intraclassOffsetHistory.setComment(comment);
			intraclassOffsetHistory.setEndVDate(endVDate);
			intraclassOffsetHistory.setLog(log);
			intraclassOffsetHistory.setOff(off);
			intraclassOffsetHistory.setRcCode(rcCode);
			intraclassOffsetHistory.setSendDate(sendDate);
			intraclassOffsetHistory.setSent(sent);
			intraclassOffsetHistory.setSusp(susp);
			intraclassOffsetHistory.setUpdDate(GenericTools.systemDate());
			intraclassOffsetHistory.setUpdType("U");
			intraclassOffsetHistory.setUpdUsr(userString());
			intraclassOffsetHistory.setStatus(status);
			
			logging.debug("Intraclass Offset History updated - classId: "+classId+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error updating Intraclass Offset History - classId: "+classId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	public void update(IntraclassOffsetHistory intraclassOffsetHistory) throws DataNotValidException {
		try {
			logging.debug("Intraclass Offset History updated - classId: "+intraclassOffsetHistory.getPk().getClassId()+"; iniVDate: "+intraclassOffsetHistory.getPk().getIniVDate());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error updating Intraclass Offset History - classId: "+intraclassOffsetHistory.getPk().getClassId()+"; iniVDate: "+intraclassOffsetHistory.getPk().getIniVDate()+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	public void remove(int classId, Timestamp iniVDate) throws DataNotValidException {
		try {
			IntraclassOffsetHistory intraclassOffsetHistory = findByPrimaryKey(classId, iniVDate);
			em.remove(intraclassOffsetHistory);
			logging.debug("Intraclass Offset History removed - classId: "+classId+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing Intraclass Offset History - classId: "+classId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	public int removeIntraClassOffsetByClass(int classId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteTraHisByClassId");
			query.setParameter("classId", classId);
			int result = query.executeUpdate();
			logging.debug(result +" Intraclass Offsets History removed - classId: "+classId);
			return result;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing Intraclass Offset History - classId: "+classId+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	public void remove(IntraclassOffsetHistory intraclassOffsetHistory) throws DataNotValidException {
		remove(intraclassOffsetHistory.getPk().getClassId(),intraclassOffsetHistory.getPk().getIniVDate());
	}
}
