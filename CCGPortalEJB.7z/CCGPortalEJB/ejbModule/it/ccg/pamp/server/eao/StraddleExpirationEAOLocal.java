package it.ccg.pamp.server.eao;
import java.sql.Timestamp;

import it.ccg.pamp.server.entities.StraddleExpiration;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface StraddleExpirationEAOLocal {
	public StraddleExpiration[] fetch() throws DataNotValidException;
	public StraddleExpiration findByPrimaryKey(int instrId, int progExp) throws DataNotValidException;
	public StraddleExpiration[] getStreddleExpByInstrId(int instrId) throws DataNotValidException;
	public void add(int instrId, int progExp, int irNode, int nv, int nDaysPer, int progExpMnt) throws DataNotValidException;
	public void store(StraddleExpiration straddleExpiration) throws DataNotValidException;
	public void update(int instrId, int progExp, int irNode, int nv, int nDaysPer, int progExpMnt) throws DataNotValidException;
	public void update(StraddleExpiration straddleExpiration) throws DataNotValidException;
	public void remove(int instrId, int progExp) throws DataNotValidException;
	public int removeByInstrId(int instrId) throws DataNotValidException;
	public void remove(StraddleExpiration streddleExp) throws DataNotValidException;
}
