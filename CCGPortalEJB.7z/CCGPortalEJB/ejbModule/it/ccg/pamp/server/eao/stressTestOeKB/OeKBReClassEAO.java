package it.ccg.pamp.server.eao.stressTestOeKB;

import it.ccg.pamp.server.entities.stressTestOeKB.OeKBReClass;
import it.ccg.pamp.server.entities.stressTestOeKB.OeKBReClassPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class OeKBReClassEAO
 */
@Stateless
public class OeKBReClassEAO implements OeKBReClassEAOLocal {

	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	//@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<OeKBReClass> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllOeKBReClass");
    		List<OeKBReClass> oeKBReClass = query.getResultList();
    		return oeKBReClass;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<OeKBReClass> getSTCgcls00fFutOpt(String cClass) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getOeKBReClassFutOpt");
    		query.setParameter("cClass", cClass);
    		List<OeKBReClass> oeKBReClassList = query.getResultList();
    		return oeKBReClassList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls0sf - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<OeKBReClass> findByCClass(String cClass) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getOeKBReClassByCClass");
    		query.setParameter("cClass", cClass);
    		List<OeKBReClass> oeKBReClassList = query.getResultList();
    		return oeKBReClassList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls0sf - cClass: "+cClass+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<OeKBReClass> findByCofCod(String cofCod) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getOeKBReClassByCofCod");
    		query.setParameter("cofCod", cofCod);
    		List<OeKBReClass> oeKBReClassList = query.getResultList();
    		return oeKBReClassList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls0sf - cofCod: "+cofCod+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public OeKBReClass findByPrimaryKey(String cClass, String cpType) throws DataNotValidException {
		try {
			OeKBReClassPK pK = new OeKBReClassPK();
			pK.setCclass(cClass);			
			pK.setCpType(cpType);
			OeKBReClass oeKBReClass = (OeKBReClass) em.find(OeKBReClass.class,pK);
    		return oeKBReClass;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls0sf - cClass: "+cClass+"; cpType: "+cpType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
}
