package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.RecordNotRestorableException;
import it.ccg.pamp.server.utils.BondClassMarginsAndMaxDurations;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface InstrumentEAOLocal {
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches all financial instruments
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param none
	   * @throws DataNotValidException;
	   * @return the list of all financial instruments or the occurred exception 
	   */
	public Instrument[] fetch() throws DataNotValidException;
	public List<String> findMarketCodeList(String divisCode) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches financial instruments filtering by division
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param divisCode - the instrument division to use in filter 
	   * @throws DataNotValidException;
	   * @return an array of financial instruments or the occurred exception  
	   */
	public Instrument[] getByDivisCode(String divisCode) throws DataNotValidException;
	
	public Instrument[] getByMultipleDivisCode(String[] multipleDivisCode) throws DataNotValidException;
	
	public List<Instrument> getAllByDivisCode(String divisCode) throws DataNotValidException;
	
	public Instrument[] getEnabledEqDerNotHavingUndIndex() throws DataNotValidException;
	
	public List<Instrument> getBondsByIrCurveList(String[] arrIrCurve) throws DataNotValidException;
	
	public List<Instrument> getAllInstrumentsHavingUndInstr() throws DataNotValidException;
	
	public Instrument[] getInterestRates() throws DataNotValidException;
	
	public List<Instrument> getEnabledNodesOfEnabledClassAndCurveByDiviscode(String divisCode) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches financial instruments with enabled and underlayed status filtering by division
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param divisCode
	   * @throws DataNotValidException;
	   * @return an array of financial instruments or the occurred exception 
	   */
	public Instrument[] getEnabledAndUnderlayingInstrumentsByDivisCode(String divisCode) throws DataNotValidException;
	
	public List<Instrument> getEnabledUnderlyingOrDelistedAfterStressTestDateInstrumentsByDivisCode(String divisCode, Timestamp stressTestDate) throws DataNotValidException;
	
	public Instrument getByClassCodeAndDivisCode(String classCode, String divisCode) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches only the enabled financial instruments which are not enabled or not exist in margin table filtering by division
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param divisCode
	   * @throws DataNotValidException;
	   * @return an array of financial instruments or the occurred exception  
	   */
	public Instrument[] getOnlyNotEnabledMarginInstrByDivisCode(String divisCode) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches only the enabled financial instruments which are not enabled or not exist in margin table filtering by division
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param divisCode
	   * @throws DataNotValidException;
	   * @return an array of financial instruments or the occurred exception  
	   */
	public Instrument[] getEnabledInstrNotInMarginByDivisCode(String divisCode) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches only the enabled financial instruments which are not enabled or not exist in minimum margin table filtering by division
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param divisCode
	   * @throws DataNotValidException;
	   * @return an array of financial instruments or the occurred exception  
	   */
	public Instrument[] getEnabledInstrNotInMinimumMarginByDivisCode(String divisCode) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches only the enabled financial instruments which are not enabled or not exist in straddle table filtering by division
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param divisCode
	   * @throws DataNotValidException;
	   * @return an array of financial instruments or the occurred exception  
	   */
	public Instrument[] getEnabledInstrNotInStraddleByDivisCode(String divisCode) throws DataNotValidException;
	
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches only the financial instruments which are enabled both in instrument table and in margin table filtering by division
	   * <p>
	   *
	   *<p>
	   * QUERY NAME: getEnabledInstrAndMarginsByDivisCode 
	   * <p>
	   * QUERY STMT: SELECT inst FROM Instrument inst WHERE inst.divisCode = :divisCode AND inst.status = 'E' AND inst.instrId IN 
	   *(SELECT mrgn.instrId FROM Margin mrgn WHERE mrgn.status = 'E') ORDER BY inst.instrId ASC
	   * Limitation: none
	   *
	   * @param divisCode
	   * @throws DataNotValidException;
	   * @return an array of financial instruments or the occurred exception  
	   */
	public Instrument[] getEnabledInstrAndMarginsByDivisCode(String divisCode) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches only the enabled financial instruments which are both in instrument table and in margin history table
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param none
	   * @throws DataNotValidException;
	   * @return a list of financial instruments or the occurred exception  
	   */
	public List<Instrument> getInstrumentInMarHis() throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches a financial instrument filtering by the primary key of the table
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param instrId - the key of the table
	   * @throws DataNotValidException;
	   * @return a single instance of financial instrument or the occurred exception  
	   */
	public Instrument findByPrimaryKey(int instrId) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches a financial instrument filtering by class code
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param classCode - the classCode of financial instrument
	   * @throws DataNotValidException;
	   * @return a single instance of financial instrument or the occurred exception  
	   */
	public Instrument findByClassCode(String classCode) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches the financial instruments filtering by classId
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param classId - the classId which a bond financial instrument is belonging to
	   * @throws DataNotValidException;
	   * @return an array of financial instruments or the occurred exception  
	   */
	public Instrument[] findByClassId(int classId, String interp, String divisCode) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches the financial instruments of electricity derivatives division which are in expiration
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param none
	   * @throws DataNotValidException;
	   * @return a list of financial instruments or the occurred exception  
	   */
	public List<Instrument> getExpirationInstrument() throws DataNotValidException;
	
	public List<Instrument> findIrNodeByInterp(String interp) throws DataNotValidException;
	
	public List<Instrument> getNotInterpNodesByIrCurveName(String irCurve) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches the financial instruments filtering by the key of instrument table
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param instrId - the instrument ID of the financial instrument of which search the underlying 
	   * @throws DataNotValidException;
	   * @return the instance of the underlying financial instrument, if exists, or the occurred exception  
	   */
	public Instrument getUnderlying(Instrument instr) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * fetches the financial instruments of electricity derivatives division which are in expiration
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param none
	   * @throws DataNotValidException
	   * @return a list of financial instruments or the occurred exception  
	   */
	public Instrument[] getSicInstrType() throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * searches into PMPTINSTR table filtering by IR node
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param irNode - the interest rate node used to filter the query
	   * @throws DataNotValidException
	   * @return an instance of instrument or the occurred exception  
	   */
	public Instrument findByIrNode(int irNode) throws DataNotValidException;
	
	public Instrument findByIrNodeAndCurve(int irNode, String listName) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * searches into PMPTINSTR table filtering by instrument ID and bond class ID
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param instrId - the unique key identifier for Instrument entities
	   * @param classId - the classId which a bond financial instrument is belonging to
	   * @throws DataNotValidException
	   * @return an instance of instrument or the occurred exception  
	   */
	public Instrument getInstrumentIdByInstrIdAndClassId(int instrId, int classId) throws DataNotValidException;
	
	/**
	   * @author Francesco Nelli
	   * <p>
	   * searches into PMPTINSTR table only the enabled components belonging to the enabled bond classes
	   * <p>
	   * 
	   * Limitation: none
	   *
	   * @param none
	   * @throws DataNotValidException
	   * @return an array of Instruments (bond class components) or the occurred exception  
	   */
	public Instrument[] getEnabledBondClassComponents() throws DataNotValidException;
	
	public Instrument[] getBondClassComponentsByClassId1And2(int classId1, int classId2, String interp) throws DataNotValidException;
	
	public Instrument[] getEnabledInflationBondClassComponents() throws DataNotValidException;
	
	public Instrument[] getCurrencies() throws DataNotValidException;
	
	public Instrument[] getCash() throws DataNotValidException;
	
	public List<BondClassMarginsAndMaxDurations> getClassMarginsList() throws DataNotValidException;
	
	public Instrument[] getInstrumentArrayForBondStressTest() throws DataNotValidException;
	
	public Instrument[] getCashAndIndex() throws DataNotValidException;
	
	public Instrument[] getIndexToSync() throws DataNotValidException;
	
	public Instrument[] getFutures() throws DataNotValidException;
	
	
	public List<Instrument> findByInstrType(String instrType) throws DataNotValidException;
	
	public Instrument[] getOptions() throws DataNotValidException;
	
	
	public Instrument[] findByClassIdAndDivisCode(int classId,String divisCode) throws DataNotValidException;
	
	public Instrument[] getIndex() throws DataNotValidException;
	public List<Instrument> getInflationBonds() throws DataNotValidException;
	
	public Instrument[] getInstrumentByDivisCodeAndUndInstrId(String divisCode, int instrId) throws DataNotValidException;
	
	public Instrument[] getInstrumentByDivisCodeAndUndInstrIdAndFalseDerHist(String divisCode, int instrId) throws DataNotValidException;
	
	public Integer[] getInstrIdByDivisCode(String divisCode) throws DataNotValidException;
	public Integer[] getInstrIdByDivisCodeAndInstrType(String divisCode, String instrType) throws DataNotValidException;
	public String[] getInstrTypeByDivisCode(String divisCode) throws DataNotValidException;
	
	public String getClassComponentString() throws DataNotValidException;
	public Integer[] getAllInstrumentClasses() throws DataNotValidException;
	public Integer[] getInstrumentIdByClassId(int classId) throws DataNotValidException;
	
	public void add(int instrId, String instrName, String listName, String classCode, String ricCode, String isinCode, String bloombCode, 
		String divisCode, String marketCode, String sgmCode, String instrType, String instrStype, String currency, String disabReas,
		String addrStreet, String addrCity, String addrDist, String addrPc, String addrState, String addrCount, int histPrId, int histVolaId,
		String delistReas, Timestamp delistDate, String industry, String compos, String issuer, String divType, String addrWeb, String bmkName,
		String bmkRic, String bmkReturn, String bmkStyle, String bmkArea, String bmkDescr, String bmkComp, String bmkSpec, String bmkCurr, 
		int bmknInstr, String status, String format, String shortTFut, String longTOpt, int futExpNumb, BigDecimal mult, BigDecimal shortOpAdj,
		String delDays, int irNode, String irNodeDesc, String reporting, String note, String updType, Timestamp updDate, String userString,
		Timestamp mktLstDate, Timestamp ccpLstDate, String superSect, int optExpNumb, String straType, int undInstrId, int defHistSer, BigDecimal marginTh,
		String derHist, String minMarType, String comparable,int rcCode, int classId, int settleType, BigDecimal duration, String mmTable,
		BigDecimal defMarg, int evtStorMv, String derPer, int derFrstMnt, BigDecimal defMinMar, BigDecimal defStradd, int derPrgMnt, String interp,
		BigDecimal yield, Timestamp expiry, Timestamp coupNextDt, BigDecimal coupFreq, BigDecimal coupVal, String process, String coupType) throws Exception;
	
	
	
	public void update(int instrId, String instrName, String listName, String classCode, String ricCode, String isinCode, String bloombCode, 
		String divisCode, String marketCode, String sgmCode, String instrType, String instrStype, String currency, String disabReas,
		String addrStreet, String addrCity, String addrDist, String addrPc, String addrState, String addrCount, int histPrId, int histVolaId,
		String delistReas, Timestamp delistDate, String industry, String compos, String issuer, String divType, String addrWeb, String bmkName,
		String bmkRic, String bmkReturn, String bmkStyle, String bmkArea, String bmkDescr, String bmkComp, String bmkSpec, String bmkCurr, 
		int bmknInstr, String status, String format, String shortTFut, String longTOpt, int futExpNumb, BigDecimal mult, BigDecimal shortOpAdj,
		String delDays, int irNode, String irNodeDesc, String reporting, String note, String updType, Timestamp updDate, String userString,
		Timestamp mktLstDate, Timestamp ccpLstDate, String superSect, int optExpNumb, String straType, int undInstrId, int defHistSer, BigDecimal marginTh,
		String derHist, String minMarType, String comparable,int rcCode, int classId, int settleType, BigDecimal duration, String mmTable,
		BigDecimal defMarg, int evtStorMv, String derPer, int derFrstMnt, BigDecimal defMinMar, BigDecimal defStradd, int derPrgMnt, String interp,
		BigDecimal yield, Timestamp expiry, Timestamp coupNextDt, BigDecimal coupFreq, BigDecimal coupVal, String process, String coupType) throws DataNotValidException;
	
	public void update(Instrument instr) throws DataNotValidException;
	public void updateUnderlayingInstrId(int instrId,int undInstrId) throws DataNotValidException;
	
	public void remove(int instrId) throws DataNotValidException;
	public void store(Instrument instrument) throws DataNotValidException;
	//public void restore(int updId) throws DataNotValidException, RecordNotRestorableException;
	public void remove(Instrument instr) throws DataNotValidException;
	public int removeByDivisCode(String divisCode) throws DataNotValidException;
	//public void backup(Instrument instr) throws DataNotValidException;
	public int removeByClassId(int classId) throws DataNotValidException;
	
	public int updateStatusToDisable(String divisCode) throws DataNotValidException;
	
	public void add(String instrName, String classCode, String isinCode, String divisCode, String instrType, String instrStype, String currency, String status) throws DataNotValidException;
	public Instrument[] findEnabledDisabledInstrByClassIdAndDivisCode(int classId,String divisCode) throws DataNotValidException;
	
	/**
	 * Return the list of nodes used for the haircut calculation
	 * @return
	 * @throws DataNotValidException
	 */
	public List<Instrument> findHairCutNode() throws DataNotValidException ;
	
	public Instrument[] getComparables() throws DataNotValidException;
	
	public List<Instrument> getEnabledInstrumentOfEnabledClassByDiviscode(String divisCode) throws DataNotValidException;
	
}
