package it.ccg.pamp.server.eao.backTest;
import it.ccg.pamp.server.entities.backTest.BackTestSetup;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface BackTestSetupEAOLocal {
	
	public List<BackTestSetup> fetch() throws DataNotValidException;
	
	public List<BackTestSetup> fetchBackTestSetupsByDivisCode(String divisCode) throws DataNotValidException;
	
	public BackTestSetup findByPrimaryKey(String instrType) throws DataNotValidException;
	
	public BackTestSetup fetchBackTestWithMaxDate(String divisCode) throws DataNotValidException;
	
	//public void add(String instrType, String disabVar, String divisCode, Timestamp histUpdDay, String histUpdLst, String nvVec, int period) throws DataNotValidException;
	
	public void store(BackTestSetup backTestSetup) throws DataNotValidException;
	
	//public void update(String instrType, String disabVar, String divisCode, Timestamp histUpdDay, String histUpdLst, String nvVec, int period) throws DataNotValidException;
	
	//public void update(BackTestSetup backTestSetup) throws DataNotValidException;
	
	public void remove(String instrType) throws DataNotValidException;
	
	public void remove(BackTestSetup backTestSetup) throws DataNotValidException;
	
}
