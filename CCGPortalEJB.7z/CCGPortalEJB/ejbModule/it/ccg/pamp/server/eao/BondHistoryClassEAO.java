package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.BondHistoryClass;
import it.ccg.pamp.server.entities.BondHistoryClassPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ConfidenceEAO
 */
@Stateless
public class BondHistoryClassEAO implements  BondHistoryClassEAOLocal {
	

	@PersistenceContext(unitName = "PAMPUSE", type = PersistenceContextType.TRANSACTION)
	private EntityManager em;

	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";

	@Resource
	SessionContext ctx;

	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}

	public List<BondHistoryClass> fetch() throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getAllBondHistoryClass");
			List<BondHistoryClass> bondHistClassList = query.getResultList();
			return bondHistClassList;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching bond history class - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	
	public List<BondHistoryClass> findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getBondHistoryClassByInstrId");
			query.setParameter("instrId", instrId);
			List<BondHistoryClass> bondHistClassList = query.getResultList();
			return bondHistClassList;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching bond history class - instrId: " + instrId + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	
	public BondHistoryClass findByPrimaryKey(int instrId, Timestamp date) throws DataNotValidException {
		try {
			BondHistoryClassPK pK = new BondHistoryClassPK();
			pK.setInstrId(instrId);
			pK.setDate(date);
			BondHistoryClass bondHistoryClass = em.find(BondHistoryClass.class, pK);
			return bondHistoryClass;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching bond history class - instrId: " + instrId + "; date: " + date + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	
	public void add(int instrId, Timestamp date, BigDecimal duration, int classId) throws DataNotValidException {
		try {
			BondHistoryClass bndHistClass = new BondHistoryClass();
			BondHistoryClassPK pK = new BondHistoryClassPK();
			
			pK.setInstrId(instrId);
			pK.setDate(date);
			
			bndHistClass.setPk(pK);
			bndHistClass.setClassId(classId);
			bndHistClass.setDuration(duration);
			bndHistClass.setUpdType(updType);
			bndHistClass.setUpdDate(GenericTools.systemDate());
			bndHistClass.setUpdUsr(userString());
			em.persist(bndHistClass);
			log.debug("Added new Bond history class - instrId: " + instrId + "; date: " + date + "; classId: " + classId+"; duration: "+duration);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding new Bond history class - instrId: " + instrId + "; date: " + date + "; classId: " + classId+"; duration: "+duration + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void store(BondHistoryClass bndHistClass) throws DataNotValidException {
		try {
			bndHistClass.setUpdType(updType);
			bndHistClass.setUpdDate(GenericTools.systemDate());
			bndHistClass.setUpdUsr(userString());
			em.persist(bndHistClass);
			log.debug("Added new Bond history class - instrId: " + bndHistClass.getPk().getInstrId() + "; date: " + bndHistClass.getPk().getDate() + "; classId: " + bndHistClass.getClassId()+"; duration: "+bndHistClass.getDuration());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding new Bond history class - instrId: " + bndHistClass.getPk().getInstrId() + "; date: " + bndHistClass.getPk().getDate() + "; classId: " + bndHistClass.getClassId()+"; duration: "+bndHistClass.getDuration() + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void update(int instrId, Timestamp date, BigDecimal duration, int classId) throws DataNotValidException {
		try {
			BondHistoryClass bndHistClass = this.findByPrimaryKey(instrId, date);
			bndHistClass.setClassId(classId);
			bndHistClass.setDuration(duration);
			bndHistClass.setUpdType("U");
			bndHistClass.setUpdDate(GenericTools.systemDate());
			bndHistClass.setUpdUsr(userString());
			log.debug("Bond history class updated - instrId: " + instrId + "; date: " + date + "; classId: " + classId+"; duration: "+duration);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error updating Bond history class - instrId: " + instrId + "; date: " + date + "; classId: " + classId+"; duration: "+duration + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void remove(int instrId, Timestamp date) throws DataNotValidException {
		try {
			BondHistoryClass bndHistClass = this.findByPrimaryKey(instrId, date);
			em.remove(bndHistClass);
			log.debug("Bond history class removed - instrId: " + instrId + "; date: " + date);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing Bond history class - instrId: " + instrId + "; date: " + date + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	
}
