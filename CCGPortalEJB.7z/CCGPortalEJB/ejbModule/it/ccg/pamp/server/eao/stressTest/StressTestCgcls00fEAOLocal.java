package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestCgcls00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface StressTestCgcls00fEAOLocal {
	
	public List<StressTestCgcls00f> fetch() throws DataNotValidException;
	
	public List<StressTestCgcls00f> getSTCgcls00fFutOpt(String cClass) throws DataNotValidException;
	
	public List<StressTestCgcls00f> findByCClass(String cClass) throws DataNotValidException;
	
	public List<StressTestCgcls00f> findByCofCod(String cofCod) throws DataNotValidException;
	
	public StressTestCgcls00f findByPrimaryKey(String cClass, String cofCod) throws DataNotValidException;
	
}	
