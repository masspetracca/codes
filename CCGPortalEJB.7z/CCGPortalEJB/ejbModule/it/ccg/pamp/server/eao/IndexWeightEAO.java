package it.ccg.pamp.server.eao;

import java.sql.Timestamp;
import java.util.List;

import it.ccg.pamp.server.entities.IndexWeight;
import it.ccg.pamp.server.entities.IndexWeightPK;
import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class IndexWeightEAO
 */
@Stateless
public class IndexWeightEAO implements  IndexWeightEAOLocal {

	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE")
    private EntityManager em;
	
	public List<IndexWeight> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllIndexWeight");
    		List<IndexWeight> indexWeightList = query.getResultList();
    		return indexWeightList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching index weights - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public IndexWeight findByPrimaryKey(int idxId,int instrId) throws DataNotValidException {
		try {
			IndexWeightPK pK = new IndexWeightPK();
			pK.setIdxId(idxId);
			pK.setInstrId(instrId);
			IndexWeight indexWeight = (IndexWeight) em.find(IndexWeight.class,pK);
    		return indexWeight;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching index weight - idxId: "+idxId+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<IndexWeight> findIndexComponents(int idxId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getIndexComponents");
    		query.setParameter("idxId", idxId);
    		List<IndexWeight> indexComponentsList = query.getResultList();
    		return indexComponentsList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching index components - idxId: "+idxId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<IndexWeight> findIndexByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getIndexByInstrId");
    		query.setParameter("instrId", instrId);
    		List<IndexWeight> indexList = query.getResultList();
    		return indexList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching index weight - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int idxId,int instrId, Timestamp date, long dividend, long outshare) throws DataNotValidException {
		
		try {
			IndexWeight idxWeight = new IndexWeight();
			IndexWeightPK pK = new IndexWeightPK();
			
			pK.setIdxId(idxId);
			pK.setInstrId(instrId);
			
			idxWeight.setDate(date);
			idxWeight.setDividend(dividend);
			idxWeight.setOutshare(outshare);
			
						
			idxWeight.setUpdType(updType);
			idxWeight.setUpdDate(GenericTools.systemDate());
			idxWeight.setUpdUsr(userString());
			
			em.persist(idxWeight);
			userLog.debug("Added new index weight - idxId: "+idxId+"; instrId: "+instrId+"; date: "+date.toString().substring(0,10)+"; dividend: "+dividend+"; outshare: "+outshare);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new index weight - idxId: "+idxId+"; instrId: "+instrId+"; date: "+date.toString().substring(0,10)+"; dividend: "+dividend+"; outshare: "+outshare+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(IndexWeight idxWeight) throws DataNotValidException {
		
		try {
			idxWeight.setUpdType(updType);
			idxWeight.setUpdDate(GenericTools.systemDate());
			idxWeight.setUpdUsr(userString());
			em.persist(idxWeight);
			userLog.debug("Added new index weight - idxId: "+idxWeight.getPk().getIdxId()+"; instrId: "+idxWeight.getPk().getInstrId()+"; date: "+idxWeight.getDate().toString().substring(0,10)+"; dividend: "+idxWeight.getDividend()+"; outshare: "+idxWeight.getOutshare());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new index weight - idxId: "+idxWeight.getPk().getIdxId()+"; instrId: "+idxWeight.getPk().getInstrId()+"; date: "+idxWeight.getDate().toString().substring(0,10)+"; dividend: "+idxWeight.getDividend()+"; outshare: "+idxWeight.getOutshare()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void update(int idxId,int instrId, Timestamp date, long dividend, long outshare) throws DataNotValidException {
		
		try {
			IndexWeight idxWeight = this.findByPrimaryKey(idxId, instrId);
			
			
			idxWeight.setDate(date);
			idxWeight.setDividend(dividend);
			idxWeight.setOutshare(outshare);
			
						
			idxWeight.setUpdType(updType);
			idxWeight.setUpdDate(GenericTools.systemDate());
			idxWeight.setUpdUsr(userString());
			
			
			userLog.debug("Updated index weight - idxId: "+idxId+"; instrId: "+instrId+"; date: "+date.toString().substring(0,10)+"; dividend: "+dividend+"; outshare: "+outshare);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating index weight - idxId: "+idxId+"; instrId: "+instrId+"; date: "+date.toString().substring(0,10)+"; dividend: "+dividend+"; outshare: "+outshare+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(IndexWeight idxWeight) throws DataNotValidException {
		
		try {
			userLog.debug("Updated index weight - idxId: "+idxWeight.getPk().getIdxId()+"; instrId: "+idxWeight.getPk().getInstrId()+"; date: "+idxWeight.getDate().toString().substring(0,10)+"; dividend: "+idxWeight.getDividend()+"; outshare: "+idxWeight.getOutshare());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating index weight - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByIndexId(int idxId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteIdxWeightByIdxClass");
			query.setParameter("idxId", idxId);
			int result = query.executeUpdate();
			if (result>0) {
				userLog.debug(result+" index weight removed");
			}
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing index weigth - indexId: "+idxId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int idxId, int instrId) throws DataNotValidException {
		try {
			IndexWeight idxWeight = this.findByPrimaryKey(idxId, instrId);
			em.remove(idxWeight);
			userLog.debug("Index weight removed - index id: "+idxId+"; instrId: "+instrId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing index weight - index id: "+idxId+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(IndexWeight idxWeight) throws DataNotValidException {
		this.remove(idxWeight.getPk().getIdxId(),idxWeight.getPk().getInstrId());
	}
	
	
}
