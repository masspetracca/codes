package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.stressTest.StressTestMemberStats;
import it.ccg.pamp.server.entities.stressTest.StressTestMemberStatsPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.MemberForReport;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StressTestMemberStatsEAO
 */
@Stateless
public class StressTestMemberStatsEAO implements StressTestMemberStatsEAOLocal {

	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	public List<StressTestMemberStats> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllStressTestMemberStats");
    		List<StressTestMemberStats> StressTestMemberStatsList = query.getResultList();
    		return StressTestMemberStatsList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member statistics - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	
	public StressTestMemberStats findByPrimaryKey(int mbrRank, int mbrId, String scenario, int stId) throws DataNotValidException {
		try {
			StressTestMemberStatsPK pK = new StressTestMemberStatsPK();
			
			pK.setMbrRank(mbrRank);
			pK.setMbrId(mbrId);
			pK.setScenario(scenario);
			pK.setStId(stId);
			
			StressTestMemberStats stressTestStatistic = (StressTestMemberStats) em.find(StressTestMemberStats.class,pK);
    		return stressTestStatistic;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member statistic - member rank: "+mbrRank+"; member: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<StressTestMemberStats> getStressTestMemberStatsByMbrId(int mbrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestMemberStatsByMbrId");
    		query.setParameter("mbrId", mbrId);
    		List<StressTestMemberStats> StressTestMemberStatsList = query.getResultList();
    		return StressTestMemberStatsList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member statistics - memberId: "+mbrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestMemberStats> getStressTestMemberStatsByStId(int stId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestMemberStatsByStId");
    		query.setParameter("stId", stId);
    		List<StressTestMemberStats> StressTestMemberStatsList = query.getResultList();
    		return StressTestMemberStatsList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member statistics - stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestMemberStats> getStressTestMemberStatsByScenario(String scenario) throws DataNotValidException {
		Query query = null;
		
		try {
    		query = em.createNamedQuery("getStressTestMemberStatsByScenario");
    		query.setParameter("scenario", scenario);
    		List<StressTestMemberStats> StressTestMemberStatsList = query.getResultList();
    		return StressTestMemberStatsList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member statistics - scenario: "+GenericTools.scenarioDesc(scenario)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestMemberStats> getStressTestMemberStatsByRank(int mbrRank) throws DataNotValidException {
		Query query = null;
		
		try {
    		query = em.createNamedQuery("getStressTestMemberStatsByRank");
    		query.setParameter("mbrRank", mbrRank);
    		List<StressTestMemberStats> StressTestMemberStatsList = query.getResultList();
    		return StressTestMemberStatsList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member statistics - mbrRank: "+mbrRank+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestMemberStats> getStressTestMemberStatsByMbrIdAndStId(int mbrId, int stId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestMemberStatsByMbrIdAndStId");
    		query.setParameter("mbrId", mbrId);
    		query.setParameter("stId", stId);
    		List<StressTestMemberStats> StressTestMemberStatsList = query.getResultList();
    		return StressTestMemberStatsList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member statistic - memberId: "+mbrId+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestMemberStats> getStressTestMemberStatsByStIdAndScenario(int stId, String scenario) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestMemberStatsByStIdAndScenario");
    		query.setParameter("stId", stId);
    		query.setParameter("scenario", scenario);
    		List<StressTestMemberStats> StressTestMemberStatsList = query.getResultList();
    		return StressTestMemberStatsList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member statistic - stress test id: "+stId+"; scenario: "+GenericTools.scenarioDesc(scenario)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestMemberStats> getStressTestMemberStatsByMbrIdAndScenario(int mbrId, String scenario) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestMemberStatsByMbrIdAndScenario");
    		query.setParameter("mbrId", mbrId);
    		query.setParameter("scenario", scenario);
    		List<StressTestMemberStats> StressTestMemberStatsList = query.getResultList();
    		return StressTestMemberStatsList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test member statistic - member id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public String getMemberReportForMail(String divisCode) throws DataNotValidException {
		
		Query query = null;
    	
		try {
    		
			/*String sqlString =  "SELECT ROW_NUMBER() OVER(ORDER BY M.NCE ASC) AS RANK, "+ 
							    "M.SCENARIO, M.STID, M.MBRID, M.GMBRID, M.MBRDESC,M.HNRMMAR AS FIRMINITIALMARGIN, M.CNRMMAR AS CLIENTINITIALMARGIN, M.HSTRMAR AS FIRMCASHCALL, M.CSTRMAR AS CLIENTCASHCALL, M.NCE, "+
							    "(SELECT SUM(M1.NCE) FROM PMPTSTMBR M1 "+
								"WHERE M1.STID=M.STID AND M1.SCENARIO=M.SCENARIO AND M.NCE>=M1.NCE) AS CUM, "+
								"(SELECT SUM(M1.NCE) FROM PMPTSTMBR M1 "+
								"WHERE M1.STID=M.STID AND M1.SCENARIO=M.SCENARIO AND M.NCE<=M1.NCE) AS RCUM, "+
							    "(SELECT SUM(M1.NCE) FROM PMPTSTMBR M1 WHERE M1.STID=M.STID AND M1.SCENARIO=M.SCENARIO) AS GLOBALSUM, "+
							    "(SELECT COUNT(M1.NCE) FROM PMPTSTMBR M1 WHERE M1.STID=M.STID AND M1.SCENARIO=M.SCENARIO AND M1.NCE<0) AS NCECOUNT, "+
							    "(SELECT COUNT(M1.NCE) FROM PMPTSTMBR M1 WHERE M1.STID=M.STID AND M1.SCENARIO=M.SCENARIO) AS MBRCOUNT "+
							    "FROM PMPTSTMBR M "+
							    "WHERE M.STID = (SELECT MAX(STID) FROM PMPTST WHERE DIVISCODE = '"+divisCode+"') "+
							    "AND M.SCENARIO <> '0' "+
							    "ORDER BY M.SCENARIO, M.NCE ASC";*/
			
			/*String sqlString = "SELECT ROW_NUMBER() OVER(ORDER BY M.NCE ASC) AS RANK, "+
								"M.SCENARIO, M.STID, M.MBRID, M.GMBRID, M.MBRDESC, ROUND(M.HNRMMAR,0) AS FIRMINITIALMARGIN, ROUND(M.CNRMMAR,0) AS CLIENTINITIALMARGIN, ROUND(M.HSTRMAR,0) AS FIRMCASHCALL, ROUND(M.CSTRMAR,0) AS CLIENTCASHCALL, M.NCE, "+
								"ROUND((SELECT SUM(M1.NCE) FROM PMPTSTMBR M1 "+
								"WHERE M1.STID=M.STID AND M1.SCENARIO=M.SCENARIO AND M.NCE>=M1.NCE),0) AS CUM, "+
								"ROUND((SELECT SUM(M1.NCE) FROM PMPTSTMBR M1 "+
								"WHERE M1.STID=M.STID AND M1.SCENARIO=M.SCENARIO AND M.NCE<=M1.NCE),0) AS RCUM, "+
								"ROUND((SELECT SUM(M1.NCE) FROM PMPTSTMBR M1 WHERE M1.STID=M.STID AND M1.SCENARIO=M.SCENARIO),0) AS GLOBALSUM, "+
								"(SELECT COUNT(M1.NCE) FROM PMPTSTMBR M1 WHERE M1.STID=M.STID AND M1.SCENARIO=M.SCENARIO AND M1.NCE<0) AS NCECOUNT, "+
								"(SELECT COUNT(M1.NCE) FROM PMPTSTMBR M1 WHERE M1.STID=M.STID AND M1.SCENARIO=M.SCENARIO) AS MBRCOUNT "+
								"FROM PMPTSTMBR M "+
								"WHERE M.STID = (SELECT MAX(STID) FROM PMPTST WHERE DIVISCODE = '"+divisCode+"') "+ 
								"AND M.SCENARIO <> '0' "+
								"ORDER BY M.SCENARIO, M.NCE ASC ";*/
			
			String sqlString =  "SELECT "+
								"M.MBRRANK AS RANK,M.SCENARIO, M.STID, M.MBRID, M.GMBRID, M.MBRDESC, ROUND(M.HNRMMAR,0) AS FIRMINITIALMARGIN, "+
								"ROUND(M.CNRMMAR,0) AS CLIENTINITIALMARGIN, ROUND(M.HSTRMAR,0) AS FIRMCASHCALL, ROUND(M.CSTRMAR,0) AS CLIENTCASHCALL, "+
								"M.NCE, M.NCECUM AS CUM, M.NCERCUM AS RCUM, M.NCESUM AS GLOBALSUM, M.TOTEXPOSED AS NCECOUNT,M.TOTMEMBERS AS MBRCOUNT "+
								"FROM PMPTSTMBRS M "+
								"WHERE M.STID = (SELECT MAX(STID) FROM PMPTST WHERE DIVISCODE = '"+divisCode+"') "+
								"AND M.SCENARIO <> '0' "+
								"ORDER BY M.SCENARIO, M.MBRRANK ASC";
    		
    		query =  em.createNativeQuery(sqlString,MemberForReport.class);
    		List<MemberForReport> memberList = query.getResultList();

    		String html = "";
    		
    		if (memberList.size()>0) {
    		
    			String htmlHead = "<table align=\"center\" cellspacing=0 style=\"border:1px solid black; font-size:11px; font-family:Arial\">"+
    			"<thead style=\" background-color:#cecece;font-weight:bold\">"+
    			"<tr style=\"border:1px solid black\">"+
    			"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Member ID </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;text-align:center;\"> Member Description </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Stress test ID </th>"+
				//"<th> Scenario </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Home cash call </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Client cash call </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Home initial margin </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Client initial margin </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> ENC </th>"+
				"<th style=\"border-bottom:1px solid black;border-right:1px solid black;width:80px;text-align:center;\"> Cum</th>"+
				"<th style=\"border-bottom:1px solid black;width:80px;text-align:center;\"> Retro cum.</th>"+
				//"<th> Sum</th>"+
				"</tr>"+
				"</thead>";
    			
    			String lastScenario = "";
    			
    			String scenarioTitle = "";
    			
    			String nceString = "";
    			
    			for (MemberForReport member:memberList) {
    				
    				// se � diverso o ho cambiato scenario oppure sto iniziando
    				if (!member.getScenario().equalsIgnoreCase(lastScenario)) {
    					
    					// se non � il primo scenario analizzato allora chiudo la tabella del precedente
    					if (!lastScenario.equalsIgnoreCase("")) {
    						html += "</table><br><br>";
    					}
    					
    					nceString = member.getNceCount()+"/"+member.getMbrCount()+" with not collateralized exposure found";
    					
    					scenarioTitle = "<p style=\"font-family:Arial;font-size:14px;font-weight:bold;text-align:center\">Scenario: "+
    									GenericTools.scenarioFromAcronymous(member.getScenario())+" - "+nceString+"</p>";
    					
    					//intestazione
    					html +=scenarioTitle+htmlHead;
    					
    					lastScenario = member.getScenario();
    				} 
    				/*
    				//ogni riga
					html += "<tbody style=\"border-bottom:1px solid black;border-right:1px solid black; text-align:center\">";
					html += "<tr>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black\"> "+member.getMbrId()+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;text-align:left\"> "+member.getMbrDesc()+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+member.getStId()+"</td>";
    				//html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.scenarioFromAcronymous(member.getScenario())+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.formatNumber(member.getFirmCashcall())+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.formatNumber(member.getClientCashCall())+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.formatNumber(member.getFirmInitialMargin())+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.formatNumber(member.getClientInitialMargin())+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.formatNumber(member.getNce())+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.formatNumber(member.getCum())+"</td>";
    				html += "<td style=\"border-bottom:1px solid black\"> "+GenericTools.formatNumber(member.getRcum())+"</td>";
    				//html += "<td style=\"border:1px solid black\"> "+GenericTools.formatNumber(member.getGlobalSum())+"</td>";
    				html += "</tr>";
    				*/
    				
    				//ogni riga
					html += "<tbody style=\"border-bottom:1px solid black;border-right:1px solid black; text-align:center\">";
					html += "<tr>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black\"> "+member.getMbrId()+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;text-align:left\"> "+member.getMbrDesc()+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+member.getStId()+"</td>";
    				//html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+GenericTools.scenarioFromAcronymous(member.getScenario())+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+member.getFirmCashcall().intValue()+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+member.getClientCashCall().intValue()+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+member.getFirmInitialMargin().intValue()+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+member.getClientInitialMargin().intValue()+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+member.getNce().intValue()+"</td>";
    				html += "<td style=\"border-bottom:1px solid black;border-right:1px solid black;\"> "+member.getCum().intValue()+"</td>";
    				html += "<td style=\"border-bottom:1px solid black\"> "+member.getRcum().intValue()+"</td>";
    				//html += "<td style=\"border:1px solid black\"> "+GenericTools.formatNumber(member.getGlobalSum())+"</td>";
    				html += "</tr>";
    			}
    			html += "</table>";
    		}

    		return html;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from member statistic table - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	

	public void add(int mbrRank, int mbrId, String scenario, int stId, BigDecimal clientInitialMargin, BigDecimal clientCashCall, BigDecimal df, String gMbrDesc, int totalExposedFromTop, 
			Timestamp histUpdDay, BigDecimal firmInitialMargin, BigDecimal firmCashCall, int lastInDf, String log, String mbrDesc, BigDecimal nce, BigDecimal nceCum, 
			BigDecimal nceRetroCum, BigDecimal nceSum, int nDaysPer, String nvVec, int totExposedMembers, int totMembers, BigDecimal dfQuotaD, BigDecimal mtmMargin, BigDecimal ordMargin, BigDecimal mia,Timestamp defFundInivDate) throws DataNotValidException {
		
		try {
			StressTestMemberStats stressTestMemberStats = new StressTestMemberStats();
			
			StressTestMemberStatsPK pK = new StressTestMemberStatsPK();
			
			pK.setMbrRank(mbrRank);
			pK.setMbrId(mbrId);
			pK.setScenario(scenario);
			pK.setStId(stId);
			
			stressTestMemberStats.setPk(pK);
			
			stressTestMemberStats.setClientInitialMargin(clientInitialMargin);
			stressTestMemberStats.setClientCashCall(clientCashCall);
			
			stressTestMemberStats.setDf(df);
			
			stressTestMemberStats.setGMbrDesc(gMbrDesc);
			stressTestMemberStats.setTotalExposedFromTop(totalExposedFromTop);
			stressTestMemberStats.setHistUpdDay(histUpdDay);
			stressTestMemberStats.setFirmInitialMargin(firmInitialMargin);
			stressTestMemberStats.setFirmCashCall(firmCashCall);
			stressTestMemberStats.setLastInDf(lastInDf);
			stressTestMemberStats.setLog(log);
			stressTestMemberStats.setMbrDesc(mbrDesc);
			stressTestMemberStats.setNce(nce);
			stressTestMemberStats.setNceRetroCum(nceRetroCum);
			stressTestMemberStats.setNceSum(nceSum);
			stressTestMemberStats.setNDaysPer(nDaysPer);
			stressTestMemberStats.setNvVec(nvVec);
			
			stressTestMemberStats.setTotExposedMembers(totExposedMembers);
			stressTestMemberStats.setTotMembers(totMembers);

			stressTestMemberStats.setDfQuotaD(dfQuotaD);
			stressTestMemberStats.setMtmMargin(mtmMargin);
			stressTestMemberStats.setOrdMargin(ordMargin);
			stressTestMemberStats.setMia(mia);
									
			stressTestMemberStats.setUpdType(updType);
			stressTestMemberStats.setUpdDate(GenericTools.systemDate());
			stressTestMemberStats.setUpdUsr(userString());
			stressTestMemberStats.setDefFundInivDate(defFundInivDate);
			
			em.persist(stressTestMemberStats);
			userLog.debug("Added new stress test member statistic - member rank: "+mbrRank+"; member Id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test member statistic - member Id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(StressTestMemberStats stressTestMemberStats) throws DataNotValidException {
		
		try {
			
			stressTestMemberStats.setUpdType(updType);
			stressTestMemberStats.setUpdDate(GenericTools.systemDate());
			stressTestMemberStats.setUpdUsr(userString());
			em.persist(stressTestMemberStats);
			userLog.debug("Added new stress test member statistic - member id: "+stressTestMemberStats.getPk().getMbrId()+"; scenario: "+GenericTools.scenarioDesc(stressTestMemberStats.getPk().getScenario())+"; stress test id: "+stressTestMemberStats.getPk().getStId());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test member statistic - member id: "+stressTestMemberStats.getPk().getMbrId()+"; scenario: "+GenericTools.scenarioDesc(stressTestMemberStats.getPk().getScenario())+"; stress test id: "+stressTestMemberStats.getPk().getStId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int mbrRank, int mbrId, String scenario, int stId, BigDecimal clientInitialMargin, BigDecimal clientCashCall, BigDecimal df, String gMbrDesc, int totalExposedFromTop, 
			Timestamp histUpdDay, BigDecimal firmInitialMargin, BigDecimal firmCashCall, int lastInDf, String log, String mbrDesc, BigDecimal nce, BigDecimal nceCum, 
			BigDecimal nceRetroCum, BigDecimal nceSum, int nDaysPer, String nvVec, int totExposedMembers, int totMembers, BigDecimal dfQuotaD, BigDecimal mtmMargin, BigDecimal ordMargin, BigDecimal mia, Timestamp defFundInivDate) throws DataNotValidException {
		
		try {
			StressTestMemberStats stressTestMemberStats = this.findByPrimaryKey(mbrRank, mbrId, scenario, stId);
			
			stressTestMemberStats.setClientInitialMargin(clientInitialMargin);
			stressTestMemberStats.setClientCashCall(clientCashCall);
			
			stressTestMemberStats.setDf(df);
			
			stressTestMemberStats.setGMbrDesc(gMbrDesc);
			stressTestMemberStats.setTotalExposedFromTop(totalExposedFromTop);
			stressTestMemberStats.setHistUpdDay(histUpdDay);
			stressTestMemberStats.setFirmInitialMargin(firmInitialMargin);
			stressTestMemberStats.setFirmCashCall(firmCashCall);
			stressTestMemberStats.setLastInDf(lastInDf);
			stressTestMemberStats.setLog(log);
			stressTestMemberStats.setMbrDesc(mbrDesc);
			stressTestMemberStats.setNce(nce);
			stressTestMemberStats.setNceRetroCum(nceRetroCum);
			stressTestMemberStats.setNceSum(nceSum);
			stressTestMemberStats.setNDaysPer(nDaysPer);
			stressTestMemberStats.setNvVec(nvVec);
			
			stressTestMemberStats.setTotExposedMembers(totExposedMembers);
			stressTestMemberStats.setTotMembers(totMembers);
			stressTestMemberStats.setDfQuotaD(dfQuotaD);
			stressTestMemberStats.setMtmMargin(mtmMargin);
			stressTestMemberStats.setOrdMargin(ordMargin);
			stressTestMemberStats.setMia(mia);
			
			stressTestMemberStats.setUpdType("U");
			stressTestMemberStats.setUpdDate(GenericTools.systemDate());
			stressTestMemberStats.setUpdUsr(userString());
			stressTestMemberStats.setDefFundInivDate(defFundInivDate);

			userLog.debug("Updated stress test member statistic - member Id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stress test member statistic - member Id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(StressTestMemberStats stressTestMemberStats) throws DataNotValidException {
		
		try {
			userLog.debug("Updated stress test member statistic - member id: "+stressTestMemberStats.getPk().getMbrId()+"; scenario: "+GenericTools.scenarioDesc(stressTestMemberStats.getPk().getScenario())+"; stress test id: "+stressTestMemberStats.getPk().getStId());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stress test member statistic - member id: "+stressTestMemberStats.getPk().getMbrId()+"; scenario: "+GenericTools.scenarioDesc(stressTestMemberStats.getPk().getScenario())+"; stress test id: "+stressTestMemberStats.getPk().getStId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int mbrRank, int mbrId, String scenario, int stId) throws DataNotValidException {
		try {
			StressTestMemberStats stressTestStatistic = this.findByPrimaryKey(mbrRank, mbrId, scenario, stId);
			em.remove(stressTestStatistic);
			userLog.debug("Stress test member statistic removed - member rank: "+mbrRank+"; member Id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member statistic - member rank: "+mbrRank+"; member Id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+"; stress test id: "+stId);
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByMbrId(int mbrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("removeStressTestMemberStatsByMbrId");
			query.setParameter("mbrId", mbrId);
			int result = query.executeUpdate();
			userLog.debug(result+" stress test member statistics removed - member id: "+mbrId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member statistics - member id: "+mbrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByStId(int stId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("removeStressTestMemberStatsByStId");
			query.setParameter("stId", stId);
			int result = query.executeUpdate();
			userLog.debug(result+" stress test member statistics removed - stress test id: "+stId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member statistics - stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByScenario(String scenario) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("removeStressTestMemberStatsByScenario");
			query.setParameter("scenario", scenario);
			int result = query.executeUpdate();
			userLog.debug(result+" stress test member statistics removed - scenario: "+GenericTools.scenarioDesc(scenario));
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member statistics - scenario: "+GenericTools.scenarioDesc(scenario)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public int removeByMbrIdAndStId(int mbrId, int stId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("removeStressTestMemberStatsByMbrIdAndStId");
			query.setParameter("mbrId", mbrId);
			query.setParameter("stId", stId);
			int result = query.executeUpdate();
			userLog.debug(result+" stress test member statistics removed - member id: "+mbrId+"; stress test id: "+stId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member statistics - member id: "+mbrId+"; stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByMbrIdAndScenario(int mbrId, String scenario) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("removeStressTestMemberStatsByMbrIdAndScenario");
			query.setParameter("mbrId", mbrId);
			query.setParameter("scenario", scenario);
			int result = query.executeUpdate();
			userLog.debug(result+" stress test member statistics removed - member id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario));
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member statistics - member id: "+mbrId+"; scenario: "+GenericTools.scenarioDesc(scenario)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByStIdAndScenario(int stId, String scenario) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("removeStressTestMemberStatsByStIdAndScenario");
			query.setParameter("stId", stId);
			query.setParameter("scenario", scenario);
			int result = query.executeUpdate();
			userLog.debug(result+" stress test member statistics removed - stress test id: "+stId+"; scenario: "+GenericTools.scenarioDesc(scenario));
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test member statistics - stress test id: "+stId+"; scenario: "+GenericTools.scenarioDesc(scenario)+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void remove(StressTestMemberStats stressTestMemberStats) throws DataNotValidException {
		this.remove(stressTestMemberStats.getPk().getMbrRank(),stressTestMemberStats.getPk().getMbrId(),stressTestMemberStats.getPk().getScenario(),stressTestMemberStats.getPk().getStId());
	}

}
