package it.ccg.pamp.server.eao;

import java.math.BigDecimal;
import java.util.List;

import it.ccg.pamp.server.entities.GroupHistory;
import it.ccg.pamp.server.entities.GroupHistoryPK;
import it.ccg.pamp.server.entities.IntracsLog;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class IntracsLogEAO
 */
@Stateless
public class IntracsLogEAO implements  IntracsLogEAOLocal {

	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger logging = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
    public List<IntracsLog> fetch() throws DataNotValidException {
    	Query query = null;
    	try {
    		query = em.createNamedQuery("getAllIntracsLog");
    		List<IntracsLog> intracsLogList = query.getResultList();
    		return intracsLogList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Intracs Log - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
    }
    
    
    public void store(IntracsLog intracsLog) throws DataNotValidException {
    	Query query = null;
    	try {
    		String sqlString = "INSERT INTO NC1PDTACG.\"TR.LOGB1\" (LDATE,LTIME,LPROG,LUSER,LWSID,LFILE,LSTAT,LBLNK,LOGDT1) VALUES (";
    		sqlString+= new BigDecimal(GenericTools.shortSysDateFormat().replaceAll("-", ""))+ ",";
    		sqlString+= new BigDecimal(GenericTools.systemTime()) + ", ";
    		sqlString+= "'" +intracsLog.getlProg()+ "', ";
    		sqlString+= "'" +intracsLog.getlUser()+ "', ";
    		sqlString+= "'', ";
    		sqlString+= "'" +intracsLog.getlFile()+ "', ";
    		sqlString+= "'" +intracsLog.getlStat()+ "', ";
    		sqlString+= "'', ";
    		sqlString+= "'" +intracsLog.getLogDt1()+ "') ";
			
    		//System.out.println(sqlString);
    		
			query = em.createNativeQuery(sqlString);
			query.executeUpdate();
			
			//em.persist(intracsLog);
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new record on Intracs Log - program "+intracsLog.getlProg()+" on "+intracsLog.getlFile()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
    }

}
