package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Group;
import it.ccg.pamp.server.entities.GroupHistory;
import it.ccg.pamp.server.entities.GroupHistoryPK;
import it.ccg.pamp.server.entities.MarginHistory;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.ReadyToExpGroupHistory;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class GroupHistoryEAO
 */
@Stateless
public class GroupHistoryEAO implements  GroupHistoryEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger logging = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@EJB
	private SchedulerEAOLocal scheduler;
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public GroupHistory[] fetch() throws DataNotValidException  {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllGroupHistory");
    		List<GroupHistory> groupHistory = query.getResultList();
    		GroupHistory[] arrGroupHistory = new GroupHistory[groupHistory.size()];
    		return groupHistory.toArray(arrGroupHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Histories - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupHistory findByPrimaryKey(int grId, Timestamp iniVDate) throws DataNotValidException {
		try {
			GroupHistoryPK pK = new GroupHistoryPK();
			pK.setGrId(grId);
			pK.setIniVDate(iniVDate);
			GroupHistory grHist = (GroupHistory) em.find(GroupHistory.class,pK);
    		return grHist;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group History - groupId: "+grId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupHistory[] findByGroupId(int grId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getGroupHistoryByGroupId");
    		query.setParameter("grId", grId);
    		List<GroupHistory> groupHistory = query.getResultList();
    		GroupHistory[] arrGroupHistory = new GroupHistory[groupHistory.size()];
    		return groupHistory.toArray(arrGroupHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Histories - groupId: "+grId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupHistory getCurrentGroup(int grId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCurrentGroup");
    		query.setParameter("grId", grId);
    		query.setMaxResults(1);
    		List<GroupHistory> groupHistory = query.getResultList();
    		if (groupHistory.size()>0) {
    			return groupHistory.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group History - groupId: "+grId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ReadyToExpGroupHistory> getGroupHistoryToExport(int step) throws DataNotValidException {
		Query query = null;
    	try {
    		String lastExecutor = scheduler.getLastExecutor(130);
    		String strSQL = "SELECT GH.GRID,GH.INIVDATE, GH.PGNAME AS GROUPNAME,GH.COEFF AS GRCOEFF, GH.STATUS AS GRSTATUS, TRS.INSTRID,TRS.SICINSTR AS SICCLASSCODE,TRS.SICINSTRTY AS SICINSTRTYPE, ";
    		
    		
    		strSQL += "I.CURRENCY, '"+lastExecutor+"' AS LASTEXECUTOR ";
    		
    		strSQL+= "FROM PMPTGRHIST GH ";
    		strSQL+= "INNER JOIN PMPTGRCMP GC ON GC.GRID = GH.GRID ";
    		strSQL+= "INNER JOIN PMPTTRSINS TRS ON TRS.INSTRID = GC.INSTRID ";
    		
    		
    		strSQL+= "INNER JOIN PMPTINSTR I ON TRS.INSTRID = I.INSTRID AND I.STATUS IN ('E','U')";
    		
    		
    		strSQL+= "WHERE ";
    		//strSQL+= "GH.STATUS = 'E' AND ";
    		strSQL+= "NOT EXISTS ";
    		strSQL+= "(SELECT * FROM PMPTGRHIST GH2 ";
    		strSQL+= "WHERE GH2.GRID = GH.GRID ";
    		strSQL+= "AND GH2.SENDDATE<=NOW() ";
    		strSQL+= "AND GH2.INIVDATE>GH.INIVDATE) ";
    		
    		/*--solo gruppi*/
    		if (step==1) {
    			strSQL+="AND NOT EXISTS ";
    			strSQL+="(SELECT * FROM PMPTTRSINS TRS2 ";
    			strSQL+="WHERE TRS2.INSTRID=TRS.INSTRID ";
    			strSQL+="AND TRS2.SICINSTR>TRS.SICINSTR) ";
    		
    			strSQL+="AND NOT EXISTS ";
    			strSQL+="(SELECT * FROM PMPTGRCMP GC2 ";
    			strSQL+="WHERE GC.INSTRID>GC2.INSTRID ";
    			strSQL+="AND GC.GRID=GC2.GRID) ";
    		}	
    		
    		strSQL+="ORDER BY GRSTATUS DESC, GRID";
	
    		//System.out.println(strSQL);
    		
    		query =  em.createNativeQuery(strSQL,ReadyToExpGroupHistory.class);
    		
    		List<ReadyToExpGroupHistory> groupHisToExp = query.getResultList();
    		
    		return groupHisToExp;
    		
    			
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group History ready to export - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	} 
	}
	
	public void add(int grId, String pgName, Timestamp iniVDate, Timestamp endVDate, BigDecimal coeff, String sent,
		Timestamp sendDate, int rcCode, String comment, String approvedBy, Timestamp apprDate, BigDecimal anCoeff, Timestamp anDate, String log, String status) throws DataNotValidException {
		try {	
			GroupHistory groupHistory = findByPrimaryKey(grId, iniVDate);
			GroupHistoryPK pK = new GroupHistoryPK();
			pK.setGrId(grId);
			pK.setIniVDate(iniVDate);
			groupHistory.setPk(pK);
			groupHistory.setPgName(pgName);
			groupHistory.setEndvdate(endVDate);
			groupHistory.setCoeff(coeff);
			groupHistory.setSent(sent);
			groupHistory.setSenddate(sendDate);
			groupHistory.setRcCode(rcCode);
			groupHistory.setComment(comment);
			groupHistory.setApprovedBy(approvedBy);
			groupHistory.setApprDate(apprDate);
			groupHistory.setAnCoeff(anCoeff);
			groupHistory.setAnDate(anDate);
			groupHistory.setLog(log);
			groupHistory.setStatus(status);
			groupHistory.setUpdDate(GenericTools.systemDate());
			groupHistory.setUpdType(updType);
			groupHistory.setUpdUsr(userString());
			em.persist(groupHistory);
			logging.debug("Added new Group History - groupId: "+grId+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Group History - groupId: "+grId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(GroupHistory groupHistory) throws DataNotValidException {
		try {
			groupHistory.setApprovedBy(userString());
			groupHistory.setApprDate(GenericTools.systemDate());
			groupHistory.setUpdDate(GenericTools.systemDate());
			groupHistory.setUpdType(updType);
			groupHistory.setUpdUsr(userString());
			em.persist(groupHistory);
			logging.debug("Added new Group History - groupId: "+groupHistory.getPk().getGrId()+"; iniVDate: "+groupHistory.getPk().getIniVdate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Group History - groupId: "+groupHistory.getPk().getGrId()+"; iniVDate: "+groupHistory.getPk().getIniVdate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(Group group) throws DataNotValidException {
		try {
			GroupHistory groupHistory = new GroupHistory();
			GroupHistoryPK pK = new GroupHistoryPK();
			pK.setGrId(group.getGrId());
			pK.setIniVDate(group.getIniVDate());
			groupHistory.setPk(pK);
			groupHistory.setPgName(group.getGrName());
			groupHistory.setEndvdate(group.getEndVDate());
			groupHistory.setCoeff(group.getPropCoeff());
			groupHistory.setSent("F");
			groupHistory.setSenddate(group.getSendDate());
			groupHistory.setRcCode(group.getRcCode());
			groupHistory.setComment(group.getComment());
			groupHistory.setApprovedBy(userString());
			groupHistory.setApprDate(GenericTools.systemDate());
			groupHistory.setAnCoeff(group.getAnCoeff());
			groupHistory.setAnDate(group.getAnDate());
			groupHistory.setLog(group.getPropLog());
			groupHistory.setStatus(group.getStatus());
			groupHistory.setUpdDate(GenericTools.systemDate());
			groupHistory.setUpdType(updType);
			groupHistory.setUpdUsr(userString());
			store(groupHistory);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Group History - groupId: "+group.getGrId()+"; iniVDate: "+group.getIniVDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int grId, String pgName, Timestamp iniVDate, Timestamp endVDate, BigDecimal coeff, String sent,
		Timestamp sendDate, int rcCode, String comment, String approvedBy, Timestamp apprDate, BigDecimal anCoeff, Timestamp anDate, String log, String status) throws DataNotValidException {
		
		GroupHistory groupHistory = findByPrimaryKey(grId, iniVDate);
		try {
			groupHistory.setPgName(pgName);
			groupHistory.setEndvdate(endVDate);
			groupHistory.setCoeff(coeff);
			groupHistory.setSent(sent);
			groupHistory.setSenddate(sendDate);
			groupHistory.setRcCode(rcCode);
			groupHistory.setComment(comment);
			groupHistory.setApprovedBy(approvedBy);
			groupHistory.setApprDate(apprDate);
			groupHistory.setAnCoeff(anCoeff);
			groupHistory.setAnDate(anDate);
			groupHistory.setLog(log);
			groupHistory.setStatus(status);
			groupHistory.setUpdDate(GenericTools.systemDate());
			groupHistory.setUpdType("U");
			groupHistory.setUpdUsr(userString());
			logging.debug("Group History updated - groupId: "+grId+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Group History - groupId: "+grId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(GroupHistory groupHistory) throws DataNotValidException {
		try {
			logging.debug("Group History updated - groupId: "+groupHistory.getPk().getGrId()+"; iniVDate: "+groupHistory.getPk().getIniVdate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Group History - groupId: "+groupHistory.getPk().getGrId()+"; iniVDate: "+groupHistory.getPk().getIniVdate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	 
	public void remove(int grId, Timestamp iniVDate) throws DataNotValidException {
		try {
			GroupHistory groupHistory = findByPrimaryKey(grId, iniVDate);
			em.remove(groupHistory);
			logging.debug("Group History removed - groupId: "+grId+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Group History - groupId: "+grId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByGroupId(int grId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteGroupHistoryByGroupId");
			query.setParameter("grId", grId);
			int result = query.executeUpdate();
			logging.debug(result+" Group History updated - groupId: "+grId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Group History - groupId: "+grId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	} 
	}
	
	public void remove(GroupHistory groupHistory) throws DataNotValidException {
		remove(groupHistory.getPk().getGrId(), groupHistory.getPk().getIniVdate());
	}
	
}
