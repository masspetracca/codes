package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Ebmprdp;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface EbmprdpEAOLocal {

	public List<Ebmprdp> fetch() throws DataNotValidException;
	public Ebmprdp findByPrimaryKey(String ebmCtyp, String ebmMktCd) throws DataNotValidException;
	
}
