package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.InstrIdTrascode;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface InstrIdTrascodeEAOLocal {
	public InstrIdTrascode[] fetch() throws DataNotValidException;
	public InstrIdTrascode[] getSicInstr(int instrId) throws DataNotValidException;
	public InstrIdTrascode[] getSicInstrByIdAndType(int instrId, String instrType) throws DataNotValidException;
	public InstrIdTrascode[] getSicInstrStoredInPamp(int instrId) throws DataNotValidException;
	public InstrIdTrascode[] getRectifiedClasses(int instrId) throws DataNotValidException;
	public InstrIdTrascode[] getInstrId(String sicInstr) throws DataNotValidException;
	public InstrIdTrascode findByPrimaryKey(int instrId, String sicInstr) throws DataNotValidException;
}
