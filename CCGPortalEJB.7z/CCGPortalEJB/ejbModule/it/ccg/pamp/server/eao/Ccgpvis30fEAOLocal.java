package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Ccgpvis30f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;

import javax.ejb.Local;

@Local
public interface Ccgpvis30fEAOLocal {
	public Ccgpvis30f[] fetch() throws DataNotValidException;
	public Ccgpvis30f[] findByV3class(String v3class) throws DataNotValidException;
	public Ccgpvis30f findByPrimaryKey(String hSymbl, BigDecimal hExpir, BigDecimal hStrik, String hPc, long hDate) throws DataNotValidException;
}
