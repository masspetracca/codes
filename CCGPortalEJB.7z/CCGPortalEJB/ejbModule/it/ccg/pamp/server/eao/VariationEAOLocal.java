package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.Correlation;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;
import java.util.Vector;

import javax.ejb.Local;

@Local
public interface VariationEAOLocal {
	public Variation[] fetchAllVar() throws DataNotValidException;
	public Variation[] fetchDerVar() throws DataNotValidException;
	public Variation[] fetchVar() throws DataNotValidException;
	
	public Variation findByPrimaryKey(int instrId, int prgExp, int nv, Timestamp priceDate, String varType) throws DataNotValidException;

	public Variation[] findByInstrIdAndVarType(Instrument instr, String varType) throws DataNotValidException;
	public Variation[] findByInstrIdAndVarTypeAndNv(Instrument instr, String varType,int nv) throws DataNotValidException;
	public Variation[] findByInstrIdAndVarTypeAndNv(int instrId, String varType,int nv) throws DataNotValidException;
	public Variation[] findByInstrIdAndVarTypeAndNvAndPrgExp(Instrument instr, String varType,int nv,int prgExp) throws DataNotValidException;
	public Variation[] findByInstrIdAndVarTypeAndNvAndDate(Instrument instr, String varType,int nv, Timestamp startDate, Timestamp endDate) throws DataNotValidException;
	
	public BigDecimal[] findVariatByInstrIdAndVarTypeAndNv(Instrument instr, String varType,int nv) throws DataNotValidException;
	
	public Correlation getCorrelationListByInstr1And2(Instrument instr1, Instrument instr2, String varType,int nv) throws DataNotValidException;
	
	public List<Correlation> getGroupCorrelationListByInstr1And2(Instrument instr1, Instrument instr2, String varType,int nv) throws DataNotValidException;
	
	public Variation[] findEnabledByInstrIdAndVarTypeAndNvAndInstrId2(Instrument instr, String varType,int nv, Instrument instr2) throws DataNotValidException;
	//public Variation[] findByDateInterval(Timestamp startDate, Timestamp endDate) throws DataNotValidException;

	public List<Variation> getFixedVariationsForBondStressTest(List<Instrument> instrList, String varType, int period, int[] nvVec, String disabVar) throws DataNotValidException;
	
	public List<Variation> getFixedVariationsForStressTest(Instrument instr, String varType, int period, int[] nvVec) throws DataNotValidException;
	
	public Variation[] getFixedVariations(Instrument instr, int nv, int period, Timestamp lastDate, String varType) throws DataNotValidException;
	public Variation[] fetchWithHp(Instrument instr) throws DataNotValidException;
	
	public int getSizeByInstrId(Instrument instr) throws DataNotValidException;
	public int getSizeByInstrIdAndNvAndTh(Instrument instr, int nv, BigDecimal th) throws DataNotValidException;
	public int getSizeByInstrIdAndNv(Instrument instr, int nv) throws DataNotValidException;
	public Integer[] getPrgExpList(Instrument instr) throws DataNotValidException;
	
	public BigDecimal getExtremeValues(Instrument instr, int nv, String varType, int period, int exclude, int n, int choose) throws DataNotValidException;
	public BigDecimal[] getExtremeValues(Instrument instr, int nv, String varType, int period, int choose) throws DataNotValidException;
	public Timestamp getOldestDateByInstrId(Instrument instr) throws DataNotValidException;
	public Timestamp getLatestDateByInstrId(Instrument instr) throws DataNotValidException;
	
	public BigDecimal getMaxVariationByInstrId(Instrument instr,String varType) throws DataNotValidException;

	public void store(Variation derivativesVariation) throws DataNotValidException;
	public void store(Vector<Variation> varVect) throws DataNotValidException;
	public void add(int instrId, int prgExp, int nv, Timestamp priceDate, String varType, BigDecimal variat, String status) throws DataNotValidException;

	public void update(int instrId, int prgExp, int nv, Timestamp priceDate, String varType, BigDecimal variat, String status) throws DataNotValidException;
	public void update(Variation derVar) throws DataNotValidException; 
	public void logUpdate(Variation derVar) throws DataNotValidException;
	
	public void remove(int instrId, int prgExp, int nv, Timestamp priceDate, String varType) throws DataNotValidException;
	public void remove(Variation derVar) throws DataNotValidException; 
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException; 
	public int removeByInstrId(Instrument instr) throws DataNotValidException;
	
}
