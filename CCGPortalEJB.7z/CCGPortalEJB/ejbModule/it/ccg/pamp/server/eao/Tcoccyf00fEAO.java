package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Calendar;
import it.ccg.pamp.server.entities.CalendarPK;
import it.ccg.pamp.server.entities.Tcoccyf00f;
import it.ccg.pamp.server.entities.Tcoccyf00fPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import java.math.BigDecimal;

/**
 * Session Bean implementation class Tcoccyf00fEAO
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class Tcoccyf00fEAO implements  Tcoccyf00fEAOLocal {

@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
	
	private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	
	public List<Tcoccyf00f> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllIntracsCurr");
    		List<Tcoccyf00f> tcoccyf00fList = query.getResultList();
    		return tcoccyf00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from intracs currency historical value change - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Tcoccyf00f> findAfterDateByBlomCode(long priceDate, String currCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getIntracsCurrByCode");
    		query.setParameter("currCode", currCode);
    		query.setParameter("priceDate", new BigDecimal(priceDate));
    		List<Tcoccyf00f> tcoccyf00fList = query.getResultList();
    		return tcoccyf00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from intracs currency historical value change - starting date: "+GenericTools.convertDateFromIntToTimestamp((int)priceDate)+"; code: "+currCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public Tcoccyf00f findByPrimaryKey(long priceDate, String currCode) throws DataNotValidException {
		Query query = null;
    	try {
    		Tcoccyf00fPK pK = new Tcoccyf00fPK();
			pK.setCcyData(new BigDecimal(priceDate));
			pK.setCcyBlom(currCode);
			Tcoccyf00f tcoccyf00f = (Tcoccyf00f) em.find(Tcoccyf00f.class,pK);
    		return tcoccyf00f;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from intracs currency historical value change - date: "+GenericTools.convertDateFromIntToTimestamp((int)priceDate)+"; code: "+currCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
}
