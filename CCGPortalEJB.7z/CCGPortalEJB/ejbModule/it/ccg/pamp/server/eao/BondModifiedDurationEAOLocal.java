package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.BondModifiedDuration;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondClassMarginsAndMaxDurations;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;

@Local
public interface BondModifiedDurationEAOLocal {
	
	public BondModifiedDuration[] fetch() throws DataNotValidException;
	
	public BondModifiedDuration findByPrimaryKey(int instrId) throws DataNotValidException;
	
	public List<BondClassMarginsAndMaxDurations> getClassMarginsAndMaxDurationsList() throws DataNotValidException;
	
	public BigDecimal getDuration(int instrId) throws DataNotValidException;
	
	public void setDuration(int instrId, BigDecimal modDur) throws DataNotValidException;
	
	public void add(int instrId, BigDecimal modDur) throws DataNotValidException;
	
	public void store(BondModifiedDuration bondModifiedDuration) throws DataNotValidException;
	
	public void remove(int instrId) throws DataNotValidException;
	
	public void remove(BondModifiedDuration bondModifiedDuration) throws DataNotValidException;
	
	public void removeByClassId(int classId) throws DataNotValidException;
	
}
