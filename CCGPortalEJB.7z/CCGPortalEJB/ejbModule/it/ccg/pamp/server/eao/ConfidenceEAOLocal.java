package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Confidence;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.utils.MultiKey;

import java.math.BigDecimal;
import java.util.Map;

import javax.ejb.Local;

@Local
public interface ConfidenceEAOLocal {
	public Confidence[] fetch() throws DataNotValidException;
	
	public Confidence[] findByInstrId(int instrId) throws DataNotValidException;
	public Confidence[] findEnabledByInstrId(int instrId) throws DataNotValidException;
	public String getConfidenceString(int instrId) throws DataNotValidException;
	public Integer[] getActiveDelta(int instrId) throws DataNotValidException;
	public Integer[] getActivePeriods(int instrId, int delta) throws DataNotValidException;
	public Integer[] getEnabledPeriods(int instrId, int delta) throws DataNotValidException;
	public Confidence findByPrimaryKey(int instrId, int nDaySper, int nv) throws DataNotValidException;
	public void getActualConfidence(int instrId, Map<MultiKey,String> actualStatusMap, Map<MultiKey,BigDecimal> actualConfidenceMap) throws DataNotValidException, InstrumentDataNotAvailableException;
	public void add(int instrId, int nDaySper, int nv, BigDecimal confid, String defConf, String status) throws DataNotValidException;
	public void store(Confidence confidence) throws DataNotValidException;
	public int storeSimulatedConfidence(int instrId) throws DataNotValidException, InstrumentDataNotAvailableException ;
	//public void restore(int updId) throws DataNotValidException;
	public void update(int instrId, int nDaySper, int nv, BigDecimal confid, String defConf, String status) throws DataNotValidException;
	public void update(Confidence entryConfidence);
	public int updateConfidenceByCurveName(int instrId,String listName) throws DataNotValidException;
	public void remove(int instrId, int nDaySper, int nv) throws DataNotValidException;
	public int removeByInstrId(int instrId) throws DataNotValidException;
	public int disableAll(int instrId) throws DataNotValidException, InstrumentDataNotAvailableException;
	public void enable(Confidence confid) throws DataNotValidException, InstrumentDataNotAvailableException;
}
