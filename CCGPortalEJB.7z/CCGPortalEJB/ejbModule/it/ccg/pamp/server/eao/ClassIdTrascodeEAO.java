package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ClassIdTrascode;
import it.ccg.pamp.server.entities.ClassIdTrascodePK;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ClassIdTrascodeEAO
 */
@Stateless
public class ClassIdTrascodeEAO implements  ClassIdTrascodeEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public List<ClassIdTrascode> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllClassIdTrascode");
    		List<ClassIdTrascode> classIdTrascodeList = query.getResultList();
    		return classIdTrascodeList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from ClassIdTrascode - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ClassIdTrascode> getSicClassId(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSicClassId");
    		query.setParameter("classId", classId);
    		List<ClassIdTrascode> classIdTrascodeList = query.getResultList();
    		return classIdTrascodeList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from ClassIdTrascode - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public InstrIdTrascode[] getSicInstrByIdAndType(int instrId, String instrType) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSicInstrByIdAndType");
    		query.setParameter("instrId", instrId);
    		query.setParameter("instrType", instrType);
    		List<InstrIdTrascode> instrIdTrascode = query.getResultList();
    		InstrIdTrascode[] arrFutClassTypeTrascode = new InstrIdTrascode[instrIdTrascode.size()];
    		return instrIdTrascode.toArray(arrFutClassTypeTrascode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from InstrIdTrascode - instrId: "+instrId+"; instrType: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
	public List<ClassIdTrascode> getPampClassId(String sicClassId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getPampClassId");
    		query.setParameter("sicClassId", sicClassId);
    		List<ClassIdTrascode> classIdTrascodeList = query.getResultList();
    		return classIdTrascodeList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from ClassIdTrascode - sicClassId: "+sicClassId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ClassIdTrascode findByPrimaryKey(int classId, String sicClassId) throws DataNotValidException {
		try {
			ClassIdTrascodePK pK = new ClassIdTrascodePK();
			pK.setClassId(classId);			
			pK.setSicClassId(sicClassId);
			ClassIdTrascode classIdTrascode = (ClassIdTrascode) em.find(ClassIdTrascode.class,pK);
    		return classIdTrascode;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from ClassIdTrascode - classId: "+classId+"; sicClassId: "+sicClassId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
