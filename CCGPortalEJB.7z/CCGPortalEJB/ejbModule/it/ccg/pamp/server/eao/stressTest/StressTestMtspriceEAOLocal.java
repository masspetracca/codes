package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestMtsprice;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;

@Local
public interface StressTestMtspriceEAOLocal {

	public List<StressTestMtsprice> fetch() throws DataNotValidException;
	
	public StressTestMtsprice findByPrimaryKey (String prIsin) throws DataNotValidException;
	
	public void update(String prIsin, BigDecimal pPrice) throws DataNotValidException;
	
}
