package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Ipindx1;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface Ipindx1EAOLocal {
	
	public List<Ipindx1> fetch() throws DataNotValidException;
	
	public Ipindx1 findByPrimaryKey(String xClass,String xSymbl) throws DataNotValidException;
	
	public List<Ipindx1> findByIndexClass(String xClass) throws DataNotValidException;
	
	public List<String> findDistinctIndexClassList() throws DataNotValidException;
	
	public List<Ipindx1> findByInstrumentSymbl(String xSymbl) throws DataNotValidException;
}
