package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ClassMargin;
import it.ccg.pamp.server.entities.Margin;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.ejb.*;
import javax.annotation.security.PermitAll;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.annotation.Resource;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ClassMarginEAO
 */
@Stateless
public class ClassMarginEAO implements  ClassMarginEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");

	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public ClassMargin[] fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllClassMargin");
    		List<ClassMargin> bondClass = query.getResultList();
    		ClassMargin[] arrClassMargin = new ClassMargin[bondClass.size()];
    		return bondClass.toArray(arrClassMargin);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond class margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public ClassMargin findByPrimaryKey(int classId) throws DataNotValidException {
		try {
			ClassMargin bondClass = (ClassMargin) em.find(ClassMargin.class,classId);
    		return bondClass;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond class margin - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public ClassMargin[] findEnabledClassMargin() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllEnabledClassMargin");
    		List<ClassMargin> bondClass = query.getResultList();
    		ClassMargin[] arrClassMargin = new ClassMargin[bondClass.size()];
    		return bondClass.toArray(arrClassMargin);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled bond class margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public ClassMargin[] findEnabledClassMarginByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllEnabledClassMarginByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<ClassMargin> bondClass = query.getResultList();
    		ClassMargin[] arrClassMargin = new ClassMargin[bondClass.size()];
    		return bondClass.toArray(arrClassMargin);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled bond class margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public ClassMargin[] findActiveClassMargin() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllActiveClassMargin");
    		List<ClassMargin> bondClass = query.getResultList();
    		ClassMargin[] arrClassMargin = new ClassMargin[bondClass.size()];
    		return bondClass.toArray(arrClassMargin);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active bond class margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public Integer[] getActiveDeltaForBond(int classId1, int classId2) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getActiveDeltaForBond");
    		query.setParameter("classId1",classId1);
    		query.setParameter("classId2",classId2);
    		List<Integer> activeDeltaList = query.getResultList();
    		Integer[] arrActiveDelta = new Integer[activeDeltaList.size()];
    		activeDeltaList.toArray(arrActiveDelta);
    		return arrActiveDelta;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active delta - classID: " + classId1 + " and "+ classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActivePeriodsForBond(int classId1, int classId2, int nv) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getActivePeriodsForBond");
    		query.setParameter("classId1",classId1);
    		query.setParameter("classId2",classId2);
    		query.setParameter("nv",nv);
    		List<Integer> activePeriodsList = query.getResultList();
    		Integer[] arrActivePeriods = new Integer[activePeriodsList.size()];
    		activePeriodsList.toArray(arrActivePeriods);
    		return arrActivePeriods;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active periods for bond class margin - classID: " + classId1 + " and "+ classId2+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ClassMargin[] findProposedClassMargin() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllProposedClassMargin");
    		List<ClassMargin> bondClass = query.getResultList();
    		ClassMargin[] arrClassMargin = new ClassMargin[bondClass.size()];
    		return bondClass.toArray(arrClassMargin);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching proposed bond class margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	
	public boolean noMarginSubmittedForApproval(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSubmitForApprovalClassMarginsByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Margin> margin = query.getResultList();
    		if (margin.size()>0) {
    			return false;
    		} else {
    			return true;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching submitted margins - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public boolean noMarginSubmittedForApproval() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSubmitForApprovalClassMargins");
    		List<Margin> margin = query.getResultList();
    		if (margin.size()>0) {
    			return false;
    		} else {
    			return true;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching submitted margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int classId, BigDecimal anCover, Timestamp anDate, Timestamp anFrstHisD, Timestamp anLastHisD, String anLog,
			 BigDecimal anMargin, int anNDaysPer, int anNodeId, int anNv, String approval, String comment, BigDecimal crCover,
			 Timestamp crFrstHisD, Timestamp crLastHisD, String crLog, BigDecimal crMargin, int crNDaysPer, int crNodeId, int crNv,
			 String custom, Timestamp endVDate, Timestamp iniVDate, BigDecimal propCover, String propLog, BigDecimal propMargin,
			 String propose, int rcCode, Timestamp sendDate, String status, String susp, BigDecimal userCov, BigDecimal userMargin, String divisCode) throws DataNotValidException {
		try {
			ClassMargin clMar = new ClassMargin();
			clMar.setClassId(classId);
			clMar.setAnCover(anCover);
			clMar.setAnDate(anDate);
			clMar.setAnFrstHisD(anFrstHisD);
			clMar.setAnLastHisD(anLastHisD);
			clMar.setAnLog(anLog);
			clMar.setAnMargin(anMargin);
			clMar.setAnNDaysPer(anNDaysPer);
			clMar.setAnNodeId(anNodeId);
			clMar.setAnNv(anNv);
			clMar.setApproval(approval);
			clMar.setComment(comment);
			clMar.setCrCover(crCover);
			clMar.setCrFrstHisD(crFrstHisD);
			clMar.setCrLastHisD(crLastHisD);
			clMar.setCrLog(crLog);
			clMar.setCrMargin(crMargin);
			clMar.setCrNDaysPer(crNDaysPer);
			clMar.setCrNodeId(crNodeId);
			clMar.setCrNv(crNv);
			clMar.setCustom(custom);
			clMar.setIniVDate(iniVDate);
			clMar.setEndVDate(endVDate);
			clMar.setPropCover(propCover);
			clMar.setPropLog(propLog);
			clMar.setPropMargin(propMargin);
			clMar.setPropose(propose);
			clMar.setRcCode(rcCode);
			clMar.setSendDate(sendDate);
			clMar.setStatus(status);
			clMar.setSusp(susp);
			clMar.setUserCov(userCov);
			clMar.setUserMargin(userMargin);
			clMar.setUpdType(updType);
			clMar.setUpdDate(GenericTools.systemDate());
			clMar.setUpdUsr(userString());
			clMar.setDivisCode(divisCode);
			
			em.persist(clMar);
			
			log.debug("Added bond class margin - classId:"+classId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding bond class margin - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	
	public void store(ClassMargin clMar) throws DataNotValidException {
		try {
			clMar.setUpdType("C");
			clMar.setUpdDate(GenericTools.systemDate());
			clMar.setUpdUsr(userString());
			em.persist(clMar);
			log.debug("Added bond class margin - classId:"+clMar.getClassId());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding bond class margin - classId: "+clMar.getClassId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public void update(int classId, BigDecimal anCover, Timestamp anDate, Timestamp anFrstHisD, Timestamp anLastHisD, String anLog,
			 BigDecimal anMargin, int anNDaysPer, int anNodeId, int anNv, String approval, String comment, BigDecimal crCover,
			 Timestamp crFrstHisD, Timestamp crLastHisD, String crLog, BigDecimal crMargin, int crNDaysPer, int crNodeId, int crNv,
			 String custom, Timestamp endVDate, Timestamp iniVDate, BigDecimal propCover, String propLog, BigDecimal propMargin,
			 String propose, int rcCode, Timestamp sendDate, String status, String susp, BigDecimal userCov, BigDecimal userMargin, String divisCode) throws DataNotValidException {
		
		try {
			ClassMargin clMar = findByPrimaryKey(classId);
			clMar.setAnCover(anCover);
			clMar.setAnDate(anDate);
			clMar.setAnFrstHisD(anFrstHisD);
			clMar.setAnLastHisD(anLastHisD);
			clMar.setAnLog(anLog);
			clMar.setAnMargin(anMargin);
			clMar.setAnNDaysPer(anNDaysPer);
			clMar.setAnNodeId(anNodeId);
			clMar.setAnNv(anNv);
			clMar.setApproval(approval);
			clMar.setComment(comment);
			clMar.setCrCover(crCover);
			clMar.setCrFrstHisD(crFrstHisD);
			clMar.setCrLastHisD(crLastHisD);
			clMar.setCrLog(crLog);
			clMar.setCrMargin(crMargin);
			clMar.setCrNDaysPer(crNDaysPer);
			clMar.setCrNodeId(crNodeId);
			clMar.setCrNv(crNv);
			clMar.setCustom(custom);
			clMar.setIniVDate(iniVDate);
			clMar.setEndVDate(endVDate);
			clMar.setPropCover(propCover);
			clMar.setPropLog(propLog);
			clMar.setPropMargin(propMargin);
			clMar.setPropose(propose);
			clMar.setRcCode(rcCode);
			clMar.setSendDate(sendDate);
			clMar.setStatus(status);
			clMar.setSusp(susp);
			clMar.setUserCov(userCov);
			clMar.setUserMargin(userMargin);
			clMar.setUpdType("U");
			clMar.setUpdDate(GenericTools.systemDate());
			clMar.setUpdUsr(userString());
			clMar.setDivisCode(divisCode);
			log.debug("Updated bond class margin - classId:"+classId);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error updating bond class margin - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public void update(ClassMargin classMargin) throws DataNotValidException {
		try {
			/*ClassMargin clMar = findByPrimaryKey(classMargin.getClassId());
			clMar.setUpdType("U");
			clMar.setUpdDate(GenericTools.systemDate());
			clMar.setUpdUsr(userString());*/
			log.debug("Updated bond class margin - classId:"+classMargin.getClassId());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error updating bond class margin - classId: "+classMargin.getClassId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public void remove(int classId) throws DataNotValidException {
		try {
			ClassMargin clMar = findByPrimaryKey(classId);
			em.remove(clMar);
			log.debug("Removed bond class margin - classId:"+classId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing bond class margin - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public int removeProposedClassMargin() throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteProposedClassMargin");
			int result = query.executeUpdate();
			log.debug(result+" proposed bond class margin removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing proposed bond class margin - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("resetClassMargin");
			query.setParameter(1, divisCode);
			query.setParameter(2, GenericTools.systemDate());
			query.setParameter(3, userString());
			int result = query.executeUpdate();
			log.debug(result+" disabled margins to instrument disabled status - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating margin to disabled status due to instrument disabled status - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(ClassMargin bondClass) throws DataNotValidException {
		try {
			remove(bondClass.getClassId());
		} catch (Exception e) {
    		log.debug("Error removing bond class margin");
    		throw new DataNotValidException("Error removing bond class margin margin - "+e.getMessage());
     	}
	}
}


