package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.utils.UserActionDto;

import java.util.HashMap;

public interface UserActionReportRemote {

	public HashMap<String, UserActionDto> getActionReport() throws Exception;
}
