package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Set;
import it.ccg.pamp.server.entities.SetComponent;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class SetEAO
 */
@Stateless
//@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class SetEAO implements  SetEAOLocal {
	
	@EJB private SetComponentEAOLocal setComp=null;
	@EJB private SetParameterEAOLocal setPar=null;
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public Set[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSets");
    		List<Set> set = query.getResultList();
    		Set[] arrSet = new Set[set.size()];
    		return set.toArray(arrSet);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Sets - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Set findByPrimaryKey(int setId) throws DataNotValidException {
		try {
			Set set = (Set) em.find(Set.class,setId);
    		return set;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Set - setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Set[] findByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSetByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Set> set = query.getResultList();
    		Set[] arrSet = new Set[set.size()];
    		return set.toArray(arrSet);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Sets - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Set[] findEnabledByDivisCode(String divisCode) throws DataNotValidException{
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledSetByDivisCode");
    		//query = em.createNamedQuery("getEnabledSetAndComponentsByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Set> List = query.getResultList();
    		Set[] arrSet = new Set[List.size()];
    		List.toArray(arrSet);
    		for (Set set:arrSet) {
    			SetComponent[] arrSetComp = setComp.findBySetId(set.getSetId());
    			List<SetComponent> setCmpList = new ArrayList<SetComponent>();
    			for (SetComponent setCmp:arrSetComp) {
    				setCmpList.add(setCmp);
    			}
    			if (setCmpList.size()!=0) {
    				set.setSetComponent(setCmpList);
    			}
    		}
    		return arrSet;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled Sets - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void add(String setName, String status, String divisCode, String note,List<SetComponent> setComponentList) throws DataNotValidException {
		try {
			Set set = new Set();
			
			set.setSetName(setName);
			set.setStatus(status);
			set.setDivisCode(divisCode);
			set.setNote(note);
			set.setUpdType(updType);
			set.setUpdDate(GenericTools.systemDate());
			set.setUpdUsr(userString());
			for (SetComponent setC:setComponentList) {
				setComp.store(setC);
			}
			em.persist(set);
			log.debug("Added new Set");
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Set - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(Set set) throws DataNotValidException {
		try {
			set.setUpdType(updType);
			set.setUpdDate(GenericTools.systemDate());
			set.setUpdUsr(userString());
			//List<SetComponent> setComponentList = set.getSetComponent(); 
			//set.setSetComponent(new ArrayList<SetComponent>());
			//set.setSetComponent(setComponentList);
			em.persist(set);
			/*for (SetComponent setC:setComponentList) {
				setComp.store(setC);
			}*/
			log.debug("Added new Set");
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Set - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void update(int setId, String setName, String status, String divisCode, String note) throws DataNotValidException {
		try {
			Set set = findByPrimaryKey(setId);
			set.setSetName(setName);
			set.setStatus(status);
			set.setDivisCode(divisCode);
			set.setNote(note);
			set.setUpdType("U");
			set.setUpdDate(GenericTools.systemDate());
			set.setUpdUsr(userString());
			log.debug("Set updated - setId: "+setId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Set - setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(Set st) throws DataNotValidException {
		try {
			Set set = findByPrimaryKey(st.getSetId());
			set.setUpdType("U");
			set.setUpdDate(GenericTools.systemDate());
			set.setUpdUsr(userString());
			log.debug("Set updated - setId: "+st.getSetId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Set - setId: "+st.getSetId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(Set st) throws DataNotValidException {
		try {
			Set set = findByPrimaryKey(st.getSetId());
			setComp.removeBySetId(st.getSetId());
			setPar.removeBySetId(st.getSetId());
			em.remove(set);
			log.debug("Set removed - setId: "+st.getSetId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Set - setId: "+st.getSetId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
}
