package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.MarketTrascode;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface MarketTrascodeEAOLocal {
	public List<MarketTrascode> fetch() throws DataNotValidException;
	public List<MarketTrascode> getMarketTrsCodeByMarketCode(String marketCode) throws DataNotValidException;
	public List<MarketTrascode> getMarketTrsCodeBySicMarketCode(String sicMarket) throws DataNotValidException;	
	public MarketTrascode findByPrimaryKey(String marketCode, String sicMarket) throws DataNotValidException;
}
