package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.SimulationRankedVariation;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.ejb.Local;

@Local
public interface SimulationRankedVariationEAOLocal {
	public SimulationRankedVariation[] fetch() throws DataNotValidException;
	public SimulationRankedVariation[] findByInstrId(int instrId) throws DataNotValidException;
	public SimulationRankedVariation[] fetchWithMode1() throws DataNotValidException;
	public SimulationRankedVariation[] findByInstrIdAndNvAndRank(int instrId, int nv, int rank) throws DataNotValidException;
	public SimulationRankedVariation findByPrimaryKey(int instrId, int nv, int nDaysPer, int rank, String varType, int mode) throws DataNotValidException;
	public void add(int instrId, int nv, int nDaysPer, int rank, String varType, int mode, Timestamp priceDate, BigDecimal variat) throws DataNotValidException;
	public void store(SimulationRankedVariation simulationRankedVariation) throws DataNotValidException;
	public void update(int instrId, int nv, int nDaysPer, int rank, String varType, int mode, Timestamp priceDate, BigDecimal variat) throws DataNotValidException;
	public void update(SimulationRankedVariation simulationRankVariation) throws DataNotValidException;
	public void remove(int instrId, int nv, int nDaysPer, int rank, String varType, int mode) throws DataNotValidException;
	public int removeByInstrId(int instrId) throws DataNotValidException;
	public int removeByMode(int Mode) throws DataNotValidException;
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException;
	public void remove(SimulationRankedVariation simRankVariation) throws DataNotValidException;
	public int transferMode1inMode2() throws DataNotValidException;
}
