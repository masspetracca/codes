package it.ccg.pamp.server.eao.stressTestOeKB;

import java.math.BigDecimal;
import java.sql.Timestamp;

import it.ccg.pamp.server.entities.IntracsLog;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StressTestProcedureEAO
 */
@Stateless
public class StressTestRePrcEAO implements StressTestRePrcEAOLocal {

	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public void cloneClassTable() throws DataNotValidException {
    
    	Query query = null;
    	try {
    		String sql = "CALL NCECPYC000";
    		
    		query =  em.createNativeQuery(sql);
	    	query.executeUpdate();

    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error cloning class table - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
    	
    }
	
	public void writeLogProcedure(IntracsLog log) throws DataNotValidException {
	    
		String prcString = new BigDecimal(GenericTools.shortSysDateFormat().replaceAll("-", ""))+ ",";
		prcString+= new BigDecimal(GenericTools.systemTime()) + ", ";
		prcString+= "'" +log.getlProg()+ "', ";
		prcString+= "'" +log.getlUser()+ "', ";
		prcString+= "'" +log.getlFile()+ "', ";
		prcString+= "'" +log.getlStat()+ "', ";
		prcString+= "'" +log.getLogDt1()+ "'";
		
    	Query query = null;
    	try {
    		String sql = "CALL NCELOG000 ("+prcString+")";
    		
    		query =  em.createNativeQuery(sql);
	    	query.executeUpdate();

    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error writing log - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
    	
    }
	
	public void startReStressTestProcedure(Timestamp stressTestDate, int stId, String scenario) throws DataNotValidException {
	    
		//String stDate = GenericTools.shortDateFormat(stressTestDate).replaceAll("-", "");
		
		String stDate = /*"20130501"*/GenericTools.shortSysDateFormat().replaceAll("-", "");
		
		String id = Integer.toString(stId);
		
    	Query query = null;
    	try {
    		//String sql = "DELETE FROM CGMGNPGH1L WHERE HGTYPE = 'IDNET' AND HGDATE = '20120301' ";//('"+stDate+"','"+id+"')";
    		
    		log.info("Stress test procedure on Risk Engine started - Stress test number: "+id+"; scenario: "+GenericTools.scenarioFromAcronymous(scenario));
    		
    		//query =  em.createNativeQuery(sql);
    		String sql = "CALL NCEMGSC000 ('"+stDate+"','"+id+"','"+scenario+"')";
    		
    		query =  em.createNativeQuery(sql);
	    	query.executeUpdate();

	    	log.info("Stress test procedure on Risk Engine completed");
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error during the execution of stress test procedure on Risk Engine - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
    	
    }

	
}
