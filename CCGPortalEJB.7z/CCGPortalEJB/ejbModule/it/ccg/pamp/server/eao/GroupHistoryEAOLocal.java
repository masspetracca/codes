package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Group;
import it.ccg.pamp.server.entities.GroupHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.ReadyToExpGroupHistory;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface GroupHistoryEAOLocal {
	
	public GroupHistory[] fetch() throws DataNotValidException;
	
	public GroupHistory findByPrimaryKey(int grId, Timestamp iniVDate) throws DataNotValidException;
	
	public GroupHistory[] findByGroupId(int grId) throws DataNotValidException;
	
	public GroupHistory getCurrentGroup(int grId) throws DataNotValidException;
	
	public List<ReadyToExpGroupHistory> getGroupHistoryToExport(int step) throws DataNotValidException;
	
	public void add(int grId, String pgName, Timestamp iniVDate, Timestamp endVDate, BigDecimal coeff, String sent,
		Timestamp sendDate, int rcCode, String comment, String approvedBy, Timestamp apprDate, BigDecimal anCoeff, Timestamp anDate, String log, String status) throws DataNotValidException;
	
	public void store(GroupHistory groupHistory) throws DataNotValidException;
	
	public void store(Group group) throws DataNotValidException;
	
	public void update(int grId, String pgName, Timestamp iniVDate, Timestamp endVDate, BigDecimal coeff, String sent,
		Timestamp sendDate, int rcCode, String comment, String approvedBy, Timestamp apprDate, BigDecimal anCoeff, Timestamp anDate, String log, String status) throws DataNotValidException; 

	public void update(GroupHistory grHistory) throws DataNotValidException;
	
	public void remove(int grId, Timestamp iniVDate) throws DataNotValidException;
	
	public int removeByGroupId(int grId) throws DataNotValidException;
	
	public void remove(GroupHistory groupHistory) throws DataNotValidException;
	
}
