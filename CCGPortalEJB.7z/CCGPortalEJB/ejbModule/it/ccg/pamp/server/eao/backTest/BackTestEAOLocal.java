package it.ccg.pamp.server.eao.backTest;
import it.ccg.pamp.server.entities.backTest.BackTest;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface BackTestEAOLocal {
	
public List<BackTest> fetchAllBackTest() throws DataNotValidException;
	
	public List<BackTest> fetchBackTestByDivisCode(String divisCode) throws DataNotValidException;
	
	public BackTest findByPrimaryKey(int btId) throws DataNotValidException;
	
	public BackTest findBackTestOrderByStId() throws DataNotValidException;
	
	public int createAndReturnBackTestId(String divisCode/*, Timestamp lstHistDat*/) throws DataNotValidException;
	
	public void add(String divisCode, Timestamp lstHistDat, String note, String status) throws DataNotValidException;
	
	public void store(BackTest backTest) throws DataNotValidException;
	
	public void update(int btId, String divisCode, Timestamp lstHistDat, String note, String status) throws DataNotValidException;
	
	public void remove(int btId) throws DataNotValidException;
	
	public void remove(BackTest backTest) throws DataNotValidException;
	
}
