package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.DefaultConfidence;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;

import javax.ejb.Local;

@Local
public interface DefaultConfidenceEAOLocal {
	public DefaultConfidence[] fetch() throws DataNotValidException;
	public DefaultConfidence[] findByInstrType(String instrType) throws DataNotValidException;
	public Integer[] getActiveDelta(String instrType) throws DataNotValidException;
	public Integer[] getActivePeriods(String instrType, int delta) throws DataNotValidException;
	public Integer[] getEnabledPeriods(String instrType, int delta) throws DataNotValidException;
	public DefaultConfidence findByPrimaryKey(String instrType, int nDaySper, int nv) throws DataNotValidException ;
	public void add(String instrType, int nDaySper, int nv, BigDecimal confidDf) throws DataNotValidException;
	public void store(DefaultConfidence defaultConfidence) throws DataNotValidException;
	public void update(String instrType, int nDaySper, int nv, BigDecimal confidDf) throws DataNotValidException;
	public void update(DefaultConfidence defConfidence) throws DataNotValidException;
	public void remove(String instrType, int nDaySper, int nv) throws DataNotValidException;
	public void remove(DefaultConfidence defaultConfidence) throws DataNotValidException;
	public int removeByInstrType(String instrType) throws DataNotValidException;
}
