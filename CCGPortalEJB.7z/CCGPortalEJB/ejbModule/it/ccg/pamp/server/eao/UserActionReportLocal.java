package it.ccg.pamp.server.eao;

public interface UserActionReportLocal {

	public void addAction(String user, String action);
}
