package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Notify;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class NotifyEAO
 */
@Stateless
public class NotifyEAO implements  NotifyEAOLocal {


	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
		
	public Notify[] fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllNotifies");
    		List<Notify> notify = query.getResultList();
    		Notify[] arrNotify = new Notify[notify.size()];
    		return notify.toArray(arrNotify);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Notifies - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Notify findByPrimaryKey(int notifyId) throws DataNotValidException  {
		try {
			Notify notify = (Notify) em.find(Notify.class,notifyId);
    		return notify;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Notify - notifyId: "+notifyId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int notifyId, String text, int value, String enable, String link) throws DataNotValidException {
		
		Notify notify = new Notify();
		try {
			notify.setNotifyId(notifyId);
			notify.setText(text);
			notify.setValue(value);
			notify.setEnable(enable);
			notify.setLink(link);
			notify.setUpdDate(GenericTools.systemDate());
			notify.setUpdType(updType);
			notify.setUpdUsr(userString());
			em.persist(notify);
			log.debug("Added new Notify - notifyId: "+notifyId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Notify - notifyId: "+notifyId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(Notify notify) throws DataNotValidException {
		try {
			notify.setUpdDate(GenericTools.systemDate());
			notify.setUpdType(updType);
			notify.setUpdUsr(userString());
			em.persist(notify);
			log.debug("Added new Notify - notifyId: "+notify.getNotifyId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding Notify - notifyId: "+notify.getNotifyId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int notifyId, String text, int value, String enable, String link) throws DataNotValidException  {
		
		Notify notify = findByPrimaryKey(notifyId);
		try {
			notify.setText(text);
			notify.setValue(value);
			notify.setEnable(enable);
			notify.setLink(link);
			notify.setUpdDate(GenericTools.systemDate());
			notify.setUpdType("U");
			notify.setUpdUsr(userString());
			log.debug("Notify updated - notifyId: "+notifyId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Notify - notifyId: "+notifyId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void enable( int notifyId) {
		
		try {
			Notify notify = findByPrimaryKey(notifyId);
			if (notify!=null) {
				notify.setEnable("T");
				notify.setUpdDate(GenericTools.systemDate());
				notify.setUpdType("U");
				notify.setUpdUsr(userString());
				log.debug("Notify enabled - notifyId: "+notifyId);
			} else {
				log.warn("no notify to enable found - codeBatch: "+notifyId);
			}
			
		} catch (Exception e) {
    		//DataNotValidException exc = new DataNotValidException("Error enabling Notify - notifyId: "+notifyId+" - "+e.getMessage());
    		log.warn(e.getMessage());
    		//throw exc;
    	}
	}
	
	public void disable(int notifyId) {
		
		try {
			Notify notify = findByPrimaryKey(notifyId);
			if (notify!=null) {
				notify.setEnable("F");
				notify.setUpdDate(GenericTools.systemDate());
				notify.setUpdType("U");
				notify.setUpdUsr(userString());
				log.debug("Notifies disabled - notifyId: "+notifyId);
			} else {
				log.warn("no notify to disable found - codeBatch: "+notifyId);
			}
		} catch (Exception e) {
			//DataNotValidException exc = new DataNotValidException("Error enabling Notify - notifyId: "+notifyId+" - "+e.getMessage());
    		log.warn(e.getStackTrace().toString());
    		//throw exc;
    	}
	}
	
	public void update(Notify notify) throws DataNotValidException {
		try {
			log.debug("Notify updated - notifyId: "+notify.getNotifyId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Notify - notifyId: "+notify.getNotifyId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int notifyId) throws DataNotValidException {
		try {	
			Notify notify = findByPrimaryKey(notifyId);
			em.remove(notify);
			log.debug("Removed Notify - notifyId: "+notifyId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Notify - notifyId: "+notifyId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(Notify notify) throws DataNotValidException {
		remove(notify.getNotifyId());
	}

}
