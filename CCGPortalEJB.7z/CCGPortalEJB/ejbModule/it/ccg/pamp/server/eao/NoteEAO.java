package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Note;
import it.ccg.pamp.server.entities.NotePK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class NoteEAO
 */
@Stateless
public class NoteEAO implements  NoteEAOLocal {

	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	public Note[] fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllNotes");
    		List<Note> note = query.getResultList();
    		Note[] arrNote = new Note[note.size()];
    		return note.toArray(arrNote);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Notes - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Note findByPrimaryKey(int noteId, String owner) throws DataNotValidException  {
		try {
			NotePK pK = new NotePK();
			pK.setNoteId(noteId);
			pK.setOwner(owner);
			Note note = (Note) em.find(Note.class,pK);
    		return note;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Note - noteId: "+noteId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Note[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getNotesByInstrId");
    		query.setParameter("instrId", instrId);
    		List<Note> noteList = query.getResultList();
    		Note[] arrNote = new Note[noteList.size()];
    		return noteList.toArray(arrNote);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Notes by instrId - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void add(int noteId, String owner, String content, int instrId, Timestamp date, int xPos, int yPos, int xDim, int yDim, String shared, String closed) throws DataNotValidException {
		try {
			Note note = new Note();
			NotePK pK = new NotePK();
			pK.setNoteId(noteId);
			pK.setOwner(owner);
			note.setPk(pK);
			note.setContent(content);
			note.setInstrId(instrId);
			note.setDate(date);
			note.setXPos(xPos);
			note.setYPos(yPos);
			note.setXDim(xDim);
			note.setYDim(yDim);
			note.setShared(shared);
			note.setClosed(closed);
			note.setUpdType(updType);
			note.setUpdDate(GenericTools.systemDate());
			note.setUpdUsr(userString());
			em.persist(note);
			log.debug("Added new Note - instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Note - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(Note note) throws DataNotValidException {
		try {
			note.setUpdType(updType);
			note.setUpdDate(GenericTools.systemDate());
			note.setUpdUsr(userString());
			em.persist(note);
			log.debug("Added new Note - instrId: "+note.getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding Note - instrId: "+note.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int noteId, String owner, String content, int instrId, Timestamp date, int xPos, int yPos, int xDim, int yDim, String shared, String closed) throws DataNotValidException  {
		
		Note note = findByPrimaryKey(noteId,owner);
		try {
			note.setContent(content);
			note.setInstrId(instrId);
			note.setDate(date);
			note.setXPos(xPos);
			note.setYPos(yPos);
			note.setXDim(xDim);
			note.setYDim(yDim);
			note.setShared(shared);
			note.setClosed(closed);
			note.setUpdType("U");
			note.setUpdDate(GenericTools.systemDate());
			note.setUpdUsr(userString());
			em.persist(note);
			log.debug("Note updated - noteId: "+noteId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Note - - noteId: "+noteId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(Note note) throws DataNotValidException {
		try {
			log.debug("Note updated - noteId: "+note.getPk().getNoteId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Note - - noteId: "+note.getPk().getNoteId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int noteId, String owner) throws DataNotValidException {
		try {	
			Note note = findByPrimaryKey(noteId, owner);
			em.remove(note);
			log.debug("Removed Note  - noteId: "+noteId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Note - noteId: "+noteId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
		try {	
			query = em.createNamedQuery("deleteNotesByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" notes removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Note - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void remove(Note note) throws DataNotValidException {
		remove(note.getPk().getNoteId(), note.getPk().getOwner());
	}
}
