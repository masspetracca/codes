package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.SimulationRankedVariation;
import it.ccg.pamp.server.entities.SimulationRankedVariationPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RankedVariationEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class SimulationRankedVariationEAO implements  SimulationRankedVariationEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@SuppressWarnings("unchecked")
	public SimulationRankedVariation[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSimRankedVar");
    		query.setParameter("updUsr", userString());
    		List<SimulationRankedVariation> simulationRankedVariation = query.getResultList();
    		SimulationRankedVariation[] arrSimulationRankedVariation = new SimulationRankedVariation[simulationRankedVariation.size()];
    		return simulationRankedVariation.toArray(arrSimulationRankedVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Simulation Ranked Variations - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationRankedVariation[] fetchWithMode1() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSimRankedVarWithMode1");
    		query.setParameter("updUsr", userString());
    		List<SimulationRankedVariation> simulationRankedVariation = query.getResultList();
    		SimulationRankedVariation[] arrRankedVariation = new SimulationRankedVariation[simulationRankedVariation.size()];
    		return simulationRankedVariation.toArray(arrRankedVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Simulation Ranked Variations with mode 1 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationRankedVariation[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSimRankedVarByInstrId");
    		query.setParameter("instrId", instrId);
    		query.setParameter("updUsr", userString());
    		List<SimulationRankedVariation> simulationRankedVariation = query.getResultList();
    		SimulationRankedVariation[] arrRankedVariation = new SimulationRankedVariation[simulationRankedVariation.size()];
    		return simulationRankedVariation.toArray(arrRankedVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Simulation Ranked Variations - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationRankedVariation[] findByInstrIdAndNvAndRank(int instrId, int nv, int rank) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSimRankedVarByInstrIdAndNvAndRank");
    		query.setParameter("instrId", instrId);
    		query.setParameter("nv", nv);
    		query.setParameter("rank", rank);
    		query.setParameter("updUsr", userString());
    		List<SimulationRankedVariation> simulationRankedVariation = query.getResultList();
    		SimulationRankedVariation[] arrRankedVariation = new SimulationRankedVariation[simulationRankedVariation.size()];
    		return simulationRankedVariation.toArray(arrRankedVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Simulation Ranked Variations - instrId: "+instrId+"; holding period: "+nv+"; rank: "+rank+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationRankedVariation findByPrimaryKey(int instrId, int nv, int nDaysPer, int rank, String varType, int mode) throws DataNotValidException {
		try {
			SimulationRankedVariationPK pK = new SimulationRankedVariationPK();
			pK.setInstrId(instrId);
			pK.setNv(nv);
			pK.setNDaysPer(nDaysPer);
			pK.setRank(rank);
			pK.setVarType(varType);
			pK.setMode(mode);
			pK.setUpdUsr(userString());
			SimulationRankedVariation simulationRankedVariation = (SimulationRankedVariation) em.find(SimulationRankedVariation.class,pK);
    		return simulationRankedVariation;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Simulation Ranked Variation - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, int nv, int nDaysPer, int rank, String varType, int mode, Timestamp priceDate, BigDecimal variat) throws DataNotValidException {
		try {
			SimulationRankedVariation simulationRankedVariation = new SimulationRankedVariation();
			SimulationRankedVariationPK pK = new SimulationRankedVariationPK();
			pK.setInstrId(instrId);
			pK.setNv(nv);
			pK.setNDaysPer(nDaysPer);
			pK.setRank(rank);
			pK.setVarType(varType);
			pK.setMode(mode);
			pK.setUpdUsr(userString());
			simulationRankedVariation.setPk(pK);
			simulationRankedVariation.setPricedate(priceDate);
			simulationRankedVariation.setVariat(variat);
			simulationRankedVariation.setUpdDate(GenericTools.systemDate());
			simulationRankedVariation.setUpdType("C");
			em.persist(simulationRankedVariation);
			log.debug("Added new Simulation Ranked Variation - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Simulation Ranked Variation - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	

	public void store(SimulationRankedVariation simulationRankedVariation) throws DataNotValidException {
		try {
			SimulationRankedVariationPK pK = new SimulationRankedVariationPK();
			pK.setInstrId(simulationRankedVariation.getPk().getInstrId());
			pK.setNv(simulationRankedVariation.getPk().getNv());
			pK.setNDaysPer(simulationRankedVariation.getPk().getNDaysPer());
			pK.setRank(simulationRankedVariation.getPk().getRank());
			pK.setVarType(simulationRankedVariation.getPk().getVarType());
			pK.setMode(simulationRankedVariation.getPk().getMode());
			pK.setUpdUsr(userString());
			simulationRankedVariation.setPk(pK);
			simulationRankedVariation.setUpdDate(GenericTools.systemDate());
			simulationRankedVariation.setUpdType("C");
			em.persist(simulationRankedVariation);
			log.debug("Added new Simulation Ranked Variation - instrId: "+simulationRankedVariation.getPk().getInstrId()+"; holding period: "+simulationRankedVariation.getPk().getNv()+"; nDaysPer: "+simulationRankedVariation.getPk().getNDaysPer()+"; rank: "+simulationRankedVariation.getPk().getRank()+"; varType: "+simulationRankedVariation.getPk().getVarType()+"; mode: "+simulationRankedVariation.getPk().getMode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Simulation Ranked Variation - instrId: "+simulationRankedVariation.getPk().getInstrId()+"; holding period: "+simulationRankedVariation.getPk().getNv()+"; nDaysPer: "+simulationRankedVariation.getPk().getNDaysPer()+"; rank: "+simulationRankedVariation.getPk().getRank()+"; varType: "+simulationRankedVariation.getPk().getVarType()+"; mode: "+simulationRankedVariation.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public void update(int instrId, int nv, int nDaysPer, int rank, String varType, int mode, Timestamp priceDate, BigDecimal variat) throws DataNotValidException {
		try {	
			SimulationRankedVariation simulationRankedVariation = findByPrimaryKey(instrId, nv, nDaysPer, rank, varType, mode);
			simulationRankedVariation.setPricedate(priceDate);
			simulationRankedVariation.setVariat(variat);
			simulationRankedVariation.setUpdDate(GenericTools.systemDate());
			simulationRankedVariation.setUpdType("U");
			log.debug("Simulation Ranked Variation updated - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Simulation Ranked Variation - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public void update(SimulationRankedVariation simRankVariation) throws DataNotValidException {
		try {
			SimulationRankedVariation simulationRankedVariation = findByPrimaryKey(simRankVariation.getPk().getInstrId(), simRankVariation.getPk().getNv(), simRankVariation.getPk().getNDaysPer(), simRankVariation.getPk().getRank(), simRankVariation.getPk().getVarType(), simRankVariation.getPk().getMode());
			simulationRankedVariation.setUpdDate(GenericTools.systemDate());
			simulationRankedVariation.setUpdType("U");
			log.debug("Simulation Ranked Variation updated - instrId: "+simRankVariation.getPk().getInstrId()+"; holding period: "+simRankVariation.getPk().getNv()+"; nDaysPer: "+simRankVariation.getPk().getNDaysPer()+"; rank: "+simRankVariation.getPk().getRank()+"; varType: "+simRankVariation.getPk().getVarType()+"; mode: "+simRankVariation.getPk().getMode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Simulation Ranked Variation - instrId: "+simRankVariation.getPk().getInstrId()+"; holding period: "+simRankVariation.getPk().getNv()+"; nDaysPer: "+simRankVariation.getPk().getNDaysPer()+"; rank: "+simRankVariation.getPk().getRank()+"; varType: "+simRankVariation.getPk().getVarType()+"; mode: "+simRankVariation.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public void remove(int instrId, int nv, int nDaysPer, int rank, String varType, int mode) throws DataNotValidException {
		try {
			SimulationRankedVariation simulationRankedVariation = findByPrimaryKey(instrId, nv, nDaysPer, rank, varType, mode);
			em.remove(simulationRankedVariation);
			log.debug("Simulation Ranked Variation removed - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Simulation Ranked Variation - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; rank: "+rank+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteSimRankedVarByInstrId");
			query.setParameter("instrId", instrId);
			query.setParameter("updUsr", userString());
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Ranked Variation removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Simulation Ranked Variations - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteSimRankedVarByEnabledInstrId");
			query.setParameter("divisCode", divisCode);
			query.setParameter("updUsr", userString());
			int result = query.executeUpdate();
			log.debug(result+" enabled Ranked Variation removed - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing enabled Simulation Ranked Variations - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public int removeByMode(int mode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteSimRankedVarByMode");
			query.setParameter("mode", mode);
			query.setParameter("updUsr", userString());
			int result = query.executeUpdate();
			log.debug(result+" Ranked Variation removed - mode: "+mode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Simulation Ranked Variations - mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
	
	public void remove(SimulationRankedVariation rankVariation) throws DataNotValidException {
		remove(rankVariation.getPk().getInstrId(), rankVariation.getPk().getNv(), rankVariation.getPk().getNDaysPer(), rankVariation.getPk().getRank(), rankVariation.getPk().getVarType(), rankVariation.getPk().getMode());
	}
	
	public int transferMode1inMode2() throws DataNotValidException {
		try {
			SimulationRankedVariation[] arrRankedVariation = fetchWithMode1();
			int i=0;
			for (SimulationRankedVariation rankedVar:arrRankedVariation) {
				SimulationRankedVariationPK pK = new SimulationRankedVariationPK();
				SimulationRankedVariation simulationRankedVariation = new SimulationRankedVariation();
				pK.setInstrId(rankedVar.getPk().getInstrId());
				pK.setNDaysPer(rankedVar.getPk().getNDaysPer());
				pK.setNv(rankedVar.getPk().getNv());
				pK.setRank(rankedVar.getPk().getRank());
				pK.setVarType(rankedVar.getPk().getVarType());
				pK.setMode(2);
				simulationRankedVariation.setPk(pK);
				simulationRankedVariation.setPricedate(rankedVar.getPricedate());
				simulationRankedVariation.setVariat(rankedVar.getVariat());
				store(simulationRankedVariation);
				i++;
			}
			log.debug((i+1)+" Simulation Ranked Variation transferrd from mode 1 to 2");
			return i+1;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring Simulation Ranked Variations from mode 1 to 2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}	
	}
}

