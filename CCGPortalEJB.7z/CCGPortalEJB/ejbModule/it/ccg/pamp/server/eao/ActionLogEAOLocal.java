package it.ccg.pamp.server.eao;
import java.util.List;

import it.ccg.pamp.server.entities.ActionLog;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface ActionLogEAOLocal {
	public void add(String actDesc, String note) throws DataNotValidException;
	public void add(String actDesc) throws DataNotValidException;
	//public void store(ActionLog actLog) throws DataNotValidException;
	public List<ActionLog> fetch() throws DataNotValidException;
}
