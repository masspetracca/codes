package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ApproveHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.properties.PropertiesEAOLocal;
import it.ccg.pamp.server.utils.MemberToSync;

import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ApproveHistoryEAO
 */
@Stateless
public class ApproveHistoryEAO implements ApproveHistoryEAOLocal {

	@EJB
	private PropertiesEAOLocal properties;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	public List<ApproveHistory> fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllApproveHistory");
    		List<ApproveHistory> approveHistoryList = query.getResultList();
    		return approveHistoryList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from the approve archive - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public ApproveHistory findByPrimaryKey(int approveId) throws DataNotValidException {
		try {
			ApproveHistory approveHistory = (ApproveHistory) em.find(ApproveHistory.class,approveId);
    		return approveHistory;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from the approve archive - approve id: "+approveId+"; - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public void store(String divisCode, Timestamp apprDate) throws DataNotValidException {
		try {
			String[] archiveTableList = properties.getPropertyMap().get("equityArchiveTableList").split(",");
			
			if (divisCode.equalsIgnoreCase("D")) {
				archiveTableList = properties.getPropertyMap().get("equityDerivativesArchiveTableList").split(",");
			}
			Query query = null;
			
			String selectMax = "";
			String integerArray = "{";
			String tableArray = "{";
			if (archiveTableList.length>0) {
				//eseguo la query sulla PMPX di ogni tabella ottenuta dal file properties
				for (String archiveTable:archiveTableList) {
					tableArray +=archiveTable+",";
					selectMax ="SELECT MAX(UPDID) FROM "+archiveTable+" WHERE UPPER(UPDUSR) != 'SYSTEM'";
					query =  em.createNativeQuery(selectMax,Integer.class);
					int currentMax = 0;
					if (query.getResultList().get(0)!=null) {
						currentMax = (Integer) query.getResultList().get(0);
					}
					integerArray+= currentMax+",";
				}
				
				tableArray = tableArray.substring(0,tableArray.length()-1);
				tableArray += "}";
				
				integerArray = integerArray.substring(0,integerArray.length()-1);
				integerArray += "}";
				
				//faccio la insert
				String strInsert = "INSERT INTO PMPTAPPRH (DIVISCODE, APPRDATE, ARCHIDVEC, ARCHTBLVEC) VALUES "+
								"('"+divisCode+"', '"+apprDate+"', '"+integerArray+"','"+tableArray+"')";
				
				query =  em.createNativeQuery(strInsert);
				query.executeUpdate();
				
				log.debug("Added new approve archive for division "+divisCode);
			} else {
				log.warn("No archive table list found on properties file");
			}
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding new approve archive for division "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}

}
