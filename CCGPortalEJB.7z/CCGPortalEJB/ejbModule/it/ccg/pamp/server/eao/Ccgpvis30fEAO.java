package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Ccgpvis30f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class Ccgpvis30fEAO
 */
@Stateless
public class Ccgpvis30fEAO implements  Ccgpvis30fEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	public Ccgpvis30f[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllCcgpvis30f");
    		List<Ccgpvis30f> ccgpvis30f = query.getResultList();
    		Ccgpvis30f[] arrCcgpvis30f = new Ccgpvis30f[ccgpvis30f.size()];
    		return ccgpvis30f.toArray(arrCcgpvis30f);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from CCGPVIS30F - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Ccgpvis30f[] findByV3class(String v3class) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCcgpvis30fByV3class");
    		query.setParameter("v3class", v3class);
    		List<Ccgpvis30f> ccgpvis30f = query.getResultList();
    		Ccgpvis30f[] arrCcgpvis30f = new Ccgpvis30f[ccgpvis30f.size()];
    		return ccgpvis30f.toArray(arrCcgpvis30f);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from CCGPVIS30F - v3class: "+v3class+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Ccgpvis30f findByPrimaryKey(String hSymbl, BigDecimal hExpir, BigDecimal hStrik, String hPc, long hDate) throws DataNotValidException {
		try {
		/*	Cpsrss1PK pK = new Cpsrss1PK();
			pK.setHSymbl(hSymbl);
			pK.setHExpir(hExpir.longValue());
			pK.setHStrik(hStrik.longValue());
			pK.setHPc(hPc);			
			pK.setHDate(hDate);
			Cpsrss1 cpsrss1 = (Cpsrss1) em.find(Cpsrss1.class,pK);*/
    		return null;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from CCGPVIS30F - hSymbl: "+hSymbl+"; hExpir: "+hExpir+"; hStrik: "+hStrik+"; hPc: "+hPc+"; hDate: "+hDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
}
