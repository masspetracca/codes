package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Tcoccyf00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface Tcoccyf00fEAOLocal {

	public List<Tcoccyf00f> fetch() throws DataNotValidException;
	public List<Tcoccyf00f> findAfterDateByBlomCode(long priceDate, String currCode) throws DataNotValidException;
	public Tcoccyf00f findByPrimaryKey(long priceDate, String currCode) throws DataNotValidException;
	
}
