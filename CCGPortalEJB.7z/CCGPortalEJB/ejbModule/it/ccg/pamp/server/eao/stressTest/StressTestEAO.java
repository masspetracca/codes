package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.eao.CalendarEAOLocal;
import it.ccg.pamp.server.entities.Calendar;
import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPricePK;
import it.ccg.pamp.server.entities.stressTest.StressTestSetup;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.ejb.EJB;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StressTestEAO
 */
@Stateless
@SuppressWarnings("unchecked")
public class StressTestEAO implements  StressTestEAOLocal {

	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@EJB
	private StressTestSetupEAOLocal stSetupEAO;
	@EJB
	private CalendarEAOLocal calendarEAO;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	public List<StressTest> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllStressTest");
    		List<StressTest> stressTestList = query.getResultList();
    		return stressTestList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress tests - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public StressTest findByPrimaryKey(int stId) throws DataNotValidException {
		try {
			StressTest stressTest = (StressTest) em.find(StressTest.class,stId);
    		return stressTest;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test - stId: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int createAndReturnStressTestId(String divisCode, String launchMode) throws DataNotValidException {
		
		String strMode = "automatically";
		
		if (launchMode.equalsIgnoreCase("M")) {
			strMode = "manually";
		}
		
		
		String[] market = new String[] {"MTA","VIE"};
		String instrType = "A";
		
		try {
			//mi prendo dal calendario la data di mercato immediatamente precedente a oggi
			Calendar cal = calendarEAO.getPreviousCalendarDateByDayAndMarketCode(GenericTools.systemDateMidNight(), market, 1);
			
			StressTest st = new StressTest();
			
			// stringa price of settata a default sull'ultima data di calendario disponibile
			String priceOf = GenericTools.shortDateFormat(cal.getPk().getDate());
			
			// inizializzo oggetto setup
			StressTestSetup stSetup = new StressTestSetup();
			
			boolean foundTrue = false;
			
			//caso bond
			if (divisCode.equalsIgnoreCase("O")) {
				market = new String[] {"MTS"};
				String[] bondInstrTypeArr = new String[] {/*"BTPi",*/"RET","GOVIES"};
				
				Timestamp appoLstHpdDate = new Timestamp(new GregorianCalendar(1900,0,1).getTimeInMillis());
				
				// ciclo sui bond type x vedere se almeno uno ha hist upd date a TRUE
				for (String bondInstrType:bondInstrTypeArr) {
					stSetup = stSetupEAO.findByPrimaryKey(bondInstrType);
					
					
					
					// se c'� almeno un true mi fermo e setto come data di stress l'ultima disponibile
					if (stSetup.getHistUpdLst().equalsIgnoreCase("T")) {
						st.setLstHistDat(cal.getPk().getDate());
						foundTrue = true;
						break;
					} else {
						// altrimenti via via che scorro mi tengo la data pi� recente tra tutti i false
						if (stSetup.getHistUpdDay().compareTo(appoLstHpdDate)==1)
							appoLstHpdDate = stSetup.getHistUpdDay();
					}
				}
				
				if (!foundTrue) {
					st.setLstHistDat(appoLstHpdDate);
					priceOf = GenericTools.shortDateFormat(appoLstHpdDate);
				} else {
					st.setLstHistDat(cal.getPk().getDate());
				}
				
			} else {
				//caso equity
				stSetup = stSetupEAO.findByPrimaryKey(instrType);
				
				//se il flag sull'ultima data disponibile � false allora utilizzo la data scelta per il test
				if (stSetup.getHistUpdLst().equalsIgnoreCase("F")) {
					priceOf = GenericTools.shortDateFormat(stSetupEAO.findByPrimaryKey(instrType).getHistUpdDay());
					st.setLstHistDat(stSetupEAO.findByPrimaryKey(instrType).getHistUpdDay());
				} else {
					st.setLstHistDat(cal.getPk().getDate());
				}
			}
			
			
			
			
			st.setNote("Stress test "+strMode+" executed on "+GenericTools.shortSysDateFormat()+" considering hist. series ending on "+priceOf);
			
			st.setDivisCode(divisCode);
			st.setStatus("T");
			
			this.store(st);
			
			st = this.findStressTestOrderByStId();
			
			return st.getStId(); 
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error starting new Stress Test - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public StressTest findStressTestOrderByStId() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestOrderByLastStId");
    		List<StressTest> stressTestList = query.getResultList();
    		
    		return stressTestList.get(0);
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress tests - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(String note, Timestamp lstHistDat, String divisCode) throws DataNotValidException {
		
		try {
			StressTest stressTest = new StressTest();
			
			stressTest.setNote("Stress test executed on "+GenericTools.systemDate().toString().substring(0,19));
			stressTest.setLstHistDat(lstHistDat);
			stressTest.setUpdType(updType);
			stressTest.setUpdDate(GenericTools.systemDate());
			stressTest.setUpdUsr(userString());
			
			em.persist(stressTest);
			userLog.debug("Added new stress test");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(StressTest stressTest) throws DataNotValidException {
		
		try {
			stressTest.setUpdType(updType);
			stressTest.setUpdDate(GenericTools.systemDate());
			stressTest.setUpdUsr(userString());
			em.persist(stressTest);
			userLog.debug("Added new stress test");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int stId, Timestamp lstHistDat, String note, String divisCode) throws DataNotValidException {
		
		try {
			StressTest stressTest = this.findByPrimaryKey(stId);
			
			stressTest.setNote(note);
			stressTest.setLstHistDat(lstHistDat);
			stressTest.setUpdType("C");
			stressTest.setUpdDate(GenericTools.systemDate());
			stressTest.setUpdUsr(userString());
			
			em.persist(stressTest);
			userLog.debug("Updated stress test - stress test id: "+stId+"; note: "+note);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stress test - stress test id: "+stId+"; note: "+note+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void renameStressTest() throws DataNotValidException {
		
		try {
			List<StressTest> stressTestList = this.fetch();
			
			String oldNote = "";
			String newNote = "";
			
			for (StressTest stressTest:stressTestList) {
				
				if (stressTest.getNote().indexOf(".")>0) {
					newNote = stressTest.getNote().substring(0,stressTest.getNote().indexOf("."));
					newNote = newNote.replaceAll("Stress test of", "Stress test executed on");
					stressTest.setNote(newNote);
				}
			}
			/*stressTest.setUpdType("C");
			stressTest.setUpdDate(GenericTools.systemDate());
			stressTest.setUpdUsr(userString());
			
			em.persist(stressTest);
			userLog.debug("Updated stress test - stress test id: "+stId+"; note: "+note);*/
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error renaming stress test - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(StressTest stressTest) throws DataNotValidException {
		
		try {
			userLog.debug("Updated stress test - stress test id: "+stressTest.getStId()+"; note: "+stressTest.getNote());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stress test - stress test id: "+stressTest.getStId()+"; note: "+stressTest.getNote()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int stId) throws DataNotValidException {
		try {
			StressTest stressTest = this.findByPrimaryKey(stId);
			em.remove(stressTest);
			userLog.debug("Stress test removed - stress test id: "+stId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test - stress test id: "+stId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(StressTest stressTest) throws DataNotValidException {
		this.remove(stressTest.getStId());
	}

}
