package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.IndexWeight;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;
import javax.persistence.Query;

@Local
public interface IndexWeightEAOLocal {
	
	public List<IndexWeight> fetch() throws DataNotValidException;
	
	public IndexWeight findByPrimaryKey(int idxId,int instrId) throws DataNotValidException;
	
	public List<IndexWeight> findIndexComponents(int idxId) throws DataNotValidException;
	
	public List<IndexWeight> findIndexByInstrId(int instrId) throws DataNotValidException;
	
	public void add(int idxId,int instrId, Timestamp date, long dividend, long outshare) throws DataNotValidException;
	
	public void store(IndexWeight idxWeight) throws DataNotValidException;
	
	public void update(int idxId,int instrId, Timestamp date, long dividend, long outshare) throws DataNotValidException;
	
	public void update(IndexWeight idxWeight) throws DataNotValidException;
	
	public void remove(int idxId, int instrId) throws DataNotValidException;
	
	public void remove(IndexWeight idxWeight) throws DataNotValidException;
	
	public int removeByIndexId(int idxId) throws DataNotValidException;
	
}
