package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.DerivativesHistoricalPrice;
import it.ccg.pamp.server.entities.HistoricalPrices;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.ejb.Local;

@Local
public interface DerivativesHistoricalPriceEAOLocal {
	
	public DerivativesHistoricalPrice[] fetch() throws DataNotValidException;
	
	public DerivativesHistoricalPrice findByPrimaryKey(int instrId, Timestamp priceDate, String pc, BigDecimal strike, int expiry, String code) throws DataNotValidException;
	
	public DerivativesHistoricalPrice[] findByInstrId(int instrId) throws DataNotValidException;
	
	public DerivativesHistoricalPrice[] findByInstrIdAndPc(int instrId, String pc) throws DataNotValidException;
	
	public DerivativesHistoricalPrice[] findByInstrIdAfterDate(int instrId, Timestamp priceDate) throws DataNotValidException;
	
	public DerivativesHistoricalPrice[] findByInstrIdAndDate(int instrId, Timestamp lastDate) throws DataNotValidException;
	
	public DerivativesHistoricalPrice[] findFutureByInstrIdAndDate(int instrId, Timestamp lastDate) throws DataNotValidException; 
	
	public DerivativesHistoricalPrice[] findOptionByInstrIdAndDate(int instrId, Timestamp lastDate) throws DataNotValidException; 
	
	public int getTimeWindow(int instrId, Timestamp firstDate, Timestamp lastDate) throws DataNotValidException;
	
	public DerivativesHistoricalPrice findBeforeDate(int instrId, Timestamp priceDate) throws DataNotValidException;
	
	public DerivativesHistoricalPrice findLastDateByInstrument(Instrument instr) throws DataNotValidException;
	
	public void add(int instrId, Timestamp priceDate, String pc, BigDecimal strike, int expiry, String code, String status, BigDecimal closePr, BigDecimal impVola) throws DataNotValidException;
	
	public void store(DerivativesHistoricalPrice derivativesHistoricalPrice) throws DataNotValidException;
	//public void restore(int updId) throws DataNotValidException;
	
	public void update(int instrId, Timestamp priceDate, String pc, BigDecimal strike, int expiry, String code, String status, BigDecimal closePr, BigDecimal impVola) throws DataNotValidException; 
	
	public void update(DerivativesHistoricalPrice derivativesHP) throws DataNotValidException;
	
	public void remove(int instrId, Timestamp priceDate, String pc, BigDecimal strike, int expiry, String code) throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
	public int removeByInstrIdAndPc(int instrId, String pc) throws DataNotValidException;
	
	public void remove(DerivativesHistoricalPrice derivativesHP) throws DataNotValidException;
	//public void backup(DerivativesHistoricalPrice derHistPrices) throws DataNotValidException;
}
