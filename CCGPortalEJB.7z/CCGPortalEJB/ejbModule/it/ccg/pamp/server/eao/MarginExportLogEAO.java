package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.MarginExportLog;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

@Stateless
public class MarginExportLogEAO implements MarginExportLogEAOLocal {

	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
    public List<MarginExportLog> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllMarginExportLog");
    		List<MarginExportLog> marginExportLogList = query.getResultList();
    		if (marginExportLogList.size()>0) {
    			return marginExportLogList;
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Margin Export log table - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
    
    public void store(MarginExportLog marginExportLog) throws DataNotValidException {
		try {
    		em.persist(marginExportLog);
    		log.debug("Added new log for margin params export on RE System - execution date: "
    				+GenericTools.shortDateFormat(GenericTools.convertDateFromIntToTimestamp((int)marginExportLog.getpK().getExportDate()))+"; "+
    				"execution time: "+marginExportLog.getpK().getExportDate());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding Margin export log - execution date: "
    				+GenericTools.shortDateFormat(GenericTools.convertDateFromIntToTimestamp((int)marginExportLog.getpK().getExportDate()))+"; "+
    				"execution time: "+marginExportLog.getpK().getExportDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
    
    public void upsert(MarginExportLog marginExportLog) throws DataNotValidException {
		if (this.fetch()!=null) {
			MarginExportLog record = this.fetch().get(0);
    		em.remove(record);
    	} 
    	// altrimenti scrivo come se fosse nuovo
    	this.store(marginExportLog);
    	
    }
}
