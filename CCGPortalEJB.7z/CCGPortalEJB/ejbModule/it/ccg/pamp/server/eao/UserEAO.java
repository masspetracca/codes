package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.User;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class UserEAO
 */
@Stateless
public class UserEAO implements  UserEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public User[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllUsers");
    		List<User> user = query.getResultList();
    		User[] arrUser = new User[user.size()];
    		return user.toArray(arrUser);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching users - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public User findByPrimaryKey(String userName) throws DataNotValidException {
		try {
			User user = (User) em.find(User.class,userName);
    		return user;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching user - userName: "+userName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public LinkedHashMap<String,String> findUserInfoMap(String userName) throws DataNotValidException {
		
		User user = this.findByPrimaryKey(userName);
		
		LinkedHashMap<String,String> userMap = new LinkedHashMap<String, String>();
		
		if (user!=null) {
			
			userMap.put("USERNAME", user.getUserName());
			userMap.put("NAME", user.getName());
			userMap.put("SURNAME", user.getSurName());
			userMap.put("PHONENUMB", user.getPhoneNumb());
			userMap.put("EMAIL", user.getEmail());
			userMap.put("NOTIFY", user.getNotify());
			userMap.put("USERDESC", user.getUserDesc());
		}
		
		return userMap;
	}
	

	public User findOrCreateByPrimaryKey(String userName) throws DataNotValidException {
		try {
			User user = (User) em.find(User.class,userName);
    		if (user!=null) {
    			return user;
    		} else {
    			createDefaultUser(userName);
    			return findByPrimaryKey(userName);
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching user - userName: "+userName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public String getUserFullName(String userName) throws DataNotValidException {
		try {
			User user = (User) em.find(User.class,userName);
    		String fullName = user.getName()+" "+user.getSurName();
			return fullName;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching user - userName: "+userName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
		
	
	public void add(String userName, String name, String surName, String phoneNumb, String email, String notify, String userDesc) throws DataNotValidException {
		
		try {
			User user = new User();
			user.setUserName(userName);
			user.setName(name);
			user.setSurName(surName);
			user.setPhoneNumb(phoneNumb);
			user.setEmail(email);
			user.setNotify(notify);
			user.setUserDesc(userDesc);
			user.setUpdDate(GenericTools.systemDate());
			user.setUpdType(updType);
			user.setUpdUsr(userString());
			em.persist(user);
			log.debug("Added new user - userName: "+userName);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding user - userName: "+userName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void createDefaultUser(String userName) throws DataNotValidException {
		
		try {
			User user = new User();
			user.setUserName(userName);
			user.setName("Nome");
			user.setSurName("Cognome");
			user.setPhoneNumb(null);
			user.setEmail(userName+"@email.com");
			user.setNotify("F");
			user.setUserDesc(null);
			user.setUpdDate(GenericTools.systemDate());
			user.setUpdType(updType);
			user.setUpdUsr(userString());
			em.persist(user);
			log.debug("Added new default user - userName: "+userName);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding default user - userName: "+userName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(User user) throws DataNotValidException {
		try {
			user.setUpdDate(GenericTools.systemDate());
			user.setUpdType(updType);
			user.setUpdUsr(userString());
			em.persist(user);
			log.debug("Added new user - userName: "+user.getUserName());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new user - userName: "+user.getUserName()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void updateUserNotifyToTrue(String userName) throws DataNotValidException {
		try {
			User user = findByPrimaryKey(userName);
			user.setNotify("T");
			user.setUpdDate(GenericTools.systemDate());
			user.setUpdType("U");
			user.setUpdUsr(userString());
			log.debug("Updated notify to true for user "+userName);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating user - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void updateUserNotifyToFalse(String userName) throws DataNotValidException {
		try {
			User user = findByPrimaryKey(userName);
			user.setNotify("F");
			user.setUpdDate(GenericTools.systemDate());
			user.setUpdType("U");
			user.setUpdUsr(userString());
			log.debug("Updated notify to true for user "+userName);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating user "+userName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(String userName, String name, String surName, String phoneNumb, String email, String notify, String userDesc) throws DataNotValidException {
		
		try {
			User user = findByPrimaryKey(userName);
			user.setName(name);
			user.setSurName(surName);
			user.setPhoneNumb(phoneNumb);
			user.setEmail(email);
			user.setNotify(notify);
			user.setUserDesc(userDesc);
			user.setUpdDate(GenericTools.systemDate());
			user.setUpdType("U");
			user.setUpdUsr(userString());
			log.debug("Updated user - userName: "+userName);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error user - userName: "+userName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void updateUserFromWeb(LinkedHashMap<String,String> userValueMap, String userName) throws DataNotValidException {
		
		String name = userValueMap.get("NAME");
		String surname = userValueMap.get("SURNAME");
		String email = userValueMap.get("EMAIL");
		String notify = userValueMap.get("NOTIFY");
		String desc = userValueMap.get("USERDESC");
		String phone = userValueMap.get("PHONENUMB");
			
		this.update(userName, name, surname, phone, email, notify, desc);
	}
	
	public void update(User user) throws DataNotValidException {
		try {
			log.debug("Updated user - userName: "+user.getUserName());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating user - userName: "+user.getUserName()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(String userName) throws DataNotValidException {
		try {
			User user = findByPrimaryKey(userName);
			em.remove(user);
			log.debug("Removed user - userName: "+userName);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing user - userName: "+userName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(User user) throws DataNotValidException {
		remove(user.getUserName());
	}
}
