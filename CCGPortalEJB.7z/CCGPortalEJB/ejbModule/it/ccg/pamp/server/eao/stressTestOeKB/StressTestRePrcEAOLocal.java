package it.ccg.pamp.server.eao.stressTestOeKB;
import java.sql.Timestamp;

import it.ccg.pamp.server.entities.IntracsLog;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface StressTestRePrcEAOLocal {

	public void cloneClassTable() throws DataNotValidException;
	
	public void startReStressTestProcedure(Timestamp stressTestDate, int stId, String scenario) throws DataNotValidException;
	
	public void writeLogProcedure(IntracsLog log) throws DataNotValidException;
	
}
