package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Cgcls00f;
import it.ccg.pamp.server.entities.Cgcls00fPK;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.ClassTableChecks;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class Cgcls00fEAO
 */
@Stateless
//@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class Cgcls00fEAO implements  Cgcls00fEAOLocal {

	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	public Cgcls00f[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllCgcls00f");
    		List<Cgcls00f> cgcls00f = query.getResultList();
    		Cgcls00f[] arrCgcls00f = new Cgcls00f[cgcls00f.size()];
    		return cgcls00f.toArray(arrCgcls00f);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	public Cgcls00f[] getCGCNotinMarHis() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCGCNotinMarHis");
    		query.setParameter("systemDate", systemDate());
    		List<Cgcls00f> cgcls00fList = query.getResultList();
    		Cgcls00f[] arrCgcls00f = new Cgcls00f[cgcls00fList.size()];
    		return cgcls00fList.toArray(arrCgcls00f);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Cgcls00f[] findOeKbCashByClassAndLastDate(String cClass, long lastDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("findOeKbCashByClassAndLastDate");
    		query.setParameter("cClass", cClass);
    		query.setParameter("lastDate", new BigDecimal(lastDate));
    		List<Cgcls00f> cgcls00f = query.getResultList();
    		Cgcls00f[] arrCgcls00f = new Cgcls00f[cgcls00f.size()];
    		return cgcls00f.toArray(arrCgcls00f);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - cClass: "+cClass+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Cgcls00f[] findByCClass(String cClass) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCgcls00fByCClass");
    		query.setParameter("cClass", cClass);
    		List<Cgcls00f> cgcls00f = query.getResultList();
    		Cgcls00f[] arrCgcls00f = new Cgcls00f[cgcls00f.size()];
    		return cgcls00f.toArray(arrCgcls00f);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - cClass: "+cClass+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Cgcls00f[] findByCofCod(String cofCod) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCgcls00fByCofCod");
    		query.setParameter("cofCod", cofCod);
    		List<Cgcls00f> cgcls00f = query.getResultList();
    		Cgcls00f[] arrCgcls00f = new Cgcls00f[cgcls00f.size()];
    		return cgcls00f.toArray(arrCgcls00f);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - cofCod: "+cofCod+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public BigDecimal getMaxChangeDate() throws DataNotValidException {
		Query query = null;
		
		
		BigDecimal maxDate = new BigDecimal(19000101);
		
    	try {
			String sqlSelectString = "SELECT MAX(CCHGDT) FROM CGCLS00F";
			
			query =  em.createNativeQuery(sqlSelectString,BigDecimal.class);
			List<BigDecimal> lastChangeDate = query.getResultList();

			if (lastChangeDate.size()>0 && lastChangeDate.get(0)!=null) {
				maxDate = lastChangeDate.get(0);
			}
			
			return maxDate;
			
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching maximum last change date from Risk Engine Cgclss00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public BigDecimal getPriceSum() throws DataNotValidException {
		Query query = null;
		
		
		BigDecimal maxDate = new BigDecimal(0);
		
    	try {
			String sqlSelectString = "SELECT SUM(CUICLP) FROM CGCLS00F";
			
			query =  em.createNativeQuery(sqlSelectString,BigDecimal.class);
			List<BigDecimal> lastChangeDate = query.getResultList();

			if (lastChangeDate.size()>0 && lastChangeDate.get(0)!=null) {
				maxDate = lastChangeDate.get(0);
			}
			
			return maxDate;
			
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last price sum from Risk Engine Cgclss00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	} 
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public ClassTableChecks getInfoToCheck() throws DataNotValidException {
		Query query = null;
		
		
		ClassTableChecks checkList = null;
		
    	try {
    		
    		String sqlSelectString = "SELECT MAX(CCHGDT) AS MAXCHGDATECHECK,";
    		sqlSelectString+="SUM(LENGTH(TRIM(CGROUP)) * ROW_NUMBER() OVER()) AS GROUPCHECK,";
    		sqlSelectString+="SUM((ROW_NUMBER() OVER()) * CUICLP) AS PRICECHECK,";
    		sqlSelectString+="SUM((ROW_NUMBER() OVER()) * CMRGNI) AS MARGINCHECK ";  
    		sqlSelectString+="FROM CGCLS00F";
    		
			query =  em.createNativeQuery(sqlSelectString,ClassTableChecks.class);
			List<ClassTableChecks> classTableChecks = query.getResultList();
			
			if (classTableChecks.size()>0 && classTableChecks.get(0)!=null) {
				checkList = classTableChecks.get(0);
			}
			
			return checkList;
			
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching consinstency checks from Risk Engine Cgclss00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<Cgcls00f> findByCofCod(List<String> cofCodList) throws DataNotValidException {
		Query query = null;
    	String cofCodStr = "";
    	for (String cofCod:cofCodList) {
    		cofCodStr += cofCod+", ";
    	}
    	
    	cofCodStr = cofCodStr.substring(0, cofCodStr.length()-1);
    	
		try {
    		query = em.createNamedQuery("getCgcls00fByCofCodList");
    		query.setParameter("cofCodList", cofCodList);
    		List<Cgcls00f> cgcls00fList = query.getResultList();
    		return cgcls00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - cofCod: "+cofCodStr+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<Cgcls00f> reCgcList() throws DataNotValidException {
	
		Query query = null;
    	
		try {
			String columnList = "CCLASS, COFCOD, CEXCH1, CMKT1, CEXCH2, CMKT2, CEXCH3, CMKT3, CGROUP, CCORR, CUISYM, CUCUSP, CUICLP, CUIPCL, CPTYPE, CDESC, CMINRT, CVAT, CVINC, CLPRES, CNSV, COXPTM, CSPRES, CSERS, CNOSER, ";
			columnList+= "CASSI, CMRGNI, CCUR, CDELVR, CSETYP, CMULTF, CPMULT, CNSYM, CEFFDT, CPCB, CSTRKA, CPOSA, CSTRKC, CEXDT1, CDIV1, CEXDT2, CDIV2, CEXDT3, CDIV3, CEXDT4, CDIV4, COPTYP, COPSTY, CODAYS, COSEDT, COPEDT, ";
			columnList+= "CAEXC, CAEXF, CAEXMM, COPINT, CLIMIT, CEXLIM, CMINFL, CBEGTM, CENDTM, CENDLT, CTNDLY, CADDAT, CCHGDT, CPRCDT, CPYCOL, CINDAT, CPRTUC, CBLK12, CPLIMA, CELIM, CELIMA, CSCURR, CMITYP, CLEAP, CFVOLT, CEXTKEY";
			
			
			String sqlInsert = "SELECT "+columnList+" FROM CGCLS00F";
			
			query = em.createNativeQuery(sqlInsert,Cgcls00f.class);
			List<Cgcls00f> cgcls00fList = query.getResultList();
    		
			return cgcls00fList;
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error synchronizing records from PAMP Cgclss00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Cgcls00f> getCgcls00fForSync() throws DataNotValidException {
		Query query = null;
    	    	
    	try {
    		query = em.createNamedQuery("getCgcls00fForSync");
    		List<Cgcls00f> cgcls00fList = query.getResultList();
    		return cgcls00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching cash data from Cgcls00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Cgcls00f getREInstrumentsForOeKBMarginExport(String cClass/*, String cpType*/) throws DataNotValidException {
		Query query = null;
    	    	
    	try {
    		query = em.createNamedQuery("getREInstrumentsForOeKBMarginExport");
    		query.setParameter("cClass",cClass);
    		/*query.setParameter("cpType",cpType);*/
    		
    		List<Cgcls00f> cgcls00fList = query.getResultList();
    		
    		if (cgcls00fList.size()>0) {
    			return cgcls00fList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching cash data from Cgcls00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Cgcls00f findByPrimaryKey(String cClass, String cofCod) throws DataNotValidException {
		try {
			Cgcls00fPK pK = new Cgcls00fPK();
			pK.setCclass(cClass);			
			pK.setCofCod(cofCod);
			Cgcls00f cgcls00f = (Cgcls00f) em.find(Cgcls00f.class,pK);
    		return cgcls00f;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - cClass: "+cClass+"; cofCode: "+cofCod+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public void update(String cClass, String cofCod, BigDecimal propMar, BigDecimal propMinMar) throws DataNotValidException {
		try {
			Cgcls00f cgcls00f = findByPrimaryKey(cClass, cofCod);
			cgcls00f.setCmrgni(propMar);
			cgcls00f.setCminrt(propMinMar);
			log.debug("Cgcls00f updated - cClass: "+cClass+"; cofCode: "+cofCod+"; new Margin: "+propMar+"; new MinMar: "+propMinMar);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Cgcls00f - cClass: "+cClass+"; cofCode: "+cofCod+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public void update(String cClass, String cofCod, BigDecimal propMar) throws DataNotValidException {
		try {
			Cgcls00f cgcls00f = findByPrimaryKey(cClass, cofCod);
			cgcls00f.setCmrgni(propMar);
			log.debug("Cgcls00f updated - cClass: "+cClass+"; cofCode: "+cofCod+"; new Margin: "+propMar);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Cgcls00f - cClass: "+cClass+"; cofCode: "+cofCod+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public void updateCashMinMar(String cClass, String cofCod, BigDecimal propMinMar) throws DataNotValidException {
		try {
			Cgcls00f cgcls00f = findByPrimaryKey(cClass, cofCod);
			cgcls00f.setCminrt(propMinMar);
			log.debug("Cgcls00f updated - cClass: "+cClass+"; cofCode: "+cofCod+"; new Minimum Margin: "+propMinMar);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Cgcls00f - cClass: "+cClass+"; cofCode: "+cofCod+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
}
