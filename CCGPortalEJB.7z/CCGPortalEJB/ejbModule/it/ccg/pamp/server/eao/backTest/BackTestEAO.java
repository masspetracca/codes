package it.ccg.pamp.server.eao.backTest;

import it.ccg.pamp.server.eao.stressTest.StressTestSetupEAOLocal;
import it.ccg.pamp.server.entities.backTest.BackTest;
import it.ccg.pamp.server.entities.stressTest.StressTest;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BackTestEAO
 */
@Stateless
public class BackTestEAO implements BackTestEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	
	@EJB
	private BackTestSetupEAOLocal btSetupeEAO;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}

	public String userString = "System";
	public String updType = "C";
	
	
	public List<BackTest> fetchAllBackTest() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllBackTest");
    		List<BackTest> backTestList = query.getResultList();
    		return backTestList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test list - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<BackTest> fetchBackTestByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBackTestByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<BackTest> backTestList = query.getResultList();
    		return backTestList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test list - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BackTest findByPrimaryKey(int btId) throws DataNotValidException {
		try {
    		BackTest backTest = (BackTest) em.find(BackTest.class,btId);
    		return backTest;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back test - backTestId: "+btId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BackTest findBackTestOrderByStId() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBackTestOrderByLastBtId");
    		List<BackTest> backTestList = query.getResultList();
    		
    		return backTestList.get(0);
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching back tests - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int createAndReturnBackTestId(String divisCode/*, Timestamp lstHistDat*/) throws DataNotValidException {
		try {
			BackTest backTest = new BackTest();
			
			backTest.setLstHistDat(btSetupeEAO.fetchBackTestWithMaxDate(divisCode).getHistUpdDay());
			backTest.setNote("Back test executed on "+GenericTools.systemDate().toString().substring(0,19));
			backTest.setDivisCode(divisCode);
			backTest.setStatus("T");
			this.store(backTest);
			backTest = this.findBackTestOrderByStId();
			return backTest.getBtId(); 
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Instrument - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(String divisCode, Timestamp lstHistDat, String note, String status) throws DataNotValidException {
		
		try {
			BackTest backTest = new BackTest();
			
			backTest.setDivisCode(divisCode);
			backTest.setLstHistDat(lstHistDat);
			backTest.setNote(note);
			backTest.setStatus(status);
			
			backTest.setUpdDate(GenericTools.systemDate());
			backTest.setUpdType("C");
			backTest.setUpdUsr(userString());
			
			em.persist(backTest);
			
			log.debug("Added new back test");
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new back test - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	public void store(BackTest backTest) throws DataNotValidException {
		
		try {
			
			backTest.setUpdDate(GenericTools.systemDate());
			backTest.setUpdType("C");
			backTest.setUpdUsr(userString());
			
			em.persist(backTest);
			
			log.debug("Added new back test");
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new back test - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	public void update(int btId, String divisCode, Timestamp lstHistDat, String note, String status) throws DataNotValidException {
		
		try {
			BackTest backTest = this.findByPrimaryKey(btId);
			
			backTest.setDivisCode(divisCode);
			backTest.setLstHistDat(lstHistDat);
			backTest.setNote(note);
			backTest.setStatus(status);
			
			backTest.setUpdDate(GenericTools.systemDate());
			backTest.setUpdType("U");
			backTest.setUpdUsr(userString());
			
			log.debug("Updated back test - backTestId: "+btId);
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating back test - back test id: "+btId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	public void remove(int btId) throws DataNotValidException {
		
		try {
			BackTest backTest = this.findByPrimaryKey(btId);
			
			em.remove(backTest);
			
			log.debug("Removed back test - backTestId: "+btId);
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing back test - back test id: "+btId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	public void remove(BackTest backTest) throws DataNotValidException {
		
		this.remove(backTest.getBtId());
		
	}
	

}
