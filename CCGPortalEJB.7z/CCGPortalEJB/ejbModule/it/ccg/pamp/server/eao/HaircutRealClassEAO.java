package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.BondClass;
import it.ccg.pamp.server.entities.HaircutRealClass;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class HaircutRealClassEAO
 */
@Stateless
public class HaircutRealClassEAO implements HaircutRealClassEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public List<HaircutRealClass> fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllHaircutRealClass");
    		List<HaircutRealClass> haircutRealClassList = query.getResultList();
    		return haircutRealClassList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching haircut real classes - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HaircutRealClass findByPrimaryKey(int inc) throws DataNotValidException {
		try {
			HaircutRealClass haircutRealClass = (HaircutRealClass) em.find(HaircutRealClass.class,inc);
    		return haircutRealClass;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching haircut real class - inc: "+inc+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<HaircutRealClass> findEnabledHaircutRealClass() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllEnabledHaircutRealClass");
    		List<HaircutRealClass> haircutRealClassList = query.getResultList();
    		return haircutRealClassList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled haircut real classes - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<HaircutRealClass> findEnabledHaircutRealClassByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getEnabledHaircutRealClassByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<HaircutRealClass> haircutRealClassList = query.getResultList();
    		return haircutRealClassList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled haircut real classes - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<HaircutRealClass> findEnabledHaircutRealClassByClassId(int classId) throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getEnabledHaircutRealClassByClassId");
    		query.setParameter("classId", classId);
    		List<HaircutRealClass> haircutRealClassList = query.getResultList();
    		return haircutRealClassList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled haircut real classes - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	

	
	public void add(BigDecimal cap, String classDesc, int classId, String divisCode, BigDecimal floor, BigDecimal mult, String status, BigDecimal addend) throws DataNotValidException {
		
		String logString = "classId: "+classId+"; description: "+classDesc+"; floor: "+floor+"; mult: "+mult;
		
		try {
			HaircutRealClass haircutRealClass = new HaircutRealClass();
			
			haircutRealClass.setCap(cap);
			haircutRealClass.setClassDesc(classDesc);
			haircutRealClass.setClassId(classId);
			haircutRealClass.setDivisCode(divisCode);
			haircutRealClass.setFloor(floor);
			haircutRealClass.setMult(mult);
			haircutRealClass.setStatus(status);
			haircutRealClass.setAddend(addend);
			
			haircutRealClass.setUpdDate(GenericTools.systemDate());
			haircutRealClass.setUpdType(updType);
			haircutRealClass.setUpdUsr(userString());
			
			em.persist(haircutRealClass);
			log.debug("Added new haircut real class - "+logString);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Haircut real class - "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(HaircutRealClass haircutRealClass) throws DataNotValidException {
		
		String logString = "classId: "+haircutRealClass.getClassId()+"; description: "+haircutRealClass.getClassDesc()+"; floor: "+haircutRealClass.getFloor()+"; mult: "+haircutRealClass.getMult();
		
		try {
			haircutRealClass.setUpdDate(GenericTools.systemDate());
			haircutRealClass.setUpdType(updType);
			haircutRealClass.setUpdUsr(userString());
			
			em.persist(haircutRealClass);
			
			log.debug("Added new haircut real class - "+logString);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding new Haircut real class - "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int inc,BigDecimal cap, String classDesc, int classId, String divisCode, BigDecimal floor, BigDecimal mult, String status, BigDecimal addend) throws DataNotValidException {
		
		String logString = "classId: "+classId+"; description: "+classDesc+"; floor: "+floor+"; mult: "+mult;
		
		try {
			HaircutRealClass haircutRealClass = this.findByPrimaryKey(inc);
			
			haircutRealClass.setCap(cap);
			haircutRealClass.setClassDesc(classDesc);
			haircutRealClass.setClassId(classId);
			haircutRealClass.setDivisCode(divisCode);
			haircutRealClass.setFloor(floor);
			haircutRealClass.setMult(mult);
			haircutRealClass.setStatus(status);
			haircutRealClass.setAddend(addend);
			
			haircutRealClass.setUpdDate(GenericTools.systemDate());
			haircutRealClass.setUpdType("U");
			haircutRealClass.setUpdUsr(userString());
			
			log.debug("Haircut real class updated - "+logString);

		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Haircut real class - "+logString+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int inc) throws DataNotValidException {
		
		try {
			HaircutRealClass haircutRealClass = this.findByPrimaryKey(inc);
			
			String logString = "classId: "+haircutRealClass.getClassId()+"; description: "+haircutRealClass.getClassDesc()+"; floor: "+haircutRealClass.getFloor()+"; mult: "+haircutRealClass.getMult();
			
			em.remove(haircutRealClass);
			
			log.debug("Haircut real class removed - "+logString);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing haircut class - inc: "+inc+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
			
	public void remove(HaircutRealClass haircutRealClass) throws DataNotValidException {
		remove(haircutRealClass.getInc());
	}

}
