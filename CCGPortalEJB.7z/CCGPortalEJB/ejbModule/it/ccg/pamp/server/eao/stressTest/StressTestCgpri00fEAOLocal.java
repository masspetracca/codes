package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.stressTest.StressTestCgpri00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

import javax.ejb.Local;

@Local
public interface StressTestCgpri00fEAOLocal {
	
	public List<StressTestCgpri00f> fetch() throws DataNotValidException;
	
	public StressTestCgpri00f findByPrimaryKey (Date prDate, String prIsin) throws DataNotValidException;
	
	public void update(Date prDate, String prIsin, BigDecimal prPric) throws DataNotValidException;
	
	public void store(StressTestCgpri00f stressTestCgpri00f) throws DataNotValidException;
	
	public int removeAll() throws DataNotValidException;

}
