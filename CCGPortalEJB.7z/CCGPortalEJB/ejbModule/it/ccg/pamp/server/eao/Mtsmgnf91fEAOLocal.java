package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Mtsmgnf91f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;

@Local
public interface Mtsmgnf91fEAOLocal {
	
	public List<Mtsmgnf91f> fetch() throws DataNotValidException;
	
	public List<Mtsmgnf91f> getMtsmgnf91fNotinClTraHis() throws DataNotValidException;
	
	public Mtsmgnf91f findByPrimaryKey(int f91cdclass) throws DataNotValidException;
	
	public void update(int f91cdclass, BigDecimal f91intridp) throws DataNotValidException;
	
}
