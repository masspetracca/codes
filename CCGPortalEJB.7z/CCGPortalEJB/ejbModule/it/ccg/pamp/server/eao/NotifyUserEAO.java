package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.NotifyUser;
import it.ccg.pamp.server.entities.NotifyUserPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondToSync;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.UserToNotify;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class NotifyUserEAO
 */
@Stateless
public class NotifyUserEAO implements  NotifyUserEAOLocal {

	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	public NotifyUser[] fetch() throws DataNotValidException {
		Query query = null;
    	try {							
    		query = em.createNamedQuery("getAllNotUser");
    		List<NotifyUser> notifyUser = query.getResultList();
    		NotifyUser[] arrNotifyUser = new NotifyUser[notifyUser.size()];
    		return notifyUser.toArray(arrNotifyUser);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Notifies User - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public NotifyUser findByPrimaryKey(String user, int notifyId) throws DataNotValidException  {
		try {
			NotifyUserPK pK = new NotifyUserPK();
			pK.setUser(user);
			pK.setNotifyId(notifyId);
			NotifyUser notifyUser = (NotifyUser) em.find(NotifyUser.class,pK);
    		return notifyUser;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Notify User - user: "+user+"; notifyId: "+notifyId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public NotifyUser[] findByNotifyId(int notifyId) throws DataNotValidException {
		Query query = null;
    	try {
    			
    		
    		query = em.createNamedQuery("getNotUserById");
    		query.setParameter("notifyId", notifyId);
    		List<NotifyUser> notifyUser = query.getResultList();
    		NotifyUser[] arrNotifyUser = new NotifyUser[notifyUser.size()];
    		return notifyUser.toArray(arrNotifyUser);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Notify User - notifyId: "+notifyId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<UserToNotify> getUserToNotifyListByNotifyId(int notifyId) throws DataNotValidException {
		
		Query query = null;
		
		String sqlString = "SELECT U.USERNAME,U.EMAIL, U.NOTIFY FROM PMPTNOTUSR N "+
						"INNER JOIN PMPTUSER U "+
						"ON N.USERNAME = U.USERNAME "+
						"WHERE N.NOTIFYID = "+notifyId+" "+
						"AND NOTIFY IN ('T','E')";
		try {
			query =  em.createNativeQuery(sqlString,UserToNotify.class);
		}  catch (Exception e) {
			e.getStackTrace();
		}

		List<UserToNotify> userToNotifyList = query.getResultList();

		return userToNotifyList;
	}
	
	public List<UserToNotify> getUserToNotifyListByUserNameAndNotifyId(String[] userNameList, int notifyId) throws DataNotValidException {
		
		Query query = null;
		
		String strUserName = "";
		
		for (String userName:userNameList) {
			strUserName += "'"+userName+"',";
		}
		
		strUserName = strUserName.substring(0, strUserName.length()-1);
		
		String sqlString = "SELECT U.USERNAME,U.EMAIL, U.NOTIFY FROM PMPTNOTUSR N "+
						"INNER JOIN PMPTUSER U "+
						"ON N.USER = U.USERNAME "+
						"WHERE N.USER IN ("+strUserName+") AND N.NOTIFYID = "+notifyId+" "+
						"AND NOTIFY IN ('T','E')";
		try {
			query =  em.createNativeQuery(sqlString,UserToNotify.class);
		}  catch (Exception e) {
			e.getStackTrace();
		}

		List<UserToNotify> userToNotifyList = query.getResultList();

		return userToNotifyList;
	}
	
	
	
	
	public NotifyUser[] findByUser(String user) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getNotUserByUser");
    		query.setParameter("user", user);
    		List<NotifyUser> notifyUser = query.getResultList();
    		NotifyUser[] arrNotifyUser = new NotifyUser[notifyUser.size()];
    		return notifyUser.toArray(arrNotifyUser);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Notify User - user: "+user+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(String user, int notifyId) throws DataNotValidException {
			
		try {
			NotifyUser notifyUser = new NotifyUser();
			NotifyUserPK pK = new NotifyUserPK();
			pK.setUser(user);
			pK.setNotifyId(notifyId);
			notifyUser.setPk(pK);
			notifyUser.setUpdDate(GenericTools.systemDate());
			notifyUser.setUpdType(updType);
			notifyUser.setUpdUsr(userString());
			em.persist(notifyUser);
			log.debug("Added new Notify - user: "+user+"; notifyId: "+notifyId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Notify - user: "+user+"; notifyId: "+notifyId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(NotifyUser notifyUser) throws DataNotValidException {
		try {
			notifyUser.setUpdDate(GenericTools.systemDate());
			notifyUser.setUpdType(updType);
			notifyUser.setUpdUsr(userString());
			em.persist(notifyUser);
			log.debug("Added new Notify - user: "+notifyUser.getPk().getUser()+"; notifyId: "+notifyUser.getPk().getNotifyId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding Notify - user: "+notifyUser.getPk().getUser()+"; notifyId: "+notifyUser.getPk().getNotifyId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByUser(String user) throws DataNotValidException {
		try {	
			Query query = null;
			query = em.createNamedQuery("deleteNotUserByUser");
			query.setParameter("user", user);
			int result = query.executeUpdate();
			log.debug(result+" Notify User removed - user: "+user);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Notify User - user: "+user+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeById(int notifyId) throws DataNotValidException {
		try {	
			Query query = null;
			query = em.createNamedQuery("deleteNotUserById");
			query.setParameter("notifyId", notifyId);
			int result = query.executeUpdate();
			log.debug(result+" Notify User removed - notifyId: "+notifyId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Notify User - notifyId: "+notifyId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(String user, int notifyId) throws DataNotValidException {
		try {	
			NotifyUser notifyUser = findByPrimaryKey(user, notifyId);
			em.remove(notifyUser);
			log.debug("Removed Notify - user: "+user+"; notifyId: "+notifyId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Notify - user: "+user+"; notifyId: "+notifyId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(NotifyUser notifyUser) throws DataNotValidException {
		remove(notifyUser.getPk().getUser(),notifyUser.getPk().getNotifyId());
	}

}
