package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.InstrumentStatistic;
import it.ccg.pamp.server.entities.SimulationStatistics;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;

import javax.ejb.Local;

@Local
public interface SimulationStatisticsEAOLocal {
	public SimulationStatistics[] fetch() throws DataNotValidException ;
	public SimulationStatistics[] fetchWithMode1() throws DataNotValidException ;
	public SimulationStatistics findByPrimaryKey(int instrId, int nv, int nDaysPer, String varType, int mode) throws DataNotValidException ;
	
	public void add(int instrId, int nv, int nDaysPer, String varType, int mode, int active, BigDecimal stDev, BigDecimal average, BigDecimal asy, BigDecimal kurtosis,
			BigDecimal perf, BigDecimal perYear, BigDecimal nDays, BigDecimal volaDay, BigDecimal eventsIn, BigDecimal eventsOut,
			BigDecimal normMar, BigDecimal normMarCov, BigDecimal normMarSd, BigDecimal maxMargin, BigDecimal maxMarSd, BigDecimal maxMarCov, BigDecimal mathMar,
			BigDecimal mathMarSd, BigDecimal mathMarCov, BigDecimal minMar, BigDecimal minMarSd, BigDecimal minMarCov, BigDecimal aveMar, BigDecimal aveMarSd,
			BigDecimal aveMarCov, BigDecimal currMarSd, BigDecimal currMarCov) throws DataNotValidException ;
	
	public void store(SimulationStatistics simulationStatistics) throws DataNotValidException ;
	
	public void update(int instrId, int nv, int nDaysPer, String varType, int mode, int active, BigDecimal stDev, BigDecimal average, BigDecimal asy, BigDecimal kurtosis,
			BigDecimal perf, BigDecimal perYear, BigDecimal nDays, BigDecimal volaDay, BigDecimal eventsIn, BigDecimal eventsOut,
			BigDecimal normMar, BigDecimal normMarCov, BigDecimal normMarSd, BigDecimal maxMargin, BigDecimal maxMarSd, BigDecimal maxMarCov, BigDecimal mathMar,
			BigDecimal mathMarSd, BigDecimal mathMarCov, BigDecimal minMar, BigDecimal minMarSd, BigDecimal minMarCov, BigDecimal aveMar, BigDecimal aveMarSd,
			BigDecimal aveMarCov, BigDecimal currMarSd, BigDecimal currMarCov) throws DataNotValidException ;
	
	public void update(SimulationStatistics simulationStatistics) throws DataNotValidException ;
	
	public void remove(int instrId, int nv, int nDaysPer, String varType,int mode) throws DataNotValidException ;
	public int removeByInstrId(int instrId) throws DataNotValidException ;
	public int removeByMode(int mode) throws DataNotValidException ;
	public void remove(SimulationStatistics simulationStatistics) throws DataNotValidException ;
	
	public int transferMode1inMode2() throws DataNotValidException ;
}
