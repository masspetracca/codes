package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Setup;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class SetupEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class SetupEAO implements  SetupEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public Setup[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSetup");
    		List<Setup> setup = query.getResultList();
    		Setup[] arrSetup = new Setup[setup.size()];
    		return setup.toArray(arrSetup);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Setups - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public String marginSetup (Setup setup, MathContext mathC) {
				
		String marginSetup = "Minimum days to propose margin: "+setup.getHisMinMar()+", ";
		
		marginSetup += "Minimum change to propose margin: "+setup.getMarMinCh().round(mathC).doubleValue()+"%, ";
		
		marginSetup += "Extreme values for margins: chosen "+GenericTools.convertStringAcronymous(setup.getRealMarGt(), 4)+", "; 
				
		marginSetup += "Sign of values for margins: "+GenericTools.convertIntegerAcronymous(setup.getPosNegeVar(), 0)+", ";
		
		marginSetup += "Margin Rounding type: "+GenericTools.convertStringAcronymous(setup.getMarRoundTy(), 2)+", "; 
				
		marginSetup += "Margin rounding precision: "+setup.getMarRoundTv().round(mathC).doubleValue()+"%, ";
		
		marginSetup += "Cut margin if one year history: "+GenericTools.convertStringAcronymous(setup.getMarCutHis(), 0)+", ";
				
		marginSetup += "Cut margin if suspended: "+GenericTools.convertStringAcronymous(setup.getMarCutSusp(), 0)+", ";
		
		if (setup.getDivisCode().equalsIgnoreCase("D")) {
			marginSetup += "Minimum days to propose minimum margin: "+setup.getHisMinStr()+", ";
			
			marginSetup += "Minimum delta to propose the change of minimum margin: "+setup.getMinMinch().round(mathC).doubleValue()*100+"%, ";
			
			marginSetup += "Minimum margin rounding type: "+GenericTools.convertStringAcronymous(setup.getMinRoundTy(), 2)+", ";
					
			marginSetup += "Minimum margin rounding precision: "+setup.getMinRoundTv().round(mathC).doubleValue()+", ";
			
			marginSetup += "Min. perc. of tied derivative "+setup.getMarTiedMin().round(mathC).doubleValue()*100+"%, ";
			
			marginSetup += "Percent coeff. for minimum margin computation: "+setup.getMinMarPerc().round(mathC).doubleValue()*100+"%, ";
			
			marginSetup += "Minimum straddle delta to propose the change: "+setup.getStrMinCh().round(mathC).doubleValue()*100+"%, ";
			
			marginSetup += "Straddle rounding type: "+GenericTools.convertStringAcronymous(setup.getStrRoundTy(), 2)+", ";
						
			marginSetup += "Straddle rounding precision: "+setup.getStrRoundTv().round(mathC).doubleValue()+", ";;
			
			marginSetup += "Sign of straddle values: "+GenericTools.convertIntegerAcronymous(setup.getStrPoneVar(), 0)+", ";
			
			marginSetup += "Straddle correlation type: "+GenericTools.convertStringAcronymous(setup.getStrCorrTyp(), 3)+", ";
			
			marginSetup += "Straddle Nth extr. int. rates. var. to consider: "+GenericTools.convertIntegerAcronymous(setup.getStrExtrVar(),1)+", ";
			
			marginSetup += "Minimum days to propose straddle: "+setup.getHisMinStr()+", ";
		}
		
		if (setup.getDivisCode().equalsIgnoreCase("E")) {
			marginSetup += "ETF Minimum income to propose rettify: "+(setup.getEtfTh().round(mathC).doubleValue()*100)+"%, ";
		}
		
		return marginSetup.substring(0,marginSetup.length()-2);
	}
	
	public String groupSetup (Setup setup, MathContext mathC) {
		
		String groupSetup = "Minimum days to propose group: "+setup.getHisMinGr()+", ";
		
		groupSetup += "Threshold correlation to propose the group: "+setup.getGroupTh().round(mathC).doubleValue()*100+"%, ";
		
		groupSetup += "Correlation type: "+GenericTools.convertStringAcronymous(setup.getGrCorrType(), 3)+", "; 
							
		groupSetup += "Minimum group delta to propose the change: "+setup.getGrMinCh().round(mathC).doubleValue()*100+"%, ";
		
		groupSetup += "Rounding type: "+GenericTools.convertStringAcronymous(setup.getGrRoundTy(), 2)+", ";
				
		groupSetup += "Rounding precision: "+setup.getGrRoundTv().multiply(new BigDecimal(100)).round(mathC).doubleValue()+"%, ";

		return groupSetup.substring(0,groupSetup.length()-2);
	}
	
	public String setupString(String divisCode, String toPrint, boolean toWrite) throws DataNotValidException {
		Setup setup = findByPrimaryKey(divisCode);
		MathContext mathC = new MathContext(6);
		String setupString = "";
				
		if (divisCode.equals("E")) {
			setupString += "EQUITY CASH ";
		} else if (divisCode.equalsIgnoreCase("D")) {
			setupString += "EQUITY DERIVATIVES ";
		} else if (divisCode.equalsIgnoreCase("B")) {
			setupString += "BONDS ";
		} else if (divisCode.equalsIgnoreCase("X")) {
			setupString += "INDEX ";
		}
		else if (divisCode.equalsIgnoreCase("L")) {
			setupString += "ELECTRIC DERIVATIVES ";
		}
		
		String commonSetupString = "Historical first date to use: "+GenericTools.shortDateFormat(setup.getHisfDate())+", ";
		commonSetupString += "Historical last date to use: "+GenericTools.shortDateFormat(setup.getHislDate())+", ";
		
		commonSetupString += "Historical first date limit enabled: "+GenericTools.convertStringAcronymous(setup.getHisfDaten(), 0)+", ";
		commonSetupString += "Historical last date limit enabled: "+GenericTools.convertStringAcronymous(setup.getHislDaten(), 0)+", ";
				
		commonSetupString += "Historical volatility days: "+setup.getVolaPer()+", ";
		
		commonSetupString += "Variation type: "+GenericTools.convertStringAcronymous(setup.getVarType(), 1)+", ";
		
		if (toPrint.equalsIgnoreCase("M")) {
			setupString += "MARGIN COMPUTATION - ";
			setupString += commonSetupString + marginSetup(setup,mathC);
		} else if (toPrint.equalsIgnoreCase("G")) {
			setupString += "GROUPS COMPUTATION - ";
			setupString += commonSetupString + groupSetup(setup,mathC);
		} 
		
		if (setupString.length()>1000 && toWrite) {
			setupString = setupString.substring(0,995);
		}
		return setupString;
	}
	
	
	public String getMaxDate(String[] arrDivisCode) throws DataNotValidException {
		Query query = null;
		String strDivisCode = "";
		for (String divisCode:arrDivisCode) {
			strDivisCode += "'"+divisCode+"',";
		}
		strDivisCode = strDivisCode.substring(0,strDivisCode.length()-1);
		
		try {
    		query = em.createNativeQuery("SELECT MAX(HISLDATE) FROM PMPTSETUP WHERE DIVISCODE IN ("+strDivisCode+") AND  HISLDATEN = 'F'");
			
			Timestamp maxDate = (Timestamp) query.getSingleResult();
    		
    		if (maxDate==null) {
    			return GenericTools.shortSysDateFormat();
    		} else {
    			return maxDate.toString().substring(0,10);
    		}
    	    		
    	} catch (Exception e) {
    		
    		strDivisCode = strDivisCode.replaceAll("'","");
    		
    		DataNotValidException exc = new DataNotValidException("Error fetching max date for divisions "+strDivisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Setup findByPrimaryKey(String divisCode) throws DataNotValidException {
		try {
			Setup setup = (Setup) em.find(Setup.class,divisCode);
    		return setup;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Setup - divisCode: "+divisCode+" - "+e.getMessage()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public Setup findByPrimaryKeyNoTransaction(String divisCode) throws DataNotValidException {
		try {
			Setup setup = (Setup) em.find(Setup.class,divisCode);
    		return setup;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Setup - divisCode: "+divisCode+" - "+e.getMessage()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(String divisCode, Timestamp hisfDate,Timestamp hislDate,String hisfDaten, String hislDaten,int hisMinMar, int hisMinGr,String marRoundTy, BigDecimal marRoundTv, BigDecimal etfTh, BigDecimal marMinCh, String realMarGt, String varType, int volaPer, BigDecimal groupTh, String grRoundTy, BigDecimal grRoundTv, String grCorrType, int posNegeVar,
			BigDecimal grMinCh,BigDecimal strMinCh,String strRoundTy,BigDecimal strRoundTv,int strPoneVar, BigDecimal minMarPerc, int strExtrVar, int hisMinStr, BigDecimal minMinch, String minRoundTy, BigDecimal minRoundTv, String strCorrTyp, String marCutHis, String marCutSusp, BigDecimal marTiedMin) throws DataNotValidException {
		
		try {
			Setup setup = new Setup();
			setup.setDivisCode(divisCode);
			setup.setHisfDate(hisfDate);
			setup.setHislDate(hislDate);
			setup.setHisfDaten(hisfDaten);
			setup.setHislDaten(hislDaten);
			setup.setHisMinMar(hisMinMar);
			setup.setHisMinGr(hisMinGr);
			setup.setMarRoundTy(marRoundTy);
			setup.setMarRoundTv(marRoundTv);
			setup.setEtfTh(etfTh);
			setup.setMarMinCh(marMinCh);
			setup.setRealMarGt(realMarGt);
			setup.setVarType(varType);
			setup.setUpdType(updType);
			setup.setUpdDate(GenericTools.systemDate());
			setup.setUpdUsr(userString());
			setup.setVolaPer(volaPer);
			setup.setGroupTh(groupTh);
			setup.setGrRoundTy(grRoundTy);
			setup.setGrRoundTv(grRoundTv);
			setup.setGrCorrType(grCorrType);
			setup.setPosNegeVar(posNegeVar);
			setup.setGrMinCh(grMinCh);
			setup.setStrMinCh(strMinCh);
			setup.setStrRoundTy(strRoundTy);
			setup.setStrRoundTv(strRoundTv);
			setup.setStrPoneVar(strPoneVar);
			setup.setMinMarPerc(minMarPerc);
			setup.setStrExtrVar(strExtrVar);
			setup.setHisMinStr(hisMinStr);
			setup.setMinMinch(minMinch);
			setup.setMinRoundTy(minRoundTy);
			setup.setMinRoundTv(minRoundTv);
			setup.setStrCorrTyp(strCorrTyp);
			setup.setMarCutHis(marCutHis);
			setup.setMarCutSusp(marCutSusp);
			setup.setMarTiedMin(marTiedMin);
			em.persist(setup);
			log.debug("Added new Setup - divisCode: "+divisCode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Setup - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(Setup setup) throws DataNotValidException {
		try {
			setup.setUpdType(updType);
			setup.setUpdDate(GenericTools.systemDate());
			setup.setUpdUsr(userString());
			em.persist(setup);
			log.debug("Added new Setup - divisCode: "+setup.getDivisCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Setup - divisCode: "+setup.getDivisCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void updateMarginSettings(Setup setup) throws DataNotValidException {
		try {
			Setup settings = findByPrimaryKey(setup.getDivisCode());
			settings.setHisfDate(setup.getHisfDate());
			settings.setHislDate(setup.getHislDate());
			settings.setHisfDaten(setup.getHisfDaten());
			settings.setHislDaten(setup.getHislDaten());
			settings.setVarType(setup.getVarType());
			settings.setMarRoundTy(setup.getMarRoundTy());
			settings.setMarRoundTv(setup.getMarRoundTv());
			settings.setMarMinCh(setup.getMarMinCh());
			settings.setHisMinMar(setup.getHisMinMar());
			settings.setRealMarGt(setup.getRealMarGt());
			settings.setPosNegeVar(setup.getPosNegeVar());
			settings.setVolaPer(setup.getVolaPer());
			settings.setMarCutSusp(setup.getMarCutSusp());
			settings.setMarCutHis(setup.getMarCutHis());
			setup.setMarTiedMin(setup.getMarTiedMin());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating margin settings - divisCode: "+setup.getDivisCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
		
	/*public void restore(int updId) throws DataNotValidException {
		Query query = null;	
		try {
			query = em.createNamedQuery("getSetupArchByUpdId");
    		query.setParameter("updId", updId);
    		SetupArchive setupArchive = (SetupArchive) query.getSingleResult();
    		Setup setup = findByPrimaryKey(setupArchive.getDivisCode());
    		boolean notExists = false;
    		if (setup!=null) {
    			setup.setHisfDate(setupArchive.getHisfDate());
				setup.setHislDate(setupArchive.getHislDate());
				setup.setHisfDaten(setupArchive.getHislDaten());
				setup.setHislDaten(setupArchive.getHislDaten());
				setup.setHisMinMar(setupArchive.getHisMinMar());
				setup.setHisMinGr(setupArchive.getHisMinGr());
				setup.setMarRoundTy(setupArchive.getMarRoundTy());
				setup.setMarRoundTv(setupArchive.getMarRoundTv());
				setup.setEtfTh(setupArchive.getEtfTh());
				setup.setMarMinCh(setupArchive.getMarMinCh());
				setup.setRealMarGt(setupArchive.getRealMarGt());
				setup.setVarType(setupArchive.getVarType());
				setup.setUpdType("U");
				setup.setUpdDate(GenericTools.systemDate());
				setup.setUpdUsr(setupArchive.getUpdUsr());
				setup.setVolaPer(setupArchive.getVolaPer());
				setup.setGroupTh(setupArchive.getGroupTh());
				setup.setGrRoundTy(setupArchive.getGrRoundTy());
				setup.setGrRoundTv(setupArchive.getGrRoundTv());
				setup.setGrCorrType(setupArchive.getGrCorrType());
				setup.setPosNegeVar(setupArchive.getPosNegeVar());
				setup.setGrMinCh(setupArchive.getGrMinCh());
				setup.setStrMinCh(setupArchive.getStrMinCh());
				setup.setStrRoundTy(setupArchive.getStrRoundTy());
				setup.setStrRoundTv(setupArchive.getStrRoundTv());
				setup.setStrPoneVar(setupArchive.getStrPoneVar());
				setup.setMinMarPerc(setupArchive.getMinMarPerc());
				setup.setStrExtrVar(setupArchive.getStrExtrVar());
				setup.setHisMinStr(setupArchive.getHisMinStr());
				setup.setMinMinch(setupArchive.getMinMinch());
				setup.setMinRoundTy(setupArchive.getMinRoundTy());
				setup.setMinRoundTv(setupArchive.getMinRoundTv());
				setup.setStrCorrTyp(setupArchive.getStrCorrTyp());
				setup.setMarCutHis(setupArchive.getMarCutHis());
				setup.setMarCutSusp(setupArchive.getMarCutSusp());
				setup.setMarTiedMin(setupArchive.getMarTiedMin());
				log.debug("Setup restored - divisCode: "+setupArchive.getDivisCode());
    		}
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error restoring Setup from archive - updId: "+updId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
	public void update(String divisCode, Timestamp hisfDate,Timestamp hislDate,String hisfDaten, String hislDaten,int hisMinMar,
		int hisMinGr,String marRoundTy, BigDecimal marRoundTv, BigDecimal etfTh, BigDecimal marMinCh, String realMarGt, String varType, int volaPer, BigDecimal groupTh, String grRoundTy, BigDecimal grRoundTv, String grCorrType, int posNegeVar,
		BigDecimal grMinCh,BigDecimal strMinCh,String strRoundTy,BigDecimal strRoundTv,int strPoneVar, BigDecimal minMarPerc, int strExtrVar, int hisMinStr, BigDecimal minMinch, String minRoundTy, BigDecimal minRoundTv, String strCorrTyp, String marCutHis, String marCutSusp, BigDecimal marTiedMin) throws DataNotValidException {
		
		try {
			Setup setup = findByPrimaryKey(divisCode);
			setup.setHisfDate(hisfDate);
			setup.setHislDate(hislDate);
			setup.setHisfDaten(hisfDaten);
			setup.setHislDaten(hislDaten);
			setup.setHisMinMar(hisMinMar);
			setup.setHisMinGr(hisMinGr);
			setup.setMarRoundTy(marRoundTy);
			setup.setMarRoundTv(marRoundTv);
			setup.setEtfTh(etfTh);
			setup.setMarMinCh(marMinCh);
			setup.setRealMarGt(realMarGt);
			setup.setVarType(varType);
			setup.setUpdType("U");
			setup.setUpdDate(GenericTools.systemDate());
			setup.setUpdUsr(userString());
			setup.setVolaPer(volaPer);
			setup.setGroupTh(groupTh);
			setup.setGrRoundTy(grRoundTy);
			setup.setGrRoundTv(grRoundTv);
			setup.setGrCorrType(grCorrType);
			setup.setPosNegeVar(posNegeVar);
			setup.setGrMinCh(grMinCh);
			setup.setStrMinCh(strMinCh);
			setup.setStrRoundTy(strRoundTy);
			setup.setStrRoundTv(strRoundTv);
			setup.setStrPoneVar(strPoneVar);
			setup.setMinMarPerc(minMarPerc);
			setup.setStrExtrVar(strExtrVar);
			setup.setHisMinStr(hisMinStr);
			setup.setMinMinch(minMinch);
			setup.setMinRoundTy(minRoundTy);
			setup.setMinRoundTv(minRoundTv);
			setup.setStrCorrTyp(strCorrTyp);
			setup.setMarCutHis(marCutHis);
			setup.setMarCutSusp(marCutSusp);
			setup.setMarTiedMin(marTiedMin);
			log.debug("Setup updated - divisCode: "+divisCode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Setup - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void copy(String oldDivisCode,String newDivisCode) throws DataNotValidException {
			
			try {
				Setup oldSetup = findByPrimaryKey(oldDivisCode);
				Setup setup = new Setup();
				setup.setDivisCode(newDivisCode);
				setup.setHisfDate(oldSetup.getHisfDate());
				setup.setHislDate(oldSetup.getHislDate());
				setup.setHisfDaten(oldSetup.getHisfDaten());
				setup.setHislDaten(oldSetup.getHislDaten());
				setup.setHisMinMar(oldSetup.getHisMinMar());
				setup.setHisMinGr(oldSetup.getHisMinGr());
				setup.setMarRoundTy(oldSetup.getMarRoundTy());
				setup.setMarRoundTv(oldSetup.getMarRoundTv());
				setup.setEtfTh(oldSetup.getEtfTh());
				setup.setMarMinCh(oldSetup.getMarMinCh());
				setup.setRealMarGt(oldSetup.getRealMarGt());
				setup.setVarType(oldSetup.getVarType());
				setup.setUpdType("C");
				setup.setUpdDate(GenericTools.systemDate());
				setup.setUpdUsr(userString());
				setup.setVolaPer(oldSetup.getVolaPer());
				setup.setGroupTh(oldSetup.getGroupTh());
				setup.setGrRoundTy(oldSetup.getGrRoundTy());
				setup.setGrRoundTv(oldSetup.getGrRoundTv());
				setup.setGrCorrType(oldSetup.getGrCorrType());
				setup.setPosNegeVar(oldSetup.getPosNegeVar());
				setup.setGrMinCh(oldSetup.getGrMinCh());
				setup.setStrMinCh(oldSetup.getStrMinCh());
				setup.setStrRoundTy(oldSetup.getStrRoundTy());
				setup.setStrRoundTv(oldSetup.getStrRoundTv());
				setup.setStrPoneVar(oldSetup.getStrPoneVar());
				setup.setMinMarPerc(oldSetup.getMinMarPerc());
				setup.setStrExtrVar(oldSetup.getStrExtrVar());
				setup.setHisMinStr(oldSetup.getHisMinStr());
				setup.setMinMinch(oldSetup.getMinMinch());
				setup.setMinRoundTy(oldSetup.getMinRoundTy());
				setup.setMinRoundTv(oldSetup.getMinRoundTv());
				setup.setStrCorrTyp(oldSetup.getStrCorrTyp());
				setup.setMarCutHis(oldSetup.getMarCutHis());
				setup.setMarCutSusp(oldSetup.getMarCutSusp());
				setup.setMarTiedMin(oldSetup.getMarTiedMin());
				em.persist(setup);
				log.debug("Setup copied - divisCode: "+newDivisCode);
			} catch (Exception e) {
	    		DataNotValidException exc = new DataNotValidException("Error copying Setup - divisCode: "+oldDivisCode+" - "+e.getMessage());
	    		exc.setStackTrace(e.getStackTrace());
	    		throw exc;
	    	}
		}
	
	public void update(Setup setUp) throws DataNotValidException {
		try {
			/*Setup setup = findByPrimaryKey(setUp.getDivisCode());
			setup.setUpdType("U");
			setup.setUpdDate(GenericTools.systemDate());
			setup.setUpdUsr(userString());*/
			log.debug("Setup updated - divisCode: "+setUp.getDivisCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Setup - divisCode: "+setUp.getDivisCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(Setup setUp) throws DataNotValidException {
		try {
			Setup setup = findByPrimaryKey(setUp.getDivisCode());
			em.remove(setup);
			log.debug("Setup removed - divisCode: "+setUp.getDivisCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Setup - divisCode: "+setUp.getDivisCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void restore(Setup oldSetup) throws DataNotValidException {
		try {
			Setup currSetup = findByPrimaryKey(oldSetup.getDivisCode());
			this.remove(currSetup);
			this.store(oldSetup);
			log.debug("Setup restore for divisCode: "+oldSetup.getDivisCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error restoring Setup - divisCode: "+oldSetup.getDivisCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
}
