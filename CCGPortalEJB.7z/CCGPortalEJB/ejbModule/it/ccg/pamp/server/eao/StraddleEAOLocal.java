package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Straddle;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.ejb.Local;

@Local
public interface StraddleEAOLocal {
	public Straddle[] fetch() throws DataNotValidException;

	public Straddle[] getEnabledStraddles() throws DataNotValidException;
	
	public Straddle findByPrimaryKey(int instrId) throws DataNotValidException;
	
	public Straddle findEnabledStraddleByInstrId(int instrId) throws DataNotValidException;
	
	public Straddle[] getEnabledStraddlesByDivisCode(String divisCode) throws DataNotValidException;
	
	public void add(int instrId, Timestamp inivDate, Timestamp endvDate, Timestamp sendDate, String status, BigDecimal crStraM, BigDecimal anStra, 
		BigDecimal usrStra, Timestamp anDate, BigDecimal propStra, int crMul, int anMul, int usrMul, BigDecimal crSpread, BigDecimal anSpread, BigDecimal usrSpread, 
		String propose, String approval, int rcCode, String comment, String crLog, String anLog, String propLog, int anNv, int crNv, int anNDaysPer, int crNDaysPer,
		int anPrgExp1, int crPrgExp1, int anPrgExp2, int crPrgExp2, String anStrType, String crStrType, String custom) throws DataNotValidException;
	
	public void store(Straddle straddle) throws DataNotValidException;
	
	public void updateCurMar(Straddle straddle) throws DataNotValidException;
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException;
	
	public void update(int instrId, Timestamp inivDate, Timestamp endvDate, Timestamp sendDate, String status, BigDecimal crStraM, BigDecimal anStra, 
		BigDecimal usrStra, Timestamp anDate, BigDecimal propStra, int crMul, int anMul, int usrMul, BigDecimal crSpread, BigDecimal anSpread, BigDecimal usrSpread, 
		String propose, String approval, int rcCode, String comment, String crLog, String anLog, String propLog, int anNv, int crNv, int anNDaysPer, int crNDaysPer,
		int anPrgExp1, int crPrgExp1, int anPrgExp2, int crPrgExp2, String anStrType, String crStrType, String custom) throws DataNotValidException;
	
	public void update(Straddle stra) throws DataNotValidException;
	
	public void logUpdate(Straddle stra) throws DataNotValidException;
	
	public void remove(int instrId) throws DataNotValidException;
	
	public void remove(Straddle straddle) throws DataNotValidException;
}
