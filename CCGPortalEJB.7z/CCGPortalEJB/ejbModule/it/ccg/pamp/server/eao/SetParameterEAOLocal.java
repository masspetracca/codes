package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.SetParameter;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface SetParameterEAOLocal {
	public SetParameter[] fetch() throws DataNotValidException;
	public SetParameter findByPrimaryKey(int nDaysPer, int nv, int setId) throws DataNotValidException;
	public SetParameter[] fetchWithSets(int setId) throws DataNotValidException;
	public SetParameter[] findBySetId(int setId) throws DataNotValidException;
	public Integer[] getActiveDelta(int setId) throws DataNotValidException;
	public Integer[] getActivePeriods(int setId, int delta) throws DataNotValidException;
	public Integer[] getEnabledPeriods(int setId, int delta) throws DataNotValidException;
	public void add(int nDaysPer, int nv, int setId, String pStatus) throws DataNotValidException;
	public void store(SetParameter setParameter) throws DataNotValidException;
	//public void restore(int updId) throws DataNotValidException;
	public void update(int nDaysPer, int nv, int setId, String pStatus) throws DataNotValidException;
	public void update(SetParameter setParam) throws DataNotValidException;
	public void remove(int nDaysPer, int nv, int setId) throws DataNotValidException;
	public int removeBySetId(int setId) throws DataNotValidException;
	public void remove(SetParameter setParam) throws DataNotValidException;
}
