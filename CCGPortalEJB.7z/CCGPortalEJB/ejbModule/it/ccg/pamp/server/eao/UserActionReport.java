package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.utils.UserActionDto;

import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.HashMap;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class UserActionReport
 */
@Stateless
@Local(UserActionReportLocal.class)
@Remote(UserActionReportRemote.class)
public class UserActionReport implements UserActionReportRemote, UserActionReportLocal {

	private static HashMap<String, UserActionDto> actions = new HashMap<String, UserActionDto>();
    /**
     * Default constructor. 
     */
    public UserActionReport() {
        // TODO Auto-generated constructor stub
    }

    @SuppressWarnings("static-access")
	public void addAction(String user, String action){
    	 System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA in UserActionReport.addAction");
    	 UserActionDto dto = new UserActionDto();
    	 System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA action "+action);
    	 dto.setAction(action);
    	 System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA user "+user);
    	 dto.setUser(user);
    	 dto.setActionDate(new GregorianCalendar());
    	 SimpleDateFormat dataFormatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    	 System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA data "+dataFormatter.format(dto.getActionDate().getTime()));
    	 dto.setStringActionDate(dataFormatter.format(dto.getActionDate().getTime()));
    	 this.actions.put(dto.getUser()+" "+dto.getAction(), dto);
    	 
     }
     
     @SuppressWarnings("static-access")
	public HashMap<String, UserActionDto> getActionReport()throws Exception{
    	 System.out.println("in UserActionReport.getActionReport");
    	 return this.actions;
     }
}
