package it.ccg.pamp.server.eao;
import java.math.BigDecimal;
import java.sql.Timestamp;

import it.ccg.pamp.server.entities.CorporateAction;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface CorporateActionEAOLocal {
	public CorporateAction[] fetch() throws DataNotValidException;
	
	public CorporateAction findByPrimaryKey(int caId) throws DataNotValidException;
	
	public CorporateAction[] findByInstrId(int instrId) throws DataNotValidException;
	
	public CorporateAction findByInstrIdAndCaDate(int instrId,Timestamp caDate) throws DataNotValidException;
	
	public CorporateAction findByInstrIdAndFrstExDate(int instrId,Timestamp frstExDate) throws DataNotValidException;
	
	public void add(String caType, Timestamp frstExDate, int instrId, int oldInstrId, Timestamp caDate, BigDecimal caValue, BigDecimal kCoeff, String invK) throws DataNotValidException;
	public void store(CorporateAction corporateAction) throws DataNotValidException;
	public void update(int caId, String caType, Timestamp frstExDate, int instrId, int oldInstrId, Timestamp caDate, BigDecimal caValue, BigDecimal kCoeff, String invK) throws DataNotValidException;
	public void update(CorporateAction corpAc) throws DataNotValidException;
	public void remove(int caId) throws DataNotValidException;
	public int removeByInstrId(int instrId) throws DataNotValidException;
	public void remove(CorporateAction corporateAction) throws DataNotValidException;
	public void flush();
}
