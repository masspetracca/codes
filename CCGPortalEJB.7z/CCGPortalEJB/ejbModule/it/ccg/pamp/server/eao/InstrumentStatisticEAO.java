package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.InstrumentStatistic;
import it.ccg.pamp.server.entities.InstrumentStatisticPK;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class InstrumentStatisticEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class InstrumentStatisticEAO implements  InstrumentStatisticEAOLocal {
	@EJB InstrumentEAOLocal instrumentEAO;
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	
	
	public InstrumentStatistic[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllInstStat");
    		List<InstrumentStatistic> instrumentStatistic = query.getResultList();
    		InstrumentStatistic[] arrInstrumentStatistic = new InstrumentStatistic[instrumentStatistic.size()];
    		return instrumentStatistic.toArray(arrInstrumentStatistic);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument Statistics - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InstrumentStatistic[] fetchWithMode1() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllInstStatWithMode1");
    		List<InstrumentStatistic> instrumentStatistic = query.getResultList();
    		InstrumentStatistic[] arrInstrumentStatistic = new InstrumentStatistic[instrumentStatistic.size()];
    		return instrumentStatistic.toArray(arrInstrumentStatistic);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument Statistics with mode 1 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<InstrumentStatistic> findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstStatByInstrId");
    		query.setParameter("instrId", instrId);
    		List<InstrumentStatistic> instrumentStatisticList = query.getResultList();
    		return instrumentStatisticList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument Statistics - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public InstrumentStatistic findMaxHistDaysByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMaxHistDaysByInstrId");
    		query.setParameter("instrId", instrId);
    		List<InstrumentStatistic> instrumentStatisticList = query.getResultList();
    		
    		if (instrumentStatisticList.size()>0) {
    			return instrumentStatisticList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument Statistics - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
		
	public InstrumentStatistic getMaxStDevByInstrIdAndPeriodAndNVArrForStressTest(int instrId, int period, int[] nvArr) throws DataNotValidException {
		
		String nVList = "";
		
		for (int nv:nvArr) {
			nVList += nv+",";
		}
		
		nVList = nVList.substring(0,nVList.length()-1);
		
		Query query = null;
    	try {
    		//String sqlString = "SELECT VAR2.INSTRID,VAR2.NV,VAR2.PRICEDATE,VAR2.VARTYPE,VAR2.VARIAT,VAR2.PRGEXP,VAR2.STATUS,VAR2.UPDTYPE,VAR2.UPDUSR,VAR2.UPDDATE FROM ";
    		String sqlString = "SELECT INSTRID, NV, NDAYSPER, VARTYPE, MODE, ACTIVE, STDEV, AVERAGE, ASY, KURTOSIS, PERF, PERYEAR, NDAYS, VOLADAY, EVENTSIN, EVENTSOUT, NORMMAR, NORMMARCOV, NORMMARSD, MAXMARGIN, ";
    		sqlString += "MAXMARSD, MAXMARCOV, MATHMAR, MATHMARSD, MATHMARCOV, MINMAR, MINMARSD, MINMARCOV, AVEMAR, AVEMARSD, AVEMARCOV, CURRMARSD, CURRMARCOV, STATUS, CONFIDENCE, UPDTYPE, UPDUSR, UPDDATE ";
    		sqlString += "FROM PMPTSTATS ";
    		sqlString += "WHERE INSTRID = "+instrId+" ";
    		sqlString += "AND NDAYSPER <= "+period+" ";
    		sqlString += "AND MODE = 2 ";
    		sqlString += "AND NV IN ("+nVList+") ";
    		sqlString += "ORDER BY NDAYSPER DESC,STDEV DESC";
    		
    		
    		query =  em.createNativeQuery(sqlString,InstrumentStatistic.class);
    		List<InstrumentStatistic> instrStatList = query.getResultList();
    		
    		if (instrStatList.size()>0) {
    			return instrStatList.get(0);
    		} else {
    			return null;
    		}

    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument Statistics - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<InstrumentStatistic> findByInstrIdAndNDaysPer(int instrId, int nDaysPer) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstStatByInstrIdAndNDaysPer");
    		query.setParameter("instrId", instrId);
    		query.setParameter("nDaysPer", nDaysPer);
    		List<InstrumentStatistic> instrumentStatisticList = query.getResultList();
    		return instrumentStatisticList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching instrument statistics - instrId: "+instrId+"; nDaysPer: "+nDaysPer+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<String> printInstrumentStatistics(int instrId) throws DataNotValidException {
		
		List<InstrumentStatistic> instrumentStatisticList = this.findByInstrId(instrId);
		
		String instrStLog = "";
		
		List<String> instrStatsForLog = new ArrayList<String>();
		
		MathContext mc = new MathContext(2);
		
		int counter = 0;
		
		for (InstrumentStatistic instrStat:instrumentStatisticList) {
			if (counter < 10) {
				instrStLog = "";
				
				instrStLog += "HP: "+instrStat.getPk().getNv()+"; ";
				instrStLog += "Period: "+instrStat.getPk().getNDaysPer()+"; ";
				instrStLog += "Standard Deviation: "+GenericTools.roundValue(instrStat.getStDev().doubleValue(),mc)+"; ";
				instrStLog += "Average: "+instrStat.getAverage().round(mc)+"; ";
				instrStLog += "Cov. Days: "+instrStat.getNDays().intValue()+"; ";
				instrStLog += "Events in: "+instrStat.getEventsIn().intValue()+"; ";
				instrStLog += "Events out: "+instrStat.getEventsOut().intValue()+"; ";
				instrStLog += "Normal Margin: "+GenericTools.percentValue(instrStat.getNormMar(),mc);
				instrStLog += "Min. Margin: "+GenericTools.percentValue(instrStat.getMinMar(),mc);
				instrStLog += "Avg Margin: "+GenericTools.percentValue(instrStat.getAveMar(),mc);
				instrStLog += "Max Margin: "+GenericTools.percentValue(instrStat.getMaxMargin(),mc);
				instrStLog += "Math. Margin: "+GenericTools.percentValue(instrStat.getMathMar(),mc);
				
				instrStatsForLog.add(instrStLog);
				
				counter++;
			} else {
				break;
			}
			
		}
		return instrStatsForLog;
	}
	
	
	public InstrumentStatistic findByPrimaryKey(int instrId, int nv, int nDaysPer, String varType,int mode) throws DataNotValidException {
		try {
			InstrumentStatisticPK pK = new InstrumentStatisticPK();
			pK.setInstrId(instrId);
			pK.setNv(nv);
			pK.setNdaysPer(nDaysPer);
			pK.setVarType(varType);
			pK.setMode(mode);
			InstrumentStatistic instrumentStatistic = (InstrumentStatistic) em.find(InstrumentStatistic.class,pK);
    		return instrumentStatistic;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument Statistic - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	//prende i delta attivi
	public Integer[] getActiveDelta(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrStatsActiveDelta");
    		query.setParameter("instrId", instrId);
    		String instrType = instrumentEAO.findByPrimaryKey(instrId).getInstrType();
    		query.setParameter("instrType", instrType);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active delta for Instrument Statistics - instrId: "+instrId+": "+e.getMessage()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActivePeriods(int instrId, int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrStatsActivePeriods");
    		query.setParameter("instrId", instrId);
    		query.setParameter("nv", delta);
    		String instrType = instrumentEAO.findByPrimaryKey(instrId).getInstrType();
    		query.setParameter("instrType", instrType);
    		List<Integer> nDaysPerList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nDaysPerList.size()];
    		nDaysPerList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active periods for Instrument Statistics - instrId: "+instrId+"; delta: "+delta+" - "+e.getMessage()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getEnabledPeriods(int instrId, int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrStatsEnabledPeriods");
    		query.setParameter("instrId", instrId);
    		query.setParameter("nv", delta);
    		String instrType = instrumentEAO.findByPrimaryKey(instrId).getInstrType();
    		query.setParameter("instrType", instrType);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled periods for Instrument Statistics - instrId: "+instrId+"; delta: "+delta+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void add(int instrId, int nv, int nDaysPer, String varType, int mode, int active, BigDecimal stDev, BigDecimal average, BigDecimal asy, BigDecimal kurtosis,
		BigDecimal perf, BigDecimal perYear, BigDecimal nDays, BigDecimal volaDay, BigDecimal eventsIn, BigDecimal eventsOut,
		BigDecimal normMar, BigDecimal normMarCov, BigDecimal normMarSd, BigDecimal maxMargin, BigDecimal maxMarSd, BigDecimal maxMarCov, BigDecimal mathMar,
		BigDecimal mathMarSd, BigDecimal mathMarCov, BigDecimal minMar, BigDecimal minMarSd, BigDecimal minMarCov, BigDecimal aveMar, BigDecimal aveMarSd,
		BigDecimal aveMarCov, BigDecimal currMarSd, BigDecimal currMarCov, BigDecimal confidence, String status) throws DataNotValidException {
		
		try {
			InstrumentStatistic instrumentStatistic = new InstrumentStatistic();
			InstrumentStatisticPK pK = new InstrumentStatisticPK();
			pK.setInstrId(instrId);
			pK.setNv(nv);
			pK.setNdaysPer(nDaysPer);
			pK.setVarType(varType);
			pK.setMode(mode);
			instrumentStatistic.setPk(pK);
			instrumentStatistic.setActive(active);
			instrumentStatistic.setStDev(stDev);
			instrumentStatistic.setAverage(average);
			instrumentStatistic.setAsy(asy);
			instrumentStatistic.setKurtosis(kurtosis);
			instrumentStatistic.setPerf(perf);
			instrumentStatistic.setPerYear(perYear);
			instrumentStatistic.setNDays(nDays);
			instrumentStatistic.setVolaDay(volaDay);
			instrumentStatistic.setEventsIn(eventsIn);
			instrumentStatistic.setEventsOut(eventsOut);
			instrumentStatistic.setNormMar(normMar);
			instrumentStatistic.setNormMarCov(normMarCov);
			instrumentStatistic.setNormMarSd(normMarSd);
			instrumentStatistic.setMaxMargin(maxMargin);
			instrumentStatistic.setMaxMarSd(maxMarSd);
			instrumentStatistic.setMaxMarCov(maxMarCov);
			instrumentStatistic.setMathMar(mathMar);
			instrumentStatistic.setMathMarSd(mathMarSd);
			instrumentStatistic.setMathMarCov(mathMarCov);
			instrumentStatistic.setMinMar(minMar);
			instrumentStatistic.setMinMarSd(minMarSd);
			instrumentStatistic.setMinMarCov(minMarCov);
			instrumentStatistic.setAveMar(aveMar);
			instrumentStatistic.setAveMarSd(aveMarSd);
			instrumentStatistic.setAveMarCov(aveMarCov);
			instrumentStatistic.setCurrMarSd(currMarSd);
			instrumentStatistic.setCurrMarCov(currMarCov);
			instrumentStatistic.setConfidence(confidence);
			instrumentStatistic.setStatus(status);
			instrumentStatistic.setUpdDate(GenericTools.systemDate());
			instrumentStatistic.setUpdType(updType);
			instrumentStatistic.setUpdUsr(userString());
			em.persist(instrumentStatistic);
			log.debug("Added new Instrument Statistic - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+"; mathMar: "+mathMar);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Instrument Statistic - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public void store(InstrumentStatistic instrumentStatistic) throws DataNotValidException {
		try {
			instrumentStatistic.setUpdDate(GenericTools.systemDate());
			instrumentStatistic.setUpdType(updType);
			instrumentStatistic.setUpdUsr(userString());
			em.persist(instrumentStatistic);
			log.debug("Added new Instrument Statistic - instrId: "+instrumentStatistic.getPk().getInstrId()+"; holding period: "+instrumentStatistic.getPk().getNv()+"; nDaysPer: "+instrumentStatistic.getPk().getNDaysPer()+"; varType: "+instrumentStatistic.getPk().getVarType()+"; mode: "+instrumentStatistic.getPk().getMode()+"; mathMar: "+instrumentStatistic.getMathMar());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Instrument Statistic - instrId: "+instrumentStatistic.getPk().getInstrId()+"; holding period: "+instrumentStatistic.getPk().getNv()+"; nDaysPer: "+instrumentStatistic.getPk().getNDaysPer()+"; varType: "+instrumentStatistic.getPk().getVarType()+"; mode: "+instrumentStatistic.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, int nv, int nDaysPer, String varType, int mode, int active, BigDecimal stDev, BigDecimal average, BigDecimal asy, BigDecimal kurtosis,
			BigDecimal perf, BigDecimal perYear, BigDecimal nDays, BigDecimal volaDay, BigDecimal eventsIn, BigDecimal eventsOut,
			BigDecimal normMar, BigDecimal normMarCov, BigDecimal normMarSd, BigDecimal maxMargin, BigDecimal maxMarSd, BigDecimal maxMarCov, BigDecimal mathMar,
			BigDecimal mathMarSd, BigDecimal mathMarCov, BigDecimal minMar, BigDecimal minMarSd, BigDecimal minMarCov, BigDecimal aveMar, BigDecimal aveMarSd,
			BigDecimal aveMarCov, BigDecimal currMarSd, BigDecimal currMarCov, BigDecimal confidence, String status) throws DataNotValidException {
		try {
			InstrumentStatistic instrumentStatistic = findByPrimaryKey(instrId, nv, nDaysPer, varType, mode);
			instrumentStatistic.setActive(active);
			instrumentStatistic.setStDev(stDev);
			instrumentStatistic.setAverage(average);
			instrumentStatistic.setAsy(asy);
			instrumentStatistic.setKurtosis(kurtosis);
			instrumentStatistic.setPerf(perf);
			instrumentStatistic.setPerYear(perYear);
			instrumentStatistic.setNDays(nDays);
			instrumentStatistic.setVolaDay(volaDay);
			instrumentStatistic.setEventsIn(eventsIn);
			instrumentStatistic.setEventsOut(eventsOut);
			instrumentStatistic.setNormMar(normMar);
			instrumentStatistic.setNormMarCov(normMarCov);
			instrumentStatistic.setNormMarSd(normMarSd);
			instrumentStatistic.setMaxMargin(maxMargin);
			instrumentStatistic.setMaxMarSd(maxMarSd);
			instrumentStatistic.setMaxMarCov(maxMarCov);
			instrumentStatistic.setMathMar(mathMar);
			instrumentStatistic.setMathMarSd(mathMarSd);
			instrumentStatistic.setMathMarCov(mathMarCov);
			instrumentStatistic.setMinMar(minMar);
			instrumentStatistic.setMinMarSd(minMarSd);
			instrumentStatistic.setMinMarCov(minMarCov);
			instrumentStatistic.setAveMar(aveMar);
			instrumentStatistic.setAveMarSd(aveMarSd);
			instrumentStatistic.setAveMarCov(aveMarCov);
			instrumentStatistic.setCurrMarSd(currMarSd);
			instrumentStatistic.setCurrMarCov(currMarCov);
			instrumentStatistic.setConfidence(confidence);
			instrumentStatistic.setStatus(status);
			instrumentStatistic.setUpdDate(GenericTools.systemDate());
			instrumentStatistic.setUpdType("U");
			instrumentStatistic.setUpdUsr(userString());
			log.debug("Instrument Statistic updated - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+"; mathMar: "+mathMar);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Instrument Statistic - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(InstrumentStatistic instrStatistic) throws DataNotValidException {
		try {
			log.debug("Instrument Statistic updated - instrId: "+instrStatistic.getPk().getInstrId()+"; holding period: "+instrStatistic.getPk().getNv()+"; nDaysPer: "+instrStatistic.getPk().getNDaysPer()+"; varType: "+instrStatistic.getPk().getVarType()+"; mode: "+instrStatistic.getPk().getMode()+"; mathMar: "+instrStatistic.getMathMar());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Instrument Statistic - instrId: "+instrStatistic.getPk().getInstrId()+"; holding period: "+instrStatistic.getPk().getNv()+"; nDaysPer: "+instrStatistic.getPk().getNDaysPer()+"; varType: "+instrStatistic.getPk().getVarType()+"; mode: "+instrStatistic.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, int nv, int nDaysPer, String varType, int mode) throws DataNotValidException {
		try {
			InstrumentStatistic instrumentStatistic = findByPrimaryKey(instrId, nv, nDaysPer, varType, mode);
			em.remove(instrumentStatistic);
			log.debug("Instrument Statistic removed - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Instrument Statistic - instrId: "+instrId+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+"; varType: "+varType+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteInstrumentStatByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Instrument Statistics removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Instrument Statistic - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteInstrumentStatByEnabledInstrId");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" Instrument Statistics related to disabled instruments removed - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing instrument statistics related to disabled instruments - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByMode(int mode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteInstrumentStatByMode");
			query.setParameter("mode", mode);
			int result = query.executeUpdate();
			log.debug(result+" Instrument Statistic - mode: "+mode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Instrument Statistic - mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(InstrumentStatistic instrStatistic) throws DataNotValidException {
		remove(instrStatistic.getPk().getInstrId(), instrStatistic.getPk().getNv(), instrStatistic.getPk().getNDaysPer(), instrStatistic.getPk().getVarType(), instrStatistic.getPk().getMode());
	}
	
	public void transferMode1To2() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("deleteMode2");
    		query.executeUpdate();
    		//query = em.createNamedQuery("transferMode1to2");
    		query = em.createNativeQuery("INSERT INTO PMPTSTATS (INSTRID,NV,NDAYSPER,VARTYPE,MODE,ACTIVE,STDEV,AVERAGE,ASY,KURTOSIS,PERF,PERYEAR,NDAYS," +
			"VOLADAY,EVENTSIN,EVENTSOUT,NORMMAR,NORMMARCOV,NORMMARSD,MAXMARGIN,MAXMARSD,MAXMARCOV,MATHMAR,MATHMARSD,MATHMARCOV,MINMAR,MINMARSD,MINMARCOV," +
			"AVEMAR,AVEMARSD,AVEMARCOV,CURRMARSD,CURRMARCOV,STATUS,CONFIDENCE,UPDDATE,UPDTYPE,UPDUSR) " +
			"SELECT INSTRID,NV,NDAYSPER,VARTYPE,2,ACTIVE,STDEV,AVERAGE,ASY,KURTOSIS,PERF,PERYEAR,NDAYS,VOLADAY,EVENTSIN,EVENTSOUT,NORMMAR,NORMMARCOV," +
			"NORMMARSD,MAXMARGIN,MAXMARSD,MAXMARCOV,MATHMAR,MATHMARSD,MATHMARCOV,MINMAR,MINMARSD,MINMARCOV,AVEMAR,AVEMARSD,AVEMARCOV,CURRMARSD,CURRMARCOV," +
			"STATUS,CONFIDENCE,'"+GenericTools.systemDate()+"','C','"+userString()+"' FROM PMPTSTATS WHERE MODE=1");
    		/*query.setParameter(1,GenericTools.systemDate() );
    		query.setParameter(2, userString());*/
    		query.executeUpdate();
    		log.debug("transfer of stats from mode 1 to 2 has been completed");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring Instrument Statistics from mode 1 to 2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void transferMode1To2ByDivisCode(List<String> divisCodeList) throws DataNotValidException {
		Query query = null;
		
		String strDivisCode = "";
		
		for (String divisCode:divisCodeList) {
			strDivisCode = "'"+divisCode+"',";
		}
		
		strDivisCode = strDivisCode.substring(0,strDivisCode.length()-1);
		String strSQLDivision = "(SELECT INSTRID FROM PMPTINSTR WHERE DIVISCODE IN ("+strDivisCode+"))";
    	try {
    		//query = em.createNamedQuery("deleteMode2");
    		//query.setParameter("divisCode", arrDivisCode);
    		String strQuery = 	"DELETE FROM PMPTSTATS WHERE MODE = 2 AND INSTRID IN "+strSQLDivision;
    							
    		query = em.createNativeQuery(strQuery);
    		query.executeUpdate();
    		//query = em.createNamedQuery("transferMode1to2");
    		query = em.createNativeQuery("INSERT INTO PMPTSTATS (INSTRID,NV,NDAYSPER,VARTYPE,MODE,ACTIVE,STDEV,AVERAGE,ASY,KURTOSIS,PERF,PERYEAR,NDAYS," +
			"VOLADAY,EVENTSIN,EVENTSOUT,NORMMAR,NORMMARCOV,NORMMARSD,MAXMARGIN,MAXMARSD,MAXMARCOV,MATHMAR,MATHMARSD,MATHMARCOV,MINMAR,MINMARSD,MINMARCOV," +
			"AVEMAR,AVEMARSD,AVEMARCOV,CURRMARSD,CURRMARCOV,STATUS,CONFIDENCE,UPDDATE,UPDTYPE,UPDUSR) " +
			"SELECT INSTRID,NV,NDAYSPER,VARTYPE,2,ACTIVE,STDEV,AVERAGE,ASY,KURTOSIS,PERF,PERYEAR,NDAYS,VOLADAY,EVENTSIN,EVENTSOUT,NORMMAR,NORMMARCOV," +
			"NORMMARSD,MAXMARGIN,MAXMARSD,MAXMARCOV,MATHMAR,MATHMARSD,MATHMARCOV,MINMAR,MINMARSD,MINMARCOV,AVEMAR,AVEMARSD,AVEMARCOV,CURRMARSD,CURRMARCOV," +
			"STATUS,CONFIDENCE,'"+GenericTools.systemDate()+"','C','"+userString()+"' FROM PMPTSTATS WHERE MODE=1 AND INSTRID IN "+strSQLDivision);
    		query.executeUpdate();
    		log.debug("transfer of stats from mode 1 to 2 has been completed for divisions "+strDivisCode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring Instrument Statistics from mode 1 to 2 for divisions "+strDivisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public int transferMode1inMode2() throws DataNotValidException {
		InstrumentStatistic[] arrInstrumentStatistic = fetchWithMode1();
		int i=0;
		try {
			for (InstrumentStatistic instrStat: arrInstrumentStatistic) {
				InstrumentStatisticPK pK = new InstrumentStatisticPK();
				InstrumentStatistic instrumentStatistic = new InstrumentStatistic();
				pK.setInstrId(instrStat.getPk().getInstrId());
				pK.setNdaysPer(instrStat.getPk().getNDaysPer());
				pK.setNv(instrStat.getPk().getNv());
				pK.setVarType(instrStat.getPk().getVarType());
				pK.setMode(2);
				instrumentStatistic.setPk(pK);
				instrumentStatistic.setActive(instrStat.getActive());
				instrumentStatistic.setStDev(instrStat.getStDev());
				instrumentStatistic.setAverage(instrStat.getAverage());
				instrumentStatistic.setAsy(instrStat.getAsy());
				instrumentStatistic.setKurtosis(instrStat.getKurtosis());
				instrumentStatistic.setPerf(instrStat.getPerf());
				instrumentStatistic.setPerYear(instrStat.getPerYear());
				instrumentStatistic.setNDays(instrStat.getNDays());
				instrumentStatistic.setVolaDay(instrStat.getVolaDay());
				instrumentStatistic.setEventsIn(instrStat.getEventsIn());
				instrumentStatistic.setEventsOut(instrStat.getEventsOut());
				instrumentStatistic.setNormMar(instrStat.getNormMar());
				instrumentStatistic.setNormMarCov(instrStat.getNormMarCov());
				instrumentStatistic.setNormMarSd(instrStat.getNormMarSd());
				instrumentStatistic.setMaxMargin(instrStat.getMaxMargin());
				instrumentStatistic.setMaxMarSd(instrStat.getMaxMarSd());
				instrumentStatistic.setMaxMarCov(instrStat.getMaxMarCov());
				instrumentStatistic.setMathMar(instrStat.getMathMar());
				instrumentStatistic.setMathMarSd(instrStat.getMathMarSd());
				instrumentStatistic.setMathMarCov(instrStat.getMathMarCov());
				instrumentStatistic.setMinMar(instrStat.getMinMar());
				instrumentStatistic.setMinMarSd(instrStat.getMinMarSd());
				instrumentStatistic.setMinMarCov(instrStat.getMinMarCov());
				instrumentStatistic.setAveMar(instrStat.getAveMar());
				instrumentStatistic.setAveMarSd(instrStat.getAveMarSd());
				instrumentStatistic.setAveMarCov(instrStat.getAveMarCov());
				instrumentStatistic.setCurrMarSd(instrStat.getCurrMarSd());
				instrumentStatistic.setCurrMarCov(instrStat.getCurrMarCov());
				instrumentStatistic.setConfidence(instrStat.getConfidence());
				instrumentStatistic.setStatus(instrStat.getStatus());
				store(instrumentStatistic);
				i++;
			}
			log.debug(i+" Instrument Statistics transferred from mode 1 to 2");
			return i;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error transferring Instrument Statistics from mode 1 to 2 - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
}
