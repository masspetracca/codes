package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.ClassHaircut;
import it.ccg.pamp.server.entities.ClassHaircutHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface ClassHaircutHistoryEAOLocal {

	public List<ClassHaircutHistory> fetch() throws DataNotValidException;
	
	public ClassHaircutHistory findByPrimaryKey(int classId, Timestamp iniVDate) throws DataNotValidException;
	
	public ClassHaircutHistory getCurrentHaircut(int classId) throws DataNotValidException;
	
	public void add(int classId,Timestamp iniVDate,BigDecimal anCap,Timestamp anDate,BigDecimal anFloor,BigDecimal anHct,BigDecimal anMult,
			String anNodes,BigDecimal anRlHct,Timestamp apprDate,String approvedBy,String comment, Timestamp endVDate,BigDecimal hct,String log,
			int rcCode,Timestamp sendDate,String sent,String susp, BigDecimal anAddend) throws DataNotValidException;
	
	public void update(int classId,Timestamp iniVDate,BigDecimal anCap,Timestamp anDate,BigDecimal anFloor,BigDecimal anHct,BigDecimal anMult,
			String anNodes,BigDecimal anRlHct,Timestamp apprDate,String approvedBy,String comment, Timestamp endVDate,BigDecimal hct,String log,
			int rcCode,Timestamp sendDate,String sent,String susp,BigDecimal anAddend) throws DataNotValidException;
	
	public void store(ClassHaircutHistory classHaircutHistory) throws DataNotValidException;
	
	public void store(ClassHaircut classHaircut) throws DataNotValidException;
	
	public void remove(int classId, Timestamp iniVDate) throws DataNotValidException;
	
	public void remove(ClassHaircutHistory classHaircutHistory) throws DataNotValidException;
	
}
