package it.ccg.pamp.server.eao.stressTest;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.stressTest.StressTestSetup;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface StressTestSetupEAOLocal {

	public List<StressTestSetup> fetch() throws DataNotValidException;
	
	public List<StressTestSetup> fetchByDivision(String divisCode) throws DataNotValidException;
	
	public StressTestSetup findByPrimaryKey(String instrType) throws DataNotValidException;
	
	public List<StressTestSetup> fetchStressTestSetupsByDivisCode(String divisCode) throws DataNotValidException;
	
	public void add(String instrType, Timestamp histUpdDay, String histUpdLst, String nvVec, int period, int extrNP, int extrSP, int extrNN, int extrSN, String marDerP, String marPropP,
		BigDecimal marMulP, String marDerN, String marPropN, BigDecimal marMulN, BigDecimal stDevMulP, BigDecimal stDevMulN, BigDecimal volaCoeff, String disabVar, 
		String method, String irCurveLst, int covMbr, String divisCode, int lstMntRep) throws DataNotValidException;
		
	public void store(StressTestSetup stressTestSetup) throws DataNotValidException;
	
	public void update(String instrType, Timestamp histUpdDay, String histUpdLst, String nvVec, int period, int extrNP, int extrSP, int extrNN, int extrSN, String marDerP, String marPropP,
		BigDecimal marMulP, String marDerN, String marPropN, BigDecimal marMulN, BigDecimal stDevMulP, BigDecimal stDevMulN, BigDecimal volaCoeff, String disabVar,
		String method, String irCurveLst, int covMbr, String divisCode, int lstMntRep) throws DataNotValidException;
	
	public void update(StressTestSetup stressTestSetup) throws DataNotValidException;
	
	public void remove(String instrType) throws DataNotValidException; 
	
	public void remove(StressTestSetup stressTestSetup) throws DataNotValidException;

	public StressTestSetup findMinDefFoundByDivisCode(String divisCode) throws DataNotValidException;
	

	/**
	 * Metodo che a partire dalla strumento recupera la classe di appartenenza e a seconda della classe recupera lo
	 * stress setup Govies (1<=classID<=11) o RET
	 * @param instr
	 * @return
	 * @throws DataNotValidException
	 */
	StressTestSetup findByBondClassID(Instrument instr) throws DataNotValidException;
}
