package it.ccg.pamp.server.eao;
import java.math.BigDecimal;
import java.util.List;

import it.ccg.pamp.server.entities.InstrumentStatistic;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface InstrumentStatisticEAOLocal {
	
	public InstrumentStatistic[] fetch() throws DataNotValidException ;
	
	public InstrumentStatistic[] fetchWithMode1() throws DataNotValidException ;
	
	public List<InstrumentStatistic> findByInstrId(int instrId) throws DataNotValidException;
	
	public InstrumentStatistic findMaxHistDaysByInstrId(int instrId) throws DataNotValidException;
	
	public List<InstrumentStatistic> findByInstrIdAndNDaysPer(int instrId, int nDaysPer) throws DataNotValidException;
	
	public List<String> printInstrumentStatistics(int instrId) throws DataNotValidException;
	
	public InstrumentStatistic findByPrimaryKey(int instrId, int nv, int nDaysPer, String varType, int mode) throws DataNotValidException ;
	
	public InstrumentStatistic getMaxStDevByInstrIdAndPeriodAndNVArrForStressTest(int instrId, int period, int[] nvArr) throws DataNotValidException;
	
	public Integer[] getActiveDelta(int instrId) throws DataNotValidException;
	
	public Integer[] getActivePeriods(int instrId, int delta) throws DataNotValidException;
	
	public Integer[] getEnabledPeriods(int instrId, int delta) throws DataNotValidException;
	
	public void add(int instrId, int nv, int nDaysPer, String varType, int mode, int active, BigDecimal stDev, BigDecimal average, BigDecimal asy, BigDecimal kurtosis,
			BigDecimal perf, BigDecimal perYear, BigDecimal nDays, BigDecimal volaDay, BigDecimal eventsIn, BigDecimal eventsOut,
			BigDecimal normMar, BigDecimal normMarCov, BigDecimal normMarSd, BigDecimal maxMargin, BigDecimal maxMarSd, BigDecimal maxMarCov, BigDecimal mathMar,
			BigDecimal mathMarSd, BigDecimal mathMarCov, BigDecimal minMar, BigDecimal minMarSd, BigDecimal minMarCov, BigDecimal aveMar, BigDecimal aveMarSd,
			BigDecimal aveMarCov, BigDecimal currMarSd, BigDecimal currMarCov, BigDecimal confidence, String status) throws DataNotValidException ;
	
	public void store(InstrumentStatistic instrumentStatistic) throws DataNotValidException ;
	
	public void update(int instrId, int nv, int nDaysPer, String varType, int mode, int active, BigDecimal stDev, BigDecimal average, BigDecimal asy, BigDecimal kurtosis,
			BigDecimal perf, BigDecimal perYear, BigDecimal nDays, BigDecimal volaDay, BigDecimal eventsIn, BigDecimal eventsOut,
			BigDecimal normMar, BigDecimal normMarCov, BigDecimal normMarSd, BigDecimal maxMargin, BigDecimal maxMarSd, BigDecimal maxMarCov, BigDecimal mathMar,
			BigDecimal mathMarSd, BigDecimal mathMarCov, BigDecimal minMar, BigDecimal minMarSd, BigDecimal minMarCov, BigDecimal aveMar, BigDecimal aveMarSd,
			BigDecimal aveMarCov, BigDecimal currMarSd, BigDecimal currMarCov, BigDecimal confidence, String status) throws DataNotValidException ;
	
	public void update(InstrumentStatistic instrStatistic) throws DataNotValidException ;
	
	public void remove(int instrId, int nv, int nDaysPer, String varType,int mode) throws DataNotValidException ;
	
	public int removeByInstrId(int instrId) throws DataNotValidException ;
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException ;
	
	public int removeByMode(int mode) throws DataNotValidException ;
	
	public void remove(InstrumentStatistic instrStatistic) throws DataNotValidException ;
	
	public void transferMode1To2() throws DataNotValidException;
	
	public int transferMode1inMode2() throws DataNotValidException;
	
	public void transferMode1To2ByDivisCode(List<String> divisCodeList) throws DataNotValidException;
}
