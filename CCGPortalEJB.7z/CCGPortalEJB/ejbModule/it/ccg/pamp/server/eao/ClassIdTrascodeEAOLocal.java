package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.ClassIdTrascode;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface ClassIdTrascodeEAOLocal {
	public List<ClassIdTrascode> fetch() throws DataNotValidException;
	public List<ClassIdTrascode> getSicClassId(int classId) throws DataNotValidException;
	public List<ClassIdTrascode> getPampClassId(String sicClassId) throws DataNotValidException;
	public ClassIdTrascode findByPrimaryKey(int classId, String sicClassId) throws DataNotValidException;
}
