package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Calendar;
import it.ccg.pamp.server.entities.CalendarPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondToSync;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.apache.openjpa.jdbc.sql.SQLBuffer;

/**
 * Session Bean implementation class CalendarEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class CalendarEAO implements  CalendarEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	
	@SuppressWarnings("unchecked")
	public List<Calendar> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllCal");
    		List<Calendar> calendarList = query.getResultList();
    		return calendarList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Calendars - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@SuppressWarnings("unchecked")
	public LinkedHashMap<Timestamp, String> getCalendarByMarketCode(String marketCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCalendarByMarketCode");
			query.setParameter("marketCode", marketCode);
			List<Calendar> calendarList = query.getResultList();
			LinkedHashMap<Timestamp, String> calendarMap = new LinkedHashMap<Timestamp, String>();
			for (Calendar cal:calendarList) {
				calendarMap.put(cal.getPk().getDate(), cal.getPk().getMarketCode());
			}
    		return calendarMap;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Calendars - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Calendar getPreviousCalendarDateByDayAndMarketCode(Timestamp date, String[] marketCodeList, int daysNumber) throws DataNotValidException {
		Query query = null;
		
		String marketCodeString = "";
		
		for (String marketCode:marketCodeList) {
			marketCodeString += "'"+marketCode+"',"; 
		}
		
		marketCodeString = marketCodeString.substring(0,marketCodeString.lastIndexOf(","));
		
    	try {
    		String sqlString = "SELECT C.DATE,C.MARKETCODE, C.UPDTYPE, C.UPDUSR, C.UPDDATE FROM PMPTCALEND C WHERE "+
					    		"C.DATE<'"+date+"' "+
					    		"AND C.MARKETCODE IN ("+marketCodeString+") "+
					    		"ORDER BY C.DATE DESC "+
					    		"FETCH FIRST "+daysNumber+" ROWS ONLY";
					    		
    		//query = em.createNamedQuery("getPreviousCalendarDateByDayAndMarketCode");
    		/*query.setParameter("marketCode", marketCode);
    		query.setParameter("date", date);
    		query.setParameter("daysNumber", daysNumber);*/
    		query =  em.createNativeQuery(sqlString,Calendar.class);
    		Calendar calendar = (Calendar) query.getSingleResult();
    		List<Calendar> calendarList = query.getResultList();
    		if (calendarList.size()>0) {
    			return calendarList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching dates list from Calendar - marketCode list: "+marketCodeString.replaceAll("'", "")+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public LinkedHashMap<Timestamp,Integer> getPreviousCalendarDateByDayAndMarketCode(Timestamp date, String marketCode, int daysNumber) throws DataNotValidException {
		Query query = null;
		
		
		
    	try {
    		String sqlString = "SELECT C.DATE,C.MARKETCODE, C.UPDTYPE, C.UPDUSR, C.UPDDATE FROM PMPTCALEND C WHERE "+
					    		"C.DATE<'"+date+"' "+
					    		"AND C.MARKETCODE ='"+marketCode+"' "+
					    		"ORDER BY C.DATE DESC "+
					    		"FETCH FIRST "+daysNumber+" ROWS ONLY";
					    		
    		query =  em.createNativeQuery(sqlString,Calendar.class);
    		
    		List<Calendar> calendarList = query.getResultList();
    		
    		LinkedHashMap<Timestamp, Integer> calendarMap = new LinkedHashMap<Timestamp, Integer>();
    		
    		if (calendarList!=null) {
    			for (Calendar cal:calendarList)
    				calendarMap.put(cal.getPk().getDate(), daysNumber--);
    		}
    		
    		return calendarMap;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching date list from Calendar - marketCode: "+marketCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Timestamp> getListDate(String marketCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getListDate");
    		query.setParameter("marketCode", marketCode);
    		List<Timestamp> listDate = query.getResultList();
    		return listDate;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching dates list from Calendar - marketCode: "+marketCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int getCalendarByStartEndDate(Timestamp firstDate,Timestamp lastDate) throws DataNotValidException {
		Query query = null;
		
		String sqlString = "SELECT COUNT(DISTINCT(DATE)) FROM PMPTCALEND "+
						"WHERE DATE BETWEEN '"+firstDate+"' AND '"+lastDate+"'";

		try {
			query =  em.createNativeQuery(sqlString,Integer.class);
			
			int numberOfDays = (Integer) query.getResultList().get(0);
			
			return numberOfDays;
			
		}  catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching calendar - first date: "+firstDate+"; lastDate: "+lastDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
		}
		
		
		
    	/*try {
    		query = em.createNamedQuery("getCalendarByStartEndDate");
    		query.setParameter("firstDate", firstDate);
    		query.setParameter("lastDate", lastDate);
    		List<Timestamp> calendarList = query.getResultList();
    		System.out.println(calendarList.size());
    		return calendarList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching calendar - first date: "+firstDate+"; lastDate: "+lastDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}*/
		
	}
	
	public List<Timestamp> getListDateByStartEndDate(String marketCode,Timestamp firstDate,Timestamp lastDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getListDateByStartEndDate");
    		query.setParameter("marketCode", marketCode);
    		query.setParameter("firstDate", firstDate);
    		query.setParameter("lastDate", lastDate);
    		List<Timestamp> listDate = query.getResultList();
    		return listDate;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching dates list from Calendar - marketCode: "+marketCode+"; first date: "+firstDate+"; lastDate: "+lastDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Calendar findByPrimaryKey(Timestamp date, String marketCode) throws DataNotValidException {
		try {
			CalendarPK pK = new CalendarPK();
			pK.setDate(date);
			pK.setMarketCode(marketCode);
			Calendar calendar = (Calendar) em.find(Calendar.class,pK);
    		return calendar;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Calendar - date: "+date+"; marketCode: "+marketCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public boolean isMarketDate() throws DataNotValidException {
		Query query = null;
		
		try {
    		query = em.createNamedQuery("getTodayAsMarketDate");
    		query.setParameter("today", GenericTools.systemDateMidNight());
    		List<Calendar> listDate = query.getResultList();
    		if (listDate.size()>0) {
    			return true;
    		} else {
    			return false;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Calendar - date: "+GenericTools.systemDateMidNight()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(Calendar calendar) throws DataNotValidException {
		try {
			calendar.setUpdDate(GenericTools.systemDate());
			calendar.setUpdType(updType);
			calendar.setUpdUsr(userString());
			em.persist(calendar);
			log.debug("Added new Calendar - date: "+calendar.getPk().getDate()+"; marketCode: "+calendar.getPk().getMarketCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Calendar - date: "+calendar.getPk().getDate()+"; marketCode: "+calendar.getPk().getMarketCode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(Timestamp date, String marketCode) throws DataNotValidException {
		try {
			Calendar calendar = new Calendar();
			CalendarPK pK = new CalendarPK();
			pK.setDate(date);
			pK.setMarketCode(marketCode);
			calendar.setPk(pK);
			calendar.setUpdDate(GenericTools.systemDate());
			calendar.setUpdType(updType);
			calendar.setUpdUsr(userString());
			em.persist(calendar);
			log.debug("Added new Calendar - date: "+date+"; marketCode: "+marketCode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Calendar - date: "+date+"; marketCode: "+marketCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(Timestamp date, String marketCode) throws DataNotValidException {
		try {
			Calendar calendar = findByPrimaryKey(date,marketCode);
			em.remove(calendar);
			log.debug("Calendar removed - date: "+date+"; marketCode: "+marketCode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Calendar - date: "+date+"; marketCode: "+marketCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void removeByMarketDate(Timestamp mktDate) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteCalendarByMarketDate");
			query.setParameter("mktDate", mktDate);
			int result = query.executeUpdate();
			log.debug(result+" market calendar dates removed from date: "+mktDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing market calendar dates from date: "+mktDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	

}
