package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.ReportRefresh;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface ReportRefreshEAOLocal {
	public void store() throws DataNotValidException;
}
