package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.InstrtypeTranscode;
import it.ccg.pamp.server.entities.TlForx1;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TfForx
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class TlForx1EAO implements  TlForx1EAOLocal {

	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
    
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public List<TlForx1> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllTfForx");
    		List<TlForx1> tfForxList = query.getResultList();
    		return tfForxList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from currency table - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public LinkedHashMap<String,String> transcodeCurrency() throws DataNotValidException {
		Query query = null;
    	try {
    		
    		List<TlForx1> tfForxList = this.fetch();
    		LinkedHashMap<String,String> tfForxMap = new LinkedHashMap<String, String>();
    		for (TlForx1 tfForx:tfForxList) {
    			tfForxMap.put(tfForx.getFeCurr(), tfForx.getFeDesc().substring(0,3));
    		}
    		
    		return tfForxMap;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from currency table - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
