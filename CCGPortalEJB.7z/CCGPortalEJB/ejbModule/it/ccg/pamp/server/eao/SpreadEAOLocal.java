package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Spread;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;

import javax.ejb.Local;

@Local
public interface SpreadEAOLocal {
	public Spread getSpread(String mmTable, BigDecimal price) throws DataNotValidException;
}
