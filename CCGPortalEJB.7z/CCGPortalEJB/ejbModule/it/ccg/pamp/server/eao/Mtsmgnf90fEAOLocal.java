package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.Mtsmgnf90f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;

@Local
public interface Mtsmgnf90fEAOLocal {
	
	public List<Mtsmgnf90f> fetch() throws DataNotValidException;
	
	public List<Mtsmgnf90f> getMtsmgnf90fNotinClMarHis() throws DataNotValidException;
	
	public Mtsmgnf90f findByPrimaryKey(int f90cdclass) throws DataNotValidException;
	
	public void update(int f90cdclass, BigDecimal f90inmargi) throws DataNotValidException;
}
