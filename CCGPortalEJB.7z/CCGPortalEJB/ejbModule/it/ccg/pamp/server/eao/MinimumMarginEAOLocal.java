package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.MinimumMargin;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.ejb.Local;

@Local
public interface MinimumMarginEAOLocal {
	public MinimumMargin[] fetch() throws DataNotValidException;
	
	public MinimumMargin[] getEnabledMinimumMargins() throws DataNotValidException;
	
	public MinimumMargin getMinMarginByUndInstrId(int undInstrId) throws DataNotValidException;
	
	public MinimumMargin[] getEnabledMinimumMarginsByDivisCode(String divisCode) throws DataNotValidException;
	
	public MinimumMargin findByPrimaryKey(int instrId) throws DataNotValidException;
	
	public void add(int instrId, Timestamp inivDate, Timestamp endvDate, Timestamp sendDate, String status, BigDecimal crMinMarM, BigDecimal anMinMar, 
		BigDecimal usrMinMar, Timestamp anDate, BigDecimal propMinMar, String propose, 
		String approval, int rcCode, String comment, String crLog, String anLog, String propLog, String custom) throws DataNotValidException;
	
	public void store(MinimumMargin minMargin) throws DataNotValidException;
	
	public void updateCurMar(MinimumMargin minMargin) throws DataNotValidException;
	
	public int updateStatusToDisabled(String divisCode) throws DataNotValidException;
	
	public void update(int instrId, Timestamp inivDate, Timestamp endvDate, Timestamp sendDate, String status, BigDecimal crMinMarM, BigDecimal anMinMar, 
			BigDecimal usrMinMar, Timestamp anDate, BigDecimal propMinMar, String propose, 
			String approval, int rcCode, String comment, String crLog, String anLog, String propLog, String custom) throws DataNotValidException;
	
	public void update(MinimumMargin minMar) throws DataNotValidException;
	
	public void logUpdate(MinimumMargin minMar) throws DataNotValidException;
	
	public void remove(int instrId) throws DataNotValidException;
	
	public void remove(MinimumMargin minMar) throws DataNotValidException;
}
