package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.stressTest.StressTestMtsprice;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StressTestMtspriceEAO
 */
@Stateless
public class StressTestMtspriceEAO implements  StressTestMtspriceEAOLocal {


	@PersistenceContext(unitName="STDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<StressTestMtsprice> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSTMtsprice");
    		List<StressTestMtsprice> stressTestMtspriceList = query.getResultList();
    		return stressTestMtspriceList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from StressTestMtsprice - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public StressTestMtsprice findByPrimaryKey (String prIsin) throws DataNotValidException {
		Query query = null;
    	try {
    		
    		StressTestMtsprice stressTestMtsprice = (StressTestMtsprice) em.find(StressTestMtsprice.class, prIsin);
    		
    		return stressTestMtsprice;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from StressTestMtsprice - isinCode: "+prIsin+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	
	public void update(String prIsin, BigDecimal pPrice) throws DataNotValidException {
		try {
			StressTestMtsprice stressTestMtsprice = this.findByPrimaryKey(prIsin);
			stressTestMtsprice.setPPrice(pPrice);
			log.debug("StressTestMtsprice updated - prIsin: "+prIsin+"; new prPric: "+pPrice);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating StressTestMtsprice - prIsin: "+prIsin+"; price: "+pPrice+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	

}
