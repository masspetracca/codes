package it.ccg.pamp.server.eao.stressTestOeKB;
import it.ccg.pamp.server.entities.stressTestOeKB.OeKBStressTestResult;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;

@Local
public interface OeKBStressTestResultEAOLocal {

	public List<OeKBStressTestResult> fetch() throws DataNotValidException;
	
	public OeKBStressTestResult findByPrimaryKey(int stId, String scenario, long uMbr, String uAcCt,  String uSGrp, String uSubAc, int uGcm) throws DataNotValidException;
	
	public List<OeKBStressTestResult> findByStId(int stId) throws DataNotValidException;
	
	public List<OeKBStressTestResult> findByScenario(String scenario) throws DataNotValidException;
	
	public List<OeKBStressTestResult> findByStIdAndScenario(int stId, String scenario) throws DataNotValidException;
	
	public int findLastStId(String scenario) throws DataNotValidException;
	
	public List<OeKBStressTestResult> findBetweenStIdInterval(int firstStId,int lastStId) throws DataNotValidException;
	
	public void add(int stId, String scenario, long uMbr, String uAcCt,  String uSGrp, String uSubAc, BigDecimal dataMrg, BigDecimal transId, BigDecimal uMargin, String pFolioId) throws DataNotValidException;
	
	public void store(OeKBStressTestResult stressTestResult) throws DataNotValidException;
	
	public void update(int stId, String scenario, long uMbr, String uAcCt,  String uSGrp, String uSubAc, int uGcm, BigDecimal dataMrg, BigDecimal transId, BigDecimal uMargin, String pFolioId) throws DataNotValidException;
	
	public void remove(OeKBStressTestResult stressTestResult) throws DataNotValidException;
	
	public void remove(int stId, String scenario, long uMbr, String uAcCt, String uSGrp, String uSubAc, int uGcm) throws DataNotValidException;
	
}
