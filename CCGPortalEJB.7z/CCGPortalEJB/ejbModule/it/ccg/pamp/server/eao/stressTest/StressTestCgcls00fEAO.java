package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.Cgcls00f;
import it.ccg.pamp.server.entities.Cgcls00fPK;
import it.ccg.pamp.server.entities.stressTest.StressTestCgcls00f;
import it.ccg.pamp.server.entities.stressTest.StressTestCgcls00fPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class Cgcls00fEAO
 */
@Stateless
public class StressTestCgcls00fEAO implements  StressTestCgcls00fEAOLocal {

	@PersistenceContext(unitName="STDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	//@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<StressTestCgcls00f> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSTCgcls00f");
    		List<StressTestCgcls00f> cgcls00fList = query.getResultList();
    		return cgcls00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestCgcls00f> getSTCgcls00fFutOpt(String cClass) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSTCgcls00fFutOpt");
    		query.setParameter("cClass", cClass);
    		List<StressTestCgcls00f> cgcls00fList = query.getResultList();
    		return cgcls00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestCgcls00f> findByCClass(String cClass) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSTCgcls00fByCClass");
    		query.setParameter("cClass", cClass);
    		List<StressTestCgcls00f> cgcls00fList = query.getResultList();
    		return cgcls00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - cClass: "+cClass+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestCgcls00f> findByCofCod(String cofCod) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSTCgcls00fByCofCod");
    		query.setParameter("cofCod", cofCod);
    		List<StressTestCgcls00f> cgcls00fList = query.getResultList();
    		return cgcls00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - cofCod: "+cofCod+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public StressTestCgcls00f findByPrimaryKey(String cClass, String cofCod) throws DataNotValidException {
		try {
			StressTestCgcls00fPK pK = new StressTestCgcls00fPK();
			pK.setCclass(cClass);			
			pK.setCofCod(cofCod);
			StressTestCgcls00f stressTestCgcls00f = (StressTestCgcls00f) em.find(StressTestCgcls00f.class,pK);
    		return stressTestCgcls00f;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Cgcls00f - cClass: "+cClass+"; cofCode: "+cofCod+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
}
