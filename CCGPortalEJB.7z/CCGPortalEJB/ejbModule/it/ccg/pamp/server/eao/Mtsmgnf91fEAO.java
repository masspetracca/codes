package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Mtsmgnf91f;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class Mtsmgnf91fEAO
 */
@Stateless
public class Mtsmgnf91fEAO implements  Mtsmgnf91fEAOLocal {

	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<Mtsmgnf91f> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllMtsmgnf91f");
    		List<Mtsmgnf91f> mtsmgnf91fList = query.getResultList();
    		return mtsmgnf91fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsmgnf91f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Mtsmgnf91f> getMtsmgnf91fNotinClTraHis() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMtsmgnf91fNotinClTraHis");
    		query.setParameter("systemDate", GenericTools.systemDate());
    		List<Mtsmgnf91f> mtsmgnf91fList = query.getResultList();
    		return mtsmgnf91fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsmgnf91f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Mtsmgnf91f findByPrimaryKey(int f91cdclass) throws DataNotValidException {
		try {
			String classId = "0";
			
			if (f91cdclass<10) {
				classId+=Integer.toString(f91cdclass);
			} else {
				classId = Integer.toString(f91cdclass);
			}
			Mtsmgnf91f mtsmgnf91f = (Mtsmgnf91f) em.find(Mtsmgnf91f.class,classId);
    		return mtsmgnf91f;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Mtsmgnf91f - f91cdclass: "+f91cdclass+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public void update(int f91cdclass, BigDecimal f91intridp) throws DataNotValidException {
		try {
			Mtsmgnf91f mtsmgnf91f = findByPrimaryKey(f91cdclass);
			mtsmgnf91f.setF91intridp(f91intridp);
			log.debug("Mtsmgnf91f updated - f91cdclass: "+f91cdclass+"; new offset: "+f91intridp);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Mtsmgnf91f - f91cdclass: "+f91cdclass+"; f91intridp: "+f91intridp+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
