package it.ccg.pamp.server.eao;
import java.util.List;

import it.ccg.pamp.server.entities.NotifyUser;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.UserToNotify;

import javax.ejb.Local;

@Local
public interface NotifyUserEAOLocal {
	
	public NotifyUser[] fetch() throws DataNotValidException;
	
	public NotifyUser findByPrimaryKey(String user, int notifyId) throws DataNotValidException;
	
	public NotifyUser[] findByNotifyId(int notifyId) throws DataNotValidException;
	
	public NotifyUser[] findByUser(String user) throws DataNotValidException;
	
	public List<UserToNotify> getUserToNotifyListByNotifyId(int notifyId) throws DataNotValidException;
	
	public List<UserToNotify> getUserToNotifyListByUserNameAndNotifyId(String[] userNameList, int notifyId) throws DataNotValidException;
	
	public void add(String user, int notifyId) throws DataNotValidException;
	
	public void store(NotifyUser notifyUser) throws DataNotValidException;
	
	public int removeByUser(String user) throws DataNotValidException;
	
	public int removeById(int notifyId) throws DataNotValidException;
	
	public void remove(String user, int notifyId) throws DataNotValidException;
	
	public void remove(NotifyUser notifyUser) throws DataNotValidException;
}
