package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.RankedVariation;
import it.ccg.pamp.server.entities.SetComponent;
import it.ccg.pamp.server.entities.SetComponentPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class SetComponentEAO
 */
@Stateless
//@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class SetComponentEAO implements  SetComponentEAOLocal {

	@EJB private InstrumentEAOLocal instrEAO=null;
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}

	public String userString = "System";
	public String updType = "C";
	
	
	public SetComponent[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSetComponent");
    		List<SetComponent> setComponent = query.getResultList();
    		SetComponent[] arrSetComponent = new SetComponent[setComponent.size()];
    		return setComponent.toArray(arrSetComponent);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Set Components - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SetComponent findByPrimaryKey(int setId, int instrId) throws DataNotValidException {
		try {
			SetComponentPK pK = new SetComponentPK();
			pK.setSetId(setId);
			pK.setInstrId(instrId);
			SetComponent setComponent = (SetComponent) em.find(SetComponent.class,pK);
    		return setComponent;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Set Component - setId: "+setId+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SetComponent[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSetComponentByInstrId");
    		query.setParameter("instrId", instrId);
    		List<SetComponent> setComponent = query.getResultList();
    		SetComponent[] arrSetComponent = new SetComponent[setComponent.size()];
    		return setComponent.toArray(arrSetComponent);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Set Components - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SetComponent[] findBySetId(int setId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSetComponentBySetId");
    		query.setParameter("setId", setId);
    		List<SetComponent> setComponentList = query.getResultList();
    		//List<SetComponent> setC = new ArrayList();
    		/*for (SetComponent setCmp;i<setComponent.size();i++) {
    			//Instrument instr = instrEAO.findByPrimaryKey(setComponent.get(i).getPk().getInstrId());
    			if ((instr!=null) && (!instr.getStatus().equals("D"))) {
    					setC.add(setComponent.get(i));
    			}
    		}*/
    		SetComponent[] arrSetComponent = new SetComponent[setComponentList.size()];
    		return setComponentList.toArray(arrSetComponent);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Set Components - setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int setId, int instrId) throws DataNotValidException {
		try {
			SetComponent setComponent = findByPrimaryKey(setId, instrId);
			SetComponentPK pK = new SetComponentPK();
			pK.setSetId(setId);
			pK.setInstrId(instrId);
			setComponent.setPk(pK);
			setComponent.setUpdType(updType);
			setComponent.setUpdDate(GenericTools.systemDate());
			setComponent.setUpdUsr(userString());
			em.persist(setComponent);
			log.debug("Added new Set Component - setId: "+setId+"; instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Set Component - setId: "+setId+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(SetComponent setComponent) throws DataNotValidException {
		try {
			setComponent.setUpdType(updType);
			setComponent.setUpdDate(GenericTools.systemDate());
			setComponent.setUpdUsr(userString());
			em.persist(setComponent);
			log.debug("Added new Set Component - setId: "+setComponent.getPk().getSetId()+"; instrId: "+setComponent.getPk().getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Set Component - setId: "+setComponent.getPk().getSetId()+"; instrId: "+setComponent.getPk().getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int setId, int instrId) throws DataNotValidException {
		try {
			SetComponent setComponent = findByPrimaryKey(setId, instrId);
			em.remove(setComponent);
			log.debug("Set Component removed - setId: "+setId+"; instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Set Component - setId: "+setId+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteSetComponentByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug(result+" Set Component removed - instrId: "+instrId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Set Component - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeBySetId(int setId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteSetComponentBySetId");
			query.setParameter("setId", setId);
			int result = query.executeUpdate();
			log.debug(result+" Set Component removed - setId: "+setId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Set Component - setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(SetComponent setComp) throws DataNotValidException {
		remove(setComp.getPk().getSetId(), setComp.getPk().getInstrId());
	}
	
}
