package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.MarginNode;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

@Local
public interface MarginNodeEAOLocal {
	public MarginNode[] fetch() throws DataNotValidException;
	
	public MarginNode[] fetchWithMode1() throws DataNotValidException;
	
	public MarginNode findByPrimaryKey(int instrId, int mode) throws DataNotValidException;
	
	public Integer[] getActiveDelta(int instrId) throws DataNotValidException;
	
	public Integer[] getActivePeriods(int instrId, int delta) throws DataNotValidException;
	
	public Integer[] getEnabledPeriods(int instrId, int delta) throws DataNotValidException;
	
	public List<MarginNode> getMarginNodeByClassId (int classId) throws DataNotValidException;
	
	public List<MarginNode> getMarginNodeByClassIdAndDivisCode (int classId,String divisCode) throws DataNotValidException;
	
	public MarginNode getMaxMarginByClassId (int classId) throws DataNotValidException;
	
	public MarginNode getMaxMarginByClassIdOrderByPrice (int classId) throws DataNotValidException;
	
	public void add(int instrId, int mode, int classId, BigDecimal cover, Timestamp frstHistD, Timestamp lastHistD, BigDecimal margin, int nDaysPer, int nv, String status, String divisCode) throws DataNotValidException;
	
	public void store(MarginNode marginNode) throws DataNotValidException;
	
	public void update(int instrId, int mode, int classId, BigDecimal cover, Timestamp frstHistD, Timestamp lastHistD, BigDecimal margin, int nDaysPer, int nv, String status, String divisCode) throws DataNotValidException;
	
	public void update(MarginNode marginNode) throws DataNotValidException;
	
	public void remove(int instrId, int mode) throws DataNotValidException;
	
	public int removeByInstrId(int instrId) throws DataNotValidException;
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException;
	
	public int removeByMode(int mode) throws DataNotValidException;
	
	public void remove(MarginNode marginNode) throws DataNotValidException;
	
	public void transferMode1To2() throws DataNotValidException;
	
	public void transferMode1To2ByDivisCode(String divisCode) throws DataNotValidException;
}
