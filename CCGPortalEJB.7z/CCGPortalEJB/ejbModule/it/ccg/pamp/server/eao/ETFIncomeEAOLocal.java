package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.ETFIncome;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.ejb.Local;

@Local
public interface ETFIncomeEAOLocal {
	public ETFIncome[] fetch() throws DataNotValidException;
	public ETFIncome findByPrimaryKey(int instrId, Timestamp incomeDate) throws DataNotValidException;
	public ETFIncome[] findByInstrId(int instrId) throws DataNotValidException;
	public void add(int instrId, Timestamp incomeDate, BigDecimal incomeValue, BigDecimal kRett) throws DataNotValidException;
	public void store(ETFIncome etfIncome) throws DataNotValidException; 
	public void update(int instrId, Timestamp incomeDate, BigDecimal incomeValue, BigDecimal kRett) throws DataNotValidException; 
	public void update(ETFIncome etf) throws DataNotValidException;
	public void remove(int instrId, Timestamp incomeDate) throws DataNotValidException;
	public int removeByInstrId(int instrId) throws DataNotValidException;
	public void remove(ETFIncome etfIncome) throws DataNotValidException;
}
