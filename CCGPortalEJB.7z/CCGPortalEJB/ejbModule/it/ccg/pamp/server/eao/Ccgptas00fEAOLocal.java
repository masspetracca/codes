package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Ccgptas00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface Ccgptas00fEAOLocal {
	public Ccgptas00f[] fetch() throws DataNotValidException;
	public Ccgptas00f findByIrNode(int irNode) throws DataNotValidException;
	public Ccgptas00f findByPrimaryKey(int irNode, long date) throws DataNotValidException;
}
