package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.properties.PropertiesEAOLocal;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RefreshMatTablesEAO
 */
@Stateless
public class RefreshMatTablesEAO implements  RefreshMatTablesEAOLocal {

	@EJB
	private PropertiesEAOLocal properties;
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	

	public String refreshEquitiesMaterializedQuery() throws DataNotValidException {
		//Tables to update
		//{"PMPMINSTR","PMPMDINSTR","PMPMSTATS","PMPMDSTATS"};
    	
    	
		try {
			String[] matQueryArr = properties.getPropertyMap().get("equityMatTableList").split(",");
			Query query = null;
			
    		String sqlRefresh = "";
    		
    		int totalTables = matQueryArr.length;
    		int counter = 0;
    		
    		for (String matQuery:matQueryArr) {
    			counter++;
    			log.info("Refreshing table "+counter+"/"+totalTables);
	    		sqlRefresh = "REFRESH TABLE "+matQuery;
	    		query =  em.createNativeQuery(sqlRefresh);
	    		query.executeUpdate();
	    		log.info("Table "+counter+"/"+totalTables+" refreshed");
    		}
    		
    		return "Equity/Eq. Derivatives materialized tables refreshed";
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error refreshing materialized queries - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
    	
    }
    
    public String refreshBondMaterializedQuery() throws DataNotValidException {
		//Tables to update
    	//{"PMPMBINSTR","PMPMBSTATS"};
    	
    	try {	
    		String[] matQueryArr = properties.getPropertyMap().get("bondMatTableList").split(",");
    		Query query = null;
    	
    		String sqlRefresh = "";

    		int totalTables = matQueryArr.length;
    		int counter = 0;
    		
    		for (String matQuery:matQueryArr) {
    			counter++;
    			log.info("Refreshing table "+counter+"/"+totalTables);
    			sqlRefresh = "REFRESH TABLE "+matQuery;
	    		query =  em.createNativeQuery(sqlRefresh);
	    		query.executeUpdate();
	    		log.info("Table "+counter+"/"+totalTables+" refreshed");
    		}
    		
    		return "Bond materialized tables refreshed";
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error refreshing materialized queries - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
    	
    }
    
    
    public String refreshComparableMaterializedQuery() throws DataNotValidException {
		//Tables to update
    	//{"PMPMCINSTR","PMPMCSTATS"};
    	
    	try {	
    		String[] matQueryArr = properties.getPropertyMap().get("comparableMatTableList").split(",");
    		Query query = null;
    	
    		int totalTables = matQueryArr.length;
    		int counter = 0;
    		
    		String sqlRefresh = "";
    		
    		for (String matQuery:matQueryArr) {
    			counter++;
    			log.info("Refreshing table "+counter+"/"+totalTables);
    			sqlRefresh = "REFRESH TABLE "+matQuery;
	    		query =  em.createNativeQuery(sqlRefresh);
	    		query.executeUpdate();
	    		log.info("Table "+counter+"/"+totalTables+" refreshed");
    		}
    		
    		return "Comparable materialized tables refreshed";
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error refreshing materialized queries - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
    	
    }
    
    public String refreshEqStressTestMaterializedQuery() throws DataNotValidException {
		
    	try {	
    		String[] matQueryArr = properties.getPropertyMap().get("stressTestEqMatTableList").split(",");
    		Query query = null;
    	
    		String sqlRefresh = "";

    		int totalTables = matQueryArr.length;
    		int counter = 0;
    		
    		for (String matQuery:matQueryArr) {
    			counter++;
    			log.info("Refreshing table "+counter+"/"+totalTables);
    			sqlRefresh = "REFRESH TABLE "+matQuery;
	    		query =  em.createNativeQuery(sqlRefresh);
	    		query.executeUpdate();
	    		log.info("Table "+counter+"/"+totalTables+" refreshed");
    		}
    		
    		return "Stress test materialized tables refreshed";
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error refreshing materialized queries - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
    	
    }
    
    public String refreshMaterializedQuery(String divisCode) throws DataNotValidException {
		//Tables to update
    	String strDivision = "equity";
    	
    	if (divisCode.equalsIgnoreCase("B")) {
    		strDivision = "bond";
    	} else if (divisCode.equalsIgnoreCase("C")) {
    		strDivision = "comparable";
    	}
    	
    	
    	try {	
    		String[] matQueryArr = properties.getPropertyMap().get(strDivision+"MatTableList").split(",");
    		Query query = null;
    	
    		String sqlRefresh = "";
    		
    		int totalTables = matQueryArr.length;
    		int counter = 0;
    		
    		for (String matQuery:matQueryArr) {
    			counter++;
    			log.info("Refreshing table "+counter+"/"+totalTables);
    			sqlRefresh = "REFRESH TABLE "+matQuery;
	    		query =  em.createNativeQuery(sqlRefresh);
	    		query.executeUpdate();
	    		log.info("Table "+counter+"/"+totalTables+" refreshed");
    		}
    		
    		return strDivision+" materialized tables refreshed";
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error refreshing materialized queries - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
    	
    }
    
    public String refreshInterestRatesCurve() throws DataNotValidException {
		//Tables to update
		//String[] matQueryArr = new String[] {"PMPMINSTR","PMPMDINSTR","PMPMSTATS","PMPMDSTATS"};
    	
    	
		try {
			//String[] matQueryArr = properties.getPropertyMap().get("equityMatTableList").split(",");
			Query query = null;
			
    		String sqlRefresh = "";
    		
    		sqlRefresh = "CALL PMPSIRCURV";
	    	query =  em.createNativeQuery(sqlRefresh);
	    	query.executeUpdate();
	    	
    		
    		return "Interest rates curve tables refreshed";
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error refreshing interest rates curve tables - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
    	
    }

}
