package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.MarginNode;
import it.ccg.pamp.server.entities.MarginNodePK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MarginNodeEAO
 */
@Stateless
public class MarginNodeEAO implements  MarginNodeEAOLocal {

@EJB InstrumentEAOLocal instrumentEAO;
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public MarginNode[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllNodes");
    		List<MarginNode> marginNode = query.getResultList();
    		MarginNode[] arrMarginNode = new MarginNode[marginNode.size()];
    		return marginNode.toArray(arrMarginNode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Margin nodes - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public MarginNode[] fetchWithMode1() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllNodesWithMode1");
    		List<MarginNode> marginNode = query.getResultList();
    		MarginNode[] arrMarginNode = new MarginNode[marginNode.size()];
    		return marginNode.toArray(arrMarginNode);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Margin nodes with mode 1 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public MarginNode findByPrimaryKey(int instrId, int mode) throws DataNotValidException {
		try {
			MarginNodePK pK = new MarginNodePK();
			pK.setInstrId(instrId);
			pK.setMode(mode);
			MarginNode marginNode = (MarginNode) em.find(MarginNode.class,pK);
    		return marginNode;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Margin node - instrId: "+instrId+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	//prende i delta attivi
	public Integer[] getActiveDelta(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getNodesActiveDelta");
    		query.setParameter("instrId", instrId);
    		String instrType = instrumentEAO.findByPrimaryKey(instrId).getInstrType();
    		query.setParameter("instrType", instrType);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active delta for Margin nodes - instrId: "+instrId+": "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public MarginNode getMaxMarginByClassId (int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMaxMarginByClassId");
    		query.setParameter("classId", classId);
    		List<MarginNode> maxMargin = query.getResultList();
    		return maxMargin.get(0);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching maximum margin for Margin nodes - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<MarginNode> getMarginNodeByClassId (int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMarginNodeByClassId");
    		query.setParameter("classId", classId);
    		List<MarginNode> maxMarginList = query.getResultList();
    		return maxMarginList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching margin for Margin nodes - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<MarginNode> getMarginNodeByClassIdAndDivisCode (int classId,String divisCode) throws DataNotValidException {
		
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMarginNodeByClassIdAndDivisCode");
    		query.setParameter("classId", classId);
    		query.setParameter("divisCode", divisCode);
    		List<MarginNode> maxMarginList = query.getResultList();
    		return maxMarginList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching margin for Margin nodes - classId: "+classId+"; division: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActivePeriods(int instrId, int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getNodesActivePeriods");
    		query.setParameter("instrId", instrId);
    		query.setParameter("nv", delta);
    		String instrType = instrumentEAO.findByPrimaryKey(instrId).getInstrType();
    		query.setParameter("instrType", instrType);
    		List<Integer> nDaysPerList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nDaysPerList.size()];
    		nDaysPerList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active periods for Margin nodes - instrId: "+instrId+"; delta: "+delta+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getEnabledPeriods(int instrId, int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getNodesEnabledPeriods");
    		query.setParameter("instrId", instrId);
    		query.setParameter("nv", delta);
    		String instrType = instrumentEAO.findByPrimaryKey(instrId).getInstrType();
    		query.setParameter("instrType", instrType);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled periods for Margin nodes - instrId: "+instrId+"; delta: "+delta+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void add(int instrId, int mode, int classId, BigDecimal cover, Timestamp frstHistD, Timestamp lastHistD, BigDecimal margin, int nDaysPer, int nv, String status, String divisCode) throws DataNotValidException {
		
		try {
			MarginNode marginNode = new MarginNode();
			MarginNodePK pK = new MarginNodePK();
			pK.setInstrId(instrId);
			pK.setMode(mode);
			marginNode.setPk(pK);
			marginNode.setClassId(classId);
			marginNode.setCover(cover);
			marginNode.setFrstHistD(frstHistD);
			marginNode.setLastHistD(lastHistD);
			marginNode.setMargin(margin);
			marginNode.setNDaysPer(nDaysPer);
			marginNode.setNv(nv);
			marginNode.setStatus(status);
			marginNode.setUpdDate(GenericTools.systemDate());
			marginNode.setUpdType(updType);
			marginNode.setUpdUsr(userString());
			marginNode.setDivisCode(divisCode);
			em.persist(marginNode);
			log.debug("Added new Margin node - instrId: "+instrId+"; mode: "+mode+"; holding period: "+nv+"; nDaysPer: "+nDaysPer);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Margin node - instrId: "+instrId+"; mode: "+mode+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public void store(MarginNode marginNode) throws DataNotValidException {
		try {
			marginNode.setUpdDate(GenericTools.systemDate());
			marginNode.setUpdType(updType);
			marginNode.setUpdUsr(userString());
			em.persist(marginNode);
			log.debug("Added new Margin node - instrId: "+marginNode.getPk().getInstrId()+"; holding period: "+marginNode.getNv()+"; nDaysPer: "+marginNode.getNDaysPer()+"; mode: "+marginNode.getPk().getMode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Margin node - instrId: "+marginNode.getPk().getInstrId()+"; holding period: "+marginNode.getNv()+"; nDaysPer: "+marginNode.getNDaysPer()+"; mode: "+marginNode.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void update(int instrId, int mode, int classId, BigDecimal cover, Timestamp frstHistD, Timestamp lastHistD, BigDecimal margin, int nDaysPer, int nv, String status, String divisCode) throws DataNotValidException {
		try {
			MarginNode marginNode = findByPrimaryKey(instrId, mode);
			marginNode.setClassId(classId);
			marginNode.setCover(cover);
			marginNode.setFrstHistD(frstHistD);
			marginNode.setLastHistD(lastHistD);
			marginNode.setMargin(margin);
			marginNode.setNDaysPer(nDaysPer);
			marginNode.setNv(nv);
			marginNode.setStatus(status);
			marginNode.setUpdDate(GenericTools.systemDate());
			marginNode.setUpdType("U");
			marginNode.setUpdUsr(userString());
			marginNode.setDivisCode(divisCode);
			log.debug("Margin node updated - instrId: "+instrId+"; mode: "+mode+"; holding period: "+nv+"; nDaysPer: "+nDaysPer);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Margin node - instrId: "+instrId+"; mode: "+mode+"; holding period: "+nv+"; nDaysPer: "+nDaysPer+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(MarginNode marginNode) throws DataNotValidException {
		try {
			log.debug("Margin node updated - instrId: "+marginNode.getPk().getInstrId()+"; holding period: "+marginNode.getNv()+"; nDaysPer: "+marginNode.getNDaysPer()+"; mode: "+marginNode.getPk().getMode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Margin node - instrId: "+marginNode.getPk().getInstrId()+"; holding period: "+marginNode.getNv()+"; nDaysPer: "+marginNode.getNDaysPer()+"; mode: "+marginNode.getPk().getMode()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void remove(int instrId, int mode) throws DataNotValidException {
		try {
			MarginNode marginNode = findByPrimaryKey(instrId, mode);
			em.remove(marginNode);
			log.debug("Margin node removed - instrId: "+instrId+"; mode: "+mode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Margin node - instrId: "+instrId+"; mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteNodesByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Margin nodes removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Margin nodes - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteNodesByEnabledInstrId");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" Margin nodes related to disabled instruments removed - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Margin nodes related to disabled instruments - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int removeByMode(int mode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteNodesByMode");
			query.setParameter("mode", mode);
			int result = query.executeUpdate();
			log.debug(result+" Margin nodes removed - mode: "+mode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Margin nodes - mode: "+mode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(MarginNode marginNode) throws DataNotValidException {
		remove(marginNode.getPk().getInstrId(), marginNode.getPk().getMode());
	}
	
	public MarginNode getMaxMarginByClassIdOrderByPrice (int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		String strQuery = "SELECT N.* FROM PMPTNDMAR N ";
    		strQuery += "INNER JOIN PMPTINSTR I ON N.INSTRID = I.INSTRID AND N.CLASSID = I.BNDCLASSID ";
    		strQuery += "WHERE N.MODE = 1 AND N.CLASSID = "+classId+" ORDER BY N.MARGIN/I.DURATION DESC";
    		
    		query = em.createNativeQuery(strQuery);
    	    
    		List<MarginNode> maxMargin = query.getResultList();
    		return maxMargin.get(0);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching maximum margin for Margin nodes - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}	
	
	public void transferMode1To2() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("deleteMarginNodeWithMode2");
    		query.executeUpdate();
    		query = em.createNativeQuery("INSERT INTO PMPTNDMAR (INSTRID,MODE,CLASSID,STATUS,MARGIN,COVER,NDAYSPER,NV,FRSTHISTD,LASTHISTD,UPDTYPE,UPDUSR,UPDDATE) " +
			"SELECT INSTRID,2,CLASSID,STATUS,MARGIN,COVER,NDAYSPER,NV,FRSTHISTD,LASTHISTD,'C','"+userString()+"','"+GenericTools.systemDate()+"' FROM PMPTNDMAR WHERE MODE=1");
    		query.executeUpdate();
    		log.debug("Transfer of margin nodes from mode 1 to 2 has been completed");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring Margin nodes from mode 1 to 2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void transferMode1To2ByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("deleteMarginNodeWithMode2ByDivisCode");
    		query.setParameter(1, divisCode);
    		query.executeUpdate();
    		query = em.createNativeQuery("INSERT INTO PMPTNDMAR (INSTRID,MODE,CLASSID,STATUS,MARGIN,COVER,NDAYSPER,NV,FRSTHISTD,LASTHISTD,DIVISCODE,UPDTYPE,UPDUSR,UPDDATE) " +
			"SELECT INSTRID,2,CLASSID,STATUS,MARGIN,COVER,NDAYSPER,NV,FRSTHISTD,LASTHISTD,'"+divisCode+"','C','"+userString()+"','"+GenericTools.systemDate()+"' FROM PMPTNDMAR WHERE MODE=1 AND DIVISCODE = '"+divisCode+"'");
    		query.executeUpdate();
    		log.debug("Transfer of margin nodes from mode 1 to 2 has been completed");
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error transferring Margin nodes from mode 1 to 2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
