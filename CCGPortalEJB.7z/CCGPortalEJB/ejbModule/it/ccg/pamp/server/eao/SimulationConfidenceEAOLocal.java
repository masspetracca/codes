package it.ccg.pamp.server.eao;
import java.math.BigDecimal;

import it.ccg.pamp.server.entities.SimulationConfidence;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;
import javax.persistence.Query;

@Local
public interface SimulationConfidenceEAOLocal {
	public SimulationConfidence[] fetch() throws DataNotValidException; 
	public SimulationConfidence findByPrimaryKey(int instrId, int nDaysPer, int nv, int uncev) throws DataNotValidException;
	public SimulationConfidence[] findByInstrId(int instrId) throws DataNotValidException;
	public SimulationConfidence find(int instrId, int nDaysPer, int nv) throws DataNotValidException;
	public Integer[] getActiveDelta(int instrId) throws DataNotValidException;
	public Integer[] getActivePeriods(int instrId, int delta) throws DataNotValidException;
	public Integer[] getEnabledPeriods(int instrId, int delta) throws DataNotValidException;
	public void add(int instrId, int nDaysPer, int nv, int uncev, String status, BigDecimal confidence, int uncevSel, BigDecimal covPerc) throws DataNotValidException;
	public void store(SimulationConfidence simulationConfidence) throws DataNotValidException;
	public void update(int instrId, int nDaysPer, int nv, int uncev, String status, BigDecimal confidence, int uncevSel, BigDecimal covPerc) throws DataNotValidException;
	public void update(SimulationConfidence simulationConf) throws DataNotValidException;
	public void remove(int instrId, int nDaysPer, int nv, int uncev) throws DataNotValidException;
	public int removeByInstrId(int instrId) throws DataNotValidException;
	public void remove(SimulationConfidence simulationConf) throws DataNotValidException;
}
