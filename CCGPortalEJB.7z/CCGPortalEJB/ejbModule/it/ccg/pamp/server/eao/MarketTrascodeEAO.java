package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.MarketTrascode;
import it.ccg.pamp.server.entities.MarketTrascodePK;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MarketCodeEAO
 */
@Stateless
public class MarketTrascodeEAO implements  MarketTrascodeEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public List<MarketTrascode> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllMarketTrsCode");
    		List<MarketTrascode> marketTranscode = query.getResultList();
    		return marketTranscode;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from market transcode - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<MarketTrascode> getMarketTrsCodeByMarketCode(String marketCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMarketTrsCodeByMarketCode");
    		query.setParameter("marketCode", marketCode);
    		List<MarketTrascode> marketTranscode = query.getResultList();
    		return marketTranscode;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from market transcode - marketCode: "+marketCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<MarketTrascode> getMarketTrsCodeBySicMarketCode(String sicMarket) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMarketTrsCodeBySicMarketCode");
    		query.setParameter("sicMarket", sicMarket);
    		List<MarketTrascode> marketTranscode = query.getResultList();
    		return marketTranscode;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from market transcode - sicMarketCode: "+sicMarket+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
		
	public MarketTrascode findByPrimaryKey(String marketCode, String sicMarket) throws DataNotValidException {
		try {
			MarketTrascodePK pK = new MarketTrascodePK();
			pK.setMarketCode(marketCode);
			pK.setSicmarket(sicMarket);
			
			MarketTrascode marketTrascode = (MarketTrascode) em.find(MarketTrascode.class,pK);
    		return marketTrascode;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from market transcode - marketCode: "+marketCode+"; sicMarket: "+sicMarket+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
}


