package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.SimulationVariation;
import it.ccg.pamp.server.entities.SimulationVariationPK;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class SimulationSimulationVariationEAO
 */
@Stateless
public class SimulationVariationEAO implements  SimulationVariationEAOLocal {

@EJB private HistoricalPricesRettEAOLocal hisprRett;
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	
	public SimulationVariation[] fetchAllSimVar() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSim");
    		List<SimulationVariation> simulationVariation = query.getResultList();
    		SimulationVariation[] arrSimulationVariation = new SimulationVariation[simulationVariation.size()];
    		return simulationVariation.toArray(arrSimulationVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching SimulationVariations - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationVariation[] fetchSimDerVar() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSimDerVar");
    		List<SimulationVariation> simulationVariation = query.getResultList();
    		SimulationVariation[] arrSimulationVariation = new SimulationVariation[simulationVariation.size()];
    		return simulationVariation.toArray(arrSimulationVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives SimulationVariations - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationVariation[] fetchSimVar() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSimVar");
    		List<SimulationVariation> simulationVariation = query.getResultList();
    		SimulationVariation[] arrSimulationVariation = new SimulationVariation[simulationVariation.size()];
    		return simulationVariation.toArray(arrSimulationVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching SimulationVariations - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public String getSimulationVariationString() throws DataNotValidException {
		String message="Time range: ";
		Timestamp lastDate = hisprRett.findLastDate().getPk().getPriceDate();
		Timestamp firstDate = hisprRett.findFirstDate().getPk().getPriceDate();
		message += "from "+firstDate.toString().substring(0,10)+" to "+lastDate.toString().substring(0,10);
		return message;
	}*/
	
	public SimulationVariation[] findByInstrId(Instrument instr) throws DataNotValidException {
		Query query = null;
    	try {
    		query.setParameter("instrId", instr.getInstrId());
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getSimDerVarByInstrId");
    		} else {
    			query = em.createNamedQuery("getSimVarByInstrId");
    		}
    		query.setParameter("updUsr", userString());
    		List<SimulationVariation> simulationVariation = query.getResultList();
    		SimulationVariation[] arrSimulationVariation = new SimulationVariation[simulationVariation.size()];
    		return simulationVariation.toArray(arrSimulationVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives SimulationVariations - instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationVariation[] fetchWithHp(Instrument instr) throws DataNotValidException {
		Query query = null;
    	try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getSimDerVarByDHP");
    		} else {
    			query = em.createNamedQuery("getSimVarByHP");
    		}
    		query.setParameter("updUsr", userString());
    		query.setParameter("instrId", instr.getInstrId());
    		List<SimulationVariation> simulationVariation = query.getResultList();
    		SimulationVariation[] arrSimulationVariation = new SimulationVariation[simulationVariation.size()];
    		return simulationVariation.toArray(arrSimulationVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching SimulationVariations with Historical Prices - instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public SimulationVariation[] fetchWithHisVol(int instrId, int progExp) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPByHisVol");
    		query.setParameter("instrId", instrId);
    		query.setParameter("progExp", progExp);
    		List<SimulationVariation> simulationVariation = query.getResultList();
    		SimulationVariation[] arrSimulationVariation = new SimulationVariation[simulationVariation.size()];
    		return simulationVariation.toArray(arrSimulationVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching SimulationVariations with Historical Volatility Series - instrId: "+instrId+"; progExp: "+progExp+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
	public SimulationVariation[] findByInstrIdAndVarTypeAndNv(Instrument instr, String varType,int nv) throws DataNotValidException {
		Query query = null;
    	try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getSimDerVarByInstrIdAndVarTypeAndNv");
    			query.setParameter("prgExp", instr.getDefHistSer());
    		} else {
    			query = em.createNamedQuery("getSimVarByInstrIdAndVarTypeAndNv");
    		}
    		query.setParameter("updUsr", userString());
    		query.setParameter("instrId", instr.getInstrId());		
    		query.setParameter("varType", varType);
    		query.setParameter("nv", nv);
    		List<SimulationVariation> simulationVariation = query.getResultList();
    		SimulationVariation[] arrSimulationVariation = new SimulationVariation[simulationVariation.size()];
    		return simulationVariation.toArray(arrSimulationVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching SimulationVariations - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; varType: "+varType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationVariation[] findByInstrIdAndVarTypeAndNvAndDate(Instrument instr, String varType,int nv, Timestamp startDate, Timestamp endDate) throws DataNotValidException {
		Query query = null;
    	try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getSimDerVarByInstrIdAndVarTypeAndNvAndDate");
    		} else {
    			query = em.createNamedQuery("getSimVarByInstrIdAndVarTypeAndNvAndDate");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("varType", varType);
    		query.setParameter("nv", nv);
    		query.setParameter("startDate", startDate);
    		query.setParameter("endDate", endDate);
    		query.setParameter("updUsr", userString());
    		List<SimulationVariation> simulationVariation = query.getResultList();
    		SimulationVariation[] arrSimulationVariation = new SimulationVariation[simulationVariation.size()];
    		return simulationVariation.toArray(arrSimulationVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives SimulationVariations - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; varType: "+varType+"; priceDate between "+startDate+" and "+endDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationVariation findByPrimaryKey(int instrId, int prgExp, int nv, Timestamp priceDate, String varType) throws DataNotValidException {
		try {
			SimulationVariationPK pK = new SimulationVariationPK();
			pK.setInstrId(instrId);
			pK.setPrgExp(prgExp);
			pK.setNv(nv);
			pK.setPriceDate(priceDate);
			pK.setVarType(varType);
			pK.setUpdUsr(userString());
			SimulationVariation simulationVariation = (SimulationVariation) em.find(SimulationVariation.class,pK);
    		return simulationVariation;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching SimulationVariation - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationVariation[] findVarByDateInterval(Timestamp startDate, Timestamp endDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSimVarByDate");
    		query.setParameter("startDate", startDate);
    		query.setParameter("endDate", endDate);
    		query.setParameter("updUsr", userString());
    		List<SimulationVariation> simulationVariation = query.getResultList();
    		SimulationVariation[] arrSimulationVariation = new SimulationVariation[simulationVariation.size()];
    		return simulationVariation.toArray(arrSimulationVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives SimulationVariations - priceDate between "+startDate+" and "+endDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationVariation[] findSimDerVarByDateInterval(Timestamp startDate, Timestamp endDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSimDerVarByDate");
    		query.setParameter("startDate", startDate);
    		query.setParameter("endDate", endDate);
    		query.setParameter("updUsr", userString());
    		List<SimulationVariation> simulationVariation = query.getResultList();
    		SimulationVariation[] arrSimulationVariation = new SimulationVariation[simulationVariation.size()];
    		return simulationVariation.toArray(arrSimulationVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives SimulationVariations - priceDate between "+startDate+" and "+endDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public SimulationVariation[] getFixedSimulationVariations(Instrument instr, int nv, int period, Timestamp lastDate, String varType) throws DataNotValidException {
		Query query = null;
    	try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getFixedDerivativesSimulationVariations");
    		} else {
    			query = em.createNamedQuery("getFixedSimulationVariations");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("nv", nv);
    		query.setParameter("lastDate", lastDate);
    		query.setParameter("varType", varType);
    		query.setParameter("updUsr", userString());
    		query.setMaxResults(period);
    		List<SimulationVariation> simulationVariation = query.getResultList();
    		SimulationVariation[] arrSimulationVariation = new SimulationVariation[simulationVariation.size()];
    		return simulationVariation.toArray(arrSimulationVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching fixed Derivatives SimulationVariations - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; varType: "+varType+"; lastDate: "+lastDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int getSizeByInstrId(Instrument instr) throws DataNotValidException {
		Query query = null;
    	try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getSimDerVarSizeByInstrId");
    		} else {
    			query = em.createNamedQuery("getSimVarSizeByInstrId");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("updUsr", userString());
    		Long size = (Long) query.getSingleResult();
    		return size.intValue();
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives SimulationVariations size - instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int getSizeByInstrIdAndNvAndTh(Instrument instr, int nv, BigDecimal th) throws DataNotValidException {
		Query query = null;
    	try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getSimDerVarSizeByInstrIdAndNvAndTh");
    		} else {
    			query = em.createNamedQuery("getSimVarSizeByInstrIdAndNvAndTh");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("nv", nv);
    		query.setParameter("th", th);
    		query.setParameter("updUsr", userString());
    		Long size = (Long) query.getSingleResult();
    		return size.intValue();
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives SimulationVariations size - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; th: "+th+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int getSizeByInstrIdAndNv(Instrument instr, int nv) throws DataNotValidException {
		Query query = null;
    	try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getSimDerVarSizeByInstrIdAndNv");
    		} else {
    			query = em.createNamedQuery("getSimVarSizeByInstrIdAndNv");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("nv", nv);
    		query.setParameter("updUsr", userString());
    		Long size = (Long) query.getSingleResult();
    		return size.intValue();
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives SimulationVariations size - instrId: "+instr.getInstrId()+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int getSizeByInstrIdAndVarTypeAndNv(Instrument instr, String varType, int nv) throws DataNotValidException {
		Query query = null;
    	try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getSimDerVarSizeByInstrIdAndVarTypeAndNv");
    		} else {
    			query = em.createNamedQuery("getSimVarSizeByInstrIdAndVarTypeAndNv");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("nv", nv);
    		query.setParameter("varType", varType);
    		query.setParameter("updUsr", userString());
    		Long size = (Long) query.getSingleResult();
    		return size.intValue();
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives SimulationVariations size - instrId: "+instr.getInstrId()+"; varType: "+varType+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public BigDecimal getExtremeValues(Instrument instr, int nv, String varType, int period, int exclude, int n, int choose) throws DataNotValidException {
		Query query = null;
		String queryName = "";
    	try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			queryName = "getSimDerVarExtremeValues";
    		} else {
    			queryName = "getSimVarExtremeValues";
    		}
    		
    		switch (exclude) {
				case 0:
					break;
				case 1:
					queryName += "Pos";
					break;
				case -1:
					queryName += "Neg";
					break;
    		}
    		query = em.createNamedQuery(queryName);
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("nv", nv);
    		query.setParameter("varType", varType);
    		query.setParameter("updUsr", userString());
    		//prende la serie di variazioni scelta
    		query.setMaxResults(period);
    		
    		//query.setFirstResult(exclude);
    		List<BigDecimal> variat = query.getResultList();
    		BigDecimal[] arrVariat = new BigDecimal[variat.size()];
    		variat.toArray(arrVariat);
    		for (int i=0;i<arrVariat.length;i++) {
    			arrVariat[i]=arrVariat[i].abs();
    		}
    		Arrays.sort(arrVariat);
    		return arrVariat[arrVariat.length-n-exclude];
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Exreme Derivatives SimulationVariation value - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; varType "+varType+"; period: "+period+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Timestamp getOldestDateByInstrId(Instrument instr) throws DataNotValidException {
		Query query = null;
    	try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getSimDerVarOldestDateByInstrId");
    		} else {
    			query = em.createNamedQuery("getSimVarOldestDateByInstrId");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("updUsr", userString());
    		//List<Integer> simulationVariation = query.getResultList();
    		Timestamp oldestDate = (Timestamp) query.getSingleResult();
    		//SimulationVariation[] arrSimulationVariation = new SimulationVariation[1];
    		return oldestDate;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Oldest Derivatives SimulationVariation date - instrId: "+ instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Timestamp getLatestDateByInstrId(Instrument instr) throws DataNotValidException {
		Query query = null;
    	try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getSimDerVarLatestDateByInstrId");
    		} else {
    			query = em.createNamedQuery("getSimVarLatestDateByInstrId");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("updUsr", userString());
    		//List<Integer> simulationVariation = query.getResultList();
    		Timestamp oldestDate = (Timestamp) query.getSingleResult();
    		//SimulationVariation[] arrSimulationVariation = new SimulationVariation[1];
    		return oldestDate;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Latest SimulationVariation date - instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, int prgExp, int nv, Timestamp priceDate, String varType, BigDecimal variat, BigDecimal oVariat) throws DataNotValidException {
		try {
			SimulationVariation simulationVariation = new SimulationVariation();
			SimulationVariationPK pK = new SimulationVariationPK();
			pK.setInstrId(instrId);
			pK.setPrgExp(prgExp);
			pK.setNv(nv);
			pK.setPriceDate(priceDate);
			pK.setVarType(varType);
			pK.setUpdUsr(userString());
			simulationVariation.setPk(pK);
			simulationVariation.setVariat(variat);
			simulationVariation.setOVariat(oVariat);
			simulationVariation.setUpdType("C");
			simulationVariation.setUpdDate(GenericTools.systemDate());
			em.persist(simulationVariation);
			log.debug("Added new Derivatives SimulationVariation - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate+"; simulationVariation: "+variat);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Derivatives SimulationVariation - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(Variation variation) throws DataNotValidException {
		try {
			SimulationVariation simulationVariation = new SimulationVariation();
			SimulationVariationPK pK = new SimulationVariationPK();
			pK.setInstrId(variation.getPk().getInstrId());
			pK.setPrgExp(variation.getPk().getPrgExp());
			pK.setNv(variation.getPk().getNv());
			pK.setPriceDate(variation.getPk().getPriceDate());
			pK.setVarType(variation.getPk().getVarType());
			pK.setUpdUsr(userString());
			simulationVariation.setPk(pK);
			simulationVariation.setVariat(variation.getVariat());
			simulationVariation.setOVariat(variation.getVariat());
			simulationVariation.setUpdType("C");
			simulationVariation.setUpdDate(GenericTools.systemDate());
			em.persist(simulationVariation);
			log.debug("Added new SimulationVariation - instrId: "+variation.getPk().getInstrId()+"; prgExp: "+variation.getPk().getPrgExp()+"; holding period: "+variation.getPk().getNv()+"; varType: "+variation.getPk().getVarType()+"; priceDate: "+variation.getPk().getPriceDate()+"; variation: "+variation.getVariat());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new SimulationVariation - instrId: "+variation.getPk().getInstrId()+"; prgExp: "+variation.getPk().getPrgExp()+"; holding period: "+variation.getPk().getNv()+"; varType: "+variation.getPk().getVarType()+"; priceDate: "+variation.getPk().getPriceDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(SimulationVariation simulationVariation) throws DataNotValidException {
		try {
			SimulationVariationPK pK = new SimulationVariationPK();
			pK.setInstrId(simulationVariation.getPk().getInstrId());
			pK.setPrgExp(simulationVariation.getPk().getPrgExp());
			pK.setNv(simulationVariation.getPk().getNv());
			pK.setPriceDate(simulationVariation.getPk().getPriceDate());
			pK.setVarType(simulationVariation.getPk().getVarType());
			pK.setUpdUsr(userString());
			simulationVariation.setPk(pK);
			simulationVariation.setUpdType("C");
			simulationVariation.setUpdDate(GenericTools.systemDate());
			em.persist(simulationVariation);
			log.debug("Added new SimulationVariation - instrId: "+simulationVariation.getPk().getInstrId()+"; prgExp: "+simulationVariation.getPk().getPrgExp()+"; holding period: "+simulationVariation.getPk().getNv()+"; varType: "+simulationVariation.getPk().getVarType()+"; priceDate: "+simulationVariation.getPk().getPriceDate()+"; variation: "+simulationVariation.getVariat());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new SimulationVariation - instrId: "+simulationVariation.getPk().getInstrId()+"; prgExp: "+simulationVariation.getPk().getPrgExp()+"; holding period: "+simulationVariation.getPk().getNv()+"; varType: "+simulationVariation.getPk().getVarType()+"; priceDate: "+simulationVariation.getPk().getPriceDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, int prgExp, int nv, Timestamp priceDate, String varType, BigDecimal variat, BigDecimal oVariat) throws DataNotValidException {
		try {	
			SimulationVariation simulationVariation = findByPrimaryKey(instrId, prgExp, nv, priceDate, varType);
			simulationVariation.setVariat(variat);
			simulationVariation.setOVariat(oVariat);
			simulationVariation.setUpdType("U");
			simulationVariation.setUpdDate(GenericTools.systemDate());
			log.debug("Derivatives SimulationVariation updated - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate+"; simulationVariation: "+variat);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Derivatives SimulationVariation - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(SimulationVariation derVar) throws DataNotValidException {
		try {
			SimulationVariation simulationVariation = findByPrimaryKey(derVar.getPk().getInstrId(), derVar.getPk().getPrgExp(), derVar.getPk().getNv(), derVar.getPk().getPriceDate(),derVar.getPk().getVarType());
			simulationVariation.setUpdType("U");
			simulationVariation.setUpdDate(GenericTools.systemDate());
			log.debug("Derivatives SimulationVariation updated - instrId: "+derVar.getPk().getInstrId()+"; holding period: "+derVar.getPk().getNv()+"; varType: "+derVar.getPk().getVarType()+"; priceDate: "+derVar.getPk().getPriceDate()+"; simulationVariation: "+derVar.getVariat());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating SimulationVariation - instrId: "+derVar.getPk().getInstrId()+"; holding period: "+derVar.getPk().getNv()+"; varType: "+derVar.getPk().getVarType()+"; priceDate: "+derVar.getPk().getPriceDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void logUpdate(SimulationVariation derVar) throws DataNotValidException {
		try {
			update(derVar);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating SimulationVariation - instrId: "+derVar.getPk().getInstrId()+"; holding period: "+derVar.getPk().getNv()+"; varType: "+derVar.getPk().getVarType()+"; priceDate: "+derVar.getPk().getPriceDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, int prgExp, int nv, Timestamp priceDate, String varType) throws DataNotValidException {
		try {
			SimulationVariation simulationVariation = findByPrimaryKey(instrId, prgExp, nv, priceDate, varType);
			em.remove(simulationVariation);
			log.debug("SimulationVariation removed - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing SimulationVariation - - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(SimulationVariation derVar) throws DataNotValidException {
		remove(derVar.getPk().getInstrId(), derVar.getPk().getPrgExp(), derVar.getPk().getNv(), derVar.getPk().getPriceDate(), derVar.getPk().getVarType());
	}
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteSimDerVarByEnabledInstrId");
			query.setParameter("updUsr", userString());
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" Simulation Variations related to disabled instruments removed - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Simulation Variations related to disabled instruments removed - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public int removeByInstrId(Instrument instr) throws DataNotValidException {
		try {
			Query query = null;
			if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("deleteSimDerVarByInstrId");
    		} else {
    			query = em.createNamedQuery("deleteSimVarByInstrId");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("updUsr", userString());
			int result = query.executeUpdate();
			log.debug("InstrId: "+instr.getInstrId()+" - "+result+" Simulation Variation removed");
			return result;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing SimulationVariations - instrId: "+instr.getInstrId()+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

}
