package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.HistoricalPrices;
import it.ccg.pamp.server.entities.HistoricalPricesPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.HistoricalPriceToExport;
import it.ccg.pamp.server.utils.HistoricalPricesForBonds;
import it.ccg.pamp.server.utils.HistoricalPricesForChart;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class HistoricalPricesEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class HistoricalPricesEAO implements HistoricalPricesEAOLocal {
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public String userString = "System";
	public String updType = "C";
	
	public HistoricalPrices[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllHP");
    		//String strQuery = "SELECT * FROM PMPTHISPR";
    		//query = em.createNativeQuery(strQuery,HistoricalPrices.class);
    		List<HistoricalPrices> historicalPrices = query.getResultList();
    		HistoricalPrices[] arrHistoricalPrices = new HistoricalPrices[historicalPrices.size()];
    		return historicalPrices.toArray(arrHistoricalPrices);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching all Historical Prices - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalPrices[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPByInstrId");
    		query.setParameter("instrId", instrId);
    		List<HistoricalPrices> historicalPrices = query.getResultList();
    		HistoricalPrices[] arrHistoricalPrices = new HistoricalPrices[historicalPrices.size()];
    		return historicalPrices.toArray(arrHistoricalPrices);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Timestamp> getLastNDays(int maxDays) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getLastNDays");
    		List<Timestamp> historicalPriceDayList = query.getResultList();
    		query.setMaxResults(maxDays);
    		return historicalPriceDayList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching first "+maxDays+" historical price dates - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public long countByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHistPriceNumbByInstrId");
    		query.setParameter("instrId", instrId);
    		long countHistPr = (Long)query.getSingleResult();
    		return countHistPr;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Timestamp findHPMaxDate() throws DataNotValidException {
		Query query = null;
    	try {
    		//String strQuery = "SELECT MAX(DISTINCT(PRICEDATE)) FROM PMPTHISPR";
    		//query = em.createNativeQuery(strQuery,Timestamp.class);
    		query = em.createNamedQuery("getHPMaxDate");
    		List<Timestamp> maxDateList = query.getResultList();
    		if (maxDateList.size()>0) {
    			return maxDateList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices maximum date - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalPrices[] findByInstrIdForDownload(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPDByInstrId");
    		query.setParameter("instrId", instrId);
    		List<HistoricalPrices> historicalPrices = query.getResultList();
    		HistoricalPrices[] arrHistoricalPrices = new HistoricalPrices[historicalPrices.size()];
    		return historicalPrices.toArray(arrHistoricalPrices);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<HistoricalPricesForChart> getValuesForChart(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		String strQuery = "SELECT H.INSTRID AS INSTRID,H.PRICEDATE AS PRICEDATE,H.CLOSEPR AS CLOSEPRICE,HPR.CLOSEPRRET AS CLOSEPRICERET,";
    		strQuery += "C.CATYPE AS CATYPE,C.KCOEFF AS KCOEFF FROM PMPTHISPR H ";
    		strQuery +="INNER JOIN PMPTHISPRR HPR LEFT JOIN PMPTCORPAC C ";
    		strQuery +="ON C.INSTRID=HPR.INSTRID AND C.FRSTEXDATE=HPR.PRICEDATE ";
    		strQuery +="ON H.INSTRID = HPR.INSTRID AND H.PRICEDATE= HPR.PRICEDATE ";
    		strQuery +="WHERE H.INSTRID = ?1 ORDER BY H.PRICEDATE ASC";
    		query = em.createNativeQuery(strQuery,HistoricalPricesForChart.class);
    		query.setParameter(1, instrId);
    		List<HistoricalPricesForChart> historicalPricesForChart = query.getResultList();
    		return historicalPricesForChart;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<HistoricalPricesForBonds> getValuesForBondChart(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		
    		String strQuery = "SELECT IRNODE, IRNODEDESC, PRICEDATE, CLOSEPR AS CLOSEPRICE, AVE20, AVE250, STD20 AS STDEV20, STD250 AS STDEV250 FROM PMPTIRCURV ";
    		strQuery += "WHERE LISTNAME IN (SELECT LISTNAME FROM PMPTINSTR WHERE INSTRID = "+instrId+") AND NUMBER IN (0,5,21,42,64,127,191,253)";
    		strQuery += " ORDER BY PRICEDATE,IRNODE";
    		
    		query = em.createNativeQuery(strQuery,HistoricalPricesForBonds.class);
    		List<HistoricalPricesForBonds> historicalPricesForBonds = query.getResultList();
    		return historicalPricesForBonds;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BigDecimal findLastPrice(int instrId, Timestamp dateRif) throws DataNotValidException {
		Query query = null;
		try {
			String date = dateRif.toString().substring(0, 10);
    		int year = Integer.parseInt(date.substring(0,4));
    		int month = Integer.parseInt(date.substring(5,7))-1;
    		int day = Integer.parseInt(date.substring(8))+1;
    		
    		GregorianCalendar cal = new GregorianCalendar(year,month,day);
    		Timestamp priceDate = new Timestamp(cal.getTimeInMillis());
			
    		query = em.createNamedQuery("getHPfindLastPrice");
    		query.setParameter("instrId", instrId);
    		query.setParameter("priceDate", priceDate);
    		query.setMaxResults(1);
    		List<HistoricalPrices> historicalPricesList = query.getResultList();
    		HistoricalPrices historicalPrices = historicalPricesList.get(0);
    		return historicalPrices.getClosepr();
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last Historical Price - instrId: "+instrId+"; date: "+dateRif+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalPrices findBeforeDate(int instrId, Timestamp priceDate) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getHPBeforeLastDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("priceDate", priceDate);
    		query.setMaxResults(1);
    		List<HistoricalPrices> historicalPricesList = query.getResultList();
    		if (historicalPricesList.size()>0) {
    			return historicalPricesList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last historical price - instrId: "+instrId+"; date: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalPrices findAfterDate(int instrId, Timestamp priceDate) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getHPAfterDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("priceDate", priceDate);
    		query.setMaxResults(1);
    		List<HistoricalPrices> historicalPricesList = query.getResultList();
    		if (historicalPricesList.size()>0) {
    			return historicalPricesList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching next historical price - instrId: "+instrId+"; date: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalPrices findLastDateByInstrument(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getHPDByInstrId");
    		query.setParameter("instrId", instrId);
    		List<HistoricalPrices> historicalPricesList = query.getResultList();
    		if (historicalPricesList.size()>0) {
    			return historicalPricesList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last historical price - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalPrices findBeforeDate(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getHPByInstrId");
    		query.setParameter("instrId", instrId);
    		query.setMaxResults(1);
    		List<HistoricalPrices> historicalPricesList = query.getResultList();
    		if (historicalPricesList.size()>0) {
    			return historicalPricesList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last historical price - instrId: "+instrId+"; - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public BigDecimal findAvgPun(int instrId, int year, int month) throws DataNotValidException {
		Query query = null;
		try {
			GregorianCalendar init= new GregorianCalendar(year,month-1,1);
			GregorianCalendar end= new GregorianCalendar(year,month-1,1);
			end.add(GregorianCalendar.MONTH, 1);
			Timestamp startDate = new Timestamp(init.getTimeInMillis());
			Timestamp endDate = new Timestamp(end.getTimeInMillis());
						
			query = em.createNamedQuery("getAVGPunByInstrIdAndYearAndMonth");
    		query.setParameter("instrId", instrId);
    		query.setParameter("startDate", startDate);
    		query.setParameter("endDate", endDate);
    		
			BigDecimal avgPun = (BigDecimal) query.getSingleResult();
    		return avgPun;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching average PUN - instrId: "+instrId+"; year: "+year+"; month: "+month+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public int getTimeWindow(int instrId, Timestamp firstDate, Timestamp lastDate) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getHPbyTimeWindow");
    		query.setParameter("instrId", instrId);
    		query.setParameter("firstDate", firstDate);
    		query.setParameter("lastDate", lastDate);
    		Long counter = (Long) query.getSingleResult();
    		return counter.intValue();
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last Historical Price - instrId: "+instrId+"; time window: "+firstDate+ " - "+lastDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public HistoricalPrices[] fetchWithCa(int instrId, Timestamp lastDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPByCa");
    		query.setParameter("instrId", instrId);
    		query.setParameter("lastDate", lastDate);
    		List<HistoricalPrices> historicalPrices = query.getResultList();
    		HistoricalPrices[] arrHistoricalPrices = new HistoricalPrices[historicalPrices.size()];
    		return historicalPrices.toArray(arrHistoricalPrices);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices joined with Corporate Action - instrId: "+instrId+"; date: "+lastDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public HistoricalPrices[] fetchInInterval(int instrId, Timestamp lastDate,Timestamp firstDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPInInterval");
    		query.setParameter("instrId", instrId);
    		query.setParameter("lastDate", lastDate);
    		query.setParameter("firstDate", firstDate);
    		List<HistoricalPrices> historicalPrices = query.getResultList();
    		HistoricalPrices[] arrHistoricalPrices = new HistoricalPrices[historicalPrices.size()];
    		return historicalPrices.toArray(arrHistoricalPrices);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices joined with Corporate Action - instrId: "+instrId+"; date: "+lastDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	
	public HistoricalPrices[] fetchWithVar(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPByVar");
    		query.setParameter("instrId", instrId);
    		List<HistoricalPrices> historicalPrices = query.getResultList();
    		HistoricalPrices[] arrHistoricalPrices = new HistoricalPrices[historicalPrices.size()];
    		return historicalPrices.toArray(arrHistoricalPrices);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices joined with Variation - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalPrices[] fetchWithHisVol(int instrId, int progExp) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPByHisVol");
    		query.setParameter("instrId", instrId);
    		query.setParameter("progExp", progExp);
    		List<HistoricalPrices> historicalPrices = query.getResultList();
    		HistoricalPrices[] arrHistoricalPrices = new HistoricalPrices[historicalPrices.size()];
    		return historicalPrices.toArray(arrHistoricalPrices);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices joined with Historical Volatility Series - instrId: "+instrId+"; progExp: "+progExp+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public HistoricalPrices findByPrimaryKey(int instrId, Timestamp priceDate) throws DataNotValidException {
		try {
			HistoricalPricesPK pK = new HistoricalPricesPK();
			pK.setInstrId(instrId);
			pK.setPriceDate(priceDate);
    		HistoricalPrices historicalPrices = (HistoricalPrices) em.find(HistoricalPrices.class,pK);
    		return historicalPrices;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Price - instrId: "+instrId+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public void add(int instrId, Timestamp priceDate, BigDecimal closePr, String status) throws DataNotValidException {
		try {	
			HistoricalPrices historicalPrices = findByPrimaryKey(instrId,priceDate);
			historicalPrices = new HistoricalPrices();
			HistoricalPricesPK pK = new HistoricalPricesPK();
			pK.setInstrId(instrId);
			pK.setPriceDate(priceDate);
			historicalPrices.setPk(pK);
			historicalPrices.setClosepr(closePr);
			historicalPrices.setStatus(status);
			historicalPrices.setUpdType(updType);
			historicalPrices.setUpdDate(GenericTools.systemDate());
			historicalPrices.setUpdUsr(userString());
			em.persist(historicalPrices);
			log.debug("Added new Historical Price - instrId: "+instrId+"; priceDate: "+priceDate+"; closePr: "+closePr);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Historical Price - instrId: "+instrId+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(HistoricalPrices historicalPrices) throws DataNotValidException {
		try {
			historicalPrices.setUpdType(updType);
			historicalPrices.setUpdDate(GenericTools.systemDate());
			historicalPrices.setUpdUsr(userString());
			em.persist(historicalPrices);
			log.debug("Added new Historical Price - instrId: "+historicalPrices.getPk().getInstrId()+"; priceDate: "+historicalPrices.getPk().getPricedate()+"; closePr: "+historicalPrices.getClosepr());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Historical Price - instrId: "+historicalPrices.getPk().getInstrId()+"; priceDate: "+historicalPrices.getPk().getPricedate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public void restore(int updId) throws DataNotValidException {
		Query query = null;	
		try {
			query = em.createNamedQuery("getHPArchByUpdId");
    		query.setParameter("updId", updId);
    		HistoricalPricesArchive hpArchive = (HistoricalPricesArchive) query.getSingleResult();
    		HistoricalPrices historicalPrices = findByPrimaryKey(hpArchive.getInstrId(),hpArchive.getPriceDate());
    		boolean notExists = false;
    		if (historicalPrices==null) {
    			historicalPrices = new HistoricalPrices();
    			HistoricalPricesPK pK = new HistoricalPricesPK();
    			pK.setInstrId(hpArchive.getInstrId());
    			pK.setPriceDate(hpArchive.getPriceDate());
    			historicalPrices.setPk(pK);
    			notExists = true;
    		}
    		historicalPrices.setClosepr(hpArchive.getClosePr());
    		historicalPrices.setStatus(hpArchive.getStatus());
    		historicalPrices.setUpdType("U");
    		historicalPrices.setUpdDate(GenericTools.systemDate());
    		historicalPrices.setUpdUsr(hpArchive.getUpdUsr());
    		if (notExists) {
    			store(historicalPrices);
    		}
			log.debug("Historical Price restored - instrId: "+hpArchive.getInstrId()+"; priceDate: "+hpArchive.getPriceDate()+"; closePr: "+hpArchive.getClosePr());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error restoring Historical Prices from archive - updId: "+updId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
	public void update(int instrId, Timestamp priceDate, BigDecimal closePr, String status) throws DataNotValidException {
		try {
			HistoricalPrices historicalPrices = findByPrimaryKey(instrId,priceDate);
			historicalPrices.setClosepr(closePr);
			historicalPrices.setStatus(status);
			historicalPrices.setUpdType("U");
			historicalPrices.setUpdDate(GenericTools.systemDate());
			historicalPrices.setUpdUsr(userString());
			log.debug("Historical Price updated - instrId: "+instrId+"; priceDate: "+priceDate+"; closePr: "+closePr);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Historical Price - instrId: "+instrId+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(HistoricalPrices histPrices) throws DataNotValidException {
		try {	
			HistoricalPrices historicalPrices = findByPrimaryKey(histPrices.getPk().getInstrId(),histPrices.getPk().getPricedate());
			historicalPrices.setUpdType("U");
			historicalPrices.setUpdDate(GenericTools.systemDate());
			historicalPrices.setUpdUsr(userString());
			log.debug("Historical Price updated - instrId: "+historicalPrices.getPk().getInstrId()+"; priceDate: "+historicalPrices.getPk().getPricedate()+"; closePr: "+historicalPrices.getClosepr());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Historical Price - instrId: "+histPrices.getPk().getInstrId()+"; priceDate: "+histPrices.getPk().getPricedate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, Timestamp priceDate) throws DataNotValidException {
		try {
			HistoricalPrices historicalPrices = findByPrimaryKey(instrId,priceDate);
			em.remove(historicalPrices);
			log.debug("Historical Price removed - instrId: "+instrId+"; priceDate: "+priceDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Historical Price- instrId: "+instrId+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public int removeByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteHPByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Historical Prices removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Historical Price - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(HistoricalPrices histPrices) throws DataNotValidException {
		remove(histPrices.getPk().getInstrId(),histPrices.getPk().getPricedate());
	}
		
	public void flush() {
		em.flush();
	}
	
	/*public void backup(HistoricalPrices histPrices) throws DataNotValidException {
		try {
			HistoricalPricesArchive hpX = new HistoricalPricesArchive();
    		
			hpX.setInstrId(histPrices.getPk().getInstrId());
			hpX.setPriceDate(histPrices.getPk().getPricedate());
    		hpX.setClosePr(histPrices.getClosepr());
    		hpX.setStatus(histPrices.getStatus());
    		hpX.setUpdType("D");
    		hpX.setUpdDate(GenericTools.systemDate());
    		hpX.setUpdUsr(userString());
    		em.persist(hpX);
			log.debug("Historical Price backuped - instrId: "+histPrices.getPk().getInstrId()+"; priceDate: "+histPrices.getPk().getPricedate()+"; closePr: "+histPrices.getClosepr());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error backuping Historical Prices from archive - instrId: "+histPrices.getPk().getInstrId()+"; priceDate: "+histPrices.getPk().getPricedate()+"; closePr: "+histPrices.getClosepr()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
}
