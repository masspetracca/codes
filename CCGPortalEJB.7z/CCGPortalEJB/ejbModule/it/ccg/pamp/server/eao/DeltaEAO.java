package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class DeltaEAO
 */
@Stateless
public class DeltaEAO implements  DeltaEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	@SuppressWarnings("unchecked")
	public Integer[] fetch() {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllDelta");
    		List<Integer> deltaList = query.getResultList();
    		Integer[] arrDelta = new Integer[deltaList.size()];
    		return deltaList.toArray(arrDelta);
    	} catch (Exception e) {
    		return null;
    	}
	}
}
