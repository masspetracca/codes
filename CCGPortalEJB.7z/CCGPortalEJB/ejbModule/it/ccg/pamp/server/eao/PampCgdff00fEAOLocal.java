package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.PampCgdff00f;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;

import javax.ejb.Local;

@Local
public interface PampCgdff00fEAOLocal {
	
	public List<PampCgdff00f> fetch() throws DataNotValidException;

	public void removeAll() throws DataNotValidException;
	
	public String synchronizeTable() throws DataNotValidException;
	
	public LinkedHashMap<Integer,BigDecimal> getDfQuota(String divisCode) throws DataNotValidException;
}
