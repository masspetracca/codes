package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Group;
import it.ccg.pamp.server.entities.GroupParameter;
import it.ccg.pamp.server.entities.GroupParameterPK;
import it.ccg.pamp.server.entities.SetParameter;
import it.ccg.pamp.server.entities.SetParameterPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class GroupParameterEAO
 */
@Stateless
public class GroupParameterEAO implements  GroupParameterEAOLocal {

	@EJB private SetParameterEAOLocal setParEAO=null;
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	
	public GroupParameter[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllGrPar");
    		List<GroupParameter> groupParameter = query.getResultList();
    		GroupParameter[] arrGroupParameter = new GroupParameter[groupParameter.size()];
    		return groupParameter.toArray(arrGroupParameter);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Parameters - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupParameter findByPrimaryKey(int grId, int nDaysPer, int nv) throws DataNotValidException {
		try {
			GroupParameterPK pK = new GroupParameterPK();
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			pK.setGrId(grId);
			GroupParameter groupParameter = (GroupParameter) em.find(GroupParameter.class,pK);
    		return groupParameter;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Parameter - groupId: "+grId+"; nDaysPer:"+nDaysPer+"; holding period"+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupParameter[] findByGroupId(int grId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getGrParByGrId");
    		query.setParameter("grId", grId);
    		List<GroupParameter> groupParameter = query.getResultList();
    		GroupParameter[] arrGroupParameter = new GroupParameter[groupParameter.size()];
    		return groupParameter.toArray(arrGroupParameter);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Parameters by groupId - groupId: "+grId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public GroupParameter[] fetchWithGroup(int groupId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getGrParWithGroup");
    		query.setParameter("groupId", groupId);
    		List<GroupParameter> groupParameter = query.getResultList();
    		GroupParameter[] arrGroupParameter = new GroupParameter[groupParameter.size()];
    		return groupParameter.toArray(arrGroupParameter);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Group Parameters with Groups - groupId: "+groupId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActiveDelta(int grId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getActiveDeltaForGrPar");
    		query.setParameter("grId", grId);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active delta for Group Parameters - groupId: "+grId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getActivePeriods(int grId, int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getActivePeriodsForGrPar");
    		query.setParameter("grId", grId);
    		query.setParameter("delta", delta);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching active periods for Group Parameters - groupId: "+grId+"; delta: "+delta+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getEnabledPeriods(int grId, int delta) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledPeriodsForGrPar");
    		query.setParameter("grId", grId);
    		query.setParameter("delta", delta);
    		List<Integer> nvList = query.getResultList();
    		Integer[] arrIntegerObj = new Integer[nvList.size()];
    		nvList.toArray(arrIntegerObj);
    		return arrIntegerObj;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled periods for Group Parameters - groupId: "+grId+"; delta: "+delta+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int nDaysPer, int nv, int grId, String pStatus) throws DataNotValidException {
		try {
			GroupParameter groupParameter = new GroupParameter();
			GroupParameterPK pK = new GroupParameterPK();
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			pK.setGrId(grId);
			groupParameter.setPk(pK);
			groupParameter.setPStatus(pStatus);
			groupParameter.setUpdType("C");
			groupParameter.setUpdDate(GenericTools.systemDate());
			groupParameter.setUpdUsr(userString());
			em.persist(groupParameter);
			log.debug("Added new Group Parameter - groupId: "+grId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Group Parameter - groupId: "+grId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(GroupParameter groupParameter) throws DataNotValidException {
		try {
			groupParameter.setUpdType(updType);
			groupParameter.setUpdDate(GenericTools.systemDate());
			groupParameter.setUpdUsr(userString());
			em.persist(groupParameter);
			log.debug("Added new Group Parameter - groupId: "+groupParameter.getPk().getGrId()+"; nDaysPer: "+groupParameter.getPk().getNDaysPer()+"; holding period: "+groupParameter.getPk().getNv());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Group Parameter - groupId: "+groupParameter.getPk().getGrId()+"; nDaysPer: "+groupParameter.getPk().getNDaysPer()+"; holding period: "+groupParameter.getPk().getNv()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void storeParametersFromSet(int grId, int setId) throws DataNotValidException {
		try {
			SetParameter[] setPar = setParEAO.findBySetId(setId);
			for (int i=0;i<setPar.length;i++) {
				GroupParameter groupParameter = new GroupParameter();
				GroupParameterPK pK = new GroupParameterPK();
				pK.setNDaysPer(setPar[i].getPk().getNDaysPer());
				pK.setNv(setPar[i].getPk().getNv());
				pK.setGrId(grId);
				groupParameter.setPk(pK);
				groupParameter.setPStatus(setPar[i].getPStatus());
				groupParameter.setUpdType("C");
				groupParameter.setUpdDate(GenericTools.systemDate());
				groupParameter.setUpdUsr(userString());
				store(groupParameter);
			}
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Group Parameter from Sets - groupId: "+grId+"; setId: "+setId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int nDaysPer, int nv, int grId, String pStatus) throws DataNotValidException {
		try {
			GroupParameter groupParameter = findByPrimaryKey(grId, nDaysPer, nv);
			groupParameter.setPStatus(pStatus);
			groupParameter.setUpdType("U");
			groupParameter.setUpdDate(GenericTools.systemDate());
			groupParameter.setUpdUsr(userString());
			log.debug("Group Parameter updated - groupId: "+grId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Group Parameter - groupId: "+grId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(GroupParameter groupPar) throws DataNotValidException {
		try {
			GroupParameter groupParameter = findByPrimaryKey(groupPar.getPk().getGrId(),groupPar.getPk().getNDaysPer(), groupPar.getPk().getNv());
			groupParameter.setUpdType("U");
			groupParameter.setUpdDate(GenericTools.systemDate());
			groupParameter.setUpdUsr(userString());
			log.debug("Group Parameter updated - groupId: "+groupPar.getPk().getGrId()+"; nDaysPer: "+groupPar.getPk().getNDaysPer()+"; holding period: "+groupPar.getPk().getNv());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Group Parameter - groupId: "+groupPar.getPk().getGrId()+"; nDaysPer: "+groupPar.getPk().getNDaysPer()+"; holding period: "+groupPar.getPk().getNv()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void logUpdate(GroupParameter groupPar) throws DataNotValidException {
		try {
			log.debug("Group Parameter updated - groupId: "+groupPar.getPk().getGrId()+"; nDaysPer: "+groupPar.getPk().getNDaysPer()+"; holding period: "+groupPar.getPk().getNv());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Group Parameter - groupId: "+groupPar.getPk().getGrId()+"; nDaysPer: "+groupPar.getPk().getNDaysPer()+"; holding period: "+groupPar.getPk().getNv()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	
	public void remove(int grId, int nDaysPer, int nv) throws DataNotValidException {
		try {
			GroupParameter groupParameter = findByPrimaryKey(grId, nDaysPer, nv);
			em.remove(groupParameter);
			log.debug("Group Parameter removed - groupId: "+grId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Group Parameter - groupId: "+grId+"; nDaysPer: "+nDaysPer+"; holding period: "+nv);
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	public int removeByGrId(int grId) throws DataNotValidException {
		try {
			GroupParameter[] groupParameter = findByGroupId(grId);
			int i=0;
			for (i=0;i<groupParameter.length;i++) {
				remove(groupParameter[i].getPk().getGrId(),groupParameter[i].getPk().getNDaysPer(),groupParameter[i].getPk().getNv());
			}
			return i;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Group Parameter by groupId- groupId: "+grId);
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(GroupParameter groupParameter) throws DataNotValidException {
		remove(groupParameter.getPk().getGrId(),groupParameter.getPk().getNDaysPer(), groupParameter.getPk().getNv());
	}

}
