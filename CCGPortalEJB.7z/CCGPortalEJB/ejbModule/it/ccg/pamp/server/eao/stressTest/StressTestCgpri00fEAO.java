package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.stressTest.StressTestCgpri00f;
import it.ccg.pamp.server.entities.stressTest.StressTestCgpri00fPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StressTestCgpri00fEAO
 */
@Stateless
public class StressTestCgpri00fEAO implements  StressTestCgpri00fEAOLocal {

	@PersistenceContext(unitName="STDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<StressTestCgpri00f> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllSTCgpri00f");
    		List<StressTestCgpri00f> stressTestCgpri00fList = query.getResultList();
    		return stressTestCgpri00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from StressTestCgpri00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public StressTestCgpri00f findByPrimaryKey (Date prDate, String prIsin) throws DataNotValidException {
		Query query = null;
    	try {
    		StressTestCgpri00fPK pK = new StressTestCgpri00fPK();
    		
    		pK.setPrDate(prDate);
    		pK.setPrIsin(prIsin);
    		    		
    		StressTestCgpri00f stressTestCgpri00f = (StressTestCgpri00f) em.find(StressTestCgpri00f.class, pK);
    		
    		return stressTestCgpri00f;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from StressTestCgpri00f - date: "+prDate+"; isinCode: "+prIsin+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public void update(Date prDate, String prIsin, BigDecimal prPric) throws DataNotValidException {
		try {
			StressTestCgpri00f stressTestCgpri00f = this.findByPrimaryKey(prDate, prIsin);
			stressTestCgpri00f.setPrPric(prPric);
			log.debug("StressTestCgpri00f updated - prDate: "+prDate+"; prIsin: "+prIsin+"; new prPric: "+prPric);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating StressTestCgpri00f - prDate: "+prDate+"; prIsin: "+prIsin+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(StressTestCgpri00f stressTestCgpri00f) throws DataNotValidException {
		try {
			em.persist(stressTestCgpri00f);
			log.debug("Added new future stressed price - prDate: "+stressTestCgpri00f.getPk().getPrDate()+"; prIsin: "+stressTestCgpri00f.getPk().getPrIsin()+"; new prPric: "+stressTestCgpri00f.getPrPric());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new StressTestCgpri00f - prDate: "+stressTestCgpri00f.getPk().getPrDate()+"; prIsin: "+stressTestCgpri00f.getPk().getPrIsin()+"; - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public int removeAll() throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteAllSTCgpri00f");
			int result = query.executeUpdate();
			log.debug(result+" future stressed price on RE System removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing future stressed price on RE System - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
}
