package it.ccg.pamp.server.eao.backTest;

import it.ccg.pamp.server.entities.backTest.BackTestClass;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

/**
 * Session Bean implementation class BackTestClassEAO
 */
@Stateless
public class BackTestClassEAO implements BackTestClassEAOLocal {
	
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
	private EntityManager em;
	

    /**
     * Default constructor. 
     */
    public BackTestClassEAO() {
    	
    }
    
    
    
    public List<BackTestClass> fetchAll() throws DataNotValidException {
    	Query query = null;							
    	query = em.createNamedQuery("getAllBTC");
		List<BackTestClass> btcList =  query.getResultList();
    	
    	return btcList;
    }
    
    
    public List<BackTestClass> fetchByClassIdList(int[] classIdArray) throws DataNotValidException {
    	Query query = null;							
    	query = em.createNamedQuery("getBTCByClassId");
    	
    	List<BackTestClass> btcList = new ArrayList<BackTestClass>();
    	
    	BackTestClass btc = new BackTestClass();
    	for(int classId : classIdArray) {
    		query.setParameter("classId", classId);
    		
    		if(query.getResultList().size() > 0) {
    			btc = (BackTestClass)query.getResultList().get(0);
    			btcList.add(btc);
    		}
    	}
    	
    	return btcList;
    }

}
