package it.ccg.pamp.server.eao;
import java.sql.Time;
import java.sql.Timestamp;

import it.ccg.pamp.server.entities.Scheduler;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface SchedulerEAOLocal {
	
	public Scheduler[] fetch() throws DataNotValidException;
	
	public Scheduler[] getEnabledSchedulers() throws DataNotValidException;
	
	public Scheduler[] getDisabledSchedulers() throws DataNotValidException;
	
	public Scheduler findByPrcName(String prcName) throws DataNotValidException;
	
	public Scheduler findByPrimaryKey(int prcId) throws DataNotValidException;
	
	public void add(String prcName, String enabled, Timestamp fixedTime, Timestamp lastExec, String atMktDate, int batchId, String frequency) throws DataNotValidException;
	
	public void store(Scheduler scheduler) throws DataNotValidException;
	
	public void disableScheduler(int prcId) throws DataNotValidException;
	
	public void disableAll() throws DataNotValidException;
	
	public void enableScheduler(int prcId) throws DataNotValidException;
	
	public String getLastExecutor(int batchId) throws DataNotValidException;
	
	//public void updateSchedulerExecution(int prcId) throws DataNotValidException;
	
	
	public void updateSchedulerExecution(int batchId) throws DataNotValidException;
	
	public void enableAll() throws DataNotValidException;
	
	public void update(int prcId, String prcName, String enabled, Timestamp fixedTime, Timestamp lastExec, String atMktDate, int batchId, String frequency) throws DataNotValidException;
	
	public void update(int prcId) throws DataNotValidException;
	
	public void remove(Scheduler sched) throws DataNotValidException;

	public abstract void disableAllWithoutUPD() throws DataNotValidException;

	public abstract void enableSchedulerWithoutUPD(int prcId) throws DataNotValidException;

	public abstract void disableSchedulerWithoutUPD(int prcId) throws DataNotValidException;
	
}
