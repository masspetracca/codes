package it.ccg.pamp.server.eao.stressTestOeKB;
import it.ccg.pamp.server.entities.stressTestOeKB.OeKBReClass;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface OeKBReClassEAOLocal {
	
	public List<OeKBReClass> fetch() throws DataNotValidException;
	
	public List<OeKBReClass> getSTCgcls00fFutOpt(String cClass) throws DataNotValidException;
	
	public List<OeKBReClass> findByCClass(String cClass) throws DataNotValidException;
	
	public List<OeKBReClass> findByCofCod(String cofCod) throws DataNotValidException;
	
	public OeKBReClass findByPrimaryKey(String cClass, String cpType) throws DataNotValidException;
	
}	
