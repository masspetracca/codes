package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.OffsetParameter;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface OffsetParameterEAOLocal {
	public OffsetParameter[] fetch() throws DataNotValidException;
	public OffsetParameter findByPrimaryKey(int nDaysPer, int nv) throws DataNotValidException;
	public OffsetParameter[] findByStatus(String pStatus) throws DataNotValidException;
	public Integer[] getActiveDelta() throws DataNotValidException;
	public Integer[] getActivePeriods(int delta) throws DataNotValidException;
	public Integer[] getEnabledPeriods(int delta) throws DataNotValidException;
	
	public void add(int nDaysPer, int nv, String pStatus) throws DataNotValidException;
	public void store(OffsetParameter offsetParameter) throws DataNotValidException; 
	
	public void update(int nDaysPer, int nv, String pStatus) throws DataNotValidException;
	public void update(OffsetParameter classParam) throws DataNotValidException;
	
	public void remove(int nDaysPer, int nv) throws DataNotValidException; 
	public void remove(OffsetParameter classParam) throws DataNotValidException;
}
