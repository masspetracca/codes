package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.MarginCover;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;

import javax.ejb.Local;

@Local
public interface MarginCoverEAOLocal {
	public MarginCover[] fetch() throws DataNotValidException;
	public MarginCover[] findByInstrId(int instrId) throws DataNotValidException;
	public MarginCover findByPrimaryKey(int instrId, int nDaysPer, int nv) throws DataNotValidException;
	public void add(int instrId, int nDaysPer, int nv, BigDecimal propMarCov, BigDecimal propMarSd, BigDecimal matDMarSd, BigDecimal matDMarCov, BigDecimal mathMarCov, BigDecimal mathMarSd) throws DataNotValidException;
	public void store(MarginCover marginCover) throws DataNotValidException;
	public void update(int instrId, int nDaysPer, int nv, BigDecimal propMarCov, BigDecimal propMarSd, BigDecimal matDMarSd, BigDecimal matDMarCov, BigDecimal mathMarCov, BigDecimal mathMarSd) throws DataNotValidException; 
	public void update(MarginCover marCover) throws DataNotValidException;
	public void logUpdate(MarginCover marCover) throws DataNotValidException;
	public void remove(int instrId, int nDaysPer, int nv) throws DataNotValidException;
	public int removeByInstrId(int instrId) throws DataNotValidException;
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException;
	public void remove(MarginCover marCover) throws DataNotValidException;
}
