package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Cgcls00f;
import it.ccg.pamp.server.entities.IntracsLog;
import it.ccg.pamp.server.entities.PAMPCgcls00f;
import it.ccg.pamp.server.entities.PAMPCgcls00fPK;
import it.ccg.pamp.server.exceptions.DataNotAvailableException;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.ClassTableChecks;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class PAMPCgcls00fEAO
 */
@Stateless
public class PAMPCgcls00fEAO implements  PAMPCgcls00fEAOLocal {

	@EJB
	private Cgcls00fEAOLocal reCgcls00fEAO;
	
	@EJB
	private IntracsLogEAOLocal intracsLogEAO;
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	public List<PAMPCgcls00f> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllPampCgcls00f");
    		List<PAMPCgcls00f> pampCgcls00fList = query.getResultList();
    		return pampCgcls00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from PAMP Cgcls00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<PAMPCgcls00f> findByCClass(String cClass) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCgcls00fByCClass");
    		query.setParameter("cClass", cClass);
    		List<PAMPCgcls00f> pampCgcls00fList = query.getResultList();
    		return pampCgcls00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from PAMP Cgcls00f - cClass: "+cClass+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<PAMPCgcls00f> findByCofCod(List<String> cofCodList) throws DataNotValidException {
		Query query = null;
    	String cofCodStr = "";
    	for (String cofCod:cofCodList) {
    		cofCodStr += cofCod+", ";
    	}
    	
    	cofCodStr = cofCodStr.substring(0, cofCodStr.length()-1);
    	
		try {
    		query = em.createNamedQuery("getCgcls00fByCofCodList");
    		query.setParameter("cofCodList", cofCodList);
    		List<PAMPCgcls00f> pampCgcls00fList = query.getResultList();
    		return pampCgcls00fList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from PAMP Cgcls00f - cofCod: "+cofCodStr+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public PAMPCgcls00f findByPrimaryKey(String cClass, String cofCod) throws DataNotValidException {
		try {
			PAMPCgcls00fPK pK = new PAMPCgcls00fPK();
			pK.setCclass(cClass);			
			pK.setCofCod(cofCod);
			PAMPCgcls00f pampCgcls00f = (PAMPCgcls00f) em.find(PAMPCgcls00f.class,pK);
    		return pampCgcls00f;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from PAMP Cgcls00f - cClass: "+cClass+"; cofCode: "+cofCod+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public BigDecimal getMaxChangeDate() throws DataNotValidException {
		Query query = null;
		
		
		BigDecimal maxDate = new BigDecimal(19000101);
		
    	try {
			String sqlSelectString = "SELECT MAX(CCHGDT) FROM CGCLS00F";
			
			query =  em.createNativeQuery(sqlSelectString,BigDecimal.class);
			List<BigDecimal> lastChangeDate = query.getResultList();

			if (lastChangeDate.size()>0 && lastChangeDate.get(0)!=null) {
				maxDate = lastChangeDate.get(0);
			}
			
			return maxDate;
			
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching maximum last change date from PAMP Cgclss00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public BigDecimal getPriceSum() throws DataNotValidException {
		Query query = null;
		
		
		BigDecimal maxDate = new BigDecimal(0);
		
    	try {
			String sqlSelectString = "SELECT SUM(CUICLP) FROM CGCLS00F";
			
			query =  em.createNativeQuery(sqlSelectString,BigDecimal.class);
			List<BigDecimal> lastChangeDate = query.getResultList();

			if (lastChangeDate.size()>0 && lastChangeDate.get(0)!=null) {
				maxDate = lastChangeDate.get(0);
			}
			
			return maxDate;
			
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last price sum from PAMP Cgclss00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public ClassTableChecks getInfoToCheck() throws DataNotValidException {
		Query query = null;
		
		
		ClassTableChecks checkList = null;
		
    	try {
    		
    		String sqlSelectString = "SELECT MAX(CCHGDT) AS MAXCHGDATECHECK,";
    		sqlSelectString+="SUM(LENGTH(TRIM(CGROUP)) * ROW_NUMBER() OVER()) AS GROUPCHECK,";
    		sqlSelectString+="SUM((ROW_NUMBER() OVER()) * CUICLP) AS PRICECHECK,";
    		sqlSelectString+="SUM((ROW_NUMBER() OVER()) * CMRGNI) AS MARGINCHECK ";  
    		sqlSelectString+="FROM CGCLS00F";
    		
			query =  em.createNativeQuery(sqlSelectString,ClassTableChecks.class);
			List<ClassTableChecks> classTableChecks = query.getResultList();

			if (classTableChecks.size()>0 && classTableChecks.get(0)!=null) {
				checkList = classTableChecks.get(0);
			}
			
			return checkList;
			
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching consinstency checks from PAMP Cgclss00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public String synchronizeTable() throws DataNotValidException {
		Query query = null;
    	
		try {
    		
    		
    		String strSync = "";
    		
    		//TODO
    		/*ClassTableChecks pampClassTableChecks = this.getInfoToCheck();
    		
    		ClassTableChecks reClassTableChecks = reCgcls00fEAO.getInfoToCheck();
    		
    		BigDecimal pampMaxDate = pampClassTableChecks.getMaxChgDateCheck();
    		
    		BigDecimal reMaxDate = reClassTableChecks.getMaxChgDateCheck();
    		
    		BigDecimal pampGrCheck = pampClassTableChecks.getGroupCheck();
    		
    		BigDecimal reGrCheck = reClassTableChecks.getGroupCheck();
    		
    		BigDecimal pampPrCheck = pampClassTableChecks.getPriceCheck();
    		
    		BigDecimal rePrCheck = reClassTableChecks.getPriceCheck();
    		
    		BigDecimal pampMarCheck = pampClassTableChecks.getMarginCheck();
    		
    		BigDecimal reMarCheck = reClassTableChecks.getMarginCheck();   		
    		
    		*/
    		
    		//if (reClassTableChecks!=null && pampMaxDate.compareTo(reMaxDate)!=0 || pampGrCheck.compareTo(reGrCheck)!=0 || pampPrCheck.compareTo(rePrCheck)!=0 || pampMarCheck.compareTo(reMarCheck)!=0) {
    		
    		//TODO
    		//cercare su actlog x descrizione batch l'ultimo record
    		// ActionLog actLog = actLogEAO.findByActDesc("Risk Engine margin synchronization completed");
    		
    		//IntracsLog intracsLog = intracsLogEAO.findByLFile("CGCLS00F");
    		
    		//String lDate = intracsLog.getlDate().toString();
    		//String lTime = intracsLog.getlTime().toString();
    		
    		//long intracsTime = Integer.parseInt(lDate+lTime);
    		
    		//if (intracsLog==null || actLog.getActDate()>intracsTime) {
    		//
    		
    		
    			query = em.createNamedQuery("deleteAllPAMPCgclss00f");
	    		
    			int deleted = query.executeUpdate();
	    		log.debug(deleted+" records deleted");
	    		
	    		List<Cgcls00f> reClassList = reCgcls00fEAO.reCgcList();
	    		
	    		String columnList = "CCLASS, COFCOD, CEXCH1, CMKT1, CEXCH2, CMKT2, CEXCH3, CMKT3, CGROUP, CCORR, CUISYM, CUCUSP, CUICLP, CUIPCL, CPTYPE, CDESC, CMINRT, CVAT, CVINC, CLPRES, CNSV, COXPTM, CSPRES, CSERS, CNOSER, ";
	    		columnList+= "CASSI, CMRGNI, CCUR, CDELVR, CSETYP, CMULTF, CPMULT, CNSYM, CEFFDT, CPCB, CSTRKA, CPOSA, CSTRKC, CEXDT1, CDIV1, CEXDT2, CDIV2, CEXDT3, CDIV3, CEXDT4, CDIV4, COPTYP, COPSTY, CODAYS, COSEDT, COPEDT, ";
	    		columnList+= "CAEXC, CAEXF, CAEXMM, COPINT, CLIMIT, CEXLIM, CMINFL, CBEGTM, CENDTM, CENDLT, CTNDLY, CADDAT, CCHGDT, CPRCDT, CPYCOL, CINDAT, CPRTUC, CBLK12, CPLIMA, CELIM, CELIMA, CSCURR, CMITYP, CLEAP, CFVOLT, CEXTKEY";
	    		
	    		
	    		
	    		String sqlInsert = "";
	    		
	    		int stored = 0;
	    		
	    		for (Cgcls00f reClass:reClassList) {
	    			
	    			Query query2 = null;
	    			
	    			sqlInsert = "INSERT INTO CGCLS00F ("+columnList+") VALUES ";
	    			sqlInsert += "(";
		    		sqlInsert +="'"+reClass.getPk().getCclass()+"','"+reClass.getPk().getCofCod()+"',"+reClass.toString();
		    		sqlInsert += ")";
		    			
		    		query2 = em.createNativeQuery(sqlInsert);
	
		    		query2.executeUpdate();
	    			
		    		stored++;
		    	}
	    		
	    		log.debug(stored+" records stored");
	    		
	    		strSync = stored+" records synchronized";
    		/*} else {
    			strSync = "RE class margin table is synchronized to the last change ("+GenericTools.shortDateFormat(GenericTools.convertDateFromIntToTimestamp((int) (reMaxDate.longValue())))+")";
    			log.info(strSync);
    			
    		}*/
    		
    		return strSync;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error synchronizing records from PAMP Cgclss00f - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
}
