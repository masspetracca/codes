package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.DerivativesHistoricalPriceRett;
import it.ccg.pamp.server.entities.DerivativesHistoricalPriceRettPK;
import it.ccg.pamp.server.entities.HistoricalPricesRett;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.DerHistPricesRettDates;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.HistPricesRettDates;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class DerivativesHistoricalPriceRettEAO
 */
@Stateless
public class DerivativesHistoricalPriceRettEAO implements  DerivativesHistoricalPriceRettEAOLocal {

	@EJB private InstrumentEAOLocal instrEAO;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	@SuppressWarnings("unchecked")
	public DerivativesHistoricalPriceRett[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllHPR");
    		List<DerivativesHistoricalPriceRett> historicalPricesRett = query.getResultList();
    		DerivativesHistoricalPriceRett[] arrDerivativesHistoricalPriceRett = new DerivativesHistoricalPriceRett[historicalPricesRett.size()];
    		return historicalPricesRett.toArray(arrDerivativesHistoricalPriceRett);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPriceRett findByPrimaryKey(int instrId, Timestamp priceDate, int progExp) throws DataNotValidException {
		try {
			DerivativesHistoricalPriceRettPK pK = new DerivativesHistoricalPriceRettPK();
			pK.setInstrId(instrId);
			pK.setPriceDate(priceDate);
			pK.setPrgExp(progExp);
			
			DerivativesHistoricalPriceRett historicalPricesRett = (DerivativesHistoricalPriceRett) em.find(DerivativesHistoricalPriceRett.class,pK);
    		return historicalPricesRett;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices - instrId: "+instrId+"; priceDate: "+priceDate+"; progExp: "+progExp+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPriceRett[] findByInstrIdAndExp(int instrId,  int prgExp) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getDerHPRettByInstrIdAndExp");
    		query.setParameter("instrId", instrId);
    		query.setParameter("prgExp", prgExp);
    		List<DerivativesHistoricalPriceRett> derivativesHistoricalPriceRett = query.getResultList();
    		DerivativesHistoricalPriceRett[] arrDerivativesHistoricalPriceRett = new DerivativesHistoricalPriceRett[derivativesHistoricalPriceRett.size()];
    		return derivativesHistoricalPriceRett.toArray(arrDerivativesHistoricalPriceRett);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices - instrId: "+instrId+"; progExp: "+prgExp+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPriceRett[] findJustBeforeDate(int instrId, Timestamp nearDate) throws DataNotValidException {
		Query query = null;
		try {
			String date = nearDate.toString().substring(0, 10);
    		int year = Integer.parseInt(date.substring(0,4));
    		int month = Integer.parseInt(date.substring(5,7))-1;
    		int day = Integer.parseInt(date.substring(8))+1;
    		GregorianCalendar cal = new GregorianCalendar(year,month,day);
    		Timestamp beforeDate = new Timestamp(cal.getTimeInMillis());
			query = em.createNamedQuery("getDerivativesHPRetfindJustBeforeDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("nearDate", beforeDate);
    		query.setMaxResults(1);
    		List<DerivativesHistoricalPriceRett> historicalPricesRett = query.getResultList();
    		if (historicalPricesRett.size()>0) {
    			DerivativesHistoricalPriceRett[] arrDerivativesHistoricalPriceRett = new DerivativesHistoricalPriceRett[historicalPricesRett.size()];
    			return arrDerivativesHistoricalPriceRett;
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices before this date: "+nearDate+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<DerivativesHistoricalPriceRett> findBeforeLastDate(int instrId, Timestamp lastDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDerHPRetBeforeLastDate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("lastDate", lastDate);
    		List<DerivativesHistoricalPriceRett> derHistoricalPricesRettList = query.getResultList();
    		if (derHistoricalPricesRettList.size()>0) {
    			return derHistoricalPricesRettList;
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching rectified derivative historical price series before the last date - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPriceRett findLastDate() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDerivativesHPRLastDate");
    		query.setMaxResults(1);
    		List<DerivativesHistoricalPriceRett> historicalPricesRett = query.getResultList();
    		if (historicalPricesRett.size()>0) {
    			return historicalPricesRett.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices last date - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPriceRett findFirstDate() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDerivativesHPRFirstDate");
    		query.setMaxResults(1);
    		List<DerivativesHistoricalPriceRett> historicalPricesRett = query.getResultList();
    		if (historicalPricesRett.size()>0) {
    			return historicalPricesRett.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices first date - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerHistPricesRettDates findFirstAndLastDateByInstrId(Instrument instr) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDerivativesHPRFirstAndLastDateByInstrId");
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("defHistSer", instr.getDefHistSer());
    		query.setMaxResults(1);
    		List<DerHistPricesRettDates> histPricesRettDate = query.getResultList();
    		if (histPricesRettDate.size()>0) {
    			return histPricesRettDate.get(0);
    		} else {
    			 return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Historical Prices Rettified first and last date for instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPriceRett findLastDateByInstrument(Instrument instr) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDerivativesHPRLastDateByInstr");
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("defHistSer", instr.getDefHistSer());
    		query.setMaxResults(1);
    		List<DerivativesHistoricalPriceRett> historicalPricesRett = query.getResultList();
    		if (historicalPricesRett.size()>0) {
    			return historicalPricesRett.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices last date: instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPriceRett findFirstDateByInstrument(Instrument instr) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDerivativesHPRFirstDateByInstr");
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("defHistSer", instr.getDefHistSer());
    		query.setMaxResults(1);
    		List<DerivativesHistoricalPriceRett> historicalPricesRett = query.getResultList();
    		if (historicalPricesRett.size()>0) {
    			return historicalPricesRett.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices first date: instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer getExpiry(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMinExpFromDerHPRett");
    		query.setParameter("instrId", instrId);
    		List<Long> expiry = query.getResultList();
    		query.setMaxResults(1);
    		if (expiry.size()>0) {
    			return (Integer) expiry.get(0).intValue();
    		} else {
    			return 0;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices expiry - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer getMaxPrg(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMaxPrgExpByInstrIdForChart");
    		query.setParameter("instrId", instrId);
    		List<Integer> expiry = query.getResultList();
    		query.setMaxResults(1);
    		if (expiry.size()>0) {
    			return expiry.get(0);
    		} else {
    			return 0;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices expiry - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPriceRett[] findJustAfterDate(int instrId, Timestamp nearDate) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getHPRetfindJustAfterDate");
    		String date = nearDate.toString().substring(0, 10);
    		int year = Integer.parseInt(date.substring(0,4));
    		int month = Integer.parseInt(date.substring(5,7))-1;
    		int day = Integer.parseInt(date.substring(8))-1;
    		GregorianCalendar cal = new GregorianCalendar(year,month,day);
    		Timestamp afterDate = new Timestamp(cal.getTimeInMillis());
			query.setParameter("instrId", instrId);
    		query.setParameter("nearDate", afterDate);
    		query.setMaxResults(1);
    		List<DerivativesHistoricalPriceRett> historicalPricesRett = query.getResultList();
    		DerivativesHistoricalPriceRett[] arrDerivativesHistoricalPriceRett = new DerivativesHistoricalPriceRett[historicalPricesRett.size()];
    		return historicalPricesRett.toArray(arrDerivativesHistoricalPriceRett);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices after this date: "+nearDate+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}	
	
	public DerivativesHistoricalPriceRett[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDerivativesHPRetByInstrId");
    		query.setParameter("instrId", instrId);
    		List<DerivativesHistoricalPriceRett> historicalPricesRett = query.getResultList();
    		DerivativesHistoricalPriceRett[] arrDerivativesHistoricalPriceRett = new DerivativesHistoricalPriceRett[historicalPricesRett.size()];
    		return historicalPricesRett.toArray(arrDerivativesHistoricalPriceRett);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public DerivativesHistoricalPriceRett[] findByInstrIdForChart(int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDerivativesHPRetByInstrIdForChart");
    		query.setParameter("instrId", instrId);
    		List<DerivativesHistoricalPriceRett> historicalPricesRett = query.getResultList();
    		DerivativesHistoricalPriceRett[] arrDerivativesHistoricalPriceRett = new DerivativesHistoricalPriceRett[historicalPricesRett.size()];
    		return historicalPricesRett.toArray(arrDerivativesHistoricalPriceRett);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	//
	public DerivativesHistoricalPriceRett[] findByInstrIdAndDate(int instrId, Timestamp firstDate, Timestamp lastDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDerivativesHPRetByInstrIdAnddate");
    		query.setParameter("instrId", instrId);
    		query.setParameter("firstDate", firstDate);
    		query.setParameter("lastDate", lastDate);
    		List<DerivativesHistoricalPriceRett> historicalPricesRett = query.getResultList();
    		DerivativesHistoricalPriceRett[] arrDerivativesHistoricalPriceRett = new DerivativesHistoricalPriceRett[historicalPricesRett.size()];
    		return historicalPricesRett.toArray(arrDerivativesHistoricalPriceRett);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives rettified historical prices between dates: "+firstDate+" AND "+lastDate+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, Timestamp priceDate, int progExp, BigDecimal closePrRet, BigDecimal impVola, String status) throws DataNotValidException {
		try {
			DerivativesHistoricalPriceRett derivativesHistoricalPricesRett = new DerivativesHistoricalPriceRett();
			DerivativesHistoricalPriceRettPK pK = new DerivativesHistoricalPriceRettPK();
			pK.setInstrId(instrId);
			pK.setPriceDate(priceDate);
			pK.setPrgExp(progExp);
			derivativesHistoricalPricesRett.setPk(pK);
			derivativesHistoricalPricesRett.setClosePrRet(closePrRet);
			derivativesHistoricalPricesRett.setImpVola(impVola);
			derivativesHistoricalPricesRett.setStatus(status);
			derivativesHistoricalPricesRett.setUpdType("C");
			derivativesHistoricalPricesRett.setUpdDate(GenericTools.systemDate());
			derivativesHistoricalPricesRett.setUpdUsr(userString());
			em.persist(derivativesHistoricalPricesRett);
			log.debug("Added new Derivatives rettified historical prices - instrId: "+instrId+"; priceDate: "+priceDate+"; closePrRett: "+closePrRet);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Derivatives rettified historical prices - instrId: "+instrId+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(DerivativesHistoricalPriceRett derivativesHistoricalPricesRett) throws DataNotValidException {
		try {
			derivativesHistoricalPricesRett.setUpdType("C");
			derivativesHistoricalPricesRett.setUpdDate(GenericTools.systemDate());
			derivativesHistoricalPricesRett.setUpdUsr(userString());
			em.persist(derivativesHistoricalPricesRett);
			log.debug("Added new Derivatives rettified historical prices - instrId: "+derivativesHistoricalPricesRett.getPk().getInstrId()+"; priceDate: "+derivativesHistoricalPricesRett.getPk().getPriceDate()+"; closePrRett: "+derivativesHistoricalPricesRett.getClosePrRet());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Derivatives rettified historical prices - instrId: "+derivativesHistoricalPricesRett.getPk().getInstrId()+"; priceDate: "+derivativesHistoricalPricesRett.getPk().getPriceDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, Timestamp priceDate, int progExp, BigDecimal closePrRet, BigDecimal impVola, String status) throws DataNotValidException {
		try {
			DerivativesHistoricalPriceRett derivativesHistoricalPricesRett = findByPrimaryKey(instrId,priceDate,progExp);
			derivativesHistoricalPricesRett.setClosePrRet(closePrRet);
			derivativesHistoricalPricesRett.setImpVola(impVola);
			derivativesHistoricalPricesRett.setStatus(status);
			derivativesHistoricalPricesRett.setUpdType("U");
			derivativesHistoricalPricesRett.setUpdDate(GenericTools.systemDate());
			derivativesHistoricalPricesRett.setUpdUsr(userString());
			log.debug("Derivatives rettified historical prices updated - instrId: "+instrId+"; priceDate: "+priceDate+"; closePrRett: "+closePrRet);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Derivatives rettified historical prices - instrId: "+instrId+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	} 
	}
	
	public void update(DerivativesHistoricalPriceRett derivativesHPR) throws DataNotValidException {
		try {
			DerivativesHistoricalPriceRett derivativesHistoricalPricesRett = findByPrimaryKey(derivativesHPR.getPk().getInstrId(),derivativesHPR.getPk().getPriceDate(),derivativesHPR.getPk().getPrgExp());
			derivativesHistoricalPricesRett.setUpdType("U");
			derivativesHistoricalPricesRett.setUpdDate(GenericTools.systemDate());
			derivativesHistoricalPricesRett.setUpdUsr(userString());
			log.debug("Derivatives rettified historical prices updated - instrId: "+derivativesHPR.getPk().getInstrId()+"; priceDate: "+derivativesHPR.getPk().getPriceDate()+"; closePrRett: "+derivativesHPR.getClosePrRet());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Derivatives rettified historical prices - instrId: "+derivativesHPR.getPk().getInstrId()+"; priceDate: "+derivativesHPR.getPk().getPriceDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, Timestamp priceDate, int progExp) throws DataNotValidException {
		try {
			DerivativesHistoricalPriceRett derivativesHistoricalPricesRett = findByPrimaryKey(instrId,priceDate,progExp);
			em.remove(derivativesHistoricalPricesRett);
			log.debug("Derivatives rettified historical prices removed - instrId: "+instrId+"; priceDate: "+priceDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Derivatives rettified historical prices - instrId: "+instrId+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	} 
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteDerivativesHPrettByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug("InstrId: "+instrId+" - "+result+" Derivatives rettified historical prices removed");
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Derivatives rettified historical prices - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	} 
	}
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteDerivativesHPrettByEnabledInstrId");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" Derivatives rettified historical prices related to disabled instruments removed - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing derivatives rettified historical prices related to disabled instruments removed - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void remove(DerivativesHistoricalPriceRett derivativesHPR) throws DataNotValidException {
		remove(derivativesHPR.getPk().getInstrId(),derivativesHPR.getPk().getPriceDate(),derivativesHPR.getPk().getPrgExp());
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void flush() {
		em.flush();
	}

}
