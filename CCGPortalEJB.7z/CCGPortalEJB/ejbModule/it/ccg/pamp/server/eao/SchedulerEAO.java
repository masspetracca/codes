package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Scheduler;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;


import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class SchedulerEAO
 */
@Stateless
public class SchedulerEAO implements  SchedulerEAOLocal {
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}

	public String userString = "System";
	public String updType = "C";
	
	
	@SuppressWarnings("unchecked")
	public Scheduler[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllScheduler");
    		List<Scheduler> scheduler = query.getResultList();
    		Scheduler[] arrScheduler = new Scheduler[scheduler.size()];
    		return scheduler.toArray(arrScheduler);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Schedulers - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Scheduler[] getEnabledSchedulers() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledSchedulers");
    		List<Scheduler> scheduler = query.getResultList();
    		Scheduler[] arrScheduler = new Scheduler[scheduler.size()];
    		scheduler.toArray(arrScheduler);
    		return arrScheduler;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled Schedulers - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Scheduler[] getDisabledSchedulers() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDisabledSchedulers");
    		List<Scheduler> scheduler = query.getResultList();
    		Scheduler[] arrScheduler = new Scheduler[scheduler.size()];
    		scheduler.toArray(arrScheduler);
    		return arrScheduler;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching disabled Schedulers - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Scheduler findByPrcName(String prcName) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSchedByPrcName");
    		query.setParameter("prcName",prcName);
    		List<Scheduler> schedulerList = query.getResultList();
    		if (schedulerList.size()>0) {
    			return schedulerList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Scheduler - prcName: "+prcName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Scheduler findByPrimaryKey(int prcId) throws DataNotValidException {
		try {
			Scheduler scheduler = (Scheduler) em.find(Scheduler.class,prcId);
    		return scheduler;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Scheduler - prcId: "+prcId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Scheduler> findByBatchId(int batchId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getSchedByBatchId");
    		query.setParameter("batchId",batchId);
    		
    		List<Scheduler> schedulerList = query.getResultList();
    		return schedulerList;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Scheduler - batchId: "+batchId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public String getLastExecutor(int batchId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getLastExecutor");
    		query.setParameter("batchId",batchId);
    		
    		List<Scheduler> schedulerList = query.getResultList();
    		if (schedulerList.size()>0) {
    			return schedulerList.get(0).getUpdUsr();
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Scheduler - batchId: "+batchId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(String prcName, String enabled, Timestamp fixedTime, Timestamp lastExec, String atMktDate, int batchId, String frequency) throws DataNotValidException {
		try {
			Scheduler scheduler = new Scheduler();
			scheduler.setPrcName(prcName);
			scheduler.setEnabled(enabled);
			scheduler.setFixedTime(fixedTime);
			scheduler.setLastExec(lastExec);
			scheduler.setAtMktDate(atMktDate);
			scheduler.setBatchId(batchId);
			scheduler.setFrequency(frequency);
			scheduler.setUpdDate(GenericTools.systemDate());
			scheduler.setUpdType(updType);
			scheduler.setUpdUsr(userString());
			em.persist(scheduler);
			log.debug("Added new Scheduler - prcName: "+prcName);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Scheduler - prcName: "+prcName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void store(Scheduler scheduler) throws DataNotValidException {
		try {
			scheduler.setUpdDate(GenericTools.systemDate());
			scheduler.setUpdType(updType);
			scheduler.setUpdUsr(userString());
			em.persist(scheduler);
			log.debug("Added new Scheduler - prcId: "+scheduler.getPrcName());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Scheduler - prcName: "+scheduler.getPrcName()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int prcId, String prcName, String enabled, Timestamp fixedTime, Timestamp lastExec, String atMktDate, int batchId, String frequency) throws DataNotValidException {
		try {
			Scheduler scheduler = findByPrimaryKey(prcId);
			scheduler.setPrcName(prcName);
			scheduler.setEnabled(enabled);
			scheduler.setFixedTime(fixedTime);
			scheduler.setLastExec(lastExec);
			scheduler.setAtMktDate(atMktDate);
			scheduler.setBatchId(batchId);
			scheduler.setFrequency(frequency);
			scheduler.setUpdDate(GenericTools.systemDate());
			scheduler.setUpdType("U");
			scheduler.setUpdUsr(userString());
			log.debug("Scheduler updated - prcId: "+prcId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Scheduler - prcId: "+prcId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int prcId) throws DataNotValidException {
		try {
			Scheduler sched = findByPrimaryKey(prcId);
			sched.setUpdDate(GenericTools.systemDate());
			sched.setUpdType("U");
			sched.setUpdUsr(userString());
			log.debug("Scheduler updated - prcId: "+sched.getPrcId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Scheduler - prcId: "+prcId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public void updateSchedulerExecution(int prcId) throws DataNotValidException {
		try {
			Scheduler sched = findByPrimaryKey(prcId);
			sched.setLastExec(GenericTools.systemDate());
			sched.setUpdDate(GenericTools.systemDate());
			sched.setUpdType("U");
			sched.setUpdUsr(userString());
			log.debug("Updated last scheduler execution - prcId: "+prcId + "; last execution: "+GenericTools.systemDate().toString().substring(0,10));
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error upating last scheduler execution - prcId: "+prcId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
	
	public void updateSchedulerExecution(int batchId) throws DataNotValidException {
		
		List<Scheduler> schedulerList = this.findByBatchId(batchId);
		
		if (schedulerList.size()==0) {
			return;
		} 
		
		try {
			
			for (Scheduler sched:schedulerList) {
				sched.setLastExec(GenericTools.systemDate());
				sched.setUpdDate(GenericTools.systemDate());
				sched.setUpdType("U");
				sched.setUpdUsr(userString());
			}
			log.debug("Updated last scheduler execution - batchId: "+batchId + "; last execution: "+GenericTools.systemDate().toString().substring(0,10));
			
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error upating last scheduler execution - batchId: "+batchId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void disableScheduler(int prcId) throws DataNotValidException {
		try {
			Scheduler sched = findByPrimaryKey(prcId);
			sched.setEnabled("F");
			sched.setUpdDate(GenericTools.systemDate());
			sched.setUpdType("U");
			sched.setUpdUsr(userString());
			log.debug("Scheduler disabled - prcId: "+sched.getPrcId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error disabling Scheduler - prcId: "+prcId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@Override
	public void disableSchedulerWithoutUPD(int prcId) throws DataNotValidException {
		try {
			Scheduler sched = findByPrimaryKey(prcId);
			sched.setEnabled("F");
			/*sched.setUpdDate(GenericTools.systemDate());
			sched.setUpdType("D");
			sched.setUpdUsr(userString());*/
			log.debug("Scheduler disabled - prcId: "+sched.getPrcId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error disabling Scheduler - prcId: "+prcId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	public void disableAll() throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNativeQuery("UPDATE PMPTSCHED SET ENABLED = 'F', UPDDATE = '"+GenericTools.systemDate()+"',UPDTYPE = 'C', UPDUSR = '"+userString()+"'");
		    int result = query.executeUpdate();
			log.debug(result+" schedulers disabled");
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error disabling all schedulers - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@Override
	public void disableAllWithoutUPD() throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNativeQuery("UPDATE PMPTSCHED SET ENABLED = 'F'");
		    int result = query.executeUpdate();
			log.debug(result+" schedulers disabled");
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error disabling all schedulers - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void enableScheduler(int prcId) throws DataNotValidException {
		try {
			Scheduler sched = findByPrimaryKey(prcId);
			sched.setEnabled("T");
			sched.setUpdDate(GenericTools.systemDate());
			sched.setUpdType("E");
			sched.setUpdUsr(userString());
			log.debug("Scheduler enabled - prcId: "+prcId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error disabling Scheduler - prcId: "+prcId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@Override
	public void enableSchedulerWithoutUPD(int prcId) throws DataNotValidException {
		try {
			Scheduler sched = findByPrimaryKey(prcId);
			sched.setEnabled("T");
			/*sched.setUpdDate(GenericTools.systemDate());
			sched.setUpdType("E");
			sched.setUpdUsr(userString());*/
			log.debug("Scheduler enabled - prcId: "+prcId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error disabling Scheduler - prcId: "+prcId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void enableAll() throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNativeQuery("UPDATE PMPTSCHED SET ENABLED = 'T', UPDDATE = '"+GenericTools.systemDate()+"',UPDTYPE = 'C', UPDUSR = '"+userString()+"'");
		    int result = query.executeUpdate();
			log.debug(result+" schedulers enabled");
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error enabling all schedulers - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(Scheduler sched) throws DataNotValidException {
		try {
			Scheduler scheduler = findByPrimaryKey(sched.getPrcId());
			em.remove(scheduler);
			log.debug("Scheduler removed - prcId: "+sched.getPrcId());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing Scheduler - prcId: "+sched.getPrcId()+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}
	
	
}
