package it.ccg.pamp.server.eao;


import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.BondClassMarginsAndMaxDurations;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;



/**
 * Session Bean implementation class InstrumentEAO
 */
@Stateless
@SuppressWarnings("unchecked")
public class InstrumentEAO implements  InstrumentEAOLocal {
	
	@EJB private BondClassEAOLocal bondClassEAO;
	
	@PersistenceContext(unitName="PAMPUSE")
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public String userString = "System";
	public String updType = "C";
	
	public Instrument[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllInst");
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	public List<String> findMarketCodeList(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("findMarketCodeList");
    		query.setParameter("divisCode", divisCode);
    		List<String> marketCodeList = query.getResultList();
    		return marketCodeList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching market list for divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getByMultipleDivisCode(String[] multipleDivisCode) throws DataNotValidException {
		Query query = null;
		
		List<String> diviscodeList = new ArrayList<String>();

		for (String diviscode:multipleDivisCode) {
			diviscodeList.add(diviscode);
		}


		try {
    		query = em.createNamedQuery("getByMultDivisCode");
    		query.setParameter("divisCode", diviscodeList);
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments by multiple divisCode: "+multipleDivisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Instrument> getAllByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
		
		try {
    		if (divisCode.equalsIgnoreCase("O")) {
    			query = em.createNamedQuery("getBondAndInflation");
    		} else {
    			query = em.createNamedQuery("getAllByDivisCode");
    			query.setParameter("divisCode", divisCode);
    		}
    		
    		List<Instrument> instrumentList = query.getResultList();
    		return instrumentList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Instrument[] getEnabledEqDerNotHavingUndIndex() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledEqDerNotHavingUndIndex");
    		List<Instrument> instrumentList = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrumentList.size()];
    		return instrumentList.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching equity derivatives instruments not having index as underlying - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<Instrument> getEnabledNodesOfEnabledClassAndCurveByDiviscode(String divisCode) throws DataNotValidException {
		Query query = null;
		
		String strQuery = 	"getEnabledNodesOfEnabledClassAndCurveForBonds";
		
		if (divisCode.equalsIgnoreCase("H")) {
			strQuery = 	"getEnabledNodesOfEnabledClassAndCurveForHaircut";
		}
		
		try {
    		query = em.createNamedQuery(strQuery);
    		query.setParameter("divisCode", divisCode);
    		List<Instrument> instrumentList = query.getResultList();
    		return instrumentList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled nodes for division "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Instrument> getEnabledInstrumentOfEnabledClassByDiviscode(String divisCode) throws DataNotValidException {
		Query query = null;
		
		String strQuery = 	"getEnabledInstrumentOfEnabledClassByDiviscode";
		
		try {
    		query = em.createNamedQuery(strQuery);
    		query.setParameter("divisCode", divisCode);
    		List<Instrument> instrumentList = query.getResultList();
    		return instrumentList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled instruments for division "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument getByClassCodeAndDivisCode(String classCode, String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrumentByClassCodeAndDivisCode");
    		query.setParameter("divisCode", divisCode);
    		query.setParameter("classCode", classCode);
    		List<Instrument> instrumentList = query.getResultList();
    		if (instrumentList.size()>0) {
    			return instrumentList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - classCode: "+classCode+"; divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Instrument> getAllInstrumentsHavingUndInstr() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllInstrumentsHavingUndInstr");
    		List<Instrument> instrumentList = query.getResultList();
    		return instrumentList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments having underlying - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getEnabledAndUnderlayingInstrumentsByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledAndUnderlayingInstrumentsByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getInstrumentArrayForBondStressTest() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrumentArrayForBondStressTest");
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond instruments - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Instrument> getEnabledUnderlyingOrDelistedAfterStressTestDateInstrumentsByDivisCode(String divisCode, Timestamp stressTestDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledUnderlyingOrDelistedAfterStressTestDateInstrumentsByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		query.setParameter("stressTestDate", stressTestDate);
    		List<Instrument> instrumentList = query.getResultList();
    		if (instrumentList.size()>0) {
    			return instrumentList;
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled or underlying instruments or delisted after the date choosen to execute the stress test - divisCode: "+divisCode+"; date: "+stressTestDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Instrument[] getInstrumentByDivisCodeAndUndInstrId(String divisCode, int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrumentByDivisCodeAndUndInstrId");
    		query.setParameter("divisCode", divisCode);
    		query.setParameter("instrId", instrId);
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - divisCode: "+divisCode+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Instrument[] getInstrumentByDivisCodeAndUndInstrIdAndFalseDerHist(String divisCode, int instrId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrumentByDivisCodeAndUndInstrIdAndFalseDerHist");
    		query.setParameter("divisCode", divisCode);
    		query.setParameter("instrId", instrId);
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - divisCode: "+divisCode+"; instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Instrument> getInstrumentInMarHis() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrumentInMarHis");
    		List<Instrument> instrumentList = query.getResultList();
    		return instrumentList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments being in margin history  - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Instrument> getBondsByIrCurveList(String[] arrIrCurve) throws DataNotValidException {
		Query query = null;
    	List<String> irCurveList = new ArrayList<String>();
    	
    	for (String irCurve:arrIrCurve) {
    		irCurveList.add(irCurve);
    	}
    	
		try {
    		query = em.createNamedQuery("getBondsByIrCurveList");
    		query.setParameter("arrIrCurve", irCurveList);
    		
    		List<Instrument> instrumentList = query.getResultList();
    		return instrumentList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bonds  - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<Instrument> getNotInterpNodesByIrCurveName(String irCurve) throws DataNotValidException {
		Query query = null;
    	
    	try {
    		query = em.createNamedQuery("getNotInterpNodesByIrCurveName");
    		query.setParameter("irCurve", irCurve);
    		
    		List<Instrument> instrumentList = query.getResultList();
    		return instrumentList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching nodes - curve name: "+irCurve+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Instrument> getExpirationInstrument() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getExpirationInstrument");
    		List<Instrument> instrumentList = query.getResultList();
    		return instrumentList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching expiration instruments  - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Instrument[] getEnabledInstrAndMarginsByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledInstrAndMarginsByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		String extDivisCode = GenericTools.getWholeDivisCode(divisCode);
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled "+extDivisCode+" instruments - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getOnlyNotEnabledMarginInstrByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getOnlyNotEnabledMarginInstrByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getEnabledInstrNotInMarginByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledInstrNotInMarginByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getEnabledInstrNotInMinimumMarginByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledInstrumentsNotInMinMarginByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getEnabledInstrNotInStraddleByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledInstrumentsNotInStraddleByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getEnabledBondClassComponents() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledBondClassComponents");
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled bond class components - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getEnabledInflationBondClassComponents() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledInflationBondClassComponents");
    		List<Instrument> instrument = query.getResultList();
    		Instrument[] arrInstruments = new Instrument[instrument.size()];
    		return instrument.toArray(arrInstruments);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching enabled inflation bond class components - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getInstrIdByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrIdByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<Integer> instrId = query.getResultList();
    		Integer[] arrInstrId = new Integer[instrId.size()];
    		return instrId.toArray(arrInstrId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getCash() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCash");
    		List<Instrument> instr = query.getResultList();
    		Instrument[] arrInstrument = new Instrument[instr.size()];
    		return instr.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching cash (financial instruments with instType: 'ETF' or 'C') - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getCurrencies() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCurrencies");
    		List<Instrument> instr = query.getResultList();
    		Instrument[] arrInstrument = new Instrument[instr.size()];
    		return instr.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching currencies - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getInterestRates() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInterestRates");
    		List<Instrument> instr = query.getResultList();
    		Instrument[] arrInstrument = new Instrument[instr.size()];
    		return instr.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching interest rates - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getComparables() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getComparables");
    		List<Instrument> instr = query.getResultList();
    		Instrument[] arrInstrument = new Instrument[instr.size()];
    		return instr.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching comparables - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getCashAndIndex() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCashAndIndex");
    		List<Instrument> instr = query.getResultList();
    		Instrument[] arrInstrument = new Instrument[instr.size()];
    		return instr.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching cashes and indexes (financial instruments with instType: 'ETF' or 'C' or 'I') - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getFutures() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getFutures");
    		List<Instrument> instr = query.getResultList();
    		Instrument[] arrInstrument = new Instrument[instr.size()];
    		return instr.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching futures (financial instruments with instType: 'F' or 'FO') - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getOptions() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getOptions");
    		List<Instrument> instr = query.getResultList();
    		Instrument[] arrInstrument = new Instrument[instr.size()];
    		return instr.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching options (financial instruments with instType: 'O' or 'FO') - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getIndex() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getIndex");
    		List<Instrument> instr = query.getResultList();
    		Instrument[] arrInstrument = new Instrument[instr.size()];
    		return instr.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching index (instruments with instType: 'INDEX') - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getIndexToSync() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getIndexToSync");
    		List<Instrument> instr = query.getResultList();
    		Instrument[] arrInstrument = new Instrument[instr.size()];
    		return instr.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching index - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<Instrument> getInflationBonds() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInflationBonds");
    		List<Instrument> inflationBondsList = query.getResultList();
    		return inflationBondsList;
    		//Instrument[] arrInstrument = new Instrument[instr.size()];
    		//return instr.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bonds - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument[] getSicInstrType() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSicInstrType");
    		List<Instrument> instrList = query.getResultList();
    		Instrument[] arrInstr = new Instrument[instrList.size()];
    		return instrList.toArray(arrInstr);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getInstrIdByDivisCodeAndInstrType(String divisCode, String instrType) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrIdByDivisCodeAndInstrType");
    		query.setParameter("divisCode", divisCode);
    		query.setParameter("instrType", instrType);
    		List<Integer> instrId = query.getResultList();
    		Integer[] arrInstrId = new Integer[instrId.size()];
    		return instrId.toArray(arrInstrId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instruments - divisCode: "+divisCode+"; instrType: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public String[] getInstrTypeByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrTypeByDivisCode");
    		query.setParameter("divisCode", divisCode);
    		List<String> instrTypes = query.getResultList();
    		String[] arrInstrTypes = new String[instrTypes.size()];
    		return instrTypes.toArray(arrInstrTypes );
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument types - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument getUnderlying(Instrument instr) throws DataNotValidException {
		
		//int underlayerId=findByPrimaryKey(instrId).getUndInstrId();
		
		if (instr.getUndInstrId()==null  || (instr.getUndInstrId()==0) ) {
			DataNotValidException exc = new DataNotValidException("No underlayer instruments for Instrument ID "+instr.getInstrId());
    		throw exc;
		} else {
			return findByPrimaryKey(instr.getUndInstrId());
		} 
	}
	
	public Instrument findByPrimaryKey(int instrId) throws DataNotValidException {
		try {
			Instrument instrument = (Instrument) em.find(Instrument.class,instrId);
			return instrument;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument findByClassCode(String classCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrumentByClassCode");
    		query.setParameter("classCode", classCode);
    		List<Instrument> instrument = query.getResultList();
    		if (instrument.size()>0) {
    			return instrument.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument - classCode: "+classCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument getInstrumentIdByInstrIdAndClassId(int instrId, int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrumentIdByInstrIdAndClassId");
    		query.setParameter("instrId", instrId);
    		query.setParameter("classId", classId);
			Instrument instrument = (Instrument) query.getSingleResult();
    		return instrument;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument by instrId and classId - instrId: "+instrId+"; classId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument findByIrNode(int irNode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrIdByIrNode");
    		query.setParameter("irNode", irNode);
			Instrument instrument = (Instrument) query.getSingleResult();
    		return instrument;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument by irNode - irNode: "+irNode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Instrument findByIrNodeAndCurve(int irNode, String listName) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrumentByIrNodeAndCurve");
    		query.setParameter("irNode", irNode);
    		query.setParameter("listName", listName);
			List<Instrument> instrumentList = query.getResultList();
			if (instrumentList.size()>0) {
				return instrumentList.get(0);
			} else {
				return null;
			}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Instrument by irNode - irNode: "+irNode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Instrument> findByInstrType(String instrType) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrumentByInstrType");
    		query.setParameter("instrType", instrType);
			List<Instrument> instrumentList = query.getResultList();
			
			return instrumentList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching instrument by type - instrType: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, String instrName, String listName, String classCode, String ricCode, String isinCode, String bloombCode, 
			String divisCode, String marketCode, String sgmCode, String instrType, String instrStype, String currency, String disabReas,
			String addrStreet, String addrCity, String addrDist, String addrPc, String addrState, String addrCount, int histPrId, int histVolaId,
			String delistReas, Timestamp delistDate, String industry, String compos, String issuer, String divType, String addrWeb, String bmkName,
			String bmkRic, String bmkReturn, String bmkStyle, String bmkArea, String bmkDescr, String bmkComp, String bmkSpec, String bmkCurr, 
			int bmknInstr, String status, String format, String shortTFut, String longTOpt, int futExpNumb, BigDecimal mult, BigDecimal shortOpAdj,
			String delDays, int irNode, String irNodeDesc, String reporting, String note, String updType, Timestamp updDate, String userString,
			Timestamp mktLstDate, Timestamp ccpLstDate, String superSect, int optExpNumb, String straType, int undInstrId, int defHistSer, BigDecimal marginTh,
			String derHist, String minMarType, String comparable,int rcCode, int classId, int settleType, BigDecimal duration, String mmTable,
			BigDecimal defMarg, int evtStorMv, String derPer, int derFrstMnt, BigDecimal defMinMar, BigDecimal defStradd, int derPrgMnt, String interp,
			BigDecimal yield, Timestamp expiry, Timestamp coupNextDt, BigDecimal coupFreq, BigDecimal coupVal, String process, String coupType) throws Exception {
		
		
		
		try {
			Instrument instrument = new Instrument();
			instrument.setInstrName(instrName);
			instrument.setListName(listName);
			instrument.setClassCode(classCode);
			instrument.setRicCode(ricCode);
			instrument.setIsinCode(isinCode);
			instrument.setBloombCode(bloombCode);
			instrument.setDivisCode(divisCode);
			instrument.setMarketCode(marketCode);
			instrument.setSgmCode(sgmCode);
			instrument.setInstrType(instrType);
			instrument.setInstrStype(instrStype);
			instrument.setCurrency(currency);
			instrument.setDisabReas(disabReas);
			instrument.setAddrStreet(addrStreet);
			instrument.setAddrCity(addrCity);
			instrument.setAddrDist(addrDist);
			instrument.setAddrPc(addrPc);
			instrument.setAddrState(addrState);
			instrument.setAddrCount(addrCount);
			instrument.setHistPrId(histPrId);
			instrument.setHistVolaId(histVolaId);
			instrument.setDelistReas(delistReas);
			instrument.setDelistDate(delistDate);
			instrument.setIndustry(industry);
			instrument.setCompos(compos);
			instrument.setIssuer(issuer);
			instrument.setDivType(divType);
			instrument.setAddrWeb(addrWeb);
			instrument.setBmkName(bmkName);
			instrument.setBmkRic(bmkRic);
			instrument.setBmkReturn(bmkReturn);
			instrument.setBmkStyle(bmkStyle);
			instrument.setBmkArea(bmkArea);
			instrument.setBmkDescr(bmkDescr);
			instrument.setBmkComp(bmkComp);
			instrument.setBmkSpec(bmkSpec);
			instrument.setBmkCurr(bmkCurr);
			instrument.setBmknInstr(bmknInstr);
			instrument.setStatus(status);
			instrument.setFormat(format);
			instrument.setShortTFut(shortTFut);
			instrument.setLongTOpt(longTOpt);
			instrument.setFutExpNumb(futExpNumb);
			instrument.setMult(mult);
			instrument.setShortOpAdj(shortOpAdj);
			instrument.setDelDays(delDays);
			instrument.setIrNode(irNode);
			instrument.setIrNodeDesc(irNodeDesc);
			instrument.setReporting(reporting);
			instrument.setNote(note);
			instrument.setUpdType(updType);
			instrument.setUpdDate(GenericTools.systemDate());
			instrument.setUpdUsr(userString());
			instrument.setMktLstDate(mktLstDate);
			instrument.setCcpLstDate(ccpLstDate);
			instrument.setSuperSect(superSect);
			instrument.setOptExpNumb(optExpNumb);
			instrument.setStraType(straType);
			instrument.setUndInstrId(undInstrId);
			instrument.setDefHistSer(defHistSer);
			instrument.setMarginTh(marginTh);
			instrument.setDerHist(derHist);
			instrument.setMinMarType(minMarType);
			instrument.setComparable(comparable);
			instrument.setRcCode(rcCode);
			instrument.setBndClassId(classId);
			instrument.setSettleType(settleType);
			instrument.setDuration(duration);
			instrument.setMmTable(mmTable);
			instrument.setDefMarg(defMarg);
			instrument.setEvtStorMv(evtStorMv);
			instrument.setDerPer(derPer);
			instrument.setDerFrstMnt(derFrstMnt);
			instrument.setDefMinMar(defMinMar);
			instrument.setDefStradd(defStradd);
			instrument.setDerPrgMnt(derPrgMnt);
			instrument.setInterp(interp);
			instrument.setYield(yield);
			instrument.setExpiry(expiry);
			instrument.setCoupNextDt(coupNextDt);
			instrument.setCoupFreq(coupFreq);
			instrument.setCoupVal(coupVal);
			instrument.setProcess(process);
			instrument.setCoupType(coupType);
			
			em.persist(instrument);
			log.debug("Added new Instrument - instrId: "+instrument.getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Instrument - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	public void store(Instrument instrument) throws DataNotValidException {
		try {
			instrument.setUpdType("C");
			instrument.setUpdDate(GenericTools.systemDate());
			instrument.setUpdUsr(userString());
			em.persist(instrument);
			log.info("Added new Instrument - code: "+instrument.getClassCode());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Instrument - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(String instrName, String classCode, String isinCode, String divisCode, String instrType, String instrStype, String currency, String status) throws DataNotValidException {
		Query query = null;
		try {
			String sqlString = "INSERT INTO PMPTINSTR (INSTRNAME, CLASSCODE, ISINCODE, DIVISCODE, INSTRTYPE, INSTRSTYPE, CURRENCY, STATUS, UPDDATE, UPDTYPE, UPDUSR) VALUES (";
    		sqlString += "'"+instrName+"',";
    		sqlString += "'"+classCode+"',";
    		sqlString += "'"+isinCode+"',";
    		sqlString += "'"+divisCode+"',";
    		sqlString += "'"+instrType+"',";
    		sqlString += "'"+instrStype+"',";
    		sqlString += "'"+currency+"',";
    		sqlString += "'"+status+"',";
    		sqlString += "'"+GenericTools.systemDate()+"',";
    		sqlString += "'"+updType+"',";
    		sqlString += "'"+userString()+"')";
    		
    		query =  em.createNativeQuery(sqlString);
    		query.executeUpdate();
			
			log.info("Added new Instrument - instrId: "+classCode);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Instrument - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public void restore(int updId) throws DataNotValidException, RecordNotRestorableException {
		Query query = null;	
		try {
			query = em.createNamedQuery("getInstrArchByUpdId");
    		query.setParameter("updId", updId);
    		InstrumentArchive instrArchive = (InstrumentArchive) query.getSingleResult();
    		Instrument instr = findByPrimaryKey(instrArchive.getInstrId());
    		if (instr==null) {
    			//instr = new Instrument();
    			throw new Exception("0");
    			//notExists = true;
    		}
    		//if (instrArchive.getUpdType().equalsIgnoreCase("D")) {
    		else {
	    		instr.setInstrName(instrArchive.getInstrName());
				instr.setListName(instrArchive.getListName());
				instr.setClassCode(instrArchive.getClassCode());
				instr.setRicCode(instrArchive.getRicCode());
				instr.setIsinCode(instrArchive.getIsinCode());
				instr.setBloombCode(instrArchive.getBloombCode());
				instr.setDivisCode(instrArchive.getDivisCode());
				instr.setMarketCode(instrArchive.getMarketCode());
				instr.setSgmCode(instrArchive.getSgmCode());
				instr.setInstrType(instrArchive.getInstrType());
				instr.setInstrStype(instrArchive.getInstrStype());
				instr.setCurrency(instrArchive.getCurrency());
				instr.setDisabReas(instrArchive.getDisabReas());
				instr.setAddrStreet(instrArchive.getAddrStreet());
				instr.setAddrCity(instrArchive.getAddrCity());
				instr.setAddrDist(instrArchive.getAddrDist());
				instr.setAddrPc(instrArchive.getAddrPc());
				instr.setAddrState(instrArchive.getAddrState());
				instr.setAddrCount(instrArchive.getAddrCount());
				instr.setHistPrId(instrArchive.getHistPrId());
				instr.setHistVolaId(instrArchive.getHistVolaId());
				instr.setDelistReas(instrArchive.getDelistReas());
				instr.setDelistDate(instrArchive.getDelistDate());
				instr.setSuperSect(instrArchive.getSuperSect());
				instr.setIndustry(instrArchive.getIndustry());
				instr.setCompos(instrArchive.getCompos());
				instr.setIssuer(instrArchive.getIssuer());
				instr.setDivType(instrArchive.getDivType());
				instr.setAddrWeb(instrArchive.getAddrWeb());
				instr.setBmkName(instrArchive.getBmkName());
				instr.setBmkRic(instrArchive.getBmkRic());
				instr.setBmkReturn(instrArchive.getBmkReturn());
				instr.setBmkStyle(instrArchive.getBmkStyle());
				instr.setBmkArea(instrArchive.getBmkArea());
				instr.setBmkDescr(instrArchive.getBmkDescr());
				instr.setBmkComp(instrArchive.getBmkComp());
				instr.setBmkSpec(instrArchive.getBmkSpec());
				instr.setBmkCurr(instrArchive.getBmkCurr());
				instr.setBmknInstr(instrArchive.getBmknInstr());
				instr.setMktLstDate(instrArchive.getMktLstDate());
				instr.setCcpLstDate(instrArchive.getCcpLstDate());
				instr.setStatus(instrArchive.getStatus());
				instr.setFormat(instrArchive.getFormat());
				instr.setShortTFut(instrArchive.getShortTFut());
				instr.setLongTOpt(instrArchive.getLongTOpt());
				instr.setOptExpNumb(instrArchive.getOptExpNumb());
				instr.setFutExpNumb(instrArchive.getFutExpNumb());
				instr.setMult(instrArchive.getMult());
				instr.setShortOpAdj(instrArchive.getShortOpAdj());
				instr.setDelDays(instrArchive.getDelDays());
				instr.setIrNode(instrArchive.getIrNode());
				instr.setIrNodeDesc(instrArchive.getIrNodeDesc());
				instr.setReporting(instrArchive.getReporting());
				instr.setNote(instrArchive.getNote());
				instr.setUpdType("U");
				instr.setUpdDate(GenericTools.systemDate());
				instr.setUpdUsr(instrArchive.getUpdUsr());
				instr.setStraType(instrArchive.getStraType());
				instr.setUndInstrId(instrArchive.getUndInstrId());
				instr.setDefHistSer(instrArchive.getDefHistSer());
				instr.setMarginTh(instrArchive.getMarginTh());
				instr.setDerHist(instrArchive.getDerHist());
				instr.setMinMarType(instrArchive.getMinMarType());
				log.debug("Instrument restored - instrId: "+instrArchive.getInstrId());
    		}
			//if (notExists) {
    		//	store(instr);
    		//}
		}  
		catch (Exception e) {
			if (e.getMessage().equalsIgnoreCase("0")) {
				RecordNotRestorableException exc = new RecordNotRestorableException("Deleted instruments cannot be restored");
				exc.setStackTrace(e.getStackTrace());
	    		throw exc;
			} else {
				DataNotValidException exc = new DataNotValidException("Error restoring Instrument from archive - updId: "+updId+" "+e.getMessage());
				exc.setStackTrace(e.getStackTrace());
	    		throw exc;
			}
		}
	}*/
	
	public void update(int instrId, String instrName, String listName, String classCode, String ricCode, String isinCode, String bloombCode, 
		String divisCode, String marketCode, String sgmCode, String instrType, String instrStype, String currency, String disabReas,
		String addrStreet, String addrCity, String addrDist, String addrPc, String addrState, String addrCount, int histPrId, int histVolaId,
		String delistReas, Timestamp delistDate, String industry, String compos, String issuer, String divType, String addrWeb, String bmkName,
		String bmkRic, String bmkReturn, String bmkStyle, String bmkArea, String bmkDescr, String bmkComp, String bmkSpec, String bmkCurr, 
		int bmknInstr, String status, String format, String shortTFut, String longTOpt, int futExpNumb, BigDecimal mult, BigDecimal shortOpAdj,
		String delDays, int irNode, String irNodeDesc, String reporting, String note, String updType, Timestamp updDate, String userString,
		Timestamp mktLstDate, Timestamp ccpLstDate, String superSect, int optExpNumb, String straType, int undInstrId, int defHistSer, BigDecimal marginTh,
		String derHist, String minMarType, String comparable,int rcCode, int classId, int settleType, BigDecimal duration, String mmTable,
		BigDecimal defMarg, int evtStorMv, String derPer, int derFrstMnt, BigDecimal defMinMar, BigDecimal defStradd, int derPrgMnt, String interp,
		BigDecimal yield, Timestamp expiry, Timestamp coupNextDt, BigDecimal coupFreq, BigDecimal coupVal, String process, String coupType) throws DataNotValidException {
		
		try {
			Instrument instrument = findByPrimaryKey(instrId);
			instrument.setInstrName(instrName);
			instrument.setListName(listName);
			instrument.setClassCode(classCode);
			instrument.setRicCode(ricCode);
			instrument.setIsinCode(isinCode);
			instrument.setBloombCode(bloombCode);
			instrument.setDivisCode(divisCode);
			instrument.setMarketCode(marketCode);
			instrument.setSgmCode(sgmCode);
			instrument.setInstrType(instrType);
			instrument.setInstrStype(instrStype);
			instrument.setCurrency(currency);
			instrument.setDisabReas(disabReas);
			instrument.setAddrStreet(addrStreet);
			instrument.setAddrCity(addrCity);
			instrument.setAddrDist(addrDist);
			instrument.setAddrPc(addrPc);
			instrument.setAddrState(addrState);
			instrument.setAddrCount(addrCount);
			instrument.setHistPrId(histPrId);
			instrument.setHistVolaId(histVolaId);
			instrument.setDelistReas(delistReas);
			instrument.setDelistDate(delistDate);
			instrument.setIndustry(industry);
			instrument.setCompos(compos);
			instrument.setIssuer(issuer);
			instrument.setDivType(divType);
			instrument.setAddrWeb(addrWeb);
			instrument.setBmkName(bmkName);
			instrument.setBmkRic(bmkRic);
			instrument.setBmkReturn(bmkReturn);
			instrument.setBmkStyle(bmkStyle);
			instrument.setBmkArea(bmkArea);
			instrument.setBmkDescr(bmkDescr);
			instrument.setBmkComp(bmkComp);
			instrument.setBmkSpec(bmkSpec);
			instrument.setBmkCurr(bmkCurr);
			instrument.setBmknInstr(bmknInstr);
			instrument.setStatus(status);
			instrument.setFormat(format);
			instrument.setShortTFut(shortTFut);
			instrument.setLongTOpt(longTOpt);
			instrument.setFutExpNumb(futExpNumb);
			instrument.setMult(mult);
			instrument.setShortOpAdj(shortOpAdj);
			instrument.setDelDays(delDays);
			instrument.setIrNode(irNode);
			instrument.setIrNodeDesc(irNodeDesc);
			instrument.setReporting(reporting);
			instrument.setNote(note);
			instrument.setUpdType("U");
			instrument.setUpdDate(GenericTools.systemDate());
			instrument.setUpdUsr(userString);
			instrument.setMktLstDate(mktLstDate);
			instrument.setCcpLstDate(ccpLstDate);
			instrument.setSuperSect(superSect);
			instrument.setOptExpNumb(optExpNumb);
			instrument.setStraType(straType);
			instrument.setUndInstrId(undInstrId);
			instrument.setDefHistSer(defHistSer);
			instrument.setMarginTh(marginTh);
			instrument.setDerHist(derHist);
			instrument.setMinMarType(minMarType);
			instrument.setComparable(comparable);
			instrument.setRcCode(rcCode);
			instrument.setBndClassId(classId);
			instrument.setSettleType(settleType);
			instrument.setDuration(duration);
			instrument.setMmTable(mmTable);
			instrument.setDefMarg(defMarg);
			instrument.setEvtStorMv(evtStorMv);
			instrument.setDerPer(derPer);
			instrument.setDerFrstMnt(derFrstMnt);
			instrument.setDefMinMar(defMinMar);
			instrument.setDefStradd(defStradd);
			instrument.setDerPrgMnt(derPrgMnt);
			instrument.setInterp(interp);
			instrument.setYield(yield);
			instrument.setExpiry(expiry);
			instrument.setCoupNextDt(coupNextDt);
			instrument.setCoupFreq(coupFreq);
			instrument.setCoupVal(coupVal);
			instrument.setProcess(process);
			instrument.setCoupType(coupType);
			
			
			log.debug("Instrument updated - instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Instrument - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(Instrument instr) throws DataNotValidException {
		try {
			/*Instrument instrument = findByPrimaryKey(instr.getInstrId());
			instrument.setUpdType("U");
			instrument.setUpdDate(GenericTools.systemDate());
			instrument.setUpdUsr(userString());*/
			log.debug("Instrument updated - instrId: "+instr.getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Instrument - instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId) throws DataNotValidException {
		try {
			Instrument instrument = findByPrimaryKey(instrId);
			em.remove(instrument);
			log.debug("Instrument removed - instrId: "+instrId);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Instrument - instrId: "+instrId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	public void remove(Instrument instr) throws DataNotValidException {
		remove(instr.getInstrId());
	}
	
	public int removeByDivisCode(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteInstrumentByDivisCode");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" Instruments removed - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Instrument - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
		
	}
	
	public List<BondClassMarginsAndMaxDurations> getClassMarginsList() throws DataNotValidException {
		  
		Query query = null;
    	try {
    		String sqlString = "SELECT I.BNDCLASSID AS CLASSID, I.DURATION AS MAXMODDUR, M.USERMARGIN, M.WORKMAR AS WORKINGMARGIN "+
    						   "FROM PMPTINSTR I "+
    						   "INNER JOIN PMPVCLMAR M ON M.CLASSID = I.BNDCLASSID "+
    						   "WHERE NOT EXISTS "+
    						   "(SELECT * FROM PMPTINSTR I2 WHERE I2.INSTRID > I.INSTRID AND I2.BNDCLASSID = I.BNDCLASSID) "+
    						   "ORDER BY MAXMODDUR DESC ";
    		
    		query =  em.createNativeQuery(sqlString,BondClassMarginsAndMaxDurations.class);
    		List<BondClassMarginsAndMaxDurations> classMarginsAndMaxDurationsList = query.getResultList();
    		
    		return classMarginsAndMaxDurationsList;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond class margins - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public String getClassComponentString() throws DataNotValidException {
		try {
			
			String classComponentString = "";
			
			//prendo tutte le classi con i loro strumenti
			Integer[] arrClassId = getAllInstrumentClasses();
			if (arrClassId.length>0) {
				for (Integer classId:arrClassId) {
					classComponentString+="Class Id: "+classId+"; Description: "+bondClassEAO.findByPrimaryKey(classId).getClassDesc()+"; ";
					Integer[] arrInstrId = this.getInstrumentIdByClassId(classId);
					classComponentString+= "Nodes: {";
					for (Integer instrId:arrInstrId) {
						classComponentString+= instrId+" ("+this.findByPrimaryKey(instrId).getIrNodeDesc()+"); ";
					}
					classComponentString = classComponentString.substring(0,classComponentString.length()-2);
					classComponentString+="}; ";
				}
				classComponentString = classComponentString.substring(0,classComponentString.length()-2);
			} else {
				classComponentString = "No bond class found";
			}
			
			if (classComponentString.length()>1000) {
				classComponentString = classComponentString.substring(0,995);
			}
			
    		return classComponentString;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond class components - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public Integer[] getAllInstrumentClasses() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllInstrumentClasses");
    		List<Integer> classIdList = query.getResultList();
    		Integer[] arrClassId = new Integer[classIdList.size()];
    		return classIdList.toArray(arrClassId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching classId list in bond class component - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc; 
     	}
	}
	
	public Integer[] getInstrumentIdByClassId(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getInstrumentIdByClassId");
    		query.setParameter("classId", classId);
    		List<Integer> instrIdList = query.getResultList();
    		Integer[] arrInstrId = new Integer[instrIdList.size()];
    		return instrIdList.toArray(arrInstrId);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching instrId list in bond class component for classId "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public Instrument[] getBondClassComponentsByClassId1And2(int classId1, int classId2, String interp) throws DataNotValidException {
		Query query = null;
    	
		String interpolated = "";
		
		if (interp.equalsIgnoreCase("F")) {
			interpolated = "not "; 
		}
		
		interpolated += "interpolated";
		
		try {
    		query = em.createNamedQuery("getBondClassComponentsByClassId1And2");
    		query.setParameter("classId1", classId1);
    		query.setParameter("classId2", classId2);
    		query.setParameter("interp", interp);
    		List<Instrument> instrumentList = query.getResultList();
    		Instrument[] arrInstrument = new Instrument[instrumentList.size()];
    		return instrumentList.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+interpolated+" instruments - classId1: "+classId1+"; classId2: "+classId2+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public Instrument[] findByClassId(int classId, String interp,String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBondClassComponentsByClassIdAndInterp");
    		query.setParameter("classId", classId);
    		query.setParameter("interp", interp);
    		query.setParameter("divisCode", divisCode);
    		List<Instrument> instrumentList = query.getResultList();
    		Instrument[] arrInstrument = new Instrument[instrumentList.size()];
    		return instrumentList.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching instrument - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public Instrument[] findByClassIdAndDivisCode(int classId,String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getBondClassComponentsByClassIdAndDivisCode");
    		query.setParameter("classId", classId);
    		query.setParameter("divisCode", divisCode);
    		List<Instrument> instrumentList = query.getResultList();
    		Instrument[] arrInstrument = new Instrument[instrumentList.size()];
    		return instrumentList.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching instrument - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	
	public Instrument[] findEnabledDisabledInstrByClassIdAndDivisCode(int classId,String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getEnabledDisabledBondClassComponentsByClassIdAndDivisCode");
    		query.setParameter("classId", classId);
    		query.setParameter("divisCode", divisCode);
    		List<Instrument> instrumentList = query.getResultList();
    		Instrument[] arrInstrument = new Instrument[instrumentList.size()];
    		return instrumentList.toArray(arrInstrument);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching instrument - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	
	
	public List<Instrument> findIrNodeByInterp(String interp) throws DataNotValidException {
		Query query = null;
		String irNodes = "irNodes";
		if (interp.equalsIgnoreCase("T")) {
			irNodes = "interpolated irNodes";
		}
    	try {
    		query = em.createNamedQuery("getAllIrNode");
    		query.setParameter("interp", interp);
    		List<Instrument> instrumentList = query.getResultList();
    		return instrumentList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+irNodes+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public List<Instrument> findHairCutNode() throws DataNotValidException {
		Query query = null;
		
	
    	try {
    		query = em.createNamedQuery("getAllHairCutNode");
    		
    		List<Instrument> instrumentList = query.getResultList();
    		return instrumentList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Hair Cut nodes "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	
	public int removeByClassId(int classId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteInstrumentByClassId");
			query.setParameter("classId", classId);
			int result = query.executeUpdate();
			log.debug(result+" bond class component removed- classId:"+classId);
			return result;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing bond class component - classId:"+classId+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
    		throw exc; 
     	}
	}
	
	public int updateStatusToDisable(String divisCode) throws DataNotValidException {
		Query query = null;
		
		String wholeDivisCode = GenericTools.getWholeDivisCode(divisCode);
		
		try {
			query = em.createNamedQuery("updateInstrStatusToDisable");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" "+wholeDivisCode+" disabled");
			return result;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error disabling "+wholeDivisCode+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
    		throw exc; 
     	}
	}
	
	public void updateUnderlayingInstrId(int instrId,int undInstrId) throws DataNotValidException {
		Instrument instr = findByPrimaryKey(instrId);
		try {
			instr.setUndInstrId(undInstrId);
			log.debug("Updated underlaying field forInstrument - instrId: "+instr.getInstrId());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating underlaying field forInstrument - instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
