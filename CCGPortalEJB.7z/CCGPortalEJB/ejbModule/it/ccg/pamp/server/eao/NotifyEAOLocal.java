package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.Notify;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface NotifyEAOLocal {
	
	public Notify[] fetch() throws DataNotValidException;
	
	public Notify findByPrimaryKey(int notifyId) throws DataNotValidException;
	
	public void add(int notifyId, String text, int value, String enable, String link) throws DataNotValidException;
	
	public void store(Notify notify) throws DataNotValidException;
	
	public void update(int notifyId, String text, int value, String enable, String link) throws DataNotValidException;
	
	public void enable(int notifyId);
	
	public void disable(int notifyId);
	
	public void update(Notify notify) throws DataNotValidException;
	
	public void remove(int notifyId) throws DataNotValidException;
	
	public void remove(Notify notify) throws DataNotValidException;
	
}
