package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.ClassMargin;
import it.ccg.pamp.server.entities.ClassMarginHistory;
import it.ccg.pamp.server.entities.ClassMarginHistoryPK;
import it.ccg.pamp.server.entities.MarginHistory;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ClassMarginHistoryEAO
 */
@Stateless
public class ClassMarginHistoryEAO implements  ClassMarginHistoryEAOLocal {

	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger logging = Logger.getLogger("it.ccg.pamp.server.log.UserLog");

	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public ClassMarginHistory[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllClassMarHis");
    		List<ClassMarginHistory> classMarHis = query.getResultList();
    		ClassMarginHistory[] arrClassMarginHistory = new ClassMarginHistory[classMarHis.size()];
    		return classMarHis.toArray(arrClassMarginHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond class Margin History - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public ClassMarginHistory getLastSentClassMargin(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getLastSentClassMargin");
    		query.setParameter("classId", classId);
    		query.setMaxResults(1);
    		List<ClassMarginHistory> classMarginHistoryList = query.getResultList();
    		if (classMarginHistoryList.size()>0) {
    			return classMarginHistoryList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last class margin history - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ClassMarginHistory findByPrimaryKey(int classId, Timestamp iniVDate) throws DataNotValidException {
		try {
			ClassMarginHistoryPK pK = new ClassMarginHistoryPK();
			pK.setClassId(classId);
			pK.setIniVDate(iniVDate);
			ClassMarginHistory classMarginHistory = (ClassMarginHistory) em.find(ClassMarginHistory.class,pK);
    		return classMarginHistory;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond class Margin History - classId: "+classId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public ClassMarginHistory[] findByClassId(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getClassMarHisByClassId");
    		query.setParameter("classId", classId);
    		List<ClassMarginHistory> classMarHis = query.getResultList();
    		ClassMarginHistory[] arrClassMarginHistory = new ClassMarginHistory[classMarHis.size()];
    		return classMarHis.toArray(arrClassMarginHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond class Margin History - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public ClassMarginHistory getLastMargin(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getLastClassMargin");
    		query.setParameter("classId", classId);
    		query.setMaxResults(1);
    		List<ClassMarginHistory> marginHistory = query.getResultList();
    		if (marginHistory.size()>0) {
    			return marginHistory.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching last Margin History - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<ClassMarginHistory> getCurrentClassMarginList(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCurrentClassMargin");
    		query.setParameter("classId", classId);
    		query.setParameter("systemDate", GenericTools.systemDate());
    		List<ClassMarginHistory> classMarginHistoryList = query.getResultList();
    		
    		return classMarginHistoryList;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching current Margin History - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public ClassMarginHistory getCurrentMargin(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCurrentClassMargin");
    		query.setParameter("classId", classId);
    		query.setParameter("systemDate", GenericTools.systemDate());
    		query.setMaxResults(1);
    		List<ClassMarginHistory> marginHistory = query.getResultList();
    		if (marginHistory.size()>0) {
    			return marginHistory.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching current Margin History - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public ClassMarginHistory[] getMarginByDateAsc(int classId) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getClassMarHisByClassIdAsc");
    		query.setParameter("classId", classId);
    		List<ClassMarginHistory> classMarHis = query.getResultList();
    		ClassMarginHistory[] arrClassMarginHistory = new ClassMarginHistory[classMarHis.size()];
    		return classMarHis.toArray(arrClassMarginHistory);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond class Margin History by date - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public List<ClassMarginHistory> getClassMarHisToExport() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getClassMarHisToExport");
    		query.setParameter("systemDate", GenericTools.systemDate());
    		List<ClassMarginHistory> classMarginHistoryList = query.getResultList();
    		return classMarginHistoryList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching bond class margin history to export - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int classId, Timestamp iniVDate, Timestamp endvDate, BigDecimal margin, String sent, 
		Timestamp sendDate, String approvedBy, Timestamp apprDate, BigDecimal anMargin, Timestamp anDate, int rcCode,String log) throws DataNotValidException {
		try {
			ClassMarginHistory classMarginHistory = new ClassMarginHistory();
			ClassMarginHistoryPK pK = new ClassMarginHistoryPK();
			pK.setClassId(classId);
			pK.setIniVDate(iniVDate);
			classMarginHistory.setPk(pK);
			classMarginHistory.setEndVDate(endvDate);
			classMarginHistory.setMargin(margin);
			classMarginHistory.setSent(sent);
			classMarginHistory.setSendDate(sendDate);
			classMarginHistory.setApprovedBy(approvedBy);
			classMarginHistory.setApprDate(apprDate);
			classMarginHistory.setAnMargin(anMargin);
			classMarginHistory.setAnDate(anDate);
			classMarginHistory.setRcCode(rcCode);
			classMarginHistory.setLog(log);
			classMarginHistory.setUpdDate(GenericTools.systemDate());
			classMarginHistory.setUpdType(updType);
			classMarginHistory.setUpdUsr(userString());
			em.persist(classMarginHistory);
			logging.debug("Added new Bond Class Margin History - classId: "+classId+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Bond Class Margin History - classId: "+classId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public void store(ClassMarginHistory classMarginHistory) throws DataNotValidException {
		try {
			classMarginHistory.setUpdDate(GenericTools.systemDate());
			classMarginHistory.setUpdType(updType);
			classMarginHistory.setUpdUsr(userString());
			em.persist(classMarginHistory);
			logging.debug("Added new Bond Class Margin History - classId: "+classMarginHistory.getPk().getClassId()+"; iniVDate: "+classMarginHistory.getPk().getIniVDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new Bond Class Margin History - classId: "+classMarginHistory.getPk().getClassId()+"; iniVDate: "+classMarginHistory.getPk().getIniVDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public void store(ClassMargin classMargin) throws DataNotValidException {
		ClassMarginHistory classMarHis = new ClassMarginHistory();
		ClassMarginHistoryPK classMarHisPK = new ClassMarginHistoryPK();
		classMarHisPK.setIniVDate(classMargin.getIniVDate());
		classMarHisPK.setClassId(classMargin.getClassId());
		classMarHis.setPk(classMarHisPK);
		classMarHis.setEndVDate(classMargin.getEndVDate());
		classMarHis.setMargin(classMargin.getPropMargin());
		classMarHis.setSent("F");
		classMarHis.setSendDate(classMargin.getSendDate());
		
		classMarHis.setApprovedBy(classMargin.getApproval());
		classMarHis.setApprDate(GenericTools.systemDate());
		classMarHis.setAnMargin(classMargin.getAnMargin());
		classMarHis.setAnCover(classMargin.getAnCover());
		classMarHis.setAnDate(classMargin.getAnDate());
		
		classMarHis.setRcCode(classMargin.getRcCode());
		
		
		classMarHis.setLog(classMargin.getPropLog());
		classMarHis.setUpdDate(GenericTools.systemDate());
		classMarHis.setUpdType(updType);
		classMarHis.setUpdUsr(userString());
		store(classMarHis);
	}
	
	public void update(int classId, Timestamp iniVDate, Timestamp endvDate, BigDecimal margin,String sent, 
		Timestamp sendDate, String approvedBy, Timestamp apprDate, BigDecimal anMargin, Timestamp anDate, int rcCode, String log) throws DataNotValidException {
		
		try {
			ClassMarginHistory classMarginHistory = findByPrimaryKey(classId, iniVDate);
			classMarginHistory.setEndVDate(endvDate);
			classMarginHistory.setMargin(margin);
			classMarginHistory.setSent(sent);
			classMarginHistory.setSendDate(sendDate);
			classMarginHistory.setApprovedBy(approvedBy);
			classMarginHistory.setApprDate(apprDate);
			classMarginHistory.setAnMargin(anMargin);
			classMarginHistory.setAnDate(anDate);
			classMarginHistory.setRcCode(rcCode);
			classMarginHistory.setLog(log);
			classMarginHistory.setUpdDate(GenericTools.systemDate());
			classMarginHistory.setUpdType("U");
			classMarginHistory.setUpdUsr(userString());
			logging.debug("Updated Bond Class Margin History - classId: "+classId+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Bond Class Margin History - classId: "+classId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}	
	
	public void update(ClassMarginHistory classMarHistory) throws DataNotValidException {
		try {
			ClassMarginHistory clMarHistory = findByPrimaryKey(classMarHistory.getPk().getClassId(), classMarHistory.getPk().getIniVDate());
			clMarHistory.setUpdDate(GenericTools.systemDate());
			clMarHistory.setUpdType("U");
			clMarHistory.setUpdUsr(userString());
			//logging.debug("Updated Bond Class Margin History - classId: "+clMarHistory.getPk().getClassId()+"; iniVDate: "+clMarHistory.getPk().getIniVDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Bond Class Margin History - classId: "+classMarHistory.getPk().getClassId()+"; iniVDate: "+classMarHistory.getPk().getIniVDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public void logUpdate(ClassMarginHistory clMarHistory) throws DataNotValidException {
		try {
			//update(marHistory);
			logging.debug("Margin History updated - instrId: "+clMarHistory.getPk().getClassId()+"; iniVDate: "+clMarHistory.getPk().getIniVDate());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Margin History - instrId: "+clMarHistory.getPk().getClassId()+"; iniVDate: "+clMarHistory.getPk().getIniVDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int classId, Timestamp iniVDate) throws DataNotValidException {
		try {
			ClassMarginHistory classMarginHistory = findByPrimaryKey(classId, iniVDate);
			em.remove(classMarginHistory);
			logging.debug("Bond Class Margin History removed - classId: "+classId+"; iniVDate: "+iniVDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Bond Class Margin History - classId: "+classId+"; iniVDate: "+iniVDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public int removeByClassId(int classId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("deleteClassMarHisByClassId");
			query.setParameter("classId", classId);
			int result = query.executeUpdate();
			logging.debug(result+" Bond Class Margin History removed - classId: "+classId);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing Bond Class Margin History - classId: "+classId+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
     	}
	}
	
	public void remove(ClassMarginHistory classMarHistory) throws DataNotValidException {
		remove(classMarHistory.getPk().getClassId(), classMarHistory.getPk().getIniVDate());
	}	

}
