package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Cpsrss1;
import it.ccg.pamp.server.entities.Cpsrss1PK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class Cpsrss1EAO
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class Cpsrss1EAO implements  Cpsrss1EAOLocal {

	@PersistenceContext(unitName="DWHDS", type=PersistenceContextType.TRANSACTION)
	
	private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	public Timestamp updDate = systemDate();
	public String updType = "C";
	
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	public Cpsrss1[] fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllCPSRSS1");
    		List<Cpsrss1> cpsrss1 = query.getResultList();
    		Cpsrss1[] arrCpsrss1 = new Cpsrss1[cpsrss1.size()];
    		return cpsrss1.toArray(arrCpsrss1);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from CPSRSS1 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Cpsrss1> findByDateAndSicType(Timestamp priceDate, String hofCod) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCPSRSS1ByDateAndSicType");
    		query.setParameter("hofCod", hofCod);
    		query.setParameter("hDate", GenericTools.shortDateFormatAsLong(priceDate));
    		List<Cpsrss1> cpsrss1List = query.getResultList();
    		return cpsrss1List;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from CPSRSS1 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Cpsrss1> findByDateSymblAndCode(Timestamp priceDate,String hSymbl, String hofCod) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCPSRSS1ByDateAndSymblAndCode");
    		query.setParameter("hDate", GenericTools.shortDateFormatAsLong(priceDate));
    		query.setParameter("hSymbl", hSymbl);
    		query.setParameter("hofCod", hofCod);
    		
    		List<Cpsrss1> cpsrss1List = query.getResultList();
    		return cpsrss1List;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from CPSRSS1 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Cpsrss1[] findFuturesBySymbl(String hSymbl, long hDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getFuturesCPSRSSBySymbl");
    		query.setParameter("hSymbl", hSymbl);
    		query.setParameter("hDate", hDate);
    		List<Cpsrss1> cpsrss1 = query.getResultList();
    		Cpsrss1[] arrCpsrss1 = new Cpsrss1[cpsrss1.size()];
    		return cpsrss1.toArray(arrCpsrss1);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from CPSRSS1 - hSymbl: "+hSymbl+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Cpsrss1[] findIndexBySymbl(String hSymbl, long hDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCashFromFuturesBySymbl");
    		query.setParameter("hSymbl", hSymbl);
    		query.setParameter("hDate", hDate);
    		List<Cpsrss1> cpsrss1 = query.getResultList();
    		Cpsrss1[] arrCpsrss1 = new Cpsrss1[cpsrss1.size()];
    		return cpsrss1.toArray(arrCpsrss1);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from CPSRSS1 - hSymbl: "+hSymbl+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Cpsrss1[] findCashFromFuturesBySymbl(String hSymbl, long hDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCashFromFuturesBySymbl");
    		query.setParameter("hSymbl", hSymbl);
    		query.setParameter("hDate", hDate);
    		List<Cpsrss1> cpsrss1 = query.getResultList();
    		Cpsrss1[] arrCpsrss1 = new Cpsrss1[cpsrss1.size()];
    		return cpsrss1.toArray(arrCpsrss1);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from CPSRSS1 - hSymbl: "+hSymbl+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Cpsrss1[] findCashBySymbl(String hSymbl, long hDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCashCPSRSSBySymbl");
    		query.setParameter("hSymbl", hSymbl);
    		query.setParameter("hDate", hDate);
    		List<Cpsrss1> cpsrss1 = query.getResultList();
    		Cpsrss1[] arrCpsrss1 = new Cpsrss1[cpsrss1.size()];
    		return cpsrss1.toArray(arrCpsrss1);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from CPSRSS1 - hSymbl: "+hSymbl+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Cpsrss1[] findOptionsBySymbl(String hSymbl, long hDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getOptionCPSRSSBySymbl");
    		query.setParameter("hSymbl", hSymbl);
    		query.setParameter("hDate", hDate);
    		List<Cpsrss1> cpsrss1 = query.getResultList();
    		Cpsrss1[] arrCpsrss1 = new Cpsrss1[cpsrss1.size()];
    		return cpsrss1.toArray(arrCpsrss1);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching options from CPSRSS1 - hSymbl: "+hSymbl+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Cpsrss1> findOptionsBySymblAndDateAndExpiryAndPc(String hSymbl, long hDate,int expiry, String pc) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getOptionCPSRSSBySymblAndDateAndExpiryAndPc");
    		query.setParameter("hSymbl", hSymbl);
    		query.setParameter("hDate", hDate);
    		query.setParameter("expiry", expiry);
    		query.setParameter("pc", pc);
    		List<Cpsrss1> cpsrss1List = query.getResultList();
    		return cpsrss1List;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching options from CPSRSS1 - hSymbl: "+hSymbl+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Cpsrss1> findFuturesBySymblAndDateAndExpiry(String hSymbl, long hDate,int expiry) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getFuturesCPSRSSBySymblAndDateAndExpiry");
    		query.setParameter("hSymbl", hSymbl);
    		query.setParameter("hDate", hDate);
    		query.setParameter("expiry", expiry);
    		List<Cpsrss1> cpsrss1List = query.getResultList();
    		return cpsrss1List;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching options from CPSRSS1 - hSymbl: "+hSymbl+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<Cpsrss1> findOptionsBySymblAndDate(String hSymbl, Timestamp hDate) throws DataNotValidException {
		Query query = null;
    	try {
    		long longDate = GenericTools.shortDateFormatAsLong(hDate);
    		query = em.createNamedQuery("getOptionCPSRSSBySymblAndDate");
    		query.setParameter("hSymbl", hSymbl);
    		query.setParameter("hDate", longDate);
    		List<Cpsrss1> cpsrss1List = query.getResultList();
    		return cpsrss1List;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching options from CPSRSS1 - hSymbl: "+hSymbl+"; hDate: "+hDate+"  - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<Cpsrss1> findFuturesBySymblAndDate(String hSymbl, Timestamp hDate) throws DataNotValidException {
		Query query = null;
    	try {
    		long longDate = GenericTools.shortDateFormatAsLong(hDate);
    		
    		query = em.createNamedQuery("getFuturesCPSRSSBySymblAndDate");
    		query.setParameter("hSymbl", hSymbl);
    		query.setParameter("hDate", longDate);
    		List<Cpsrss1> cpsrss1List = query.getResultList();
    		return cpsrss1List;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching futures from CPSRSS1 - hSymbl: "+hSymbl+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Cpsrss1 findByPrimaryKey(String hSymbl, long hExpir, BigDecimal hStrik, String hPc, long hDate) throws DataNotValidException {
		try {
			Cpsrss1PK pK = new Cpsrss1PK();
			pK.setHSymbl(hSymbl);
			pK.setHExpir(hExpir);
			pK.setHStrik(hStrik);
			pK.setHPc(hPc);			
			pK.setHDate(hDate);
			Cpsrss1 cpsrss1 = (Cpsrss1) em.find(Cpsrss1.class,pK);
    		return cpsrss1;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from CPSRSS1 - - hSymbl: "+hSymbl+"; hExpir: "+hExpir+"; hStrik: "+hStrik+"; hPc: "+hPc+"; hDate: "+hDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
}
