package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.entities.VariationPK;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.Correlation;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class VariationEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class VariationEAO implements  VariationEAOLocal {

	@EJB private InstrumentEAOLocal instrEAO;
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}

	public String userString = "System";
	public String updType = "C";
	
	
	public Variation[] fetchAllVar() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAll");
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Variations - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Variation[] fetchDerVar() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllDerVar");
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives Variations - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Variation[] fetchVar() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllVar");
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Variations - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public String getVariationString() throws DataNotValidException {
		String message="Time range: ";
		Timestamp lastDate = hisprRett.findLastDate().getPk().getPriceDate();
		Timestamp firstDate = hisprRett.findFirstDate().getPk().getPriceDate();
		message += "from "+firstDate.toString().substring(0,10)+" to "+lastDate.toString().substring(0,10);
		return message;
	}*/
	
	public Variation[] findByInstrId(Instrument instr) throws DataNotValidException {
		Query query = null;
		String division = "equities";
    	try {
    		query.setParameter("instrId", instr.getInstrId());
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getDerVarByInstrId");
    			division = "derivatives";
    		} else {
    			query = em.createNamedQuery("getVarByInstrId");
    		}
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" variations - instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Variation[] fetchWithHp(Instrument instr) throws DataNotValidException {
		Query query = null;
		String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getDerVarByDHP");
    			division = "derivatives";
    		} else {
    			query = em.createNamedQuery("getVarByHP");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" variations with Historical Prices - instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	/*public Variation[] fetchWithHisVol(int instrId, int progExp) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHPByHisVol");
    		query.setParameter("instrId", instrId);
    		query.setParameter("progExp", progExp);
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Variations with Historical Volatility Series - instrId: "+instrId+"; progExp: "+progExp+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}*/
	
	
	
	public Variation[] findByInstrIdAndVarType(Instrument instr, String varType) throws DataNotValidException {
		Query query = null;
    	String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getDerVarByInstrIdAndVarType");
    			query.setParameter("prgExp", instr.getDefHistSer());
    			division = "derivatives";
    		} else {
    			query = em.createNamedQuery("getVarByInstrIdAndVarType");
    		}
    		query.setParameter("instrId", instr.getInstrId());		
    		query.setParameter("varType", varType);
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" variations - instrId: "+instr.getInstrId()+"; varType: "+varType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Variation[] findByInstrIdAndVarTypeAndNv(Instrument instr, String varType,int nv) throws DataNotValidException {
		Query query = null;
    	String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getDerVarByInstrIdAndVarTypeAndNv");
    			query.setParameter("prgExp", instr.getDefHistSer());
    			division = "derivatives";
    		} else {
    			query = em.createNamedQuery("getVarByInstrIdAndVarTypeAndNv");
    		}
    		query.setParameter("instrId", instr.getInstrId());		
    		query.setParameter("varType", varType);
    		query.setParameter("nv", nv);
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" variations - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; varType: "+varType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BigDecimal[] findVariatByInstrIdAndVarTypeAndNv(Instrument instr, String varType,int nv) throws DataNotValidException {
		Query query = null;
    	String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getDerVariatFieldByInstrIdAndVarTypeAndNv");
    			query.setParameter("prgExp", instr.getDefHistSer());
    			division = "derivatives";
    		} else {
    			query = em.createNamedQuery("getVariatFieldByInstrIdAndVarTypeAndNv");
    		}
    		query.setParameter("instrId", instr.getInstrId());		
    		query.setParameter("varType", varType);
    		query.setParameter("nv", nv);
    		List<BigDecimal> variation = query.getResultList();
    		BigDecimal[] arrVariation = new BigDecimal[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" variations - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; varType: "+varType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Correlation getCorrelationListByInstr1And2(Instrument instr1, Instrument instr2, String varType,int nv) throws DataNotValidException {
		Query query = null;
    	String division = GenericTools.getWholeDivisCode(instr1.getDivisCode());
		
    	int prgExp = 0;
		
		int instrId1 = instr1.getInstrId();
    	int instrId2 = instr2.getInstrId();
    	
		try {
    		
			if (instr1.getDivisCode().equalsIgnoreCase("D")) {
    			prgExp = instr1.getDefHistSer();
    		}
    		
    		String sqlString = "SELECT V1.PRICEDATE AS PRICEDATE, V1.VARIAT AS VARIATION1, V2.VARIAT AS VARIATION2 FROM PMPTVAR V1";
    		sqlString += " INNER JOIN PMPTVAR V2"; 
    		sqlString += " ON V1.PRICEDATE = V2.PRICEDATE"; 
    		sqlString += " AND V2.INSTRID = "+instrId2; 
    		sqlString += " AND V1.PRGEXP = V2.PRGEXP";
    		sqlString += " AND V1.NV = V2.NV";
    		sqlString += " AND V1.VARTYPE = V2.VARTYPE";
    		sqlString += " AND V1.STATUS = V2.STATUS";
    		sqlString += " WHERE V1.INSTRID = "+instrId1; 
    		sqlString += " AND V1.PRGEXP = "+prgExp; 
    		sqlString += " AND V1.NV = "+nv; 
    		sqlString += " AND V1.VARTYPE = '"+varType+"'"; 
    		sqlString += " AND V1.STATUS <> 'D'";
    		sqlString += " ORDER BY V1.PRICEDATE DESC";
    		
    		query =  em.createNativeQuery(sqlString,Correlation.class);
    		
    		List<Correlation> correlationList = query.getResultList();
    		
    		Correlation correlation = null;
    		
    		if (correlationList.size()>0)
    			correlation = Correlation.setCorrelationArray(correlationList); 
    		
    		return correlation;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" correlations - instrId1: "+instrId1+"; instrId2: "+instrId2+"; holding period: "+nv+"; varType: "+varType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<Correlation> getGroupCorrelationListByInstr1And2(Instrument instr1, Instrument instr2, String varType,int nv) throws DataNotValidException {
		Query query = null;
    	String division = GenericTools.getWholeDivisCode(instr1.getDivisCode());
		
    	int prgExp = 0;
		
		int instrId1 = instr1.getInstrId();
    	int instrId2 = instr2.getInstrId();
    	
		try {
    		
			if (instr1.getDivisCode().equalsIgnoreCase("D")) {
    			prgExp = instr1.getDefHistSer();
    		}
    		
    		String sqlString = "SELECT V1.PRICEDATE AS PRICEDATE, V1.VARIAT AS VARIATION1, V2.VARIAT AS VARIATION2 FROM PMPTVAR V1";
    		sqlString += " INNER JOIN PMPTVAR V2"; 
    		sqlString += " ON V1.PRICEDATE = V2.PRICEDATE"; 
    		sqlString += " AND V2.INSTRID = "+instrId2; 
    		sqlString += " AND V1.PRGEXP = V2.PRGEXP";
    		sqlString += " AND V1.NV = V2.NV";
    		sqlString += " AND V1.VARTYPE = V2.VARTYPE";
    		sqlString += " AND V1.STATUS = V2.STATUS";
    		sqlString += " WHERE V1.INSTRID = "+instrId1; 
    		sqlString += " AND V1.PRGEXP = "+prgExp; 
    		sqlString += " AND V1.NV = "+nv; 
    		sqlString += " AND V1.VARTYPE = '"+varType+"'"; 
    		sqlString += " AND V1.STATUS <> 'D'";
    		sqlString += " ORDER BY V1.PRICEDATE DESC";
    		
    		query =  em.createNativeQuery(sqlString,Correlation.class);
    		
    		List<Correlation> correlationList = query.getResultList();
    		
    		//Correlation correlation = Correlation.setCorrelationArray(correlationList); 
    		
    		return correlationList;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" correlations - instrId1: "+instrId1+"; instrId2: "+instrId2+"; holding period: "+nv+"; varType: "+varType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public Variation[] findByInstrIdAndVarTypeAndNv(int instrId, String varType,int nv) throws DataNotValidException {
		Instrument instr = instrEAO.findByPrimaryKey(instrId);
		return findByInstrIdAndVarTypeAndNv(instr,varType,nv);
	}
	
	public Variation[] findEnabledByInstrIdAndVarTypeAndNvAndInstrId2(Instrument instr, String varType,int nv, Instrument instr2) throws DataNotValidException {
		Query query = null;
    	String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query = em.createNamedQuery("getDerVarByInstrIdAndVarTypeAndNv2");
    			query.setParameter("prgExp", instr.getDefHistSer());
    			division = "derivatives";
    		} else {
    			query = em.createNamedQuery("getVarByInstrIdAndVarTypeAndNv2");
    		}
    		query.setParameter("instrId", instr.getInstrId());		
    		query.setParameter("varType", varType);
    		query.setParameter("nv", nv);
    		query.setParameter("instrId2", instr2.getInstrId());
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" variations - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; varType: "+varType+"; instrId2: "+instr2.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Variation[] findByInstrIdAndVarTypeAndNvAndPrgExp(Instrument instr, String varType,int nv, int prgExp) throws DataNotValidException {
		Query query = null;
		String division = "derivatives";
		try {
    		query = em.createNamedQuery("getDerVarByInstrIdAndVarTypeAndNvAndProgExp");
    		query.setParameter("prgExp", prgExp);
    		query.setParameter("instrId", instr.getInstrId());		
    		query.setParameter("varType", varType);
    		query.setParameter("nv", nv);
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" variations - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; varType: "+varType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Variation[] findByInstrIdAndVarTypeAndNvAndDate(Instrument instr, String varType,int nv, Timestamp startDate, Timestamp endDate) throws DataNotValidException {
		Query query = null;
		String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			division = "derivatives";
    			query = em.createNamedQuery("getDerVarByInstrIdAndVarTypeAndNvAndDate");
    		} else {
    			query = em.createNamedQuery("getVarByInstrIdAndVarTypeAndNvAndDate");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("varType", varType);
    		query.setParameter("nv", nv);
    		query.setParameter("startDate", startDate);
    		query.setParameter("endDate", endDate);
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" variations - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; varType: "+varType+"; priceDate between "+startDate+" and "+endDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Variation findByPrimaryKey(int instrId, int prgExp, int nv, Timestamp priceDate, String varType) throws DataNotValidException {
		try {
			VariationPK pK = new VariationPK();
			pK.setInstrId(instrId);
			pK.setPrgExp(prgExp);
			pK.setNv(nv);
			pK.setPriceDate(priceDate);
			pK.setVarType(varType);
			Variation variation = (Variation) em.find(Variation.class,pK);
    		return variation;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching variations - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Variation[] findVarByDateInterval(Timestamp startDate, Timestamp endDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getVarByDate");
    		query.setParameter("startDate", startDate);
    		query.setParameter("endDate", endDate);
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching variations - priceDate between "+startDate+" and "+endDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Variation[] findDerVarByDateInterval(Timestamp startDate, Timestamp endDate) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDerVarByDate");
    		query.setParameter("startDate", startDate);
    		query.setParameter("endDate", endDate);
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives Variations - priceDate between "+startDate+" and "+endDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Variation[] getFixedVariations(Instrument instr, int nv, int period, Timestamp lastDate, String varType) throws DataNotValidException {
		Query query = null;
		String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			division = "derivatives";
    			query = em.createNamedQuery("getFixedDerivativesVariations");
    		} else {
    			query = em.createNamedQuery("getFixedVariations");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("nv", nv);
    		query.setParameter("lastDate", lastDate);
    		query.setParameter("varType", varType);
    		query.setMaxResults(period);
    		List<Variation> variation = query.getResultList();
    		Variation[] arrVariation = new Variation[variation.size()];
    		return variation.toArray(arrVariation);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching fixed "+division+" variations - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; varType: "+varType+"; lastDate: "+lastDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<Variation> getFixedVariationsForBondStressTest(List<Instrument> instrList, String varType, int period, int[] nvVec, String disabVar) throws DataNotValidException {
		  
		String statusNoDisabled = "";
		String logDisabVar = "disabled variations not allowed";
		if (disabVar.equalsIgnoreCase("T")) {
			statusNoDisabled = " var.STATUS!='D'";
			logDisabVar = "disabled variations not allowed";
		}
		
		/*String posNegOrAllVariat = "";
		
		String strPosOrNegOrAll = "";
		
		switch (posOrNegOrAll) {
			case -1:
				posNegOrAllVariat = " WHERE VAR2.VARIAT < 0 ORDER BY ABS(VAR2.VARIAT) DESC"; 
				strPosOrNegOrAll = "only negative";
				break;
			case 0:
				posNegOrAllVariat+= " ORDER BY ABS(VAR2.VARIAT) DESC"; 
				strPosOrNegOrAll = "all";
				break;
			case 1:
				posNegOrAllVariat+= " WHERE VAR2.VARIAT > 0 ORDER BY ABS(VAR2.VARIAT) DESC"; 
				strPosOrNegOrAll = "only positive";
		}
		
		strPosOrNegOrAll+=" variations";*/
		
		/*String irCurveStr = "";
		
		for (String irCurve:arrIrCurve) {
			irCurveStr += "'"+irCurve+"',";
		}
		
		irCurveStr = irCurveStr.substring(0,irCurveStr.length()-1);*/
		
		String instrIdStr = "";
		
		
		for (Instrument instr:instrList) {
			instrIdStr += instr.getInstrId()+",";
		}
		
		instrIdStr = instrIdStr.substring(0,instrIdStr.length()-1);
		
		String nVList = "";
		
		for (int nv:nvVec) {
			nVList += nv+",";
		}
		
		nVList = nVList.substring(0,nVList.length()-1);
		
		Query query = null;
    	try {
    		String sqlString = "SELECT INSTRID,NV,PRICEDATE,VARTYPE,VARIAT,PRGEXP,STATUS,UPDTYPE,UPDUSR,UPDDATE FROM PMPTVAR VAR ";
    		sqlString += "WHERE VAR.INSTRID IN ("+instrIdStr+") ";
    		//sqlString += "(SELECT INSTRID FROM PMPTINSTR INSTR WHERE INSTR.LISTNAME IN ("+irCurveStr+"))";
    		sqlString += "AND VAR.PRGEXP = 0 ";
    		sqlString += "AND VAR.VARTYPE='"+varType+"' ";
    		sqlString += "AND VAR.NV IN ("+nVList+") ";// "+statusNoDisabled+" ";
    		sqlString += "ORDER BY VAR.PRICEDATE DESC ";//FETCH FIRST "+period+" ROWS ONLY";
    		
    		/*String sqlString = "SELECT VAR2.INSTRID,VAR2.NV,VAR2.PRICEDATE,VAR2.VARTYPE,VAR2.VARIAT,VAR2.PRGEXP,VAR2.STATUS,VAR2.UPDTYPE,VAR2.UPDUSR,VAR2.UPDDATE FROM ";
    		sqlString += "(SELECT INSTRID,NV,PRICEDATE,VARTYPE,VARIAT,PRGEXP,STATUS,UPDTYPE,UPDUSR,UPDDATE FROM PMPTVAR VAR WHERE INSTRID IN ";
    		sqlString += "(SELECT INSTRID FROM PMPTINSTR INSTR WHERE INSTR.LISTNAME IN ("+listName+"))";
    		sqlString += "AND VAR.PRGEXP = 0 AND VAR.VARTYPE='"+varType+"' AND VAR.NV IN ("+nVList+") "+statusNoDisabled+" ORDER BY VAR.PRICEDATE DESC FETCH FIRST "+period+" ROWS ONLY) ";
    		sqlString += "ORDER BY VAR.PRICEDATE DESC FETCH FIRST "+period+" ROWS ONLY";*/
    		
    		//System.out.println(sqlString);
    		
    		query =  em.createNativeQuery(sqlString,Variation.class);
    		List<Variation> variationList = query.getResultList();
    		
    		return variationList;
    		
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching the list of variations - instrId list: "+instrIdStr+"; varType: "+varType+"; period: "+period+", hp: "+nVList+"; "+logDisabVar+" - "+e.getMessage());
    		//DataNotValidException exc = new DataNotValidException("Error fetching the list of variations - listName: "+irCurveStr+"; varType: "+varType+"; period: "+period+", hp: "+nVList+"; "+logDisabVar+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public List<Variation> getFixedVariationsForStressTest(Instrument instr, String varType, int period, int[] nvVec) throws DataNotValidException {
		  
		/*String statusNoDisabled = "";
		String logDisabVar = "disabled variations not allowed";
		if (disabVar.equalsIgnoreCase("T")) {
			statusNoDisabled = " var.STATUS!='D' ";
			logDisabVar = "disabled variations not allowed";
		}*/
		
		/*String posNegOrAllVariat = "";
		
		String strPosOrNegOrAll = "";
		
		switch (posOrNegOrAll) {
			case -1:
				posNegOrAllVariat = " WHERE VAR2.VARIAT < 0 ORDER BY ABS(VAR2.VARIAT) DESC"; 
				strPosOrNegOrAll = "only negative";
				break;
			case 0:
				posNegOrAllVariat+= " ORDER BY ABS(VAR2.VARIAT) DESC"; 
				strPosOrNegOrAll = "all";
				break;
			case 1:
				posNegOrAllVariat+= " WHERE VAR2.VARIAT > 0 ORDER BY ABS(VAR2.VARIAT) DESC"; 
				strPosOrNegOrAll = "only positive";
		}
		
		strPosOrNegOrAll+=" variations";*/
		
		int instrId = instr.getInstrId();
		
		String classCode = instr.getClassCode();
		
		int prgExp = 0;
		
		if (instr.getDivisCode().equalsIgnoreCase("D")) {
			prgExp = instr.getDefHistSer();
		}
		
		String nVList = "";
		
		for (int nv:nvVec) {
			nVList += nv+",";
		}
		
		period = period*nvVec.length;
		
		nVList = nVList.substring(0,nVList.length()-1);
		
		Query query = null;
    	try {
    		//String sqlString = "SELECT VAR2.INSTRID,VAR2.NV,VAR2.PRICEDATE,VAR2.VARTYPE,VAR2.VARIAT,VAR2.PRGEXP,VAR2.STATUS,VAR2.UPDTYPE,VAR2.UPDUSR,VAR2.UPDDATE FROM ";
    		String sqlString = "SELECT INSTRID,NV,PRICEDATE,VARTYPE,VARIAT,PRGEXP,STATUS,UPDTYPE,UPDUSR,UPDDATE FROM PMPTVAR VAR ";
    		sqlString += "WHERE VAR.INSTRID = "+instrId+" ";
    		sqlString += "AND VAR.PRGEXP = "+prgExp+" ";
    		sqlString += "AND VAR.VARTYPE='"+varType+"' ";
    		sqlString += "AND VAR.NV IN ("+nVList+") ";
    		sqlString += "ORDER BY VAR.PRICEDATE DESC FETCH FIRST "+period+" ROWS ONLY";
    		//sqlString += "VAR2 ";
    		
    		//System.out.println(sqlString);
    		
    		query =  em.createNativeQuery(sqlString,Variation.class);
    		List<Variation> variationList = query.getResultList();

   			return variationList;
   			
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching the list of variations - instrId: "+instrId+"; classCode: "+classCode+"; varType: "+varType+"; period: "+period+", hp: "+nVList+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public int getSizeByInstrId(Instrument instr) throws DataNotValidException {
		Query query = null;
		String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			division = "derivatives";
    			query = em.createNamedQuery("getDerVarSizeByInstrId");
    		} else {
    			query = em.createNamedQuery("getVarSizeByInstrId");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		Long size = (Long) query.getSingleResult();
    		return size.intValue();
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" variations size - instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public int getSizeByInstrIdAndNvAndTh(Instrument instr, int nv, BigDecimal th) throws DataNotValidException {
		Query query = null;
		String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			division = "derivatives";
    			query = em.createNamedQuery("getDerVarSizeByInstrIdAndNvAndTh");
    		} else {
    			query = em.createNamedQuery("getVarSizeByInstrIdAndNvAndTh");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("nv", nv);
    		query.setParameter("th", th);
    		Long size = (Long) query.getSingleResult();
    		return size.intValue();
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" variations size - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; th: "+th+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
				
	public int getSizeByInstrIdAndNv(Instrument instr, int nv) throws DataNotValidException {
		Query query = null;
		String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			division = "derivatives";
    			query = em.createNamedQuery("getDerVarSizeByInstrIdAndNv");
    		} else {
    			query = em.createNamedQuery("getVarSizeByInstrIdAndNv");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("nv", nv);
    		Long size = (Long) query.getSingleResult();
    		return size.intValue();
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" variations size - instrId: "+instr.getInstrId()+"; holding period: "+nv+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Integer[] getPrgExpList(Instrument instr) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getDerVarDistinctPrgExp");
    		query.setParameter(1, instr.getInstrId());
    		List<Integer> prgExpList = query.getResultList();
    		Integer[] arrPrgExpList = new Integer[prgExpList.size()];
    		return prgExpList.toArray(arrPrgExpList);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Derivatives Variations PrgExp list - instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	

	public BigDecimal getExtremeValues(Instrument instr, int nv, String varType, int period, int exclude, int n, int choose) throws DataNotValidException {
		Query query = null;
		String queryName = "";
		String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			division = "derivatives";
    			queryName = "getDerVarExtremeValues";
    		} else {
    			queryName = "getVarExtremeValues";
    		}
    		
    		switch (choose) {
				case 0:
					break;
				case 1:
					queryName += "Pos";
					break;
				case -1:
					queryName += "Neg";
					break;
    		}
    		query = em.createNamedQuery(queryName);
    		query.setParameter("prgExp", instr.getDefHistSer());
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("nv", nv);
    		query.setParameter("varType", varType);
    		//prende la serie di variazioni scelta
    		query.setMaxResults(period);
    		
    		//query.setFirstResult(exclude);
    		List<BigDecimal> variat = query.getResultList();
    		BigDecimal[] arrVariat = new BigDecimal[variat.size()];
    		variat.toArray(arrVariat);
    		for (int i=0;i<arrVariat.length;i++) {
    			arrVariat[i]=arrVariat[i].abs();
    		}
    		Arrays.sort(arrVariat);
    		return arrVariat[arrVariat.length-1-n-exclude];
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Exreme "+division+" variations value - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; varType "+varType+"; period: "+period+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BigDecimal[] getExtremeValues(Instrument instr, int nv, String varType, int period, int choose) throws DataNotValidException {
		Query query = null;
		String queryName = "";
		String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			division = "derivatives";
    			queryName = "getDerVarExtremeValues";
    		} else {
    			queryName = "getVarExtremeValues";
    		}
    		
    		switch (choose) {
				case 0:
					break;
				case 1:
					queryName += "Pos";
					break;
				case -1:
					queryName += "Neg";
					break;
    		}
    		query = em.createNamedQuery(queryName);
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			query.setParameter("prgExp", instr.getDefHistSer());	
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("nv", nv);
    		query.setParameter("varType", varType);
    		//prende la serie di variazioni scelta
    		query.setMaxResults(period);
    		
    		//query.setFirstResult(exclude);
    		List<BigDecimal> variat = query.getResultList();
    		BigDecimal[] arrVariat = new BigDecimal[variat.size()];
    		variat.toArray(arrVariat);
    		for (int i=0;i<arrVariat.length;i++) {
    			arrVariat[i]=arrVariat[i].abs();
    		}
    		Arrays.sort(arrVariat);
    		return arrVariat;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Exreme "+division+" variations value - instrId: "+instr.getInstrId()+"; holding period: "+nv+"; varType "+varType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Timestamp getOldestDateByInstrId(Instrument instr) throws DataNotValidException {
		Query query = null;
		String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			division = "derivatives";
    			query = em.createNamedQuery("getDerVarOldestDateByInstrId");
    		} else {
    			query = em.createNamedQuery("getVarOldestDateByInstrId");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		//List<Integer> variation = query.getResultList();
    		Timestamp oldestDate = (Timestamp) query.getSingleResult();
    		//Variation[] arrVariation = new Variation[1];
    		return oldestDate;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Oldest "+division+" variations date - instrId: "+ instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Timestamp getLatestDateByInstrId(Instrument instr) throws DataNotValidException {
		Query query = null;
		String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			division = "derivatives";
    			query = em.createNamedQuery("getDerVarLatestDateByInstrId");
    		} else {
    			query = em.createNamedQuery("getVarLatestDateByInstrId");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		//List<Integer> variation = query.getResultList();
    		Timestamp oldestDate = (Timestamp) query.getSingleResult();
    		//Variation[] arrVariation = new Variation[1];
    		return oldestDate;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" variations date - instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public BigDecimal getMaxVariationByInstrId(Instrument instr, String varType) throws DataNotValidException {
		Query query = null;
		String division = "equities";
		try {
    		if (instr.getDivisCode().equalsIgnoreCase("D")) {
    			division = "derivatives";
    			query = em.createNamedQuery("getMaxDerVariationByInstrId");
    		} else {
    			query = em.createNamedQuery("getMaxVariationByInstrId");
    		}
    		query.setParameter("instrId", instr.getInstrId());
    		query.setParameter("varType", varType.toUpperCase());
    		BigDecimal maxVariation = (BigDecimal) query.getSingleResult();
    		return maxVariation;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching "+division+" max variations - instrId: "+instr.getInstrId()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void add(int instrId, int prgExp, int nv, Timestamp priceDate, String varType, BigDecimal variat, String status) throws DataNotValidException {
		try {
			Variation variation = new Variation();
			VariationPK pK = new VariationPK();
			pK.setInstrId(instrId);
			pK.setPrgExp(prgExp);
			pK.setNv(nv);
			pK.setPriceDate(priceDate);
			pK.setVarType(varType);
			variation.setPk(pK);
			variation.setVariat(variat);
			variation.setStatus(status);
			variation.setUpdDate(GenericTools.systemDate());
			variation.setUpdType(updType);
			variation.setUpdUsr(userString());
			em.persist(variation);
			log.debug("Added new Derivatives Variation - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate+"; variation: "+variat);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new variation - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(Vector<Variation> varVect) throws DataNotValidException {
		try {
			int i = 1;
			for (Variation var:varVect) {
				var.setUpdDate(GenericTools.systemDate());
				var.setUpdType(updType);
				var.setUpdUsr(userString());
				em.persist(var);
				if ((i % 1000) == 0) {
					em.flush();
					em.clear();
				}
				i++;
			}
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new variation - "+e.getMessage());// - instrId: "+variation.getPk().getInstrId()+"; prgExp: "+variation.getPk().getPrgExp()+"; nv: "+variation.getPk().getNv()+"; varType: "+variation.getPk().getVarType()+"; priceDate: "+variation.getPk().getPriceDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}  
	
	public void store(Variation variation) throws DataNotValidException {
		try {
			variation.setUpdDate(GenericTools.systemDate());
			variation.setUpdType(updType);
			variation.setUpdUsr(userString());
			em.persist(variation);
			log.debug("Added new Variation - instrId: "+variation.getPk().getInstrId()+"; prgExp: "+variation.getPk().getPrgExp()+"; holding period: "+variation.getPk().getNv()+"; varType: "+variation.getPk().getVarType()+"; priceDate: "+variation.getPk().getPriceDate()+"; variation: "+variation.getVariat());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new variation - instrId: "+variation.getPk().getInstrId()+"; prgExp: "+variation.getPk().getPrgExp()+"; holding period: "+variation.getPk().getNv()+"; varType: "+variation.getPk().getVarType()+"; priceDate: "+variation.getPk().getPriceDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(int instrId, int prgExp, int nv, Timestamp priceDate, String varType, BigDecimal variat, String status) throws DataNotValidException {
		try {	
			Variation variation = findByPrimaryKey(instrId, prgExp, nv, priceDate, varType);
			variation.setVariat(variat);
			variation.setStatus(status);
			variation.setUpdDate(GenericTools.systemDate());
			variation.setUpdType("U");
			variation.setUpdUsr(userString());
			log.debug("Derivatives Variation updated - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate+"; variation: "+variat);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating variation - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(Variation derVar) throws DataNotValidException {
		try {
			log.debug("Derivatives Variation updated - instrId: "+derVar.getPk().getInstrId()+"; holding period: "+derVar.getPk().getNv()+"; varType: "+derVar.getPk().getVarType()+"; priceDate: "+derVar.getPk().getPriceDate()+"; variation: "+derVar.getVariat());
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating variation - instrId: "+derVar.getPk().getInstrId()+"; holding period: "+derVar.getPk().getNv()+"; varType: "+derVar.getPk().getVarType()+"; priceDate: "+derVar.getPk().getPriceDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void logUpdate(Variation derVar) throws DataNotValidException {
		try {
			update(derVar);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating variation - instrId: "+derVar.getPk().getInstrId()+"; holding period: "+derVar.getPk().getNv()+"; varType: "+derVar.getPk().getVarType()+"; priceDate: "+derVar.getPk().getPriceDate()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(int instrId, int prgExp, int nv, Timestamp priceDate, String varType) throws DataNotValidException {
		try {
			Variation variation = findByPrimaryKey(instrId, prgExp, nv, priceDate, varType);
			em.remove(variation);
			log.debug("Variation removed - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing variation - instrId: "+instrId+"; prgExp: "+prgExp+"; holding period: "+nv+"; varType: "+varType+"; priceDate: "+priceDate+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(Variation derVar) throws DataNotValidException {
		remove(derVar.getPk().getInstrId(), derVar.getPk().getPrgExp(), derVar.getPk().getNv(), derVar.getPk().getPriceDate(), derVar.getPk().getVarType());
	}
	
	public int removeByEnabledInstrId(String divisCode) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteAllVarByEnabledInstrId");
			query.setParameter("divisCode", divisCode);
			int result = query.executeUpdate();
			log.debug(result+" Variations related to disabled instruments removed - divisCode: "+divisCode);
			return result;
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing variations related to disabled instruments removed - divisCode: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public int removeByInstrId(Instrument instr) throws DataNotValidException {
		Query query = null;
		String division = "equities";
		try {
	    	if (instr.getDivisCode().equalsIgnoreCase("D")) {
	    		division = "derivatives";
    			query = em.createNamedQuery("deleteDerVarByInstrId");
    		} else {
    			query = em.createNamedQuery("deleteVarByInstrId");
    		}
    		query.setParameter(1, instr.getInstrId());
			int result = query.executeUpdate();
			log.debug("InstrId: "+instr.getInstrId()+" - "+result+" "+division+" variations removed");
			return result;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing "+division+" variations - instrId: "+instr.getInstrId()+" - "+e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

}
