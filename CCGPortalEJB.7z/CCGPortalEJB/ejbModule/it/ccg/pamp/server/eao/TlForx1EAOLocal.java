package it.ccg.pamp.server.eao;
import it.ccg.pamp.server.entities.TlForx1;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.util.LinkedHashMap;
import java.util.List;

import javax.ejb.Local;
import javax.persistence.Query;

@Local
public interface TlForx1EAOLocal {
	
	public List<TlForx1> fetch() throws DataNotValidException;
	
	public LinkedHashMap<String,String> transcodeCurrency() throws DataNotValidException;
	
}
