package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Spread;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class SpreadEAO
 */
@Stateless
public class SpreadEAO implements  SpreadEAOLocal {
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	public Spread getSpread(String mmTable, BigDecimal price) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getSpread");
    		query.setParameter("mmTable", mmTable);
    		query.setParameter("price", price);
    		List<Spread> spreadList = query.getResultList();
    		query.setMaxResults(1);
    		Spread spread = null;
    		if (spreadList.size()>0) { 
    			spread = spreadList.get(0);
    		}
    		return spread;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching Spread - mmTable: "+mmTable+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
