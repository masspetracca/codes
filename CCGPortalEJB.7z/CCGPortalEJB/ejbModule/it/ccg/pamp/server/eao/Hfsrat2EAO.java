package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Hfsrat2;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class Hfsrat2EAO
 */
@Stateless
public class Hfsrat2EAO implements  Hfsrat2EAOLocal {
	
	@PersistenceContext(unitName="CSDS", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public Timestamp updDate = systemDate();
	public String userString = "System";
	public String updType = "C";
	
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<Hfsrat2> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllHfsrat2");
    		List<Hfsrat2> hfsrat2List = query.getResultList();
    		return hfsrat2List;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Hfsrat2 - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public Hfsrat2 findByFClass(String fClass) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getHfsrat2ByFClass");
    		query.setParameter("fClass", fClass);
    		Hfsrat2 hfsrat2 = (Hfsrat2) query.getSingleResult();
    		//Hfsrat2[] arrHfsrat2 = new Hfsrat2[hfsrat2.size()];
    		return hfsrat2;//.toArray(arrHfsrat2);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching data from Hfsrat2 - fClass: "+fClass+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public void update(String fClass, BigDecimal straddle) throws DataNotValidException {
		try {
			Hfsrat2 hfsrat2 = findByFClass(fClass);
			hfsrat2.setFssprd(straddle);
			hfsrat2.setFnsprd(straddle);
			log.debug("Hfsrat2 updated - fClass: "+fClass+"; new fssprd: "+straddle+"; new fnsprd: "+straddle);
		} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating Hfsrat2 - fClass: "+fClass+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

}
