package it.ccg.pamp.server.eao.stressTest;
import java.sql.Timestamp;

import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface StressTestRiskEngineProceduresEAOLocal {

	public void launchGiornoZero() throws DataNotValidException;
	
	public void startReStressTestProcedure(Timestamp stressTestDate, int stId, String scenario) throws DataNotValidException;
	
	public String commandCallAs400(int processId, String divisCode) throws DataNotValidException;
	
}
