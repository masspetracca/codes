package it.ccg.pamp.server.eao;

import it.ccg.pamp.server.entities.Confidence;
//import it.ccg.pamp.server.entities.ConfidenceArchive;
import it.ccg.pamp.server.entities.ConfidencePK;
import it.ccg.pamp.server.entities.DefaultConfidence;
import it.ccg.pamp.server.entities.DefaultDelta;
import it.ccg.pamp.server.entities.DefaultPeriod;
import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.SimulationConfidence;
import it.ccg.pamp.server.entities.Variation;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.exceptions.InstrumentDataNotAvailableException;
import it.ccg.pamp.server.utils.GenericTools;
import it.ccg.pamp.server.utils.MultiKey;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ConfidenceEAO
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class ConfidenceEAO implements  ConfidenceEAOLocal {
	@EJB
	InstrumentEAOLocal instrumentEAO;
	@EJB
	DefaultConfidenceEAOLocal defConfEAO;
	@EJB
	DefaultPeriodEAOLocal defPerEAO;
	@EJB
	DefaultDeltaEAOLocal defDeltaEAO;
	@EJB
	SimulationConfidenceEAOLocal simConfEAO;
	@EJB
	ConfidenceEAOLocal confEAO;

	@PersistenceContext(unitName = "PAMPUSE", type = PersistenceContextType.TRANSACTION)
	private EntityManager em;

	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	public String updType = "C";

	@Resource
	SessionContext ctx;

	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}

	

	@SuppressWarnings("unchecked")
	public Confidence[] fetch() throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getAllCNF");
			List<Confidence> confidence = query.getResultList();
			Confidence[] arrConfidence = new Confidence[confidence.size()];
			return confidence.toArray(arrConfidence);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching Confidences - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public String getConfidenceString(int instrId) throws DataNotValidException {
		String message = "Confidences: ";
		Integer[] delta = getActiveDelta(instrId);
		MathContext mathC = new MathContext(3);
		for (int i = 0; i < delta.length; i++) {
			Integer[] periods = getEnabledPeriods(instrId, delta[i]);
			for (int j = 0; j < periods.length; j++) {
				Confidence conf = findByPrimaryKey(instrId, periods[j], delta[i]);
				message += "{delta: " + delta[i] + "; period: " + periods[j] + "; conf: " + conf.getConfidence().round(mathC).doubleValue() * 100 + "%} ";
			}
		}
		return message;
	}

	// prende i delta attivi
	public Integer[] getActiveDelta(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getActiveDelta");
			query.setParameter("instrId", instrId);
			String instrType = instrumentEAO.findByPrimaryKey(instrId).getInstrType();
			query.setParameter("instrType", instrType);
			List<Integer> nvList = query.getResultList();
			Integer[] arrIntegerObj = new Integer[nvList.size()];
			nvList.toArray(arrIntegerObj);
			return arrIntegerObj;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching active delta for Confidences - instrId: " + instrId + ": " + e.getMessage() + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public Integer[] getActivePeriods(int instrId, int delta) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getActivePeriods");
			query.setParameter("instrId", instrId);
			query.setParameter("nv", delta);
			String instrType = instrumentEAO.findByPrimaryKey(instrId).getInstrType();
			query.setParameter("instrType", instrType);
			List<Integer> nDaysPerList = query.getResultList();
			Integer[] arrIntegerObj = new Integer[nDaysPerList.size()];
			nDaysPerList.toArray(arrIntegerObj);
			return arrIntegerObj;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching active periods for Confidences - instrId: " + instrId + "; delta: " + delta + " - " + e.getMessage() + " - "
					+ e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public Integer[] getEnabledPeriods(int instrId, int delta) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getEnabledPeriods");
			query.setParameter("instrId", instrId);
			query.setParameter("nv", delta);
			String instrType = instrumentEAO.findByPrimaryKey(instrId).getInstrType();
			query.setParameter("instrType", instrType);
			List<Integer> nvList = query.getResultList();
			Integer[] arrIntegerObj = new Integer[nvList.size()];
			nvList.toArray(arrIntegerObj);
			return arrIntegerObj;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching enabled periods for Confidences - instrId: " + instrId + "; delta: " + delta + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public Confidence[] findByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getCNFByInstrId");
			query.setParameter("instrId", instrId);
			List<Confidence> confidence = query.getResultList();
			Confidence[] arrConfidence = new Confidence[confidence.size()];
			return confidence.toArray(arrConfidence);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching Confidences - instrId: " + instrId + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public Confidence[] findEnabledByInstrId(int instrId) throws DataNotValidException {
		Query query = null;
		try {
			query = em.createNamedQuery("getEnabledConfByInstrId");
			query.setParameter("instrId", instrId);
			List<Confidence> confidence = query.getResultList();
			Confidence[] arrConfidence = new Confidence[confidence.size()];
			return confidence.toArray(arrConfidence);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching enabled confidences - instrId: " + instrId + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public Confidence findByPrimaryKey(int instrId, int nDaysPer, int nv) throws DataNotValidException {
		try {
			ConfidencePK pK = new ConfidencePK();
			pK.setInstrId(instrId);
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			Confidence confidence = em.find(Confidence.class, pK);
			return confidence;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching Confidence - instrId: " + instrId + "; nDaysPer: " + nDaysPer + "; holding period: " + nv + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	
	public int updateConfidenceByCurveName(int instrId,String listName) throws DataNotValidException {
		Query query = null;
    	try {
    		String sqlString = "UPDATE PMPTCONF C1 "+
    						   "SET (C1.CONFIDENCE,C1.STATUS, C1.DEFCONF, C1.UPDTYPE, C1.UPDDATE, C1.UPDUSR) = "+ 
    						   "(SELECT C2.CONFIDENCE, C2.STATUS, C2.DEFCONF, 'U', '"+GenericTools.systemDate()+"', '"+userString()+"' "+
    						   "FROM PMPTCONF C2 "+
    						   "WHERE C2.NV = C1.NV AND C2.NDAYSPER = C1.NDAYSPER "+ 
    						   "AND C2.INSTRID = "+instrId+") "+
    						   "WHERE INSTRID IN (SELECT INSTRID FROM PMPTINSTR WHERE DIVISCODE = 'B' AND STATUS = 'E' AND LISTNAME = '"+listName+"') ";
    		
    		
    		query =  em.createNativeQuery(sqlString);
    		int i = query.executeUpdate();
    		log.debug("Updated "+i+" confidences for IR curve "+listName+" using confidence values of instrId: " + instrId);
   			return i;
   			
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating confidence for IR curve "+listName+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void getActualConfidence(int instrId, Map<MultiKey, String> actualStatusMap, Map<MultiKey, BigDecimal> actualConfidenceMap) throws DataNotValidException,
			InstrumentDataNotAvailableException {
		try {

			// instrument type
			String instrType = instrumentEAO.findByPrimaryKey(instrId).getInstrType();

			// periodi di default per instrType
			DefaultPeriod[] defPer = defPerEAO.findByInstrType(instrType);
			if (defPer == null || defPer.length == 0)
				throw new InstrumentDataNotAvailableException(instrId, "Default period not available for instrType: " + instrType);

			Map<Integer, String> defPerMap = new HashMap<Integer, String>();
			for (DefaultPeriod dP : defPer) {
				defPerMap.put(dP.getPk().getNDaysPer(), dP.getPStatus());
			}

			// delta di default per instrType
			DefaultDelta[] defDelta = defDeltaEAO.findByInstrType(instrType);
			if (defDelta == null || defDelta.length == 0)
				throw new InstrumentDataNotAvailableException(instrId, "Default delta not available for instrType: " + instrType);

			Map<Integer, String> defDeltaMap = new HashMap<Integer, String>();
			for (DefaultDelta dDel : defDelta) {
				defDeltaMap.put(dDel.getPk().getNv(), dDel.getDStatus());
			}

			// confidence di default per instrType
			DefaultConfidence[] defConf = defConfEAO.findByInstrType(instrType);
			if (defConf == null || defConf.length == 0)
				throw new InstrumentDataNotAvailableException(instrId, "Default confidence not available for instrType: " + instrType);

			Map<MultiKey, BigDecimal> defConfMap = new HashMap<MultiKey, BigDecimal>();
			MultiKey multiKey = null; // multikey = nv,nDaysPer
			for (DefaultConfidence dConf : defConf) {
				multiKey = new MultiKey(dConf.getPk().getNv(), dConf.getPk().getNDaysPer());
				defConfMap.put(multiKey, dConf.getConfidDf());
			}

			// ottengo le confidence per instrId
			Confidence[] arrConf = findByInstrId(instrId);
			if (arrConf == null)
				throw new InstrumentDataNotAvailableException(instrId, "Confidence not available");
			int nv = 0;
			int nDaysPer = 0;
			String def = "T";
			String status = "E";
			for (Confidence conf : arrConf) {
				nv = conf.getPk().getNv();
				nDaysPer = conf.getPk().getNDaysPer();
				def = conf.getDefConf();
				status = conf.getStatus();
				multiKey = new MultiKey(nv, nDaysPer);
				// siamo nella condizione di default
				if (def.equals("T")) {
					if (defDeltaMap.get(nv).equalsIgnoreCase("E")) {
						actualStatusMap.put(multiKey, defPerMap.get(nDaysPer));
					} else {
						actualStatusMap.put(multiKey, "D");
					}
					actualConfidenceMap.put(multiKey, defConfMap.get(multiKey));
				}
				// non siamo nella condizione di default ma in quella customized
				else {
					actualStatusMap.put(multiKey, status);
					actualConfidenceMap.put(multiKey, conf.getConfidence());
				}
			}

		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error fetching actual Confidence - instrId: " + instrId + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public int disableAll(int instrId) throws DataNotValidException, InstrumentDataNotAvailableException {
		try {
			Query query = null;
			query = em.createNamedQuery("disableConfidenceByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug(result + " Confidences disabled - instrId: " + instrId);
			return result;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error disabling Confidences - instrId: " + instrId + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void enable(Confidence confid) throws DataNotValidException, InstrumentDataNotAvailableException {
		try {
			Confidence confidence = findByPrimaryKey(confid.getPk().getInstrId(), confid.getPk().getNDaysPer(), confid.getPk().getNv());
			confidence.setStatus("E");
			confidence.setDefConf("F");
			log.debug("Confidence enabled - instrId: " + confid.getPk().getInstrId() + "; nDaysPer: " + confid.getPk().getNDaysPer() + "; holding period: " + confid.getPk().getNv());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error enabling this Confidence - instrId: " + confid.getPk().getInstrId() + "; nDaysPer: " + confid.getPk().getNDaysPer() + "; holding period: "
					+ confid.getPk().getNv() + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void add(int instrId, int nDaysPer, int nv, BigDecimal confid, String defConf, String status) throws DataNotValidException {
		try {
			Confidence confidence = new Confidence();
			ConfidencePK pK = new ConfidencePK();
			pK.setInstrId(instrId);
			pK.setNDaysPer(nDaysPer);
			pK.setNv(nv);
			confidence.setPk(pK);
			confidence.setConfidence(confid);
			confidence.setDefConf(defConf);
			confidence.setStatus(status);
			confidence.setUpdType(updType);
			confidence.setUpdDate(GenericTools.systemDate());
			confidence.setUpdUsr(userString());
			em.persist(confidence);
			log.debug("Added new Confidence - instrId: " + instrId + "; nDaysPer: " + nDaysPer + "; holding period: " + nv);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding new Confidence - instrId: " + instrId + "; nDaysPer: " + nDaysPer + "; holding period: " + nv + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void store(Confidence confidence) throws DataNotValidException {
		try {
			confidence.setUpdType(updType);
			confidence.setUpdDate(GenericTools.systemDate());
			confidence.setUpdUsr(userString());
			em.persist(confidence);
			log.debug("Added new Confidence - instrId: " + confidence.getPk().getInstrId() + "; nDaysPer: " + confidence.getPk().getNDaysPer() + "; holding period: " + confidence.getPk().getNv());
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error adding new Confidence - instrId: " + confidence.getPk().getInstrId() + "; nDaysPer: " + confidence.getPk().getNDaysPer()
					+ "; holding period: " + confidence.getPk().getNv() + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public int storeSimulatedConfidence(int instrId) throws DataNotValidException, InstrumentDataNotAvailableException {
		Instrument instr = instrumentEAO.findByPrimaryKey(instrId);
		if (instr == null) {
			throw new InstrumentDataNotAvailableException(instrId, "No instruments found with this instrID");
		}

		// recupero conf e status dello strumento
		Map<MultiKey, String> actualStatusMap = new HashMap<MultiKey, String>();
		Map<MultiKey, BigDecimal> actualConfidenceMap = new HashMap<MultiKey, BigDecimal>();
		this.getActualConfidence(instrId, actualStatusMap, actualConfidenceMap);

		SimulationConfidence[] simConfarr = simConfEAO.findByInstrId(instrId);
		if(simConfarr.length==0){
			log.warn("INSTRID " + instrId + ": no sim confidences found for this instrid");
			return 0;
		}
			
			
			
		int counter = 0;
		for (SimulationConfidence simconf : simConfarr) {

			MultiKey multiKey = new MultiKey(simconf.getPk().getNv(), simconf.getPk().getNDaysPer());

			String actualStatus = actualStatusMap.get(multiKey);
			BigDecimal actualConfidence = actualConfidenceMap.get(multiKey);

			// se lo stato corrente della confidence � diverso da quello della
			// simulazione devo operare l'update
			// stessa cosa se le confidence non sono uguali e lo stato lo �
			if ((!actualStatus.equalsIgnoreCase(simconf.getStatus())) || (actualStatus.equalsIgnoreCase(simconf.getStatus()) && actualConfidence.compareTo(simconf.getConfidence()) != 0)) {
				Confidence confidence = confEAO.findByPrimaryKey(instrId, simconf.getPk().getNDaysPer(), simconf.getPk().getNv());
				if (confidence == null) {
					log.warn("INSTRID " + instrId + ": no confidences found for ndaysper " + simconf.getPk().getNDaysPer() + " and holding period " + simconf.getPk().getNv());
					continue;
				}
				
				
				confidence.setConfidence(simconf.getConfidence());
				confidence.setDefConf("F");
				confidence.setStatus(simconf.getStatus());
				confidence.setUpdType(updType);
				confidence.setUpdDate(GenericTools.systemDate());
				confidence.setUpdUsr(userString());
		
				log.info("INSTRID "+instrId+" NV "+simconf.getPk().getNv()+" NDaysPer "+simconf.getPk().getNDaysPer()+": Confidence updated, new value: "+confidence.getConfidence()+" status: "+confidence.getStatus());
				
				
				counter++;

			}
			else{
				log.info("INSTRID "+instrId+" NV "+simconf.getPk().getNv()+" NDaysPer "+simconf.getPk().getNDaysPer()+": No differences between Actual confidence and SimConfidence");
				
			}

			// defConfEAO.findByPrimaryKey(instr.getInstrType(),
			// confidence.getPk().getNDaysPer(), confidence.getPk().getNv());

			
		}
		return counter;
	}

	/*
	 * public void restore(int updId) throws DataNotValidException { Query query
	 * = null; try { query = em.createNamedQuery("getCnfArchByUpdId");
	 * query.setParameter("updId", updId); ConfidenceArchive confArchive =
	 * (ConfidenceArchive) query.getSingleResult(); Confidence confidence =
	 * findByPrimaryKey
	 * (confArchive.getInstrId(),confArchive.getNDaysPer(),confArchive.getNV());
	 * if (confArchive!=null) {
	 * confidence.setConfidence(confArchive.getConfidence());
	 * confidence.setDefConf(confArchive.getDefConf());
	 * confidence.setStatus(confArchive.getStatus());
	 * confidence.setUpdType("U"); confidence.setUpdDate(GenericTools.systemDate());
	 * confidence.setUpdUsr(confArchive.getUpdUsr());
	 * log.debug("Confidence restored - instrId: "
	 * +confArchive.getInstrId()+"; nDaysPer: "
	 * +confArchive.getNDaysPer()+"; nv: "+confArchive.getNV()); } } catch
	 * (Exception e) { DataNotValidException exc = new
	 * DataNotValidException("Error restoring Confidence from archive - updId: "
	 * +updId+" "+e.getMessage()); exc.setStackTrace(e.getStackTrace()); throw
	 * exc; } }
	 */
	public void update(int instrId, int nDaysPer, int nv, BigDecimal confid, String defConf, String status) throws DataNotValidException {
		try {
			Confidence confidence = findByPrimaryKey(instrId, nDaysPer, nv);
			confidence.setConfidence(confid);
			confidence.setDefConf(defConf);
			confidence.setStatus(status);
			confidence.setUpdType("U");
			confidence.setUpdDate(GenericTools.systemDate());
			confidence.setUpdUsr(userString());
			log.debug("Confidence updated - instrId: " + instrId + "; nDaysPer: " + nDaysPer + "; holding period: " + nv);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error updating Confidence - instrId: " + instrId + "; nDaysPer: " + nDaysPer + "; holding period: " + nv + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void update(Confidence entryConfidence) {

			log.info("Confidence updated - INSTRID: " + entryConfidence.getPk().getInstrId() + "; nDaysPer: " + entryConfidence.getPk().getNDaysPer() + "; holding period: " + entryConfidence.getPk().getNv());
			
		
	}

	public void remove(int instrId, int nDaysPer, int nv) throws DataNotValidException {
		try {
			Confidence confidence = findByPrimaryKey(instrId, nDaysPer, nv);
			em.remove(confidence);
			log.debug("Confidence removed - instrId: " + instrId + "; nDaysPer: " + nDaysPer + "; holding period: " + nv);
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing Confidence - instrId: " + instrId + "; nDaysPer: " + nDaysPer + "; holding period: " + nv + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public int removeByInstrId(int instrId) throws DataNotValidException {
		try {
			Query query = null;
			query = em.createNamedQuery("deleteCNFByInstrId");
			query.setParameter("instrId", instrId);
			int result = query.executeUpdate();
			log.debug(result + " Confidences removed - instrId: " + instrId);
			return result;
		} catch (Exception e) {
			DataNotValidException exc = new DataNotValidException("Error removing Confidence - instrId: " + instrId + " - " + e.getMessage());
			exc.setStackTrace(e.getStackTrace());
			throw exc;
		}
	}

	public void remove(Confidence confidence) throws DataNotValidException {
		remove(confidence.getPk().getInstrId(), confidence.getPk().getNDaysPer(), confidence.getPk().getNv());
	}
}
