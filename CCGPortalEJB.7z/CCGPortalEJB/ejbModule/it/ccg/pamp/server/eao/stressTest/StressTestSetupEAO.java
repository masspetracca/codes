package it.ccg.pamp.server.eao.stressTest;

import it.ccg.pamp.server.entities.Instrument;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPrice;
import it.ccg.pamp.server.entities.stressTest.StressTestHistPricePK;
import it.ccg.pamp.server.entities.stressTest.StressTestSetup;
import it.ccg.pamp.server.exceptions.DataNotValidException;
import it.ccg.pamp.server.utils.GenericTools;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class StressTestSetupEAO
 */
@Stateless
public class StressTestSetupEAO implements  StressTestSetupEAOLocal {

	Logger userLog = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	@Resource
	SessionContext ctx;
	
	@PermitAll
	public String userString() throws DataNotValidException {
		if (!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED")) {
			return ctx.getCallerPrincipal().getName().toString();
		} else {
			return "System";
		}
	}
	
	public String userString = "System";
	public String updType = "C";
	
	@PersistenceContext(unitName="PAMPUSE", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	public List<StressTestSetup> fetch() throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getAllStressTestSetups");
    		List<StressTestSetup> stressTestSetupList = query.getResultList();
    		return stressTestSetupList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test settings - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestSetup> fetchStressTestSetupsByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("fetchStressTestSetupsByDivisCode");
    		query.setParameter("divisCode",divisCode);
    		List<StressTestSetup> stressTestSetupList = query.getResultList();
    		return stressTestSetupList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test settings - division: "+divisCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public List<StressTestSetup> fetchByDivision(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getStressTestSetupsByDivision");
    		query.setParameter("divisCode",divisCode);
    		List<StressTestSetup> stressTestSetupList = query.getResultList();
    		return stressTestSetupList;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test settings - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	public StressTestSetup findByPrimaryKey(String instrType) throws DataNotValidException {
		try {
			StressTestSetup stressTestSetup = (StressTestSetup) em.find(StressTestSetup.class,instrType);
    		return stressTestSetup;
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test settings - instrType: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	@Override
	public StressTestSetup findByBondClassID(Instrument instr) throws DataNotValidException {
		String instrType="";
		if(instr.getBndClassId()>=1&&instr.getBndClassId()<=11){
			
			userLog.info("INSTRID "+instr.getInstrId()+": using the Govies stress setup as class ID is equal to "+instr.getBndClassId());
			instrType="GOVIES";
		
		}
		else {
			instrType="RET";
			userLog.info("INSTRID "+instr.getInstrId()+": using the RET stress setup as class ID is equal to "+instr.getBndClassId());
		}
		return this.findByPrimaryKey(instrType);
	}
	
	
	public StressTestSetup findMinDefFoundByDivisCode(String divisCode) throws DataNotValidException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getMinDefFoundByDivisCode");
    		query.setParameter("divisCode",divisCode);
    		List<StressTestSetup> stressTestSetupList = query.getResultList();
    		if (stressTestSetupList.size()>0) {
    			return stressTestSetupList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error fetching stress test settings - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}

	
	
	public void add(String instrType, Timestamp histUpdDay, String histUpdLst, String nvVec, int period, int extrNP, int extrSP, int extrNN, int extrSN, String marDerP, String marPropP,
		BigDecimal marMulP, String marDerN, String marPropN, BigDecimal marMulN, BigDecimal stDevMulP, BigDecimal stDevMulN, BigDecimal volaCoeff, String disabVar, String method, String irCurveLst, int covMbr, String divisCode, int lstMntRep) throws DataNotValidException {
		
		try {
			StressTestSetup stressTestSetup = new StressTestSetup();
			
			stressTestSetup.setInstrType(instrType);
			stressTestSetup.setHistUpdDay(histUpdDay);
			stressTestSetup.setHistUpdLst(histUpdLst);
			stressTestSetup.setNvVec(nvVec);
			stressTestSetup.setPeriod(period);
			stressTestSetup.setExtrNP(extrNP);
			stressTestSetup.setExtrSP(extrSP);
			stressTestSetup.setExtrNN(extrNN);
			stressTestSetup.setExtrSN(extrSN);
			stressTestSetup.setMarDerP(marDerP);
			stressTestSetup.setMarDerN(marDerN);
			stressTestSetup.setMarPropP(marPropP);
			stressTestSetup.setMarPropN(marPropN);
			stressTestSetup.setMarMulP(marMulP);
			stressTestSetup.setMarMulN(marMulN);
			stressTestSetup.setStDevMulP(stDevMulP);
			stressTestSetup.setStDevMulN(stDevMulN);
			stressTestSetup.setVolaCoeff(volaCoeff);
			stressTestSetup.setDisabVar(disabVar);
			stressTestSetup.setMethod(method);
			stressTestSetup.setIrCurveLst(irCurveLst);
			stressTestSetup.setCovMbr(covMbr);
			stressTestSetup.setDivisCode(divisCode);
			stressTestSetup.setLstMntRep(lstMntRep);
			
			stressTestSetup.setUpdType(updType);
			stressTestSetup.setUpdDate(GenericTools.systemDate());
			stressTestSetup.setUpdUsr(userString());
			
			em.persist(stressTestSetup);
			userLog.debug("Added new stress test setting - instrType: "+instrType);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test setting -  instrType: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	
	public void store(StressTestSetup stressTestSetup) throws DataNotValidException {
		
		try {
			stressTestSetup.setUpdType(updType);
			stressTestSetup.setUpdDate(GenericTools.systemDate());
			stressTestSetup.setUpdUsr(userString());
			em.persist(stressTestSetup);
			userLog.debug("Added new stress test setting - instrType: "+stressTestSetup.getInstrType());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error adding new stress test setting -  instrType: "+stressTestSetup.getInstrType()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(String instrType, Timestamp histUpdDay, String histUpdLst, String nvVec, int period, int extrNP, int extrSP, int extrNN, int extrSN, String marDerP, String marPropP,
		BigDecimal marMulP, String marDerN, String marPropN, BigDecimal marMulN, BigDecimal stDevMulP, BigDecimal stDevMulN, BigDecimal volaCoeff, String disabVar, String method, String irCurveLst, int covMbr, String divisCode, int lstMntRep) throws DataNotValidException {
		
		try {
			StressTestSetup stressTestSetup = this.findByPrimaryKey(instrType);
			
			stressTestSetup.setPeriod(period);
			stressTestSetup.setHistUpdDay(histUpdDay);
			stressTestSetup.setHistUpdLst(histUpdLst);
			stressTestSetup.setNvVec(nvVec);
			stressTestSetup.setExtrNP(extrNP);
			stressTestSetup.setExtrSP(extrSP);
			stressTestSetup.setExtrNN(extrNN);
			stressTestSetup.setExtrSN(extrSN);
			stressTestSetup.setMarDerP(marDerP);
			stressTestSetup.setMarDerN(marDerN);
			stressTestSetup.setMarPropP(marPropP);
			stressTestSetup.setMarPropN(marPropN);
			stressTestSetup.setMarMulP(marMulP);
			stressTestSetup.setMarMulN(marMulN);
			stressTestSetup.setStDevMulP(stDevMulP);
			stressTestSetup.setStDevMulN(stDevMulN);
			stressTestSetup.setVolaCoeff(volaCoeff);
			stressTestSetup.setDisabVar(disabVar);
			stressTestSetup.setMethod(method);
			stressTestSetup.setIrCurveLst(irCurveLst);
			stressTestSetup.setCovMbr(covMbr);
			
			stressTestSetup.setUpdType("U");
			stressTestSetup.setUpdDate(GenericTools.systemDate());
			stressTestSetup.setUpdUsr(userString());
			stressTestSetup.setDivisCode(divisCode);
			stressTestSetup.setLstMntRep(lstMntRep);
			
			userLog.debug("Updated stress test setting - instrType: "+instrType);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stress test setting - instrType: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void update(StressTestSetup stressTestSetup) throws DataNotValidException {
		
		try {
			userLog.debug("Updated stress test setting - instrType: "+stressTestSetup.getInstrType());
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error updating stress test setting - instrType: "+stressTestSetup.getInstrType()+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(String instrType) throws DataNotValidException {
		try {
			StressTestSetup stressTestSetup = this.findByPrimaryKey(instrType);
			em.remove(stressTestSetup);
			userLog.debug("Stress test setting removed - divisCode: "+instrType);
    	} catch (Exception e) {
    		DataNotValidException exc = new DataNotValidException("Error removing stress test setting - divisCode: "+instrType+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	
	public void remove(StressTestSetup stressTestSetup) throws DataNotValidException {
		this.remove(stressTestSetup.getInstrType());
	}

}
