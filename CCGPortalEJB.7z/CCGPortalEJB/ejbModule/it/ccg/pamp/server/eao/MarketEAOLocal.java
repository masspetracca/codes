package it.ccg.pamp.server.eao;
import java.util.List;

import it.ccg.pamp.server.entities.Market;
import it.ccg.pamp.server.exceptions.DataNotValidException;

import javax.ejb.Local;

@Local
public interface MarketEAOLocal {

	public List<Market> fetch() throws DataNotValidException;
	
	public Market findByPrimaryKey(String marketCode) throws DataNotValidException;
	
	public Market findLastMarket() throws DataNotValidException;
	
	public void add(String marketCode, String marketDesc, int index, String marketGrp) throws DataNotValidException;
	
	public void store(Market market) throws DataNotValidException;
	
	public void update(String marketCode, String marketDesc, int index, String marketGrp) throws DataNotValidException;
	
	public void update(Market mkt) throws DataNotValidException;
	
	public void remove(Market mkt) throws DataNotValidException;
	
}
