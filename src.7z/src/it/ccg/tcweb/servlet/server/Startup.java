package it.ccg.tcweb.servlet.server;

import it.ccg.tcejb.server.logengine.Log4jSetup;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.security.SessionManagerLocal;
import it.ccg.tcejb.server.system.LocalBeanLookup;
import it.ccg.tcejb.server.system.SystemProperties;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class Startup
 */
@WebServlet(loadOnStartup=1, urlPatterns={"/Startup"} )
public class Startup extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger;
	
	private SessionManagerLocal sessionManagerLocal;  
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Startup() {
    	super();
    	
    	try {
    		System.out.println("Loading TerrorismControl system environment..");
    		
    		// Load log4j properties
			Log4jSetup.loadLog4JProperties();
			logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
			
			// Load system properties
    		SystemProperties.loadSystemProperties();
			// Init session manager
    		this.sessionManagerLocal = (SessionManagerLocal)LocalBeanLookup.lookup(SessionManagerLocal.class.getCanonicalName());
			this.sessionManagerLocal.init();
			
			
			logger.debug(new StandardLogMessage("TerrorismControl system environment successfully loaded"));
    	}
    	catch(Exception e) {
    		System.out.println("Errore during loading TerrorismControl system environment.. "+e.getMessage());
    		e.printStackTrace();
		}
    }
}
