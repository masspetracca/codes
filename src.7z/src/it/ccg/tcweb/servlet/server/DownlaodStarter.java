package it.ccg.tcweb.servlet.server;

import it.ccg.tc.server.bean.DownloadManagerLocal;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.google.gwt.dev.shell.remoteui.RemoteMessageProto.Message.Response;

/**
 * Servlet implementation class DownlaodStarter
 */
@WebServlet("/DownlaodStarter")
public class DownlaodStarter extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger log = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	@EJB
	public DownloadManagerLocal dManager;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DownlaodStarter() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug(new StandardLogMessage("in DownlaodStarter.doPost")); 
		String src = request.getParameter("src");
		if (src.equalsIgnoreCase("EU")){
			dManager.downloadEUList();
		}else if (src.equalsIgnoreCase("UN")){
			dManager.downloadUNList();
		}else if (src.equalsIgnoreCase("OFAC")){
			dManager.downloadOFACList();
		}else{
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST, "src non valido");
		}
		
		log.debug(new StandardLogMessage("done"));
	}

}
