package com.talend.csv;
 /*
 *
 * Decompiled with CFR 0_102.
 */


import java.io.Closeable;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.List;

public class CSVWriter
implements Closeable {
    public static final int INITIAL_STRING_SIZE = 128;
    private Writer rawWriter;
    private PrintWriter pw;
    private char separator = 44;
    private char quotechar = 34;
    private char escapechar = 34;
    private String lineEnd;
    private QuoteStatus quotestatus = QuoteStatus.AUTO;

    public CSVWriter(Writer writer) {
        this.rawWriter = writer;
        this.pw = new PrintWriter(writer);
    }

    public void writeAll(List<String[]> allLines) {
        for (String[] line : allLines) {
            this.writeNext(line);
        }
    }

    public CSVWriter setLineEnd(String lineEnd) {
        this.lineEnd = lineEnd;
        return this;
    }

    public CSVWriter setSeparator(char separator) {
        this.separator = separator;
        return this;
    }

    public CSVWriter setEscapeChar(char escapechar) {
        this.escapechar = escapechar;
        if (this.escapechar == '\u0000') {
            throw new RuntimeException("unvalid escape char");
        }
        return this;
    }

    public CSVWriter setQuoteChar(char quotechar) {
        this.quotechar = quotechar;
        if (this.quotechar == '\u0000') {
            throw new RuntimeException("unvalid quote char");
        }
        return this;
    }

    public CSVWriter setQuoteStatus(QuoteStatus quotestatus) {
        this.quotestatus = quotestatus;
        return this;
    }

    public void writeNext(String[] nextLine) {
        if (nextLine == null) {
            return;
        }
        StringBuilder sb = new StringBuilder(128);
        for (int i = 0; i < nextLine.length; ++i) {
            StringBuilder escapeResult;
            String nextElement;
            if (i != 0) {
                sb.append(this.separator);
            }
            if ((nextElement = nextLine[i]) == null) {
                nextElement = "";
            }
            boolean quote = false;
            if (this.quotestatus == QuoteStatus.AUTO) {
                quote = this.needQuote(nextElement, i);
            } else if (this.quotestatus == QuoteStatus.FORCE) {
                quote = true;
            }
            if (quote) {
                sb.append(this.quotechar);
            }
            if ((escapeResult = this.escape(nextElement, quote)) != null) {
                sb.append(escapeResult);
            } else {
                sb.append(nextElement);
            }
            if (!quote) continue;
            sb.append(this.quotechar);
        }
        if (this.lineEnd != null) {
            sb.append(this.lineEnd);
            this.pw.write(sb.toString());
        } else {
            this.pw.println(sb.toString());
        }
    }

    public void writeNextEnhance(String[] nextLine, String str4Nil) {
        if (nextLine == null) {
            return;
        }
        if (str4Nil == null) {
            this.writeNext(nextLine);
            return;
        }
        StringBuilder sb = new StringBuilder(128);
        for (int i = 0; i < nextLine.length; ++i) {
            StringBuilder escapeResult;
            String nextElement;
            boolean isNil = false;
            if (i != 0) {
                sb.append(this.separator);
            }
            if ((nextElement = nextLine[i]) == null) {
                nextElement = str4Nil;
                isNil = true;
            }
            boolean quote = false;
            if (this.quotestatus == QuoteStatus.AUTO) {
                quote = this.needQuote(nextElement, i);
            } else if (this.quotestatus == QuoteStatus.FORCE) {
                quote = true;
            }
            quote = quote && !isNil;
            if (quote) {
                sb.append(this.quotechar);
            }
            if ((escapeResult = this.escape(nextElement, quote)) != null) {
                sb.append(escapeResult);
            } else {
                sb.append(nextElement);
            }
            if (!quote) continue;
            sb.append(this.quotechar);
        }
        if (this.lineEnd != null) {
            sb.append(this.lineEnd);
            this.pw.write(sb.toString());
        } else {
            this.pw.println(sb.toString());
        }
    }

    private boolean needQuote(String field, int fieldIndex) {
        boolean need;
        boolean bl = need = field.indexOf(this.quotechar) > -1 || field.indexOf(this.separator) > -1 || this.lineEnd == null && (field.indexOf(10) > -1 || field.indexOf(13) > -1) || this.lineEnd != null && field.indexOf(this.lineEnd) > -1 || fieldIndex == 0 && field.length() == 0;
        if (!(need || field.length() <= 0)) {
            char last;
            char first = field.charAt(0);
            if (first == ' ' || first == '\t') {
                need = true;
            }
            if (!(need || field.length() <= 1 || (last = field.charAt(field.length() - 1)) != ' ' && last != '\t')) {
                need = true;
            }
        }
        return need;
    }

    private StringBuilder escape(String field, boolean quote) {
        if (quote) {
            return this.processLine(field);
        }
        if (this.escapechar != this.quotechar) {
            return this.processLine2(field);
        }
        return null;
    }

    protected StringBuilder processLine(String nextElement) {
        StringBuilder sb = new StringBuilder(128);
        for (int j = 0; j < nextElement.length(); ++j) {
            char nextChar = nextElement.charAt(j);
            if (nextChar == this.quotechar) {
                sb.append(this.escapechar).append(nextChar);
                continue;
            }
            if (nextChar == this.escapechar) {
                sb.append(this.escapechar).append(nextChar);
                continue;
            }
            sb.append(nextChar);
        }
        return sb;
    }

    protected StringBuilder processLine2(String nextElement) {
        StringBuilder sb = new StringBuilder(128);
        for (int j = 0; j < nextElement.length(); ++j) {
            char nextChar = nextElement.charAt(j);
            if (nextChar == this.escapechar) {
                sb.append(this.escapechar).append(nextChar);
                continue;
            }
            if (nextChar == this.separator) {
                sb.append(this.escapechar).append(nextChar);
                continue;
            }
            if (this.lineEnd == null && (nextChar == '\r' || nextChar == '\n')) {
                sb.append(this.escapechar).append(nextChar);
                continue;
            }
            if (this.lineEnd != null && this.lineEnd.indexOf(nextChar) > -1) {
                sb.append(this.escapechar).append(nextChar);
                continue;
            }
            sb.append(nextChar);
        }
        return sb;
    }

    public void flush() throws IOException {
        this.pw.flush();
    }

    @Override
    public void close() throws IOException {
        this.flush();
        this.pw.close();
        this.rawWriter.close();
    }

    public boolean checkError() {
        return this.pw.checkError();
    }

    public static enum QuoteStatus {
        FORCE,
        AUTO,
        NO;
        

        private QuoteStatus() {
        }
    }
}
