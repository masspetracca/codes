package local_project.tfileoutputdelimitedcsv_0_1;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javax.sql.DataSource;
import routines.TalendString;
import routines.system.IPersistableRow;
import routines.system.ParserUtils;
import routines.system.ResumeUtil;
import routines.system.TDieException;
import routines.system.TalendDataSource;
import routines.system.api.TalendJob;

public class tFileOutputDelimitedCSV
implements TalendJob {
    public final Object obj = new Object();
    private Object valueObject = null;
    private static final String defaultCharset = Charset.defaultCharset().name();
    private static final String utf8Charset = "UTF-8";
    private Properties defaultProps = new Properties();
    private ContextProperties context;
    private final String jobVersion = "0.1";
    private final String jobName = "tFileOutputDelimitedCSV";
    private final String projectName = "LOCAL_PROJECT";
    public Integer errorCode;
    private String currentComponent;
    private final Map<String, Object> globalMap;
    private static final Map<String, Object> junitGlobalMap = new HashMap<String, Object>();
    private final Map<String, Long> start_Hash;
    private final Map<String, Long> end_Hash;
    private final Map<String, Boolean> ok_Hash;
    public final List<String[]> globalBuffer;
    public boolean isExportedAsOSGI;
    private static final String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
    private final ByteArrayOutputStream baos;
    private final PrintStream errorMessagePS;
    private Exception exception;
    public String resuming_logs_dir_path;
    public String resuming_checkpoint_path;
    public String parent_part_launcher;
    private String resumeEntryMethodName;
    private boolean globalResumeTicket;
    public boolean watch;
    public Integer portStats;
    public int portTraces;
    public String clientHost;
    public String defaultClientHost;
    public String contextStr;
    public boolean isDefaultContext;
    public String pid;
    public String rootPid;
    public String fatherPid;
    public String fatherNode;
    public long startTime;
    public boolean isChildJob;
    public String log4jLevel;
    private boolean execStat;
    private ThreadLocal<Map<String, String>> threadLocal;
    private Properties context_param;
    public Map<String, Object> parentContextMap;
    public String status;
    private final String[][] escapeChars;
    ResumeUtil resumeUtil;

    public tFileOutputDelimitedCSV() {
        this.context = new ContextProperties(this);
        this.jobVersion = "0.1";
        this.jobName = "tFileOutputDelimitedCSV";
        this.projectName = "LOCAL_PROJECT";
        this.errorCode = null;
        this.currentComponent = "";
        this.globalMap = new HashMap<String, Object>();
        this.start_Hash = new HashMap<String, Long>();
        this.end_Hash = new HashMap<String, Long>();
        this.ok_Hash = new HashMap<String, Boolean>();
        this.globalBuffer = new ArrayList<String[]>();
        this.isExportedAsOSGI = true;
        this.baos = new ByteArrayOutputStream();
        this.errorMessagePS = new PrintStream(new BufferedOutputStream(this.baos));
        this.resuming_logs_dir_path = null;
        this.resuming_checkpoint_path = null;
        this.parent_part_launcher = null;
        this.resumeEntryMethodName = null;
        this.globalResumeTicket = false;
        this.watch = false;
        this.portStats = null;
        this.portTraces = 4334;
        this.defaultClientHost = "localhost";
        this.contextStr = "demo";
        this.isDefaultContext = true;
        this.pid = "0";
        this.rootPid = null;
        this.fatherPid = null;
        this.fatherNode = null;
        this.startTime = 0;
        this.isChildJob = false;
        this.log4jLevel = "";
        this.execStat = true;
        this.threadLocal = new ThreadLocal<Map<String, String>>(){

            @Override
            protected Map<String, String> initialValue() {
                HashMap<String, String> threadRunResultMap = new HashMap<String, String>();
                threadRunResultMap.put("errorCode", null);
                threadRunResultMap.put("status", "");
                return threadRunResultMap;
            }
        };
        this.context_param = new Properties();
        this.parentContextMap = new HashMap<String, Object>();
        this.status = "";
        this.escapeChars = new String[][]{{"\\\\", "\\"}, {"\\n", "\n"}, {"\\'", "'"}, {"\\r", "\r"}, {"\\f", "\f"}, {"\\b", "\b"}, {"\\t", "\t"}};
        this.resumeUtil = null;
    }

    public Object getValueObject() {
        return this.valueObject;
    }

    public void setValueObject(Object valueObject) {
        this.valueObject = valueObject;
    }

    public ContextProperties getContext() {
        return this.context;
    }

    public void setDataSources(Map<String, DataSource> dataSources) {
        HashMap<String, TalendDataSource> talendDataSources = new HashMap<String, TalendDataSource>();
        for (Map.Entry<String, DataSource> dataSourceEntry : dataSources.entrySet()) {
            talendDataSources.put(dataSourceEntry.getKey(), new TalendDataSource(dataSourceEntry.getValue()));
        }
        this.globalMap.put("KEY_DB_DATASOURCES", talendDataSources);
    }

    public String getExceptionStackTrace() {
        if ("failure".equals(this.getStatus())) {
            this.errorMessagePS.flush();
            return this.baos.toString();
        }
        return null;
    }

    public Exception getException() {
        if ("failure".equals(this.getStatus())) {
            return this.exception;
        }
        return null;
    }

    public void tRowGenerator_1_error(Exception exception, String errorComponent, Map<String, Object> globalMap) throws TalendException {
        this.end_Hash.put(errorComponent, System.currentTimeMillis());
        this.status = "failure";
        this.tRowGenerator_1_onSubJobError(exception, errorComponent, globalMap);
    }

    public void tLogRow_1_error(Exception exception, String errorComponent, Map<String, Object> globalMap) throws TalendException {
        this.end_Hash.put(errorComponent, System.currentTimeMillis());
        this.status = "failure";
        this.tRowGenerator_1_onSubJobError(exception, errorComponent, globalMap);
    }

    public void tFileOutputDelimited_1_error(Exception exception, String errorComponent, Map<String, Object> globalMap) throws TalendException {
        this.end_Hash.put(errorComponent, System.currentTimeMillis());
        this.status = "failure";
        this.tRowGenerator_1_onSubJobError(exception, errorComponent, globalMap);
    }

    public void tRowGenerator_1_onSubJobError(Exception exception, String errorComponent, Map<String, Object> globalMap) throws TalendException {
        this.resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", String.valueOf(Thread.currentThread().getId()), "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace((Exception)exception), "");
    }

    /*
     * Exception decompiling
     */
    public void tRowGenerator_1Process(Map<String, Object> globalMap) throws TalendException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.NullPointerException
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03Blocks$Block3.getLastUnconditionalBackjumpToHere(Op03Blocks.java:1107)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03Blocks.detectMoves(Op03Blocks.java:404)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03Blocks.topologicalSort(Op03Blocks.java:877)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:515)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:214)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:159)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:353)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:731)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:663)
        // org.benf.cfr.reader.Main.doJar(Main.java:126)
        // org.benf.cfr.reader.Main.main(Main.java:178)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void main(String[] args) {
        tFileOutputDelimitedCSV tFileOutputDelimitedCSVClass = new tFileOutputDelimitedCSV();
        int exitCode = tFileOutputDelimitedCSVClass.runJobInTOS(args);
        System.exit(exitCode);
    }

    public String[][] runJob(String[] args) {
        int exitCode = this.runJobInTOS(args);
        String[][] bufferValue = new String[][]{{Integer.toString(exitCode)}};
        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
        boolean hastBufferOutput = false;
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
        this.status = "";
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
                continue;
            }
            if (lastStr.equals("")) {
                this.evalParam(arg);
                continue;
            }
            this.evalParam(String.valueOf(lastStr) + " " + arg);
            lastStr = "";
        }
        if (this.clientHost == null) {
            this.clientHost = this.defaultClientHost;
        }
        if (this.pid == null || "0".equals(this.pid)) {
            this.pid = TalendString.getAsciiRandomString((int)6);
        }
        if (this.rootPid == null) {
            this.rootPid = this.pid;
        }
        if (this.fatherPid == null) {
            this.fatherPid = this.pid;
        } else {
            this.isChildJob = true;
        }
        try {
            InputStream inContext = tFileOutputDelimitedCSV.class.getClassLoader().getResourceAsStream("local_project/tfileoutputdelimitedcsv_0_1/contexts/" + this.contextStr + ".properties");
            if (!(this.isDefaultContext && inContext == null)) {
                if (inContext != null) {
                    this.defaultProps.load(inContext);
                    inContext.close();
                    this.context = new ContextProperties(this, this.defaultProps);
                } else {
                    System.err.println("Could not find the context " + this.contextStr);
                }
            }
            if (!this.context_param.isEmpty()) {
                this.context.putAll(this.context_param);
            }
            try {
                this.context.sampleInt = ParserUtils.parseTo_Integer((String)this.context.getProperty("sampleInt"));
            }
            catch (NumberFormatException e) {
                this.context.sampleInt = null;
            }
            this.context.root = this.context.getProperty("root");
        }
        catch (IOException ie) {
            System.err.println("Could not load context " + this.contextStr);
            ie.printStackTrace();
        }
        if (!(this.parentContextMap == null || this.parentContextMap.isEmpty())) {
            if (this.parentContextMap.containsKey("sampleInt")) {
                this.context.sampleInt = (Integer)this.parentContextMap.get("sampleInt");
            }
            if (this.parentContextMap.containsKey("root")) {
                this.context.root = (String)this.parentContextMap.get("root");
            }
        }
        this.resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName((String)this.resuming_checkpoint_path);
        this.resumeUtil = new ResumeUtil(this.resuming_logs_dir_path, this.isChildJob, this.rootPid);
        this.resumeUtil.initCommonInfo(this.pid, this.rootPid, this.fatherPid, "LOCAL_PROJECT", "tFileOutputDelimitedCSV", this.contextStr, "0.1");
        ArrayList parametersToEncrypt = new ArrayList();
        this.resumeUtil.addLog("JOB_STARTED", "JOB:tFileOutputDelimitedCSV", this.parent_part_launcher, String.valueOf(Thread.currentThread().getId()), "", "", "", "", ResumeUtil.convertToJsonText((Object)this.context, parametersToEncrypt));
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        this.globalMap.put("concurrentHashMap", concurrentHashMap);
        long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        long endUsedMemory = 0;
        long end = 0;
        this.startTime = System.currentTimeMillis();
        this.globalResumeTicket = true;
        this.globalResumeTicket = false;
        try {
            this.errorCode = null;
            this.tRowGenerator_1Process(this.globalMap);
            if (!"failure".equals(this.status)) {
                this.status = "end";
            }
        }
        catch (TalendException e_tRowGenerator_1) {
            this.globalMap.put("tRowGenerator_1_SUBPROCESS_STATE", -1);
            e_tRowGenerator_1.printStackTrace();
        }
        this.globalResumeTicket = true;
        end = System.currentTimeMillis();
        if (this.watch) {
            System.out.println(String.valueOf(end - this.startTime) + " milliseconds");
        }
        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        int returnCode = 0;
        returnCode = this.errorCode == null ? (this.status != null && this.status.equals("failure") ? 1 : 0) : this.errorCode;
        this.resumeUtil.addLog("JOB_ENDED", "JOB:tFileOutputDelimitedCSV", this.parent_part_launcher, String.valueOf(Thread.currentThread().getId()), "", "" + returnCode, "", "", "");
        return returnCode;
    }

    public void destroy() {
    }

    private Map<String, Object> getSharedConnections4REST() {
        HashMap<String, Object> connections = new HashMap<String, Object>();
        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            this.resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            this.resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            this.parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            this.watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (!(portStatsStr == null || portStatsStr.equals("null"))) {
                this.portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            this.portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            this.clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            this.contextStr = arg.substring(10);
            this.isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            this.fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            this.rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            this.fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            this.pid = arg.substring(6);
        } else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf(61)) > -1) {
                if (this.fatherPid == null) {
                    this.context_param.put(keyValue.substring(0, index), this.replaceEscapeChars(keyValue.substring(index + 1)));
                } else {
                    this.context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            this.log4jLevel = arg.substring(13);
        }
    }

    private String replaceEscapeChars(String keyValue) {
        if (keyValue == null || "".equals(keyValue.trim())) {
            return keyValue;
        }
        StringBuilder result = new StringBuilder();
        int currIndex = 0;
        while (currIndex < keyValue.length()) {
            int index = -1;
            for (String[] strArray : this.escapeChars) {
                index = keyValue.indexOf(strArray[0], currIndex);
                if (index < 0) continue;
                result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace((CharSequence)strArray[0], (CharSequence)strArray[1]));
                currIndex = index + strArray[0].length();
                break;
            }
            if (index >= 0) continue;
            result.append(keyValue.substring(currIndex));
            currIndex+=keyValue.length();
        }
        return result.toString();
    }

    public Integer getErrorCode() {
        return this.errorCode;
    }

    public String getStatus() {
        return this.status;
    }

    static /* synthetic */ void access$1(tFileOutputDelimitedCSV tFileOutputDelimitedCSV, Exception exception) {
        tFileOutputDelimitedCSV.exception = exception;
    }

    public class ContextProperties
    extends Properties {
        private static final long serialVersionUID = 1;
        public Integer sampleInt;
        public String root;
        final /* synthetic */ tFileOutputDelimitedCSV this$0;

        public ContextProperties(tFileOutputDelimitedCSV tFileOutputDelimitedCSV, Properties properties) {
            this.this$0 = tFileOutputDelimitedCSV;
            super(properties);
        }

        public ContextProperties(tFileOutputDelimitedCSV tFileOutputDelimitedCSV) {
            this.this$0 = tFileOutputDelimitedCSV;
        }

        public void synchronizeContext() {
            if (this.sampleInt != null) {
                this.setProperty("sampleInt", this.sampleInt.toString());
            }
            if (this.root != null) {
                this.setProperty("root", this.root.toString());
            }
        }

        public Integer getSampleInt() {
            return this.sampleInt;
        }

        public String getRoot() {
            return this.root;
        }
    }

    private class TalendException
    extends Exception {
        private static final long serialVersionUID = 1;
        private Map<String, Object> globalMap;
        private Exception e;
        private String currentComponent;
        private String virtualComponentName;
        final /* synthetic */ tFileOutputDelimitedCSV this$0;

        public void setVirtualComponentName(String virtualComponentName) {
            this.virtualComponentName = virtualComponentName;
        }

        private TalendException(tFileOutputDelimitedCSV tFileOutputDelimitedCSV, Exception e, String errorComponent, Map<String, Object> globalMap) {
            this.this$0 = tFileOutputDelimitedCSV;
            this.globalMap = null;
            this.e = null;
            this.currentComponent = null;
            this.virtualComponentName = null;
            this.currentComponent = errorComponent;
            this.globalMap = globalMap;
            this.e = e;
        }

        public Exception getException() {
            return this.e;
        }

        public String getCurrentComponent() {
            return this.currentComponent;
        }

        public String getExceptionCauseMessage(Exception e) {
            String message = null;
            int i = 10;
            for (Throwable cause = e; cause != null && i-- > 0; cause = cause.getCause()) {
                message = cause.getMessage();
                if (message != null) break;
            }
            if (message == null) {
                message = e.getClass().getName();
            }
            return message;
        }

        @Override
        public void printStackTrace() {
            if (!(this.e instanceof TalendException || this.e instanceof TDieException)) {
                if (this.virtualComponentName != null && this.currentComponent.indexOf(String.valueOf(this.virtualComponentName) + "_") == 0) {
                    this.globalMap.put(String.valueOf(this.virtualComponentName) + "_ERROR_MESSAGE", this.getExceptionCauseMessage(this.e));
                }
                this.globalMap.put(String.valueOf(this.currentComponent) + "_ERROR_MESSAGE", this.getExceptionCauseMessage(this.e));
                System.err.println("Exception in component " + this.currentComponent);
            }
            if (!(this.e instanceof TDieException)) {
                if (this.e instanceof TalendException) {
                    this.e.printStackTrace();
                } else {
                    this.e.printStackTrace();
                    this.e.printStackTrace(this.this$0.errorMessagePS);
                    tFileOutputDelimitedCSV.access$1(this.this$0, this.e);
                }
            }
            if (!(this.e instanceof TalendException)) {
                try {
                    for (Method m : this.getClass().getEnclosingClass().getMethods()) {
                        if (m.getName().compareTo(String.valueOf(this.currentComponent) + "_error") != 0) continue;
                        m.invoke(this.this$0, this.e, this.currentComponent, this.globalMap);
                        break;
                    }
                    this.e instanceof TDieException;
                }
                catch (Exception e) {
                    this.e.printStackTrace();
                }
            }
        }

        /* synthetic */ TalendException(tFileOutputDelimitedCSV tFileOutputDelimitedCSV, Exception exception, String string, Map map, TalendException talendException) {
            TalendException talendException2;
            talendException2(tFileOutputDelimitedCSV, exception, string, map);
        }
    }

    public static class row1Struct
    implements IPersistableRow<row1Struct> {
        static final byte[] commonByteArrayLock_LOCAL_PROJECT_tFileOutputDelimitedCSV = new byte[0];
        static byte[] commonByteArray_LOCAL_PROJECT_tFileOutputDelimitedCSV = new byte[0];
        public int number;
        public String txt;
        public String date;
        public boolean flag;

        public int getNumber() {
            return this.number;
        }

        public String getTxt() {
            return this.txt;
        }

        public String getDate() {
            return this.date;
        }

        public boolean getFlag() {
            return this.flag;
        }

        private String readString(ObjectInputStream dis) throws IOException {
            String strReturn = null;
            int length = 0;
            length = dis.readInt();
            if (length == -1) {
                strReturn = null;
            } else {
                if (length > commonByteArray_LOCAL_PROJECT_tFileOutputDelimitedCSV.length) {
                    commonByteArray_LOCAL_PROJECT_tFileOutputDelimitedCSV = length < 1024 && commonByteArray_LOCAL_PROJECT_tFileOutputDelimitedCSV.length == 0 ? new byte[1024] : new byte[2 * length];
                }
                dis.readFully(commonByteArray_LOCAL_PROJECT_tFileOutputDelimitedCSV, 0, length);
                strReturn = new String(commonByteArray_LOCAL_PROJECT_tFileOutputDelimitedCSV, 0, length, "UTF-8");
            }
            return strReturn;
        }

        private void writeString(String str, ObjectOutputStream dos) throws IOException {
            if (str == null) {
                dos.writeInt(-1);
            } else {
                byte[] byteArray = str.getBytes("UTF-8");
                dos.writeInt(byteArray.length);
                dos.write(byteArray);
            }
        }

        public void readData(ObjectInputStream dis) {
            byte[] arrby = commonByteArrayLock_LOCAL_PROJECT_tFileOutputDelimitedCSV;
            synchronized (arrby) {
                try {
                    boolean length = false;
                    this.number = dis.readInt();
                    this.txt = this.readString(dis);
                    this.date = this.readString(dis);
                    this.flag = dis.readBoolean();
                }
                catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }

        public void writeData(ObjectOutputStream dos) {
            try {
                dos.writeInt(this.number);
                this.writeString(this.txt, dos);
                this.writeString(this.date, dos);
                dos.writeBoolean(this.flag);
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(super.toString());
            sb.append("[");
            sb.append("number=" + String.valueOf(this.number));
            sb.append(",txt=" + this.txt);
            sb.append(",date=" + this.date);
            sb.append(",flag=" + String.valueOf(this.flag));
            sb.append("]");
            return sb.toString();
        }

        public int compareTo(row1Struct other) {
            int returnValue = -1;
            return returnValue;
        }

        private int checkNullsAndCompare(Object object1, Object object2) {
            int returnValue = 0;
            returnValue = object1 instanceof Comparable && object2 instanceof Comparable ? ((Comparable)object1).compareTo(object2) : (object1 != null && object2 != null ? this.compareStrings(object1.toString(), object2.toString()) : (object1 == null && object2 != null ? 1 : (object1 != null && object2 == null ? -1 : 0)));
            return returnValue;
        }

        private int compareStrings(String string1, String string2) {
            return string1.compareTo(string2);
        }
    }

    public static class row2Struct
    implements IPersistableRow<row2Struct> {
        static final byte[] commonByteArrayLock_LOCAL_PROJECT_tFileOutputDelimitedCSV = new byte[0];
        static byte[] commonByteArray_LOCAL_PROJECT_tFileOutputDelimitedCSV = new byte[0];
        public int number;
        public String txt;
        public String date;
        public boolean flag;

        public int getNumber() {
            return this.number;
        }

        public String getTxt() {
            return this.txt;
        }

        public String getDate() {
            return this.date;
        }

        public boolean getFlag() {
            return this.flag;
        }

        private String readString(ObjectInputStream dis) throws IOException {
            String strReturn = null;
            int length = 0;
            length = dis.readInt();
            if (length == -1) {
                strReturn = null;
            } else {
                if (length > commonByteArray_LOCAL_PROJECT_tFileOutputDelimitedCSV.length) {
                    commonByteArray_LOCAL_PROJECT_tFileOutputDelimitedCSV = length < 1024 && commonByteArray_LOCAL_PROJECT_tFileOutputDelimitedCSV.length == 0 ? new byte[1024] : new byte[2 * length];
                }
                dis.readFully(commonByteArray_LOCAL_PROJECT_tFileOutputDelimitedCSV, 0, length);
                strReturn = new String(commonByteArray_LOCAL_PROJECT_tFileOutputDelimitedCSV, 0, length, "UTF-8");
            }
            return strReturn;
        }

        private void writeString(String str, ObjectOutputStream dos) throws IOException {
            if (str == null) {
                dos.writeInt(-1);
            } else {
                byte[] byteArray = str.getBytes("UTF-8");
                dos.writeInt(byteArray.length);
                dos.write(byteArray);
            }
        }

        public void readData(ObjectInputStream dis) {
            byte[] arrby = commonByteArrayLock_LOCAL_PROJECT_tFileOutputDelimitedCSV;
            synchronized (arrby) {
                try {
                    boolean length = false;
                    this.number = dis.readInt();
                    this.txt = this.readString(dis);
                    this.date = this.readString(dis);
                    this.flag = dis.readBoolean();
                }
                catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }

        public void writeData(ObjectOutputStream dos) {
            try {
                dos.writeInt(this.number);
                this.writeString(this.txt, dos);
                this.writeString(this.date, dos);
                dos.writeBoolean(this.flag);
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(super.toString());
            sb.append("[");
            sb.append("number=" + String.valueOf(this.number));
            sb.append(",txt=" + this.txt);
            sb.append(",date=" + this.date);
            sb.append(",flag=" + String.valueOf(this.flag));
            sb.append("]");
            return sb.toString();
        }

        public int compareTo(row2Struct other) {
            int returnValue = -1;
            return returnValue;
        }

        private int checkNullsAndCompare(Object object1, Object object2) {
            int returnValue = 0;
            returnValue = object1 instanceof Comparable && object2 instanceof Comparable ? ((Comparable)object1).compareTo(object2) : (object1 != null && object2 != null ? this.compareStrings(object1.toString(), object2.toString()) : (object1 == null && object2 != null ? 1 : (object1 != null && object2 == null ? -1 : 0)));
            return returnValue;
        }

        private int compareStrings(String string1, String string2) {
            return string1.compareTo(string2);
        }
    }

}
