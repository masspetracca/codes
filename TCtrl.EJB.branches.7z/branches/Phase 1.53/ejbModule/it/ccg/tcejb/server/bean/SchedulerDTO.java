package it.ccg.tcejb.server.bean;

import it.ccg.tcejb.server.util.SchedulerType;

import java.io.Serializable;
import java.sql.Timestamp;

public class SchedulerDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8821453484519766972L;
	
	private String name;
	private int numberValue;
	private SchedulerType typeOfScheduler;
	private String stringValue; 
	
	private int companyId;
	private String methodName;
	private String parameterType;
	private Class<?> methodClass;
	private String description;
	private String updUser;
	private String updType;
	private Timestamp updDate;
	
	public SchedulerDTO(String name, int numberValue, SchedulerType typeOfScheduler, String stringValue, 
			int companyId, String parameterType, String methodName, Class<?> methodClass, String description, String updUser, String updType, Timestamp updDate) {
		this.name = name;
		this.numberValue = numberValue;
		this.stringValue = stringValue;
		this.typeOfScheduler = typeOfScheduler;
		
		this.parameterType = parameterType;
		this.companyId = companyId;
		this.methodName = methodName;
		this.methodClass = methodClass;
		this.description = description;
		this.updUser = updUser;
		this.updType = updType;
		this.updDate = updDate;
	}

	public SchedulerDTO() {
	}

	/**
	 * @return the numberValue
	 */
	public int getNumberValue() {
		return numberValue;
	}

	/**
	 * @param numberValue the numberValue to set
	 */
	public void setNumberValue(int numberValue) {
		this.numberValue = numberValue;
	}

	/**
	 * @return the typeOfScheduler
	 */
	public SchedulerType getTypeOfScheduler() {
		return typeOfScheduler;
	}

	/**
	 * @param typeOfScheduler the typeOfScheduler to set
	 */
	public void setTypeOfScheduler(SchedulerType typeOfScheduler) {
		this.typeOfScheduler = typeOfScheduler;
	}

	/**
	 * @return the stringValue
	 */
	public String getStringValue() {
		return stringValue;
	}

	/**
	 * @param stringValue the stringValue to set
	 */
	public void setStringValue(String stringValue) {
		this.stringValue = stringValue;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return the methodName
	 */
	public String getMethodName() {
		return methodName;
	}
	
	/**
	 * @param methodName the methodName to set
	 */
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	
	/**
	 * @return the methodClass
	 */
	public Class<?> getMethodClass() {
		return methodClass;
	}
	
	/**
	 * @param methodClass the methodClass to set
	 */
	public void setMethodClass(Class<?> methodClass) {
		this.methodClass = methodClass;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the companyId
	 */
	public int getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the parameterType
	 */
	public String getParameterType() {
		return parameterType;
	}

	/**
	 * @param parameterType the parameterType to set
	 */
	public void setParameterType(String parameterType) {
		this.parameterType = parameterType;
	}

	/**
	 * @return the udpUser
	 */
	public String getUpdUser() {
		return updUser;
	}

	/**
	 * @param udpUser the udpUser to set
	 */
	public void setUpdUser(String udpUser) {
		this.updUser = udpUser;
	}

	/**
	 * @return the updType
	 */
	public String getUpdType() {
		return updType;
	}

	/**
	 * @param updType the updType to set
	 */
	public void setUpdType(String updType) {
		this.updType = updType;
	}

	/**
	 * @return the udpDate
	 */
	public Timestamp getUpdDate() {
		return updDate;
	}

	/**
	 * @param udpDate the udpDate to set
	 */
	public void setUpdDate(Timestamp udpDate) {
		this.updDate = udpDate;
	}
	
}
