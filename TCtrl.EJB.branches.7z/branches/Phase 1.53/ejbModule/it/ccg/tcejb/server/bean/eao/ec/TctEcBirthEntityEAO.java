package it.ccg.tcejb.server.bean.eao.ec;

import it.ccg.tcejb.server.bean.entity.ec.TctEcBirthEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctEcBirthEntityEAO
 */
@Stateless
@LocalBean
public class TctEcBirthEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
    /**
     * Default constructor. 
     */
    public TctEcBirthEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctEcBirthEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctEcBirthEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcBirth identification data: EC Entity code = "+entity.getId().getEntityid() +" , birth id = "+entity.getId().getBirthId()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public void insertEntity(Set<TctEcBirthEntity> entities) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("insertEntity(Set<TctEcBirthEntity> entities)"));
	    	for (TctEcBirthEntity entity : entities){
	    		ejbLogger.debug(new StandardLogMessage("TctEcBirth identification data: EC Entity code = "+entity.getId().getEntityid() +" , birth id = "+entity.getId().getBirthId()));
		    	
		    	this.manager.persist(entity);
	    	}
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	this.manager.flush();
	    	
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
  	public void deleteEntity(TctEcBirthEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctEcBirthEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcBirthEntity identification data: EC Entity code = "+entity.getId().getEntityid() +" , birth id = "+entity.getId().getBirthId()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void deleteEveryEntity() throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteEcBirthEveryEntity");
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	this.manager.flush();
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctEcBirthEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctEcBirthEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcBirthEntity identification data: EC Entity code = "+entity.getId().getEntityid() +" , birth id = "+entity.getId().getBirthId()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	@SuppressWarnings("unchecked")
	public  List<TctEcBirthEntity> retrieveEntityBirthByEntId(int entityId) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<TctEcBirthEntity> retrieveEntityBirthByEntId(int entityId)"));
	    	ejbLogger.debug(new StandardLogMessage("ecEntityId "+entityId));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getEcBirthEntitiesById");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("entityId", entityId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	List<TctEcBirthEntity> ecBitEntities = (List<TctEcBirthEntity>) q.getResultList();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return ecBitEntities;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
}
