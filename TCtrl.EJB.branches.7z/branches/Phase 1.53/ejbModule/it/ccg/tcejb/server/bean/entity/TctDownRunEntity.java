package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the TCTDOWNRUN database table.
 * 
 */
@Entity
@Table(name="TCTDOWNRUN")
@NamedQueries({
	@NamedQuery(name="getDonwRunLatestID",   query="SELECT entity.id.downloadid " +
            "								          FROM TctDownRunEntity entity " +
            "								         WHERE entity.id.runid  = (SELECT MAX(entity2.id.runid)" +
            "																   FROM TctDownRunEntity entity2)"),
    @NamedQuery(name="getDonwloadIDbyRun",   query="SELECT entity.id.downloadid " +
            "								          FROM TctDownRunEntity entity " +
            "								         WHERE entity.id.runid  = :run")
	
})
public class TctDownRunEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TctDownRunEntityPK id;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(length=50)
	private String updUser;

	//bi-directional many-to-one association to TctDownRegEntity
    @ManyToOne
	@JoinColumn(name="DOWNLOADID", nullable=false, insertable=false, updatable=false)
	private TctDownRegEntity tctdownreg;

	//bi-directional many-to-one association to TctRunRegEntity
    @ManyToOne
	@JoinColumns({
		@JoinColumn(name="CMPNID", referencedColumnName="CMPNID", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="RUNID", referencedColumnName="RUNID", nullable=false, insertable=false, updatable=false)
		})
	private TctRunRegEntity tctrunreg;

    public TctDownRunEntity() {
    }

	public TctDownRunEntityPK getId() {
		return this.id;
	}

	public void setId(TctDownRunEntityPK id) {
		this.id = id;
	}
	
	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public TctDownRegEntity getTctdownreg() {
		return this.tctdownreg;
	}

	public void setTctdownreg(TctDownRegEntity tctdownreg) {
		this.tctdownreg = tctdownreg;
	}
	
	public TctRunRegEntity getTctrunreg() {
		return this.tctrunreg;
	}

	public void setTctrunreg(TctRunRegEntity tctrunreg) {
		this.tctrunreg = tctrunreg;
	}
	
}