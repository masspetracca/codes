package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctClientEntity;
import it.ccg.tcejb.server.bean.entity.TctClientHEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctClientHEntityEAO
 */
@Stateless
@LocalBean
public class TctClientHEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctClientHEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctClientHEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctClientHEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctClientHEntity identification data: run id = "+entity.getId().getRunid() +" , company id = "+entity.getId().getCpmnid()+" , client id = "+entity.getId().getClntid()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));	
    }
        
    public void insertEntity(List<TctClientHEntity> entities) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in insertEntity(List<TctClientHEntity> entities)"));
    	int idxToFlush = 0;
    	for (TctClientHEntity entity :entities){
    		ejbLogger.debug(new StandardLogMessage("TctClientHEntity identification data: run id = "+entity.getId().getRunid() +" , company id = "+entity.getId().getCpmnid()+" , client id = "+entity.getId().getClntid()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	idxToFlush++;
	    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
	    		ejbLogger.debug(new StandardLogMessage("insert"));
		    	this.manager.flush();
	    	}
    	}
    	ejbLogger.debug(new StandardLogMessage("last insert"));
    	this.manager.flush();
    }
    
  	public void deleteEntity(TctClientHEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctClientHEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctClientHEntity identification data: run id = "+entity.getId().getRunid() +" , company id = "+entity.getId().getCpmnid()+" , client id = "+entity.getId().getClntid()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctClientHEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctClientHEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctClientHEntity identification data: run id = "+entity.getId().getRunid() +" , company id = "+entity.getId().getCpmnid()+" , client id = "+entity.getId().getClntid()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("U");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	/*
  	 * SELECT entity " +
            "								           			FROM TctClientHEntity entity " +
            "								         			WHERE entity.id.cmpnId  = :cmpnId" +
            "													  AND entity.id.runid = :runid" +
            "													  AND entity.clntName = :clntName
  	 */
  	@SuppressWarnings("unchecked")
	public List<TctClientHEntity> retrieveClientsByRunIDAndClientName(int runId,TctClientEntity entity) throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in List<TctClientHEntity> retrieveClientsByrunID(int run)"));
    	ejbLogger.debug(new StandardLogMessage("Run id "+runId));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("retrieveClientByNameAndRunId");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("cmpnId", entity.getId().getCmpnId());
    	q.setParameter("runid", runId);
    	q.setParameter("clntName", entity.getClntName());
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
    	List<TctClientHEntity> clients = (List<TctClientHEntity>) q.getResultList();
		ejbLogger.debug(new StandardLogMessage("return"));
    	return clients;
  		
  	}
}
