package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTCLIENTH database table.
 * 
 */
@Embeddable
public class TctClientHEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int runid;

	@Column(unique=true, nullable=false)
	private int clntid;

	@Column(unique=true, nullable=false)
	private int cpmnid;

    public TctClientHEntityPK() {
    }
	public int getRunid() {
		return this.runid;
	}
	public void setRunid(int runid) {
		this.runid = runid;
	}
	public int getClntid() {
		return this.clntid;
	}
	public void setClntid(int clntid) {
		this.clntid = clntid;
	}
	public int getCpmnid() {
		return this.cpmnid;
	}
	public void setCpmnid(int cpmnid) {
		this.cpmnid = cpmnid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctClientHEntityPK)) {
			return false;
		}
		TctClientHEntityPK castOther = (TctClientHEntityPK)other;
		return 
			(this.runid == castOther.runid)
			&& (this.clntid == castOther.clntid)
			&& (this.cpmnid == castOther.cpmnid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.runid;
		hash = hash * prime + this.clntid;
		hash = hash * prime + this.cpmnid;
		
		return hash;
    }
}