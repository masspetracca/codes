package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctFalNegHEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctalNegHEntityEAO
 */
@Stateless
@LocalBean
public class TctFalNegHEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctFalNegHEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctFalNegHEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctFalNegHEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctFalNegHEntity identification data: client id = "+entity.getId().getClntid() +" , company id = "+entity.getId().getCompnid()+" , aggregated id= "+entity.getId().getAggrid()+" , run id= "+entity.getId().getRunid()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));	
    }
        
    public void insertEntity(List<TctFalNegHEntity> entities) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in insertEntity(List<TctFalNegHEntity> entities)"));
    	int idxToFlush = 0;
    	for (TctFalNegHEntity entity :entities){
    		ejbLogger.debug(new StandardLogMessage("TctFalNegHEntity identification data: client id = "+entity.getId().getClntid() +" , company id = "+entity.getId().getCompnid()+" , aggregated id= "+entity.getId().getAggrid()+" , run id= "+entity.getId().getRunid()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	idxToFlush++;
	    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
	    		ejbLogger.debug(new StandardLogMessage("insert"));
		    	this.manager.flush();
	    	}
    	}
    	ejbLogger.debug(new StandardLogMessage("last insert"));
    	this.manager.flush();
    }
    
  	public void deleteEntity(TctFalNegHEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctFalNegtEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctFalNegHEntity identification data: client id = "+entity.getId().getClntid() +" , company id = "+entity.getId().getCompnid()+" , aggregated id= "+entity.getId().getAggrid()+" , run id= "+entity.getId().getRunid()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctFalNegHEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctClientEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctFalNegHEntity identification data: client id = "+entity.getId().getClntid() +" , company id = "+entity.getId().getCompnid()+" , aggregated id= "+entity.getId().getAggrid()+" , run id= "+entity.getId().getRunid()));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("U");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
}
