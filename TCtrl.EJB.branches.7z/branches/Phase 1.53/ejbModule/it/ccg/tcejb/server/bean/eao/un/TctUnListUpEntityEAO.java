package it.ccg.tcejb.server.bean.eao.un;

import it.ccg.tcejb.server.bean.entity.un.TctUnLstUp;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctUnListUpEntityEAO
 */
@Stateless
@LocalBean
public class TctUnListUpEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	
	@Resource
	private SessionContext sessionContext;
	
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctUnListUpEntityEAO() {
        // TODO Auto-generated constructor stub
    }
    
    public void insertEntity(TctUnLstUp entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctUnLstUp entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnLstUp identification data:"+entity.getEntityid()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public void insertEntity(Set<TctUnLstUp> entities) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctUnLstUp entity)"));
	    	int idxToFlush = 0;
	    	for (TctUnLstUp entity : entities){
	    		ejbLogger.debug(new StandardLogMessage("TctUnLstUp identification data: "+entity.getEntityid()+" value "+entity.getValue()));
		    	
		    	this.manager.persist(entity);
		    	idxToFlush++;
		    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
		    		ejbLogger.debug(new StandardLogMessage("insert"));
			    	this.manager.flush();
		    	}
	    	}
	    	ejbLogger.debug(new StandardLogMessage("last insert"));
	    	this.manager.flush();
	    	
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
  	public void deleteEntity(TctUnLstUp entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctUnLstUp entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnLstUp identification data: "+entity.getEntityid() +" , upd id = "+entity.getLstDtUdpId()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void deleteEveryEntity() throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteUnLtUpEveryEntity");
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	this.manager.flush();
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctUnLstUp entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctUnLstUp entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnLstUp identification data: "+entity.getEntityid() +" , address id = "+entity.getLstDtUdpId()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	@SuppressWarnings("unchecked")
	public  List<TctUnLstUp> retrieveEntityLastListUpdByEntId(int entityId) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<TctUnLstUp> retrieveEntityLastListUpdByEntId(int entityId)"));
	    	ejbLogger.debug(new StandardLogMessage("ecEntityId "+entityId));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getUnLtUpEntitiesById");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("entityId", entityId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	List<TctUnLstUp> unUnLsupds = (List<TctUnLstUp>) q.getResultList();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return unUnLsupds;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}

}
