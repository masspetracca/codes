package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TCTAUDITH database table.
 * 
 */
@Entity
@Table(name="TCTAUDITH")
public class TctAuditHEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TctAuditHEntityPK id;

    @Lob()
	@Column(nullable=false)
	private byte[] audHBlob;

	@Column(length=30)
	private String desc;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=25)
	private String updUser;

    public TctAuditHEntity() {
    }

	public TctAuditHEntityPK getId() {
		return this.id;
	}

	public void setId(TctAuditHEntityPK id) {
		this.id = id;
	}
	
	public byte[] getAudHBlob() {
		return this.audHBlob;
	}

	public void setAudHBlob(byte[] audHBlob) {
		this.audHBlob = audHBlob;
	}

	public String getDesc() {
		return this.desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

}