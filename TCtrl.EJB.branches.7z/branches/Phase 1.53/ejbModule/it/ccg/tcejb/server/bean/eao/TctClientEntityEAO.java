package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctClientEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctClientEntityEAO
 */
@Stateless
@LocalBean
public class TctClientEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctClientEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctClientEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctClientEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctClientEntity identification data: client id = "+entity.getId().getClntId() +" , company id = "+entity.getId().getCmpnId()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));	
    }
        
    public void insertEntity(List<TctClientEntity> entities) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in insertEntity(List<TctClientEntity> entities)"));
    	int idxToFlush = 0;
    	for (TctClientEntity entity :entities){
    		ejbLogger.debug(new StandardLogMessage("TctClientEntity identification data: client id = "+entity.getId().getClntId() +" , company id = "+entity.getId().getCmpnId()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	
	    	this.manager.persist(entity);
	    	idxToFlush++;
	    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
	    		ejbLogger.debug(new StandardLogMessage("insert"));
		    	this.manager.flush();
	    	}
    	}
    	ejbLogger.debug(new StandardLogMessage("last insert"));
    	this.manager.flush();
    }
    
  	public void deleteEntity(TctClientEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctClientEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctClientEntity identification data: client id = "+entity.getId().getClntId() +" , company id = "+entity.getId().getCmpnId()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctClientEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctClientEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctClientEntity identification data: client id = "+entity.getId().getClntId() +" , company id = "+entity.getId().getCmpnId()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("U");
	    	entity.setUpdUser(sessionContext.getCallerPrincipal().getName());
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	@SuppressWarnings("unchecked")
	public List<TctClientEntity> retrieveClientsByCompanyID(int companyId) throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in List<TctClientEntity> retrieveRunByRunDate(TctClientEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("Company id "+companyId));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getClientsByCmpnId");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("cmpnId", companyId);
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
    	List<TctClientEntity> clients = (List<TctClientEntity>) q.getResultList();
		ejbLogger.debug(new StandardLogMessage("return"));
    	return clients;
  		
  	}
  	
  	@SuppressWarnings("unchecked")
	public List<TctClientEntity> retrieveAllClients() throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in List<TctClientEntity> retrieveAllClients()"));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getAllClients");
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
    	List<TctClientEntity> clients = (List<TctClientEntity>) q.getResultList();
		ejbLogger.debug(new StandardLogMessage("return"));
    	return clients;
  	}

  	
  	@SuppressWarnings("unchecked")
	public TctClientEntity retrieveClientsByClientIdAndCompanyId(int companyId,int clientId) throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in TctClientEntity retrieveClientsByClientIdAndCompanyId(int companyId,int clientId)"));
    	ejbLogger.debug(new StandardLogMessage("Company id "+companyId));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getClientsByCmpnIdAndClientId");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("cmpnId", companyId);
    	q.setParameter("clntId", clientId);
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
    	List<TctClientEntity> clients = (List<TctClientEntity>) q.getResultList();
    	TctClientEntity client=null;
    	if (clients.size()==1){
    		client = clients.get(0);
    	}else if(clients.size()>1){
    		throw new BackEndException("too many rows selected");
    	}
		ejbLogger.debug(new StandardLogMessage("return"));
    	return client;
  		
  	}
}
