package it.ccg.tcejb.server.util;

import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardCheckPointMessage;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

public class NameCleaner {
	private Logger calcLogger = Logger.getLogger(LoggerFactory.CALCULATION_LOGGER);
	
	public NameCleaner(){
		
	}
	
	@SuppressWarnings("rawtypes")
	public List<String> clean(List<String> entityNames) throws BackEndException{
		//calcLogger.debug(new StandardLogMessage("in List<String> clean(List<String> entityNames)"));
		//calcLogger.info(new StandardCheckPointMessage("Business names cleaning start"));
		List<String> result = new ArrayList<String>(entityNames.size());
		//calcLogger.debug(new StandardLogMessage("entyties analized "+entityNames.size()));
		
		Set keySet = SystemProperties.getBusinessNamesProperties().keySet();
		nextname: for (String name : entityNames){
			for (Object key: keySet){
				Pattern localPattern;
				
				localPattern = Pattern.compile(SystemProperties.getBusinessNamesProperty((String)key),Pattern.CASE_INSENSITIVE);
				
				Matcher m = localPattern.matcher(name);
				//System.out.println(Pattern.matches(this.businnesTypeProp.getProperty((String)key), name));
				if (m.find()){
					name=name.replaceAll(m.group(),"");
					name=name.replaceAll(",", "");
					name=name.replaceAll("''", " ");
					name=name.replaceAll("\"", "");
					name=name.replaceAll("- ", " ");
					name=name.replaceAll(" - ", " ");
					name=name.replaceAll("-", " ");
					name=name.replaceAll(":", "");
					name=name.replaceAll("/ ", "");
					name=name.replaceAll("/", " ");
					name=name.replaceAll("\\. ", " ");
					name=name.replaceAll("\\.", " ");
					result.add(name);
					continue nextname;
				}
			}
			name=name.replaceAll(",", "");
			name=name.replaceAll("''", " ");
			name=name.replaceAll("\"", "");
			name=name.replaceAll("- ", " ");
			name=name.replaceAll(" - ", " ");
			name=name.replaceAll("-", " ");
			name=name.replaceAll(":", "");
			name=name.replaceAll("/ ", "");
			name=name.replaceAll("/", " ");
			name=name.replaceAll("\\. ", " ");
			name=name.replaceAll("\\.", " ");
			result.add(name);
		}
		//calcLogger.info(new StandardCheckPointMessage("Business names cleaning completed"));
		return result;
	 }
	 
	 @SuppressWarnings("rawtypes")
	public String clean(String entityName) throws BackEndException{
		 //calcLogger.debug(new StandardLogMessage("in String clean(String entityName)"));
		 //calcLogger.debug(new StandardLogMessage("entity name "+entityName));
		 String result=entityName;
		 
		 Set keySet = SystemProperties.getBusinessNamesProperties().keySet();
		 for (Object key: keySet){
			 /*ejbLogger.debug(new StandardLogMessage("Key "+(String)key));
			 ejbLogger.debug(new StandardLogMessage("Property "+SystemProperties.getBusinessNamesProperty((String)key)));*/
			 Pattern localPattern = Pattern.compile(SystemProperties.getBusinessNamesProperty((String)key),Pattern.CASE_INSENSITIVE);
			 Matcher m = localPattern.matcher(entityName);
			 //System.out.println(Pattern.matches(this.businnesTypeProp.getProperty((String)key), name));
			 if (m.find()){
				 entityName=entityName.replaceAll(m.group(),"");
			 }
		 }
		 entityName=entityName.replaceAll(",", "");
		 entityName=entityName.replaceAll("''", " ");
		 entityName=entityName.replaceAll("\"", "");
		 entityName=entityName.replaceAll("- ", " ");
		 entityName=entityName.replaceAll(" - ", " ");
		 entityName=entityName.replaceAll("-", " ");
		 entityName=entityName.replaceAll(":", "");
		 entityName=entityName.replaceAll("/ ", "");
		 entityName=entityName.replaceAll("/", " ");
		 entityName=entityName.replaceAll("\\. ", " ");
		 entityName=entityName.replaceAll("\\.", " ");
		 result = entityName;
		 //calcLogger.debug(new StandardLogMessage("return"));
		 return result;
	 }
}
