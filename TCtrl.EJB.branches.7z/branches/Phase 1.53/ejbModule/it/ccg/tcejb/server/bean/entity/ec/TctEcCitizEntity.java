package it.ccg.tcejb.server.bean.entity.ec;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;

import java.util.Date;


/**
 * The persistent class for the TCTECCITIZ database table.
 * 
 */
@Entity
@Table(name="TCTECCITIZ")
@NamedQueries({
	@NamedQuery(name="deleteEcCitizEveryEntity", query="DELETE FROM TctEcCitizEntity"),
	@NamedQuery(name="getEcCitizEntitiesById", query="SELECT entity FROM TctEcCitizEntity entity WHERE entity.id.entityid = :entityId ORDER BY entity.id.cityId ASC")
})
public class TctEcCitizEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@EmbeddedId
	private TctEcCitizEntityPK id;

	@Column(length=50)
	private String country;

	@Column(length=100)
	private String legalBasis;

	@Column(length=2000)
	private String pdfLink;

    @Temporal( TemporalType.DATE)
	private Date regDate;

	//bi-directional many-to-one association to TctEcEntitEntity
    @ManyToOne(optional=true)
	@JoinColumn(name="ENTITYID", nullable=true, insertable=true, updatable=true)
	private TctEcEntitEntity tctecentit;

    public TctEcCitizEntity() {
    }

	public TctEcCitizEntityPK getId() {
		return this.id;
	}

	public void setId(TctEcCitizEntityPK id) {
		this.id = id;
	}
	
	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		if (country != null && country.length()>50){
			ejbLogger.debug(country+" >50 than truncate");
			this.country = country.substring(0, 49);
		}else{
			this.country = country;
		}
	}

	public String getLegalBasis() {
		return this.legalBasis;
	}

	public void setLegalBasis(String legalBasis) {
		if (legalBasis !=null && legalBasis.length()>100){
			ejbLogger.debug(legalBasis+" >100 than truncate");
			this.legalBasis = legalBasis.substring(0, 99);
		}else{
			this.legalBasis = legalBasis;
		}
	}

	public String getPdfLink() {
		return this.pdfLink;
	}

	public void setPdfLink(String pdfLink) {
		if (pdfLink !=null && pdfLink.length()>2000){
			ejbLogger.debug(pdfLink+" >2000 than truncate");
			this.pdfLink = pdfLink.substring(0, 1999);
		}else{
			this.pdfLink = pdfLink;
		}
	}

	public Date getRegDate() {
		return this.regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public TctEcEntitEntity getTctecentit() {
		return this.tctecentit;
	}

	public void setTctecentit(TctEcEntitEntity tctecentit) {
		this.tctecentit = tctecentit;
	}
	
}