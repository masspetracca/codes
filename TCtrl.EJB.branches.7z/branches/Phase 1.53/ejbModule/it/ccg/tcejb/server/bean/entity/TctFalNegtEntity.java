package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TCTFALNEGT database table.
 * 
 */
@Entity
@Table(name="TCTFALNEGT")
@NamedQueries({
	/*
	 * raffaele de lauri
	 * TN_CCG15575
	 * add check on status column
	 */
	/*@NamedQuery(name="getFNegativeByCmpnId",   query="SELECT entity " +
            "								           FROM TctFalNegtEntity entity " +
            "								          WHERE entity.id.cmpnid  = :cmpnId" +
            "											AND entity.status='F'")*/
	/*
	 * raffaele de lauri
	 * TN_CCG16359
	 * cambio query di selezione per escludere i falsi negativi gi� segnalati.
	 */
	@NamedQuery(name="getFNegativeByCmpnId",   query="SELECT entity " +
            "								           FROM TctFalNegtEntity entity " +
            "								          WHERE entity.id.cmpnid  = :cmpnId" +
            "											AND entity.status='F'" +
            "											AND entity.id.aggrId NOT IN (SELECT entityH.id.aggrid FROM TctFalNegHEntity entityH"+
			"										                        WHERE entityH.id.compnid  = entity.id.cmpnid"+
			"										                          AND entityH.status = entity.status)")
})
public class TctFalNegtEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TctFalNegtEntityPK id;

	@Column(nullable=false, length=255)
	private String entityName;

	@Column(length=255)
	private String note;

	@Column(nullable=false, length=30)
	private String source;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	@Column(nullable=false, length=1)
	private String status;
	
	//bi-directional many-to-one association to TctFalNegHEntity
	//@OneToMany(mappedBy="tctfalnegt")
	@Transient
	private Set<TctFalNegHEntity> tctfalneghs;

	//bi-directional many-to-one association to TctAggrEntEntity
    @ManyToOne
    @JoinColumns({
		@JoinColumn(name="AGGRID", referencedColumnName="AGGREGID", nullable=false, insertable=false, updatable=false),
	    @JoinColumn(name="DOWNLOADID", referencedColumnName="DOWNLOADID", nullable=false, insertable=false, updatable=false)
    })
	private TctAggrEntEntity tctaggrent;

	//bi-directional many-to-one association to TctClientEntity
    @ManyToOne
	@JoinColumns({
		@JoinColumn(name="CLNTID", referencedColumnName="CLNTID", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="CMPNID", referencedColumnName="CMPNID", nullable=false, insertable=false, updatable=false)
		})
	private TctClientEntity tctclient;

	//bi-directional many-to-one association to TctCompanyEntity
    @ManyToOne
	@JoinColumn(name="CMPNID", nullable=false, insertable=false, updatable=false)
	private TctCompanyEntity tctcompany;

    public TctFalNegtEntity() {
    }

	public TctFalNegtEntityPK getId() {
		return this.id;
	}

	public void setId(TctFalNegtEntityPK id) {
		this.id = id;
	}
	
	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getSource() {
		return this.source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public Set<TctFalNegHEntity> getTctfalneghs() {
		return this.tctfalneghs;
	}

	public void setTctfalneghs(Set<TctFalNegHEntity> tctfalneghs) {
		this.tctfalneghs = tctfalneghs;
	}
	
	public TctAggrEntEntity getTctaggrent() {
		return this.tctaggrent;
	}

	public void setTctaggrent(TctAggrEntEntity tctaggrent) {
		this.tctaggrent = tctaggrent;
	}
	
	public TctClientEntity getTctclient() {
		return this.tctclient;
	}

	public void setTctclient(TctClientEntity tctclient) {
		this.tctclient = tctclient;
	}
	
	public TctCompanyEntity getTctcompany() {
		return this.tctcompany;
	}

	public void setTctcompany(TctCompanyEntity tctcompany) {
		this.tctcompany = tctcompany;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
}