package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTOPTIMIZ database table.
 * 
 */
@Embeddable
public class TctOptimizEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int itId;

	@Column(unique=true, nullable=false)
	private int clntid;

	@Column(unique=true, nullable=false)
	private int cmpnid;

	@Column(unique=true, nullable=false, length=20)
	private String aggrid;

	@Column(unique=true, nullable=false)
	private int downloadid;

    public TctOptimizEntityPK() {
    }
	public int getItId() {
		return this.itId;
	}
	public void setItId(int itId) {
		this.itId = itId;
	}
	public int getClntid() {
		return this.clntid;
	}
	public void setClntid(int clntid) {
		this.clntid = clntid;
	}
	public int getCmpnid() {
		return this.cmpnid;
	}
	public void setCmpnid(int cmpnid) {
		this.cmpnid = cmpnid;
	}
	public String getAggrid() {
		return this.aggrid;
	}
	public void setAggrid(String aggrid) {
		this.aggrid = aggrid;
	}
	public int getDownloadid() {
		return this.downloadid;
	}
	public void setDownloadid(int downloadid) {
		this.downloadid = downloadid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctOptimizEntityPK)) {
			return false;
		}
		TctOptimizEntityPK castOther = (TctOptimizEntityPK)other;
		return 
			(this.itId == castOther.itId)
			&& (this.clntid == castOther.clntid)
			&& (this.cmpnid == castOther.cmpnid)
			&& this.aggrid.equals(castOther.aggrid)
			&& (this.downloadid == castOther.downloadid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.itId;
		hash = hash * prime + this.clntid;
		hash = hash * prime + this.cmpnid;
		hash = hash * prime + this.aggrid.hashCode();
		hash = hash * prime + this.downloadid;
		
		return hash;
    }
}