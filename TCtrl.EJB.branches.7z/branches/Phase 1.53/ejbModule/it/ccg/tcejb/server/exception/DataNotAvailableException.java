package it.ccg.tcejb.server.exception;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)

public class DataNotAvailableException extends Exception {



	public DataNotAvailableException(String message) {
		super("Data not available: "+message);
		
	}

	

}
