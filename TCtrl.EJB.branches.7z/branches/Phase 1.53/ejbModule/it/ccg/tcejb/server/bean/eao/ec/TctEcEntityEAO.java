package it.ccg.tcejb.server.bean.eao.ec;

import it.ccg.tcejb.server.bean.entity.ec.TctEcEntitEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctEcEntityEAO
 */
@Stateless
@LocalBean
public class TctEcEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	/*@Resource
	private SessionContext sessionContext;*/
	@EJB
	private TctEcAddrdEntityEAO addressEAO;
	@EJB
	private TctEcCitizEntityEAO citizenEAO;
	@EJB
	private TctEcBirthEntityEAO birthEAO;
	@EJB
	private TctEcPssPTEntityEAO pssEAO;
	@EJB
	private TctEcENameEAO nameEAO;
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
	
    public TctEcEntityEAO() {
        // TODO Auto-generated constructor stub
    }
    
    public void insertEntity(TctEcEntitEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctEcEntitEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcEntitEntity identification data: EC identity code = "+entity.getEntityId()+", regate= "+df.format(entity.getRegDate()))+" type= "+entity.getType());
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
	    	/*to DELETE
	    	 * this.addressEAO.deleteEveryEntity();
	    	this.citizenEAO.deleteEveryEntity();
	    	this.birthEAO.deleteEveryEntity();
	    	this.pssEAO.deleteEveryEntity();
	    	this.nameEAO.deleteEveryEntity();*/
	    	/*if (entity.getTctecaddrds()!=null && entity.getTctecaddrds().size()>0){
	    		addressEAO.insertEntity(entity.getTctecaddrds());
	    	}
	    	if (entity.getTcteccitizs()!=null && entity.getTcteccitizs().size()>0){
	    		citizenEAO.insertEntity(entity.getTcteccitizs());
	    	}
	    	if (entity.getTctecbirths()!=null && entity.getTctecbirths().size()>0){
	    		birthEAO.insertEntity(entity.getTctecbirths());
	    	}
	    	if(entity.getTctecenames()!=null && entity.getTctecenames().size()>0){
	    		nameEAO.insertEntity(entity.getTctecenames());
	    	}
	    	if(entity.getTctecpsspts()!=null && entity.getTctecpsspts().size()>0){
	    		pssEAO.insertEntity(entity.getTctecpsspts());
	    	}
	    	*/
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public void insertEntity(List<TctEcEntitEntity> entities) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctEcEntitEntity entity)"));
	    	int idxToFlush = 0;
	    	for (TctEcEntitEntity entity : entities){
		    	ejbLogger.debug(new StandardLogMessage("TctEcEntitEntity identification data: EC identity code = "+entity.getEntityId()+", regate= "+df.format(entity.getRegDate()))+" type= "+entity.getType());
		    	
		    	this.manager.persist(entity);	
		    	idxToFlush++;
		    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
		    		ejbLogger.debug(new StandardLogMessage("insert"));
			    	this.manager.flush();
		    	}
	    	}
	    	ejbLogger.debug(new StandardLogMessage("last insert"));
	    	this.manager.flush();
	    	/*this.addressEAO.deleteEveryEntity();
	    	this.citizenEAO.deleteEveryEntity();
	    	this.birthEAO.deleteEveryEntity();
	    	this.pssEAO.deleteEveryEntity();
	    	this.nameEAO.deleteEveryEntity();
	    	for(TctEcEntit entity : entities){
	    		if (entity.getTctecaddrds()!=null && entity.getTctecaddrds().size()>0){
		    		addressEAO.insertEntity(entity.getTctecaddrds());
		    	}
		    	if (entity.getTcteccitizs()!=null && entity.getTcteccitizs().size()>0){
		    		citizenEAO.insertEntity(entity.getTcteccitizs());
		    	}
		    	if (entity.getTctecbirths()!=null && entity.getTctecbirths().size()>0){
		    		birthEAO.insertEntity(entity.getTctecbirths());
		    	}
		    	if(entity.getTctecenames()!=null && entity.getTctecenames().size()>0){
		    		nameEAO.insertEntity(entity.getTctecenames());
		    	}
		    	if(entity.getTctecpsspts()!=null && entity.getTctecpsspts().size()>0){
		    		pssEAO.insertEntity(entity.getTctecpsspts());
		    	}
	    	}*/
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    
  	public void deleteEntity(TctEcEntitEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctEcEntitEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcEntit identification data: EC identity code = "+entity.getEntityId()+", regate= "+df.format(entity.getRegDate()))+" type= "+entity.getType());
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void deleteEveryEntity() throws BackEndException{
  		try{
  			//cancello i dati anche sulle tabello che fanno rifermento alla Entity
	    	this.addressEAO.deleteEveryEntity();
	    	this.citizenEAO.deleteEveryEntity();
	    	this.birthEAO.deleteEveryEntity();
	    	this.pssEAO.deleteEveryEntity();
	    	this.nameEAO.deleteEveryEntity();
	    	
	    	ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteEcEveryEntity");
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	
	    	this.manager.flush();
	    	
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctEcEntitEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctEcEntitEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctEcEntit identification data: EC identity code = "+entity.getEntityId()+", regate= "+df.format(entity.getRegDate()))+" type= "+entity.getType());
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	@SuppressWarnings("unchecked")
	public  List<TctEcEntitEntity> retrieveEntityById(int entityId) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<TctEcEntitEntity> retrieveEntityById(int entityId)"));
	    	ejbLogger.debug(new StandardLogMessage("ecEntityId "+entityId));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getEcEntitiesById");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("entityId", entityId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	List<TctEcEntitEntity> ecEntities = (List<TctEcEntitEntity>) q.getResultList();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return ecEntities;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
  	
  	@SuppressWarnings("unchecked")
	public List<TctEcEntitEntity> retrieveEntityBySrcListDate(String srcLstDate) throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in List<TctEcEntitEntity> retrieveEntityBySrcListDate(String srcLstDate)"));
       	ejbLogger.debug(new StandardLogMessage("srcLstDate : "+srcLstDate));
       	List<TctEcEntitEntity> tctEcEntities = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getEcEntitiesBySrcListDate");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			q.setParameter("srcListDate", df.parse(srcLstDate));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			tctEcEntities = (List<TctEcEntitEntity>) q.getResultList();
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return tctEcEntities; 	
  	}
  	
  	public List<TctEcEntitEntity> retrievePeopleBySrcListDate(String srcLstDate) throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in List<TctEcEntitEntity> retrievePeopleBySrcListDate(String srcLstDate)"));
       	ejbLogger.debug(new StandardLogMessage("srcLstDate : "+srcLstDate));
       	List<TctEcEntitEntity> tctEcEntities = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getEcPeopleBySrcListDate");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			q.setParameter("srcListDate", df.parse(srcLstDate));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			tctEcEntities = (List<TctEcEntitEntity>) q.getResultList();
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return tctEcEntities;
  	}
  	
  	public Date getLatestsrcListDate() throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in Date getLatestSrcListDate()"));
  		Date maxSrcListDate= null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getEcLatestSrcListDate");
			ejbLogger.debug(new StandardLogMessage("getSingleResult"));
			maxSrcListDate = (Date) q.getSingleResult();
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return maxSrcListDate;
  		
  	}
  	
  	public List<TctEcEntitEntity> retrieveLatestEntities() throws BackEndException{
  		ejbLogger.debug(new StandardLogMessage("in List<TctEcEntitEntity> retrieveLatestEntities()"));
       	List<TctEcEntitEntity> tctOfEntities = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getEcLatestEntities");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			tctOfEntities = (List<TctEcEntitEntity>) q.getResultList();
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return tctOfEntities;
  	}
  	
  	public List<TctEcEntitEntity> retrieveLatestPeople() throws BackEndException{
		return null;
  		
  	}
  	
  	public TctEcEntitEntity retrieveAllEntities() throws BackEndException{
		return null;
  		
  	}
}
