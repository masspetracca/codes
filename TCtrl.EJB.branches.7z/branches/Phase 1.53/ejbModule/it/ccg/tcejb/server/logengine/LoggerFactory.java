package it.ccg.tcejb.server.logengine;

import org.apache.log4j.Logger;


public class LoggerFactory {
	
	public static final String EJB_LOGGER = "tcejb.server.logger";
	public static final String WEB_LOGGER = "tcweb.server.logger";
	public static final String USER_LOGGER = "tcweb.server.user_logger";
	public static final String CALCULATION_LOGGER = "tcweb.server.calculation_logger";
	public static final String SYS_LOG = "tc.sys_log";
	
	public static final String applicationCode = "TC";
	
	public static Logger getLogger(String loggerType){
		
		Logger logger = null;
		
		
		if(loggerType.equalsIgnoreCase(EJB_LOGGER)) {
			
			logger =  Logger.getLogger(EJB_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(WEB_LOGGER)) {
			
			logger =  Logger.getLogger(WEB_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(USER_LOGGER)) {
			
			logger =  Logger.getLogger(USER_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(CALCULATION_LOGGER)) {
			
			logger =  Logger.getLogger(CALCULATION_LOGGER);
		}else if(loggerType.equalsIgnoreCase(SYS_LOG)) {
			
			logger =  Logger.getLogger(SYS_LOG);
		}else {
			
			try {
				throw new Exception("loggerType \'" + loggerType + "\' not defined.");
			}
			catch (Exception e) {
				
				e.printStackTrace();
			}
			
		}
		
		
		return logger;
	}

}
