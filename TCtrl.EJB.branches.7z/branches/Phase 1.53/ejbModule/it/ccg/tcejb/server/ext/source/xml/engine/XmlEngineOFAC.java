package it.ccg.tcejb.server.ext.source.xml.engine;

import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.ext.source.xml.ofac.ObjectFactory;
import it.ccg.tcejb.server.ext.source.xml.ofac.SdnEntry;
import it.ccg.tcejb.server.ext.source.xml.ofac.SdnList;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

public class XmlEngineOFAC {
	private static final Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	public static void main(String[] args){
		try {
			new XmlEngineOFAC().read();
		} catch (BackEndException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public SdnList read(String path) throws JAXBException, BackEndException{
		InputStream inputStream =null;
		try {
			inputStream = new FileInputStream(path);
			Reader reader;
			
			reader = new InputStreamReader(inputStream, "UTF-8");
			
			
			JAXBContext jaxbContext;
			SdnList cont=null;
	
			jaxbContext = JAXBContext.newInstance(ObjectFactory.class, SdnList.class);
			
			
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			cont = (SdnList)jaxbUnmarshaller.unmarshal(reader);
	
			return cont;
		} catch (UnsupportedEncodingException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		} catch (FileNotFoundException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		}
		finally{
			try {
				if (inputStream!=null)
					inputStream.close();
			} catch (IOException e) {
				ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
				throw new BackEndException(e);
			}
		}
	}
	
	/**
	 * Methods that use a determinate path
	 * C:/Users/rdelauri/Desktop/Antiterrorismo/Antiterrorismo/01_Requisiti utente/Flussi/onu/AQList.xml
	 * @return
	 * @throws BackEndException 
	 */
	public SdnList read() throws BackEndException{
		File file = new File("C:/Temp/sdn.xml");
		JAXBContext jaxbContext;
		SdnList cont=null;
		try {
			jaxbContext = JAXBContext.newInstance(ObjectFactory.class, SdnList.class);
			
			
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			cont = (SdnList)jaxbUnmarshaller.unmarshal(file);

			//System.out.println(cont.getPublshInformation().getPublishDate());
			for (SdnEntry e :cont.getSdnEntry()){
				System.out.println(e.getUid());
			}
			
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		}
		return cont;
	}
	
	public SdnList read(File file) throws JAXBException{

		JAXBContext jaxbContext;
		SdnList cont = null;
		jaxbContext = JAXBContext.newInstance(ObjectFactory.class, SdnList.class);

		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		cont = (SdnList)jaxbUnmarshaller.unmarshal(file);
			
		return cont;
	}
	
	public SdnList read(InputStream iStream) throws BackEndException{

		JAXBContext jaxbContext;
		SdnList cont = null;
		try {
			jaxbContext = JAXBContext.newInstance(ObjectFactory.class, SdnList.class);
			
			
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			cont = (SdnList)jaxbUnmarshaller.unmarshal(iStream);
			
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger,e);
			throw new BackEndException(e);
		}
		return cont;
	}
}
