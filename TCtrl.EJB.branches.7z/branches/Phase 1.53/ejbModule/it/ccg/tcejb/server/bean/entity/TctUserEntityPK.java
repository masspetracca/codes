package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTUSER database table.
 * 
 */
@Embeddable
public class TctUserEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false, length=30)
	private String userName;

	@Column(unique=true, nullable=false)
	private int cmpnid;

    public TctUserEntityPK() {
    }
	public String getUserName() {
		return this.userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getCmpnid() {
		return this.cmpnid;
	}
	public void setCmpnid(int cmpnid) {
		this.cmpnid = cmpnid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctUserEntityPK)) {
			return false;
		}
		TctUserEntityPK castOther = (TctUserEntityPK)other;
		return 
			this.userName.equals(castOther.userName)
			&& (this.cmpnid == castOther.cmpnid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.userName.hashCode();
		hash = hash * prime + this.cmpnid;
		
		return hash;
    }
}