package it.ccg.tcejb.server.bean.eao.un;

import it.ccg.tcejb.server.bean.entity.un.TctUnAddr;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctUnAddrEntityEAO
 */
@Stateless
@LocalBean
public class TctUnAddrEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctUnAddrEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctUnAddr entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctUnAddr entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnAddr identification data: UN Entity code = "+entity.getEntityid()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public void insertEntity(Set<TctUnAddr> entities) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctUnAddr entity)"));
	    	int idxToFlush = 0;
	    	for (TctUnAddr entity : entities){
	    		ejbLogger.debug(new StandardLogMessage("TctUnAddr identification data: UN Entity code = "+entity.getEntityid()));

		    	this.manager.persist(entity);
		    	idxToFlush++;
		    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
		    		ejbLogger.debug(new StandardLogMessage("insert"));
			    	this.manager.flush();
		    	}
	    	}
	    	ejbLogger.debug(new StandardLogMessage("last insert"));
	    	this.manager.flush();
	    	
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
  	public void deleteEntity(TctUnAddr entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctUnAddr entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnAddr identification data: UN Entity code = "+entity.getEntityid() +" , address id = "+entity.getAddrId()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void deleteEveryEntity() throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteUnAddrEveryEntity");
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	this.manager.flush();
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctUnAddr entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctUnAddr entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnAddr identification data: UN Entity code = "+entity.getEntityid() +" , address id = "+entity.getAddrId()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	@SuppressWarnings("unchecked")
	public  List<TctUnAddr> retrieveEntityAddrByEntId(int entityId) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<TctUnAddr> retrieveEntityAddrByEntId(int entityId)"));
	    	ejbLogger.debug(new StandardLogMessage("UnEntityId "+entityId));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getUnAddrEntitiesById");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("entityId", entityId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	List<TctUnAddr> unAddEntities = (List<TctUnAddr>) q.getResultList();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return unAddEntities;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
}
