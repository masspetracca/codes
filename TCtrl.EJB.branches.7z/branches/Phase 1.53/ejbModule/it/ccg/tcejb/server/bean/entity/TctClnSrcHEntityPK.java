package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTCLNSRCH database table.
 * 
 */
@Embeddable
public class TctClnSrcHEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int cmpnid;

	@Column(unique=true, nullable=false)
	private int runid;

    public TctClnSrcHEntityPK() {
    }
	public int getCmpnid() {
		return this.cmpnid;
	}
	public void setCmpnid(int cmpnid) {
		this.cmpnid = cmpnid;
	}
	public int getRunid() {
		return this.runid;
	}
	public void setRunid(int runid) {
		this.runid = runid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctClnSrcHEntityPK)) {
			return false;
		}
		TctClnSrcHEntityPK castOther = (TctClnSrcHEntityPK)other;
		return 
			(this.cmpnid == castOther.cmpnid)
			&& (this.runid == castOther.runid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.cmpnid;
		hash = hash * prime + this.runid;
		
		return hash;
    }
}