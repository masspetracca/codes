package it.ccg.tcejb.server.util;

import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;


public class XmlManager {
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	public static byte[] parse(byte[] streamToParse) {
		logger.debug(new StandardLogMessage("in XmlManager.parse"));
		File stylesheet;
		ByteArrayOutputStream bAOS = null;
		try {
			//logger.debug(new StandardLogMessage("load xsl file"));
			//stylesheet = new File(SystemProperties.getSystemProperty("xsl.path"));
			logger.debug(new StandardLogMessage("load xml stream"));
			
	        ByteArrayInputStream bAIS = new ByteArrayInputStream(streamToParse);
	        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	        Document document = builder.parse(bAIS);
	        
	        
	        
	        //StreamSource stylesource = new StreamSource(stylesheet); 
	        
	       Transformer transformer = TransformerFactory.newInstance().newTransformer();
	       transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
	       transformer.setOutputProperty(OutputKeys.METHOD, "xml");
	       transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	       transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
	       transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
	        
	        bAOS = new ByteArrayOutputStream();
	        
	       DOMSource source = new DOMSource(document);
	       StreamResult result = new StreamResult(bAOS);
	       logger.debug(new StandardLogMessage("extracting xml..."));
	        
	       transformer.transform(source, result);
	       
	       //System.out.println(result.getWriter().toString());
	        
		} catch (ParserConfigurationException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			ExceptionUtil.logCompleteStackTrace(logger,new Exception(e));
		} catch (SAXException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (TransformerConfigurationException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (TransformerException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		}
		logger.debug(new StandardLogMessage("return"));
		return bAOS.toByteArray();
		
	}
}
