package it.ccg.tcejb.server.bean.eao.ofac;

import it.ccg.tcejb.server.bean.entity.ofac.TctOfCitzEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Set;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctOfCitzEAO
 */
@Stateless
@LocalBean
public class TctOfCitzEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
    /**
     * Default constructor. 
     */
    public TctOfCitzEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctOfCitzEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctOfCitzEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctOfCitzEntity identification data: OFAC citizen code = "+entity.getId().getEntityid() +" , citized id = "+entity.getId().getCitizId()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public void insertEntity(Set<TctOfCitzEntity> entities) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(Set<TctOfCitzEntity> entities)"));
	    	int idxToFlush = 0;
	    	for (TctOfCitzEntity entity : entities){
	    		ejbLogger.debug(new StandardLogMessage("TctOfCitz identification data: OFAC citizen code = "+entity.getId().getEntityid() +" , citized id = "+entity.getId().getCitizId()));
		    	
		    	this.manager.persist(entity);
		    	idxToFlush++;
		    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
		    		ejbLogger.debug(new StandardLogMessage("insert"));
			    	this.manager.flush();
		    	}
	    	}
	    	ejbLogger.debug(new StandardLogMessage("last insert"));
	    	this.manager.flush();
	    	
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
  	public void deleteEntity(TctOfCitzEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctOfCitzEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctOfCitzEntity identification data: OFAC citizen code = "+entity.getId().getEntityid() +" , citized id = "+entity.getId().getCitizId()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void deleteEveryEntity() throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteOfCitizEveryEntity");
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	this.manager.flush();
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctOfCitzEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctOfCitzEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctOfCitzEntity identification data: OFAC citizen code = "+entity.getId().getEntityid() +" , citized id = "+entity.getId().getCitizId()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	@SuppressWarnings("unchecked")
	public  List<TctOfCitzEntity> retrieveEntityCitizByEntId(int entityId) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<TctOfCitzEntity> retrieveEntityCitizByEntId(int entityId)"));
	    	ejbLogger.debug(new StandardLogMessage("ecEntityId "+entityId));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getOfCitizEntitiesById");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("entityId", entityId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	List<TctOfCitzEntity> ofCitizEntities = (List<TctOfCitzEntity>) q.getResultList();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return ofCitizEntities;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
}
