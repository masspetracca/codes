package it.ccg.tcejb.server.exception;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class PropertyException extends Exception {

	public PropertyException(String message,String stackTrace) {
		super(message+" - "+stackTrace);
		
	}

}
