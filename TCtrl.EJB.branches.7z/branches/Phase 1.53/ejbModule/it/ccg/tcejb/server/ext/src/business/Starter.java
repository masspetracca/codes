package it.ccg.tcejb.server.ext.src.business;

import it.ccg.tcejb.server.bean.AnalysisController;
import it.ccg.tcejb.server.bean.DownloadManagerLocal;
import it.ccg.tcejb.server.bean.OptimizationController;
import it.ccg.tcejb.server.bean.eao.TctAggrEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctClientEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctClientHEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctCompanyEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctCorrLstEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctCorrispEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctDownRegEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctDownRunEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctFalNegHEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctFalsNegtEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctOptimizEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctRunRegEAO;
import it.ccg.tcejb.server.bean.eao.TctSrcFlHEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctSrcUpDtEntityEAO;
import it.ccg.tcejb.server.bean.eao.ec.TctEcEntityEAO;
import it.ccg.tcejb.server.bean.eao.ofac.TctOfEntityEAO;
import it.ccg.tcejb.server.bean.eao.un.TctUnEntityEAO;
import it.ccg.tcejb.server.bean.entity.TctAggrEntEntity;
import it.ccg.tcejb.server.bean.entity.TctAggrEntEntityPK;
import it.ccg.tcejb.server.bean.entity.TctClientEntity;
import it.ccg.tcejb.server.bean.entity.TctClientHEntity;
import it.ccg.tcejb.server.bean.entity.TctClientHEntityPK;
import it.ccg.tcejb.server.bean.entity.TctCompanyEntity;
import it.ccg.tcejb.server.bean.entity.TctCorrLstEntity;
import it.ccg.tcejb.server.bean.entity.TctCorrispEntity;
import it.ccg.tcejb.server.bean.entity.TctCorrispEntityPK;
import it.ccg.tcejb.server.bean.entity.TctDownRegEntity;
import it.ccg.tcejb.server.bean.entity.TctDownRunEntity;
import it.ccg.tcejb.server.bean.entity.TctDownRunEntityPK;
import it.ccg.tcejb.server.bean.entity.TctFalNegHEntity;
import it.ccg.tcejb.server.bean.entity.TctFalNegHEntityPK;
import it.ccg.tcejb.server.bean.entity.TctFalNegtEntity;
import it.ccg.tcejb.server.bean.entity.TctOptimizEntity;
import it.ccg.tcejb.server.bean.entity.TctRunRegEntity;
import it.ccg.tcejb.server.bean.entity.TctSrcFlHEntity;
import it.ccg.tcejb.server.bean.entity.TctSrcUpDtEntity;
import it.ccg.tcejb.server.bean.entity.ec.TctEcENameEntity;
import it.ccg.tcejb.server.bean.entity.ec.TctEcEntitEntity;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfAkaAliasEntity;
import it.ccg.tcejb.server.bean.entity.ofac.TctOfEntitEntity;
import it.ccg.tcejb.server.bean.entity.un.TctUnAlia;
import it.ccg.tcejb.server.bean.entity.un.TctUnEntit;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.find.business.ClientsAligner;
import it.ccg.tcejb.server.find.business.MatchFinder;
import it.ccg.tcejb.server.find.business.NotificationEmailSender;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardCheckPointMessage;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;


/**
 * Session Bean implementation class Starter
 */
@Stateless
@LocalBean
public class Starter {
	private static final Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private static final Logger sysLogger = Logger.getLogger(LoggerFactory.SYS_LOG);
	
	@EJB
	public OFACSourceHandler ofacSourceHandler;
	@EJB
	public ECSourceHandler ecSourceHandler;
	@EJB
	public UNSourceHandler unSourceHandler;
	@EJB
	private TctDownRegEntityEAO downRegEAO;
	@EJB
	private TctSrcFlHEntityEAO tctSrcFlEAO;
	@EJB 
	private TctDownRunEntityEAO downRunEAO; 
	@EJB
	private TctEcEntityEAO ecEntityEAO;
	@EJB
	private TctUnEntityEAO unEntityEAO;
	@EJB
	private TctOfEntityEAO ofEntityEAO;
	@EJB
	private TctAggrEntityEAO aggrEntityEAO;
	@EJB
	private DownloadManagerLocal downloadManager;
	@EJB
	private TctCompanyEntityEAO companyEntityEAO;
	@EJB
	private TctRunRegEAO runRegEntityEAO;
	@EJB
	private TctDownRunEntityEAO downRunEntityEAO; 
	@EJB
	private TctClientEntityEAO clientEntityEAO;
	@EJB
	private TctClientHEntityEAO clientHEntityEAO;
	@EJB
	private TctCorrispEntityEAO corrispEntityEAO;
	@EJB
	private TctFalsNegtEntityEAO falsNegtEntityEAO;
	@EJB
	private TctFalNegHEntityEAO falNegHEntityEAO;
	@EJB
	private TctOptimizEntityEAO optimizEntityEAO;
	@EJB
	private TctSrcUpDtEntityEAO tctSrcUpDtEntityEAO;
	@EJB
	private MatchFinder finder;
	@EJB
	private ClientsAligner aligner;
	@EJB
	private OptimizationController optimizationController;
	@EJB
	private AnalysisController analysisController;
	@EJB
	private TctCorrLstEntityEAO tctCorrLstEntityEAO;
	@EJB
	private NotificationEmailSender notificationSender;
	
	@Resource
	private SessionContext sessionContext;
	
	private String treeSetPath;
    /**
     * Default constructor. 
     */
    public Starter() {
       try {
    	   /*
    	    * READ properties file
    	    */
			treeSetPath = SystemProperties.getSystemProperty("treeset.path");
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			e.printStackTrace();
		}
    }

    /**
     * Terrorist data download flow
     * @throws BackEndException
     */
    public void startTerroristDataFlow() throws BackEndException{
    	try {
	    	ejbLogger.debug("in void startTerroristDataFlow()");
	    	ejbLogger.info(new StandardCheckPointMessage("Start Terrorism data flow "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
	    	TreeMap<String,TctAggrEntEntity> prevAggr=null,currentAggr=null;
	    	
	    	TctDownRegEntity download = new TctDownRegEntity();
	    	download.setDownloadDt(new Timestamp(new Date().getTime()));
	    	
	    	ejbLogger.debug(new StandardLogMessage("insert download record"));
	    	
	    	/*
	    	 * INSERT entry DOWNLOAD  register and get DOWNLOAD_ID
	    	 */
			this.downRegEAO.insertDownload(download);
			
			ejbLogger.debug("retrieve current download id");
			int downloadID = this.downRegEAO.retrieveLatestIDByDownloadDate(download);
			
			
			
			/*
			 * READ PREV_DOWNLOAD_ID on the DOWNLOAD_RUN_CORR
			 */
			int prevDownloadId = downRunEAO.retrieveLatestDownID();
			/*
			 * LOAD PREV_AGGREGATED_LIST (seriazed file with PREV_DOWNLOAD_ID as prefix)
			 * 
			 */
			if(prevDownloadId != -1){
				prevAggr = this.readPreviousAggLis(prevDownloadId);
			}
			/*
	    	 * start download flow, marshal and insert data into db
	    	 */
			TctSrcUpDtEntity [] dataRetrieved = this.retrieveTerroristData(downloadID);
			boolean isDataRetrieved =  ((dataRetrieved[0]!=null) || (dataRetrieved[1]!=null) || (dataRetrieved[2]!=null));//this.retrieveTerroristData(downloadID);
	    	/*
	    	 * CHECK at least one file chenged
	    	 */
			if (isDataRetrieved){
	    		/*
	    		 * new data inserted, than historicize
	    		 * INSERT all BLOB XML to DB (DOWNLOAD_ID)
	    		 */
	    		this.storeSrcFile(download);
	    		if( dataRetrieved[0]!=null)
	    			this.tctSrcUpDtEntityEAO.insertEntity(dataRetrieved[0]);
	    		
	    		if( dataRetrieved[1]!=null)
	    			this.tctSrcUpDtEntityEAO.insertEntity(dataRetrieved[1]);
	    		
	    		if( dataRetrieved[2]!=null)
	    			this.tctSrcUpDtEntityEAO.insertEntity(dataRetrieved[2]);
	    		
		    	List<TctAggrEntEntity> aggrEnts = new ArrayList<TctAggrEntEntity>();
		    	currentAggr = new TreeMap<String,TctAggrEntEntity>();
		    	ejbLogger.info(new StandardCheckPointMessage("Aggregated list popolation start"));
		    	
		    	/*
		    	 * create current treemap and AggregatedEntity list
		    	 * POPULATE AGGREGATED_LIST
		    	 * comparing the lists and populating IsNew Flag (DOWNLOAD_ID)
		    	 */
		    	ejbLogger.debug(new StandardLogMessage("reading EC list"));
		    	List<TctEcEntitEntity> ecEntities = ecEntityEAO.retrieveLatestEntities();
		    	for (TctEcEntitEntity entity : ecEntities){
		    		Set<TctEcENameEntity> names = entity.getTctecenames();
		    		for (TctEcENameEntity name : names){
		    			TctAggrEntEntity aggrEnt = new TctAggrEntEntity();
		    			TctAggrEntEntityPK pk = new TctAggrEntEntityPK();
			    		pk.setAggregId("EC"+name.getId().getEntityid()+"-"+name.getId().getNameId());
			    		pk.setDownloadid(downloadID);
			    		aggrEnt.setId(pk);
			    		aggrEnt.setEntityid(name.getId().getEntityid());
			    		aggrEnt.setNameid(name.getId().getNameId());
		    			aggrEnt.setSrcCode("EC");
		    			/*
		    			 * raffaele de lauri
		    			 * TN_CCG15376
		    			 */
		    			if (name.getWholeName() == null || name.getWholeName().equalsIgnoreCase("")){
		    				aggrEnt.setEntityName(name.getLastName());
		    			}else{
		    				aggrEnt.setEntityName(name.getWholeName());
		    			}
		    			/*
		    			 * raffaele de lauri
		    			 * TN_CCG15375
		    			 * in fase ricerca all'interno della treemap � stata aggiunta la concatenazione nel codice della lista al nome dell'entit�
		    			 */
		    			if (prevAggr!=null){
		    				aggrEnt.setIsnew(prevAggr.keySet().contains(aggrEnt.getEntityName()+"%EC")?"N":"Y");
		    			}else{
		    				/*
		    				 * raffaele de lauri
		    				 * TN_CCG16438
		    				 * modifico assegnazione flag per primo giro
		    				 */
		    				aggrEnt.setIsnew("N");
		    			}
		    			aggrEnt.setPdfLink(name.getPdfLink());
		    			if (name.getRegDate()!=null){
		    				aggrEnt.setPresentFrom(name.getRegDate());
		    			}else{
		    				aggrEnt.setPresentFrom(name.getTctecentit().getSrcListDate());
		    			}
		    			
		    			/*
		    			 * ticket 14890
		    			 */
		    			aggrEnt.setSrcList("EC");
		    			aggrEnt.setSrcLstDate(name.getTctecentit().getSrcListDate());
		    			aggrEnt.setUpdUser(sessionContext.getCallerPrincipal().getName());
		    			/*
		    			 * raffaele de lauri
		    			 * TN_CCG15280
		    			 */
		    			currentAggr.put(name.getWholeName()+"%EC",aggrEnt);
		    			aggrEnts.add(aggrEnt);
		    		}
		    	}
		    	
		    	ejbLogger.debug(new StandardLogMessage("reading UN list"));
		    	List<TctUnEntit> unEntities = unEntityEAO.retrieveLatestEntities();
		    	for (TctUnEntit entity : unEntities){
		    		TctAggrEntEntity aggrEnt = new TctAggrEntEntity();
		    		TctAggrEntEntityPK pk = new TctAggrEntEntityPK();
		    		pk.setAggregId("UN"+entity.getDataId()+"-"+entity.getDataId());
		    		pk.setDownloadid(downloadID);
		    		aggrEnt.setId(pk);
		    		aggrEnt.setEntityid(entity.getDataId());
		    		aggrEnt.setNameid(entity.getDataId());
					aggrEnt.setSrcCode("UN");
					aggrEnt.setEntityName(entity.getFirstName());
					/*
	    			 * raffaele de lauri
	    			 * TN_CCG15375
	    			 * in fase ricerca all'interno della treemap � stata aggiunta la concatenazione nel codice della lista al nome dell'entit�
	    			 */
					if (prevAggr!=null){
						aggrEnt.setIsnew(prevAggr.keySet().contains(aggrEnt.getEntityName()+"%UN")?"N":"Y");
					}else{
						/*
	    				 * raffaele de lauri
	    				 * TN_CCG16438
	    				 * modifico assegnazione flag per primo giro
	    				 */
	    				aggrEnt.setIsnew("N");
					}
					aggrEnt.setPdfLink("");
					if(entity.getListedOn()!=null){
						aggrEnt.setPresentFrom(entity.getListedOn());
					}else{
						aggrEnt.setPresentFrom(entity.getReleasedDt());
					}
					
					aggrEnt.setSrcList("UN");
					aggrEnt.setSrcLstDate(entity.getReleasedDt());
					/*
	    			 * raffaele de lauri
	    			 * TN_CCG15280
	    			 */
					currentAggr.put(entity.getFirstName()+"%UN",aggrEnt);
					aggrEnts.add(aggrEnt);
					
					Set<TctUnAlia> unAlias = entity.getTctunalias();
					for(TctUnAlia alias : unAlias){
						TctAggrEntEntity aggrAlis = new TctAggrEntEntity();
						TctAggrEntEntityPK aliasPk = new TctAggrEntEntityPK();
						aliasPk.setAggregId("UN"+alias.getEntityid()+"-"+alias.getAlaisId());
						aliasPk.setDownloadid(downloadID);
						aggrAlis.setId(aliasPk);	
			    		aggrAlis.setEntityid(entity.getDataId());
			    		aggrAlis.setNameid(alias.getAlaisId());
						aggrAlis.setSrcCode("UN");
						aggrAlis.setEntityName(alias.getAliasName());
						/*
		    			 * raffaele de lauri
		    			 * TN_CCG15375
		    			 * in fase ricerca all'interno della treemap � stata aggiunta la concatenazione nel codice della lista al nome dell'entit�
		    			 */
						if (prevAggr!=null){
							aggrAlis.setIsnew(prevAggr.keySet().contains(aggrAlis.getEntityName()+"%UN")?"N":"Y");
						}else{
							/*
		    				 * raffaele de lauri
		    				 * TN_CCG16438
		    				 * modifico assegnazione flag per primo giro
		    				 */
							aggrAlis.setIsnew("N");
						}
						
						aggrAlis.setPdfLink("");
						if(alias.getTctunentit().getListedOn()!=null){
							aggrAlis.setPresentFrom(alias.getTctunentit().getListedOn());
						}else{
							aggrAlis.setPresentFrom(alias.getTctunentit().getReleasedDt());
						}
						
						aggrAlis.setSrcList("UN");
						aggrAlis.setSrcLstDate(alias.getTctunentit().getReleasedDt());
						/*
		    			 * raffaele de lauri
		    			 * TN_CCG15280
		    			 */
						currentAggr.put(alias.getAliasName()+"%UN",aggrAlis);
						aggrEnts.add(aggrAlis);
					}
		    	}
		    	
		    	ejbLogger.debug(new StandardLogMessage("reading OFAC list"));
		    	List<TctOfEntitEntity> ofEntities = ofEntityEAO.retrieveLatestEntities();
		    	for (TctOfEntitEntity entity : ofEntities){
		    		TctAggrEntEntity aggrEnt = new TctAggrEntEntity();
		    		TctAggrEntEntityPK pk = new TctAggrEntEntityPK();
		    		pk.setAggregId("OF"+entity.getEntityId()+"-"+entity.getEntityId());
		    		pk.setDownloadid(downloadID);
		    		aggrEnt.setId(pk);
		    		aggrEnt.setEntityid(entity.getEntityId());
		    		aggrEnt.setNameid(entity.getEntityId());
					aggrEnt.setSrcCode("OFC");
					aggrEnt.setEntityName(entity.getLastName());
					/*
	    			 * raffaele de lauri
	    			 * TN_CCG15375
	    			 * in fase ricerca all'interno della treemap � stata aggiunta la concatenazione nel codice della lista al nome dell'entit�
	    			 */
					if (prevAggr!=null){
						aggrEnt.setIsnew(prevAggr.keySet().contains(aggrEnt.getEntityName()+"%OFAC")?"N":"Y");
					}else{
						/*
	    				 * raffaele de lauri
	    				 * TN_CCG16438
	    				 * modifico assegnazione flag per primo giro
	    				 */
	    				aggrEnt.setIsnew("N");
					}
					aggrEnt.setPdfLink("");
					aggrEnt.setPresentFrom(entity.getSrcListDate());
					aggrEnt.setSrcList("OFAC");
					aggrEnt.setSrcLstDate(entity.getSrcListDate());
					/*
	    			 * raffaele de lauri
	    			 * TN_CCG15280
	    			 */
					currentAggr.put(entity.getLastName()+"%OFAC",aggrEnt);
					aggrEnts.add(aggrEnt);
					
					Set<TctOfAkaAliasEntity> ofAlias = entity.getTctofakaals();
					for(TctOfAkaAliasEntity alias : ofAlias){
						TctAggrEntEntity aggrAlis = new TctAggrEntEntity();
						TctAggrEntEntityPK aliasPk = new TctAggrEntEntityPK();
						aliasPk.setAggregId("OF"+alias.getId().getEntityid()+"-"+alias.getId().getAkaId());
						aliasPk.setDownloadid(downloadID);
						aggrAlis.setId(aliasPk);
						aggrAlis.setEntityid(entity.getEntityId());
			    		aggrAlis.setNameid(alias.getId().getAkaId());
						aggrAlis.setSrcCode("OFC");
						aggrAlis.setEntityName(alias.getLastName());
						/*
		    			 * raffaele de lauri
		    			 * TN_CCG15375
		    			 * in fase ricerca all'interno della treemap � stata aggiunta la concatenazione nel codice della lista al nome dell'entit�
		    			 */
						if (prevAggr!=null){
							aggrAlis.setIsnew(prevAggr.keySet().contains(aggrAlis.getEntityName()+"%OFAC")?"N":"Y");
						}else{
							/*
		    				 * raffaele de lauri
		    				 * TN_CCG16438
		    				 * modifico assegnazione flag per primo giro
		    				 */
							aggrAlis.setIsnew("N");
						}
						
						aggrAlis.setPdfLink("");
						aggrAlis.setPresentFrom(alias.getTctofentit().getSrcListDate());
						aggrAlis.setSrcList("OFAC");
						aggrAlis.setSrcLstDate(alias.getTctofentit().getSrcListDate());
						/*
		    			 * raffaele de lauri
		    			 * TN_CCG15280
		    			 */
						currentAggr.put(alias.getLastName()+"%OFAC",aggrAlis);
						aggrEnts.add(aggrAlis);
					}
		    	}
		    	ejbLogger.debug(new StandardLogMessage("aggrEnts "+aggrEnts.size()));
		    	/*
		    	 * store AggregegatedEntity list
		    	 * INSERT Aggregated terrorist list to DB (DOWNLOAD_ID)
		    	 */
		    	aggrEntityEAO.insertEntity(aggrEnts);
		    	/*
		    	 * serialize current treemap
		    	 * SAVE AGGREGATED_LIST (serialized file with DOWNLOAD_ID in the file pattern)
		    	 */
		    	this.writeCurrentAggLis(downloadID, currentAggr);
		    	/*
		    	 * LOG "Data flow completed"
		    	 */
		    	ejbLogger.info(new StandardCheckPointMessage("Terrorism data flow completed "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
	    	}else{
	    		/*
	    		 * LOG "No variations"
	    		 */
	    		/*
	    		 * raffale de lauri
	    		 * TN_CCG15333
	    		 * without variation, than set status as DOWNLOAD EMPTY 
	    		 */
	    		download.setStatus("E");
	    		ejbLogger.info(new StandardCheckPointMessage("Terrorism data flow completed with no variations "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
	    	}
    	} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Terrorism data flow completed with error: "+e.getMessage()));
			/*
			 * Raffaele De Lauri
			 * TN_CCG14897
			 */
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3Terrorism data flow completed with error: "+e.getMessage());
			throw e;
		}finally{
			downloadManager.deleteDownloadedList();
		}
    	
    }
    
    /**
     * Find matches batch
     * @param companyId
     * @throws BackEndException
     */
    @SuppressWarnings("unchecked")
	public void startFindMatch(Integer companyId) throws BackEndException{
    	ejbLogger.debug("in void startFindMatch()");
    	ejbLogger.info(new StandardCheckPointMessage("Start find matches flow "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	/*
    	 * LOAD THRESHOULD (for comany/risk profile)
    	 */
    	ejbLogger.debug("companyId "+companyId);
    	Future<Boolean> analisysChecher = null;
    	try {
	    	TctCompanyEntity company = companyEntityEAO.retrieveCompanyByCompanyId(companyId);
	    	double thrsld1=0,thrsld2=0;
	    	switch (company.getRiskProf()){
	    		case "hr":
	    			thrsld1 = company.getThrsldHr1().doubleValue();
	    			thrsld2 = company.getThrsldHr2().doubleValue();
	    			break;
	    		case "mr":
	    			thrsld1 = company.getThrsldMr1().doubleValue();
	    			thrsld2 = company.getThrsldMr2().doubleValue();
	    			break;
	    		case "lr":
	    			thrsld1 = company.getThrsldLr1().doubleValue();
	    			thrsld2 = company.getThrsldLr2().doubleValue();
	    			break;
	    	}
	    	ejbLogger.debug(new StandardLogMessage("thresholds loaded"));
	    	
	    	Date runDate = new Date();
	    	TctRunRegEntity runEntity = new TctRunRegEntity();
	    	
	    	/*
	    	 * INSERT entry for COMPANY into RUN_REGISTER 
	    	 */
	    	runEntity.setCmpnid(company.getCmpnId());
	    	runEntity.setMatchFound("F");
	    	runEntity.setApproved("F");
	    	runEntity.setRunDate(new Timestamp(runDate.getTime()));
	    	ejbLogger.debug(new StandardLogMessage("insert RunRegister"));
	    	runRegEntityEAO.insertEntity(runEntity);
	    	/*
	    	 * and get RUN_ID
	    	 */
	    	TctRunRegEntity currentRun = runRegEntityEAO.retrieveRunByRunDate(runEntity);
	    	
	    	/*
	    	 * READ LAST_DOWNLOAD_ID on the DOWNLOAD_REG
	    	 */
	    	TctDownRegEntity downReg = downRegEAO.retrieveLatestDownloadID();
	    	/*
	    	 * INSERT LAST_DOWNLOAD_ID/RUN_ID INTO DOWNLOAD_RUN_CORR
	    	 */
	    	TctDownRunEntity downRun = new TctDownRunEntity();
	    	TctDownRunEntityPK dRPk = new TctDownRunEntityPK();
	    	dRPk.setCmpnid(companyId);
	    	dRPk.setDownloadid(downReg.getDownlaodId());
	    	dRPk.setRunid(currentRun.getRunId());
	    	downRun.setId(dRPk);
	    	downRun.setTctdownreg(downReg);
	    	downRun.setTctrunreg(currentRun);
	    	    	
	    	downRunEntityEAO.insertDownload(downRun);
	    	
	    	/*
	    	 * load clients from external resources
	    	 */
	    	List<TctClientEntity> clientsAppo = new ArrayList<TctClientEntity>();
	    	Method[] methods = this.aligner.getClass().getMethods();
	    	read: for (Method m : methods){
	    		if (m.getName().equals(company.getReadMethod())){
	    			clientsAppo = (List<TctClientEntity>)m.invoke(this.aligner, company);
	    			break read;
	    		}
	    	}
	    	
	    	write: for (Method m : methods){
	    		if (m.getName().equals(company.getWritMethod())){
	    			m.invoke(this.aligner, clientsAppo);
	    			break write;
	    		}
	    	}
	    	
	    	/*
	    	 * donwload CLIENT List filtered by COMPANY (RUNID)
	    	 */
	    	List<TctClientEntity> clients = clientEntityEAO.retrieveClientsByCompanyID(companyId);
	    	
	    	/*
	    	 * READ PREV_RUN_ID for COMPANY on the RUN_REGISTER
	    	 */
	    	TctRunRegEntity previousRun = runRegEntityEAO.retrievePreviousRun(currentRun);
	    	
	    	/*
	    	 * UPDATE the Client list with the FLAG OLD/NEW 
	    	 * comparing the RUN_ID list with the LAST_RUN_ID list
	    	 */
	    	List<TctClientHEntity> newClients = new ArrayList<TctClientHEntity>();
	    	for (TctClientEntity client : clients){ 
	    		TctClientHEntity hEntity = new TctClientHEntity();
	    		TctClientHEntityPK hEntityPk = new TctClientHEntityPK();
	    		hEntityPk.setClntid(client.getId().getClntId());
	    		hEntityPk.setCpmnid(client.getId().getCmpnId());
	    		hEntityPk.setRunid(currentRun.getRunId());
	    		
	    		hEntity.setId(hEntityPk);
	    		hEntity.setClntAlias1(client.getClntAlias1());
	    		hEntity.setClntAlias2(client.getClntAlias2());
	    		hEntity.setClntAlias3(client.getClntAlias3());
	    		hEntity.setClntName(client.getClntName());
	    		
	    		/*
	    		 * Raffaele De Lauri
	    		 * TN_CCG15506
	    		 * aggiungo il settaggio di questi attributi
	    		 */
	    		hEntity.setAbiCode(client.getAbiCode());
	    		hEntity.setAdminName(client.getAdminName());
	    		hEntity.setAdminSurn(client.getAdminSurn());
	    		hEntity.setCountry(client.getCountry());
	    		hEntity.setGroup(client.getGroup());
	    		hEntity.setIdAdmin(client.getIdAdmin());
	    		hEntity.setIdLegalRap(client.getIdLegalRap());
	    		hEntity.setLegalName(client.getLegalName());
	    		hEntity.setLegalSurna(client.getLegalSurna());
	    		/*
	    		 * fine TN_CCG15506
	    		 */
	    		hEntity.setTctclient(client);
	    		hEntity.setTctrunreg(currentRun);
	    		hEntity.setTctcompany(company);

		    	if (((previousRun!=null) && (clientHEntityEAO.retrieveClientsByRunIDAndClientName(previousRun.getRunId(), client)!=null))){
		    		client.setIsNew("N");
		    	}else{
		    		client.setIsNew("Y");
		    	}
		    	hEntity.setIsNew(client.getIsNew());
		    	newClients.add(hEntity);
	    	}
	    	
	    	/*
	    	 * STORE client list into HISOTRY CLIENT TABLE
	    	 */
	    	clientHEntityEAO.insertEntity(newClients);
	    	
	    	/*
	    	 * LOAD LAST_AGGREGATED_LIST (serialized file with LAST_DOWNLOAD_ID as prefix)
	    	 */
	    	ejbLogger.debug(new StandardLogMessage("loading aggregatedList"));
	    	TreeMap<String,TctAggrEntEntity> aggregMap = null;
	    	if (previousRun == null){
	    		ejbLogger.debug(new StandardLogMessage("no run present for company "+companyId+" than load latest aggregated list"));
	    		aggregMap = this.readPreviousAggLis(downReg.getDownlaodId());
	    	}else{
	    		Set<TctDownRunEntity> downRunEnt = previousRun.getTctdownruns();
	    		int previousDown=0;
	    		
	    		/*
	    		 * READ LAST_DOWNLOAD_ID on the DOWNLOAD_RUN_CORR
	    		 */
	    		for (TctDownRunEntity entity : downRunEnt){
	    			if ((entity.getId().getRunid()==previousRun.getRunId())&& (entity.getId().getCmpnid() == companyId)){
	    				previousDown = entity.getId().getDownloadid();
	    			}
	    		}
	    		aggregMap = this.readPreviousAggLis(previousDown);
	    	}
	    	ejbLogger.debug(new StandardLogMessage("aggregatedList loaded"));
	    	
	    	/*
	    	 * TRAIN SecondoString SoftTF_IDF with CLIENTS, ALIAS, AGGREGATED_LIST (full lists)
	    	 */
	    	ejbLogger.debug(new StandardLogMessage("train second string"));
	    	this.finder.trainSecondString(aggregMap.keySet(), clients);

	    	/*
	    	 * LOAD per company FALSE_POSITIVE list into a TreeSet (concatenate client/terrorist)
	    	 */
	    	ejbLogger.debug(new StandardLogMessage("load false positive"));
	    	TreeSet<String> fPositiveCorrisp = this.corrispEntityEAO.retrieveFPositiveByCompanyID(companyId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("asynchronous part"));
	    	
	    	/*
	    	 * CYCLE CLIENTS
	    	 */
	    	List<TctCorrispEntity> corrisps = new ArrayList<TctCorrispEntity>();
	    	List<Future<List<TctCorrispEntity>>> results = new ArrayList<Future<List<TctCorrispEntity>>>();
	    	analisysChecher = this.analysisController.checkStatus(clients.size());
	    	for (TctClientEntity c : clients){
	    		Future<List<TctCorrispEntity>> tempResult = this.finder.analyze(c, aggregMap, currentRun, fPositiveCorrisp, thrsld1, thrsld2);
	    		results.add(tempResult);
	    	}
	    	
	    	for (Future<List<TctCorrispEntity>> r : results){
	    		List<TctCorrispEntity> tempCorrisp = r.get();
				corrisps.addAll(tempCorrisp);
	    	}	    	
	    	
	    	/*
	    	 * LOAD FALSE_NEGATIVE list and ADD to MATCHING CORRESPONDENCES  
	    	 */
	    	ejbLogger.debug("load false negative");
	    	/*
	    	 * raffaele de lauri
	    	 * TN_CCG15575
	    	 * send also correspondence list
	    	 */
	    	corrisps.addAll(this.translateFalseNegativeToCorrisp(companyId, currentRun, aggregMap, corrisps));
	    	ejbLogger.debug("match entries total number "+corrisps.size());
	    	ejbLogger.debug(new StandardLogMessage("store historical false negative"));
	    	/*
	    	 * STORE False negative list into HISTORICAL TABLE
	    	 */
	    	this.historicizeFalseNegative(companyId, currentRun/*, aggregMap*/);
	    	ejbLogger.debug(new StandardLogMessage("store corrispondences"));
	    	this.corrispEntityEAO.insertEntity(corrisps);
	    	
	    	ejbLogger.debug("matches "+corrisps.size());
	    	matchFound:for (TctCorrispEntity entity : corrisps){
	    		if (entity.getStatus().equalsIgnoreCase("O")){
	    			runEntity.setMatchFound("T");
	    			runEntity.setReport("F");
	    			break matchFound;
	    		}
	    	}
	    	/*
	    	 * GENERATE REPORT
	    	 */
	    	ejbLogger.debug(new StandardLogMessage("send report"));
	    	this.notificationSender.sendPossibleMatches(corrisps, company);
	    	
	    	ejbLogger.info(new StandardCheckPointMessage("Find matches flow terminated "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	} catch (InterruptedException e) {
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Find matches flow terminated with errors: "+e.getMessage()));
			/*
			 * Raffaele De Lauri
			 * TN_CCG14897
			 */
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3Find matches flow terminated with errors: "+e.getMessage());
			throw new BackEndException(e.getMessage());
		} catch (ExecutionException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Find matches flow terminated with errors: "+e.getMessage()));
			/*
			 * Raffaele De Lauri
			 * TN_CCG14897
			 */
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3Find matches flow terminated with errors: "+e.getMessage());
			throw new BackEndException(e.getMessage());
		}catch (IllegalAccessException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Find matches flow terminated with errors: "+e.getMessage()));
			/*
			 * Raffaele De Lauri
			 * TN_CCG14897
			 */
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3Find matches flow terminated with errors: "+e.getMessage());
			if (analisysChecher!=null) analisysChecher.cancel(true);
			throw new BackEndException(e.getMessage());
		}catch (IllegalArgumentException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Find matches flow terminated with errors: "+e.getMessage()));
			/*
			 * Raffaele De Lauri
			 * TN_CCG14897
			 */
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3Find matches flow terminated with errors: "+e.getMessage());
			throw new BackEndException(e.getMessage());
		}catch (InvocationTargetException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Find matches flow terminated with errors: "+e.getMessage()));
			/*
			 * Raffaele De Lauri
			 * TN_CCG14897
			 */
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3Find matches flow terminated with errors: "+e.getMessage());
			if (analisysChecher!=null) analisysChecher.cancel(true);
			throw new BackEndException(e.getMessage());
		}catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Find matches flow terminated with errors: "+e.getMessage()));
			/*
			 * Raffaele De Lauri
			 * TN_CCG14897
			 */
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3Find matches flow terminated with errors: "+e.getMessage());
			throw e;
		}catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Find matches flow terminated with errors: "+e.getMessage()));
			/*
			 * Raffaele De Lauri
			 * TN_CCG14897
			 */
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3Find matches flow terminated with errors: "+e.getMessage());
			throw e;
		}finally{
			if (analisysChecher!=null) {
				boolean cancel = analisysChecher.cancel(true);
				ejbLogger.debug("analisysChecher stopped "+cancel);
			}
		}
    }
    
    /**
     * Admission control find match method
     * @param companyId
     * @param clientNames
     * @throws BackEndException
     */
    public void startFindMatch(int companyId,String... clientNames) throws BackEndException{
    	ejbLogger.debug("in void startFindMatch(int companyId,String... clientNames)");
    	ejbLogger.info(new StandardCheckPointMessage("Start find matches flow for admission "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	ejbLogger.debug("companyId "+companyId);
    	try {
    		/*
    		 * LOAD THRESHOLDS (for company/risk profile)
    		 */
	    	TctCompanyEntity company = companyEntityEAO.retrieveCompanyByCompanyId(companyId);
			
			double thrsld1=0,thrsld2=0;
			switch (company.getRiskProf()){
				case "hr":
					thrsld1 = company.getThrsldHr1().doubleValue();
					thrsld2 = company.getThrsldHr2().doubleValue();
					break;
				case "mr":
					thrsld1 = company.getThrsldMr1().doubleValue();
					thrsld2 = company.getThrsldMr2().doubleValue();
					break;
				case "lr":
					thrsld1 = company.getThrsldLr1().doubleValue();
					thrsld2 = company.getThrsldLr2().doubleValue();
					break;
			}
			ejbLogger.debug(new StandardLogMessage("thresholds loaded"));
			
			/*
			 * READ LAST_DOWNLOAD_ID on the  DOWNLOAD_REG
			 */
			TctDownRegEntity downReg = downRegEAO.retrieveLatestDownloadID();
			
			/*
			 * LOAD LAST_AGGREGATED_LIST (serialized file with LAST_DOWNLOAD_ID as prefix)	
			 */
			ejbLogger.debug(new StandardLogMessage("loading aggregatedList"));
			TreeMap<String,TctAggrEntEntity> aggregMap = null;
			aggregMap = this.readPreviousAggLis(downReg.getDownlaodId());
			ejbLogger.debug(new StandardLogMessage("aggregatedList loaded"));
			
			/*
			 * TRAIN secondString SoftTf_IDF with CLIENTS_NAMES parameter and AGGREGATED_LIST (full list)
			 */
			ejbLogger.debug(new StandardLogMessage("train second string"));
			this.finder.trainSecondString(aggregMap.keySet(), clientNames);
			
			/*
			 * DELETE previous CORRLIST results 
			 */
			ejbLogger.debug(new StandardLogMessage("delete previous record for company "+company.getCmpnId()));
			this.tctCorrLstEntityEAO.deleteEveryEntity(company.getCmpnId());
			
   	
			List<TctCorrLstEntity> corrisps = new ArrayList<TctCorrLstEntity>();
			/*
			 * EXECUTE Soft TF-IDF on the CLIENTS_NAME parameter/TERRORIST couple
			 */
			List<TctCorrLstEntity> tempCorrisp = this.finder.analyze(aggregMap, company, thrsld1, thrsld2,clientNames);
			
			corrisps.addAll(tempCorrisp);
			
			ejbLogger.debug("matches "+corrisps.size());
			
			ejbLogger.debug(new StandardLogMessage("store corrispondences"));
			/*
			 * INSERT CORRLIST
			 */
			this.tctCorrLstEntityEAO.insertEntity(corrisps);
			
			ejbLogger.info(new StandardCheckPointMessage("Find matches flow for admission terminated "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date()))); 
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Find matches flow for admission terminated with errors: "+e.getMessage()));
			/*
			 * Raffaele De Lauri
			 * TN_CCG14897
			 */
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3Find matches flow for admission terminated with errors: "+e.getMessage());
			throw e;
		}
    }
    
    /**
     * Optimization analisys flow
     * @param companyId
     * @throws BackEndException
     */
    public void startOptimization(int companyId) throws BackEndException{
    	ejbLogger.debug("in void startOptimization(int companyId)");
    	
    	ejbLogger.info(new StandardCheckPointMessage("Start optimization flow "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	ejbLogger.debug("companyId "+companyId);
    	Future<Boolean> optimizerChecker =null;
    	try {
    		optimizEntityEAO.deleteEveryEntity();
    		List<TctOptimizEntity> optimization = new ArrayList<TctOptimizEntity>();
    		if (companyId > 0){
		    	   	    	
		    	TctDownRegEntity downReg = downRegEAO.retrieveLatestDownloadID();
		     	List<TctClientEntity> clients = clientEntityEAO.retrieveClientsByCompanyID(companyId);
		    	
		    	TreeMap<String,TctAggrEntEntity> aggregMap = null;
		    	
	    		ejbLogger.debug(new StandardLogMessage("load latest aggregated list"));
	    		aggregMap = this.readPreviousAggLis(downReg.getDownlaodId());
		    	
		    	ejbLogger.debug(new StandardLogMessage("aggregatedList loaded"));
		    	
		    	ejbLogger.debug(new StandardLogMessage("train second string"));
		    	String jarowinklerOptimizationThrshld = SystemProperties.getSystemProperty("jarowinkler.thrshld.optim");
		    	String[] optimizationThrshldString = jarowinklerOptimizationThrshld.split("\\|");
		    	/*
		    	 * ciclo per ogni valore presente sul properties
		    	 */
		    	optimizerChecker = this.optimizationController.checkStatus(clients.size());
		    	/*
		    	 * ticket 14888
		    	 */
		    	int itId = 0;
		    	for (String s : optimizationThrshldString){
		    		itId++;
		    		Double jaroWinklerThrshld = new Double(s);
		    		this.finder.trainSecondStringForOptimization(aggregMap.keySet(),clients,jaroWinklerThrshld);
			    	
			    	ejbLogger.debug(new StandardLogMessage("asynchronous part"));

			    	
			    	List<Future<List<TctOptimizEntity>>> results = new ArrayList<Future<List<TctOptimizEntity>>>();
			    	for (TctClientEntity c : clients){
			    		Future<List<TctOptimizEntity>> tempResult = this.finder.optimize(c, aggregMap,jaroWinklerThrshld,itId);
			    		results.add(tempResult);
			    	}
			    	
			    	for (Future<List<TctOptimizEntity>> r : results){
			    		List<TctOptimizEntity> tempOptim = r.get();
			    		optimization.addAll(tempOptim);
			    	}
		    	}
    		}else{
    			TctDownRegEntity downReg = downRegEAO.retrieveLatestDownloadID();
		     	List<TctClientEntity> clients = clientEntityEAO.retrieveAllClients();
		    	
		    	TreeMap<String,TctAggrEntEntity> aggregMap = null;
		    	
	    		ejbLogger.debug(new StandardLogMessage("load latest aggregated list"));
	    		aggregMap = this.readPreviousAggLis(downReg.getDownlaodId());
		    	
		    	ejbLogger.debug(new StandardLogMessage("aggregatedList loaded"));
		    	
		    	ejbLogger.debug(new StandardLogMessage("train second string"));
		    	String jarowinklerOptimizationThrshld = SystemProperties.getSystemProperty("jarowinkler.thrshld.optim");
		    	String[] optimizationThrshldString = jarowinklerOptimizationThrshld.split("|");
		    	/*
		    	 * ciclo per ogni valore presente sul properties
		    	 */
		    	optimizerChecker = this.optimizationController.checkStatus(clients.size());
		    	/*
		    	 * ticket 14888
		    	 */
		    	int itId = 0;
		    	for (String s : optimizationThrshldString){
		    		itId++;
		    		Double jaroWinklerThrshld = new Double(s);
		    		this.finder.trainSecondStringForOptimization(aggregMap.keySet(),clients,jaroWinklerThrshld);
			    	ejbLogger.debug(new StandardLogMessage("load false positive"));
			    	
			    	ejbLogger.debug(new StandardLogMessage("asynchronous part"));
			    	
			    	List<Future<List<TctOptimizEntity>>> results = new ArrayList<Future<List<TctOptimizEntity>>>();
			    	for (TctClientEntity c : clients){
			    		Future<List<TctOptimizEntity>> tempResult = this.finder.optimize(c, aggregMap,jaroWinklerThrshld,itId);
			    		results.add(tempResult);
			    	}
			    	
			    	for (Future<List<TctOptimizEntity>> r : results){
			    		List<TctOptimizEntity> tempOptim = r.get();
			    		optimization.addAll(tempOptim);
			    	}
		    	}
    		}
    		ejbLogger.debug("optimized "+optimization.size());
    		ejbLogger.debug(new StandardLogMessage("store optimizations"));
    		this.optimizEntityEAO.insertEntity(optimization);
	    	ejbLogger.info(new StandardCheckPointMessage("Optimization flow terminated "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	} catch (InterruptedException e) {
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Optimization flow terminated with errors: "+e.getMessage()));
			/*
			 * Raffaele De Lauri
			 * TN_CCG14897
			 */
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3Optimization flow terminated with errors: "+e.getMessage());
			if (optimizerChecker!=null) optimizerChecker.cancel(true);
			throw new BackEndException(e.getMessage());
		} catch (ExecutionException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Optimization flow terminated with errors: "+e.getMessage()));
			/*
			 * Raffaele De Lauri
			 * TN_CCG14897
			 */
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3Optimization flow terminated with errors: "+e.getMessage());
			if (optimizerChecker!=null) optimizerChecker.cancel(true);
			throw new BackEndException(e.getMessage());
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Optimization flow terminated with errors: "+e.getMessage()));
			/*
			 * Raffaele De Lauri
			 * TN_CCG14897
			 */
			sysLogger.error("PAMPTEAM|0"+LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2599|3Optimization flow terminated with errors: "+e.getMessage());
			if (optimizerChecker!=null) optimizerChecker.cancel(true);
			throw e;
		}finally{
			if (optimizerChecker!=null) {
				boolean cancel = optimizerChecker.cancel(true);
				ejbLogger.debug("optimizerChecker stopped "+cancel);
			}
		}
    }
    
    /**
     * 
     * @param downloadID - <code>int</code>
     * @return
     * @throws BackEndException
     */
    private TctSrcUpDtEntity [] retrieveTerroristData(int downloadID) throws BackEndException{
    	ejbLogger.info(new StandardCheckPointMessage("Retrieve terrorism data start "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	/*
    	 * DOWNLOAD AND SAVE OFAC xml file (DOWNLOAD_ID)
    	 */
    	Future<TctSrcUpDtEntity> ofacData = ofacSourceHandler.getData(this.sessionContext.getCallerPrincipal().getName(),downloadID);
    	/*
    	 * DOWNLOAD AND SAVE EC xml file (DOWNLOAD_ID)
    	 */
    	Future<TctSrcUpDtEntity> ecData = ecSourceHandler.getData(this.sessionContext.getCallerPrincipal().getName(),downloadID);
    	/*
    	 * DOWNLOAD AND SAVE UN xml file (DOWNLOAD_ID)
    	 */
    	Future<TctSrcUpDtEntity> unData = unSourceHandler.getData(this.sessionContext.getCallerPrincipal().getName(),downloadID);
    	
    	TctSrcUpDtEntity ofResult=null ,ecResult=null,unResult = null;
    	TctSrcUpDtEntity [] results = new TctSrcUpDtEntity[3];
    	try {
    		/*
    		 * wait for thread completion 
    		 */
    		while (!ofacData.isDone()){
    			Thread.sleep(60000);
    		}
    		while (!ecData.isDone()){
    			Thread.sleep(60000);
    		}
    		while (!unData.isDone()){
    			Thread.sleep(60000);
    		}

    		ofResult = ofacData.get();
			ecResult = ecData.get();
	    	unResult = unData.get();
	    	
	    	results[0] = ofResult;
	    	results[1] = ecResult;
	    	results[2] = unResult;
	    	
		} catch (InterruptedException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Retrieve terrorism data completed with errors: "+e.getMessage()));
			throw new BackEndException(e.getMessage());
		} catch (ExecutionException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Retrieve terrorism data completed with errors: "+e.getMessage()));
			throw new BackEndException(e.getMessage());
		}
    	ejbLogger.info(new StandardLogMessage("ofResult "+ofResult+" ecResult "+ecResult+" unResult "+unResult));
    	ejbLogger.info(new StandardCheckPointMessage("Retrieve terrorism data completed "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())));
    	return results;
    	
    }
    
    /**
     * Read previous aggregated's treemap serialized on file stystem
     * @param prevDownloadId - <code>int</code>
     * @return aggregated treemap - <code>TreeMap<String,TctAggrEntEntity></code> 
     * @throws BackEndException
     */
    @SuppressWarnings("unchecked")
	private TreeMap<String,TctAggrEntEntity> readPreviousAggLis(int prevDownloadId) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in TreeMap<String,TctAggrEntEntity> readPreviousAggLis(int prevDownloadId)"));
		FileInputStream streamIn;
		TreeMap<String,TctAggrEntEntity> prevTreeSet = null;
		try {
			streamIn = new FileInputStream(this.treeSetPath+System.getProperty("file.separator")+prevDownloadId+".treemap");
	        ObjectInputStream objectinputstream = new ObjectInputStream(streamIn);
	        prevTreeSet = (TreeMap<String,TctAggrEntEntity>) objectinputstream.readObject();
		} catch (FileNotFoundException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.debug(new StandardLogMessage("Error in readPreviousAggLis: "+e.getMessage()));
			/*
			 * raffaele de lauri
			 * TN_CCG14891
			 */
			TreeMap<String,TctAggrEntEntity> appo = this.aggrEntityEAO.getTreeMapByDonwloadId(prevDownloadId);
			this.writeCurrentAggLis(prevDownloadId, appo);
			
			return appo;
			/*
			 * fine 
			 * TN_CCG14891
			 */
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.debug(new StandardLogMessage("Error in readPreviousAggLis: "+e.getMessage()));
			throw new BackEndException(e.getMessage());
		} catch (ClassNotFoundException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.debug(new StandardLogMessage("Error in readPreviousAggLis: "+e.getMessage()));
			throw new BackEndException(e.getMessage());
		}
        return prevTreeSet;
    }
    
    /**
     * Serialize aggregated's treemap on file system
     * @param DownloadId - <code>int</code>
     * @param currentTreeMap - <code>TreeMap<String,TctAggrEntEntity></code>  
     * @throws BackEndException
     */
    private void writeCurrentAggLis(int DownloadId,TreeMap<String,TctAggrEntEntity> currentTreeSet) throws BackEndException{
    	ejbLogger.debug("in void writeCurrentAggLis(int DownloadId,TreeMap<String,TctAggrEntEntity> currentTreeSet)");
		try {
			FileOutputStream fout = new FileOutputStream(this.treeSetPath+System.getProperty("file.separator")+DownloadId+".treemap");
	    	ObjectOutputStream oos = new ObjectOutputStream(fout);
	    	oos.writeObject(currentTreeSet);
		} catch (FileNotFoundException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.debug(new StandardLogMessage("Error in readPreviousAggLis: "+e.getMessage()));
			throw new BackEndException(e.getMessage());
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.debug(new StandardLogMessage("Error in readPreviousAggLis: "+e.getMessage()));
			throw new BackEndException(e.getMessage());
		}
    }
    
    /**
     * Store source file method
     * @param download - <code>TctDownRegEntity</code>
     * @throws BackEndException
     */
    private void storeSrcFile(TctDownRegEntity download) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in storeSrcFile(TctDownRegEntity download)"));
    	try {
	    	TctSrcFlHEntity srcFl = new TctSrcFlHEntity();
			srcFl.setDownloadDt(new Date(download.getDownloadDt().getTime()));
			srcFl.setDownloadid(download.getDownlaodId());
			Path ecPath = Paths.get(SystemProperties.getSystemProperty("ec.file.name"));
			Path unPath = Paths.get(SystemProperties.getSystemProperty("un.file.name"));
			Path ofacPath = Paths.get(SystemProperties.getSystemProperty("ofac.file.name"));
			
			byte[] ecData = Files.readAllBytes(ecPath);
			byte[] unData = Files.readAllBytes(unPath);
			byte[] ofacData = Files.readAllBytes(ofacPath);
			
			ejbLogger.debug(new StandardLogMessage("ecData size" +ecData.length));
			ejbLogger.debug(new StandardLogMessage("unData sie" +unData.length));
			ejbLogger.debug(new StandardLogMessage("ofacData size" +ofacData.length));
			srcFl.setEcFile(ecData);
			srcFl.setOfacFile(ofacData);
			srcFl.setUnFile(unData);
			this.tctSrcFlEAO.insertDownload(srcFl);
			
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardLogMessage("error in storeSrcFile: "+e.getMessage()));
			throw new BackEndException(e);
		}
    }
    
    /**
     * Historicize false negative method
     * @param companyId - <code>int</code>
     * @param currentRun - <code>TctRunRegEntity</code>
     * @param aggregMap - <code>TreeMap<String,TctAggrEntEntity></code>
     * @throws BackEndException
     */
    private void historicizeFalseNegative(int companyId,TctRunRegEntity currentRun/*,TreeMap<String,TctAggrEntEntity> aggregMap*/) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in List<TctCorrispEntity> translateFalseNegativeToCorrisp()"));
    	ejbLogger.info(new StandardCheckPointMessage("Start historicize false negative"));
    	try {
	    	List<TctFalNegtEntity> fNegative = this.falsNegtEntityEAO.retrieveFalseNegativeByCompanyID(companyId);
	    	List<TctFalNegHEntity> fNegativeHList = new ArrayList<TctFalNegHEntity>();
	    	for (TctFalNegtEntity fneg : fNegative){
	    		TctFalNegHEntity fNegatH = new TctFalNegHEntity(); 
	    		TctFalNegHEntityPK pk = new TctFalNegHEntityPK();
	    		pk.setAggrid(fneg.getId().getAggrId());
	    		pk.setClntid(fneg.getId().getClntid());
	    		pk.setCompnid(fneg.getId().getCmpnid());
	    		pk.setRunid(currentRun.getRunId());
	    		pk.setDownloadid(fneg.getId().getDownloadid());
	    		fNegatH.setId(pk);
	    		
	    		fNegatH.setNote(fneg.getNote());
	    		fNegatH.setSource(fneg.getSource());
	    		fNegatH.setEntityName(fneg.getEntityName());
	    		fNegatH.setTctaggrent(fneg.getTctaggrent());
	    		fNegatH.setTctcompany(fneg.getTctcompany());
	    		fNegatH.setTctfalnegt(fneg);
	    		fNegatH.setTctrunreg(currentRun);
	    		fNegativeHList.add(fNegatH);
	    	}
	    	
	    	
			this.falNegHEntityEAO.insertEntity(fNegativeHList);
			
	    	ejbLogger.info(new StandardCheckPointMessage("Historicize false negative completed"));
    	} catch (BackEndException e) {
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.info(new StandardCheckPointMessage("Historicize false negative completed with errors: "+e.getMessage()));
			throw new BackEndException(e.getMessage());
		}
    }
    
    /**
     * Translate false negative entities into corrispondece entities
     * @param companyId - <code>int</code>
     * @param currentRun - <code>TctRunRegEntity</code>
     * @param aggregMap - <code>TreeMap<String,TctAggrEntEntity></code>
     * @return <code>List<TctCorrispEntity></code>
     * @throws BackEndException
     */
    private List<TctCorrispEntity> translateFalseNegativeToCorrisp(int companyId,TctRunRegEntity currentRun,TreeMap<String,TctAggrEntEntity> aggregMap, List<TctCorrispEntity> realCorrisps) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in List<TctCorrispEntity> translateFalseNegativeToCorrisp()"));
    	List<TctFalNegtEntity> fNegative = this.falsNegtEntityEAO.retrieveFalseNegativeByCompanyID(companyId);
    	List<TctCorrispEntity> corrispList = new ArrayList<TctCorrispEntity>();
    	for (TctFalNegtEntity fneg : fNegative){
    		TctClientEntity client = this.clientEntityEAO.retrieveClientsByClientIdAndCompanyId(fneg.getId().getCmpnid(), fneg.getId().getClntid());
    		
    		TctCorrispEntity corrisp = new TctCorrispEntity();
    		TctCorrispEntityPK pk = new TctCorrispEntityPK();
    		pk.setAggrId(fneg.getId().getAggrId());
    		pk.setClntid(fneg.getId().getClntid());
    		pk.setCmpnid(fneg.getId().getCmpnid());
    		pk.setDownloadid(fneg.getId().getDownloadid());
    		pk.setRunId(currentRun.getRunId());
    		
    		corrisp.setId(pk);
    		corrisp.setEntityName(fneg.getEntityName());
    		corrisp.setClntName(client.getClntName());
    		corrisp.setCorrIndex(new BigDecimal(1));
    		corrisp.setStatus("O");
    		corrisp.setTctrunreg(currentRun);
    		/*
			 * raffaele de lauri
			 * TN_CCG15280
			 */
    		corrisp.setTctaggrent(aggregMap.get(fneg.getEntityName()+"%"+fneg.getSource()));
    		corrisp.setTctclient(client); 
    		/*
    		 * raffaele de lauri
    		 * TN_CCG15575
    		 * check if the correspondence already exist
    		 */
    		if (realCorrisps.indexOf(corrisp)>-1){
    			realCorrisps.remove(corrisp);
    		}
    		
    		corrispList.add(corrisp);
    	}
    	
    	return corrispList;
    }
}
