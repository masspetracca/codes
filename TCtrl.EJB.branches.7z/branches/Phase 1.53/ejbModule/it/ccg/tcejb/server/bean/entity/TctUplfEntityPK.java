package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTUPLF database table.
 * 
 */
@Embeddable
public class TctUplfEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private int uplid;

	private int runid;

	public TctUplfEntityPK() {
	}
	public int getUplid() {
		return this.uplid;
	}
	public void setUplid(int uplid) {
		this.uplid = uplid;
	}
	public int getRunid() {
		return this.runid;
	}
	public void setRunid(int runid) {
		this.runid = runid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctUplfEntityPK)) {
			return false;
		}
		TctUplfEntityPK castOther = (TctUplfEntityPK)other;
		return 
			(this.uplid == castOther.uplid)
			&& (this.runid == castOther.runid);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.uplid;
		hash = hash * prime + this.runid;
		
		return hash;
	}
}