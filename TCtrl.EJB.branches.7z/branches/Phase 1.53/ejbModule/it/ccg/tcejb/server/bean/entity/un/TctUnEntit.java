package it.ccg.tcejb.server.bean.entity.un;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTUNENTIT database table.
 * 
 */
@Entity
@Table(name="TCTUNENTIT")
@NamedQueries({
	@NamedQuery(name="getUnEntitiesById", query="SELECT entity FROM TctUnEntit entity WHERE entity.dataId = :dataId ORDER BY entity.dataId ASC"),
	@NamedQuery(name="getUnEntities", query="SELECT entity FROM TctUnEntit entity ORDER BY entity.dataId ASC"),
	@NamedQuery(name="getUnEntitiesBySrcListDate", query="SELECT entity " +
			   "										 FROM TctUnEntit entity " +
			   "										WHERE entity.dateGenerated = :srcListDate " +
			   "										ORDER BY entity.dataId ASC"),
    @NamedQuery(name="getUnLatestSrcListDate",    query="SELECT MAX(entity.releasedDt) " +
	           "										   FROM TctUnEntit entity"),
	/*
	 * raffaele de lauri
	 * TN_CCG15298
	 */
    @NamedQuery(name="getUnLatestEntities", query="SELECT entity " +
               "								     FROM TctUnEntit entity " +
               "								    WHERE entity.releasedDt = (SELECT MAX(entity2.releasedDt) " +
               "								 							  FROM TctUnEntit entity2)" +
    		   "								    ORDER BY entity.dataId ASC"),
    @NamedQuery(name="deleteUnEveryEntity", query="DELETE FROM TctUnEntit")
})
public class TctUnEntit implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@Id
	@Column(unique=true, nullable=false, name="DATAID")
	private int dataId;

	@Column(length=1000)
	private String comments1;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date dateGenerated;

	@Column(nullable=false, length=255)
	private String firstName;

	@Column(nullable=false)
	private Timestamp listedOn;

	@Column(nullable=false, length=50)
	private String refNumber;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date releasedDt;
    
    @Column(length=255)
	private String nOrgScript;

	@Column(length=50)
	private String secondName;

	@Column(nullable=true, length=255)
	private String sortKey;

	@Column(nullable=true)
	private Timestamp sortKeyLsMod;

	@Column(length=50)
	private String thirdName;

	@Column(nullable=false, length=50)
	private String unListTp;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=10)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	//bi-directional many-to-one association to TctUnAddr
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunentit")
	//@Transient
	private Set<TctUnAddr> tctunaddrs;

	//bi-directional many-to-one association to TctUnAlia
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunentit")
	//@Transient
	private Set<TctUnAlia> tctunalias;

	/*//bi-directional many-to-one association to TctUnLisTp
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunentit")*/
	//@Transient
	//private Set<TctUnLisTp> tctunlistps;

	//bi-directional many-to-one association to TctUnLstUp
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunentit")
	//@Transient
	private Set<TctUnLstUp> tctunlstups;

	/*@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunentit")
	private Set<TctAggrEntEntity> tctaggrents;*/
	
    public TctUnEntit() {
    }

	public int getDataId() {
		return this.dataId;
	}

	public void setDataId(int dataId) {
		this.dataId = dataId;
	}

	public String getComments1() {
		return this.comments1;
	}

	public void setComments1(String comments1) {
		if (comments1 != null && comments1.length()>1000){
			ejbLogger.debug(comments1+" >1000 than truncate");
			this.comments1 = comments1.substring(0, 999);
		}else{
			this.comments1 = comments1;
		}
	}

	public Date getDateGenerated() {
		return this.dateGenerated;
	}

	public void setDateGenerated(Date dateGenerated) {
		this.dateGenerated = dateGenerated;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		if (firstName != null && firstName.length()>255){
			ejbLogger.debug(firstName+" >255 than truncate");
			this.firstName = firstName.substring(0, 254);
		}else{
			this.firstName = firstName;
		}
	}

	public Timestamp getListedOn() {
		return this.listedOn;
	}

	public void setListedOn(Timestamp listedOn) {
		this.listedOn = listedOn;
	}

	public String getRefNumber() {
		return this.refNumber;
	}

	public void setRefNumber(String refNumber) {
		if (refNumber != null && refNumber.length()>50){
			ejbLogger.debug(refNumber+" >50 than truncate");
			this.refNumber = refNumber.substring(0, 49);
		}else{
			this.refNumber = refNumber;
		}
	}

	public Date getReleasedDt() {
		return this.releasedDt;
	}

	public void setReleasedDt(Date releasedDt) {
		this.releasedDt = releasedDt;
	}

	public String getSecondName() {
		return this.secondName;
	}

	public void setSecondName(String secondName) {
		if (secondName != null && secondName.length()>50){
			ejbLogger.debug(secondName+" >50 than truncate");
			this.secondName = secondName.substring(0, 49);
		}else{
			this.secondName = secondName;
		}
		
	}

	public String getSortKey() {
		return this.sortKey;
	}

	public void setSortKey(String sortKey) {
		if (sortKey !=null && sortKey.length()>255){
			ejbLogger.debug(sortKey+" >255 than truncate");
			this.sortKey = sortKey.substring(0, 254);
		}else{
			this.sortKey = sortKey;
		}
	}

	public Timestamp getSortKeyLsMod() {
		return this.sortKeyLsMod;
	}

	public void setSortKeyLsMod(Timestamp sortKeyLsMod) {
		this.sortKeyLsMod = sortKeyLsMod;
	}

	public String getThirdName() {
		return this.thirdName;
	}

	public void setThirdName(String thirdName) {
		if (thirdName != null && thirdName.length()>50){
			ejbLogger.debug(sortKey+" >50 than truncate");
			this.thirdName = thirdName.substring(0, 49);
		}else{
			this.thirdName = thirdName;
		}
	}

	public String getUnListTp() {
		return this.unListTp;
	}

	public void setUnListTp(String unListTp) {
		if (unListTp != null && unListTp.length()>50){
			ejbLogger.debug(unListTp+" >50 than truncate");
			this.unListTp = unListTp.substring(0, 49);
		}else{
			this.unListTp = unListTp;
		}
	}
	
	/**
	 * @return the nOrgScript
	 */
	public String getnOrgScript() {
		return nOrgScript;
	}

	/**
	 * @param nOrgScript the nOrgScript to set
	 */
	public void setnOrgScript(String nOrgScript) {
		if (nOrgScript != null && nOrgScript.length()>255){
			ejbLogger.debug(nOrgScript+" >255 than truncate");
			this.nOrgScript = nOrgScript.substring(0, 254);
		}else{
			this.nOrgScript = nOrgScript;
		}
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public Set<TctUnAddr> getTctunaddrs() {
		return this.tctunaddrs;
	}

	public void setTctunaddrs(Set<TctUnAddr> tctunaddrs) {
		this.tctunaddrs = tctunaddrs;
	}
	
	public Set<TctUnAlia> getTctunalias() {
		return this.tctunalias;
	}

	public void setTctunalias(Set<TctUnAlia> tctunalias) {
		this.tctunalias = tctunalias;
	}
	
	public Set<TctUnLstUp> getTctunlstups() {
		return this.tctunlstups;
	}

	public void setTctunlstups(Set<TctUnLstUp> tctunlstups) {
		this.tctunlstups = tctunlstups;
	}
}