package it.ccg.tcejb.server.bean.eao.view;

import java.util.HashMap;
import it.ccg.tcejb.server.util.UserActionDto;

public interface UserActionReportEAORemote {

	public HashMap<String, UserActionDto> getActionReport() throws Exception;
}
