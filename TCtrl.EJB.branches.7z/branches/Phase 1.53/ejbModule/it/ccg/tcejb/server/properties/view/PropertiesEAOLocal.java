package it.ccg.tcejb.server.properties.view;

import it.ccg.tcejb.server.exception.PropertyException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

public interface PropertiesEAOLocal {

	public void loadProperties() throws PropertyException;
	
	public HashMap<String,String> getPropertyMap() throws PropertyException;
	
	public HashMap<String,String> refreshPropertyMap() throws PropertyException;
	
}
