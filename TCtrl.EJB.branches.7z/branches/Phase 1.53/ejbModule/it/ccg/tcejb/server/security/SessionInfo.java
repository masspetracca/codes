package it.ccg.tcejb.server.security;

import it.ccg.tcejb.server.security.view.SessionInfoLocal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class SessionInfo
 */
@Stateless
@Local(SessionInfoLocal.class)
@LocalBean
public class SessionInfo implements SessionInfoRemote, SessionInfoLocal {
	
	Logger log = Logger.getLogger("it.ccg.pamp.server.log.UserLog");
	
	private static Map<String, SessionUser> loggedUsersMap = null;
	
	
	@Resource
	private SessionContext sessionContext;
	
	private String[] ROLES = {"user", "visitor", "admin", "manager", "causer", "supervisor", "ccpamanagement"};


    /**
     * Default constructor. 
     */
    public SessionInfo() {
    	
    	if(loggedUsersMap == null) {
    		
    		loggedUsersMap = new HashMap<String, SessionUser>();
    	}
    }

    
    
	@Override
	public void addLoggedUser(String userName) throws Exception {
		
		loggedUsersMap.put(userName, new SessionUser(userName));
		
		//log.info("User \'" + userName + "\' added to logged users list.");
	}
	
	
	@Override
	public void removeLoggedUser(String userName) throws Exception {
		
		loggedUsersMap.remove(userName);
		
		//log.info("User \'" + userName + "\' removed from logged users list.");
	}


	@Override
	public List<SessionUser> listLoggedUsers() throws Exception {
		
		List<SessionUser> loggedUsersList = new ArrayList<SessionUser>();
		
		Set<String> keySet = loggedUsersMap.keySet();
		for(String key : keySet) {
			
			loggedUsersList.add(loggedUsersMap.get(key));
		}
		
		return loggedUsersList;
	}
    
    


	@Override
	public String getCurrentUser() throws Exception {
		
		String currentUser = this.sessionContext.getCallerPrincipal().getName();
			
		if(currentUser.equalsIgnoreCase("UNAUTHENTICATED")) {
			
			currentUser = "WAS";
		}
		
		return currentUser;
	}
    
	
    
	public List<String> getCurrentUserRoles() throws Exception {
		
		List<String> userRoles = new ArrayList<String>();
		
		for(String role : ROLES) {
			
			if(this.sessionContext.isCallerInRole(role)) {
				
				userRoles.add(role);
			}
		}
		
		return userRoles;
	}


    

}