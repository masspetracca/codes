package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTCORRISP database table.
 * 
 */
@Embeddable
public class TctCorrispEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int runId;

	@Column(unique=true, nullable=false)
	private int clntid;

	@Column(unique=true, nullable=false, length=20)
	private String aggrId;

	@Column(unique=true, nullable=false)
	private int cmpnid;

	@Column(unique=true, nullable=false)
	private int downloadid;

    public TctCorrispEntityPK() {
    }
	public int getRunId() {
		return this.runId;
	}
	public void setRunId(int runId) {
		this.runId = runId;
	}
	public int getClntid() {
		return this.clntid;
	}
	public void setClntid(int clntid) {
		this.clntid = clntid;
	}
	public String getAggrId() {
		return this.aggrId;
	}
	public void setAggrId(String aggrId) {
		this.aggrId = aggrId;
	}
	public int getCmpnid() {
		return this.cmpnid;
	}
	public void setCmpnid(int cmpnid) {
		this.cmpnid = cmpnid;
	}
	public int getDownloadid() {
		return this.downloadid;
	}
	public void setDownloadid(int downloadid) {
		this.downloadid = downloadid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctCorrispEntityPK)) {
			return false;
		}
		TctCorrispEntityPK castOther = (TctCorrispEntityPK)other;
		return 
			(this.runId == castOther.runId)
			&& (this.clntid == castOther.clntid)
			&& this.aggrId.equals(castOther.aggrId)
			&& (this.cmpnid == castOther.cmpnid)
			&& (this.downloadid == castOther.downloadid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.runId;
		hash = hash * prime + this.clntid;
		hash = hash * prime + this.aggrId.hashCode();
		hash = hash * prime + this.cmpnid;
		hash = hash * prime + this.downloadid;
		
		return hash;
    }
}