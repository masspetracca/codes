package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctCompanyEntity;
import it.ccg.tcejb.server.bean.entity.TctUserEntity;
import it.ccg.tcejb.server.bean.entity.TctUserEntityPK;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctUserEntityEAO
 */
@Stateless
@LocalBean
public class TctUserEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctUserEntityEAO() {
        // TODO Auto-generated constructor stub
    }
    
    public void insertEntity(TctUserEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctUserEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	entity.setUpdDate(new Timestamp(new Date().getTime()));
	    	entity.setUpdType("C");
	    	entity.setUpdUser("SYSTEM");
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public void deleteEntity(TctUserEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctUserEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUserEntity identification data: username = "+entity.getId().getUserName()+" type= "+entity.getId().getCmpnid()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
    
    public void updateEntity(TctUserEntity entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctUserEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUserEntity identification data: username = "+entity.getId().getUserName()+" type= "+entity.getId().getCmpnid()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
    
    public TctUserEntity retrieveCompanyIdByUsername(String userName) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in int retrieveCompanyIdByUsername(String userName)"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getCompanyIdByUsername");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("userName", userName);
	    	
	    	TctUserEntity toReturn = (TctUserEntity) q.getSingleResult();
	    	return toReturn;
	    	
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
    
    public List<TctUserEntity> retrieveNotificationUsersByCompanyId(TctCompanyEntity company) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in int retrieveCompanyIdByUsername(String userName)"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getNotificationUserByCompanyid");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("cmpnid", company.getCmpnId());
	    	
	    	List<TctUserEntity> toReturn = (List<TctUserEntity>) q.getResultList();
	    	return toReturn;
	    	
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}
    
    
    public TctUserEntity findByPrimaryKey(int cpmnID, String username) throws BackEndException {
		try {
			TctUserEntityPK pK = new TctUserEntityPK();
			pK.setCmpnid(cpmnID);
			pK.setUserName(username);
			TctUserEntity userEntity = (TctUserEntity) this.manager.find(TctUserEntity.class,pK);
    		return userEntity;
    	} catch (Exception e) {
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
	}
    
    
  
}
