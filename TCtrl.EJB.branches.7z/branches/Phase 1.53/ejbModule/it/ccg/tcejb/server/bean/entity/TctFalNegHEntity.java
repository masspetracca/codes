package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the TCTFALNEGH database table.
 * 
 */
@Entity
@Table(name="TCTFALNEGH")
public class TctFalNegHEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TctFalNegHEntityPK id;

	@Column(nullable=false, length=255)
	private String entityName;

	@Column(length=255)
	private String note;

	@Column(nullable=false, length=30)
	private String source;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	@Column(nullable=false, length=1)
	private String status;
	
	//bi-directional many-to-one association to TctCompanyEntity
    /*@ManyToOne
	@JoinColumn(name="COMPNID", nullable=false, insertable=false, updatable=false)*/
	@Transient
	private TctCompanyEntity tctcompany;

	//bi-directional many-to-one association to TctFalNegtEntity
   /* @ManyToOne
	@JoinColumns({
		@JoinColumn(name="AGGRID", referencedColumnName="AGGRID", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="CLNTID", referencedColumnName="CLNTID", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="COMPNID", referencedColumnName="CMPNID", nullable=false, insertable=false, updatable=false)
		})*/
	@Transient
	private TctFalNegtEntity tctfalnegt;

/*	//bi-directional many-to-one association to TctRunRegEntity
    @ManyToOne
	@JoinColumn(name="RUNID", referencedColumnName="RUNID", nullable=false, insertable=false, updatable=false)
	private TctRunRegEntity tctrunreg1;*/

	//bi-directional many-to-one association to TctRunRegEntity
   /* @ManyToOne
	@JoinColumns({
		@JoinColumn(name="COMPNID", referencedColumnName="CMPNID", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="RUNID", referencedColumnName="RUNID", nullable=false, insertable=false, updatable=false)
		})*/
	@Transient
	private TctRunRegEntity tctrunreg;

  //bi-directional many-to-one association to TctAggrEntEntity
   /* @ManyToOne
	@JoinColumns({
		@JoinColumn(name="AGGRID", referencedColumnName="AGGREGID", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="DOWNLOADID", referencedColumnName="DOWNLOADID", nullable=false, insertable=false, updatable=false)
		})*/
	@Transient
	private TctAggrEntEntity tctaggrent;
    
    public TctFalNegHEntity() {
    }

	public TctFalNegHEntityPK getId() {
		return this.id;
	}

	public void setId(TctFalNegHEntityPK id) {
		this.id = id;
	}
	
	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getSource() {
		return this.source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public TctCompanyEntity getTctcompany() {
		return this.tctcompany;
	}

	public void setTctcompany(TctCompanyEntity tctcompany) {
		this.tctcompany = tctcompany;
	}
	
	public TctFalNegtEntity getTctfalnegt() {
		return this.tctfalnegt;
	}

	public void setTctfalnegt(TctFalNegtEntity tctfalnegt) {
		this.tctfalnegt = tctfalnegt;
	}
	
	/*public TctRunRegEntity getTctrunreg1() {
		return this.tctrunreg1;
	}

	public void setTctrunreg1(TctRunRegEntity tctrunreg1) {
		this.tctrunreg1 = tctrunreg1;
	}*/
	
	public TctRunRegEntity getTctrunreg() {
		return this.tctrunreg;
	}

	public void setTctrunreg(TctRunRegEntity tctrunreg) {
		this.tctrunreg = tctrunreg;
	}

	/**
	 * @return the tctaggrent
	 */
	public TctAggrEntEntity getTctaggrent() {
		return tctaggrent;
	}

	/**
	 * @param tctaggrent the tctaggrent to set
	 */
	public void setTctaggrent(TctAggrEntEntity tctaggrent) {
		this.tctaggrent = tctaggrent;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
}