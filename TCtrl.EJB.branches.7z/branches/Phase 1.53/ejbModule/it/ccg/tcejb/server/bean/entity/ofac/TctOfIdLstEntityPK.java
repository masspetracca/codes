package it.ccg.tcejb.server.bean.entity.ofac;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTOFIDLST database table.
 * 
 */
@Embeddable
public class TctOfIdLstEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int idLstId;

	@Column(unique=true, nullable=false)
	private int entityid;

    public TctOfIdLstEntityPK() {
    }
	public int getIdLstId() {
		return this.idLstId;
	}
	public void setIdLstId(int idLstId) {
		this.idLstId = idLstId;
	}
	public int getEntityid() {
		return this.entityid;
	}
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctOfIdLstEntityPK)) {
			return false;
		}
		TctOfIdLstEntityPK castOther = (TctOfIdLstEntityPK)other;
		return 
			(this.idLstId == castOther.idLstId)
			&& (this.entityid == castOther.entityid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.idLstId;
		hash = hash * prime + this.entityid;
		
		return hash;
    }
}