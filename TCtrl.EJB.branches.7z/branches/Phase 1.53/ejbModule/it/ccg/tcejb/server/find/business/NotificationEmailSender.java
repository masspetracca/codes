package it.ccg.tcejb.server.find.business;

import it.ccg.tcejb.server.bean.eao.TctAggrEntityEAO;
import it.ccg.tcejb.server.bean.eao.TctUserEntityEAO;
import it.ccg.tcejb.server.bean.entity.TctAggrEntEntity;
import it.ccg.tcejb.server.bean.entity.TctAggrEntEntityPK;
import it.ccg.tcejb.server.bean.entity.TctCompanyEntity;
import it.ccg.tcejb.server.bean.entity.TctCorrispEntity;
import it.ccg.tcejb.server.bean.entity.TctUserEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.MailManager;

import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;
/*
 * TICKET TN_CCG14896
 */
/**
 * Session Bean implementation class NotificationEmailSender
 */
@Stateless
@LocalBean
public class NotificationEmailSender {
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	@EJB
	private TctUserEntityEAO userEAO;
	
	@EJB
	private TctAggrEntityEAO aggrentEAO;
	
	@Resource
	private SessionContext sessionContext;
    /**
     * Default constructor. 
     */
    public NotificationEmailSender() {
        // TODO Auto-generated constructor stub
    }

   public void sendPossibleMatches(List<TctCorrispEntity> corrisp, TctCompanyEntity company) throws BackEndException{
	   ejbLogger.debug(new StandardLogMessage("in sendPossibleMatches(List<TctCorrispEntity> corrisp)"));
	   
	   List<TctUserEntity> notificationUsers = this.userEAO.retrieveNotificationUsersByCompanyId(company);
	   String[] notificationMails = new String[notificationUsers.size()];
	   for (int i=0;i<notificationUsers.size();i++){
		   notificationMails[i]=notificationUsers.get(i).getEMail();
	   }
	   MailManager mailMan = new MailManager(notificationMails, null);
	   
	   StringBuffer msgText=new StringBuffer();
	   msgText.append("<p>The application has detected the following potential matches:</p><br />");
	   msgText.append("<table border=2><th>Run ID</th><th>Client ID</th><th>Terrorist ID</th><th>Client name</th><th>Terrorist name</th><th>Sanctioned by</th><th>Status</th>");
	   int oCorrisp=0;
	   for (TctCorrispEntity c : corrisp){
		   if (!(c.getStatus().equalsIgnoreCase("D") || c.getStatus().equalsIgnoreCase("N"))){
			   oCorrisp++;
			   TctAggrEntEntityPK pk = new TctAggrEntEntityPK();
			   pk.setAggregId(c.getId().getAggrId());
			   pk.setDownloadid(c.getId().getDownloadid());
			   TctAggrEntEntity aggrEnt;
		
				aggrEnt = this.aggrentEAO.retrieveAggregatedById(pk);
			
			   msgText.append("<tr>");
			   msgText.append("<td align=center>"+c.getId().getRunId()+"</td><td align=center>"+c.getTctclient().getId().getClntId()+"</td><td align=center>"+c.getId().getAggrId()+"</td><td align=center>"+c.getClntName()+"</td><td align=center>"+aggrEnt.getEntityName()+"</td><td align=center>"+aggrEnt.getSrcList()+"</td>");
			  
			   	if (c.getStatus().equalsIgnoreCase("O")){
			   		msgText.append("<td align=center>Outstanding</td>");
			   	}else if(c.getStatus().equalsIgnoreCase("F")){
			   		msgText.append("<td align=center>False positive</td>");
			   	}else if(c.getStatus().equalsIgnoreCase("P")){
			   		msgText.append("<td align=center>Positive match</td>");
			   	}
			   	msgText.append("</tr>");			
		   }
	   }
	   msgText.append("</table><br />");
	   msgText.append("<p>Please access the application and submit the false positive analysis.</p>");
	   if (oCorrisp>0){
		   ejbLogger.info(new StandardLogMessage("send notification"));
		   mailMan.sendMail("Terrorism control: potential matches detected", msgText.toString(), null);
	   }
   }
}
