package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctSrcFlHEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Query;
import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctSrcFlHEntityEAO
 */
@Stateless
@LocalBean
public class TctSrcFlHEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	@Resource
	private SessionContext sessionContext;

	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	/**
	 * Default constructor. 
	 */
	public TctSrcFlHEntityEAO() {
		// TODO Auto-generated constructor stub
	}

	public void insertDownload(TctSrcFlHEntity entity) throws BackEndException{
		try{
			ejbLogger.debug(new StandardLogMessage("in insertDownload(TctSrcFlH entity)"));
			ejbLogger.debug(new StandardLogMessage("insert"));
			entity.setUpdDate(new Timestamp(new Date().getTime()));
			entity.setUpdType("C");
			entity.setUpdUser(sessionContext.getCallerPrincipal().getName());

			this.manager.persist(entity);
			//	    	this.manager.flush();
		}catch(Exception e){
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
		ejbLogger.debug(new StandardLogMessage("inserted"));
	}

	/******************************************/

	public TctSrcFlHEntity fetchSrcByDownloadIdAndSourceList(String srcList, String downloadId ) throws Exception {

			String queryString ="SELECT DOWNLOADID, "+srcList+"FILE FROM TCTSRCFLH " +
					"WHERE DOWNLOADID = ? ";
			Query query = this.manager.createNativeQuery(queryString, TctSrcFlHEntity.class);
			query.setParameter(1, downloadId);
			//query.setParameter(2, downloadId);
			TctSrcFlHEntity entity = (TctSrcFlHEntity)query.getSingleResult();
			
			
			//byte[] result = (byte[]) query.getSingleResult();
			return entity;
		}

	/******************************************/
}
