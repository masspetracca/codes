package it.ccg.tcejb.server.security;

import java.util.List;

public interface SessionInfoRemote {
	
	public List<SessionUser> listLoggedUsers() throws Exception;

}