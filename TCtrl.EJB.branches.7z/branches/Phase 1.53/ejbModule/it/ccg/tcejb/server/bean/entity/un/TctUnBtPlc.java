package it.ccg.tcejb.server.bean.entity.un;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTUNBTPLC database table.
 * 
 */
@Entity
@Table(name="TCTUNBTPLC")
@NamedQueries({
	@NamedQuery(name="deleteUnBtPlcEveryEntity", query="DELETE FROM TctUnBtPlc"),
	@NamedQuery(name="getUnBtPlcEntitiesById", query="SELECT entity FROM TctUnBtPlc entity WHERE entity.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctUnBtPlc implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="BPLACEID")
	private int bPlaceId;

	@Column(nullable=false)
	private int entityid;

	@Column(length=255)
	private String city;

	@Column(length=255)
	private String stateProv;

	//bi-directional many-to-one association to TctUnIndiv
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	private TctUnIndiv tctunindiv;

    public TctUnBtPlc() {
    }

	
	/**
	 * @return the bPlaceId
	 */
	public int getbPlaceId() {
		return bPlaceId;
	}


	/**
	 * @param bPlaceId the bPlaceId to set
	 */
	public void setbPlaceId(int bPlaceId) {
		this.bPlaceId = bPlaceId;
	}


	/**
	 * @return the entityid
	 */
	public int getEntityid() {
		return entityid;
	}


	/**
	 * @param entityid the entityid to set
	 */
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}


	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		if (city != null && city.length()>255){
			ejbLogger.debug(city+" >255 than truncate");
			this.city = city.substring(0, 254);
		}else{
			this.city = city;
		}
	}

	public String getStateProv() {
		return this.stateProv;
	}

	public void setStateProv(String stateProv) {
		if (stateProv !=null && stateProv.length()>255){
			ejbLogger.debug(stateProv+" >255 than truncate");
			this.stateProv = stateProv.substring(0, 254);
		}else{
			this.stateProv = stateProv;
		}
	}

	public TctUnIndiv getTctunindiv() {
		return this.tctunindiv;
	}

	public void setTctunindiv(TctUnIndiv tctunindiv) {
		this.tctunindiv = tctunindiv;
	}
	
}