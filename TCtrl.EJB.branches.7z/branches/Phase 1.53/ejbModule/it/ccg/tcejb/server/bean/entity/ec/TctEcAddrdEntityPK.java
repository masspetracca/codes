package it.ccg.tcejb.server.bean.entity.ec;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCTECADDRD database table.
 * 
 */
@Embeddable
public class TctEcAddrdEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int addressId;

	@Column(unique=true, nullable=false)
	private int entityid;

    public TctEcAddrdEntityPK() {
    }
	public int getAddressId() {
		return this.addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public int getEntityid() {
		return this.entityid;
	}
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TctEcAddrdEntityPK)) {
			return false;
		}
		TctEcAddrdEntityPK castOther = (TctEcAddrdEntityPK)other;
		return 
			(this.addressId == castOther.addressId)
			&& (this.entityid == castOther.entityid);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.addressId;
		hash = hash * prime + this.entityid;
		
		return hash;
    }
}