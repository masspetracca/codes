package it.ccg.tcejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TCTCLIENT database table.
 * 
 */
@Entity
@Table(name="TCTCLIENT")
@NamedQueries({
	@NamedQuery(name="getClientsByCmpnId",   query="SELECT entity " +
            "								          FROM TctClientEntity entity " +
            "								         WHERE entity.id.cmpnId  = :cmpnId"), 
	@NamedQuery(name="getClientsByCmpnIdAndClientId",   query="SELECT entity " +
            "								          FROM TctClientEntity entity " +
            "								         WHERE entity.id.cmpnId  = :cmpnId" +
            "										   AND entity.id.clntId = :clntId"),
    @NamedQuery(name="getAllClients",        query="SELECT entity " +
            "								          FROM TctClientEntity entity ") 
	
})
public class TctClientEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TctClientEntityPK id;

	@Column(name="ABI_CODE", length=30)
	private String abiCode;

	@Column(length=30)
	private String adminName;

	@Column(length=30)
	private String adminSurn;

	@Column(name="CLNTALIAS_1", length=50)
	private String clntAlias1;

	@Column(name="CLNTALIAS_2", length=50)
	private String clntAlias2;

	@Column(name="CLNTALIAS_3", length=50)
	private String clntAlias3;

	@Column(nullable=false, length=100)
	private String clntName;

	@Column(length=30)
	private String country;

	@Column(length=100)
	private String group;

	private int idAdmin;

	private int idLegalRap;

	@Column(nullable=false, length=1)
	private String isNew;

	@Column(length=30)
	private String legalName;

	@Column(length=30)
	private String legalSurna;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	//bi-directional many-to-one association to TctClientHEntity
	@OneToMany(mappedBy="tctclient")
	private Set<TctClientHEntity> tctclienths;

	//bi-directional many-to-one association to TctCorrispEntity
	@OneToMany(mappedBy="tctclient")
	private Set<TctCorrispEntity> tctcorrisps;

	//bi-directional many-to-one association to TctFalNegtEntity
	@OneToMany(mappedBy="tctclient")
	private Set<TctFalNegtEntity> tctfalnegts;

	//bi-directional many-to-one association to TctOptimiz
	@OneToMany(mappedBy="tctclient",cascade={CascadeType.DETACH})
	private Set<TctOptimizEntity> tctoptimizs;
		
    public TctClientEntity() {
    }

	public TctClientEntityPK getId() {
		return this.id;
	}

	public void setId(TctClientEntityPK id) {
		this.id = id;
	}
	
	public String getClntAlias1() {
		return this.clntAlias1;
	}

	public void setClntAlias1(String clntAlias1) {
		this.clntAlias1 = clntAlias1;
	}

	public String getClntAlias2() {
		return this.clntAlias2;
	}

	public void setClntAlias2(String clntAlias2) {
		this.clntAlias2 = clntAlias2;
	}

	public String getClntAlias3() {
		return this.clntAlias3;
	}

	public void setClntAlias3(String clntAlias3) {
		this.clntAlias3 = clntAlias3;
	}

	public String getIsNew() {
		return this.isNew;
	}

	public void setIsNew(String isNew) {
		this.isNew = isNew;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public Set<TctClientHEntity> getTctclienths() {
		return this.tctclienths;
	}

	public void setTctclienths(Set<TctClientHEntity> tctclienths) {
		this.tctclienths = tctclienths;
	}
	
	public Set<TctCorrispEntity> getTctcorrisps() {
		return this.tctcorrisps;
	}

	public void setTctcorrisps(Set<TctCorrispEntity> tctcorrisps) {
		this.tctcorrisps = tctcorrisps;
	}
	
	public Set<TctFalNegtEntity> getTctfalnegts() {
		return this.tctfalnegts;
	}

	public void setTctfalnegts(Set<TctFalNegtEntity> tctfalnegts) {
		this.tctfalnegts = tctfalnegts;
	}

	/**
	 * @return the tctoptimizs
	 */
	public Set<TctOptimizEntity> getTctoptimizs() {
		return tctoptimizs;
	}

	/**
	 * @param tctoptimizs the tctoptimizs to set
	 */
	public void setTctoptimizs(Set<TctOptimizEntity> tctoptimizs) {
		this.tctoptimizs = tctoptimizs;
	}

	/**
	 * @return the abiCode
	 */
	public String getAbiCode() {
		return abiCode;
	}

	/**
	 * @param abiCode the abiCode to set
	 */
	public void setAbiCode(String abiCode) {
		this.abiCode = abiCode;
	}

	/**
	 * @return the adminName
	 */
	public String getAdminName() {
		return adminName;
	}

	/**
	 * @param adminName the adminName to set
	 */
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	/**
	 * @return the adminSurn
	 */
	public String getAdminSurn() {
		return adminSurn;
	}

	/**
	 * @param adminSurn the adminSurn to set
	 */
	public void setAdminSurn(String adminSurn) {
		this.adminSurn = adminSurn;
	}

	/**
	 * @return the clntName
	 */
	public String getClntName() {
		return clntName;
	}

	/**
	 * @param clntName the clntName to set
	 */
	public void setClntName(String clntName) {
		this.clntName = clntName;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the group
	 */
	public String getGroup() {
		return group;
	}

	/**
	 * @param group the group to set
	 */
	public void setGroup(String group) {
		this.group = group;
	}

	/**
	 * @return the idAdmin
	 */
	public int getIdAdmin() {
		return idAdmin;
	}

	/**
	 * @param idAdmin the idAdmin to set
	 */
	public void setIdAdmin(int idAdmin) {
		this.idAdmin = idAdmin;
	}

	/**
	 * @return the idLegalRap
	 */
	public int getIdLegalRap() {
		return idLegalRap;
	}

	/**
	 * @param idLegalRap the idLegalRap to set
	 */
	public void setIdLegalRap(int idLegalRap) {
		this.idLegalRap = idLegalRap;
	}

	/**
	 * @return the legalName
	 */
	public String getLegalName() {
		return legalName;
	}

	/**
	 * @param legalName the legalName to set
	 */
	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}

	/**
	 * @return the legalSurna
	 */
	public String getLegalSurna() {
		return legalSurna;
	}

	/**
	 * @param legalSurna the legalSurna to set
	 */
	public void setLegalSurna(String legalSurna) {
		this.legalSurna = legalSurna;
	}
}