package it.ccg.tcejb.server.ext.source.xml.un;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{}TYPE_OF_DOCUMENT" minOccurs="0"/>
 *         &lt;element ref="{}TYPE_OF_DOCUMENT2" minOccurs="0"/>
 *         &lt;element ref="{}NUMBER" minOccurs="0"/>
 *         &lt;element ref="{}ISSUING_COUNTRY" minOccurs="0"/>
 *         &lt;element ref="{}DATE_OF_ISSUE" minOccurs="0"/>
 *         &lt;element ref="{}CITY_OF_ISSUE" minOccurs="0"/>
 *         &lt;element ref="{}COUNTRY_OF_ISSUE" minOccurs="0"/>
 *         &lt;element ref="{}NOTE" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "typeofdocument",
    "typeofdocument2",
    "number",
    "issuingcountry",
    "dateofissue",
    "cityofissue",
    "countryofissue",
    "note"
})
@XmlRootElement(name = "INDIVIDUAL_DOCUMENT")
public class IndividualDocument {

    @XmlElement(name = "TYPE_OF_DOCUMENT")
    protected String typeofdocument;
    @XmlElement(name = "TYPE_OF_DOCUMENT2")
    protected String typeofdocument2;
    @XmlElement(name = "NUMBER")
    protected String number;
    @XmlElement(name = "ISSUING_COUNTRY")
    protected String issuingcountry;
    @XmlElement(name = "DATE_OF_ISSUE")
    protected String dateofissue;
    @XmlElement(name = "CITY_OF_ISSUE")
    protected String cityofissue;
    @XmlElement(name = "COUNTRY_OF_ISSUE")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String countryofissue;
    @XmlElement(name = "NOTE")
    protected String note;

    /**
     * Gets the value of the typeofdocument property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTYPEOFDOCUMENT() {
        return typeofdocument;
    }

    /**
     * Sets the value of the typeofdocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTYPEOFDOCUMENT(String value) {
        this.typeofdocument = value;
    }

    /**
     * Gets the value of the typeofdocument2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTYPEOFDOCUMENT2() {
        return typeofdocument2;
    }

    /**
     * Sets the value of the typeofdocument2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTYPEOFDOCUMENT2(String value) {
        this.typeofdocument2 = value;
    }

    /**
     * Gets the value of the number property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNUMBER() {
        return number;
    }

    /**
     * Sets the value of the number property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNUMBER(String value) {
        this.number = value;
    }

    /**
     * Gets the value of the issuingcountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISSUINGCOUNTRY() {
        return issuingcountry;
    }

    /**
     * Sets the value of the issuingcountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISSUINGCOUNTRY(String value) {
        this.issuingcountry = value;
    }

    /**
     * Gets the value of the dateofissue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDATEOFISSUE() {
        return dateofissue;
    }

    /**
     * Sets the value of the dateofissue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDATEOFISSUE(String value) {
        this.dateofissue = value;
    }

    /**
     * Gets the value of the cityofissue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCITYOFISSUE() {
        return cityofissue;
    }

    /**
     * Sets the value of the cityofissue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCITYOFISSUE(String value) {
        this.cityofissue = value;
    }

    /**
     * Gets the value of the countryofissue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOUNTRYOFISSUE() {
        return countryofissue;
    }

    /**
     * Sets the value of the countryofissue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOUNTRYOFISSUE(String value) {
        this.countryofissue = value;
    }

    /**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNOTE() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNOTE(String value) {
        this.note = value;
    }

}
