package it.ccg.tcejb.server.bean.eao.un;

import it.ccg.tcejb.server.bean.entity.un.TctUnIndiv;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctUnIndivEntityEAO
 */
@Stateless
@LocalBean
public class TctUnIndivEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	
	@SuppressWarnings("unused")
	@Resource
	private SessionContext sessionContext;
	@EJB
	private TctUnAliasEntityEAO unAliaEAO;
	@EJB
	private TctUnListUpEntityEAO unLtUpEntityEAO;
	@EJB
	private TctUnBrtDtEntityEAO brtDtEntityEAO;
	@EJB
	private TctUnBtPlcEntityEAO btPlcEntityEAO;
	@EJB
	private TctUnNatEntityEAO natEntityEAO;
	@EJB
	private TctUnDesigEntityEAO desigEntityEAO;
	@EJB
	private TctUnTitleEntityEAO titleEntityEAO;

	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctUnIndivEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertIndividual(TctUnIndiv entity) throws BackEndException{
		try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctUnIndiv entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnIndiv identification data: UN identity code = "+entity.getDataId()+", regate= "+df.format(entity.getDateGenerated())));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();

	    	
	    	if (entity.getTctunalias()!=null && entity.getTctunalias().size()>0){
	    		this.unAliaEAO.insertEntity(entity.getTctunalias());
	    	}
	    	if(entity.getTctunlstups()!=null && entity.getTctunlstups().size()>0){
	    		this.unLtUpEntityEAO.insertEntity(entity.getTctunlstups());
	    	}
	    	if (entity.getTctunbrtdts()!=null && entity.getTctunbrtdts().size()>0){
	    		this.brtDtEntityEAO.insertEntity(entity.getTctunbrtdts());
	    	}
	    	if (entity.getTctunbtplcs()!=null && entity.getTctunbtplcs().size()>0){
	    		this.btPlcEntityEAO.insertEntity(entity.getTctunbtplcs());
	    	}
	    	if (entity.getTctunnats() !=null && entity.getTctunnats().size()>0){
	    		this.natEntityEAO.insertEntity(entity.getTctunnats());
	    	}
	    	if (entity.getTctundesigs() !=null && entity.getTctundesigs().size()>0){
	    		this.desigEntityEAO.insertEntity(entity.getTctundesigs());
	    	}
	    	if (entity.getTctuntitles() !=null && entity.getTctuntitles().size()>0){
	    		this.titleEntityEAO.insertEntity(entity.getTctuntitles());
	    	}
	    	
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
	}
    
	public void insertIndividual(List<TctUnIndiv> entities) throws BackEndException{
		try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctUnIndiv entity)"));
	    	int idxToFlush = 0;
	    	for (TctUnIndiv entity : entities){
	    		ejbLogger.debug(new StandardLogMessage("TctUnIndiv identification data: UN identity code = "+entity.getDataId()+", regate= "+df.format(entity.getDateGenerated())));
		    	
		    	this.manager.persist(entity);	
		    	idxToFlush++;
		    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
		    		ejbLogger.debug(new StandardLogMessage("insert"));
			    	//this.manager.flush();
		    	}
	    	}
	    	ejbLogger.debug(new StandardLogMessage("last insert"));
//	    	this.manager.flush();
	    	
	    	/*this.unAddrEAO.deleteEveryEntity();
	    	this.unAliaEAO.deleteEveryEntity();
	    	this.unListTpEntityEAO.deleteEveryEntity();
	    	this.unLtUpEntityEAO.deleteEveryEntity();*/
	    	/*for(TctUnIndiv entity : entities){
	    		if (entity.getTctunalias()!=null && entity.getTctunalias().size()>0){
		    		this.unAliaEAO.insertEntity(entity.getTctunalias());
		    	}
		    	if(entity.getTctunlstups()!=null && entity.getTctunlstups().size()>0){
		    		this.unLtUpEntityEAO.insertEntity(entity.getTctunlstups());
		    	}
		    	if (entity.getTctunbrtdts()!=null && entity.getTctunbrtdts().size()>0){
		    		this.brtDtEntityEAO.insertEntity(entity.getTctunbrtdts());
		    	}
		    	if (entity.getTctunbtplcs()!=null && entity.getTctunbtplcs().size()>0){
		    		this.btPlcEntityEAO.insertEntity(entity.getTctunbtplcs());
		    	}
		    	if (entity.getTctunnats() !=null && entity.getTctunnats().size()>0){
		    		this.natEntityEAO.insertEntity(entity.getTctunnats());
		    	}
	    	}*/
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
	public void deleteIndividual(TctUnIndiv entity) throws BackEndException{
		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteIndividual(TctUnIndiv entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnIndiv identification data: UN individual identity code = "+entity.getDataId()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
	}
	
	public void deleteEveryIndividuals() throws BackEndException{
  		try{
   			ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteUnEveryIndividuals");
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	this.manager.flush();
	    	
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
	
	public void updateIndividual(TctUnIndiv entity) throws BackEndException{
		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateIndividual(TctUnIndiv entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnIndiv identification data: UN individual identity code = "+entity.getDataId()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
	}
	
	@SuppressWarnings("unchecked")
	public List<TctUnIndiv> retrieveIndividualById(int entityId) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in List<TctUnIndiv> retrieveIndividualById(int entityId)"));
    	ejbLogger.debug(new StandardLogMessage("ofEntityId "+entityId));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getUnIndividualsById");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("entityId", entityId);
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
		List<TctUnIndiv> ofIndividual = (List<TctUnIndiv>) q.getResultList();
		ejbLogger.debug(new StandardLogMessage("return"));
    	return ofIndividual;
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TctUnIndiv> retrieveIndividualBySrcListDate(String srcLstDate) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in List<TctUnIndiv> retrieveIndividualBySrcListDate(String srcLstDate)"));
       	ejbLogger.debug(new StandardLogMessage("srcLstDate : "+srcLstDate));
       	List<TctUnIndiv> tctUnEntities = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getUnIndividualsBySrcListDate");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			q.setParameter("srcListDate", df.parse(srcLstDate));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			tctUnEntities = (List<TctUnIndiv>) q.getResultList();
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return tctUnEntities; 
		
	}
	
	public Date getLatestSrcListDate() throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in Date getLatestSrcListDate()"));
  		Date maxSrcListDate= null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getUnIndLatestSrcListDate");
			ejbLogger.debug(new StandardLogMessage("getSingleResult"));
			maxSrcListDate = (Date) q.getSingleResult();
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return maxSrcListDate;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<TctUnIndiv> retrieveLatestIndividuals(String srcLstDate) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in List<TctUnIndiv> retrieveLatestIndividuals(String srcLstDate)"));
       	List<TctUnIndiv> tctUnIndividuals = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getUnLatestIndividuals");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			tctUnIndividuals = (List<TctUnIndiv>) q.getResultList();
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return tctUnIndividuals;	
	}
	
	public  List<TctUnIndiv> retrieveAllIndividials() throws BackEndException{
		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<TctUnIndiv> retrieveAllIndividials()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getUnIndividuals");
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<TctUnIndiv> unIndividuals = (List<TctUnIndiv>) q.getResultList();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return unIndividuals;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}
}
