package it.ccg.tcejb.server.bean.entity.un;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTUNBRTDT database table.
 * 
 */
@Entity
@Table(name="TCTUNBRTDT")
@NamedQueries({
	@NamedQuery(name="deleteUnBrtDtEveryEntity", query="DELETE FROM TctUnBrtDt"),
	@NamedQuery(name="getUnBrtDtEntitiesById", query="SELECT entity FROM TctUnBrtDt entity WHERE entity.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctUnBrtDt implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="BIRTHDATID")
	private int birthDatId;
	
	@Column(nullable=false)
	private int entityid;
	
    @Temporal( TemporalType.DATE)
	private Date birthDate;

	private int fromYear;

	@Column(length=1000)
	private String note;

	private int toYear;

	@Column(length=30)
	private String typeOfDate;

	private int year;
	
	//bi-directional many-to-one association to TctUnIndiv
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false, insertable=false, updatable=false)
	private TctUnIndiv tctunindiv;

    public TctUnBrtDt() {
    }

    /**
     * 
     * @return
     */
	public String getTypeOfDate() {
		return this.typeOfDate;
	}

	/**
	 * 
	 * @param typeOfDate
	 */
	public void setTypeOfDate(String typeOfDate) {
		if (typeOfDate != null && typeOfDate.length()>30){
			ejbLogger.debug(typeOfDate+" >30 than truncate");
			this.typeOfDate = typeOfDate.substring(0, 29);
		}else{
			this.typeOfDate = typeOfDate;
		}
	}

	/**
	 * 
	 * @return
	 */
	public int getFromYear() {
		return this.fromYear;
	}

	/**
	 * 
	 * @param fromYear
	 */
	public void setFromYear(int fromYear) {
		this.fromYear = fromYear;
	}

	/**
	 * 
	 * @return
	 */
	public String getNote() {
		return this.note;
	}

	/**
	 * 
	 * @param note
	 */
	public void setNote(String note) {
		if (note != null && note.length()>1000){
			ejbLogger.debug(note+" >1000 than truncate");
			this.note = note.substring(0, 999);
		}else{
			this.note = note;
		}
	}

	/**
	 * 
	 * @return
	 */
	public int getToYear() {
		return this.toYear;
	}

	/**
	 * 
	 * @param toYear
	 */
	public void setToYear(int toYear) {
		this.toYear = toYear;
	}
	
	/**
	 * 
	 * @return
	 */
	public int getYear() {
		return this.year;
	}

	/**
	 * 
	 * @param year
	 */
	public void setYear(int year) {
		this.year = year;
	}

	/**
	 * 
	 * @return
	 */
	public TctUnIndiv getTctunindiv() {
		return this.tctunindiv;
	}

	/**
	 * 
	 * @param tctunindiv
	 */
	public void setTctunindiv(TctUnIndiv tctunindiv) {
		this.tctunindiv = tctunindiv;
	}

	/**
	 * @return the birthDatId
	 */
	public int getBirthDatId() {
		return birthDatId;
	}

	/**
	 * @param birthDatId the birthDatId to set
	 */
	public void setBirthDatId(int birthDatId) {
		this.birthDatId = birthDatId;
	}
	
	/**
	 * @return the entityid
	 */
	public int getEntityid() {
		return entityid;
	}

	/**
	 * @param entityid the entityid to set
	 */
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}

	/**
	 * @return the birthDate
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/**
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
}