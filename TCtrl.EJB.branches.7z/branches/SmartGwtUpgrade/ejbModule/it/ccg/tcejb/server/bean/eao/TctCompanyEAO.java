package it.ccg.tcejb.server.bean.eao;

import it.ccg.tcejb.server.bean.entity.TctCompanyEntity;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.util.Arrays;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctCompanyEAO
 */
@Stateless
@LocalBean
public class TctCompanyEAO {

	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	
	
	
	public TctCompanyEntity findByCompanyCode(String companyCode) throws BackEndException {
		Query query = null;
    	try {
    		query = em.createNamedQuery("getCompanyByCompanyCode");
    		/*
    		 * Raffaele De Lauri
    		 * TN_CCG16966
    		 * 22/04/2015
    		 * modifico il formato dei valori che vengono passati alla query
    		 */
    		List<String> appo = (List<String>)Arrays.asList(companyCode.split(","));
    		query.setParameter("companyCode", appo);
    		/*
    		 * fine TN_CCG16966
    		 */
    		List<TctCompanyEntity> companyList = query.getResultList();
    		if (companyList.size()>0) {
    			return companyList.get(0);
    		} else {
    			return null;
    		}
    	} catch (Exception e) {
    		BackEndException exc = new BackEndException("Error fetching Company - companyCode: "+companyCode+" - "+e.getMessage());
    		exc.setStackTrace(e.getStackTrace());
    		throw exc;
    	}
	}
	

}
