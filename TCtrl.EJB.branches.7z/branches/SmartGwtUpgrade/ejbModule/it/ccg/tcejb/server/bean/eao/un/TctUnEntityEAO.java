package it.ccg.tcejb.server.bean.eao.un;

import it.ccg.tcejb.server.bean.entity.un.TctUnEntit;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctUnEntityEAO
 */
@Stateless
@LocalBean
public class TctUnEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	
	/*@Resource
	private SessionContext sessionContext;*/
	@EJB
	private TctUnAddrEntityEAO unAddrEAO;
	@EJB
	private TctUnAliasEntityEAO unAliaEAO;
	@EJB
	private TctUnListUpEntityEAO unLtUpEntityEAO;
	@EJB
	private TctUnBrtDtEntityEAO brtDtEntityEAO;
	@EJB
	private TctUnBtPlcEntityEAO btPlcEntityEAO;
	@EJB	private TctUnNatEntityEAO natEntityEAO;
	@EJB
	private TctUnIndivEntityEAO individualEntityEAO;
	
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public TctUnEntityEAO() {
        // TODO Auto-generated constructor stub
    }
	public void insertEntity(TctUnEntit entity) throws BackEndException{
		try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctUnEntit entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnEntit identification data: UN identity code = "+entity.getDataId()+", regate= "+df.format(entity.getDateGenerated())));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
	    	
	    	if (entity.getTctunaddrs()!=null && entity.getTctunaddrs().size()>0){
	    		this.unAddrEAO.insertEntity(entity.getTctunaddrs());
	    	}
	    	if (entity.getTctunalias()!=null && entity.getTctunalias().size()>0){
	    		this.unAliaEAO.insertEntity(entity.getTctunalias());
	    	}
	    	if(entity.getTctunlstups()!=null && entity.getTctunlstups().size()>0){
	    		this.unLtUpEntityEAO.insertEntity(entity.getTctunlstups());
	    	}
	    	
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
	}
	public void insertEntity(List<TctUnEntit> entities) throws BackEndException{
		try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctEcEntit entity)"));
	    	int idxToFlush = 0;
	    	for (TctUnEntit entity : entities){
	    		ejbLogger.debug(new StandardLogMessage("TctUnEntit identification data: UN identity code = "+entity.getDataId()+", regate= "+df.format(entity.getDateGenerated())));
		    	
		    	this.manager.persist(entity);	
		    	idxToFlush++;
		    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
		    		ejbLogger.debug(new StandardLogMessage("insert"));
			    	//this.manager.flush();
		    	}
	    	}
	    	ejbLogger.debug(new StandardLogMessage("last insert"));
	    	//this.manager.flush();
	    	
	    	/*this.unAddrEAO.deleteEveryEntity();
	    	this.unAliaEAO.deleteEveryEntity();
	    	this.unListTpEntityEAO.deleteEveryEntity();
	    	this.unLtUpEntityEAO.deleteEveryEntity();*/
	    	/*for(TctUnEntit entity : entities){
	    		if (entity.getTctunaddrs()!=null && entity.getTctunaddrs().size()>0){
	    			unAddrEAO.insertEntity(entity.getTctunaddrs());
		    	}
		    	if (entity.getTctunalias()!=null && entity.getTctunalias().size()>0){
		    		unAliaEAO.insertEntity(entity.getTctunalias());
		    	}
		    	if(entity.getTctunlstups()!=null && entity.getTctunlstups().size()>0){
		    		unLtUpEntityEAO.insertEntity(entity.getTctunlstups());
		    	}
	    	}*/
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
	public void deleteEntity(TctUnEntit entity) throws BackEndException{
		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctUnEntit entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnIndiv identification data: UN entity identity code = "+entity.getDataId()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
	}
	
	public void deleteEveryEntity() throws BackEndException{
  		try{
  		//cancello i dati anche sulle tabello che fanno rifermento alla Entity
	    	this.unAddrEAO.deleteEveryEntity();
	    	this.unAliaEAO.deleteEveryEntity();
	    	this.natEntityEAO.deleteEveryEntity();
	    	this.brtDtEntityEAO.deleteEveryEntity();
	    	this.btPlcEntityEAO.deleteEveryEntity();
	    	this.individualEntityEAO.deleteEveryIndividuals();
  			ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteUnEveryEntity");
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	this.manager.flush();
	    	
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
	
	public void updateEntity(TctUnEntit entity) throws BackEndException{
		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctUnEntit entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnIndiv identification data: UN entity identity code = "+entity.getDataId()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
	}
	
	@SuppressWarnings("unchecked")
	public List<TctUnEntit> retrieveEntityById(int entityId) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in List<TctUnEntit> retrieveEntityById(int entityId)"));
    	ejbLogger.debug(new StandardLogMessage("ofEntityId "+entityId));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getUnEntitiesById");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("entityId", entityId);
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
		List<TctUnEntit> ofEntities = (List<TctUnEntit>) q.getResultList();
		ejbLogger.debug(new StandardLogMessage("return"));
    	return ofEntities;
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TctUnEntit> retrieveEntityBySrcListDate(String srcLstDate) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in List<TctUnEntit> retrieveEntityBySrcListDate(String srcLstDate)"));
       	ejbLogger.debug(new StandardLogMessage("srcLstDate : "+srcLstDate));
       	List<TctUnEntit> tctUnEntities = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getUnEntitiesBySrcListDate");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			q.setParameter("srcListDate", df.parse(srcLstDate));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			tctUnEntities = (List<TctUnEntit>) q.getResultList();
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return tctUnEntities; 	
		
	}
	
	public Date getLatestSrcListDate() throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in Date getLatestSrcListDate()"));
  		Date maxSrcListDate= null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getUnLatestSrcListDate");
			ejbLogger.debug(new StandardLogMessage("getSingleResult"));
			maxSrcListDate = (Date) q.getSingleResult();
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return maxSrcListDate;
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TctUnEntit> retrieveLatestEntities() throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in List<TctUnEntit> retrieveLatestEntities()"));
       	List<TctUnEntit> tctUnEntities = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getUnLatestEntities");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			tctUnEntities = (List<TctUnEntit>) q.getResultList();
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	ejbLogger.debug(new StandardLogMessage("return"));
       	return tctUnEntities;
		
	}
	
	
	@SuppressWarnings("unchecked")
	public List<TctUnEntit> retrieveAllEntities() throws BackEndException{
		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<TctOfEntit> retrieveAllEntities()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getUnEntities");
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<TctUnEntit> unEntities = (List<TctUnEntit>) q.getResultList();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return unEntities;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  
	}
}
