package it.ccg.tcejb.server.bean.eao.un;

import it.ccg.tcejb.server.bean.entity.un.TctUnDesig;
import it.ccg.tcejb.server.exception.BackEndException;
import it.ccg.tcejb.server.logengine.LoggerFactory;
import it.ccg.tcejb.server.logengine.StandardLogMessage;
import it.ccg.tcejb.server.system.SystemProperties;
import it.ccg.tcejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class TctUnDesigEntityEAO
 */
@Stateless
@LocalBean
public class TctUnDesigEntityEAO {
	@PersistenceContext(unitName="TerrorismControl", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	
	@SuppressWarnings("unused")
	@Resource
	private SessionContext sessionContext;
	
	@SuppressWarnings("unused")
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
    /**
     * Default constructor. 
     */
    public TctUnDesigEntityEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertEntity(TctUnDesig entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctUnDesig entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnDesig identification data: "+entity.getTctunindiv().getDataId()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
    public void insertEntity(Set<TctUnDesig> entities) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertEntity(TctUnDesig entity)"));
	    	int idxToFlush = 0;
	    	for (TctUnDesig entity : entities){
	    		ejbLogger.debug(new StandardLogMessage("TctUnDesig identification data: "+entity.getTctunindiv().getDataId()+" "+entity.getValue()));
		    	
		    	this.manager.persist(entity);
		    	idxToFlush++;
		    	if (idxToFlush% Integer.parseInt(SystemProperties.getSystemProperty("flush.limit")) == 0){
		    		ejbLogger.debug(new StandardLogMessage("insert"));
			    	this.manager.flush();
		    	}
	    	}
	    	ejbLogger.debug(new StandardLogMessage("last insert"));
	    	this.manager.flush();
	    	
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    	ejbLogger.debug(new StandardLogMessage("inserted"));
    }
    
  	public void deleteEntity(TctUnDesig entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEntity(TctUnDesig entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnDesig identification data: "+entity.getTctunindiv().getDataId()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void deleteEveryEntity() throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteEveryEntity()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("deleteUnDesignEveryEntity");
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	ejbLogger.debug(new StandardLogMessage("executeUpdate"));
	    	q.executeUpdate();
	    	this.manager.flush();
	    	ejbLogger.debug(new StandardLogMessage("deleted"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	public void updateEntity(TctUnDesig entity) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateEntity(TctUnDesig entity)"));
	    	ejbLogger.debug(new StandardLogMessage("TctUnDesig identification data: "+entity.getTctunindiv().getDataId() +" , designed id = "+entity.getDesignId()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    	ejbLogger.debug(new StandardLogMessage("updated"));
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
  	}
  	
  	/*@SuppressWarnings("unchecked")
	public  List<TctUnDesig> retrieveEntityDesignedByEntId(int entityId) throws BackEndException{
  		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<TctUnDesig> retrieveEntityNationalityByEntId(int entityId)"));
	    	ejbLogger.debug(new StandardLogMessage("ecEntityId "+entityId));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getUnNatEntitiesById");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("entityId", entityId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	List<TctUnDesig> unDes = (List<TctUnDesig>) q.getResultList();
			ejbLogger.debug(new StandardLogMessage("return"));
	    	return unDes;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}  	
  	}*/
}
