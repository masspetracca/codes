package it.ccg.tcejb.server.bean.entity.un;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the TCTUNDESIG database table.
 * 
 */
@Entity
@Table(name="TCTUNDESIG")
@NamedQueries({
	@NamedQuery(name="deleteUnDesignEveryEntity", query="DELETE FROM TctUnDesig")//,
	//@NamedQuery(name="getUnTitleEntitiesById", query="SELECT entity FROM TctUnTitle entity WHERE entity.entityid = :entityId ORDER BY entity.id.addressId ASC")
})
public class TctUnDesig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="DESIGNID")
	private int designId;

	@Column(nullable=false)
	private int entityid;
	
	@Column(length=255)
	private String value;

	//bi-directional many-to-one association to TctUnIndivEntity
    @ManyToOne
	@JoinColumn(name="ENTITYID", nullable=false)
	private TctUnIndiv tctunindiv;

    public TctUnDesig() {
    }

	public int getDesignId() {
		return this.designId;
	}

	public void setDesignId(int designId) {
		this.designId = designId;
	}

	/**
	 * @return the entityid
	 */
	public int getEntityid() {
		return entityid;
	}

	/**
	 * @param entityid the entityid to set
	 */
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}
	
	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public TctUnIndiv getTctunindiv() {
		return this.tctunindiv;
	}

	public void setTctunindiv(TctUnIndiv tctunindiv) {
		this.tctunindiv = tctunindiv;
	}
	
}