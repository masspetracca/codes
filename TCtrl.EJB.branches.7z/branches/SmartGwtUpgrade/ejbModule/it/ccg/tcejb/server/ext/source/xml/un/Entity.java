package it.ccg.tcejb.server.ext.source.xml.un;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{}DATAID"/>
 *         &lt;element ref="{}VERSIONNUM"/>
 *         &lt;element ref="{}FIRST_NAME"/>
 *         &lt;element ref="{}UN_LIST_TYPE"/>
 *         &lt;element ref="{}REFERENCE_NUMBER"/>
 *         &lt;element ref="{}LISTED_ON"/>
 *         &lt;element ref="{}SUBMITTED_ON" minOccurs="0"/>
 *         &lt;element ref="{}NAME_ORIGINAL_SCRIPT" minOccurs="0"/>
 *         &lt;element ref="{}COMMENTS1"/>
 *         &lt;element ref="{}LIST_TYPE"/>
 *         &lt;element ref="{}LAST_DAY_UPDATED" minOccurs="0"/>
 *         &lt;element ref="{}ENTITY_ALIAS" maxOccurs="unbounded"/>
 *         &lt;element ref="{}ENTITY_ADDRESS" maxOccurs="unbounded"/>
 *         &lt;element ref="{}SORT_KEY"/>
 *         &lt;element ref="{}SORT_KEY_LAST_MOD"/>
 *         &lt;element ref="{}DELISTED_ON" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "dataid",
    "versionnum",
    "firstname",
    "unlisttype",
    "referencenumber",
    "listedon",
    "submittedon",
    "nameoriginalscript",
    "comments1",
    "listtype",
    "lastdayupdated",
    "entityalias",
    "entityaddress",
    "sortkey",
    "sortkeylastmod",
    "delistedon"
})
@XmlRootElement(name = "ENTITY")
public class Entity {

    @XmlElement(name = "DATAID", required = true, defaultValue = "000000")
    protected BigInteger dataid;
    @XmlElement(name = "VERSIONNUM", required = true, defaultValue = "1")
    protected BigInteger versionnum;
    @XmlElement(name = "FIRST_NAME", required = true)
    protected String firstname;
    @XmlElement(name = "UN_LIST_TYPE", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String unlisttype;
    @XmlElement(name = "REFERENCE_NUMBER", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String referencenumber;
    @XmlElement(name = "LISTED_ON", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar listedon;
    @XmlElement(name = "SUBMITTED_ON")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar submittedon;
    @XmlElement(name = "NAME_ORIGINAL_SCRIPT")
    protected String nameoriginalscript;
    @XmlElement(name = "COMMENTS1", required = true)
    protected String comments1;
    @XmlElement(name = "LIST_TYPE", required = true)
    protected ListType listtype;
    @XmlElement(name = "LAST_DAY_UPDATED")
    protected LastDayUpdated lastdayupdated;
    @XmlElement(name = "ENTITY_ALIAS", required = true)
    protected List<EntityAlias> entityalias;
    @XmlElement(name = "ENTITY_ADDRESS", required = true)
    protected List<EntityAddress> entityaddress;
    @XmlElement(name = "SORT_KEY", required = true)
    protected String sortkey;
    @XmlElement(name = "SORT_KEY_LAST_MOD", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sortkeylastmod;
    @XmlElement(name = "DELISTED_ON")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar delistedon;

    /**
     * Gets the value of the dataid property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDATAID() {
        return dataid;
    }

    /**
     * Sets the value of the dataid property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDATAID(BigInteger value) {
        this.dataid = value;
    }

    /**
     * Gets the value of the versionnum property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getVERSIONNUM() {
        return versionnum;
    }

    /**
     * Sets the value of the versionnum property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setVERSIONNUM(BigInteger value) {
        this.versionnum = value;
    }

    /**
     * Gets the value of the firstname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFIRSTNAME() {
        return firstname;
    }

    /**
     * Sets the value of the firstname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFIRSTNAME(String value) {
        this.firstname = value;
    }

    /**
     * Gets the value of the unlisttype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUNLISTTYPE() {
        return unlisttype;
    }

    /**
     * Sets the value of the unlisttype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUNLISTTYPE(String value) {
        this.unlisttype = value;
    }

    /**
     * Gets the value of the referencenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREFERENCENUMBER() {
        return referencenumber;
    }

    /**
     * Sets the value of the referencenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREFERENCENUMBER(String value) {
        this.referencenumber = value;
    }

    /**
     * Gets the value of the listedon property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLISTEDON() {
        return listedon;
    }

    /**
     * Sets the value of the listedon property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLISTEDON(XMLGregorianCalendar value) {
        this.listedon = value;
    }

    /**
     * Gets the value of the submittedon property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSUBMITTEDON() {
        return submittedon;
    }

    /**
     * Sets the value of the submittedon property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSUBMITTEDON(XMLGregorianCalendar value) {
        this.submittedon = value;
    }

    /**
     * Gets the value of the nameoriginalscript property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNAMEORIGINALSCRIPT() {
        return nameoriginalscript;
    }

    /**
     * Sets the value of the nameoriginalscript property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNAMEORIGINALSCRIPT(String value) {
        this.nameoriginalscript = value;
    }

    /**
     * Gets the value of the comments1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMMENTS1() {
        return comments1;
    }

    /**
     * Sets the value of the comments1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMMENTS1(String value) {
        this.comments1 = value;
    }

    /**
     * Gets the value of the listtype property.
     * 
     * @return
     *     possible object is
     *     {@link LISTTYPE }
     *     
     */
    public ListType getLISTTYPE() {
        return listtype;
    }

    /**
     * Sets the value of the listtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link LISTTYPE }
     *     
     */
    public void setLISTTYPE(ListType value) {
        this.listtype = value;
    }

    /**
     * Gets the value of the lastdayupdated property.
     * 
     * @return
     *     possible object is
     *     {@link LASTDAYUPDATED }
     *     
     */
    public LastDayUpdated getLASTDAYUPDATED() {
        return lastdayupdated;
    }

    /**
     * Sets the value of the lastdayupdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link LASTDAYUPDATED }
     *     
     */
    public void setLASTDAYUPDATED(LastDayUpdated value) {
        this.lastdayupdated = value;
    }

    /**
     * Gets the value of the entityalias property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the entityalias property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getENTITYALIAS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ENTITYALIAS }
     * 
     * 
     */
    public List<EntityAlias> getENTITYALIAS() {
        if (entityalias == null) {
            entityalias = new ArrayList<EntityAlias>();
        }
        return this.entityalias;
    }

    /**
     * Gets the value of the entityaddress property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the entityaddress property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getENTITYADDRESS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ENTITYADDRESS }
     * 
     * 
     */
    public List<EntityAddress> getENTITYADDRESS() {
        if (entityaddress == null) {
            entityaddress = new ArrayList<EntityAddress>();
        }
        return this.entityaddress;
    }

    /**
     * Gets the value of the sortkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSORTKEY() {
        return sortkey;
    }

    /**
     * Sets the value of the sortkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSORTKEY(String value) {
        this.sortkey = value;
    }

    /**
     * Gets the value of the sortkeylastmod property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSORTKEYLASTMOD() {
        return sortkeylastmod;
    }

    /**
     * Sets the value of the sortkeylastmod property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSORTKEYLASTMOD(XMLGregorianCalendar value) {
        this.sortkeylastmod = value;
    }

    /**
     * Gets the value of the delistedon property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDELISTEDON() {
        return delistedon;
    }

    /**
     * Sets the value of the delistedon property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDELISTEDON(XMLGregorianCalendar value) {
        this.delistedon = value;
    }

}
