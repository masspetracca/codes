package it.ccg.tcejb.server.bean.entity.un;

import it.ccg.tcejb.server.logengine.LoggerFactory;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.apache.log4j.Logger;


/**
 * The persistent class for the TCTUNENTIT database table.
 * 
 */
@Entity
@Table(name="TCTUNENTIT")
@NamedQueries({
	@NamedQuery(name="getUnEntitiesById", query="SELECT entity FROM TctUnEntit entity WHERE entity.dataId = :dataId ORDER BY entity.dataId ASC"),
	@NamedQuery(name="getUnEntities", query="SELECT entity FROM TctUnEntit entity ORDER BY entity.dataId ASC"),
	@NamedQuery(name="getUnEntitiesBySrcListDate", query="SELECT entity " +
			   "										 FROM TctUnEntit entity " +
			   "										WHERE entity.dateGenerated = :srcListDate " +
			   "										ORDER BY entity.dataId ASC"),
    @NamedQuery(name="getUnLatestSrcListDate",    query="SELECT MAX(entity.releasedDt) " +
	           "										   FROM TctUnEntit entity"),
	/*
	 * raffaele de lauri
	 * TN_CCG15298
	 */
    @NamedQuery(name="getUnLatestEntities", query="SELECT entity " +
               "								     FROM TctUnEntit entity " +
               "								    WHERE entity.releasedDt = (SELECT MAX(entity2.releasedDt) " +
               "								 							  FROM TctUnEntit entity2)" +
    		   "								    ORDER BY entity.dataId ASC"),
    @NamedQuery(name="deleteUnEveryEntity", query="DELETE FROM TctUnEntit")
})
public class TctUnEntit implements Serializable {
	private static final long serialVersionUID = 1L;
	@Transient
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@Id
	@Column(unique=true, nullable=false, name="DATAID")
	private int dataId;

	@Column(length=1000)
	private String comments1;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date dateGenerated;

    @Temporal( TemporalType.DATE)
	private Date delistOnDt;

	@Column(nullable=false, length=255)
	private String firstName;

	@Column(nullable=false)
	private Timestamp listedOn;

	@Column(nullable=false, length=50)
	private String listTp;

	@Column(length=255)
	private String national2;

	@Column(length=255)
	private String nOrgScript;

	@Column(nullable=false, length=255)
	private String refNumber;

    @Temporal( TemporalType.DATE)
	@Column(nullable=false)
	private Date releasedDt;

	@Column(length=255)
	private String sortKey;

	private Timestamp sortKeyLsMod;

	@Column(nullable=true)
	private Timestamp submitedOn;

	@Column(nullable=false, length=50)
	private String unListTp;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=10)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	private int versionNum;

	//bi-directional many-to-one association to TctUnAddr
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunentit")
	//@Transient
	private Set<TctUnAddr> tctunaddrs;

	//bi-directional many-to-one association to TctUnAlia
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunentit")
	//@Transient
	private Set<TctUnAlia> tctunalias;

	/*//bi-directional many-to-one association to TctUnLisTp
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunentit")*/
	//@Transient
	//private Set<TctUnLisTp> tctunlistps;

	//bi-directional many-to-one association to TctUnLstUp
	@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunentit")
	//@Transient
	private Set<TctUnLstUp> tctunlstups;

	/*@OneToMany(cascade=CascadeType.ALL,mappedBy="tctunentit")
	private Set<TctAggrEntEntity> tctaggrents;*/
	
    public TctUnEntit() {
    }

    /**
     * 
     * @return
     */
	public int getDataId() {
		return this.dataId;
	}

	/**
	 * 
	 * @param dataId
	 */
	public void setDataId(int dataId) {
		this.dataId = dataId;
	}

	/**
	 * 
	 * @return
	 */
	public String getComments1() {
		return this.comments1;
	}

	/**
	 * 
	 * @param comments1
	 */
	public void setComments1(String comments1) {
		if (comments1 != null && comments1.length()>1000){
			ejbLogger.debug(comments1+" >1000 than truncate");
			this.comments1 = comments1.substring(0, 999);
		}else{
			this.comments1 = comments1;
		}
	}

	/**
	 * 
	 * @return
	 */
	public Date getDateGenerated() {
		return this.dateGenerated;
	}

	/**
	 * 
	 * @param dateGenerated
	 */
	public void setDateGenerated(Date dateGenerated) {
		this.dateGenerated = dateGenerated;
	}

	/**
	 * 
	 * @return
	 */
	public Date getDelistOnDt() {
		return this.delistOnDt;
	}

	/**
	 * 
	 * @param delistOnDt
	 */
	public void setDelistOnDt(Date delistOnDt) {
		this.delistOnDt = delistOnDt;
	}
	/*
	 * 
	 * 
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * 
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		if (firstName != null && firstName.length()>255){
			ejbLogger.debug(firstName+" >255 than truncate");
			this.firstName = firstName.substring(0, 254);
		}else{
			this.firstName = firstName;
		}
	}

	/**
	 * 
	 * @return
	 */
	public Timestamp getListedOn() {
		return this.listedOn;
	}

	/**
	 * 
	 * @param listedOn
	 */
	public void setListedOn(Timestamp listedOn) {
		this.listedOn = listedOn;
	}

	/**
	 * 
	 * @return
	 */
	public String getListTp() {
		return this.listTp;
	}

	/**
	 * 
	 * @param listTp
	 */
	public void setListTp(String listTp) {
		if (listTp != null && listTp.length()>50){
			ejbLogger.debug(listTp+" >50 than truncate");
			this.listTp = listTp.substring(0, 49);
		}else{
			this.listTp = listTp;
		}
	}
	
	/**
	 * 
	 * @return
	 */
	public String getNational2() {
		return this.national2;
	}

	/**
	 * 
	 * @param national2
	 */
	public void setNational2(String national2) {
		if (national2 != null && national2.length()>255){
			ejbLogger.debug(national2+" >255 than truncate");
			this.national2 = national2.substring(0, 254);
		}else{
			this.national2 = national2;
		}
	}
	
	/**
	 * 
	 * @return
	 */
	public String getRefNumber() {
		return this.refNumber;
	}

	/**
	 * 
	 * @param refNumber
	 */
	public void setRefNumber(String refNumber) {
		if (refNumber != null && refNumber.length()>50){
			ejbLogger.debug(refNumber+" >50 than truncate");
			this.refNumber = refNumber.substring(0, 49);
		}else{
			this.refNumber = refNumber;
		}
	}

	/**
	 * 
	 * @return
	 */
	public Date getReleasedDt() {
		return this.releasedDt;
	}

	/**
	 * 
	 * @param releasedDt
	 */
	public void setReleasedDt(Date releasedDt) {
		this.releasedDt = releasedDt;
	}

	/**
	 * 
	 * @return
	 */
	public String getSortKey() {
		return this.sortKey;
	}

	/**
	 * 
	 * @param sortKey
	 */
	public void setSortKey(String sortKey) {
		if (sortKey !=null && sortKey.length()>255){
			ejbLogger.debug(sortKey+" >255 than truncate");
			this.sortKey = sortKey.substring(0, 254);
		}else{
			this.sortKey = sortKey;
		}
	}

	/**
	 * 
	 * @return
	 */
	public Timestamp getSortKeyLsMod() {
		return this.sortKeyLsMod;
	}

	/**
	 * 
	 * @param sortKeyLsMod
	 */
	public void setSortKeyLsMod(Timestamp sortKeyLsMod) {
		this.sortKeyLsMod = sortKeyLsMod;
	}

	/**
	 * 
	 * @return
	 */
	public Timestamp getSubmitedOn() {
		return this.submitedOn;
	}

	/**
	 * 
	 * @param submitedOn
	 */
	public void setSubmitedOn(Timestamp submitedOn) {
		this.submitedOn = submitedOn;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getUnListTp() {
		return this.unListTp;
	}

	/**
	 * 
	 * @param unListTp
	 */
	public void setUnListTp(String unListTp) {
		if (unListTp != null && unListTp.length()>50){
			ejbLogger.debug(unListTp+" >50 than truncate");
			this.unListTp = unListTp.substring(0, 49);
		}else{
			this.unListTp = unListTp;
		}
	}
	
	/**
	 * @return the nOrgScript
	 */
	public String getnOrgScript() {
		return nOrgScript;
	}

	/**
	 * @param nOrgScript the nOrgScript to set
	 */
	public void setnOrgScript(String nOrgScript) {
		if (nOrgScript != null && nOrgScript.length()>255){
			ejbLogger.debug(nOrgScript+" >255 than truncate");
			this.nOrgScript = nOrgScript.substring(0, 254);
		}else{
			this.nOrgScript = nOrgScript;
		}
	}

	/**
	 * 
	 * @return
	 */
	public Timestamp getUpdDate() {
		return this.updDate;
	}

	/**
	 * 
	 * @param updDate
	 */
	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	/**
	 * 
	 * @return
	 */
	public String getUpdType() {
		return this.updType;
	}

	/**
	 * 
	 * @param updType
	 */
	public void setUpdType(String updType) {
		this.updType = updType;
	}

	/**
	 * 
	 * @return
	 */
	public String getUpdUser() {
		return this.updUser;
	}

	/**
	 * 
	 * @param updUser
	 */
	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	/**
	 * 
	 * @return
	 */
	public int getVersionNum() {
		return this.versionNum;
	}

	/**
	 * 
	 * @param versionNum
	 */
	public void setVersionNum(int versionNum) {
		this.versionNum = versionNum;
	}
	
	/**
	 * 
	 * @return
	 */
	public Set<TctUnAddr> getTctunaddrs() {
		return this.tctunaddrs;
	}

	/**
	 * 
	 * @param tctunaddrs
	 */
	public void setTctunaddrs(Set<TctUnAddr> tctunaddrs) {
		this.tctunaddrs = tctunaddrs;
	}
	
	/**
	 * 
	 * @return
	 */
	public Set<TctUnAlia> getTctunalias() {
		return this.tctunalias;
	}

	/**
	 * 
	 * @param tctunalias
	 */
	public void setTctunalias(Set<TctUnAlia> tctunalias) {
		this.tctunalias = tctunalias;
	}
	
	/**
	 * 
	 * @return
	 */
	public Set<TctUnLstUp> getTctunlstups() {
		return this.tctunlstups;
	}

	/**
	 * 
	 * @param tctunlstups
	 */
	public void setTctunlstups(Set<TctUnLstUp> tctunlstups) {
		this.tctunlstups = tctunlstups;
	}
}