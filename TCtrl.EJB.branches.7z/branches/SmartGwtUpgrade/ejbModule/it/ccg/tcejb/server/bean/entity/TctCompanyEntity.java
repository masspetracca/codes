package it.ccg.tcejb.server.bean.entity;


import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Set;


/**
 * The persistent class for the TCTCOMPANY database table.
 * 
 */
@Entity
@Table(name="TCTCOMPANY")

/*
 * Raffaele De Lauri
 * TN_CCG16966
 * 21/04/2015
 * cambio il tipo del parametro companyCode nella query getCompanyByCompanyCode
 */
@NamedQueries({
	@NamedQuery(name="getCompanyByCompanyCode", query="SELECT comp FROM TctCompanyEntity comp WHERE comp.companyCode in :companyCode ")
})
public class TctCompanyEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CMPNID")
	private int cmpnId;

	@Column(nullable=false, length=30)
	private String companyCode;

	@Column(nullable=false, length=55)
	private String companyName;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal thrsldHr1;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal thrsldHr2;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal thrsldLr1;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal thrsldLr2;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal thrsldMr1;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal thrsldMr2;
	
	@Column(nullable=false, length=2)
	private String riskProf;
	
	@Column(length=50)
	private String readMethod;
	
	@Column(length=50)
	private String writMethod;
	
	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=50)
	private String updUser;

	//bi-directional many-to-one association to TctClientHEntity
	@OneToMany(mappedBy="tctcompany")
	private Set<TctClientHEntity> tctclienths;

	//bi-directional many-to-one association to TctFalNegHEntity
	//@OneToMany(mappedBy="tctcompany")
	@Transient
	private Set<TctFalNegHEntity> tctfalneghs;

	//bi-directional many-to-one association to TctFalNegtEntity
	@OneToMany(mappedBy="tctcompany")
	private Set<TctFalNegtEntity> tctfalnegts;

	//bi-directional many-to-one association to TctRunRegEntity
	@OneToMany(mappedBy="tctcompany")
	private Set<TctRunRegEntity> tctrunregs;

	//bi-directional many-to-one association to TctUserEntity
	@OneToMany(mappedBy="tctcompany")
	private Set<TctUserEntity> tctusers;

	//bi-directional many-to-one association to TctClnSrcHEntity
	@OneToMany(mappedBy="tctcompany")
	private Set<TctClnSrcHEntity> tctclnsrches;
	
	//bi-directional many-to-one association to TctCorrLstEntity
	@OneToMany(mappedBy="tctcompany")
	private Set<TctCorrLstEntity> tctcorrlsts;

    public TctCompanyEntity() {
    }

	public int getCmpnId() {
		return this.cmpnId;
	}

	public void setCmpnId(int cmpnId) {
		this.cmpnId = cmpnId;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCompanyName() {
		return this.companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public BigDecimal getThrsldHr1() {
		return this.thrsldHr1;
	}

	public void setThrsldHr1(BigDecimal thrsldHr1) {
		this.thrsldHr1 = thrsldHr1;
	}

	public BigDecimal getThrsldHr2() {
		return this.thrsldHr2;
	}

	public void setThrsldHr2(BigDecimal thrsldHr2) {
		this.thrsldHr2 = thrsldHr2;
	}

	public BigDecimal getThrsldLr1() {
		return this.thrsldLr1;
	}

	public void setThrsldLr1(BigDecimal thrsldLr1) {
		this.thrsldLr1 = thrsldLr1;
	}

	public BigDecimal getThrsldLr2() {
		return this.thrsldLr2;
	}

	public void setThrsldLr2(BigDecimal thrsldLr2) {
		this.thrsldLr2 = thrsldLr2;
	}

	public BigDecimal getThrsldMr1() {
		return this.thrsldMr1;
	}

	public void setThrsldMr1(BigDecimal thrsldMr1) {
		this.thrsldMr1 = thrsldMr1;
	}

	public BigDecimal getThrsldMr2() {
		return this.thrsldMr2;
	}

	public void setThrsldMr2(BigDecimal thrsldMr2) {
		this.thrsldMr2 = thrsldMr2;
	}

	/**
	 * @return the riskProf
	 */
	public String getRiskProf() {
		return riskProf;
	}

	/**
	 * @param riskProf the riskProf to set
	 */
	public void setRiskProf(String riskProf) {
		this.riskProf = riskProf;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

	public Set<TctClientHEntity> getTctclienths() {
		return this.tctclienths;
	}

	public void setTctclienths(Set<TctClientHEntity> tctclienths) {
		this.tctclienths = tctclienths;
	}
	
	public Set<TctFalNegHEntity> getTctfalneghs() {
		return this.tctfalneghs;
	}

	public void setTctfalneghs(Set<TctFalNegHEntity> tctfalneghs) {
		this.tctfalneghs = tctfalneghs;
	}
	
	public Set<TctFalNegtEntity> getTctfalnegts() {
		return this.tctfalnegts;
	}

	public void setTctfalnegts(Set<TctFalNegtEntity> tctfalnegts) {
		this.tctfalnegts = tctfalnegts;
	}
	
	public Set<TctRunRegEntity> getTctrunregs() {
		return this.tctrunregs;
	}

	public void setTctrunregs(Set<TctRunRegEntity> tctrunregs) {
		this.tctrunregs = tctrunregs;
	}
	
	public Set<TctUserEntity> getTctusers() {
		return this.tctusers;
	}

	public void setTctusers(Set<TctUserEntity> tctusers) {
		this.tctusers = tctusers;
	}
	
	public Set<TctClnSrcHEntity> getTctclnsrches() {
		return this.tctclnsrches;
	}

	public void setTctclnsrches(Set<TctClnSrcHEntity> tctclnsrches) {
		this.tctclnsrches = tctclnsrches;
	}

	/**
	 * @return the readMethod
	 */
	public String getReadMethod() {
		return readMethod;
	}

	/**
	 * @param readMethod the readMethod to set
	 */
	public void setReadMethod(String readMethod) {
		this.readMethod = readMethod;
	}

	/**
	 * @return the writMethod
	 */
	public String getWritMethod() {
		return writMethod;
	}

	/**
	 * @param writMethod the writMethod to set
	 */
	public void setWritMethod(String writMethod) {
		this.writMethod = writMethod;
	}
	
}