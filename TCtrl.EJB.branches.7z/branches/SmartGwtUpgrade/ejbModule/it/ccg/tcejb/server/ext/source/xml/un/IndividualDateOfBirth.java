package it.ccg.tcejb.server.ext.source.xml.un;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{}TYPE_OF_DATE" minOccurs="0"/>
 *         &lt;choice minOccurs="0">
 *           &lt;element ref="{}NOTE"/>
 *           &lt;element ref="{}DATE"/>
 *           &lt;element ref="{}YEAR"/>
 *           &lt;sequence>
 *             &lt;element ref="{}FROM_YEAR"/>
 *             &lt;element ref="{}TO_YEAR"/>
 *           &lt;/sequence>
 *         &lt;/choice>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "typeofdate",
    "note",
    "date",
    "year",
    "fromyear",
    "toyear"
})
@XmlRootElement(name = "INDIVIDUAL_DATE_OF_BIRTH")
public class IndividualDateOfBirth {

    @XmlElement(name = "TYPE_OF_DATE")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String typeofdate;
    @XmlElement(name = "NOTE")
    protected String note;
    @XmlElement(name = "DATE")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar date;
    @XmlElement(name = "YEAR")
    protected BigInteger year;
    @XmlElement(name = "FROM_YEAR")
    protected BigInteger fromyear;
    @XmlElement(name = "TO_YEAR")
    protected BigInteger toyear;

    /**
     * Gets the value of the typeofdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTYPEOFDATE() {
        return typeofdate;
    }

    /**
     * Sets the value of the typeofdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTYPEOFDATE(String value) {
        this.typeofdate = value;
    }

    /**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNOTE() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNOTE(String value) {
        this.note = value;
    }

    /**
     * Gets the value of the date property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDATE() {
        return date;
    }

    /**
     * Sets the value of the date property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDATE(XMLGregorianCalendar value) {
        this.date = value;
    }

    /**
     * Gets the value of the year property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getYEAR() {
        return year;
    }

    /**
     * Sets the value of the year property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setYEAR(BigInteger value) {
        this.year = value;
    }

    /**
     * Gets the value of the fromyear property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getFROMYEAR() {
        return fromyear;
    }

    /**
     * Sets the value of the fromyear property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setFROMYEAR(BigInteger value) {
        this.fromyear = value;
    }

    /**
     * Gets the value of the toyear property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTOYEAR() {
        return toyear;
    }

    /**
     * Sets the value of the toyear property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTOYEAR(BigInteger value) {
        this.toyear = value;
    }

}