
public class Persona {
	private String nome;
	private String cognome;
	private Address indirizzo;

	// Setters:
	public void setNome(String Nome) {
		System.out.println("+ setNome():"+getNome());
	}
	public void setCognome(String Cognome) {
		System.out.println("+ setCognome():"+getCognome());
	}
	public void setIndirizzo(String Indirizzo) {
		System.out.println("+ setIndirizzo():"+getIndirizzo());
	}
	// Getters:
	public String getNome() {
		System.out.println("+ getNome():"+getNome());
		return getNome();
	}
	public String getCognome() {
		System.out.println("+ getCognome():"+getCognome());
		return getCognome();
	}
	public Address getIndirizzo() {
		System.out.println("+ getIndirizzo():"+getIndirizzo());
		return getIndirizzo();
	}
}