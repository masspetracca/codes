import java.util.List;

public class Proprietario extends Persona {
	private List<Address> unitaPossedute;
	
	// Collection Accessors:
	public void addUnitaPossedute (int Address) {
		System.out.println("+addUnitaPossedute():"+Address);
	}
	public void removeUnitaPossedute(int Address) {
		System.out.println("+removeUnitaPossedute()"+Address);
	}
	public int unitaPosseduteSize(int Address) {
		System.out.println("+unitaPosseduteSize()"+Address);
		return Address;
	}
	public boolean unitaPosseduteEPresente(boolean upep) {
		System.out.println("+unitaPosseduteEPresente()"+upep);
		return upep;
	}
	}
