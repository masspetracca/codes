import java.util.List;

public class Condominio {
	private Address indirizzo;
	private String scala;
	private Persona amministratore;
	private List<Address> unita;

	// Setters:
	public void setIndirizzo(String Indirizzo) {
		System.out.println("+ setIndirizzo():"+getIndirizzo());
	}
	public void setScala(String Scala) {
		System.out.println("+ setscala():"+getScala());
	}
	public void setAmministratore(String Amministratore) {
		System.out.println("+ setAmministratore():"+getAmministratore());
	}
	// Getters:
	public Address getIndirizzo() {
		return getIndirizzo();
	}
	public String getScala() {
		return getScala();
	}
	public Persona getAmministratore() {
		return getAmministratore();
	}
	// Collection Accessors:
	public void addUnita(Address Address) {
	}
	public void removeUnita(Address Address) {
	}
	public int unitaSize() {
		return 0;
	}
	public boolean unitaEPresente(Address Address) {
		return false;
	}
	}