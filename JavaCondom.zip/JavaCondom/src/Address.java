import java.util.List;

public class Address {
	private String interno;
	private String scala;
	private List<Proprietario> proprietari;
	private Proprietario contatto;
	
	// Setters:
	public void setInterno(String Interno) {
	}
	public void setScala(String Scala) {
	}
	public void setContatto(Proprietario Contatto) {
	}
	// Getters:
	public String getInterno() {
		return getInterno();
	}
	public String getScala() {
		return getScala();
	}
	public Proprietario getContatto() {
		return getContatto();
	}
	// Collection Accessors:
	public void addProprietari (Proprietario Proprietario) {
	}
	public void removeProprietari(Proprietario Proprietario) {
	}
	public int ProprietariSize() {
		return 0;
	}
	public boolean ProprietariEPresente(Proprietario Proprietario) {
		return false;
	}
}
