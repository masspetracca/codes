
public class MainCondom {


	private static String Amministratore;
	private static String Scala = "A";
	private static String Indirizzo = "G.B.Falda, 22";

	public static void main(String[] args) {
		System.out.println("*****INIZIO *****");
		condom();
		address();
 		persona();
		proprietario();
		System.out.println("*****FINE *****");
	}

	private static void proprietario() {
		System.out.println("+Proprietario()");
		Proprietario prop = new Proprietario();
		prop.addUnitaPossedute(10);
		prop.unitaPosseduteSize(1000);
		prop.unitaPosseduteEPresente(true);
	}

	private static void persona() {
		System.out.println("+Persona()");
		Persona pers = new Persona();
	}

	private static void address() {
		System.out.println("+Address()");
		Address addr = new Address();
	}

	private static void condom() {
		System.out.println("+Condominio()");
		Condominio cond = new Condominio();		
		cond.setAmministratore(Amministratore);
		cond.setScala(Scala);
		cond.setIndirizzo(Indirizzo);
	}
}
