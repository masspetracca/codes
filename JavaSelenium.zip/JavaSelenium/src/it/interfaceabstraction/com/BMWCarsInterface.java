package it.interfaceabstraction.com;

public interface BMWCarsInterface {
	
	public void headsUpNavigation();

}
