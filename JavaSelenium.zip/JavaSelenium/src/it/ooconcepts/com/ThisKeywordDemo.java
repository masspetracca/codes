package it.ooconcepts.com;

public class ThisKeywordDemo {

	public static void main(String[] args) {
		System.out.println("###Car###");
		Car c1 = new Car();
		Car c2 = new Car();
		
		c1.setMake("BMW");
		System.out.println(c1.getMake());
		
		c2.setMake("Benz");
		System.out.println(c2.getMake());
		
		System.out.println("###Car1###");
		Car1 c3 = new Car1(3, 4);
		Car1 c4 = new Car1();
		
		c3.setMake("BMW");
		System.out.println(c3.getMake());
		
		c4.setMake("Benz");
		System.out.println(c4.getMake());
	}
}