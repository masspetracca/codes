package it.ooconcepts.com;

public class ClassDemo {
	
	String str2 = "Hi There !!!";
	
	/***
	 * [][][][CarClass - c1][CarClass - c2][][][][][]
	 * @param args
	 */

	public static void main(String[] args) {
		String str1 = "Hello Java";
		
		System.out.println(str1);
		
		for (int i=0; i < args.length; i++) {
			System.out.println(args[i]);
			
		}
	}
}