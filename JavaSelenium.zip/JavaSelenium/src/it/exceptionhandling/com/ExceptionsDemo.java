package it.exceptionhandling.com;

import java.sql.SQLException;

public class ExceptionsDemo {
	public static void main(String [] args) {
		Account acc = new Account();
		try {
		System.out.println("1^ first line");
		acc.withdraw(100);
		System.out.println("After tryng the withdraw method");
		} 
		catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println("Try again at some other point/driver");
		} 
		finally {
			System.out.println("Always executed");
		}
	}
}
