package it.datatypes.com;

public class StringDemo {

	public static void main(String[] args) {
		// String Literal - String Constant Pool
		String str1 = "Hello";
		//System.out.println("String: " + str1);
		
		String str3 = "Hello";
		//System.out.println("String: " + str3);
		
		// String Object - Heap
		String str2 = new String("Welcome");
		//System.out.println("String: " + str2);

		
		String str4 = new String("Welcome");
		//System.out.println("String: " + str4);
		
		// Strings
		
		str1 = "More Hello";
		//System.out.println("String: " + str1);

		String stradd = str1 + str2;
		//System.out.println("String: " + stradd);

	}

}
