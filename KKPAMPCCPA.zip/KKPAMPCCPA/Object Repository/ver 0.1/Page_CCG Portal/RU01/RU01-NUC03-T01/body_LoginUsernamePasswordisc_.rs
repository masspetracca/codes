<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_LoginUsernamePasswordisc_</name>
   <tag></tag>
   <elementGuidId>1af62d06-6ffa-4de8-ba48-f3c78c04623e</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onload</name>
      <type>Main</type>
      <value>javascript:enableError(false,'')</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
		
			Login
			
				
					
						Username:
						
						
					
					
						Password:
						
					
					
					
						
						
					
				
				
					
						
					
				
			


		
		
		
		
		//'&quot;]]>>isc_loginRequired
			//
			// Embed this whole script block VERBATIM into your login page to enable
			// SmartClient RPC relogin.
 

			if (!window.isc &amp;&amp; (window.opener != null || window.top != window)) {
				while (document.domain.indexOf(&quot;.&quot;) != -1) {
					try {
						if (window.opener &amp;&amp; window.opener.isc) break;
						if (window.top.isc) break;
					} catch (e) {
						try {
							document.domain = document.domain.replace(/.*?\./, '');
						} catch (ee) {
							break;
						}
					}
				} 
			}
			
			var isc = top.isc ? top.isc : window.opener ? window.opener.isc : null;
			if (isc &amp;&amp; isc.RPCManager) isc.RPCManager.delayCall(&quot;handleLoginRequired&quot;, [window]);
			
		



	
</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//body</value>
   </webElementXpaths>
</WebElementEntity>
