package it.ccg.fpm.fdos.batch;

public class DosInstallation {
		public static void main(String[] args) throws Exception {
//		public DosInstallation() {
			System.out.println("Inizio esecuzione <DosInstallation>");
			
			Runtime runtime = Runtime.getRuntime(); 
			String com = "cmd /C start ";
			String com1 = "download-freefileviewer.exe ";
			System.out.println("cmd: "+com+com1);
			try { 
			    Process process = runtime.exec(com+com1); 
					System.out.println("Fine esecuzione <DosInstallation>");
			        System.exit(0);
			} catch (Exception e) {
				System.out.println("Fine anomala <DosInstallation>");
		        System.exit(1);				
			} 
		}
}
