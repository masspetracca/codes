package it.ccg.test.collaudo.server.bus;



import java.io.IOException;
import java.sql.SQLException;





/**
 * Main Batch
 */
  
public class MainBatch {
 public static void main(String[] args) throws Exception {
	 int returnCode = 0;

	 //Main Batch
//	  System.out.println("Inizio <MainBatch>");	
//	  if (returnCode == 0) { 
//		  //Load Data File
//		  MainData(returnCode);
//	  }  
//	  
//	  if (returnCode != 0) {
//		 System.out.println("Errore nella fase  <MainBatch> - verificare !");
//	  }
//	  if (returnCode == 0) { 
		  //General Batch
		  GeneralBatch(returnCode);
//	  }  
  
		  if (returnCode != 0) {
			  System.out.println("Errore nella fase  <MainBatch> - verificare !");
		  }
		  ResultDb2(returnCode);
		  if (returnCode != 0) {
			  System.out.println("Errore nella fase  <ResultDb2> - verificare !");
		  }
		  
	  System.out.println("Fine esecuzione <MAIN BATCH>");
  }




	private static void GeneralBatch(int returnCode) throws IOException, SQLException, ClassNotFoundException, IllegalAccessException, InstantiationException {
			GeneralBatch gb = new GeneralBatch(returnCode);
}


	private static void ResultDb2(int returnCode) throws IOException {
		ResultDb2 rdb2 = new ResultDb2(returnCode);
	
}


//	private static void MainData(int returnCode) throws IOException, DocumentException {
//			MainData md = new MainData(returnCode);	
//	}
}


