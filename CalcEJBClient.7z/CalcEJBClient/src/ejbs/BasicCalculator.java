package ejbs;
/**
 * Remote interface for Enterprise Bean: BasicCalculator
 */
public interface BasicCalculator extends javax.ejb.EJBObject {
	public double addTwoNumbers(double first, double second) throws java.rmi.RemoteException;
	public double subtractTwoNumbers(double first, double second) throws java.rmi.RemoteException;
}
