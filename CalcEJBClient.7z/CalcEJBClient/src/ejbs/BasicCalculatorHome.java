package ejbs;
/**
 * Home interface for Enterprise Bean: BasicCalculator
 */
public interface BasicCalculatorHome extends javax.ejb.EJBHome {
	/**
	 * Creates a default instance of Session Bean: BasicCalculator
	 */
	public ejbs.BasicCalculator create()
		throws javax.ejb.CreateException,
		java.rmi.RemoteException;
}
