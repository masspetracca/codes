package it.ccg.test.collaudo.server.bus;



import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

public class PopulateDb {
	
	//Table access keys
	private static String kArea = ""; 
	private static String kStato = ""; 
	private static String kFreq ="";
	private static String kTipo ="";
	
	String nodeGifDtData;
	String nodeIDGifData;
	String nodeGFDescData;
	String nodeAmountData;


	private String TableHQBLOAD = PropertyFiles.getTabName1();

	private static String vcol3 = "";
	private static String vcol4 = "";
	private static String vcol5 = "";

	private static String sdate =null;
	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

//	private static String tabFreq ="";
	private int ctrIns;
//	private int ctrUpd;
 	private int returnCode = 0;
 	private static String sqlUpdate;
//	
//
//	private static Object rs;
	
	PreparedStatement st;
	private String sqlDelete;
	private int ctrDel;


	public PopulateDb(String kGifDt, String kIDGifData) throws ClassNotFoundException, IOException, SQLException, IllegalAccessException, InstantiationException {
		
		sqlUpdate=" ";
		//upate table
		 sqlUpdate = kGifDt+" "+ kIDGifData;
		 System.out.println("SQL>>"+ sqlUpdate);

//		System.out.println("SQL>>"+kIDGifData.substring(1,kIDGifData.length())+", "); 		
		++ctrIns;
		//setting upd parameters
		TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 
		upd.setSqlUpdate(sqlUpdate);	
		
}



}


	
		
							
   

