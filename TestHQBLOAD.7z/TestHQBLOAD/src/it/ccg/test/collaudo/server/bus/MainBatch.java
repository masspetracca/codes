package it.ccg.test.collaudo.server.bus;



import java.io.IOException;
import java.sql.SQLException;





/**
 * Main Batch
 */
  
public class MainBatch {
 public static void main(String[] args) throws Exception {
	 int returnCode = 0;

	 //Main Batch
	  System.out.println("Inizio <MainBatch>");	
	  //ResultDb2
	   //ResultDb2(returnCode);
  
	   if (returnCode != 0) {
		  System.out.println("Errore nella fase  <ResultDb2> - verificare !");
	   }
	  //General Batch
		   GeneralBatchBLOAD(returnCode);
	   
	  if (returnCode != 0) {
		  System.out.println("Errore nella fase  <MainBatch> - verificare !");
	  }


	  System.out.println("Fine esecuzione <MainBatch>");
  }



	private static void ResultDb2(int returnCode) throws IllegalAccessException, InstantiationException, ClassNotFoundException, IOException, SQLException {
		ResultDb2 rdb2 = new ResultDb2(returnCode);
	}



	private static void GeneralBatchBLOAD(int returnCode) throws IOException, IllegalAccessException, InstantiationException, ClassNotFoundException, SQLException {
		GeneralBatchBLOAD rdb2 = new GeneralBatchBLOAD(returnCode);
	}



}


