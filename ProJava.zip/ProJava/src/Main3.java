import java.util.Calendar;

public class Main3 {
   public static void main(String[] args) {
     System.out.println(new Order().toString());
      
     SalesOrder order = new SalesOrder(Calendar.getInstance(), "CONFIRMED");
     order.setId(123L);
        
     System.out.println(order);
        
     SalesOrder order2 = new SalesOrder(Calendar.getInstance(), "DELIVERED");
        
     System.out.println(order.equals(order2)+"-->CONFIRMED"); // <--- order ed order2 sono oggetti distinti quindi equals ritorna FALSE
        
     SalesOrder order3 = order;
     System.out.println(order.equals(order3)+"-->DELIVERED"); // <--- order ed order3 sono lo stesso oggetto quindi equals ritorna TRUE
  }
}