import java.util.Calendar;

public class Order {
    private Long id;
    protected String status;
    private Calendar orderDate;
    
    public Order() {
        
    }
    public Order(Calendar orderDate, String status) {
        this.orderDate = orderDate;
        this.status = status;
    }
	public void createInvoice(String filename) {
		// TODO Auto-generated method stub
		
	}
	protected String getId() {
		// TODO Auto-generated method stub
		return null;
	}
	protected Calendar getOrderDate() {
		// TODO Auto-generated method stub
		return null;
	}
}