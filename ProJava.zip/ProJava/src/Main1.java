import java.util.Date;

public class Main1 {
    public static String converti(Object obj) {
        if(obj instanceof String) {
            return ((String) obj).toUpperCase();
        } else if(obj instanceof StringBuffer) {
            return ((StringBuffer) obj).toString().toUpperCase();
        }
        
        return obj.toString();
    }
    
    public static void main(String[] args) {        
        System.out.println(converti("abc"));                    //<--- L'output sar� ABC (entro nel 1� if del metodo converti)
        System.out.println(converti(new StringBuffer("def")));  //<--- L'output sar� DEF (entro nel 2� if del metodo converti)
        System.out.println(converti(new Date()));               //<--- L'output sar� Wed Apr 04 12:05:29 CEST 2018 (nessuna delle condizioni del metodo converti viene verificata)
    }
}