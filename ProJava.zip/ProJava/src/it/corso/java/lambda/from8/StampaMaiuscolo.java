package it.corso.java.lambda.from8;

@FunctionalInterface
public interface StampaMaiuscolo {
	public String stampa(String testo);
}
