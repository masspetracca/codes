package it.corso.java.lambda.from8;

@FunctionalInterface
public interface FormaGeometrica {
	public double calcolaArea(double lato1, double lato2);
}
