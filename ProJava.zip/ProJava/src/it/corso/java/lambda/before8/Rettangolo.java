package it.corso.java.lambda.before8;

public class Rettangolo implements FormaGeometrica {
	@Override
	public double calcolaArea(double lato1, double lato2) {
		return lato1*lato2;
	}
}
