package it.corso.java.lambda.before8;

public class Main {

	public static void main(String[] args) {
		FormaGeometrica r1 = new Rettangolo();
		r1.calcolaArea(3, 4);
	}
}
