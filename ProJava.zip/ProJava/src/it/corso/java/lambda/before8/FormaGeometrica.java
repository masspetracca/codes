package it.corso.java.lambda.before8;

public interface FormaGeometrica {
	public double calcolaArea(double lato1, double lato2);
}
