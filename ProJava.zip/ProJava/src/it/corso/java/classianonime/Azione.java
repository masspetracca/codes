package it.corso.java.classianonime;

public interface Azione {
	public void eseguiAzione();
}
