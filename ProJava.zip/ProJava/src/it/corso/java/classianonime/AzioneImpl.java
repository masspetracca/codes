package it.corso.java.classianonime;

public class AzioneImpl implements Azione{

	@Override
	public void eseguiAzione() {
		System.out.println("sono nella classe AzioneImpl");
	}

}
