package it.corso.java.interfacce;

public class FormaGeometrica implements GeneraDati {
	private double lato1;
	private double lato2;
	private double lato3;
	private double lato4;
	private double lato5;
	
	/**
	 * @return the lato1
	 */
	public double getLato1() {
		return lato1;
	}
	/**
	 * @param lato1 the lato1 to set
	 */
	public void setLato1(double lato1) {
		this.lato1 = lato1;
	}
	/**
	 * @return the lato2
	 */
	public double getLato2() {
		return lato2;
	}
	/**
	 * @param lato2 the lato2 to set
	 */
	public void setLato2(double lato2) {
		this.lato2 = lato2;
	}
	/**
	 * @return the lato3
	 */
	public double getLato3() {
		return lato3;
	}
	/**
	 * @param lato3 the lato3 to set
	 */
	public void setLato3(double lato3) {
		this.lato3 = lato3;
	}
	/**
	 * @return the lato4
	 */
	public double getLato4() {
		return lato4;
	}
	/**
	 * @param lato4 the lato4 to set
	 */
	public void setLato4(double lato4) {
		this.lato4 = lato4;
	}
	/**
	 * @return the lato5
	 */
	public double getLato5() {
		return lato5;
	}
	/**
	 * @param lato5 the lato5 to set
	 */
	public void setLato5(double lato5) {
		this.lato5 = lato5;
	}
	
	public double calcolaPerimetro() {
		return 0; /*calcolo perimetro*/
	}
	
	public double calcolaArea() {
		return 0; /*calcolo area*/
	}
	@Override
	public String generaXML() {
		return null;
	}
}
