package it.corso.java.interfacce;

public interface GeneraDati {
	public String generaXML();
}
