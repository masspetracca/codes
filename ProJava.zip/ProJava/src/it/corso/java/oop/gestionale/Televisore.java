package it.corso.java.oop.gestionale;

public class Televisore extends ProdottoElettronico {

}
