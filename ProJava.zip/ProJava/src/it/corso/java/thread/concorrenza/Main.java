package it.corso.java.thread.concorrenza;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;

import it.corso.java.thread.concorrenza.GetSitePage;
import it.corso.java.thread.concorrenza.GetSitePageExecutor;
import it.corso.java.thread.concorrenza.GetSitePageForJoin;

public class Main {

	public static void main(String[] args) {
		Main m = new Main();
		
//		try {
//			m.esempioConcorrenzaThread();
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
		
//		try {
//			m.esempioConcorrenzaExecutor();
//		} catch (InterruptedException | ExecutionException e) {
//			e.printStackTrace();
//		}
		
		m.esempioConcorrenzaForkJoin();
	}
	
	private void esempioConcorrenzaForkJoin() {
		ForkJoinPool f = new ForkJoinPool();
		
		System.out.println(f.invoke(new GetSitePageForJoin("http://www.paolopreite.it")));
		System.out.println(f.invoke(new GetSitePageForJoin("http://www.google.it")));
		
		f.shutdown();
	}
	
	private void esempioConcorrenzaExecutor() throws InterruptedException, ExecutionException {
		List<Callable<String>> siti = new ArrayList<Callable<String>>();
		
		siti.add(new GetSitePageExecutor("http://www.paolopreite.it"));
		siti.add(new GetSitePageExecutor("http://www.google.it"));
		
		ExecutorService ex = Executors.newSingleThreadExecutor();
		
		List<Future<String>> out = ex.invokeAll(siti);
		
		for (Future<String> future : out) {
			System.out.println(future.get());
		}
		
		ex.shutdown();
	}
	
	private void esempioConcorrenzaThread() throws InterruptedException {
		
		GetSitePage s1 = new GetSitePage("http://www.paolopreite.it");
		GetSitePage s2 = new GetSitePage("http://www.google.it");
		
		s1.start();
		s2.start();
		
		s1.join();
		s2.join();
		
		System.out.println("OUTPUT PAOLOPREITE");
		System.out.println(s1.getContent());
		
		
		System.out.println("OUTPUT GOOGLE");
		System.out.println(s2.getContent());
	}
	

}
