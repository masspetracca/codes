package it.corso.java.thread.pool.banca;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BancaCassa {
	private final static int CLIENTI_DA_SERVIRE = 5;
	private final int DIPENDENTI_ALLA_CASSA = 2;
	
	private BlockingQueue<Runnable> codaCassa = new ArrayBlockingQueue<Runnable>(20, true);
	private ExecutorService dipendentiDisponibili = Executors.newFixedThreadPool(DIPENDENTI_ALLA_CASSA);

	public static void main(String[] args) {
		System.out.println("Nella banca ci sono " + CLIENTI_DA_SERVIRE + " clienti che stanno andando alla cassa");

		BancaCassa bcassa = new BancaCassa();
		bcassa.arrivoClientiAllaCassa();
		bcassa.servizioClienti();
	}

	private void arrivoClientiAllaCassa() {
		for (int i = 0; i <= CLIENTI_DA_SERVIRE; i++) {
			try {
				/* il cliente viene inserito in coda */
				codaCassa.put(new Cliente(i));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void servizioClienti() {
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					try {
						/* il primo cliente disponibile viene servito ... */
						dipendentiDisponibili.execute(codaCassa.take());
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}).start();
	}
}
