package it.corso.java.thread.pool.banca;

public class Saldi {
int saldo = 1000;

public int getSaldo() {
	return saldo;
}

public void setSaldo(int saldo) {
	this.saldo = saldo;
}
}
