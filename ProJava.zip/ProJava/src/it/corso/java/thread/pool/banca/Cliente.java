package it.corso.java.thread.pool.banca;

import java.util.Random;

public class Cliente implements Runnable {
	private int numeroTicket;
	private int sumCard = 10;
	private int saldoCard;
	private it.corso.java.thread.pool.banca.Saldi Saldi;

	public Cliente(int numeroTicket) {
		if (numeroTicket >0){
			System.out.println("E' arrivato un nuovo cliente ed ha preso il numero " + numeroTicket);
			this.numeroTicket = numeroTicket;

			Saldi si = new Saldi();
			si.setSaldo(sumCard+si.getSaldo());
			System.out.println("Saldo:" + si.getSaldo());	
		}
	}

	public void run() {
		/* il cliente ordina i bancomat al dipendente presente alla cassa */
		richiediBmatCard();
	}

	private void richiediBmatCard() {
		if (numeroTicket >0){
			System.out.println("Viene servito il cliente numero " + numeroTicket);			
		}

		

		/* imposto una durata random per ciascun cliente... */
		Random r = new Random();

		/* per semplicit� ipotizzo che ogni cliente impieghi tra 5 e 20 secondi per prendere la sua Bmat Card */
		int tempoImpiegatoPerConsegnaCard = (r.nextInt(15) + 5)*1000;
		saldoCard = Saldi.getSaldo();

		try {
			/* 
			 * il thread viene sospeso per tempoImpiegatoPerAcquisto millisecondi.
			 * Quest'attesa equivale al cliente che sta effettuando l'ordine al dipendente della Cassa 
			 */
			Thread.sleep(tempoImpiegatoPerConsegnaCard);
			Thread.sleep(saldoCard);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		if (numeroTicket >0){
			System.out.println("Il cliente che aveva il numero " + numeroTicket + " ha ricevuto la b.mat Card in " + tempoImpiegatoPerConsegnaCard/1000 + " secondi");
			System.out.println("Il cliente ha saldo nella nuova Bmat Card di "  + saldoCard);
		}
	}

	private void Saldi(int s) {
		Saldi sa = new Saldi();
		
	}


}