package it.corso.java.thread;

public class Main {

	public static void main(String[] args)  {
		EsempioThread et = new EsempioThread();
		EsempioThread et1 = new EsempioThread();
		EsempioThread et2 = new EsempioThread();

		// Avvio il Thread
		//et.start();	
		String name = "Thread:1";
		et.setName(name);
		et.start();

		String name1 = "Thread:2";
		et1.setName(name1);
		et1.start();

		String name2 = "Thread:3";
		et2.setName(name2);
		et2.start();
		
		// Override runnable
		Thread t = new Thread(new EsempioRunnable());
		t.start();
	}

}
