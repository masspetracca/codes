package it.corso.java.string;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class EsempiStringa2 {

	@Test
	public void contaOccorrenze() {
		EsempiStringa es = new EsempiStringa();
		
		String testo = "Oggi � il giorno del mio compleanno";
		
		int nOccorrenze = 3;
		
		String token = "oggi";
		assertEquals("Il numero delle occorrenze: ",nOccorrenze, es.contaOccorrenze(testo, token));
		assertNotNull("La variabile non � null",testo);
	}
}
