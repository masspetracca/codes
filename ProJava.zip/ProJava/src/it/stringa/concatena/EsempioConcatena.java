package it.stringa.concatena;
 
public class EsempioConcatena{
    public static void main(String[] args){
        System.out.println(sottostringa("testo con pi� di tre lettere"));
        System.out.println(sottostringa("tre"));
        System.out.println(sottostringa("123"));
      }
 
    public static String sottostringa(String testo) {
        if(testo.length() > 3) {
            return testo.substring(0, 3);
        }
  
        return testo;
    }
}