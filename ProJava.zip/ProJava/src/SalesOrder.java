import java.util.Calendar;

public class SalesOrder extends Order {
    public SalesOrder(Calendar orderDate, String status) {
        super(orderDate, status);
    }
 
    @Override
    public boolean equals(Object obj) {
        if(obj != null && obj instanceof SalesOrder) {
            if(((SalesOrder)obj).getId() == getId()) {
                return true;
            }
        }
        
        return false;
    }

	public void setId(long l) {
		return;
		
	}
}