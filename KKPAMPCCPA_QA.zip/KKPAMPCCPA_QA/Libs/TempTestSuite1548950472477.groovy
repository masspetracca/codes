import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.reporting.ReportUtil
import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.testdata.TestDataColumn
import groovy.lang.MissingPropertyException
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import internal.GlobalVariable as GlobalVariable

Map<String, String> suiteProperties = new HashMap<String, String>();


suiteProperties.put('id', 'Test Suites/Imported from Selenium IDE Scripts/Test Suite/Tsuite')

suiteProperties.put('name', 'Tsuite')

suiteProperties.put('description', '')
 

DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())



RunConfiguration.setExecutionSettingFile("C:\\Users\\mpetracc\\Katalon Studio\\KKPAMPCCPA_QA\\Reports\\Imported from Selenium IDE Scripts\\Test Suite\\Tsuite\\20190131_170112\\execution.properties")

TestCaseMain.beforeStart()

TestCaseMain.startTestSuite('Test Suites/Imported from Selenium IDE Scripts/Test Suite/Tsuite', suiteProperties, [new TestCaseBinding('Test Cases/ver. 0.1/RU09/RU09-NUC01-T01', 'Test Cases/ver. 0.1/RU09/RU09-NUC01-T01',  null), new TestCaseBinding('Test Cases/ver. 0.1/RU09/RU09-NUC01-T02', 'Test Cases/ver. 0.1/RU09/RU09-NUC01-T02',  null), new TestCaseBinding('Test Cases/ver. 0.1/RU09/RU09-NUC01-T03', 'Test Cases/ver. 0.1/RU09/RU09-NUC01-T03',  null), new TestCaseBinding('Test Cases/ver. 0.1/RU09/RU09-NUC01-T04', 'Test Cases/ver. 0.1/RU09/RU09-NUC01-T04',  null)])
