import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.reporting.ReportUtil
import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.testdata.TestDataColumn
import groovy.lang.MissingPropertyException
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import internal.GlobalVariable as GlobalVariable

Map<String, String> suiteProperties = new HashMap<String, String>();


suiteProperties.put('id', 'Test Suites/Imported from Selenium IDE Scripts/Test Suite/Tsuite_ver01A-firefox')

suiteProperties.put('name', 'Tsuite_ver01A-firefox')

suiteProperties.put('description', '')
 

DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())



RunConfiguration.setExecutionSettingFile("C:\\Users\\mpetracc\\Katalon Studio\\KKPAMPCCPA_QA\\Reports\\Imported from Selenium IDE Scripts\\Test Suite\\Tsuite_ver01A-firefox\\20190329_152750\\execution.properties")

TestCaseMain.beforeStart()

TestCaseMain.startTestSuite('Test Suites/Imported from Selenium IDE Scripts/Test Suite/Tsuite_ver01A-firefox', suiteProperties, [new TestCaseBinding('Test Cases/ver 0.1A/ver 0.1A-firefox/RU01-EQUITIES/RU01-NUC01-T01', 'Test Cases/ver 0.1A/ver 0.1A-firefox/RU01-EQUITIES/RU01-NUC01-T01',  null), new TestCaseBinding('Test Cases/ver 0.1A/ver 0.1A-firefox/RU01-EQUITIES/RU01-NUC01-T02', 'Test Cases/ver 0.1A/ver 0.1A-firefox/RU01-EQUITIES/RU01-NUC01-T02',  null), new TestCaseBinding('Test Cases/ver 0.1A/ver 0.1A-firefox/RU01-EQUITIES/RU01-NUC02-T01', 'Test Cases/ver 0.1A/ver 0.1A-firefox/RU01-EQUITIES/RU01-NUC02-T01',  null), new TestCaseBinding('Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC01-T02', 'Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC01-T02',  null), new TestCaseBinding('Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC02-T01', 'Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC02-T01',  null), new TestCaseBinding('Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC03-T01', 'Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC03-T01',  null), new TestCaseBinding('Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC04-T01', 'Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC04-T01',  null), new TestCaseBinding('Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC07-T01', 'Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC07-T01',  null), new TestCaseBinding('Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC08-T01', 'Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC08-T01',  null), new TestCaseBinding('Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC09-T01', 'Test Cases/ver 0.1A/ver 0.1A-firefox/RU02-HAIRCUT/RU02-NUC09-T01',  null), new TestCaseBinding('Test Cases/ver 0.1A/ver 0.1A-firefox/RU05-STRESSTEST/RU05-NUC02-T01', 'Test Cases/ver 0.1A/ver 0.1A-firefox/RU05-STRESSTEST/RU05-NUC02-T01',  null), new TestCaseBinding('Test Cases/ver 0.1A/ver 0.1A-firefox/RU06-REVSTRESSTEST/RU06-NUC02-T01', 'Test Cases/ver 0.1A/ver 0.1A-firefox/RU06-REVSTRESSTEST/RU06-NUC02-T01',  null), new TestCaseBinding('Test Cases/ver 0.1A/ver 0.1A-firefox/RU09-GENERAL/RU09-NUC01-T03', 'Test Cases/ver 0.1A/ver 0.1A-firefox/RU09-GENERAL/RU09-NUC01-T03',  null)])
