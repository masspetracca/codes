package applicazione;

import playlist.*;
import brano.*;
import contiene.*;
import java.util.*;

public final class Main {
    public static void main (String[] args) {
	Brano 
	    b1 = new Brano("Blackbird", 314, "Musica/blackbird.mp3"), 
	    b2 = new Brano ("Hang Up", 520, "Musica/hangup.mp3"),
	    b3 = new Brano ("Tangled up in blue", 810, "Musica/tangled.mp3"), 
	    b4 = new Brano ("Big Jig in the Sky", 335, "Musica/Jig.mp3");
	PlayList 
	    pl = new PlayList("PlayListSonia");
	
	pl.inserisciLinkContiene(b1);
	pl.inserisciLinkContiene(b2);
	pl.inserisciLinkContiene(b3);
	pl.inserisciLinkContiene(b4);
	
	Stampa.stampaBrani(pl);
	
    }

    private Main() { }
}
