package contiene;

import brano.*;
import playlist.*;

public final class ManagerContiene {

    private PlayList playlist;
    private Brano brano;

    private ManagerContiene(PlayList p, Brano b) { 
	playlist = p; 
	brano = b; 
    }

    public PlayList getPlayList() { return playlist; }
    public Brano getBrano() { return brano; }

    public static void inserisci(PlayList p, Brano b) {
        if (p != null && b != null) {
            ManagerContiene k = new ManagerContiene(p,b);
            p.inserisciPerManagerContiene(k);
            b.inserisciPerManagerContiene(k);
        }
    }

    public static void elimina(PlayList p, Brano b) {
        if (p != null && b != null) {
	    ManagerContiene k = new ManagerContiene(p,b);
            p.eliminaPerManagerContiene(k);
            b.eliminaPerManagerContiene(k);
        }
    }
}
