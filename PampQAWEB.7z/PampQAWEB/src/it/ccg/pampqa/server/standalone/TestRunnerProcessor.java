package it.ccg.pampqa.server.standalone;

import com.isomorphic.autotest.TestRunnerDriver;

public class TestRunnerProcessor {
	
	// used to block concurrent user to save parameters and run TestRunner
	private static boolean isRunning = false;
	
	public static void main(String[] args) {
		
		try {
			
			if(args.length != 1) {
				
				throw new Exception("Usage: Main [propertiesFileAbsolutePath]");
			}
			
			
			// load TestRunner properties
			String TR_PROPERTIES_FILE_ABSOLUTE_PATH = args[0];
			
			TestRunnerDriverProperties testRunnerProperties = TestRunnerDriverProperties.getInstace(TR_PROPERTIES_FILE_ABSOLUTE_PATH);
			
			// check integrity
			/*if(!testRunnerProperties.isValid()) {
				
				throw new Exception("Not valid TestRunner configuration.");
			}*/
			
			
			TestRunnerDriver driver = new TestRunnerDriver();
			
			driver.setBranch(testRunnerProperties.getBranch());
			driver.setFileRoot(testRunnerProperties.getFileRoot());
			driver.setTestRoot(testRunnerProperties.getTestRoot());
			driver.setFiles(testRunnerProperties.getFiles());
	        driver.setHttpTarget(testRunnerProperties.getHttpTarget());
	        driver.setHttpPort(testRunnerProperties.getHttpPort());
	        driver.setSeleniumTimeout(testRunnerProperties.getSeleniumTimeout());
	        driver.setMaximizeBrowser(testRunnerProperties.isMaximizeBrowser());
	        if(testRunnerProperties.isCaptureScreenshot()) { driver.setCaptureScreenshot(); }
	        if(testRunnerProperties.isSaveMessages()) { driver.setSaveMessages(); }
	        driver.setBatchCommit(testRunnerProperties.isBatchCommit());
	        driver.setBrowser(testRunnerProperties.getBrowser());
	        driver.setBatchLog(testRunnerProperties.getBatchLog());
	        

	        System.out.println("TestRunner configuration: ");
			System.out.println(testRunnerProperties.toString());
	        
			System.out.println("Starting TestRunner..");
			
	        // run
	        driver.run();
	        
			
	        System.out.println("TestRunner successfully executed.");
			
		}
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}

	
	
	public static boolean isRunning() {
		return isRunning;
	}
	
	
}
