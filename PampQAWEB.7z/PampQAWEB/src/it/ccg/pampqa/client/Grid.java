package it.ccg.pampqa.client;


import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.widgets.form.FilterBuilder;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;

public class Grid extends ListGrid {
	
	final FilterBuilder advancedFilter = new FilterBuilder();  

	public Grid() {
		super();
		
		DataSource pampqa = DataSource.get("pampqa");
		this.setDataSource(pampqa);
		
		this.setFetchOperation("fetch_all");
		this.setAutoFetchData(true);
		
		this.setCanEdit(true);
		this.setEditEvent(ListGridEditEvent.DOUBLECLICK);  
		this.setModalEditing(true);
		this.setShowFilterEditor(true); 
		this.setCanRemoveRecords(true);

		ListGrid grid = new ListGrid();
		
		ListGridField dateid = new ListGridField("DATEID", 120);
		dateid.setAttribute("title", "DateId");
		ListGridField info = new ListGridField("INFO", 120);
		info.setAttribute("title", "Info");
		ListGridField classname = new ListGridField("CLASSNAME", 120);
		classname.setAttribute("title", "ClassName");
		ListGridField queuename = new ListGridField("QUEUENAME", 120);
		queuename.setAttribute("title", "QueueName");
		ListGridField systemmsg = new ListGridField("SYSTEMMSG", 120);
		systemmsg.setAttribute("title", "SystemMsg");
		ListGridField reqid = new ListGridField("REQID", 120);
		reqid.setAttribute("title", "ReqId");
		ListGridField runid = new ListGridField("RUNID", 120);
		runid.setAttribute("title", "RunId");
        
        this.setFields(
        		dateid, info, classname, queuename, systemmsg, reqid, runid
        		);  
        grid.draw();
		}
		

}
