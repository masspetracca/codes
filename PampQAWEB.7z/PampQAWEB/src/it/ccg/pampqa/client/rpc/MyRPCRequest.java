package it.ccg.pampqa.client.rpc;

import java.util.Map;

import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.types.PromptStyle;

public class MyRPCRequest extends RPCRequest {
	
	public MyRPCRequest(String url, Map<String, Object> params) {
		
		super();
		this.setHttpMethod("POST");
		
		// this is to simulate synchronous RPC
		this.setShowPrompt(true);
		this.setPromptStyle(PromptStyle.CURSOR);
		
		// timeout = 0  -->  no timeout
		this.setTimeout(0);
		
		this.setActionURL(url);
		this.setParams(params);
		
	}

}
