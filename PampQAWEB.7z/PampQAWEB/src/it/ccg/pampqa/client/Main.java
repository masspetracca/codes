package it.ccg.pampqa.client;

import it.ccg.pampqa.client.Layout;

import com.google.gwt.core.client.EntryPoint;

public class Main implements EntryPoint {

	@Override
	public void onModuleLoad() {
		
		new Layout();
		
	}

}
