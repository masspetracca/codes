package it.ccg.pampqa.client;

import it.ccg.pampqa.client.rpc.Json2POJO;
import it.ccg.pampqa.client.rpc.MyRPCRequest;


import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.TreeModelType;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.grid.CellFormatter;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.tree.Tree;
import com.smartgwt.client.widgets.tree.TreeGrid;
import com.smartgwt.client.widgets.tree.TreeGridField;
import com.smartgwt.client.widgets.tree.TreeNode;

public class SectionTreeGrid extends TreeGrid {

	public SectionTreeGrid() {
		super();
		
		this.setWidth("17%");  
		this.setShowConnectors(true);  
		this.setShowResizeBar(true);
        
        Tree data = new Tree();  
        data.setModelType(TreeModelType.CHILDREN);
        TreeNode root = new TreeNode("root");
        data.setRoot(root);
        
        TreeNode communicationManager = new TreeNode("Quality Assurance");
        
        data.add(communicationManager, root);
        
        this.setData(data);  
          
        TreeNode testRunner = new TreeNode("Test Runner");
        
        data.add(testRunner, root);
        
        this.setData(data);  

        TreeGridField field = new TreeGridField("Navigation");  
        field.setCellFormatter(new CellFormatter() {  
            public String format(Object value, ListGridRecord record, int rowNum, int colNum) {  
                return record.getAttribute("name");  
            }  
        });
        
        this.setFields(field);
        
        this.addRecordClickHandler
        	(new RecordClickHandler() {
			
			@Override
			public void onRecordClick(RecordClickEvent event) {
				
				MyRPCRequest rpcRequest = new MyRPCRequest("TestRunnerServlet", null);
				
				RPCManager.sendRequest
						(rpcRequest, new RPCCallback() {

							@Override
							public void execute(RPCResponse response, Object rawData, RPCRequest request) {
								
							}
					
				
			
				});
			}
        });
	}
}
