package it.ccg.pampqa.client;


import com.smartgwt.client.data.Record;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.TextAreaItem;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.SectionStackSection;
import com.smartgwt.client.widgets.layout.VLayout;

public class InsertSectionStackSection extends SectionStackSection {
	
	private Grid grid;
	
	public InsertSectionStackSection(Layout mainLayout) {
		super();
		
		this.grid = mainLayout.getListGrid();
		  
		// Insert form
        final DynamicForm insertForm = new DynamicForm();
        
        final TextAreaItem messageAreaItem = new TextAreaItem();  
        messageAreaItem.setTitle("Message");
        messageAreaItem.setWidth(400);
        messageAreaItem.setHeight(60);
        messageAreaItem.setRequired(true);
        
       
        insertForm.setItems(messageAreaItem
        		);
        
       // buttons
        final IButton insertButton = new IButton();
        insertButton.setTitle("Insert");
        insertButton.setHeight(25);
        insertButton.setWidth(60);
        insertButton.setAlign(Alignment.CENTER);
        insertButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				try {
            		Record record = new Record();
            		
                	record.setAttribute("TITLE", "null");
                	record.setAttribute("DATEID", (String)messageAreaItem.getValue());
                	record.setAttribute("INFO", (String)messageAreaItem.getValue());
                   	record.setAttribute("CLASSNAME", (String)messageAreaItem.getValue());
                	record.setAttribute("QUEUENAME", (String)messageAreaItem.getValue());
                   	record.setAttribute("SYSTEMMSG", (String)messageAreaItem.getValue());
                	record.setAttribute("REQID", (String)messageAreaItem.getValue());
                	record.setAttribute("RUNID", (Integer)messageAreaItem.getValue());

                	grid.addData(record);
                	
                	grid.redraw();
                	
                	insertForm.reset();
            	}
            	catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
        
        final IButton cancelButton = new IButton();
        cancelButton.setTitle("Cancel");
        cancelButton.setHeight(25);
        cancelButton.setWidth(60);
        cancelButton.setAlign(Alignment.CENTER);
        cancelButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				insertForm.reset();
				
			}
		});
        
        HLayout hLayout = new HLayout();  
        hLayout.setMembersMargin(15);
        hLayout.setAutoHeight();
        hLayout.setLayoutLeftMargin(360);
        hLayout.addMember(cancelButton);  
        hLayout.addMember(insertButton);
        
        // buttons       
        VLayout vLayout = new VLayout();
        vLayout.addMember(insertForm);
        vLayout.addMember(hLayout);
        
	}

}
