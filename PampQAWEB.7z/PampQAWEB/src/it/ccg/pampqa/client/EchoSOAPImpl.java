package it.ccg.pampqa.client;



@javax.jws.WebService (endpointInterface="it.ccg.pampqa.client.EchoServicePortType", targetNamespace="http://com/ibm/was/wssample/sei/echo/", serviceName="EchoService", portName="EchoServicePort")
public class EchoSOAPImpl{

    public EchoStringResponse echoOperation(EchoStringInput parameter) {
        // TODO Auto-generated method stub
        return null;
    }

}