package it.ccg.pampqa.client;

public class BatchViewerTreeNode {

	public BatchViewerTreeNode(String nameViewer, String rootName, String labelViewer,
			Object object) {

		return;
	}


}
