package it.ccg.pampqa.client;


import com.smartgwt.client.types.VisibilityMode;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.SectionStack;
import com.smartgwt.client.widgets.layout.SectionStackSection;
import com.smartgwt.client.widgets.layout.VLayout;


public class Layout extends HLayout {
	
	final private SectionTreeGrid sectionTreeGrid;
	final private Grid listGrid;
//	final private NavigationTreeGrid navigationTreeGrid;
	
	
	public Layout() {
		super();
		
		// grid section
        listGrid = new Grid();
        listGrid.setHeight("72%");
        SectionStackSection listGridSection = new SectionStackSection();
        listGridSection.setResizeable(false);
        listGridSection.setTitle("Quality Tester");
        listGridSection.setItems(listGrid);
        listGridSection.setExpanded(true);
        // grid
		
        // section tree
		this.sectionTreeGrid = new SectionTreeGrid();

	
	
        // edit section
        InsertSectionStackSection editSectionStack = new InsertSectionStackSection(this);
        // edit section
        
        
        SectionStack sectionStack = new SectionStack();
        sectionStack.setVisibilityMode(VisibilityMode.MULTIPLE);  
        sectionStack.setAnimateSections(true);
        
        sectionStack.setSections(listGridSection, editSectionStack);
        
        
        VLayout vLayout = new VLayout();  
        vLayout.setWidth("72%");
        
        vLayout.addMember(sectionStack);
        
        
        this.setWidth100();
		this.setHeight100();
        this.addMember(sectionTreeGrid);
        this.addMember(vLayout);  
        
       
        this.draw();
	}
	
	
	public Grid getListGrid() {
		return listGrid;
	}
	
	public SectionTreeGrid getSectionTreeGrid() {
		return sectionTreeGrid;
	}


}

