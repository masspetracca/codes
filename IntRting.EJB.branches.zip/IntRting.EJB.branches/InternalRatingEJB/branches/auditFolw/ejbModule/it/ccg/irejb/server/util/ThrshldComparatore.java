package it.ccg.irejb.server.util;

import it.ccg.irejb.server.bean.entity.RctThrshldEntity;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;

import java.util.Comparator;

import org.apache.log4j.Logger;

public class ThrshldComparatore implements Comparator<RctThrshldEntity> {
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Override
	public int compare(RctThrshldEntity object1, RctThrshldEntity object2) {
		ejbLogger.debug(new StandardLogMessage("in int compare"));
		
		ejbLogger.debug(new StandardLogMessage("object1.getThrshldval()==object2.getThrshldval() --> "+(object1.getThrshldval()==object2.getThrshldval())));
		if (object1.getThrshldval()==object2.getThrshldval()){
			ejbLogger.debug(new StandardLogMessage("object1.getThrshldop().equalsIgnoreCase(\"else\") && object2.getThrshldop().equalsIgnoreCase(\"NA\") --> "+(object1.getThrshldop().equalsIgnoreCase("else") && object2.getThrshldop().equalsIgnoreCase("NA"))));
			ejbLogger.debug(new StandardLogMessage("object2.getThrshldop().equalsIgnoreCase(\"else\") && object1.getThrshldop().equalsIgnoreCase(\"NA\") --> "+(object2.getThrshldop().equalsIgnoreCase("else") && object1.getThrshldop().equalsIgnoreCase("NA"))));
			if (object1.getThrshldop().equalsIgnoreCase("else") && object2.getThrshldop().equalsIgnoreCase("NA")){
				return -1;
			}else if(object2.getThrshldop().equalsIgnoreCase("else") && object1.getThrshldop().equalsIgnoreCase("NA")){
				return 1;
			}else{
				return 0;
			}
		}else{
			ejbLogger.debug(new StandardLogMessage("object1.getThrshldval()<object2.getThrshldval() --> "+(object1.getThrshldval()<object2.getThrshldval())));
			ejbLogger.debug(new StandardLogMessage("object2.getThrshldval()<object1.getThrshldval() --> "+(object2.getThrshldval()<object1.getThrshldval())));
			if (object1.getThrshldval()<object2.getThrshldval()){
				return -1;
			}else if(object2.getThrshldval()<object1.getThrshldval()){
				return 1;
			}else{
				return 0;
			}
		}
	}

	

}
