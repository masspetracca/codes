package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctAudHistEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

public interface RctAudHistEAOLocal {
		public void insertAuditFlow(RctAudHistEntity entity) throws BackEndException;
		public List<RctAudHistEntity> fetch() throws Exception;
}
