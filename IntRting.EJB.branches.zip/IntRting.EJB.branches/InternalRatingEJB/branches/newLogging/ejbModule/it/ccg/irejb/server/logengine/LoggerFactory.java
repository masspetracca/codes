package it.ccg.irejb.server.logengine;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.FileAppender;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;


public class LoggerFactory {
	
	public static final String EJB_LOGGER = "irejb.server.logger";
	public static final String WEB_LOGGER = "irweb.server.logger";
	public static final String USER_LOGGER = "irweb.server.user_logger";
	public static final String CALCULATION_LOGGER = "irweb.server.calculation_logger";
	public static final String SYS_LOG = "ir.sys_log";
	
	public static final String applicationCode = "IR";
	
	public static Logger getLogger(String loggerType){
		
		Logger logger = null;
		
		
		if(loggerType.equalsIgnoreCase(EJB_LOGGER)) {
			
			logger =  Logger.getLogger(EJB_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(WEB_LOGGER)) {
			
			logger =  Logger.getLogger(WEB_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(USER_LOGGER)) {
			
			logger =  Logger.getLogger(USER_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(CALCULATION_LOGGER)) {
			
			logger =  Logger.getLogger(CALCULATION_LOGGER);
		}else if(loggerType.equalsIgnoreCase(SYS_LOG)) {
			
			logger =  Logger.getLogger(SYS_LOG);
		}else {
			
			try {
				throw new Exception("loggerType \'" + loggerType + "\' not defined.");
			}
			catch (Exception e) {
				
				e.printStackTrace();
			}
			
		}
		
		
		return logger;
	}

}
