package it.ccg.irejb.server.dmi;

import it.ccg.irejb.server.bean.CalculationBean;
import it.ccg.irejb.server.bean.TimerBeanLocal;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;
import com.isomorphic.util.ErrorMessage;

public class SchedulersDmiDAO {

	private TimerBeanLocal timerBeanLocal;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	public SchedulersDmiDAO() throws BackEndException{
		try {
			Context ctx;
			ctx = new InitialContext();
		
			timerBeanLocal = (TimerBeanLocal) ctx.lookup("ejblocal:" + TimerBeanLocal.class.getName());
		} catch (NamingException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		} 
		
	}
	
	public Object add(DSRequest dsRequest, HttpServletRequest servletRequest, HttpServletResponse httpServletResponse) throws BackEndException {
		logger.debug(new StandardLogMessage("in SchedulersDmiDAO.add(DSRequest dsRequest, HttpServletRequest servletRequest, HttpServletResponse httpServletResponse)throws BackEndException"));
		Object resultObject = null;
		try{
		
			CalculationBean bean = new CalculationBean(((String)dsRequest.getFieldValue("type")),((Date)dsRequest.getFieldValue("startDateTime")),(String)dsRequest.getAttribute("UPDUSR"));
			bean.setType((String)dsRequest.getFieldValue("type"));
			bean.setStartDateTime((Date)dsRequest.getFieldValue("startDateTime"));
			
			CalculationBean apoBean = timerBeanLocal.createTimer(bean);
			logger.debug(new StandardLogMessage("dsRequest attribute"));
			
			Iterator i = dsRequest.getAttributeNames();
			while(i.hasNext()){
				String name = (String) i.next();
			}
			
			if(apoBean == null) {
				DSResponse dsResponse = new DSResponse();
				dsResponse.addError("name", new ErrorMessage("Schedule \'" + (String)bean.getType() + "\' already exists."));
				
				resultObject = dsResponse;
			}
			else {
				resultObject = apoBean;
			}
		}catch(Exception e){
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		}
		httpServletResponse.setStatus(DSResponse.STATUS_SUCCESS);
		return resultObject;
	}  

	public Object remove(DSRequest dsRequest,HttpServletRequest servletRequest, HttpServletResponse httpServletResponse) throws BackEndException { 
		logger.debug(new StandardLogMessage("in SchedulersDmiDAO.remove(DSRequest dsRequest,HttpServletRequest servletRequest, HttpServletResponse httpServletResponse)throws BackEndException"));
		
		CalculationBean bean=null;
		try {
			bean = new CalculationBean((String)dsRequest.getFieldValue("type"),(Date)dsRequest.getFieldValue("startDateTime"),(String)dsRequest.getAttribute("UPDUSR"));
			bean.setType((String)dsRequest.getFieldValue("type"));
			bean.setStartDateTime((Date)dsRequest.getFieldValue("startDateTime"));
			
			
				timerBeanLocal.deleteTimer(bean.getType());
			
			logger.debug(new StandardLogMessage("dsRequest attrobute"));
			
			Iterator i = dsRequest.getAttributeNames();
			while(i.hasNext()){
				String name = (String) i.next();
			}
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		}		
		return bean;
	}

	public Object removeAll(DSRequest dsRequest,HttpServletRequest servletRequest, HttpServletResponse httpServletResponse) throws BackEndException{ 
		logger.debug(new StandardLogMessage("in SchedulersDmiDAO.removeAll(DSRequest dsRequest,HttpServletRequest servletRequest, HttpServletResponse httpServletResponse)throws BackEndException"));
	
		DSResponse response = new DSResponse();
		try {
			CalculationBean bean = new CalculationBean((String)dsRequest.getFieldValue("type"),(Date)dsRequest.getFieldValue("startDateTime"),(String)dsRequest.getAttribute("UPDUSR"));
			bean.setType((String)dsRequest.getFieldValue("type"));
			bean.setStartDateTime((Date)dsRequest.getFieldValue("startDateTime"));
			
			
				timerBeanLocal.deleteAllTimers();
			
			logger.debug(new StandardLogMessage("dsRequest attribute"));
			
			Iterator i = dsRequest.getAttributeNames();
			while(i.hasNext()){
				String name = (String) i.next();
			}
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		}
		return response;
	}
	
	//Get System date
	public Timestamp systemDate() {
		GregorianCalendar cal = new GregorianCalendar();
		Timestamp now = new Timestamp(cal.getTimeInMillis());
		return now;
	}
	
	public DSResponse fetch(DSRequest dsRequest) throws BackEndException {
		logger.debug(new StandardLogMessage("in DSResponse fetch(DSRequest dsRequest) throws BackEndException "));
		
		DSResponse dsResponse = new DSResponse();
		try{
			logger.debug(new StandardLogMessage("get all timers"));
			List<CalculationBean> timerList = this.timerBeanLocal.getAllTimers();
			logger.debug(new StandardLogMessage("timer list "+timerList.size()));
			dsResponse.setData(timerList);
		}catch(Exception e){
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw new BackEndException(e);
		}
		return dsResponse;
	}
}
