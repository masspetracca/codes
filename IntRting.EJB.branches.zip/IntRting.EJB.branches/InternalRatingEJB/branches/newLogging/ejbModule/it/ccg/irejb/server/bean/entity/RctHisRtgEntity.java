package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the RCTHISRTG database table.
 * 
 */
@Entity
@Table(name="RCTHISRTG")
@NamedQueries({
	@NamedQuery(name="getratingByBloombCode", query="SELECT rating FROM RctHisRtgEntity rating WHERE rating.id.bloombCode = :bloombCode ORDER BY rating.id.rtgDate DESC"),
	@NamedQuery(name="getLatestRatingsByTicker", query="SELECT rating " +
			   "										 FROM RctHisRtgEntity rating " +
			   "										WHERE rating.id.bloombCode = :bloombCode " +
			   "										  AND rating.id.rtgDate = (SELECT MAX(rating2.id.rtgDate) " +
			   "																	  FROM RctHisRtgEntity rating2 " +
			   "																	 WHERE rating2.id.bloombCode = rating.id.bloombCode) " +
			   " 										ORDER BY rating.id.rtgDate DESC")
})
public class RctHisRtgEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RctHisRtgEntityPK id;

	/*@Column(nullable=false)
	private int bankId;*/

	@Column(length=10)
	private String fitchRtg;

	private int ftcTrscRtg;

	private int mdsTrscRtg;

	@Column(length=10)
	private String moodRtg;

	@Column(length=10)
	private String spRtg;

	private int spTrscRtg;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=30)
	private String updUsr;

    public RctHisRtgEntity() {
    }

	public RctHisRtgEntityPK getId() {
		return this.id;
	}

	public void setId(RctHisRtgEntityPK id) {
		this.id = id;
	}
	
	/*public int getBankId() {
		return this.bankId;
	}

	public void setBankId(int bankId) {
		this.bankId = bankId;
	}*/

	public String getFitchRtg() {
		return this.fitchRtg;
	}

	public void setFitchRtg(String fitchRtg) {
		this.fitchRtg = fitchRtg;
	}

	public int getFtcTrscRtg() {
		return this.ftcTrscRtg;
	}

	public void setFtcTrscRtg(int ftcTrscRtg) {
		this.ftcTrscRtg = ftcTrscRtg;
	}

	public int getMdsTrscRtg() {
		return this.mdsTrscRtg;
	}

	public void setMdsTrscRtg(int mdsTrscRtg) {
		this.mdsTrscRtg = mdsTrscRtg;
	}

	public String getMoodRtg() {
		return this.moodRtg;
	}

	public void setMoodRtg(String moodRtg) {
		this.moodRtg = moodRtg;
	}

	public String getSpRtg() {
		return this.spRtg;
	}

	public void setSpRtg(String spRtg) {
		this.spRtg = spRtg;
	}

	public int getSpTrscRtg() {
		return this.spTrscRtg;
	}

	public void setSpTrscRtg(int spTrscRtg) {
		this.spTrscRtg = spTrscRtg;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUsr() {
		return this.updUsr;
	}

	public void setUpdUsr(String updUsr) {
		this.updUsr = updUsr;
	}

}