package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.bean.eao.RctBankEAOLocal;
import it.ccg.irejb.server.bean.eao.RctThrshldEAOLocal;
import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.bean.entity.RctThrshldEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ImportBanksBean
 */
@Stateless
@Local(ImportsBeanLocal.class)
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class ImportsBean implements ImportsBeanLocal {

	private static final Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	@EJB
	private RctBankEAOLocal rctBankLocal;
	
	@EJB
	private RctThrshldEAOLocal rctThrshldLocal;
	
	/*@EJB
	private RctVarsEAOLocal rctVarLocal;*/
	
	public ImportsBean(){
		
	}
	
	public int insertBankCsvValue(String[][] dati,String user) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in ImportsBean.insertBankCsvValue"));
		String [] headers = dati[0];
		int bnkIdx=0;
		for(int i = 1; i<dati.length;i++){
			String[] tempDati = dati[i];
			ejbLogger.debug(new StandardLogMessage("tempDati "+tempDati.toString()));
			ejbLogger.debug(new StandardLogMessage("tempDati "+i+"" +tempDati.length));
			RctBankEntity entity = new RctBankEntity();
			for(int j = 0;j<tempDati.length;j++){
				try {
					if (tempDati[j]!=null && !tempDati[j].equalsIgnoreCase("")){
						Method m = entity.getClass().getMethod(transcodeBankHeaders(headers[j]), String.class );
						m.invoke(entity, tempDati[j].trim());
					}
				} catch (SecurityException e) {
					ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
					throw new BackEndException("NoSuchFields");
				} catch (NoSuchMethodException e) {
					ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
					throw new BackEndException("NoSuchFields");
				}catch (IllegalArgumentException e) {
					ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
					throw new BackEndException("NoSuchFields");
				} catch (IllegalAccessException e) {
					ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
					throw new BackEndException("NoSuchFields");
				} catch (InvocationTargetException e) {
					ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
					throw new BackEndException("NoSuchFields");
				}
			}
			entity.setUpdUsr(user);
			entity.setUpdDate(new Timestamp(new Date().getTime()));
			entity.setUpdType("C");
			List<RctBankEntity> banks = rctBankLocal.retrieveBankByName(entity.getBankName());
			List<RctBankEntity> banksBloom=new ArrayList<RctBankEntity>();
			List<RctBankEntity> banksFitch = new ArrayList<RctBankEntity>();
			if (entity.getBloombCode()!=null && !entity.getBloombCode().equalsIgnoreCase("")){
				banksBloom = rctBankLocal.retrieveBankByBloombCode(entity.getBloombCode());
			}
			
			if(entity.getFitchCode()!=null && !entity.getFitchCode().equalsIgnoreCase("")){
				banksFitch= rctBankLocal.retrieveBankByFitchCode(entity.getFitchCode());
			}
			
			if(banks.size()==0 && banksBloom.size() ==0 && banksFitch.size()==0){
				rctBankLocal.insertBank(entity);
				bnkIdx++;
			}
		}
		ejbLogger.debug("Inserted "+bnkIdx+" banks");
		return bnkIdx;
	}
	
	/* (non-Javadoc)
	 * @see it.ccg.irejb.server.bean.ImportsBeanLocal#insertThresholdCsvValue(java.lang.String[][], java.lang.String)
	 */
	@Override
	public int insertThresholdCsvValue(String[][] dati, String user,int varId) throws BackEndException {
		ejbLogger.debug(new StandardLogMessage("in ImportsBean.insertThresholdCsvValue"));
		String [] headers = dati[0];
		int thrshldIdx=0;
		Timestamp thresholdDate =  new Timestamp(new Date().getTime());
		List<RctThrshldEntity>  entities = new ArrayList<RctThrshldEntity>();
		for(int i = 1; i<dati.length;i++){
			String[] tempDati = dati[i];
			ejbLogger.debug(new StandardLogMessage("tempDati "+tempDati.toString()));
			ejbLogger.debug(new StandardLogMessage("tempDati "+i+"" +tempDati.length));
			RctThrshldEntity entity = new RctThrshldEntity();
			
			entity.setThrshlddte(thresholdDate);
			entity.setVarid(varId);
			
			//List<RctVarsEntity> vars= rctVarLocal.retrieveRtcVarByVarId(varId);
			//entity.setRctvar(vars.get(0));

			nextVal: for(int j = 0;j<tempDati.length;j++){
				ejbLogger.debug(new StandardLogMessage(transcodeThresholdHeaders(headers[j])+" -> "+tempDati[j]));
				try {
					//if (tempDati[j]!=null && !tempDati[j].equalsIgnoreCase("")){
						Method[] methods = entity.getClass().getMethods();
						for (int z=0;z<methods.length;z++){
							if (methods[z].getName().equalsIgnoreCase(transcodeThresholdHeaders(headers[j]))){
								ejbLogger.debug(new StandardLogMessage("invoke "+methods[z].getName()+" --> "+tempDati[j]));
								methods[z].invoke(entity, tempDati[j]);
								continue nextVal;
							}
							
						}
						
					//}
				} catch (SecurityException e) {
					ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
					throw new BackEndException("NoSuchFields");
				} catch (IllegalArgumentException e) {
					ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
					throw new BackEndException("NoSuchFields");
				} catch (IllegalAccessException e) {
					ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
					throw new BackEndException("NoSuchFields");
				} catch (InvocationTargetException e) {
					ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
					throw new BackEndException("NoSuchFields");
				}
			}
			entity.setUpddate(new Timestamp(new Date().getTime()));
			entity.setUpdusr(user);
			entity.setUpdtype("C");
			
			entities.add(entity);
			//rctThrshldLocal.insertRctThreshold(entity);
			//thrshldIdx++;
		}
		
		for(RctThrshldEntity entity : entities){
			rctThrshldLocal.insertRctThreshold(entity);
		}
		ejbLogger.debug("Inserted "+thrshldIdx+" thresholds");
		
		
		return thrshldIdx;
	}

	private String transcodeBankHeaders(String header) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in ImportBanks.transcodeBankHeaders"));
		header.replaceAll("\"", "");
		if(header.equalsIgnoreCase("Bank name")){
			return "setBankname";
		}else if(header.equalsIgnoreCase("ABI code")){
			return "setAbicode";
		}else if(header.equalsIgnoreCase("Bloomberg code")){
			return "setBloombcode";
		}else if(header.equalsIgnoreCase("Fitch code")){
			return "setFitchcode";
		}else if(header.equalsIgnoreCase("Calculation")){
			return "setStatus";
		}else if(header.equalsIgnoreCase("Counterparty")){
			return "setCtp";
		}else if(header.equalsIgnoreCase("Participant")){
			return "setParticipnt";
		}else if(header.equalsIgnoreCase("Country")){
			return "setCountry";
		}else if(header.equalsIgnoreCase("Parent company name")){
			return "setParbnkname";
		}else if(header.equalsIgnoreCase("Parent company bloomber ticker")){
			return "setParbnkblcd";
		}else if(header.equalsIgnoreCase("Holding bloomberg ticker")){
			return "setParbnktick";
		}else{
			ExceptionUtil.logCompleteStackTrace(ejbLogger, new NoSuchElementException("no transcoding for "+header));
			throw new BackEndException("NoSuchFields");
		}
	}
	
	private String transcodeThresholdHeaders(String header) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in ImportBanks.transcodeThresholdHeaders"));
		ejbLogger.debug("I'm trying to transcode "+ header);
		header.replaceAll("\"", "");
		if(header.equalsIgnoreCase("Threshold")){
			return "setThrshldvalString";
		}else if(header.equalsIgnoreCase("Operator")){
			return "setThrshldop";
		}else if(header.equalsIgnoreCase("Coefficient")){
			return "setThrshldcoeString";
		}else{
			ExceptionUtil.logCompleteStackTrace(ejbLogger, new NoSuchElementException("no transcoding for "+header));
			throw new BackEndException("NoSuchFields");
		}
	}

}
