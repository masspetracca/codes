package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctRatingHEntity;
import it.ccg.irejb.server.bean.entity.RctRatingHEntityPK;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.apache.openjpa.persistence.NoResultException;

import com.ibm.ws.management.discovery.exception.AbnormalTargetException;

/**
 * Session Bean implementation class RctRatingHEAO
 */
@Stateless
@Local(RctRatingHEAOLocal.class)
@TransactionAttribute(TransactionAttributeType.MANDATORY)
public class RctRatingHEAO implements RctRatingHEAOLocal {

	@PersistenceContext(unitName="InternalRatingEJB", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private DateFormat df = new SimpleDateFormat("yyyy/mm/dd");
    /**
     * Default constructor. 
     */
    public RctRatingHEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertRatingHistory(RctRatingHEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in insertRatingHistory(RctRatingHEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctRatingHEntity identification data: bankId = "+entity.getId().getBankid()+" rating date = "+entity.getId().getRatingdate()));
    	ejbLogger.debug(new StandardLogMessage("insert"));
    	this.manager.persist(entity);
    }
    
    public void deleteRatingHistory(RctRatingHEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in deleteRatingHistory(RctRatingHEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctRatingHEntity identification data: bankId = "+entity.getId().getBankid()+" rating date = "+entity.getId().getRatingdate()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	this.manager.remove(entity);
    }

    public void updateRatingHistory(RctRatingHEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in updateRatingHistory(RctRatingHEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctRatingHEntity identification data: bankId = "+entity.getId().getBankid()+" rating date = "+entity.getId().getRatingdate()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	this.manager.merge(entity);
    }
    
    public RctRatingHEntity retrieveRatingHistoryById(String bankId, String ratingDate) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in RctRatingHEntity retrieveById(String bankId, String ratingDate) throws BackEndException"));
    	RctRatingHEntity rating = null;
    	try {
	    	
			Date rtgDate = this.df.parse(ratingDate);
			RctRatingHEntityPK pk = new RctRatingHEntityPK();
			pk.setBankid(Integer.parseInt(bankId));
			pk.setRatingdate(rtgDate);
						
	    	ejbLogger.debug(new StandardLogMessage("Bank identification ID: "+bankId));
	    	ejbLogger.debug(new StandardLogMessage("Rating date: "+ratingDate));
	    	ejbLogger.debug(new StandardLogMessage("find"));
	    	
	    	rating = (RctRatingHEntity)this.manager.find(RctRatingHEntity.class, pk);
	    	
    	} catch (ParseException e) {
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    	return rating;
    }
    
    //getRatingHistByBankId
    @SuppressWarnings("unchecked")
	public List<RctRatingHEntity> retrieveRatingHistoryByBankId(String bankId){
    	ejbLogger.debug(new StandardLogMessage("in List<RctRatingHEntity> retrieveRatingHistoryByBankId(String bankId)"));
    	ejbLogger.debug(new StandardLogMessage("Bank id: "+bankId));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getRatingHistByBankId");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("bankid", bankId);
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
		List<RctRatingHEntity> ratings = (List<RctRatingHEntity>) q.getResultList();
		
    	return ratings;
    }
    
    public RctRatingHEntity retrieveLastRatingHistoryByBankId(int bankId){
    	RctRatingHEntity rating = null;
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctRatingHEntity> retrieveLastRatingHistoryByBankId(String bankId)"));
	    	ejbLogger.debug(new StandardLogMessage("Bank id: "+bankId));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getLastRatingHistByBankId");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("bankid", bankId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			rating = (RctRatingHEntity) q.getSingleResult();
    	}catch(NoResultException e){
    		ejbLogger.warn(new StandardLogMessage("NO rating history for bank "+bankId));
    	}
    	return rating;
    }
    
    //getRatingHistByRatingDate
    @SuppressWarnings("unchecked")
	public List<RctRatingHEntity> retrieveRatingHistoryByRatingDate(String ratingDate) throws BackEndException{
       	ejbLogger.debug(new StandardLogMessage("in List<RctRatingHEntity> retrieveRatingHistoryByRatingDate(String ratingDate) throws BackEndException"));
       	List<RctRatingHEntity> ratings = null;
       	try {
	       	ejbLogger.debug(new StandardLogMessage("Rating date : "+ratingDate));
	       	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	       	Query q = this.manager.createNamedQuery("getRatingHistByRatingDate");
	       	ejbLogger.debug(new StandardLogMessage("populate named query"));
	       	
			q.setParameter("ratingdate", df.parse(ratingDate));
			
	       	ejbLogger.debug(new StandardLogMessage("getResultList"));
	       	ratings = (List<RctRatingHEntity>) q.getResultList();
       	} catch (ParseException e) {
       		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
       	return ratings;
    }
    
    //getRatingHistByStatus
    @SuppressWarnings("unchecked")
	public List<RctRatingHEntity> retrieveRatingHistoryByStatus(String status){
       	ejbLogger.debug(new StandardLogMessage("in List<RctRatingHEntity> retrieveRatingHistoryByStatus(String status)"));
       	ejbLogger.debug(new StandardLogMessage("Status : "+status));
       	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
       	Query q = this.manager.createNamedQuery("getRatingHistByStatus");
       	ejbLogger.debug(new StandardLogMessage("populate named query"));
       	q.setParameter("status", status);
       	
       	ejbLogger.debug(new StandardLogMessage("getResultList"));
   		List<RctRatingHEntity> ratings = (List<RctRatingHEntity>) q.getResultList();
   		
       	return ratings;
     } 

}
