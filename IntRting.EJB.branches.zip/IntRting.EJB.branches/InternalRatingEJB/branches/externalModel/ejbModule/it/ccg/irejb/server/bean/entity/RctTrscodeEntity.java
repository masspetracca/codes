package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the RCTTRSCODE database table.
 * 
 */
@Entity
//@Table(name="PAMPTEST.RCTTRSCODE")
@Table(name="RCTTRSCODE")
@NamedQueries({
	@NamedQuery(name="getRtcTranscodeByRtgCode", query="SELECT rctTrscode FROM RctTrscodeEntity rctTrscode WHERE rctTrscode.rtgcode = :rtgcode ORDER BY rctTrscode.id.ranking ASC"),
	@NamedQuery(name="getRtcTranscodeByProvider", query="SELECT rctTrscode FROM RctTrscodeEntity rctTrscode WHERE rctTrscode.id.provider = :provider ORDER BY rctTrscode.id.ranking ASC")
})
public class RctTrscodeEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RctTrscodeEntityPK id;

	@Column(precision=15, scale=8)
	private BigDecimal maxrtg;

	@Column(precision=15, scale=8)
	private BigDecimal minrtg;

	@Column(length=5)
	private String rtgcode;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

    public RctTrscodeEntity() {
    }

	public RctTrscodeEntityPK getId() {
		return this.id;
	}

	public void setId(RctTrscodeEntityPK id) {
		this.id = id;
	}
	
	public BigDecimal getMaxrtg() {
		return this.maxrtg;
	}

	public void setMaxrtg(BigDecimal maxrtg) {
		this.maxrtg = maxrtg;
	}

	public BigDecimal getMinrtg() {
		return this.minrtg;
	}

	public void setMinrtg(BigDecimal minrtg) {
		this.minrtg = minrtg;
	}

	public String getRtgcode() {
		return this.rtgcode;
	}

	public void setRtgcode(String rtgcode) {
		this.rtgcode = rtgcode;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

}