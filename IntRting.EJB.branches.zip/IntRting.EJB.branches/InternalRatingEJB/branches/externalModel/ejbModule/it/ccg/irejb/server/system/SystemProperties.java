package it.ccg.irejb.server.system;


import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class SystemProperties {
	
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	

	private static final String PROPERTIES_SYSTEM_FILE_ABS_PATH = System.getProperty("user.install.root") + 
															      System.getProperty("file.separator") +
															      "properties" + 
															      System.getProperty("file.separator") +
															      "internalrating.system.properties";
	
	private static final String PROPERTIES_LINEAR_FILE_ABS_PATH = System.getProperty("user.install.root") + 
															      System.getProperty("file.separator") +
															      "properties" + 
															      System.getProperty("file.separator") +
															      "internalrating.linear.properties";
	
	private static Properties systemProperties = null;
	private static Properties linearProperties = null;
	
	
	
	public static void loadSystemProperties() throws BackEndException {
		
		// load properties from file
		systemProperties = new Properties();
		try {
			systemProperties.load(new FileInputStream(PROPERTIES_SYSTEM_FILE_ABS_PATH));
						// load other system properties
			systemProperties.put("user.install.root", System.getProperty("user.install.root"));
			systemProperties.put("file.separator", System.getProperty("file.separator"));
			
			
			logger.debug(new StandardLogMessage("InternalRating system properties successfully loaded from file: " + PROPERTIES_SYSTEM_FILE_ABS_PATH));
		} catch (FileNotFoundException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		}
	}
	
	public static void loadLinearProperties() throws BackEndException {
		
		// load properties from file
		linearProperties = new Properties();
		try {
			linearProperties.load(new FileInputStream(PROPERTIES_LINEAR_FILE_ABS_PATH));
						// load other system properties
			linearProperties.put("user.install.root", System.getProperty("user.install.root"));
			linearProperties.put("file.separator", System.getProperty("file.separator"));
			
			
			logger.debug(new StandardLogMessage("InternalRating system properties successfully loaded from file: " + PROPERTIES_LINEAR_FILE_ABS_PATH));
		} catch (FileNotFoundException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		}
	}
	
	public static String getSystemProperty(String propertyName) throws BackEndException {
		
		if(systemProperties == null) {
			
			loadSystemProperties();
		}
		
		return systemProperties.getProperty(propertyName);
	}

	public static String getLinearProperty(String propertyName) throws BackEndException {
		
		if(linearProperties == null) {
			
			loadLinearProperties();
		}
		
		return linearProperties.getProperty(propertyName);
	}

	public static Properties getSystemProperties() throws BackEndException {
		
		if(systemProperties == null) {
			
			loadSystemProperties();
		}
		
		return systemProperties;
	}
	
	public static Properties getLinearProperties() throws BackEndException {
		
		if(linearProperties == null) {
			
			loadLinearProperties();
		}
		
		return linearProperties;
	}


	public static String getSystemPropertiesFileAbsPath() {
		
		return PROPERTIES_SYSTEM_FILE_ABS_PATH;
	}
	
	public static String getLinearPropertiesFileAbsPath() {
		
		return PROPERTIES_LINEAR_FILE_ABS_PATH;
	}

}
