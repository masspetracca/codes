package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the RCTBNKFTCT database table.
 * 
 */

@Entity
//@Table(name="PAMPTEST.RCTBNKFTCT")
@Table(name="RCTBNKFTCT")
@NamedQueries({
	@NamedQuery(name="getRctBnkFtcTByFitchCode", query="SELECT bnkFtc FROM RctBnkFtcTEntity bnkFtc WHERE bnkFtc.id.fitchcode = :fitchcode"),
	@NamedQuery(name="getRctBnkFtcTByAccountingSys", query="SELECT bnkFtc FROM RctBnkFtcTEntity bnkFtc WHERE bnkFtc.accountsys = :accountsys"),
	@NamedQuery(name="getRtcBnkFtcTByLatestPeriod", query="SELECT bnkFtc FROM RctBnkFtcTEntity bnkFtc WHERE bnkFtc.latestper = :latestper"),
	@NamedQuery(name="getRtcBnkFtcTByIsConsolidated", query="SELECT bnkFtc FROM RctBnkFtcTEntity bnkFtc WHERE bnkFtc.isconsolid = :isconsolid"),
	@NamedQuery(name="getRtcBnkFtcTIFRSForCalc", query="SELECT bnkFtc " +
											    	     "FROM RctBnkFtcTEntity bnkFtc " +
											    	    "WHERE bnkFtc.id.fitchcode = :fitchcode " +
											    	      "AND bnkFtc.accountsys LIKE '%IFRS%' " +
											    	      "AND bnkFtc.isconsolid = 'Y' " +
											    	      "AND bnkFtc.latestper = (SELECT MAX(bnkFtc2.latestper) " +
											    	     						    "FROM RctBnkFtcTEntity bnkFtc2 " +
											    	     						   "WHERE bnkFtc2.id.fitchcode = :fitchcode " +
											    	     						     "AND bnkFtc2.accountsys LIKE '%IFRS%' " +
											    	     						     "AND bnkFtc2.isconsolid = 'Y')"),
			    	     						    
	 @NamedQuery(name="getRtcBnkFtcTGAAPForCalc", query="SELECT bnkFtc " +
		    	     						    	      "FROM RctBnkFtcTEntity bnkFtc " +
		    	     						    	     "WHERE bnkFtc.id.fitchcode = :fitchcode " +
		    	     						    	       "AND bnkFtc.accountsys LIKE '%GAAP%' " +
		    	     						    	       "AND bnkFtc.isconsolid = 'Y' " +
		    	     						    	       "AND bnkFtc.latestper = (SELECT MAX(bnkFtc2.latestper) " +
		    	     						    	     						     "FROM RctBnkFtcTEntity bnkFtc2 " +
		    	     						    	     						    "WHERE bnkFtc2.id.fitchcode = :fitchcode " +
		    	     						    	     						      "AND bnkFtc2.accountsys LIKE '%GAAP%' " +
		    	     						    	     						      "AND bnkFtc2.isconsolid = 'Y')"),
     @NamedQuery(name="getRtcBnkFtcTIFRSNotConsolidatedForCalc", query="SELECT bnkFtc " +
    		 															 "FROM RctBnkFtcTEntity bnkFtc " +
			    	     						    	                "WHERE bnkFtc.id.fitchcode = :fitchcode " +
			    	     						    	                  "AND bnkFtc.accountsys LIKE '%IFRS%' " +
			    	     						    	                  "AND bnkFtc.isconsolid = 'N' " +
							    	     						    	  "AND bnkFtc.latestper = (SELECT MAX(bnkFtc2.latestper) " +
							    	     						    	     					    "FROM RctBnkFtcTEntity bnkFtc2 " +
							    	     						    	     					   "WHERE bnkFtc2.id.fitchcode = :fitchcode " +
							    	     						    	     						 "AND bnkFtc2.accountsys LIKE '%IFRS%' " +
							    	     						    	     						 "AND bnkFtc2.isconsolid = 'N')"),
		    	     						    	     						    	     						    
	@NamedQuery(name="getRtcBnkFtcTGAAPNotConsolidatedForCalc", query="SELECT bnkFtc " +
						    	     						    	    "FROM RctBnkFtcTEntity bnkFtc " +
						    	     						    	   "WHERE bnkFtc.id.fitchcode = :fitchcode " +
						    	     						             "AND bnkFtc.accountsys LIKE '%GAAP%' " +
						    	     						   	         "AND bnkFtc.isconsolid = 'N' " +
						    	     						    	     "AND bnkFtc.latestper = (SELECT MAX(bnkFtc2.latestper) " +
						    	     						    	     						   "FROM RctBnkFtcTEntity bnkFtc2 " +
						    	     						    	     						  "WHERE bnkFtc2.id.fitchcode = :fitchcode " +
						    	     						    	     						    "AND bnkFtc2.accountsys LIKE '%GAAP%' " +
						    	     						    	     						    "AND bnkFtc2.isconsolid = 'N')")

	
})
public class RctBnkFtcTEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RctBnkFtcTEntityPK id;

	@Column(nullable=false, length=200)
	private String accountsys;

	@Column(nullable=false, length=1)
	private String isconsolid;

	@Column(nullable=false)
	private Timestamp latestper;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

    public RctBnkFtcTEntity() {
    }

	public RctBnkFtcTEntityPK getId() {
		return this.id;
	}

	public void setId(RctBnkFtcTEntityPK id) {
		this.id = id;
	}
	
	public String getAccountsys() {
		return this.accountsys;
	}

	public void setAccountsys(String accountsys) {
		this.accountsys = accountsys;
	}

	public String getIsconsolid() {
		return this.isconsolid;
	}

	public void setIsconsolid(String isconsolid) {
		this.isconsolid = isconsolid;
	}

	public Timestamp getLatestper() {
		return this.latestper;
	}

	public void setLatestper(Timestamp latestper) {
		this.latestper = latestper;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}
}