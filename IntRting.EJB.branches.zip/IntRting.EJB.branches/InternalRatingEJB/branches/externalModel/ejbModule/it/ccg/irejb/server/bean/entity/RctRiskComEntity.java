package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the RCTRISKCOM database table.
 * 
 */
@Entity
//@Table(name="PAMPTEST.RCTRISKCOM")
@Table(name="RCTRISKCOM")
@NamedQueries({
	@NamedQuery(name="getRiskComByRcDate", query="SELECT committee FROM RctRiskComEntity committee WHERE committee.rcdate= :rcdate ORDER BY committee.rcdate DESC"),
})
public class RctRiskComEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false)
	private int rccode;

	@Column(nullable=false)
	private Timestamp rcdate;

	@Column(nullable=false, length=255)
	private String rcdesc;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

	//bi-directional many-to-one association to RctRatingHEntity
	@OneToMany(mappedBy="rctriskcom")
	private Set<RctRatingHEntity> rctratinghs;

    public RctRiskComEntity() {
    }

	public int getRccode() {
		return this.rccode;
	}

	public void setRccode(int rccode) {
		this.rccode = rccode;
	}

	public Timestamp getRcdate() {
		return this.rcdate;
	}

	public void setRcdate(Timestamp rcdate) {
		this.rcdate = rcdate;
	}

	public String getRcdesc() {
		return this.rcdesc;
	}

	public void setRcdesc(String rcdesc) {
		this.rcdesc = rcdesc;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

	public Set<RctRatingHEntity> getRctratinghs() {
		return this.rctratinghs;
	}

	public void setRctratinghs(Set<RctRatingHEntity> rctratinghs) {
		this.rctratinghs = rctratinghs;
	}
	
}