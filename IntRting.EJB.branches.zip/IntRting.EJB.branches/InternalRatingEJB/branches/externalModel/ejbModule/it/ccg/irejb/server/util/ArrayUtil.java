package it.ccg.irejb.server.util;

import java.util.ArrayList;
import java.util.List;

public class ArrayUtil {
	
	public static List<Object> toList(Object[] array) {
		
		List<Object> list = new ArrayList<Object>();
		for(Object s : array) {
			
			list.add(s);
		}
		
		
		return list;
	}

}
