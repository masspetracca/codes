package it.ccg.irejb.server.security;

import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

public interface SessionManagerLocal {
	
	public void init() throws BackEndException;
	
	public void addLoggedUser(String userName, String sessionId) throws BackEndException;
	public void removeLoggedUser(String userName) throws BackEndException;
	
	public String getCurrentUser() throws BackEndException;
	public String getCurrentUserSessionId() throws BackEndException;
	public List<String> getCurrentUserRoles() throws BackEndException;
	
	public List<String> listLoggedUsers() throws BackEndException;
	
}
