package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

public interface ActiveBanksBeanRemote {

	public List<RctBankEntity> getActiveBanksList() throws BackEndException;
}
