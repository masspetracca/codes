package it.ccg.irejb.server.business;

import it.ccg.irejb.server.bean.ExternalRatingCalculationBeanLocal;
import it.ccg.irejb.server.bean.FinancialRatingCaculationsBeanLocal;
import it.ccg.irejb.server.bean.MarketRatingCalculationsBeanLocal;
import it.ccg.irejb.server.bean.eao.RctBankEAOLocal;
import it.ccg.irejb.server.bean.eao.RctRatingEAOLocal;
import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.bean.entity.RctRatingEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

public class RatingsCalculations {
	private FinancialRatingCaculationsBeanLocal financialRatingCaculationsBean;
	private MarketRatingCalculationsBeanLocal marketRatingCalculationsBean;
	private ExternalRatingCalculationBeanLocal externalRatingCalculationBean;
	private RctBankEAOLocal rctBankEao;
	private List<RctBankEntity> enabledBanks;
	private Map<Integer,RctRatingEntity> ratings;
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private RctRatingEAOLocal rcTRatingEAO;
	//private RctRatingHEAOLocal rcTRatingHEAO;
	private String user;
	
	public RatingsCalculations(String user) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in RatingsCalculations"));
		Context context;
		this.user = user;
		try {
			context = new InitialContext();
			this.financialRatingCaculationsBean = (FinancialRatingCaculationsBeanLocal) context.lookup("ejblocal:it.ccg.irejb.server.bean.FinancialRatingCaculationsBeanLocal");
			this.marketRatingCalculationsBean = (MarketRatingCalculationsBeanLocal) context.lookup("ejblocal:it.ccg.irejb.server.bean.MarketRatingCalculationsBeanLocal");
			this.externalRatingCalculationBean = (ExternalRatingCalculationBeanLocal) context.lookup("ejblocal:it.ccg.irejb.server.bean.ExternalRatingCalculationBeanLocal");
			
			this.rctBankEao = (RctBankEAOLocal) context.lookup("ejblocal:it.ccg.irejb.server.bean.eao.RctBankEAOLocal");
			this.rcTRatingEAO = (RctRatingEAOLocal) context.lookup("ejblocal:it.ccg.irejb.server.bean.eao.RctRatingEAOLocal");

		} catch (NamingException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}

/*	@TransactionAttribute(TransactionAttributeType.REQUIRED)*/
	public void dailyRun(){
		ejbLogger.debug(new StandardLogMessage("in RatingsCalculations.dailyRun"));
		try {
			ejbLogger.info(new StandardLogMessage("retrieve every enabled banks"));
			enabledBanks = rctBankEao.retrieveBankByStatus("E");
			ejbLogger.info(new StandardLogMessage("Active banks num: "+enabledBanks.size()));
			
			ejbLogger.info(new StandardLogMessage("financial model calc"));
			this.ratings = financialRatingCaculationsBean.dailyRun(enabledBanks);
			
			ejbLogger.info(new StandardLogMessage("ratings collection check"));
			if (this.ratings!=null && this.ratings.size()>0){
				ejbLogger.info(new StandardLogMessage("market model calc"));
				this.ratings = marketRatingCalculationsBean.dailyRun(enabledBanks, this.ratings);
			}
			
			ejbLogger.info(new StandardLogMessage("ratings collection check"));
			if (this.ratings!=null && this.ratings.size()>0){
				ejbLogger.info(new StandardLogMessage("external model calc"));
				this.ratings = externalRatingCalculationBean.dailyRun(enabledBanks, this.ratings);
			}
			
			Map <Integer,RctRatingEntity> presentRating = rcTRatingEAO.retrieveAllRatings();
			Timestamp calcultionDate = new Timestamp(new Date().getTime());
			Set<Integer> keys = ratings.keySet();
			for (Integer i : keys){
				RctRatingEntity rating = ratings.get(i);
				/* ottimizzo
				 * List<RctRatingEntity> ratingsAppo =  rcTRatingEAO.retrieveRatingsByBankId(rating.getBankid());
				 */
				try{
				if (presentRating.get(rating.getBankid())  != null){
					ejbLogger.info(new StandardLogMessage("Rating already present for "+rating.getBankid()+", then update"));
					rating.setUpdtype("U");
					RctRatingEntity appo =  presentRating.get(rating.getBankid());
					appo.setUpdtype(rating.getUpdtype());
					appo.setUpdusr(this.user);
					appo.setUpddate(calcultionDate);
					appo.setRatingdate(calcultionDate);
					if (rating.getBalancertg() != null && !rating.getBalancertg().equals(0))
						appo.setBalancertg(rating.getBalancertg());
					
					if (rating.getExternrtg() != null && !rating.getExternrtg().equals(0))
						appo.setExternrtg(rating.getExternrtg());
					
					if(rating.getSpreadrtg() != null && !rating.getSpreadrtg().equals(0))
						appo.setSpreadrtg(rating.getSpreadrtg());
					
					ejbLogger.debug(new StandardLogMessage("rating updated"));

				}else{
					rating.setUpddate(calcultionDate);
					rating.setRatingdate(calcultionDate);
					rating.setUpdusr(this.user);
					ejbLogger.info(new StandardLogMessage("Rating not present for "+rating.getBankid()+", then create"));
					rating.setUpdtype("C");
					rcTRatingEAO.insertRctRating(rating);
				}
				}catch(Exception e){
					ejbLogger.error(e.getMessage());
					System.out.println(e.getMessage());
				}
			}
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
		}
	}
	
/*	@TransactionAttribute(TransactionAttributeType.REQUIRED)*/
	public void dailyRunOneShot(){
		ejbLogger.debug(new StandardLogMessage("in RatingsCalculations.dailyRunOneShot"));
		try {
			ejbLogger.info(new StandardLogMessage("retrieve every enabled banks"));
			enabledBanks = rctBankEao.retrieveBankByStatus("E");
			ejbLogger.info(new StandardLogMessage("Active banks num: "+enabledBanks.size()));
			
			ejbLogger.info(new StandardLogMessage("financial model calc"));
			this.ratings = financialRatingCaculationsBean.dailyRun(enabledBanks);
			
			ejbLogger.info(new StandardLogMessage("ratings collection check"));
			if (this.ratings!=null && this.ratings.size()>0){
				ejbLogger.info(new StandardLogMessage("market model calc"));
				this.ratings = marketRatingCalculationsBean.dailyRun(enabledBanks, this.ratings);
			}
			
			ejbLogger.info(new StandardLogMessage("ratings collection check"));
			if (this.ratings!=null && this.ratings.size()>0){
				ejbLogger.info(new StandardLogMessage("external model calc"));
				this.ratings = externalRatingCalculationBean.dailyRun(enabledBanks, this.ratings);
			}
			ejbLogger.debug("read already present ratings");
			Map <Integer,RctRatingEntity> presentRating = rcTRatingEAO.retrieveAllRatings();
			
			Timestamp calcultionDate = new Timestamp(new Date().getTime());
			Set<Integer> keys = ratings.keySet();
			for (Integer i : keys){
				RctRatingEntity rating = ratings.get(i);
				/* ottimizzo
				 * List<RctRatingEntity> ratingsAppo =  rcTRatingEAO.retrieveRatingsByBankId(rating.getBankid());
				 */
				try{
				if (presentRating.get(rating.getBankid())  != null){
					ejbLogger.info(new StandardLogMessage("Rating already present for "+rating.getBankid()+", then update"));
					rating.setUpdtype("U");
					RctRatingEntity appo =  presentRating.get(rating.getBankid());
					appo.setUpdtype(rating.getUpdtype());
					appo.setUpdusr(this.user);
					appo.setUpddate(calcultionDate);
					appo.setRatingdate(calcultionDate);
					if (rating.getBalancertg() != null && !rating.getBalancertg().equals(0))
						appo.setBalancertg(rating.getBalancertg());
					
					if (rating.getExternrtg() != null && !rating.getExternrtg().equals(0))
						appo.setExternrtg(rating.getExternrtg());
					
					if(rating.getSpreadrtg() != null && !rating.getSpreadrtg().equals(0))
						appo.setSpreadrtg(rating.getSpreadrtg());
					
					ejbLogger.debug(new StandardLogMessage("rating updated"));

				}else{
					rating.setUpddate(calcultionDate);
					rating.setRatingdate(calcultionDate);
					rating.setUpdusr(this.user);
					ejbLogger.info(new StandardLogMessage("Rating not present for "+rating.getBankid()+", then create"));
					rating.setUpdtype("C");
					rcTRatingEAO.insertRctRating(rating);
				}
				}catch(Exception e){
					ejbLogger.error(e.getMessage());
					System.out.println(e.getMessage());
				}
			}
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
		} 
	}
	
	public void setUp(){
		ejbLogger.debug(new StandardLogMessage("in RatingsCalculations.setUp"));
		try {
			this.marketRatingCalculationsBean.setUp();
			ejbLogger.debug(new StandardLogMessage("setUp complited"));
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
		}
		
		 
	}
}
