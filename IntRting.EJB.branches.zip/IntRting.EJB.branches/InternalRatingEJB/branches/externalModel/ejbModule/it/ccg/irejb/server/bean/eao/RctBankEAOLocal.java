package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

public interface RctBankEAOLocal {

	public void insertBank(RctBankEntity entity) throws BackEndException;
	public void deleteBank(RctBankEntity entity) throws BackEndException;
	public void updateBank(RctBankEntity entity) throws BackEndException;
	public RctBankEntity retrieveBankById(String bankId) throws BackEndException;
	public List<RctBankEntity> retrieveBankByAbicode(String abicode) throws BackEndException;
	public List<RctBankEntity> retrieveBankByFitchCode(String fithCode) throws BackEndException;
	public List<RctBankEntity> retrieveBankByBloombCode(String bloombCode) throws BackEndException;
	public List<RctBankEntity> retrieveBankByName(String name) throws BackEndException;
	public List<RctBankEntity> retrieveBankByStatus(String status) throws BackEndException;
}
 