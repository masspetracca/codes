package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RCTIFPRTGH database table.
 * 
 */
@Embeddable
public class RctIfpRtgHEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int bankid;

	@Column(unique=true, nullable=false, length=1)
	private String provider;

	@Column(unique=true, nullable=false, length=2)
	private String rtgtype;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(unique=true, nullable=false)
	private java.util.Date lstupddate;

    public RctIfpRtgHEntityPK() {
    }
	public int getBankid() {
		return this.bankid;
	}
	public void setBankid(int bankid) {
		this.bankid = bankid;
	}
	public String getProvider() {
		return this.provider;
	}
	public void setProvider(String provider) {
		this.provider = provider;
	}
	public String getRtgtype() {
		return this.rtgtype;
	}
	public void setRtgtype(String rtgtype) {
		this.rtgtype = rtgtype;
	}
	public java.util.Date getLstupddate() {
		return this.lstupddate;
	}
	public void setLstupddate(java.util.Date lstupddate) {
		this.lstupddate = lstupddate;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RctIfpRtgHEntityPK)) {
			return false;
		}
		RctIfpRtgHEntityPK castOther = (RctIfpRtgHEntityPK)other;
		return 
			(this.bankid == castOther.bankid)
			&& this.provider.equals(castOther.provider)
			&& this.rtgtype.equals(castOther.rtgtype)
			&& this.lstupddate.equals(castOther.lstupddate);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.bankid;
		hash = hash * prime + this.provider.hashCode();
		hash = hash * prime + this.rtgtype.hashCode();
		hash = hash * prime + this.lstupddate.hashCode();
		
		return hash;
    }
}