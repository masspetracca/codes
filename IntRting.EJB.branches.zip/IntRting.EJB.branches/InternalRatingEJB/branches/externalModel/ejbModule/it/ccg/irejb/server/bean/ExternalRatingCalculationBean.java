package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.bean.eao.RctHisRtgEAOLocal;
import it.ccg.irejb.server.bean.eao.RctTrscodeEAOLocal;
import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.bean.entity.RctHisRtgEntity;
import it.ccg.irejb.server.bean.entity.RctRatingEntity;
import it.ccg.irejb.server.bean.entity.RctTrscodeEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ExternalRatingCalculation
 */
@Stateless
@Local(ExternalRatingCalculationBeanLocal.class)
public class ExternalRatingCalculationBean implements ExternalRatingCalculationBeanLocal {

	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private Logger calcLogger = Logger.getLogger(LoggerFactory.CALCULATION_LOGGER);
	
	@EJB
	private RctHisRtgEAOLocal rctHisRtgEAO;
	
	@EJB
	private RctTrscodeEAOLocal rctTrscodeEAO;
	
    /**
     * Default constructor. 
     */
    public ExternalRatingCalculationBean() {
        // TODO Auto-generated constructor stub
    }
    
    public Map<Integer,RctRatingEntity> dailyRun(List<RctBankEntity> rctBanks,Map<Integer,RctRatingEntity> ratings) throws BackEndException{
    	Map<String, RctTrscodeEntity> fitchTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("F");
    	Map<String, RctTrscodeEntity> moodysTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("M");
    	Map<String, RctTrscodeEntity> sPTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("S");
    	Map<String, RctTrscodeEntity> internalTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("I");
    	
    	bankCycle: for(RctBankEntity bank : rctBanks){				
			calcLogger.info(new StandardLogMessage("Bank "+bank.getBankName()+" id "+bank.getBankId()+";"));
			if(bank.getBloombCode()==null || bank.getBloombCode().equalsIgnoreCase("")){
				ejbLogger.info(new StandardLogMessage("No bloomberg code for bank "+bank.getBankName() +" "+bank.getBankId()));
				calcLogger.info(new StandardLogMessage("No bloomberg code for bank "+bank.getBankName() +";"));
				continue bankCycle;
			}
			//leggo le issues per ogni banca
			List<RctHisRtgEntity> extRatings= rctHisRtgEAO.retrieveLatestRatingByBlombCode(bank.getBloombCode());
			
			if(extRatings.size()==0){
				ejbLogger.info(new StandardLogMessage("No ratings for bank "+bank.getBankName() +" "+bank.getBankId()));
				calcLogger.info(new StandardLogMessage("No ratings for bank "+bank.getBankName() +";"));
				continue bankCycle;
			}
			
			RctHisRtgEntity appoRating = extRatings.get(0);
			ejbLogger.debug(new StandardLogMessage("(appoRating.getFitchRtg()==null || appoRating.getFitchRtg().equalsIgnoreCase(\"\") || appoRating.getFitchRtg().equalsIgnoreCase(\"WD\") || appoRating.getFitchRtg().equalsIgnoreCase(\"NR\") || appoRating.getFitchRtg().equalsIgnoreCase(\"WR\") || appoRating.getFitchRtg().equalsIgnoreCase(\"N.A.\")) &&"
				                                  +"(appoRating.getMoodRtg()==null || appoRating.getMoodRtg().equalsIgnoreCase(\"\") || appoRating.getMoodRtg().equalsIgnoreCase(\"WD\") || appoRating.getMoodRtg().equalsIgnoreCase(\"NR\") || appoRating.getMoodRtg().equalsIgnoreCase(\"WR\") || appoRating.getFitchRtg().equalsIgnoreCase(\"N.A.\")) && "
				+"(appoRating.getSpRtg()==null || appoRating.getSpRtg().equalsIgnoreCase(\"\") || appoRating.getSpRtg().equalsIgnoreCase(\"WD\") || appoRating.getSpRtg().equalsIgnoreCase(\"NR\") || appoRating.getSpRtg().equalsIgnoreCase(\"WR\") || appoRating.getFitchRtg().equalsIgnoreCase(\"N.A.\"))"+
								((appoRating.getFitchRtg()==null || appoRating.getFitchRtg().equalsIgnoreCase("") || appoRating.getFitchRtg().equalsIgnoreCase("WD") || appoRating.getFitchRtg().equalsIgnoreCase("NR") || appoRating.getFitchRtg().equalsIgnoreCase("WR") || appoRating.getFitchRtg().equalsIgnoreCase("N.A.")) &&
										(appoRating.getMoodRtg()==null || appoRating.getMoodRtg().equalsIgnoreCase("") || appoRating.getMoodRtg().equalsIgnoreCase("WD") || appoRating.getMoodRtg().equalsIgnoreCase("NR") || appoRating.getMoodRtg().equalsIgnoreCase("WR") || appoRating.getFitchRtg().equalsIgnoreCase("N.A.")) &&
										(appoRating.getSpRtg()==null || appoRating.getSpRtg().equalsIgnoreCase("") || appoRating.getSpRtg().equalsIgnoreCase("WD") || appoRating.getSpRtg().equalsIgnoreCase("NR") || appoRating.getSpRtg().equalsIgnoreCase("WR") || appoRating.getFitchRtg().equalsIgnoreCase("N.A.")))));
			
			if ((appoRating.getFitchRtg()==null || appoRating.getFitchRtg().equalsIgnoreCase("") || appoRating.getFitchRtg().equalsIgnoreCase("WD") || appoRating.getFitchRtg().equalsIgnoreCase("NR") || appoRating.getFitchRtg().equalsIgnoreCase("WR") || appoRating.getFitchRtg().equalsIgnoreCase("N.A.")) &&
				(appoRating.getMoodRtg()==null || appoRating.getMoodRtg().equalsIgnoreCase("") || appoRating.getMoodRtg().equalsIgnoreCase("WD") || appoRating.getMoodRtg().equalsIgnoreCase("NR") || appoRating.getMoodRtg().equalsIgnoreCase("WR") || appoRating.getMoodRtg().equalsIgnoreCase("N.A.")) &&
				(appoRating.getSpRtg()==null || appoRating.getSpRtg().equalsIgnoreCase("") || appoRating.getSpRtg().equalsIgnoreCase("WD") || appoRating.getSpRtg().equalsIgnoreCase("NR") || appoRating.getSpRtg().equalsIgnoreCase("WR") || appoRating.getSpRtg().equalsIgnoreCase("N.A."))){
				calcLogger.debug(new StandardLogMessage("Bank "+bank.getBankName()+" excluded because has not rating available"));
				continue bankCycle;
			}
			
	    	double divRtg=0;
			double sumRtg = 0;
			double externalResult=0;
	    	//transcodifica
	    	if (appoRating.getFitchRtg()!=null && 
	    		!appoRating.getFitchRtg().equalsIgnoreCase("") && 
	    		!appoRating.getFitchRtg().equalsIgnoreCase("WD") && 
	    		!appoRating.getFitchRtg().equalsIgnoreCase("NR") && 
	    		!appoRating.getFitchRtg().equalsIgnoreCase("WR") &&
	    		!appoRating.getFitchRtg().equalsIgnoreCase("N.A.")){
				ejbLogger.debug(new StandardLogMessage("fitch ratings "+appoRating.getFitchRtg()));
				calcLogger.info(new StandardLogMessage("fitch ratings "+appoRating.getFitchRtg()));

				appoRating.setFtcTrscRtg(((fitchTranscode.get(appoRating.getFitchRtg()))!=null ? fitchTranscode.get(appoRating.getFitchRtg()).getMinrtg().intValueExact() : 17));
				calcLogger.info(new StandardLogMessage("fitch transocded value "+((fitchTranscode.get(appoRating.getFitchRtg()))!=null ? fitchTranscode.get(appoRating.getFitchRtg()).getMinrtg().intValueExact() : 17)));
				
				sumRtg += appoRating.getFtcTrscRtg();
				ejbLogger.debug(new StandardLogMessage("fitch transcoded rating "+appoRating.getFtcTrscRtg()));
				divRtg++;
			}

			if (appoRating.getMoodRtg()!=null && 
				!appoRating.getMoodRtg().equalsIgnoreCase("") && 
				!appoRating.getMoodRtg().equalsIgnoreCase("WD") && 
				!appoRating.getMoodRtg().equalsIgnoreCase("NR") && 
				!appoRating.getMoodRtg().equalsIgnoreCase("WR") &&
	    		!appoRating.getMoodRtg().equalsIgnoreCase("N.A.")){
				ejbLogger.debug(new StandardLogMessage("moody's ratings "+appoRating.getMoodRtg()));
				calcLogger.info(new StandardLogMessage("moody's ratings "+appoRating.getMoodRtg()));
				
				appoRating.setMdsTrscRtg(((moodysTranscode.get(appoRating.getMoodRtg()))!=null ? moodysTranscode.get(appoRating.getMoodRtg()).getMinrtg().intValueExact() : 17));
				calcLogger.info(new StandardLogMessage("moody's transocded value "+((moodysTranscode.get(appoRating.getMoodRtg()))!=null ? moodysTranscode.get(appoRating.getMoodRtg()).getMinrtg().intValueExact() : 17)));
				
				sumRtg += appoRating.getMdsTrscRtg();
				ejbLogger.debug(new StandardLogMessage("moody's transcoded rating "+appoRating.getMdsTrscRtg()));
				divRtg++;
			}
			
			if (appoRating.getSpRtg()!=null && 
				!appoRating.getSpRtg().equalsIgnoreCase("") && 
				!appoRating.getSpRtg().equalsIgnoreCase("WD") && 
				!appoRating.getSpRtg().equalsIgnoreCase("NR") && 
				!appoRating.getSpRtg().equalsIgnoreCase("WR") &&
	    		!appoRating.getSpRtg().equalsIgnoreCase("N.A.")){
				ejbLogger.debug(new StandardLogMessage("S&P ratings "+appoRating.getSpRtg()));
				calcLogger.info(new StandardLogMessage("S&P ratings "+appoRating.getSpRtg()));
				
				appoRating.setSpTrscRtg(((sPTranscode.get(appoRating.getSpRtg()))!=null ? sPTranscode.get(appoRating.getSpRtg()).getMinrtg().intValueExact() : 17));
				calcLogger.info(new StandardLogMessage("S&P transocded value "+((sPTranscode.get(appoRating.getSpRtg()))!=null ? sPTranscode.get(appoRating.getSpRtg()).getMinrtg().intValueExact() : 17)));
								
				sumRtg += appoRating.getSpTrscRtg();
				ejbLogger.debug(new StandardLogMessage("S&P transcoded rating "+appoRating.getSpTrscRtg()));
				divRtg++;;
			}
	    	
			externalResult = sumRtg/divRtg;
			calcLogger.debug(new StandardLogMessage("result "+(int) Math.round(externalResult)+";"));
			int intResult = (int) Math.round(externalResult);
			calcLogger.info(new StandardLogMessage("externalRating "+intResult+";"));
			
			//transcode to output rank
			int finalResult=0;
			Set<String> interalrtg = internalTranscode.keySet();
			for (String rtg:interalrtg){
				RctTrscodeEntity appoTrnsc = internalTranscode.get(rtg);
				if (intResult>=17){
					calcLogger.info(new StandardLogMessage("External rating scaled rank "+7));
					finalResult = 7;
					break;
					//appoTrnsc.getMinrtg().intValue() <= intResult && intResult < appoTrnsc.getMaxrtg().intValue()
					//intResult < appoTrnsc.getMaxrtg().intValue() && intResult>=appoTrnsc.getMinrtg().intValue()
				}else if(appoTrnsc.getMinrtg().intValue() <= intResult && intResult < appoTrnsc.getMaxrtg().intValue()){
					calcLogger.info(new StandardLogMessage("External rating scaled rank "+appoTrnsc.getId().getRanking()));
					finalResult=appoTrnsc.getId().getRanking();
					break;
				}
			}
			
			if (ratings.get(bank.getBankId())!=null){
				ratings.get(bank.getBankId()).setExternrtg(new BigDecimal(finalResult));
			}else{
				RctRatingEntity ratingEntity = new RctRatingEntity();
				ratingEntity.setBankid(bank.getBankId());

				ratingEntity.setStatus("N");
				ratingEntity.setExternrtg(new BigDecimal(finalResult));
				
				ratings.put(ratingEntity.getBankid(), ratingEntity);
			}
		}
    	
    	return ratings;
    }

}
