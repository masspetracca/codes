package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.bean.eao.RctIssFldEAOLocal;
import it.ccg.irejb.server.bean.eao.RctIssuesEAOLocal;
import it.ccg.irejb.server.bean.eao.RctTrscodeEAOLocal;
import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.bean.entity.RctIssFldEntity;
import it.ccg.irejb.server.bean.entity.RctIssuesEntity;
import it.ccg.irejb.server.bean.entity.RctRatingEntity;
import it.ccg.irejb.server.bean.entity.RctTrscodeEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.system.SystemProperties;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;

import org.apache.commons.math3.analysis.function.Log;
import org.apache.commons.math3.stat.regression.SimpleRegression;
import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MarketRatingCalculationsBean
 */
@Stateless
@Local(MarketRatingCalculationsBeanLocal.class)
public class MarketRatingCalculationsBean implements MarketRatingCalculationsBeanLocal {

	private Properties properties;
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private Logger calcLogger = Logger.getLogger(LoggerFactory.CALCULATION_LOGGER);
	@EJB
	private RctIssuesEAOLocal rctIssuesEAO;
	
	@EJB
	private RctIssFldEAOLocal rctIssFldEAO;
	
	@EJB
	private RctTrscodeEAOLocal rctTrscodeEAO;
    /**
     * Default constructor. 
     * @throws BackEndException 
     */
    public MarketRatingCalculationsBean() throws BackEndException {
    	try {
			this.properties = SystemProperties.getLinearProperties();
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }

    public void setUp() throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in void MarketRatingCalculationsBean.setUp() throws BackEndException"));
    	try {
	    	ejbLogger.debug(new StandardLogMessage("loading every updated issues"));
	
	    	//carico tutti i valore delle issues dove la data di inserimento valore � pi� vicina alla data odierna 
	    	List<RctIssFldEntity> issues =  this.rctIssFldEAO.retrieveLatestIssFld();
	    	ejbLogger.debug(new StandardLogMessage("issues retrieved "+issues.size()));
	    	ejbLogger.debug(new StandardLogMessage("loading transcoding values"));
	    	//carico i transcode per i ratings dei vari infoproviders
	    	Map<String, RctTrscodeEntity> fitchTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("F");
	    	Map<String, RctTrscodeEntity> moodysTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("M");
	    	Map<String, RctTrscodeEntity> sPTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("S");
	    	
	    	
	    	//mappa che contiene gli arraylist utilizzato per calcolare la deviazione standard
	    	Map <Integer,RatingClass> sprdMap= new HashMap<Integer,RatingClass>();
	    	sprdMap.put(1, new RatingClass());sprdMap.put(2, new RatingClass());sprdMap.put(3, new RatingClass());sprdMap.put(4, new RatingClass());
	    	sprdMap.put(5, new RatingClass());sprdMap.put(6, new RatingClass());sprdMap.put(7, new RatingClass());sprdMap.put(8, new RatingClass());
	    	sprdMap.put(9, new RatingClass());sprdMap.put(10, new RatingClass());sprdMap.put(11, new RatingClass());sprdMap.put(12, new RatingClass());
	    	sprdMap.put(13, new RatingClass());sprdMap.put(14, new RatingClass());sprdMap.put(15, new RatingClass());sprdMap.put(16, new RatingClass());
	    	sprdMap.put(17, new RatingClass());
	    	
	    	
	    	ejbLogger.debug(new StandardLogMessage("starting calculation"));
	    	//trascodifico tutti i ratings
	    	issueCycle: for (int idx =0 ;idx<issues.size(); idx++){
	    		ejbLogger.debug(new StandardLogMessage("(issues.get(idx).getMtStOtrSpr().doubleValue()<0 || " +
	    												"issues.get(idx).getMtStOtrSpr().doubleValue()>10000 ||" +
	    												"issues.get(idx).getMtStOtrSpr().doubleValue()==0)||" +
	    												"((issues.get(idx).getFitchRtg()==null || issues.get(idx).getFitchRtg().equalsIgnoreCase(\"\") || issues.get(idx).getFitchRtg().equalsIgnoreCase(\"WD\") || issues.get(idx).getFitchRtg().equalsIgnoreCase(\"NR\") || issues.get(idx).getFitchRtg().equalsIgnoreCase(\"WR\")) &&" +
	    												" (issues.get(idx).getMoodRtg()==null || issues.get(idx).getMoodRtg().equalsIgnoreCase(\"\") || issues.get(idx).getMoodRtg().equalsIgnoreCase(\"WD\") || issues.get(idx).getMoodRtg().equalsIgnoreCase(\"NR\") || issues.get(idx).getMoodRtg().equalsIgnoreCase(\"WR\")) && " +
	    												" (issues.get(idx).getSpRtg()==null || issues.get(idx).getSpRtg().equalsIgnoreCase(\"\") || issues.get(idx).getSpRtg().equalsIgnoreCase(\"WD\") || issues.get(idx).getSpRtg().equalsIgnoreCase(\"NR\")|| issues.get(idx).getSpRtg().equalsIgnoreCase(\"WR\"))) "+
	    												((issues.get(idx).getMtStOtrSpr().doubleValue()<0 || issues.get(idx).getMtStOtrSpr().doubleValue()>10000 || issues.get(idx).getMtStOtrSpr().doubleValue()==0)||
										    			((issues.get(idx).getFitchRtg()==null || issues.get(idx).getFitchRtg().equalsIgnoreCase("") || issues.get(idx).getFitchRtg().equalsIgnoreCase("WD") || issues.get(idx).getFitchRtg().equalsIgnoreCase("NR") || issues.get(idx).getFitchRtg().equalsIgnoreCase("WR")) &&
										    			 (issues.get(idx).getMoodRtg()==null || issues.get(idx).getMoodRtg().equalsIgnoreCase("") || issues.get(idx).getMoodRtg().equalsIgnoreCase("WD") || issues.get(idx).getMoodRtg().equalsIgnoreCase("NR") || issues.get(idx).getMoodRtg().equalsIgnoreCase("WR")) &&
										    			 (issues.get(idx).getSpRtg()==null || issues.get(idx).getSpRtg().equalsIgnoreCase("") || issues.get(idx).getSpRtg().equalsIgnoreCase("WD") || issues.get(idx).getSpRtg().equalsIgnoreCase("NR") || issues.get(idx).getSpRtg().equalsIgnoreCase("WR"))))));
	    		
	    		if ((issues.get(idx).getMtStOtrSpr().doubleValue()<0 || 
	    			 issues.get(idx).getMtStOtrSpr().doubleValue()>10000 || 
	    			 issues.get(idx).getMtStOtrSpr().doubleValue()==0)||
	    			((issues.get(idx).getFitchRtg()==null || issues.get(idx).getFitchRtg().equalsIgnoreCase("") || issues.get(idx).getFitchRtg().equalsIgnoreCase("WD") || issues.get(idx).getFitchRtg().equalsIgnoreCase("NR") || issues.get(idx).getFitchRtg().equalsIgnoreCase("WR")) &&
	    			 (issues.get(idx).getMoodRtg()==null || issues.get(idx).getMoodRtg().equalsIgnoreCase("") || issues.get(idx).getMoodRtg().equalsIgnoreCase("WD") || issues.get(idx).getMoodRtg().equalsIgnoreCase("NR") || issues.get(idx).getMoodRtg().equalsIgnoreCase("WR")) &&
	    			 (issues.get(idx).getSpRtg()==null || issues.get(idx).getSpRtg().equalsIgnoreCase("") || issues.get(idx).getSpRtg().equalsIgnoreCase("WD") || issues.get(idx).getSpRtg().equalsIgnoreCase("NR") || issues.get(idx).getSpRtg().equalsIgnoreCase("WR")))){
	    			calcLogger.debug(new StandardLogMessage("issue "+issues.get(idx).getDsplyName()+" excluded spread= "+issues.get(idx).getMtStOtrSpr()));
	    			continue issueCycle;
	    		}
	    		ejbLogger.debug(new StandardLogMessage("issues retrieved "+issues.size()));
	    		ejbLogger.debug(new StandardLogMessage("issue spread "+issues.get(idx).getMtStOtrSpr()));
	    		calcLogger.debug(new StandardLogMessage("issue "+issues.get(idx).getDsplyName()+" spread= "+issues.get(idx).getMtStOtrSpr()));
	    		double divRtg=0;
				double avgRtg=0;
				double sumRtg = 0;
				if (issues.get(idx).getFitchRtg()!=null && !issues.get(idx).getFitchRtg().equalsIgnoreCase("") && !issues.get(idx).getFitchRtg().equalsIgnoreCase("WD") && !issues.get(idx).getFitchRtg().equalsIgnoreCase("NR") && !issues.get(idx).getFitchRtg().equalsIgnoreCase("WR")){
					ejbLogger.debug(new StandardLogMessage("fitch ratings "+issues.get(idx).getFitchRtg()));
					sumRtg += (fitchTranscode.get(issues.get(idx).getFitchRtg()))!=null ? fitchTranscode.get(issues.get(idx).getFitchRtg()).getMinrtg().intValueExact() : 17;
					issues.get(idx).setFithcTrsc((fitchTranscode.get(issues.get(idx).getFitchRtg()))!=null?fitchTranscode.get(issues.get(idx).getFitchRtg()).getMinrtg().intValueExact():17);
					divRtg++;
				}
				
				if (issues.get(idx).getMoodRtg()!=null && !issues.get(idx).getMoodRtg().equalsIgnoreCase("") && !issues.get(idx).getMoodRtg().equalsIgnoreCase("WD") && !issues.get(idx).getMoodRtg().equalsIgnoreCase("NR") && !issues.get(idx).getMoodRtg().equalsIgnoreCase("WR")){
					ejbLogger.debug(new StandardLogMessage("moody's ratings "+issues.get(idx).getMoodRtg()));
					sumRtg += (moodysTranscode.get(issues.get(idx).getMoodRtg()))!=null?moodysTranscode.get(issues.get(idx).getMoodRtg()).getMinrtg().intValueExact():17;
					issues.get(idx).setMoodTrsc((moodysTranscode.get(issues.get(idx).getMoodRtg()))!=null?moodysTranscode.get(issues.get(idx).getMoodRtg()).getMinrtg().intValueExact():17);
					divRtg++;
				}
				
				if (issues.get(idx).getSpRtg()!=null && !issues.get(idx).getSpRtg().equalsIgnoreCase("") && !issues.get(idx).getSpRtg().equalsIgnoreCase("WD") && !issues.get(idx).getSpRtg().equalsIgnoreCase("NR") && !issues.get(idx).getSpRtg().equalsIgnoreCase("WR")){
					ejbLogger.debug(new StandardLogMessage("S&P ratings "+issues.get(idx).getSpRtg()));
					sumRtg += (sPTranscode.get(issues.get(idx).getSpRtg()))!= null?sPTranscode.get(issues.get(idx).getSpRtg()).getMinrtg().intValueExact():17;
					issues.get(idx).setSpTrsc((sPTranscode.get(issues.get(idx).getSpRtg()))!= null?sPTranscode.get(issues.get(idx).getSpRtg()).getMinrtg().intValueExact():17);
					divRtg++;
				}
				
				avgRtg = sumRtg / divRtg;
				calcLogger.debug(new StandardLogMessage("sum for issue "+issues.get(idx).getDsplyName()+" = "+sumRtg));
				calcLogger.debug(new StandardLogMessage("div for issue "+issues.get(idx).getDsplyName()+" = "+divRtg));
				calcLogger.debug(new StandardLogMessage("average rating for issue "+issues.get(idx).getDsplyName()+" = "+ avgRtg ));
				issues.get(idx).setAvrgRtg((int)Math.round(avgRtg));
				
				switch (issues.get(idx).getAvrgRtg()){
					case 1:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(1).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 1"));
						break;
					case 2:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(2).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 2"));
						break;
					case 3:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(3).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 3"));
						break;
					case 4:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(4).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 4"));
						break;
					case 5:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(5).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 5"));
						break;
					case 6:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(6).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 6"));
						break;
					case 7:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(7).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 7"));
						break;
					case 8:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(8).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 8"));
						break;
					case 9:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(9).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 9"));
						break;
					case 10:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(10).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 10"));
						break;
					case 11:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(11).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 11"));
						break;
					case 12:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(12).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 12"));
						break;
					case 13:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(13).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 13"));
						break;
					case 14:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(14).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 14"));
						break;
					case 15:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(15).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 15"));
						break;
					case 16:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(16).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 16"));
						break;
					case 17:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(17).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 17"));
						break;
					default:
						break;
				}
	    	}
	    	 
	    	SimpleRegression linearRegretion = new SimpleRegression();
	    	
	    	Set<Integer> keys = sprdMap.keySet();
	
	    	for(int i :keys){
	    		
	    		ejbLogger.debug(new StandardLogMessage("Present "+sprdMap.get(i).getIssuer().size() +" issues for rank "+i));
	    		calcLogger.debug(new StandardLogMessage("Present "+sprdMap.get(i).getIssuer().size() +" issues for rank "+i));
	    		if (sprdMap.get(i).getIssuer().size()>0){
		    		calcLogger.debug(new StandardLogMessage("adding "+sprdMap.get(i).getLnAvgStdDev()));
		    		calcLogger.debug(new StandardLogMessage("Calculations for rank "+i));
		    		linearRegretion.addData(sprdMap.get(i).getLnAvgStdDev(),(double)i);
	    		}
	    	}
	    	calcLogger.info(new StandardLogMessage("slope market "+linearRegretion.getSlope()));
	    	calcLogger.info(new StandardLogMessage("offset market "+linearRegretion.getIntercept()));
	    	this.properties.put("slope.Market", linearRegretion.getSlope()+"");
			this.properties.put("offset.Market",linearRegretion.getIntercept()+"");
			
			ejbLogger.debug(new StandardLogMessage("store path "+SystemProperties.getLinearPropertiesFileAbsPath()));
			this.properties.store(new FileWriter(SystemProperties.getLinearPropertiesFileAbsPath()), null);
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
		}
    }
    
    public Map<Integer,RctRatingEntity> dailyRun(List<RctBankEntity> rctBanks,Map<Integer,RctRatingEntity> ratings) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in MarketRatingCalculationsBean.dailyRun"));
		Map<String, RctTrscodeEntity> internalTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("I");
		try {
			
			bankCycle: for(RctBankEntity bank : rctBanks){				
				calcLogger.info(new StandardLogMessage("Bank "+bank.getBankName()+" id "+bank.getBankId()+";"));
				if(bank.getRTicker()==null || bank.getRTicker().equalsIgnoreCase("")){
					ejbLogger.info(new StandardLogMessage("No reuters ticker for bank "+bank.getBankName() +" "+bank.getBankId()));
					calcLogger.info(new StandardLogMessage("No reuters ticker for bank "+bank.getBankName() +";"));
					continue bankCycle;
				}
				//leggo le issues per ogni banca
				List<RctIssuesEntity> issues= rctIssuesEAO.retrieveLatestIssuesByTicker(bank.getRTicker());
				if(issues.size()==0){
					ejbLogger.info(new StandardLogMessage("No issues for bank "+bank.getBankName() +" "+bank.getBankId()));
					calcLogger.info(new StandardLogMessage("No issues for bank "+bank.getBankName() +";"));
					continue bankCycle;
				}
				double result = 0;
				double sumSpread=0;
				int divSpread=0;
				//inizio l'immenso calcolo
				for (RctIssuesEntity issue: issues){
					
					//calcolo lo spread medio di tutte le issues per la banca
					if(issue.getMtStOtrSpr()!=null && issue.getMtStOtrSpr().doubleValue() !=0){
						sumSpread+=issue.getMtStOtrSpr().doubleValue();
						divSpread++;
					}
				}
				
				double avgSpread = sumSpread/divSpread;
				
				Log logarithm = new Log();
				ejbLogger.info(new StandardLogMessage("logarithm calculation"));
				Double slopeMarket = new Double(this.properties.getProperty("slope.Market"));
				Double offsetMarket = new Double(this.properties.getProperty("offset.Market"));
				
				calcLogger.info(new StandardLogMessage("ln(score) "+logarithm.value(avgSpread)+";"));
				calcLogger.debug(new StandardLogMessage("formula "+slopeMarket +" * "+logarithm.value(avgSpread)+" + "+offsetMarket+";"));
				result = (slopeMarket * logarithm.value(avgSpread))+offsetMarket;
				calcLogger.debug(new StandardLogMessage("result "+(int) Math.round(result)+";"));
				int intResult = (int) Math.round(result);
				calcLogger.info(new StandardLogMessage("maketRating "+intResult+";"));
				
				if (result>17){
					result=17;
				}else if(result<1){
					result=1;
				}
				
				//transcode to output rank
				int finalResult=0;
				Set<String> interalrtg = internalTranscode.keySet();
				for (String rtg:interalrtg){
					RctTrscodeEntity appoTrnsc = internalTranscode.get(rtg);
					if (intResult>=17){
						calcLogger.info(new StandardLogMessage("Market rating scaled rank "+7));
						finalResult = 7;
						break;
					}else if(intResult < appoTrnsc.getMaxrtg().intValue() && intResult>=appoTrnsc.getMinrtg().intValue()){
						calcLogger.info(new StandardLogMessage("Market rating scaled rank "+appoTrnsc.getId().getRanking()));
						finalResult=appoTrnsc.getId().getRanking();
						break;
					}
				}
				if (ratings.get(bank.getBankId())!=null){
					ratings.get(bank.getBankId()).setSpreadrtg(new BigDecimal(finalResult));
				}else{
					RctRatingEntity ratingEntity = new RctRatingEntity();
					ratingEntity.setBankid(bank.getBankId());
	
					ratingEntity.setStatus("N");
					ratingEntity.setSpreadrtg(new BigDecimal(finalResult));
					
					ratings.put(ratingEntity.getBankid(), ratingEntity);
					
				}
				
			}
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
		}
    	return ratings;
	}
}

