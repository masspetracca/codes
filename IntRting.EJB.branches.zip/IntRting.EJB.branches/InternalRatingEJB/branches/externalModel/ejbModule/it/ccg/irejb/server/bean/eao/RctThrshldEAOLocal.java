package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctThrshldEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

public interface RctThrshldEAOLocal {

	public void insertRctThreshold(RctThrshldEntity entity) throws BackEndException;
    public void deleteRctThreshold(RctThrshldEntity entity) throws BackEndException;
    public void updateRctThreshold(RctThrshldEntity entity) throws BackEndException;
    public RctThrshldEntity retrieveThresholdById(int varId,int thresholdId,String thresholdDate) throws BackEndException;
	public List<RctThrshldEntity> retrieveSortedThresholdByVarId(int varId) throws BackEndException;
	public List<RctThrshldEntity> retrieveThresholdByThrshldDate(String thrshldDate) throws BackEndException;
	public List<RctThrshldEntity> retrieveThresholdByThrshldId(String thrshldId) throws BackEndException;
}
