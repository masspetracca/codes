package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.bean.eao.RctBnkFtcTEAOLocal;
import it.ccg.irejb.server.bean.eao.RctThrshldEAOLocal;
import it.ccg.irejb.server.bean.eao.RctVarHEAOLocal;
import it.ccg.irejb.server.bean.eao.RctVarsEAOLocal;
import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.bean.entity.RctBnkFtcTEntity;
import it.ccg.irejb.server.bean.entity.RctRatingEntity;
import it.ccg.irejb.server.bean.entity.RctThrshldEntity;
import it.ccg.irejb.server.bean.entity.RctVarHEntity;
import it.ccg.irejb.server.bean.entity.RctVarsEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.system.SystemProperties;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;

import org.apache.commons.math3.analysis.function.Exp;
import org.apache.commons.math3.analysis.function.Log;
import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RatingsCaculationsBean
 */
@Stateless
@Local(FinancialRatingCaculationsBeanLocal.class)
public class FinancialRatingCaculationsBean implements FinancialRatingCaculationsBeanLocal {
	private Properties properties;
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private Logger calcLogger = Logger.getLogger(LoggerFactory.CALCULATION_LOGGER);
		
	@EJB
	private RctVarsEAOLocal rctVarsEao;
	
	@EJB
	private RctThrshldEAOLocal rctThrshldEAO;
	
	@EJB
	private RctVarHEAOLocal rctVarHEAO;
	
	@EJB
	private RctBnkFtcTEAOLocal rctBnkFtcTEAO;
    
	/**
     * Default constructor. 
     * @throws Exception 
     */
    public FinancialRatingCaculationsBean() throws BackEndException {
    	try {
			this.properties = SystemProperties.getLinearProperties();
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    
    public Map<Integer,RctRatingEntity> dailyRun(List<RctBankEntity> rctBanks) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in FinancialRatingCaculationsBean.dailyRun"));
		
		Map<Integer,RctRatingEntity> ratings = new HashMap<Integer,RctRatingEntity>();
    	
		try {
			ejbLogger.info(new StandardLogMessage("retrieve every enabled vars"));
			List<RctVarsEntity> enabledVars = rctVarsEao.retrieveRtcVarForDailyRunCalc();
			ejbLogger.info(new StandardLogMessage("Enabled var num: "+enabledVars.size()));
			
			//carico le soglie una volta per tutte
			//nuovo
			Map <Integer,List<RctThrshldEntity>> thrshldMap = new HashMap<Integer, List<RctThrshldEntity>>();
			for (RctVarsEntity var:enabledVars){
				List<RctThrshldEntity> thrshldsAp = rctThrshldEAO.retrieveSortedThresholdByVarId(var.getId().getVarid());
				thrshldMap.put(var.getId().getVarid(), thrshldsAp);
			}
			//fine nuovo
			
			bankCycle: for(RctBankEntity bank : rctBanks){
				
				//leggo gli dati di bilancio per ogni banca
				//popolo list<datiDiBinalcio>
				RctRatingEntity ratingEntity = new RctRatingEntity();
				ratingEntity.setBankid(bank.getBankId());
				calcLogger.info(new StandardLogMessage("Bank "+bank.getBankName()+" id "+bank.getBankId()+";"));
		
				ratingEntity.setStatus("N");
				
				double logit=0;
				double result = 0;
				
				List<RctThrshldEntity> thrshlds;
				//inizio l'immenso calcolo
				for (RctVarsEntity var:enabledVars){
					// carico le soglie
					ejbLogger.info(new StandardLogMessage("retrieve every thresholds"));
					/* originale
					 * thrshlds = rctThrshldEAO.retrieveSortedThresholdByVarId(var.getId().getVarid());
					 */
					thrshlds = thrshldMap.get(var.getId().getVarid());
					ejbLogger.info(new StandardLogMessage("Thresholds num for varid "+var.getId().getVarid()+": "+thrshlds.size()));
					
					//carico i fitchnickname per ogni fitchcode
					if (bank.getFitchCode() == null || bank.getFitchCode().equalsIgnoreCase("")){
						ejbLogger.info(new StandardLogMessage("No firch code for bank "+bank.getBankName() +" "+bank.getBankId()));
						calcLogger.info(new StandardLogMessage("No firch code for bank "+bank.getBankName() +";"));
						continue bankCycle;
					}
					List<RctBnkFtcTEntity> bnkFtcs = rctBnkFtcTEAO.retrieveBnkFtcTForCalculationByFitchCode(Integer.parseInt(bank.getFitchCode()));
					ejbLogger.info(new StandardLogMessage("Fitch nickname num for bankid "+bank.getBankId()+" and fitchcode "+bank.getFitchCode()+": "+bnkFtcs.size()));
					
					if (bnkFtcs.size()==0){
						ejbLogger.error(new StandardLogMessage("no Transcode record for fitch code "+bank.getFitchCode()));
						calcLogger.info(new StandardLogMessage("No Transcode record for fitch code "+bank.getBankName() +";"));
						continue bankCycle;
					}
					
					//carico i valori di bilancio per i fitchnichname
					List<RctVarHEntity> varsHEntity = rctVarHEAO.retrieveVarHhistByVarIdFitchNName(var.getId().getVarid(), bnkFtcs.get(0).getId().getFitchnname());
					ejbLogger.info(new StandardLogMessage("Var values num for varid "+var.getId().getVarid()+" and fitch nickname "+bnkFtcs.get(0).getId().getFitchnname()+": "+varsHEntity.size()));
					
					if (varsHEntity == null || varsHEntity.size()==0){
						ejbLogger.error(new StandardLogMessage("no var history record for varid "+var.getId().getVarid()));
						continue bankCycle;
					}

					//controllo subito se � il caso di NA
					if (varsHEntity.get(0).getVarvalue()==null || varsHEntity.get(0).getVarvalue().equals(new BigDecimal(0))){
						calcLogger.info(new StandardLogMessage("var "+varsHEntity.get(0).getId().getVarid()+" value null;"));
						ejbLogger.info(new StandardLogMessage("NA case"));
						RctThrshldEntity naEnt = thrshlds.get(3);
						calcLogger.info(new StandardLogMessage("NA threshold selected "+naEnt.getThrshldcoe()+";"));
						logit += naEnt.getThrshldcoe();
						//sommatoria.add(new BigDecimal(naEnt.getThrshldval()));
					}else{
						calcLogger.info(new StandardLogMessage("var "+varsHEntity.get(0).getId().getVarid()+" value "+varsHEntity.get(0).getVarvalue().divide(new BigDecimal(100))+";"));
						//non � il caso NA quindi controllo le soglie
						ejbLogger.info(new StandardLogMessage("no NA case than start threshold calculation"));
						Iterator<RctThrshldEntity> thrsIt = thrshlds.iterator();
						Double appoLogit = null;
						RctThrshldEntity appo;
						while (thrsIt.hasNext()){
							appo = thrsIt.next();
							if (!appo.getThrshldop().equalsIgnoreCase("NA") && !appo.getThrshldop().equalsIgnoreCase("else")){
								BigDecimal tempVarVal = varsHEntity.get(0).getVarvalue().divide(new BigDecimal(100));
								ejbLogger.debug("appo.getThrshldval() "+appo.getThrshldval());
								ejbLogger.debug("varsHEntity.get(0).getVarvalue() "+varsHEntity.get(0).getVarvalue());
								ejbLogger.debug("varsHEntity.get(0).getVarvalue().min(new BigDecimal(appo.getThrshldval()))== varsHEntity.get(0).getVarvalue() "+(tempVarVal.min(new BigDecimal(appo.getThrshldval()))== tempVarVal));
								if ((tempVarVal.min(new BigDecimal(appo.getThrshldval())) == tempVarVal) && appoLogit == null){
									calcLogger.info((new StandardLogMessage("threshold selected "+appo.getThrshldcoe()+";")));
									appoLogit = new Double(appo.getThrshldcoe());
									//continue appoLogitCalc;
								}
							}
						}
						
						if (appoLogit==null){
							ejbLogger.info(new StandardLogMessage("else case"));
							calcLogger.info(new StandardLogMessage("Else threshold selected "+thrshlds.get(2).getThrshldcoe()+";"));
							appoLogit = new Double(thrshlds.get(2).getThrshldcoe());
						}
						calcLogger.debug(new StandardLogMessage("appoSomm.doubleValue() "+appoLogit.doubleValue()+";"));
						logit += appoLogit.doubleValue();
					}
				}
				
				Log logarithm = new Log();
				ejbLogger.info(new StandardLogMessage("logarithm calculation"));
				Double slopeFinancial = new Double(this.properties.getProperty("slope.Financial"));
				Double constantFinancial = new Double(this.properties.getProperty("constant.financial"));
				Double offsetFinancial = new Double(this.properties.getProperty("offset.Financial"));
				logit+= constantFinancial;
				calcLogger.info(new StandardLogMessage("logit "+logit+";"));
				
				Exp exp = new Exp();
				double score = (exp.value(logit)/(1+exp.value(logit)));
				calcLogger.info(new StandardLogMessage("score "+score+";"));
				
				calcLogger.info(new StandardLogMessage("ln(score) "+logarithm.value(score)+";"));
				calcLogger.debug(new StandardLogMessage("formula "+slopeFinancial +" * "+logarithm.value(score)+" + "+offsetFinancial+";"));
				result = (slopeFinancial * logarithm.value(score))+offsetFinancial;
				calcLogger.info(new StandardLogMessage("result "+result+";"));
				//double a = Math.round(result*100.0)/100.0;
				calcLogger.debug(new StandardLogMessage("round "+new BigDecimal(Math.round(result*100.0)/100.0)+";"));
				ratingEntity.setBalancertg(new BigDecimal(Math.round(result*100.0)/100.0));
				calcLogger.info(new StandardLogMessage("balanceRating "+ratingEntity.getBalancertg()+";"));
				ratings.put(ratingEntity.getBankid(), ratingEntity);
				
			}
			ejbLogger.info(new StandardLogMessage("####################"+ratings.size()+ " ratings calculated #################################"));
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
		}
    	return ratings;
	}

}
