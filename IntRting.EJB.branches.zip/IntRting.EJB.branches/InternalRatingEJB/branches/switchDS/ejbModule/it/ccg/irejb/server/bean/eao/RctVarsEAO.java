package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctVarsEntity;
import it.ccg.irejb.server.bean.entity.RctVarsEntityPK;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RctVarsEAO
 */
@Stateless
@Local(RctVarsEAOLocal.class)
public class RctVarsEAO implements RctVarsEAOLocal {

	@PersistenceContext(type=PersistenceContextType.TRANSACTION)
	private EntityManager manager;

	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
    /**
     * Default constructor. 
     */
    public RctVarsEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertRtcVar(RctVarsEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertRtcVar(RctVarsEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctVarsEntity identification data: VarID = "+entity.getId().getVarid()+" provider = "+entity.getId().getProvider()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	this.manager.persist(entity);
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    public void deleteRtcVar(RctVarsEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteRtcVar(RctVarsEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctVarsEntity identification data: VarID = "+entity.getId().getVarid()+" provider = "+entity.getId().getProvider()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }

    public void updateRtcVar(RctVarsEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in updateRtcVar(RctVarsEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctVarsEntity identification data: VarID = "+entity.getId().getVarid()+" provider = "+entity.getId().getProvider()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.merge(entity);
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    public RctVarsEntity retrieveRtcVarById(int varId,String provider) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in RctVarHEntity retrieveRtcVarHistory(String varId,String provider,String valueDate) throws BackEndException"));
	    	
	    	RctVarsEntityPK pk = new RctVarsEntityPK();
			pk.setVarid(varId);
			pk.setProvider(provider);
	
	    	ejbLogger.debug(new StandardLogMessage("Var ID: "+varId));
	    	ejbLogger.debug(new StandardLogMessage("Provider: "+provider));
	    	ejbLogger.debug(new StandardLogMessage("find"));
	    	
	    	RctVarsEntity var = (RctVarsEntity)this.manager.find(RctVarsEntity.class, pk);
	
	    	return var;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    //getRtcVarByVarId
    @SuppressWarnings("unchecked")
	public List<RctVarsEntity> retrieveRtcVarByVarId(int varId) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctVarsEntity> retrieveRtcVarByVarId(String varId)"));
	    	ejbLogger.debug(new StandardLogMessage("Var id: "+varId));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getRtcVarByVarId");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("varid", varId);
	    	
	    	ejbLogger.debug("getResultList");
			List<RctVarsEntity> ratings = (List<RctVarsEntity>) q.getResultList();
			
	    	return ratings;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    //getRtcVarByProvider
    @SuppressWarnings("unchecked")
	public List<RctVarsEntity> retrieveRtcVarByProvider(String provider) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctVarsEntity> retrieveRtcVarByProvider(String provider)"));
	    	ejbLogger.debug(new StandardLogMessage("provider: "+provider));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getRtcVarByProvider");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("provider", provider);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctVarsEntity> ratings = (List<RctVarsEntity>) q.getResultList();
			
	    	return ratings;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    //getRtcVarByYearSetup
    @SuppressWarnings("unchecked")
	public List<RctVarsEntity> retrieveRtcVarByYearSetup(String yearSetup) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctVarsEntity> retrieveRtcVarByYearSetup(String yearSetup)"));
	    	ejbLogger.debug(new StandardLogMessage("year setup: "+yearSetup));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getRtcVarByYearSetup");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("yearsetup", yearSetup);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctVarsEntity> ratings = (List<RctVarsEntity>) q.getResultList();
			
	    	return ratings;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    //getRtcVarByStatus
    @SuppressWarnings("unchecked")
	public List<RctVarsEntity> retrieveRtcVarByStatus(String status) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctVarsEntity> retrieveRtcVarByStatus(String status)"));
	    	ejbLogger.debug(new StandardLogMessage("status: "+status));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getRtcVarByStatus");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("status", status);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctVarsEntity> ratings = (List<RctVarsEntity>) q.getResultList();
			
	    	return ratings;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    //getRtcVarByDailyRun
    @SuppressWarnings("unchecked")
	public List<RctVarsEntity> retrieveRtcVarByDailyRun(String dailyRun) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctVarsEntity> retrieveRtcVarByDailyRun(String dailyRun)"));
	    	ejbLogger.debug(new StandardLogMessage("Daily run: "+dailyRun));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getRtcVarByStatus");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("dailyrun", dailyRun);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctVarsEntity> ratings = (List<RctVarsEntity>) q.getResultList();
			
	    	return ratings;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    //getRtcVarForDailyRunCalc
    @SuppressWarnings("unchecked")
   	public List<RctVarsEntity> retrieveRtcVarForDailyRunCalc() throws BackEndException{
       	try{
   	    	ejbLogger.debug(new StandardLogMessage("in List<RctVarsEntity> retrieveRtcVarForDailyRunCalc()"));
     	    ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
   	    	Query q = this.manager.createNamedQuery("getRtcVarForDailyRunCalc");
   	    	
   	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
   			List<RctVarsEntity> ratings = (List<RctVarsEntity>) q.getResultList();
   			
   	    	return ratings;
   	    }catch(Exception e){
   	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
   			throw new BackEndException(e);
   		}
    }
    
    //getRtcVar
    @SuppressWarnings("unchecked")
   	public List<RctVarsEntity> retrieveEveryRtcVar() throws BackEndException{
       	try{
   	    	ejbLogger.debug(new StandardLogMessage("in List<RctVarsEntity> retrieveEveryRtcVar()"));
     	    ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
   	    	Query q = this.manager.createNamedQuery("getRtcVar");
   	    	
   	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
   			List<RctVarsEntity> ratings = (List<RctVarsEntity>) q.getResultList();
   			
   	    	return ratings;
   	    }catch(Exception e){
   	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
   			throw new BackEndException(e);
   		}
    }
}
