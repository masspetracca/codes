package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RctBankEAO
 */
@Stateless
@Local(RctBankEAOLocal.class)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class RctBankEAO implements RctBankEAOLocal {

	@PersistenceContext(type=PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public RctBankEAO() {
        // TODO Auto-generated constructor stub
    }
    
    public void insertBank(RctBankEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertBank(RctBankEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctBankEntity identification data: Bank name = "+entity.getBankName()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    }
    
    public void deleteBank(RctBankEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteBank(RctBankEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctBankEntity identification data: ABICODE = "+entity.getAbiCode()+" Bank name = "+entity.getBankName()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    }

    public void updateBank(RctBankEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in updateBank(RctBankEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctBankEntity identification data: ABICODE = "+entity.getAbiCode()+" Bank name = "+entity.getBankName()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    }
    
    public RctBankEntity retrieveBankById(String bankId) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in RctBankEntity retrieveBank(String bankId)"));
	    	ejbLogger.debug(new StandardLogMessage("Bank identification ID: "+bankId));
	    	ejbLogger.debug(new StandardLogMessage("find"));
	    	RctBankEntity bank = (RctBankEntity)this.manager.find(RctBankEntity.class, bankId);
	    	
	    	return bank;
    	}catch(Exception e){ 
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
    }
    
    @SuppressWarnings("unchecked")
    /*
     * @NamedQuery(name="getBankByAbicode", query="SELECT bank FROM RctBankEntity bank WHERE bank.abicode= :abicode ORDER BY bank.bankname ASC"),
     */
    public List<RctBankEntity> retrieveBankByAbicode(String abicode) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctBankEntity> retrieveBankByAbicode(String abicode)"));
	    	ejbLogger.debug(new StandardLogMessage("Bank ABICODE: "+abicode));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getBankByAbicode");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("abicode", abicode);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctBankEntity> banks = (List<RctBankEntity>) q.getResultList();
			
	    	return banks;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    @SuppressWarnings("unchecked")
    /*
     * @NamedQuery(name="getBankByFitchCode", query="SELECT bank FROM RctBankEntity bank WHERE bank.fitchcode= :fitchcode ORDER BY bank.bankname ASC"),
     */
    public List<RctBankEntity> retrieveBankByFitchCode(String fithCode) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctBankEntity> retrieveBankByFitchCode(String fithCode)"));
	    	ejbLogger.debug(new StandardLogMessage("Bank FitchCode: "+fithCode));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getBankByFitchCode");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("fitchcode", fithCode);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctBankEntity> banks = (List<RctBankEntity>) q.getResultList();
			
	    	return banks;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    @SuppressWarnings("unchecked")
    /*
     * @NamedQuery(name="getBankByBloombCode", query="SELECT bank FROM RctBankEntity bank WHERE bank.bloombcode= :bloombcode ORDER BY bank.bankname ASC"),
     */
    public List<RctBankEntity> retrieveBankByBloombCode(String bloombCode) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctBankEntity> retrieveBankByBloombCode(String bloombCode)"));
	    	ejbLogger.debug(new StandardLogMessage("Bank bloombCode: "+bloombCode));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getBankByBloombCode");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("bloombcode", bloombCode);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctBankEntity> banks = (List<RctBankEntity>) q.getResultList();
			
	    	return banks;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    @SuppressWarnings("unchecked")
    /*
     * @NamedQuery(name="getBankByName", query="SELECT bank FROM RctBankEntity bank WHERE bank.bankname like :bankname ORDER BY bank.bankname ASC"),
     */
    public List<RctBankEntity> retrieveBankByName(String name) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctBankEntity> retrieveBankByName(String name)"));
	    	ejbLogger.debug(new StandardLogMessage("Bank name: "+name));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getBankByName");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("bankname", name);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			
			List<RctBankEntity> banks = (List<RctBankEntity>) q.getResultList();
			
	    	return banks;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    @SuppressWarnings("unchecked")
    /*
	 * @NamedQuery(name="getBankByStatus", query="SELECT bank FROM RctBankEntity bank WHERE bank.status = :status ORDER BY bank.bankname ASC")
	 */
    public List<RctBankEntity> retrieveBankByStatus(String status) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctBankEntity> retrieveBankByName(String name)"));
	    	ejbLogger.debug(new StandardLogMessage("Bank status: "+status));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getBankByStatus");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("status", status);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			
			List<RctBankEntity> banks = (List<RctBankEntity>) q.getResultList();
			
	    	return banks;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
}
