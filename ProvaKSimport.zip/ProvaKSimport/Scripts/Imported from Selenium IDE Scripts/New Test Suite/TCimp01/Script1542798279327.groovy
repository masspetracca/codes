import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint


import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern

import javax.media.StopAtTimeEvent

import static org.apache.commons.lang3.StringUtils.join


WebUI.openBrowser('')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https:www.katalon.com"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://www.katalon.com/sign-up/")
selenium.type("id=user_login","masspetracca")
selenium.type("id=user_email","masspetracca@gmail.com")
selenium.type("id=user_pass","gratis63")
selenium.click("id=signup-btn")
selenium.close(FailureHandling.STOP_ON_FAILURE)
//waitForPageToLoad("30")
/*
WebUI.openBrowser('')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://10.0.10.230:10084/PampWeb/index.html"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://10.0.10.230:10084/PampWeb/index.html")
selenium.click("id=Username")
selenium.click("id=Password")
selenium.click("id=submitLabel")
selenium.click("id=input_Password_submitLabel")
*/
/*
selenium.click("id=sidenavtree_valueCell17")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Back test date'])[1]/following::div[6]")
selenium.click("id=isc_37")
selenium.click("id=isc_4M")
selenium.type("id=isc_4M", "MEDIO")
selenium.click("name=isc_5Zicon")
selenium.click("id=isc_4M")
selenium.type("id=isc_4M", "ME")
selenium.click("id=isc_4P")
selenium.click("name=isc_5Zicon")
selenium.click("id=isc_4P")
selenium.type("id=isc_4P", "BANCA")
selenium.sendKeys("id=isc_4P", "${KEY_ENTER}")
selenium.click("id=isc_52")
selenium.click("id=isc_7Y")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Select Date Range'])[2]/following::img[3]")
selenium.click("id=isc_8H")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Nov'])[1]/following::td[4]")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Clear'])[1]/following::td[1]")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='True'])[5]/following::td[10]")
selenium.click("id=isc_5K")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Client'])[3]/following::div[1]")
selenium.click("name=isc_5Zicon")
selenium.click("id=isc_5Q")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='True'])[4]/following::div[1]")
selenium.click("name=isc_5Zicon")
selenium.click("id=isc_5Q")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Sa'])[2]/following::div[6]")
selenium.click("name=isc_5Zicon")
selenium.click("id=isc_5K")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Sa'])[2]/following::div[6]")
selenium.click("name=isc_5Zicon")
selenium.click("id=isc_52")
selenium.click("id=isc_8U")
selenium.click("id=isc_8W")
selenium.click("id=isc_4P")
selenium.type("id=isc_4P", "")
selenium.click("id=isc_4M")
selenium.type("id=isc_4M", "")
selenium.click("name=isc_5Zicon")

selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Internal test environment'])[1]/following::b[1]")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Manage profile'])[1]/following::font[1]")
*/
selenium.close()


