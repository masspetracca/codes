wgxpath - Wicked Good XPath

https://github.com/google/wicked-good-xpath

The source in this directory is from:

https://github.com/google/wicked-good-xpath/tree/423f1b76c626cb4464962e638c27816fc8c2a8d4/src

excluding the *_test* files.
