package it.ccg.ifpejb.smartgwt.server.dmi;



import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;
import it.ccg.ifpejb.smartgwt.server.util.DmiEAOUtil;
import it.ccg.ifpejb.smartgwt.server.util.JpaQuery;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;



/**
 * Session Bean implementation class HisPrDmiCmtEAO
 */
@Stateless
public class HisPrDmiEAO implements HisPrDmiEAOLocal {
	
	@PersistenceContext(name="HisPrEM", unitName="InfoProvidersEjb")
	private EntityManager em;
	
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	
    /**
     * Default constructor. 
     */
    public HisPrDmiEAO() {
    	
    }
    
    
    @Override
	public DSResponse fetchInfoView(DSRequest dsRequest) throws Exception {
		
		JpaQuery jpaQuery = new JpaQuery("SELECT hisPrInfo", "FROM it.ccg.ifpejb.server.bean.entity.HisPrInfoViewEntity hisPrInfo", "", "", "", "ORDER BY hisPrInfo.instrumentId");
		
		
		JpaQuery filteredJpaQuery = DmiEAOUtil.getFilteredQuery(jpaQuery, dsRequest);
		
    	logger.info(new StandardLogMessage("query: " + filteredJpaQuery.toString()));
    	
    	
		return DmiEAOUtil.executeQuery(filteredJpaQuery, dsRequest, this.em);
	}
	
	
	@Override
	public DSResponse fetchInstrHis(DSRequest dsRequest) throws Exception {
		
		// This query is ever executed with condition "WHERE hisPr.id.instrumentId = instrId".
		// The instrId value is from client criteria.
		JpaQuery jpaQuery = new JpaQuery("SELECT new HisPrInstrHis(hisPr.id.priceDate, hisPr.closingPrice)", "FROM it.ccg.ifpejb.server.bean.entity.HisPrEntity hisPr", "", "", "", "ORDER BY hisPr.id.priceDate DESC");
		
		
		JpaQuery filteredJpaQuery = DmiEAOUtil.getFilteredQuery(jpaQuery, dsRequest);
		
    	logger.info(new StandardLogMessage("query: " + filteredJpaQuery.toString()));
    	
    	
		return DmiEAOUtil.executeQuery(filteredJpaQuery, dsRequest, this.em);
	}
	
	
	
	
	
	// *** OLD ************************************************************************
	// ********************************************************************************

	/*@SuppressWarnings("unchecked")
	@Override
	public DSResponse fetchInfo(DSRequest dsRequest) throws Exception {
		
		logger.debug(new StandardLogMessage("Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		
		String selectClause = "SELECT new HisPrInfo(hisPr.id.instrumentId, instr.instrumentName, MIN(hisPr.id.priceDate), MAX(hisPr.id.priceDate), COUNT(hisPr.id.priceDate))";
		String fromClause = "FROM HistoricalPricesEntity hisPr JOIN hisPr.instr instr";
		String whereClause = "WHERE 1=1";
		String groupByClause = "GROUP BY hisPr.id.instrumentId, instr.instrumentName";
		String havingClause = "HAVING 1=1";
		String orderByClause = new String();
		
		
		Map<String, Object> jpaQueryParams = new HashMap<String, Object>();
		
		// Where/Having ******************************************
    	AdvancedCriteria advancedCriteria = dsRequest.getAdvancedCriteria();
		Map<String, Object> criteriaStructure = advancedCriteria.getCriteriaAsMap();
		List<Map<String, Object>> criteriaList = (List<Map<String, Object>>)criteriaStructure.get("criteria");

		if((criteriaList.size() > 0) && (criteriaList.get(0).get("criteria") !=  null)) {
			criteriaList = (List<Map<String, Object>>)criteriaList.get(0).get("criteria");
		}
		
		logger.debug(new StandardLogMessage("criteriaList: " + criteriaList));
			
		for(Map<String, Object> criteria : criteriaList) {
    		
    		if(criteria.isEmpty()) {
    			break;
    		}
    		
    		
    		// fieldName, operator, value
    		
    		String fieldName = (String)criteria.get("fieldName");
    		String operator = (String)criteria.get("operator");
    		
    		
    		if(fieldName.equalsIgnoreCase("instrumentId")) {
    			
    			whereClause += " AND " + this.criteriaJpqlOperatorConverter.convertToJPQL("hisPr.id.instrumentId", operator, (String)criteria.get("value"));
    		}
    		else if(fieldName.equalsIgnoreCase("instrumentName")) {
    			
    			whereClause += " AND " + this.criteriaJpqlOperatorConverter.convertToJPQL("instr.instrumentName", operator, (String)criteria.get("value"));
    		}
    		else if(fieldName.equalsIgnoreCase("minPriceDate")) {
    			
    			Date date = (Date)criteria.get("value");
    			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    			String value = sdf.format(date);
    			
    			havingClause += " AND " + this.criteriaJpqlOperatorConverter.convertToJPQL("MIN(hisPr.id.priceDate)", operator, value);
    		}
			else if(fieldName.equalsIgnoreCase("maxPriceDate")) {
				
				Date date = (Date)criteria.get("value");
    			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    			String value = sdf.format(date);
				
				havingClause += " AND " + this.criteriaJpqlOperatorConverter.convertToJPQL("MAX(hisPr.id.priceDate)", operator, value);
			}
			else if(fieldName.equalsIgnoreCase("count")) {
				
				havingClause += " AND " + this.criteriaJpqlOperatorConverter.convertToJPQL("COUNT(hisPr.id.priceDate)", operator, (String)criteria.get("value"));
			}
			else {
				
			}
    		
    	}
		// Where/Having  ******************************************
    	
    	// Order by ****************************************
    	List<String> sortByFieldsList = dsRequest.getSortByFields();
    	
    	if(sortByFieldsList.size() > 0) {
    		orderByClause = "ORDER BY" + " ";
    		
    		for(String sortByField : sortByFieldsList) {
        		if(sortByField.charAt(0) == '-') {
        			String fieldName = sortByField.substring(1);
        			
        			if(fieldName.equalsIgnoreCase("instrumentId")) {
        				orderByClause += "hisPr.id.instrumentId desc" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("instrumentName")) {
            			orderByClause += "instr.instrumentName desc" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("minPriceDate")) {
            			orderByClause += "MIN(hisPr.id.priceDate) desc" + ",";
            		}
        			else if(fieldName.equalsIgnoreCase("maxPriceDate")) {
        				orderByClause += "MAX(hisPr.id.priceDate) desc" + ",";
        			}
        			else if(fieldName.equalsIgnoreCase("count")) {
        				orderByClause += "COUNT(hisPr.id.priceDate) desc" + ",";
        			}
        			else {
        				
        			}
        			
        		}
        		else {
        			String fieldName = sortByField;
        			
        			if(fieldName.equalsIgnoreCase("instrumentId")) {
        				orderByClause += "hisPr.id.instrumentId" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("instrumentName")) {
            			orderByClause += "instr.instrumentName" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("minPriceDate")) {
            			orderByClause += "MIN(hisPr.id.priceDate)" + ",";
            		}
        			else if(fieldName.equalsIgnoreCase("maxPriceDate")) {
        				orderByClause += "MAX(hisPr.id.priceDate)" + ",";
        			}
        			else if(fieldName.equalsIgnoreCase("count")) {
        				orderByClause += "COUNT(hisPr.id.priceDate)" + ",";
        			}
        			else {
        				
        			}
        		}
        		
        	}
        	
        	orderByClause = orderByClause.substring(0, orderByClause.length() - 1);
    	}
    	else {
    		orderByClause = "ORDER BY hisPr.id.instrumentId";
    	}
    	// Order by ****************************************
    	
    	
    	
    	JpaQuery jpaQuery = new JpaQuery(selectClause, fromClause, whereClause, groupByClause, havingClause, orderByClause);


    	logger.debug(new StandardLogMessage("jpaQueryString: " + jpaQuery.toString()));
    	
    	
		return executeQuery(jpaQuery, jpaQueryParams, dsRequest);
	}
	*/
	
	/*@SuppressWarnings("unchecked")
	@Override
	public DSResponse fetchInfoView(DSRequest dsRequest) throws Exception {
		
		logger.debug(new StandardLogMessage("Operation type: " + dsRequest.getOperationType() + ", Operation: " + dsRequest.getOperationId() + ", DataSource: " + dsRequest.getDataSourceName()));
		
		
		String selectClause = "SELECT hisPrInfo";
		String fromClause = "FROM HisPrInfoViewEntity hisPrInfo";
		String whereClause = "WHERE 1=1";
		String groupByClause = "";
		String havingClause = "";
		String orderByClause = new String();
		
		
		Map<String, Object> jpaQueryParams = new HashMap<String, Object>();
		
		// Where  ******************************************
    	AdvancedCriteria advancedCriteria = dsRequest.getAdvancedCriteria();
		Map<String, Object> criteriaStructure = advancedCriteria.getCriteriaAsMap();
		List<Map<String, Object>> criteriaList = (List<Map<String, Object>>)criteriaStructure.get("criteria");

		if((criteriaList.size() > 0) && (criteriaList.get(0).get("criteria") !=  null)) {
			criteriaList = (List<Map<String, Object>>)criteriaList.get(0).get("criteria");
		}
		
		logger.debug(new StandardLogMessage("criteriaList: " + criteriaList));
			
		for(Map<String, Object> criteria : criteriaList) {
    		
    		if(criteria.isEmpty()) {
    			break;
    		}
    		
    		
    		// fieldName, operator, value
    		
    		String fieldName = (String)criteria.get("fieldName");
    		String operator = (String)criteria.get("operator");
    		
    		
    		if(fieldName.equalsIgnoreCase("instrumentId")) {
    			
    			whereClause += " AND " + this.criteriaJpqlOperatorConverter.convertToJPQL("hisPrInfo.instrumentId", operator, (String)criteria.get("value"));
    		}
    		else if(fieldName.equalsIgnoreCase("instrumentName")) {
    			
    			whereClause += " AND " + this.criteriaJpqlOperatorConverter.convertToJPQL("hisPrInfo.instrumentName", operator, (String)criteria.get("value"));
    		}
    		else if(fieldName.equalsIgnoreCase("minPriceDate")) {
    			
    			Date date = (Date)criteria.get("value");
    			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    			String value = sdf.format(date);
    			
    			whereClause += " AND " + this.criteriaJpqlOperatorConverter.convertToJPQL("hisPrInfo.minPriceDate)", operator, value);
    		}
			else if(fieldName.equalsIgnoreCase("maxPriceDate")) {
				
				Date date = (Date)criteria.get("value");
    			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    			String value = sdf.format(date);
				
    			whereClause += " AND " + this.criteriaJpqlOperatorConverter.convertToJPQL("hisPrInfo.maxPriceDate)", operator, value);
			}
			else if(fieldName.equalsIgnoreCase("count")) {
				
				whereClause += " AND " + this.criteriaJpqlOperatorConverter.convertToJPQL("hisPrInfo.count", operator, (String)criteria.get("value"));
			}
			else {
				
			}
    		
    	}
		// Where  ******************************************
    	
    	// Order by ****************************************
    	List<String> sortByFieldsList = dsRequest.getSortByFields();
    	
    	if(sortByFieldsList.size() > 0) {
    		orderByClause = "ORDER BY" + " ";
    		
    		for(String sortByField : sortByFieldsList) {
        		if(sortByField.charAt(0) == '-') {
        			String fieldName = sortByField.substring(1);
        			
        			if(fieldName.equalsIgnoreCase("instrumentId")) {
        				orderByClause += "hisPrInfo.instrumentId desc" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("instrumentName")) {
            			orderByClause += "hisPrInfo.instrumentName desc" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("minPriceDate")) {
            			orderByClause += "hisPrInfo.minPriceDate desc" + ",";
            		}
        			else if(fieldName.equalsIgnoreCase("maxPriceDate")) {
        				orderByClause += "hisPrInfo.maxPriceDate desc" + ",";
        			}
        			else if(fieldName.equalsIgnoreCase("count")) {
        				orderByClause += "hisPrInfo.count desc" + ",";
        			}
        			else {
        				
        			}
        			
        		}
        		else {
        			String fieldName = sortByField;
        			
        			if(fieldName.equalsIgnoreCase("instrumentId")) {
        				orderByClause += "hisPrInfo.instrumentId" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("instrumentName")) {
            			orderByClause += "hisPrInfo.instrumentName" + ",";
            		}
            		else if(fieldName.equalsIgnoreCase("minPriceDate")) {
            			orderByClause += "hisPrInfo.minPriceDate" + ",";
            		}
        			else if(fieldName.equalsIgnoreCase("maxPriceDate")) {
        				orderByClause += "hisPrInfo.maxPriceDate" + ",";
        			}
        			else if(fieldName.equalsIgnoreCase("count")) {
        				orderByClause += "hisPrInfo.count" + ",";
        			}
        			else {
        				
        			}
        		}
        		
        	}
        	
        	orderByClause = orderByClause.substring(0, orderByClause.length() - 1);
    	}
    	else {
    		orderByClause = "ORDER BY hisPrInfo.instrumentId";
    	}
    	// Order by ****************************************
    	
    	
    	
    	JpaQuery jpaQuery = new JpaQuery(selectClause, fromClause, whereClause, groupByClause, havingClause, orderByClause);


    	logger.debug(new StandardLogMessage("jpaQueryString: " + jpaQuery.toString()));
    	
    	
		return executeQuery(jpaQuery, jpaQueryParams, dsRequest);
	}*/
	
	
	
}
