package it.ccg.ifpejb.smartgwt.server.dmi;

import it.ccg.ifpejb.server.system.LocalBeanLookup;

public class HisPrDmiEAOFactory {
	
	
	public HisPrDmiEAOFactory() {
		
	}
	
	
	
	public HisPrDmiEAOLocal create() throws Exception {

		HisPrDmiEAOLocal hisPrDmiEAOLocal = (HisPrDmiEAOLocal)LocalBeanLookup.lookup(HisPrDmiEAOLocal.class.getName());
		
		return hisPrDmiEAOLocal;
	}

}
