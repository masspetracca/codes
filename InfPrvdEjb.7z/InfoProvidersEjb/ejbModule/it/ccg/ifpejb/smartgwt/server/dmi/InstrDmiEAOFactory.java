package it.ccg.ifpejb.smartgwt.server.dmi;

import it.ccg.ifpejb.server.system.LocalBeanLookup;

public class InstrDmiEAOFactory {
	
	
	public InstrDmiEAOFactory() {
		
	}
	
	
	
	public InstrDmiEAOLocal create() throws Exception {

		InstrDmiEAOLocal instrDmiEAOLocal = (InstrDmiEAOLocal)LocalBeanLookup.lookup(InstrDmiEAOLocal.class.getName());
		
		return instrDmiEAOLocal;
	}

}
