package it.ccg.ifpejb.smartgwt.server.dmi;


import javax.ejb.Local;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;

@Local
public interface HisPrDmiEAOLocal {
	
	//public DSResponse fetchInfo(DSRequest dsRequest) throws Exception;
	/*public DSResponse fetchInfoTest1(DSRequest dsRequest) throws Exception;
	public DSResponse fetchInfoTest2(DSRequest dsRequest) throws Exception;
	public DSResponse fetchInfoTest3(DSRequest dsRequest) throws Exception;*/
	public DSResponse fetchInfoView(DSRequest dsRequest) throws Exception;
	
	public DSResponse fetchInstrHis(DSRequest dsRequest) throws Exception;
	
}
