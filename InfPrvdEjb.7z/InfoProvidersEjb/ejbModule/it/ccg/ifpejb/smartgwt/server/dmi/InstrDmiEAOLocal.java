package it.ccg.ifpejb.smartgwt.server.dmi;

import it.ccg.ifpejb.server.bean.entity.InstrEntity;

import javax.ejb.Local;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;


@Local
public interface InstrDmiEAOLocal {
	
	public DSResponse fetch(DSRequest dsRequest) throws Exception;
	public InstrEntity add(DSRequest dsRequest) throws Exception;
	public InstrEntity update(DSRequest dsRequest) throws Exception;
	public InstrEntity remove(DSRequest dsRequest) throws Exception;

}
