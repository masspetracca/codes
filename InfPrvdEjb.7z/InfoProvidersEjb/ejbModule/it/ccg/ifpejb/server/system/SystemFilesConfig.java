package it.ccg.ifpejb.server.system;

import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

public class SystemFilesConfig {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	public static void createSystemFiles() throws Exception {
		
		Properties properties = SystemProperties.getProperties();
		
		String LOG_DIR_ABSOLUTE_PATH = properties.getProperty("user.install.root") + 
									   properties.getProperty("ifp_log_dir_relative_path");
		
		String TEMP_DIR_ABSOLUTE_PATH = properties.getProperty("user.install.root") + 
		   						 		properties.getProperty("ifp_temp_dir_relative_path");
		
		String UPLOAD_DIR_NAME = properties.getProperty("ifp_upload_dir_name");
		
		String INTERNAL_DIR_NAME = properties.getProperty("ifp_internal_dir_name");
    	
		
		List<String> dirList = new ArrayList<String>();
		dirList.add(LOG_DIR_ABSOLUTE_PATH);
		dirList.add(TEMP_DIR_ABSOLUTE_PATH);
		dirList.add(TEMP_DIR_ABSOLUTE_PATH + UPLOAD_DIR_NAME);
		dirList.add(TEMP_DIR_ABSOLUTE_PATH + INTERNAL_DIR_NAME);
		
		
		for(String dirAbsPath : dirList) {
			
			File tempFile = new File(dirAbsPath);
			
			if(!tempFile.exists()) {
				
				tempFile.mkdir();
				
				
				logger.info(new StandardLogMessage("File (folder) \'" + tempFile.getAbsolutePath() + "\' successfully created."));
			}
			else {
				
				//logger.debug(new StandardLogMessage("File (folder) \'" + tempFile.getAbsolutePath() + "\' already exists."));
			}
			
		}
		
		
		logger.info(new StandardLogMessage("InfoProviders system files successfully created: " + dirList));
    }

}
