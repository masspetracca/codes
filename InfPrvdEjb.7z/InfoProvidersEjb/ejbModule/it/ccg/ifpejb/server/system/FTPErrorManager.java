package it.ccg.ifpejb.server.system;


import java.util.HashMap;
import java.util.Map;

public class FTPErrorManager {
	
	
	private static Map<String, Integer> ticketMap = new HashMap<String, Integer>();
	
	
	public static void registerTicket(String jobName) throws Exception {
		
		// Se il ticket esiste incrementa il contatore (caso in cui il ticket � stato gi� aperto)
		if(ticketMap.get(jobName) != null) {
			
			ticketMap.put(jobName, (ticketMap.get(jobName) + 1));
		}
		// altrimenti apri un nuovo ticket (primo errore FTP sul job)
		else {
			
			ticketMap.put(jobName, 1);
		}
		
		//System.out.println("WARN - ticket: " + jobName + ", counter: " + ticketMap.get(jobName));
	}
	
	
	public static int getCounter(String jobName) throws Exception {
		
		if(ticketMap.get(jobName) == null) {
			
			throw new Exception("Ticket \'" + jobName + "\' not found.");
		}
		
		return ticketMap.get(jobName);
		
	}
	
	
	public static void destroyTicket(String jobName) throws Exception {
		
		ticketMap.remove(jobName);
		
	}
	

}
