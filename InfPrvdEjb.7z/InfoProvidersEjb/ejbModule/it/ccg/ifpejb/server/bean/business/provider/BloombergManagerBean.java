package it.ccg.ifpejb.server.bean.business.provider;

import it.ccg.ifpejb.server.bean.eao.InstrEAOLocal;
import it.ccg.ifpejb.server.bean.entity.InstrEntity;
import it.ccg.ifpejb.server.exception.ExceptionUtil;
import it.ccg.ifpejb.server.file.factory.BBGRequestType;
import it.ccg.ifpejb.server.file.factory.BloombergRequestFactory;
import it.ccg.ifpejb.server.file.parser.BloombergRequestParser;
import it.ccg.ifpejb.server.file.template.BloombergRequestTemplate;
import it.ccg.ifpejb.server.ftp.FTPFactory;
import it.ccg.ifpejb.server.ftp.FTPServiceInterface;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;
import it.ccg.ifpejb.server.providerengine.ProviderEngine;
import it.ccg.ifpejb.server.security.SecurityEjb;
import it.ccg.ifpejb.server.system.SystemProperties;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BloombergManagerBean
 */
@Stateless
public class BloombergManagerBean implements BloombergManagerBeanLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	private static final Logger monitorLogger = LoggerFactory.getLogger(LoggerFactory.MONITOR_LOGGER);
	
	private FTPServiceInterface ftpServiceInterface;
	
	
	@EJB
	private InstrEAOLocal instrumentsEAOLocal;
	
	@EJB
	private BaseBeanLocal baseBeanLocal;
	
	private static Properties properties;
	
	private static String TEMP_DIR_ABSOLUTE_PATH;
	
	private static String PROVIDER_NAME;
	private static String FLOW_CURR_NAME;
	private static String FLOW_NIR_NAME;
	private static String REMOTE_CURR_REQUEST_FILE_NAME;
	private static String UPLOADING_CURR_REQUEST_FILE_NAME;
	private static String REMOTE_NIR_REQUEST_FILE_NAME;
	private static String UPLOADING_NIR_REQUEST_FILE_NAME;
	
	private static String PATH_SEPARATOR;
	

    /**
     * Default constructor. 
     */
    public BloombergManagerBean() throws Exception {
		
    	try {
    		
    		properties = SystemProperties.getProperties();
        	
        	TEMP_DIR_ABSOLUTE_PATH = properties.getProperty("user.install.root") +
    							  	 properties.getProperty("ifp_temp_dir_relative_path");
        	
        	PATH_SEPARATOR = properties.getProperty("file.separator");
        	
        	// provider engine IDs from properties file
        	PROVIDER_NAME = properties.getProperty("provider.bloomberg.name");
        	
    	}
    	catch(Exception e) {
    		
    		logger.warn(new StandardLogMessage("Exception into bean constructor. Exception: " + e));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
    }
    
    

	@Override
	public void checkCurrAlignment() throws Exception {
		
		try {
			
        	FLOW_CURR_NAME = properties.getProperty("provider.bloomberg.flow.curr.name");
        	UPLOADING_CURR_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_CURR_NAME).getRequestFileName();
        	REMOTE_CURR_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_CURR_NAME).getRequestFileName() + ".copied";
        	
			
			logger.info(new StandardLogMessage("Bloomberg CURR request alignment check started."));
			
			
			boolean aligned = true;
			
			// computation START
			
			// local list
			List<InstrEntity> enabledInstrList = this.instrumentsEAOLocal.fetchEnabled("C", "Bloomberg");
			List<InstrEntity> oneShotInstrList = this.instrumentsEAOLocal.fetchOneShot("C", "Bloomberg");
			List<InstrEntity> tempList = new ArrayList<InstrEntity>();
			tempList.addAll(enabledInstrList);
			tempList.addAll(oneShotInstrList);
			List<String> localList = new ArrayList<String>();
			for(InstrEntity entity : tempList) {
				
				localList.add(entity.getBloombergCode());
			}
			
			// remote list
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.BLOOMBERG_SERVICE);
			
			// create temporary folder and files to work
			String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + REMOTE_CURR_REQUEST_FILE_NAME;
			File file = new File(tempFileAbsPath);
			//file.createNewFile();
			
			this.ftpServiceInterface.downloadRequestFile(REMOTE_CURR_REQUEST_FILE_NAME, file);
			
			BloombergRequestParser bloombergRequestParser = new BloombergRequestParser();
			BloombergRequestTemplate bloombergRequestTemplate = bloombergRequestParser.parse(file);
			List<String> remoteSecuritiesList = bloombergRequestTemplate.getSecurities();
			
			
			// confronta
			
			// 
			for(String bbgCode : localList) {
				if(!remoteSecuritiesList.contains(bbgCode)) {
					
					aligned = false;
					
					logger.warn(new StandardLogMessage("Bloomberg code \'" + bbgCode + "\' enabled in local environment but not present in remote intrument list."));
				}
			}
			
			//
			for(String bbgCode : remoteSecuritiesList) {
				if(!localList.contains(bbgCode)) {
					
					aligned = false;
					
					logger.warn(new StandardLogMessage("Bloomberg code \'" + bbgCode + "\' present in remote intrument list but disabled in local environment."));
				}
			}
			
			
			// computation END
			
			if(aligned) {
				logger.info(new StandardLogMessage("Bloomberg CURR local and remote instrument lists aligned."));
				
				monitorLogger.info(new StandardLogMessage("Bloomberg CURR local and remote instrument lists aligned."));
			}
			else {
				logger.warn(new StandardLogMessage("Bloomberg CURR local and remote instrument lists not aligned."));
				
				monitorLogger.warn(new StandardLogMessage("Bloomberg CURR local and remote instrument lists not aligned. Read logs for details."));
			}
			
			
			// delete tempWorkingFolder
			//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
		}
		catch(Exception e) {
			// monitor error
			monitorLogger.error(new StandardLogMessage("Bloomberg CURR request alignment check failed."));
			// default logger
			logger.error(new StandardLogMessage("Bloomberg CURR request alignment check failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Bloomberg CURR request alignment check failed.");
		}
		
	}
	
	@Override
	public void alignCurrRequest() throws Exception {
		
		try {
			
			FLOW_CURR_NAME = properties.getProperty("provider.bloomberg.flow.curr.name");
        	UPLOADING_CURR_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_CURR_NAME).getRequestFileName();
        	REMOTE_CURR_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_CURR_NAME).getRequestFileName() + ".copied";
        	
			
			logger.info(new StandardLogMessage("Bloomberg CURR request alignment started."));
			
			
			List<InstrEntity> enabledInstrList = this.instrumentsEAOLocal.fetchEnabled("C","Bloomberg");
			List<InstrEntity> oneShotInstrList = this.instrumentsEAOLocal.fetchOneShot("C","Bloomberg");
			List<InstrEntity> instrList = new ArrayList<InstrEntity>();
			instrList.addAll(enabledInstrList);
			instrList.addAll(oneShotInstrList);
			
			
			logger.info(new StandardLogMessage("Instrument list size: " + instrList.size()));
			logger.info(new StandardLogMessage("Instrument list details: " + instrList));
			
			
			// create temporary folder and files to work
			String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + UPLOADING_CURR_REQUEST_FILE_NAME;
			File fileToSaveInto = new File(tempFileAbsPath);
			fileToSaveInto.createNewFile();
			
			BloombergRequestFactory bloombergRequestFactory = new BloombergRequestFactory();
			bloombergRequestFactory.createRequestFile(BBGRequestType.CURR_REQUEST, fileToSaveInto, instrList);
			
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.BLOOMBERG_SERVICE);
			
			this.ftpServiceInterface.uploadRequestFile(UPLOADING_CURR_REQUEST_FILE_NAME, fileToSaveInto);
			
			
			monitorLogger.info(new StandardLogMessage("Bloomberg CURR request successfully aligned."));
			logger.info(new StandardLogMessage("Bloomberg CURR request successfully aligned."));
			
			
			// delete tempWorkingFolder
			//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
		}
		catch(Exception e) {
			// monitor error
			monitorLogger.error(new StandardLogMessage("Bloomberg CURR request alignment failed."));
			// default logger
			logger.error(new StandardLogMessage("Bloomberg CURR request alignment failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Bloomberg CURR request alignment failed.");
		}
		
	}
	
	
	@Override
	public void checkNirAlignment() throws Exception {
		
		try {
			
			FLOW_NIR_NAME = properties.getProperty("provider.bloomberg.flow.nir.name");
        	UPLOADING_NIR_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_NIR_NAME).getRequestFileName();
        	REMOTE_NIR_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_NIR_NAME).getRequestFileName() + ".copied";
    		
			
			logger.info(new StandardLogMessage("Bloomberg NIR request alignment check started."));
			
			
			boolean aligned = true;
			
			// computation START
			
			// local list
			List<InstrEntity> enabledInstrList = this.instrumentsEAOLocal.fetchEnabled("IRNODE", "Bloomberg");
			List<InstrEntity> oneShotInstrList = this.instrumentsEAOLocal.fetchOneShot("IRNODE", "Bloomberg");
			List<InstrEntity> tempList = new ArrayList<InstrEntity>();
			tempList.addAll(enabledInstrList);
			tempList.addAll(oneShotInstrList);
			List<String> localList = new ArrayList<String>();
			for(InstrEntity entity : tempList) {
				
				localList.add(entity.getBloombergCode());
			}
			
			// remote list
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.BLOOMBERG_SERVICE);
			
			// create temporary folder and files to work
			String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + REMOTE_NIR_REQUEST_FILE_NAME;
			File file = new File(tempFileAbsPath);
			file.createNewFile();
			
			this.ftpServiceInterface.downloadRequestFile(REMOTE_NIR_REQUEST_FILE_NAME, file);
			
			BloombergRequestParser bloombergRequestParser = new BloombergRequestParser();
			BloombergRequestTemplate bloombergRequestTemplate = bloombergRequestParser.parse(file);
			List<String> remoteSecuritiesList = bloombergRequestTemplate.getSecurities();
			
			
			// confronta
			
			// 
			for(String bbgCode : localList) {
				if(!remoteSecuritiesList.contains(bbgCode)) {
					
					aligned = false;
					
					logger.warn(new StandardLogMessage("Bloomberg code \'" + bbgCode + "\' enabled in local environment but not present in remote intrument list."));
				}
			}
			
			//
			for(String bbgCode : remoteSecuritiesList) {
				if(!localList.contains(bbgCode)) {
					
					aligned = false;
					
					logger.warn(new StandardLogMessage("Bloomberg code \'" + bbgCode + "\' present in remote intrument list but disabled in local environment."));
				}
			}
			
			
			// computation END
			
			if(aligned) {
				logger.info(new StandardLogMessage("Bloomberg NIR local and remote instrument lists aligned."));
				
				monitorLogger.info(new StandardLogMessage("Bloomberg NIR local and remote instrument lists aligned."));
			}
			else {
				logger.warn(new StandardLogMessage("Bloomberg NIR local and remote instrument lists not aligned."));
				
				monitorLogger.warn(new StandardLogMessage("Bloomberg NIR local and remote instrument lists not aligned. Read logs for details."));
			}
			
			
			// delete tempWorkingFolder
			//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
		}
		catch(Exception e) {
			// monitor error
			monitorLogger.error(new StandardLogMessage("Bloomberg NIR request alignment check failed."));
			// default logger
			logger.error(new StandardLogMessage("Bloomberg NIR request alignment check failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Bloomberg NIR request alignment check failed.");
		}
		
	}
	
	

	
	
	
	@Override
	public void alignNirRequest() throws Exception {
		
		try {
			
			FLOW_NIR_NAME = properties.getProperty("provider.bloomberg.flow.nir.name");
        	UPLOADING_NIR_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_NIR_NAME).getRequestFileName();
        	REMOTE_NIR_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_NIR_NAME).getRequestFileName() + ".copied";
    		
        	
			logger.info(new StandardLogMessage("Bloomberg NIR request alignment started."));
			
			
			List<InstrEntity> enabledInstrList = this.instrumentsEAOLocal.fetchEnabled("IRNODE","Bloomberg");
			List<InstrEntity> oneShotInstrList = this.instrumentsEAOLocal.fetchOneShot("IRNODE","Bloomberg");
			List<InstrEntity> instrList = new ArrayList<InstrEntity>();
			instrList.addAll(enabledInstrList);
			instrList.addAll(oneShotInstrList);
			
			
			logger.info(new StandardLogMessage("Instrument list size: " + instrList.size()));
			logger.info(new StandardLogMessage("Instrument list details: " + instrList));
			
			
			// create temporary folder and files to work
			String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + UPLOADING_NIR_REQUEST_FILE_NAME;
			File fileToSaveInto = new File(tempFileAbsPath);
			fileToSaveInto.createNewFile();
			
			BloombergRequestFactory bloombergRequestFactory = new BloombergRequestFactory();
			bloombergRequestFactory.createRequestFile(BBGRequestType.NIR_REQUEST, fileToSaveInto, instrList);
			
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.BLOOMBERG_SERVICE);
			
			this.ftpServiceInterface.uploadRequestFile(UPLOADING_NIR_REQUEST_FILE_NAME, fileToSaveInto);
			
			
			monitorLogger.info(new StandardLogMessage("Bloomberg NIR request successfully aligned."));
			logger.info(new StandardLogMessage("Bloomberg NIR request successfully aligned."));
			
			
			// delete tempWorkingFolder
			//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
		}
		catch(Exception e) {
			// monitor error
			monitorLogger.error(new StandardLogMessage("Bloomberg NIR request alignment failed."));
			// default logger
			logger.error(new StandardLogMessage("Bloomberg NIR request alignment failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Bloomberg NIR request alignment failed.");
		}
		
	}
	

}
