package it.ccg.ifpejb.server.bean.eao;


import it.ccg.ifpejb.server.bean.entity.HisPrEntity;
import it.ccg.ifpejb.server.bean.entity.HisPrEntityPK;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;

import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class HistoricalPricesEAO
 */
@SuppressWarnings("unchecked")
@Stateless(mappedName = "HistoricalPricesEAO")
public class HisPrEAO implements HisPrEAOLocal {
	
	@PersistenceContext(unitName="InfoProvidersEjb", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Resource
	private SessionContext sessionContext;
	
	
	private String tableName = ((Table)(HisPrEntity.class.getAnnotation(Table.class))).name();
	
    /**
     * Default constructor. 
     */
    public HisPrEAO() throws Exception {
    	
    }

	@Override
	public List<HisPrEntity> fetch() throws Exception {
		
		Query query = em.createNamedQuery("getAllHistoricalPrices");
		
		
		return (List<HisPrEntity>)query.getResultList();
	}

	@Override
	public HisPrEntity findByPrimaryKey(HisPrEntityPK pK) throws Exception {
		
		return (HisPrEntity)em.find(HisPrEntity.class, pK);
	}
	
	
	@Override
	public List<HisPrEntity> fetchLastDateHisPr(List<Integer> instrIDs) throws Exception {
		
		Query query = em.createNamedQuery("fetchLastDateHisPr");
		query.setParameter("instrIDsList", instrIDs);
		
		
		return (List<HisPrEntity>)query.getResultList();
	}
	

	@Override
	public int getInstrMinPriceDate(int instrId) throws Exception {
		
		Query query = em.createNamedQuery("getInstrMinDate");
		query.setParameter("instrId", instrId);
		
		
		return (Integer)query.getSingleResult();
	}
	
	
	@Override
	public void add(HisPrEntity hpe) throws Exception {
		
		// set current user
		hpe.setUpdatingUser(this.sessionContext.getCallerPrincipal().getName());
		
		em.persist(hpe);
		
		logger.info(new StandardLogMessage("Persisted data into \'" + this.tableName + "\'. " + hpe));
		
		
		// refresh materialized view
		Query query = em.createNamedQuery("refreshHisPrInfoView");
		query.executeUpdate();
		
		logger.info(new StandardLogMessage("INFOP.IFPMHISPR successfully refreshed."));
		
	}

	
	@Override
	public void update(HisPrEntity hpe) throws Exception {
		
		throw new Exception();
	}

	@Override
	public void remove(HisPrEntity hpe) throws Exception {
		
		throw new Exception();
	}
	
	
	
}
