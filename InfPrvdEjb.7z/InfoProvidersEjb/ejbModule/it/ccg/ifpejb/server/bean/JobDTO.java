package it.ccg.ifpejb.server.bean;

import java.io.Serializable;

public class JobDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5134058302118744558L;
	
	
	private String name;
	private String methodName;
	private Class<?> methodClass;
	private String description;
	
	
	public JobDTO(String name, String methodName, Class<?> methodClass, String description) {
		
		this.name = name;
		this.methodName = methodName;
		this.methodClass = methodClass;
		this.description = description;
	}
	
	
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getMethodName() {
		return methodName;
	}
	
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	
	public Class<?> getMethodClass() {
		return methodClass;
	}
	
	public void setMethodClass(Class<?> methodClass) {
		this.methodClass = methodClass;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
	@Override
	public String toString() {
		
		return "[name: " + this.name + 
		 	  ", methodName: " + this.methodName + 
		 	  ", methodClass: " + this.methodClass +
		 	  ", description: " + this.description +
		 	  "]";
	}
	
	
	
}
