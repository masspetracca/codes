package it.ccg.ifpejb.server.bean.eao;

import it.ccg.ifpejb.server.bean.entity.FTPFileEntity;

import java.util.List;

import javax.ejb.Local;

@Local
public interface FTPFileEAOLocal {

	public List<FTPFileEntity> fetch() throws Exception;
	public FTPFileEntity findByPrimaryKey(int fileId) throws Exception;
	public FTPFileEntity findByName(String fileName) throws Exception;
	public FTPFileEntity add(FTPFileEntity fileEntity) throws Exception;
	public void update(FTPFileEntity fileEntity) throws Exception;
	public void remove(FTPFileEntity fileEntity) throws Exception;
	
}
