package it.ccg.ifpejb.server.bean.eao;


import it.ccg.ifpejb.server.bean.entity.InstrEntity;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;

import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class InstrumentsEAO
 */
@SuppressWarnings("unchecked")
@Stateless(mappedName = "InstrumentsEAO")
public class InstrEAO implements InstrEAOLocal {

	@PersistenceContext(unitName = "InfoProvidersEjb", type = PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Resource
	private SessionContext sessionContext;
	
	private String tableName = ((Table)(InstrEntity.class.getAnnotation(Table.class))).name();

	/**
	 * Default constructor.
	 */
	public InstrEAO() throws Exception {
		
	}

	@Override
	public List<InstrEntity> fetch() throws Exception {
		
		Query query = this.em.createNamedQuery("fetchAllInstruments");
		List<InstrEntity>instrumentsList = (List<InstrEntity>)query.getResultList();
		
		return instrumentsList;
	}
	

	@Override
	public List<InstrEntity> fetchEnabled(String instTypy, String provider) throws Exception {
		
		Query query = this.em.createNamedQuery("fetchEnabledInstruments");
		query.setParameter("instrType", instTypy);
		query.setParameter("provider", provider);
		List<InstrEntity>instrumentsList = (List<InstrEntity>)query.getResultList();
		
		return instrumentsList;
	}
	
	@Override
	public List<InstrEntity> fetchOneShot(String instTypy, String provider) throws Exception {
		
		Query query = this.em.createNamedQuery("fetchOneShotInstruments");
		query.setParameter("instrType", instTypy);
		query.setParameter("provider", provider);
		List<InstrEntity>instrumentsList = (List<InstrEntity>)query.getResultList();
		
		return instrumentsList;
	}
	
	

	@Override
	public InstrEntity findByPrimaryKey(int instrumentID) throws Exception {
		
		return (InstrEntity)this.em.find(InstrEntity.class, instrumentID);
	}
	
	
	@Override
	public InstrEntity findByCode(String code) throws Exception {
		
		Query query = this.em.createNamedQuery("getInstrumentByCode");
		query.setParameter("code", code);
		
		InstrEntity instrEntity = null;
		List<InstrEntity> list = (List<InstrEntity>)query.getResultList();
		if(list.size() != 0) {
			instrEntity = list.get(0);
		}
		
		
		return instrEntity;
	}
	
	@Override
	public InstrEntity findByBloombergCode(String bbgCode) throws Exception {
		
		Query query = this.em.createNamedQuery("getInstrumentByBloombergCode");
		query.setParameter("bbgCode", bbgCode);
			
		InstrEntity instrEntity = null;
		List<InstrEntity> list = (List<InstrEntity>)query.getResultList();
		if(list.size() != 0) {
			instrEntity = list.get(0);
		}
		
		
		return instrEntity;
	}
	
	@Override
	public InstrEntity findByRICCode(String ricCode) throws Exception {
		
		Query query = this.em.createNamedQuery("getInstrumentByRicCode");
		query.setParameter("ricCode", ricCode);
		
		InstrEntity instrEntity = null;
		List<InstrEntity> list = (List<InstrEntity>)query.getResultList();
		if(list.size() != 0) {
			instrEntity = list.get(0);
		}
		
			
		return instrEntity;
	}
	
	@Override
	public List<InstrEntity> findInstrumentByType(String instrumentType) throws Exception {
		
		Query query = em.createNamedQuery("fetchInstrumentsByType");
		query.setParameter("instrType", instrumentType);
		
		List<InstrEntity>instrumentsList = (List<InstrEntity>)query.getResultList();
		
		return instrumentsList;
	}

	@Override
	public List<InstrEntity> fetchFutures() throws Exception {
		
		Query query = em.createNamedQuery("fetchAllFutures");
		List<InstrEntity>instrumentsList = (List<InstrEntity>)query.getResultList();
		
		return instrumentsList;
	}
	
	

	@Override
	public void add(InstrEntity instrEntity) throws Exception {
		
		// upd info
		instrEntity.setUpdateDate(new Timestamp(System.currentTimeMillis()));
		instrEntity.setUpdateType("C");
		instrEntity.setUpdatingUser(this.sessionContext.getCallerPrincipal().getName());
		
		this.em.persist(instrEntity);
		
		logger.info(new StandardLogMessage("Persisted data into \'" + this.tableName + "\'. " + instrEntity));
	}

	@Override
	public InstrEntity update(InstrEntity ie) throws Exception {
		
		InstrEntity syncEntity = findByPrimaryKey(ie.getInstrumentId());
		
		syncEntity.setBloombergCode(ie.getBloombergCode());
		syncEntity.setClassCode(ie.getClassCode());
		syncEntity.setCurrency(ie.getCurrency());
		syncEntity.setDataType(ie.getDataType());
		syncEntity.setInstrumentName(ie.getInstrumentName());
		syncEntity.setInstrumentSubtype(ie.getInstrumentSubtype());
		syncEntity.setInstrumentType(ie.getInstrumentType());
		syncEntity.setIsinCode(ie.getIsinCode());
		syncEntity.setMarketCode(ie.getMarketCode());
		syncEntity.setNote(ie.getNote());
		syncEntity.setProvider(ie.getProvider());
		syncEntity.setReutersIdentifierCode(ie.getReutersIdentifierCode());
		syncEntity.setSegmentCode(ie.getSegmentCode());
		syncEntity.setStatus(ie.getStatus());
		// upd info
		syncEntity.setUpdateDate(new Timestamp(System.currentTimeMillis()));
		syncEntity.setUpdateType("U");
		syncEntity.setUpdatingUser(this.sessionContext.getCallerPrincipal().getName());
		
		logger.info(new StandardLogMessage("Updated data into \'" + this.tableName + "\'. " + syncEntity));
		
		
		return syncEntity;
	}

	@Override
	public void remove(InstrEntity instrEntity) throws Exception {
		
		InstrEntity temp = findByPrimaryKey(instrEntity.getInstrumentId());
		String tempToString = temp.toString();
		
		em.remove(temp);
		
		logger.info(new StandardLogMessage("Deleted data into \'" + this.tableName + "\'. " + tempToString));
	}
	
	
}
