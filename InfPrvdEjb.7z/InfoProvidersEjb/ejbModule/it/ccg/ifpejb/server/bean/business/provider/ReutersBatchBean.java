package it.ccg.ifpejb.server.bean.business.provider;

import it.ccg.ifpejb.server.bean.eao.FTPFileEAOLocal;
import it.ccg.ifpejb.server.bean.eao.InstrEAOLocal;
import it.ccg.ifpejb.server.bean.entity.HisPrEntity;
import it.ccg.ifpejb.server.bean.entity.HisPrEntityPK;
import it.ccg.ifpejb.server.bean.entity.InstrEntity;
import it.ccg.ifpejb.server.exception.DuplicateKeyException;
import it.ccg.ifpejb.server.exception.ExceptionUtil;
import it.ccg.ifpejb.server.exception.FTPException;
import it.ccg.ifpejb.server.exception.NewDataNotAvailableException;
import it.ccg.ifpejb.server.file.parser.ReutersResponseParser;
import it.ccg.ifpejb.server.file.template.ReutersResponseTemplate;
import it.ccg.ifpejb.server.file.util.ReutersResponseFTPFileComparator;
import it.ccg.ifpejb.server.ftp.FTPFactory;
import it.ccg.ifpejb.server.ftp.FTPServiceInterface;
import it.ccg.ifpejb.server.logengine.LoggerFactory;
import it.ccg.ifpejb.server.logengine.StandardLogMessage;
import it.ccg.ifpejb.server.providerengine.ProviderEngine;
import it.ccg.ifpejb.server.security.SecurityEjb;
import it.ccg.ifpejb.server.system.MailManager;
import it.ccg.ifpejb.server.system.SystemProperties;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ReutersBatchBean
 */
@Stateless
public class ReutersBatchBean implements ReutersBatchBeanLocal {
	
	private static Properties properties;
	
	private static String TEMP_DIR_ABSOLUTE_PATH;
	
	private static String PROVIDER_NAME;
	private static String FLOW_NIR_NAME;
	private static String FLOW_FCP_NAME;
	private static String FLOW_COLL_NAME;
	private static String NIR_RESPONSE_FILE_NAME;
	private static String FCP_RESPONSE_FILE_NAME;
	private static String COLL_RESPONSE_FILE_NAME;
	
	private static String PATH_SEPARATOR;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	private static final Logger monitorLogger = LoggerFactory.getLogger(LoggerFactory.MONITOR_LOGGER);
	
	
	private FTPServiceInterface ftpServiceInterface;
	
	
	@EJB
	private InstrEAOLocal instrEAOLocal;
	
	@EJB
	private FTPFileEAOLocal ftpFileEAOLocal;
	
	@EJB
	private ReutersManagerBeanLocal reutersManagerBeanLocal;
	
	@EJB
	private BaseBeanLocal baseBeanLocal;
	
	

    /**
     * Default constructor. 
     */
    public ReutersBatchBean() throws Exception {
    	
    	try {
    		
    		properties = SystemProperties.getProperties();
    		
    		TEMP_DIR_ABSOLUTE_PATH = properties.getProperty("user.install.root") +
    			 					 properties.getProperty("ifp_temp_dir_relative_path");
    		
    		PATH_SEPARATOR = properties.getProperty("file.separator");
    		
    		// provider engine IDs from properties file
        	PROVIDER_NAME = properties.getProperty("provider.reuters.name");
        	
    	}
    	catch(Exception e) {
    		
    		logger.warn(new StandardLogMessage("Exception into bean constructor. Exception: " + e));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
		
    }
    
    
    // Batches START ***************************************************************************************************************************************
    
    @Override
    public void nodeInterestRatesBatch() throws Exception {

		try {
			
			
			logger.info(new StandardLogMessage("Reuters NIR synchronization started."));
			
			// first, check Reuters request alignment
			// NON BLOCCANTE
			try {
				this.reutersManagerBeanLocal.checkNirAlignment();
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Reuters NIR request alignment check failed."));
				// default logger
				logger.warn(new StandardLogMessage("Reuters NIR request alignment check failed."));
			}
			

			FLOW_NIR_NAME = properties.getProperty("provider.reuters.flow.nir.name");
    		NIR_RESPONSE_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_NIR_NAME).getResponseFileName();
    		
			
			// create temporary folder and files to work
			// ***************************************************************************************************************
			String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + NIR_RESPONSE_FILE_NAME;
			File tempFile = new File(tempFileAbsPath);
			if (!tempFile.createNewFile()) {
				
				throw new Exception("Unable to create temp file \'" + tempFileAbsPath + "\'.");
			}
			// ***************************************************************************************************************
			
			// get file from ftp and save it into TEMP_FILE_ABSOLUTE_PATH
			String fileName = this.getFileFromFTP(NIR_RESPONSE_FILE_NAME, tempFileAbsPath);
			
			// parse file
			ReutersResponseParser reutersResponseParser = new ReutersResponseParser();
			ReutersResponseTemplate reutersResponseTemplate = reutersResponseParser.parse(tempFile);
			List<HisPrEntity> hisPrEntityList = this.convertRawDataToHPE(reutersResponseTemplate);
			
			// persist data
			try {
				this.baseBeanLocal.persistHistoricalData(hisPrEntityList);
			}
			catch(DuplicateKeyException e) {
				
				monitorLogger.warn(new StandardLogMessage("Reuters NIR batch - Duplicate key values found in new data."));
			}

			// save information about executed batch
			this.baseBeanLocal.saveJobInfo("Reuters", "Bond IR data download", hisPrEntityList, fileName, tempFileAbsPath);
			
			// change status from oneShot to disable for each ex-oneShot instrument
			try {
				this.baseBeanLocal.updateOneShotToDisable(hisPrEntityList);
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Reuters NIR batch - Unable to change ONESHOT to DISABLE."));
				// default logger
				logger.warn(new StandardLogMessage("Reuters NIR batch - Unable to change ONESHOT to DISABLE."));
				ExceptionUtil.logCompleteStackTrace(logger, e);
			}
			
			// align reuters request
			try {
				this.reutersManagerBeanLocal.alignNirRequest();
			}
			
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Reuters NIR request alignment failed."));
				// default logger
				logger.warn(new StandardLogMessage("Reuters NIR request alignment failed."));
				ExceptionUtil.logCompleteStackTrace(logger, e);
			}
			
			// monitor info
			monitorLogger.info(new StandardLogMessage("Reuters NIR synchronization successfully executed."));
			// default logger
			logger.info(new StandardLogMessage("Reuters NIR synchronization successfully executed."));
			
			
			// delete tempWorkingFolder
			//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
		}
		catch(NewDataNotAvailableException e) {
			// monitor warning
			monitorLogger.warn(new StandardLogMessage("Reuters NIR synchronization not completed. New data not available."));
			// default logger
			logger.warn(new StandardLogMessage("Reuters NIR synchronization not completed. New data not available."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Reuters NIR synchronization not completed. New data not available.");
		}
		catch(FTPException e) {
			
			// default logger
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			// FTPEception is managed into caller class.
			throw e;
		}
		catch(Exception e) {
			// monitor error
			monitorLogger.error(new StandardLogMessage("Reuters NIR synchronization failed."));
			// default logger
			logger.error(new StandardLogMessage("Reuters NIR synchronization failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// send notification mail
			MailManager mailManager = new MailManager();
			String message = "Reuters NIR synchronization failed.";
			mailManager.sendMail("InfoProviders System batch generic error", message, null);
			
			// throw at caller
			throw new Exception("Reuters NIR synchronization failed.");
		}
		
	}
    
    
	@Override
	public void futureClosePriceBatch() throws Exception {
		
		try {
			
			logger.info(new StandardLogMessage("Reuters FCP synchronization started."));
			
			// first, check Reuters request alignment
			// NON BLOCCANTE
			try {
				this.reutersManagerBeanLocal.checkFcpAlignment();
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Reuters FCP request alignment check failed."));
				// default logger
				logger.warn(new StandardLogMessage("Reuters FCP request alignment check failed."));
			}
			

			FLOW_FCP_NAME = properties.getProperty("provider.reuters.flow.fcp.name");
        	FCP_RESPONSE_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_FCP_NAME).getResponseFileName();
    		
        	
			
			// create temporary folder and files to work
			// ***************************************************************************************************************
			String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + FCP_RESPONSE_FILE_NAME;
			File tempFile = new File(tempFileAbsPath);
			if (!tempFile.createNewFile()) {
				
				throw new Exception("Unable to create temp file \'" + tempFileAbsPath + "\'.");
			}
			// ***************************************************************************************************************
			
			// get file from ftp and save it into TEMP_FILE_ABSOLUTE_PATH
			String fileName = this.getFileFromFTP(FCP_RESPONSE_FILE_NAME, tempFileAbsPath);
			
			// parse file
			ReutersResponseParser reutersResponseParser = new ReutersResponseParser();
			ReutersResponseTemplate reutersResponseTemplate = reutersResponseParser.parse(tempFile);
			List<HisPrEntity> hisPrEntityList = this.convertRawDataToHPE(reutersResponseTemplate);
			
			// persist data
			try {
				this.baseBeanLocal.persistHistoricalData(hisPrEntityList);
			}
			catch(DuplicateKeyException e) {

				monitorLogger.warn(new StandardLogMessage("Reuters FCP batch - Duplicate key values found in new data."));
			}

			// save information about executed batch
			this.baseBeanLocal.saveJobInfo("Reuters", "Reuters FCP synchronization", hisPrEntityList, fileName, tempFileAbsPath);
			
			// change status from oneShot to disable for each ex-oneShot reuters instrument
			try {
				this.baseBeanLocal.updateOneShotToDisable(hisPrEntityList);
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Reuters FCP batch - Unable to change ONESHOT to DISABLE."));
				// default logger
				logger.warn(new StandardLogMessage("Reuters FCP batch - Unable to change ONESHOT to DISABLE."));
				ExceptionUtil.logCompleteStackTrace(logger, e);
			}
			
			// update reuters request
			try {
				this.reutersManagerBeanLocal.alignFcpRequest();
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Reuters FCP request alignment failed."));
				// default logger
				logger.warn(new StandardLogMessage("Reuters FCP request alignment failed."));
				ExceptionUtil.logCompleteStackTrace(logger, e);
			}
			
			// monitor info
			monitorLogger.info(new StandardLogMessage("Reuters FCP synchronization successfully executed."));
			// default logger
			logger.info(new StandardLogMessage("Reuters FCP synchronization successfully executed."));
			
			
			// delete tempWorkingFolder
			//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
		}
		catch(NewDataNotAvailableException e) {
			// monitor warning
			monitorLogger.warn(new StandardLogMessage("Reuters FCP synchronization not completed. New data not available."));
			// default logger
			logger.warn(new StandardLogMessage("Reuters FCP synchronization not completed. New data not available."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Reuters FCP synchronization not completed. New data not available.");
		}
		catch(FTPException e) {
			
			// default logger
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			// FTPEception is managed into caller class.
			throw e;
		}
		catch(Exception e) {
			// monitor error
			monitorLogger.error(new StandardLogMessage("Reuters FCP synchronization failed."));
			// default logger
			logger.error(new StandardLogMessage("Reuters FCP synchronization failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// send notification mail
			MailManager mailManager = new MailManager();
			String message = "Reuters FCP synchronization failed.";
			mailManager.sendMail("InfoProviders System batch generic error", message, null);
			
			// throw at caller
			throw new Exception("Reuters FCP synchronization failed.");
		}
	}
	
	
	@Override
	public void collateralBatch() throws Exception {
		
		/*try {
		 
		
			logger.info(new StandardLogMessage("Reuters COLLATERAL synchronization started."));
			
			// first, check Reuters request alignment
			// NON BLOCCANTE
			try {
				this.reutersManagerBeanLocal.checkCollAlignment();
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Reuters COLL request alignment check failed."));
				// default logger
				logger.warn(new StandardLogMessage("Reuters COLL request alignment check failed."));
			}
			
			
			
			FLOW_COLL_NAME = properties.getProperty("provider.reuters.flow.coll.name");
        	COLL_RESPONSE_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_COLL_NAME).getResponseFileName();
    		
			
			
			// create temporary folder and files to work
			// ***************************************************************************************************************
			String tempWorkingFolderName = Crypto.MD5(Util.getUniqueToken());
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + COLL_RESPONSE_FILE_NAME;
			File tempFile = new File(tempFileAbsPath);
			if (!tempFile.createNewFile()) {
				
				throw new Exception("Unable to create temp file \'" + tempFileAbsPath + "\'.");
			}
			// ***************************************************************************************************************
			
			// get file from ftp and save it into TEMP_FILE_ABSOLUTE_PATH
			String fileName = this.getFileFromFTP(COLL_RESPONSE_FILE_NAME, tempFileAbsPath);
			
			// parse file
			ReutersResponseParser reutersResponseParser = new ReutersResponseParser();
			ReutersResponseTemplate reutersResponseTemplate = reutersResponseParser.parse(tempFile);
			List<HisPrEntity> hisPrEntityList = this.convertRawDataToHPE(reutersResponseTemplate);
			
			// persist data
			try {
				this.baseBeanLocal.persistHistoricalData(hisPrEntityList);
			}
			catch(DuplicateKeyException e) {

				monitorLogger.warn(new StandardLogMessage("Reuters COLLATERAL batch - Duplicate key values found in new data."));
			}

			// save information about executed batch
			this.baseBeanLocal.saveJobInfo("Reuters", "Reuters COLLATERAL synchronization", hisPrEntityList, fileName, tempFileAbsPath);
			
			// change status from oneShot to disable for each ex-oneShot reuters instrument
			try {
				this.baseBeanLocal.updateOneShotToDisable(hisPrEntityList);
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Reuters COLLATERAL batch - Unable to change ONESHOT to DISABLE."));
				// default logger
				logger.warn(new StandardLogMessage("Reuters COLLATERAL batch - Unable to change ONESHOT to DISABLE."));
				ExceptionUtil.logCompleteStackTrace(logger, e);
			}
			
			// update reuters request
			try {
				this.reutersManagerBeanLocal.alignFcpRequest();
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Reuters COLLATERAL request alignment failed."));
				// default logger
				logger.warn(new StandardLogMessage("Reuters COLLATERAL request alignment failed."));
				ExceptionUtil.logCompleteStackTrace(logger, e);
			}
			
			// monitor info
			monitorLogger.info(new StandardLogMessage("Reuters COLLATERAL synchronization successfully executed."));
			// default logger
			logger.info(new StandardLogMessage("Reuters COLLATERAL synchronization successfully executed."));
			
			
			// delete tempWorkingFolder
			this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
		}
		catch(NewDataNotAvailableException e) {
			// monitor warning
			monitorLogger.warn(new StandardLogMessage("Reuters COLLATERAL synchronization not completed. New data not available."));
			// default logger
			logger.warn(new StandardLogMessage("Reuters COLLATERAL synchronization not completed. New data not available."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception("Reuters FCP synchronization not completed. New data not available.");
		}
		catch(FTPException e) {
			
			// default logger
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			// FTPEception is managed into caller class.
			throw e;
		}
		catch(Exception e) {
			// monitor error
			monitorLogger.error(new StandardLogMessage("Reuters FCP synchronization failed."));
			// default logger
			logger.error(new StandardLogMessage("Reuters FCP synchronization failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// send notification mail
			MailManager mailManager = new MailManager();
			String message = "Reuters FCP synchronization failed.";
			mailManager.sendMail("InfoProviders System batch generic error", message, null);
			
			// throw at caller
			throw new Exception("Reuters FCP synchronization failed.");
		}*/
		
	}
	
	
	
    
    // Batches END ***************************************************************************************************************************************
    
    
    
    // Getting file START ***************************************************************************************************************************************
	
    // get file from ftp and save it into tempFileAbsPath
    private String getFileFromFTP(String fileType, String tempFileAbsPath) throws Exception {
    	
    	try {
	    	String fileName = null;
	    	
	    	// initialize ftpService
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.REUTERS_SERVICE);
			
			// compute file name to download
			FTPFile[] fileArray = this.ftpServiceInterface.getResponseFilesInfo();
			fileName = this.getOutTypeLastFileInfo(fileArray, fileType).getName();
			
			// controllo file gi� scaricato / dati gi� scaricati
			if(this.ftpFileEAOLocal.findByName(fileName) != null) {
				
				logger.warn(new StandardLogMessage("File \'" + fileName + "\' already downloaded. New data not available."));
				
				throw new NewDataNotAvailableException("File \'" + fileName + "\' already downloaded. New data not available.");
			}
			
			// download file
			this.ftpServiceInterface.downloadResponseFile(fileName, new File(tempFileAbsPath));
	    	
			
			logger.info(new StandardLogMessage("File \'" + fileName + "\' successfully downloaded."));
			
			return fileName;
    	}
		catch(Exception e) {
			
			throw e;
		}
		
    }
    
    // Getting file END ***************************************************************************************************************************************
    
	
    // Parsing file START ***************************************************************************************************************************************
    
    // convert Reuters response data file (file data line format [ric, date, price])
    private List<HisPrEntity> convertRawDataToHPE(ReutersResponseTemplate reutersResponseTemplate) throws Exception {
    	
    	try {
			
    		List<Object[]> data = reutersResponseTemplate.getData();
        	
        	List<HisPrEntity> list = new ArrayList<HisPrEntity>();
    		
    		for(Object[] record : data) {
			
				// check corrupted data
				if(record.length < 3) {
					
					logger.warn(new StandardLogMessage("Missing values in data file. Corrupted line: " + ArrayUtils.toString(record)));
					
					monitorLogger.warn(new StandardLogMessage("Missing values in data file. Corrupted line: " + ArrayUtils.toString(record)));
					
					
					continue;
				}
				
				String ricCode = ((String)record[0]).trim();
				int date = Integer.parseInt(((String)record[1]).trim());
				String price = ((String)record[2]).trim();
				
				HisPrEntity hisPrEntity = new HisPrEntity();
				HisPrEntityPK hisPrEntityPK = new HisPrEntityPK();
				
				InstrEntity instrEntity = this.instrEAOLocal.findByRICCode(ricCode);
				
				// *** IMPORTANT ***
				// Check if the downloaded line matches with an instrument in my static data.
				// IF NOT, it means i am downloading something useless and someone directly modified 
				// Reuters request file on Reuters account folder;
				// or i am testing some new instrument in a different environment!!!
				if(instrEntity == null) {
					
					logger.error(new StandardLogMessage("Instrument having Reuters Code \'" + ricCode + "\' not fount in Static Data. Check StaticData/Reuters request alignment."));
					monitorLogger.error(new StandardLogMessage("Instrument having Reuters Code \'" + ricCode + "\' not fount in Static Data. Check StaticData/Reuters request alignment."));
					
					continue;
					//throw new Exception();
				}
				
				int instrumentId = instrEntity.getInstrumentId();
				hisPrEntityPK.setInstrumentId(instrumentId);
				hisPrEntityPK.setPriceDate(date);
				//hisPrEntityPK.setPriceTime(priceTime);
				hisPrEntity.setId(hisPrEntityPK);
				hisPrEntity.setClosingPrice(new BigDecimal(price));
				
				list.add(hisPrEntity);
			}
    		
    		logger.info(new StandardLogMessage("Parsing successfully completed."));
    		

    		return list;
    	}
		catch(Exception e) {
			
			throw new Exception("Cannot convert from raw data to HistoricalPricesEntity.");
		}
		
	}
    
    // Parsing file END ***************************************************************************************************************************************
    
    
	private FTPFile getOutTypeLastFileInfo(FTPFile[] fileArray, String outType) throws Exception {
		
		// file name format: OUTTYPEyyyymmdd.csv (for example: "NIR_20120303.csv")
		
		String prefix = outType;
		
		Set<FTPFile> fileList = new TreeSet <FTPFile>(new ReutersResponseFTPFileComparator(prefix));
		
		for(FTPFile file : fileArray) {
			
			String fileName = file.getName();
			
			// considero tutti i file con prefisso dato e estensione .csv
			if(fileName.startsWith(prefix) && fileName.endsWith(".csv")) {
				
				fileList.add(file);
			}
		}
		
		if(fileList.size() < 1) {
			
			throw new Exception(outType + " data not available on Reuters server.");
		}
		
		// prendo il primo, la lista � ordinata in modo decrescente secondo la data
		return ((FTPFile)fileList.toArray()[0]);
	}
	
	

}

