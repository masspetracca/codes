package it.ccg.ifpejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the IFPVHISPRINFO database table.
 * 
 */
@Entity
@Table(name="IFPMHISPR")
@NamedNativeQueries({
	@NamedNativeQuery(name="refreshHisPrInfoView", query="REFRESH TABLE INFOP.IFPMHISPR")
})
public class HisPrInfoViewEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int count;
	
	@Id
	@Column(name="INSTR_ID", nullable=false)
	private int instrumentId;

	@Column(name="INSTRNAME", length=255)
	private String instrumentName;
	
	@Column(name="MINPDATE")
	private int minPriceDate;
	
	@Column(name="MAXPDATE")
	private int maxPriceDate;

    public HisPrInfoViewEntity() {
    	
    }

	public int getCount() {
		return this.count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getInstrumentId() {
		return instrumentId;
	}

	public void setInstrumentId(int instrumentId) {
		this.instrumentId = instrumentId;
	}

	public String getInstrumentName() {
		return instrumentName;
	}

	public void setInstrumentName(String instrumentName) {
		this.instrumentName = instrumentName;
	}

	public int getMaxPriceDate() {
		return maxPriceDate;
	}

	public void setMaxPriceDate(int maxPriceDate) {
		this.maxPriceDate = maxPriceDate;
	}

	public int getMinPriceDate() {
		return minPriceDate;
	}

	public void setMinPriceDate(int minPriceDate) {
		this.minPriceDate = minPriceDate;
	}

	



}