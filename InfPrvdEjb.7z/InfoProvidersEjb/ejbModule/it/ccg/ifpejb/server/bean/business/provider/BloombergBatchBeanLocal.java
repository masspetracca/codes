package it.ccg.ifpejb.server.bean.business.provider;



import javax.ejb.Local;

@Local
public interface BloombergBatchBeanLocal {
	
	public void currencyRatesBatch() throws Exception;
	public void nodesInterestRatesBatch() throws Exception;
	
}
