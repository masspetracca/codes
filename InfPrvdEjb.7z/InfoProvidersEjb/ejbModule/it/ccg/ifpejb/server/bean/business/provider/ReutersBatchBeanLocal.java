package it.ccg.ifpejb.server.bean.business.provider;


import javax.ejb.Local;

@Local
public interface ReutersBatchBeanLocal {
	
	public void nodeInterestRatesBatch() throws Exception;
	public void futureClosePriceBatch() throws Exception;
	
	public void collateralBatch() throws Exception;
	
}

