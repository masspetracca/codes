package it.ccg.ifpejb.server.bean.eao;

import it.ccg.ifpejb.server.bean.entity.MiPrCurrInstrEntity;

import java.math.BigDecimal;
import java.util.List;

public interface MiPrCurrInstrEAOLocal {
	
	public MiPrCurrInstrEntity findByPrimaryKey(String paramString, BigDecimal paramBigDecimal) throws Exception;
	public List<MiPrCurrInstrEntity> fetchAll() throws Exception;

}
