package it.ccg.ifpejb.server.bean.eao;


import it.ccg.ifpejb.server.bean.entity.InstrEntity;

import java.util.List;

import javax.ejb.Local;

@Local
public interface InstrEAOLocal {

	public List<InstrEntity> fetch() throws Exception;
	public List<InstrEntity> fetchFutures() throws Exception;
	public List<InstrEntity> fetchEnabled(String instTypy, String provider) throws Exception;
	public List<InstrEntity> fetchOneShot(String instTypy, String provider) throws Exception;
	public InstrEntity findByPrimaryKey(int instrumentID) throws Exception;
	public InstrEntity findByRICCode(String ricCode) throws Exception;
	public InstrEntity findByBloombergCode(String bbgCode) throws Exception;
	public InstrEntity findByCode(String code) throws Exception;
	public List<InstrEntity> findInstrumentByType(String instrumentType) throws Exception;
	
	public void add(InstrEntity ie) throws Exception;
	public InstrEntity update(InstrEntity ie) throws Exception;
	public void remove(InstrEntity ie) throws Exception;
	
}
