package it.ccg.ifpejb.server.bean;


import it.ccg.ifpejb.server.providerengine.util.JobType;

import java.util.List;

import javax.ejb.Local;

@Local
public interface JobManagerBeanLocal {
	
	public List<ProviderDTO> getProviderList() throws Exception;
	
	public List<JobDTO> getJobListByProviderName(String providerName) throws Exception;
	public JobDTO getJobByName(String jobName) throws Exception;
	public JobDTO getJobByJobMethodNClass(String method, Class<?> _class) throws Exception;
	public JobDTO getJobBy_Provider_DataType_JobType(String provider, String instrType, JobType jobType) throws Exception;
	
	public void executeJob(JobDTO jobDTO) throws Exception;
	
}
