package it.ccg.ifpejb.server.bean.business.provider;



import javax.ejb.Local;

@Local
public interface BloombergManagerBeanLocal {
	
	public void checkCurrAlignment() throws Exception;
	public void alignCurrRequest() throws Exception;
	
	public void checkNirAlignment() throws Exception;
	public void alignNirRequest() throws Exception;
	
}
