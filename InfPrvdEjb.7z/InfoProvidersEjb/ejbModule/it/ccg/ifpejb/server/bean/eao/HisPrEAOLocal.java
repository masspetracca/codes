package it.ccg.ifpejb.server.bean.eao;
import it.ccg.ifpejb.server.bean.entity.HisPrEntity;
import it.ccg.ifpejb.server.bean.entity.HisPrEntityPK;

import java.util.List;

import javax.ejb.Local;

@Local
public interface HisPrEAOLocal {

	public List<HisPrEntity> fetch() throws Exception;
	public HisPrEntity findByPrimaryKey(HisPrEntityPK pK) throws Exception;
	
	public List<HisPrEntity> fetchLastDateHisPr(List<Integer> instrIDs) throws Exception;
	
	public int getInstrMinPriceDate(int instrId) throws Exception;
	
	public void add(HisPrEntity ie) throws Exception;
	public void update(HisPrEntity ie) throws Exception;
	public void remove(HisPrEntity ie) throws Exception;
	
}
