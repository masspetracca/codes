package it.ccg.ifpejb.server.bean.business.provider;

import javax.ejb.Local;

@Local
public interface GenericProcedureBeanLocal {
	
	public void addHistoricalDataFromUploadedFile(String fileName) throws Exception;
	//public void checkInstrumentHistoricalDataAlignment(int instrumentId) throws Exception;

}
