package it.ccg.ifpejb.server.logengine;



import java.net.URL;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class Log4jSetup {
	
	private static Logger logger;
	
	public static void loadLog4JProperties() throws Exception {
		
		URL log4jPropertiesURL = Thread.currentThread().getContextClassLoader().getResource("log4j.isc.config.xml");
		
		DOMConfigurator.configure(log4jPropertiesURL);
		
		logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
		logger.info(new StandardLogMessage("InfoProviders system Log4J properties successfully loaded from " + log4jPropertiesURL));
		
	}
	
	
}
