package it.ccg.ifpejb.server.exception;


import it.ccg.ifpejb.server.logengine.StandardLogMessage;

import org.apache.log4j.Logger;

public class ExceptionUtil {
	
	
	public static void logCompleteStackTrace(Logger logger, Throwable throwable) {
		
		logger.error(new StandardLogMessage(throwable.toString()));
		
		StackTraceElement[] stackTraceElements = throwable.getStackTrace();
		for(StackTraceElement element : stackTraceElements) {
			
			logger.error(new StandardLogMessage(element.toString()));
		}
		
	}
	
	
}
