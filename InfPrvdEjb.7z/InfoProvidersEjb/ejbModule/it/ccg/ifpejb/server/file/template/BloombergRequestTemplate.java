package it.ccg.ifpejb.server.file.template;


import java.util.List;
import java.util.Map;
import java.util.Set;

public class BloombergRequestTemplate {
	
	private Map<String, String> headers;
	private List<String> fields;
	private List<String> securities;
	
	
	public BloombergRequestTemplate(Map<String, String> headers, List<String> fields, List<String> securities) {
		
		this.headers = headers;
		this.fields = fields;
		this.securities = securities;
	}
	
	
	public String getAsFileFormattedString() {
		String temp = new String();
		
		temp += "START-OF-FILE" + "\n";
		temp += "\n";
		
		Set<String> keySet = this.headers.keySet();
		for(String key : keySet) {
			temp += key + "=" + this.headers.get(key) + "\n";
		}
		temp += "\n";
		
		temp += "START-OF-FIELDS" + "\n";
		for(String field : this.fields) {
			temp += field + "\n";
		}
		temp += "END-OF-FIELDS" + "\n";
		temp += "\n";
		
		temp += "START-OF-DATA" + "\n";
		for(String security : this.securities) {
			temp += security + "\n";
		}
		temp += "END-OF-DATA" + "\n";
		temp += "\n";
		
		temp += "END-OF-FILE" + "\n";
		temp += "\n";
		
		
		return temp;
	}


	public Map<String, String> getHeaders() {
		return headers;
	}


	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}


	public List<String> getFields() {
		return fields;
	}


	public void setFields(List<String> fields) {
		this.fields = fields;
	}


	public List<String> getSecurities() {
		return securities;
	}


	public void setSecurities(List<String> securities) {
		this.securities = securities;
	}
	
	
	
	@Override
	public String toString() {
		
		String dataString = "\n";
		for(String security : this.securities) {
			
			dataString += "\t" + security + "\n";
		}
		
		
		return "BloombergResponse" + "\n" + 
			   "[header=" + headers + "\n" + 
			   " fields=" + fields + "\n" + 
			   
			   " data=[\n" + dataString + " ]\n"; 
			   
	}
	

}
