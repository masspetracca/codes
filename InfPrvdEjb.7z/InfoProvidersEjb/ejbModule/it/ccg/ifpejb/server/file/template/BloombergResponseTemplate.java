package it.ccg.ifpejb.server.file.template;


import java.util.List;
import java.util.Map;

public class BloombergResponseTemplate {
	
	private Map<String, String> header;
	private List<String> fields;
	private Object timeStarted;
	private List<Object[]> data;
	private Object timeFinished;
	
	
	public BloombergResponseTemplate(Map<String, String> header, List<String> fields, Object timeStarted, List<Object[]> data, Object timeFinished) {
		this.header = header;
		this.fields = fields;
		this.timeStarted = timeStarted;
		this.data = data;
		this.timeFinished = timeFinished;
	}
	
	
	
	
	public Map<String, String> getHeader() {
		return header;
	}
	

	public List<String> getFields() {
		return fields;
	}


	public Object getTimeStarted() {
		return timeStarted;
	}


	public List<Object[]> getData() {
		return data;
	}


	public Object getTimeFinished() {
		return timeFinished;
	}




	@Override
	public String toString() {
		
		String dataString = "\n";
		for(Object[] record : data) {
			
			String recordString = new String();
			
			for(Object obj : record) {
				recordString += (String)obj + "|";
			}
			//recordString = recordString.substring(0, recordString.length() - 1);
			
			dataString += "\t" + recordString + "\n";
		}
		
		
		return "BloombergResponse" + "\n" + 
			   "[header=" + header + "\n" + 
			   " fields=" + fields + "\n" + 
			   " timeStarted=" + timeStarted + "\n" +
			   
			   " data=[\n" + dataString + " ]\n" + 
			   
			   " timeFinished=" + timeFinished + "]";
	}
	
	
	

}
