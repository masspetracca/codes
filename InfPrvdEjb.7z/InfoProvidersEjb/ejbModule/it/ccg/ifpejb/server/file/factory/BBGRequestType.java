package it.ccg.ifpejb.server.file.factory;

public enum BBGRequestType {
	
	CURR_REQUEST,
	NIR_REQUEST;

}
