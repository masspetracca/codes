package it.ccg.ifpejb.server.file.template;

import java.util.ArrayList;
import java.util.List;

public class ReutersResponseTemplate {
	
	private List<Object[]> data;
	
	public ReutersResponseTemplate() {
		
		this.data = new ArrayList<Object[]>();
	}
	
	public ReutersResponseTemplate(List<Object[]> data) {
		
		this.data = data;
	}
	
	

	public List<Object[]> getData() {
		return data;
	}

	public void setDataList(List<Object[]> data) {
		this.data = data;
	}

}
