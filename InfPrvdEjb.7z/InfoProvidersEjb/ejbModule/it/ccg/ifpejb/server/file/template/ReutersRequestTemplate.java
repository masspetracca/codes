package it.ccg.ifpejb.server.file.template;

import java.util.ArrayList;
import java.util.List;

public class ReutersRequestTemplate {
	
	private List<String> instruments;
	
	public ReutersRequestTemplate() {
		
		this.instruments = new ArrayList<String>();
	}
	
	public ReutersRequestTemplate(List<String> instruments) {
		
		this.instruments = instruments;
	}
	
	
	
	public List<String> getInstruments() {
		return instruments;
	}

	public void setInstruments(List<String> instruments) {
		this.instruments = instruments;
	}

}
