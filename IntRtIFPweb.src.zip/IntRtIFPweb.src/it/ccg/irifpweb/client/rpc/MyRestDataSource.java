package it.ccg.irifpweb.client.rpc;

import java.util.HashMap;
import java.util.Map;

import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.RestDataSource;
import com.smartgwt.client.types.DSDataFormat;

public class MyRestDataSource extends RestDataSource {
	
	public MyRestDataSource(String dataURL) {
		
		this.setDataURL(dataURL);
		this.setDataFormat(DSDataFormat.JSON);
		
		DSRequest requestProperties = new DSRequest();
		requestProperties.setHttpMethod("POST");
		
		//
		Map<String, String> params = new HashMap<String, String>();
		params.put("_isRestDataSource", "");
		requestProperties.setParams(params);
		
		this.setRequestProperties(requestProperties);
		
	}

}
