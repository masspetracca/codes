package it.ccg.irifpweb.client.security;

import java.util.List;

public class UserData {
	
	private static UserData currentUserData;
	
	private String cn;
	private List<String> userRolesList;
	
	
	public UserData() {
		
	}
	
	public UserData(String cn, List<String> userRolesList) {
		
		this.cn = cn;
		this.userRolesList = userRolesList;
	}
	
	
	public String getCn() {
		return cn;
	}

	public void setCn(String cn) {
		this.cn = cn;
	}

	public List<String> getUserRolesList() {
		return userRolesList;
	}



	public static UserData getCurrentUserData() {
		
		return currentUserData;
	}
	
	public static void setCurrentUserData(UserData currentUserData) {
		
		UserData.currentUserData = currentUserData;
	}

}
