package it.ccg.irifpweb.client.base;


import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.DataSourceField;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;

public class MyListGrid extends ListGrid {
	
	
	public static MyListGrid getInstance(DataSource dataSource) {
		
		MyListGrid grid = new MyListGrid(dataSource);
		
		grid.mapDSFieldsWithLGFields();
		
		
		return grid;
	}
	
	
	
	private MyListGrid(DataSource dataSource) {
		
		super();
		
		this.setShowFilterEditor(true);
		this.setCanSort(true);
		this.setCanMultiSort(false);
		this.setCanGroupBy(false);
		
		this.setDataSource(dataSource);
		this.setAutoFetchData(false);
		
	}
	
	
	// this overrides the DataSourceField list to have the functions of ListGridField for each field
	private void mapDSFieldsWithLGFields() {
		
		DataSource datasource = this.getDataSource();
		
		DataSourceField[] dsFields = datasource.getFields();
		
		ListGridField[] lgFields = new ListGridField[dsFields.length];
		for(int i=0; i<lgFields.length; i++) {
			
			ListGridField lgField = new ListGridField();
			lgField.setName(dsFields[i].getName());
			lgField.setTitle(dsFields[i].getTitle());
			
			lgFields[i] = lgField;
		}
		
		
		this.setFields(lgFields);
	}
	

}
