package it.ccg.irifpweb.client.base;

import com.smartgwt.client.widgets.IButton;

public class StandardButton extends IButton {
	
	public StandardButton() {
		super();
		
		this.setWidth(120);
		this.setHeight(20);
	}
	
}
