package it.ccg.irifpweb.server.servlet;

import it.ccg.irifpejb.server.bean.JobDTO;
import it.ccg.irifpejb.server.bean.JobManagerBeanLocal;
import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.logengine.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.isomorphic.rpc.RPCManager;
import com.isomorphic.rpc.RPCResponse;

/**
 * Servlet implementation class ExecuteBatch
 */
public class JobExecute extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	
	@EJB
	private JobManagerBeanLocal jobManagerBeanLocal;
	
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JobExecute() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		throw new ServletException("Servlet does not allow GET request.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.doWork(request, response);
	}
	
	
	private void doWork(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		try {
			
			
			
			String jobName = request.getParameter("jobName");
			
			JobDTO jobDTO = this.jobManagerBeanLocal.getJobByName(jobName);
			
			if(jobDTO == null) {
				
				throw new Exception("Job \'" + jobName + "\' doesn't exist.");
			}
			
			this.jobManagerBeanLocal.executeJob(jobDTO);
			
			

			//Creo l'oggetto RPC per la gestione SmartGWT dei parametri della servlet
			RPCManager rpcManager = new RPCManager(request, response);
			// response
			RPCResponse rpcResponse = new RPCResponse();
			// creo una map per la risposta
			Map<String, Object> responseData = new HashMap<String, Object>();
			responseData.put("message", "Job \'" + jobName + "\' successfully executed. Read logs for details.");
			// popolo i dati di risposta
			rpcResponse.setData(responseData);
			
			//
			response.setStatus(HttpServletResponse.SC_OK);
			// restituzione del risultato
			rpcManager.send(rpcResponse);
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
		
	}

}
