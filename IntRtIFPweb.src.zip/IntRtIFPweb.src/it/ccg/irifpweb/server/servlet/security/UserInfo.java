package it.ccg.irifpweb.server.servlet.security;


import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.ldap.LDAPUserBeanLocal;
import it.ccg.irifpejb.server.ldap.LDAPUserDTO;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.system.SystemProperties;

import java.io.IOException;
import java.security.Principal;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;


public class UserInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	@EJB
	private LDAPUserBeanLocal ldapUserBeanLocal;
	
	private static String[] availableRoles = null;
		
	
	/**
     * @see HttpServlet#HttpServlet()
     */
    public UserInfo() {
    	
        super();
    }
    
    
	
	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			availableRoles = SystemProperties.getProperty("security.roles").split(",");
			
			
			Principal principal = request.getUserPrincipal();
			
			String cn = null;
			String rolesString = new String();
			
			// principal == null se ho disabilitato la sicurezza --> sono in modalit� sviluppo
			if(principal == null) {
				
				cn = "DEVELOPER";
				rolesString = "admin";
			}
			else {
				
				LDAPUserDTO ldapUserDTO = this.ldapUserBeanLocal.getLDAPUserByUID(principal.getName());
				
				// 
				if(ldapUserDTO == null) {
					
					throw new Exception("User \'" + principal.getName() + "\' not found in register.");
				}
				
				cn = ldapUserDTO.getCn();
				
				for(String role : availableRoles) {
					if(request.isUserInRole(role)) {
						
						rolesString += role + "|";
					}
				}
				if(rolesString.length() > 0) {
					
					rolesString = rolesString.substring(0, rolesString.length() - 1);
				}
			}
			
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("cn", cn);
			jsonObject.put("roles", rolesString);
			
			String jsonString = jsonObject.toJSONString();
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			response.getWriter().print(jsonString);
			
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}

}
