package it.ccg.irifpweb.server.servlet;


import it.ccg.irifpejb.server.logengine.Log4jSetup;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.server.providerengine.ProviderEngine;
import it.ccg.irifpejb.server.system.SystemFilesConfig;
import it.ccg.irifpejb.server.system.SystemProperties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;


/**
 * Servlet implementation class Startup
 */
public class Startup extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger logger;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Startup() {
    	super();
    }
    
    
    @Override
    public void init() throws ServletException {
    	
    	try {
    		System.out.println("Loading IntRatIFP system environment..");
    		
    		// load log4j properties
			Log4jSetup.loadLog4JProperties();
			
			// load system properties
			SystemProperties.loadSystemProperties();
			
    		// system files
			SystemFilesConfig.createSystemFiles();
			
			// load provider config
			ProviderEngine.load();
			
    		
			logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
			
    		logger.info(new StandardLogMessage("..IntRatIFP system environment successfully loaded."));
    	}
    	catch(Exception e) {
    		
    		e.printStackTrace();
		}
    	
    }
    

}
