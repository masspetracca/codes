package it.ccg.irifpweb.server.servlet.data;


import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.logengine.LogLineDTO;
import it.ccg.irifpejb.server.logengine.LogService;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.system.SystemProperties;
import it.ccg.irifpweb.server.util.POJO2Json;
import it.ccg.irifpweb.server.util.SmartGwtUtil;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;



/**
 * Servlet implementation class LogEndpoint
 */
public class LogEndpoint extends DataEndpoint {
	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	//private static final Logger userLogger = PALoggerFactory.getLogger(PALoggerFactory.USER_LOGGER);
	
	private PrintWriter outStream = null;
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogEndpoint() {
        super();
        
    }

	@Override
	protected void fetch(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String _operationId = request.getParameter("_operationId");
			
			if(_operationId == null) {
				
				throw new ServletException("Unable to process request. \'operation\' parameter not found.");
			}
			
			
			if(_operationId.equalsIgnoreCase("fetchLogsByType")) {
				
				this.fetchLogsByType(request, response);
			}
			else if(_operationId.equalsIgnoreCase("fetchLogByFileName")) {
				
				this.fetchLogByFileName(request, response);
			}
			else {
				
				throw new ServletException("Unable to process request. \'_operationId\' of type \'" + _operationId + "\' not valid.");
			}
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	private void fetchLogsByType(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			String logType = request.getParameter("logType");
			
			String LOG_FILE_DIR_ABSOLUTE_PATH = SystemProperties.getProperty("user.install.root") +
												SystemProperties.getProperty("file.separator") +
												SystemProperties.getProperty("ifp_log_dir_relative_path");
			LogService logService = new LogService(LOG_FILE_DIR_ABSOLUTE_PATH);
			
			List<Map<String, String>> list = logService.getLogsListByType(logType);
			
			String jsonString = POJO2Json.convert(Map.class, list);
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}


	private void fetchLogByFileName(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			String[] criteriaStructArray = request.getParameterValues("criteria");
			
			JSONParser jsonParser = new JSONParser();
			
			
			Map<String, Object> filterParams = new HashMap<String, Object>();
			
			for(String criteriaStruct : criteriaStructArray) {
				
				@SuppressWarnings("unchecked")
				Map<String, Object> criteriaMap = (Map<String, Object>)jsonParser.parse(criteriaStruct);
				
				Object value = null;
				
				if(criteriaMap.get("value") instanceof JSONArray) {
					
					value = ((JSONArray)criteriaMap.get("value")).toArray();
				}
				else if(criteriaMap.get("value") instanceof String) {
					
					value = (String)criteriaMap.get("value");
				}
				else {
					
					throw new Exception("Error parsing criteria.");
				}
				
				filterParams.put((String)criteriaMap.get("fieldName"), value);
			}
			
			String LOG_FILE_DIR_ABSOLUTE_PATH = SystemProperties.getProperty("user.install.root") +
												SystemProperties.getProperty("file.separator") +
												SystemProperties.getProperty("ifp_log_dir_relative_path");
			LogService logService = new LogService(LOG_FILE_DIR_ABSOLUTE_PATH);

			List<LogLineDTO> dataList = logService.getLog((String)filterParams.get("logFileName"), filterParams);
			
			
			int totalRows = dataList.size();
	        int startRow = Integer.parseInt(request.getParameter("_startRow"));  
	        int endRow = Integer.parseInt(request.getParameter("_endRow"));  
	        endRow = Math.min(endRow, totalRows);
			
	        dataList = dataList.subList(startRow, endRow);
			
			String dataJsonString = POJO2Json.convert(LogLineDTO.class, dataList);
			
			String responseBody = SmartGwtUtil.getDSResponseBody(dataJsonString, startRow, endRow, totalRows);
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(responseBody);
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	
	
	
}

