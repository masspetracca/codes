package it.ccg.irifpweb.server.servlet;



import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.system.SystemProperties;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class PropertyRefresh
 */
public class SPL extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private PrintWriter out;
	
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SPL() throws Exception {
    	super();
    	
    }
    
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.doWork(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.doWork(request, response);
	}
    
    
    private void doWork(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	try {
    		// load system properties
    		SystemProperties.loadSystemProperties();
        	
    		// render page
    		this.renderPage(response);
    	}
    	catch(Exception e) {
    		
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
    	
    }
    
    
    private void renderPage(HttpServletResponse response) throws Exception {
    	
    	this.out = response.getWriter();
    	
    	this.out.println("Properties successfully loaded!");
    	this.out.println();
    	this.out.println();
		
		BufferedReader bufferedReader = new BufferedReader(new FileReader(new File(SystemProperties.getPropertiesFileAbsPath())));    
		
		String line = bufferedReader.readLine();
		
		while(line != null) {
			
			out.println(line);
			
			line = bufferedReader.readLine();
		}
		
    }
    
    

}
