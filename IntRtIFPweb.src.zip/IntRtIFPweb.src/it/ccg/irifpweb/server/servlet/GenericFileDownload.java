package it.ccg.irifpweb.server.servlet;


import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.server.system.SystemProperties;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;



/**
 * Servlet implementation class GenericFileDownload
 */
public class GenericFileDownload extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	
	
	private static String INTERNAL_DIR_ABSOLUTE_PATH;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GenericFileDownload() throws Exception {
    	super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		throw new ServletException("Servlet does not allow GET request.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.doWork(request, response);
	}
	
	
	
	protected void doWork(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		try {
			
			INTERNAL_DIR_ABSOLUTE_PATH = SystemProperties.getProperty("user.install.root") + 
										 SystemProperties.getProperty("ifp_internal_dir_relative_path");
			
			
			// file path
			String fileName = request.getParameter("fileName");
			
			//
			File file = new File(INTERNAL_DIR_ABSOLUTE_PATH + fileName);
			if(!file.exists()) {
				
				throw new FileNotFoundException("File \'" + file.getAbsolutePath() + "\' not found.");
			}
			
			DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
			
			int length = 0;
			ServletOutputStream servletOutputStream = response.getOutputStream();
			
			
			byte[] buffer = new byte[1024];
			
			while((dataInputStream != null) && ((length = dataInputStream.read(buffer)) != -1)) {
				
				servletOutputStream.write(buffer, 0, length);
			}
			
			response.setContentType("application/zip");
			response.setContentLength((int)file.length());
			response.setHeader("Content-Disposition","attachment; filename=\"" + file.getName() + "\"");
			
			dataInputStream.close();
			servletOutputStream.flush();
			servletOutputStream.close();
			
			// 
			response.setStatus(HttpServletResponse.SC_OK);
			
			logger.debug(new StandardLogMessage("File \'" + file.getName() + "\' successfully downloaded."));
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	

}
