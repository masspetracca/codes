package it.ccg.irifpweb.server.util;

public class SmartGwtUtil {
	
	
	public static String getDSResponseBody(String dataJsonString, int startRow, int endRow, int totalRows) {
		
		String responseBody = new String();
		
		
		responseBody += "{";
		
		responseBody += "response:{";
		
		responseBody += "status:" + 0 + ",";
		responseBody += "startRow:" + startRow + ",";
		responseBody += "endRow:" + endRow + ",";
		responseBody += "totalRows:" + totalRows + ",";
		responseBody += "data:" + dataJsonString;
		
		responseBody += "}";
		
		responseBody += "}";
		
		
		return responseBody;
	}

}
