package it.ccg.irifpweb.server.filter.util;

import it.ccg.irifpejb.server.logengine.LoggerFactory;

import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.rpc.RPCManager;
//import com.isomorphic.rpc.RPCRequest;


public class UserLogUtil {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = LoggerFactory.getLogger(LoggerFactory.USER_LOGGER);
	
	
	@SuppressWarnings("unchecked")
	public static String getUserLogFormatLine(HttpServletRequest request, HttpServletResponse response) {
		
		String userReqLogMessage = "User request. Url: " + request.getRequestURL();
		
		try {
			
			// Questa chiamata lancia un'eccezione se la request non � n� di tipo DSRequest
			// n� di tipo RPCRequest. Questo accade o per request NON SmartGwt (ad esempio al 
			// caricamento di index.html, o la GET di una immagine, ecc..), o per request di 
			// tipo DSRequest con datasource di tipo RestDataSource che usa lo standard JSON.
			RPCManager rpcManager = new RPCManager(request, response);
			
			// arrivati a questo punto, posso avere o una RPCRequest o una DSRequest
			
			// case: RPCRequest
			if(rpcManager.getDSRequest() == null) {
				
				//RPCRequest rpcRequest = rpcManager.getRequest();
				
				userReqLogMessage += "; [";
				
				Map<String, String[]> paramMap = (Map<String, String[]>)request.getParameterMap();
				Set<String> keySet = paramMap.keySet();
				for(String param : keySet) {
					
					if(!occurCheck(param)) {
						
						userReqLogMessage += param + ": " + ArrayUtils.toString(paramMap.get(param)) + ", ";
					}
					
				}
				
				userReqLogMessage = userReqLogMessage.substring(0, userReqLogMessage.length() - 2);
				
				userReqLogMessage += "]";
			}
			// case: DSRequest
			else {
				
				DSRequest dsRequest = rpcManager.getDSRequest();
				
				userReqLogMessage += "; [";
				userReqLogMessage += "operationType: " + dsRequest.getOperationType() + ", ";
				userReqLogMessage += "dataSource: " + dsRequest.getDataSourceName() + ", ";
				userReqLogMessage += "operationId: " + dsRequest.getOperationId() + ", ";
				userReqLogMessage += "criteria: " + dsRequest.getCriteria() + ", ";
				userReqLogMessage += "values: " + dsRequest.getValues() + ", ";
				userReqLogMessage += "oldValues: " + dsRequest.getOldValues();
				userReqLogMessage += "]";
			}
			
			
			
		}
		catch(Exception e) {
			
			// case: DSRequest - RestDataSource
			if(request.getParameter("_isRestDataSource") != null) {
				
				Map<String, String[]> paramMap = (Map<String, String[]>)request.getParameterMap();
				
				userReqLogMessage += "; [";
				userReqLogMessage += "operationType: " + ArrayUtils.toString(paramMap.get("_operationType")) + ", ";
				userReqLogMessage += "operationId: " + ArrayUtils.toString(paramMap.get("_operationId")) + ", ";
				userReqLogMessage += "criteria: " + ArrayUtils.toString(paramMap.get("criteria")) + ", ";
				userReqLogMessage += "values: " + ArrayUtils.toString(paramMap.get("values")) + ", ";
				userReqLogMessage += "oldValues: " + ArrayUtils.toString(paramMap.get("oldValues"));
				userReqLogMessage += "]";
				
			}
			// case: OTHER
			else {
				
				logger.warn(e);
				userLogger.warn(e);
			}
			
		}
		
		
		return userReqLogMessage;
	}
	
	
	
	private static boolean occurCheck(String parameter) {
		
		boolean result = false;
		
		String[] prefixToSkip = {"isc_", "_transaction", "protocolVersion"};
		
		for(String prefix : prefixToSkip) {
			
			if(parameter.startsWith(prefix)) {
				
				result = true;
				
				break;
			}
		}
		
		
		return result;
	}
	
	
}
