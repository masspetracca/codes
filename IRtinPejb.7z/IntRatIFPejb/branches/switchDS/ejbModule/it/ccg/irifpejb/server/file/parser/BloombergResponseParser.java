package it.ccg.irifpejb.server.file.parser;



import it.ccg.irifpejb.server.file.template.BloombergResponseTemplate;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

public class BloombergResponseParser {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	public BloombergResponseParser() throws Exception {
		
	}
	
	
	public BloombergResponseTemplate parse(File file) throws Exception {
		
		if(!file.exists()) {
		
			logger.error(new StandardLogMessage("File \'" + file.getAbsolutePath() + "\' not exists."));
			
			throw new Exception("File \'" + file.getAbsolutePath() + "\' not exists.");
		}
		
			
		// apro lo stream per leggere il file
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(file));
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		// marker at beginning of file
		try {
			br.mark((int)(file.length() / 2));  // /2 because char type is 16 bit in java
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		Map<String, String> header = this.getHeader(br);
		List<String> fields = this.getFields(br);
		Object timeStarted = this.getTimeStarted(br);
		List<Object[]> data = this.getData(br);
		Object timeFinished = this.getTimeFinished(br);
		
			
		/*while(!line.startsWith("END-OF-FILE")) {
			line = br.readLine();
		}*/
			
			
		try {
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		BloombergResponseTemplate bloombergResponseFileMapping = new BloombergResponseTemplate(header, fields, timeStarted, data, timeFinished);
		
		
		return bloombergResponseFileMapping;
	}
	
	
	
	private Map<String, String> getHeader(BufferedReader br) {
		
		Map<String, String> header = new HashMap<String, String>();
		
		// leggo riga per riga
		String line = null;
		try {
			
			// pointer at beginning of file
			br.reset();
			
			line = br.readLine();
			// 
			while(!line.equalsIgnoreCase("START-OF-FILE")) {
				line = br.readLine();
			}
			
			line = br.readLine(); // prima riga dell'header section
			while(!line.equalsIgnoreCase("START-OF-FIELDS")) {
				if(!isCommentOrEmptyLine(line)) {
					
					header.put((line.split("="))[0].trim(), (line.split("="))[1].trim());
				}
				
				line = br.readLine();
			}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return header;
	}
	
	private List<String> getFields(BufferedReader br) {
		
		List<String> fields = new ArrayList<String>();
		
		// leggo riga per riga
		String line = null;
		try {
			
			// pointer at beginning of file
			br.reset();
			

			line = br.readLine();
			// 
			while(!line.equalsIgnoreCase("START-OF-FIELDS")) {
				line = br.readLine();
			}
			
			line = br.readLine(); // prima riga della fields section
			while(!line.equalsIgnoreCase("END-OF-FIELDS")) {
				if(!isCommentOrEmptyLine(line)) {
					fields.add(line.trim());
				}
				
				line = br.readLine();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return fields;
	}
	
	private Object getTimeStarted(BufferedReader br) {
		
		Object timeStarted = null;
		
		String line = null;
		try {
			
			// pointer at beginning of file
			br.reset();
			
			line = br.readLine();
			while(!line.startsWith("TIMESTARTED")) {
				line = br.readLine();
			}
			//
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		timeStarted = line != null ? (line.split("="))[1].trim() : null;
		
		
		return timeStarted;
	}
	
	private List<Object[]> getData(BufferedReader br) {
		
		List<Object[]> data = new ArrayList<Object[]>();
		
		// leggo riga per riga
		String line = null;
		try {
			
			// pointer at beginning of file
			br.reset();
			
			line = br.readLine();
			while(!line.startsWith("START-OF-DATA")) {
				line = br.readLine();
			}
			
			line = br.readLine(); // prima riga della data section
			while(!line.startsWith("END-OF-DATA")) {
				if(!isCommentOrEmptyLine(line)) {
					
					Object[] temp = line.split("\\|");
					
					for(Object obj : temp) {
						obj = ((String)obj).trim();
					}
					
					data.add(temp);
				}
				
				line = br.readLine();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return data;
	}
	
	private Object getTimeFinished(BufferedReader br) {

		Object timeFinished = null;
		
		String line = null;
		try {
			line = br.readLine();
			
			while(!line.startsWith("TIMEFINISHED")) {
				line = br.readLine();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//
		timeFinished = line != null ? (line.split("="))[1].trim() : null;
		
		
		return timeFinished;
	}
	
	
	private boolean isCommentOrEmptyLine(String line) {
		
		return (line.startsWith("#")) || (line.trim().length() == 0);
	}
	
	
	
}
