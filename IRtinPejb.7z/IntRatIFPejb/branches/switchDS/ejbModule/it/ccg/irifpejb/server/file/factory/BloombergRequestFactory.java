package it.ccg.irifpejb.server.file.factory;

import it.ccg.irifpejb.server.file.parser.BloombergRequestParser;
import it.ccg.irifpejb.server.file.template.BloombergRequestTemplate;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

public class BloombergRequestFactory {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	public BloombergRequestFactory() throws Exception {
		
	}
	
	
	/*public void createRequestFile(BBGRequestType requestType, File outputFile, List<InstrEntity> instrList) throws Exception {
		
		if(requestType == BBGRequestType.CURR_REQUEST) {
			
			this.createCurrRequestFile(outputFile, instrList);
		}
		else if(requestType == BBGRequestType.NIR_REQUEST) {
			
			this.createNirRequestFile(outputFile, instrList);
		}
		else {
			
			logger.error(new StandardLogMessage("Invalid Reuters request type \'" + requestType + "\'."));
			
			throw new Exception("Invalid Reuters request type \'" + requestType + "\'.");
		}
		
	}
	
	
	private void createCurrRequestFile(File outputFile, List<InstrEntity> instrList) throws Exception {
		
		// headers
		Map<String, String>headers = new HashMap<String, String>();
		headers.put("FIRMNAME", "dl782252");
		headers.put("FILETYPE", "pc");
		headers.put("CLOSINGVALUES", "yes");
		headers.put("DATEFORMAT", "yyyymmdd");
		headers.put("PROGRAMFLAG", "daily");
		headers.put("PROGRAMNAME", "getdata");
		
		// fields
		List<String> fields = new ArrayList<String>();
		fields.add("PX_LAST");
		fields.add("PX_CLOSE_DT");
		
		// securities
		List<String> securities = new ArrayList<String>();
		for(InstrEntity instrEntity : instrList) {
			securities.add(instrEntity.getBloombergCode());
		}
		
		BloombergRequestTemplate bloombergRequestTemplate = new BloombergRequestTemplate(headers, fields, securities);
		
		
		// write
		this.writeDocumentToFile(bloombergRequestTemplate, outputFile);
	}
	
	
	private void createNirRequestFile(File outputFile, List<InstrEntity> instrList) throws Exception {
		
		// headers
		Map<String, String>headers = new HashMap<String, String>();
		headers.put("FIRMNAME", "dl782252");
		headers.put("FILETYPE", "pc");
		headers.put("CLOSINGVALUES", "yes");
		headers.put("DATEFORMAT", "yyyymmdd");
		headers.put("PROGRAMFLAG", "daily");
		headers.put("PROGRAMNAME", "getdata");
		
		// fields
		List<String> fields = new ArrayList<String>();
		fields.add("PX_LAST");
		fields.add("LAST_UPDATE_DT");
		
		// securities
		List<String> securities = new ArrayList<String>();
		for(InstrEntity instrEntity : instrList) {
			securities.add(instrEntity.getBloombergCode());
		}
		
		BloombergRequestTemplate bloombergRequestTemplate = new BloombergRequestTemplate(headers, fields, securities);
		
		
		// write
		this.writeDocumentToFile(bloombergRequestTemplate, outputFile);
	}
	
	
	public void addInstrument(File file, InstrEntity instrEntity) throws Exception {
		
		String bbgCode = instrEntity.getBloombergCode();
		
		if(exists(file, bbgCode)) {
			
			logger.error(new StandardLogMessage("Instrument having bbgCode=\'" + bbgCode + "\' yet in \'" + file.getName() + "\'."));
			
			throw new Exception("Instrument having bbgCode=\'" + bbgCode + "\' yet in \'" + file.getName() + "\'.");
		}
		
		BloombergRequestTemplate bloombergRequestTemplate = this.loadDocumentFromFile(file);
		
		List<String> securities = bloombergRequestTemplate.getSecurities();
		securities.add(bbgCode);
		
		bloombergRequestTemplate.setSecurities(securities);
		
		this.writeDocumentToFile(bloombergRequestTemplate, file);
	}
	
	
	public void removeInstrument(File file, InstrEntity instrEntity) throws Exception {
		
		String bbgCode = instrEntity.getBloombergCode();
		
		if(!exists(file, bbgCode)) {
			
			logger.error(new StandardLogMessage("Instrument having bbgCode=\'" + bbgCode + "\' not exists in \'" + file.getName() + "\'."));
			
			throw new Exception("Instrument having bbgCode=\'" + bbgCode + "\' not exists in \'" + file.getName() + "\'.");
		}
		
		BloombergRequestTemplate bloombergRequestTemplate = this.loadDocumentFromFile(file);
		
		List<String> securities = bloombergRequestTemplate.getSecurities();
		securities.remove(bbgCode);
		
		bloombergRequestTemplate.setSecurities(securities);
		
		this.writeDocumentToFile(bloombergRequestTemplate, file);
	}
	
	
	
	private boolean exists(File file, String bbgCode) throws Exception {
		boolean exist = false;
		
		BloombergRequestTemplate bloombergRequestTemplate = this.loadDocumentFromFile(file);
		
		if(bloombergRequestTemplate.getSecurities().contains(bbgCode)) {
			
			exist = true;
		}
		
	    return exist;
	}
	
	
	private BloombergRequestTemplate loadDocumentFromFile(File file) throws Exception {
		
		BloombergRequestParser bloombergRequestParser = new BloombergRequestParser();
		
		return bloombergRequestParser.parse(file);
	}
	
	
	private void writeDocumentToFile(BloombergRequestTemplate template, File file) throws Exception {
		
		BufferedWriter bw = null;
		
		try {
			bw = new BufferedWriter(new PrintWriter(file));
			
			bw.write(template.getAsFileFormattedString());
		}
		catch(Exception e) {
			
			logger.error(new StandardLogMessage(e.toString()));
			
			throw new Exception(e.toString());
		}
		finally {
			if(bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		}
	}
	*/

}
