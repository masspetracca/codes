package it.ccg.irifpejb.server.bean.business;


import javax.ejb.Local;

@Local
public interface ReutersBatchBeanLocal {
	
	public void nodeInterestRatesBatch() throws Exception;
	public void futureClosePriceBatch() throws Exception;
	
	public void collateralBatch() throws Exception;
	
}

