package it.ccg.irifpejb.server.security;

import java.util.List;

public interface SessionManagerLocal {
	
	public void addLoggedUser(String userName, String sessionId) throws Exception;
	public void removeLoggedUser(String userName) throws Exception;
	
	public String getCurrentUser() throws Exception;
	public String getCurrentUserSessionId() throws Exception;
	public List<String> getCurrentUserRoles() throws Exception;
	
	public List<String> listLoggedUsers() throws Exception;
	
}
