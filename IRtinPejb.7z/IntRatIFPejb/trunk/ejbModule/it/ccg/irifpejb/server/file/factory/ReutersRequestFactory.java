package it.ccg.irifpejb.server.file.factory;


import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class ReutersRequestFactory {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	public ReutersRequestFactory() throws Exception {
		
	}
	
	
	/*public void createRequestFile(RTRRequestType requestType, File outputFile, List<InstrEntity> instrList) throws Exception {
		
		String inputListName = new String();
		
		if(requestType == RTRRequestType.NIR_REQUEST) {
			
			inputListName = "IRNodes";
		}
		else if (requestType == RTRRequestType.FUTCP_REQUEST) {
			
			inputListName = "FCPList";
		}
		else {
			
			logger.error(new StandardLogMessage("Invalid Reuters request type \'" + requestType + "\'."));
			
			throw new Exception("Invalid Reuters request type \'" + requestType + "\'.");
		}
		
		
		Document document = this.createNewEmptyDocument();
		
		// create the root element
		Element rootElement = document.createElement("ReportRequest");
		rootElement.setAttribute("xmlns", "http://www.reuters.com/Datascope/ReportRequest.xsd");
		document.appendChild(rootElement);
		
		//
		Element inputListElement = document.createElement("InputList");
		rootElement.appendChild(inputListElement);
		
			//
			Element inputListActionElement = document.createElement("InputListAction");
			Text inputListActionText = document.createTextNode("Replace");
			inputListActionElement.appendChild(inputListActionText);
		
		inputListElement.appendChild(inputListActionElement);
		
			// input list name
			Element nameElement = document.createElement("Name");
			Text nameText = document.createTextNode(inputListName);
			nameElement.appendChild(nameText);
		
		inputListElement.appendChild(nameElement);
		
		
		//
		for(InstrEntity instrEntity : instrList) {
			Element instrElement = createInstrumentElement(document, instrEntity);
			
			inputListElement.appendChild(instrElement);
		}
		
		// write to file
		this.writeDocumentToFile(document, outputFile);
	}
	
	
	public void addInstrument(File file, InstrEntity instrEntity) throws Exception {
		
		String ricCode = instrEntity.getReutersIdentifierCode();
		
		if(this.exists(file, ricCode)) {
			
			logger.error(new StandardLogMessage("Instrument having ricCode=\'" + ricCode + "\' yet in \'" + file.getName() + "\'."));
			
			throw new Exception("Instrument having ricCode=\'" + ricCode + "\' yet in \'" + file.getName() + "\'.");
		}
		
		Document document = this.loadDocumentFromFile(file);
		
		NodeList inputListNodeList = document.getElementsByTagName("InputList");
		Node inputListElement = inputListNodeList.item(0);
		
		Element instrElement = createInstrumentElement(document, instrEntity);
		
		inputListElement.appendChild(instrElement);
		
		
		this.writeDocumentToFile(document, file);
	}
	
	
	public void removeInstrument(File file, InstrEntity instrEntity) throws Exception {
		
		String ricCode = instrEntity.getReutersIdentifierCode();
		
		if(!this.exists(file, ricCode)) {
			
			logger.error(new StandardLogMessage("Instrument having ricCode=\'" + ricCode + "\' not exists in \'" + file.getName() + "\'."));
			
			throw new Exception("Instrument having ricCode=\'" + ricCode + "\' not exists in \'" + file.getName() + "\'.");
		}
		
		Document document = this.loadDocumentFromFile(file);
		
		Element rootElement = document.getDocumentElement();
		
		NodeList identifierNodeList = rootElement.getElementsByTagName("Identifier");
		
		if(identifierNodeList != null && identifierNodeList.getLength() > 0) {
			
			for(int i = 0 ; i < identifierNodeList.getLength(); i++) {
				Node node = identifierNodeList.item(i);
				
				if(node.getTextContent().equalsIgnoreCase(ricCode)) {
					Node instrumentNode = node.getParentNode();
					Node inputListNode = instrumentNode.getParentNode();
					
					inputListNode.removeChild(instrumentNode);
					
					break;
				}
				else {
					continue;
				}
			}
		}
		
		this.writeDocumentToFile(document, file);
	}
	
	
	private Document createNewEmptyDocument() throws Exception {
		Document document = null;
		
		try {
			
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			documentBuilderFactory.setNamespaceAware(true);
			documentBuilderFactory.setValidating(true);
			
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			
			document = documentBuilder.newDocument();
			
			
		}
		catch(ParserConfigurationException e) {
			
			logger.error(new StandardLogMessage(e.toString()));
			
			throw e;
		}
		
		return document;
	}
	
	
	private Element createInstrumentElement(Document document, InstrEntity instrEntity) throws Exception {
		
		//
		Element instrumentElement = document.createElement("Instrument");
		
			//
			Element identifierTypeElement = document.createElement("IdentifierType");
			Text identifierTypeText = document.createTextNode("RIC");
			identifierTypeElement.appendChild(identifierTypeText);
	
			Element identifierElement = document.createElement("Identifier");
			Text identifierText = document.createTextNode(instrEntity.getReutersIdentifierCode());
			identifierElement.appendChild(identifierText);
			
			Element descriptionElement = document.createElement("Description");
			Text descriptionText = document.createTextNode(instrEntity.getInstrumentName());
			descriptionElement.appendChild(descriptionText);
		
		
		instrumentElement.appendChild(identifierTypeElement);
		instrumentElement.appendChild(identifierElement);
		instrumentElement.appendChild(descriptionElement);
		
		
		return instrumentElement;
	}
	
	private boolean exists(File file, String ricCode) throws Exception {
		boolean exist = false;

		Document document = this.loadDocumentFromFile(file);
		
		Element rootElement = document.getDocumentElement();
		
		NodeList identifierNodeList = rootElement.getElementsByTagName("Identifier");
		
		if(identifierNodeList != null && identifierNodeList.getLength() > 0) {
			
			for(int i=0 ; i<identifierNodeList.getLength(); i++) {
				Node node = identifierNodeList.item(i);
				if(node.getTextContent().equalsIgnoreCase(ricCode)) {
					exist = true;
					break;
				}
				else {
					continue;
				}
			}
		}
		
	    return exist;
	}
	
	private Document loadDocumentFromFile(File file) throws Exception {
		try {
			
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(file.getAbsolutePath());
			
			return document;
		}
		catch(Exception e) {
			
			logger.error(new StandardLogMessage(e.toString()));
			
			throw new Exception(e.toString());
		}
	}
	
	private void writeDocumentToFile(Document document, File file) throws Exception {
		try {
			
			OutputFormat outputFormat = new OutputFormat(document);
			outputFormat.setIndenting(true);

			//to generate output to console use this serializer
			//XMLSerializer serializer = new XMLSerializer(System.out, format);
			
			XMLSerializer serializer = new XMLSerializer(new FileOutputStream(file), outputFormat);
			serializer.serialize(document);
		}
		catch(Exception e) {
			
			logger.error(new StandardLogMessage(e.toString()));
			
			throw new Exception(e.toString());
		}
	}
	*/

}

