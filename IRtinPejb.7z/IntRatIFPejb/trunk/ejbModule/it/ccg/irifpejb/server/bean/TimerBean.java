package it.ccg.irifpejb.server.bean;


import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.server.system.LocalBeanLookup;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.log4j.Logger;



/**
 * Session Bean implementation class BloombergTimerBean
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class TimerBean implements TimerBeanLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	//private static final Logger monitorLogger = LoggerFactory.getLogger(LoggerFactory.MONITOR_LOGGER);
	
	
	@Resource
	private TimerService timerService;
	
	
    /**
     * Default constructor. 
     */
    public TimerBean() {
    	
    }
    
    
	@Override
	public TimerDTO createTimer(TimerDTO timerDTO) throws Exception {
		
		TimerDTO result = null;
		
		if(this.getTimer(timerDTO.getName()) != null) {
			logger.error("Duplicate timer name.");
			
			return null;
		}
		
		result = (TimerDTO)(this.timerService.createTimer(timerDTO.getStartDateTime(), timerDTO.getInterval(), timerDTO)).getInfo();
		
		
		logger.info(new StandardLogMessage("Timer \'" + timerDTO.getName() + "\' created."));
		
		
		return result;
	}
	
	
	@Override
	public TimerDTO createSingleActionTimer(TimerDTO timerDTO) throws Exception {
		
		TimerDTO result = null;
		
		if(this.getTimer(timerDTO.getName()) != null) {
			logger.error("Duplicate timer name.");
			
			return null;
		}
		
		result = (TimerDTO)(this.timerService.createTimer(timerDTO.getStartDateTime(), timerDTO)).getInfo();
		
		
		logger.info(new StandardLogMessage("Timer \'" + timerDTO.getName() + "\' created."));
		
		
		return result;
	}
	
	
	@Override
	public void deleteTimer(String timerName) throws Exception {
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = this.timerService.getTimers();
    	for(Timer timer : collection) {
    		if(((String)((TimerDTO)timer.getInfo()).getName()).equals(timerName)) {
    			
    			timer.cancel();
    			
    			logger.info(new StandardLogMessage("Timer \'" + timerName + "\' deleted."));
    		}
    	}
	}
	
	
	@Override
	public void deleteAllTimers() throws Exception {
		
		while(this.timerService.getTimers().iterator().hasNext()) {
			
			Timer timer = (Timer)this.timerService.getTimers().iterator().next();
			
			String timerName = ((TimerDTO)timer.getInfo()).getName();
			
			timer.cancel();
    		
			
    		logger.info(new StandardLogMessage("Timer \'" + timerName + "\' deleted."));
    	}
		
	}
	

	@Override
	public TimerDTO getTimer(String timerName) throws Exception {
		
		TimerDTO timerDTO = null;
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = this.timerService.getTimers();
    	
    	for(Timer timer : collection) {
    		if(((String)((TimerDTO)timer.getInfo()).getName()).equals(timerName)) {
    			
    			timerDTO = (TimerDTO)timer.getInfo();
    		}
    	}
		
    	
    	
		return timerDTO;
	}
	

	@Override
	public List<TimerDTO> getAllTimers() throws Exception {
		
		List<TimerDTO> list = new ArrayList<TimerDTO>();
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = this.timerService.getTimers();
    	
    	for(Timer timer : collection) {
    		
    		if (timer.getInfo() instanceof SchedulerDTO){
    			SchedulerDTO schedulerDTO = (SchedulerDTO)timer.getInfo();
    			list.add(schedulerDTO);
    		}else{
    			TimerDTO timerDTO = (TimerDTO)timer.getInfo();
    			list.add(timerDTO);
    		}
    		
    		//list.add(timerDTO);
    	}
		
    	
		return list;
	}
	
	
	
	@Timeout
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void timeout(Timer timer) {
		
		try {
			
			if (timer.getInfo() instanceof SchedulerDTO){
				Calendar calendar = GregorianCalendar.getInstance();
				SchedulerDTO schedulerDTO = (SchedulerDTO)timer.getInfo();
				logger.info(new StandardLogMessage("Scheduler \'" + schedulerDTO.getName()));
				
				if (schedulerDTO.isOnMonthStar()){
					logger.info(new StandardLogMessage("Scheduler \'" + schedulerDTO.getName()+" is on month start"));
					int currentDay = calendar.get(GregorianCalendar.DAY_OF_MONTH);
					if (currentDay == 1){
						JobDTO jobDTO = schedulerDTO.getJobDTO();
						String methodName = jobDTO.getMethodName();
						Class<?> methodClass = jobDTO.getMethodClass();			
						
						Method method = methodClass.getMethod(methodName, (Class<?>[])null);
						
						// class is an EJB interface
						Object classInstance = LocalBeanLookup.lookup(methodClass.getCanonicalName());
						
						method.invoke(classInstance, (Object[])null);
					}
				}else if(schedulerDTO.isOnMonthEnd()){
					logger.info(new StandardLogMessage("Scheduler \'" + schedulerDTO.getName()+" is on month end"));
					
					int currentMonth = calendar.get(GregorianCalendar.MONTH);
					logger.debug(new StandardLogMessage("current month: "+currentMonth));
					calendar.add(Calendar.DATE, 1);
					int calculatedMonth = calendar.get(GregorianCalendar.MONTH);
					logger.debug(new StandardLogMessage("calculated month: "+calculatedMonth));
					if ((calculatedMonth > currentMonth && currentMonth != 11) || (currentMonth == 11 && calculatedMonth == 0)){
						
						JobDTO jobDTO = schedulerDTO.getJobDTO();
						String methodName = jobDTO.getMethodName();
						Class<?> methodClass = jobDTO.getMethodClass();			
						
						Method method = methodClass.getMethod(methodName, (Class<?>[])null);
						
						// class is an EJB interface
						Object classInstance = LocalBeanLookup.lookup(methodClass.getCanonicalName());
						
						method.invoke(classInstance, (Object[])null);
					}
				}else if(schedulerDTO.getDayOfWeek()> -1){
					logger.info(new StandardLogMessage("Scheduler \'" + schedulerDTO.getName()+" is on day of week"));
					
					int currentWeekDay = calendar.get(GregorianCalendar.DAY_OF_WEEK);
					
					if (currentWeekDay == schedulerDTO.getDayOfWeek()){
						
						JobDTO jobDTO = schedulerDTO.getJobDTO();
						String methodName = jobDTO.getMethodName();
						Class<?> methodClass = jobDTO.getMethodClass();			
						
						Method method = methodClass.getMethod(methodName, (Class<?>[])null);
						
						// class is an EJB interface
						Object classInstance = LocalBeanLookup.lookup(methodClass.getCanonicalName());
						
						method.invoke(classInstance, (Object[])null);
					}
				}else if(schedulerDTO.getDayOfMonth() > -1){
					logger.info(new StandardLogMessage("Scheduler \'" + schedulerDTO.getName()+" is on day of month"));
					
					int currentMonthDay = calendar.get(GregorianCalendar.DAY_OF_MONTH);
					
					if (currentMonthDay == schedulerDTO.getDayOfMonth()){
						
						JobDTO jobDTO = schedulerDTO.getJobDTO();
						String methodName = jobDTO.getMethodName();
						Class<?> methodClass = jobDTO.getMethodClass();			
						
						Method method = methodClass.getMethod(methodName, (Class<?>[])null);
						
						// class is an EJB interface
						Object classInstance = LocalBeanLookup.lookup(methodClass.getCanonicalName());
						
						method.invoke(classInstance, (Object[])null);
					}
				}
			}else{
				TimerDTO timerDTO = (TimerDTO)timer.getInfo();
				
				logger.info(new StandardLogMessage("Timer \'" + timerDTO.getName() + "\' expired."));
				
				JobDTO jobDTO = timerDTO.getJobDTO();
				String methodName = jobDTO.getMethodName();
				Class<?> methodClass = jobDTO.getMethodClass();			
				
				Method method = methodClass.getMethod(methodName, (Class<?>[])null);
				
				// class is an EJB interface
				Object classInstance = LocalBeanLookup.lookup(methodClass.getCanonicalName());
				
				method.invoke(classInstance, (Object[])null);
			}
		}
		catch(Exception e) {
			// *** IMPORTANT ***
			// At this point, whatever exception type results as InvocationTargetException with no message.
			// For error details, it is necessary to log at job method level.
			ExceptionUtil.logCompleteStackTrace(logger, e);
		}
		
	}
	
	
}
