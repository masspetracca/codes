package it.ccg.irifpejb.server.ftp;

import it.ccg.irifpejb.server.exception.FTPException;

import java.io.File;

import org.apache.commons.net.ftp.FTPFile;

public interface FTPServiceInterface {
	
	public FTPFile getResponseFileInfo(String fileName) throws FTPException;
	public FTPFile[] getResponseFilesInfo() throws FTPException;
	
	public void downloadResponseFile(String fileName, File outputFile) throws FTPException;
	public void downloadRequestFile(String fileName, File outputFile) throws FTPException;
	public void uploadRequestFile(String fileName, File inputFile)throws FTPException;
	
	public boolean responseFileIsPresent(String fileName) throws FTPException;
	public boolean requestFileIsPresent(String fileName) throws FTPException;

}
