package it.ccg.irifpejb.server.bean;


import java.io.Serializable;
import java.util.Date;


public class TimerDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4532042410246488052L;
	
	
	protected String name;
	protected boolean isSingle;
	protected boolean isScheduler;
	protected Date startDateTime;
	protected long interval;
	protected String provider;
	protected JobDTO jobDTO;
	
	
	public TimerDTO() {
		
	}
	
	public TimerDTO(String name, boolean isSingle, Date startDateTime, long interval, String provider, JobDTO jobDTO) {
		this.name = name;
		this.isSingle = isSingle;
		this.startDateTime = startDateTime;
		this.interval = interval;
		this.provider = provider;
		this.jobDTO = jobDTO;
	}
	
	public TimerDTO(String name, boolean isSingle, Date startDateTime, String provider, JobDTO jobDTO) {
		this.name = name;
		this.isSingle = isSingle;
		this.startDateTime = startDateTime;
		this.provider = provider;
		this.jobDTO = jobDTO;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(Date startDateTime) {
		this.startDateTime = startDateTime;
	}

	public long getInterval() {
		return interval;
	}

	public void setInterval(long interval) {
		this.interval = interval;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public JobDTO getJobDTO() {
		return jobDTO;
	}

	public void setJobDTO(JobDTO jobDTO) {
		this.jobDTO = jobDTO;
	}

	/**
	 * @return the isSingle
	 */
	public boolean getIsSingle() {
		return isSingle;
	}

	/**
	 * @param isSingle the isSingle to set
	 */
	public void setSingle(boolean isSingle) {
		this.isSingle = isSingle;
	}

	/**
	 * @return the isScheduler
	 */
	public boolean getIsScheduler() {
		return isScheduler;
	}

	/**
	 * @param isScheduler the isScheduler to set
	 */
	public void setScheduler(boolean isScheduler) {
		this.isScheduler = isScheduler;
	}
}
