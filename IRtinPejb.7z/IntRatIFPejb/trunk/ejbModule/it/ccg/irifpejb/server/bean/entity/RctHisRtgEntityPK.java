package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the RCTHISRTG database table.
 * 
 */
@Embeddable
public class RctHisRtgEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false, length=20)
	private String bloombCode;

	@Column(unique=true, nullable=false)
	private int rtgDate;

	@Column(unique=true, nullable=false)
	private int rtgTime;

    public RctHisRtgEntityPK() {
    }
	public String getBloombCode() {
		return this.bloombCode;
	}
	public void setBloombCode(String bloombCode) {
		this.bloombCode = bloombCode;
	}
	public int getRtgDate() {
		return this.rtgDate;
	}
	public void setRtgDate(int rtgDate) {
		this.rtgDate = rtgDate;
	}
	public int getRtgTime() {
		return this.rtgTime;
	}
	public void setRtgTime(int rtgTime) {
		this.rtgTime = rtgTime;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RctHisRtgEntityPK)) {
			return false;
		}
		RctHisRtgEntityPK castOther = (RctHisRtgEntityPK)other;
		return 
			this.bloombCode.equals(castOther.bloombCode)
			&& (this.rtgDate == castOther.rtgDate)
			&& (this.rtgTime == castOther.rtgTime);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.bloombCode.hashCode();
		hash = hash * prime + this.rtgDate;
		hash = hash * prime + this.rtgTime;
		
		return hash;
    }
}