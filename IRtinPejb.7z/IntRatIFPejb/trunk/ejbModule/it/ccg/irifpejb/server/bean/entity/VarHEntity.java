package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the RCTVARH database table.
 * 
 */
@Entity
@Table(name="RCTVARH")
@NamedNativeQueries({
	@NamedNativeQuery(name="refreshVarHView", query="REFRESH TABLE RCMVARH")
})
public class VarHEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private VarHEntityPK id;
	
	@Column(nullable=false)
	private int audqualflg;

	@Column(nullable=false)
	private int dataflag;

	@Column(nullable=false)
	private int periodleng;

	@Column(nullable=false)
	private int periodtype;

	private int pfileid;

	@Column(nullable=false)
	private Timestamp upddate = new Timestamp(System.currentTimeMillis());

	@Column(length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

	@Column(precision=15, scale=8)
	private BigDecimal varvalue;
	
	/*@ManyToOne
	private VarsEntity rctvar;*/

    public VarHEntity() {
    }

	public VarHEntityPK getId() {
		return this.id;
	}

	public void setId(VarHEntityPK id) {
		this.id = id;
	}
	
	public int getAudqualflg() {
		return this.audqualflg;
	}

	public void setAudqualflg(int audqualflg) {
		this.audqualflg = audqualflg;
	}

	public int getDataflag() {
		return this.dataflag;
	}

	public void setDataflag(int dataflag) {
		this.dataflag = dataflag;
	}

	public int getPeriodleng() {
		return this.periodleng;
	}

	public void setPeriodleng(int periodleng) {
		this.periodleng = periodleng;
	}

	public int getPeriodtype() {
		return this.periodtype;
	}

	public void setPeriodtype(int periodtype) {
		this.periodtype = periodtype;
	}
	
	public int getPfileid() {
		return this.pfileid;
	}

	public void setPfileid(int pfileid) {
		this.pfileid = pfileid;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

	public BigDecimal getVarvalue() {
		return this.varvalue;
	}

	public void setVarvalue(BigDecimal varvalue) {
		this.varvalue = varvalue;
	}
	
	/*public VarsEntity getRctvar() {
		return rctvar;
	}
	
	public void setRctvar(VarsEntity rctvar) {
		this.rctvar = rctvar;
	}*/
	
	
	@Override
	public String toString() {
		
		return "[FITCHNAME: " + this.id.getFitchnname() + ", VARID: " + this.id.getVarid() + ", DATE: " + this.id.getValuedate() + ", VALUE: " + this.varvalue + "]";
	}

}