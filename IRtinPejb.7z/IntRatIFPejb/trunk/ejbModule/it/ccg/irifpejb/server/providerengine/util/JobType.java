package it.ccg.irifpejb.server.providerengine.util;

public enum JobType {
	
	RES_DOWNLOAD("res-download"),
	REQ_ALIGN_CHECK("req-align-check"),
	REQ_ALIGN("req-align");
	
	
	private final String jobType;
	
	
	private JobType(String jobType) {
		
		this.jobType = jobType;
	}
	
	
	public String getJobType() {
		return jobType;
	}
	
}
