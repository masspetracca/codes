package it.ccg.irifpejb.server.bean.business;

public interface BloombergManagerBeanLocal {

	public void checkBankAlignment() throws Exception;
	public void alignBankRequest() throws Exception;
	
}
