package it.ccg.irifpejb.server.bean.eao;

import java.sql.Timestamp;
import java.util.Date;

import it.ccg.irifpejb.server.bean.entity.RctBnkFtctEntity;
import it.ccg.irifpejb.server.bean.entity.RctBnkFtctEntityPK;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BnkEAO
 */
@Stateless
@Local(BnkEAOLocal.class)
public class BnkEAO implements BnkEAOLocal {
	
	
	@PersistenceContext(unitName="IntRatIFPejb", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Resource
	private SessionContext sessionContext;
	
	
	private String tableName = ((Table)(RctBnkFtctEntity.class.getAnnotation(Table.class))).name();
	
    /**
     * Default constructor. 
     */
    public BnkEAO() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public RctBnkFtctEntity findByPrimaryKey(String fitchnickname,int fitchcode) throws Exception {
		
		RctBnkFtctEntityPK pk = new RctBnkFtctEntityPK();
		pk.setFitchCode(fitchcode);
		pk.setFitchNName(fitchnickname);
		
		return (RctBnkFtctEntity)this.em.find(RctBnkFtctEntity.class, pk);
	}

	@Override
	public void add(RctBnkFtctEntity e) throws Exception {
		
		// set current user
		e.setUpdUsr(this.sessionContext.getCallerPrincipal().getName());
		// set updtype
		e.setUpdType("C");
		e.setUpdDate(new Timestamp(new Date().getTime()));
		em.persist(e);
		
		logger.info(new StandardLogMessage("Persisted data into \'" + this.tableName + "\'. " + e));
		
	}

}
