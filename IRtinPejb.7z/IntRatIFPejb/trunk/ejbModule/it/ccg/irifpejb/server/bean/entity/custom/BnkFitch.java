package it.ccg.irifpejb.server.bean.entity.custom;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Transient;
import java.sql.Timestamp;

/**
 * Entity implementation class for Entity: BnkFitch
 *
 */
@Entity

public class BnkFitch implements Serializable {

	
	private static final long serialVersionUID = 1L;
	@Transient
	private int fitchcode;
	@Transient
	private String fitchnname;
	@Transient
	private String isConsolid;
	@Transient
	private String accountSys;
	@Transient
	private Timestamp latestPer;
	
	public BnkFitch() {
		super();
	}
	
	public BnkFitch(int fCode, String fName, String isCon,String accSys,Timestamp latestPer){
		this.fitchcode = fCode;
		this.fitchnname = fName;
		this.isConsolid = isCon;
		this.accountSys = accSys;
		this.latestPer = latestPer;
	}
	/**
	 * @return the isConsolid
	 */
	public String getIsConsolid() {
		return isConsolid;
	}

	/**
	 * @param isConsolid the isConsolid to set
	 */
	public void setIsConsolid(String isConsolid) {
		this.isConsolid = isConsolid;
	}

	/**
	 * @return the accountSys
	 */
	public String getAccountSys() {
		return accountSys;
	}

	/**
	 * @param accountSys the accountSys to set
	 */
	public void setAccountSys(String accountSys) {
		this.accountSys = accountSys;
	}

	/**
	 * @return the latestPer
	 */
	public Timestamp getLatestPer() {
		return latestPer;
	}

	/**
	 * @param latestPer the latestPer to set
	 */
	public void setLatestPer(Timestamp latestPer) {
		this.latestPer = latestPer;
	}

	/**
	 * @return the fitchcode
	 */
	public int getFitchcode() {
		return fitchcode;
	}

	/**
	 * @param fitchcode the fitchcode to set
	 */
	public void setFitchcode(int fitchcode) {
		this.fitchcode = fitchcode;
	}

	/**
	 * @return the fitchnname
	 */
	public String getFitchnname() {
		return fitchnname;
	}

	/**
	 * @param fitchnname the fitchnname to set
	 */
	public void setFitchnname(String fitchnname) {
		this.fitchnname = fitchnname;
	}
}
