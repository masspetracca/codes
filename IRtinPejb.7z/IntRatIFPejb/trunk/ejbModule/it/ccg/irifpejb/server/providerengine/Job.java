package it.ccg.irifpejb.server.providerengine;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="job")
@XmlAccessorType(XmlAccessType.FIELD)
public class Job {
	
	@XmlAttribute
	private String type;
	@XmlElement
	private String name;
	@XmlElement
	private String methodName;
	@XmlElement
	private String methodClass;
	@XmlElement
	private String description;
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	public String getMethodClass() {
		return methodClass;
	}
	public void setMethodClass(String methodClass) {
		this.methodClass = methodClass;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
	@Override
	public String toString() {
		
		return "[type: " + this.type + ", name: " + this.name + ", methodName: " + this.methodName + 
			  ", methodClass: " + this.methodClass + ", description: " + this.description + "]";
	}

}
