package it.ccg.irifpejb.server.providerengine;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="ProviderConfig")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProviderConfig {
	
	@XmlElement(name="provider")
	private List<Provider> providerList;
	
	
	public List<Provider> getProviderList() {
		return providerList;
	}
	
	public void setProviderList(List<Provider> providerList) {
		this.providerList = providerList;
	}
	
	
	@Override
	public String toString() {
		
		String toString = "[" + "\n";
		
		if(this.providerList != null) {
			for(Provider provider : this.providerList) {
				
				toString += "  " + provider.toString() + ",\n";
			}
		}
		toString = toString.substring(0, toString.length() - 2);
		
		toString += "\n" + "]";
		
		
		return toString;
	}
	
	
	
	// *** Query ***
	
	public Provider getProviderByName(String providerName) {
		
		Provider provider = null;
		
		for(Provider p : this.providerList) {
			
			if(p.getName().equalsIgnoreCase(providerName)) {
				
				provider = p;
				
				break;
			}
			
		}
		
		
		return provider;
	}
	
	
	

}
