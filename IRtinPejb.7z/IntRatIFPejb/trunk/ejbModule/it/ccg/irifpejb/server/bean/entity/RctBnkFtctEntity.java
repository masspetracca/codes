package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the RCTBNKFTCT database table.
 * 
 */
@Entity
@Table(name="RCTBNKFTCT")
public class RctBnkFtctEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RctBnkFtctEntityPK id;

	@Column(nullable=false, length=200)
	private String accountSys;

	@Column(nullable=false, length=1)
	private String isConsolid;

	@Column(nullable=false)
	private Timestamp latestPer;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=30)
	private String updUsr;

    public RctBnkFtctEntity() {
    }

	public RctBnkFtctEntityPK getId() {
		return this.id;
	}

	public void setId(RctBnkFtctEntityPK id) {
		this.id = id;
	}
	
	public String getAccountSys() {
		return this.accountSys;
	}

	public void setAccountSys(String accountSys) {
		this.accountSys = accountSys;
	}

	public String getIsConsolid() {
		return this.isConsolid;
	}

	public void setIsConsolid(String isConsolid) {
		this.isConsolid = isConsolid;
	}

	public Timestamp getLatestPer() {
		return this.latestPer;
	}

	public void setLatestPer(Timestamp latestPer) {
		this.latestPer = latestPer;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUsr() {
		return this.updUsr;
	}

	public void setUpdUsr(String updUsr) {
		this.updUsr = updUsr;
	}

}