package it.ccg.irifpejb.server.file.parser;

import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.file.template.FitchResponseTemplate;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;

import au.com.bytecode.opencsv.CSVReader;

public class FitchResponseParser {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	
	public FitchResponseParser() throws Exception {
		
	}
	
	
	public FitchResponseTemplate parse(File dataFile, File codesFile) throws Exception {
		
		if(!dataFile.exists()) {
			
			logger.error(new StandardLogMessage("File \'" + dataFile.getAbsolutePath() + "\' not exists."));
			
			throw new Exception("File \'" + dataFile.getAbsolutePath() + "\' not exists.");
		}
		if(!codesFile.exists()) {
			
			logger.error(new StandardLogMessage("File \'" + codesFile.getAbsolutePath() + "\' not exists."));
			
			throw new Exception("File \'" + codesFile.getAbsolutePath() + "\' not exists.");
		}
		
		
		FitchResponseTemplate fitchResponseTemplate = null;
		BufferedReader br = null;
		
		try {	
			
			List<Object[]> dataList;
			List<Object[]> codesList;
			Object[] codesHeaders=null;
			
			CSVReader csvReader = null;
			Object[] record = null;
			
			// DATA FILE
			dataList = new ArrayList<Object[]>();
			csvReader = new CSVReader(new FileReader(dataFile));
			// salto la prima riga d'intestazione
			record = csvReader.readNext();
			while((record = csvReader.readNext()) != null) {
				
				for(int i=0; i<record.length; i++) {
					
					record[i] = new String(((String)record[i]).getBytes(), Charset.forName("UTF-16"));
				}
				
				if(record.length > 1) {
					
					dataList.add(record);
				}
				
			}
			csvReader.close();
			
			
			// CODES FILE
			codesList = new ArrayList<Object[]>();
			csvReader = new CSVReader(new FileReader(codesFile));
			// leggo la prima riga e la salvo per la ricerca successiva
						record = csvReader.readNext();
						for(int i = 0;i<record.length;i++){
							record[i]=new String(((String)record[i]).getBytes(), Charset.forName("UTF-16"));
						}
						codesHeaders = record;
						//procedo con il resto dei dati
			while((record = csvReader.readNext()) != null) {
				
				for(int i=0; i<record.length; i++) {
					record[i] = new String(((String)record[i]).getBytes(), Charset.forName("UTF-16"));
				}
				
				if(record.length > 1) {
					codesList.add(record);
				}
				
			}
			csvReader.close();
			
			
			
			// 
			fitchResponseTemplate = new FitchResponseTemplate(dataList, codesList,codesHeaders);
			
			
			
			/*for(Object[] r : fitchResponseTemplate.getData()) {
				
				System.out.println(ArrayUtils.toString(r) + " - size: " + r.length);
			}
			
			for(Object[] r : fitchResponseTemplate.getCodes()) {
				
				System.out.println(ArrayUtils.toString(r) + " - size: " + r.length);
			}*/
			
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		finally {
			if(br != null) {
				br.close();
			}
		}
		
		
		return fitchResponseTemplate;
	}
	
	

}
