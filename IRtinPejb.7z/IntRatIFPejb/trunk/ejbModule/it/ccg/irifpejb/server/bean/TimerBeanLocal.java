package it.ccg.irifpejb.server.bean;


import java.util.List;

import javax.ejb.Local;

@Local
public interface TimerBeanLocal {
	
	public TimerDTO createTimer(TimerDTO timerData) throws Exception;
	public TimerDTO createSingleActionTimer(TimerDTO timerData) throws Exception;
	
	public void deleteTimer(String name) throws Exception;
	public void deleteAllTimers() throws Exception;
	
	public TimerDTO getTimer(String name) throws Exception;
	public List<TimerDTO> getAllTimers() throws Exception;
	
}
