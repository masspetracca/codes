package it.ccg.irifpejb.server.file.template;

import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.system.SystemProperties;

import java.util.List;

import org.apache.log4j.Logger;

public class FitchResponseTemplate {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	List<Object[]> data;
	List<Object[]> codes;
	Object[] codesHeaders;
	int idxFNName,idxFCode,idxAccountSys,idxIsConsolid,idxlatestPer = -1;
	
	public FitchResponseTemplate(List<Object[]> data, List<Object[]> codes, Object[] headers) throws Exception {
		try {
			this.data = data;
			this.codes = codes;
			this.codesHeaders = headers;
			for (int i = 0;i<headers.length;i++){
				if(((String)headers[i]).equalsIgnoreCase(SystemProperties.getProperty("fNNane"))){
	    			idxFNName =i;
	    		} else if(((String)headers[i]).equalsIgnoreCase(SystemProperties.getProperty("fCode"))){
							idxFCode=i;
				}else if(((String)headers[i]).equalsIgnoreCase(SystemProperties.getProperty("fCode"))){
					idxFCode=i;
				}else if(((String)headers[i]).equalsIgnoreCase(SystemProperties.getProperty("accSys"))){
					idxAccountSys=i;
				}else if(((String)headers[i]).equalsIgnoreCase(SystemProperties.getProperty("isConsolid"))){
					idxIsConsolid=i;
				}else if(((String)headers[i]).equalsIgnoreCase(SystemProperties.getProperty("latestPeriod"))){
					idxlatestPer=i;
				}	
			}
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw e;
		}
	}
	
	
	public List<Object[]> getData() {
		return data;
	}
	
	public void setData(List<Object[]> data) {
		this.data = data;
	}
	
	public List<Object[]> getCodes() {
		return codes;
	}
	
	public void setCodes(List<Object[]> codes) {
		this.codes = codes;
	}
	
	/**
	 * @return the headers
	 */
	public Object[] getCodesHeaders() {
		return codesHeaders;
	}


	/**
	 * @return the idxFNName
	 */
	public int getIdxFNName() {
		return idxFNName;
	}


	/**
	 * @param idxFNName the idxFNName to set
	 */
	public void setIdxFNName(int idxFNName) {
		this.idxFNName = idxFNName;
	}


	/**
	 * @return the idxFCode
	 */
	public int getIdxFCode() {
		return idxFCode;
	}


	/**
	 * @param idxFCode the idxFCode to set
	 */
	public void setIdxFCode(int idxFCode) {
		this.idxFCode = idxFCode;
	}


	/**
	 * @return the idxAccountSys
	 */
	public int getIdxAccountSys() {
		return idxAccountSys;
	}


	/**
	 * @param idxAccountSys the idxAccountSys to set
	 */
	public void setIdxAccountSys(int idxAccountSys) {
		this.idxAccountSys = idxAccountSys;
	}


	/**
	 * @return the idxIsConsolid
	 */
	public int getIdxIsConsolid() {
		return idxIsConsolid;
	}


	/**
	 * @param idxIsConsolid the idxIsConsolid to set
	 */
	public void setIdxIsConsolid(int idxIsConsolid) {
		this.idxIsConsolid = idxIsConsolid;
	}


	/**
	 * @return the idxlatestPer
	 */
	public int getIdxlatestPer() {
		return idxlatestPer;
	}


	/**
	 * @param idxlatestPer the idxlatestPer to set
	 */
	public void setIdxlatestPer(int idxlatestPer) {
		this.idxlatestPer = idxlatestPer;
	}


	/**
	 * @param headers the headers to set
	 * @throws Exception 
	 */
	public void setCodesHeaders(Object[] headers) throws Exception {
		try {
			this.codesHeaders = headers;
			for (int i = 0;i<headers.length;i++){
				if(((String)headers[i]).equalsIgnoreCase(SystemProperties.getProperty("fNNane"))){
	    			idxFNName =i;
	    		} else if(((String)headers[i]).equalsIgnoreCase(SystemProperties.getProperty("fCode"))){
							idxFCode=i;
				}else if(((String)headers[i]).equalsIgnoreCase(SystemProperties.getProperty("fCode"))){
					idxFCode=i;
				}else if(((String)headers[i]).equalsIgnoreCase(SystemProperties.getProperty("accSys"))){
					idxAccountSys=i;
				}else if(((String)headers[i]).equalsIgnoreCase(SystemProperties.getProperty("isConsolid"))){
					idxIsConsolid=i;
				}else if(((String)headers[i]).equalsIgnoreCase(SystemProperties.getProperty("latestPeriod"))){
					idxlatestPer=i;
				}	
			}
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw e;
		}
	}
}
