package it.ccg.irifpejb.server.bean.business;

import it.ccg.irifpejb.server.bean.eao.BankEAOLocal;
import it.ccg.irifpejb.server.bean.eao.FileEAOLocal;
import it.ccg.irifpejb.server.bean.entity.BankEntity;
import it.ccg.irifpejb.server.bean.entity.RctHisRtgEntity;
import it.ccg.irifpejb.server.bean.entity.RctHisRtgEntityPK;
import it.ccg.irifpejb.server.exception.DuplicateKeyException;
import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.exception.NewDataNotAvailableException;
import it.ccg.irifpejb.server.file.parser.BloombergResponseParser;
import it.ccg.irifpejb.server.file.template.BloombergResponseTemplate;
import it.ccg.irifpejb.server.file.util.BloombergResponseFTPFileComparator;
import it.ccg.irifpejb.server.ftp.FTPFactory;
import it.ccg.irifpejb.server.ftp.FTPServiceInterface;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.server.providerengine.ProviderEngine;
import it.ccg.irifpejb.server.security.SecurityEjb;
import it.ccg.irifpejb.server.system.SystemProperties;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.log4j.Logger;

import com.bloomberg.datalic.api.BBDES;

/**
 * Session Bean implementation class BloombergBatchBean
 */
@Stateless
@Local(BloombergBatchBeanLocal.class)
public class BloombergBatchBean implements BloombergBatchBeanLocal {

	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	private static final Logger monitorLogger = LoggerFactory.getLogger(LoggerFactory.MONITOR_LOGGER);
	
	private static Properties properties;
	private FTPServiceInterface ftpServiceInterface;
	private static String TEMP_DIR_ABSOLUTE_PATH;
	
	private static String PROVIDER_NAME;
	private static String FLOW_BANK_NAME;
	private static String BANK_RESPONSE_ENC_FILE_NAME;
	private static String BANK_RESPONSE_DEC_FILE_NAME;
	
	private static String PATH_SEPARATOR;
	
	private static String DEC_KEY;
	
	@EJB
	private BankEAOLocal bankEAOLocal;
	
	@EJB
	private BaseBeanLocal baseEAOLocal;
	
	@EJB
	private FileEAOLocal fileEAOLocal;
	
	@EJB
	private BloombergManagerBeanLocal bloombergManagerBeanLocal;
	/**
     * Default constructor. 
     */
	 public BloombergBatchBean() throws Exception {
			
	    	try {
	    		
	    		properties = SystemProperties.getProperties();
	    		
	        	TEMP_DIR_ABSOLUTE_PATH = properties.getProperty("user.install.root") +
	    		  						 properties.getProperty("temp_dir_relative_path");
	        	
	        	PATH_SEPARATOR = properties.getProperty("file.separator");
	        	
	        	
	        	// provider engine IDs from properties file
	        	PROVIDER_NAME = properties.getProperty("provider.bloomberg.name");
	        	
	    		DEC_KEY = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getDataDecKey();
	    		
	    	}
	    	catch(Exception e) {
	    		
	    		logger.warn(new StandardLogMessage("Exception into bean constructor. Exception: " + e));
				ExceptionUtil.logCompleteStackTrace(logger, e);
				
				throw e;
			}
			
	    }

	@Override
	public void externaRatingBatch() throws Exception {
		// TODO Auto-generated method stub
		logger.info(new StandardLogMessage("Bloomberg BANK synchronization started."));
		try{
			/*
			 * check bloomberg request alignment
			 */
			try {
				this.bloombergManagerBeanLocal.checkBankAlignment();
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Bloomberg BANK request alignment check failed."));
				// default logger
				logger.warn(new StandardLogMessage("Bloomberg BANK request alignment check failed."));
			}
			
			FLOW_BANK_NAME = properties.getProperty("provider.bloomberg.flow.bank.name");
			BANK_RESPONSE_ENC_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_BANK_NAME).getResponseFileName();
	    	BANK_RESPONSE_DEC_FILE_NAME = BANK_RESPONSE_ENC_FILE_NAME + ".dec";
	
	    	// create temporary folder and files to work
			// ***************************************************************************************************************
			String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempEncFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + BANK_RESPONSE_ENC_FILE_NAME;
			
			if(!new File(tempEncFileAbsPath).createNewFile()) {
				
				throw new Exception("Unable to create temp file \'" + tempEncFileAbsPath + "\'.");
			}
			
			String tempDecFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + BANK_RESPONSE_DEC_FILE_NAME;
			
			if(!new File(tempDecFileAbsPath).createNewFile()) {
				
				throw new Exception("Unable to create temp file \'" + tempDecFileAbsPath + "\'.");
			}
			// ***************************************************************************************************************
			
			// get file from ftp and save it into tempEncFileAbsPath
			String fileName = this.getFileFromFTP(BANK_RESPONSE_ENC_FILE_NAME, new File(tempEncFileAbsPath));
			
			// decrypting
			this.decryptFile(tempEncFileAbsPath, tempDecFileAbsPath);
			
			//parse file
			BloombergResponseParser bloombergResponseParser = new BloombergResponseParser();
			BloombergResponseTemplate bloombergResponseTemplate = bloombergResponseParser.parse(new File(tempDecFileAbsPath));
			List<RctHisRtgEntity> ratingEntityList = this.convertRawDataToHRtgE(bloombergResponseTemplate);
			
			// persist data
			try {
				this.baseEAOLocal.persistHistoricalData(ratingEntityList);
			}
			catch(DuplicateKeyException e) {
				
				monitorLogger.warn(new StandardLogMessage("Bloomberg CURR batch - Duplicate key values found in new data."));
			}
			
			// save information about executed batch
			this.baseEAOLocal.saveJobInfo("Bloomberg", "Bloomberg BANK synchronization", fileName, tempDecFileAbsPath);
			
			// change status from oneShot to disable for each ex-oneShot instrument
			/*try {
				this.baseEAOLocal.updateOneShotToDisable(ratingEntityList);
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Bloomberg NIR batch - Unable to change ONESHOT to DISABLE."));
				// default logger
				logger.warn(new StandardLogMessage("Bloomberg NIR batch - Unable to change ONESHOT to DISABLE."));
				ExceptionUtil.logCompleteStackTrace(logger, e);
			}*/
			
			// align bloomberg request
			try {
				this.bloombergManagerBeanLocal.alignBankRequest();
			}
			catch(Exception e) {
				// monitor warning
				monitorLogger.warn(new StandardLogMessage("Bloomberg BANK request alignment failed."));
				// default logger
				logger.warn(new StandardLogMessage("Bloomberg BANK request alignment failed."));
				ExceptionUtil.logCompleteStackTrace(logger, e);
			}
			
			// monitor info
			monitorLogger.info(new StandardLogMessage("Bloomberg BANK synchronization successfully executed."));
			// default logger
			logger.info(new StandardLogMessage("Bloomberg BANK synchronization successfully executed."));
			
			// delete tempWorkingFolder
			this.baseEAOLocal.deleteTempWorkingFolder(tempWorkingFolder);
		}catch(NewDataNotAvailableException e){
			monitorLogger.info(new StandardLogMessage("Bloomberg BANK synchronization not executed: new data not available."));
			// default logger
			logger.info(new StandardLogMessage("Bloomberg BANK synchronization not executed: new data not available."));
		}
	}

	// get file from ftp and save it into tempFileAbsPath
    private String getFileFromFTP(String outType, File fileToSaveInto) throws Exception {
    	
    	String fileName = null;
    	
    	// initialize ftpService
		this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.BLOOMBERG_SERVICE);
		
		// compute file name to download
		FTPFile[] fileArray = this.ftpServiceInterface.getResponseFilesInfo();
		fileName = this.getOutTypeLastFileInfo(fileArray, outType).getName();
		
		// controllo file gi� scaricato / dati gi� scaricati
		if(this.fileEAOLocal.findByName(fileName) != null) {
			
			logger.warn(new StandardLogMessage("File \'" + fileName + "\' already downloaded. New data not available."));
			
			throw new NewDataNotAvailableException("File \'" + fileName + "\' already downloaded. New data not available.");
		}
		
		// download file
		this.ftpServiceInterface.downloadResponseFile(fileName, fileToSaveInto);
    	
		
		logger.info(new StandardLogMessage("File \'" + fileName + "\' successfully downloaded."));
		
		
		return fileName;
		
    }
    
    private FTPFile getOutTypeLastFileInfo(FTPFile[] fileArray, String outType) throws Exception {
		String prefix = outType + ".";
		Set<FTPFile> fileList = new TreeSet<FTPFile>(new BloombergResponseFTPFileComparator(prefix));
		
		for(FTPFile file : fileArray) {
			
			String fileName = file.getName();
			
			if(fileName.startsWith(prefix)) {
				// scarto tutti i file bbg_curr.out.yyyymmdd.n
				if(fileName.split("\\.").length > 3) {
					continue;
				}
				fileList.add(file);
			}
		}
		
		if(fileList.size() < 1) {
			throw new Exception(outType + " data not available on Bloomberg server.");
		}
		
		// prendo il primo, la lista � ordinata in modo decrescente secondo la data
		return ((FTPFile)fileList.toArray()[0]);
	}
    
	private void decryptFile(String encFileAbsPath, String decFileAbsPath) throws Exception {
		
		try {
			BBDES bbDes = new BBDES(DEC_KEY);
			bbDes.setuseCAPoption(true);
			bbDes.setuuencode(true);
			bbDes.decryptDES(encFileAbsPath, decFileAbsPath);
			
			logger.info(new StandardLogMessage("Decripting file successfully completed."));
		}
		catch(Exception e) {
			
			throw new Exception("File decrypting failed.");
		}
		
	}
	
	private List<RctHisRtgEntity> convertRawDataToHRtgE(BloombergResponseTemplate bloombergResponseTemplate) throws Exception {
		
		try {
			
			List<Object[]> data = bloombergResponseTemplate.getData();
			Map<String,String> header = bloombergResponseTemplate.getHeader();
			List<RctHisRtgEntity> list = new ArrayList<RctHisRtgEntity>();
			
			rating:for(Object[] record : data) {
		
				// check corrupted data
				if(record.length < 3) {
					
					String errorMessage = "Missing values in data file. Corrupted line: " + ArrayUtils.toString(record);
					
					logger.warn(new StandardLogMessage(errorMessage));
					
					monitorLogger.warn(new StandardLogMessage(errorMessage));
					
					continue;
				}
				
				for(Object object : record) {
					
					if(/*((String)object).trim().equalsIgnoreCase("") ||
					   ((String)object).trim().equalsIgnoreCase("N.A.") ||*/
					   ((String)object).trim().equalsIgnoreCase("N.D.") ||
					   ((String)object).trim().equalsIgnoreCase("N.S.") ||
					   ((String)object).trim().equalsIgnoreCase("FLD UNKNOWN")) {
						
						String errorMessage = "Invalid values in data file. Corrupted line: " + ArrayUtils.toString(record);
						
						logger.error(new StandardLogMessage(errorMessage));
						
						monitorLogger.error(new StandardLogMessage(errorMessage));
						
						throw new Exception(errorMessage);
					}
					
				}
				
				
				RctHisRtgEntity hisRtgEntity = new RctHisRtgEntity();
				RctHisRtgEntityPK hisRtgEntityPK = new RctHisRtgEntityPK();
				
				String bbgCode = ((String)record[0]).trim().substring(0, ((String)record[0]).trim().indexOf(" Equity"));
				int date = Integer.parseInt(header.get("RUNDATE"));
				String spRating = ((String)record[3]).trim();
				String mdyRating = ((String)record[4]).trim();
				String fitchRating = ((String)record[5]).trim();
				BankEntity bankEntity = this.bankEAOLocal.retrieveBankByBloombCode(bbgCode);
				
				// *** IMPORTANT ***
				// Check if the downloaded line matches with an instrument in my static data.
				// IF NOT, it means i am downloading something useless and someone directly modified 
				// Bloomberg request file on Bloomberg account folder;
				// or i am testing some new instrument in a different environment!!!
				if(bankEntity == null) {
					
					logger.warn(new StandardLogMessage("Bank having Bloomberg Code \'" + bbgCode + "\' not fount in Static Data. Check StaticData/Bloomberg request alignment."));
					monitorLogger.warn(new StandardLogMessage("Bank having Bloomberg Code \'" + bbgCode + "\' not fount in Static Data. Check StaticData/Bloomberg request alignment."));
					
					continue;
					//throw new Exception();
				}
				// ***
				
				hisRtgEntityPK.setBloombCode(bbgCode);
				hisRtgEntityPK.setRtgDate(date);
				hisRtgEntityPK.setRtgTime(0000);

				hisRtgEntity.setId(hisRtgEntityPK);
				hisRtgEntity.setSpRtg(spRating);
				hisRtgEntity.setMoodRtg(mdyRating);
				hisRtgEntity.setFitchRtg(fitchRating);
				hisRtgEntity.setBankId(bankEntity.getBankId());
				list.add(hisRtgEntity);
				
			}
			
			logger.info(new StandardLogMessage("Parsing successfully completed."));
			

			return list;
		}
		catch(Exception e) {
			
			throw new Exception("Cannot convert from raw data to HistoricalPricesEntity. " + e.toString());
		}
		
	}
	
}
