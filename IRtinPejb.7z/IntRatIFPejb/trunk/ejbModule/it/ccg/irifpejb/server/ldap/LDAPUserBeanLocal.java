package it.ccg.irifpejb.server.ldap;


public interface LDAPUserBeanLocal {
	
	public LDAPUserDTO getLDAPUserByUID(String uid) throws Exception;
	
}
