package it.ccg.irifpejb.server.bean.business;



import javax.ejb.Local;

@Local
public interface FitchBatchBeanLocal {
	
	public void bankBatch() throws Exception;
	
}
