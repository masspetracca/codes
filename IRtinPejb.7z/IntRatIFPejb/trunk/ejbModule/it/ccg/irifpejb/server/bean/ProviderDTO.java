package it.ccg.irifpejb.server.bean;

import java.io.Serializable;

public class ProviderDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5903821977512923399L;
	
	private String name;
	private Class<?>[] _classes;
	private String description;
	
	
	public ProviderDTO(String name, Class<?>[] _classes, String description) {
		
		this.name = name;
		this._classes = _classes;
		this.description = description;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Class<?>[] get_classes() {
		return _classes;
	}


	public void set_classes(Class<?>[] _classes) {
		this._classes = _classes;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}
	

}
