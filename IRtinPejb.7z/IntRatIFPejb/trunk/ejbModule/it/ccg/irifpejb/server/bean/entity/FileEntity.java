package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the RCITFILE database table.
 * 
 */
@Entity
@Table(name="RCITFILE")
@NamedQueries({
	@NamedQuery(name="fetchAllFtpFiles", query="SELECT file FROM FileEntity file"),
	@NamedQuery(name="fetchByName", query="SELECT file FROM FileEntity file WHERE file.fileName = :fileName")
})
public class FileEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.TABLE, generator="ID_FILE_TABLE_GENERATOR")
	@TableGenerator(name="ID_FILE_TABLE_GENERATOR", table="RCITIDGEN", pkColumnName="ID_NAME", pkColumnValue="USER_SEQUENCE", valueColumnName="ID_VALUE")
	@Column(name="FILE_ID", unique=true, nullable=false)
	private int fileId;

	@Column(length=10000)
	private String content;

	@Column(name="FILE_NAME", nullable=false, length=30)
	private String fileName;

	@Column(name="P_BATCH_ID", nullable=false)
	private int pBatchId;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

    public FileEntity() {
    }
    
    public FileEntity(String fileName, String content, int pBatchId) {
    	this.fileName = fileName;
    	this.content = content;
    	this.pBatchId = pBatchId;
    }

	public int getFileId() {
		return this.fileId;
	}

	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getPBatchId() {
		return this.pBatchId;
	}

	public void setPBatchId(int pBatchId) {
		this.pBatchId = pBatchId;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

}