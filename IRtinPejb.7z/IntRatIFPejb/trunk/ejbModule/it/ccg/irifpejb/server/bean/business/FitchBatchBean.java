package it.ccg.irifpejb.server.bean.business;

import it.ccg.irifpejb.server.bean.eao.BnkEAOLocal;
import it.ccg.irifpejb.server.bean.eao.FileEAOLocal;
import it.ccg.irifpejb.server.bean.eao.VarHEAOLocal;
import it.ccg.irifpejb.server.bean.entity.RctBnkFtctEntity;
import it.ccg.irifpejb.server.bean.entity.RctBnkFtctEntityPK;
import it.ccg.irifpejb.server.bean.entity.VarHEntity;
import it.ccg.irifpejb.server.bean.entity.VarHEntityPK;
import it.ccg.irifpejb.server.exception.DuplicateKeyException;
import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.exception.FTPException;
import it.ccg.irifpejb.server.exception.NewDataNotAvailableException;
import it.ccg.irifpejb.server.file.parser.FitchResponseParser;
import it.ccg.irifpejb.server.file.template.FitchResponseTemplate;
import it.ccg.irifpejb.server.file.util.FitchResponseFTPFileComparator;
import it.ccg.irifpejb.server.ftp.FTPFactory;
import it.ccg.irifpejb.server.ftp.FTPServiceInterface;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.server.security.SecurityEjb;
import it.ccg.irifpejb.server.system.MailManager;
import it.ccg.irifpejb.server.system.SystemProperties;
import it.ccg.irifpejb.server.system.ZipManager;

import java.io.File;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BloombergBatchBean
 */
@Stateless
public class FitchBatchBean implements FitchBatchBeanLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	private static final Logger monitorLogger = LoggerFactory.getLogger(LoggerFactory.MONITOR_LOGGER);
	
	private static String TEMP_DIR_ABSOLUTE_PATH;
	private static String PROVIDER_NAME;
	private static String FLOW_BANK_NAME;
	private FTPServiceInterface ftpServiceInterface; 
	
	@EJB
	private BnkEAOLocal bnkEAOLocal;
	
	@EJB
	private VarHEAOLocal varHEAOLocal;
	
	@EJB
	private FileEAOLocal fileEAOLocal;
	
	@EJB
	private BaseBeanLocal baseBeanLocal;
	
	
	public FitchBatchBean() throws Exception {
		
		try {
    		
    		TEMP_DIR_ABSOLUTE_PATH = SystemProperties.getProperty("user.install.root") +
    								 SystemProperties.getProperty("temp_dir_relative_path");
    		
    		// provider engine IDs from properties file
        	PROVIDER_NAME = SystemProperties.getProperty("provider.fitch.name");
        	
    	}
    	catch(Exception e) {
    		
    		logger.warn(new StandardLogMessage("Exception into bean constructor. Exception: " + e));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
	}

	

	@Override
	public void bankBatch() throws Exception {
		
		String BATCH_DESC = "Bank variable synchronization";
		
		try {
			logger.info(new StandardLogMessage(BATCH_DESC + " started."));
			
			// TODO:
			PROVIDER_NAME = SystemProperties.getProperty("provider.fitch.name");
			FLOW_BANK_NAME = SystemProperties.getProperty("provider.fitch.flow.bank.name");
			
			//String RESPONSE_FILE_NAME = "20130823_1201.ibd.ref.usd.zip";
    		
			// create temporary folder to work
			// ***************************************************************************************************************
			String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			// ***************************************************************************************************************
			
			// get file from ftp and save it into TEMP_FILE_ABSOLUTE_PATH
			String tempFileAbsPath = this.getFileFromFTP(tempWorkingFolder.getAbsolutePath());
			
			// it is a .zip file, extract it
			ZipManager.unZip(tempFileAbsPath, tempWorkingFolder.getCanonicalPath());
			
			/*String tempWorkingFolderName = "C:\\Users\\pcocchi\\Desktop\\fitch_file_folder";
			File tempWorkingFolder = new File(tempWorkingFolderName);*/
			
			// TODO:
			String dataFileAbsPath = tempWorkingFolder.getCanonicalPath() + File.separator;
			for(File file: tempWorkingFolder.listFiles()) {
				
				if(file.getName().endsWith(".fid")) {
					
					dataFileAbsPath += file.getName();
				}
			}
			
			String codesFileAbsPath = tempWorkingFolder.getCanonicalPath() + File.separator;
			for(File file: tempWorkingFolder.listFiles()) {
				
				if(file.getName().endsWith(".smt")) {
					codesFileAbsPath += file.getName();
				}
			}
			
			logger.warn(new StandardLogMessage("WARN - parsing"));
			
			// parse file
			FitchResponseParser parser = new FitchResponseParser();
			FitchResponseTemplate fitchResponseTemplate = parser.parse(new File(dataFileAbsPath), new File(codesFileAbsPath));
			
			
			// SMT
			this.manageSMT(fitchResponseTemplate);
			
			
			// FID
			List<VarHEntity> toSave = this.manageFID(fitchResponseTemplate);
			
			// refresh varH view
			try {
				// TODO: remove comment
				monitorLogger.info(new StandardLogMessage("refresh varh view"));
				logger.info(new StandardLogMessage("refresh varh view"));
				this.varHEAOLocal.refreshVarHView();
			}
			catch (Exception e) {
				
				// write on system log
				e.printStackTrace();
				
				String errorMessage = "VarH View refreshing failed.";
				
				monitorLogger.error(new StandardLogMessage(errorMessage));
				logger.error(new StandardLogMessage(errorMessage));
			}
			
			
			
			// save information about executed batch
			
			// TODO: remove comment
			this.baseBeanLocal.saveJobInfo("Fitch", "Bank data download", toSave, new File(tempFileAbsPath).getName(), tempFileAbsPath);
			 
			
			
			// monitor info
			monitorLogger.info(new StandardLogMessage(BATCH_DESC + " successfully executed."));
			// default logger
			logger.info(new StandardLogMessage(BATCH_DESC + " successfully executed."));
			
			
			// delete tempWorkingFolder
			this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
		}catch(NewDataNotAvailableException e) {
			// monitor warning
			monitorLogger.warn(new StandardLogMessage(BATCH_DESC + " not completed. New data not available."));
			// default logger
			logger.warn(new StandardLogMessage(BATCH_DESC + " not completed. New data not available."));
			
			/*
			 * commento per far chiudere il giro
			 */
			//ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			//throw new Exception(BATCH_DESC + " not completed. New data not available.");
		}catch(FTPException e) {
			
			// default logger
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			// FTPEception is managed into caller class.
			throw e;
		}catch(Exception e) {
			// monitor error
			monitorLogger.error(new StandardLogMessage(BATCH_DESC + " failed."));
			// default logger
			logger.error(new StandardLogMessage(BATCH_DESC + " failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// send notification mail
			MailManager mailManager = new MailManager();
			String message = BATCH_DESC + " failed.";
			mailManager.sendMail("InternalRating IFP System batch generic error", message, null);
			
			// throw at caller
			throw new Exception(BATCH_DESC + " failed.");
		}		
	}
	
	
	private void manageSMT(FitchResponseTemplate fitchResponseTemplate) throws Exception {
		
		System.out.println("WARN - converting raw data to BnkFtcTEntity");
		
		
		List<RctBnkFtctEntity> entityList = this.convertRawSMT(fitchResponseTemplate);
		
		
		System.out.println("WARN - persisting");
		
		
		// persist data
		try {
			this.persistSMT(entityList);
		}
		catch(DuplicateKeyException e) {
			
			monitorLogger.warn(new StandardLogMessage("Duplicate key values found in new data."));
		}
		
		
		
	}
	
	private List<VarHEntity> manageFID(FitchResponseTemplate fitchResponseTemplate) throws Exception {
		
		System.out.println("WARN - converting raw data to VarHEntity");
		
		
		List<VarHEntity> entityList = this.convertRawFID(fitchResponseTemplate);
		
		
		System.out.println("WARN - persisting VarHEntity");
		
		// persist data
		try {
			this.persistFID(entityList);
		}
		catch(DuplicateKeyException e) {
			
			monitorLogger.warn(new StandardLogMessage("Duplicate key values found in new data."));
		}
		
		return entityList;
		
	}
	
	
	
    // get file from ftp and save it into tempFileAbsPath
    private String getFileFromFTP(String tempFolderAbsPath) throws Exception {
    	
    	try {
	    	
	    	// initialize ftpService
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.FITCH_SERVICE);
			
			// compute file name to download
			FTPFile[] fileArray = this.ftpServiceInterface.getResponseFilesInfo();
			String fileName = this.getLastFileInfo(fileArray).getName();
			
			// controllo file gi� scaricato / dati gi� scaricati
			if(this.fileEAOLocal.findByName(fileName) != null) {
				
				logger.warn(new StandardLogMessage("File \'" + fileName + "\' already downloaded. New data not available."));
				
				throw new NewDataNotAvailableException("File \'" + fileName + "\' already downloaded. New data not available.");
			}
			

			String tempFileAbsPath = tempFolderAbsPath + File.separator + fileName;
			
			// download file
			this.ftpServiceInterface.downloadResponseFile(fileName, new File(tempFileAbsPath));
	    	
			
			logger.info(new StandardLogMessage("File \'" + fileName + "\' successfully downloaded."));
			
			
			return tempFileAbsPath;
    	}
		catch(Exception e) {
			
			throw e;
		}
		
    }
    
    private FTPFile getLastFileInfo(FTPFile[] fileArray) throws Exception {
		
		// file name format: yyyymmdd + other (for example: "20130823_1201.ibd.ref.usd.zip")
		
		Set<FTPFile> fileList = new TreeSet<FTPFile>(new FitchResponseFTPFileComparator());
		
		for(FTPFile file : fileArray) {
			
			String fileName = file.getName();
			
			// considero tutti i file con prefisso diverso da "FDS" (� la lista delle banche) e estensione .zip
			if(!fileName.startsWith("FDS") && fileName.endsWith(".zip")) {
				logger.debug(new StandardLogMessage("FTPFile "+file.getName()+" size: "+file.getSize())); 
				fileList.add(file);
			}
		}
		
		if(fileList.size() < 1) {
			
			throw new Exception("Data not available on Fitch server.");
		}
		
		// prendo il primo, la lista � ordinata in modo decrescente secondo la data
		return ((FTPFile)fileList.toArray()[0]);
	}
    
    
    
    private List<RctBnkFtctEntity> convertRawSMT(FitchResponseTemplate fitchResponseTemplate) throws Exception {
    	
    	try {
			
    		List<Object[]> codes = fitchResponseTemplate.getCodes();
    		
    		// get data
        	List<RctBnkFtctEntity> newList = new ArrayList<RctBnkFtctEntity>();
    		
        	RctBnkFtctEntity bnkEntity;
        	
        	// for each FitchNickName
    		for(Object[] record : codes) {
    			
    			//String fitchnname = (String)record[8];
    			String fitchnname = (String)record[fitchResponseTemplate.getIdxFNName()];
    			String fitchcode = (String)record[fitchResponseTemplate.getIdxFCode()];
    			String accountsys = (String)record[fitchResponseTemplate.getIdxAccountSys()];
    			//String isconsolid = (String)record[11];
    			String isconsolid = (String)record[fitchResponseTemplate.getIdxIsConsolid()];
    			//
    			//String latestPeriodString = ((String)record[13]).substring(0, 10);
				String latestPeriodString = ((String)record[fitchResponseTemplate.getIdxlatestPer()]).substring(0, 10);
				GregorianCalendar latestperGC = this.getGCFormat(latestPeriodString);
				
				
				// check existing data
				if(this.bnkEAOLocal.findByPrimaryKey(fitchnname,Integer.parseInt(fitchcode)) != null) {
					
					continue;
				}
				
				// check corrupted data
				/*if(record.length < ?) {
					
					String message = "Missing values in data file. Corrupted line: " + ArrayUtils.toString(record);
					
					logger.warn(new StandardLogMessage(message));
					monitorLogger.warn(new StandardLogMessage(message));
					
					continue;
				}*/
				
				
				// new entity
				bnkEntity = new RctBnkFtctEntity();
				RctBnkFtctEntityPK bnkEntityPK = new RctBnkFtctEntityPK();
				bnkEntityPK.setFitchNName(fitchnname.trim());
				bnkEntityPK.setFitchCode(Integer.parseInt(fitchcode));
				
				bnkEntity.setId(bnkEntityPK);
				bnkEntity.setAccountSys(accountsys);
				bnkEntity.setIsConsolid(isconsolid);
				bnkEntity.setLatestPer(new Timestamp(latestperGC.getTimeInMillis()));
				
				
				newList.add(bnkEntity);
				
			}
				
    		
    		logger.info(new StandardLogMessage("Parsing successfully completed."));
    		

    		return newList;
    	}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw new Exception("Cannot convert from raw data to BnkFtcTEntity.");
		}
		
		
	}
    	
    
    
    
    // 
    private List<VarHEntity> convertRawFID(FitchResponseTemplate fitchResponseTemplate) throws Exception {
    	
    	try {
			
    		List<Object[]> data = fitchResponseTemplate.getData();
    		
    		
    		// get data
        	List<VarHEntity> newList = new ArrayList<VarHEntity>();
    		
        	VarHEntity varHEntity;
			VarHEntityPK varHEntityPK;
        	
        	// for each FitchNickName
    		for(Object[] record : data) {
			// TODO: remove
			// ******************************
			/*for(int k=0; k<50; k++) {
    			
				Object[] record = data.get(k);
				*/
			// ******************************
    			String fitchnname = (String)record[1];
    			
				String dateString = ((String)record[2]).substring(0, 10);
				GregorianCalendar gc = this.getGCFormat(dateString);
				
				
				// check existing data
				// new PK entity
				varHEntityPK = new VarHEntityPK();
				varHEntityPK.setFitchnname(fitchnname);
				varHEntityPK.setProvider("F");
				varHEntityPK.setValuedate(new Timestamp(gc.getTimeInMillis()));
				// If number 1 exists, then others exist
				varHEntityPK.setVarid(1);
				/*
				 * Raffaele De Lauri
				 * TN_CCG15881
				 * 05/01/2015
				 */
				VarHEntity oldVarHEntity = this.varHEAOLocal.findByPrimaryKey(varHEntityPK);
				if((oldVarHEntity != null) && 
				   (Integer.parseInt((String)record[5])!=1 && oldVarHEntity.getDataflag()==Integer.parseInt((String)record[5])) && 
				   (Integer.parseInt((String)record[5])!=0 || Integer.parseInt((String)record[5])!=1)) {
					
					continue;
				}
				/*
				 * fine *TN_CCG15881
				 */
				
				// common fields
				int periodleng = Integer.parseInt((String)record[3]);
				int periodtype = Integer.parseInt((String)record[4]);
				int dataflag = Integer.parseInt((String)record[5]);
				int audqualflg = Integer.parseInt((String)record[6]);
				
				
				// for each variable
				// Into .fid file the first column i want is "Original Currency Conversion Rate", which is the 8th field
				int START_INDEX = 7;
				
				for(int i=START_INDEX; i<record.length; i++) {
					
					// check corrupted data
					/*if(record.length < ?) {
						
						String message = "Missing values in data file. Corrupted line: " + ArrayUtils.toString(record);
						
						logger.warn(new StandardLogMessage(message));
						monitorLogger.warn(new StandardLogMessage(message));
						
						continue;
					}*/
					
					
					// new PK entity
					varHEntityPK = new VarHEntityPK();
					varHEntityPK.setFitchnname(fitchnname);
					varHEntityPK.setProvider("F");
					varHEntityPK.setValuedate(new Timestamp(gc.getTimeInMillis()));
					varHEntityPK.setVarid(i - (START_INDEX - 1));
					
					// new entity
					varHEntity = new VarHEntity();
					
					String valueString = (String)record[i];
					if(!valueString.equalsIgnoreCase("")) {
						varHEntity.setVarvalue(new BigDecimal(valueString));
					}
					else {
						
						varHEntity.setVarvalue(null);
					}
					
					varHEntity.setId(varHEntityPK);
					
					varHEntity.setPeriodleng(periodleng);
					varHEntity.setPeriodtype(periodtype);
					varHEntity.setDataflag(dataflag);
					varHEntity.setAudqualflg(audqualflg);
					
					
					newList.add(varHEntity);
					
				}
				
			}
    		
    		logger.info(new StandardLogMessage("Parsing successfully completed."));
    		

    		return newList;
    	}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw new Exception("Cannot convert from raw data to VarHEntity.");
		}
		
	}
    
    
	
	private void persistSMT(List<RctBnkFtctEntity> entityList) throws Exception {
		
    	try {
    	
			boolean duplicateKeyFoundFlag = false;
				
	    	for(RctBnkFtctEntity bnkEntity : entityList) {
	    		
	    		// gestione chiave duplicata
	    		// *********************************************************************************************************************
	    		
	    		RctBnkFtctEntity temp = this.bnkEAOLocal.findByPrimaryKey(bnkEntity.getId().getFitchNName(),bnkEntity.getId().getFitchCode());
	    		
	    		// se il dato gi� esiste
				if(temp != null) {
					
					logger.warn(new StandardLogMessage(bnkEntity + " already exists in RCTBNKFTCT. Skipping data."));
					
					duplicateKeyFoundFlag = true;
					
					// skip
					continue;
				}
	    		// *********************************************************************************************************************
	    		
				// scrivi dato
				this.bnkEAOLocal.add(bnkEntity);
				
			}
		    	
	    	
			if(duplicateKeyFoundFlag) {
				
				logger.warn(new StandardLogMessage("Persisting data successfully completed. Duplicate key values found in new data."));
			}
			else {
				
				logger.info(new StandardLogMessage("Persisting data successfully completed."));
			}
			
    	}
    	catch(Exception e) {
    		
    		logger.error(new StandardLogMessage(e.toString()));
    		
			throw e;
		}
    }
	
	
	private void persistFID(List<VarHEntity> entityList) throws Exception {
		
    	try {
    	
			boolean duplicateKeyFoundFlag = false;
			boolean updatedKeyFoundFlag = false;
				
	    	for(VarHEntity varHEntity : entityList) {
	    		
	    		// gestione chiave duplicata
	    		// *********************************************************************************************************************
	    		
	    		VarHEntity temp = this.varHEAOLocal.findByPrimaryKey(varHEntity.getId());
	    		
	    		// se il dato gi� esiste
				if(temp != null) {
					/*
					 * Raffaele De Lauri
					 * TN_CCG15881
					 * 09/01/2015
					 */
					if ((temp.getDataflag()!=varHEntity.getDataflag() || varHEntity.getDataflag()==1) && (varHEntity.getDataflag()==0 || varHEntity.getDataflag()==1)){
						
						varHEntity.setUpddate(new Timestamp(new Date().getTime()));
						varHEntity.setUpdtype("U");
						
						//aggiorno
						BeanUtils.copyProperties(temp, varHEntity);
						
						updatedKeyFoundFlag = true;
						logger.warn(new StandardLogMessage(varHEntity + " already exists in RCTVARH. Update data."));
						continue;
						/*
						 * Fine TN_CCG15881
						 */
					}else{
						logger.warn(new StandardLogMessage(varHEntity + " already exists in RCTVARH. Skipping data."));
						
						duplicateKeyFoundFlag = true;
						
						// skip
						continue;
					}
				}
	    		// *********************************************************************************************************************
	    		
				// scrivi dato
				this.varHEAOLocal.add(varHEntity);
			}
		    
	    	/*
			 * Raffaele De Lauri
			 * TN_CCG15881
			 * 09/01/2015
			 */
	    	if(duplicateKeyFoundFlag && updatedKeyFoundFlag){
	    		logger.warn(new StandardLogMessage("Persisting data successfully completed. Duplicate key and updated values found in new data."));
	    	}
	    	/*
			 * Fine TN_CCG15881
			 */
	    	else if(duplicateKeyFoundFlag) {
				
				logger.warn(new StandardLogMessage("Persisting data successfully completed. Duplicate key values found in new data."));
				
			}
	    	/*
			 * Raffaele De Lauri
			 * TN_CCG15881
			 * 09/01/2015
			 */
	    	else if(updatedKeyFoundFlag){
				
				logger.warn(new StandardLogMessage("Persisting data successfully completed. Updated values found in new data."));
			}
	    	/*
			 * Fine TN_CCG15881
			 */
			else {
				
				logger.info(new StandardLogMessage("Persisting data successfully completed."));
			}
			
    	}
    	catch(Exception e) {
    		
    		logger.error(new StandardLogMessage(e.toString()));
    		
			throw e;
		}
    }
	
	
	// from 'dd/mm/yyyy hh:mm' to GregorianCalendar
	private GregorianCalendar getGCFormat(String dateString) {
		
		String[] comp = dateString.split("-");
		
		return new GregorianCalendar(Integer.parseInt(comp[0]), Integer.parseInt(comp[1]) - 1, Integer.parseInt(comp[2]));
	}
	
	

}
