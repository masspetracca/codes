package it.ccg.irifpejb.server.ftp;



import it.ccg.irifpejb.server.exception.FTPException;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.server.providerengine.ProviderEngine;
import it.ccg.irifpejb.server.providerengine.config.FitchConfig;
import it.ccg.irifpejb.server.system.SystemProperties;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.log4j.Logger;


public class FTPServiceFitch implements FTPServiceInterface {
	
	private FTPClient ftpClient;
	private static String PROVIDER_NAME;
	
	private static String URL;
	private static String USERNAME;
	private static String PASSWD;
	private static String DOWNLOAD_DIR;

	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	
	public FTPServiceFitch() throws Exception {
				
		
		PROVIDER_NAME = SystemProperties.getProperty("provider.fitch.name");
		
		URL = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getUrl();
		USERNAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getUserName();
		PASSWD = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getPassword();
		DOWNLOAD_DIR = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getDownloadDataDir();
	
		this.ftpClient = new FTPClient();
		
	}
	
	
	private void openConnection() throws Exception {
		
		this.ftpClient.connect(URL);
		
		if(this.ftpClient.isConnected()) {
			logger.debug(new StandardLogMessage("Connected to \'" + URL + "\' .."));	
			if(this.ftpClient.login(USERNAME, PASSWD)) {
				logger.debug(new StandardLogMessage("User \'" + USERNAME + "\' logged in.."));
			}else {
				logger.error(new StandardLogMessage("Authentication of user \'" + USERNAME+ "\' failed."));
				throw new Exception("Authentication of user \'" + USERNAME + "\' failed.");
			}
		}else {
			logger.error(new StandardLogMessage("Connection to \'" + URL + "\' failed."));
			throw new Exception("Connection to \'" + URL + "\' failed.");
		}
		
	}
	
	
	private void closeConnection() throws Exception {
		
		this.ftpClient.logout();
		
		if(this.ftpClient.isConnected()) {
			this.ftpClient.disconnect();
		}
		
		if(this.ftpClient.isConnected()) {
			
			logger.warn(new StandardLogMessage("Unable to disconnect from \'" + URL + "\'. Connection will be closed by server.."));
		}
		else {
			logger.debug(new StandardLogMessage("Disconnected from \'" + URL + "\'."));
		}
		
	}
	
	
	@Override
	public FTPFile getResponseFileInfo(String fileName) throws FTPException {
		
		try {
			if(!responseFileIsPresent(fileName)) {
				logger.error(new StandardLogMessage("File \'" + fileName + "\' not found."));
				
				throw new Exception("File \'" + fileName + "\' not found.");
			}
			
			
			this.openConnection();
			this.changeWorkingDir(DOWNLOAD_DIR);
			
			FTPFile fileInfo = null;
			FTPFile[] fileList = this.ftpClient.listFiles();
			
			for(FTPFile file : fileList) {
				if(file.getName().equalsIgnoreCase(fileName)) {
					fileInfo = file;
					logger.debug(new StandardLogMessage("File \'" + fileName + "\' info successfully downloaded. Size: "+file.getSize()));
					break;
				}
			}
			
			this.closeConnection();
			
			return fileInfo;
		}
		catch(Exception e) {

			throw new FTPException(e.toString());
		}
		
	}
	
	
	@Override
	public FTPFile[] getResponseFilesInfo() throws FTPException {
		try {
			this.openConnection();
			
			this.changeWorkingDir(DOWNLOAD_DIR);
			
			FTPFile[] filesInfo = ftpClient.listFiles();
			logger.debug(new StandardLogMessage("Files info successfully downloaded."));
			
			this.closeConnection();
			
			return filesInfo;
		}
		catch(Exception e) {

			throw new FTPException(e.toString());
		}
	}
	
	
	@Override
	public void downloadResponseFile(String fileName, File outputFile) throws FTPException {
		try {
			if(!responseFileIsPresent(fileName)) {
				logger.error(new StandardLogMessage("File \'" + fileName + "\' not found."));
				
				throw new Exception("File \'" + fileName + "\' not found.");
			}
			else {
				logger.debug(new StandardLogMessage("File \'" + fileName + "\' found."));
			}
			
			
			this.openConnection();
			
			this.changeWorkingDir(DOWNLOAD_DIR);
		
			FileOutputStream outputStream = new FileOutputStream(outputFile);
			
			this.ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE, FTPClient.BINARY_FILE_TYPE);
			this.ftpClient.setFileTransferMode(FTPClient.BINARY_FILE_TYPE);
			
			boolean result = ftpClient.retrieveFile(fileName, outputStream);
			
			outputStream.close();
			
			if(result) {
				logger.debug(new StandardLogMessage("File \'" + fileName + "\' successfully downloaded."));
				
				this.closeConnection();
			}
			else {
				logger.error(new StandardLogMessage("Unable to download file \'" + fileName + "\'."));
				
				this.closeConnection();
				
				throw new Exception("Unable to download file \'" + fileName + "\'.");
			}
		}
		catch(Exception e) {

			throw new FTPException(e.toString());
		}
	}
	
	@Override
	public void downloadRequestFile(String fileName, File outputFile) throws FTPException {
		
		throw new FTPException("Request download not implemented.");
	}
	
	
	@Override
	public void uploadRequestFile(String fileName, File inputFile) throws FTPException {
		try {
			this.openConnection();
			
			this.changeWorkingDir(DOWNLOAD_DIR);
			
			
			FileInputStream inputStream = new FileInputStream(inputFile);
			
			boolean result = ftpClient.storeFile(fileName, inputStream);
			
			inputStream.close();
			
			
			
			if(result) {
				logger.debug(new StandardLogMessage("File \'" + fileName + "\' successfully uploaded."));
				
				this.closeConnection();
			}
			else {
				logger.error(new StandardLogMessage("Unable to upload file \'" + fileName + "\'."));
				
				this.closeConnection();
				
				throw new Exception("Unable to upload file \'" + fileName + "\'.");
			}
		}
		catch(Exception e) {

			throw new FTPException(e.toString());
		}
	}
	
	
	@Override
	public boolean responseFileIsPresent(String fileName) throws FTPException {
		try {
			this.openConnection();
			
			logger.debug(new StandardLogMessage("Searching file \'" + fileName + "\'.."));
			
			this.changeWorkingDir(DOWNLOAD_DIR);
			
			boolean result = false;
			
			FTPFile[] fileList = this.ftpClient.listFiles();
			
			for(FTPFile file : fileList) {
				if(file.getName().equalsIgnoreCase(fileName)) {
					result = true;
					
					break;
				}
			}
			
			this.closeConnection();
			
			return result;
		}
		catch(Exception e) {

			throw new FTPException(e.toString());
		}
	}
	
	@Override
	public boolean requestFileIsPresent(String fileName) throws FTPException {
		
		throw new FTPException("Request download not implemented.");
	}
	
	
	
	private void changeWorkingDir(String workingDir) throws Exception {
		
		if(!this.ftpClient.changeWorkingDirectory(workingDir)){
			logger.error(new StandardLogMessage("Unable to change working directory."));
			
			this.closeConnection();
			
			throw new Exception("Unable to change working directory.");
		}
		else {
			logger.debug(new StandardLogMessage("Working directory changed to \'"+ workingDir +"\'."));
		}
		
	}
	
	
}
