package it.ccg.irifpejb.server.bean.eao;

import it.ccg.irifpejb.server.bean.entity.RctHisRtgEntity;
import it.ccg.irifpejb.server.bean.entity.RctHisRtgEntityPK;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import java.util.List;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class HistoricalRatingEAO
 */
@Stateless
@Local(HistoricalRatingEAOLocal.class)
public class HistoricalRatingEAO implements HistoricalRatingEAOLocal {

	@PersistenceContext(unitName="IntRatIFPejb", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Resource
	private SessionContext sessionContext;
	private String tableName = ((Table)(RctHisRtgEntity.class.getAnnotation(Table.class))).name();
	
	@SuppressWarnings("unchecked")
	public List<RctHisRtgEntity> fetch() throws Exception{
		Query query = em.createNamedQuery("getAllHistoricalPrices");
		
		
		return (List<RctHisRtgEntity>)query.getResultList();
	}
	
	public RctHisRtgEntity findByPrimaryKey(RctHisRtgEntityPK pK) throws Exception{
		
		return (RctHisRtgEntity)em.find(RctHisRtgEntity.class, pK);
	}
	
	@SuppressWarnings("unchecked")
	public List<RctHisRtgEntity> fetchLastDateHisRtg(List<Integer> bankIDs) throws Exception{
		
		Query query = em.createNamedQuery("fetchLastDateHisRtg");
		query.setParameter("bankIDsList", bankIDs);
		
		
		return (List<RctHisRtgEntity>)query.getResultList();
	}
	
	public void add(RctHisRtgEntity rE) throws Exception{
		// set current user
		rE.setUpdUsr(this.sessionContext.getCallerPrincipal().getName());
		
		em.persist(rE);
		
		logger.info(new StandardLogMessage("Persisted data into \'" + this.tableName + "\'. " + rE));

	}
	
	public void update(RctHisRtgEntity rE) throws Exception{
		throw new Exception();
	}
	
	public void remove(RctHisRtgEntity rE) throws Exception{
		throw new Exception();
	}

}
