package it.ccg.irifpejb.server.bean.entity.custom;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Transient;

/**
 * Entity implementation class for Entity: Issues
 *
 */
@Entity

public class Issues implements Serializable {

	private static final long serialVersionUID = 1L;
	@Transient
	private Date valuedate;
	@Transient
	private String rTicker;
	@Transient
	private String dsplyname;
	@Transient
	private Timestamp matdate;
	@Transient
	private String fitchrtg;
	@Transient
	private String moodrtg;
	@Transient
	private String sprtg;
	@Transient
	private BigDecimal mtstotrspr;
	@Transient
	private String indSec;
	
	public Issues() {
		super();
	}
	
	public Issues(Date valuedate,String rTicker,String dsplyname,Timestamp matdate,String fitchrtg,String moodrtg,String sprtg,BigDecimal mtstotrspr,String indSec) {
		this.valuedate=valuedate;
		this.rTicker=rTicker;
		this.dsplyname=dsplyname;
		this.matdate=matdate;
		this.fitchrtg=fitchrtg;
		this.moodrtg=moodrtg;
		this.sprtg=sprtg;
		this.mtstotrspr=mtstotrspr;
		this.indSec=indSec;
	}

	/**
	 * @return the valuedate
	 */
	public Date getValuedate() {
		return valuedate;
	}

	/**
	 * @param valuedate the valuedate to set
	 */
	public void setValuedate(Date valuedate) {
		this.valuedate = valuedate;
	}

	/**
	 * @return the rTicker
	 */
	public String getrTicker() {
		return rTicker;
	}

	/**
	 * @param rTicker the rTicker to set
	 */
	public void setrTicker(String rTicker) {
		this.rTicker = rTicker;
	}

	/**
	 * @return the dsplyname
	 */
	public String getDsplyname() {
		return dsplyname;
	}

	/**
	 * @param dsplyname the dsplyname to set
	 */
	public void setDsplyname(String dsplyname) {
		this.dsplyname = dsplyname;
	}

	/**
	 * @return the matdate
	 */
	public Timestamp getMatdate() {
		return matdate;
	}

	/**
	 * @param matdate the matdate to set
	 */
	public void setMatdate(Timestamp matdate) {
		this.matdate = matdate;
	}

	/**
	 * @return the fitchrtg
	 */
	public String getFitchrtg() {
		return fitchrtg;
	}

	/**
	 * @param fitchrtg the fitchrtg to set
	 */
	public void setFitchrtg(String fitchrtg) {
		this.fitchrtg = fitchrtg;
	}

	/**
	 * @return the moodrtg
	 */
	public String getMoodrtg() {
		return moodrtg;
	}

	/**
	 * @param moodrtg the moodrtg to set
	 */
	public void setMoodrtg(String moodrtg) {
		this.moodrtg = moodrtg;
	}

	/**
	 * @return the sprtg
	 */
	public String getSprtg() {
		return sprtg;
	}

	/**
	 * @param sprtg the sprtg to set
	 */
	public void setSprtg(String sprtg) {
		this.sprtg = sprtg;
	}

	/**
	 * @return the mtstotrspr
	 */
	public BigDecimal getMtstotrspr() {
		return mtstotrspr;
	}

	/**
	 * @param mtstotrspr the mtstotrspr to set
	 */
	public void setMtstotrspr(BigDecimal mtstotrspr) {
		this.mtstotrspr = mtstotrspr;
	}

	/**
	 * @return the indSec
	 */
	public String getIndSec() {
		return indSec;
	}

	/**
	 * @param indSec the indSec to set
	 */
	public void setIndSec(String indSec) {
		this.indSec = indSec;
	}
}
