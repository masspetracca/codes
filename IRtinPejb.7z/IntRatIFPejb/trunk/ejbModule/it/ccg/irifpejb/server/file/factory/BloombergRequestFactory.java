package it.ccg.irifpejb.server.file.factory;

import it.ccg.irifpejb.server.bean.entity.BankEntity;
import it.ccg.irifpejb.server.file.parser.BloombergRequestParser;
import it.ccg.irifpejb.server.file.template.BloombergRequestTemplate;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

public class BloombergRequestFactory {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	public BloombergRequestFactory() throws Exception {
		
	}
	
	
	public void createRequestFile(BBGRequestType requestType, File outputFile, List<BankEntity> bankList) throws Exception {
		
		if(requestType == BBGRequestType.BANK_REQUEST) {
			
			this.createBankRequestFile(outputFile, bankList);
		}
		/*else if(requestType == BBGRequestType.NIR_REQUEST) {
			
			this.createNirRequestFile(outputFile, bankList);
		}*/
		else {
			
			logger.error(new StandardLogMessage("Invalid Reuters request type \'" + requestType + "\'."));
			
			throw new Exception("Invalid Reuters request type \'" + requestType + "\'.");
		}
		
	}
	
	
	private void createBankRequestFile(File outputFile, List<BankEntity> bankList) throws Exception {
		
		// headers
		Map<String, String>headers = new HashMap<String, String>();
		headers.put("FIRMNAME", "dl782252");
		headers.put("FILETYPE", "pc");
		headers.put("CLOSINGVALUES", "yes");
		headers.put("DATEFORMAT", "yyyymmdd");
		headers.put("PROGRAMFLAG", "daily");
		headers.put("DERIVED", "yes");
		headers.put("HISTORICAL", "yes");
		headers.put("SECMASTER", "yes");

		// fields
		List<String> fields = new ArrayList<String>();
		fields.add("RTG_SP_LT_LC_ISSUER_CREDIT");
		fields.add("RTG_MDY_ISSUER");
		fields.add("RTG_FITCH_LT_ISSUER_DEFAULT");
		
		// securities
		List<String> securities = new ArrayList<String>();
		for(BankEntity bankEntity : bankList) {
			securities.add(bankEntity.getBloombCode());
		}
		
		BloombergRequestTemplate bloombergRequestTemplate = new BloombergRequestTemplate(headers, fields, securities);
		
		
		// write
		this.writeDocumentToFile(bloombergRequestTemplate, outputFile);
	}
	
	
	/*private void createNirRequestFile(File outputFile, List<BankEntity> bankList) throws Exception {
		
		// headers
		Map<String, String>headers = new HashMap<String, String>();
		headers.put("FIRMNAME", "dl782252");
		headers.put("FILETYPE", "pc");
		headers.put("CLOSINGVALUES", "yes");
		headers.put("DATEFORMAT", "yyyymmdd");
		headers.put("PROGRAMFLAG", "daily");
		headers.put("PROGRAMNAME", "getdata");
		
		// fields
		List<String> fields = new ArrayList<String>();
		fields.add("PX_LAST");
		fields.add("LAST_UPDATE_DT");
		
		// securities
		List<String> securities = new ArrayList<String>();
		for(InstrEntity instrEntity : instrList) {
			securities.add(instrEntity.getBloombergCode());
		}
		
		BloombergRequestTemplate bloombergRequestTemplate = new BloombergRequestTemplate(headers, fields, securities);
		
		
		// write
		this.writeDocumentToFile(bloombergRequestTemplate, outputFile);
	}*/
	
	
	public void addBank(File file, BankEntity bankEntity) throws Exception {
		
		String bbgCode = bankEntity.getBloombCode();
		
		if(exists(file, bbgCode)) {
			
			logger.error(new StandardLogMessage("Bank having bbgCode=\'" + bbgCode + "\' yet in \'" + file.getName() + "\'."));
			
			throw new Exception("Bank having bbgCode=\'" + bbgCode + "\' yet in \'" + file.getName() + "\'.");
		}
		
		BloombergRequestTemplate bloombergRequestTemplate = this.loadDocumentFromFile(file);
		
		List<String> securities = bloombergRequestTemplate.getSecurities();
		securities.add(bbgCode);
		
		bloombergRequestTemplate.setSecurities(securities);
		
		this.writeDocumentToFile(bloombergRequestTemplate, file);
	}
	
	
	public void removeBank(File file, BankEntity bankEntity) throws Exception {
		
		String bbgCode = bankEntity.getBloombCode();
		
		if(!exists(file, bbgCode)) {
			
			logger.error(new StandardLogMessage("Bank having bbgCode=\'" + bbgCode + "\' not exists in \'" + file.getName() + "\'."));
			
			throw new Exception("Bank having bbgCode=\'" + bbgCode + "\' not exists in \'" + file.getName() + "\'.");
		}
		
		BloombergRequestTemplate bloombergRequestTemplate = this.loadDocumentFromFile(file);
		
		List<String> securities = bloombergRequestTemplate.getSecurities();
		securities.remove(bbgCode);
		
		bloombergRequestTemplate.setSecurities(securities);
		
		this.writeDocumentToFile(bloombergRequestTemplate, file);
	}
	
	
	
	private boolean exists(File file, String bbgCode) throws Exception {
		boolean exist = false;
		
		BloombergRequestTemplate bloombergRequestTemplate = this.loadDocumentFromFile(file);
		
		if(bloombergRequestTemplate.getSecurities().contains(bbgCode)) {
			
			exist = true;
		}
		
	    return exist;
	}
	
	
	private BloombergRequestTemplate loadDocumentFromFile(File file) throws Exception {
		
		BloombergRequestParser bloombergRequestParser = new BloombergRequestParser();
		
		return bloombergRequestParser.parse(file);
	}
	
	
	private void writeDocumentToFile(BloombergRequestTemplate template, File file) throws Exception {
		
		BufferedWriter bw = null;
		
		try {
			bw = new BufferedWriter(new PrintWriter(file));
			
			bw.write(template.getRatingRequestAsFileFormattedString());
		}
		catch(Exception e) {
			
			logger.error(new StandardLogMessage(e.toString()));
			
			throw new Exception(e.toString());
		}
		finally {
			if(bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		}
	}
	
}
