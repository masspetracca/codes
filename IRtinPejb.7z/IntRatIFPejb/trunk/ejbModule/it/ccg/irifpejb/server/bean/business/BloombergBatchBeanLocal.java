package it.ccg.irifpejb.server.bean.business;

public interface BloombergBatchBeanLocal {
	
	public void externaRatingBatch() throws Exception;
}
