package it.ccg.irifpejb.server.bean.eao;

import it.ccg.irifpejb.server.bean.entity.VarsEntity;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class VarsEAO
 */
@Stateless
@Local(VarsEAOLocal.class)
public class VarsEAO implements VarsEAOLocal {

    /**
     * Default constructor. 
     */
    public VarsEAO() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public List<VarsEntity> fetch() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
