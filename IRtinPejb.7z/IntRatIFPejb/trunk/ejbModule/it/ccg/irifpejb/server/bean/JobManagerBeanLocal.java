package it.ccg.irifpejb.server.bean;


import java.util.List;

import javax.ejb.Local;

@Local
public interface JobManagerBeanLocal {
	
	public List<ProviderDTO> getProviderList() throws Exception;
	
	public List<JobDTO> getJobListByProviderName(String providerName) throws Exception;
	public JobDTO getJobByName(String jobName) throws Exception;
	public JobDTO getJobByJobMethodNClass(String method, Class<?> _class) throws Exception;
	
	public void executeJob(JobDTO jobDTO) throws Exception;
	
}
