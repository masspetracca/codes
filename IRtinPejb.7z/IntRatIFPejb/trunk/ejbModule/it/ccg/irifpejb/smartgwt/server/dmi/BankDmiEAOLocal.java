package it.ccg.irifpejb.smartgwt.server.dmi;

import it.ccg.irifpejb.server.bean.entity.BankEntity;

import javax.ejb.Local;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;


@Local
public interface BankDmiEAOLocal {
	
	public DSResponse fetch(DSRequest dsRequest) throws Exception;
	public BankEntity add(DSRequest dsRequest) throws Exception;
	public BankEntity update(DSRequest dsRequest) throws Exception;
	public BankEntity remove(DSRequest dsRequest) throws Exception;

}
