package it.ccg.irifpejb.smartgwt.server.dmi;


import javax.ejb.Local;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;

@Local
public interface VarsDmiEAOLocal {
	
	public DSResponse fetch(DSRequest dsRequest) throws Exception;
	
	
}
