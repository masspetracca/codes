package Test;

import oopconcepts.Car;


public class TestCar {

		    static String Colors= "Rossa";

		    public static void main(String[] args) {
				Car fiat = new Car();
				fiat.setColor("Rosso");
				//fiat.getColors(Colors);
				System.out.println("Color: "+ fiat.getColor());
			}

}
