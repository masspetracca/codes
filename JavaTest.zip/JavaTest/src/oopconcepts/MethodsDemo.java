package oopconcepts;

public class MethodsDemo {

	private static Object a2;

	public static void main(String[] args) {
		String a = "Hey, Martina ";
		System.out.println(a);
		
		Demo dm = new Demo();
		a2=a+"& Massimo";
		dm.toString(a2);
	}
	
	public static void methodNum(String a2) {
		String a = "Hey, Massimo ";
		System.out.println(a);
		//System.out.println(a2);
	}
}