package it.ccg.test.collaudo.server.bus;



import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

public class PopulateDb {
	
	//Table access keys
	private static String kArea = ""; 
	private static String kStato = ""; 
	private static String kFreq ="";
	private static String kTipo ="";

	private static String Tab_col0 = "KEYID";
	private static String Tab_col1 = "DATEID";
	private static String Tab_col2 = "PROGID";
	private static String Tab_col3 = "OPENURL";
	private static String Tab_col4 = "NODENAME";
	private static String Tab_col5 = "NODETYPE";

	private static String Tab_col6 = "CHILDNAME";
	private static String Tab_col7 = "NODEACTION";
	private static String Tab_col8 = "NODEVALUE";
	private static String Tab_col9 = "NOTE";
	private static String Tab_col10 = "";
	private static String TableName = PropertyFiles.getTabName1();

	private static String vcol3 = "";
	private static String vcol4 = "";
	private static String vcol5 = "";

	private static String sdate =null;
	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

//	private static String tabFreq ="";
	private int ctrIns;
//	private int ctrUpd;
 	private int returnCode = 0;
 	private static String sqlUpdate;
//	
//
//	private static Object rs;
	
	PreparedStatement st;
	private String sqlDelete;
	private int ctrDel;


	public PopulateDb(String keyIdData, String keyDateData, String keyProgData, String openUrlData, String nodeNameData , String nodeTypeData,  String childNameData, String actionData, String nodeValueData, String noteData) throws ClassNotFoundException, IOException, SQLException, IllegalAccessException, InstantiationException {
		
		
		//upate table
		       sqlUpdate= 
				"INSERT INTO "+TableName
				+"("
				+""+Tab_col0
				+", "+Tab_col1
				+", "+Tab_col2
				+", "+Tab_col3
				+", "+Tab_col4
				+", "+Tab_col5
				+", "+Tab_col6
				+", "+Tab_col7
				+", "+Tab_col8
				+", "+Tab_col9
				+") VALUES ("
				+"'"+keyIdData.substring(0,keyIdData.length() )+"'" 				
				+", '"+keyDateData+"'" 
				+",  "+keyProgData
				+", '"+openUrlData+"'" 
				+", '"+nodeNameData+"'" 
				+", '"+nodeTypeData+"'" 
				+", '"+childNameData+"'" 
				+", '"+actionData+"'" 
				+", '"+nodeValueData+"'" 
				+", '"+noteData+"'" 
				+")"
				;

	    System.out.println(sqlUpdate);		
		++ctrIns;
		//setting upd parameters
		TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 
		upd.setSqlUpdate(sqlUpdate);	
}


	



}


	
		
							
   

