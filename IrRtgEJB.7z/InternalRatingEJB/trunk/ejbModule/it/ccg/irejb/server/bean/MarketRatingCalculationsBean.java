package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.bean.eao.RctIssFldEAOLocal;
import it.ccg.irejb.server.bean.eao.RctIssuesEAOLocal;
import it.ccg.irejb.server.bean.eao.RctTrscodeEAOLocal;
import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.bean.entity.RctIssFldEntity;
import it.ccg.irejb.server.bean.entity.RctIssuesEntity;
import it.ccg.irejb.server.bean.entity.RctRatingEntity;
import it.ccg.irejb.server.bean.entity.RctTrscodeEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.system.SystemProperties;
import it.ccg.irejb.server.util.ExceptionUtil;
import it.ccg.auditing.elements.Attribute;
import it.ccg.auditing.elements.Container;
import it.ccg.auditing.elements.Obj;

import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;

import org.apache.commons.math3.analysis.function.Log;
import org.apache.commons.math3.stat.regression.SimpleRegression;
import org.apache.log4j.Logger;

/**
 * Session Bean implementation class MarketRatingCalculationsBean
 */
@Stateless
@Local(MarketRatingCalculationsBeanLocal.class)
public class MarketRatingCalculationsBean implements MarketRatingCalculationsBeanLocal {

	private Properties properties;
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private Logger calcLogger = Logger.getLogger(LoggerFactory.CALCULATION_LOGGER);
	@EJB
	private RctIssuesEAOLocal rctIssuesEAO;
	
	@EJB
	private RctIssFldEAOLocal rctIssFldEAO;
	
	@EJB
	private RctTrscodeEAOLocal rctTrscodeEAO;
    /**
     * Default constructor. 
     * @throws BackEndException 
     */
    public MarketRatingCalculationsBean() throws BackEndException {
    	try {
			this.properties = SystemProperties.getLinearProperties();
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }

    public void setUp(Container container) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in void MarketRatingCalculationsBean.setUp() throws BackEndException"));
    	try {
	    	ejbLogger.debug(new StandardLogMessage("loading every updated issues"));
	    	
	    	it.ccg.auditing.elements.List issuesList = new it.ccg.auditing.elements.List();
	    	issuesList.setType("Issues");
			container.setList(issuesList);
			
	    	//carico tutti i valore delle issues dove la data di inserimento valore � pi� vicina alla data odierna 
	    	List<RctIssFldEntity> issues =  this.rctIssFldEAO.retrieveLatestIssFld();
	    	ejbLogger.debug(new StandardLogMessage("issues retrieved "+issues.size()));
	    	ejbLogger.debug(new StandardLogMessage("loading transcoding values"));
	    	//carico i transcode per i ratings dei vari infoproviders
	    	Map<String, RctTrscodeEntity> fitchTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("F");
	    	Map<String, RctTrscodeEntity> moodysTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("M");
	    	Map<String, RctTrscodeEntity> sPTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("S");
	    	
	    	
	    	//mappa che contiene gli arraylist utilizzato per calcolare la deviazione standard
	    	Map <Integer,RatingClass> sprdMap= new HashMap<Integer,RatingClass>();
	    	sprdMap.put(1, new RatingClass());sprdMap.put(2, new RatingClass());sprdMap.put(3, new RatingClass());sprdMap.put(4, new RatingClass());
	    	sprdMap.put(5, new RatingClass());sprdMap.put(6, new RatingClass());sprdMap.put(7, new RatingClass());sprdMap.put(8, new RatingClass());
	    	sprdMap.put(9, new RatingClass());sprdMap.put(10, new RatingClass());sprdMap.put(11, new RatingClass());sprdMap.put(12, new RatingClass());
	    	sprdMap.put(13, new RatingClass());sprdMap.put(14, new RatingClass());sprdMap.put(15, new RatingClass());sprdMap.put(16, new RatingClass());
	    	sprdMap.put(17, new RatingClass());
	    	
	    	
	    	ejbLogger.debug(new StandardLogMessage("starting calculation"));
	    	//trascodifico tutti i ratings
	    	issueCycle: for (int idx =0 ;idx<issues.size(); idx++){
	    		
	    		////
	    		Container issuesContainer = new Container();
	    		issuesContainer.setType("Issue");
	    		issuesContainer.setId(issues.get(idx).getId().getRCode()+"");
	    		issuesContainer.setValue(issues.get(idx).getDsplyName());
				Attribute timeAttribute = new Attribute();
				timeAttribute.setName("Time");
				timeAttribute.setValue(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date()));
				issuesContainer.getAttribute().add(timeAttribute);
				
				
				Obj marketObj = new Obj();
				marketObj.setType("Market Model");
	    		////
	    		
	    		ejbLogger.debug(new StandardLogMessage("(issues.get(idx).getMtStOtrSpr().doubleValue()<0 || " +
	    												"issues.get(idx).getMtStOtrSpr().doubleValue()>10000 ||" +
	    												"issues.get(idx).getMtStOtrSpr().doubleValue()==0)||" +
	    												"((issues.get(idx).getFitchRtg()==null || issues.get(idx).getFitchRtg().equalsIgnoreCase(\"\") || issues.get(idx).getFitchRtg().equalsIgnoreCase(\"WD\") || issues.get(idx).getFitchRtg().equalsIgnoreCase(\"NR\") || issues.get(idx).getFitchRtg().equalsIgnoreCase(\"WR\")) &&" +
	    												" (issues.get(idx).getMoodRtg()==null || issues.get(idx).getMoodRtg().equalsIgnoreCase(\"\") || issues.get(idx).getMoodRtg().equalsIgnoreCase(\"WD\") || issues.get(idx).getMoodRtg().equalsIgnoreCase(\"NR\") || issues.get(idx).getMoodRtg().equalsIgnoreCase(\"WR\")) && " +
	    												" (issues.get(idx).getSpRtg()==null || issues.get(idx).getSpRtg().equalsIgnoreCase(\"\") || issues.get(idx).getSpRtg().equalsIgnoreCase(\"WD\") || issues.get(idx).getSpRtg().equalsIgnoreCase(\"NR\")|| issues.get(idx).getSpRtg().equalsIgnoreCase(\"WR\"))) "+
	    												((issues.get(idx).getMtStOtrSpr().doubleValue()<0 || issues.get(idx).getMtStOtrSpr().doubleValue()>10000 || issues.get(idx).getMtStOtrSpr().doubleValue()==0)||
										    			((issues.get(idx).getFitchRtg()==null || issues.get(idx).getFitchRtg().equalsIgnoreCase("") || issues.get(idx).getFitchRtg().equalsIgnoreCase("WD") || issues.get(idx).getFitchRtg().equalsIgnoreCase("NR") || issues.get(idx).getFitchRtg().equalsIgnoreCase("WR")) &&
										    			 (issues.get(idx).getMoodRtg()==null || issues.get(idx).getMoodRtg().equalsIgnoreCase("") || issues.get(idx).getMoodRtg().equalsIgnoreCase("WD") || issues.get(idx).getMoodRtg().equalsIgnoreCase("NR") || issues.get(idx).getMoodRtg().equalsIgnoreCase("WR")) &&
										    			 (issues.get(idx).getSpRtg()==null || issues.get(idx).getSpRtg().equalsIgnoreCase("") || issues.get(idx).getSpRtg().equalsIgnoreCase("WD") || issues.get(idx).getSpRtg().equalsIgnoreCase("NR") || issues.get(idx).getSpRtg().equalsIgnoreCase("WR"))))));
	    		
	    		if ((issues.get(idx).getMtStOtrSpr().doubleValue()<0 || 
	    			 issues.get(idx).getMtStOtrSpr().doubleValue()>10000 || 
	    			 issues.get(idx).getMtStOtrSpr().doubleValue()==0)||
	    			((issues.get(idx).getFitchRtg()==null || issues.get(idx).getFitchRtg().equalsIgnoreCase("") || issues.get(idx).getFitchRtg().equalsIgnoreCase("WD") || issues.get(idx).getFitchRtg().equalsIgnoreCase("NR") || issues.get(idx).getFitchRtg().equalsIgnoreCase("WR")) &&
	    			 (issues.get(idx).getMoodRtg()==null || issues.get(idx).getMoodRtg().equalsIgnoreCase("") || issues.get(idx).getMoodRtg().equalsIgnoreCase("WD") || issues.get(idx).getMoodRtg().equalsIgnoreCase("NR") || issues.get(idx).getMoodRtg().equalsIgnoreCase("WR")) &&
	    			 (issues.get(idx).getSpRtg()==null || issues.get(idx).getSpRtg().equalsIgnoreCase("") || issues.get(idx).getSpRtg().equalsIgnoreCase("WD") || issues.get(idx).getSpRtg().equalsIgnoreCase("NR") || issues.get(idx).getSpRtg().equalsIgnoreCase("WR")))){
	    			calcLogger.debug(new StandardLogMessage("issue "+issues.get(idx).getDsplyName()+" excluded spread= "+issues.get(idx).getMtStOtrSpr()));
	    			Attribute issueAttribute = new Attribute();
	    			issueAttribute.setValue("issue "+issues.get(idx).getDsplyName()+" excluded spread= "+issues.get(idx).getMtStOtrSpr()+" fitch rating= \""+issues.get(idx).getFitchRtg()+"\", moodys rating= \""+issues.get(idx).getMoodRtg()+"\" sp rating= \""+issues.get(idx).getSpRtg()+"\"");
	    			issuesContainer.getAttribute().add(issueAttribute);
	    			issuesList.getContainer().add(issuesContainer);
	    			//TODO
	    			continue issueCycle;
	    		}
	    		ejbLogger.debug(new StandardLogMessage("issues retrieved "+issues.size()));
	    		ejbLogger.debug(new StandardLogMessage("issue spread "+issues.get(idx).getMtStOtrSpr()));
	    		calcLogger.debug(new StandardLogMessage("issue "+issues.get(idx).getDsplyName()+" spread= "+issues.get(idx).getMtStOtrSpr()));
	    		double divRtg=0;
				double avgRtg=0;
				double sumRtg = 0;
				if (issues.get(idx).getFitchRtg()!=null && !issues.get(idx).getFitchRtg().equalsIgnoreCase("") && !issues.get(idx).getFitchRtg().equalsIgnoreCase("WD") && !issues.get(idx).getFitchRtg().equalsIgnoreCase("NR") && !issues.get(idx).getFitchRtg().equalsIgnoreCase("WR")){
					ejbLogger.debug(new StandardLogMessage("fitch ratings "+issues.get(idx).getFitchRtg()));
					sumRtg += (fitchTranscode.get(issues.get(idx).getFitchRtg()))!=null ? fitchTranscode.get(issues.get(idx).getFitchRtg()).getMinrtg().intValueExact() : 17;
					issues.get(idx).setFithcTrsc((fitchTranscode.get(issues.get(idx).getFitchRtg()))!=null?fitchTranscode.get(issues.get(idx).getFitchRtg()).getMinrtg().intValueExact():17);
					divRtg++;
					/////////////////
					Attribute fitchAttribute = new Attribute();
					fitchAttribute.setName("FitchRating");
					fitchAttribute.setValue(issues.get(idx).getFitchRtg());
	    			issuesContainer.getAttribute().add(fitchAttribute);
	    			Attribute fitchTranscodeAttribute = new Attribute();
	    			fitchTranscodeAttribute.setName("FitchTranscode");
	    			fitchTranscodeAttribute.setValue(issues.get(idx).getFithcTrsc()+"");
	    			issuesContainer.getAttribute().add(fitchTranscodeAttribute);
				}
				
				if (issues.get(idx).getMoodRtg()!=null && !issues.get(idx).getMoodRtg().equalsIgnoreCase("") && !issues.get(idx).getMoodRtg().equalsIgnoreCase("WD") && !issues.get(idx).getMoodRtg().equalsIgnoreCase("NR") && !issues.get(idx).getMoodRtg().equalsIgnoreCase("WR")){
					ejbLogger.debug(new StandardLogMessage("moody's ratings "+issues.get(idx).getMoodRtg()));
					sumRtg += (moodysTranscode.get(issues.get(idx).getMoodRtg()))!=null?moodysTranscode.get(issues.get(idx).getMoodRtg()).getMinrtg().intValueExact():17;
					issues.get(idx).setMoodTrsc((moodysTranscode.get(issues.get(idx).getMoodRtg()))!=null?moodysTranscode.get(issues.get(idx).getMoodRtg()).getMinrtg().intValueExact():17);
					divRtg++;
					////////////
					Attribute moodysAttribute = new Attribute();
					moodysAttribute.setName("MoodysRating");
					moodysAttribute.setValue(issues.get(idx).getMoodRtg());
	    			issuesContainer.getAttribute().add(moodysAttribute);
	    			Attribute moodysTranscodeAttribute = new Attribute();
	    			moodysTranscodeAttribute.setName("MoodysTranscode");
	    			moodysTranscodeAttribute.setValue(issues.get(idx).getMoodTrsc()+"");
	    			issuesContainer.getAttribute().add(moodysTranscodeAttribute);
				}
				
				if (issues.get(idx).getSpRtg()!=null && !issues.get(idx).getSpRtg().equalsIgnoreCase("") && !issues.get(idx).getSpRtg().equalsIgnoreCase("WD") && !issues.get(idx).getSpRtg().equalsIgnoreCase("NR") && !issues.get(idx).getSpRtg().equalsIgnoreCase("WR")){
					ejbLogger.debug(new StandardLogMessage("S&P ratings "+issues.get(idx).getSpRtg()));
					sumRtg += (sPTranscode.get(issues.get(idx).getSpRtg()))!= null?sPTranscode.get(issues.get(idx).getSpRtg()).getMinrtg().intValueExact():17;
					issues.get(idx).setSpTrsc((sPTranscode.get(issues.get(idx).getSpRtg()))!= null?sPTranscode.get(issues.get(idx).getSpRtg()).getMinrtg().intValueExact():17);
					divRtg++;
					////////////
					Attribute spAttribute = new Attribute();
					spAttribute.setName("SPRating");
					spAttribute.setValue(issues.get(idx).getSpRtg());
	    			issuesContainer.getAttribute().add(spAttribute);
	    			Attribute spTranscodeAttribute = new Attribute();
	    			spTranscodeAttribute.setName("SPTranscode");
	    			spTranscodeAttribute.setValue(issues.get(idx).getSpTrsc()+"");
	    			issuesContainer.getAttribute().add(spTranscodeAttribute);
				}
				
				avgRtg = sumRtg / divRtg;
				calcLogger.debug(new StandardLogMessage("sum for issue "+issues.get(idx).getDsplyName()+" = "+sumRtg));
				calcLogger.debug(new StandardLogMessage("div for issue "+issues.get(idx).getDsplyName()+" = "+divRtg));
				calcLogger.debug(new StandardLogMessage("average rating for issue "+issues.get(idx).getDsplyName()+" = "+ avgRtg ));
				/////////////////
				Attribute sumAttribute = new Attribute();
				sumAttribute.setName("Sum");
				sumAttribute.setValue(sumRtg+"");
    			issuesContainer.getAttribute().add(sumAttribute);
    			Attribute divAttribute = new Attribute();
    			divAttribute.setName("Div");
    			divAttribute.setValue(divRtg+"");
    			issuesContainer.getAttribute().add(divAttribute);
    			Attribute avgAttribute = new Attribute();
    			avgAttribute.setName("AverageRating");
    			avgAttribute.setValue(avgRtg+"");
    			issuesContainer.getAttribute().add(avgAttribute);
    			issuesList.getContainer().add(issuesContainer);
    			////////
				issues.get(idx).setAvrgRtg((int)Math.round(avgRtg));
				
				switch (issues.get(idx).getAvrgRtg()){
					case 1:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(1).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 1"));
						break;
					case 2:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(2).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 2"));
						break;
					case 3:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(3).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 3"));
						break;
					case 4:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(4).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 4"));
						break;
					case 5:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(5).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 5"));
						break;
					case 6:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(6).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 6"));
						break;
					case 7:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(7).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 7"));
						break;
					case 8:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(8).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 8"));
						break;
					case 9:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(9).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 9"));
						break;
					case 10:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(10).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 10"));
						break;
					case 11:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(11).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 11"));
						break;
					case 12:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(12).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 12"));
						break;
					case 13:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(13).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 13"));
						break;
					case 14:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(14).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 14"));
						break;
					case 15:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(15).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 15"));
						break;
					case 16:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(16).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 16"));
						break;
					case 17:
						calcLogger.debug(new StandardLogMessage("adding issue"));
						sprdMap.get(17).getIssuer().add(issues.get(idx));
						calcLogger.debug(new StandardLogMessage("added issue to rank 17"));
						break;
					default:
						break;
				}
	    	}
	    	 
	    	SimpleRegression linearRegretion = new SimpleRegression();
	    	Set<Integer> keys = sprdMap.keySet();
	    	
	    	for(int i :keys){
	    		
		    	Container rankContainer = new Container();
		    	rankContainer.setType("Rank");
		    	rankContainer.setId(i+"");
		    	
		    	Attribute issuesNAttribute = new Attribute();
		    	issuesNAttribute.setName("Issues");
		    	issuesNAttribute.setValue(sprdMap.get(i).getIssuer().size()+"");
		    	rankContainer.getAttribute().add(issuesNAttribute);
    			
	    		ejbLogger.debug(new StandardLogMessage("Present "+sprdMap.get(i).getIssuer().size() +" issues for rank "+i));
	    		calcLogger.debug(new StandardLogMessage("Present "+sprdMap.get(i).getIssuer().size() +" issues for rank "+i));
	    		if (sprdMap.get(i).getIssuer().size()>0){
		    		calcLogger.debug(new StandardLogMessage("adding "+sprdMap.get(i).getLnAvgStdDev()));
		    		calcLogger.debug(new StandardLogMessage("Calculations for rank "+i));
		    		linearRegretion.addData(sprdMap.get(i).getLnAvgStdDev(),(double)i);
		    		
		    		//
		    		Attribute AvgSpreadAttribute = new Attribute();
		    		AvgSpreadAttribute.setName("AverageSpread");
		    		AvgSpreadAttribute.setValue(sprdMap.get(i).getAvgSpread()+"");
		    		rankContainer.getAttribute().add(AvgSpreadAttribute);
		    		Attribute AvgStdDevAttribute = new Attribute();
		    		AvgStdDevAttribute.setName("AvgStandardDeviation");
		    		AvgStdDevAttribute.setValue(sprdMap.get(i).getAvgStdDev()+"");
		    		rankContainer.getAttribute().add(AvgStdDevAttribute);
		    		Attribute maxStdDevAttribute = new Attribute();
		    		maxStdDevAttribute.setName("MaxStandardDeviation");
		    		maxStdDevAttribute.setValue(sprdMap.get(i).getMaxStdDev()+"");
		    		rankContainer.getAttribute().add(maxStdDevAttribute);
		    		Attribute minStdDevAttribute = new Attribute();
		    		minStdDevAttribute.setName("MinStandardDeviation");
		    		minStdDevAttribute.setValue(sprdMap.get(i).getMinStdDev()+"");
		    		rankContainer.getAttribute().add(minStdDevAttribute);
		    		Attribute StdDevAttribute = new Attribute();
		    		StdDevAttribute.setName("StandardDeviation");
		    		StdDevAttribute.setValue(sprdMap.get(i).getStdDeviation()+"");
		    		rankContainer.getAttribute().add(StdDevAttribute);
		    		Attribute lnAvgStdDevAttribute = new Attribute();
		    		lnAvgStdDevAttribute.setName("LnAvgStandardDeviation");
		    		lnAvgStdDevAttribute.setValue(sprdMap.get(i).getLnAvgStdDev()+"");
			    	rankContainer.getAttribute().add(lnAvgStdDevAttribute);
	    		}
	    	}
	    	
	    	Attribute slopeAttribute = new Attribute();
	    	slopeAttribute.setName("Slope");
	    	slopeAttribute.setValue(linearRegretion.getSlope()+"");
	    	container.getAttribute().add(slopeAttribute);
	    	Attribute offsetAttribute = new Attribute();
	    	offsetAttribute.setName("Offset");
	    	offsetAttribute.setValue(linearRegretion.getIntercept()+"");
	    	container.getAttribute().add(offsetAttribute);
	    	
	    	calcLogger.info(new StandardLogMessage("slope market "+linearRegretion.getSlope()));
	    	calcLogger.info(new StandardLogMessage("offset market "+linearRegretion.getIntercept()));
	    	this.properties.put("slope.Market", linearRegretion.getSlope()+"");
			this.properties.put("offset.Market",linearRegretion.getIntercept()+"");
			
			ejbLogger.debug(new StandardLogMessage("store path "+SystemProperties.getLinearPropertiesFileAbsPath()));
			this.properties.store(new FileWriter(SystemProperties.getLinearPropertiesFileAbsPath()), null);
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
		}
    }
    
    public Map<Integer,RctRatingEntity> dailyRun(List<RctBankEntity> rctBanks,Map<Integer,RctRatingEntity> ratings,Map<Integer,Container> bankMap) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in MarketRatingCalculationsBean.dailyRun"));
		Map<String, RctTrscodeEntity> internalTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("I");
		try {
			
			bankCycle: for(RctBankEntity bank : rctBanks){				
				Container bankContainer = new Container();
				bankContainer.setType("Bank");
				bankContainer.setId(bank.getBankId()+"");
				bankContainer.setValue(bank.getBankName());
				Obj marketObj = new Obj();
				marketObj.setType("Market Model");
				
				Attribute slopeMarketAttr = new Attribute();
				slopeMarketAttr.setName("Market slope");
				slopeMarketAttr.setValue(this.properties.getProperty("slope.Market"));
								
				Attribute offsetMarketAttr = new Attribute();
				offsetMarketAttr.setName("Market offset");
				offsetMarketAttr.setValue(this.properties.getProperty("offset.Market"));
				
				marketObj.getAttributeList().add(slopeMarketAttr);
				marketObj.getAttributeList().add(offsetMarketAttr);
				
				calcLogger.info(new StandardLogMessage("Bank "+bank.getBankName()+" id "+bank.getBankId()+";"));
				if(bank.getRTicker()==null || bank.getRTicker().equalsIgnoreCase("")){
					ejbLogger.info(new StandardLogMessage("No reuters ticker for bank "+bank.getBankName() +" "+bank.getBankId()));
					calcLogger.info(new StandardLogMessage("No reuters ticker for bank "+bank.getBankName() +";"));
					
					Attribute noReutersCodeAttr = new Attribute();
					noReutersCodeAttr.setValue("No reuters ticker for bank "+bank.getBankName());
					marketObj.getAttributeList().add(noReutersCodeAttr);
					bankContainer.getObj().add(marketObj);
					if(bankMap.get(bank.getBankId())!=null ){
						bankMap.get(bank.getBankId()).getObj().add(marketObj);
					}else{
						bankContainer.getObj().add(marketObj);
						bankMap.put(bank.getBankId(), bankContainer);
					}
										
					continue bankCycle;
				}
				//leggo le issues per ogni banca
				List<RctIssuesEntity> issues= rctIssuesEAO.retrieveLatestIssuesByTicker(bank.getRTicker());
				if(issues.size()==0){
					ejbLogger.info(new StandardLogMessage("No issues for bank "+bank.getBankName() +" "+bank.getBankId()));
					calcLogger.info(new StandardLogMessage("No issues for bank "+bank.getBankName() +";"));
					Attribute noReutersCodeAttr = new Attribute();
					noReutersCodeAttr.setValue("No reuters ticker for bank "+bank.getBankName());
					marketObj.getAttributeList().add(noReutersCodeAttr);
					bankContainer.getObj().add(marketObj);
					if(bankMap.get(bank.getBankId())!=null ){
						bankMap.get(bank.getBankId()).getObj().add(marketObj);
					}else{
						bankContainer.getObj().add(marketObj);
						bankMap.put(bank.getBankId(), bankContainer);
					}
					
					continue bankCycle;
				}
				double result = 0;
				double sumSpread=0;
				int divSpread=0;
				//inizio l'immenso calcolo
				for (RctIssuesEntity issue: issues){
					
					//calcolo lo spread medio di tutte le issues per la banca
					if(issue.getMtStOtrSpr()!=null && issue.getMtStOtrSpr().doubleValue() !=0){
						sumSpread+=issue.getMtStOtrSpr().doubleValue();
						divSpread++;
					}
				}
				
				double avgSpread = sumSpread/divSpread;
				
				Attribute avgSpreadAttr = new Attribute();
				avgSpreadAttr.setName("AveregeSpread");
				avgSpreadAttr.setValue(avgSpread+"");
				marketObj.getAttributeList().add(avgSpreadAttr);
				
				Log logarithm = new Log();
				ejbLogger.info(new StandardLogMessage("logarithm calculation"));
				Double slopeMarket = new Double(this.properties.getProperty("slope.Market"));
				Double offsetMarket = new Double(this.properties.getProperty("offset.Market"));
				
				Attribute lnScoreAttr = new Attribute();
				lnScoreAttr.setName("LnScore");
				lnScoreAttr.setValue(logarithm.value(avgSpread)+"");
				marketObj.getAttributeList().add(lnScoreAttr);
				
				calcLogger.info(new StandardLogMessage("ln(score) "+logarithm.value(avgSpread)+";"));
				calcLogger.debug(new StandardLogMessage("formula "+slopeMarket +" * "+logarithm.value(avgSpread)+" + "+offsetMarket+";"));
				result = (slopeMarket * logarithm.value(avgSpread))+offsetMarket;
				
				Attribute resultAttr = new Attribute();
				resultAttr.setName("Result");
				resultAttr.setValue((int) Math.round(result)+"");
				marketObj.getAttributeList().add(lnScoreAttr);
				
				calcLogger.debug(new StandardLogMessage("result "+(int) Math.round(result)+";"));
				int intResult = (int) Math.round(result);
				calcLogger.info(new StandardLogMessage("maketRating "+intResult+";"));
				
				if (result>17){
					result=17;
				}else if(result<1){
					result=1;
				}
				
				//transcode to output rank
				int finalResult=0;
				Set<String> interalrtg = internalTranscode.keySet();
				for (String rtg:interalrtg){
					RctTrscodeEntity appoTrnsc = internalTranscode.get(rtg);
					if (intResult>=17){
						calcLogger.info(new StandardLogMessage("Market rating scaled rank "+7));
						finalResult = 7;
						break;
					}else if(intResult < appoTrnsc.getMaxrtg().intValue() && intResult>=appoTrnsc.getMinrtg().intValue()){
						calcLogger.info(new StandardLogMessage("Market rating scaled rank "+appoTrnsc.getId().getRanking()));
						finalResult=appoTrnsc.getId().getRanking();
						break;
					}
				}
				
				Attribute ratingAttr = new Attribute();
				ratingAttr.setName("Rating");
				ratingAttr.setValue(finalResult+"");
				marketObj.getAttributeList().add(ratingAttr);
				
				if (ratings.get(bank.getBankId())!=null){
					ratings.get(bank.getBankId()).setSpreadrtg(new BigDecimal(finalResult));
				}else{
					RctRatingEntity ratingEntity = new RctRatingEntity();
					ratingEntity.setBankid(bank.getBankId());
	
					ratingEntity.setStatus("N");
					ratingEntity.setSpreadrtg(new BigDecimal(finalResult));
					
					ratings.put(ratingEntity.getBankid(), ratingEntity);
					
				}
				
				if(bankMap.get(bank.getBankId())!=null ){
					bankMap.get(bank.getBankId()).getObj().add(marketObj);
				}else{
					bankContainer.getObj().add(marketObj);
					bankMap.put(bank.getBankId(), bankContainer);
				}
				
			}
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
		}
    	return ratings;
	}
}

