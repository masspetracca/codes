package it.ccg.irejb.server.business;

import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.system.SystemProperties;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

public class FitchCSVGenerator {
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	private File csvFile;
	private List<RctBankEntity> banks;
	private Properties properties;
	
	public FitchCSVGenerator(List<RctBankEntity> in) throws BackEndException{
		logger.debug(new StandardLogMessage("in FitchCSVGenerator.FitchCSVGenerator(List<RctBankEntity>)"));
		try {
			this.properties = SystemProperties.getSystemProperties();
			this.banks = in;
			csvFile = new File(System.getProperty("user.install.root")+"/temp/"+this.properties.getProperty("fitch.file.name"));
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		}
	}
	
	public File getFitchCsvFile() throws BackEndException{
		logger.info(new StandardLogMessage("in FitchCSVGenerator.getFitchCsvFile()"));
		try {
			FileWriter out = new FileWriter(csvFile);
			out.append("CUSIP,ISIN,Customer Identifier,VS ID,Agent Common ID,Security Common ID,Agent ID");
			out.append('\n');
	
			for(int i = 0;i<banks.size();i++){
				out.append(",,"+banks.get(i).getBankName()+",,"+banks.get(i).getFitchCode()+",,");
				out.append('\n');
			}
			out.flush();
			out.close();
			logger.debug(new StandardLogMessage("return"));
			return csvFile;
			
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw new BackEndException(e);
		}
	}
	
}
