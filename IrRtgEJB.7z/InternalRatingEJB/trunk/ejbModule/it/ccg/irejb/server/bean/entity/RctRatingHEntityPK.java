package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.*;

/**
 * The primary key class for the RCTRATINGH database table.
 * 
 */
@Embeddable
public class RctRatingHEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int bankid;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(unique=true, nullable=false)
	private java.util.Date ratingdate;
    
    @Temporal( TemporalType.TIMESTAMP)
    @Column(nullable=false)
	private Timestamp apprdate;
    
    
	public void setApprdate(Timestamp apprdate) {
		this.apprdate = apprdate;
	}
	public RctRatingHEntityPK() {
    }
	public int getBankid() {
		return this.bankid;
	}
	public void setBankid(int bankid) {
		this.bankid = bankid;
	}
	public java.util.Date getRatingdate() {
		return this.ratingdate;
	}
	public void setRatingdate(java.util.Date ratingdate) {
		this.ratingdate = ratingdate;
	}
	
	/**
	 * @return the apprdate
	 */
	public Timestamp getApprdate() {
		return apprdate;
	}
	/**
	 * @param apprdate the apprdate to set
	 */

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RctRatingHEntityPK)) {
			return false;
		}
		RctRatingHEntityPK castOther = (RctRatingHEntityPK)other;
		return (this.bankid == castOther.bankid) && this.ratingdate.equals(castOther.ratingdate) && this.apprdate.equals(castOther.apprdate);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.bankid;
		hash = hash * prime + this.ratingdate.hashCode();
		hash = hash * prime + this.apprdate.hashCode();
		
		return hash;
    }
}