package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctVarsEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

public interface RctVarsEAOLocal {

	public void insertRtcVar(RctVarsEntity entity) throws BackEndException;
    public void deleteRtcVar(RctVarsEntity entity) throws BackEndException;
    public void updateRtcVar(RctVarsEntity entity) throws BackEndException;
    public RctVarsEntity retrieveRtcVarById(int varId,String provider) throws BackEndException;
	public List<RctVarsEntity> retrieveRtcVarByVarId(int varId) throws BackEndException;
	public List<RctVarsEntity> retrieveRtcVarByProvider(String provider) throws BackEndException;
	public List<RctVarsEntity> retrieveRtcVarByYearSetup(String yearSetup) throws BackEndException;
	public List<RctVarsEntity> retrieveRtcVarByStatus(String status) throws BackEndException;
	public List<RctVarsEntity> retrieveRtcVarByDailyRun(String dailyRun) throws BackEndException;
	public List<RctVarsEntity> retrieveRtcVarForDailyRunCalc() throws BackEndException;
	public List<RctVarsEntity> retrieveEveryRtcVar() throws BackEndException;
}
