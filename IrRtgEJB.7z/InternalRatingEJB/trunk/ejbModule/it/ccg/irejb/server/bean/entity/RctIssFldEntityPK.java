package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RCTISSFLD database table.
 * 
 */
@Embeddable
public class RctIssFldEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false, length=20)
	private String rCode;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(unique=true, nullable=false)
	private java.util.Date valueDate;

    public RctIssFldEntityPK() {
    }
	public String getRCode() {
		return this.rCode;
	}
	public void setRCode(String rCode) {
		this.rCode = rCode;
	}
	public java.util.Date getValueDate() {
		return this.valueDate;
	}
	public void setValueDate(java.util.Date valueDate) {
		this.valueDate = valueDate;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RctIssFldEntityPK)) {
			return false;
		}
		RctIssFldEntityPK castOther = (RctIssFldEntityPK)other;
		return 
			this.rCode.equals(castOther.rCode)
			&& this.valueDate.equals(castOther.valueDate);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.rCode.hashCode();
		hash = hash * prime + this.valueDate.hashCode();
		
		return hash;
    }
}