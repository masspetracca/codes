package it.ccg.irejb.server.exception;

public class BackEndException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8141489039484965765L;

	public BackEndException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BackEndException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BackEndException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BackEndException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
