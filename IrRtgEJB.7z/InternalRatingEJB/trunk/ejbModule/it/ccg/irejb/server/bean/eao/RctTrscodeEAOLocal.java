package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctTrscodeEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;
import java.util.Map;

public interface RctTrscodeEAOLocal {

	public void insertRtcTranscode(RctTrscodeEntity entity);    
    public void deleteRtcTranscode(RctTrscodeEntity entity);
    public void updateRtcTranscode(RctTrscodeEntity entity);
    public RctTrscodeEntity retrieveRtcTranscodeById(String ranking,String provider) throws BackEndException;
	public List<RctTrscodeEntity> retrieveRtcTranscodeByRtgCode(String rtgCode);
	public Map<String, RctTrscodeEntity> retrieveMapRtcTranscodeByProvider(String provider);
}
