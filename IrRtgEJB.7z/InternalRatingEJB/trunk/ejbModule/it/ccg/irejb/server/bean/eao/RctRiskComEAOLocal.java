package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctRiskComEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

public interface RctRiskComEAOLocal {
	public void insertRiskCommittee(RctRiskComEntity entity);   
    public void deleteRiskCommittee(RctRiskComEntity entity);    
    public void updateRiskCommittee(RctRiskComEntity entity);   
    public RctRiskComEntity retrieveRiskCommitteeById(String rcCode);
	public List<RctRiskComEntity> retrieveRiskCommitteeByRcDate(String rcDate) throws BackEndException;
}
