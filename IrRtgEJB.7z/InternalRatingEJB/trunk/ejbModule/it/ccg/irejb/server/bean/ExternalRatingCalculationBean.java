package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.bean.eao.RctHisRtgEAOLocal;
import it.ccg.irejb.server.bean.eao.RctTrscodeEAOLocal;
import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.bean.entity.RctHisRtgEntity;
import it.ccg.irejb.server.bean.entity.RctRatingEntity;
import it.ccg.irejb.server.bean.entity.RctTrscodeEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.auditing.elements.Attribute;
import it.ccg.auditing.elements.Container;
import it.ccg.auditing.elements.Obj;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ExternalRatingCalculation
 */
@Stateless
@Local(ExternalRatingCalculationBeanLocal.class)
public class ExternalRatingCalculationBean implements ExternalRatingCalculationBeanLocal {

	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private Logger calcLogger = Logger.getLogger(LoggerFactory.CALCULATION_LOGGER);
	
	@EJB
	private RctHisRtgEAOLocal rctHisRtgEAO;
	
	@EJB
	private RctTrscodeEAOLocal rctTrscodeEAO;
	
    /**
     * Default constructor. 
     */
    public ExternalRatingCalculationBean() {
        // TODO Auto-generated constructor stub
    }
    
    public Map<Integer,RctRatingEntity> dailyRun(List<RctBankEntity> rctBanks,Map<Integer,RctRatingEntity> ratings,Map<Integer,Container> bankMap) throws BackEndException{
    	Map<String, RctTrscodeEntity> fitchTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("F");
    	Map<String, RctTrscodeEntity> moodysTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("M");
    	Map<String, RctTrscodeEntity> sPTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("S");
    	Map<String, RctTrscodeEntity> internalTranscode = rctTrscodeEAO.retrieveMapRtcTranscodeByProvider("I");
    	
    	bankCycle: for(RctBankEntity bank : rctBanks){	
    		Container bankContainer = new Container();
    		bankContainer.setType("Bank");
			bankContainer.setId(bank.getBankId()+"");
			bankContainer.setValue(bank.getBankName());
			Attribute timeAttribute = new Attribute();
			timeAttribute.setName("Time");
			timeAttribute.setValue(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date()));
			bankContainer.getAttribute().add(timeAttribute);
			Obj externalObj = new Obj();
			externalObj.setType("External Model");
			
			calcLogger.info(new StandardLogMessage("Bank "+bank.getBankName()+" id "+bank.getBankId()+";"));
			if(bank.getBloombCode()==null || bank.getBloombCode().equalsIgnoreCase("")){
				ejbLogger.info(new StandardLogMessage("No bloomberg code for bank "+bank.getBankName() +" "+bank.getBankId()));
				calcLogger.info(new StandardLogMessage("No bloomberg code for bank "+bank.getBankName() +";"));
				
				Attribute noBloomCodeAttr = new Attribute();
				noBloomCodeAttr.setValue("No bloomberg code for bank "+bank.getBankName());
				externalObj.getAttributeList().add(noBloomCodeAttr);
				if(bankMap.get(bank.getBankId())!=null ){
					bankMap.get(bank.getBankId()).getObj().add(externalObj);
				}else{
					bankContainer.getObj().add(externalObj);
					bankMap.put(bank.getBankId(), bankContainer);
				}
				
				continue bankCycle;
			}
			//leggo le issues per ogni banca
			List<RctHisRtgEntity> extRatings= rctHisRtgEAO.retrieveLatestRatingByBlombCode(bank.getBloombCode());
			
			if(extRatings.size()==0){
				ejbLogger.info(new StandardLogMessage("No ratings for bank "+bank.getBankName() +" "+bank.getBankId()));
				calcLogger.info(new StandardLogMessage("No ratings for bank "+bank.getBankName() +";"));
				
				Attribute noRAtingAttr = new Attribute();
				noRAtingAttr.setValue("No ratings for bank "+bank.getBankName());
				externalObj.getAttributeList().add(noRAtingAttr);
				if(bankMap.get(bank.getBankId())!=null ){
					bankMap.get(bank.getBankId()).getObj().add(externalObj);
				}else{
					bankContainer.getObj().add(externalObj);
					bankMap.put(bank.getBankId(), bankContainer);
				}
				
				continue bankCycle;
			}
			
			RctHisRtgEntity appoRating = extRatings.get(0);
			ejbLogger.debug(new StandardLogMessage("(appoRating.getFitchRtg()==null || appoRating.getFitchRtg().equalsIgnoreCase(\"\") || appoRating.getFitchRtg().equalsIgnoreCase(\"WD\") || appoRating.getFitchRtg().equalsIgnoreCase(\"NR\") || appoRating.getFitchRtg().equalsIgnoreCase(\"WR\") || appoRating.getFitchRtg().equalsIgnoreCase(\"N.A.\")) &&"
				                                  +"(appoRating.getMoodRtg()==null || appoRating.getMoodRtg().equalsIgnoreCase(\"\") || appoRating.getMoodRtg().equalsIgnoreCase(\"WD\") || appoRating.getMoodRtg().equalsIgnoreCase(\"NR\") || appoRating.getMoodRtg().equalsIgnoreCase(\"WR\") || appoRating.getFitchRtg().equalsIgnoreCase(\"N.A.\")) && "
				+"(appoRating.getSpRtg()==null || appoRating.getSpRtg().equalsIgnoreCase(\"\") || appoRating.getSpRtg().equalsIgnoreCase(\"WD\") || appoRating.getSpRtg().equalsIgnoreCase(\"NR\") || appoRating.getSpRtg().equalsIgnoreCase(\"WR\") || appoRating.getFitchRtg().equalsIgnoreCase(\"N.A.\"))"+
								((appoRating.getFitchRtg()==null || appoRating.getFitchRtg().equalsIgnoreCase("") || appoRating.getFitchRtg().equalsIgnoreCase("WD") || appoRating.getFitchRtg().equalsIgnoreCase("NR") || appoRating.getFitchRtg().equalsIgnoreCase("WR") || appoRating.getFitchRtg().equalsIgnoreCase("N.A.")) &&
										(appoRating.getMoodRtg()==null || appoRating.getMoodRtg().equalsIgnoreCase("") || appoRating.getMoodRtg().equalsIgnoreCase("WD") || appoRating.getMoodRtg().equalsIgnoreCase("NR") || appoRating.getMoodRtg().equalsIgnoreCase("WR") || appoRating.getFitchRtg().equalsIgnoreCase("N.A.")) &&
										(appoRating.getSpRtg()==null || appoRating.getSpRtg().equalsIgnoreCase("") || appoRating.getSpRtg().equalsIgnoreCase("WD") || appoRating.getSpRtg().equalsIgnoreCase("NR") || appoRating.getSpRtg().equalsIgnoreCase("WR") || appoRating.getFitchRtg().equalsIgnoreCase("N.A.")))));
			
			if ((appoRating.getFitchRtg()==null || appoRating.getFitchRtg().equalsIgnoreCase("") || appoRating.getFitchRtg().equalsIgnoreCase("WD") || appoRating.getFitchRtg().equalsIgnoreCase("NR") || appoRating.getFitchRtg().equalsIgnoreCase("WR") || appoRating.getFitchRtg().equalsIgnoreCase("N.A.")) &&
				(appoRating.getMoodRtg()==null || appoRating.getMoodRtg().equalsIgnoreCase("") || appoRating.getMoodRtg().equalsIgnoreCase("WD") || appoRating.getMoodRtg().equalsIgnoreCase("NR") || appoRating.getMoodRtg().equalsIgnoreCase("WR") || appoRating.getMoodRtg().equalsIgnoreCase("N.A.")) &&
				(appoRating.getSpRtg()==null || appoRating.getSpRtg().equalsIgnoreCase("") || appoRating.getSpRtg().equalsIgnoreCase("WD") || appoRating.getSpRtg().equalsIgnoreCase("NR") || appoRating.getSpRtg().equalsIgnoreCase("WR") || appoRating.getSpRtg().equalsIgnoreCase("N.A."))){
				calcLogger.debug(new StandardLogMessage("Bank "+bank.getBankName()+" excluded because has not rating available"));
				continue bankCycle;
			}
			
	    	double divRtg=0;
			double sumRtg = 0;
			double externalResult=0;
	    	//transcodifica
	    	if (appoRating.getFitchRtg()!=null && 
	    		!appoRating.getFitchRtg().equalsIgnoreCase("") && 
	    		!appoRating.getFitchRtg().equalsIgnoreCase("WD") && 
	    		!appoRating.getFitchRtg().equalsIgnoreCase("NR") && 
	    		!appoRating.getFitchRtg().equalsIgnoreCase("WR") &&
	    		!appoRating.getFitchRtg().equalsIgnoreCase("N.A.")){
				ejbLogger.debug(new StandardLogMessage("fitch ratings "+appoRating.getFitchRtg()));
				calcLogger.info(new StandardLogMessage("fitch ratings "+appoRating.getFitchRtg()));
				String appoFitchRating="";
				if(appoRating.getFitchRtg().indexOf("*") > 0){
					appoFitchRating = appoRating.getFitchRtg().substring(0,appoRating.getFitchRtg().indexOf("*-"));
				}else{
					appoFitchRating = appoRating.getFitchRtg();
				}
				
				Attribute fitchAttr = new Attribute();
				fitchAttr.setName("FitchRating");
				fitchAttr.setValue(appoRating.getFitchRtg());
				externalObj.getAttributeList().add(fitchAttr);
				
				appoRating.setFtcTrscRtg(((fitchTranscode.get(appoFitchRating.trim()))!=null ? fitchTranscode.get(appoFitchRating.trim()).getMinrtg().intValueExact() : 17));
				calcLogger.info(new StandardLogMessage("fitch transocded value "+((fitchTranscode.get(appoFitchRating.trim()))!=null ? fitchTranscode.get(appoFitchRating.trim()).getMinrtg().intValueExact() : 17)));
				
				Attribute fitchTransAttr = new Attribute();
				fitchTransAttr.setName("FitchTranscode");
				fitchTransAttr.setValue(appoRating.getFtcTrscRtg()+"");
				externalObj.getAttributeList().add(fitchTransAttr);
				
				sumRtg += appoRating.getFtcTrscRtg();
				ejbLogger.debug(new StandardLogMessage("fitch transcoded rating "+appoRating.getFtcTrscRtg()));
				divRtg++;
			}

			if (appoRating.getMoodRtg()!=null && 
				!appoRating.getMoodRtg().equalsIgnoreCase("") && 
				!appoRating.getMoodRtg().equalsIgnoreCase("WD") && 
				!appoRating.getMoodRtg().equalsIgnoreCase("NR") && 
				!appoRating.getMoodRtg().equalsIgnoreCase("WR") &&
	    		!appoRating.getMoodRtg().equalsIgnoreCase("N.A.")){
				ejbLogger.debug(new StandardLogMessage("moody's ratings "+appoRating.getMoodRtg()));
				calcLogger.info(new StandardLogMessage("moody's ratings "+appoRating.getMoodRtg()));
				
				String appoMoodysRating="";
				if(appoRating.getMoodRtg().indexOf("*") > 0){
					appoMoodysRating = appoRating.getMoodRtg().substring(0,appoRating.getMoodRtg().indexOf("*-"));
				}else{
					appoMoodysRating = appoRating.getMoodRtg();
				}
				
				Attribute moodysAttr = new Attribute();
				moodysAttr.setName("MoodysRating");
				moodysAttr.setValue(appoRating.getMoodRtg());
				externalObj.getAttributeList().add(moodysAttr);
				
				appoRating.setMdsTrscRtg(((moodysTranscode.get(appoMoodysRating.trim()))!=null ? moodysTranscode.get(appoMoodysRating.trim()).getMinrtg().intValueExact() : 17));
				calcLogger.info(new StandardLogMessage("moody's transocded value "+((moodysTranscode.get(appoMoodysRating.trim()))!=null ? moodysTranscode.get(appoMoodysRating.trim()).getMinrtg().intValueExact() : 17)));
				
				Attribute moodysTransAttr = new Attribute();
				moodysTransAttr.setName("MoodysTranscode");
				moodysTransAttr.setValue(appoRating.getMdsTrscRtg()+"");
				externalObj.getAttributeList().add(moodysTransAttr);
				
				sumRtg += appoRating.getMdsTrscRtg();
				ejbLogger.debug(new StandardLogMessage("moody's transcoded rating "+appoRating.getMdsTrscRtg()));
				divRtg++;
			}
			
			if (appoRating.getSpRtg()!=null && 
				!appoRating.getSpRtg().equalsIgnoreCase("") && 
				!appoRating.getSpRtg().equalsIgnoreCase("WD") && 
				!appoRating.getSpRtg().equalsIgnoreCase("NR") && 
				!appoRating.getSpRtg().equalsIgnoreCase("WR") &&
	    		!appoRating.getSpRtg().equalsIgnoreCase("N.A.")){
				ejbLogger.debug(new StandardLogMessage("S&P ratings "+appoRating.getSpRtg()));
				calcLogger.info(new StandardLogMessage("S&P ratings "+appoRating.getSpRtg()));
				
				String appoSPRating="";
				if(appoRating.getSpRtg().indexOf("*") > 0){
					appoSPRating = appoRating.getSpRtg().substring(0,appoRating.getSpRtg().indexOf("*-"));
				}else{
					appoSPRating = appoRating.getSpRtg();
				}
				
				Attribute sPAttr = new Attribute();
				sPAttr.setName("SPRating");
				sPAttr.setValue(appoRating.getSpRtg());
				externalObj.getAttributeList().add(sPAttr);
				
				appoRating.setSpTrscRtg(((sPTranscode.get(appoSPRating.trim()))!=null ? sPTranscode.get(appoSPRating.trim()).getMinrtg().intValueExact() : 17));
				calcLogger.info(new StandardLogMessage("S&P transocded value "+((sPTranscode.get(appoSPRating.trim()))!=null ? sPTranscode.get(appoSPRating.trim()).getMinrtg().intValueExact() : 17)));
								
				Attribute sPTransAttr = new Attribute();
				sPTransAttr.setName("SPTranscode");
				sPTransAttr.setValue(appoRating.getSpTrscRtg()+"");
				externalObj.getAttributeList().add(sPTransAttr);
				
				sumRtg += appoRating.getSpTrscRtg();
				ejbLogger.debug(new StandardLogMessage("S&P transcoded rating "+appoRating.getSpTrscRtg()));
				divRtg++;
			}
	    	
			externalResult = sumRtg/divRtg;
			
			Attribute resultAttr = new Attribute();
			resultAttr.setName("Result");
			resultAttr.setValue((int) Math.round(externalResult)+"");
			externalObj.getAttributeList().add(resultAttr);
			
			calcLogger.debug(new StandardLogMessage("result "+(int) Math.round(externalResult)+";"));
			int intResult = (int) Math.round(externalResult);
			calcLogger.info(new StandardLogMessage("externalRating "+intResult+";"));
			
			//transcode to output rank
			int finalResult=0;
			Set<String> interalrtg = internalTranscode.keySet();
			for (String rtg:interalrtg){
				RctTrscodeEntity appoTrnsc = internalTranscode.get(rtg);
				if (intResult>=17){
					calcLogger.info(new StandardLogMessage("External rating scaled rank "+7));
					finalResult = 7;
					break;
					//appoTrnsc.getMinrtg().intValue() <= intResult && intResult < appoTrnsc.getMaxrtg().intValue()
					//intResult < appoTrnsc.getMaxrtg().intValue() && intResult>=appoTrnsc.getMinrtg().intValue()
				}else if(appoTrnsc.getMinrtg().intValue() <= intResult && intResult < appoTrnsc.getMaxrtg().intValue()){
					calcLogger.info(new StandardLogMessage("External rating scaled rank "+appoTrnsc.getId().getRanking()));
					finalResult=appoTrnsc.getId().getRanking();
					break;
				}
			}
			
			Attribute ratingAttr = new Attribute();
			ratingAttr.setName("Rating");
			ratingAttr.setValue(finalResult+"");
			externalObj.getAttributeList().add(ratingAttr);
			
			if (ratings.get(bank.getBankId())!=null){
				ratings.get(bank.getBankId()).setExternrtg(new BigDecimal(finalResult));
			}else{
				RctRatingEntity ratingEntity = new RctRatingEntity();
				ratingEntity.setBankid(bank.getBankId());

				ratingEntity.setStatus("N");
				ratingEntity.setExternrtg(new BigDecimal(finalResult));
				
				ratings.put(ratingEntity.getBankid(), ratingEntity);
			}
			
			if(bankMap.get(bank.getBankId())!=null ){
				bankMap.get(bank.getBankId()).getObj().add(externalObj);
			}else{
				bankContainer.getObj().add(externalObj);
				bankMap.put(bank.getBankId(), bankContainer);
			}
		}
    	
    	return ratings;
    }

}
