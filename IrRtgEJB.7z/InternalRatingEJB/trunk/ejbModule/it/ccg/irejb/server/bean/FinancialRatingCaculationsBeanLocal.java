package it.ccg.irejb.server.bean;

import java.util.List;
import java.util.Map;

import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.bean.entity.RctRatingEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.auditing.elements.Container;

public interface FinancialRatingCaculationsBeanLocal {
	public Map<Integer,RctRatingEntity> dailyRun(List<RctBankEntity> rctBanks,Map<Integer,Container> bankMap) throws BackEndException;
}
