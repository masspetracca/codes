package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctRatingEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RctRatingEAO
 */
@Stateless
@Local(RctRatingEAOLocal.class)
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class RctRatingEAO implements RctRatingEAOLocal {

	@PersistenceContext(unitName="InternalRatingEJB", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	
    /**
     * Default constructor. 
     */
    public RctRatingEAO() {
        // TODO Auto-generated constructor stub
    }
    
    public void insertRctRating(RctRatingEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertRctRating(RctRatingEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctIfpRtgHEntity identification data: BankID = "+entity.getBankid()+" rating date = "+df.format(entity.getRatingdate())));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	this.manager.persist(entity);
	    	ejbLogger.debug(new StandardLogMessage("inserted bank id: "+entity.getBankid()+" upddate "+entity.getUpddate()));
	    } catch (Exception e) {
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
  
    public void deleteRctRating(RctRatingEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteRctRating(RctRatingEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctRatingEntity identification data: BankID = "+entity.getBankid()+" rating date = "+df.format(entity.getRatingdate())));
	    	RctRatingEntity appo = this.retrieveRatingById(entity.getBankid());
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(appo);
	    } catch (Exception e) {
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }

    public void updateRctRating(RctRatingEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in updateRctRating(RctRatingEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctRatingEntity identification data: BankID = "+entity.getBankid()+" rating date = "+df.format(entity.getRatingdate())));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
	    } catch (Exception e) {
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    
    public RctRatingEntity retrieveRatingById(int bankId) throws BackEndException {
    	ejbLogger.debug(new StandardLogMessage("in RctRatingEntity retrieveRatingById(String bankId) throws BackEndException"));
    	RctRatingEntity rating = null;
    	try {
	    	ejbLogger.debug(new StandardLogMessage("Bank identification ID: "+bankId));
	    	ejbLogger.debug(new StandardLogMessage("find"));
	    	
	    	rating = this.manager.find(RctRatingEntity.class, bankId);
	    	
    	} catch (Exception e) {
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    	return rating;
    }
    
    //getAllRatings
    public Map<Integer, RctRatingEntity> retrieveAllRatings() throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in Map<Integer, RctRatingEntity> retrieveAllRatings() throws BackEndException"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getAllRatings");

	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctRatingEntity> ratings = q.getResultList();
			Map <Integer,RctRatingEntity> result = new HashMap<Integer, RctRatingEntity>();
			for (RctRatingEntity ent: ratings){
				result.put(ent.getBankid(), ent);
			}
			ejbLogger.debug("results "+result.size());
	    	return result;
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    //getRatingByBankId
    @SuppressWarnings("unchecked")
	public List<RctRatingEntity> retrieveRatingsByBankId(int bankId) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctRatingEntity> retrieveRatingsByBankId(String bankId)"));
	    	ejbLogger.debug(new StandardLogMessage("Bank id: "+bankId));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getRatingByBankId");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("bankid", bankId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctRatingEntity> ratings = q.getResultList();
			
	    	return ratings;
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    } 
    
    //getRatingByRatingDate
	@SuppressWarnings("unchecked")
	public List<RctRatingEntity> retrieveRatingsByRatingDate(String ratingDate) throws BackEndException {
       	ejbLogger.debug(new StandardLogMessage("in List<RctRatingEntity> retrieveRatingsByRatingDate(String ratingDate)"));
       	List<RctRatingEntity> ratings = null;
       	try {
	       	ejbLogger.debug(new StandardLogMessage("Rating date : "+ratingDate));
	       	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	       	Query q = this.manager.createNamedQuery("getRatingByRatingDate");
	       	ejbLogger.debug(new StandardLogMessage("populate named query"));
	       	
			q.setParameter("ratingdate", df.parse(ratingDate));
			
	       	ejbLogger.debug(new StandardLogMessage("getResultList"));
	       	ratings = (List<RctRatingEntity>) q.getResultList();
       	} catch (Exception e) {
       		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
       	return ratings;
    } 
	
	//getRatingByStatus
	@SuppressWarnings("unchecked")
	public List<RctRatingEntity> retrieveRatingsByStatus(String status) throws BackEndException{
		try{
	       	ejbLogger.debug(new StandardLogMessage("in List<RctRatingEntity> retrieveRatingsByStatus(String status)"));
	       	ejbLogger.debug(new StandardLogMessage("Status : "+status));
	       	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	       	Query q = this.manager.createNamedQuery("getRatingByStatus");
	       	ejbLogger.debug(new StandardLogMessage("populate named query"));
	       	q.setParameter("status", status);
	       	
	       	ejbLogger.debug(new StandardLogMessage("getResultList"));
	   		List<RctRatingEntity> ratings = (List<RctRatingEntity>) q.getResultList();
	   		
	       	return ratings;
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
     } 

}
