package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the RCTVARH database table.
 * 
 */
@Entity
//@Table(name="PAMPTEST.RCTVARH")
@Table(name="RCTVARH")
@NamedQueries({
	@NamedQuery(name="getRtcVarHistoryByVarId", query="SELECT hist FROM RctVarHEntity hist WHERE hist.id.varid = :varid AND hist.hist.id.valuedate = (Select max(appo.id.valuedate) FROM RctVarHEntity appo WHERE appo.id.varid = :varid) ORDER BY hist.id.valuedate DESC"),
	@NamedQuery(name="getRtcVarHistoryByProvider", query="SELECT hist FROM RctVarHEntity hist WHERE hist.id.provider = :provider ORDER BY hist.id.valuedate DESC"),
	@NamedQuery(name="getRtcVarHistoryByValueDate", query="SELECT hist FROM RctVarHEntity hist WHERE hist.id.valuedate = :valuedate ORDER BY hist.id.valuedate DESC"),
	@NamedQuery(name="getRtcVarHistoryByVarIdFitchNNameForCalcWithLatestData", 
	query="SELECT hist " +
		    "FROM RctVarHEntity hist " +
		   "WHERE hist.id.varid = :varid " +
		     "AND hist.id.fitchnname = :fitchnname " +
		     "AND hist.id.provider = 'F' " +
		     "AND hist.periodleng = 12 " +
		     "AND hist.periodtype = 0 " +
		     "AND hist.id.valuedate = (SELECT max(appo.id.valuedate) " +
		     							"FROM RctVarHEntity appo " +
		     						   "WHERE appo.id.varid = :varid " +
		     						     "AND appo.id.fitchnname = :fitchnname " +
		     						     "AND appo.id.provider = 'F' " +
		     						     "AND appo.periodleng = 12 " +
		     						     "AND appo.periodtype = 0) " +
		     						   "ORDER BY hist.id.valuedate DESC"),
	//TODO
	@NamedQuery(name="getRtcVarHistoryByVarIdFitchNNameForCalc", query="SELECT hist FROM RctVarHEntity hist WHERE hist.id.varid = :varid and hist.id.fitchnname = :fitchnname and hist.id.provider = 'F' and hist.id.valuedate = (Select max(appo.id.valuedate) FROM RctVarHEntity appo WHERE appo.id.varid = :varid and appo.id.fitchnname = :fitchnname) ORDER BY hist.id.valuedate DESC")
})
public class RctVarHEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RctVarHEntityPK id;
	
	@Column(nullable=false)
	private int audqualflg;

	@Column(nullable=false)
	private int dataflag;

	@Column(nullable=false)
	private int periodleng;

	@Column(nullable=false)
	private int periodtype;

	private int pfileid;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

	@Column(precision=15, scale=8)
	private BigDecimal varvalue;
	
	/*@ManyToOne
	private VarsEntity rctvar;*/

    public RctVarHEntity() {
    }

	public RctVarHEntityPK getId() {
		return this.id;
	}

	public void setId(RctVarHEntityPK id) {
		this.id = id;
	}
	
	public int getAudqualflg() {
		return this.audqualflg;
	}

	public void setAudqualflg(int audqualflg) {
		this.audqualflg = audqualflg;
	}

	public int getDataflag() {
		return this.dataflag;
	}

	public void setDataflag(int dataflag) {
		this.dataflag = dataflag;
	}

	public int getPeriodleng() {
		return this.periodleng;
	}

	public void setPeriodleng(int periodleng) {
		this.periodleng = periodleng;
	}

	public int getPeriodtype() {
		return this.periodtype;
	}

	public void setPeriodtype(int periodtype) {
		this.periodtype = periodtype;
	}

	public int getPfileid() {
		return this.pfileid;
	}

	public void setPfileid(int pfileid) {
		this.pfileid = pfileid;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

	public BigDecimal getVarvalue() {
		return this.varvalue;
	}

	public void setVarvalue(BigDecimal varvalue) {
		this.varvalue = varvalue;
	}
}
