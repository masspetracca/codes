package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.bean.eao.RctAudHistEAOLocal;
import it.ccg.irejb.server.bean.entity.RctAudHistEntity;
import it.ccg.irejb.server.bean.entity.RctAudHistEntityPK;
import it.ccg.irejb.server.business.RatingsCalculations;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;
import it.ccg.auditing.elements.Attribute;
import it.ccg.auditing.Auditor;
import it.ccg.auditing.elements.Container;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

import com.ibm.ejs.jms.mq.pcf.InvalidArgumentException;

/**
 * Session Bean implementation class TimerBean
 */
@Stateless
/*@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)*/
public class TimerBean implements TimerBeanLocal {

	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@EJB
	private RctAudHistEAOLocal rctAudHitsEAO;
	
	@Resource
	private TimerService timerService;
	
	
    /**
     * Default constructor. 
     */
    public TimerBean() {
        // TODO Auto-generated constructor stub
    }
    
    public CalculationBean createTimer(CalculationBean bean) throws BackEndException{
    	logger.debug(new StandardLogMessage("in TimerBean.createTimer(CalculationBean bean) throws BackEndException"));
    	CalculationBean timer;
    	if(this.getTimer(bean.getType()) != null) {
    		logger.info(new StandardLogMessage("CalculationBean already present"));
			
			return null;
		}
    	
    	if ((bean.getType()!=null || !bean.getType().equalsIgnoreCase("")) && bean.getStartDateTime()!=null && (bean.getInterval()!=0 || !(bean.getInterval()<0))){
    		logger.debug(new StandardLogMessage("creating timer"));
    		timer = (CalculationBean) timerService.createTimer(bean.getStartDateTime(), bean.getInterval(), bean).getInfo();
    		logger.info(new StandardLogMessage("timer created"));
    	}else{
    		ExceptionUtil.logCompleteStackTrace(logger, new InvalidArgumentException("Invalid calculationBean "+bean.toString()));
    		throw new BackEndException("Invalid calculationBean");
    	}
    	
    	return timer;
    }
    
    public CalculationBean createOneShotTimer(CalculationBean bean) throws BackEndException{
    	logger.debug(new StandardLogMessage("in TimerBean.createOneShotTimer(CalculationBean bean) throws BackEndException"));
    	CalculationBean timer;
    	
    	if ((bean.getType()!=null || !bean.getType().equalsIgnoreCase("")) && bean.getStartDateTime()!=null){
    		logger.debug(new StandardLogMessage("creating one shot timer"));
    		timer = (CalculationBean) timerService.createTimer(bean.getStartDateTime(),bean).getInfo();
    		logger.info(new StandardLogMessage("timer one shot created"));
    	}else{
    		ExceptionUtil.logCompleteStackTrace(logger, new InvalidArgumentException("Invalid calculationBean "+bean.toString()));
    		throw new BackEndException("Invalid calculationBean");
    	}
    	
    	return timer;
    }

    public CalculationBean getTimer(String timerType) {
		logger.debug(new StandardLogMessage("in TimerBean.getTimer(String timerType)"));
    	CalculationBean bean = null;
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = this.timerService.getTimers();
    	
    	for(Timer timer : collection) {
    		if(((String)((CalculationBean)timer.getInfo()).getType()).equals(timerType)) {	
    			bean = (CalculationBean)timer.getInfo();
    		}
    	}
    	//logger.debug("timer found "+bean.getType());
		return bean;
	}
 
	public List<CalculationBean> getAllTimers() {
		logger.debug(new StandardLogMessage("in TimerBean.getAllTimers()"));
		List<CalculationBean> list = new ArrayList<CalculationBean>();
		
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = this.timerService.getTimers();

    	for(Timer timer : collection) {
    		CalculationBean timerDTO = (CalculationBean)timer.getInfo();
    		list.add(timerDTO);
    	}
    	logger.debug(new StandardLogMessage("number fo timers "+list.size()));
  
		return list;
	}
	
	public void deleteTimer(String timerType) throws BackEndException {
		logger.debug(new StandardLogMessage("in TimerBean.deleteTimer(String timerName) throws BackEndException"));
		@SuppressWarnings("unchecked")
		Collection<Timer> collection = this.timerService.getTimers();
    	for(Timer timer : collection) {
    		if(((String)((CalculationBean)timer.getInfo()).getType()).equals(timerType)) {
    			
    			timer.cancel();
    			
    			logger.info(new StandardLogMessage("Timer \'" + timerType + "\' deleted."));
    		}
    	}
	}
	
	public void deleteAllTimers() throws BackEndException {
		logger.debug(new StandardLogMessage("in deleteAllTimers() throws BackEndException"));
		while(this.timerService.getTimers().iterator().hasNext()) {
			Timer timer = (Timer)this.timerService.getTimers().iterator().next();
			String timerName = ((CalculationBean)timer.getInfo()).getType();
			timer.cancel();
    		logger.info(new StandardLogMessage("Timer \'" + timerName + "\' deleted."));
    	}
		
	}
	
	@Timeout
	public void timeout(Timer timer) {
		logger.debug(new StandardLogMessage("in TimerBean.timeout(Timer timer)"));
		try {
			CalculationBean bean = (CalculationBean)timer.getInfo();
			Container scheduleContainer = new Container();
			scheduleContainer.setType("Schedule");
			Attribute timeAttribute = new Attribute();
			timeAttribute.setName("Time");
			timeAttribute.setValue(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date()));
			scheduleContainer.getAttribute().add(timeAttribute);
			
			Attribute typeAttribute = new Attribute();
			typeAttribute.setName("Type");
			typeAttribute.setValue(bean.getType());
			scheduleContainer.getAttribute().add(typeAttribute);
			
			Attribute startDtAttribute = new Attribute();
			startDtAttribute.setName("StartDateTime");
			startDtAttribute.setValue(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(bean.getStartDateTime()));
			scheduleContainer.getAttribute().add(startDtAttribute);
			
			Attribute intervalAttribute = new Attribute();
			intervalAttribute.setName("Interval(milliseconds)");
			intervalAttribute.setValue(bean.getInterval()+"");
			scheduleContainer.getAttribute().add(intervalAttribute);
			
			Attribute userAttribute = new Attribute();
			userAttribute.setName("User");
			userAttribute.setValue(bean.getUser());
			scheduleContainer.getAttribute().add(userAttribute);
			
			Auditor aud = new Auditor();
			ByteArrayOutputStream oS =  (ByteArrayOutputStream) aud.marshal(scheduleContainer);
			byte[] xml = new byte[oS.toString().getBytes().length];
			xml = oS.toByteArray();
			//oS.write(xml);
			
			RctAudHistEntity audEntity = new RctAudHistEntity();
			RctAudHistEntityPK audEntityPk = new RctAudHistEntityPK();
			audEntityPk.setAudHisDat(new Date());
			audEntityPk.setApplCode("INTERNAL RATING");
			audEntity.setId(audEntityPk);

			audEntity.setAudHBlob(xml);
			
			rctAudHitsEAO.insertAuditFlow(audEntity);
			
			logger.info(new StandardLogMessage("Timer \'" + bean.getType()+ "\' expired."));

			String methodName = bean.getType();
			RatingsCalculations calculator = new RatingsCalculations(bean.getUser());
			
			RatingsCalculations.class.getMethod(methodName, null).invoke(calculator);
			
		} catch (IllegalArgumentException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (SecurityException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (IllegalAccessException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (InvocationTargetException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (NoSuchMethodException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} 
	}
}
