package it.ccg.irejb.server.logengine;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

public class UserLogUtil {
	
	
	public static String getUserLogFormatLine(HttpServletRequest request) throws ServletException, IOException {
		
		String logMessage = "User request. Url: " + request.getRequestURL() + " [";
		
		Enumeration<?> paramNames = request.getParameterNames();
		while(paramNames.hasMoreElements()) {
			
			String param = (String)paramNames.nextElement();
			
			if(!occurCheck(param)) {
				
				logMessage += param + ": " + request.getParameter(param) + ", ";
			}
			
		}
		logMessage = logMessage.substring(0, logMessage.length() - 2);
		logMessage += "]";
		
		
		return logMessage;
	}
	
	
	private static boolean occurCheck(String parameter) {
		
		boolean result = false;
		
		String[] negFilter = {"isc", "_constructor", "operator", "_dataSource", "_textMatchStyle", "criteria", "_componentId", "_endRow", "_startRow"};
		
		for(String prefix : negFilter) {
			
			if(parameter.startsWith(prefix)) {
				
				result = true;
				
				break;
			}
		}
		
		
		return result;
	}
	
}
