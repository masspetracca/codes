package it.ccg.irejb.server.bean.eao;

import java.util.List;

import it.ccg.irejb.server.bean.entity.RctHisRtgEntity;
import it.ccg.irejb.server.bean.entity.RctIssuesEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RctHisRtgEAO
 */
@Stateless
@Local(RctHisRtgEAOLocal.class)
public class RctHisRtgEAO implements RctHisRtgEAOLocal {

	@PersistenceContext(unitName="InternalRatingEJB", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
   
	/**
     * Default constructor. 
     */
    public RctHisRtgEAO() {
        // TODO Auto-generated constructor stub
    }
    
	@Override
	public void insertHistRtg(RctHisRtgEntity entity) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in insertHistRtg(RctHisRtgEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctHisRtgEntity identification data: Bloomberg code = "+entity.getId().getBloombCode()+", rating date= "+entity.getId().getRtgDate()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
		
	}
	
	@Override
	public void deleteHistRtg(RctHisRtgEntity entity) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteHistRtg(RctHisRtgEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctIssuesEntity identification data: Bloomberg code = "+entity.getId().getBloombCode()+", rating date= "+entity.getId().getRtgDate()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
		
	}
	
	@Override
	public void updateHistRtg(RctHisRtgEntity entity) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateIssue(RctIssuesEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctIssuesEntity identification data: Bloomberg code = "+entity.getId().getBloombCode()+", rating date= "+entity.getId().getRtgDate()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
	}
	
	@Override
	//getratingByBloombCode
	public List<RctHisRtgEntity> retrieveRatingByBlombCode(String blombCode) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctHisRtgEntity> retrieveRatingByBlombCode(String blombCode)"));
	    	ejbLogger.debug(new StandardLogMessage("BloombergCode "+blombCode));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getratingByBloombCode");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("bloombCode", blombCode);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctHisRtgEntity> ratings = (List<RctHisRtgEntity>) q.getResultList();
			
	    	return ratings;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}
	
	@Override
	//getLatestRatingsByTicker
	public List<RctHisRtgEntity> retrieveLatestRatingByBlombCode(String blombCode) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctHisRtgEntity> retrieveLatestRatingByBlombCode(String blombCode)"));
	    	ejbLogger.debug(new StandardLogMessage("Retures ticker: "+blombCode));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getLatestRatingsByTicker");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("bloombCode", blombCode);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctHisRtgEntity> ratings = (List<RctHisRtgEntity>) q.getResultList();
			
	    	return ratings;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}
    

}
