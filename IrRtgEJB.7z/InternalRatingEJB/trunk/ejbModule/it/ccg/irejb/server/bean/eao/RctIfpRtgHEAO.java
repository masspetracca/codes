package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctIfpRtgHEntity;
import it.ccg.irejb.server.bean.entity.RctIfpRtgHEntityPK;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RctIfpRtgHEAO
 */
@Stateless
@Local(RctIfpRtgHEAOLocal.class)
public class RctIfpRtgHEAO implements RctIfpRtgHEAOLocal {

	@PersistenceContext(unitName="InternalRatingEJB", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private DateFormat df = new SimpleDateFormat("yyyy/mm/dd");
	
    /**
     * Default constructor. 
     */
    public RctIfpRtgHEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertRatingHistory(RctIfpRtgHEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in insertRatingHistory(RctRatingHEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctIfpRtgHEntity identification data: BankID = "+entity.getId().getBankid()+" provider = "+entity.getId().getProvider()+" rating type ="+entity.getId().getRtgtype()+" last update date = "+entity.getId().getLstupddate()));
    	ejbLogger.debug(new StandardLogMessage("insert"));
    	this.manager.persist(entity);
    }
    
    public void deleteRatingHistory(RctIfpRtgHEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in deleteBank(RctBankEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctIfpRtgHEntity identification data: BankID = "+entity.getId().getBankid()+" provider = "+entity.getId().getProvider()+" rating type ="+entity.getId().getRtgtype()+" last update date = "+entity.getId().getLstupddate()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	this.manager.remove(entity);
    }

    public void updateRatingHistory(RctIfpRtgHEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in updateBank(RctBankEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctIfpRtgHEntity identification data: BankID = "+entity.getId().getBankid()+" provider = "+entity.getId().getProvider()+" rating type ="+entity.getId().getRtgtype()+" last update date = "+entity.getId().getLstupddate()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	this.manager.merge(entity);
    }
    
    public RctIfpRtgHEntity retrieveRatingHistoryById(String bankId,String provider,String rtgType,String lstUpdDate) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in RctIfpRtgHEntity retrieveRatingHistoryById(String bankId,String provider,String rtgType,String lstUpdDate)"));
    	RctIfpRtgHEntity rating = null;
    	try {
    		    	
			Date updateDate = this.df.parse(lstUpdDate);
			RctIfpRtgHEntityPK pk = new RctIfpRtgHEntityPK();
			pk.setBankid(Integer.parseInt(bankId));
			pk.setProvider(provider);
			pk.setRtgtype(rtgType);
			pk.setLstupddate(updateDate);
			
	    	ejbLogger.debug(new StandardLogMessage("Bank identification ID: "+bankId));
	    	ejbLogger.debug(new StandardLogMessage("Provider: "+provider));
	    	ejbLogger.debug(new StandardLogMessage("Rating type: "+rtgType));
	    	ejbLogger.debug(new StandardLogMessage("Last update: "+lstUpdDate));
	    	ejbLogger.debug(new StandardLogMessage("find"));
	    	
	    	rating = (RctIfpRtgHEntity)this.manager.find(RctIfpRtgHEntity.class, pk);
	    	
    	} catch (ParseException e) {
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    	return rating;
    }
   
    //getRatingByBankId
    @SuppressWarnings("unchecked")
	public List<RctIfpRtgHEntity> retrieveRatingsByBankId(String bankId){
    	ejbLogger.debug(new StandardLogMessage("in List<RctIfpRtgHEntity> retrieveRatingsByBankId(String bankId)"));
    	ejbLogger.debug(new StandardLogMessage("Bank id: "+bankId));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getRatingByBankId");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("bankid", bankId);
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
		List<RctIfpRtgHEntity> ratings = (List<RctIfpRtgHEntity>) q.getResultList();
		
    	return ratings;
    } 
    
    //getRatingByProvider
    @SuppressWarnings("unchecked")
   	public List<RctIfpRtgHEntity> retrieveRatingsByProvider(String provider){
       	ejbLogger.debug(new StandardLogMessage("in List<RctIfpRtgHEntity> retrieveRatingsByProvider(String provider)"));
       	ejbLogger.debug(new StandardLogMessage("Provider : "+provider));
       	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
       	Query q = this.manager.createNamedQuery("getRatingByProvider");
       	ejbLogger.debug(new StandardLogMessage("populate named query"));
       	q.setParameter("provider", provider);
       	
       	ejbLogger.debug(new StandardLogMessage("getResultList"));
   		List<RctIfpRtgHEntity> ratings = (List<RctIfpRtgHEntity>) q.getResultList();
   		
       	return ratings;
    } 
    
    //getRatingByRtgType
    @SuppressWarnings("unchecked")
   	public List<RctIfpRtgHEntity> retrieveRatingsByRtgType(String rtgType){
       	ejbLogger.debug(new StandardLogMessage("in List<RctIfpRtgHEntity> retrieveRatingsByRtgType(String rtgType)"));
       	ejbLogger.debug(new StandardLogMessage("Rating type : "+rtgType));
       	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
       	Query q = this.manager.createNamedQuery("getRatingByRtgType");
       	ejbLogger.debug(new StandardLogMessage("populate named query"));
       	q.setParameter("rtgtype", rtgType);
       	
       	ejbLogger.debug(new StandardLogMessage("getResultList"));
   		List<RctIfpRtgHEntity> ratings = (List<RctIfpRtgHEntity>) q.getResultList();
   		
       	return ratings;
     } 
}
