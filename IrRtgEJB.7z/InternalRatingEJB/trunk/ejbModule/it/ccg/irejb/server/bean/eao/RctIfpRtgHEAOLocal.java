package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctIfpRtgHEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

public interface RctIfpRtgHEAOLocal {
	
	public void insertRatingHistory(RctIfpRtgHEntity entity);   
    public void deleteRatingHistory(RctIfpRtgHEntity entity);
    public void updateRatingHistory(RctIfpRtgHEntity entity);
    public RctIfpRtgHEntity retrieveRatingHistoryById(String bankId,String provider,String rtgType,String lstUpdDate) throws BackEndException;
	public List<RctIfpRtgHEntity> retrieveRatingsByBankId(String bankId);
   	public List<RctIfpRtgHEntity> retrieveRatingsByProvider(String provider);
   	public List<RctIfpRtgHEntity> retrieveRatingsByRtgType(String rtgType);

}
