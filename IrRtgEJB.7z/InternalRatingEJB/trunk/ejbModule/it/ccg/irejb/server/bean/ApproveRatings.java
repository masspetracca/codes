package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.bean.eao.RctRatingEAOLocal;
import it.ccg.irejb.server.bean.eao.RctRatingHEAOLocal;
import it.ccg.irejb.server.bean.eao.RctRiskComEAOLocal;
import it.ccg.irejb.server.bean.entity.RctRatingEntity;
import it.ccg.irejb.server.bean.entity.RctRatingHEntity;
import it.ccg.irejb.server.bean.entity.RctRatingHEntityPK;
import it.ccg.irejb.server.bean.entity.RctRiskComEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ApproveRatings
 */
@Stateless
@Local(ApproveRatingsLocal.class)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class ApproveRatings implements ApproveRatingsLocal {

	private static final Logger logger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	
	@EJB
	private RctRatingHEAOLocal rctRatingH;
	
	@EJB
	private RctRatingEAOLocal rctRating;
	
	@EJB
	private RctRiskComEAOLocal rctRiskCom;
	
    /**
     * Default constructor. 
     */
    public ApproveRatings() {
        // TODO Auto-generated constructor stub
    }

    public void approve(String rcCode, String user) throws BackEndException{
    	try {
			//TODO aggiunto requires new
			List<RctRatingEntity> ratings= rctRating.retrieveRatingsByStatus("S");
			
			RctRiskComEntity comm = rctRiskCom.retrieveRiskCommitteeById(rcCode);
			//List<RctRatingHEntity> ratingsHist = new ArrayList<RctRatingHEntity>();
			
			int idx = 0;
			for (RctRatingEntity rat : ratings){
				idx++;
				RctRatingHEntity hist = new RctRatingHEntity();
				RctRatingHEntityPK pkHist = new RctRatingHEntityPK();
				logger.debug(new StandardLogMessage("coping pk from rat to hist"));
				//BeanUtils.copyProperties(pkHist, rat.getId());
				pkHist.setBankid(rat.getBankid());
				pkHist.setRatingdate(rat.getRatingdate());
				pkHist.setApprdate(new Timestamp(new Date().getTime()));
				hist.setId(pkHist);
				logger.debug(new StandardLogMessage("coping rat to hist"));
				//BeanUtils.copyProperties(hist, rat);
				//PropertyUtils.copyProperties(hist, rat);
				hist.copyRatingData(rat);
				logger.debug(new StandardLogMessage("setting approved data"));
				hist.setApprovedby(user);
				hist.setApprrtg(rat.getProprtg());
				hist.setRctriskcom(comm);
				logger.debug(new StandardLogMessage("setting upd data"));
				hist.setUpdusr(user);
				hist.setUpddate(new Timestamp(new Date().getTime()));
				hist.setUpdtype("C");
				logger.debug(new StandardLogMessage("inserting history"));
				logger.info(new StandardLogMessage("Inserting history"));
				rctRatingH.insertRatingHistory(hist);
				logger.debug(new StandardLogMessage("deleting rating"));
				logger.info(new StandardLogMessage("deleting rating"));
				rctRating.deleteRctRating(rat);
			}
			
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			throw e;
		//	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}
    }
}
