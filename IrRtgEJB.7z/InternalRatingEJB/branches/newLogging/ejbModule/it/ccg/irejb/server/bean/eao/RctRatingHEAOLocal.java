package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctRatingHEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

public interface RctRatingHEAOLocal {
	
	public void insertRatingHistory(RctRatingHEntity entity);  
    public void deleteRatingHistory(RctRatingHEntity entity);
    public void updateRatingHistory(RctRatingHEntity entity);
    public RctRatingHEntity retrieveRatingHistoryById(String bankId, String ratingDate) throws BackEndException;
	public List<RctRatingHEntity> retrieveRatingHistoryByBankId(String bankId);
	public RctRatingHEntity retrieveLastRatingHistoryByBankId(int bankId);
	public List<RctRatingHEntity> retrieveRatingHistoryByRatingDate(String ratingDate) throws BackEndException;
	public List<RctRatingHEntity> retrieveRatingHistoryByStatus(String status);
}
