package it.ccg.irejb.server.business;

import it.ccg.irejb.server.bean.ExternalRatingCalculationBeanLocal;
import it.ccg.irejb.server.bean.FinancialRatingCaculationsBeanLocal;
import it.ccg.irejb.server.bean.MarketRatingCalculationsBeanLocal;
import it.ccg.irejb.server.bean.eao.RctAudHistEAOLocal;
import it.ccg.irejb.server.bean.eao.RctBankEAOLocal;
import it.ccg.irejb.server.bean.eao.RctRatingEAOLocal;
import it.ccg.irejb.server.bean.eao.RctRatingHEAOLocal;
import it.ccg.irejb.server.bean.entity.RctAudHistEntity;
import it.ccg.irejb.server.bean.entity.RctAudHistEntityPK;
import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.bean.entity.RctRatingEntity;
import it.ccg.irejb.server.bean.entity.RctRatingHEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.system.SystemProperties;
import it.ccg.irejb.server.util.ExceptionUtil;
import it.ccg.auditing.elements.Attribute;
import it.ccg.auditing.Auditor;
import it.ccg.auditing.elements.Container;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

public class RatingsCalculations {
	private FinancialRatingCaculationsBeanLocal financialRatingCaculationsBean;
	private MarketRatingCalculationsBeanLocal marketRatingCalculationsBean;
	private ExternalRatingCalculationBeanLocal externalRatingCalculationBean;
	private RctRatingHEAOLocal rctRatingHistEAO;
	private RctAudHistEAOLocal rctAudHitsEAO;
	private RctBankEAOLocal rctBankEao;
	private List<RctBankEntity> enabledBanks;
	private Map<Integer,RctRatingEntity> ratings;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private Logger sysLogger = LoggerFactory.getLogger(LoggerFactory.SYS_LOG);
	
	private RctRatingEAOLocal rcTRatingEAO;
	//private RctRatingHEAOLocal rcTRatingHEAO;
	private String user;
	
	public RatingsCalculations(String user) throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in RatingsCalculations"));
		Context context;
		this.user = user;
		try {
			context = new InitialContext();
			this.financialRatingCaculationsBean = (FinancialRatingCaculationsBeanLocal) context.lookup("ejblocal:it.ccg.irejb.server.bean.FinancialRatingCaculationsBeanLocal");
			this.marketRatingCalculationsBean = (MarketRatingCalculationsBeanLocal) context.lookup("ejblocal:it.ccg.irejb.server.bean.MarketRatingCalculationsBeanLocal");
			this.externalRatingCalculationBean = (ExternalRatingCalculationBeanLocal) context.lookup("ejblocal:it.ccg.irejb.server.bean.ExternalRatingCalculationBeanLocal");
			this.rctAudHitsEAO = (RctAudHistEAOLocal) context.lookup("ejblocal:it.ccg.irejb.server.bean.eao.RctAudHistEAOLocal");
			this.rctRatingHistEAO = (RctRatingHEAOLocal) context.lookup("ejblocal:it.ccg.irejb.server.bean.eao.RctRatingHEAOLocal");
			this.rctBankEao = (RctBankEAOLocal) context.lookup("ejblocal:it.ccg.irejb.server.bean.eao.RctBankEAOLocal");
			this.rcTRatingEAO = (RctRatingEAOLocal) context.lookup("ejblocal:it.ccg.irejb.server.bean.eao.RctRatingEAOLocal");

		} catch (NamingException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}

/*	@TransactionAttribute(TransactionAttributeType.REQUIRED)*/
	public void dailyRun() throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in RatingsCalculations.dailyRun"));
		Container ratingsContaioner = new Container();
		ratingsContaioner.setType("Rating");
		
		it.ccg.auditing.elements.List banks = new it.ccg.auditing.elements.List();
		banks.setType("Banks");
		ratingsContaioner.setList(banks);
		Map<Integer,Container> bankMap = new HashMap<Integer, Container>();		
		
		try {
			ejbLogger.info(new StandardLogMessage("retrieve every enabled banks"));
			enabledBanks = rctBankEao.retrieveBankByStatus("E");
			ejbLogger.info(new StandardLogMessage("Active banks num: "+enabledBanks.size()));
			
			ejbLogger.info(new StandardLogMessage("financial model calc"));
			this.ratings = financialRatingCaculationsBean.dailyRun(enabledBanks,bankMap);
			
			ejbLogger.info(new StandardLogMessage("ratings collection check"));
			if (this.ratings!=null && this.ratings.size()>0){
				ejbLogger.info(new StandardLogMessage("market model calc"));
				this.ratings = marketRatingCalculationsBean.dailyRun(enabledBanks, this.ratings,bankMap);
			}
			
			ejbLogger.info(new StandardLogMessage("ratings collection check"));
			if (this.ratings!=null && this.ratings.size()>0){
				ejbLogger.info(new StandardLogMessage("external model calc"));
				this.ratings = externalRatingCalculationBean.dailyRun(enabledBanks, this.ratings,bankMap);
			}
			
			Map <Integer,RctRatingEntity> presentRating = rcTRatingEAO.retrieveAllRatings();
			Timestamp calcultionDate = new Timestamp(new Date().getTime());
			Set<Integer> keys = ratings.keySet();
			for (Integer i : keys){
				RctRatingEntity rating = ratings.get(i);
				/* ottimizzo
				 * List<RctRatingEntity> ratingsAppo =  rcTRatingEAO.retrieveRatingsByBankId(rating.getBankid());
				 */
				try{
					if (presentRating.get(rating.getBankid())  != null){
						ejbLogger.info(new StandardLogMessage("Rating already present for "+rating.getBankid()+", then update"));
						rating.setUpdtype("U");
						RctRatingEntity appo =  presentRating.get(rating.getBankid());
						appo.setUpdtype(rating.getUpdtype());
						appo.setUpdusr(this.user);
						appo.setUpddate(calcultionDate);
						appo.setRatingdate(calcultionDate);
						int ratingDividend=0;
						double ratingSum=0;
						if (rating.getBalancertg() != null && !rating.getBalancertg().equals(0)){
							appo.setBalancertg(rating.getBalancertg());
							ratingDividend++;
							ratingSum+=rating.getBalancertg().doubleValue();
						}
							
						
						if (rating.getExternrtg() != null && !rating.getExternrtg().equals(0)){
							appo.setExternrtg(rating.getExternrtg());
							ratingDividend++;
							ratingSum+=rating.getExternrtg().doubleValue();
						}
						
						if(rating.getSpreadrtg() != null && !rating.getSpreadrtg().equals(0)){
							appo.setSpreadrtg(rating.getSpreadrtg());
							ratingDividend++;
							ratingSum+=rating.getSpreadrtg().doubleValue();
						}
						
						appo.setProprtg(new BigDecimal((ratingSum/ratingDividend)));
						RctRatingHEntity history = (RctRatingHEntity) rctRatingHistEAO.retrieveLastRatingHistoryByBankId(appo.getBankid());
						appo.setWoringkRtg(history!=null?history.getApprrtg():null);
						
						Attribute ratingProp = new Attribute();
						ratingProp.setName("Rating proposal");
						ratingProp.setValue(appo.getProprtg().toString());
						bankMap.get(rating.getBankid()).getAttribute().add(ratingProp);
						
						ejbLogger.info(new StandardLogMessage("proposal rating for bank "+appo.getRctbank().getBankName())+" : "+appo.getProprtg());
						ejbLogger.debug(new StandardLogMessage("rating updated"));
	
					}else{
						int ratingDividend=0;
						double ratingSum=0;
						if (rating.getBalancertg() != null && !rating.getBalancertg().equals(0)){
							ratingDividend++;
							ratingSum+=rating.getBalancertg().doubleValue();
						}
						
						if (rating.getExternrtg() != null && !rating.getExternrtg().equals(0)){
							ratingDividend++;
							ratingSum+=rating.getExternrtg().doubleValue();
						}
						
						if(rating.getSpreadrtg() != null && !rating.getSpreadrtg().equals(0)){
							ratingDividend++;
							ratingSum+=rating.getSpreadrtg().doubleValue();
						}
						rating.setProprtg(new BigDecimal((ratingSum/ratingDividend)));
						ejbLogger.info(new StandardLogMessage("proposal rating for bank "+rating.getRctbank().getBankName())+" : "+rating.getProprtg());
						
						rating.setUpddate(calcultionDate);
						rating.setRatingdate(calcultionDate);
						rating.setUpdusr(this.user);
						RctRatingHEntity history = (RctRatingHEntity) rctRatingHistEAO.retrieveLastRatingHistoryByBankId(rating.getBankid());
						rating.setWoringkRtg(history!=null?history.getApprrtg():null);

						ejbLogger.info(new StandardLogMessage("Rating not present for "+rating.getBankid()+", then create"));
						rating.setUpdtype("C");
						
						Attribute ratingProp = new Attribute();
						ratingProp.setName("Rating proposal");
						ratingProp.setValue(rating.getProprtg().toString());
						bankMap.get(rating.getBankid()).getAttribute().add(ratingProp);
						
						rcTRatingEAO.insertRctRating(rating);
					}
				}catch(Exception e){
					ejbLogger.error(e.getMessage());
				}
				
				for (Integer itg : bankMap.keySet()){
					ratingsContaioner.getList().getContainer().add(bankMap.get(itg));
				}
				
				Auditor aud = new Auditor();
				ByteArrayOutputStream oS =  (ByteArrayOutputStream) aud.marshal(ratingsContaioner);
				byte[] xml = new byte[oS.toString().getBytes().length];
				xml = oS.toByteArray();
				
				RctAudHistEntity audEntity = new RctAudHistEntity();
				RctAudHistEntityPK audEntityPk = new RctAudHistEntityPK();
				audEntityPk.setAudHisDat(new Date());
				audEntityPk.setApplCode(LoggerFactory.applicationCode);
				audEntity.setId(audEntityPk);
				audEntity.setAudHBlob(xml);
				
				rctAudHitsEAO.insertAuditFlow(audEntity);
			}
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
			sysLogger.error(LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2"+"DailyRun batch failed.");
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
			sysLogger.error(LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2"+"DailyRun batch failed.");
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
			sysLogger.error(LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2"+"DailyRun batch failed.");
		}
	}
	
/*	@TransactionAttribute(TransactionAttributeType.REQUIRED)*/
	public void dailyRunOneShot() throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in RatingsCalculations.dailyRun"));
		Container ratingsContaioner = new Container();
		ratingsContaioner.setType("Rating");
		Attribute timeAttribute = new Attribute();
		timeAttribute.setName("Time");
		timeAttribute.setValue(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date()));
		ratingsContaioner.getAttribute().add(timeAttribute);
		//bankContainer.getAttribute().add(timeAttribute);
		
		it.ccg.auditing.elements.List banks = new it.ccg.auditing.elements.List();
		banks.setType("Banks");
		ratingsContaioner.setList(banks);
		Map<Integer,Container> bankMap = new HashMap<Integer, Container>();		
		
		try {
			ejbLogger.info(new StandardLogMessage("retrieve every enabled banks"));
			enabledBanks = rctBankEao.retrieveBankByStatus("E");
			ejbLogger.info(new StandardLogMessage("Active banks num: "+enabledBanks.size()));
			
			ejbLogger.info(new StandardLogMessage("financial model calc"));
			this.ratings = financialRatingCaculationsBean.dailyRun(enabledBanks,bankMap);
			
			ejbLogger.info(new StandardLogMessage("ratings collection check"));
			if (this.ratings!=null && this.ratings.size()>0){
				ejbLogger.info(new StandardLogMessage("market model calc"));
				this.ratings = marketRatingCalculationsBean.dailyRun(enabledBanks, this.ratings,bankMap);
			}
			
			ejbLogger.info(new StandardLogMessage("ratings collection check"));
			if (this.ratings!=null && this.ratings.size()>0){
				ejbLogger.info(new StandardLogMessage("external model calc"));
				this.ratings = externalRatingCalculationBean.dailyRun(enabledBanks, this.ratings,bankMap);
			}
			
			Map <Integer,RctRatingEntity> presentRating = rcTRatingEAO.retrieveAllRatings();
			Timestamp calcultionDate = new Timestamp(new Date().getTime());
			Set<Integer> keys = ratings.keySet();
			for (Integer i : keys){
				RctRatingEntity rating = ratings.get(i);
				/* ottimizzo
				 * List<RctRatingEntity> ratingsAppo =  rcTRatingEAO.retrieveRatingsByBankId(rating.getBankid());
				 */
				try{
					if (presentRating.get(rating.getBankid())  != null){
						ejbLogger.info(new StandardLogMessage("Rating already present for "+rating.getBankid()+", then update"));
						rating.setUpdtype("U");
						RctRatingEntity appo =  presentRating.get(rating.getBankid());
						appo.setUpdtype(rating.getUpdtype());
						appo.setUpdusr(this.user);
						appo.setUpddate(calcultionDate);
						appo.setRatingdate(calcultionDate);
						int ratingDividend=0;
						double ratingSum=0;
						if (rating.getBalancertg() != null && !rating.getBalancertg().equals(0)){
							appo.setBalancertg(rating.getBalancertg());
							ratingDividend++;
							ratingSum+=rating.getBalancertg().doubleValue();
						}
							
						
						if (rating.getExternrtg() != null && !rating.getExternrtg().equals(0)){
							appo.setExternrtg(rating.getExternrtg());
							ratingDividend++;
							ratingSum+=rating.getExternrtg().doubleValue();
						}
						
						if(rating.getSpreadrtg() != null && !rating.getSpreadrtg().equals(0)){
							appo.setSpreadrtg(rating.getSpreadrtg());
							ratingDividend++;
							ratingSum+=rating.getSpreadrtg().doubleValue();
						}
						
						appo.setProprtg(new BigDecimal(Math.round(ratingSum/ratingDividend)));
						RctRatingHEntity history = (RctRatingHEntity) rctRatingHistEAO.retrieveLastRatingHistoryByBankId(appo.getBankid());
						appo.setWoringkRtg(history!=null?history.getApprrtg():null);
						Attribute ratingProp = new Attribute();
						ratingProp.setName("Rating proposal");
						ratingProp.setValue(appo.getProprtg().toString());
						bankMap.get(rating.getBankid()).getAttribute().add(ratingProp);
						
						ejbLogger.info(new StandardLogMessage("proposal rating for bank "+appo.getRctbank().getBankName())+" : "+appo.getProprtg());
						ejbLogger.debug(new StandardLogMessage("rating updated"));
	
					}else{
						int ratingDividend=0;
						double ratingSum=0;
						if (rating.getBalancertg() != null && !rating.getBalancertg().equals(0)){
							ratingDividend++;
							ratingSum+=rating.getBalancertg().doubleValue();
						}
						
						if (rating.getExternrtg() != null && !rating.getExternrtg().equals(0)){
							ratingDividend++;
							ratingSum+=rating.getExternrtg().doubleValue();
						}
						
						if(rating.getSpreadrtg() != null && !rating.getSpreadrtg().equals(0)){
							ratingDividend++;
							ratingSum+=rating.getSpreadrtg().doubleValue();
						}
						rating.setProprtg(new BigDecimal((ratingSum/ratingDividend)));
						ejbLogger.info(new StandardLogMessage("proposal rating for bank "+rating.getRctbank().getBankName())+" : "+rating.getProprtg());
						rating.setUpddate(calcultionDate);
						rating.setRatingdate(calcultionDate);
						rating.setUpdusr(this.user);
						RctRatingHEntity history = (RctRatingHEntity) rctRatingHistEAO.retrieveLastRatingHistoryByBankId(rating.getBankid());
						rating.setWoringkRtg(history!=null?history.getApprrtg():null);
						
						Attribute ratingProp = new Attribute();
						ratingProp.setName("Rating proposal");
						ratingProp.setValue(rating.getProprtg().toString());
						bankMap.get(rating.getBankid()).getAttribute().add(ratingProp);
						
						ejbLogger.info(new StandardLogMessage("Rating not present for "+rating.getBankid()+", then create"));
						rating.setUpdtype("C");
						rcTRatingEAO.insertRctRating(rating);
					}
				}catch(Exception e){
					ejbLogger.error(e.getMessage());
				}
								
			}
			for (Integer itg : bankMap.keySet()){
				ratingsContaioner.getList().getContainer().add(bankMap.get(itg));
			}
			
			Auditor aud = new Auditor();
			ByteArrayOutputStream oS =  (ByteArrayOutputStream) aud.marshal(ratingsContaioner);
			byte[] xml = new byte[oS.toString().getBytes().length];
			xml = oS.toByteArray();
			
			RctAudHistEntity audEntity = new RctAudHistEntity();
			RctAudHistEntityPK audEntityPk = new RctAudHistEntityPK();
			audEntityPk.setAudHisDat(new Date());
			audEntityPk.setApplCode(LoggerFactory.applicationCode);
			audEntity.setId(audEntityPk);
			audEntity.setAudHBlob(xml);
			
			rctAudHitsEAO.insertAuditFlow(audEntity);
			
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
			sysLogger.error(LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2"+"DailyRun - one shot batch failed.");
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
			sysLogger.error(LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2"+"DailyRun - one shot batch failed.");
		}
	}
	
	public void setUp() throws BackEndException{
		ejbLogger.debug(new StandardLogMessage("in RatingsCalculations.setUp"));
		try {
			Container setUpContaioner = new Container();
			setUpContaioner.setType("SetUp");
			Attribute timeAttribute = new Attribute();
			timeAttribute.setName("Time");
			timeAttribute.setValue(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date()));
			setUpContaioner.getAttribute().add(timeAttribute);
			//bankContainer.getAttribute().add(timeAttribute);
						
			this.marketRatingCalculationsBean.setUp(setUpContaioner);
			
			Auditor aud = new Auditor();
			ByteArrayOutputStream oS =  (ByteArrayOutputStream) aud.marshal(setUpContaioner);
			byte[] xml = new byte[oS.toString().getBytes().length];
			xml = oS.toByteArray();
			
			RctAudHistEntity audEntity = new RctAudHistEntity();
			RctAudHistEntityPK audEntityPk = new RctAudHistEntityPK();
			audEntityPk.setAudHisDat(new Date());
			audEntityPk.setApplCode("INTERNAL RATING");
			audEntity.setId(audEntityPk);

			audEntity.setAudHBlob(xml);
			
			rctAudHitsEAO.insertAuditFlow(audEntity);
			
			ejbLogger.debug(new StandardLogMessage("setUp complited"));
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
			sysLogger.error(LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2"+"SetUp batch failed.");
		} catch (JAXBException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
			sysLogger.error(LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2"+"SetUp batch failed.");
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			ejbLogger.error(new StandardLogMessage("Exception during calculation - proceed"));
			sysLogger.error(LoggerFactory.applicationCode+"|1"+SystemProperties.getSystemProperty("enviroment")+"|2"+"SetUp batch failed.");
		}
		
		 
	}
}
