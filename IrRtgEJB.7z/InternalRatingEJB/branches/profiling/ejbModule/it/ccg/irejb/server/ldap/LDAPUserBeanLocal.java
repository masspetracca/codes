package it.ccg.irejb.server.ldap;

public interface LDAPUserBeanLocal {

	public LDAPUserDTO getLDAPUserByUID(String uid) throws Exception;
}
