package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctBnkFtcTEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RctBnkFtcTEAO
 */
@Stateless
@Local(RctBnkFtcTEAOLocal.class)
public class RctBnkFtcTEAO implements RctBnkFtcTEAOLocal {
	
	@PersistenceContext
	private EntityManager manager;
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private DateFormat df = new SimpleDateFormat("yyyy/mm/dd");
    /**
     * Default constructor. 
     */
    public RctBnkFtcTEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertRtcBnkFtc(RctBnkFtcTEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in insertRtcBnkFtc(RctBnkFtcTEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctBnkFtcTEntity identification data: fitch nickname = "+entity.getId().getFitchnname()+" fitch code = "+entity.getId().getFitchcode()));
    	ejbLogger.debug(new StandardLogMessage("insert"));
    	this.manager.persist(entity);
    }
    
    public void deleteRtcBnkFtc(RctBnkFtcTEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in deleteRtcBnkFtc(RctBnkFtcTEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctVarHEntity identification data: fitch nickname = "+entity.getId().getFitchnname()+" fitch code = "+entity.getId().getFitchcode()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	this.manager.remove(entity);
    }

    public void updateRtcBnkFtc(RctBnkFtcTEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in updateRtcBnkFtc(RctBnkFtcTEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctVarHEntity identification data: fitch nickname = "+entity.getId().getFitchnname()+" fitch code = "+entity.getId().getFitchcode()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	this.manager.merge(entity);
    }
    
    /*
     * 
		
     * @see it.ccg.irejb.server.bean.eao.RctBnkFtcTEAOLocal#RtcBnkFtcById(java.lang.String)
     */
    
    public RctBnkFtcTEntity RtcBnkFtcById(String fitchNname) throws BackEndException {
    	ejbLogger.debug(new StandardLogMessage("in RctBnkFtcTEntity RtcBnkFtcById(String fitchNname) throws BackEndException"));
    	RctBnkFtcTEntity bnkFtc = null;
	
    	ejbLogger.debug(new StandardLogMessage("fitch nickname: "+fitchNname));
    	ejbLogger.debug(new StandardLogMessage("find"));
    	bnkFtc = (RctBnkFtcTEntity)this.manager.find(RctBnkFtcTEntity.class, fitchNname);

		return bnkFtc;
    }
    
   //@NamedQuery(name="getRctBnkFtcTByFitchCode", query="SELECT bnkFtc FROM RctBnkFtcTEntity bnkFtc WHERE bnkFtc.fitchcode = :fitchcode"),
    @SuppressWarnings("unchecked")
	public List<RctBnkFtcTEntity> retrieveBnkFtcTByFitchCode(int fitchCode){
    	ejbLogger.debug(new StandardLogMessage("in List<RctBnkFtcTEntity> retrieveBnkFtcTByFitchCode(int fitchCode)"));
    	ejbLogger.debug(new StandardLogMessage("Fitch code: "+fitchCode));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getRctBnkFtcTByFitchCode");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("fitchcode", fitchCode);
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
		List<RctBnkFtcTEntity> bnkFtcs = (List<RctBnkFtcTEntity>) q.getResultList();
		
    	return bnkFtcs;
    }
    
    //@NamedQuery(name="getRctBnkFtcTByAccountingSys", query="SELECT bnkFtc FROM RctBnkFtcTEntity bnkFtc WHERE bnkFtc.accountsys = :accountsys"),
    @SuppressWarnings("unchecked")
	public List<RctBnkFtcTEntity> retrieveBnkFtcTByAccountingSys(String accountingSystem){
       	ejbLogger.debug(new StandardLogMessage("in List<RctBnkFtcTEntity> retrieveBnkFtcTByAccountingSys(String accountingSystem)"));
       	ejbLogger.debug(new StandardLogMessage("accountsys : "+accountingSystem));
       	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
       	Query q = this.manager.createNamedQuery("getRctBnkFtcTByAccountingSys");
       	ejbLogger.debug(new StandardLogMessage("populate named query"));
       	q.setParameter("accountsys", accountingSystem);
       	
       	ejbLogger.debug(new StandardLogMessage("getResultList"));
   		List<RctBnkFtcTEntity> bnkFtcs = (List<RctBnkFtcTEntity>) q.getResultList();
   		
       	return bnkFtcs;
    }
    
    //@NamedQuery(name="getRtcBnkFtcTByLatestPeriod", query="SELECT bnkFtc FROM RctBnkFtcTEntity bnkFtc WHERE bnkFtc.latestper = :latestper"),
    @SuppressWarnings("unchecked")
	public List<RctBnkFtcTEntity> retrieveBnkFtcTByLatestPeriod(String latestPeriod) throws BackEndException {
       	ejbLogger.debug(new StandardLogMessage("in List<RctBnkFtcTEntity> retrieveBnkFtcTByLatestPeriod(String latestPeriod) throws BackEndException"));
       	ejbLogger.debug(new StandardLogMessage("latestPeriod : "+latestPeriod));
       	List<RctBnkFtcTEntity> bnkFtcs = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getRtcBnkFtcTByLatestPeriod");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			q.setParameter("latestper", df.parse(latestPeriod));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			bnkFtcs = (List<RctBnkFtcTEntity>) q.getResultList();
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	return bnkFtcs;
     } 
    
    //@NamedQuery(name="getRtcBnkFtcTByIsConsolidated", query="SELECT bnkFtc FROM RctBnkFtcTEntity bnkFtc WHERE bnkFtc.isconsolid = :isconsolid"),
    @SuppressWarnings("unchecked")
	public List<RctBnkFtcTEntity> retrieveBnkFtcTByIsConsolidated(String isConsolidated){
    	ejbLogger.debug(new StandardLogMessage("in List<RctBnkFtcTEntity> retrieveBnkFtcTByIsConsolidated(String isConsolidated)"));
    	ejbLogger.debug(new StandardLogMessage("isConsolidated: "+isConsolidated));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getRtcBnkFtcTByIsConsolidated");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("isconsolid", isConsolidated);
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
    	List<RctBnkFtcTEntity> bnkFtcs = (List<RctBnkFtcTEntity>) q.getResultList();
		
    	return bnkFtcs;
    }
    
    //@NamedQuery(name="getRtcBnkFtcTForCalc", query="SELECT bnkFtc FROM RctBnkFtcTEntity bnkFtc WHERE bnkFtc.fitchcode = :fitchcode and UPPER(bnkFtc.accountsys) like UPPER('%(IFRS)') and bnkFtc.isconsolid = 'Y' and bnkFtc.latestper = (SELECT MAX(bnkFtc2.latestper) FROM RctBnkFtcTEntity bnkFtc2 WHERE bnkFtc2.fitchcode = :fitchcode and UPPER(bnkFtc2.accountsys) like UPPER('%(IFRS)') and bnkFtc2.isconsolid = 'Y')")
    @SuppressWarnings("unchecked")
	public List<RctBnkFtcTEntity> retrieveBnkFtcTForCalculationByFitchCode(int fitchcode){
    	ejbLogger.debug(new StandardLogMessage("in List<RctBnkFtcTEntity> retrieveBnkFtcTForCalculationByFitchCode(String fitchcode)"));
    	ejbLogger.debug(new StandardLogMessage("fitchcode: "+fitchcode));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	//IFRS consilidate query 
    	Query qIfrs = this.manager.createNamedQuery("getRtcBnkFtcTIFRSForCalc");
    	ejbLogger.debug(new StandardLogMessage("populate IFRS named query"));
    	qIfrs.setParameter("fitchcode", fitchcode);
    	//GAAP consilidate query 
    	Query qGaap = this.manager.createNamedQuery("getRtcBnkFtcTGAAPForCalc");
    	ejbLogger.debug(new StandardLogMessage("populate GAAP named query"));
    	qGaap.setParameter("fitchcode", fitchcode);
    	
    	//IFRS not consilidate query 
    	Query qIfrsNC = this.manager.createNamedQuery("getRtcBnkFtcTIFRSNotConsolidatedForCalc");
    	ejbLogger.debug(new StandardLogMessage("populate IFRS not cosolidated named query"));
    	qIfrsNC.setParameter("fitchcode", fitchcode);
    	//GAAP not consilidate query 
    	Query qGaapNC = this.manager.createNamedQuery("getRtcBnkFtcTGAAPNotConsolidatedForCalc");
    	ejbLogger.debug(new StandardLogMessage("populate GAAP not cosolidated named query"));
    	qGaapNC.setParameter("fitchcode", fitchcode);
    	
    	ejbLogger.debug(new StandardLogMessage("IFRS getResultList"));
    	List<RctBnkFtcTEntity> bnkFtc = (List<RctBnkFtcTEntity>) qIfrs.getResultList();
    	if (bnkFtc.size() ==0) {
    		ejbLogger.debug(new StandardLogMessage("GAAP getResultList"));
    		bnkFtc = (List<RctBnkFtcTEntity>) qGaap.getResultList();
    	}
    	if (bnkFtc.size() == 0){
    		ejbLogger.debug(new StandardLogMessage("IFRS not cosolidated getResultList"));
			bnkFtc = (List<RctBnkFtcTEntity>) qIfrsNC.getResultList();
		}
    	if (bnkFtc.size() == 0){
    		ejbLogger.debug(new StandardLogMessage("GAAP not cosolidated getResultList"));
			bnkFtc = (List<RctBnkFtcTEntity>) qGaapNC.getResultList();
		}
		
    	return bnkFtc;
    }
}
