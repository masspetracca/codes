package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctVarHEntity;
import it.ccg.irejb.server.bean.entity.RctVarHEntityPK;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RctVarHEAO
 */
@Stateless
@Local(RctVarHEAOLocal.class)
public class RctVarHEAO implements RctVarHEAOLocal {

	@PersistenceContext
	private EntityManager manager;
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private DateFormat df = new SimpleDateFormat("yyyy/mm/dd");
    /**
     * Default constructor. 
     */
    public RctVarHEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertRtcVarHistory(RctVarHEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in insertRatingHistory(RctRatingHEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctVarHEntity identification data: VarID = "+entity.getId().getVarid()+" provider = "+entity.getId().getProvider()+" value date ="+entity.getId().getValuedate()));
    	ejbLogger.debug(new StandardLogMessage("insert"));
    	this.manager.persist(entity);
    }
    
    public void deleteRtcVarHistory(RctVarHEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in deleteBank(RctBankEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctVarHEntity identification data: VarID = "+entity.getId().getVarid()+" provider = "+entity.getId().getProvider()+" value date ="+entity.getId().getValuedate()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	this.manager.remove(entity);
    }

    public void updateRtcVarHistory(RctVarHEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in updateBank(RctBankEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctVarHEntity identification data: VarID = "+entity.getId().getVarid()+" provider = "+entity.getId().getProvider()+" value date ="+entity.getId().getValuedate()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	this.manager.merge(entity);
    }
    
    public RctVarHEntity retrieveRtcVarHistoryById(int varId,String provider,String valueDate) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in RctVarHEntity retrieveRtcVarHistory(String varId,String provider,String valueDate) throws BackEndException"));
    	RctVarHEntity var = null;
    	try {
    		    	
			Date updateDate = this.df.parse(valueDate);
			RctVarHEntityPK pk = new RctVarHEntityPK();
			pk.setVarid(varId);
			pk.setProvider(provider);
			pk.setValuedate(updateDate);
			
	    	ejbLogger.debug(new StandardLogMessage("Var ID: "+varId));
	    	ejbLogger.debug(new StandardLogMessage("Provider: "+provider));
	    	ejbLogger.debug(new StandardLogMessage("value date: "+valueDate));
	    	ejbLogger.debug(new StandardLogMessage("find"));
	    	
	    	var = (RctVarHEntity)this.manager.find(RctVarHEntity.class, pk);
	    	
    	} catch (ParseException e) {
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    	return var;
    }
    
    //getRtcVarHistoryByVarId
    @SuppressWarnings("unchecked")
	public List<RctVarHEntity> retrieveVarHhistByVarId(int varId){
    	ejbLogger.debug(new StandardLogMessage("in List<RctVarHEntity> retrieveVarHhistByVarId(String varId)"));
    	ejbLogger.debug(new StandardLogMessage("Var id: "+varId));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getRtcVarHistoryByVarId");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("varid", varId);
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
		List<RctVarHEntity> var = (List<RctVarHEntity>) q.getResultList();
		
    	return var;
    }
    
    //getRtcVarHistoryByProvider
    @SuppressWarnings("unchecked")
	public List<RctVarHEntity> retrieveVarHhistByProvider(String provider){
       	ejbLogger.debug(new StandardLogMessage("in List<RctVarHEntity> retrieveVarHhistByProvider(String provider)"));
       	ejbLogger.debug(new StandardLogMessage("Provider : "+provider));
       	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
       	Query q = this.manager.createNamedQuery("getRtcVarHistoryByProvider");
       	ejbLogger.debug(new StandardLogMessage("populate named query"));
       	q.setParameter("provider", provider);
       	
       	ejbLogger.debug(new StandardLogMessage("getResultList"));
   		List<RctVarHEntity> var = (List<RctVarHEntity>) q.getResultList();
   		
       	return var;
    }
    
    //getRtcVarHistoryByValueDate
    @SuppressWarnings("unchecked")
	public List<RctVarHEntity> retrieveVarHhistByValueDate(String valueDate) throws BackEndException {
       	ejbLogger.debug(new StandardLogMessage("in List<RctVarHEntity> retrieveVarHhistByValueDate(String valueDate)"));
       	ejbLogger.debug(new StandardLogMessage("Value date : "+valueDate));
       	List<RctVarHEntity> var = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getRtcVarHistoryByValueDate");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			q.setParameter("valuedate", df.parse(valueDate));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			var = (List<RctVarHEntity>) q.getResultList();
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}	
       	return var;
     } 
    
    //getRtcVarHistoryByVarIdBankIdForCalc
    @SuppressWarnings("unchecked")
	public List<RctVarHEntity> retrieveVarHhistByVarIdFitchNName(int varId, String fitchNName){
    	ejbLogger.debug(new StandardLogMessage("in List<RctVarHEntity> retrieveVarHhistByVarIdFitchNName(int varId, String fitchNName)"));
    	ejbLogger.debug(new StandardLogMessage("Var id: "+varId));
    	ejbLogger.debug(new StandardLogMessage("Fitch nickname: "+fitchNName));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	
    	Query q = this.manager.createNamedQuery("getRtcVarHistoryByVarIdFitchNNameForCalcWithLatestData");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("varid", varId);
    	q.setParameter("fitchnname", fitchNName);
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
    	List<RctVarHEntity> var = (List<RctVarHEntity>) q.getResultList();
		
    	return var;
    }
}
