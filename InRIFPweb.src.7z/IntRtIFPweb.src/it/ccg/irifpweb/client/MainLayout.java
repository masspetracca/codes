package it.ccg.irifpweb.client;


import it.ccg.irifpweb.client.ac.ACMainLayout;
import it.ccg.irifpweb.client.security.UserData;

import java.util.ArrayList;
import java.util.List;

import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.ResizedEvent;
import com.smartgwt.client.widgets.events.ResizedHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.tab.Tab;
import com.smartgwt.client.widgets.tab.TabSet;
import com.smartgwt.client.widgets.tab.events.TabSelectedEvent;
import com.smartgwt.client.widgets.tab.events.TabSelectedHandler;


public class MainLayout extends VLayout {
	
	private static MainLayout mainLayout;													//	mainLayout
	
	private HLayout headerHLayout;									//		headerHLayout
	private HeaderUserSection headerUserSection;
	private HLayout tabSetHLayout;											//		tabSetHLayout
	
	Tab administrativeConsoleTab;
	
	
	public static MainLayout createInstance() {
		
		mainLayout = new MainLayout();
		
		return mainLayout;
	}
	
	
	
	public MainLayout() {
		
		super();
		
		this.setWidth("99%");
		this.setHeight("99%");
		
		// definisco la struttura
		// ***************************************************************************
		
		// header -----------------------------------------------------------------------
		
		this.headerHLayout = new HLayout();
		this.headerHLayout.setHeight("10%");
		this.headerHLayout.setWidth100();
		this.headerHLayout.setLayoutTopMargin(5);
		//this.headerHLayout.setShowResizeBar(true);
		
		// logo  
		Img logo = new Img("IFPlogo.png", 321, 50); 	
		this.headerHLayout.addMember(logo, 0);
		
		// white space
		LayoutSpacer layoutSpacer = new LayoutSpacer();
		layoutSpacer.setHeight("10%");
		layoutSpacer.setWidth100();
		this.headerHLayout.addMember(layoutSpacer, 1);
		
		// user info
		this.headerUserSection = new HeaderUserSection();
		this.headerHLayout.addMember(this.headerUserSection, 2);
		
		// header -------------------------------------------------------------------
		
		
		// tab set ----------------------------------------------------------------------
		TabSet tabSet = new TabSet(); 
		
		List<Tab> tempList = new ArrayList<Tab>();
		
		if(UserData.getCurrentUserData().getUserRolesList().contains("admin")) {
			Tab administrativeConsoleTab = new Tab("Administrative console");
			administrativeConsoleTab.setPane(new ACMainLayout());
			
			tempList.add(administrativeConsoleTab);
		}
        
        final Tab staticDataTab = new Tab("Static data");
        staticDataTab.setPane(new StaticDataCanvas());
        tempList.add(staticDataTab);
        staticDataTab.addTabSelectedHandler(new TabSelectedHandler() {
			
			@Override
			public void onTabSelected(TabSelectedEvent event) {
				
				if(staticDataTab.getPane() != null) {
					staticDataTab.getPane().destroy();
				}
				
		        staticDataTab.setPane(new StaticDataCanvas());
			}
		});
        
        final Tab historicalDataTab = new Tab("Historical data");
        tempList.add(historicalDataTab);
        historicalDataTab.addTabSelectedHandler(new TabSelectedHandler() {
			
			@Override
			public void onTabSelected(TabSelectedEvent event) {
				
				if(historicalDataTab.getPane() != null) {
					historicalDataTab.getPane().destroy();
				}
				
				historicalDataTab.setPane(new HisDataCanvas());
			}
		});
        
        
        Tab[] tabArray = new Tab[tempList.size()];
        tabArray = tempList.toArray(tabArray);
        
        tabSet.setTabs(tabArray);
        
        this.tabSetHLayout = new HLayout();
        this.tabSetHLayout.setHeight100();
		this.tabSetHLayout.setWidth100();
        this.tabSetHLayout.setLayoutTopMargin(20);
        
        this.tabSetHLayout.addMember(tabSet);
        
        // tab set ----------------------------------------------------------------------
        
        
		this.addMember(this.headerHLayout);
		this.addMember(this.tabSetHLayout);
		
		this.setLeft("8");
		this.setTop("3");
		
		// ***************************************************************************
		
		
		// La finestra account utente, se presente, scompare al click su qualsiasi punto del main layout
		this.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(Window.getById("_AccountWindow") != null) {
					
					// remove
					mainLayout.removeChild(Window.getById("_AccountWindow"));
					// destroy
					Window.getById("_AccountWindow").destroy();
				}
				
			}
		});
		// Intercetta il ridimensionamento della main layout e ridisegna l'account window, solo se quest'ultima era visibile
		this.addResizedHandler(new ResizedHandler() {
			
			@Override
			public void onResized(ResizedEvent event) {
				
				if(Window.getById("_AccountWindow") != null) {
					
					// remove
					mainLayout.removeChild(Window.getById("_AccountWindow"));
					// destroy
					Window.getById("_AccountWindow").destroy();
					
					headerUserSection.redrawAccountWindow();
					
				}
				
			}
		});
		
	}

	

	public static MainLayout getMainLayout() {
		
		return mainLayout;
	}


	
}

