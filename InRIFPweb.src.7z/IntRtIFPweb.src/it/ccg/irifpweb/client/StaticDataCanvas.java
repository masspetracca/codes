package it.ccg.irifpweb.client;


import it.ccg.irifpweb.client.base.InputFileInfo;
import it.ccg.irifpweb.client.base.MyListGrid;
import it.ccg.irifpweb.client.base.PopupWindow;
import it.ccg.irifpweb.client.base.StandardButton;
import it.ccg.irifpweb.client.base.UploadForm;
import it.ccg.irifpweb.client.security.UserData;

import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.JSOHelper;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;

public class StaticDataCanvas extends Canvas {
	
	private MyListGrid staticDataGrid;
	
	public StaticDataCanvas() {
		super();
		
		this.setID("StaticDataSection");
		
		this.setHeight100();
		this.setWidth100();
		
		VLayout vLayout = new VLayout();
		vLayout.setWidth100();
		vLayout.setHeight100();
		
		
		
		// instruments grid section *******************************************************************************
		staticDataGrid = this.createStaticDataGrid();
		staticDataGrid.setWidth100();
		staticDataGrid.setHeight100();
		
		staticDataGrid.setShowResizeBar(true);
		staticDataGrid.setResizeBarTarget("next");
        
		vLayout.addMember(staticDataGrid);
        
        
        // instruments grid section *******************************************************************************
		
		
		// se sono amministratore..
        // add edit section *******************************************************************************
		if(UserData.getCurrentUserData().getUserRolesList().contains("admin")) {
			
			// ..posso editare
			VLayout editVLayout = this.createEditLayout();
			editVLayout.setWidth100();
			editVLayout.setHeight(40);
			
			vLayout.addMember(editVLayout);
			
		}
		// add edit section *******************************************************************************
		
		
        // add sectionStack to canvas
        this.addChild(vLayout);
	}
	
	
	private MyListGrid createStaticDataGrid() {
		
		MyListGrid grid = MyListGrid.getInstance(DataSource.get("bank"));

		grid.setAlternateRecordStyles(true);
		grid.setHeight("100%");
		grid.setWidth("100%");
		
		grid.setAutoFetchData(true);
		grid.setCanEdit(false);
		grid.setFetchOperation("fetch");
		grid.setAddOperation("add");
		grid.setUpdateOperation("update");
		grid.setRemoveOperation("remove");
		
		
		return grid;
	}
	
	
	private VLayout createEditLayout() {
		VLayout vLayout = new VLayout();
		
		// buttons
        IButton newButton = new StandardButton();
        newButton.setTitle("Add");
        newButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
		        
		        // open window
		        createAddPopupWindow().draw();
			}
		});
        
        IButton updateButton = new StandardButton();
        updateButton.setTitle("Update");
        updateButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(staticDataGrid.getSelectedRecord() == null) {
					
					SC.warn("No selected record.");
					
					return;
				}
				
				// open window
				createUpdatePopupWindow().draw();
			}
		});
        
        IButton removeButton = new StandardButton();
        removeButton.setTitle("Remove");
        removeButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(staticDataGrid.getSelectedRecord() == null) {
					
					SC.warn("No selected record.");
					
					return;
				}
				
				SC.confirm("Delete selected record?", new BooleanCallback() {
					
					@Override
					public void execute(Boolean value) {
						
						if(value) {
							
							// remove data
							staticDataGrid.removeData(staticDataGrid.getSelectedRecord());
						}
						
					}
				});
				
				
			}
		});
        
        IButton importButton = new StandardButton();
        importButton.setTitle("Import");
        importButton.setAlign(Alignment.CENTER);
        importButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				// open window
				createImportStaticDataPopupWindow().draw();
			}
		});
        
        final IButton exportButton = new StandardButton();
        exportButton.setTitle("Export");
        //addButton.setAlign(Alignment.CENTER);
        exportButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				// TODO
				
			}
		});
        
        
        
        HLayout hButtonLayout = new HLayout();  
        hButtonLayout.setMembersMargin(15);
        
        hButtonLayout.setMembers(newButton, updateButton, removeButton, importButton/*, exportButton*/);
        // buttons
        
        
        vLayout.addMember(hButtonLayout);
        vLayout.setLayoutTopMargin(10);
        vLayout.setLayoutBottomMargin(10);
        vLayout.setLayoutLeftMargin(10);
		
		
		return vLayout;
	}
	
	
	
	// ******************************************************************************
	// ******************************************************************************
	// ******************************************************************************
	// ******************************************************************************
	// ******************************************************************************
	
	
	
	private PopupWindow createAddPopupWindow() {
		
		PopupWindow popupWindow = PopupWindow.getInstance("Add", 850, 350);
		
		VLayout vLayout = new VLayout();
		
		// form
		final DynamicForm form = this.createInstrForm();
		// add form to vLayout
		vLayout.addMember(form);
		
		// buttons
        IButton addButton = new StandardButton();
        addButton.setTitle("Add");
        addButton.setAlign(Alignment.CENTER);
        addButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(!form.validate()) {
        			
					return;
        		}
				
				// add data
				staticDataGrid.addData(form.getValuesAsRecord());
				
				form.reset();
			}
		});
        
        IButton cancelButton = new StandardButton();
        cancelButton.setTitle("Cancel");
        cancelButton.setAlign(Alignment.CENTER);
        cancelButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				form.reset();
			}
		});
        
        HLayout buttonHLayout = new HLayout();  
        buttonHLayout.setMembersMargin(15);
        buttonHLayout.setLayoutTopMargin(10);
        buttonHLayout.setLayoutLeftMargin(10);
         
        buttonHLayout.addMember(addButton);
        buttonHLayout.addMember(cancelButton);
        // add buttons to vLayout
        vLayout.addMember(buttonHLayout);
        
        
        //
        vLayout.setMembersMargin(20);
        
        // add form to window
        popupWindow.addMember(vLayout);
		
		
		return popupWindow;
	}
	
	
	private PopupWindow createUpdatePopupWindow() {
		
		PopupWindow popupWindow = PopupWindow.getInstance("Update", 850, 350);
		
		VLayout vLayout = new VLayout();
		
		// form
		final DynamicForm form = this.createInstrForm();
		// fill form
		form.setValues(JSOHelper.convertToMap(staticDataGrid.getSelectedRecord().getJsObj()));
		// add form to vLayout
		vLayout.addMember(form);
		
		// buttons
        IButton updateButton = new StandardButton();
        updateButton.setTitle("Update");
        updateButton.setAlign(Alignment.CENTER);
        updateButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(!form.validate()) {
        			
					return;
        		}
				
				// update data
				DSRequest dsRequest = new DSRequest();
				dsRequest.setOldValues(staticDataGrid.getSelectedRecord());
				staticDataGrid.updateData(form.getValuesAsRecord(), new DSCallback() {
					
					@Override
					public void execute(DSResponse response, Object rawData, DSRequest request) {
						
						// DO NOTHING
					
					}
					
				}, dsRequest);
				
			}
		});
        
        IButton cancelButton = new StandardButton();
        cancelButton.setTitle("Cancel");
        cancelButton.setAlign(Alignment.CENTER);
        cancelButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				form.reset();
			}
		});
        
        HLayout buttonHLayout = new HLayout();  
        buttonHLayout.setMembersMargin(15);
        buttonHLayout.setLayoutTopMargin(10);
        buttonHLayout.setLayoutLeftMargin(10);
        
        buttonHLayout.addMember(updateButton);
        buttonHLayout.addMember(cancelButton);
        // add buttons to vLayout
        vLayout.addMember(buttonHLayout);
        
        
        //
        vLayout.setMembersMargin(20);
        
        // add form to window
        popupWindow.addMember(vLayout);
		
		
		return popupWindow;
	}
	
	
	
	
	
	
	private DynamicForm createInstrForm() {
		
		// form
		DynamicForm dynamicForm = new DynamicForm();
		// retrieve form fields from instr.ds.xml
		dynamicForm.setDataSource(DataSource.get("bank"));
		
		dynamicForm.setNumCols(6);
		
		// if i call draw() now, form will be designed at random
		/*// (*) needed to successfully call method on dynamicForm at this moment
		dynamicForm.draw();
		
		// (*)
		FormItem[] items = dynamicForm.getFields();
		for(FormItem item : items) {
			item.setTitle("<nobr>" + item.getTitle() + "</nobr>");
			
			if(!item.getCanEdit()) {
				
				item.setVisible(false);
			}
		}*/
		
        
		return dynamicForm;
	}
	
	
	// it correctly uploads file, and i have callback
	private PopupWindow createImportStaticDataPopupWindow() {
		
		PopupWindow popupWindow = PopupWindow.getInstance("Import static data..", 600, 250);
		
		// file format info
		InputFileInfo inputFileInfo = new InputFileInfo("instr-example.csv");
		// upload form
		UploadForm uploadForm = new UploadForm() {
			
			// set action to accomplish if upload succeeded
			@Override
			protected void onSubmitSucceed() {
				
				// TODO
				
				
				/*RPCRequest rpcRequest = new RPCRequest();
				rpcRequest.setActionURL("servlet/ImportData");
				
				Map<String,String> params = new HashMap<String, String>();
				params.put("fileName", uploadItem.getFilename());
				
				rpcRequest.setParams(params);
				
				RPCManager.sendRequest(rpcRequest, new RPCCallback() {
					
					@Override
					public void execute(RPCResponse response, Object rawData, RPCRequest request) {
						
						progressBar.setFinished();
						
						
						@SuppressWarnings("unchecked")
						Map<String, Object> data = response.getAttributeAsMap("data");
						
						String status = (String)data.get("status");
						String msg = (String)data.get("msg");
						
						if(status.equalsIgnoreCase("0")) {
							SC.say("Import data info", msg, new BooleanCallback() {
								
								@Override
								public void execute(Boolean value) {
									
									form.reset();
						            
						            uploadButton.setEnabled(true);
						            
						            vLayout.removeMember(progressBar);
						            progressBar.destroy();
								}
							});
						}
			            else if(status.equalsIgnoreCase("-1")) {
							SC.warn(msg, new BooleanCallback() {
								
								@Override
								public void execute(Boolean value) {
									
									form.reset();
									
									vLayout.removeMember(progressBar);
									progressBar.destroy();
									
						            uploadButton.setEnabled(true);
								}
							});
						}
					}
				});*/
				
			}
			
		};
	    
		VLayout vLayout = new VLayout();
	    vLayout.addMember(inputFileInfo);
		vLayout.addMember(uploadForm);
		
		vLayout.setLayoutLeftMargin(5);
		vLayout.setLayoutTopMargin(5);
		vLayout.setMembersMargin(20);
		
        // add vLayout to popupWindow
		popupWindow.addMember(vLayout);
		
		
		return popupWindow;
	}
	
	

}
