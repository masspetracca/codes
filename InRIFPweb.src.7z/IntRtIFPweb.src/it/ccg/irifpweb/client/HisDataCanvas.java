package it.ccg.irifpweb.client;


import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpweb.client.base.InputFileInfo;
import it.ccg.irifpweb.client.base.LoadingWidget;
import it.ccg.irifpweb.client.base.MyListGrid;
import it.ccg.irifpweb.client.base.PopupWindow;
import it.ccg.irifpweb.client.base.StandardButton;
import it.ccg.irifpweb.client.base.UploadForm;
import it.ccg.irifpweb.client.rpc.MyRPCCallback;
import it.ccg.irifpweb.client.rpc.MyRPCRequest;
import it.ccg.irifpweb.client.security.UserData;

import java.util.HashMap;
import java.util.Map;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.OperatorId;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.grid.CellFormatter;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.CellClickEvent;
import com.smartgwt.client.widgets.grid.events.CellClickHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;


public class HisDataCanvas extends Canvas {
	
	private HLayout gridLayout = new HLayout();
	
	
	public HisDataCanvas() {
		super();
		
		//this.setID("_HisDataCanvas_0");
		
		this.setHeight100();
		this.setWidth100();
		
		VLayout vLayout = new VLayout();
		vLayout.setWidth100();
		vLayout.setHeight100();
		
		
		// grid section *******************************************************************************
		this.gridLayout.setWidth100();
		this.gridLayout.setHeight100();
		this.gridLayout.setMembersMargin(10);
		this.gridLayout.setShowResizeBar(true);
		this.gridLayout.setResizeBarTarget("next");
		
		this.gridLayout.addMember(this.createInfoBankGrid(), 0);
		this.gridLayout.addMember(this.createInfoVarGrid(null), 1);
		this.gridLayout.addMember(this.createHisGrid(null, null), 2);
		
		vLayout.addMember(this.gridLayout);
        // grid section *******************************************************************************
        
		
        // se sono amministratore..
        // import data section *******************************************************************************
		if(UserData.getCurrentUserData().getUserRolesList().contains("admin")) {
			
			// ..posso aggiungere dati
			
			VLayout temp2_vLayout = this.createEditLayout();
			temp2_vLayout.setWidth100();
			temp2_vLayout.setHeight(40);
			
	        vLayout.addMember(temp2_vLayout);
		}
		// import data section *******************************************************************************
		
        
        
        
        // add sectionStack to canvas
        this.addChild(vLayout);
		
	}
	
	private MyListGrid createInfoBankGrid() {
		
		final MyListGrid grid = MyListGrid.getInstance(DataSource.getDataSource("bank"));
		
		grid.setWidth("60%");
		
		grid.setAutoFetchData(true);
		grid.setFetchOperation("fetch");
		
		grid.setCanEdit(false);
		
		// show historical data on click
		grid.addCellClickHandler(new CellClickHandler() {
			
			@Override
			public void onCellClick(CellClickEvent event) {
				
				if(MyListGrid.getById("_VarsGrid_0") != null) {
					
					MyListGrid.getById("_VarsGrid_0").destroy();
				}
				
				ListGridRecord record = grid.getSelectedRecord();
				int bankid = Integer.parseInt(record.getAttribute("bankid"));
			
				gridLayout.addMember(createInfoVarGrid(bankid), 1);
				
			}
		});
		
		
		return grid;
	}
	
	
	private MyListGrid createInfoVarGrid(final Integer bankid) {
		
		final MyListGrid grid = MyListGrid.getInstance(DataSource.getDataSource("vars"));
		
		grid.setID("_VarsGrid_0");
		grid.setWidth("25%");
		
		grid.setAutoFetchData(true);
		grid.setFetchOperation("fetch");
		
		grid.setCanEdit(false);
		
		/*//
		if(bankid != null) {
			
			// I send "bankid" because it is the field's name into the JPA entity. 
			// See server side code for details.
			AdvancedCriteria advancedCriteria = new AdvancedCriteria("bankid", OperatorId.EQUALS, bankid);
			grid.fetchData(advancedCriteria);
			grid.setFilterEditorCriteria(advancedCriteria);
		}*/
		
		
		// show historical data on click
		grid.addCellClickHandler(new CellClickHandler() {
			
			@Override
			public void onCellClick(CellClickEvent event) {
				
				if(MyListGrid.getById("_HisGrid_0") != null) {
					
					MyListGrid.getById("_HisGrid_0").destroy();
				}
				
				ListGridRecord record = grid.getSelectedRecord();
				int varid = Integer.parseInt(record.getAttribute("varid"));
			
				gridLayout.addMember(createHisGrid(bankid, varid), 2);
				
			}
		});
		
		
		return grid;
	}
	
	private MyListGrid createHisGrid(Integer bankid, Integer varid) {
		
		MyListGrid grid = MyListGrid.getInstance(DataSource.getDataSource("varh.his"));
		
		grid.setID("_HisGrid_0");
		grid.setWidth("15%");
		
		grid.setFetchOperation("fetchHis");
		
		grid.setCanEdit(false);
		
		//
		if(bankid != null && varid != null) {
			
			// I send "bankid" because it is the field's name into the JPA entity. 
			// See server side code for details.
			AdvancedCriteria advancedCriteria = new AdvancedCriteria();
			advancedCriteria.addCriteria("bankid", OperatorId.EQUALS, bankid);
			advancedCriteria.addCriteria("varid", OperatorId.EQUALS, varid);
			grid.fetchData(advancedCriteria);
			grid.setFilterEditorCriteria(advancedCriteria);
		}
		
		
		return grid;
	}
	
	
	
	private VLayout createEditLayout() {
		VLayout vLayout = new VLayout();
		
		// buttons
        
        final IButton importButton = new StandardButton();
        importButton.setTitle("Import");
        importButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
		        // create import data popup window
		        createImportHistoricalDataPopupWindow().draw();
			}
		});
        
        
        HLayout hButtonLayout = new HLayout();  
        hButtonLayout.setMembersMargin(15);
        
        hButtonLayout.setMembers(importButton/*, exportButton*/);
        // buttons
        
        
        vLayout.addMember(hButtonLayout);
        vLayout.setLayoutTopMargin(10);
        vLayout.setLayoutBottomMargin(10);
        vLayout.setLayoutLeftMargin(10);
		
		
		return vLayout;
	}
	
	
	
	private PopupWindow createImportHistoricalDataPopupWindow() {
		
		PopupWindow popupWindow = PopupWindow.getInstance("Import historical data..", 600, 250);
		
		// file format info
		InputFileInfo inputFileInfo = new InputFileInfo("hispr-example.csv");
		// upload form
		UploadForm uploadForm = new UploadForm() {
			
			// set action to accomplish if upload succeeded
			@Override
			protected void onSubmitSucceed() {
				
				Map<String,String> params = new HashMap<String, String>();
				
				// TODO: non so come sia possibile, ma il filename a questo punto risulta essere (testualmente) "C:\fakepath\" + "FILENAME"
				String fileName = this.getUploadItem().getFilename();
				fileName = fileName.substring(fileName.lastIndexOf("\\") + 1, fileName.length());
				
				params.put("fileName", fileName);
				
				MyRPCRequest rpcRequest = new MyRPCRequest("servlet/ImportData", params);
				
				// **
				LoadingWidget.getInstance("_loadingWidget0").draw();
				
				RPCManager.sendRequest(rpcRequest, new MyRPCCallback() {
					
					@Override
					public void onCallback(RPCResponse response, Object rawData, RPCRequest request) {
						
						// **
			    		LoadingWidget.getById("_loadingWidget0").destroy();
			    		
					}
				});
				
			}
			
		};
	    
		VLayout vLayout = new VLayout();
	    vLayout.addMember(inputFileInfo);
		vLayout.addMember(uploadForm);
		
		vLayout.setLayoutLeftMargin(5);
		vLayout.setLayoutTopMargin(5);
		vLayout.setMembersMargin(20);
		
        // add vLayout to popupWindow
		popupWindow.addMember(vLayout);
		
		
		return popupWindow;
	}
	
	
	
}
