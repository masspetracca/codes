package it.ccg.irifpweb.client.rpc;

import java.util.Map;

import com.google.gwt.http.client.Response;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.util.SC;

public class MyRPCCallback implements RPCCallback {

	@Override
	final public void execute(RPCResponse response, Object rawData, RPCRequest request) {
		
		// always executed
		this.onCallback(response, rawData, request);
		
		
		if(response.getHttpResponseCode() == Response.SC_OK) {
			
			this.onSuccess(response, rawData, request);
		}
		else {
			
			this.onError(response, rawData, request);
		}
		
	}
	
	
	protected void onCallback(RPCResponse response, Object rawData, RPCRequest request) {
		
	}
	
	
	protected void onSuccess(RPCResponse response, Object rawData, RPCRequest request) {
		
		@SuppressWarnings("unchecked")
		Map<String, Object> data = response.getAttributeAsMap("data");
		
		if((data != null) && (data.get("message") != null)) {
			
			SC.say((String)data.get("message"));
		}
		
	}
	
	
	protected void onError(RPCResponse response, Object rawData, RPCRequest request) {
		
		SC.warn("Server error. Contact CC&G HelpDesk.");
		
	}
	
	
}

