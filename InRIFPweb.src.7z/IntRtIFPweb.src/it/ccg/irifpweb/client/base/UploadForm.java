package it.ccg.irifpweb.client.base;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONValue;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FileUpload;
import com.google.gwt.user.client.ui.FormPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.layout.HLayout;

public class UploadForm extends FormPanel {
	
	private FileUpload uploadItem;
	
	
	public UploadForm() {
		
		this.setAction("servlet/FileUpload");
		
	    // Because we're going to add a FileUpload widget, we'll need to set the
	    // form to use the POST method, and multipart MIME encoding.
		this.setEncoding(FormPanel.ENCODING_MULTIPART);
		this.setMethod(FormPanel.METHOD_POST);
	    
		// create a panel to hold all the form widgets
	    VerticalPanel vPanel = new VerticalPanel();
		
		// FileUpload item
	    this.uploadItem = new FileUpload();
	    // set a name to FileUpload item (necessary to correctly work)
	    this.uploadItem.setName("uploadItem0");
	    // add to vPanel
	    vPanel.add(this.uploadItem);
	    
	    // Add a 'submit' button.
	    final Button uploadButton = new Button("Import");
	    final UploadForm formReference = this;
	    uploadButton.addClickHandler(new com.google.gwt.event.dom.client.ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				
				// send
				formReference.submit();
			}
		});
	    HLayout buttonHLayout = new HLayout();
	    buttonHLayout.addMember(uploadButton);
	    buttonHLayout.setLayoutTopMargin(10);
	    // add to vPanel
	    vPanel.add(buttonHLayout);
	    
	    
	    // add elements to form
	    this.setWidget(vPanel);
	    
	    
	    // Add an submit event handler to form
	    this.addSubmitHandler(new SubmitHandler() {
	        
	    	// This event is fired just before the form is submitted. 
	    	@Override
	    	public void onSubmit(SubmitEvent event) {
	            
	            if(uploadItem.getFilename().equalsIgnoreCase("")) {
	                
	            	SC.warn("No file selected.");
	                
	                event.cancel();
	                
	                return;
	            }
	            
	            
	            // **
	            uploadButton.setEnabled(false);
            	LoadingWidget.getInstance("_loadingWidget0").draw();
	            
	        }
	    });
	    
	    
	    
	    this.addSubmitCompleteHandler(new SubmitCompleteHandler() {
	    	
	    	@Override
	        public void onSubmitComplete(SubmitCompleteEvent event) {
	    		
	    		// **
	    		LoadingWidget.getById("_loadingWidget0").destroy();
	    		uploadButton.setEnabled(true);
	    		// ERROR! Se faccio reset qua, poi non vedr� il file name sulle chiamate successive
	    		//formReference.reset();
	    		
	    		
	    		/*String httpResponseBody = event.getResults();
	    		
	    		JSONValue jsonValue = JSONParser.parseStrict(httpResponseBody);
	    		JSONObject jsonObject = jsonValue.isObject();
	    		
	    		String status = jsonObject.get("status").isString().stringValue();
	    		String message = jsonObject.get("message").isString().stringValue();
	    		
	    		if(status.equalsIgnoreCase("-1")) {
	    			
	    			SC.warn(message);
	    			
		    		return;
	    		}*/
	    		
	    		
	    		// custom actions if submit succeeded
	    		onSubmitSucceed();
	    		
	    		// 
	    		formReference.reset();
	        }
	    });

		
	}
	
	
	protected void onSubmitSucceed() {
		// Do nothing. Override if necessary.
	}
	
	
	public FileUpload getUploadItem() {
		return this.uploadItem;
	}

}
