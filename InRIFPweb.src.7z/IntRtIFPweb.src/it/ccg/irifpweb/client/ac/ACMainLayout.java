package it.ccg.irifpweb.client.ac;



import com.smartgwt.client.types.TreeModelType;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.grid.CellFormatter;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.tab.Tab;
import com.smartgwt.client.widgets.tab.TabSet;
import com.smartgwt.client.widgets.tree.Tree;
import com.smartgwt.client.widgets.tree.TreeGrid;
import com.smartgwt.client.widgets.tree.TreeGridField;
import com.smartgwt.client.widgets.tree.TreeNode;

public class ACMainLayout extends Canvas {
	
	private Tab tab;
	
	
	public ACMainLayout() {
		super();
		
		this.setHeight100();
		this.setWidth100();
		
		HLayout hLayout = new HLayout();
		hLayout.setWidth100();
		hLayout.setHeight100();
		
		// tab set 
		TabSet tabSet = new TabSet();
		// initial canvas into tabset
		this.tab = new Tab("Home");
		this.tab.setPane(new ACHomeCanvas());
		tabSet.setTabs(this.tab);
		
		// add components
		hLayout.setMembers(this.createTreeGrid(), tabSet);
		
		
		this.addChild(hLayout);
	}
	
	
	private TreeGrid createTreeGrid() {
		
		TreeGrid treeGrid = new TreeGrid();
		
		treeGrid.setWidth("17%");  
		treeGrid.setShowConnectors(true);  
		treeGrid.setShowResizeBar(true);
        
        Tree dataTree = new Tree();  
        dataTree.setModelType(TreeModelType.CHILDREN);
        
        TreeNode rootNode = new TreeNode("root");
        dataTree.setRoot(rootNode);
        
        TreeNode homeNode = new TreeNode("Home");
        dataTree.add(homeNode, rootNode);
        
        TreeNode timerNode = new TreeNode("Scheduler");
        dataTree.add(timerNode, homeNode);
        
        TreeNode logNode = new TreeNode("Log");
        dataTree.add(logNode, homeNode);
        
        TreeNode monitoringNode = new TreeNode("Monitor");
        dataTree.add(monitoringNode, homeNode);
        
        // i call it after filling data
        dataTree.openAll();
        
        treeGrid.setData(dataTree);  
          
        TreeGridField treeGridField = new TreeGridField("Navigation");  
        treeGridField.setCellFormatter(new CellFormatter() {  
        	
            @Override
        	public String format(Object value, ListGridRecord record, int rowNum, int colNum) {  
                return record.getAttribute("name");  
            }  
        });
        
        treeGrid.setFields(treeGridField);
        
        treeGrid.addRecordClickHandler(new RecordClickHandler() {
			
			@Override
			public void onRecordClick(RecordClickEvent event) {
				
				if(event.getRecord().getAttributeAsString("name").equalsIgnoreCase("Home")) {
					
					tab.getPane().destroy();
					
			        tab.setTitle("Home");
					tab.setPane(new ACHomeCanvas());
				}
				else if(event.getRecord().getAttributeAsString("name").equalsIgnoreCase("Scheduler")) {
					
					tab.getPane().destroy();
					
					tab.setTitle("Scheduler");
					tab.setPane(new ACSchedulerCanvas());
				}
				else if(event.getRecord().getAttributeAsString("name").equalsIgnoreCase("Log")) {
					
					tab.getPane().destroy();
					
					tab.setTitle("Log");
					tab.setPane(new ACLogCanvas());
				}
				else if(event.getRecord().getAttributeAsString("name").equalsIgnoreCase("Monitor")) {
					
					tab.getPane().destroy();
					
					tab.setTitle("Monitor");
					tab.setPane(new ACMonitorCanvas());
				}
				else {
					// DO NOTHING
				}
				
			}
			
		});
		
        
        return treeGrid;
	}
	

}
