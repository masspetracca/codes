package it.ccg.irifpweb.client.ac;



import it.ccg.irifpweb.client.base.LoadingWidget;
import it.ccg.irifpweb.client.base.MyListGrid;
import it.ccg.irifpweb.client.base.PopupWindow;
import it.ccg.irifpweb.client.base.StandardButton;
import it.ccg.irifpweb.client.rpc.MyRPCCallback;
import it.ccg.irifpweb.client.rpc.MyRPCRequest;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.gwt.core.client.JavaScriptObject;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.DSDataFormat;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.JSOHelper;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.CheckboxItem;
import com.smartgwt.client.widgets.form.fields.DateTimeItem;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.fields.events.ChangedEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangedHandler;
import com.smartgwt.client.widgets.form.validator.RegExpValidator;
import com.smartgwt.client.widgets.grid.CellFormatter;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;

public class ACSchedulerCanvas extends Canvas {
	
	private ListGrid timerListGrid;
	
	//private ProgressBar progressBar;
	
	
	public ACSchedulerCanvas() {
		super();
		
		this.setWidth100();
		this.setHeight100();
		this.setLeft(10);
		
		VLayout vLayout = new VLayout();
		vLayout.setWidth100();
		vLayout.setHeight100();
		
		
		// grid section
        this.timerListGrid = this.createTimerListGrid();
        this.timerListGrid.setWidth100();
        this.timerListGrid.setHeight100();
        
        this.timerListGrid.setShowResizeBar(true);
        this.timerListGrid.setResizeBarTarget("next");
        
        vLayout.addMember(this.timerListGrid);
        // grid section
		
        
        // edit section
        
        final IButton deleteAllSchedulesButton = new StandardButton();
        deleteAllSchedulesButton.setTitle("Delete all schedules");
        deleteAllSchedulesButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				SC.confirm("Delete all schedules?", new BooleanCallback() {
					
					@Override
					public void execute(Boolean value) {
						
						if(value) {
							
							// remove data
							/*ListGridRecord[] records = timerListGrid.getRecords();
							for(Record record : records) {
								timerListGrid.removeData(record);
							}*/
							
							DSRequest dsRequest = new DSRequest();
							//dsRequest.setWillHandleError(true);
							
							timerListGrid.getDataSource().performCustomOperation("removeAll", new Record(), new DSCallback() {
								
								@Override
								public void execute(DSResponse response, Object rawData, DSRequest request) {
									
									timerListGrid.invalidateCache();
								}
								
							}, dsRequest);
						}
						
					}
				});
				
			}
		});
        
        final IButton deleteScheduleButton = new StandardButton();
        deleteScheduleButton.setTitle("Delete schedule");
        deleteScheduleButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(timerListGrid.getSelectedRecord() == null) {
					
					SC.warn("No selected schedule.");
					
					return;
				}
				
				SC.confirm("Delete selected schedule?", new BooleanCallback() {
					
					@Override
					public void execute(Boolean value) {
						
						if(value) {
							
							// remove data
							timerListGrid.removeData(timerListGrid.getSelectedRecord());
						}
						
					}
				});
				
				
			}
		});
        
        final IButton addScheduleButton = new StandardButton();
        addScheduleButton.setTitle("Add schedule");
        addScheduleButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				PopupWindow window = PopupWindow.getInstance("Add new schedule..", 380, 250);
				final VLayout addTimerDynamicFormLayout = createAddTimerFormLayout();
				
		        // add form to window
		        window.addMember(addTimerDynamicFormLayout);
		        
		        // draw on screen
		        window.draw();
			}
		});
        
        final IButton startJobButton = new StandardButton();
        startJobButton.setTitle("Start job");
        startJobButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				PopupWindow window = PopupWindow.getInstance("Start job..", 380, 250);
				final VLayout startBatchDynamicFormLayout = createStartBatchFormLayout();
				
		        // add form to window
		        window.addMember(startBatchDynamicFormLayout);
		        
		        // draw on screen
		        window.draw();
				
			}
		});
        
        
        HLayout hButtonLayout = new HLayout();  
        hButtonLayout.setMembersMargin(15);
        
        hButtonLayout.setLayoutTopMargin(10);
        hButtonLayout.setLayoutBottomMargin(10);
        hButtonLayout.setLayoutLeftMargin(10);
        
        hButtonLayout.setHeight(40);
        
        hButtonLayout.setMembers(deleteAllSchedulesButton, deleteScheduleButton, addScheduleButton, startJobButton);
        
        vLayout.addMember(hButtonLayout);
        
        // edit section
        
        
        this.addChild(vLayout);
		
	}
	
	
	
	private MyListGrid createTimerListGrid() {
		
		DataSource dataSource = DataSource.get("timer");
		// DSDataFormat.JSON mi permette di poter utilizzare correttamente l'attributo valueXPath in timer.ds.xml
		dataSource.setDataFormat(DSDataFormat.JSON);
		
		MyListGrid timerGrid = MyListGrid.getInstance(dataSource);
		
		timerGrid.setCanRemoveRecords(true);
		
		timerGrid.setAutoFetchData(true);
		timerGrid.setFetchOperation("fetch");
		timerGrid.setUpdateOperation("update");
		timerGrid.setRemoveOperation("remove");
		
		
		// set interval field format
		ListGridField intervalLGField = timerGrid.getField("interval");
		intervalLGField.setCellFormatter(new CellFormatter() {
			
			@Override
			public String format(Object value, ListGridRecord record, int rowNum, int colNum) {
				
				String formattedValue = new String();
				
				if(value != null) {
					
					long intervalInMillis = Long.parseLong(value.toString());
					
					long days = intervalInMillis / (24*60*60*1000);
				    long hours = ((intervalInMillis - days * (24*60*60*1000)))/(60*60*1000);
				    long minutes = ((intervalInMillis - days * (24*60*60*1000) - hours * (60*60*1000)))/(60*1000);
				    
				    formattedValue = days + "d-" + hours + "h-" + minutes + "m";
				}
				
				return formattedValue;
			}
			
		});
		
		
		return timerGrid;
	}
	
	
	private VLayout createAddTimerFormLayout() {
		
		final DynamicForm dynamicForm = new DynamicForm();
		

		// name text item
	 	TextItem nameTextItem = new TextItem("name"); 
	 	nameTextItem.setType("text");
	 	nameTextItem.setRequired(true);
	 	nameTextItem.setTitle("Name"); 
	 	
	 	// start date item
        final DateTimeItem startDateTimeItem = new DateTimeItem("startDateTime"); 
        startDateTimeItem.setType("datetime");
        startDateTimeItem.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATETIME);
        startDateTimeItem.setRequired(true);
        startDateTimeItem.setTitle("Start date time");
        
        // interval text item
        final TextItem intervalTextItem = new TextItem("interval");
        intervalTextItem.setRequired(false);
        intervalTextItem.setTitle("Interval");
        intervalTextItem.disable();
        RegExpValidator regExpValidator = new RegExpValidator("^[0-9]*d-[0-9]*h-[0-9]*m$");
        regExpValidator.setErrorMessage("Interval value must match pattern \'Nd-Nh-Nm\'");
        intervalTextItem.setValidators(regExpValidator);
        intervalTextItem.setHint("<nobr>Nd-Nh-Nm</nobr>");
        
        // isSingle Checkbox
        final CheckboxItem isSingleCheckboxItem = new CheckboxItem("isSingle");
        isSingleCheckboxItem.setType("boolean");
        isSingleCheckboxItem.setTitle("One shot timer");
        isSingleCheckboxItem.setDefaultValue(true);
        isSingleCheckboxItem.addChangedHandler(new ChangedHandler() {
			
			@Override
			public void onChanged(ChangedEvent event) {
				if(isSingleCheckboxItem.getValueAsBoolean()) {
					intervalTextItem.disable();
					intervalTextItem.setRequired(false);
				}
				else {
					intervalTextItem.enable();
					intervalTextItem.setRequired(true);
				}
			}
		});
        
        
        // job select item
        final SelectItem jobSelectItem = new SelectItem("jobName");
        jobSelectItem.setType("enum");
        jobSelectItem.setRequired(true);
        jobSelectItem.setTitle("Job");
        jobSelectItem.setWidth(250);
        
        
        // provider select item
        final SelectItem providerSelectItem = new SelectItem("provider");
        providerSelectItem.setType("enum");
        providerSelectItem.setRequired(true);
        providerSelectItem.setTitle("Provider");
        // get provider values
        // OLD ***
        /*LinkedHashMap<String, String> providerSelectItemValueMap = new LinkedHashMap<String, String>();
        providerSelectItemValueMap.put("Bloomberg", "Bloomberg");
        providerSelectItemValueMap.put("Reuters", "Reuters");
        providerSelectItemValueMap.put("temp", "temp");
        providerSelectItem.setValueMap(providerSelectItemValueMap);*/
        // **************************************************************
        
		
		Map<String,String> params = new HashMap<String, String>();
		params.put("_operationId", "getProviderList");
		
		MyRPCRequest rpcRequest = new MyRPCRequest("servlet/JobInfo", params);
		
		RPCManager.sendRequest(rpcRequest, new MyRPCCallback() {
			
			@Override
			public void onSuccess(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				JavaScriptObject providerListJSO = response.getAttributeAsJavaScriptObject("data");
				
				@SuppressWarnings("unchecked")
				List<Map<String, String>> providerList = JSOHelper.convertToList(providerListJSO);
				
				LinkedHashMap<String, String> valueMap = new LinkedHashMap<String, String>();
				
				for(Map<String, String> provider : providerList) {
					
					valueMap.put(provider.get("name"), provider.get("description"));
				}	
				
				providerSelectItem.setValueMap(valueMap);
				
			}
			
		});
        
        
        providerSelectItem.addChangedHandler(new ChangedHandler() {
			
			@Override
			public void onChanged(ChangedEvent event) {
				
				// get jobs
				
				Map<String,String> params = new HashMap<String, String>();
				params.put("_operationId", "getJobListByProviderName");
				params.put("provider", providerSelectItem.getValueAsString());
				
				MyRPCRequest rpcRequest = new MyRPCRequest("servlet/JobInfo", params);
				
				RPCManager.sendRequest(rpcRequest, new MyRPCCallback() {
					
					@Override
					public void onSuccess(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						JavaScriptObject jobListJSO = response.getAttributeAsJavaScriptObject("data");
						
						@SuppressWarnings("unchecked")
						List<Map<String, String>> jobList = JSOHelper.convertToList(jobListJSO);
						
						LinkedHashMap<String, String> valueMap = new LinkedHashMap<String, String>();
						
						for(Map<String, String> job : jobList) {
							valueMap.put(job.get("name"), job.get("description"));
						}
						
						jobSelectItem.setValueMap(valueMap);
						
					}
					
				});
				
			}
		});
        
        
        
        // add items to form
		dynamicForm.setItems(nameTextItem, startDateTimeItem, isSingleCheckboxItem, intervalTextItem, providerSelectItem, jobSelectItem);
		
		
		// buttons
        final IButton addButton = new StandardButton();
        addButton.setTitle("Add");
        //addButton.setAlign(Alignment.CENTER);
        addButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(!dynamicForm.validate()) {
        			return;
        		}
				
				//
				Date startDateTime =  startDateTimeItem.getValueAsDate();
				long startDateTimeMillis = startDateTime.getTime();
				
				long currentTimeMillis = System.currentTimeMillis();
				
				if(startDateTimeMillis < currentTimeMillis) {
					
					SC.say("Start date time must be greater than current date time.");
					
					return;
				}
				
				
				// get form values as Record
				Record record = dynamicForm.getValuesAsRecord();
				
				// check isSingleCheckboxItem value
				if(!isSingleCheckboxItem.getValueAsBoolean()) {
					
					String intervalString = intervalTextItem.getValueAsString();
					String[] components = intervalString.split("-");
					long daysInMillis = (long)(Long.parseLong((components[0].substring(0, components[0].length() - 1))))*24*60*60*1000;
					long hoursInMillis = (long)(Long.parseLong((components[1].substring(0, components[1].length() - 1))))*60*60*1000;
					long minutesInMillis = (long)(Long.parseLong((components[2].substring(0, components[2].length() - 1))))*60*1000;
					
					long totalMillis = daysInMillis + hoursInMillis + minutesInMillis;
					
					
					JavaScriptObject javaScriptObject = record.getJsObj();
					JSOHelper.setAttribute(javaScriptObject, "interval", totalMillis);
					
					record.setJsObj(javaScriptObject);
				}
				
				
				DSRequest dsRequest = new DSRequest();
				dsRequest.setWillHandleError(true);
				
				timerListGrid.addData(record, new DSCallback() {
					
					@SuppressWarnings("rawtypes")
					@Override
					public void execute(DSResponse response, Object rawData, DSRequest request) {
						
						if(response.getStatus() != 0) {
							String errorMessage = new String();
							
							Map errorMap = response.getErrors();
							Set keySet = errorMap.keySet();
							
							for(Object key : keySet) {
								errorMessage += ((Map)errorMap.get(key)).get("errorMessage") + "<br>";
							}
							
							SC.say(errorMessage);
						}
						
					}
				}, dsRequest);
				
				
				
				dynamicForm.reset();
				
			}
		});
        
        final IButton cancelButton = new StandardButton();
        cancelButton.setTitle("Cancel");
        //cancelButton.setAlign(Alignment.CENTER);
        cancelButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				dynamicForm.reset();
				
			}
		});
        
        
        
        HLayout hButtonLayout = new HLayout();  
        hButtonLayout.setMembersMargin(15);
        //hLayout.setAutoHeight();
        hButtonLayout.setLayoutTopMargin(10);
        hButtonLayout.setLayoutLeftMargin(10);
        hButtonLayout.addMember(cancelButton);
        hButtonLayout.addMember(addButton);
        // buttons
        
        
        VLayout vLayout = new VLayout();
        vLayout.addMember(dynamicForm);
        vLayout.addMember(hButtonLayout);
        vLayout.setLayoutBottomMargin(10);
		
		
		
		return vLayout;
	}
	
	
	private VLayout createStartBatchFormLayout() {
		
		final VLayout vLayout = new VLayout();
		
		final DynamicForm dynamicForm = new DynamicForm();
		
		// job select item
        final SelectItem jobSelectItem = new SelectItem("jobName");
        jobSelectItem.setType("enum");
        jobSelectItem.setRequired(true);
        jobSelectItem.setTitle("Job");
        jobSelectItem.setWidth(250);
        
        
        // provider select item
        final SelectItem providerSelectItem = new SelectItem("provider");
        providerSelectItem.setType("enum");
        providerSelectItem.setRequired(true);
        providerSelectItem.setTitle("Provider");
        
        /*LinkedHashMap<String, String> providerSelectItemValueMap = new LinkedHashMap<String, String>();
        providerSelectItemValueMap.put("Bloomberg", "Bloomberg");
        providerSelectItemValueMap.put("Reuters", "Reuters");
        providerSelectItem.setValueMap(providerSelectItemValueMap);*/
        
        
		Map<String,String> params = new HashMap<String, String>();
		params.put("_operationId", "getProviderList");
		
		MyRPCRequest rpcRequest = new MyRPCRequest("servlet/JobInfo", params);
		
		RPCManager.sendRequest(rpcRequest, new MyRPCCallback() {
			
			@Override
			public void onSuccess(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				JavaScriptObject providerListJSO = response.getAttributeAsJavaScriptObject("data");
				
				@SuppressWarnings("unchecked")
				List<Map<String, String>> providerList = JSOHelper.convertToList(providerListJSO);
				
				LinkedHashMap<String, String> valueMap = new LinkedHashMap<String, String>();
				
				for(Map<String, String> provider : providerList) {
					
					valueMap.put(provider.get("name"), provider.get("description"));
				}	
				
				providerSelectItem.setValueMap(valueMap);
				
			}
			
		});
        
        providerSelectItem.addChangedHandler(new ChangedHandler() {
			
			@Override
			public void onChanged(ChangedEvent event) {
				
				// get jobs
				
				Map<String,String> params = new HashMap<String, String>();
				params.put("_operationId", "getJobListByProviderName");
				params.put("provider", providerSelectItem.getValueAsString());
				
				MyRPCRequest rpcRequest = new MyRPCRequest("servlet/JobInfo", params);
				
				RPCManager.sendRequest(rpcRequest, new MyRPCCallback() {
					
					@Override
					public void onSuccess(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						JavaScriptObject jobListJSO = response.getAttributeAsJavaScriptObject("data");
						
						@SuppressWarnings("unchecked")
						List<Map<String, String>> jobList = JSOHelper.convertToList(jobListJSO);
						
						LinkedHashMap<String, String> valueMap = new LinkedHashMap<String, String>();
						
						for(Map<String, String> job : jobList) {
							valueMap.put(job.get("name"), job.get("description"));
						}
						
						jobSelectItem.setValueMap(valueMap);
						
					}
					
				});
				
			}
		});
        
        
        
        // add items to form
		dynamicForm.setItems(providerSelectItem, jobSelectItem);
		
		
        
		// button
		HLayout buttonsLayout = new HLayout();
		
		final IButton startButton = new StandardButton();
		startButton.setTitle("Start job");
		startButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(!dynamicForm.validate()) {
        			return;
        		}
				
				
				Map<String,String> params = new HashMap<String, String>();
				params.put("jobName", jobSelectItem.getValueAsString());
				
				MyRPCRequest rpcRequest = new MyRPCRequest("servlet/JobExecute", params);
				
				// **
				startButton.disable();
				LoadingWidget.getInstance("_loadingWidget0").draw();
				
				RPCManager.sendRequest(rpcRequest, new MyRPCCallback() {
					
					@Override
					public void onCallback(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						// **
			    		LoadingWidget.getById("_loadingWidget0").destroy();
			    		startButton.enable();
			    		dynamicForm.reset();
			    		
					}
					
				});
				
			}
			
		});
		
		buttonsLayout.addMember(startButton);
		
		buttonsLayout.setLayoutTopMargin(10);
		buttonsLayout.setLayoutLeftMargin(10);
		
		// button
		
		
		
		vLayout.addMember(dynamicForm);
		vLayout.addMember(buttonsLayout);
		
		vLayout.setLayoutBottomMargin(10);
		
		
		return vLayout;
	}

}
