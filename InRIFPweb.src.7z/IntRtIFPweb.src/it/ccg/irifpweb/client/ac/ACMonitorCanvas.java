package it.ccg.irifpweb.client.ac;



import it.ccg.irifpweb.client.base.StandardButton;
import it.ccg.irifpweb.client.rpc.Json2POJO;
import it.ccg.irifpweb.client.rpc.MyRPCCallback;
import it.ccg.irifpweb.client.rpc.MyRPCRequest;
import it.ccg.irifpweb.client.rpc.MyRestDataSource;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.DataSourceField;
import com.smartgwt.client.data.RestDataSource;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.FieldType;
import com.smartgwt.client.types.OperatorId;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;


public class ACMonitorCanvas extends Canvas {
	
	VLayout mainVLayout;
	private ListGrid listGrid;
	
	
	public ACMonitorCanvas() {
		super();
		
		this.setWidth100();
		this.setHeight100();
		this.setLeft(10);
		
		// form section
		final HLayout formLayout = this.createFormLayout();
		
		// grid section
		this.listGrid = this.createListGrid("ifp_monitor.log");
		this.listGrid.setWidth100();
		this.listGrid.setHeight100();
		
        
        this.mainVLayout = new VLayout();
        this.mainVLayout.setWidth100();
        this.mainVLayout.setHeight100();
        this.mainVLayout.setMembers(formLayout, this.listGrid);
        
        
        this.addChild(this.mainVLayout);
        
	}
	
	
	private HLayout createFormLayout() {
		
		final DynamicForm dynamicForm = new DynamicForm();
		
		// name text item
		final SelectItem logSelectItem = new SelectItem("log");
		logSelectItem.setType("enum");
		logSelectItem.setRequired(true);
		logSelectItem.setTitle("<nobr>Monitor log</nobr>");
		logSelectItem.setWidth(250);
		logSelectItem.setDefaultValue("ifp_monitor.log");
		
		Map<String,String> params = new HashMap<String,String>();
		params.put("_operationType", "fetch");
		params.put("_operationId", "fetchLogsByType");
		params.put("logType", "ifp_monitor");
		
		MyRPCRequest rpcRequest = new MyRPCRequest("servlet/LogEndpoint", params);

		RPCManager.sendRequest(rpcRequest, new MyRPCCallback() {
			
			@Override
			public void onSuccess(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				LinkedHashMap<String, String> valueMap = Json2POJO.getComboLinkedHashMap(response);
				
				logSelectItem.setValueMap(valueMap);
				
			}
			
		});
		
		dynamicForm.setItems(logSelectItem);
		
		
		// buttons
        final IButton showButton = new StandardButton();
        showButton.setTitle("Show");
        showButton.setAlign(Alignment.CENTER);
        showButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(!dynamicForm.validate()) {
        			return;
        		}
				
				mainVLayout.removeMember(listGrid);
				listGrid = createListGrid(logSelectItem.getValueAsString());
				mainVLayout.addMember(listGrid);
			}
		});
        
        HLayout hButtonLayout = new HLayout();
        hButtonLayout.setLayoutLeftMargin(30);
        hButtonLayout.setLayoutTopMargin(3);
        hButtonLayout.addMember(showButton);
                
        
        HLayout hLayout = new HLayout();
        hLayout.addMember(dynamicForm);
        hLayout.addMember(hButtonLayout);
        hLayout.setLayoutBottomMargin(10);
        
        hLayout.setWidth100();
        hLayout.setHeight(40);
		
		
		return hLayout;
		
	}
	
	
	
	private ListGrid createListGrid(String logFileName) {
		
		// datasource
		RestDataSource dataSource = new MyRestDataSource("servlet/LogEndpoint");
		
		DataSourceField dateTimeField = new DataSourceField("dateTime", FieldType.TEXT);  
		dateTimeField.setAttribute("width", "150");
		
		DataSourceField typeField = new DataSourceField("type", FieldType.TEXT);  
		typeField.setAttribute("width", "180");
		typeField.setAttribute("type", "enum");
		LinkedHashMap<String, String> valueMap = new LinkedHashMap<String, String>();
		valueMap.put("INFO", "INFO");
		valueMap.put("DEBUG", "DEBUG");
		valueMap.put("WARN", "WARN");
		valueMap.put("ERROR", "ERROR");
		typeField.setValueMap(valueMap);
		typeField.setMultiple(true);
		
		DataSourceField classMethodField = new DataSourceField("classMethod", FieldType.TEXT);  
		classMethodField.setAttribute("width", "200");
		
		DataSourceField userField = new DataSourceField("user", FieldType.TEXT);  
		userField.setAttribute("width", "200");
		
		DataSourceField messageField = new DataSourceField("message", FieldType.TEXT);
		
		dataSource.setFields(dateTimeField, typeField, classMethodField, userField, messageField);
		
		// grid
		ListGrid logGrid = new ListGrid() {
			@Override
			protected String getCellCSSText(ListGridRecord record, int rowNum, int colNum) {
				String type = record.getAttributeAsString("type");
            	if(type != null){
					
            		if(type.equalsIgnoreCase("ERROR")) {
            			
						return "color:#FF0000";
					} 
            		else if(type.equalsIgnoreCase("WARN")) {
						
						return "color:#B17A0F";
					}
            		else if(type.equalsIgnoreCase("DEBUG")) {
						
						return "color:#2569d0";
					}
            		else if(type.equalsIgnoreCase("INFO")) {
						
						return "color:#000000";
					}
            		else {
                		
                		return super.getCellCSSText(record, rowNum, colNum);
                	}
				
            	}
            	else {
            		
            		return super.getCellCSSText(record, rowNum, colNum);
            	}
			}
		};
		
		// set datasource to grid
		logGrid.setDataSource(dataSource);
		
		// operation settings
		AdvancedCriteria advancedCriteria = new AdvancedCriteria();
		advancedCriteria.addCriteria("logFileName", OperatorId.EQUALS, logFileName);
		advancedCriteria.addCriteria("type", OperatorId.IN_SET, new String[]{"INFO", "WARN", "ERROR"});
		
		logGrid.setInitialCriteria(advancedCriteria);
		logGrid.setAutoFetchData(true);
		logGrid.setFetchOperation("fetchLogByFileName");
		
		logGrid.setFilterEditorCriteria(advancedCriteria);
		
		logGrid.setShowFilterEditor(true);
		
		logGrid.setCanSort(false);
		logGrid.setCanMultiSort(false);
		logGrid.setCanGroupBy(false);
		
		
		return logGrid;
	}
		
	

}


