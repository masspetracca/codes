package it.ccg.irifpweb.server.servlet;

import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.server.system.SystemProperties;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;


/**
 * Servlet implementation class FileUpload2
 */
public class FileUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	private static String UPLOAD_DIR_ABSOLUTE_PATH;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FileUpload() throws Exception {
    	super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		throw new ServletException("Servlet does not allow GET request.");
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.doWork(request, response);
	}
	
	
	@SuppressWarnings("unchecked")
	private void doWork(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			UPLOAD_DIR_ABSOLUTE_PATH = SystemProperties.getProperty("user.install.root") + 
									   SystemProperties.getProperty("ifp_upload_dir_relative_path");
			
			
			// if it is not a multipart request i cannot process it
			if(!ServletFileUpload.isMultipartContent(request)) {
				
				throw new Exception("Request content not supported.");
			}
			
			// process multipart request
			
            // Create a factory for disk-based file items
            FileItemFactory factory = new DiskFileItemFactory();
            // Create a new file upload handler
            ServletFileUpload upload = new ServletFileUpload(factory);
            // Parse the request
			List<FileItem> itemsList = upload.parseRequest(request);
			
            for(FileItem item : itemsList) {
            	
                // process only file upload, discard other form item types
                if(item.isFormField()) {
                	
                	continue;
                }
                
                String fileName = item.getName();
                // get only the file name, not whole path
                fileName = FilenameUtils.getName(fileName);

                File file = new File(UPLOAD_DIR_ABSOLUTE_PATH, fileName);
                
                // se un file con il nome specificato esiste, allora cancellalo
                if(file.exists()) {
                	
                	file.delete();
                }
                
                // create new file
            	file.createNewFile();
            	
            	// scrivi su server il file spedito da client
            	item.write(file);
                
            	
                logger.debug(new StandardLogMessage("File \'" + fileName + "\' successfully uploaded."));
                
                
                // set response
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("status", 0);
                jsonObject.put("message", "File \'" + fileName + "\' successfully uploaded.");
               
                String jsonString = jsonObject.toJSONString();
				
                // set response attributes
    			response.setStatus(HttpServletResponse.SC_OK);
    			// return data to client
    			response.getWriter().print(jsonString);
                
	        }
            
            // i could place this code here if i supported multiple file upload
            /*// set response
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("status", 0);
            jsonObject.put("message", "File \'" + fileName + "\' successfully uploaded.");
            responseJsonString = jsonObject.toJSONString();*/
	        
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
		
	}
	
	

}
