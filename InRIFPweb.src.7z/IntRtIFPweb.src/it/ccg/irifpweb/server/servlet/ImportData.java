package it.ccg.irifpweb.server.servlet;

import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.isomorphic.rpc.RPCManager;
import com.isomorphic.rpc.RPCResponse;


/**
 * Servlet implementation class ImportData
 */
public class ImportData extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	/*@EJB
	private GenericProcedureBeanLocal genericProcedureBeanLocal;*/
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ImportData() throws Exception {
        super();
    }
    
    
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		throw new ServletException("Servlet does not allow GET request.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.doWork(request, response);
	}
    
    
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doWork(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		try {
			
			String fileName = request.getParameter("fileName");
			
			logger.debug(new StandardLogMessage("Importing historical data from \'" + fileName + "\'.."));
			
			this.genericProcedureBeanLocal.addHistoricalDataFromUploadedFile(fileName);
			
			logger.debug(new StandardLogMessage("Data from \'" + fileName + "\' successfully imported."));
            
			
			//Creo l'oggetto RPC per la gestione SmartGWT dei parametri della servlet
			RPCManager rpcManager = new RPCManager(request, response);
			// response
			RPCResponse rpcResponse = new RPCResponse();
			// creo una map per la risposta
			Map<String, Object> responseData = new HashMap<String, Object>();
			responseData.put("message", "Data from \'" + fileName + "\' successfully imported. Read logs for details.");
			// popolo i dati di risposta
			rpcResponse.setData(responseData);
			
			// HTTP_200
			response.setStatus(HttpServletResponse.SC_OK);
			// restituzione del risultato
			rpcManager.send(rpcResponse);
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		*/
		
	}
	
	

}
