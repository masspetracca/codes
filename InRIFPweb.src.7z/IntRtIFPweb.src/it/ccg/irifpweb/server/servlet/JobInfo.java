package it.ccg.irifpweb.server.servlet;

import it.ccg.irifpejb.server.bean.JobDTO;
import it.ccg.irifpejb.server.bean.JobManagerBeanLocal;
import it.ccg.irifpejb.server.bean.ProviderDTO;
import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import java.io.IOException;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.isomorphic.rpc.RPCManager;
import com.isomorphic.rpc.RPCResponse;

/**
 * Servlet implementation class JobInfo
 */
public class JobInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	
	@EJB
	private JobManagerBeanLocal jobManagerBeanLocal;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JobInfo() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		throw new ServletException("Servlet does not allow GET request.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String _operationId = request.getParameter("_operationId");
		
		if(_operationId == null) {
			
			throw new ServletException("Unable to process request. \'_operationId\' parameter not found.");
		}
		
		
		if(_operationId.equalsIgnoreCase("getProviderList")) {
			
			this.getProviderList(request, response);
		}
		else if(_operationId.equalsIgnoreCase("getJobListByProviderName")) {
			
			this.getJobListByProviderName(request, response);
		}
		else{
			
			throw new ServletException("Unable to process request. \'_operationId\' of type \'" + _operationId + "\' not valid.");
		}
		
	}
	
	
	private void getProviderList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			List<ProviderDTO> jobList = this.jobManagerBeanLocal.getProviderList();
			
			
			// Creo l'oggetto RPC per la gestione SmartGWT dei parametri della servlet
			RPCManager rpcManager = new RPCManager(request, response);
			// response
			RPCResponse rpcResponse = new RPCResponse();
			// popolo i dati di risposta
			rpcResponse.setData(jobList);
			
			//
			response.setStatus(HttpServletResponse.SC_OK);
			// restituzione del risultato
			rpcManager.send(rpcResponse);
			
			
			logger.debug(new StandardLogMessage("Provider data successfully fetched."));
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	private void getJobListByProviderName(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			String provider = request.getParameter("provider");
			
			List<JobDTO> jobList = this.jobManagerBeanLocal.getJobListByProviderName(provider);
			
			
			// Creo l'oggetto RPC per la gestione SmartGWT dei parametri della servlet
			RPCManager rpcManager = new RPCManager(request, response);
			// response
			RPCResponse rpcResponse = new RPCResponse();
			// creo una response e la popolo l'oggetto di risposta
			rpcResponse.setData(jobList);
			
			// HTTP_200
			response.setStatus(HttpServletResponse.SC_OK);
			// restituzione del risultato
			rpcManager.send(rpcResponse);
			
			
			logger.debug(new StandardLogMessage(provider + " job data successfully fetched."));
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}

}
