package it.ccg.irifpweb.server.filter;

import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.server.security.SessionManagerLocal;
import it.ccg.irifpweb.server.filter.util.UserLogUtil;
import it.ccg.irifpweb.server.security.SecurityWeb;

import java.io.IOException;
import java.util.Enumeration;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

/**
 * Servlet Filter implementation class SecurityFilter
 */
public class SecurityFilter implements Filter {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = LoggerFactory.getLogger(LoggerFactory.USER_LOGGER);
	
	private SessionManagerLocal sessionManagerLocal;
	
	private static boolean isAfterlogin = false;
	

    /**
     * Default constructor. 
     */
    public SecurityFilter() {
    	
    	try {  
            Context ctx = new InitialContext(); 
            
            this.sessionManagerLocal = (SessionManagerLocal)ctx.lookup("ejblocal:it.ccg.irifpejb.server.security.SessionManagerLocal");    
        } 
        catch(NamingException e) {
        	
        	e.printStackTrace();
        }
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		HttpServletRequest httpServletRequest = (HttpServletRequest)request;
		
		// Check if a principal exists.
		// If a client makes requests without authenticating, forward it to login.jsp
		if(httpServletRequest.getUserPrincipal() == null) {
			
			logger.warn(new StandardLogMessage("Resource request without authentication from " + request.getRemoteAddr()));
			
			RequestDispatcher dispatcher = httpServletRequest.getRequestDispatcher("login.jsp");
			dispatcher.forward(request, response);
			
			return;
		}
		
		
		// *** Log user request ***
		String userReqLogMessage = UserLogUtil.getUserLogFormatLine(httpServletRequest, (HttpServletResponse)response);
		
		// user log
		userLogger.info(new StandardLogMessage(userReqLogMessage));
		// default log
		logger.info(new StandardLogMessage(userReqLogMessage));
		
		
		// Double session status check: 
		// 1) if session id is changed, it means a concurrent login was attempted;
		// 2) if session is null, it means active session is expired
		try {
			String caller = httpServletRequest.getUserPrincipal().getName();
			
			String callerSessionId = new String();
			
			// only the first time in SecurityFilter a new session is created
			if(isAfterlogin) {
				
				callerSessionId = httpServletRequest.getSession().getId();
			}
			// after the first time i want to check the session created above
			else {
				
				HttpSession httpSession = httpServletRequest.getSession(false);
				
				// 2) session expired
				if(httpSession == null) {
					
					logger.warn(new StandardLogMessage("Session expired."));
					
					SecurityWeb.invalidateSession(httpServletRequest, (HttpServletResponse)response);
					
					logger.info(new StandardLogMessage("Session invalidated."));
					
					// i do not allow the request processing
					return;
				}
				
				callerSessionId = httpSession.getId();
			}
			
			String loggedCaller = this.sessionManagerLocal.getCurrentUser();
			String loggedCallerSessionId = this.sessionManagerLocal.getCurrentUserSessionId();
			
			logger.debug(new StandardLogMessage("Session Id check - Caller: " + caller + ", sessionId: " + callerSessionId + "; Logged caller: " + loggedCaller + ", logged sessionId: " + loggedCallerSessionId));
			
			// 1) concurrent login
			if(!callerSessionId.equalsIgnoreCase(loggedCallerSessionId)) {
				
				logger.error(new StandardLogMessage("Session Id changed."));
				
				SecurityWeb.invalidateSession(httpServletRequest, (HttpServletResponse)response);
				
				logger.info(new StandardLogMessage("Session invalidated."));
				
				// i do not allow the request processing
				return;
			}
			
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// i do not allow the request processing
			return;
		}
		
		
		// This check is to mark a request which comes after a login. The variable isAfterLofin is set into LoginFilter.
		if(isAfterlogin) {
			
			// clear the variable at the first execution after re-login to avoid an other execution of the code in this if block.
			isAfterlogin = false;
			
			// This check is to control if the current request is a index.html request. 
			// If it is, i do nothing. 
			// If it isn't, this means it was a generic request after a re-login (caused by a session expiration), so i send a redirect to index.html.
			// This control is necessary. If i send a redirect to index.html after a index.html request, then i see a blank page on the browser (this happens at first login).
			
			String uri = httpServletRequest.getRequestURI();
			
			String contextPath = httpServletRequest.getContextPath();
			
			if(!uri.endsWith(contextPath + "/")) {
				
				HttpServletResponse httpServletResponse = (HttpServletResponse)response;
				httpServletResponse.sendRedirect(contextPath + "/");
				
				
				return;
			}
			
		}
		
		
		// other security checks
		
		@SuppressWarnings("unchecked")
		Enumeration<String> params = (Enumeration<String>)httpServletRequest.getParameterNames();
		
		_ext: while(params.hasMoreElements()) {
			
			String param = params.nextElement();
			
			// Exclude SmartGWT framework parameters from check
			String[] toSkipArray = {"_transaction"};
			for(String toSkip : toSkipArray) {
				if(param.equalsIgnoreCase(toSkip)) {
					
					continue _ext;
				}
			}
			
			
			String[] paramValues = httpServletRequest.getParameterValues(param);
			
			try {
				
				for(String paramValue : paramValues) {
					
					logger.debug(new StandardLogMessage("Script check on [param: " + param + ", value: " + paramValue + "]"));
					
					if(SecurityWeb.isScript(paramValue)) {
						
						logger.error(new StandardLogMessage("Script check failed on [param: " + param + ", value: " + paramValue + "]"));
						
						SecurityWeb.invalidateSession(httpServletRequest, (HttpServletResponse)response);
						
						logger.info(new StandardLogMessage("Session invalidated."));
						
						// i do not allow the request processing
						throw new Exception();
					}
				}
				
			}
			catch(Exception e) {
				
				ExceptionUtil.logCompleteStackTrace(logger, e);
				
				// i do not allow the request processing
				throw new ServletException();
			}
		}
		
		
		
		
		
		// pass the request along the filter chain
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// Auto-generated method stub
	}
	
	
	
	public static void setAfterlogin(boolean isAfterlogin) {
		SecurityFilter.isAfterlogin = isAfterlogin;
	}
	
	

}
