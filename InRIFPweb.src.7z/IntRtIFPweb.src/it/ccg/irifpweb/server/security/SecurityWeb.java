package it.ccg.irifpweb.server.security;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SecurityWeb {
	
	/* The call to ibm_security_logout:
    - delete SSO (single sign-on) cookie (LTPA - Lightweight Third Party Authentication)
    - invalidates HTTP session
    - remove related user from authentication cache
	*/
	public static void invalidateSession(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
		
		// N.B.: � molto importante che per il logout si utilizzi la servlet ibm_security_logout di ibm
		//       e che il redirect sia indicato con "&logoutExitPage=". Solo in questo modo la sessione 
		//		 viene distrutta
		
		String logoutPage= "/login.jsp";
	
		// Utilizzo ibm_security_logout e faccio il forward verso la pagina di login
		String  logoutURL= "/ibm_security_logout?logout=Logout&logoutExitPage=" + logoutPage;
		
		RequestDispatcher dispatcher = httpServletRequest.getRequestDispatcher(logoutURL);
	    
		dispatcher.forward(httpServletRequest, httpServletResponse);
	}
	
	
	public static boolean isScript(String inputString) throws Exception{
		
		boolean isScript = false;
		
		Pattern scriptPattern = Pattern.compile("<.*[Ss].*[Cc].*[Rr].*[Ii].*[Pp].*[Tt].*>", Pattern.DOTALL);
		Pattern imgPattern = Pattern.compile("<.*[Ii].*[Mm].*[Gg].*>", Pattern.DOTALL);
		Pattern htmlPattern = Pattern.compile("<.*[Hh].*[Tt].*[Mm].*[Ll].*>", Pattern.DOTALL);
		Pattern objectPattern = Pattern.compile("<.*[Oo].*[Bb].*[Jj].*[Ee].*[Cc].*[Tt].*>", Pattern.DOTALL);
		Pattern videoPattern = Pattern.compile("<.*[Vv].*[Ii].*[Dd].*[Ee].*[Oo].*>", Pattern.DOTALL);
		Pattern alertPattern = Pattern.compile("<.*[Aa].*[Ll].*[Ee].*[Rr].*[Tt].*>", Pattern.DOTALL);
		Pattern basePattern = Pattern.compile("<.*[Bb].*[Aa].*[Ss].*[Ee].*[6].*[4].*>", Pattern.DOTALL);
		
		Pattern[] patterns = {scriptPattern, imgPattern, htmlPattern, objectPattern, videoPattern, alertPattern, basePattern};

		
		for(Pattern pattern : patterns) {
		
			Matcher matcher = pattern.matcher(inputString);
			
			if(matcher.find()) {
				
				isScript = true;
				
				break;
			}
		}
		

		return isScript;
	}

}
