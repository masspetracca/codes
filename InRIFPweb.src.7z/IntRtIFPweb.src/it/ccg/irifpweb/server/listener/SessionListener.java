package it.ccg.irifpweb.server.listener;

import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.server.security.SessionManagerLocal;

import javax.ejb.EJB;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.log4j.Logger;

/**
 * Application Lifecycle Listener implementation class SessionListener
 *
 */
public class SessionListener implements HttpSessionListener {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	
	@EJB
	private SessionManagerLocal sessionManagerLocal;
	
	
    /**
     * Default constructor. 
     */
    public SessionListener() {
        // TODO Auto-generated constructor stub
    }
    
    
    /**
     * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent se) {
    	
    	try {
    		String currentUser = this.sessionManagerLocal.getCurrentUser();
    		
    		if(currentUser != null && !currentUser.equalsIgnoreCase("WAS")) {
    			
    			logger.debug(new StandardLogMessage("System created new session for logged user: " + currentUser));
            	
    			// user correctly logged, but did it grant PortalAdmin roles?
    			logger.debug(new StandardLogMessage("Roles check for user: " + currentUser));
    			// if yes
    			if(this.sessionManagerLocal.getCurrentUserRoles().size() > 0) {
    				
    				logger.debug(new StandardLogMessage("User \'" + currentUser + "\' granted PortalAdmin roles: " + this.sessionManagerLocal.getCurrentUserRoles()));
    				
    				this.sessionManagerLocal.addLoggedUser(currentUser, se.getSession().getId());
                	
    				logger.debug(new StandardLogMessage("User added to logged user list. [user: " + currentUser + ", sessionId: " + se.getSession().getId() + ", roles: " + this.sessionManagerLocal.getCurrentUserRoles() + "]"));
    			}
    			// otherwise
    			else {
    				
    				logger.error(new StandardLogMessage("User \'" + currentUser + "\' didn't grant any of PortalAdmin required roles."));
                }
    			
    			
            }
        	
        }
    	catch(Exception e) {
    		
    		ExceptionUtil.logCompleteStackTrace(logger, e);
		}
    	
    }
    

	/**
     * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent se) {
    	
    	try {
    		String currentUser = this.sessionManagerLocal.getCurrentUser();
        	
    		if(currentUser != null && this.sessionManagerLocal.listLoggedUsers().contains(currentUser)) {
    			
    			logger.debug(new StandardLogMessage("Logged out user: " + currentUser));
            	
            	this.sessionManagerLocal.removeLoggedUser(currentUser);
            	
            	logger.debug(new StandardLogMessage("User removed from logged user list: " + currentUser));
            }
        }
    	catch (Exception e) {
    		
    		ExceptionUtil.logCompleteStackTrace(logger, e);
		}
    	
    }

	
	
}
