package it.ccg.test.collaudo.server.bus;

import it.ccg.fpm.freader.batch.PropertyFiles;
import it.ccg.test.collaudo.server.eao.TestCollaudoQAEAO;
import it.ccg.test.collaudo.server.eao.TestCollaudoQAEAOLocal;
import it.ccg.test.collaudo.server.exceptions.DataNotValidException;

import it.ccg.fpm.freader.batch.PropertyFiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.log4j.Logger;

// Referenced classes of package it.ccg.test.collaudo.server.bus:
//            GeneralBatchLocal
/**
 * Session Bean implementation class TestCollaudo
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class GeneralBatch implements GeneralBatchLocal {

@EJB
TestCollaudoQAEAOLocal testcollaudoEAO;

private static String stl;
    private static String tok;
//    TestCollaudoQA testcollaudoqa;
    Logger userLog;
	private int indx;
	private String keyIdData = " ";
	private String keyDateData = " ";
	private String keyProgData= " ";

	private String openUrlData = " ";
	private String nodeTypeData = " ";
	private String nodeNameData= " ";
	private String nodeValueData= " ";
	private String childNameData = " ";
	private String actionData= " ";
	private String noteData = " ";

	private String oldIdData;


    public GeneralBatch(int returnCode) throws IOException, DataNotValidException {
        userLog = Logger.getLogger("it.ccg.test.collaudo.server.log.UserLog");
        userLog.debug("##Read Data Test Collaudo QA   ... ");
        readData();
        
        //attr. settings
        TestCollaudoQAEAO tc = new TestCollaudoQAEAO();
        tc.keyId = keyIdData;
        tc.keyDate = keyDateData;
        tc.keyProg = keyProgData;
        tc.openUrl = openUrlData;
        tc.nodeName = nodeNameData;
        tc.nodeType = nodeTypeData;
        tc.nodeValue = nodeValueData;
        tc.childName = childNameData;
        tc.action = actionData;
        tc.note = noteData;

        userLog.debug("##End ...Read Data Test Collaudo QA");
    }

 

	public void readData()
        throws IOException, DataNotValidException { 
    	GetProperties();
        BufferedReader in = new BufferedReader
        //(new FileReader("datiPM/Selenium_testOUT.txt"));
		(new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTVALUES_FILE_OUTPUT()));

    	System.out.println("readData: "+stl);

         while ((stl = in.readLine()) != null) {
 	       	tok="";
    	    indx=0;
	        StringTokenizer f= new StringTokenizer(stl, "|");
	        while(f.hasMoreTokens()) {
	        	    indx++;
	        	    if (indx == 1) {
	        	    	tok = (String)f.nextElement();
	        	    	keyIdData = tok;
	        	    }
	        	    if (indx == 2) {
	        	    	tok = (String)f.nextElement();
	        	    	keyDateData = tok;	        	    	
	        	    }
	        	    if (indx == 3) {
	        	    	tok = (String)f.nextElement();
	        	    	keyProgData = tok;
	        	    }
	        	    if (indx == 4) {
	        	    	tok = (String)f.nextElement();
	        	    	openUrlData = tok;
	        	    }
	        	    if (indx == 5) {
	        	    	tok = (String)f.nextElement();
	        	    	nodeNameData = tok;
	        	    }
	        	    if (indx == 6) {
	        	    	tok = (String)f.nextElement();
	        	    	nodeTypeData = tok;
	        	    }
	        	    if (indx == 7) {
	        	    	tok = (String)f.nextElement();
	        	    	childNameData = tok;
	        	    }
	        	    if (indx == 8) {
	        	    	tok = (String)f.nextElement();
	        	    	childNameData = tok;
	        	    }
	        	    if (indx == 9) {
	        	    	tok = (String)f.nextElement();
	        	    	actionData = tok;
	        	    }
	        	    if (indx == 10) {
	        	    	tok = (String)f.nextElement();
	        	    	noteData = tok;
	        	    }
	        	    if (indx > 10) {
	        	    	 System.out.println("Fine anomala  ... "+(String)f.nextElement());
	        	    	 System.exit(10);
	        	    }
			        System.out.println("token: "+tok);
		        }
	        	//remove keyId, dateID, keyProgData
 	        	if (indx >= 3){ 
 	        		if (keyIdData.equals(oldIdData) == false) {
	 	        		oldIdData = keyIdData;
		            	removeByKeyData(keyIdData, keyDateData, keyProgData);
 	        		}
 	        	}
		        storeData(keyIdData, keyDateData, keyProgData, openUrlData, nodeNameData, nodeTypeData, nodeValueData, childNameData, actionData, noteData);
	    }
        in.close();
        System.out.println("Fine esecuzione ##End ...Read Data Test Collaudo QA");
    }

    private static void GetProperties() throws IOException {
  		PropertyFiles pf = new PropertyFiles();
  	  }

	@Override
	public void removeByKeyData(String keyIdData, String keyDateData, String keyProgData) throws DataNotValidException {
		keyIdData = this.keyIdData;
		keyDateData =this.keyDateData;
		keyProgData =this.keyProgData;
		System.out.println("removeByKeyData>> "
	        	+keyIdData
	        	+keyDateData
	        	+keyProgData
        ); 
		//testcollaudoEAO.removeByKeyId(keyIdData, keyDateData, keyProgData);

	}
	@Override
	public void storeData(String keyIdData, String keyDateData, String keyProgData, String openUrlData, String nodeNameData, String nodeTypeData, String nodeValueData, String childNameData, String actionData, String noteData) throws DataNotValidException {
        System.out.println("storeDATA>> "
        	+keyIdData
        	+keyDateData
        	+keyProgData
        	+openUrlData
        	+nodeNameData
        	+nodeTypeData
        	+nodeValueData
        	+childNameData
        	+actionData
        	+noteData
        ); 
		testcollaudoEAO.store(keyIdData,keyDateData, keyProgData, openUrlData, nodeNameData, nodeTypeData, nodeValueData, childNameData, actionData, noteData);
    }




}