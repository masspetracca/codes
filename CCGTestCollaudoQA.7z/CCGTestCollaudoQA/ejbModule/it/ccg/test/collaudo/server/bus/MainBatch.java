package it.ccg.test.collaudo.server.bus;

import java.io.IOException;

import org.dom4j.DocumentException;

import it.ccg.fpm.freader.batch.MainData;
import it.ccg.test.collaudo.server.exceptions.DataNotValidException;



/**
 * Main Batch
 */
  
public class MainBatch {
 public static void main(String[] args) throws Exception {
	 int returnCode = 0;

	 //Main Batch
	  System.out.println("Inizio <MainBatch>");	
	  if (returnCode == 0) { 
		  //Load Data File
		  MainData(returnCode);
	  }  
	  
	  if (returnCode != 0) {
		 System.out.println("Errore nella fase  <MainBatch> - verificare !");
	  }
	  if (returnCode == 0) { 
		  //General Batch
		  GeneralBatch(returnCode);
	  }  
	  
	  if (returnCode != 0) {
		 System.out.println("Errore nella fase  <MainBatch> - verificare !");
	 }

	  System.out.println("Fine esecuzione <MAIN BATCH>");
  }


	private static void GeneralBatch(int returnCode) throws IOException, DataNotValidException {
		GeneralBatch md = new GeneralBatch(returnCode);	
	
}


	private static void MainData(int returnCode) throws IOException, DocumentException {
			MainData md = new MainData(returnCode);	
	}
}


