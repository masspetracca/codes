package it.ccg.test.collaudo.server.eao;

import it.ccg.test.collaudo.server.exceptions.DataNotValidException;

import javax.ejb.SessionContext;
import javax.persistence.EntityManager;

import org.apache.log4j.Logger;

// Referenced classes of package it.ccg.test.collaudo.server.eao:
//            TestCollaudoQAEAOLocal

public class TestCollaudoQAEAO
    implements TestCollaudoQAEAOLocal {
    private EntityManager em;
    Logger log;
    public String keyId;
	public String keyProg;
	public String keyDate;
    public String openUrl;
    public String nodeName;
    public String nodeType;
    public String childName;
    public String action;
    public String nodeValue;
    public String note;
    
    SessionContext ctx;


    public TestCollaudoQAEAO() {
    	log = Logger.getLogger("it.ccg.test.collaudo.server.log.UserLog");
    }

    public String userString()
        throws DataNotValidException {
        if(!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED"))
            return ctx.getCallerPrincipal().getName().toString();
        else
            return "System";
    }
  


	@Override
	public void removeByKeyId(String keyIdData, String keyDateData,
			String keyProgData) {
		// TODO Auto-generated method stub
        throw new Error("Unresolved compilation problems: \n\tCannot make a static reference to the non-static method removeByKeyId() from the type TestCollaudoQA\n\ttestCollaudoQA cannot be resolved\n");
	}

	@Override
	public void store(String keyIdData, String keyDateData, String keyProgData,
			String openUrlData, String nodeNameData, String nodeTypeData,
			String nodeValueData, String childNameData, String actionData,
			String noteData) {
        throw new Error("Unresolved compilation problem: \n\tThe method store(TestCollaudoQA) is undefined for the type EntityManager\n");
	}

	@Override
	public String removeByKeyId(String keyID, String dateID)
			throws DataNotValidException {
		// TODO Auto-generated method stub
		return null;
	}



}