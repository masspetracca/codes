package it.ccg.test.collaudo.server.bus;

import it.ccg.test.collaudo.server.exceptions.DataNotValidException;
import java.io.FileNotFoundException;
import java.io.IOException;

public interface GeneralBatchLocal
{

	void storeData(String keyIdData, String keyDateData, String keyProgData, String openUrlData,
			String nodeNameData, String nodeTypeData, String nodeValueData,
			String childNameData, String actionData, String noteData)
			throws DataNotValidException;

	void removeByKeyData(String keyIdData, String keyDateData, String keyProgData)
			throws DataNotValidException;

}