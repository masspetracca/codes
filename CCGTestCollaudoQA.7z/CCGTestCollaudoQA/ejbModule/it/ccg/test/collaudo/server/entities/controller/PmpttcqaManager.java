package it.ccg.test.collaudo.server.entities.controller;

import com.ibm.jpa.web.JPAManager;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import com.ibm.jpa.web.Action;
import javax.persistence.PersistenceUnit;
import it.ccg.test.collaudo.server.entities.Pmpttcqa;
import it.ccg.test.collaudo.server.entities.PmpttcqaPK;

@SuppressWarnings("unchecked")
@JPAManager(targetEntity = it.ccg.test.collaudo.server.entities.Pmpttcqa.class)
public class PmpttcqaManager {

	@PersistenceUnit
	private EntityManagerFactory emf;

	public PmpttcqaManager() {
	
	}

	private EntityManager getEntityManager() {
		return emf.createEntityManager();
	}

	@Action(Action.ACTION_TYPE.CREATE)
	public String createPmpttcqa(Pmpttcqa pmpttcqa) throws Exception {
		EntityManager em = getEntityManager();
		try {
			em.persist(pmpttcqa);
		} finally {
			em.close();
		}
		return "";
	}

	@Action(Action.ACTION_TYPE.DELETE)
	public String deletePmpttcqa(Pmpttcqa pmpttcqa) throws Exception {
		EntityManager em = getEntityManager();
		try {
			pmpttcqa = em.merge(pmpttcqa);
			em.remove(pmpttcqa);
		} finally {
			em.close();
		}
		return "";
	}

	@Action(Action.ACTION_TYPE.UPDATE)
	public String updatePmpttcqa(Pmpttcqa pmpttcqa) throws Exception {
		EntityManager em = getEntityManager();
		try {
			pmpttcqa = em.merge(pmpttcqa);
		} finally {
			em.close();
		}
		return "";
	}

	@Action(Action.ACTION_TYPE.FIND)
	public Pmpttcqa findPmpttcqaByPrimaryKey(String dateid, String keyid,
			int progid) {
		Pmpttcqa pmpttcqa = null;
		EntityManager em = getEntityManager();
		PmpttcqaPK pk = new PmpttcqaPK();
		pk.setDateid(dateid);
		pk.setKeyid(keyid);
		pk.setProgid(progid);
		try {
			pmpttcqa = (Pmpttcqa) em.find(Pmpttcqa.class, pk);
		} finally {
			em.close();
		}
		return pmpttcqa;
	}

	@Action(Action.ACTION_TYPE.NEW)
	public Pmpttcqa getNewPmpttcqa() {
	
		Pmpttcqa pmpttcqa = new Pmpttcqa();
	
		return pmpttcqa;
	}

}