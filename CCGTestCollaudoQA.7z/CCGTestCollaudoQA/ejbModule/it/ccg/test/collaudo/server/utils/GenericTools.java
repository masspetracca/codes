package it.ccg.test.collaudo.server.utils;

import it.ccg.test.collaudo.server.exceptions.DataNotValidException;
import java.io.PrintStream;
import java.math.*;
import java.security.Principal;
import java.sql.Timestamp;
import java.text.*;
import java.util.*;
import javax.ejb.SessionContext;
import org.apache.log4j.Logger;

public class GenericTools
{

    public GenericTools()
    {
    }

    public static String userString(SessionContext ctx)
        throws DataNotValidException
    {
        if(!ctx.getCallerPrincipal().getName().toString().equalsIgnoreCase("UNAUTHENTICATED"))
            return ctx.getCallerPrincipal().getName().toString();
        else
            return "System";
    }

    public static Timestamp systemDate()
    {
        GregorianCalendar cal = new GregorianCalendar();
        Timestamp now = new Timestamp(cal.getTimeInMillis());
        return now;
    }

    public static Timestamp systemDateMidNight()
    {
        int year = Integer.parseInt(shortSysDateFormat().substring(0, 4));
        int month = Integer.parseInt(shortSysDateFormat().substring(5, 7)) - 1;
        int day = Integer.parseInt(shortSysDateFormat().substring(8));
        GregorianCalendar cal = new GregorianCalendar(year, month, day);
        Timestamp now = new Timestamp(cal.getTimeInMillis());
        return now;
    }

    public static long systemDateLongFormat()
    {
        GregorianCalendar cal = new GregorianCalendar();
        Timestamp now = new Timestamp(cal.getTimeInMillis());
        return shortDateFormatAsLong(now);
    }

    public static long systemTime()
    {
        String sysTime = systemDate().toString().substring(11, 19);
        long time = Integer.parseInt(sysTime.replaceAll(":", ""));
        return time;
    }

    public static Integer delayRestartAfterOrBeforeChangingTime(int days)
    {
        GregorianCalendar cal = new GregorianCalendar();
        Integer ret = null;
        boolean isAfterOrBeforeChangingTime = false;
        cal.add(5, -days);
        if(cal.get(7) == 7)
        {
            boolean isOctoberOrMarch = false;
            boolean nextWeekIsStillOctoberOrMarch = false;
            if(cal.get(2) == 9 || cal.get(2) == 2)
                isOctoberOrMarch = true;
            cal.add(5, -days + 7);
            if(cal.get(2) == 9 || cal.get(2) == 2)
                nextWeekIsStillOctoberOrMarch = true;
            if(isOctoberOrMarch && !nextWeekIsStillOctoberOrMarch)
                isAfterOrBeforeChangingTime = true;
        }
        if(days == 0 && isAfterOrBeforeChangingTime)
        {
            if(2 == 9)
                ret = Integer.valueOf(1);
            else
                ret = Integer.valueOf(-1);
        } else
        if(days == 1 && isAfterOrBeforeChangingTime)
            ret = Integer.valueOf(0);
        return ret;
    }

    public static String shortSysDateFormat()
    {
        return systemDate().toString().substring(0, 10);
    }

    public static boolean isBissextileYear(int todayYear)
    {
        int startingYear = 2012;
        GregorianCalendar cal = new GregorianCalendar();
        boolean isBissextile = false;
        if(todayYear >= startingYear)
        {
            for(int i = 0; i < 11; i++)
                if(todayYear == startingYear + 4 * i)
                    isBissextile = true;

        }
        return isBissextile;
    }

    public static String cardinal(int n)
    {
        String number = "";
        if(n == 11 || n == 12 || n == 13)
        {
            number = (new StringBuilder(String.valueOf(n))).append("th").toString();
        } else
        {
            int i = 0;
            if(i < n + 1)
                if(n - i == 1)
                    number = (new StringBuilder(String.valueOf(n))).append("st").toString();
                else
                if(n - i == 2)
                    number = (new StringBuilder(String.valueOf(n))).append("nd").toString();
                else
                if(n - i == 3)
                    number = (new StringBuilder(String.valueOf(n))).append("rd").toString();
                else
                    number = (new StringBuilder(String.valueOf(n))).append("th").toString();
        }
        return number;
    }

    public static String padding(String startingStr, int fieldLen)
    {
        String outputString = startingStr;
        for(int i = 0; i < fieldLen - (startingStr.length() + 1); i++)
            outputString = (new StringBuilder(String.valueOf(outputString))).append(" ").toString();

        return outputString;
    }

    public static String paddingForDecimal(String startingStr, int fieldLen)
    {
        String outputString = startingStr;
        for(int i = 0; i < fieldLen - (startingStr.length() + 1); i++)
            outputString = (new StringBuilder(String.valueOf(outputString))).append("0").toString();

        return outputString;
    }

    public static String padding(String startingStr, int fieldLen, boolean reverse)
    {
        String outputString = startingStr;
        if(!reverse)
        {
            for(int i = 0; i < fieldLen - (startingStr.length() + 1); i++)
                outputString = (new StringBuilder(String.valueOf(outputString))).append(" ").toString();

        } else
        {
            String spazio = "";
            for(int i = 0; i < fieldLen - startingStr.length(); i++)
                spazio = (new StringBuilder(String.valueOf(spazio))).append(" ").toString();

            outputString = (new StringBuilder(String.valueOf(spazio))).append(outputString).toString();
        }
        return outputString;
    }

    public static String scenarioDesc(String scenarioAcronymous)
    {
        String scenario = "increasing";
        if(scenarioAcronymous.equalsIgnoreCase("d"))
            scenario = "decreasing";
        else
        if(scenarioAcronymous.equalsIgnoreCase("0"))
            scenario = "resetting";
        return scenario;
    }

    public static String shortDateFormat(Timestamp fullDate)
    {
        return fullDate.toString().substring(0, 10);
    }

    public static long shortDateFormatAsLong(Timestamp fullDate)
    {
        String date = (new StringBuilder(String.valueOf(fullDate.toString().substring(0, 4)))).append(fullDate.toString().substring(5, 7)).append(fullDate.toString().substring(8, 10)).toString();
        Long dateAsLong = Long.valueOf(Long.parseLong(date));
        return dateAsLong.longValue();
    }

    public static Timestamp convertDateFromIntToTimestamp(int dateToConvert)
        throws DataNotValidException
    {
        if(Integer.toString(dateToConvert).length() == 8)
        {
            String year = Integer.toString(dateToConvert).substring(0, 4);
            String month = Integer.toString(dateToConvert).substring(4, 6);
            String day = Integer.toString(dateToConvert).substring(6, 8);
            GregorianCalendar cal = new GregorianCalendar(Integer.parseInt(year), Integer.parseInt(month) - 1, Integer.parseInt(day));
            Timestamp dateToReturn = new Timestamp(cal.getTimeInMillis());
            return dateToReturn;
        } else
        {
            throw new DataNotValidException((new StringBuilder("Date ")).append(dateToConvert).append(" unconvertible to Timestamp format").toString());
        }
    }

    public static List arrayToList(String arrayString[])
    {
        List returnList = new ArrayList();
        String as[];
        int j = (as = arrayString).length;
        for(int i = 0; i < j; i++)
        {
            String str = as[i];
            returnList.add(str);
        }

        return returnList;
    }

    public static Timestamp convertStringDateToTimestamp(String dateToConvert, String validSeparators[], String entryFormat, String atPosition)
        throws Exception
    {
        boolean defaultFormat = true;
        String originalDate = dateToConvert;
        String exceptionMsg = (new StringBuilder("Date ")).append(originalDate).append(" not valid ").append(atPosition).append(". ").toString();
        String defaultDateString = "";
        if(entryFormat != null && !entryFormat.toUpperCase().equalsIgnoreCase("YYYY-MM-DD") && !entryFormat.equalsIgnoreCase(""))
            defaultFormat = false;
        if(!defaultFormat && !entryFormat.toUpperCase().contains("Y") && !entryFormat.toUpperCase().contains("M") && !entryFormat.toUpperCase().contains("D"))
            throw new Exception((new StringBuilder("Date format ")).append(entryFormat).append(" not allowed ").append(atPosition).append(" - expected \"YYYY-MM-DD\" format").toString());
        int yearStart = 0;
        int yearEnd = 4;
        int yearDigits = 4;
        int monthStart = 4;
        int monthEnd = 6;
        int dayStart = 6;
        int dayEnd = 8;
        int formatLength = 0;
        int dateToConvertLength = 0;
        boolean separatorFound = false;
        String separator = "";
        int year = 0;
        int month = 0;
        int day = 0;
        if(validSeparators.length != 0)
        {
            String as[];
            int j = (as = validSeparators).length;
            for(int i = 0; i < j; i++)
            {
                String sep = as[i];
                if(dateToConvert.indexOf(sep) <= 0)
                    continue;
                separatorFound = true;
                separator = sep;
                break;
            }

            if(!separatorFound)
                throw new Exception((new StringBuilder("Valid date separators not found ")).append(atPosition).toString());
            if(separator.equalsIgnoreCase("-"))
            {
                dateToConvert = dateToConvert.replaceAll(separator, "/");
                entryFormat = entryFormat.replaceAll(separator, "/");
                separator = "/";
            } else
            {
                throw new Exception((new StringBuilder("Date separator \"")).append(separator).append("\" not allowed ").append(atPosition).append(" - expected \"-\"").toString());
            }
            dateToConvertLength = dateToConvert.length();
            formatLength = entryFormat.length();
            yearStart = entryFormat.toUpperCase().indexOf("Y");
            yearEnd = entryFormat.toUpperCase().lastIndexOf("Y") + 1;
            yearDigits = yearEnd - yearStart;
            monthStart = entryFormat.toUpperCase().indexOf("M");
            monthEnd = entryFormat.toUpperCase().lastIndexOf("M") + 1;
            dayStart = entryFormat.toUpperCase().indexOf("D");
            dayEnd = entryFormat.toUpperCase().lastIndexOf("D") + 1;
            String DLchars = "char";
            if(dateToConvertLength > 1)
                DLchars = "chars";
            DLchars = (new StringBuilder(String.valueOf(dateToConvertLength))).append(" ").append(DLchars).toString();
            String formatChars = "char";
            if(formatLength > 1)
                formatChars = "chars";
            formatChars = (new StringBuilder(String.valueOf(formatLength))).append(" ").append(formatChars).toString();
            if(formatLength != dateToConvertLength)
                throw new Exception((new StringBuilder(String.valueOf(exceptionMsg))).append("Date length (").append(DLchars).append(") is different than format length (").append(formatChars).append(")").toString());
            defaultDateString = (new StringBuilder(String.valueOf(dateToConvert.substring(monthStart, monthEnd)))).append(dateToConvert.substring(dayStart, dayEnd)).toString();
            String yearStr = dateToConvert.substring(yearStart, yearEnd);
            System.out.println((new StringBuilder("yearStr: ")).append(yearStr).toString());
            if(yearDigits == 2)
                yearStr = (new StringBuilder("20")).append(yearStr).toString();
            defaultDateString = (new StringBuilder(String.valueOf(yearStr))).append(defaultDateString).toString();
            year = Integer.parseInt(defaultDateString.substring(0, 4));
            GregorianCalendar appoCalendar = new GregorianCalendar();
            month = Integer.parseInt(defaultDateString.substring(4, 6));
            if(month > 12)
                throw new Exception((new StringBuilder(String.valueOf(exceptionMsg))).append("Month value greater than the maximum - found ").append(month).append(" but maximum allowed is 12").toString());
            day = Integer.parseInt(defaultDateString.substring(6, 8));
            int maxDay = 30;
            String leapYearExc = "";
            switch(month)
            {
            case 1: // '\001'
            case 3: // '\003'
            case 5: // '\005'
            case 7: // '\007'
            case 8: // '\b'
            case 10: // '\n'
            case 12: // '\f'
                maxDay = 31;
                break;

            case 2: // '\002'
                maxDay = 28;
                leapYearExc = (new StringBuilder(" - ")).append(year).append(" is not a leap year").toString();
                if(appoCalendar.isLeapYear(year))
                    maxDay = 29;
                break;
            }
            if(day > maxDay)
                throw new Exception((new StringBuilder(String.valueOf(exceptionMsg))).append("Day value not allowed for month ").append(month).append(" - found ").append(day).append(" but maximum allowed is ").append(maxDay).append(leapYearExc).toString());
            SimpleDateFormat dateFormat = new SimpleDateFormat(entryFormat);
            dateToConvert = dateFormat.format(new Date(dateToConvert));
            System.out.println((new StringBuilder("DOPO: ")).append(dateToConvert).toString());
            entryFormat = entryFormat.replaceAll(separator, "");
            dateToConvert = dateToConvert.replaceAll(separator, "");
        }
        GregorianCalendar cal = new GregorianCalendar(year, month - 1, day);
        Timestamp dateToReturn = new Timestamp(cal.getTimeInMillis());
        return dateToReturn;
    }

    public static Timestamp convertDateFromStringToTimestamp(String dateToConvert)
        throws DataNotValidException
    {
        if(dateToConvert.length() == 10)
        {
            String date[] = dateToConvert.split("/");
            int year = Integer.parseInt(date[2]);
            int month = Integer.parseInt(date[1]);
            int day = Integer.parseInt(date[0]);
            GregorianCalendar cal = new GregorianCalendar(year, month - 1, day);
            Timestamp dateToReturn = new Timestamp(cal.getTimeInMillis());
            return dateToReturn;
        } else
        {
            throw new DataNotValidException((new StringBuilder("Date ")).append(dateToConvert).append(" unconvertible to Timestamp format").toString());
        }
    }

    public static String convertDateFromIntToString(int dateToConvert)
        throws DataNotValidException
    {
        if(Integer.toString(dateToConvert).length() == 8)
        {
            Timestamp timestamp = convertDateFromIntToTimestamp(dateToConvert);
            String dateToReturn = shortDateFormat(timestamp);
            return dateToReturn;
        } else
        {
            throw new DataNotValidException((new StringBuilder("Date ")).append(dateToConvert).append(" unconvertible to Timestamp format").toString());
        }
    }

    public static Timestamp previousDate(Timestamp today)
    {
        int todayYear = Integer.parseInt(today.toString().substring(0, 4));
        int todayMonth = Integer.parseInt(today.toString().substring(5, 7));
        int todayDay = Integer.parseInt(today.toString().substring(8, 10));
        int yesterdayYear = todayYear;
        int yesterdayMonth = todayMonth;
        int yesterdayDay = todayDay - 1;
        GregorianCalendar calendar = new GregorianCalendar();
        if(todayDay == 1)
        {
            yesterdayDay = 30;
            yesterdayMonth--;
            switch(todayMonth)
            {
            case 5: // '\005'
            case 7: // '\007'
            case 8: // '\b'
            case 10: // '\n'
            default:
                break;

            case 1: // '\001'
                yesterdayYear = yesterdayYear--;
                yesterdayMonth = 12;
                yesterdayDay = 31;
                break;

            case 3: // '\003'
                yesterdayDay = 28;
                if(calendar.isLeapYear(todayYear))
                    yesterdayDay = 29;
                break;

            case 2: // '\002'
            case 4: // '\004'
            case 6: // '\006'
            case 9: // '\t'
            case 11: // '\013'
                yesterdayDay = 31;
                break;
            }
        }
        Timestamp yesterday = new Timestamp((new GregorianCalendar(yesterdayYear, yesterdayMonth - 1, yesterdayDay)).getTimeInMillis());
        return yesterday;
    }

    public static String shortDateFormat()
    {
        return systemDate().toString().substring(0, 19);
    }

    public static String getStringDate()
    {
        Date today = Calendar.getInstance().getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-dd-MM-hh.mm.ss");
        String folderName = formatter.format(today);
        return folderName;
    }

    public static Double roundValue(Double value, MathContext mathC)
    {
        BigDecimal rounded = new BigDecimal(value.doubleValue());
        return Double.valueOf(rounded.round(mathC).doubleValue());
    }

    public static String percentValue(BigDecimal value, MathContext mathC)
    {
        BigDecimal rounded = value.round(mathC).multiply(new BigDecimal(100));
        return (new StringBuilder(String.valueOf(rounded.toString()))).append("%").toString();
    }

    public static String convertStringAcronymous(String acronymous, int dataType)
    {
        String fullWord = "";
        switch(dataType)
        {
        default:
            break;

        case 0: // '\0'
            fullWord = "true";
            if(acronymous.equalsIgnoreCase("F"))
                fullWord = "false";
            break;

        case 1: // '\001'
            fullWord = "percentual";
            if(acronymous.equalsIgnoreCase("L"))
                fullWord = "logarithmic";
            break;

        case 2: // '\002'
            fullWord = "Nearest";
            if(acronymous.equalsIgnoreCase("C"))
            {
                fullWord = "Ceiling";
                break;
            }
            if(acronymous.equalsIgnoreCase("F"))
                fullWord = "Floor";
            break;

        case 3: // '\003'
            fullWord = "Standard";
            if(acronymous.equalsIgnoreCase("C"))
            {
                fullWord = "Pearson";
                break;
            }
            if(acronymous.equalsIgnoreCase("D"))
                fullWord = "Div-Undiv";
            break;

        case 4: // '\004'
            fullWord = "average between highest and second highest module";
            if(acronymous.equalsIgnoreCase("H"))
            {
                fullWord = "highest module";
                break;
            }
            if(acronymous.equalsIgnoreCase("S"))
                fullWord = "second highest module";
            break;
        }
        return fullWord;
    }

    public static String scenarioFromAcronymous(String acronymous)
    {
        String scenario = "Decrease";
        if(acronymous.equalsIgnoreCase("I"))
            scenario = "Increase";
        if(acronymous.equalsIgnoreCase("0"))
            scenario = "Day 0";
        return scenario;
    }

    public static String formatNumber(BigDecimal theNumber)
    {
        DecimalFormat df = new DecimalFormat("###,##0.00");
        DecimalFormatSymbols dfs = new DecimalFormatSymbols();
        dfs.setDecimalSeparator(',');
        df.setDecimalFormatSymbols(dfs);
        NumberFormat formatter = df;
        if(theNumber.compareTo(new BigDecimal(0)) == 0)
            return "0";
        else
            return formatter.format(theNumber);
    }

    public static String formatNumber(BigDecimal theNumber, int digits)
    {
        String decForm = "###,##0.";
        for(int i = 0; i < digits; i++)
            decForm = (new StringBuilder(String.valueOf(decForm))).append("0").toString();

        DecimalFormat df = new DecimalFormat(decForm);
        DecimalFormatSymbols dfs = new DecimalFormatSymbols();
        dfs.setDecimalSeparator('.');
        df.setDecimalFormatSymbols(dfs);
        NumberFormat formatter = df;
        if(theNumber.compareTo(new BigDecimal(0)) == 0)
            return "0";
        else
            return formatter.format(theNumber);
    }

    public static String convertIntegerAcronymous(int acronymous, int dataType)
    {
        String fullWord = "";
        switch(dataType)
        {
        default:
            break;

        case 0: // '\0'
            fullWord = "all variations";
            if(acronymous == -1)
                fullWord = "negative variations";
            else
            if(acronymous == 1)
                fullWord = "positive variations";
            break;

        case 1: // '\001'
            fullWord = "all variations";
            if(acronymous == 0)
            {
                fullWord = "highest module";
                break;
            }
            if(acronymous == 1)
                fullWord = "second highest module";
            break;
        }
        return fullWord;
    }

    public static String getWholeDivisCode(String divisCode)
    {
        String fullName = "equity cash";
        if(divisCode.equalsIgnoreCase("ED"))
            fullName = "eq. cash/eq. derivatives";
        if(divisCode.equalsIgnoreCase("D"))
            fullName = "equity derivatives";
        else
        if(divisCode.equalsIgnoreCase("B"))
            fullName = "interest rates";
        else
        if(divisCode.equalsIgnoreCase("X"))
            fullName = "index";
        else
        if(divisCode.equalsIgnoreCase("L"))
            fullName = "electricity derivatives";
        else
        if(divisCode.equalsIgnoreCase("O"))
            fullName = "bond";
        else
        if(divisCode.equalsIgnoreCase("C"))
            fullName = "forex";
        else
        if(divisCode.equalsIgnoreCase("Y"))
            fullName = "comparables";
        return fullName;
    }

    public static BigDecimal checkCap(Logger userLog, int instrID, int nv, int periodo, String tipoVar, BigDecimal daControllare, int numDecimaliAmmessi, String nomeCampo)
    {
        double soglia = Math.pow(10D, numDecimaliAmmessi);
        BigDecimal restituito = null;
        if(daControllare.doubleValue() >= soglia)
        {
            double newFieldValue = soglia - 1.0D;
            userLog.warn((new StringBuilder("INSTRID ")).append(instrID).append(": value of the field ").append(nomeCampo).append(" for holding period ").append(nv).append(" period ").append(periodo).append(" and tipovar ").append(tipoVar).append(" is greater than the threshold ").append(soglia).append(" (").append(daControllare).append(") and will be set to a value of ").append(newFieldValue).toString());
            restituito = new BigDecimal(newFieldValue);
        } else
        {
            restituito = daControllare;
        }
        return restituito;
    }

    public static BigDecimal checkCap(Logger userLog, int instrID1, int instrID2, int nv, int periodo, String tipoVar, BigDecimal daControllare, int numDecimaliAmmessi, 
            String nomeCampo)
    {
        double soglia = Math.pow(10D, numDecimaliAmmessi);
        BigDecimal restituito = null;
        if(daControllare.doubleValue() >= soglia)
        {
            double newFieldValue = soglia - 1.0D;
            userLog.warn((new StringBuilder("INSTRID1 ")).append(instrID1).append(" INSTRID2 ").append(instrID2).append(": value of the field ").append(nomeCampo).append(" for holding period ").append(nv).append(" period ").append(periodo).append(" and tipovar ").append(tipoVar).append(" is greater than the threshold ").append(soglia).append(" (").append(daControllare).append(") and will be set to a value of ").append(newFieldValue).toString());
            restituito = new BigDecimal(newFieldValue);
        } else
        {
            restituito = daControllare;
        }
        return restituito;
    }

    public static boolean isOverCap(double daControllare, int numDecimaliAmmessi)
    {
        double soglia = Math.pow(10D, numDecimaliAmmessi);
        boolean overcap = false;
        if(daControllare >= soglia)
            overcap = true;
        return overcap;
    }

    public static String array2String(String stringarr[])
    {
        String stringafinale = "{";
        String as[];
        int j = (as = stringarr).length;
        for(int i = 0; i < j; i++)
        {
            String mini = as[i];
            stringafinale = (new StringBuilder(String.valueOf(stringafinale))).append(mini = (new StringBuilder(String.valueOf(mini))).append(",").toString()).toString();
        }

        if(stringafinale.endsWith(","))
            stringafinale = (new StringBuilder(String.valueOf(stringafinale.substring(0, stringafinale.length() - 1)))).append("}").toString();
        else
            stringafinale = (new StringBuilder(String.valueOf(stringafinale))).append("}").toString();
        return stringafinale;
    }

    public static String intarray2String(int stringarr[])
    {
        String stringafinale = "{";
        int ai[];
        int j = (ai = stringarr).length;
        for(int i = 0; i < j; i++)
        {
            int mini = ai[i];
            stringafinale = (new StringBuilder(String.valueOf(stringafinale))).append(mini).append(",").toString();
        }

        if(stringafinale.endsWith(","))
            stringafinale = (new StringBuilder(String.valueOf(stringafinale.substring(0, stringafinale.length() - 1)))).append("}").toString();
        else
            stringafinale = (new StringBuilder(String.valueOf(stringafinale))).append("}").toString();
        return stringafinale;
    }

    public static String[] string2Array(String stringona)
        throws DataNotValidException
    {
        if(stringona == null || stringona.length() < 2 || !stringona.startsWith("{") || !stringona.endsWith("}"))
        {
            throw new DataNotValidException((new StringBuilder("String structure (")).append(stringona).append(") not valid").toString());
        } else
        {
            stringona = stringona.substring(1, stringona.length() - 1);
            String stringarr[] = stringona.split(",");
            return stringarr;
        }
    }

    public static int[] string2IntArray(String stringona)
        throws DataNotValidException
    {
        if(stringona == null || stringona.length() < 2 || !stringona.startsWith("{") || !stringona.endsWith("}"))
            throw new DataNotValidException("String structure not valid");
        stringona = stringona.substring(1, stringona.length() - 1);
        String stringarr[] = stringona.split(",");
        int intarr[] = new int[stringarr.length];
        for(int i = 0; i < stringarr.length; i++)
            intarr[i] = Integer.parseInt(stringarr[i]);

        return intarr;
    }

    public static boolean contains(String methodarr[], String method)
    {
        String as[];
        int j = (as = methodarr).length;
        for(int i = 0; i < j; i++)
        {
            String methcur = as[i];
            if(methcur.equalsIgnoreCase(method))
                return true;
        }

        return false;
    }

    public static BigDecimal getLinearInterpolation(BigDecimal x0, BigDecimal y0, BigDecimal x1, BigDecimal y1, BigDecimal x)
    {
        BigDecimal linearInterpolation = null;
        BigDecimal mNum = y1.subtract(y0);
        BigDecimal mDen = x1.subtract(x0);
        BigDecimal l = x.subtract(x0).multiply(mNum.divide(mDen, 8, RoundingMode.HALF_EVEN));
        linearInterpolation = y0.add(l, new MathContext(8, RoundingMode.HALF_EVEN));
        return linearInterpolation;
    }

    public static int getDaysToNextCouponBase30360(GregorianCalendar settlDate, GregorianCalendar nextCouponDate)
        throws DataNotValidException
    {
        int days = 0;
        if(settlDate.after(nextCouponDate))
            throw new DataNotValidException("The settlement date is after the nextCouponDate");
        if(settlDate.get(5) == 31)
            settlDate.set(5, 30);
        GregorianCalendar settlDateRett = new GregorianCalendar(settlDate.get(1), settlDate.get(2), settlDate.get(5) != 31 ? settlDate.get(5) : 30);
        if(settlDateRett.get(1) == nextCouponDate.get(1))
        {
            if(settlDateRett.get(2) == nextCouponDate.get(2))
                days = nextCouponDate.get(5) - settlDateRett.get(5);
            else
                days = (30 - settlDateRett.get(5)) + (nextCouponDate.get(2) - settlDateRett.get(2) - 1) * 30 + nextCouponDate.get(5);
        } else
        {
            GregorianCalendar ultimoDellAnno = new GregorianCalendar(settlDateRett.get(1), 11, 30);
            if(settlDateRett.get(2) == ultimoDellAnno.get(2))
                days = ultimoDellAnno.get(5) - settlDateRett.get(5);
            else
                days = (30 - settlDateRett.get(5)) + (ultimoDellAnno.get(2) - settlDateRett.get(2) - 1) * 30 + ultimoDellAnno.get(5);
            days = days + (nextCouponDate.get(1) - settlDateRett.get(1) - 1) * 360 + (nextCouponDate.get(5) + nextCouponDate.get(2) * 30);
        }
        return days;
    }

    public static int getDaysToNextCouponBaseActualActual(GregorianCalendar settlDate, GregorianCalendar nextCouponDate)
        throws DataNotValidException
    {
        return getDaysBetween2Dates(nextCouponDate, settlDate);
    }

    public static int getDaysBetween2Dates(GregorianCalendar recentDate, GregorianCalendar oldDate)
    {
        GregorianCalendar recentDateRett = new GregorianCalendar(recentDate.get(1), recentDate.get(2), recentDate.get(5), 0, 0, 0);
        GregorianCalendar oldDateRett = new GregorianCalendar(oldDate.get(1), oldDate.get(2), oldDate.get(5), 0, 0, 0);
        return (int)((recentDateRett.getTimeInMillis() - oldDateRett.getTimeInMillis()) / 0x5265c00L);
    }

    public static int getNumberOfCoupons2Maturity(Timestamp maturityDate, GregorianCalendar nextCouponDate, int bondFrequency)
    {
        GregorianCalendar maturityDay = new GregorianCalendar();
        maturityDay.setTimeInMillis(maturityDate.getTime());
        int numcoup = 0;
        if(nextCouponDate.get(1) == maturityDay.get(1))
        {
            numcoup = nextCouponDate.get(2) != maturityDay.get(2) ? 2 : 1;
        } else
        {
            int numyear = maturityDay.get(1) - nextCouponDate.get(1);
            numcoup = numyear * bondFrequency;
            numcoup += nextCouponDate.get(2) != maturityDay.get(2) ? nextCouponDate.get(2) <= maturityDay.get(2) ? 2 : 0 : 1;
        }
        return numcoup;
    }

    public static String getNameFromLastString(int fieldLenght, String lastString, String prefix)
        throws DataNotValidException
    {
        String nextname = "";
        fieldLenght--;
        if(lastString == null || lastString.trim().equalsIgnoreCase(""))
        {
            lastString = "0";
            for(int i = 1; i < fieldLenght; i++)
                lastString = (new StringBuilder(String.valueOf(lastString))).append("0").toString();

        } else
        {
            lastString = lastString.substring(1, lastString.length());
        }
        if(lastString.length() != fieldLenght)
            throw new DataNotValidException((new StringBuilder("The last string lenght is different from the fieldlenght parameter requested ")).append(fieldLenght).append(1).toString());
        String alfanumarr[] = {
            "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
            "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", 
            "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", 
            "U", "V", "W", "X", "Y", "Z"
        };
        for(int suc = fieldLenght; suc > 0; suc--)
        {
            String cara = lastString.substring(suc - 1, suc);
            if(cara.equalsIgnoreCase("Z"))
            {
                nextname = (new StringBuilder("0")).append(nextname).toString();
                continue;
            }
            for(int i = 0; i < alfanumarr.length - 1; i++)
            {
                if(!alfanumarr[i].equalsIgnoreCase(cara))
                    continue;
                nextname = (new StringBuilder(String.valueOf(alfanumarr[i + 1]))).append(nextname).toString();
                break;
            }

            break;
        }

        return (new StringBuilder(String.valueOf(prefix))).append(lastString.substring(0, lastString.length() - nextname.length())).append(nextname).toString();
    }

    public static GregorianCalendar getNextCouponDate(GregorianCalendar maturityDate, GregorianCalendar settlementDate, int bondFreq)
        throws DataNotValidException
    {
        GregorianCalendar nextCD = new GregorianCalendar(maturityDate.get(1), maturityDate.get(2), maturityDate.get(5), 0, 0, 0);
        if(maturityDate.before(settlementDate))
            throw new DataNotValidException("The maturity date is before the settlement date");
        for(; nextCD.after(settlementDate); nextCD.add(2, -12 / bondFreq));
        nextCD.add(2, 12 / bondFreq);
        return nextCD;
    }

    static Logger userLog = Logger.getLogger("it.ccg.test.collaudo.server.log.UserLog");

}