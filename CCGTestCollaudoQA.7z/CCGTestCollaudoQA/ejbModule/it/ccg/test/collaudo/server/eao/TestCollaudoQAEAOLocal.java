package it.ccg.test.collaudo.server.eao;

import it.ccg.test.collaudo.server.exceptions.DataNotValidException;

public interface TestCollaudoQAEAOLocal {
 
    public String removeByKeyId(String keyID, String dateID)
    		throws DataNotValidException;


	public void removeByKeyId(String keyIdData, String keyDateData,
			String keyProgData);

	public void store(String keyIdData, String keyDateData, String keyProgData,
			String openUrlData, String nodeNameData, String nodeTypeData,
			String nodeValueData, String childNameData, String actionData,
			String noteData)
			throws DataNotValidException;
}