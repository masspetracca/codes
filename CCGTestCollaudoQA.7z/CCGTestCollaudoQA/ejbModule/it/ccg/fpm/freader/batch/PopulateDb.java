package it.ccg.fpm.freader.batch;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import it.ccg.fpm.freader.batch.DateUtils;
import it.ccg.fpm.freader.batch.PropertyFiles;

public class PopulateDb {
	//chiavi di accesso per UPD
	private static String kArea = ""; 
	//Stati: "CO" eseguito, "IW" in attesa di esecuzione, "IP" in esecuzione
	private static String kStato = ""; 
	private static String kFreq ="";
	private static String kTipo ="";

	private static String Tab_col0 = "SCAREA";
	private static String Tab_col1 = "SCFREQ";
	private static String Tab_col2 = "SCTIPO";
	private static String Tab_col3 = "SCDATA";
	private static String Tab_col4 = "SCORAR";
	private static String Tab_col5 = "SCSTATO";

	private static String Tab_col6 = "SCSTART";
	private static String Tab_col7 = "SCEND";
	private static String Tab_col8 = "SCIP";
	private static String Tab_col9 = "SCLIB";
	private static String Tab_col10 = "SCTAB";
	
	

	private static String vcol3 = "";
	private static String vcol4 = "";
	private static String vcol5 = "";

	private static String sdate =null;
	private static String nomeTab;
	

	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

	private static String tabFreq ="";
	private int ctrIns;
	private int ctrUpd;
	

	private static Object rs;
	private static PreparedStatement st;

	
	PopulateDb() throws IOException{ 
	//public static void main(String[] args) throws IOException {
	GetProperties();
	nomeTab = PropertyFiles.getTabName1();
    

	sdate = day.now();
	
	String sdateaaaa = sdate.substring(0, 4);
	String sdatemm =   sdate.substring(5, 7);
	String sdategg = sdate.substring(8, 10);
	
	String stimehh = sdate.substring(11, 13);
	String stimemm = sdate.substring(14, 16);
	String stimess = sdate.substring(17, 19);
	
	sDate = (sdateaaaa+sdatemm+sdategg);
	sTime = (stimehh+stimemm+stimess);
	System.out.println("date:"+sDate);
	System.out.println("time:"+sTime);

    
 	   
	try {
		try {
			//Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
			Class.forName(PropertyFiles.getDbDriverTest()).newInstance();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}	
		
		//String url = "jdbc:db2://localhost:50000/DB2";
		String url = PropertyFiles.getDbConnStringTest();
		Properties props = new Properties();
		//props.setProperty("user", "db2admin");
		props.setProperty("user", PropertyFiles.getDbUserTest());
		//props.setProperty("password", "main");
		props.setProperty("password", PropertyFiles.getDbPasswordTest());
		try {
			Connection conn = DriverManager.getConnection(url, props);
				
			System.out.println("Inizio <PopulateDb> popolamento tabelle DB2 via JDBC");
			//segnalazioni di test
			System.out.println("**************************************");
			System.out.println("**       Segnalazioni tecniche      **");
			System.out.println("**************************************");
			System.out.println("url per POPOLAMENTO: "+nomeTab+" "+url);
			System.out.println("drivers: "+PropertyFiles.getDbDriverTest());
			System.out.println("User Test: "+ PropertyFiles.getDbUserTest());
			System.out.println("Password Test: "+ PropertyFiles.getDbPasswordTest());
			System.out.println("**************************************");

			
			BufferedReader in = new BufferedReader
			//(new FileReader("dati/Selenium_tests.xml"));
			(new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTFIELDS_FILE_OUTPUT()));
			try {	
				String line;
    
				while ((line = in.readLine()) != null) {
					//UPDATE
					/*if (line.substring(0, line.length()).contains("UPDATE ")) { 
						//System.out.println("testo letto-OK UPD: " + line);
						String sqlUpdate= line;
						System.out.println(sqlUpdate);
						st = conn.prepareStatement (sqlUpdate); 
						st.executeUpdate();
						++ctrIns;
						*/
					//}
					// INSERT
					//if (line.substring(0, line.length()).contains("INSERT ")) { 
						//System.out.println("testo letto-OK INS: " + line);
						String sqlUpdate= line;
					    System.out.println(sqlUpdate);
						st = conn.prepareStatement (sqlUpdate); 
						st.executeUpdate();
						++ctrIns;
					//}
				} // end WHILE
				if (ctrIns >= 0) {
					AllTabStrutture();
				}
			} catch (Exception e) {e.printStackTrace();}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				try {
					//if(rs != null) ((OutputStreamWriter) rs).close();
					if(st != null)st.close();
					System.out.println("Fine popolamento via JDBC");
					
				} catch (SQLException e) {
					
				}
				
				
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Driver non trovato !");
				e.printStackTrace();
			}
		}
	private void AllTabStrutture() {
		//String url = "jdbc:db2://127.0.0.1:50000/db2";
		String url = PropertyFiles.getDbConnStringTest();
		
		Properties props = new Properties();
		//props.setProperty("user", "db2admin");
		props.setProperty("user", PropertyFiles.getDbUserTest());
		//props.setProperty("password", "main");
		props.setProperty("password", PropertyFiles.getDbPasswordTest());
		System.out.println("**************************************");
		System.out.println("**       Segnalazioni tecniche      **");
		System.out.println("**************************************");
		System.out.println("url per UPDATE: "+nomeTab+" - "+url);
		System.out.println("drivers: "+PropertyFiles.getDbDriverTest());
		System.out.println("User Test: "+ PropertyFiles.getDbUserTest());
		System.out.println("Password Test: "+ PropertyFiles.getDbPasswordTest());
		System.out.println("**************************************");
		
		  if ((PropertyFiles.getDbUserTest().contains("db2admin")) 
		
			&& (PropertyFiles.getDbPasswordTest().contains("main")) == true) {
			
		} else {
			url = "jdbc:as400://10.0.40.10:50000/";
		}
		
		try {
			Connection conn = DriverManager.getConnection(url, props);
	
			sdate = day.now();
			
			String sdateaaaa = sdate.substring(0, 4);
			String sdatemm =   sdate.substring(5, 7);
			String sdategg = sdate.substring(8, 10);
			
			String stimehh = sdate.substring(11, 13);
			String stimemm = sdate.substring(14, 16);
			String stimess = sdate.substring(17, 19);
			
			sDate = (sdateaaaa+sdatemm+sdategg);
			sTime = (stimehh+stimemm+stimess);
			System.out.println("date:"+sDate);
			System.out.println("time:"+sTime);
			
			//Parametri chiave per update
			vcol4 = sTime;
			vcol5 = "'CO'";
			kStato = "'IP'";
			//strutture
			//kFreq = "'D'";
			//kTipo = "'C'";
			//kArea = "'EUR'";
			kFreq = "'"+PropertyFiles.getFREQUENZA()+"'";
			kTipo = "'"+PropertyFiles.getTIPO()+"'";
			kArea = "'"+PropertyFiles.getAREA()+"'";


			nomeTab = PropertyFiles.getTabName2();
			//System.out.println("testo letto: " + line);
			String sqlUpdate = ("UPDATE  "+nomeTab +" SET "
					+	  Tab_col7+" = "+vcol4
					+" ,"+Tab_col5+" = "+vcol5+" "
					+" WHERE " + Tab_col0 + " = "+kArea
					+" AND " + Tab_col5 + " = "+kStato
					+" AND " + Tab_col1 + " = "+kFreq
					+" AND " + Tab_col2 + " = "+kTipo
			);
			System.out.println(sqlUpdate);
			st = conn.prepareStatement (sqlUpdate); 
			st.executeUpdate();
			++ctrUpd;
		} catch(SQLException e) {e.printStackTrace();}
		System.out.println("fine aggiornamenti batch - aggiornati: " + ctrUpd);

		
	}
	private static void GetProperties() throws IOException {
		PropertyFiles pf = new PropertyFiles();
	}

}


	
		
							
   

