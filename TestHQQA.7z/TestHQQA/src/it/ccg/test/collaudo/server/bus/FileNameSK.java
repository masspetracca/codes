package it.ccg.test.collaudo.server.bus;

public class FileNameSK {


	static String filenamesk;
	public FileNameSK(String file) {
	}

	/**
	 *
	 * @author Massimo
	 * Gestisce le Properties del progetto batch
	 * @param file 
	 * @return 
	 * @return 
	 */
	
	public static String getFileNameSK() {
		return filenamesk;
	}

	public static void setFileNameSK(String file) {
		filenamesk = file;
	}

}
