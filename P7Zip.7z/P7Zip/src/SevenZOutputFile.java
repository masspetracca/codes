import java.io.File;

public class SevenZOutputFile {

	public SevenZOutputFile(File file) {
		// TODO Auto-generated constructor stub
	}

}
