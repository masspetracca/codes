package com.p1.selenium.ir.run1;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import it.ccg.calculator.main.testing.IWebDriver;

public class EntryPoint { 
	static ChromeDriver driver = new ChromeDriver(); 
	static IWebElement textBox;
	static void Main() { 
		string url = "http://testing.todorvachev.com/special-elements/text-input-field/";
		driver.Navigate().GoToUrl(url);
		textBox = driver.FindElement(By.Name("username"));
		textBox.SendKeys("Test text");
		Thread.Sleep(3000);
		Console.WriteLine(textBox.GetAttribute("maxlength"));
		Thread.Sleep(3000);
		driver.Quit(); }
}
