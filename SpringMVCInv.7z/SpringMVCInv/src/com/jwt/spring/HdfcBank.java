package com.jwt.spring;

public class HdfcBank implements Bank {
	 
    @Override
    public int getRateOfInterest() {
        return 13;
    }

}