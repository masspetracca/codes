package com.jwt.spring;

 
public interface Bank {
    public int getRateOfInterest(); 
}