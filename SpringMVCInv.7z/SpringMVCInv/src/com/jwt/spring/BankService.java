package com.jwt.spring;

public class BankService {
	   Bank bank1 = new HdfcBank();
	   Bank bank2 = new CitiBank();
	   
	    public void rateOfInterest() {
	        System.out.println("Bank Name#HdfcBank and "+"rate of Interest is :" + bank1.getRateOfInterest()+ "%");
	        System.out.println("Bank Name#CitiBank and "+"rate of Interest is :" + bank2.getRateOfInterest()+ "%");	    	
	    }

		   

}