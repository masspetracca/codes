package com.jwt.spring;

public class BankApplication {
	    public static void main(String as[]) {
	        BankService bankService = new BankService();
	        bankService.rateOfInterest();
	    }
 
}