package com.jwt.spring;


public class CitiBank implements Bank {
 
    @Override
    public int getRateOfInterest() {
        return 15;
    }

}