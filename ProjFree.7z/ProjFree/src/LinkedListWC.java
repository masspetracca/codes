
public class LinkedListWC<T> {

}
