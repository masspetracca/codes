
public interface Time {

	int getHH();

	int getMM();

	int getSS();

	int getMS();

	void setHH(int hh);

	void setMM(int mm);

	void setSS(int ss);

	void setMS(int ms);

}
