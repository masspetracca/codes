public class TimeInterval implements Comparable<TimeInterval> {
	private int startTime;
	private int endTime;

	@Override
	public int compareTo(TimeInterval that) {
		if (startTime.compareTo(that.endTime) > 0) {
			return 1;
		}
		if (endTime.compareTo(that.startTime) < 0) {
			return -1;
		}
		return 0;
	}
}
