
public class SubtitleSeqFactory {

	public static SubtitleSeq getSubtitleSeq() {
		// TODO Auto-generated method stub
		return getSubtitleSeq();
	}

}
