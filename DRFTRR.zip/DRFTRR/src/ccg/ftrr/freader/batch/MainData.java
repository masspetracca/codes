package ccg.ftrr.freader.batch;

import java.io.IOException;

public class MainData {
	/**
	 * Estrattore file .dat con esclusione delle label.
	 */
	  
	
	  public static void main(String[] args) throws Exception {
		  int returnCode = 0;
		  System.out.println("Inizio esecuzione <MAIN>");
		//Filtra e carica i files *.out
		  GetFiles();
		  
		  PopulateDb();

		  if (returnCode != 0) {
			 System.out.println("Errore nella fase  <DataFile> - verificare !");
		 }
		  System.out.println("Fine esecuzione <MAIN>");
	  }


	private static void Errore() {
		// TODO Auto-generated method stub
		
	}


	private static void LoadReq() {
		// TODO Auto-generated method stub
		
	}


	private static void GetFiles() throws IOException {
		GetFiles gf = new GetFiles(); 		
	}
	private static void GetProperties() throws IOException {
		PropertyFiles pf = new PropertyFiles();		
	}
	private static void PopulateDb() throws IOException {
		PopulateDb popdb = new PopulateDb(); 	
	}

}



