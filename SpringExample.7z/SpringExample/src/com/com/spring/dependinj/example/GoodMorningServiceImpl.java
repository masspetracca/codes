package com.spring.dependinj.example;

import org.springframework.stereotype.Component;

//single matching bean found2: goodMorningServiceImpl, goodNightServiceImpl
@Component
public class GoodMorningServiceImpl implements HiService {
	@Override
	public String sayHi() {
		return "Good Morning";
	}

}
