package com.spring.dependinj.example;

public class Todo {
	private int id;
	private String description;
	private boolean isDone;
	
	public Todo() {
		super();
	}
	public Todo(int id, String description, boolean isDone) {
		this();
		this.id=id;
		this.description=description;
		this.isDone=isDone;
	}
}
