package com.spring.dependinj.example;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

//Spring IOC Container => service
//beans
//1. Spring -> create a GoodMorningService => Component
//2. Spring -> Needs to DependencyInjectionExamples the created GoodMorningService
@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(classes=JavaTestContext.class)
@Qualifier(value="goodMorningServiceImpl")

public class InjectionExamples {
	@Autowired
	@Qualifier(value="goodMorningServiceImpl")
	HiService service;
	
	@Test
	public void dummy1Test() {
		assertEquals("Good Morning", service.sayHi());
	}
	
	//Constructor
	@Autowired
	public void setService(HiService service) {
		System.out.println("HiService Setter");
		this.service = service;
	}
}
