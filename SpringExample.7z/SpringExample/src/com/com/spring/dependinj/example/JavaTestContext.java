package com.spring.dependinj.example;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration
@ComponentScan(basePackages="com.spring.dependinj.example")

public class JavaTestContext {
	
}
