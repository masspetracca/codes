package com.spring.dependinj.example;

import org.springframework.stereotype.Component;

@Component
public class GoodNightService implements HiService {
	@Override
	public String sayHi() {
		return "Good Night";
	}
}
