package com.spring.dependinj.example;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

//Spring IOC Container => service
//beans
//1. Spring -> create a GoodMorningService => Component
//2. Spring -> Needs to DependencyInjectionExamples the created GoodMorningService
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"/TestContext.xml"})


public class DependencyInjectionExamples {
	@Autowired
	@Qualifier(value="goodMorningServiceImpl")
	//GoodMorningService service;
	HiService service;
	HiService goodNightServiceImpl;
	HiService GoodMorningServiceImpl;
	
//	@Test
//	public void dummyTest() {
//		System.out.println(service.sayHi());
//	}
	@Test
	public void dummy1Test() {
		assertEquals("Good Morning", service.sayHi());
		System.out.println(GoodMorningServiceImpl);
	}
	@Test
	public void dummy2Test() {
		System.out.println(GoodMorningServiceImpl.sayHi());
	}
	@Test
	public void dummy3Test() {
		System.out.println(goodNightServiceImpl.sayHi());
	}

}
