package com.spring.dependinj.example;

public interface HiService {

	public String sayHi();
	
}
