package com.spring.dependinj.example;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration(class = SpringContextAOP.class)
public class AOPExampleTest {
	@Autowired
	private HiByeService service;
	
	@Test
	public void testSomething() {
		service.sayBye();
		service.returnSomething();
	}
			
}
