package com.spring.dependinj.example;

public class Dummy {

}
