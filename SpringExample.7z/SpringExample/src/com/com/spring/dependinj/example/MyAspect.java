package com.spring.dependinj.example;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
public class MyAspect {
	@Before ("execution(*com.in28minutes.example.spring.business.aop.HiByeservice.*(..)")
	public void before (JoinPoint joinPoint) {
		System.out.print("Before ");
		System.out.println(joinPoint.getSignature().getName());
	}
	@AfterReturning (pointcut="execution(*com.in28minutes.example.spring.business.aop.HiByeservice")
	public void afterReturning(JoinPoint joinPoint, Object result) {
		System.out.print("After ");
		System.out.println(joinPoint.getSignature().getName());
		System.out.print(" result is "+result);
	//			+ " Returned with " + result);
	}
}
