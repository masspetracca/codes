package com.spring.dependinj.example;

import java.util.List;

import org.springframework.stereotype.Component;

import com.in28minutes.jdbc.model.Todo;

@Component
public interface TodoBusinessService {

	List<Todo> retrieveTodosRelatedToSpring(String user);

	
}
