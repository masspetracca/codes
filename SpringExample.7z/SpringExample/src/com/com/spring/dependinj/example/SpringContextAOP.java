package com.spring.dependinj.example;

public class SpringContextAOP {

}
