package com.spring.dependinj.example;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TodoDataService<Todo> {

	private Object INSERT_TODO_QUERY;
	private Object db;
	public void retrieveTodos(String user) {
		// TODO Auto-generated method stub
		return;
	}
	private void insertTodo(Todo todo) {
		PreparedStatement st = null;
		try {
			st = db.conn.prepareStatement(INSERT_TODO_QUERY);
			st.setString(1, todo.getDescription());
			st.setString(2, todo.isDone());
			st.execute();
			
		} catch (SQLException e) {
			Logger.fatal("Query Failed: " + INSERT_TODO_QUERY, e);
		} finally {
			if (st != null) {
				try {
					st.close();
				} catch (SQLException e) {
			}
		}
		
	}
	}
}


		
