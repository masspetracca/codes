package com.spring.dependinj.example;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.in28minutes.jdbc.model.Todo;

@Component
public class TodoBusinessServiceImpl implements TodoBusinessService {

	@Autowired
	TodoDataService todoDs;
	
	@Override
	public List<Todo> retrieveTodosRelatedToSpring(String user) {
		//System.out.println("retrieveTodosRelatedToSpring is called with parameter "+user);
		List <Todo> todos =  todoDs.retrieveTodos(user);
		List<Todo> filteredTodos = filterTodosRelatedToSpring(todos);
	 	//System.out.println("retrieveTodosRelatedToSpring completed execution" + filteredTodos);
	    //          return filteredTodos;
	}

	private List<Todo> filterTodosRelatedToSpring(List<Todo> todos) {
		// TODO Auto-generated method stub
		return todos ;
	}




}

