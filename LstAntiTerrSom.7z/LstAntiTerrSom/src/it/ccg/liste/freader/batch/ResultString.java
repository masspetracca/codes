package it.ccg.liste.freader.batch;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import uk.ac.shef.wit.simmetrics.similaritymetrics.AbstractStringMetric;
import uk.ac.shef.wit.simmetrics.similaritymetrics.EuclideanDistance;

public class ResultString {

		private static Object rs;
		private static PreparedStatement st;
		private static Object conn;
		private static String currdate;

		private static String sdate =null;
		private static String sTime ="";
		private static String sDate = "";
		static DateUtils day = new DateUtils();
	
		String tableName = null;

		String tab_1 = "MEXMEM";
	    String tab_2 = "MFMNAM";
	    String tab_3 = "MFMEEN";
	    String tab_4 = "MFESIG";
	    String tab_5 = "MFNOTE";
		private int indx;
		private int name0;
		private String name1;
		private String name2;
		private String indicator;
		private String line;
		private int name3;
		private String name4;
		private float name5;
		private float ind;
		private String nameNORM;
		 
	    

		ResultString(int returnCode) throws IOException, SQLException{ 
		//public static void main(String[] args) throws IOException {
			System.out.println("Inizio esecuzione <ResultString>");
			
			sdate = day.now();
			 
			 String sdateaaaa = sdate.substring(0, 4);
			 String sdatemm =   sdate.substring(5, 7);
			 String sdategg = sdate.substring(8, 10);
			
		 	 String stimehh = sdate.substring(11, 13);
			 String stimemm = sdate.substring(14, 16);
			 String stimess = sdate.substring(17, 19);
			
			 sDate = (sdateaaaa+sdatemm+sdategg);
			 sTime = (stimehh+stimemm+stimess);
			 System.out.println("date:"+sDate);
			 System.out.println("time:"+sTime);
			 currdate = sDate+sTime;
			GetProperties(); 

			 
			 File outputFile = new File(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTDB2_FILE_OUTPUT()+".al"+currdate+".csv");
		    // System.out.println(outputFile.getAbsolutePath());
		    FileWriter writer = null;
		    
		    try {								
		    	boolean deleted = false;							
		    	if (outputFile.exists()) {							
		    		deleted = outputFile.delete();						
		    	}							
		    	System.out.println("rimosso file da: " + outputFile.getAbsolutePath() + "; " + deleted);							
		    	writer = new FileWriter(outputFile, false);							
		    								
		    } catch (IOException e1) {								
		    	System.out.println(e1.getMessage());							
		    	e1.printStackTrace();							
		    }


			try {
				try {
					//Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
					Class.forName(PropertyFiles.getDbDriverTest()).newInstance();
				} catch (InstantiationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IllegalAccessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}	
				//String url = "jdbc:db2://127.0.0.1:50000/db2";
				String url = PropertyFiles.getDbConnStringTest();
				Properties props = new Properties();
				//props.setProperty("user"; "db2admin");
				props.setProperty("user", PropertyFiles.getDbUserTest());
				//props.setProperty("password"; "main");
				props.setProperty("password", PropertyFiles.getDbPasswordTest());
				try {
					Connection conn = DriverManager.getConnection(url, props);
						
					System.out.println("Inizio scansione JDBC");
					tableName = PropertyFiles.getTabName1();

					String stconn =
						("SELECT MEXMEM, MFMNAM, MFMEEN, MFESIG, MFNOTE  FROM " 
								+ tableName 
								+ " ORDER BY " + tab_1
					);
					System.out.println("stringa- test:"+stconn);
					st = conn
					.prepareStatement 
					("SELECT MEXMEM, MFMNAM, MFMEEN, MFESIG, MFNOTE  FROM " 
							+ tableName 
							+ " ORDER BY " + tab_1
					); 

					//TABLENAME
					rs = st.executeQuery();
					int i = 0;
					System.out.println(((ResultSet) rs).getRow());

					//writer.write(str+"\n");
					 Names name = new Names();
					 line=("Id, Indicator, Formula,MEMBER Description,ENTITY Description, Expected Result, MATCH type, ERROR");
					 writer.write(line+"\n");
						while (((ResultSet) rs).next()) {
							i++;
//							System.out.println("Leggo: rec#" + i 
//									+ ":   " 
//									+ ((ResultSet) rs).getInt(1) 
//									+ ", " + ((ResultSet) rs).getString(2)
//									+ ", " + ((ResultSet) rs).getString(3)
//									+ ", " + ((ResultSet) rs).getString(4)
//									+ ", " + ((ResultSet) rs).getString(5)
//									);
	
								 indx++;
								 name.setMem1(((ResultSet) rs).getInt(1) );
								 name.setName2(((ResultSet) rs).getString(2) );
								 name.setName3(((ResultSet) rs).getString(3) );
								 
								 nameNORM = name.getName2();
								 nameNORM = nameNORM.replace(".", "");
								 name.setName2(nameNORM);

								 nameNORM = name.getName3();
								 nameNORM = nameNORM.replace(".", "");
								 name.setName3(nameNORM);

								 name.setSig4(((ResultSet) rs).getInt(4) );
								 name.setNote5(((ResultSet) rs).getString(5) );
								 name0=name.getMem1();
								 name1=name.getName2();
								 name2=name.getName3();
								 name3=name.getSig4();
								 name4=name.getNote5();
								 String indicatorl=null;
								 String indicatore=null;

								Metrics metrica = new Metrics();
 							    Symmetrics(name1, name2, indicator);
							    indicatorl=metrica.getIndicatorl();
							    indicatore="Levenshtein";
							    ind = Float.parseFloat(indicatorl);
							    name5=name3-ind;
							    if (name5 <0) {
							    	name5=name5*-1;
							    }
							    line=(name0+","+indicatorl+","+indicatore+","+name1+","+name2+","+name3+","+name4+","+name5);
							    writer.write(line+"\n");
	
//								Metrics metricame = new Metrics();
//								SymmetricMongeElkan(name1, name2, indicator);
//								indicatore="MongeElkan";
//								indicatorl=metricame.getIndicatorl();
//							    ind = Float.parseFloat(indicatorl);
//							    name5=name3-ind;
//							    if (name5 <0) {
//							    	name5=name5*-1;
//							    }
//								line=(name0+","+indicatorl+","+indicatore+","+name1+","+name2+","+name3+","+name4+","+name5);
//								writer.write(line+"\n");
								
								Metrics metricaidf = new Metrics();
								SoftTFIDFTrain(name1, name2, indicator);
								//SymmetricSoftTFIDF(name1, name2, indicator);
								indicatore="SoftTFIDF";
								indicatorl=metricaidf.getIndicatorl();
							    ind = Float.parseFloat(indicatorl);
							    name5=name3-ind;
							    if (name5 <0) {
							    	name5=name5*-1;
							    }
								line=(name0+","+indicatorl+","+indicatore+","+name1+","+name2+","+name3+","+name4+","+name5);
								writer.write(line+"\n");
								
								Metrics metricaqgrm = new Metrics();
								QGramsDistance(name1, name2, indicator);
								indicatore="QGramsDistance";
								indicatorl=metricaqgrm.getIndicatorl();
							    ind = Float.parseFloat(indicatorl);
							    name5=name3-ind;
							    if (name5 <0) {
							    	name5=name5*-1;
							    }
								line=(name0+","+indicatorl+","+indicatore+","+name1+","+name2+","+name3+","+name4+","+name5);
								writer.write(line+"\n");
							}
					}
					finally {
							System.out.println("Fine scansione - righe lette: " + indx);
							if(st != null)st.close();
							if(writer != null)writer.close();
							if(conn != null) ((OutputStreamWriter) conn).close();
					}

				} catch (ClassNotFoundException e) {
					System.out.println("Driver non trovato !");
					e.printStackTrace();
				}
			}




		private void QGramsDistance(String name1, String name2, String indicator) {
			QGramsDistance qgram = new QGramsDistance(name1, name2);
			qgram.getSimilarity(name1, name2);
		}




		private static void Symmetrics(String name1, String name2, String indicator) throws IOException {
			Symmetrics sym = new Symmetrics(name1, name2, indicator);
	}


		private static void GetProperties() throws IOException {
			PropertyFiles pf = new PropertyFiles();
		}

		private void SymmetricMongeElkan(String name1, String name2, String indicator) throws IOException {
			SymmetricMongeElkan sme = new SymmetricMongeElkan(name1, name2, indicator);
		
	}

		private static void SymmetricSoftTFIDF(String name1, String name2, String indicator) throws IOException {
			SymmetricSoftTFIDF sstfidf = new SymmetricSoftTFIDF(name1, name2, indicator);
		
	}
		private void SoftTFIDFTrain(String name1, String name2, String indicator) throws IOException {
			SoftTFIDFTrain sfttfdftt = new SoftTFIDFTrain(name1, name2, indicator);
			
		}

		
		
}




