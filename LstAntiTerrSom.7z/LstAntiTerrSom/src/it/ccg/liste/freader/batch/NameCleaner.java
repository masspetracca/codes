package it.ccg.liste.freader.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NameCleaner {
 private Properties businnesTypeProp = null;
 
 public NameCleaner() throws FileNotFoundException, IOException{
	 this.businnesTypeProp= new Properties();
	 this.businnesTypeProp.load(new FileInputStream(new File("C:/Users/rdelauri/Desktop/businnes_entity.properties")));

 }
 
 public List<String> clean(List<String> entityNames){
	 List<String> result = new ArrayList<String>(entityNames.size());
	 
	 Set keySet = this.businnesTypeProp.keySet();
	 nextname: for (String name : entityNames){
		 for (Object key: keySet){
			 Pattern localPattern = Pattern.compile(this.businnesTypeProp.getProperty((String)key),Pattern.CASE_INSENSITIVE);
			 Matcher m = localPattern.matcher(name);
			 //System.out.println(Pattern.matches(this.businnesTypeProp.getProperty((String)key), name));
			 if (m.find()){
				 result.add(name.replaceAll(m.group(),""));
				 continue nextname;
			 }
		 }
		 result.add(name);
	 }
	 return result;
 }
 
 //chiamata
 public String clean(String entityName){
	 String result=entityName;
	 
	 Set keySet = this.businnesTypeProp.keySet();
	 for (Object key: keySet){
		 Pattern localPattern = Pattern.compile(this.businnesTypeProp.getProperty((String)key),Pattern.CASE_INSENSITIVE);
		 Matcher m = localPattern.matcher(entityName);
		 //System.out.println(Pattern.matches(this.businnesTypeProp.getProperty((String)key), name));
		 if (m.find()){
			 result = entityName.replaceAll(m.group(),"");
		 }
	 }
	 return result;
 }
}