package it.ccg.liste.freader.batch;


import com.wcohen.ss.MongeElkan;

public class SymmetricMongeElkan {
	//public static void main(String[] args)     {  
	public SymmetricMongeElkan(final String str1, final String str2, String indicator) {
		// create a SoftTFIDF distance learner         
		Metrics metrica = new Metrics(); 
		String s =str1;
		String t =str2;
		double d=0;
		MongeElkan distance = new MongeElkan();
		d=distance.score(s, t);

	//		now use the distance metric on some examples
		myCompare(d, s, t);         
		metrica.setIndicatorl(String.valueOf(d));
		System.out.println("ind:"+metrica.getIndicatorl());
      
	}  
	static void myCompare(double d1, String s, String t)     {         
		// compute the similarity         
		double d = d1;          
		// print it out         
		System.out.println("==========SymmetricMongeElkan=======================");         
		System.out.println("String s:  '"+s+"'");         
		System.out.println("String t:  '"+t+"'");         
		System.out.println("Similarity: "+d);          
		// a sort of system-provided debug output         
		System.out.println("Explanation:\n" + d);          
		} 
}
