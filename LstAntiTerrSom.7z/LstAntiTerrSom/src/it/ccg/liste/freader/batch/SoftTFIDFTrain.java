package it.ccg.liste.freader.batch;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.wcohen.ss.BasicStringWrapperIterator;
import com.wcohen.ss.JaroWinkler;
import com.wcohen.ss.SoftTFIDF;
import com.wcohen.ss.api.Tokenizer;
import com.wcohen.ss.tokens.SimpleTokenizer;

public class SoftTFIDFTrain {
	private int nameLength;
	private String stl;
	private String stla;
	private int i;
	private String s1;
	private String s2;
	

	public SoftTFIDFTrain(String str1, String str2, String indicator) throws IOException {
		// TODO Auto-generated constructor stub
	Tokenizer tokenizer = new SimpleTokenizer(false,true);         
	double minTokenSimilarity = 0.8;  

	SoftTFIDF distance = new SoftTFIDF(tokenizer,new JaroWinkler(),0.8);                 
	// train the distance on some strings - in general, this would         
	// be a large corpus of existing strings, so that some         
	// meaningful frequency estimates can be accumulated.  for         
	// efficiency, you train on an iterator over StringWrapper         
	// objects, which are produced with the 'prepare' function.



	stl="";
	stla="";
	List list = new ArrayList(); 
	
	// CICLO:inizio
	//read File
	BufferedReader in = new BufferedReader
  			//(new FileReader("datiTRR/"+"outFPM.txt"));
	(new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTFPM_FILE_INPUT_D()));
	    //string readline
		while ((stl=in.readLine()) != null){
			if (stl != null)
				stla=stl;	
		
			i=0;
			//lavora su stringa solamente = s1
			String StrSplit = new String(stla);
			for (String retval: StrSplit.split(",", 2)){
		         //System.out.println(retval);
		         i++;
		         if (i==1) {
		        	 s1=retval;
		         }
		         if (i==2) {
		        	 s2=retval;
		         }
		         
			}
		         
		        //String[] corpus = {s1, s2};
		        String [] corpus = {s1};
				for (int i=0; i<corpus.length; i++) {             
					list.add( distance.prepare(corpus[i]) );         
				} 
			
		
			}
			in.close();				
		
			distance.train( new BasicStringWrapperIterator(list.iterator()) ); 
			
			// now use the distance metric on some examples         
			myCompare(distance, str1, str2);   
		
		  
	}

		static void myCompare(SoftTFIDF distance, String s, String t)     {
			 Metrics metrica = new Metrics(); 
			// compute the similarity         
			double d = distance.score(s,t);          
			// print it out         
			System.out.println("==========SymmetricSoftTFIDF=======================");         
			System.out.println("String s:  '"+s+"'");         
			System.out.println("String t:  '"+t+"'");         
			System.out.println("Similarity: "+d);          
			// a sort of system-provided debug output         
			System.out.println("Explanation:\n" + distance.explainScore(s,t));          
			// this is equivalent to d, above, but if you compare s to         
			// many strings t1, t2, ... it's a more efficient to only         
			// 'prepare' s once.          
			double e = distance.score( distance.prepare(s), distance.prepare(t) ); 
			metrica.setIndicatorl(String.valueOf(e));
			System.out.println("ind:"+metrica.getIndicatorl());

			}

}
