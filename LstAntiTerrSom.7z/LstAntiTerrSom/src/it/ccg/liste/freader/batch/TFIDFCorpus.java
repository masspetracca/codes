package it.ccg.liste.freader.batch;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class TFIDFCorpus {

			private static Object rs;
			private static PreparedStatement st;
			private static Object conn;
			private static String currdate;

			private static String sdate =null;
			private static String sTime ="";
			private static String sDate = "";
			static DateUtils day = new DateUtils();
		
//			String tableName = "TRRLSLISTA";
			String tableName="TRRLSFTX";
			private int indx;
			private String name1;
			private String name2;
			private float ind;
			private String name0;
			private String line;
			private int nameLength;
			private int indmax;
			 
		    

			TFIDFCorpus(int returnCode) throws IOException, SQLException{ 
			//public static void main(String[] args) throws IOException {
				System.out.println("Inizio esecuzione <TFIDFCorpus>");
				 
				 indmax=500;
				 sdate = day.now();
				 
				 String sdateaaaa = sdate.substring(0, 4);
				 String sdatemm =   sdate.substring(5, 7);
				 String sdategg = sdate.substring(8, 10);
				
			 	 String stimehh = sdate.substring(11, 13);
				 String stimemm = sdate.substring(14, 16);
				 String stimess = sdate.substring(17, 19);
				
				 sDate = (sdateaaaa+sdatemm+sdategg);
				 sTime = (stimehh+stimemm+stimess);
				 System.out.println("date:"+sDate);
				 System.out.println("time:"+sTime);
				 currdate = sDate+sTime;
				 GetProperties(); 

				 
				 File outputFile = new File(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTFPM_FILE_INPUT_D());
			    // System.out.println(outputFile.getAbsolutePath());
			    FileWriter writer = null;
			    
			    try {								
			    	boolean deleted = false;							
			    	if (outputFile.exists()) {							
			    		deleted = outputFile.delete();						
			    	}							
			    	System.out.println("rimosso file da: " + outputFile.getAbsolutePath() + "; " + deleted);							
			    	writer = new FileWriter(outputFile, false);							
			    								
			    } catch (IOException e1) {								
			    	System.out.println(e1.getMessage());							
			    	e1.printStackTrace();							
			    }


				try {
					try {
						//Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
						Class.forName(PropertyFiles.getDbDriverTest()).newInstance();
					} catch (InstantiationException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IllegalAccessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}	
					//String url = "jdbc:db2://127.0.0.1:50000/db2";
					String url = PropertyFiles.getDbConnStringTest();
					Properties props = new Properties();
					//props.setProperty("user"; "db2admin");
					props.setProperty("user", PropertyFiles.getDbUserTest());
					//props.setProperty("password"; "main");
					props.setProperty("password", PropertyFiles.getDbPasswordTest());
					try {
						Connection conn = DriverManager.getConnection(url, props);
							
						System.out.println("Inizio scansione JDBC");
						//tableName = PropertyFiles.getTabName1();

						String stconn =
//							("SELECT NAME " +
							("SELECT MFMNAM" +
									" FROM " 
									+ tableName 
							);
						System.out.println("stringa- test:"+stconn);
						st = conn
						.prepareStatement 
//						("SELECT NAME " +
						("SELECT MFMNAM" +
								" FROM " 
								+ tableName 
						);

						//TABLENAME
						rs = st.executeQuery();
						int i = 0;
						System.out.println(((ResultSet) rs).getRow());

						Corpus corpus = new Corpus();
							while (((ResultSet) rs).next()) {
								i++;
//								System.out.println("Leggo: rec#" + i 
//										+ ":   " 
//										+ ((ResultSet) rs).getInt(1) 
//										+ ", " + ((ResultSet) rs).getString(2)
//										+ ", " + ((ResultSet) rs).getString(3)
//										+ ", " + ((ResultSet) rs).getString(4)
//										+ ", " + ((ResultSet) rs).getString(5)
//										);
		
									 indx++;
									 corpus.setName1(((ResultSet) rs).getString(1) );
									 name1=corpus.getName1();
									 
								     line=(name1);
									 line = line.replace(".", "");
								     writer.write(line+"\n");

//								     //togliere !!!!!!!!!!!!
//								     if (indx>=indmax) {
//								    	 break;								    	 
//								     }
//								     //togliere !!!
									}
						}
						finally {
								System.out.println("Fine scansione TFIDFCorpus - righe lette: " + indx);
								if(st != null)st.close();
								if(writer != null)writer.close();
								if(conn != null) ((OutputStreamWriter) conn).close();
						}

					} catch (ClassNotFoundException e) {
						System.out.println("Driver non trovato !");
						e.printStackTrace();
					}
				}

		
		private static void GetProperties() throws IOException {
			PropertyFiles pf = new PropertyFiles();		
		}
			
	
}
