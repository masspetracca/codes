package it.ccg.liste.freader.batch;

public class Metrics {

	static String indicatorl;
	static String indicatore;

	public String getIndicatorl() {
		// TODO Auto-generated method stub
		return indicatorl;
	}
	public void setIndicatorl(String indicatorl) {
		Metrics.indicatorl = indicatorl;
	}
	public String getIndicatore() {
		// TODO Auto-generated method stub
		return indicatore;
	}
	public void setIndicatore(String indicatore) {
		Metrics.indicatore = indicatore;
	}

}
