package it.ccg.liste.freader.batch;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import uk.ac.shef.wit.simmetrics.similaritymetrics.AbstractStringMetric;
import uk.ac.shef.wit.simmetrics.similaritymetrics.EuclideanDistance;

public class ResStrings {

		private static Object rs;
		private static PreparedStatement st;
		private static Object conn;
		private static String currdate;

		private static String sdate =null;
		private static String sTime ="";
		private static String sDate = "";
		static DateUtils day = new DateUtils();
	
		String tableName = null;

		String tab_1 = "MEXMEM";
	    String tab_2 = "MFMNAM";
		private int indx;
		private int name0;
		private String name1;
		private String name2;
		private String indicator;
		private String line;
		private int name3;
		private String name4;
		private float name5;
		private float ind;
		private String nameNORM;
		private int indmax;
		 
	    

		ResStrings(int returnCode) throws IOException, SQLException{ 
		//public static void main(String[] args) throws IOException {
			System.out.println("Inizio esecuzione <ResultString>");
			indmax=5000000;
			
			sdate = day.now();
			 
			 String sdateaaaa = sdate.substring(0, 4);
			 String sdatemm =   sdate.substring(5, 7);
			 String sdategg = sdate.substring(8, 10);
			
		 	 String stimehh = sdate.substring(11, 13);
			 String stimemm = sdate.substring(14, 16);
			 String stimess = sdate.substring(17, 19);
			
			 sDate = (sdateaaaa+sdatemm+sdategg);
			 sTime = (stimehh+stimemm+stimess);
			 System.out.println("date:"+sDate);
			 System.out.println("time:"+sTime);
			 currdate = sDate+sTime;
			 GetProperties(); 

			 
			 File outputFile = new File(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTDB2_FILE_OUTPUT()+".al"+currdate+".csv");
		    // System.out.println(outputFile.getAbsolutePath());
		    FileWriter writer = null;
		    
		    try {								
		    	boolean deleted = false;							
		    	if (outputFile.exists()) {							
		    		deleted = outputFile.delete();						
		    	}							
		    	System.out.println("rimosso file da: " + outputFile.getAbsolutePath() + "; " + deleted);							
		    	writer = new FileWriter(outputFile, false);							
		    								
		    } catch (IOException e1) {								
		    	System.out.println(e1.getMessage());							
		    	e1.printStackTrace();							
		    }


			try {
				try {
					//Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
					Class.forName(PropertyFiles.getDbDriverTest()).newInstance();
				} catch (InstantiationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IllegalAccessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}	
				//String url = "jdbc:db2://127.0.0.1:50000/db2";
				String url = PropertyFiles.getDbConnStringTest();
				Properties props = new Properties();
				//props.setProperty("user"; "db2admin");
				props.setProperty("user", PropertyFiles.getDbUserTest());
				//props.setProperty("password"; "main");
				props.setProperty("password", PropertyFiles.getDbPasswordTest());
				try {
					Connection conn = DriverManager.getConnection(url, props);
						
					System.out.println("Inizio scansione JDBC");
					tableName = PropertyFiles.getTabName1();

					String stconn =
						("SELECT TRRRAGS, MFMNAM1" +
								" FROM " 
								+ tableName 
						);
					System.out.println("stringa- test:"+stconn);
					st = conn
					.prepareStatement 
					("SELECT NAME1, NAME2" +
							" FROM " 
							+ tableName 
					);

					//TABLENAME
					rs = st.executeQuery();
					int i = 0;
					System.out.println(((ResultSet) rs).getRow());

					//writer.write(str+"\n");
					 Names name = new Names();
					 line=("Id, Indicator, Formula,MEMBER Description,ENTITY Description, Expected Result, MATCH type, ERROR");
					 writer.write(line+"\n");
						while (((ResultSet) rs).next()) {
							i++;
//							System.out.println("Leggo: rec#" + i 
//									+ ":   " 
//									+ ((ResultSet) rs).getInt(1) 
//									+ ", " + ((ResultSet) rs).getString(2)
//									+ ", " + ((ResultSet) rs).getString(3)
//									+ ", " + ((ResultSet) rs).getString(4)
//									+ ", " + ((ResultSet) rs).getString(5)
//									);
	
								 indx++;
								 if (indx > indmax) {
									 break;
								 }
								 name.setName2(((ResultSet) rs).getString(1) );
								 name.setName3(((ResultSet) rs).getString(2) );
								 
								 nameNORM = name.getName2();
								 nameNORM = nameNORM.replace(".", "");
								 name.setName2(nameNORM);

								 nameNORM = name.getName3();
								 nameNORM = nameNORM.replace(".", "");
								 name.setName3(nameNORM);
								 
								 name.setMem1(0);
								 name.setSig4(0);
								 name.setNote5("");
								 name0=name.getMem1();
								 name1=name.getName2();
								 name2=name.getName3();
								 name3=name.getSig4();
								 name4=name.getNote5();
								 String indicatorl=null;
								 String indicatore=null;


//								if (name2.equals("")==true) {
//									break;
//								}
//								if (name2.equals("")==false) {
									Metrics metrica = new Metrics();
	 							    Symmetrics(name1, name2, indicator);
								    indicatorl=metrica.getIndicatorl();
								    indicatore="Levenshtein";
								    ind = Float.parseFloat(indicatorl);
								    name5=name3-ind;
								    if (name5 <0) {
								    	name5=name5*-1;
								    }
								    line=(name0+","+indicatorl+","+indicatore+","+name1+","+name2+","+name3+","+name4+","+name5);
								    writer.write(line+"\n");
//		
//									Metrics metricame = new Metrics();
//									SymmetricMongeElkan(name1, name2, indicator);
//									indicatore="MongeElkan";
//									indicatorl=metricame.getIndicatorl();
//								    ind = Float.parseFloat(indicatorl);
//								    name5=name3-ind;
//								    if (name5 <0) {
//								    	name5=name5*-1;
//								    }
//									line=(name0+","+indicatorl+","+indicatore+","+name1+","+name2+","+name3+","+name4+","+name5);
//									writer.write(line+"\n");
									
									Metrics metricaidf = new Metrics();
									SoftTFIDFTrain(name1, name2, indicator);
									//SymmetricSoftTFIDF(name1, name2, indicator);
									indicatore="SoftTFIDF";
									indicatorl=metricaidf.getIndicatorl();
								    ind = Float.parseFloat(indicatorl);
								    name5=name3-ind;
								    if (name5 <0) {
								    	name5=name5*-1;
								    }
									line=(name0+","+indicatorl+","+indicatore+","+name1+","+name2+","+name3+","+name4+","+name5);
									writer.write(line+"\n");
									
									Metrics metricaqgrm = new Metrics();
									QGramsDistance(name1, name2, indicator);
									indicatore="QGramsDistance";
									indicatorl=metricaqgrm.getIndicatorl();
								    ind = Float.parseFloat(indicatorl);
								    name5=name3-ind;
								    if (name5 <0) {
								    	name5=name5*-1;
								    }
									line=(name0+","+indicatorl+","+indicatore+","+name1+","+name2+","+name3+","+name4+","+name5);
									writer.write(line+"\n");
								}
							//}
					}
					finally {
							System.out.println("Fine scansione - righe lette: " + indx);
							if(st != null)st.close();
							if(writer != null)writer.close();
							if(conn != null) ((OutputStreamWriter) conn).close();
					}

				} catch (ClassNotFoundException e) {
					System.out.println("Driver non trovato !");
					e.printStackTrace();
				}
			}




		private void SoftTFIDFTrain(String name1, String name2, String indicator) throws IOException {
			SoftTFIDFTrain sfttfdftt = new SoftTFIDFTrain(name1, name2, indicator);
			
		}




		private void QGramsDistance(String name1, String name2, String indicator) {
			QGramsDistance qgram = new QGramsDistance(name1, name2);
			qgram.getSimilarity(name1, name2);
		}




		private static void Symmetrics(String name1, String name2, String indicator) throws IOException {
			Symmetrics sym = new Symmetrics(name1, name2, indicator);
	}


		private static void GetProperties() throws IOException {
			PropertyFiles pf = new PropertyFiles();
		}

		private void SymmetricMongeElkan(String name1, String name2, String indicator) throws IOException {
			SymmetricMongeElkan sme = new SymmetricMongeElkan(name1, name2, indicator);
		
	}

		private static void SymmetricSoftTFIDF(String name1, String name2, String indicator) throws IOException {
			SymmetricSoftTFIDF sstfidf = new SymmetricSoftTFIDF(name1, name2, indicator);
		
	}

		
		
}



