package it.ccg.liste.freader.batch;

import java.io.IOException;
import java.sql.SQLException;

public class MainData {
	/**
	 * Main DataFile
	 * @throws IOException 
	 * @throws DocumentException 
	 */
	//public MainData(int returnCode) throws IOException, DocumentException {
		// TODO Auto-generated constructor stub
	
	  private static  int returnCode;
	
	  public static void main(String[] args) throws Exception {
		  System.out.println("Inizio esecuzione <MAIN DATA>");
		  //Train
		    TFIDFCorpus(returnCode);
		  
		  //ResultString
		  ResultString(returnCode);
		  
		  //Lettura db2
		  //ResStrings(returnCode);
		  
		  if (returnCode != 0) {
			 System.out.println("Errore nella fase - verificare !");
		 }
		  System.out.println("Fine esecuzione <MAIN>");
	  }


	private static void TFIDFCorpus(int returnCode) throws IOException, SQLException {
		TFIDFCorpus TFIDFC = new TFIDFCorpus(returnCode);
	}

	private static void ResultString(int returnCode) throws IOException, SQLException {
		ResultString str = new ResultString(returnCode);
	}


	private static void ResStrings(int returnCode) throws IOException, SQLException {
		ResStrings rstr = new ResStrings(returnCode);
	}


	private static void Errore() {
		// TODO Auto-generated method stub
		System.exit(1);
	}


	private static void LoadReq() {
		// TODO Auto-generated method stub
		
	}


	private static void GetProperties() throws IOException {
		PropertyFiles pf = new PropertyFiles();		
	}

}



