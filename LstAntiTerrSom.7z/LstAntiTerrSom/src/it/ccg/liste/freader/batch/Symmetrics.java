package it.ccg.liste.freader.batch;  
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import uk.ac.shef.wit.simmetrics.similaritymetrics.AbstractStringMetric;
import uk.ac.shef.wit.simmetrics.similaritymetrics.EuclideanDistance;
import uk.ac.shef.wit.simmetrics.similaritymetrics.Levenshtein;
import uk.ac.shef.wit.simmetrics.similaritymetrics.MongeElkan;

/**  * Package: uk.ac.shef.wit.simmetrics  * Description: SimpleExample implements a simple example to demonstrate the ease to use a similarity metric.  * Date: 19-Apr-2004  * Time: 14:25:11  *  * @author Sam Chapman <a href="http://www.dcs.shef.ac.uk/~sam/">Website</a>, <a href="mailto:sam@dcs.shef.ac.uk">Email</a>.  */ 
public class Symmetrics {
	private static String currdate;

	private static String sdate =null;
	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

	private static String line;
	
	/**  
	 * * SimMetrics - SimMetrics is a java library of Similarity or Distance  * Metrics, e.g. Levenshtein Distance, that provide float based similarity  * measures between String Data. All metrics return consistant measures  * rather than unbounded similarity scores.  *  * Copyright (C) 2005 Sam Chapman - Open Source Release v1.1  *  * Please Feel free to contact me about this library, I would appreciate  * knowing quickly what you wish to use it for and any criticisms/comments  * upon the SimMetric library.  *  * email:       s.chapman@dcs.shef.ac.uk  * www:         http://www.dcs.shef.ac.uk/~sam/  * www:         http://www.dcs.shef.ac.uk/~sam/stringmetrics.html  *  * address:     Sam Chapman,  *              Department of Computer Science,  *              University of Sheffield,  *              Sheffield,  *              S. Yorks,  *              S1 4DP  *              United Kingdom,  *  * This program is free software; you can redistribute it and/or modify it  * under the terms of the GNU General Public License as published by the  * Free Software Foundation; either version 2 of the License, or (at your  * option) any later version.  *  * This program is distributed in the hope that it will be useful, but  * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY  * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License  * for more details.  *  * You should have received a copy of the GNU General Public License along  * with this program; if not, write to the Free Software Foundation, Inc.,  * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  */  
	/**      * runs a simple example.      
	 * *      * @param args two strings required for comparison      
	 * *      * @see this.usage() in the same source file      
	 * * for more details on the usage instructions      
	 * @param name2 
	 * @param name1 
	 * @param indicator 
	 * @param indicator 
	 * @throws IOException*/ 
	public Symmetrics(String name1, String name2, String indicator) throws IOException {
	//public static void main(final String[] args) { 
		 Metrics metrica = new Metrics(); 
		 Names name = new Names(); 

		//checks for the expected user input  
			if(name1.length() <=0 && (name2.length()<=0)) { 
			//provides usage information to inform the user of the correct way             
			// to work             
			usage();         
			} else {    
				//gets the two input given by the user 
				String str1l = name1;           
				String str2l = name2;              
				//creates the single metric to use - in this case the simple             
				// Levenshtein is used, this is far from recomended as much better             
				// metrics can be employed in most cases, please see the sourceforge             
				// SimMetric forums for advice on the best metric to employ in             
				// differing situations. 
				AbstractStringMetric metricl = new Levenshtein(); 
				// AbstractStringMetric metric = new CosineSimilarity(); 
				//AbstractStringMetric metrice = new EuclideanDistance();             
				//AbstractStringMetric metric = new MongeElkan();              
				//this single line performs the similarity test             

				//System.out.println("Metric types: Levenshtein()");      
				float resultl = metricl.getSimilarity(str1l, str2l);
				String metricimpl = "Metric types: ";
				
				 //outputs the results			Levenshtein()
				outputResult(metricimpl, resultl, metricl, str1l, str2l);
				metrica.setIndicatorl(String.valueOf(resultl));
				indicator=metrica.getIndicatorl();
				//System.out.println("Metrica:indicator"+indicator);

				}     
		}      

	/**      * outputs the result of the metric test.      *      
		* @param result the float result of the metric test      
		* * @param metric the metric itself to provide its description in the output      
		* * @param str1 the first string with which to compare      
		* * @param str2 the second string to compare with the first      */     
	private void outputResult(String metricimpl, final Float indicator, final AbstractStringMetric metric, final String str1, final String str2) { 
		//if (result <1) {
			//System.out.println(">>>Using Metric " + metric.getShortDescriptionString() + " on strings \"" + str1 + "\" & \"" + str2 + "\" gives a similarity score of " + result);      
//		 line = 
//			 ("Metric types"  +metric.getShortDescriptionString() + ", "  + str1+ ", "  + str2);
//		 System.out.println(">>>Using Metric " + metric.getShortDescriptionString() + " on strings \"" + str1 + "\" & \"" + str2 + "\" gives a similarity score of " + indicator);  
		 //}
	}      
	/**      * details the usage of the simple example outputing instructions to the standard output.      */     
	private static void usage() {         
		System.out.println("Performs a rudimentary string metric comparison from the arguments given.\n\tArgs:\n\t\t1) String1 to compare\n\t\t2)String2 to compare\n\n\tReturns:\n\t\tA standard output (command line of the similarity metric with the given test strings, for more details of this simple class please see the SimpleExample.java source file)");     
	} 
	
	
	}

