import java.io.File;




public class CreaXls {
	//Leggere xls
	Workbook workbook = Workbook.getWorkbook(new File("nome_file.xls"));

	Sheet sheet = workbook.getSheet(0);

	Sheet sheet = workbook.getSheet("nome_foglio");

	Cell a = sheet.getCell(0,0);

	Cell b = sheet.getCell(1,1);

	Cell c = sheet.getCell(2,1);


	String stringa1 = a.getContents();

	String stringa2 = b.getContents();

	String stringa3 = c.getContents();





	String stringa = null;
	double numero = 0;
	Date data = null;
	Cell a = sheet.getCell(0,0);Cell b = sheet.getCell(1,1);
	Cell c = sheet.getCell(2,1); 
	if (c.getType() == CellType.DATE){DateCell dc = (DateCell) c;data = dc.getDate();
	}
	if (a.getType() == CellType.LABEL){LabelCell lc = (LabelCell) a;
	stringa = lc.getString();
	}
	if (b.getType() == CellType.NUMBER){NumberCell nc = (NumberCell) b;numero = nc.getValue();
	} 

	getCell(int column, int row)

	workbook.close();
}
