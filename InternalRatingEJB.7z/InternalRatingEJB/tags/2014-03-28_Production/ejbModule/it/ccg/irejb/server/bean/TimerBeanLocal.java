package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Timer;

@Local
public interface TimerBeanLocal {

	public CalculationBean createTimer(CalculationBean bean) throws BackEndException;
	public CalculationBean createOneShotTimer(CalculationBean bean) throws BackEndException;
    public CalculationBean getTimer(String timerType);
	public List<CalculationBean> getAllTimers();
	public void timeout(Timer timer);
	public void deleteTimer(String timerType) throws BackEndException;
	public void deleteAllTimers() throws BackEndException;
}
