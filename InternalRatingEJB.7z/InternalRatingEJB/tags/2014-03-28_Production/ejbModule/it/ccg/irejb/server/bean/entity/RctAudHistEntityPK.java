package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RCTAUDHIST database table.
 * 
 */
@Embeddable
public class RctAudHistEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	 @Temporal( TemporalType.TIMESTAMP)
	@Column(unique=true, nullable=false)
	private java.util.Date audHisDat;

	@Column(unique=true, nullable=false, length=25)
	private String applCode;

    public RctAudHistEntityPK() {
    }
	public java.util.Date getAudHisDat() {
		return this.audHisDat;
	}
	public void setAudHisDat(java.util.Date audHisDat) {
		this.audHisDat = audHisDat;
	}
	public String getApplCode() {
		return this.applCode;
	}
	public void setApplCode(String applCode) {
		this.applCode = applCode;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RctAudHistEntityPK)) {
			return false;
		}
		RctAudHistEntityPK castOther = (RctAudHistEntityPK)other;
		return 
			this.audHisDat.equals(castOther.audHisDat)
			&& this.applCode.equals(castOther.applCode);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.audHisDat.hashCode();
		hash = hash * prime + this.applCode.hashCode();
		
		return hash;
    }
}