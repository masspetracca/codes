package it.ccg.irejb.server.bean;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CalculationBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1425109222882367228L;
	private String type;
	private Date startDateTime;
	private long interval;
	private String user;
	public static final String DAILYRUN = "dailyRun";
	public static final String DAILYRUNONESHOT = "dailyRunOneShot";
	public static final String YEARSETUP = "setUp";
	
	/**
	 * Instantiate a CalculationBean that start now with default interval value (1 day) and type = dailyRun  
	 */
	public CalculationBean(String user){
		//24 hours = 60(min) * 24(hours) = 1440 minutes
		this.interval = (1440 * 1000); //milliseconds
		this.startDateTime = new Date();
		this.type = CalculationBean.DAILYRUN;
		this.user = user;
	}
	
	/**
	 * Instantiate a CalculationBean that start at specified date with specified interval
	 * @param type
	 * @param startDate
	 * @param interval
	 */
	public CalculationBean(String type, Date startDate,long interval,String user){
		this.interval = interval;
		this.startDateTime = startDate;
		this.type = type;
		this.user = user;
	}
	
	/**
	 * Instantiate a CalculationBean that start now with specified interval
	 * @param type
	 * @param interval
	 */
	public CalculationBean(String type,long interval,String user){
		this.interval = interval;
		this.startDateTime = new Date();
		this.type = type;
		this.user = user;
	}
	
	public CalculationBean(String type, Date startDate,String user){
		//24 hours = 60(min) * 24(hours) = 1440 minutes
		this.interval = (1440 * 1000); //milliseconds
		this.startDateTime = startDate;
		this.type = type;
		this.user = user;
	}
	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the startDateTime
	 */
	public Date getStartDateTime() {
		return startDateTime;
	}

	/**
	 * @param startDateTime the startDateTime to set
	 */
	public void setStartDateTime(Date startDateTime) {
		this.startDateTime = startDateTime;
	}

	/**
	 * @return the interval
	 */
	public long getInterval() {
		return interval;
	}

	/**
	 * @param interval the interval to set
	 */
	public void setInterval(long interval) {
		this.interval = interval;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		return "Type: "+this.type+", date: "+format.format(this.startDateTime)+", interval: "+this.interval;
	}
		
}
