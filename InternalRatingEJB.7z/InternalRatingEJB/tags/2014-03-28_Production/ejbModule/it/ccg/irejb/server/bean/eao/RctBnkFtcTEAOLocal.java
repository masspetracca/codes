package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctBnkFtcTEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

public interface RctBnkFtcTEAOLocal {

	public void insertRtcBnkFtc(RctBnkFtcTEntity entity);
    public void deleteRtcBnkFtc(RctBnkFtcTEntity entity);
    public void updateRtcBnkFtc(RctBnkFtcTEntity entity);
    public RctBnkFtcTEntity RtcBnkFtcById(String fitchNname) throws BackEndException ;
	public List<RctBnkFtcTEntity> retrieveBnkFtcTByFitchCode(int fitchCode);
	public List<RctBnkFtcTEntity> retrieveBnkFtcTByAccountingSys(String accountingSystem);
	public List<RctBnkFtcTEntity> retrieveBnkFtcTByLatestPeriod(String latestPeriod) throws BackEndException;
	public List<RctBnkFtcTEntity> retrieveBnkFtcTByIsConsolidated(String isConsolidated);
	public List<RctBnkFtcTEntity> retrieveBnkFtcTForCalculationByFitchCode(int fitchcode);
}
