package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctIssFldEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

public interface RctIssFldEAOLocal {
	
	public void insertIssFld(RctIssFldEntity entity) throws BackEndException;
	public void deleteIssFld(RctIssFldEntity entity) throws BackEndException;
	public void updateIssFld(RctIssFldEntity entity) throws BackEndException;
	public List<RctIssFldEntity> retrieveIssFldByRCode(String rCode) throws BackEndException;
	public List<RctIssFldEntity> retrieveLatestIssFld() throws BackEndException;
	
}
