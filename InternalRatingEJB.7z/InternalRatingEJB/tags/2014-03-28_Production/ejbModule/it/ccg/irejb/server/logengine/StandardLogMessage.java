package it.ccg.irejb.server.logengine;

import it.ccg.irejb.server.security.SecurityEjb;

public class StandardLogMessage {
	
	private String currentUser;
	private String message;
	
	
	public StandardLogMessage(String message) {
		
		try {
			this.currentUser = SecurityEjb.getCurrentUser();
		}
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
		this.message = message;
	}
	
	
	@Override
	public String toString() {
		
		return this.currentUser + "|" + this.message;
	}

}
