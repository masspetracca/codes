package it.ccg.irejb.server.security;

public class AvailableRole {
	
	public static final String ADMIN = "admin";

}
