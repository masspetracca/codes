package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.bean.eao.RctBankEAOLocal;
import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.business.FitchCSVGenerator;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.io.File;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ActiveBanksBean
 */
@Stateless
@Local(ActiveBanksBeanLocal.class)
@Remote(ActiveBanksBeanRemote.class)
public class ActiveBanksBean implements ActiveBanksBeanRemote, ActiveBanksBeanLocal {
	
	private static final Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);

	@EJB
	private RctBankEAOLocal rctBankEAO;
    /**
     * Default constructor. 
     */
    public ActiveBanksBean() {
        // TODO Auto-generated constructor stub
    }

    public List<RctBankEntity> getActiveBanksList() throws BackEndException{
    	ejbLogger.info(new StandardLogMessage("in ActiveBanksBean.getActiveBanksList()"));
    	List<RctBankEntity> activeBanks = null;
    	try {
    		ejbLogger.debug(new StandardLogMessage("retrieveBankByStatus"));
    		activeBanks = rctBankEAO.retrieveBankByStatus("E");
    		ejbLogger.debug(new StandardLogMessage("retrieved "+activeBanks.size()+" banks"));
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
    		throw new BackEndException(e);
		}
    	return activeBanks;
    }
    
    public File getActiveBanksFitchFile() throws BackEndException{
    	ejbLogger.info(new StandardLogMessage("in ActiveBanksBean.getActiveBanksFitchFile()"));
    	List<RctBankEntity> activeBanks = null;
    	try {
    		ejbLogger.debug(new StandardLogMessage("retrieveBankByStatus"));
    		activeBanks = rctBankEAO.retrieveBankByStatus("E");
    		ejbLogger.debug(new StandardLogMessage("retrieved "+activeBanks.size()+" banks"));
    		FitchCSVGenerator fitchGenerator = new FitchCSVGenerator(activeBanks);
    		return fitchGenerator.getFitchCsvFile();
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
    		throw new BackEndException(e);
		}
    }
}
