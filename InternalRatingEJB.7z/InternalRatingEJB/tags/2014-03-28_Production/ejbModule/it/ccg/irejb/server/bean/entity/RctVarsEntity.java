package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the RCTVARS database table.
 * 
 */
@Entity
//@Table(name="PAMPTEST.RCTVARS")
@Table(name="RCTVARS")
@NamedQueries({
	@NamedQuery(name="getRtcVarByVarId", query="SELECT var FROM RctVarsEntity var WHERE var.id.varid = :varid ORDER BY var.vardesc ASC"),
	@NamedQuery(name="getRtcVarByProvider", query="SELECT var FROM RctVarsEntity var WHERE var.id.provider = :provider ORDER BY var.vardesc ASC"),
	@NamedQuery(name="getRtcVarByYearSetup", query="SELECT var FROM RctVarsEntity var WHERE var.yearsetup = :yearsetup ORDER BY var.vardesc ASC"),
	@NamedQuery(name="getRtcVarByStatus", query="SELECT var FROM RctVarsEntity var WHERE var.status = :status ORDER BY var.vardesc ASC"),
	@NamedQuery(name="getRtcVarByDailyRun", query="SELECT var FROM RctVarsEntity var WHERE var.dailyrun = :dailyrun ORDER BY var.vardesc ASC"),
	@NamedQuery(name="getRtcVarForDailyRunCalc", query="SELECT var FROM RctVarsEntity var WHERE var.dailyrun = 'T' and var.status ='E' ORDER BY var.vardesc ASC"),
	@NamedQuery(name="getRtcVar", query="SELECT var FROM RctVarsEntity var ORDER BY var.vardesc ASC")
})
public class RctVarsEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RctVarsEntityPK id;

	@Column(nullable=false, length=1)
	private String dailyrun;

	@Column(nullable=false, length=1)
	private String status;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

	@Column(nullable=false, length=1000)
	private String vardesc;

	@Column(nullable=false, length=1)
	private String yearsetup;

	//bi-directional many-to-one association to RctThrshldEntity
	//@OneToMany(mappedBy="rctvar")
	private Set<RctThrshldEntity> rctthrshlds;

	//bi-directional many-to-one association to RctVarHEntity
	//@OneToMany(mappedBy="rctvar")
	private Set<RctVarHEntity> rctvarhs;

    public RctVarsEntity() {
    }

	public RctVarsEntityPK getId() {
		return this.id;
	}

	public void setId(RctVarsEntityPK id) {
		this.id = id;
	}
	
	public String getDailyrun() {
		return this.dailyrun;
	}

	public void setDailyrun(String dailyrun) {
		this.dailyrun = dailyrun;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

	public String getVardesc() {
		return this.vardesc;
	}

	public void setVardesc(String vardesc) {
		this.vardesc = vardesc;
	}

	public String getYearsetup() {
		return this.yearsetup;
	}

	public void setYearsetup(String yearsetup) {
		this.yearsetup = yearsetup;
	}

	public Set<RctThrshldEntity> getRctthrshlds() {
		return this.rctthrshlds;
	}

	public void setRctthrshlds(Set<RctThrshldEntity> rctthrshlds) {
		this.rctthrshlds = rctthrshlds;
	}
	
	public Set<RctVarHEntity> getRctvarhs() {
		return this.rctvarhs;
	}

	public void setRctvarhs(Set<RctVarHEntity> rctvarhs) {
		this.rctvarhs = rctvarhs;
	}
	
}