package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the RCTISSUES database table.
 * 
 */
@Entity
@Table(name="RCTISSUES")
@NamedQueries({
	@NamedQuery(name="getIssuesByRCode", query="SELECT issue FROM RctIssuesEntity issue WHERE issue.id.rCode= :rCode ORDER BY issue.id.valueDate ASC"),
	@NamedQuery(name="getIssuesByTicker", query="SELECT issue FROM RctIssuesEntity issue WHERE issue.id.rTicker = :rTicker ORDER BY issue.id.valueDate ASC"),
	@NamedQuery(name="getLatestIssuesByTicker", query="SELECT issue " +
			   "										 FROM RctIssuesEntity issue " +
			   "										WHERE issue.id.rTicker= :rTicker" +
			   "										  AND issue.id.valueDate = (SELECT MAX(issue2.id.valueDate) " +
			   "																	  FROM RctIssuesEntity issue2 " +
			   "																	 WHERE issue2.id.rTicker = issue.id.rTicker" +
			   "                                                                       AND issue2.id.rCode = issue.id.rCode) " +
			   " 										ORDER BY issue.id.valueDate ASC")
})
public class RctIssuesEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RctIssuesEntityPK id;

	@Column(nullable=false, length=20)
	private String dsplyName;

	@Column(nullable=false, length=10)
	private String fitchRtg;

	private int fithcTrsc;

	@Column(name="INDSEC", length=20)
	private String indSec;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal matAnalSpr;

	@Column(nullable=false)
	private Timestamp matDate;

	@Column(nullable=false, length=10)
	private String moodRtg;

	private int moodTrsc;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal mtStOtrSpr;

	@Column(nullable=false, length=10)
	private String spRtg;

	private int spTrsc;

	private Timestamp updDate;

	@Column(length=1)
	private String updType;

	@Column(length=30)
	private String updUsr;

    public RctIssuesEntity() {
    }

	public RctIssuesEntityPK getId() {
		return this.id;
	}

	public void setId(RctIssuesEntityPK id) {
		this.id = id;
	}
	
	public String getDsplyName() {
		return this.dsplyName;
	}

	public void setDsplyName(String dsplyName) {
		this.dsplyName = dsplyName;
	}

	public String getFitchRtg() {
		return this.fitchRtg;
	}

	public void setFitchRtg(String fitchRtg) {
		this.fitchRtg = fitchRtg;
	}

	public int getFithcTrsc() {
		return this.fithcTrsc;
	}

	public void setFithcTrsc(int fithcTrsc) {
		this.fithcTrsc = fithcTrsc;
	}

	public String getIndSec() {
		return this.indSec;
	}

	public void setIndSec(String indSec) {
		this.indSec = indSec;
	}

	public BigDecimal getMatAnalSpr() {
		return this.matAnalSpr;
	}

	public void setMatAnalSpr(BigDecimal matAnalSpr) {
		this.matAnalSpr = matAnalSpr;
	}

	public Timestamp getMatDate() {
		return this.matDate;
	}

	public void setMatDate(Timestamp matDate) {
		this.matDate = matDate;
	}

	public String getMoodRtg() {
		return this.moodRtg;
	}

	public void setMoodRtg(String moodRtg) {
		this.moodRtg = moodRtg;
	}

	public int getMoodTrsc() {
		return this.moodTrsc;
	}

	public void setMoodTrsc(int moodTrsc) {
		this.moodTrsc = moodTrsc;
	}

	public BigDecimal getMtStOtrSpr() {
		return this.mtStOtrSpr;
	}

	public void setMtStOtrSpr(BigDecimal mtStOtrSpr) {
		this.mtStOtrSpr = mtStOtrSpr;
	}

	public String getSpRtg() {
		return this.spRtg;
	}

	public void setSpRtg(String spRtg) {
		this.spRtg = spRtg;
	}

	public int getSpTrsc() {
		return this.spTrsc;
	}

	public void setSpTrsc(int spTrsc) {
		this.spTrsc = spTrsc;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUsr() {
		return this.updUsr;
	}

	public void setUpdUsr(String updUsr) {
		this.updUsr = updUsr;
	}

}