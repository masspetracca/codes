package it.ccg.irejb.server.bean.eao;

import java.util.List;

import it.ccg.irejb.server.bean.entity.RctHisRtgEntity;
import it.ccg.irejb.server.exception.BackEndException;

public interface RctHisRtgEAOLocal {
	public void insertHistRtg(RctHisRtgEntity entity) throws BackEndException;
	public void deleteHistRtg(RctHisRtgEntity entity) throws BackEndException;
	public void updateHistRtg(RctHisRtgEntity entity) throws BackEndException;
	public List<RctHisRtgEntity> retrieveRatingByBlombCode(String blombCode) throws BackEndException;
	public List<RctHisRtgEntity> retrieveLatestRatingByBlombCode(String blombCode) throws BackEndException;
}
