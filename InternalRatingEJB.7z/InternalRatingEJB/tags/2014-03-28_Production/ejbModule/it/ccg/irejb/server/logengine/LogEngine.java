package it.ccg.irejb.server.logengine;

import it.ccg.irejb.server.system.SystemProperties;

public class LogEngine {
	
	private static String LOG_FILE_DIR_ABSOLUTE_PATH;


	
	
	
	public static String getLOG_FILE_DIR_ABSOLUTE_PATH() {
		
		if(LOG_FILE_DIR_ABSOLUTE_PATH == null) {
			
			try {
				init();
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return LOG_FILE_DIR_ABSOLUTE_PATH;
	}
	
	
	private static void init() throws Exception {
		
		LOG_FILE_DIR_ABSOLUTE_PATH = SystemProperties.getSystemProperty("user.install.root") +
									 SystemProperties.getSystemProperty("file.separator") +
									 SystemProperties.getSystemProperty("logengine.logdir_rel_path");
		
	}
	

}
