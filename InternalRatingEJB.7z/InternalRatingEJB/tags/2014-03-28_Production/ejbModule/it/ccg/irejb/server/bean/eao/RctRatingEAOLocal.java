package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctRatingEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;
import java.util.Map;

public interface RctRatingEAOLocal {

	public void insertRctRating(RctRatingEntity entity) throws BackEndException;
    public void deleteRctRating(RctRatingEntity entity) throws BackEndException;
    public void updateRctRating(RctRatingEntity entity) throws BackEndException;
    public RctRatingEntity retrieveRatingById(int bankId) throws BackEndException ;
    public Map<Integer, RctRatingEntity> retrieveAllRatings() throws BackEndException;
	public List<RctRatingEntity> retrieveRatingsByBankId(int bankId) throws BackEndException;
	public List<RctRatingEntity> retrieveRatingsByRatingDate(String ratingDate) throws BackEndException;
	public List<RctRatingEntity> retrieveRatingsByStatus(String status) throws BackEndException;
}
