package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.*;

import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the RCTRATING database table.
 * 
 */
@Entity
//@Table(name="RCTRATING", schema="PAMPTEST")
@Table(name="RCTRATING")
@NamedQueries({
	@NamedQuery(name="getRatingByBankId", query="SELECT rating FROM RctRatingEntity rating WHERE rating.bankid = :bankid ORDER BY rating.ratingdate DESC"),
	@NamedQuery(name="getRatingByRatingDate", query="SELECT rating FROM RctRatingEntity rating WHERE rating.ratingdate= :ratingdate ORDER BY rating.ratingdate DESC"),
	@NamedQuery(name="getRatingByStatus", query="SELECT rating FROM RctRatingEntity rating WHERE rating.status = :status ORDER BY rating.ratingdate DESC"),
	@NamedQuery(name="getAllRatings", query="SELECT rating FROM RctRatingEntity rating ORDER BY rating.ratingdate DESC")
})
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class RctRatingEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(unique=true, nullable=false)
	private int bankid;

	@Column(precision=15, scale=8)
	private BigDecimal balancertg;

	@Column(length=1000)
	private String comment;

	@Column(precision=15, scale=8)
	private BigDecimal externrtg;

	@Column(length=1000)
	private String note;

	@Column(precision=15, scale=8)
	private BigDecimal proprtg;

	@Column(nullable=false)
	private Timestamp ratingdate;

	@Column(precision=15, scale=8)
	private BigDecimal spreadrtg;

	@Column(length=1)
	private String status;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

	@Column(precision=15, scale=5)
	private BigDecimal woringkRtg;
	
	//bi-directional one-to-one association to RctBankEntity
	@OneToOne
	@JoinColumn(name="BANKID", nullable=false, insertable=false, updatable=false)
	private RctBankEntity rctbank;

    public RctRatingEntity() {
    }

	/**
	 * @return the bankid
	 */
	public int getBankid() {
		return bankid;
	}

	/**
	 * @param bankid the bankid to set
	 */
	public void setBankid(int bankid) {
		this.bankid = bankid;
	}

	/**
	 * @return the balancertg
	 */
	public BigDecimal getBalancertg() {
		return balancertg;
	}

	/**
	 * @param balancertg the balancertg to set
	 */
	public void setBalancertg(BigDecimal balancertg) {
		this.balancertg = balancertg;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the externrtg
	 */
	public BigDecimal getExternrtg() {
		return externrtg;
	}

	/**
	 * @param externrtg the externrtg to set
	 */
	public void setExternrtg(BigDecimal externrtg) {
		this.externrtg = externrtg;
	}

	/**
	 * @return the note
	 */
	public String getNote() {
		return note;
	}

	/**
	 * @param note the note to set
	 */
	public void setNote(String note) {
		this.note = note;
	}

	/**
	 * @return the proprtg
	 */
	public BigDecimal getProprtg() {
		return proprtg;
	}

	/**
	 * @param proprtg the proprtg to set
	 */
	public void setProprtg(BigDecimal proprtg) {
		this.proprtg = proprtg;
	}

	/**
	 * @return the ratingdate
	 */
	public Timestamp getRatingdate() {
		return ratingdate;
	}

	/**
	 * @param ratingdate the ratingdate to set
	 */
	public void setRatingdate(Timestamp ratingdate) {
		this.ratingdate = ratingdate;
	}

	/**
	 * @return the spreadrtg
	 */
	public BigDecimal getSpreadrtg() {
		return spreadrtg;
	}

	/**
	 * @param spreadrtg the spreadrtg to set
	 */
	public void setSpreadrtg(BigDecimal spreadrtg) {
		this.spreadrtg = spreadrtg;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the upddate
	 */
	public Timestamp getUpddate() {
		return upddate;
	}

	/**
	 * @param upddate the upddate to set
	 */
	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	/**
	 * @return the updtype
	 */
	public String getUpdtype() {
		return updtype;
	}

	/**
	 * @param updtype the updtype to set
	 */
	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	/**
	 * @return the updusr
	 */
	public String getUpdusr() {
		return updusr;
	}

	/**
	 * @param updusr the updusr to set
	 */
	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

	/**
	 * @return the rctbank
	 */
	public RctBankEntity getRctbank() {
		return rctbank;
	}

	/**
	 * @param rctbank the rctbank to set
	 */
	public void setRctbank(RctBankEntity rctbank) {
		this.rctbank = rctbank;
	}
	
	/**
	 * 
	 * @return
	 */
	public BigDecimal getWoringkRtg() {
		return this.woringkRtg;
	}

	/**
	 * 
	 * @param woringkRtg
	 */
	public void setWoringkRtg(BigDecimal woringkRtg) {
		this.woringkRtg = woringkRtg;
	}
}