package it.ccg.irejb.server.util;

import java.util.Random;

public class PasswordGenerator {
	
	private static Random rnd = new Random();
	
	public static String generatePassword(){
		String characters = "qwertyuiopasdfghjklzxcvbnm1234567890QWERTYUIOPASDFGHJKLZXCVBNM";//@_$%-/&\
		String specialChar = "@_$%-&";
		
		StringBuilder sb = new StringBuilder(10);
		for( int i = 0; i < 10; i++ ) {
			sb.append(characters.charAt(rnd.nextInt(characters.length())));
		}
		
		//inserting special character
		sb.insert(rnd.nextInt(sb.length()), specialChar.charAt(rnd.nextInt(specialChar.length())));
		
		return sb.toString();

	}
}
