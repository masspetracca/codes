package it.ccg.irejb.server.ldap;

import javax.ejb.Local;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class LDAPUserBean
 */
@Stateless
@Local(LDAPUserBeanLocal.class)
public class LDAPUserBean implements LDAPUserBeanLocal {

    /**
     * Default constructor. 
     */
    public LDAPUserBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public LDAPUserDTO getLDAPUserByUID(String uid) throws Exception {
		LDAPManager manager = new LDAPManager();
		
		LDAPUserDTO user = manager.getUserByUID(uid);
		
		
		return user;
	}

    
}
