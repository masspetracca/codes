package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctTrscodeEntity;
import it.ccg.irejb.server.bean.entity.RctTrscodeEntityPK;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RctTrscodeEAO
 */
@Stateless
@Local(RctTrscodeEAOLocal.class)
public class RctTrscodeEAO implements RctTrscodeEAOLocal {

	@PersistenceContext
	private EntityManager manager;
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public RctTrscodeEAO() {
        // TODO Auto-generated constructor stub
    }
    
    public void insertRtcTranscode(RctTrscodeEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in insertRtcTranscode(RctTrscodeEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctTrscodeEntity identification data: ranking = "+entity.getId().getRanking()+" provider = "+entity.getId().getProvider()));
    	ejbLogger.debug(new StandardLogMessage("insert"));
    	this.manager.persist(entity);
    }
    
    public void deleteRtcTranscode(RctTrscodeEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in deleteRtcTranscode(RctTrscodeEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctTrscodeEntity identification data: ranking = "+entity.getId().getRanking()+" provider = "+entity.getId().getProvider()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	this.manager.remove(entity);
    }

    public void updateRtcTranscode(RctTrscodeEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in updateRtcTranscode(RctTrscodeEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctTrscodeEntity identification data: ranking = "+entity.getId().getRanking()+" provider = "+entity.getId().getProvider()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	this.manager.merge(entity);
    }
    
    public RctTrscodeEntity retrieveRtcTranscodeById(String ranking,String provider) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in RctTrscodeEntity retrieveRtcTranscodeById(String ranking,String provider) throws BackEndException"));
    	RctTrscodeEntity rating = null;
    		  
    	RctTrscodeEntityPK pk = new RctTrscodeEntityPK();
		pk.setRanking(Integer.parseInt(ranking));
		pk.setProvider(provider);

    	ejbLogger.debug(new StandardLogMessage("Rankoing: "+ranking));
    	ejbLogger.debug(new StandardLogMessage("Provider: "+provider));
    	ejbLogger.debug(new StandardLogMessage("find"));
    	rating = (RctTrscodeEntity)this.manager.find(RctTrscodeEntity.class, pk);
	    	
    	return rating;
    }
    
    //getRtcTranscodeByRtgCode
    @SuppressWarnings("unchecked")
	public List<RctTrscodeEntity> retrieveRtcTranscodeByRtgCode(String rtgCode){
    	ejbLogger.debug(new StandardLogMessage("in List<RctTrscodeEntity> retrieveRtcTranscodeByRtgCode(String rtgCode)"));
    	ejbLogger.debug(new StandardLogMessage("Rtg code: "+rtgCode));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getRatingByBankId");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("rtgcode", rtgCode);
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
		List<RctTrscodeEntity> ratings = (List<RctTrscodeEntity>) q.getResultList();
		
    	return ratings;
    }
    
    //getRtcTranscodeByProvider
    @SuppressWarnings("unchecked")
	public Map<String, RctTrscodeEntity> retrieveMapRtcTranscodeByProvider(String provider){
    	ejbLogger.debug(new StandardLogMessage("in Map<String,RctTrscodeEntity> retrieveMapRtcTranscodeByProvider(String rtgCode)"));
    	ejbLogger.debug(new StandardLogMessage("provider: "+provider));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	Query q = this.manager.createNamedQuery("getRtcTranscodeByProvider");
    	ejbLogger.debug(new StandardLogMessage("populate named query"));
    	q.setParameter("provider", provider);
    	
    	ejbLogger.debug(new StandardLogMessage("getResultList"));
		List<RctTrscodeEntity> ratings = (List<RctTrscodeEntity>) q.getResultList();
		
		Map<String, RctTrscodeEntity> result =new HashMap<String, RctTrscodeEntity>();
		for (RctTrscodeEntity  ent : ratings){
			result.put(ent.getRtgcode(), ent);
		}
		
		return result;
    }
}
