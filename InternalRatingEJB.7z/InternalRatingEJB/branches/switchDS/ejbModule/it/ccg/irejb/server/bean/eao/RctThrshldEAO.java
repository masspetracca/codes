package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctThrshldEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;
import it.ccg.irejb.server.util.ThrshldComparatore;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RctThrshldEAO
 */
@Stateless
@Local(RctThrshldEAOLocal.class)
public class RctThrshldEAO implements RctThrshldEAOLocal {

	@PersistenceContext
	private EntityManager manager;
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
    /**
     * Default constructor. 
     */
    public RctThrshldEAO() {
        // TODO Auto-generated constructor stub
    }

    public void insertRctThreshold(RctThrshldEntity entity) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in insertRctThreshold(RctThrshldEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctThrshldEntity identification data: thresholdId = "+entity.getThrsholdid()+" threshold date = "+entity.getThrshlddte()+" var id ="+entity.getVarid()));
    	ejbLogger.debug(new StandardLogMessage("insert"));
    	try{
	    	this.manager.persist(entity);
	    }catch (Exception e) {
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    public void deleteRctThreshold(RctThrshldEntity entity) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in deleteRctThreshold(RctThrshldEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctThrshldEntity identification data: thresholdId = "+entity.getThrsholdid()+" threshold date = "+entity.getThrshlddte()+" var id ="+entity.getVarid()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	try{
	    	this.manager.remove(entity);
	    }catch (Exception e) {
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    public void updateRctThreshold(RctThrshldEntity entity) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in updateBank(RctBankEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctThrshldEntity identification data: thresholdId = "+entity.getThrsholdid()+" threshold date = "+entity.getThrshlddte()+" var id ="+entity.getVarid()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	try{
	    	this.manager.merge(entity);
	    }catch (Exception e) {
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    public RctThrshldEntity retrieveThresholdById(int varId,int thresholdId,String thresholdDate) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in RctIfpRtgHEntity retrieveRatingHistoryById(String bankId,String provider,String rtgType,String lstUpdDate)"));
    	RctThrshldEntity threshold = null;
    	try {
    		    	
			Date thrshldDate = this.df.parse(thresholdDate);
			RctThrshldEntity entity = new RctThrshldEntity();
			entity.setVarid(varId);
			entity.setThrsholdid(thresholdId);
			entity.setThrshlddte(new Timestamp(thrshldDate.getTime()));
			
	    	ejbLogger.debug(new StandardLogMessage("Var identification ID: "+varId));
	    	ejbLogger.debug(new StandardLogMessage("Threshold id : "+thresholdId));
	    	ejbLogger.debug(new StandardLogMessage("Threshold date: "+thresholdDate));
	    	ejbLogger.debug(new StandardLogMessage("find"));
	    	
	    	threshold = (RctThrshldEntity)this.manager.find(RctThrshldEntity.class, entity);
	    	return threshold;
    	}catch (Exception e) {
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    //getThrshldByVarId
    @SuppressWarnings("unchecked")
	public List<RctThrshldEntity> retrieveSortedThresholdByVarId(int varId) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in List<RctThrshldEntity> retrieveThresholdByVarId(String varId)"));
    	ejbLogger.debug(new StandardLogMessage("Var id: "+varId));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	try{
    		Query q = this.manager.createNamedQuery("getThrshldByVarId");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("varid", varId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctThrshldEntity> appo = (List<RctThrshldEntity>) q.getResultList();
			
			List<RctThrshldEntity> results = new ArrayList<RctThrshldEntity>();
			RctThrshldEntity elseEnt=null;
			RctThrshldEntity naEnt=null;
			for (RctThrshldEntity ent : appo){
				if (!ent.getThrshldop().equalsIgnoreCase("else") && !ent.getThrshldop().equalsIgnoreCase("NA")){
					results.add(ent);
				}else{
					if (ent.getThrshldop().equalsIgnoreCase("else")){
						elseEnt = ent;
					}else{
						naEnt = ent;
					}
				}	
			}
			Collections.sort(results,new ThrshldComparatore());
 			
			results.add(elseEnt);
			results.add(naEnt);
	    	return results;
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    //getThrshldByThrshldDate
    @SuppressWarnings("unchecked")
	public List<RctThrshldEntity> retrieveThresholdByThrshldDate(String thrshldDate) throws BackEndException{
       	ejbLogger.debug(new StandardLogMessage("in List<RctThrshldEntity> retrieveThresholdByThrshldDate(String provider)"));
       	List<RctThrshldEntity> ratings = null;
       	try {
       		ejbLogger.debug(new StandardLogMessage("thrshldDate : "+thrshldDate));
           	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
           	Query q = this.manager.createNamedQuery("getThrshldByThrshldDate");
           	ejbLogger.debug(new StandardLogMessage("populate named query"));
			q.setParameter("thrshlddte", df.parse(thrshldDate));
			ejbLogger.debug(new StandardLogMessage("getResultList"));
			ratings = (List<RctThrshldEntity>) q.getResultList();
			return ratings;
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
    
    //getThrshldByThrshldId
    @SuppressWarnings("unchecked")
	public List<RctThrshldEntity> retrieveThresholdByThrshldId(String thrshldId) throws BackEndException{
    	try{
	       	ejbLogger.debug(new StandardLogMessage("in List<RctThrshldEntity> retrieveThresholdByThrshldId(String thrshldId)"));
	       	ejbLogger.debug(new StandardLogMessage("Threshold ID : "+thrshldId));
	       	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	       	Query q = this.manager.createNamedQuery("getThrshldByThrshldId");
	       	ejbLogger.debug(new StandardLogMessage("populate named query"));
	       	q.setParameter("thrsholdid", thrshldId);
	       	
	       	ejbLogger.debug(new StandardLogMessage("getResultList"));
	   		List<RctThrshldEntity> ratings = (List<RctThrshldEntity>) q.getResultList();
	   		
	       	return ratings;
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
     } 
  
    public List<RctThrshldEntity> retrieveThresholdByVarIdForCalc(int varId) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in List<RctThrshldEntity> retrieveThresholdByVarIdForCalc(int varId)"));
    	ejbLogger.debug(new StandardLogMessage("Var id: "+varId));
    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
    	try{
    	Query q = this.manager.createNamedQuery("getThrshldByVarIdForCalc");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("varid", varId);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctThrshldEntity> ratings = (List<RctThrshldEntity>) q.getResultList();
			
	    	return ratings;
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
}
