package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the RCTISSFLD database table.
 * 
 */
@Entity
//@Table(name="PAMPTEST.RCTISSFLD")
@Table(name="RCTISSFLD")
@NamedQueries({
	@NamedQuery(name="getIssFldByRCode", query="SELECT issFld FROM RctIssFldEntity issFld WHERE issFld.id.rCode= :rCode ORDER BY issFld.id.valueDate ASC"),
	@NamedQuery(name="getLatestIssFld", query="SELECT issFld " +
			   "								 FROM RctIssFldEntity issFld " +
			   "								WHERE issFld.id.valueDate = (SELECT MAX(issFld2.id.valueDate) " +
			   "															  FROM RctIssFldEntity issFld2 " +
			   "															 WHERE issFld2.id.rCode = issFld.id.rCode) " +
			   " 								ORDER BY issFld.id.valueDate ASC")
})
public class RctIssFldEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RctIssFldEntityPK id;

	private int avrgRtg;

	@Column(nullable=false, length=20)
	private String dsplyName;

	@Column(nullable=false, length=10)
	private String fitchRtg;

	private int fithcTrsc;

	@Column(name="INDSEC", length=20)
	private String indSec;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal matAnalSpr;

	@Column(nullable=false)
	private Timestamp matDate;

	@Column(nullable=false, length=10)
	private String moodRtg;

	private int moodTrsc;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal mtStOtrSpr;

	@Column(nullable=false, length=10)
	private String spRtg;

	private int spTrsc;

	private Timestamp updDate;

	@Column(length=1)
	private String updType;

	@Column(length=30)
	private String updUsr;

    public RctIssFldEntity() {
    }

	public RctIssFldEntityPK getId() {
		return this.id;
	}

	public void setId(RctIssFldEntityPK id) {
		this.id = id;
	}
	
	public int getAvrgRtg() {
		return this.avrgRtg;
	}

	public void setAvrgRtg(int avrgRtg) {
		this.avrgRtg = avrgRtg;
	}

	public String getDsplyName() {
		return this.dsplyName;
	}

	public void setDsplyName(String dsplyName) {
		this.dsplyName = dsplyName;
	}

	public String getFitchRtg() {
		return this.fitchRtg;
	}

	public void setFitchRtg(String fitchRtg) {
		this.fitchRtg = fitchRtg;
	}

	public int getFithcTrsc() {
		return this.fithcTrsc;
	}

	public void setFithcTrsc(int fithcTrsc) {
		this.fithcTrsc = fithcTrsc;
	}

	public String getIndSec() {
		return this.indSec;
	}

	public void setIndSec(String indSec) {
		this.indSec = indSec;
	}

	public BigDecimal getMatAnalSpr() {
		return this.matAnalSpr;
	}

	public void setMatAnalSpr(BigDecimal matAnalSpr) {
		this.matAnalSpr = matAnalSpr;
	}

	public Timestamp getMatDate() {
		return this.matDate;
	}

	public void setMatDate(Timestamp matDate) {
		this.matDate = matDate;
	}

	public String getMoodRtg() {
		return this.moodRtg;
	}

	public void setMoodRtg(String moodRtg) {
		this.moodRtg = moodRtg;
	}

	public int getMoodTrsc() {
		return this.moodTrsc;
	}

	public void setMoodTrsc(int moodTrsc) {
		this.moodTrsc = moodTrsc;
	}

	public BigDecimal getMtStOtrSpr() {
		return this.mtStOtrSpr;
	}

	public void setMtStOtrSpr(BigDecimal mtStOtrSpr) {
		this.mtStOtrSpr = mtStOtrSpr;
	}

	public String getSpRtg() {
		return this.spRtg;
	}

	public void setSpRtg(String spRtg) {
		this.spRtg = spRtg;
	}

	public int getSpTrsc() {
		return this.spTrsc;
	}

	public void setSpTrsc(int spTrsc) {
		this.spTrsc = spTrsc;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUsr() {
		return this.updUsr;
	}

	public void setUpdUsr(String updUsr) {
		this.updUsr = updUsr;
	}
}