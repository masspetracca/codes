package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctRiskComEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RctRiskComEAO
 */
@Stateless
@Local(RctRiskComEAOLocal.class)
public class RctRiskComEAO implements RctRiskComEAOLocal {

	@PersistenceContext
	private EntityManager manager;
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
	private DateFormat df = new SimpleDateFormat("yyyy/mm/dd");
    /**
     * Default constructor. 
     */
    public RctRiskComEAO() {
        // TODO Auto-generated constructor stub
    }
    
    public void insertRiskCommittee(RctRiskComEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in insertRiskCommittee(RctRiskComEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctRiskComEntity identification data: rccode = "+entity.getRccode()));
    	ejbLogger.debug(new StandardLogMessage("insert"));
    	this.manager.persist(entity);
    }
    
    public void deleteRiskCommittee(RctRiskComEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in deleteRiskCommittee(RctRiskComEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctRiskComEntity identification data: rccode = "+entity.getRccode()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	this.manager.remove(entity);
    }
    
    public void updateRiskCommittee(RctRiskComEntity entity){
    	ejbLogger.debug(new StandardLogMessage("in updateBank(RctBankEntity entity)"));
    	ejbLogger.debug(new StandardLogMessage("RctRiskComEntity identification data: rccode = "+entity.getRccode()));
    	ejbLogger.debug(new StandardLogMessage("delete"));
    	this.manager.merge(entity);
    }
    
    public RctRiskComEntity retrieveRiskCommitteeById(String rcCode){
    	ejbLogger.debug(new StandardLogMessage("in RctRiskComEntity retrieveRiskCommitteeById(String rcCode)"));
    	ejbLogger.debug(new StandardLogMessage("Bank identification rccode: "+rcCode));
    	ejbLogger.debug(new StandardLogMessage("find"));
    	RctRiskComEntity com = (RctRiskComEntity)this.manager.find(RctRiskComEntity.class, Integer.parseInt(rcCode));
    	return com;
    }
    
    //getRiskComByRcDate
    @SuppressWarnings("unchecked")
	public List<RctRiskComEntity> retrieveRiskCommitteeByRcDate(String rcDate) throws BackEndException{
    	ejbLogger.debug(new StandardLogMessage("in List<RctRiskComEntity> retrieveRiskCommitteeByRcDate(String rcDate) throws BackEndException"));
    	List<RctRiskComEntity> committee = null;
    	try {
			Date riskCommDate = this.df.parse(rcDate);
			ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getRiskComByRcDate");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("rcdate", riskCommDate);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
	    	committee = (List<RctRiskComEntity>) q.getResultList();
		} catch (ParseException e) {
			ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
				
    	return committee;
    }
    
}
