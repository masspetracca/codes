package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.bean.entity.RctRatingEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;
import java.util.Map;

public interface MarketRatingCalculationsBeanLocal {

	public Map<Integer,RctRatingEntity> dailyRun(List<RctBankEntity> rctBanks,Map<Integer,RctRatingEntity> ratings) throws BackEndException;
	public void setUp() throws BackEndException;
}
