<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chk_Medicaid</name>
   <tag></tag>
   <elementGuidId>a9ef1a35-94ae-4c4e-bc9f-a4290a17ff33</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>radio_program_medicaid</value>
   </webElementProperties>
</WebElementEntity>
