<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chk_None</name>
   <tag></tag>
   <elementGuidId>0ca90087-4c70-4ce8-b79b-b0dfca22ae31</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>radio_program_none</value>
   </webElementProperties>
</WebElementEntity>
