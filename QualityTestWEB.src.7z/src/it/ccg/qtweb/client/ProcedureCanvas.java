package it.ccg.qtweb.client;

import it.ccg.qtweb.client.rpc.Json2POJO;
import it.ccg.qtweb.client.rpc.MyRPCRequest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.Window.Location;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.ListGridFieldType;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.FormItem;
import com.smartgwt.client.widgets.form.fields.events.ChangedEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangedHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;


public class ProcedureCanvas extends Canvas {
	
	private FormItem testRunnerResultFolderItem;
	private ListGrid testRunnerResultGrid;
	
	private static Map<String, String> testRunnerConfig;
	
	
	public ProcedureCanvas() {
		
		super();
		
		this.setWidth100();
		this.setHeight100();
		
		VLayout vLayout = new VLayout();
		vLayout.setMembersMargin(30);
		vLayout.setLayoutTopMargin(15);
		
		vLayout.addMember(this.createTestRunnerForm());
		vLayout.addMember(this.createXMLLayout());
		
		
		this.addChild(vLayout);
		
	}
	
	
	private VLayout createTestRunnerForm() {
		
		VLayout vLayoutMain = new VLayout();
		
		VLayout vLayoutOutside = new VLayout();
		vLayoutOutside.setMembersMargin(10);
		vLayoutOutside.setBorder("1px solid grey");
		vLayoutOutside.setWidth(1000);
		
		VLayout vLayoutInside = new VLayout();
		vLayoutInside.setMargin(20);
		
		vLayoutOutside.addMember(vLayoutInside);
		

		Label label = new Label("<nobr>TestRunner procedure</nobr>");
		label.setHeight(20);
		
		vLayoutMain.addMember(label);
		vLayoutMain.addMember(vLayoutOutside);
		
		
		final DynamicForm form1 = new DynamicForm();
        
		/*FormItem fileRootItem = new FormItem("fileRoot");
		fileRootItem.setType("text");*/
		
		final FormItem testRootItem = new FormItem("testRoot");
		testRootItem.setType("text");
		testRootItem.setDefaultValue("");
		testRootItem.setWidth(250);
		
		Label filesGridLabel = new Label("Files");
		filesGridLabel.setHeight(20);
		
		/*FormItem filesItem = new FormItem("files");
		filesItem.setType("text");*/
		final ListGrid filesGrid = new ListGrid();
		filesGrid.setTitleField("Files");
		filesGrid.setHeight(200);
		filesGrid.setWidth(400);
		filesGrid.setShowHeader(false);
	    ListGridField checkField = new ListGridField("check", "Check");
	    checkField.setType(ListGridFieldType.BOOLEAN);
	    checkField.setCanEdit(true);
	    ListGridField nameField = new ListGridField("name", "Name");
	    nameField.setAttribute("primaryKey", true);
	    filesGrid.setFields(checkField, nameField);
	    
	    testRootItem.addChangedHandler(new ChangedHandler() {
			
			@Override
			public void onChanged(ChangedEvent event) {
				
				// read folder content
		        Map<String, Object> params = new HashMap<String, Object>();
				params.put("_operationId", "readFolder");
				params.put("folderName", testRootItem.getValue());
				
		        MyRPCRequest rpcRequest = new MyRPCRequest("ReadFolderServlet", params);
				
				RPCManager.sendRequest(rpcRequest, new RPCCallback() {
					
					@Override
					public void execute(RPCResponse response, Object rawData, RPCRequest request) {
						
						// clear table
						filesGrid.setData(new Record[0]);
						
						String[] fileArray = Json2POJO.getMap(response).get("fileList").split(",");
						
						ListGridRecord[] records = new ListGridRecord[fileArray.length];
						for(int i=0; i< records.length; i++) {
							
							ListGridRecord record = new ListGridRecord();
							record.setAttribute("check", true);
							record.setAttribute("name", fileArray[i].trim());
							
							records[i] = record;
							
						}
						
						
						filesGrid.setData(records);
						
					}
				});
		        
				
			}
		});
	    
	    
	    // add elements to form1
	    form1.setFields(/*fileRootItem, */testRootItem);
        
	    
	    final DynamicForm form2 = new DynamicForm();
		
	    final FormItem browserItem = new FormItem("browser");
		browserItem.setType("text");
		
		final FormItem httpTargetItem = new FormItem("httpTarget");
		httpTargetItem.setType("text");
		
		final FormItem httpPortItem = new FormItem("httpPort");
		httpPortItem.setType("text");
		
		final FormItem captureScreenshotItem = new FormItem("captureScreenshot");
		captureScreenshotItem.setType("boolean");
		
		final FormItem maximizeBrowserItem = new FormItem("maximizeBrowser");
		maximizeBrowserItem.setType("boolean");
		
		final FormItem batchCommitItem = new FormItem("batchCommit");
		batchCommitItem.setType("boolean");
		
		final FormItem saveMessagesItem = new FormItem("saveMessages");
		saveMessagesItem.setType("boolean");
		
		final FormItem seleniumTimeoutItem = new FormItem("seleniumTimeout");
		seleniumTimeoutItem.setType("text");
		
		final FormItem branchItem = new FormItem("branch");
		branchItem.setType("text");
		branchItem.setHint("<nobr>Use this field to set the TestSuite name</nobr>");
		
		final FormItem batchLogItem = new FormItem("batchLog");
		batchLogItem.setType("text");
		
		
		// add elements to form2
        form2.setFields(browserItem, httpTargetItem, httpPortItem, captureScreenshotItem, maximizeBrowserItem, batchCommitItem, saveMessagesItem, seleniumTimeoutItem, branchItem, batchLogItem);
        
        // read current settings
        Map<String, Object> params = new HashMap<String, Object>();
		params.put("_operationId", "readConfig");
		
        MyRPCRequest rpcRequest = new MyRPCRequest("TestRunnerServlet", params);
		
		RPCManager.sendRequest(rpcRequest, new RPCCallback() {
			
			@Override
			public void execute(RPCResponse response, Object rawData, RPCRequest request) {
				
				try {
					
					final Map<String, String> values = Json2POJO.getMap(response);
					
					testRootItem.setValue(values.get("testRoot"));
					browserItem.setValue(values.get("browser"));
					httpTargetItem.setValue(values.get("httpTarget"));
					httpPortItem.setValue(values.get("httpPort"));
					captureScreenshotItem.setValue(values.get("captureScreenshot"));
					maximizeBrowserItem.setValue(values.get("maximizeBrowser"));
					batchCommitItem.setValue(values.get("batchCommit"));
					saveMessagesItem.setValue(values.get("saveMessages"));
					seleniumTimeoutItem.setValue(values.get("seleniumTimeout"));
					branchItem.setValue(values.get("branch"));
					batchLogItem.setValue(values.get("batchLog"));
					
					
					// for files
					// read folder content
			        Map<String, Object> params = new HashMap<String, Object>();
					params.put("_operationId", "readFolder");
					params.put("folderName", testRootItem.getValue());
					
			        MyRPCRequest rpcRequest = new MyRPCRequest("ReadFolderServlet", params);
					
					RPCManager.sendRequest(rpcRequest, new RPCCallback() {
						
						@Override
						public void execute(RPCResponse response, Object rawData, RPCRequest request) {
							
							// clear table
							filesGrid.setData(new Record[0]);
							
							String[] totalFiles = Json2POJO.getMap(response).get("fileList").split(",");
							
							String[] returnedFiles = values.get("files").split(",");
							
							ListGridRecord[] records = new ListGridRecord[totalFiles.length];
							for(int i=0; i< records.length; i++) {
								
								ListGridRecord record = new ListGridRecord();
								if(Arrays.asList(returnedFiles).contains(totalFiles[i].trim())) {
									
									record.setAttribute("check", true);
								}
								else {
									
									record.setAttribute("check", false);
								}
								record.setAttribute("name", totalFiles[i].trim());
								
								records[i] = record;
								
							}
							
							
							filesGrid.setData(records);
							
						}
					});
					
					
					
				}
				catch (Exception e) {
					
					SC.warn(e.toString());
				}
				
			}
		});
        
        
        
        // buttons
        HLayout buttonHLayout = new HLayout();
        buttonHLayout.setMembersMargin(10);
        buttonHLayout.setLayoutTopMargin(15);
        
        IButton startTestRunnerButton = new IButton("Start TestRunner", new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				// *** SAVE SETTINGS ***
				
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("_operationId", "saveConfig");
				params.put("batchCommit", batchCommitItem.getValue());
				params.put("batchLog", batchLogItem.getValue());
				params.put("branch", branchItem.getValue());
				params.put("browser", browserItem.getValue());
				params.put("captureScreenshot", captureScreenshotItem.getValue());
				
				String files = new String();
				
				ListGridRecord[] records = filesGrid.getRecords();
				
				
				if(records.length > 0) {
					
					for(ListGridRecord record : filesGrid.getRecords()) {
						
						if(record.getAttributeAsBoolean("check")) {
							 
							files += record.getAttribute("name") + ",";
						}
						
					}
					
					if(files.length() > 0) {
						
						files = files.substring(0, files.length() - 1);
					}
					
				}
				params.put("files", files);
				
				params.put("httpPort", httpPortItem.getValue());
				params.put("httpTarget", httpTargetItem.getValue());
				params.put("maximizeBrowser", maximizeBrowserItem.getValue());
				params.put("saveMessages", saveMessagesItem.getValue());
				params.put("seleniumTimeout", seleniumTimeoutItem.getValue());
				params.put("testRoot", testRootItem.getValue());
				
				MyRPCRequest rpcRequest = new MyRPCRequest("TestRunnerServlet", params);
				
				RPCManager.sendRequest(rpcRequest, new RPCCallback() {
					
					@Override
					public void execute(RPCResponse response, Object rawData, RPCRequest request) {
						
						// *** START TESTRUNNER *** 
						
						Map<String, Object> params = new HashMap<String, Object>();
						params.put("_operationId", "run");
						
						MyRPCRequest rpcRequest = new MyRPCRequest("TestRunnerServlet", params);
						
						RPCManager.sendRequest(rpcRequest, new RPCCallback() {
							
							@Override
							public void execute(RPCResponse response, Object rawData, RPCRequest request) {
								
								Map<String, String> responseData = Json2POJO.getMap(response);
								String folder = responseData.get("resultSubFolderAbsolutePath");
								
								
								// folder name
								testRunnerResultFolderItem.setValue(folder);
								
								// list generated output
								Map<String, Object> params = new HashMap<String, Object>();
								params.put("_operationId", "readFolder");
								params.put("folderName", folder);
								
						        MyRPCRequest rpcRequest = new MyRPCRequest("ReadFolderServlet", params);
								
								RPCManager.sendRequest(rpcRequest, new RPCCallback() {
									
									@Override
									public void execute(RPCResponse response, Object rawData, RPCRequest request) {
										
										// clear table
										testRunnerResultGrid.setData(new Record[0]);
										
										String[] files = Json2POJO.getMap(response).get("fileList").split(",");
										List<String> rctestFiles = new ArrayList<String>();
										for(String file : files) {
											
											if(file.contains(".rctest.")) {
												
												rctestFiles.add(file);
											}
										}
										
										ListGridRecord[] records = new ListGridRecord[rctestFiles.size()];
										for(int i=0; i< records.length; i++) {
											
											ListGridRecord record = new ListGridRecord();
											record.setAttribute("check", true);
											record.setAttribute("name", rctestFiles.get(i).trim());
											
											records[i] = record;
											
										}
										
										
										testRunnerResultGrid.setData(records);
										
									}
								});
								
							}
						});
						
						
					}
				});
				
				
				
			}
		});
        
        
        buttonHLayout.setMembers(startTestRunnerButton);
        
        
        vLayoutInside.setMembers(form1, filesGridLabel, filesGrid, form2, buttonHLayout);
        
        
        return vLayoutMain;
		
	}
	
	
	private VLayout createXMLLayout() {
		
		VLayout vLayoutMain = new VLayout();
		
		VLayout vLayoutOutside = new VLayout();
		vLayoutOutside.setMembersMargin(10);
		vLayoutOutside.setBorder("1px solid grey");
		vLayoutOutside.setWidth(1000);
		
		VLayout vLayoutInside = new VLayout();
		vLayoutInside.setMargin(20);
		
		vLayoutOutside.addMember(vLayoutInside);
		
		
		Label label1 = new Label("XML procedure");
		label1.setHeight(20);
		

		vLayoutMain.addMember(label1);
		vLayoutMain.addMember(vLayoutOutside);
		
		
		Label gridLabel = new Label("Results from TestRunner procedure");
		gridLabel.setHeight(20);
		
		//
		this.testRunnerResultFolderItem =  new FormItem("Output folder");
		this.testRunnerResultFolderItem.setType("text");
		this.testRunnerResultFolderItem.setCanEdit(false);
		this.testRunnerResultFolderItem.setWidth(250);
		DynamicForm form = new DynamicForm();
		form.setItems(this.testRunnerResultFolderItem);
		
		// file grid
		this.testRunnerResultGrid = new ListGrid();
		this.testRunnerResultGrid.setHeight(200);
		this.testRunnerResultGrid.setWidth(400);
		this.testRunnerResultGrid.setShowHeader(false);
		
		ListGridField checkField = new ListGridField("check", "Check");
	    checkField.setType(ListGridFieldType.BOOLEAN);
	    checkField.setCanEdit(true);
	    ListGridField nameField = new ListGridField("name", "Name");
	    this.testRunnerResultGrid.setFields(checkField, nameField);
	    
	    // buttons
	    HLayout buttonHLayout = new HLayout();
	    buttonHLayout.setMembersMargin(10);
	    buttonHLayout.setLayoutTopMargin(15);
	    
	    IButton makeXMLButton = new IButton("Make XML", new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				// TODO:
				/*if(testRunnerResultGrid.getSelectedRecord() == null) {
					
					SC.warn("No file selected.");
					
					return;
				}
				
				
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("_operationId", "makeXML");
				
				MyRPCRequest rpcRequest = new MyRPCRequest("TestRunnerServlet", params);
				
				RPCManager.sendRequest(rpcRequest, new RPCCallback() {
					
					@Override
					public void execute(RPCResponse response, Object rawData, RPCRequest request) {
						// TODO Auto-generated method stub
						
					}
				});*/
				
				
				// TODO: temp
				
				Window.open(Location.getPath() + "files/Selenium_tests.xml", "_blank", null);
				
				
			}
		});
	    
	    buttonHLayout.setMembers(makeXMLButton);
	    
		
	    vLayoutInside.setMembers(gridLabel, form, this.testRunnerResultGrid, buttonHLayout);
		
	    
		return vLayoutMain;
	}
	
	
	private native String getFileNames(Element input) /*-{

	    var result = "";
	
	    // microsoft support
	    if((typeof (input.files) == 'undefined') || (typeof (input.files.length) == 'undefined')) {
	        
	        return input.value;
	    }
	
	    for(var i=0; i<input.files.length; i++) {
	        
	        if(i > 0) {
	            
	            result += ",";
	        }
	        
	        result += input.files[i].name;
	    }
	    
	    
	    return ret;
	    
	}-*/;
	
	

}

