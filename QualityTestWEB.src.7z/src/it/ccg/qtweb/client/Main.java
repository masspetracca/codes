package it.ccg.qtweb.client;

import it.ccg.qtweb.client.rpc.MyRPCCallback;
import it.ccg.qtweb.client.rpc.MyRPCRequest;
import it.ccg.qtweb.client.security.UserData;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONValue;
import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window.Location;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;

public class Main implements EntryPoint {

	@Override
	public void onModuleLoad() {
		
		// Login check
		// If user does not login, server does not generate LTPA token
		if(Cookies.getCookie("LtpaToken2") == null) {
			
			Location.assign(Location.getPath() + "login.jsp");
			
			return;
		}
		
		// Expired session/LTPA token check
		Timer sessionExpiredCheckTimer = new Timer() {
			
			@Override
			public void run() {
				
				// Expired session check
				// If session is expired, server destroys the login generated LTPA token and FORWARDS to login page.
				// At this time (login page RPC), LTPA token does not exist.
				if(Cookies.getCookie("LtpaToken2") == null) {
					
					Location.assign(Location.getPath() + "login.jsp");
					
					return;
				}
				
				// Expired LTPA token check
				// If LTPA token is expired, WebSphere REDIRECTS to login page (through the "Location" response header) 
				// forces the client to set the WASReqURL cookie (through the "Set-cookie" response header)
				// source: http://www-01.ibm.com/support/docview.wss?uid=swg21422980
				if(Cookies.getCookie("WASReqURL") != null) {
					
					Location.assign(Location.getPath() + "login.jsp");
					
					return;
				}
				
			}
		};
		
		sessionExpiredCheckTimer.scheduleRepeating(5*1000);
		
		
		// get user info
		MyRPCRequest rpcRequest = new MyRPCRequest("servlet/UserInfo", null);
		
		RPCManager.sendRequest(rpcRequest, new MyRPCCallback() {
			
			@Override
			protected void onSuccess(RPCResponse response, Object rawData, RPCRequest request) {
				
				@SuppressWarnings("deprecation")
				JSONValue jsonValue = JSONParser.parse(response.getAttributeAsString("httpResponseText"));
				
				JSONObject jsonObject = jsonValue.isObject();
				
				String cn = jsonObject.get("cn").isString().stringValue();
				
				String rolesString = jsonObject.get("roles").isString().stringValue();
				String[] rolesArray = rolesString.split("\\|");
				List<String> userRolesList = new ArrayList<String>();
				for(String role : rolesArray) {
					
					userRolesList.add(role);
				}
				
				UserData.setCurrentUserData(new UserData(cn, userRolesList));
				
				
				// *** START ***
				MainLayout.getInstance().draw();
				
			}
			
			@Override
			protected void onError(RPCResponse response, Object rawData, RPCRequest request) {
				
				SC.warn("Unable to load user info.", new BooleanCallback() {
					
					@Override
					public void execute(Boolean value) {
						
						Location.assign(Location.getPath() + "login.jsp");
						
					}
				});
				
			}

		});
	
		
	}

}
