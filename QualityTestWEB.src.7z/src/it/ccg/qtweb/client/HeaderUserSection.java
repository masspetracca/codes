package it.ccg.qtweb.client;



import it.ccg.qtweb.client.rpc.MyRPCCallback;
import it.ccg.qtweb.client.rpc.MyRPCRequest;
import it.ccg.qtweb.client.security.UserData;

import java.util.List;

import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.LinkItem;
import com.smartgwt.client.widgets.form.fields.events.ClickEvent;
import com.smartgwt.client.widgets.form.fields.events.ClickHandler;
import com.smartgwt.client.widgets.layout.VLayout;


public class HeaderUserSection extends Canvas {
	
	
	public HeaderUserSection() {
		
		super();
		
		this.setWidth("10%");
		
		DynamicForm dynamicForm = new DynamicForm();
		dynamicForm.setNumCols(1);
		dynamicForm.setItems(this.createAccountLink());
		
		dynamicForm.setTop(10);
		
		this.addChild(dynamicForm);
		
	}
	
	
	
	private LinkItem createAccountLink() {
		
		LinkItem accountLink = new LinkItem();
		
		accountLink.setShowTitle(false);
		
		accountLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(Window.getById("_AccountWindow") != null) {
					
					MainLayout.getMainLayout().removeChild(Window.getById("_AccountWindow"));
					
					Window.getById("_AccountWindow").destroy();
				}
				
				
				Window accountWindow = createAccountWindow();
				
				accountWindow.setLeft(MainLayout.getMainLayout().getWidth() - 200);
				MainLayout.getMainLayout().addChild(accountWindow);
				
			}
			
		});
		
		
		List<String> currentUserRolesList = UserData.getCurrentUserData().getUserRolesList();
		
		String rolesString = "";
		for(String role : currentUserRolesList) {
			rolesString += role + ", ";
		}
		rolesString = rolesString.substring(0, rolesString.length() - 2);
		
		//
		accountLink.setLinkTitle("<font color=\"005596\"><b>" + UserData.getCurrentUserData().getCn() + "</b> " + "(" + rolesString + ")"+"</font>");
		
		
		return accountLink;
	}
	
	
	private Window createAccountWindow() {
		
		final Window accountWindow = new Window();
		
		accountWindow.setID("_AccountWindow");
		accountWindow.setTop(45);
		
		accountWindow.setWidth(180);
		accountWindow.setHeight(110);
		
		accountWindow.setShowHeader(false);
		accountWindow.setShowEdges(false);
		accountWindow.setCanDragResize(false);
		accountWindow.setCanDragReposition(false);
		
		accountWindow.setBackgroundColor("FAFAFA");
		accountWindow.setBorder("1px solid #c0c0c0");
		
		accountWindow.setShowShadow(true);  
		accountWindow.setShadowSoftness(10);  
		accountWindow.setShadowOffset(10);
		
		DynamicForm dynamicForm = new DynamicForm();
		dynamicForm.setNumCols(1);
		dynamicForm.setItems(this.createLogoutLink(), this.createSmartGwtConsoleLink());
		
		VLayout vLayout = new VLayout();
		vLayout.setWidth100();
		vLayout.setTop(10);
		
		vLayout.setMembers(dynamicForm);
		vLayout.setLayoutLeftMargin(5);
		
		accountWindow.addChild(vLayout);
		
		
		return accountWindow;
	}
	
	public void redrawAccountWindow() {
		
		if(Window.getById("_AccountWindow") != null) {
			
			MainLayout.getMainLayout().removeChild(Window.getById("_AccountWindow"));
			
			Window.getById("_AccountWindow").destroy();
		}
		
		
		Window accountWindow = createAccountWindow();
		
		accountWindow.setLeft(MainLayout.getMainLayout().getWidth() - 200);
		MainLayout.getMainLayout().addChild(accountWindow);
		
	}
	
	
	private LinkItem createLogoutLink() {
		
		LinkItem logoutLink = new LinkItem();
		
		logoutLink.setShowTitle(false);
		logoutLink.setLinkTitle("<font color=\"005596\">Logout</font>");
		
		logoutLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				MyRPCRequest rpcRequest = new MyRPCRequest("servlet/Logout", null);
				
				RPCManager.sendRequest(rpcRequest, new MyRPCCallback() {
					
					/*@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						@SuppressWarnings("unchecked")
						Map<Object, Object> httpHeader = response.getHttpHeaders();
						Object location = httpHeader.get("Location");
						
						Location.assign((String)location);
						
					}*/
					
				});
				
			}
			
		});
		
		
		return logoutLink;
	}
	
	
	private LinkItem createSmartGwtConsoleLink() {
		
		LinkItem linkItem = new LinkItem();
		
		linkItem.setShowTitle(false);
		
		linkItem.setLinkTitle("<font color=\"005596\">SmartGwt Console</font>");
		
		if(!UserData.getCurrentUserData().getUserRolesList().contains("admin")) {
			
			linkItem.setVisible(false);
		}
		
		
		linkItem.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				SC.showConsole();
			}
			
		});
		
		
		return linkItem;
	}
	
	

}
