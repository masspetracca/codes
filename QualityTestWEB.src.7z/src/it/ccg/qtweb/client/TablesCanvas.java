package it.ccg.qtweb.client;

import it.ccg.qtweb.client.base.RefreshToolStripButton;

import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.layout.VLayout;

public class TablesCanvas extends Canvas {
	
	private ListGrid batchGrid;
	private ListGrid testResultGrid;
	
	
	public TablesCanvas() {
		
		super();
		
		this.setWidth100();
		this.setHeight100();
		
		VLayout vLayout = new VLayout();
		vLayout.setMembersMargin(20);
		vLayout.setLayoutTopMargin(15);
		
		RefreshToolStripButton refreshToolStripButton = new RefreshToolStripButton(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				batchGrid.fetchData();
				testResultGrid.fetchData();
				
			}
		});
		
		vLayout.addMember(refreshToolStripButton);
		vLayout.addMember(this.createBatchRunLayout());
		vLayout.addMember(this.createTestResultLayout());
		
		
		this.addChild(vLayout);
		
	}
	
	
	
	
	private VLayout createBatchRunLayout() {
		
		VLayout vLayout = new VLayout();
		vLayout.setMembersMargin(10);
		
		Label label = new Label("BatchRun");
		label.setHeight(20);
		
		this.batchGrid = new ListGrid(DataSource.get("batchRun"));
		this.batchGrid.setHeight(400);
		this.batchGrid.setWidth(1100);
		//this.batchGrid.setAutoFetchData(true);
		
		vLayout.setMembers(label, this.batchGrid);
		
		
		return vLayout;
	}
	
	private VLayout createTestResultLayout() {
		
		VLayout vLayout = new VLayout();
		vLayout.setMembersMargin(10);
		
		Label label = new Label("TestResult");
		label.setHeight(20);
		
		this.testResultGrid = new ListGrid(DataSource.get("testResult"));
		this.testResultGrid.setHeight(400);
		this.testResultGrid.setWidth(1100);
		//this.testResultGrid.setAutoFetchData(true);
		
		vLayout.setMembers(label, this.testResultGrid);
		
		
		return vLayout;
	}

	

}
