package it.ccg.qtweb.client;

import com.google.gwt.user.client.ui.Frame;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.layout.VLayout;

public class TestResultViewerCanvas extends Canvas {
	
	public TestResultViewerCanvas() {
		
		super();
		
		this.setWidth100();
		this.setHeight100();
		
		VLayout vLayout = new VLayout();
		vLayout.setMembersMargin(30);
		
		Frame frame = new Frame("qualitytest/tools/selenium/testResultViewer.jsp");
		frame.setHeight("1000");
		frame.setWidth("1500");
		
		vLayout.addMember(frame);
		
		
		this.addChild(vLayout);
		
	}
	
	
}
