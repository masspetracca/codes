package it.ccg.qtweb.client.base;

import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;

public class RefreshToolStripButton extends ToolStripButton {
	
	
	public RefreshToolStripButton(ClickHandler clickHandler) {
		
		super();
		
		this.setIcon("[SKIN]/actions/refresh.png");
		this.setPrompt("Refresh");
		this.setTitle("Refresh");
		
		this.addClickHandler(clickHandler);
		
	}
	
	
}
