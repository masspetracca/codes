package it.ccg.qtweb.client.base;

import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.types.RPCTransport;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.LinkItem;
import com.smartgwt.client.widgets.form.fields.events.ClickEvent;
import com.smartgwt.client.widgets.form.fields.events.ClickHandler;
import com.smartgwt.client.widgets.layout.HLayout;

public class InputFileInfo extends HLayout {
	
	public InputFileInfo(final String fileName) {
		
		super();
		
		this.setWidth(300);
		
		this.setPadding(10);
		this.setPaddingAsLayoutMargin(true);
		
		//this.setShowEdges(true);
		
		
		Label label = new Label();
		label.setWrap(false);  
		label.setIcon("icons/userinfo.png");
		label.setContents("Learn how to correctly format your input file with this");
		HLayout labelHLayout = new HLayout();
		labelHLayout.addMember(label);
		labelHLayout.setLayoutTopMargin(1);
		
		
		LinkItem exampleLink = new LinkItem();
		exampleLink.setShowTitle(false);
		exampleLink.setLinkTitle("<font color=\"005596\">example</font>");
		exampleLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				RPCRequest rpcRequest = new RPCRequest();
				rpcRequest.setHttpMethod("POST");
				// Sto dicendo al client di aprire un hidden frame dal quale generare la richiesta in POST
				rpcRequest.setTransport(RPCTransport.HIDDENFRAME);
				rpcRequest.setActionURL("servlet/GenericFileDownload?fileName=" + fileName);
				
				RPCManager.sendRequest(rpcRequest);
			}
		});
		DynamicForm dynamicForm = new DynamicForm();
		dynamicForm.setItems(exampleLink);
		HLayout formHLayout = new HLayout();
		formHLayout.addMember(dynamicForm);
		formHLayout.setLayoutLeftMargin(2);
		
		
		this.setMembers(labelHLayout, formHLayout);
		
	}

}
