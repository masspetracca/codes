package it.ccg.qtweb.client.base;

import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;

public class LoadingWidget extends Window {
	
	
	public static LoadingWidget getInstance(String id) {
		
		return new LoadingWidget(id);
	}
	
	
	private LoadingWidget(String id) {
		
		super();
		
		super.setID(id);
		
		this.setWidth(160);
		this.setHeight(90);
		this.setShowEdges(false);
		this.setShowHeader(false);
		this.setBackgroundColor("FAFAFA");
		this.setBorder("1px solid #c0c0c0");
		this.setCanDragResize(false);
		this.setCanDragReposition(false);
		this.setIsModal(true);
		this.centerInPage();
		this.bringToFront();
		
		VLayout vLayout = new VLayout();
		vLayout.setWidth100();
		vLayout.setHeight100();
		
		Img loadingGif = new Img("loading.gif", 30, 30);
		HLayout gifLayout = new HLayout();
		gifLayout.setAlign(Alignment.CENTER);
		gifLayout.addMember(loadingGif);
		
		vLayout.addMember(gifLayout);
		
		Label label = new Label("Processing request..");
		label.setHeight(25);
		HLayout labelLayout = new HLayout();
		labelLayout.setAlign(Alignment.CENTER);
		labelLayout.addMember(label);
		
		vLayout.addMember(labelLayout);
		
		vLayout.setLayoutTopMargin(10);
		
		vLayout.setMembersMargin(10);
		
		this.addItem(vLayout);
		
	}
	
	
}
