package it.ccg.qtweb.client;

import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.ResizedEvent;
import com.smartgwt.client.widgets.events.ResizedHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.tab.Tab;
import com.smartgwt.client.widgets.tab.TabSet;
import com.smartgwt.client.widgets.tab.events.TabDeselectedEvent;
import com.smartgwt.client.widgets.tab.events.TabDeselectedHandler;
import com.smartgwt.client.widgets.tab.events.TabSelectedEvent;
import com.smartgwt.client.widgets.tab.events.TabSelectedHandler;

public class MainLayout extends VLayout {
	
	
	
	private static MainLayout mainLayout; //	mainLayout
	private HLayout tabSetHLayout = new HLayout(); //		tabSetHLayout
	private HLayout headerHLayout = new HLayout();
	private HeaderUserSection headerUserSection;
	
	private Tab procedureTab;
	private Tab tableTab;
	private Tab testResultViewerTab;
	
	
	public static MainLayout getInstance() {
		
		mainLayout = new MainLayout();
		
		return mainLayout;
	}
	
	public MainLayout() {
		super();
		
		this.setWidth("99%");
		this.setHeight("99%");
		
		
		// header -----------------------------------------------------------------------
		
		//this.headerHLayout.setHeight("10%");
		this.headerHLayout.setHeight(60);
		this.headerHLayout.setWidth100();
		this.headerHLayout.setLayoutTopMargin(new Integer(5));
		//this.headerHLayout.setShowResizeBar(true);
		this.headerHLayout.setAlign(VerticalAlignment.CENTER);
		
		// logo  
		Img logoImg = new Img("CCGlogo.gif", 386, 51);  	
		this.headerHLayout.addMember(logoImg, 0);
		
		// white space
		LayoutSpacer layoutSpacer = new LayoutSpacer();
		layoutSpacer.setHeight("10%");
		layoutSpacer.setWidth100();
		this.headerHLayout.addMember(layoutSpacer, 1);
		
		// user info
		this.headerUserSection = new HeaderUserSection();
		this.headerHLayout.addMember(this.headerUserSection, 2);
		
		// header -------------------------------------------------------------------
		
		
		
		// tab set ----------------------------------------------------------------------
		TabSet tabSet = new TabSet(); 
			
		//
		this.procedureTab = new Tab("Procedure");
		// not needed, this tab is the first one, so at startup the code will enter the onTabSelected method
		this.procedureTab.setPane(new ProcedureCanvas());
		/*this.procedureTab.addTabSelectedHandler(new TabSelectedHandler() {
			
			@Override
			public void onTabSelected(TabSelectedEvent event) {
				
				procedureTab.setPane(new ProcedureCanvas());
			}
		});
		this.procedureTab.addTabDeselectedHandler(new TabDeselectedHandler() {
			
			@Override
			public void onTabDeselected(TabDeselectedEvent event) {
				
				procedureTab.getPane().destroy();
			}
		});*/
		
        //
		this.tableTab = new Tab("Tables");
		this.tableTab.setPane(new TablesCanvas());
		/*this.tableTab.addTabSelectedHandler(new TabSelectedHandler() {
			
			@Override
			public void onTabSelected(TabSelectedEvent event) {
				
				tableTab.setPane(new TablesCanvas());
			}
		});
		this.tableTab.addTabDeselectedHandler(new TabDeselectedHandler() {
			
			@Override
			public void onTabDeselected(TabDeselectedEvent event) {
				
				tableTab.getPane().destroy();
			}
		});*/
		
		//
		this.testResultViewerTab = new Tab("TestResultViewer");
		this.testResultViewerTab.setPane(new TestResultViewerCanvas());
		/*this.testResultViewerTab.addTabSelectedHandler(new TabSelectedHandler() {
			
			@Override
			public void onTabSelected(TabSelectedEvent event) {
				
				testResultViewerTab.setPane(new TestResultViewerCanvas());
			}
		});
		this.testResultViewerTab.addTabDeselectedHandler(new TabDeselectedHandler() {
			
			@Override
			public void onTabDeselected(TabDeselectedEvent event) {
				
				testResultViewerTab.getPane().destroy();
			}
		});*/
		
		
		
		// add tabs to tabSet
        tabSet.setTabs(this.procedureTab, this.tableTab, this.testResultViewerTab);
        
        this.tabSetHLayout.addMember(tabSet);
        this.tabSetHLayout.setLayoutTopMargin(20);
        // tab set ----------------------------------------------------------------------
        
        this.addMember(this.headerHLayout);
		this.addMember(this.tabSetHLayout);
		
		this.setLeft("8");
		this.setTop("3");
		
		// ***************************************************************************
		
		
		
		// La finestra account utente, se presente, scompare al click su qualsiasi punto del main layout
		this.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(Window.getById("_AccountWindow") != null) {
					
					// remove
					mainLayout.removeChild(Window.getById("_AccountWindow"));
					// destroy
					Window.getById("_AccountWindow").destroy();
				}
				
			}
		});
		// Intercetta il ridimensionamento della main layout e ridisegna l'account window, solo se quest'ultima era visibile
		this.addResizedHandler(new ResizedHandler() {
			
			@Override
			public void onResized(ResizedEvent event) {
				
				if(Window.getById("_AccountWindow") != null) {
					
					// remove
					mainLayout.removeChild(Window.getById("_AccountWindow"));
					// destroy
					Window.getById("_AccountWindow").destroy();
					
					headerUserSection.redrawAccountWindow();
					
				}
				
			}
		});
	}

	

	public static MainLayout getMainLayout() {
		return mainLayout;
	}
	
	public HLayout getTabSetHLayout() {
		return tabSetHLayout;
	}

	public void setTabSetHLayout(HLayout tabSetHLayout) {
		this.tabSetHLayout = tabSetHLayout;
	}

	

}
