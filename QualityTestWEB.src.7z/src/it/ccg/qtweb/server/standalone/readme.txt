This package contains the stand-alone part of the application.
TestRunner (and thus Selenium) is launched from the TestRunnerProcessor class.
TestRunnerProcessor class has a "main" method. This class is launched into a separate Java process.
So, when launched, Java needs to have a correctly configured class-path.
Actually the package classes do not refer any of WebSphere AS lib or code which refers to them.
If these libs are needed, they have to be declared into the Java class-path.