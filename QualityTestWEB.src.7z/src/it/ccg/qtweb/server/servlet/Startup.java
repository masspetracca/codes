package it.ccg.qtweb.server.servlet;


import it.ccg.qtejb.server.logengine.Log4jSetup;
import it.ccg.qtejb.server.logengine.LoggerFactory;
import it.ccg.qtejb.server.logengine.StandardLogMessage;
import it.ccg.qtejb.server.system.SystemFilesConfig;
import it.ccg.qtejb.server.system.SystemProperties;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;


/**
 * Servlet implementation class Startup
 */
public class Startup extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger logger;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Startup() {
    	super();
    }
    
    
    @Override
    public void init() throws ServletException {
    	
    	try {
    		System.out.println("Loading QualityTest system environment..");
    		
    		// load log4j properties
			Log4jSetup.loadLog4JProperties();
			
			// load system properties
			SystemProperties.loadSystemProperties();
			
    		// system files
			SystemFilesConfig.createSystemFiles();
			
			// TestRunner properties
			String TR_PROPERTIES_FILE_ABSOLUTE_PATH = SystemProperties.getProperty("user.install.root") + 
													  SystemProperties.getProperty("temp_dir_relative_path") + 
													  SystemProperties.getProperty("TR.properties.file");
			
			// create a default TR.properties if it does not exist
			if(!new File(TR_PROPERTIES_FILE_ABSOLUTE_PATH).exists()) {
				
				Properties prop = new Properties();
	    		//set the properties value
	    		/*prop.setProperty("branch", "PAMP quality test");
	    		prop.setProperty("fileRoot", "C:\\Users\\pcocchi\\Desktop");
	    		prop.setProperty("testRoot", "MyTS");
	    		prop.setProperty("files", "");
	    		prop.setProperty("httpTarget", "10.0.10.240");
	    		prop.setProperty("httpPort", "10000");
	    		prop.setProperty("seleniumTimeout", "120");
	    		prop.setProperty("maximizeBrowser", "true");
	    		prop.setProperty("captureScreenshot", "true");
	    		prop.setProperty("saveMessages", "true");
	    		prop.setProperty("batchCommit", "true");
	    		prop.setProperty("browser", "*firefox C:\\ff17esr\\firefox.exe");
	    		prop.setProperty("batchLog", "");
	    		prop.setProperty("outputFilePrefix", "");*/
				
				prop.setProperty("branch", "");
	    		prop.setProperty("fileRoot", "");
	    		prop.setProperty("testRoot", "");
	    		prop.setProperty("files", "");
	    		prop.setProperty("httpTarget", "");
	    		prop.setProperty("httpPort", "");
	    		prop.setProperty("seleniumTimeout", "");
	    		prop.setProperty("maximizeBrowser", "true");
	    		prop.setProperty("captureScreenshot", "true");
	    		prop.setProperty("saveMessages", "true");
	    		prop.setProperty("batchCommit", "true");
	    		prop.setProperty("browser", "");
	    		prop.setProperty("batchLog", "");
	    		prop.setProperty("outputFilePrefix", "");
				
	    		//save properties to file
	    		prop.store(new FileOutputStream(TR_PROPERTIES_FILE_ABSOLUTE_PATH), null);
		    		
			}
			
    		
			logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
			
    		logger.info(new StandardLogMessage("..QualityTest system environment successfully loaded."));
    	}
    	catch(Exception e) {
    		
    		e.printStackTrace();
		}
    	
    }
    

}
