package it.ccg.qtweb.server.servlet;

import it.ccg.qtejb.server.logengine.LoggerFactory;
import it.ccg.qtejb.server.logengine.StandardLogMessage;
import it.ccg.qtejb.server.system.SystemProperties;
import it.ccg.qtweb.server.servlet.jdbc.JDBC;
import it.ccg.qtweb.server.standalone.TestRunnerDriverProperties;
import it.ccg.qtweb.server.standalone.TestRunnerProcessor;
import it.ccg.qtweb.server.util.POJO2Json;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.ArrayUtils;
import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

//import com.ibm.websphere.validation.base.config.level51.requestmetricsvalidation_51_NLS;

/**
 * Servlet implementation class TestRunnerServlet
 */
public class TestRunnerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	
	private Map<String, String> detailsMap = new HashMap<String, String>();
	
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestRunnerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		throw new ServletException("Http GET request not allowed.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String _operationId = request.getParameter("_operationId");
		
		if(_operationId.equalsIgnoreCase("readConfig")) {
			
			this.readConfig(request, response);
		}
		else if(_operationId.equalsIgnoreCase("saveConfig")) {
			
			this.saveConfig(request, response);
		}
		else if(_operationId.equalsIgnoreCase("run")) {
			
			this.run(request, response);
		}
		else {
			
			throw new ServletException("Unknown _operationId: " + _operationId);
		}
		
	}
	
	
	private void readConfig(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			// TestRunner properties
			String TR_PROPERTIES_FILE_ABSOLUTE_PATH = SystemProperties.getProperty("user.install.root") + 
													  SystemProperties.getProperty("temp_dir_relative_path") + 
													  SystemProperties.getProperty("TR.properties.file");
			
			TestRunnerDriverProperties testRunnerProperties = TestRunnerDriverProperties.getInstace(TR_PROPERTIES_FILE_ABSOLUTE_PATH);
			
			Map<String, String> map = new HashMap<String, String>();
			map.put("batchLog", testRunnerProperties.getBatchLog());
			map.put("branch", testRunnerProperties.getBranch());
			map.put("browser", testRunnerProperties.getBrowser());
			map.put("fileRoot", testRunnerProperties.getFileRoot());
			map.put("httpTarget", testRunnerProperties.getHttpTarget());
			map.put("testRoot", testRunnerProperties.getTestRoot());
			
			String arrayString = ArrayUtils.toString(testRunnerProperties.getFiles());
			map.put("files", (testRunnerProperties.getFiles() != null) ? arrayString.substring(1, arrayString.length() - 1) : "");
			
			map.put("httpPort", (testRunnerProperties.getHttpPort() != null) ? Integer.toString(testRunnerProperties.getHttpPort()) : "");
			map.put("seleniumTimeout", (testRunnerProperties.getSeleniumTimeout() != null) ? Integer.toString(testRunnerProperties.getSeleniumTimeout()) : "");
			map.put("batchCommit", (testRunnerProperties.isBatchCommit() != null) ? Boolean.toString(testRunnerProperties.isBatchCommit()) : "");
			map.put("captureScreenshot", (testRunnerProperties.isCaptureScreenshot() != null) ? Boolean.toString(testRunnerProperties.isCaptureScreenshot()) : "");
			map.put("maximizeBrowser", (testRunnerProperties.isMaximizeBrowser() != null) ? Boolean.toString(testRunnerProperties.isMaximizeBrowser()) : "");
			map.put("saveMessages", (testRunnerProperties.isSaveMessages() != null) ? Boolean.toString(testRunnerProperties.isSaveMessages()) : "");
			
			String jsonString = POJO2Json.convert(Map.class, map);
			
			response.getWriter().println(jsonString);
			
		}
		catch(Exception e) {
			
			e.printStackTrace();
		}
		
	}
	
	private void saveConfig(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			
			// TestRunner properties file
			String TR_PROPERTIES_FILE_ABSOLUTE_PATH = SystemProperties.getProperty("user.install.root") + 
													  SystemProperties.getProperty("temp_dir_relative_path") + 
													  SystemProperties.getProperty("TR.properties.file");
			
			
			TestRunnerDriverProperties testRunnerProperties = new TestRunnerDriverProperties();
			testRunnerProperties.setBatchCommit((request.getParameter("batchCommit").trim().length() > 0) ? Boolean.parseBoolean(request.getParameter("batchCommit")) : null);
			testRunnerProperties.setBatchLog(request.getParameter("batchLog"));
			testRunnerProperties.setBranch(request.getParameter("branch"));
			testRunnerProperties.setBrowser(request.getParameter("browser"));
			testRunnerProperties.setCaptureScreenshot((request.getParameter("captureScreenshot").trim().length() > 0) ? Boolean.parseBoolean(request.getParameter("captureScreenshot")) : null);
			testRunnerProperties.setFileRoot(request.getParameter("fileRoot"));
			testRunnerProperties.setFiles((request.getParameter("files").trim().length() > 0) ? request.getParameter("files").split(",") : null);
			testRunnerProperties.setHttpPort((request.getParameter("httpPort").trim().length() > 0) ? Integer.parseInt(request.getParameter("httpPort")) : null);
			testRunnerProperties.setHttpTarget(request.getParameter("httpTarget"));
			testRunnerProperties.setMaximizeBrowser((request.getParameter("maximizeBrowser").trim().length() > 0) ? Boolean.parseBoolean(request.getParameter("maximizeBrowser")) : null);
			testRunnerProperties.setSaveMessages((request.getParameter("saveMessages").trim().length() > 0) ? Boolean.parseBoolean(request.getParameter("saveMessages")) : null);
			testRunnerProperties.setSeleniumTimeout((request.getParameter("seleniumTimeout").trim().length() > 0) ? Integer.parseInt(request.getParameter("seleniumTimeout")): null);
			testRunnerProperties.setTestRoot(request.getParameter("testRoot"));
			
			TestRunnerDriverProperties.setInstace(testRunnerProperties, TR_PROPERTIES_FILE_ABSOLUTE_PATH);
			
			
			logger.info(new StandardLogMessage(("New TestRunner configuration: " + "\n" + TestRunnerDriverProperties.getInstace(TR_PROPERTIES_FILE_ABSOLUTE_PATH).toString())));
			
		}
		catch(Exception e) {
			
			e.printStackTrace();
		}
		
	}
	
	
	
	private void run(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			String classCanonicalName = TestRunnerProcessor.class.getCanonicalName();
			//URL url = TestRunnerProcessor.class.getResource("TestRunnerProcessor.class");
			
			URL smartGwtPropsURL = Thread.currentThread().getContextClassLoader().getResource("server.properties");
			Properties smartGwtProps = new Properties();
			smartGwtProps.load(new FileInputStream(new File(smartGwtPropsURL.getFile())));
			
			String absoluteWebRoot = smartGwtProps.getProperty("webRoot");
			
			String classesAbsolutePath = absoluteWebRoot + "/WEB-INF/classes";
			String libAbsolutePath = absoluteWebRoot + "/WEB-INF/lib";
			
			// TODO: remove
			System.out.println("********");
			System.out.println(classCanonicalName);
			System.out.println(classesAbsolutePath);
			System.out.println("********");

			String classpath = libAbsolutePath + "\\*" + ";" + 
			   classesAbsolutePath + ";" + 
			   absoluteWebRoot + "\\qualitytest\\tools\\selenium" + ";" + 
			   "%JAVA_HOME%\\lib\\tools.jar" + ";" + 
			   "%JAVA_HOME%\\lib\\dt.jar";		
//old		
//			String classpath = libAbsolutePath + "\\*" + ";" + 
//							   classesAbsolutePath + ";" + 
//							   absoluteWebRoot + "\\qualitytest\\tools\\selenium" + ";" + 
//							   "%JAVA_HOME%\\lib\\tools.jar" + ";" + 
//							   "%JAVA_HOME%\\lib\\dt.jar" + ";" + 
//							   "C:\\workspace\\QualityTestEJB\\build\\classes"; //<< localhost
//							   //SystemProperties.getProperty("user.install.root") + "\\installedApps\\I65BD99F_PAMP_QA\\QualityTestEAR.ear\\QualityTestEJB.jar";
//			
//			
			// TestRunner properties
			String TR_PROPERTIES_FILE_ABSOLUTE_PATH = SystemProperties.getProperty("user.install.root") + 
													  SystemProperties.getProperty("temp_dir_relative_path") + 
													  SystemProperties.getProperty("TR.properties.file");
			
			
			String command = "java -cp \"" + classpath + "\" " + classCanonicalName + " " + "\"" + TR_PROPERTIES_FILE_ABSOLUTE_PATH + "\"";
			
			logger.info(new StandardLogMessage("Executing TestRunner in separate process. command: " + command));
			
			// Execute
			Process process = Runtime.getRuntime().exec(command);
			
			// Read output
			TestRunnerDriverProperties testRunnerProperties = TestRunnerDriverProperties.getInstace(TR_PROPERTIES_FILE_ABSOLUTE_PATH);
			String[] testCaseFiles = testRunnerProperties.getFiles();
			String line;
			BufferedReader outBr = new BufferedReader(new InputStreamReader(process.getInputStream()));
			
			logger.info(new StandardLogMessage("*** Output from TestRunner process - START ***"));
			
			String tempTestCaseLog = new String();
			int i = 0;
			boolean saving = false;
			
			while((line = outBr.readLine()) != null) {
				
				logger.info(new StandardLogMessage(line));
				
				
				// make temp details map
				
				if(!saving) {
					
					// testcase log is starting
					if(line.contains("results for")) {
						
						//detailsMap.put(testCaseFiles[i], null);
						
						
						saving = true;
					}
				}
				else {
					
					// testcase log is ended
					if(line.equalsIgnoreCase("")) {
						
						// fine del log
						saving = false;
						// scrivo nella mappa
						detailsMap.put(testCaseFiles[i], tempTestCaseLog);
						// clean della risorsa temporanea
						tempTestCaseLog = new String();
						// vado col prossimo testcase
						i++;
						
					}
				}
				
				// if needed, save!
				if(saving) {
					
					tempTestCaseLog += line + "\n";
				}
				
				
				
			}
			
			logger.info(new StandardLogMessage("*** Output from TestRunner process - END ***"));
			outBr.close();
			
			
			BufferedReader errorBr = new BufferedReader(new InputStreamReader(process.getErrorStream()));
			logger.info(new StandardLogMessage("*** Error from TestRunner process - START ***"));
			while((line = errorBr.readLine()) != null) {
				
				logger.error(new StandardLogMessage(line));
			}
			
			logger.info(new StandardLogMessage("*** Error from TestRunner process - END ***"));
			errorBr.close();
			
			
			
			// generate output reports
			logger.info(new StandardLogMessage("Generating reports.."));
			
			String resultSubFolderAbsolutePath = this.generateOutputReports();
			
			
			

			// return results to client
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("resultSubFolderAbsolutePath", resultSubFolderAbsolutePath);
			
			String jsonString = jsonObject.toJSONString();
			
			response.setStatus(HttpStatus.SC_OK);
			response.getWriter().print(jsonString);
			
		}
		catch(Exception e) {
			
			e.printStackTrace();
			
			response.setStatus(500);
		}
		
	}
	
	
	private String generateOutputReports() throws Exception {

		URL smartGwtPropsURL = Thread.currentThread().getContextClassLoader().getResource("server.properties");
		Properties smartGwtProps = new Properties();
		smartGwtProps.load(new FileInputStream(new File(smartGwtPropsURL.getFile())));
		
		// TestRunner properties
		String TR_PROPERTIES_FILE_ABSOLUTE_PATH = SystemProperties.getProperty("user.install.root") + 
												  SystemProperties.getProperty("temp_dir_relative_path") + 
												  SystemProperties.getProperty("TR.properties.file");
		
		// needed objects
		TestRunnerDriverProperties trdp = TestRunnerDriverProperties.getInstace(TR_PROPERTIES_FILE_ABSOLUTE_PATH);
		String driver = smartGwtProps.getProperty("sql.HSQLDB.driver");
		String driverUrl = smartGwtProps.getProperty("sql.HSQLDB.driver.url");
		String user = smartGwtProps.getProperty("sql.HSQLDB.driver.user");
		String password = smartGwtProps.getProperty("sql.HSQLDB.driver.password");
		Connection connection;
		String query;
		
		
		// folder to save the reports
		
		// branch is my TestSuite
		String branch = trdp.getBranch();
		
		// retrieve current batch id
		connection = JDBC.connect2DB(driver, driverUrl, user, password);
//		query 
//		= "SELECT * FROM batchrun WHERE branch=\'" + branch + "\' "  
//		  +"AND batchstarttime " 
//		  +"	in (SELECT MAX(batchstarttime) as batchstarttime FROM batchrun')";
		query = "SELECT * FROM batchrun " +
//				"WHERE branch=\'" + branch + "\' " + 
		"WHERE id = (SELECT MAX(id) AS ID FROM batchrun) " 
//		"WHERE branch=\'" + branch + "\' 
		 ;
		
		Object[][] relation = JDBC.query(connection, query);
		connection.close();
		
		if(relation.length != 1) {
			
			throw new Exception("Error fetching result for branch \'" + branch + "\' from BATCHRUN table.");
		}
		
		
		Object[] record = relation[0];
		Integer batchId = (Integer)record[0];
		Timestamp batchStartTime = (Timestamp)record[2];
		
		String resultSubFolderName = "BATCH_" + batchId;
		String resultSubFolderAbsolutePath = trdp.getTestRoot() + File.separator + resultSubFolderName;
		new File(resultSubFolderAbsolutePath).mkdir();
		
		// array di TestCase della run
		String[] testSuiteFiles = trdp.getFiles();
		
		for(String testCaseFile : testSuiteFiles) {
					
			connection = JDBC.connect2DB(driver, driverUrl, user, password);
			query = "SELECT * FROM testResult WHERE branch=\'" + branch + "\' " + 
					"AND TESTFILE like ('%" + testCaseFile + "%') " +
					"AND starttime = "
				  + " (SELECT MAX(starttime) "
				  + " FROM testResult 	" 
				  + " WHERE TESTFILE like ('%" + testCaseFile + "%') )"
				  ;
	
//			query = "SELECT * FROM testResult WHERE branch=\'" + branch + "\' " + 
//			"AND TESTFILE like ('%" + testCaseFile + "%') " + 
//			"AND  batchstarttime = \'" + batchStartTime + "\'";


			relation = JDBC.query(connection, query);
			connection.close();
			
			if(relation.length != 1) {
				
				throw new Exception("Error fetching result for file \'" + testCaseFile + "\' from TESTRESULT table.");
			}
			
			
			//JDBC.printRelation(relation);
			
			record = relation[0];
			String result = (String)record[1];
			
			/*if(result.equalsIgnoreCase("success")) {
				
				// TODO
			}
			else if(result.equalsIgnoreCase("failure")) {
				
				// IMPORTANTE!
				// TestRunner va a cercare dentrro la fileRoot qualunque nome di file che contiene i nomi di file specificati, in qualunque sottocartella.
				// Se io salvassi i file di output in una sottocartella ma con lo stesso nome del file di input, 
				// al giro successivo il TestRunner proverebbe a eseguire anche questi file (e, non essendo script, questi file vanno in errore).
				String fileName = trdp.getOutputFilePrefix() + "_" + ((String)record[0]).substring(((String)record[0]).lastIndexOf("/") + 1, ((String)record[0]).lastIndexOf(".")) + ".out";
				
				File outputFile = new File(folderAbsolutePath + File.separator + fileName);
				outputFile.createNewFile();
				
				PrintWriter pw = new PrintWriter(outputFile);
				
				pw.write((String)record[2]);

				//MP			
				pw.write("#end");
				
				pw.close();
				
				logger.info(new StandardLogMessage("generated " + outputFile.getAbsolutePath()));
			}
			else if(result.equalsIgnoreCase("timeout")) {
				
				// TODO
			}
			else {
				
				throw new Exception("Not valid RESULT value \'" + result + "\' for file \'" + testCaseFile + "\'");
			}
			
		}*/
			
			
			// IMPORTANTE!
			// TestRunner va a cercare dentrro la fileRoot qualunque nome di file che contiene i nomi di file specificati, in qualunque sottocartella.
			// Se io salvassi i file di output in una sottocartella ma con lo stesso nome del file di input, 
			// al giro successivo il TestRunner proverebbe a eseguire anche questi file (e, non essendo script, questi file vanno in errore).
			String fileName = ((String)record[0]).substring(((String)record[0]).lastIndexOf("/") + 1, ((String)record[0]).lastIndexOf("."));
			
			if(result.equalsIgnoreCase("success")) {
				
				fileName += ".success";
			}
			else if(result.equalsIgnoreCase("failure")) {
				
				fileName += ".failure";
			}
			else if(result.equalsIgnoreCase("timeout")) {
				
				fileName += ".timeout";
			}
			else {
				
				throw new Exception("Not valid RESULT value \'" + result + "\' for file \'" + testCaseFile + "\'");
			}
			
			fileName += ".out";
			
			
			// generate output file
			File outputFile = new File(resultSubFolderAbsolutePath + File.separator + fileName);
			outputFile.createNewFile();
			
			PrintWriter pw = new PrintWriter(outputFile);
			
			pw.write(detailsMap.get(testCaseFile));
			pw.write("#end");
			
			pw.close();
			
			logger.info(new StandardLogMessage("generated " + outputFile.getAbsolutePath()));
			
			
			
		} //FINE
		
		
		// generate test suite regression results
		
//		File outputFile = new File(resultSubFolderAbsolutePath + File.separator + "TestSuite_results.out");
//		outputFile.createNewFile();
//		
//		// TODO: compute results
//		int total = testSuiteFiles.length;
//		int passed = 0;
//		int errors = 0;
//		int fixed = 0;
//		int regressions = 0;
//		int timeout = 0;

		
//		for(String testCaseFile : testSuiteFiles) {
//			
//			// get current run result
//			connection = JDBC.connect2DB(driver, driverUrl, user, password);
//			query = "SELECT * FROM testResult WHERE branch=\'" + branch + "\' " + 
//			"AND TESTFILE like ('%" + testCaseFile + "%') " + 
//			"AND  batchstarttime = \'" + batchStartTime + "\'";
//			
//			relation = JDBC.query(connection, query);
//			connection.close();
//			
//			if(relation.length != 1) {
//				
//				throw new Exception("Error fetching result for file \'" + testCaseFile + "\' from TESTRESULT table.");
//			}
//
//			record = relation[0];
//			String currentRunResult = (String)record[1];
//			
//			
//			// get previous run result
//			connection = JDBC.connect2DB(driver, driverUrl, user, password);
//			query = "SELECT * FROM testResult t1 WHERE t1.branch=\'" + branch + "\' " + 
//			"AND t1.testFile like ('%" + testCaseFile + "%') " + 
//			"AND 1 = (SELECT count(t2.batchstarttime) FROM testResult t2 WHERE t2.branch=\'" + branch + "\' " + 
//			"AND t2.testFile like ('%" + testCaseFile + "%') " + 
//			"AND t2.batchstarttime <= \'" + batchStartTime + "\' " + 
//			"AND t1.batchstarttime < t2.batchstarttime)";
//			
//			
//			relation = JDBC.query(connection, query);
//			connection.close();
//			
//			String previousRunResult = null;
//			
//			if(relation.length == 1) {
//
//				record = relation[0];
//				previousRunResult = (String)record[1];
//			}
//			// non esiste la run recedente, � la prima run
//			else {
//				
//				// DO NOTHING - previousRunResult = null
//			}
//
//			
//			// logica
//			
//			if(currentRunResult.equalsIgnoreCase("success")) {
//				
//				passed++;
//				
//				// se esiste una run precedente
//				if(previousRunResult != null) {
//					
//					if(previousRunResult.equalsIgnoreCase("failure")) {
//						
//						fixed++;
//					}
//					
//				}
//				
//			}
//			else if(currentRunResult.equalsIgnoreCase("failure")) {
//				
//				errors++;
//				
//				// se esiste una run precedente
//				if(previousRunResult != null) {
//					
//					if(previousRunResult.equalsIgnoreCase("success")) {
//						
//						regressions++;
//					}
//					
//				}
//				
//			}
//			else if(currentRunResult.equalsIgnoreCase("timeout")) {
//				
//				timeout++;
//			}
//			
//			
//			
//		}
		
		
		
//		// write results
//		String header = "TOTAL|PASSED|FIXED|ERRORS|REGRESSIONS|TIMEOUT";
//		String body = total + "|" + passed + "|" + fixed  + "|" + errors + "|" + regressions + "|" + timeout;
//		
//		PrintWriter pw = new PrintWriter(outputFile);
//		pw.write(header + "\n" + body);
//		
//		pw.close();
		
		
		// return result folder path
		return resultSubFolderAbsolutePath;
		
	}
	
	

}