package it.ccg.qtweb.server.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ParserServlet
 */
public class ParserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ParserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		throw new ServletException("Http GET request not allowed.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String _operationId = request.getParameter("_operationId");
		
		if(_operationId.equalsIgnoreCase("makeXML")) {
			
			this.makeXML(request, response);
		}
		/*else if(_operationId.equalsIgnoreCase("saveConfig")) {
			
			this.saveConfig(request, response);
		}*/
		else {
			
			throw new ServletException("Unknown _operationId: " + _operationId);
		}
		
	}
	
	
	private void makeXML(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}
	
	

}
