package it.ccg.qtweb.server.servlet.jdbc;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.SQLException;



public class JDBC {
	
	
	public static Connection connect2DB(String driver, String driverUrl, String user, String password) throws SQLException {
		
		Connection connection = null;
		
		try {
			Class.forName(driver);
		}
		catch(ClassNotFoundException e) {
			
			e.printStackTrace();
			
			return connection;
		}
		
		if((user != null) && (password != null)) {
			connection = DriverManager.getConnection(driverUrl, user, password);
		}
		else {
			connection = DriverManager.getConnection(driverUrl);
		}
		
		
		return connection;
	}
	
	public static Object[][] query(Connection connection, String q) throws SQLException {
		Statement stat = connection.createStatement();
		ResultSet rs;
		ResultSetMetaData rsmd;
		Object[][] o;
        
        rs = stat.executeQuery(q);
        if(!rs.next()) {
        	rs.close();
        	stat.close();
        	return new Object[0][];
        }
        
        rs.close();
        
        int r = rowNumber(connection, q);
		rs = stat.executeQuery(q);
        rsmd = rs.getMetaData();
		int c = rsmd.getColumnCount();

		o = new Object[r][c];	
		
		int i=0;
		while(rs.next()) {
			for(int k=0; k<c; k++) {
				o[i][k] = rs.getObject(k+1);
			}
			i++;
		}
		
		rs.close();
		stat.close();
		
		return o;
	}
	
	public static void update(Connection connection, String u) throws SQLException {
		Statement stat = connection.createStatement();
		stat.executeUpdate(u);
		stat.close();
	}
	
    private static int rowNumber(Connection connection, String q) throws SQLException {
    	
    	int count = 0;
    	
    	Statement stat = connection.createStatement();
		ResultSet rs = stat.executeQuery(q);
				
		while (rs.next()) {
		  count++;
	    }
				
		rs.close();
		stat.close();
    	
    	return count;
    	
    }
    
    
    public static void printRelation(Object[][] obj) {
		System.out.println();
		for(int i=0; i<obj.length; i++) {
			System.out.print("|");
			for(int k=0; k<obj[i].length; k++) {
				System.out.print(" " + obj[i][k] + " |" );
			}
			System.out.println();
		}
		System.out.println();
	}
	
	
}
