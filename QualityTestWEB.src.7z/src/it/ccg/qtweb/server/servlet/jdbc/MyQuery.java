package it.ccg.qtweb.server.servlet.jdbc;

public class MyQuery {
	
	public static final String query = "";

}
