package it.ccg.qtweb.server.servlet;

import it.ccg.qtweb.server.util.POJO2Json;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;

/**
 * Servlet implementation class ReadFolderServlet
 */
public class ReadFolderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReadFolderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		throw new ServletException("Http GET request not allowed.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String _operationId = request.getParameter("_operationId");
		
		if(_operationId.equalsIgnoreCase("readFolder")) {
			
			this.readFolder(request, response);
		}
		/*else if(_operationId.equalsIgnoreCase("?")) {
			
			this.?(request, response);
		}*/
		else {
			
			throw new ServletException("Unknown _operationId: " + _operationId);
		}
		
	}
	
	
	private void readFolder(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			String folderName = request.getParameter("folderName");
			
			String jsonString = new String();
			
			if(!new File(folderName).exists()) {
				
				jsonString = new JSONObject().toJSONString();
			}
			else {
				
				File[] files = new File(folderName).listFiles();
				
				String fileList = new String();
				for(File file : files) {
					
					if(file.isFile() && (file.getAbsolutePath().trim().length() > 0)) {
						
						fileList += file.getName() + ",";
					}
				}
				
				if(fileList.length() > 0) {
					
					fileList = fileList.substring(0, fileList.length() - 1);
					
					Map<String, String> map = new HashMap<String, String>();
					map.put("fileList", fileList);
					
					jsonString = POJO2Json.convert(Map.class, map);
				}
				else {
					
					jsonString = new JSONObject().toJSONString();
				}
				
			}
			
			
			response.getWriter().println(jsonString);
			
		}
		catch(Exception e) {
			
			e.printStackTrace();
		}
		
	}

}
