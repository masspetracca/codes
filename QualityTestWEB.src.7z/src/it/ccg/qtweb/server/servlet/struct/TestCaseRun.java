package it.ccg.qtweb.server.servlet.struct;

import java.sql.Timestamp;

public class TestCaseRun {
	
	private String name;
	private String testSuite;
	private Timestamp runDate;
	private TestCaseRunResult result;
	
	public TestCaseRun(String name, String testSuite, Timestamp runDate, TestCaseRunResult result) {
		
		this.name = name;
		this.testSuite = testSuite;
		this.runDate = runDate;
		this.result = result;
		
	}

	public String getName() {
		return name;
	}

	public String getTestSuite() {
		return testSuite;
	}

	public Timestamp getRunDate() {
		return runDate;
	}

	public TestCaseRunResult getResult() {
		return result;
	}

	
	
	
	
}
