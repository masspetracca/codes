package it.ccg.qtweb.server.servlet.struct;

public enum TestCaseRunResult {
	
	SUCCESS,
	FAILURE,
	TIMEOUT;
	
}
