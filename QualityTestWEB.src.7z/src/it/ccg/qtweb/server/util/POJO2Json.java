package it.ccg.qtweb.server.util;


import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;



public class POJO2Json {
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static String convert(Class<?> c, Object o) {
		
		if(o instanceof List) {
			
			return convert(c, (List)o);
		}
		
		return getJsonObject(c, o).toJSONString();
	}
	
	
	
	@SuppressWarnings("unchecked")
	private static String convert(Class<?> c, List<Object> objectList) {
		
		JSONArray jsonObjectArray = new JSONArray();
		
		for(Object object : objectList) {
			
			jsonObjectArray.add(getJsonObject(c, object));
		}
		
		return jsonObjectArray.toJSONString();
	}
	
	
	@SuppressWarnings("unchecked")
	private static JSONObject getJsonObject(Class<?> c, Object o) {
		
		JSONObject jsonObject = null;
		
		try {
			
			Map<String, String> objectMap = new HashMap<String, String>();
			
			
			if(o instanceof Map) {
				
				objectMap = (Map<String, String>)o;
			}
			else {
				Field[] fields = c.getDeclaredFields();
				
				Object castedObject = c.cast(o);
				
				for(Field field : fields) {
					
					if(!field.getName().equalsIgnoreCase("serialVersionUID")) {
						
						Method method = null;
						
						if(field.getType() == boolean.class) {
							
							method = c.getMethod(field.getName(), (Class<?>[])null);
						}
						else {
							
							method = c.getMethod(getGetter(field.getName()), (Class<?>[])null);
						}
						
						
						
						Object fieldValue = method.invoke(castedObject, (Object[])null);
						
						
						if(fieldValue != null) {
							
							//objectMap.put(field.getName(), (field.getType().cast(fieldValue)).toString());
							
							objectMap.put(field.getName(), fieldValue.toString());
						}
					}
					
				}
			}
			
			
			jsonObject = new JSONObject(objectMap);
		}
		catch(Exception e) {
			
			e.printStackTrace();
		}
		
		return jsonObject;
	}
	
	
	private static String getGetter(String field) {
		
		String upperFirst = field.substring(0, 1).toUpperCase();
		
		return "get" + upperFirst + field.substring(1);
	}

}
