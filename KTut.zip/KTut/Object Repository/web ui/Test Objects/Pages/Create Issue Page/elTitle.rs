<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>elTitle</name>
   <tag></tag>
   <elementGuidId>63e0f97a-5541-43ed-b07f-3b41f7de9f09</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@id='create-issue-dialog']//h2[count(. | //*[@ref_element = 'Object Repository/UI Test Objects/Pages/Create Issue Page/elRoot' and @ref_element_is_shadow_root = 'true']) = count(//*[@ref_element = 'Object Repository/UI Test Objects/Pages/Create Issue Page/elRoot' and @ref_element_is_shadow_root = 'true'])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@id='create-issue-dialog']//h2</value>
   </webElementProperties>
</WebElementEntity>
