<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>elCancel</name>
   <tag></tag>
   <elementGuidId>b0df2045-5816-4a31-8e3c-c7b429208b9c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@id='create-issue-dialog']//a[.='Cancel'][count(. | //*[@ref_element = 'Object Repository/UI Test Objects/Pages/Create Issue Page/elRoot' and @ref_element_is_shadow_root = 'true']) = count(//*[@ref_element = 'Object Repository/UI Test Objects/Pages/Create Issue Page/elRoot' and @ref_element_is_shadow_root = 'true'])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@id='create-issue-dialog']//a[.='Cancel']</value>
   </webElementProperties>
</WebElementEntity>
