<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>elCreate</name>
   <tag></tag>
   <elementGuidId>8d9c1183-e771-4d58-b219-4fcc3ade04d1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@id='create-issue-dialog']//input[@value='Create'][count(. | //*[@ref_element = 'Object Repository/UI Test Objects/Pages/Create Issue Page/elRoot' and @ref_element_is_shadow_root = 'true']) = count(//*[@ref_element = 'Object Repository/UI Test Objects/Pages/Create Issue Page/elRoot' and @ref_element_is_shadow_root = 'true'])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@id='create-issue-dialog']//input[@value='Create']</value>
   </webElementProperties>
</WebElementEntity>
