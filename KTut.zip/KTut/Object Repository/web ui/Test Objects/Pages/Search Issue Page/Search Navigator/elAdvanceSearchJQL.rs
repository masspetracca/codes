<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>elAdvanceSearchJQL</name>
   <tag></tag>
   <elementGuidId>109a5583-42b5-4051-9a2b-8fb8971f28fe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//form[contains(@class, 'navigator-search')]//textarea[@id='advanced-search']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//form[contains(@class, 'navigator-search')]//textarea[@id='advanced-search']</value>
   </webElementProperties>
</WebElementEntity>
