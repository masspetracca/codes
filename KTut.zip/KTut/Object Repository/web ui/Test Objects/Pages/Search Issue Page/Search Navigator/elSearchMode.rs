<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>elSearchMode</name>
   <tag></tag>
   <elementGuidId>4ecdd2a3-088b-41f7-9d00-78dafa1a9912</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//form[contains(@class, 'navigator-search')]//a[contains(@class, 'switcher-item active')]</value>
   </webElementProperties>
</WebElementEntity>
