<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>elSearch</name>
   <tag></tag>
   <elementGuidId>bec717b7-e5cb-475e-9ced-f12ab77f8678</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//form[contains(@class, 'navigator-search')]//button[.='Search']</value>
   </webElementProperties>
</WebElementEntity>
