<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>elHeader</name>
   <tag></tag>
   <elementGuidId>dd89b8bc-c56c-4aeb-a0dd-1a37e6b30cf7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@id='root']//h1[.='Log in to your account']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@id='root']//h1[.='Log in to your account']</value>
   </webElementProperties>
</WebElementEntity>
