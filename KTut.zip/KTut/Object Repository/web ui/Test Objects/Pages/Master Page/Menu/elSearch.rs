<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>elSearch</name>
   <tag></tag>
   <elementGuidId>7df8a086-55cd-4de6-b8fd-eb89ea62e183</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[.//span[@aria-label='Search (/)']]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[.//span[@aria-label='Search (/)']]</value>
   </webElementProperties>
</WebElementEntity>
