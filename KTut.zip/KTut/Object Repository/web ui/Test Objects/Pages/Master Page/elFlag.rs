<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>elFlag</name>
   <tag></tag>
   <elementGuidId>f86e9b3f-c651-40e5-b4c9-d1cd7b23b7be</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@id='aui-flag-container']//a[contains(., '${summary}')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@id='aui-flag-container']//a[contains(., '${summary}')]</value>
   </webElementProperties>
</WebElementEntity>
