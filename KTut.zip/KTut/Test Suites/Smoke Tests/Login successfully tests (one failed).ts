<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Login successfully tests (one failed)</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-07-18T14:09:36</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>19369edf-d637-4540-a8d8-ae0bf364f3fd</testSuiteGuid>
   <testCaseLink>
      <guid>cf208ae6-c0a1-46c8-835d-c4f3ba0fd04f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Web UI Tests/Advance Tests/Tests/Login Test/User should login successfully with a valid account</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>7440cc66-a499-4614-a1c6-e6ed64e33e3b</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/test-accounts</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>7440cc66-a499-4614-a1c6-e6ed64e33e3b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Username</value>
         <variableId>db0d2634-eb7c-41f6-900b-212e3b6baa42</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>7440cc66-a499-4614-a1c6-e6ed64e33e3b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Password</value>
         <variableId>a5ee436b-09a4-4881-bfb1-21ebd667f963</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
