<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Login successfully tests</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-06-24T23:15:20</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>b4bd05ed-f6e0-462f-a2a7-edcf7117de9c</testSuiteGuid>
   <testCaseLink>
      <guid>a3a1c5fd-3684-4190-ac21-ec32b3025245</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Web UI Tests/Advance Tests/Tests/Login Test/User should login successfully using encrypted password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f909b3c4-7390-4f35-a8f3-80ef61a621a4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Web UI Tests/Advance Tests/Tests/Login Test/User should login successfully with a valid account</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>db0d2634-eb7c-41f6-900b-212e3b6baa42</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>a5ee436b-09a4-4881-bfb1-21ebd667f963</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
