<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS01</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-10-18T14:48:14</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>247167a4-dc85-4651-89dc-a1298bb7b7f9</testSuiteGuid>
   <testCaseLink>
      <guid>153e0a31-c2ba-4a01-a9bc-7f0bc655fd05</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TestVariables/TC01</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
