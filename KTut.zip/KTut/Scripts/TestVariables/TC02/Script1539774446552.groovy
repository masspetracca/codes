import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import javax.security.auth.login.LoginContext as LoginContext
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.ConditionType as ConditionType
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.testobject.TestObjectProperty as TestObjectProperty
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.navigateToUrl('http://wics-test/ccpacg/')

WebUI.openBrowser('')


LoginContext("mpetracca","mpetracca1");
//props.add(new TestObjectProperty("name", ConditionType.EQUALS, "UserName"));
/*

WebUI.setText(findTestObject('Object Repository/Page_CG AUSTRIA - Login/input_Login_utente'), 'PETRACCA')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_CG AUSTRIA - Login/input_Login_password'), '0UPVPN7E41imvqSiXfxE9w==')

WebUI.click(findTestObject('Object Repository/Page_CG AUSTRIA - Login/input_Login_submit'))

//Press Ctrl+A to select all text in txt_Comment'
WebUI.sendKeys(findTestObject('Object Repository/Page_CG AUSTRIA - Login/input_Login_utente'), Keys.chord(Keys.CONTROL, 
        'a'), FailureHandling.STOP_ON_FAILURE)

*/
//Thread.sleep(4000)
WebUI.closeBrowser()

def LoginContext(def userName, def password) {
    myTestObject = new TestObject('customObject')

    List<TestObject> props = new ArrayList<TestObjectProperty>()

    props.add(new TestObjectProperty('xpath', ConditionType.EQUALS, 'id(\'username'), 'PETRACCA')

    myTestObject.setProperties(props)

    WebUI.setText(myTestObject, 'Object Repository/Page_CG AUSTRIA - Login/')

    WebUI.setText(findTestObject('input_Login_utente'), username)
}

