package sahoo.hybridapp.example2.webclient;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.annotation.security.RolesAllowed;
import javax.annotation.Resource;
import javax.transaction.UserTransaction;
import java.io.PrintWriter;

@WebServlet(urlPatterns = "/login")
@RolesAllowed("Role1")
public class LoginServlet extends HttpServlet
{
    @Resource
    UserTransaction utx;

    public void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, java.io.IOException
    {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println("<HTML> <HEAD> <TITLE> Login " +
                "</TITLE> </HEAD> <BODY BGCOLOR=white>");

        String name = req.getParameter("name");
        String password = req.getParameter("password");
        try
        {
            // Uncomment utx.begin and commit and make necessary change in EJBs to see JTA propagation 
//            utx.begin();
            if (Activator.userAuthService != null) {
                if (Activator.userAuthService.login(name, password)) {
                    out.println("Welcome " + name);
                } else {
                    out.println("Incorrect user name or password. Try again");
                }
            } else {
                out.println("Service is not yet available");
            }
//            utx.commit();

        }
        catch (Exception e)
        {
            e.printStackTrace(out);
        }
        out.println("</BODY> </HTML> ");

    }
}
