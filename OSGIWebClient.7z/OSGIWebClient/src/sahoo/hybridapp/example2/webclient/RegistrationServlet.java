package sahoo.hybridapp.example2.webclient;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.annotation.Resource;
import javax.transaction.UserTransaction;
import java.io.PrintWriter;

@WebServlet(urlPatterns = "/registration")
public class RegistrationServlet extends HttpServlet
{
    /**
	 * 
	 */
	private static final long serialVersionUID = -2441151202700652620L;
	@Resource
    UserTransaction utx;

    public void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, java.io.IOException
    {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println("<HTML> <HEAD> <TITLE> Registration " +
                "</TITLE> </HEAD> <BODY BGCOLOR=white>");

        String name = req.getParameter("name");
        String password = req.getParameter("password");
        try
        {
//            utx.begin();
            if (Activator.userAuthService != null) {
                if (Activator.userAuthService.register(name, password)) {
                    out.println("Registered " + name);
                } else {
                    out.println("Failed to register " + name);
                }
            } else {
                out.println("Service is not yet available");
            }
//            utx.commit();
        }
        catch (Exception e)
        {
            e.printStackTrace(out);
        }
        out.println("</BODY> </HTML> ");

    }
}
