package it.ccg.portaladminweb.server.servlet.system;



import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.system.SystemProperties;
import it.ccg.portaladminejb.server.util.ExceptionUtil;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class PropertyRefresh
 */
public class SystemPropertiesLoad extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private PrintWriter out;
	
	private static Logger logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SystemPropertiesLoad() throws Exception {
    	super();
    	
    	
    }
    
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doWork(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doWork(request, response);
	}
    
    
    private void doWork(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	try {
    		// load system properties
    		SystemProperties.loadSystemProperties();
        	
    		// render page
    		this.renderPage(response);
    	}
    	catch(Exception e) {
    		// default logger
			try {
				ExceptionUtil.logCompleteStackTrace(logger, e);
				
				this.renderError(response, "Unable to load system properties. Read logs for details.");
			}
			catch(Exception e1) {
				
				e1.printStackTrace();
			}
		}
    	
    }
    
    private void renderPage(HttpServletResponse response) throws Exception {
    	
    	this.out = response.getWriter();
    	
    	this.out.println("Properties successfully loaded!" + "<br>");
    	this.out.println("<br>");
    	this.out.println(new Timestamp(System.currentTimeMillis()));
    	this.out.println("<br>");
		
		/*BufferedReader bufferedReader = new BufferedReader(new FileReader(new File(SystemProperties.getPropertiesFileAbsPath())));    
		
		String line = bufferedReader.readLine();
		
		while(line != null) {
			out.println(line + "<br>");
			
			line = bufferedReader.readLine();
		}*/
    }
    
    private void renderError(HttpServletResponse response, String errorMessage) throws Exception {
    	
    	this.out = response.getWriter();
    	
    	this.out.println("Error: " + errorMessage);
    	this.out.println();
    	this.out.println();
    }


}
