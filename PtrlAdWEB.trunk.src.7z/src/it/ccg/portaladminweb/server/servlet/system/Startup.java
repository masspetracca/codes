package it.ccg.portaladminweb.server.servlet.system;



import it.ccg.portaladminejb.server.bean.dao.RoleBeanLocal;
import it.ccg.portaladminejb.server.logengine.Log4jSetup;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;
import it.ccg.portaladminejb.server.system.SystemProperties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;


/**
 * Servlet implementation class Startup
 */
public class Startup extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger logger;
	
	private RoleBeanLocal roleBeanLocal;
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Startup() {
    	super();
    	
    	try {
    		System.out.println("Loading PortalAdmin system environment..");
    		
    		// load system properties
    		SystemProperties.loadSystemProperties();
    		
    		// load log4j properties
			Log4jSetup.loadLog4JProperties();
			
			// load WS user/role mapping settings
			Context ctx = new InitialContext();
			this.roleBeanLocal = (RoleBeanLocal)ctx.lookup("ejblocal:" + RoleBeanLocal.class.getCanonicalName());
			this.roleBeanLocal.loadUserRoleMapping();
			
			
			logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
    		
			logger.debug(new StandardLogMessage("PortalAdmin system environment successfully loaded."));
    	}
    	catch(Exception e) {
    		
    		e.printStackTrace();
		}
		
    }
    

}
