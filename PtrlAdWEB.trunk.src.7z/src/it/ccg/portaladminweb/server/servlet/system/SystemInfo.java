package it.ccg.portaladminweb.server.servlet.system;

import it.ccg.pamp.server.security.SessionInfoRemote;
import it.ccg.pamp.server.security.SessionUser;
import it.ccg.portaladminejb.server.bean.system.SystemInfoBeanLocal;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.system.SystemProperties;
import it.ccg.portaladminejb.server.util.ExceptionUtil;
import it.ccg.portaladminweb.server.rpcutil.POJO2Json;
import it.ccg.portaladminweb.server.system.RemoteBeanLookup;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Properties;

import javax.ejb.EJB;
import javax.rmi.PortableRemoteObject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

/**
 * Servlet implementation class SystemInfo
 */
public class SystemInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
	
	private PrintWriter outStream;
	
	
	@EJB
	private SystemInfoBeanLocal systemInfoBeanLocal;
	
	private SessionInfoRemote sessionInfoRemote;
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SystemInfo() {
        super();
    }
    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		throw new ServletException("SystemInfo servlet doesn\'t allow get requests.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String _operationId = request.getParameter("_operationId");
		
		if(_operationId == null) {
			
			throw new ServletException("Unable to process request. \'_operationId\' parameter not found.");
		}
		
		if(_operationId.equalsIgnoreCase("checkInstalledApp")) {
			
			this.checkInstalledApp(request, response);
		}
		else if(_operationId.equalsIgnoreCase("getLoggedUsers")) {
			
			this.getLoggedUsers(request, response);
		}
		else if(_operationId.equalsIgnoreCase("getEnviroment")) {
			
			this.getEnviroment(request, response);
		}
		else {
			
			throw new ServletException("Unable to process request. \'_operationId\' of type \'" + _operationId + "\' not valid.");
		}
		
	}
	
	
	@SuppressWarnings("unchecked")
	private void checkInstalledApp(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			List<String> list = this.systemInfoBeanLocal.listInstalledApps();
			
			JSONObject jsonObject = new JSONObject();
			
			if(list.contains(SystemProperties.getProperty("app.name"))) {
				
				jsonObject.put("installedAppCheck", "0");
			}
			else {
				
				jsonObject.put("installedAppCheck", "-1");
			}
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonObject.toJSONString());
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	private void getLoggedUsers(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// this is the response body
		String jsonString = null;
		
		try {
			//
			Object object = RemoteBeanLookup.lookup("ejb/CCGPortal/CCGPortalEJB.jar/SessionInfo#it.ccg.pamp.server.security.SessionInfoRemote");
			this.sessionInfoRemote = (SessionInfoRemote)PortableRemoteObject.narrow(object, SessionInfoRemote.class);
			
			// 
			List<SessionUser> list = this.sessionInfoRemote.listLoggedUsers();
			
			jsonString = POJO2Json.convert(SessionUser.class, list);
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
			
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
		
	}

	@SuppressWarnings("unchecked")
	private void getEnviroment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// this is the response body
		String jsonString = null;
		
		try {
			Properties properties = SystemProperties.getProperties();
			
			JSONObject jsonObject = new JSONObject();			
			jsonObject.put("environment", properties.getProperty("enviroment"));
			
			jsonString = jsonObject.toString();
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
			
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
		
	}
}
