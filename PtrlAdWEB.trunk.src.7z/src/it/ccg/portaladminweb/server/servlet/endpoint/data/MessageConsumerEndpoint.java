package it.ccg.portaladminweb.server.servlet.endpoint.data;

import it.ccg.pamp.server.queues.AsyncStarterManagerRemote;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;
import it.ccg.portaladminejb.server.util.ExceptionUtil;
import it.ccg.portaladminweb.server.system.RemoteBeanLookup;
import it.ccg.portaladminweb.server.system.UserLogUtil;

import java.io.IOException;
import java.io.PrintWriter;

import javax.rmi.PortableRemoteObject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

/**
 * Servlet implementation class MessageConsumerEndpoint
 */
public class MessageConsumerEndpoint extends DataEndpoint {
	private static final long serialVersionUID = 1L;
	
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = PALoggerFactory.getLogger(PALoggerFactory.USER_LOGGER);
	
	private PrintWriter outStream = null;
	
	
	private AsyncStarterManagerRemote asyncStarterManagerRemote;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MessageConsumerEndpoint() throws Exception {
        super();
    }
    
    
    @Override
	protected void fetch(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	String _operationId = request.getParameter("_operationId");
		
		if(_operationId == null) {
			
			throw new ServletException("Unable to process request. \'_operationId\' parameter not found.");
		}
		
		if(_operationId.equalsIgnoreCase("isMessageConsumerEnabled")) {
			
			this.isMessageConsumerEnabled(request, response);
		}
		else {
			
			throw new ServletException("Unable to process request. \'_operationId\' of type \'" + _operationId + "\' not valid.");
		}
    	
	}
    
    
	@Override
	protected void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String _operationId = request.getParameter("_operationId");
		
		if(_operationId == null) {
			
			throw new ServletException("Unable to process request. \'_operationId\' parameter not found.");
		}
		
		if(_operationId.equalsIgnoreCase("startMessageConsumer")) {
			
			this.startMessageConsumer(request, response);
		}
		else if(_operationId.equalsIgnoreCase("stopMessageConsumer")) {
			
			this.stopMessageConsumer(request, response);
		}
		else {
			
			throw new ServletException("Unable to process request. \'_operationId\' of type \'" + _operationId + "\' not valid.");
		}
		
	}
    
	

	@SuppressWarnings("unchecked")
	private void startMessageConsumer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// this is the response body
		String jsonString = null;
		
		try {
			//
			Object object = RemoteBeanLookup.lookup("ejb/CCGPortal/CCGPortalEJB.jar/AsyncStarterManager#it.ccg.pamp.server.queues.AsyncStarterManagerRemote");
			this.asyncStarterManagerRemote = (AsyncStarterManagerRemote)PortableRemoteObject.narrow(object, AsyncStarterManagerRemote.class);
			
			// 
			this.asyncStarterManagerRemote.startMessageConsumer();
			
			// log in userlog
			userLogger.info(new StandardLogMessage("CCGPortal message consumer enabled."));
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", "CCGPortal message consumer successfully enabled.");
			jsonString = jsonObject.toJSONString();
			
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", "Error. Read logs for details.");
			jsonString = jsonObject.toJSONString();
			
		}
		finally {
			
			// return data to client
    		this.outStream = response.getWriter();
    		this.outStream.print(jsonString);
		}
		
	}
	
	@SuppressWarnings("unchecked")
	private void stopMessageConsumer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// this is the response body
		String jsonString = null;
		
		try {
			//
			Object object = RemoteBeanLookup.lookup("ejb/CCGPortal/CCGPortalEJB.jar/AsyncStarterManager#it.ccg.pamp.server.queues.AsyncStarterManagerRemote");
			this.asyncStarterManagerRemote = (AsyncStarterManagerRemote)PortableRemoteObject.narrow(object, AsyncStarterManagerRemote.class);
			
			// 
			this.asyncStarterManagerRemote.stopMessageConsumer();
			
			// log in userlog
			userLogger.info(new StandardLogMessage("CCGPortal message consumer disabled."));
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", "CCGPortal message consumer successfully disabled.");
			jsonString = jsonObject.toJSONString();
			
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", "Error. Read logs for details.");
			jsonString = jsonObject.toJSONString();
			
		}
		finally {
			
			// return data to client
    		this.outStream = response.getWriter();
    		this.outStream.print(jsonString);
		}
		
	}
	
	
	@SuppressWarnings("unchecked")
	private void isMessageConsumerEnabled(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// this is the response body
		String jsonString = null;
		
		try {
			//
			Object object = RemoteBeanLookup.lookup("ejb/CCGPortal/CCGPortalEJB.jar/AsyncStarterManager#it.ccg.pamp.server.queues.AsyncStarterManagerRemote");
			this.asyncStarterManagerRemote = (AsyncStarterManagerRemote)PortableRemoteObject.narrow(object, AsyncStarterManagerRemote.class);
			
			// 
			boolean isMessageConsumerEnabled = this.asyncStarterManagerRemote.isMessageConsumerEnabled();
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("isMessageConsumerEnabled", isMessageConsumerEnabled);
			jsonString = jsonObject.toJSONString();
			
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", "Error. Read logs for details.");
			jsonString = jsonObject.toJSONString();
			
		}
		finally {
			
			// return data to client
    		this.outStream = response.getWriter();
    		this.outStream.print(jsonString);
		}
		
	}
	

}
