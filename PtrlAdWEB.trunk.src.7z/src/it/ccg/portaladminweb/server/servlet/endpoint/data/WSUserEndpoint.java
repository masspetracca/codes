package it.ccg.portaladminweb.server.servlet.endpoint.data;

import it.ccg.portaladminejb.server.bean.dao.WSUserBeanLocal;
import it.ccg.portaladminejb.server.dto.WSUserDTO;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.util.ExceptionUtil;
import it.ccg.portaladminweb.server.rpcutil.POJO2Json;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class WSUserEndpoint
 */
public class WSUserEndpoint extends DataEndpoint {
	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
	//private static final Logger userLogger = PALoggerFactory.getLogger(PALoggerFactory.USER_LOGGER);
	
	private PrintWriter outStream = null;
	
	@EJB
	private WSUserBeanLocal wsUserLocal;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WSUserEndpoint() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	
	@Override
	protected void fetch(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String _operationId = request.getParameter("_operationId");
			
			if(_operationId == null) {
				
				throw new ServletException("Unable to process request. \'_operationId\' parameter not found.");
			}
			
			
			if(_operationId.equalsIgnoreCase("fetchAll")) {
				
				this.fetchAll(request, response);
			}
			else if(_operationId.equalsIgnoreCase("fetchRoleRelated")) {
				
				this.fetchRoleRelated(request, response);
			}
			else if(_operationId.equalsIgnoreCase("fetchRoleNotRelated")) {
				
				this.fetchRoleNotRelated(request, response);
			}
			else {
				
				throw new ServletException("Unable to process request. \'_operationId\' of type \'" + _operationId + "\' not valid.");
			}
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	
	private void fetchAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try{
			// get data
			List<WSUserDTO> list = this.wsUserLocal.listWSUsers();
			
			// i need to return only uid
			for(WSUserDTO wsUserDTO : list) {
				
				wsUserDTO.setCn((String)null);
				wsUserDTO.setO((String)null);
				wsUserDTO.setC((String)null);
			}
			
			String jsonString = POJO2Json.convert(WSUserDTO.class, list);
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	private void fetchRoleRelated(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String roleValue = request.getParameter("role");
			
			if(roleValue == null) {
				
				throw new ServletException("Unable to process request. \'role\' parameter not found.");
			}
			
			List<WSUserDTO> list = this.wsUserLocal.listRoleRelatedUsers(roleValue);
			
			
			
			String jsonString = POJO2Json.convert(WSUserDTO.class, list);
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	private void fetchRoleNotRelated(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String roleValue = request.getParameter("role");
			
			if(roleValue == null) {
				
				throw new ServletException("Unable to process request. \'role\' parameter not found.");
			}
			
			List<WSUserDTO> list = this.wsUserLocal.listRoleNotRelatedUsers(roleValue);
			
			String jsonString = POJO2Json.convert(WSUserDTO.class, list);
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}

	
    

}
