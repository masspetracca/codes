package it.ccg.portaladminweb.server.servlet.endpoint.data;


import it.ccg.portaladminejb.server.bean.dao.LDAPUserBeanLocal;
import it.ccg.portaladminejb.server.bean.dao.RoleBeanLocal;
import it.ccg.portaladminejb.server.dto.LDAPUserDTO;
import it.ccg.portaladminejb.server.dto.Role;
import it.ccg.portaladminejb.server.dto.WSUserDTO;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.util.ExceptionUtil;
import it.ccg.portaladminweb.server.rpcutil.POJO2Json;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;


/**
 * Servlet implementation class GetRoles
 */
public class RoleEndpoint extends DataEndpoint {
	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
	//private static final Logger userLogger = PALoggerFactory.getLogger(PALoggerFactory.USER_LOGGER);
	
	private PrintWriter outStream = null;
	
	@EJB
	private RoleBeanLocal roleBeanLocal;
	
	@EJB
	private LDAPUserBeanLocal ldapUserBeanLocal;
	
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RoleEndpoint() {
        super();
        // TODO Auto-generated constructor stub
    }
	
	
	@Override
	protected void fetch(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String _operationId = request.getParameter("_operationId");
		
		if(_operationId == null) {
			
			throw new ServletException("Unable to process request. \'_operationId\' parameter not found.");
		}
		
		
		if(_operationId.equalsIgnoreCase("fetchAll")) {
			
			this.fetchAll(request, response);
		}
		else if(_operationId.equalsIgnoreCase("fetchUserRelated")) {
			
			this.fetchUserRelated(request, response);
		}
		else if(_operationId.equalsIgnoreCase("fetchUserNotRelated")) {
			
			this.fetchUserNotRelated(request, response);
		}
		else {
			
			throw new ServletException("Unable to process request. \'_operationId\' of type \'" + _operationId + "\' not valid.");
		}
		
		
	}
	

	private void fetchAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			List<Role> list = this.roleBeanLocal.listRoles();
			
			// remove 'remote' from role list
			list.remove(new Role("remote"));
			
			String jsonString = POJO2Json.convert(Role.class, list);
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
		}
		catch (Exception e) {

			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	private void fetchUserRelated(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String uid = request.getParameter("uid");
			
			if((uid == null) || (uid.equalsIgnoreCase("null")) || (uid.equalsIgnoreCase(""))) {
				
				throw new ServletException("Unable to process request. \'uid\' parameter not found.");
			}
			
			LDAPUserDTO ldapUserDTO = this.ldapUserBeanLocal.getLDAPUserByUID(uid);
			
			WSUserDTO wsUserDTO = new WSUserDTO(ldapUserDTO.getCn(), ldapUserDTO.getO(), ldapUserDTO.getC(), ldapUserDTO.getUid());
			
			String userContextName = wsUserDTO.getUserContextName();
			
			
			List<Role> list = this.roleBeanLocal.listUserRelatedRoles(userContextName);
			
			// remove 'remote' from role list
			list.remove(new Role("remote"));
			
			String jsonString = POJO2Json.convert(Role.class, list);
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	private void fetchUserNotRelated(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String uid = request.getParameter("uid");
			
			if((uid == null) || (uid.equalsIgnoreCase("null")) || (uid.equalsIgnoreCase(""))) {
				
				throw new ServletException("Unable to process request. \'uid\' parameter not found.");
			}
			
			LDAPUserDTO ldapUserDTO = this.ldapUserBeanLocal.getLDAPUserByUID(uid);
			
			WSUserDTO wsUserDTO = new WSUserDTO(ldapUserDTO.getCn(), ldapUserDTO.getO(), ldapUserDTO.getC(), ldapUserDTO.getUid());
			
			String userContextName = wsUserDTO.getUserContextName();
			
			
			List<Role> list = this.roleBeanLocal.listUserNotRelatedRoles(userContextName);
			
			// remove 'remote' from role list
			list.remove(new Role("remote"));
			
			String jsonString = POJO2Json.convert(Role.class, list);
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	
	
	
	

}
