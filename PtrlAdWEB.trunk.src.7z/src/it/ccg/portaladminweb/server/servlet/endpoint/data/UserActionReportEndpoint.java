package it.ccg.portaladminweb.server.servlet.endpoint.data;

import it.ccg.pamp.server.eao.UserActionReportRemote;
import it.ccg.pamp.server.utils.UserActionDto;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.util.ExceptionUtil;
import it.ccg.portaladminweb.server.rpcutil.POJO2Json;
import it.ccg.portaladminweb.server.smartgwt.util.ActionComparator;
import it.ccg.portaladminweb.server.system.RemoteBeanLookup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.rmi.PortableRemoteObject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class UserActionReportEndpoint
 */
public class UserActionReportEndpoint extends DataEndpoint {
	private static final long serialVersionUID = 1L;
	
	private UserActionReportRemote userActionRemote;
    
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
	//private static final Logger userLogger = PALoggerFactory.getLogger(PALoggerFactory.USER_LOGGER);
    /**
     * @see DataEndpoint#DataEndpoint()
     */
    public UserActionReportEndpoint() {
        super();
        // TODO Auto-generated constructor stub
    }

	@Override
	protected void fetch(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {

		try {
			
			Object object = RemoteBeanLookup.lookup("ejb/CCGPortal/CCGPortalEJB.jar/UserActionReport#it.ccg.pamp.server.eao.UserActionReportRemote");
			this.userActionRemote = (UserActionReportRemote)PortableRemoteObject.narrow(object, UserActionReportRemote.class);
			
	    	HashMap<String, UserActionDto> userActions= this.userActionRemote.getActionReport();
	    	
	    	Set<String> keys = userActions.keySet();
	    	Iterator<String> itKeys = keys.iterator();
	    	List<UserActionDto> dtos = new ArrayList<UserActionDto>();
	    	while(itKeys.hasNext()) {
	    		
	    		dtos.add(userActions.get(itKeys.next()));
	    	}
	    	
	    	Collections.sort(dtos, new ActionComparator());
	    	String jsonString = POJO2Json.convert(UserActionDto.class, dtos);
	    	
	    	
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client	
			response.getWriter().print(jsonString);
			
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}

}
