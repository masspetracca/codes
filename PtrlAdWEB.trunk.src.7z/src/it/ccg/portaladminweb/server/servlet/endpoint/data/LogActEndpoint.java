package it.ccg.portaladminweb.server.servlet.endpoint.data;

import it.ccg.portaladminejb.server.bean.eao.LogActEAOLocal;
import it.ccg.portaladminejb.server.bean.eao.util.Criteria;
import it.ccg.portaladminejb.server.bean.entity.LogActEntity;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.util.ExceptionUtil;
import it.ccg.portaladminweb.server.rpcutil.Entity2Json;
import it.ccg.portaladminweb.server.smartgwt.util.CriteriaParser;
import it.ccg.portaladminweb.server.smartgwt.util.HttpServletResponseUtil;

import java.io.IOException;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;


/**
 * Servlet implementation class LogActEndpoint
 */
public class LogActEndpoint extends DataEndpoint {
	private static final long serialVersionUID = 1L;

	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
	//private static final Logger userLogger = PALoggerFactory.getLogger(PALoggerFactory.USER_LOGGER);
	
	@EJB
	private LogActEAOLocal logActEAOLocal;
	
	/*@Override
	protected void fetch(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		logger.debug("getAllJons");
		List<LogActEntity> entityList = logAct.getAllJobs();
		logger.debug(entityList.size());
		logger.debug("convert");
		String jsonString = Entity2Json.convert(LogActEntity.class, entityList);
		
		// set response attributes
		response.setStatus(HttpServletResponse.SC_OK);
		// return data to client
		response.getWriter().print(jsonString);
	}*/
	
	@Override
	protected void fetch(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		
		try {
			// get criteria from request
			List<Criteria> criteriaList = CriteriaParser.getCriteria(request);
			
	        int startRow = Integer.parseInt(request.getParameter("_startRow"));  
	        int endRow = Integer.parseInt(request.getParameter("_endRow"));  
			
			// execute fetch
			List<LogActEntity> dataList = this.logActEAOLocal.fetch(criteriaList, startRow, endRow);
			
			String dataJsonString = Entity2Json.convert(LogActEntity.class, dataList);
			
			// execute fetch count
	        long totalRows = this.logActEAOLocal.fetchCount(criteriaList);
			
			String responseBody = HttpServletResponseUtil.getSmartClientResponseBody(dataJsonString, startRow, endRow, totalRows);
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			response.getWriter().print(responseBody);
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}


}
