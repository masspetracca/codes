package it.ccg.portaladminweb.server.servlet.endpoint.generic;

import it.ccg.portaladminejb.server.bean.business.RoleUserManagerBeanLocal;
import it.ccg.portaladminejb.server.bean.dao.LDAPUserBeanLocal;
import it.ccg.portaladminejb.server.bean.dao.RoleBeanLocal;
import it.ccg.portaladminejb.server.bean.dao.WSUserBeanLocal;
import it.ccg.portaladminejb.server.bean.system.PDFGeneratorLocal;
import it.ccg.portaladminejb.server.dto.LDAPUserDTO;
import it.ccg.portaladminejb.server.dto.Role;
import it.ccg.portaladminejb.server.dto.WSUserDTO;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;
import it.ccg.portaladminejb.server.system.MailManager;
import it.ccg.portaladminejb.server.system.SystemProperties;
import it.ccg.portaladminejb.server.util.ArrayUtil;
import it.ccg.portaladminejb.server.util.ExceptionUtil;
import it.ccg.portaladminweb.server.system.UserLogUtil;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

/**
 * Servlet implementation class ProcEndpoint
 */
public class ProcedureEndpoint extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = PALoggerFactory.getLogger(PALoggerFactory.USER_LOGGER);
	
	private PrintWriter outStream = null;
	
	@EJB
	private RoleUserManagerBeanLocal roleUserManagerBeanLocal;
	
	@EJB
	private RoleBeanLocal roleBeanLocal;
	
	@EJB
	private WSUserBeanLocal wsUserBeanLocal;
	
	@EJB
	private PDFGeneratorLocal pdfGenerator;
	
	@EJB
	private LDAPUserBeanLocal ldapUserBeanLocal;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcedureEndpoint() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String _operationId = request.getParameter("_operationId");
		
		if(_operationId == null) {
			
			throw new ServletException("Unable to process request. \'_operationId\' parameter not found.");
		}
		
		
		if(_operationId.equalsIgnoreCase("saveUserRoleMatching")) {
			
			this.saveUserRoleMatching(request, response);
		}
		else if(_operationId.equalsIgnoreCase("saveRoleUserMatching")) {
			
			this.saveRoleUserMatching(request, response);
		}
		else if(_operationId.equalsIgnoreCase("sendReport")) {
			
			this.sendReport(request, response);
		}
		else if(_operationId.equalsIgnoreCase("sendNewPassword")) {
			
			this.sendNewPassword(request, response);
		}
		else{
			
			throw new ServletException("Unable to process request. \'_operationId\' of type \'" + _operationId + "\' not valid.");
		}
		
		
	}
	
	
	
	@SuppressWarnings("unchecked")
	private void saveUserRoleMatching(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// this is the response body
		String jsonString = null;
		
		try {
			String uid = request.getParameter("uid");
			
			// i need the userContextName
			LDAPUserDTO ldapUserDTO = this.ldapUserBeanLocal.getLDAPUserByUID(uid);
			
			if(ldapUserDTO == null) {
				
				throw new Exception("User uid: " + uid + " not found on LDAP.");
			}
			
			WSUserDTO wsUserDTO = new WSUserDTO(ldapUserDTO.getCn(), ldapUserDTO.getO(), ldapUserDTO.getC(), ldapUserDTO.getUid());
			String userContextName = wsUserDTO.getUserContextName();
			
			
			String[] roles = request.getParameter("roles").split("\\$");
			
			
			Map<String, String[]> userRolesMap = new HashMap<String, String[]>();
			userRolesMap.put(userContextName, roles);
			
			
			// get old values before changing
			List<Role> oldUserRelatedRoles = this.roleBeanLocal.listUserRelatedRoles(userContextName);
			
			this.roleUserManagerBeanLocal.saveUserRoleMatching(userRolesMap);
			
			// log in userlog
			userLogger.info(new StandardLogMessage("User/Role mapping configuration saved for user \'" + userContextName + "\'. New values: " + ArrayUtil.toList(roles) + ", Old values: " + oldUserRelatedRoles));
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", "CCGPortal user/role matching configuration correctly updated.");
			jsonString = jsonObject.toJSONString();
			
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", "Procedure execution failed. Error: " + e.getMessage() + ". Read logs for details.");
			jsonString = jsonObject.toJSONString();
			
		}
		finally {
			
			// return data to client
    		this.outStream = response.getWriter();
    		this.outStream.print(jsonString);
		}
		
	}
	
	
	@SuppressWarnings("unchecked")
	private void saveRoleUserMatching(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// this is the response body
		String jsonString = null;
		
		try {
			String role = request.getParameter("role");
			String[] uids = request.getParameter("uids").split("\\$");
			
			// i need the userContextName
			List<String> userContextNameList = new ArrayList<String>();
			for(String uid : uids) {
				
				LDAPUserDTO ldapUserDTO = this.ldapUserBeanLocal.getLDAPUserByUID(uid);
				
				if(ldapUserDTO == null) {
					
					throw new Exception("User uid: " + uid + " not found on LDAP.");
				}
				
				WSUserDTO wsUserDTO = new WSUserDTO(ldapUserDTO.getCn(), ldapUserDTO.getO(), ldapUserDTO.getC(), ldapUserDTO.getUid());
				
				userContextNameList.add(wsUserDTO.getUserContextName());
			}
			
			Object[] tempArray = userContextNameList.toArray();
			String[] userContextNameArray = new String[tempArray.length];
			for(int i=0; i<userContextNameArray.length; i++) {
				
				userContextNameArray[i] = (String)tempArray[i];
			}
			
			Map<String, String[]> roleUsersMap = new HashMap<String, String[]>();
			roleUsersMap.put(role, userContextNameArray);
			
			
			// get old values before changing
			List<WSUserDTO> oldRoleRelatedUsers = this.wsUserBeanLocal.listRoleRelatedUsers(role);
			List<String> oldUserContextNameList = new ArrayList<String>();
			for(WSUserDTO wsUserDTO : oldRoleRelatedUsers) {
				
				oldUserContextNameList.add(wsUserDTO.getUserContextName());
			}
			
			this.roleUserManagerBeanLocal.saveRoleUserMatching(roleUsersMap);
			
			// log in userlog
			userLogger.info(new StandardLogMessage("Role/User mapping configuration saved for role \'" + role + "\'. New values: " + userContextNameList + ", Old values: " + oldUserContextNameList));
			

			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", "CCGPortal user/role matching configuration correctly updated.");
			jsonString = jsonObject.toJSONString();
			
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", "Procedure execution failed. Error: " + e.getMessage() + ". Read logs for details.");
			jsonString = jsonObject.toJSONString();
			
		}
		finally {
			
			// return data to client
    		this.outStream = response.getWriter();
    		this.outStream.print(jsonString);
		}
		
	}
	
	
	@SuppressWarnings("unchecked")
	private void sendReport(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String jsonString = null;
		
		try {
			logger.debug(new StandardLogMessage("populateMap"));
			Map<LDAPUserDTO,List<Role>> mappa = this.pdfGenerator.populateMap();

			logger.debug(new StandardLogMessage("generatePdf"));
			this.pdfGenerator.generatePdf(mappa);
			
			File f = new File(SystemProperties.getProperty("user.install.root")+SystemProperties.getProperty("file.separator")+SystemProperties.getProperty("temp_report_file"));
			logger.debug(new StandardLogMessage("file "+f.getAbsolutePath()));
			
			MailManager mail = new MailManager();
			logger.debug(new StandardLogMessage("sendMail"));
			mail.sendMail("Report", "Report Attached", f);
			
			// delete temporary file
			this.pdfGenerator.cleanTemporaryFile();
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", "Report correctly sent.");
			jsonString = jsonObject.toJSONString();
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", "Error sending report.");
			jsonString = jsonObject.toJSONString();
		}
		finally {
			
			// return data to client
    		this.outStream = response.getWriter();
    		this.outStream.print(jsonString);
		}
		
	}
	
	@SuppressWarnings("unchecked")
	private void sendNewPassword(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String user = request.getParameter("user");
		String jsonString = null;
		
		try {
			LDAPUserDTO ldapUserDTO = this.ldapUserBeanLocal.getLDAPUserByContextName(user);
			
			if(ldapUserDTO.getMail()==null || ldapUserDTO.getMail().equalsIgnoreCase("")){
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("message", "Error, selected user doesn't have e-mail address");
				jsonString = jsonObject.toJSONString();
				
			}else{
				this.ldapUserBeanLocal.sendNewLDAPUserPasssword(ldapUserDTO);
				
				response.setStatus(HttpServletResponse.SC_OK);
				
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("message", "New password correctly sended.");
				jsonString = jsonObject.toJSONString();
			}
			
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", "Error during send new password.");
			jsonString = jsonObject.toJSONString();
			
		}finally {
			
			// return data to client
    		this.outStream = response.getWriter();
    		this.outStream.print(jsonString);
		}
		
	}
	

}
