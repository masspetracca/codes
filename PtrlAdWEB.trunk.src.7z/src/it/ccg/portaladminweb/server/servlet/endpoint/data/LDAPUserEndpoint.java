package it.ccg.portaladminweb.server.servlet.endpoint.data;

import it.ccg.portaladminejb.server.bean.dao.LDAPUserBeanLocal;
import it.ccg.portaladminejb.server.dto.LDAPUserDTO;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;
import it.ccg.portaladminejb.server.system.SystemProperties;
import it.ccg.portaladminejb.server.util.ExceptionUtil;
import it.ccg.portaladminweb.server.rpcutil.POJO2Json;
import it.ccg.portaladminweb.server.system.UserLogUtil;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class UserEndpoint
 */
public class LDAPUserEndpoint extends DataEndpoint {
	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = PALoggerFactory.getLogger(PALoggerFactory.USER_LOGGER);
	
	private PrintWriter outStream = null;
	
	@EJB
	private LDAPUserBeanLocal ldapUserBeanLocal;
	
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LDAPUserEndpoint() {
        super();
        // TODO Auto-generated constructor stub
    }

    
    
    @Override
	protected void fetch(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	String _operationId = request.getParameter("_operationId");
		
		if(_operationId == null) {
			
			throw new ServletException("Unable to process request. \'_operationId\' parameter not found.");
		}
		
		
		if(_operationId.equalsIgnoreCase("fetchAll")) {
			
			this.fetchAll(request, response);
		}
		else if(_operationId.equalsIgnoreCase("fetch_O_C_OU")) {
			
			this.fetch_O_C_OU(request, response);
		}
		else {
			
			throw new ServletException("Unable to process request. \'_operationId\' of type \'" + _operationId + "\' not valid.");
		}
		
	}
    
    
    
    
	private void fetchAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			List<LDAPUserDTO> list = this.ldapUserBeanLocal.listLDAPUsers();
			
			String jsonString = POJO2Json.convert(LDAPUserDTO.class, list);
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
	}
	
	
	
	private void fetch_O_C_OU(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			Map<String, String> map = this.ldapUserBeanLocal.get_O_C_OU();
			
			String jsonString = POJO2Json.convert(Map.class, map);
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
	}
	



	@Override
	protected void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String cn = request.getParameter("cn");
			String sn = request.getParameter("sn");
			String uid = request.getParameter("uid");
			String o = SystemProperties.getProperty("ldap.user_set.o");
			String c = SystemProperties.getProperty("ldap.user_set.c");
			String userpassword = request.getParameter("userpassword");
			String mailAddress = request.getParameter("mailAddress");
			String ou = request.getParameter("ou");
			
			// Salto il controllo dei parametri, il client garantisce
			// che arrivino valori !null e !blank
			
			LDAPUserDTO ldapUserDTO = new LDAPUserDTO(cn, sn, uid,o,c, userpassword, mailAddress, ou);
			
			
			if(this.ldapUserBeanLocal.exists(ldapUserDTO)) {
				
				throw new Exception("User \'" + ldapUserDTO + "\' already exists on LDAP.");
			}
			if(this.ldapUserBeanLocal.uidAlreadyInUse(ldapUserDTO)) {
				
				throw new Exception("uid \'" + ldapUserDTO.getUid() + "\' already in use on LDAP. " + ldapUserDTO);
			}
			
			
			this.ldapUserBeanLocal.addLDAPUser(ldapUserDTO);
			
			
			// default logger
			logger.info(new StandardLogMessage("User " + ldapUserDTO + " created in LDAP register."));
			// log in userlog
			userLogger.info(new StandardLogMessage("User " + ldapUserDTO + " created in LDAP register."));
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	
	@Override
	protected void remove(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String user = request.getParameter("user");
			
			// Salto il controllo dei parametri, il client garantisce
			// che arrivino valori !null
			
			
			LDAPUserDTO ldapUserDTO = this.ldapUserBeanLocal.getLDAPUserByContextName(user);
			
			
			if(ldapUserDTO != null) {
				this.ldapUserBeanLocal.removeLDAPUser(ldapUserDTO);
				
				// default logger
				logger.info(new StandardLogMessage("User " + ldapUserDTO + " removed from LDAP register."));
				// log in userlog
				userLogger.info(new StandardLogMessage("User " + ldapUserDTO + " removed from LDAP register."));
			}
			else {
				
				throw new Exception("Unable to remove user " + user + ". User not found in LDAP register.");
			}
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
	}
	
	
	
	
	

}
