package it.ccg.portaladminweb.server.servlet.endpoint.data;


import it.ccg.pamp.server.schedulers.SchedulerBeanRemote;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;
import it.ccg.portaladminejb.server.util.ExceptionUtil;
import it.ccg.portaladminweb.server.rpcutil.POJO2Json;
import it.ccg.portaladminweb.server.system.RemoteBeanLookup;
import it.ccg.portaladminweb.server.system.UserLogUtil;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.rmi.PortableRemoteObject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class ScheduleDataEndpoint
 */
public class ScheduleDataEndpoint extends DataEndpoint {
	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = PALoggerFactory.getLogger(PALoggerFactory.USER_LOGGER);
	
	private PrintWriter outStream = null;
    
	
	private SchedulerBeanRemote schedulerBeanRemote;
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ScheduleDataEndpoint()throws Exception {
        super();
    }
    
    
    
	@Override
	protected void fetch(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			//
			Object object = RemoteBeanLookup.lookup("ejb/CCGPortal/CCGPortalEJB.jar/SchedulerBean#it.ccg.pamp.server.schedulers.SchedulerBeanRemote");
			this.schedulerBeanRemote = (SchedulerBeanRemote)PortableRemoteObject.narrow(object, SchedulerBeanRemote.class);
			
			String activeTimerBatchString = this.schedulerBeanRemote.getActiveTimer();
			
			String[] activeTimerBatchArray = activeTimerBatchString.substring(0, activeTimerBatchString.length() - 1).split(",");
			
			List<Map<String, String>> activeTimerBatchList = new ArrayList<Map<String,String>>();
			
			Map<String, String> tempMap = null;
			for(String batch : activeTimerBatchArray) {
				
				if(!batch.equalsIgnoreCase("No schedule enable")) {
					
					tempMap = new HashMap<String, String>();
					tempMap.put("batchName", batch);
					
					activeTimerBatchList.add(tempMap);
				}
			}
			
			
			String jsonString = POJO2Json.convert(Map.class, activeTimerBatchList);
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
		}
		catch (Exception e) {

			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}



	@Override
	protected void remove(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String _operationId = request.getParameter("_operationId");
			
			if(_operationId == null) {
				
				throw new ServletException("Unable to process request. \'_operationId\' parameter not found.");
			}
			
			
			if(_operationId.equalsIgnoreCase("removeAll")) {
				
				this.removeAll(request, response);
			}
			else if(_operationId.equalsIgnoreCase("removeOne")) {
				
				this.removeOne(request, response);
			}
			else {
				
				throw new ServletException("Unable to process request. \'_operationId\' of type \'" + _operationId + "\' not valid.");
			}
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	private void removeAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			//
			Object object = RemoteBeanLookup.lookup("ejb/CCGPortal/CCGPortalEJB.jar/SchedulerBean#it.ccg.pamp.server.schedulers.SchedulerBeanRemote");
			this.schedulerBeanRemote = (SchedulerBeanRemote)PortableRemoteObject.narrow(object, SchedulerBeanRemote.class);
			
			this.schedulerBeanRemote.stop();
			
			// default logger
			logger.info(new StandardLogMessage("All schedules removed from CCGPortal timer service."));
			// log in userlog
			userLogger.info(new StandardLogMessage("All schedules removed from CCGPortal timer service."));
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	private void removeOne(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			//
			Object object = RemoteBeanLookup.lookup("ejb/CCGPortal/CCGPortalEJB.jar/SchedulerBean#it.ccg.pamp.server.schedulers.SchedulerBeanRemote");
			this.schedulerBeanRemote = (SchedulerBeanRemote)PortableRemoteObject.narrow(object, SchedulerBeanRemote.class);
			
			String batchName = request.getParameter("batchName");
			
			this.schedulerBeanRemote.stop(batchName);
			
			// default logger
			logger.info(new StandardLogMessage("Schedule \'batchName=" + batchName + "\' removed from CCGPortal timer service."));
			// log in userlog
			userLogger.info(new StandardLogMessage("Schedule \'batchName=" + batchName + "\' removed from CCGPortal timer service."));
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	

}
