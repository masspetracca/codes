package it.ccg.portaladminweb.server.servlet.endpoint.data;

import it.ccg.pamp.server.queues.AsyncStarterManagerRemote;
import it.ccg.pamp.server.queues.PAMPQueueEntry;
import it.ccg.portaladminejb.server.bean.dao.PAMPQueueBeanLocal;
import it.ccg.portaladminejb.server.bean.eao.BatchEAOLocal;
import it.ccg.portaladminejb.server.bean.entity.BatchEntity;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;
import it.ccg.portaladminejb.server.util.ExceptionUtil;
import it.ccg.portaladminweb.server.rpcutil.Entity2Json;
import it.ccg.portaladminweb.server.rpcutil.POJO2Json;
import it.ccg.portaladminweb.server.system.RemoteBeanLookup;
import it.ccg.portaladminweb.server.system.UserLogUtil;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.rmi.PortableRemoteObject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

/**
 * Servlet implementation class QueueEndpoint
 */
public class QueueEndpoint extends DataEndpoint {
	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = PALoggerFactory.getLogger(PALoggerFactory.USER_LOGGER);
	
	@EJB
	private PAMPQueueBeanLocal queueBean;
	
	@EJB
	private BatchEAOLocal batchEAOLocal;
	
	private PrintWriter outStream = null;	
	private AsyncStarterManagerRemote asyncStarterManagerRemote;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QueueEndpoint() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
	protected void fetch(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	try {
			String _operationId = request.getParameter("_operationId");
			
			if(_operationId == null) {
				
				throw new ServletException("Unable to process request. \'_operationId\' parameter not found.");
			}
			
			
			if(_operationId.equalsIgnoreCase("fetchQueueEntry")) {
				
				this.fetchQueueEntry(request, response);
			}
			else if(_operationId.equalsIgnoreCase("fetchAllJobs")) {
				
				this.fetchAllJobs(request, response);
			}
			else {
				
				throw new ServletException("Unable to process request. \'_operationId\' of type \'" + _operationId + "\' not valid.");
			}
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
    	
	}
    
    
	@SuppressWarnings("unchecked")
	@Override
	protected void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String _operationId = request.getParameter("_operationId");
		String jsonString = null;
		
		try {
			if(_operationId==null){
				throw new ServletException("Unable to process request. \'_operationId\' parameter not found.");
			}
			
			if(_operationId.equalsIgnoreCase("appendJob")){
				String batchID = request.getParameter("batchID");

				String user = request.getUserPrincipal().getName();
				
				queueBean.addQueueEntry(batchID, user);
				
				response.setStatus(HttpServletResponse.SC_OK);
				
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("message", "Schedule sended");
				jsonString = jsonObject.toJSONString();
				
			}else{
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("message", "Error, cannot find operation");
				jsonString = jsonObject.toJSONString();
			}
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}finally {
			
			// return data to client
    		this.outStream = response.getWriter();
    		this.outStream.print(jsonString);
		}
	    	
	}

	@Override
	protected void remove(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
    		int n = this.asyncStarterManagerRemote.emptyQueue();
    		
    		// default logger
			logger.info(new StandardLogMessage(n + " messages removed from MDBStarter."));
			// log in userlog
			userLogger.info(new StandardLogMessage(n + " messages removed from MDBStarter."));
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
    	}
    	catch (Exception e) {
    		
    		ExceptionUtil.logCompleteStackTrace(logger, e);
    		//
    		userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
    	
	}
	
	/**
	 * Method to fetch all jobs presents on pmptbatch
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void fetchAllJobs(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			//
			logger.debug("getAllJobs");

			List<BatchEntity> entityList = this.batchEAOLocal.getAllJobs();

			logger.debug(entityList.size());
			logger.debug("convert");
			
			String jsonString = Entity2Json.convert(BatchEntity.class, entityList);
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			response.getWriter().print(jsonString);

		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//
			userLogger.error(new StandardLogMessage(UserLogUtil.getUserLogFormatLine(request)));
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
    
	/**
	 * Method to fetch all queue entry
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void fetchQueueEntry(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		try {
    		//
			Object object = RemoteBeanLookup.lookup("ejb/CCGPortal/CCGPortalEJB.jar/AsyncStarterManager#it.ccg.pamp.server.queues.AsyncStarterManagerRemote");
			this.asyncStarterManagerRemote = (AsyncStarterManagerRemote)PortableRemoteObject.narrow(object, AsyncStarterManagerRemote.class);
			
        	List<PAMPQueueEntry> list = this.asyncStarterManagerRemote.listQueueEntries();
        	
    		String jsonString = POJO2Json.convert(PAMPQueueEntry.class, list);
    		
    		
    		// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
    	}
    	catch (Exception e) {
    		
    		ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
	}

}
