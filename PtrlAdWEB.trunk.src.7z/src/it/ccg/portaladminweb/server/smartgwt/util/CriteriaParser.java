package it.ccg.portaladminweb.server.smartgwt.util;

import it.ccg.portaladminejb.server.bean.eao.util.Criteria;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.parser.JSONParser;

public class CriteriaParser {
	
	
	public static List<Criteria> getCriteria(HttpServletRequest request) throws Exception {
		
		List<Criteria> criteriaList = new ArrayList<Criteria>();
		
		
		String[] criteriaStructArray = request.getParameterValues("criteria");
		if(criteriaStructArray != null) {
			
			JSONParser jsonParser = new JSONParser();
			
			for(String criteriaStruct : criteriaStructArray) {
				
				@SuppressWarnings("unchecked")
				Map<String, String> criteriaMap = (Map<String, String>)jsonParser.parse(criteriaStruct);
				
				if(!criteriaMap.get("fieldName").equalsIgnoreCase("_$")) {
					
					criteriaList.add(new Criteria(criteriaMap.get("fieldName"), criteriaMap.get("operator"), criteriaMap.get("value")));
				}
			}
		}
		
		
		return criteriaList;
	}
	
	
}
