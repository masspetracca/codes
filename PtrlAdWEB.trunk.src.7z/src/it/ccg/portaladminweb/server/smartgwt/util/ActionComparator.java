package it.ccg.portaladminweb.server.smartgwt.util;

import it.ccg.pamp.server.utils.UserActionDto;

import java.util.Comparator;

public class ActionComparator implements Comparator<UserActionDto> {

	@Override
	public int compare(UserActionDto object1, UserActionDto object2) {
		
		return object2.getActionDate().compareTo(object1.getActionDate());
	}

}
