package it.ccg.portaladminweb.server.smartgwt.util;

public class HttpServletResponseUtil {
	
	public static String getSmartClientResponseBody(String dataJsonString, int startRow, int endRow, long totalRows) {
		
		String responseBody = new String();
		
		
		responseBody += "{";
		
		responseBody += "response:{";
		
		responseBody += "status:" + 0 + ",";
		responseBody += "startRow:" + startRow + ",";
		responseBody += "endRow:" + endRow + ",";
		responseBody += "totalRows:" + totalRows + ",";
		responseBody += "data:" + dataJsonString;
		
		responseBody += "}";
		
		responseBody += "}";
		
		
		return responseBody;
	}


}
