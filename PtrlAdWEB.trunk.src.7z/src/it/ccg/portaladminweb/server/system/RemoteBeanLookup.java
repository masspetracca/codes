package it.ccg.portaladminweb.server.system;

import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;
import it.ccg.portaladminejb.server.security.Security;
import it.ccg.portaladminejb.server.system.SystemProperties;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.log4j.Logger;

public class RemoteBeanLookup {
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
	
	
	public static Object lookup(String remoteInterfaceGlobalJNDI) throws Exception {
		
		Hashtable<String, String> env = new Hashtable<String, String>();
        
		// This is the default
		/*env.put(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.websphere.naming.WsnInitialContextFactory");  
		env.put(Context.PROVIDER_URL, "corbaloc:iiop:localhost:2809");*/ 
		env.put(Context.SECURITY_PRINCIPAL, SystemProperties.getProperty("pamp_rmi.user")); 
		env.put(Context.SECURITY_CREDENTIALS, Security.decodeBASE64(SystemProperties.getProperty("pamp_rmi.password"))); 
		
		Context context = new InitialContext(env);
		
		Object object = context.lookup(remoteInterfaceGlobalJNDI);
		
		logger.debug(new StandardLogMessage("Looked up: " + object.getClass()));
		
		
		return object;
	}
	

}
