package it.ccg.portaladminweb.server.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class CharsetFilter
 */
public class ResponseSettingsFilter implements Filter {

    /**
     * Default constructor. 
     */
    public ResponseSettingsFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		HttpServletResponse httpServletResponse = (HttpServletResponse)response;
		
		// content type necessary for correct client data parsing (SmartGwt client)
		httpServletResponse.setContentType("text/html; charset=utf-8");
		
		// lock for iframes
		httpServletResponse.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		httpServletResponse.addHeader("Strict-Transport-Security", "max-age=31536000");
		
		
		// pass the request along the filter chain
		chain.doFilter(request, httpServletResponse);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
