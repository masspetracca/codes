package it.ccg.portaladminweb.client;

import it.ccg.portaladminweb.client.rpc.PARPCRequest;

import java.util.HashMap;
import java.util.Map;

import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONValue;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.tab.Tab;
import com.smartgwt.client.widgets.tab.TabSet;
import com.smartgwt.client.widgets.tab.events.TabDeselectedEvent;
import com.smartgwt.client.widgets.tab.events.TabDeselectedHandler;
import com.smartgwt.client.widgets.tab.events.TabSelectedEvent;
import com.smartgwt.client.widgets.tab.events.TabSelectedHandler;


public class MainLayout extends VLayout {
	
	private static MainLayout mainLayout; //	mainLayout
	private HLayout tabSetHLayout = new HLayout(); //		tabSetHLayout
	private HLayout headerHLayout = new HLayout();
	
	private Tab userListTab;
	private Tab queueListTab;
	private Tab userRoleTab;
	private Tab roleUserTab;
	private Tab logTab;
	private Tab scheduleTab;
	private Tab logActTab;
	private Tab useActTab;
	private Label envLabel;
	
	public static MainLayout getInstance() {
		
		mainLayout = new MainLayout();
		
		return mainLayout;
	}
	
	public MainLayout() {
		super();
		
		this.setWidth("99%");
		this.setHeight("99%");
		
		
		// header -----------------------------------------------------------------------
		
		//this.headerHLayout.setHeight("10%");
		this.headerHLayout.setHeight(60);
		this.headerHLayout.setWidth100();
		this.headerHLayout.setLayoutTopMargin(new Integer(5));
		//this.headerHLayout.setShowResizeBar(true);
		this.headerHLayout.setAlign(VerticalAlignment.CENTER);
		
		// logo  
		Img logoImg = new Img("CCGlogo.gif", 386, 51);  	
		this.headerHLayout.addMember(logoImg, 0);
		
		//env
		Map<String,String> params = new HashMap<String, String>();
		params.put("_operationId", "getEnviroment");
		
		PARPCRequest request = new PARPCRequest("servlet/system/SystemInfo", params);
		RPCManager.sendRequest(request, new RPCCallback() {
			
			@Override
			public void execute(RPCResponse response, Object rawData, RPCRequest request) {
				
				String responseBody = response.getHttpResponseText();
				
				JSONValue jsonValue = JSONParser.parseStrict(responseBody);
				JSONObject jsonObject = jsonValue.isObject();
				
				String enviroment = jsonObject.get("environment").isString().stringValue();
				envLabel = new Label("<font color=\"005596\"><nobr> <b>" + enviroment + " enviroment</b><nobr></font>");
				
				envLabel.setTop(40);
				envLabel.setLeft(352);
				
				headerHLayout.addMember(envLabel, 1);
			}
		});
		
		
		
		// white space
		LayoutSpacer layoutSpacer = new LayoutSpacer();
		layoutSpacer.setHeight("10%");
		layoutSpacer.setWidth100();
		this.headerHLayout.addMember(layoutSpacer, 2);
		
		// user info
		this.headerHLayout.addMember(new HeaderUserSection(), 3);
		
		// header -------------------------------------------------------------------
		
		
		
		// tab set ----------------------------------------------------------------------
		TabSet tabSet = new TabSet(); 
			
		//
		this.userListTab = new Tab("Users");
		// not needed, this tab is the first one, so at startup the code will enter the onTabSelected method
		//this.userListTab.setPane(new LDAPUserCanvas());
		this.userListTab.addTabSelectedHandler(new TabSelectedHandler() {
			
			@Override
			public void onTabSelected(TabSelectedEvent event) {
				
				userListTab.setPane(new LDAPUserCanvas());
			}
		});
		this.userListTab.addTabDeselectedHandler(new TabDeselectedHandler() {
			
			@Override
			public void onTabDeselected(TabDeselectedEvent event) {
				
				userListTab.getPane().destroy();
			}
		});
		
		
		        
        //
		this.userRoleTab = new Tab("User/Role Mapping");
		this.userRoleTab.addTabSelectedHandler(new TabSelectedHandler() {
			
			@Override
			public void onTabSelected(TabSelectedEvent event) {
				
				userRoleTab.setPane(new UserRoleCanvas());
				
			}
		});
		this.userRoleTab.addTabDeselectedHandler(new TabDeselectedHandler() {
			
			@Override
			public void onTabDeselected(TabDeselectedEvent event) {
				
				userRoleTab.getPane().destroy();
			}
		});
		
		
        //
		this.roleUserTab = new Tab("Role/Users Mapping");
        this.roleUserTab.addTabSelectedHandler(new TabSelectedHandler() {
			
			@Override
			public void onTabSelected(TabSelectedEvent event) {
				
				roleUserTab.setPane(new RoleUserCanvas());
			}
		});
        this.roleUserTab.addTabDeselectedHandler(new TabDeselectedHandler() {
			
			@Override
			public void onTabDeselected(TabDeselectedEvent event) {
				
				roleUserTab.getPane().destroy();
			}
		});
		
        
        //
		this.scheduleTab = new Tab("Schedule");
		this.scheduleTab.addTabSelectedHandler(new TabSelectedHandler() {
			
			@Override
			public void onTabSelected(TabSelectedEvent event) {
				
				scheduleTab.setPane(new SchedulerCanvas());
			}
		});
		this.scheduleTab.addTabDeselectedHandler(new TabDeselectedHandler() {
			
			@Override
			public void onTabDeselected(TabDeselectedEvent event) {
				
				scheduleTab.getPane().destroy();
			}
		});
		
        
        //
		this.queueListTab = new Tab("Queue");
		this.queueListTab.addTabSelectedHandler(new TabSelectedHandler() {
			
			@Override
			public void onTabSelected(TabSelectedEvent event) {
				
				queueListTab.setPane(new QueueCanvas());
			}
		});
		this.queueListTab.addTabDeselectedHandler(new TabDeselectedHandler() {
			
			@Override
			public void onTabDeselected(TabDeselectedEvent event) {
				
				queueListTab.getPane().destroy();
			}
		});
		
		
		//
		this.logTab = new Tab("Log");
		this.logTab.addTabSelectedHandler(new TabSelectedHandler() {
			
			@Override
			public void onTabSelected(TabSelectedEvent event) {
				
				logTab.setPane(new LogCanvas());
			}
		});
		this.logTab.addTabDeselectedHandler(new TabDeselectedHandler() {
			
			@Override
			public void onTabDeselected(TabDeselectedEvent event) {
				
				logTab.getPane().destroy();
			}
		});
		
		// logAct tab
		this.logActTab = new Tab("Pamp Activity Log");
		this.logActTab.addTabSelectedHandler(new TabSelectedHandler() {
			
			@Override
			public void onTabSelected(TabSelectedEvent event) {
				
				logActTab.setPane(new JobLogCanvas());
			}
		});
		this.logActTab.addTabDeselectedHandler(new TabDeselectedHandler() {
			
			@Override
			public void onTabDeselected(TabDeselectedEvent event) {
				
				logActTab.getPane().destroy();
			}
		});
		
		//userAction tab
		this.useActTab = new Tab("Pamp User Action");
		this.useActTab.addTabSelectedHandler(new TabSelectedHandler() {
			
			@Override
			public void onTabSelected(TabSelectedEvent event) {
				
				useActTab.setPane(new UserActionsReportCanvas());
			}
		});
		this.useActTab.addTabDeselectedHandler(new TabDeselectedHandler() {
			
			@Override
			public void onTabDeselected(TabDeselectedEvent event) {
				
				useActTab.getPane().destroy();
			}
		});
		
		
		// add every tabs to tabSet
        tabSet.setTabs(this.userListTab, this.userRoleTab, this.roleUserTab, this.scheduleTab, this.queueListTab, this.logActTab,this.useActTab, this.logTab);
        
        this.tabSetHLayout.addMember(tabSet);
        this.tabSetHLayout.setLayoutTopMargin(20);
        // tab set ----------------------------------------------------------------------
        
        this.addMember(this.headerHLayout);
		this.addMember(this.tabSetHLayout);
		
		this.setLeft("8");
		this.setTop("3");
		
		// ***************************************************************************
		
		
		
		//
		this.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(Window.getById("_AccountWindow") != null) {
					
					mainLayout.removeChild(Window.getById("_AccountWindow"));
					
					Window.getById("_AccountWindow").destroy();
				}
				if(Window.getById("_UsersWindow") != null) {
					
					mainLayout.removeChild(Window.getById("_UsersWindow"));
					
					Window.getById("_UsersWindow").destroy();
				}
			}
		});
	}

	

	public static MainLayout getMainLayout() {
		return mainLayout;
	}
	
	public HLayout getTabSetHLayout() {
		return tabSetHLayout;
	}

	public void setTabSetHLayout(HLayout tabSetHLayout) {
		this.tabSetHLayout = tabSetHLayout;
	}

	/**
	 * @return the logTab
	 */
	public Tab getLogTab() {
		return logTab;
	}
}

