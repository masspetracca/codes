package it.ccg.portaladminweb.client.base;

import com.smartgwt.client.widgets.IButton;

public class ACButton extends IButton{

	public ACButton (){
		super();
		
		this.setWidth(130);
		this.setHeight(21);
	}
	
}
