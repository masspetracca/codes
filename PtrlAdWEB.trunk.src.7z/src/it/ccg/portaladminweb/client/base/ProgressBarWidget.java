package it.ccg.portaladminweb.client.base;

import com.google.gwt.user.client.Timer;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.Progressbar;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.layout.HLayout;

public class ProgressBarWidget extends Window {
	
	private HLayout mainHLayout;
	
	private Label progressBarLabel;
	private Progressbar progressbar;
	private Timer progressBarTimer;
	
	public ProgressBarWidget(String id, int leftOffset, int topOffset) {
		
		super();
		
		this.setWidth(330);
		this.setHeight(52);
		this.setShowHeader(false);
		this.setCanDragResize(false);
		this.setCanDragReposition(false);
		
		this.setID(id + "Window");
		this.setLeft(leftOffset - 165);
		this.setTop(topOffset - 26);
		
		this.bringToFront();
		
		this.progressBarLabel = new Label("Processing request");
		this.progressBarLabel.setHeight(25);
		
		this.progressbar = new Progressbar();
		this.progressbar.setID(id);
		this.progressbar.setWidth(200);
		this.progressbar.setHeight(30);
		HLayout tempHLayout = new HLayout();
		tempHLayout.setLayoutTopMargin(2);
		tempHLayout.addMember(progressbar);
		//this.progressbar.draw();
		
		this.mainHLayout = new HLayout();
		/*this.mainHLayout.setWidth100();
		this.mainHLayout.setHeight100();*/
		this.mainHLayout.addMember(this.progressBarLabel);
		//this.mainHLayout.addMember(this.progressbar);
		this.mainHLayout.addMember(tempHLayout);
		this.mainHLayout.setLayoutLeftMargin(10);
		this.mainHLayout.setLayoutTopMargin(10);
		this.mainHLayout.setLayoutRightMargin(10);
		this.mainHLayout.setLayoutBottomMargin(10);
		
		
		this.addItem(this.mainHLayout);
		
	}
	
	
	public void setEnable() {
		
		this.progressBarLabel.setOpacity(100);
		this.progressbar.enable();
		
		this.progressbar.redraw();
	}
	
	
	public void setDisable() {
		
		this.progressBarLabel.setOpacity(30);
		this.progressbar.disable();
		
		this.progressbar.redraw();
	}
	
	
	public void setPercentDone(int percentDone) {
		
		if(percentDone < 0) {
			percentDone = 0;
		}
		else if(percentDone > 100) {
			percentDone = 100;
		}
		
		this.progressbar.setPercentDone(percentDone);
		
		this.progressbar.redraw();
	}
	
	
	public int getPercentDone(int percentDone) {
		
		return this.progressbar.getPercentDone();
	}
	
	public void setStarted() {
		
		this.progressbar.setPercentDone(0);
		
		this.progressbar.redraw();
		
		this.startTimer();
	}
	
	public void setFinished() {
		
		this.stopTimer();
		
		this.progressbar.setPercentDone(100);
		
		this.progressbar.redraw();
	}
	
	public void startTimer() {
		this.progressBarTimer = new Timer() {
        	
        	private int progressbarValue;
        	
        	@Override
            public void run() {
        		
        		this.progressbarValue = progressbar.getPercentDone();
        		
        		if(progressbar.getPercentDone() > 99) {
                    
        			this.progressbarValue = -2;
                }
        		
        		this.progressbarValue += 2;
        		
    			progressbar.setPercentDone(this.progressbarValue);
    			
    			progressbar.redraw();
                
            }
        	
		};
		
		this.progressBarTimer.scheduleRepeating(50);
	}
	
	
	public void stopTimer() {
		this.progressBarTimer.cancel();
	}

}
