package it.ccg.portaladminweb.client.base;

import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;

public class LoadingWidget extends Window {
	
	
	public LoadingWidget() {
		
		super();
		
		this.setWidth(160);
		this.setHeight(90);
		this.setShowEdges(false);
		this.setShowHeader(false);
		this.setCanDragResize(false);
		this.setCanDragReposition(false);
		
		this.centerInPage();
		this.bringToFront();
		
		
		VLayout vLayout = new VLayout();
		vLayout.setWidth100();
		vLayout.setHeight100();
		
		
		Img loadingGif = new Img("loading.gif", 30, 30);
		HLayout gifLayout = new HLayout();
		gifLayout.setAlign(Alignment.CENTER);
		gifLayout.addMember(loadingGif);
		
		vLayout.addMember(gifLayout);
		
		Label label = new Label("Processing request..");
		label.setHeight(25);
		HLayout labelLayout = new HLayout();
		labelLayout.setAlign(Alignment.CENTER);
		labelLayout.addMember(label);
		
		vLayout.addMember(labelLayout);
		
		vLayout.setLayoutTopMargin(10);
		
		vLayout.setMembersMargin(10);
		
		this.addItem(vLayout);
		
	}
	
	
}
