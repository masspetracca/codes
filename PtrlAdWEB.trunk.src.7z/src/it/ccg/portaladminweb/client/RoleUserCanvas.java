package it.ccg.portaladminweb.client;

import it.ccg.portaladminweb.client.base.StandardButton;
import it.ccg.portaladminweb.client.base.LoadingWidget;
import it.ccg.portaladminweb.client.rpc.DSRequestType;
import it.ccg.portaladminweb.client.rpc.PADSCallback;
import it.ccg.portaladminweb.client.rpc.PADSRequest;
import it.ccg.portaladminweb.client.rpc.PARPCCallback;
import it.ccg.portaladminweb.client.rpc.PARPCRequest;
import it.ccg.portaladminweb.client.rpcutil.Json2POJO;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.google.gwt.http.client.Response;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONValue;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.TransferImgButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.events.ChangedEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangedHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;

public class RoleUserCanvas extends Canvas{
	
	private SelectItem roleComboBox;
	private Label roleRelatedUserLaber;
	private Label roleNotRelatedUserLabel;
	private ListGrid roleRelatedUserGrid;
	private ListGrid roleNotRelatedUserGrid;
	
	
	public RoleUserCanvas() {
		super();
				
		this.setWidth100();
		this.setHeight100();
		
		VLayout containerLayout = this.createContainerLayout();
		HLayout firstRowLayout = this.createFirstRowLayout();
		HLayout secondRowLayout = this.createSecondRowLayout();
		HLayout commandButtonContainerLayout = this.createCommandButtonContainerLayout();
	
        containerLayout.addMember(firstRowLayout);
        containerLayout.addMember(secondRowLayout);
        containerLayout.addMember(commandButtonContainerLayout);
        
        this.addChild(containerLayout);
        this.draw();
	}
	
	private VLayout createContainerLayout() {
		VLayout containerLayout = new VLayout();
		
		containerLayout.setWidth("70%");
		containerLayout.setHeight("80%");
		containerLayout.setMembersMargin(20);
		
		return containerLayout;
	}
	
	private HLayout createFirstRowLayout(){
		HLayout firstRowLayout = new HLayout();
		
		final DynamicForm form = new DynamicForm();  
        //form.setWidth(200);
    
		this.roleComboBox = new SelectItem();
		this.roleComboBox.setWidth(120);
		this.roleComboBox.setTitle("<nobr>Select Role</nobr>");
		this.roleComboBox.setRequired(true);
		this.roleComboBox.setType("enum");
		
		Map<String,String> params = new HashMap<String, String>();
		params.put("_operationId", "fetchAll");
		
		PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/RoleEndpoint", DSRequestType.FETCH, params);
		
		RPCManager.sendRequest(dsRequest, new PADSCallback() {
			@Override
			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				LinkedHashMap<String, String> valueMap = Json2POJO.getComboLinkedHashMap(response);
				
				roleComboBox.setValueMap(valueMap);
			}
		});
		
		this.roleComboBox.addChangedHandler(new ChangedHandler() {
			
			@Override
			public void onChanged(ChangedEvent event) {
				
				// get user related role
				Map<String,String> params = new HashMap<String, String>();
				params.put("_operationId", "fetchRoleRelated");
				params.put("role", roleComboBox.getValueAsString());
				
				PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/WSUserEndpoint", DSRequestType.FETCH, params);
				
				RPCManager.sendRequest(dsRequest, new PADSCallback() {
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						Record[] records = Json2POJO.getGridRecords(response);
						
						roleRelatedUserGrid.setData(records);
					}
				});
				
				// get user not related role
				params = new HashMap<String, String>();
				params.put("_operationId", "fetchRoleNotRelated");
				params.put("role", roleComboBox.getValueAsString());
				
				dsRequest = new PADSRequest("servlet/endpoint/data/WSUserEndpoint", DSRequestType.FETCH, params);
				RPCManager.sendRequest(dsRequest, new PADSCallback() {
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						Record[] records = Json2POJO.getGridRecords(response);
						
						roleNotRelatedUserGrid.setData(records);
					}
				});
				
			}
		});
		
		
		form.setItems(this.roleComboBox);
		firstRowLayout.addMember(form);
		
		return firstRowLayout;
	}
	
	private HLayout createSecondRowLayout(){
		HLayout secondRowLayout = new HLayout();
		secondRowLayout.setWidth100();
		secondRowLayout.setHeight100();
		//secondRowLayout.setMembersMargin(30);
		
		this.roleRelatedUserGrid = this.createUserGrid();
		this.roleRelatedUserLaber = this.createGridLabel("Related Users");
		VLayout userRelatedColLayout = this.createUsersVLayout();
		userRelatedColLayout.addMember(this.roleRelatedUserLaber);
		userRelatedColLayout.addMember(roleRelatedUserGrid);
		VLayout rowButtonContainerLayout = this.createRowButtonContainerLayout();
		
		this.roleNotRelatedUserGrid = this.createUserGrid();
		this.roleNotRelatedUserLabel = this.createGridLabel("Not Related Users");
		VLayout userNotRelatedColLayout = this.createUsersVLayout();
		userNotRelatedColLayout.addMember(this.roleNotRelatedUserLabel);
		userNotRelatedColLayout.addMember(this.roleNotRelatedUserGrid);
		
		
		secondRowLayout.addMember(userNotRelatedColLayout);
	    secondRowLayout.addMember(rowButtonContainerLayout);
	    secondRowLayout.addMember(userRelatedColLayout);
	    
        
		return secondRowLayout;
	}
	
	private ListGrid createUserGrid() {
		final ListGrid userGrid = new ListGrid();
		//userGrid.setWidth("45%");
		userGrid.setWidth("100%");
		userGrid.setShowHeader(false);
		userGrid.setCanDragRecordsOut(true);  
		userGrid.setCanAcceptDroppedRecords(true);  
		userGrid.setCanReorderFields(true);
		
		ListGridField cnField = new ListGridField("cn");
		cnField.setHidden(true);
		ListGridField oField = new ListGridField("o");
		oField.setHidden(true);
		ListGridField cField = new ListGridField("c");
		cField.setHidden(true);
		ListGridField uidField = new ListGridField("uid");
		
		userGrid.setFields(cnField, oField, cField, uidField);
		
		return userGrid;
	}
	
	private VLayout createRowButtonContainerLayout(){
		VLayout buttonContainerLayout = new VLayout();
		buttonContainerLayout.setHeight("70%");
		buttonContainerLayout.setWidth("10%");
		buttonContainerLayout.setAlign(VerticalAlignment.CENTER);
		
		TransferImgButton buttonRight = new TransferImgButton(TransferImgButton.RIGHT);  
        buttonRight.addClickHandler(new ClickHandler() {  
            @Override
        	public void onClick(ClickEvent event) {  
                
            	roleRelatedUserGrid.transferSelectedData(roleNotRelatedUserGrid); 
            }  
        });  
        
  
        TransferImgButton buttonLeft = new TransferImgButton(TransferImgButton.LEFT);  
        buttonLeft.addClickHandler(new ClickHandler() {  
        	@Override
        	public void onClick(ClickEvent event) {  
                
        		roleNotRelatedUserGrid.transferSelectedData(roleRelatedUserGrid);
            }  
        });
        
        buttonContainerLayout.addMember(buttonRight);
		buttonContainerLayout.addMember(buttonLeft);
		
        return buttonContainerLayout;        
	}

	private HLayout createCommandButtonContainerLayout(){
		HLayout commandButtonContainerLayout = new HLayout();
		commandButtonContainerLayout.setAlign(VerticalAlignment.TOP);
		commandButtonContainerLayout.setMembersMargin(5);
		
		final StandardButton saveButton = new StandardButton();
		saveButton.setTitle("Save");
		
		saveButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				// check combo
				if(!roleComboBox.validate()) {
					
					return;
				}
				
				
				//
				final LoadingWidget loadingWidget = new LoadingWidget();
				loadingWidget.draw();
				
				
				Map<String,String> params = new HashMap<String, String>();
				params.put("_operationId", "saveRoleUserMatching");
				// passa al server i dati per i settaggi
				params.put("role", roleComboBox.getValueAsString());
				
				Record[] recordArray = roleRelatedUserGrid.getRecords();
				String rolesString = new String();
				for(Record record : recordArray) {
					
					rolesString += record.getAttributeAsString("uid") + "$";
				}
				rolesString = rolesString.substring(0, rolesString.length() - 1);
				
				params.put("uids", rolesString);
				
				
				PARPCRequest rpcRequest = new PARPCRequest("servlet/endpoint/generic/ProcedureEndpoint", params);
				
				RPCManager.sendRequest(rpcRequest, new PARPCCallback() {
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						//
						loadingWidget.destroy();
						
						
						String responseBody = response.getHttpResponseText();
						JSONValue jsonValue = JSONParser.parseStrict(responseBody);
						JSONObject jsonObject = jsonValue.isObject();
						
						String message = jsonObject.get("message").isString().stringValue();
						
						
						if(response.getHttpResponseCode() == Response.SC_OK) {
							
							SC.say(message, new BooleanCallback() {

								@Override
								public void execute(Boolean value) {
									
									saveButton.enable();
								}
								
							});
						}
						else {
							
							SC.warn(message, new BooleanCallback() {

								@Override
								public void execute(Boolean value) {
									
									saveButton.enable();
								}
								
							});
						}
					}
				});
				
			}
		});
		
		
		StandardButton cancelButton = new StandardButton();
		cancelButton.setTitle("Cancel");
		cancelButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				roleComboBox.clearValue();
				
				roleRelatedUserGrid.setData(new Record[0]);
				roleNotRelatedUserGrid.setData(new Record[0]);
			}
		});
		
		
		final StandardButton buttonSendReport = new StandardButton();  
		buttonSendReport.setTitle("Send Report");
		buttonSendReport.setShowRollOver(true);  
		buttonSendReport.setShowDown(true);  
		buttonSendReport.addClickHandler(new ClickHandler() {  
			
			@Override
            public void onClick(ClickEvent event) {
				
				//
				final LoadingWidget loadingWidget = new LoadingWidget();
				loadingWidget.draw();
				
				
				Map<String,String> params = new HashMap<String, String>();
				params.put("_operationId", "sendReport");
				
				PARPCRequest rpcRequest = new PARPCRequest("servlet/endpoint/generic/ProcedureEndpoint", params);
				
				RPCManager.sendRequest(rpcRequest, new PARPCCallback() {
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						//
						loadingWidget.destroy();
						
						
						String responseBody = response.getHttpResponseText();
						JSONValue jsonValue = JSONParser.parseStrict(responseBody);
						JSONObject jsonObject = jsonValue.isObject();
						
						String message = jsonObject.get("message").isString().stringValue();
						
						
						if(response.getHttpResponseCode() == Response.SC_OK) {
							
							SC.say(message);
						}
						else {
							
							SC.warn(message);
						}
					}
				});
			}
		});
		
		
		commandButtonContainerLayout.addMember(saveButton);
		commandButtonContainerLayout.addMember(cancelButton);
		commandButtonContainerLayout.addMember(buttonSendReport);
		
		return commandButtonContainerLayout;
	}

	private Label createGridLabel(String title){
		Label titleLabel = new Label(title);  
		titleLabel.setWidth("100%");
		titleLabel.setHeight(20); 
		titleLabel.setWrap(false);
		
        return titleLabel;
	}
	
	private VLayout createUsersVLayout() {
		VLayout usersVLayout = new VLayout();
		
		usersVLayout.setWidth("100%");
		usersVLayout.setHeight("100%");
		
		return usersVLayout;
	}
}
