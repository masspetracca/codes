package it.ccg.portaladminweb.client;

import it.ccg.portaladminweb.client.base.StandardButton;
import it.ccg.portaladminweb.client.base.PopupWindow;
import it.ccg.portaladminweb.client.rpc.DSRequestType;
import it.ccg.portaladminweb.client.rpc.PADSCallback;
import it.ccg.portaladminweb.client.rpc.PADSRequest;
import it.ccg.portaladminweb.client.rpc.PARPCCallback;
import it.ccg.portaladminweb.client.rpcutil.Json2POJO;

import java.util.HashMap;
import java.util.Map;

import com.google.gwt.http.client.Response;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONValue;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;

public class QueueCanvas extends Canvas {

	private ListGrid queueGrid;
	private ListGrid jobsGrid;
	
	public QueueCanvas() {
		
		VLayout containerLayout = this.createContainerLayout();
		
		this.queueGrid = this.createQueueGrid();
		// first fetch
		this.fetchGrid();
		
		
		// refresh button
		ToolStripButton refreshButton = this.createRefreshButton();
			
		VLayout gridContainerLayout = this.createGridContainerLayout();
		gridContainerLayout.addMember(refreshButton);
		gridContainerLayout.addMember(this.queueGrid);
		
		HLayout buttonHLayout = this.createButtonHLayout();
		
		
		containerLayout.addMember(gridContainerLayout);
		containerLayout.addMember(buttonHLayout);
		
		this.addChild(containerLayout);
	}
	
	
	
	private VLayout createContainerLayout(){
		VLayout containerLayout = new VLayout();
		containerLayout.setHeight100();
		containerLayout.setWidth100();
		containerLayout.setMembersMargin(5);
		
		return containerLayout;
	}
	
	private HLayout createButtonHLayout(){
		
		HLayout buttonHLayout = new HLayout();
		buttonHLayout.setMembersMargin(5);
		
		
		StandardButton newJobButton = new StandardButton();
		newJobButton.setID("addButton");
		newJobButton.setTitle("Append new job");
		newJobButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				final Window newJobWindow = PopupWindow.getInstance("Append new job", 700, 700);
				newJobWindow.addMember(populateWindow());
				newJobWindow.draw();
				newJobWindow.addCloseClickHandler(new CloseClickHandler() {
					
					@Override
					public void onCloseClick(CloseClickEvent event) {
						fetchGrid();
						newJobWindow.destroy();
						
					}
				});
			}
		});
		
		StandardButton emptyButton = new StandardButton();
		emptyButton.setID("emptyButton");
		emptyButton.setTitle("<b>Empty queue<b>");
		emptyButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				SC.confirm("Delete all messages in queue?", new BooleanCallback() {
					
					@Override
					public void execute(Boolean value) {
						
						if(value) {
							
							PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/QueueEndpoint", DSRequestType.REMOVE, new HashMap<String, String>());
							
							RPCManager.sendRequest(dsRequest, new PADSCallback() {
								@Override
								public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
									
									fetchGrid();
									
									/*Record[] records = queueGrid.getRecords();
									
									if(records.length == 1) {
										
										String messageInfo = "[Message ID: " + records[0].getAttributeAsString("messageID") + ", " + 
										 					 "[Creation Time: " + records[0].getAttributeAsString("creationTime") + ", " + 
										 					 "[JMS Destination: " + records[0].getAttributeAsString("jmsDestination") + ", " + 
										 					 "[Message Text: " + records[0].getAttributeAsString("messageText") + "]";
										
										SC.say("Messages correctly deleted. One message locked in execution:" + "<br>" + 
											   "<br>" +
											   messageInfo);
									}
									else {
										
										SC.say("Messages correctly deleted. One message locked in execution.");
									}*/
									
									SC.say("Messages correctly deleted. One message locked in execution.");
									
									
								}
							});
							
						}
					}
				});
			}
		});
		
		
		final StandardButton stopMessageConsumerButton = new StandardButton();
		
		final StandardButton startMessageConsumerButton = new StandardButton();
		startMessageConsumerButton.setID("startButton");
		startMessageConsumerButton.setTitle("Start Message Consumer");
		startMessageConsumerButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				Map<String,String> params = new HashMap<String, String>();
				params.put("_operationId", "startMessageConsumer");
				
				PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/MessageConsumerEndpoint", DSRequestType.UPDATE, params);
				
				RPCManager.sendRequest(dsRequest, new PADSCallback() {
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						String responseBody = response.getHttpResponseText();
						JSONValue jsonValue = JSONParser.parseStrict(responseBody);
						JSONObject jsonObject = jsonValue.isObject();
						
						String message = jsonObject.get("message").isString().stringValue();
						
						if(response.getHttpResponseCode() == Response.SC_OK) {
							
							SC.say(message, new BooleanCallback() {

								@Override
								public void execute(Boolean value) {
									
									startMessageConsumerButton.disable();
									stopMessageConsumerButton.enable();
									
									fetchGrid();
								}
								
							});
						}
						else {
							
							SC.warn(message);
						}
					}
				});
				
			}
		});
		
		stopMessageConsumerButton.setID("stopButton");
		stopMessageConsumerButton.setTitle("Stop Message Consumer");
		stopMessageConsumerButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				Map<String,String> params = new HashMap<String, String>();
				params.put("_operationId", "stopMessageConsumer");
				
				PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/MessageConsumerEndpoint", DSRequestType.UPDATE, params);
				
				RPCManager.sendRequest(dsRequest, new PADSCallback() {
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						String responseBody = response.getHttpResponseText();
						JSONValue jsonValue = JSONParser.parseStrict(responseBody);
						JSONObject jsonObject = jsonValue.isObject();
						
						String message = jsonObject.get("message").isString().stringValue();
						
						if(response.getHttpResponseCode() == Response.SC_OK) {
							
							SC.say(message, new BooleanCallback() {

								@Override
								public void execute(Boolean value) {
									
									startMessageConsumerButton.enable();
									stopMessageConsumerButton.disable();
									
									fetchGrid();
								}
								
							});
						}
						else {
							
							SC.warn(message);
						}
					}
				});
				
			}
		});
		
		
		
		Map<String,String> params = new HashMap<String, String>();
		params.put("_operationId", "isMessageConsumerEnabled");
		
		PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/MessageConsumerEndpoint", DSRequestType.FETCH, params);
		
		RPCManager.sendRequest(dsRequest, new PADSCallback() {	
			@Override
			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				String responseBody = response.getHttpResponseText();
				JSONValue jsonValue = JSONParser.parseStrict(responseBody);
				JSONObject jsonObject = jsonValue.isObject();
				
				
				if(response.getHttpResponseCode() == Response.SC_OK) {
					
					boolean isMessageConsumerEnabled = jsonObject.get("isMessageConsumerEnabled").isBoolean().booleanValue();
					
					if(isMessageConsumerEnabled) {
						
						startMessageConsumerButton.disable();
						stopMessageConsumerButton.enable();
					}
					else {
						
						startMessageConsumerButton.enable();
						stopMessageConsumerButton.disable();
					}
					
				}
				else {
					
					String message = jsonObject.get("message").isString().stringValue();
					
					SC.warn(message);
				}
				
				
			}
		});
		
		
		buttonHLayout.addMember(newJobButton);
		buttonHLayout.addMember(emptyButton);
		
		buttonHLayout.addMember(startMessageConsumerButton);
		buttonHLayout.addMember(stopMessageConsumerButton);
		
		
		
		return buttonHLayout;
	}
	
	private VLayout createGridContainerLayout(){
		VLayout gridContainerLayout = new VLayout();
		gridContainerLayout.setWidth100();
		gridContainerLayout.setHeight100();
		
		return gridContainerLayout;
	}
	
	private ToolStripButton createRefreshButton(){
		ToolStripButton refreshButton = new ToolStripButton();  
		refreshButton.setID("refreshButton");
		refreshButton.setIcon("[SKIN]/actions/refresh.png");
		refreshButton.setPrompt("Refresh List");
		refreshButton.setTitle("Refresh");
		
		refreshButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				fetchGrid();
			}
		});
		
		return refreshButton;
	}
	
	private ListGrid createQueueGrid() {
		
		ListGrid grid = new ListGrid();
		
		ListGridField userID = new ListGridField("messageID","Message ID");  
		userID.setWidth("25%");
	    ListGridField creationTime = new ListGridField("creationTime","Creation Time"); 
	    creationTime.setWidth("25%");
	    ListGridField jmsDestination = new ListGridField("jmsDestination", "JMS Destination");  
	    jmsDestination.setWidth("25%");
	    ListGridField messageText = new ListGridField("messageText","Message Text"); 
	    messageText.setWidth("25%");
	    
	    grid.setWidth("70%");
	    grid.setHeight100();
	
	    grid.setFields(userID, creationTime, jmsDestination, messageText);
	    
	    
	    return grid;
	}
	
	private void fetchGrid() {
		
		Map<String,String> params = new HashMap<String, String>();
		params.put("_operationId", "fetchQueueEntry");
		
		PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/QueueEndpoint", DSRequestType.FETCH, params);
		
		RPCManager.sendRequest(dsRequest, new PADSCallback() {
			@Override
			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				Record[] records = Json2POJO.getGridRecords(response);
				
				queueGrid.setData(records);
			}
		});
		
	}
	
	private void fetchAllJobs() {
		
		Map<String,String> params = new HashMap<String, String>();
		params.put("_operationId", "fetchAllJobs");
		
		PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/QueueEndpoint", DSRequestType.FETCH, params);
		
		RPCManager.sendRequest(dsRequest, new PADSCallback() {
			@Override
			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				Record[] records = Json2POJO.getGridRecords(response);
				
				jobsGrid.setData(records);
			}
		});
		
	}
	
	private VLayout populateWindow() {
		
		VLayout containerLayout = new VLayout();
    	containerLayout.setHeight100();
    	containerLayout.setWidth100();
    	containerLayout.setAlign(Alignment.CENTER);
    	containerLayout.setMembersMargin(7);

    	HLayout buttonContainer = new HLayout();
    	buttonContainer.setMembersMargin(5);
        
        jobsGrid = new ListGrid();
        jobsGrid.setHeight(600);
        jobsGrid.setAutoFetchData(true);
        jobsGrid.setCanEdit(false);
        
        ListGridField batchID = new ListGridField("batchid");
        batchID.setTitle("Batch ID");
        batchID.setWidth("10%");
        
        ListGridField batchName = new ListGridField("batchname");
        batchName.setTitle("Batch Nme");
        batchName.setWidth("50%");
		
        ListGridField batchCat = new ListGridField("batchcat");
        batchCat.setTitle("Batch Category");
        batchCat.setWidth("20%");
        
        Map<String, String> statusMap = new HashMap<String, String>();
        statusMap.put("E", "Enabled");
        statusMap.put("D", "Disabled");
        
        ListGridField status = new ListGridField("status");
        status.setValueMap(statusMap);
        status.setTitle("Status");
        status.setWidth("20%");
		
        jobsGrid.setFields(batchID,batchName,batchCat,/*runnMode,*/status);
		
        this.fetchAllJobs();
        containerLayout.addMember(jobsGrid);		
		
		StandardButton startImmediately = new StandardButton();
		startImmediately.setTitle("Start immediately");
		startImmediately.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(jobsGrid.getSelectedRecord() == null) {
					
					SC.warn("No selected batch.");
					
					return;
				}
				Record record = jobsGrid.getSelectedRecord();
				
				SC.confirm("Do you want to start "+record.getAttributeAsString("batchname")+" ?", new BooleanCallback() {
					
					@Override
					public void execute(Boolean value) {
						
						if(value) {
							
							 // rpc per la remove
							Record record = jobsGrid.getSelectedRecord();
							
							Map<String,String> params = new HashMap<String, String>();
							
							params.put("batchID", record.getAttributeAsString("batchid"));
							
							params.put("_operationId", "appendJob");
							
							PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/QueueEndpoint", DSRequestType.ADD, params);
			        		
							RPCManager.sendRequest(dsRequest, new PARPCCallback() {
								
			        			@Override
			        			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
			        				
			        				String responseBody = response.getHttpResponseText();
									JSONValue jsonValue = JSONParser.parseStrict(responseBody);
									JSONObject jsonObject = jsonValue.isObject();
									String message = jsonObject.get("message").isString().stringValue();
									


									if(response.getHttpResponseCode() != Response.SC_OK) {

										SC.warn(message);
									}
									else {
										
										SC.say(message);
									}
									
									fetchAllJobs();
		                		}
			                		
							});	
						}		        		
					}
        		
				});
				//
			}
		});
		buttonContainer.addMember(startImmediately);

        containerLayout.addMember(buttonContainer);
        
        return containerLayout;
	}
	
}
