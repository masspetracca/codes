package it.ccg.portaladminweb.client.rpc;

import java.util.Map;

import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.types.PromptStyle;

public class PARPCRequest extends RPCRequest {
	
	public PARPCRequest(String url, Map<String, String> params) {
		
		super();
		this.setHttpMethod("POST");
		
		this.setShowPrompt(true);
		this.setPromptStyle(PromptStyle.CURSOR);
		
		// 
		this.setTimeout(0);
		
		this.setActionURL(url);
		this.setParams(params);
		
	}

}
