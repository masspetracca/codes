package it.ccg.portaladminweb.client.rpc;

public enum DSRequestType {
	
	FETCH,
	ADD,
	UPDATE,
	REMOVE;

}
