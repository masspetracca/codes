package it.ccg.portaladminweb.client.rpc;

import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;

public class PARPCCallback implements RPCCallback {

	@Override
	final public void execute(RPCResponse response, Object rawData, RPCRequest request) {
		
		// TODO
		// various checks
		
		
		// now execute custom code specified by developer
		this.executeImpl(response, rawData, request);
	}
	
	
	protected void executeImpl(RPCResponse response, Object rawData, RPCRequest request) {
		
	}
	
	
}

