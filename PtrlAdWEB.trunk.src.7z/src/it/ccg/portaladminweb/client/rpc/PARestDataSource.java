package it.ccg.portaladminweb.client.rpc;

import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.RestDataSource;
import com.smartgwt.client.types.DSDataFormat;

public class PARestDataSource extends RestDataSource {
	
	public PARestDataSource(String dataURL) {
		
		this.setDataURL(dataURL);
		this.setDataFormat(DSDataFormat.JSON);
		
		DSRequest requestProperties = new DSRequest();
		requestProperties.setHttpMethod("POST");
		this.setRequestProperties(requestProperties);
		
	}

}
