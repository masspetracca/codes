package it.ccg.portaladminweb.client.rpc;

import java.util.HashMap;
import java.util.Map;

import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.types.PromptStyle;

public class PADSRequest extends RPCRequest {
	
	public PADSRequest(String url, DSRequestType dsRequestType, Map<String, String> params) {
		
		super();
		this.setHttpMethod("POST");
		
		this.setShowPrompt(true);
		this.setPromptStyle(PromptStyle.CURSOR);
		
		// TODO
		//this.setTimeout(?);
		
		this.setActionURL(url);
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("_operationType", dsRequestType.toString().toLowerCase());
		if(params != null) {
			
			map.putAll(params);
		}
		
		this.setParams(map);
		
	}

}