package it.ccg.portaladminweb.client.rpc;

import com.google.gwt.http.client.Response;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.util.SC;

public class PADSCallback implements RPCCallback {

	@Override
	final public void execute(RPCResponse response, Object rawData, RPCRequest request) {
		
		// check response code
		// if OK
		if(response.getHttpResponseCode() == Response.SC_OK) {
			
			// execute custom code specified by developer
			this.executeImpl(response, rawData, request);
		}
		else {
			
			SC.warn("Server problems. Contact CC&G Helpdesk.");
		}
		
		
	}
	
	
	protected void executeImpl(RPCResponse response, Object rawData, RPCRequest request) {
		
	}
	
}
