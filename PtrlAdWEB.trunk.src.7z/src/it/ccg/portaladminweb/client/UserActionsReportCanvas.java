package it.ccg.portaladminweb.client;

import it.ccg.portaladminweb.client.rpc.DSRequestType;
import it.ccg.portaladminweb.client.rpc.PADSCallback;
import it.ccg.portaladminweb.client.rpc.PADSRequest;
import it.ccg.portaladminweb.client.rpcutil.Json2POJO;

import java.util.HashMap;
import java.util.Map;

import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;

public class UserActionsReportCanvas extends Canvas {

	private VLayout mainVLayout;
	private ListGrid userActionGrid;
	
	public UserActionsReportCanvas(){
		super();
		this.setWidth100();
		this.setHeight100();
		this.setLeft(10);
		
		
		ToolStripButton refreshButton = this.createRefreshButton();  
		
		this.createUserActionGrid();
		this.fetchGrid();
		
		this.mainVLayout = new VLayout();
		this.mainVLayout.setHeight100();
		this.mainVLayout.setWidth100();
		
		this.mainVLayout.addMember(refreshButton);
		this.mainVLayout.addMember(this.userActionGrid);
		this.addChild(this.mainVLayout);
		
	}
	
	private void createUserActionGrid(){
		
		this.userActionGrid = new  ListGrid();
	
		this.userActionGrid.setAutoFetchData(true);
		this.userActionGrid.setCanEdit(false);
		this.userActionGrid.setCanMultiSort(false);
		this.userActionGrid.setCanGroupBy(false);
		this.userActionGrid.setCanSort(false);
		
		ListGridField userField = new ListGridField("user");
		userField.setTitle("User");
		userField.setWidth(100);
		
		ListGridField actionDateField = new ListGridField("stringActionDate");
		actionDateField.setTitle("Date");
		actionDateField.setWidth(150);
		
		ListGridField actionField = new ListGridField("action");
		actionField.setTitle("Action");
				
		this.userActionGrid.setFields(userField,actionDateField,actionField);
			
	}
	
	private ToolStripButton createRefreshButton(){
		ToolStripButton refreshButton = new ToolStripButton();  
		refreshButton.setID("refreshButton");
		refreshButton.setIcon("[SKIN]/actions/refresh.png");
		refreshButton.setPrompt("Refresh List");
		refreshButton.setTitle("Refresh");
		
		refreshButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				fetchGrid();
			}
		});
		
		return refreshButton;
	}
	
	private void fetchGrid() {
		
		Map<String,String> params = new HashMap<String, String>();
		params.put("_operationId", "fetchQueueEntry");
		
		PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/UserActionReportEndpoint", DSRequestType.FETCH, params);
		
		RPCManager.sendRequest(dsRequest, new PADSCallback() {
			@Override
			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				Record[] records = Json2POJO.getGridRecords(response);
				
				userActionGrid.setData(records);
			}
		});

	}

}
