package it.ccg.portaladminweb.client.rpcutil;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONValue;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.RPCResponse;

public class Json2POJO {
	
	
	public static Object convert(String jsonString) {
		
		
		return null;
	}
	
	
	
	public static Record[] getGridRecords(RPCResponse response) {
		
		JSONValue jsonValue = JSONParser.parseStrict(response.getAttributeAsString("httpResponseText"));
		JSONArray jsonArray = jsonValue.isArray();
		
		
		Record[] records = new Record[jsonArray.size()];
		JSONObject jsonObject = null;
		Map<String, String> jsonObjectMap = null;
		
		for(int i=0; i<jsonArray.size(); i++) {
			
			jsonObject = jsonArray.get(i).isObject();
			
			Set<String> keySet = jsonObject.keySet();
			
			jsonObjectMap = new HashMap<String, String>();
			for(String key : keySet) {
				
				jsonObjectMap.put(key, jsonObject.get(key).isString().stringValue());
			}
			
			records[i] = new Record(jsonObjectMap);
		}
		
		/*SC.say("jsonValue: " + jsonValue + "<br>" + 
			   "jsonArray: " + jsonArray + "<br>" +
			   "jsonArray size: " + jsonArray.size());*/
		
		return records;
	}
	
	
	public static LinkedHashMap<String, String> getComboLinkedHashMap(RPCResponse response) {
		
		JSONValue jsonValue = JSONParser.parseStrict(response.getAttributeAsString("httpResponseText"));
		JSONArray jsonArray = jsonValue.isArray();
		
		
		JSONObject jsonObject = null;
		LinkedHashMap<String, String> comboValueMap = new LinkedHashMap<String, String>();
		
		for(int i=0; i<jsonArray.size(); i++) {
			
			jsonObject = jsonArray.get(i).isObject();
			
			Set<String> keySet = jsonObject.keySet();
			
			// only one field
			String key = keySet.iterator().next();
				
			comboValueMap.put(jsonObject.get(key).isString().stringValue(), jsonObject.get(key).isString().stringValue());
			
		}
		
		/*SC.say("jsonValue: " + jsonValue + "<br>" + 
			   "jsonArray: " + jsonArray + "<br>" +
			   "jsonArray size: " + jsonArray.size());*/
		
		return comboValueMap;
	}
	
	
	public static Map<String, String> getMap(RPCResponse response) {
		
		JSONValue jsonValue = JSONParser.parseStrict(response.getAttributeAsString("httpResponseText"));
		JSONObject jsonObject = jsonValue.isObject();
		
		
		Map<String, String> map = new HashMap<String, String>();
		
		Set<String> keySet = jsonObject.keySet();
		
		for(String key : keySet) {
			
			map.put(key, jsonObject.get(key).isString().stringValue());
		}
		
		
		/*SC.say("jsonValue: " + jsonValue + "<br>" + 
			   "jsonArray: " + jsonArray + "<br>" +
			   "jsonArray size: " + jsonArray.size());*/
		
		return map;
	}


}
