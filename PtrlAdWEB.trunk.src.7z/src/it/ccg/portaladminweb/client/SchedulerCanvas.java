package it.ccg.portaladminweb.client;



import it.ccg.portaladminweb.client.base.StandardButton;
import it.ccg.portaladminweb.client.rpc.DSRequestType;
import it.ccg.portaladminweb.client.rpc.PADSCallback;
import it.ccg.portaladminweb.client.rpc.PADSRequest;
import it.ccg.portaladminweb.client.rpcutil.Json2POJO;

import java.util.HashMap;
import java.util.Map;

import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.SelectionStyle;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.grid.CellFormatter;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;

public class SchedulerCanvas extends Canvas {
	
	private ListGrid timerListGrid;
	private HLayout buttonHLayout;
	
	
	public SchedulerCanvas() {
		super();
		this.setWidth100();
		this.setHeight100();
		this.setLeft(10);
		
		VLayout vLayout = new VLayout();
		vLayout.setWidth100();
		vLayout.setHeight100();
		
		// grid section
        this.timerListGrid = this.createTimerListGrid();
        this.timerListGrid.setWidth100();
        this.timerListGrid.setHeight100();
        // first fetch
		this.fetchTimerListGrid();
        
        this.timerListGrid.setShowResizeBar(true);
        this.timerListGrid.setResizeBarTarget("next");
        
        
		ToolStripButton refreshButton = this.createRefreshButton();
		
		VLayout gridContainerLayout = this.createGridContainerLayout();
		gridContainerLayout.addMember(refreshButton);
		gridContainerLayout.addMember(this.timerListGrid);
		        
        vLayout.addMember(gridContainerLayout);
        // grid section
		
        
        // edit section
        
        this.buttonHLayout = this.createButtonLayout();
        vLayout.addMember(this.buttonHLayout);
        
        // edit section
        
        
        this.addChild(vLayout);
		
	}
	
	private VLayout createGridContainerLayout(){
		VLayout gridContainerLayout = new VLayout();
		gridContainerLayout.setWidth100();
		gridContainerLayout.setHeight100();
		
		return gridContainerLayout;
	}
	
	private ToolStripButton createRefreshButton(){
		ToolStripButton refreshButton = new ToolStripButton();  
		refreshButton.setID("refreshButton");
		refreshButton.setIcon("[SKIN]/actions/refresh.png");
		refreshButton.setPrompt("Refresh List");
		refreshButton.setTitle("Refresh");
		
		refreshButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				fetchTimerListGrid();
			}
		});
		
		return refreshButton;
	}
	
	private ListGrid createTimerListGrid() {
		
		ListGrid timerGrid = new ListGrid();
		
		timerGrid.setCanRemoveRecords(false);
		
		timerGrid.setSelectionType(SelectionStyle.SINGLE);
		
		// create fields
		/*ListGridField nameField = new ListGridField("name");
		ListGridField jobDTOField = new ListGridField("jobDTO");
		jobDTOField.setAttribute("valueXPath", "jobDTO/description");
		ListGridField isSingleField = new ListGridField("isSingle");
		ListGridField startDateTimeField = new ListGridField("startDateTime");
		ListGridField intervalField = new ListGridField("interval");
		ListGridField providerField = new ListGridField("provider");*/
		ListGridField batchNameField = new ListGridField("batchName", "Batch name");
		
		timerGrid.setFields(batchNameField/*nameField, jobDTOField, isSingleField, startDateTimeField, intervalField, providerField*/);
		
		
		this.setIntervalFieldFormat(timerGrid);
		
		
		return timerGrid;
	}
	
	
	
	private void fetchTimerListGrid() {
		
		PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/ScheduleDataEndpoint", DSRequestType.FETCH, null);

		RPCManager.sendRequest(dsRequest, new PADSCallback() {
			@Override
			public void executeImpl(RPCResponse response, Object rawData, RPCRequest request) {
				
				Record[] records = Json2POJO.getGridRecords(response);
				
				timerListGrid.setData(records);
			}
		});
		
	}
	
	
	
	private void setIntervalFieldFormat(ListGrid listGrid) {
		
		ListGridField[] lgFields = listGrid.getAllFields();
		
		for(ListGridField lgField : lgFields) {
			if(lgField.getName().equalsIgnoreCase("interval")) {
				
				lgField.setCellFormatter(new CellFormatter() {
					
					@Override
					public String format(Object value, ListGridRecord record, int rowNum, int colNum) {
						
						if(value != null) {
							long intervalInMillis = Long.parseLong(value.toString());
							
							long days = intervalInMillis / (24*60*60*1000);
						    long hours = ((intervalInMillis - days * (24*60*60*1000)))/(60*60*1000);
						    long minutes = ((intervalInMillis - days * (24*60*60*1000) - hours * (60*60*1000)))/(60*1000);
						    
						    return days + "d-" + hours + "h-" + minutes + "m";
						}
						
						else return "";
					}
					
				});
				
			}
		}
	}
	
	
	private HLayout createButtonLayout() {
		
		final IButton deleteAllSchedulesButton = new StandardButton();
        deleteAllSchedulesButton.setTitle("Delete all schedules");
        deleteAllSchedulesButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(timerListGrid.getRecords().length == 0) {
					
					SC.warn("No schedules to delete.");
					
					return;
				}
				
				SC.confirm("Delete all schedules?", new BooleanCallback() {
					
					@Override
					public void execute(Boolean value) {
						
						if(value) {
							
							Map <String,String> params = new HashMap<String,String>();
							params.put("_operationId", "removeAll");
							
							PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/ScheduleDataEndpoint", DSRequestType.REMOVE, params);

							RPCManager.sendRequest(dsRequest, new PADSCallback() {
								@Override
								public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
			        				
									fetchTimerListGrid();
								}
							});
							
						}
						
					}
				});
				
			}
		});
        
        final IButton deleteScheduleButton = new StandardButton();
        deleteScheduleButton.setTitle("Delete schedule");
        deleteScheduleButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(timerListGrid.getSelectedRecord() == null) {
					
					SC.warn("No selected schedule.");
					
					return;
				}
				
				SC.confirm("Delete selected schedule?", new BooleanCallback() {
					
					@Override
					public void execute(Boolean value) {
						
						if(value) {
							
							Map <String,String> params = new HashMap<String,String>();
							params.put("_operationId", "removeOne");
							params.put("batchName", timerListGrid.getSelectedRecord().getAttributeAsString("batchName"));
							
							PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/ScheduleDataEndpoint", DSRequestType.REMOVE, params);

							RPCManager.sendRequest(dsRequest, new PADSCallback() {
								@Override
								public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
			        				
									fetchTimerListGrid();
								}
							});
							
						}
						
					}
				});
				
				
			}
		});
        
        
        HLayout buttonHLayout = new HLayout();  
        buttonHLayout.setMembersMargin(15);
        
        buttonHLayout.setLayoutTopMargin(10);
        buttonHLayout.setLayoutBottomMargin(10);
        buttonHLayout.setLayoutLeftMargin(10);
        
        buttonHLayout.setHeight(40);
        
        buttonHLayout.setMembers(deleteAllSchedulesButton, deleteScheduleButton);
        
		
        return buttonHLayout;
	}
	
	

}
