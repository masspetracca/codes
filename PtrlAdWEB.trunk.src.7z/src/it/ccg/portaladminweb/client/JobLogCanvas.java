package it.ccg.portaladminweb.client;

import it.ccg.portaladminweb.client.rpc.PARestDataSource;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.DataSourceField;
import com.smartgwt.client.data.RestDataSource;
import com.smartgwt.client.types.FieldType;
import com.smartgwt.client.types.OperatorId;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;

public class JobLogCanvas extends Canvas {
	
	private VLayout mainVLayout;
	private ListGrid logGrid;
	
	public JobLogCanvas(){
		super();
		this.setWidth100();
		this.setHeight100();
		this.setLeft(10);
		
		
		ToolStripButton refreshButton = this.createRefreshButton();  
		
		this.createLogGrid();
		
		this.mainVLayout = new VLayout();
		this.mainVLayout.setHeight100();
		this.mainVLayout.setWidth100();
		
		this.mainVLayout.addMember(refreshButton);
		this.mainVLayout.addMember(this.logGrid);
		this.addChild(this.mainVLayout);
		
	}
	
	private void createLogGrid(){
		
		RestDataSource dataSource = new PARestDataSource("servlet/endpoint/data/LogActEndpoint");
		
		DataSourceField actID = new DataSourceField("actid", FieldType.TEXT);
		actID.setTitle("ID");
		actID.setAttribute("width", 100);
		
		DataSourceField actDate = new DataSourceField("actdate", FieldType.TEXT);
		actDate.setTitle("Date");
		//actDate.setType(ListGridFieldType.DATETIME);
		actDate.setAttribute("width", 180);
		
		DataSourceField atcUser = new DataSourceField("actusr", FieldType.TEXT);
		atcUser.setTitle("User");
		atcUser.setAttribute("width", 150);
		
		DataSourceField actDesc = new DataSourceField("actdesc", FieldType.TEXT);
		actDesc.setTitle("Description");
		
		DataSourceField note = new DataSourceField("note", FieldType.TEXT);
		note.setTitle("Note");
		
		DataSourceField updateDate = new DataSourceField("upddate", FieldType.TEXT);
		updateDate.setTitle("Update Date");
		updateDate.setDetail(true);
		
		DataSourceField updateType = new DataSourceField("updtype", FieldType.TEXT);
		updateType.setTitle("Update Type");
		updateType.setDetail(true);
		
		DataSourceField updateUser = new DataSourceField("updusr", FieldType.TEXT);
		updateUser.setTitle("Update User");
		updateUser.setDetail(true);
		
		dataSource.setFields(actID,actDate,atcUser,actDesc,note,updateDate,updateType,updateUser);
		
		
		this.logGrid = new ListGrid(dataSource);
		
		this.logGrid.setAutoFetchData(true);
		this.logGrid.setCanEdit(false);
		
		this.logGrid.setFetchOperation("fetch");
		this.logGrid.setAutoFetchData(true);
		
		this.logGrid.setShowFilterEditor(true);
		
		// this is to always have AdvancedCriteria as filter
		AdvancedCriteria advancedCriteria = new AdvancedCriteria();
		// meaningless criteria
		advancedCriteria.addCriteria("_$", OperatorId.EQUALS, "_$");
		this.logGrid.setInitialCriteria(advancedCriteria);
		this.logGrid.setFilterEditorCriteria(advancedCriteria);
		this.logGrid.setCanGroupBy(false);
		this.logGrid.setCanSort(false);
		this.logGrid.setCanMultiSort(false);
		
	}
	
	private ToolStripButton createRefreshButton(){
		ToolStripButton refreshButton = new ToolStripButton();  
		refreshButton.setID("refreshButton");
		refreshButton.setIcon("[SKIN]/actions/refresh.png");
		refreshButton.setPrompt("Refresh List");
		refreshButton.setTitle("Refresh");
		
		refreshButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				// this is to always have AdvancedCriteria as filter
				AdvancedCriteria advancedCriteria = new AdvancedCriteria();
				// meaningless criteria
				advancedCriteria.addCriteria("_$", OperatorId.EQUALS, "_$");
				
				logGrid.fetchData(advancedCriteria);
			}
		});
		
		return refreshButton;
	}
	
	
}
