package it.ccg.portaladminweb.client;

import it.ccg.portaladminweb.client.base.StandardButton;
import it.ccg.portaladminweb.client.base.LoadingWidget;
import it.ccg.portaladminweb.client.rpc.DSRequestType;
import it.ccg.portaladminweb.client.rpc.PADSCallback;
import it.ccg.portaladminweb.client.rpc.PADSRequest;
import it.ccg.portaladminweb.client.rpc.PARPCCallback;
import it.ccg.portaladminweb.client.rpc.PARPCRequest;
import it.ccg.portaladminweb.client.rpcutil.Json2POJO;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.google.gwt.http.client.Response;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONValue;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.TransferImgButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.events.ChangedEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangedHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;

public class UserRoleCanvas extends Canvas {
	
	private SelectItem userComboBox;
	private Label userRelatedRoleLaber;
	private Label userNotRelatedRoleLaber;
	private ListGrid userRelatedRoleGrid;
	private ListGrid userNotRelatedRoleGrid;
	
	public UserRoleCanvas() {
		super();
				
		this.setWidth100();
		this.setHeight100();
		
		VLayout containerLayout = this.createContainerLayout();
		
		HLayout firstRowLayout = this.createFirstRowLayout();
		HLayout secondRowLayout = this.createSecondRowLayout();
        HLayout commandButtonContainerLayout = this.createCommandButtonContainerLayout();
        
        
        containerLayout.addMember(firstRowLayout);
        containerLayout.addMember(secondRowLayout);
        containerLayout.addMember(commandButtonContainerLayout);
        
        
        this.addChild(containerLayout);
        this.draw();
	}
	
	
	
	private VLayout createContainerLayout() {
		
		VLayout containerLayout = new VLayout();
		
		containerLayout.setWidth("70%");
		containerLayout.setHeight("80%");
		containerLayout.setMembersMargin(20);
		
		return containerLayout;
	}
	
	private HLayout createFirstRowLayout(){
		HLayout firstRowLayout = new HLayout();
		
		DynamicForm form = new DynamicForm();
		//form.setWidth(200);
        
        this.userComboBox = new SelectItem();
        this.userComboBox.setWidth(120);
        this.userComboBox.setTitle("<nobr>Select User</nobr>");
        this.userComboBox.setRequired(true);
        this.userComboBox.setType("enum");
		
		// send request
		Map<String,String> params = new HashMap<String, String>();
		params.put("_operationId", "fetchAll");
		
		PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/WSUserEndpoint", DSRequestType.FETCH, params);
		
		RPCManager.sendRequest(dsRequest, new PADSCallback() {
			@Override
			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				LinkedHashMap<String, String> valueMap = Json2POJO.getComboLinkedHashMap(response);
				
				userComboBox.setValueMap(valueMap);
			}
		});
		
		
		this.userComboBox.addChangedHandler(new ChangedHandler() {
			
			@Override
			public void onChanged(ChangedEvent event) {
				
				// get user related role
				Map<String,String> params = new HashMap<String, String>();
				params.put("_operationId", "fetchUserRelated");
				params.put("uid", userComboBox.getValueAsString());
				
				PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/RoleEndpoint", DSRequestType.FETCH, params);
				
				RPCManager.sendRequest(dsRequest, new PADSCallback() {
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						Record[] records = Json2POJO.getGridRecords(response);
						
						userRelatedRoleGrid.setData(records);
					}
				});
				
				// get user not related role
				params = new HashMap<String, String>();
				params.put("_operationId", "fetchUserNotRelated");
				params.put("uid", userComboBox.getValueAsString());
				
				dsRequest = new PADSRequest("servlet/endpoint/data/RoleEndpoint", DSRequestType.FETCH, params);
				
				RPCManager.sendRequest(dsRequest, new PADSCallback() {
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						Record[] records = Json2POJO.getGridRecords(response);
						
						userNotRelatedRoleGrid.setData(records);
					}
				});
				
			}
		});
		
		
		form.setItems(this.userComboBox);
		
		firstRowLayout.addMember(form);
		
		return firstRowLayout;
	}
	
	private HLayout createSecondRowLayout(){
		HLayout secondRowLayout = new HLayout();
		secondRowLayout.setWidth100();
		secondRowLayout.setHeight100();
		//secondRowLayout.setMembersMargin(30);
		
		this.userRelatedRoleGrid = this.createRoleGrid();
		this.userRelatedRoleLaber = this.createGridLabel("Related Roles");
		VLayout roleRelatedColLayout = this.createUsersVLayout();
		roleRelatedColLayout.addMember(this.userRelatedRoleLaber);
		roleRelatedColLayout.addMember(this.userRelatedRoleGrid);
		VLayout rowButtonContainerLayout = this.createRowButtonContainerLayout();
		
        this.userNotRelatedRoleGrid = this.createRoleGrid();
        this.userNotRelatedRoleLaber = this.createGridLabel("Not Related Roles");
		VLayout roleNotRelatedColLayout = this.createUsersVLayout();
		roleNotRelatedColLayout.addMember(this.userNotRelatedRoleLaber);
		roleNotRelatedColLayout.addMember(this.userNotRelatedRoleGrid);
		
		secondRowLayout.addMember(roleNotRelatedColLayout);  
        secondRowLayout.addMember(rowButtonContainerLayout);
        secondRowLayout.addMember(roleRelatedColLayout);
		
		return secondRowLayout;
	}
	
	private VLayout createRowButtonContainerLayout(){
		VLayout buttonContainerLayout = new VLayout();
		buttonContainerLayout.setHeight("70%");
		buttonContainerLayout.setWidth("10%");
		buttonContainerLayout.setAlign(VerticalAlignment.CENTER);
		
		TransferImgButton buttonRight = new TransferImgButton(TransferImgButton.RIGHT);  
        buttonRight.addClickHandler(new ClickHandler() {

        	@Override
            public void onClick(ClickEvent event) {
            	
        		userRelatedRoleGrid.transferSelectedData(userNotRelatedRoleGrid);
            }  
        });  
        
  
        TransferImgButton buttonLeft = new TransferImgButton(TransferImgButton.LEFT);  
        buttonLeft.addClickHandler(new ClickHandler() { 
        	
        	@Override
            public void onClick(ClickEvent event) {  
        		userNotRelatedRoleGrid.transferSelectedData(userRelatedRoleGrid); 
            	  
            }  
        }); 
        
        buttonContainerLayout.addMember(buttonRight);
        buttonContainerLayout.addMember(buttonLeft);
		
		
		
		return buttonContainerLayout;
	}
	
	
	private ListGrid createRoleGrid() {
		
		final ListGrid roleGrid = new ListGrid();  
		//roleGrid.setWidth("45%");
		roleGrid.setWidth("100%");
		roleGrid.setShowHeader(false);
		roleGrid.setCanDragRecordsOut(true);  
		roleGrid.setCanAcceptDroppedRecords(true);  
		roleGrid.setCanReorderRecords(false);
		
	    ListGridField roleField = new ListGridField("role", "Role");
	    roleGrid.setFields(roleField);
		
		
		return roleGrid;
	}
	
	
	private HLayout createCommandButtonContainerLayout(){
		
		HLayout commandButtonContainerLayout = new HLayout();
		
        commandButtonContainerLayout.setMembersMargin(5);
        
        final StandardButton saveButton = new StandardButton();
        saveButton.setTitle("Save");
        saveButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				// check combo
				if(!userComboBox.validate()) {
					
					return;
				}
				
				
				//
				final LoadingWidget loadingWidget = new LoadingWidget();
				loadingWidget.draw();
				
				
				Map<String,String> params = new HashMap<String, String>();
				params.put("_operationId", "saveUserRoleMatching");
				// passa al server i dati per i settaggi
				params.put("uid", userComboBox.getValueAsString());
				
				Record[] recordArray = userRelatedRoleGrid.getRecords();
				String rolesString = new String();
				for(Record record : recordArray) {
					
					rolesString += record.getAttributeAsString("role") + "$";
				}
				rolesString = rolesString.substring(0, rolesString.length() - 1);
				
				params.put("roles", rolesString);
				
				
				PARPCRequest rpcRequest = new PARPCRequest("servlet/endpoint/generic/ProcedureEndpoint", params);
				
				RPCManager.sendRequest(rpcRequest, new PARPCCallback() {
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						//
						loadingWidget.destroy();
						
						
						String responseBody = response.getHttpResponseText();
						JSONValue jsonValue = JSONParser.parseStrict(responseBody);
						JSONObject jsonObject = jsonValue.isObject();
						
						String message = jsonObject.get("message").isString().stringValue();
						
						
						if(response.getHttpResponseCode() == Response.SC_OK) {
							
							SC.say(message, new BooleanCallback() {

								@Override
								public void execute(Boolean value) {
									
									saveButton.enable();
								}
								
							});
						}
						else {
							
							SC.warn(message, new BooleanCallback() {

								@Override
								public void execute(Boolean value) {
									
									saveButton.enable();
								}
								
							});
						}
					}
				});
				
			}
		});
        
        
        StandardButton cancelButton = new StandardButton();
        cancelButton.setTitle("Cancel");
        cancelButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				userComboBox.clearValue();
				
				userRelatedRoleGrid.setData(new Record[0]);
				userNotRelatedRoleGrid.setData(new Record[0]);
			}
		});
        
        
        final StandardButton buttonSendReport = new StandardButton();  
		buttonSendReport.setTitle("Send Report");
		buttonSendReport.setShowRollOver(true);  
		buttonSendReport.setShowDown(true);  
		buttonSendReport.addClickHandler(new ClickHandler() {  
			@Override
            public void onClick(ClickEvent event) {
				
				//
				final LoadingWidget loadingWidget = new LoadingWidget();
				loadingWidget.draw();
				
				
				Map<String,String> params = new HashMap<String, String>();
				params.put("_operationId", "sendReport");
				
				PARPCRequest rpcRequest = new PARPCRequest("servlet/endpoint/generic/ProcedureEndpoint", params);
				
				RPCManager.sendRequest(rpcRequest, new PARPCCallback() {
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						//
						loadingWidget.destroy();
						
						
						String responseBody = response.getHttpResponseText();
						JSONValue jsonValue = JSONParser.parseStrict(responseBody);
						JSONObject jsonObject = jsonValue.isObject();
						
						String message = jsonObject.get("message").isString().stringValue();
						
						
						if(response.getHttpResponseCode() == Response.SC_OK) {
							
							SC.say(message);
						}
						else {
							
							SC.warn(message);
						}
					}
				});
			}
        });
        
        commandButtonContainerLayout.addMember(saveButton);
        commandButtonContainerLayout.addMember(cancelButton);
        commandButtonContainerLayout.addMember(buttonSendReport);
		
        
		return commandButtonContainerLayout;
	}
	
	private Label createGridLabel(String title){
		Label titleLabel = new Label(title);  
		titleLabel.setWidth("100%");
		titleLabel.setHeight(20); 
		titleLabel.setWrap(false);
		
        return titleLabel;
	}
	
	private VLayout createUsersVLayout() {
		VLayout usersVLayout = new VLayout();
		
		usersVLayout.setWidth("100%");
		usersVLayout.setHeight("100%");
		
		return usersVLayout;
	}
	
}
