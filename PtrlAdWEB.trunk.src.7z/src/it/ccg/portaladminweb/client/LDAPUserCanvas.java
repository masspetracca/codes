package it.ccg.portaladminweb.client;

import it.ccg.portaladminweb.client.base.StandardButton;
import it.ccg.portaladminweb.client.base.LoadingWidget;
import it.ccg.portaladminweb.client.base.PopupWindow;
import it.ccg.portaladminweb.client.rpc.DSRequestType;
import it.ccg.portaladminweb.client.rpc.PADSCallback;
import it.ccg.portaladminweb.client.rpc.PADSRequest;
import it.ccg.portaladminweb.client.rpc.PARPCCallback;
import it.ccg.portaladminweb.client.rpc.PARPCRequest;
import it.ccg.portaladminweb.client.rpcutil.Json2POJO;
import it.ccg.portaladminweb.server.security.Regex;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.google.gwt.http.client.Response;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONValue;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.SelectionStyle;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.PasswordItem;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.validator.MatchesFieldValidator;
import com.smartgwt.client.widgets.form.validator.RegExpValidator;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;

public class LDAPUserCanvas extends Canvas {
	
	
	private ListGrid ldapUserlistGrid;
	private HLayout buttonContainerLayout;
	
	
	public LDAPUserCanvas(){
		this.setWidth100();
		this.setHeight100();
		
		VLayout containerLayout = this.createContainerLayout();
		
		
		this.ldapUserlistGrid = this.createLDAPUserListGrid();
		// first fetch
		this.fetchLdapUserGrid();
		
		
		ToolStripButton refreshButton = this.createRefreshButton();
			
		VLayout gridContainerLayout = this.createGridContainerLayout();
		gridContainerLayout.addMember(refreshButton);
		gridContainerLayout.addMember(this.ldapUserlistGrid);
				
		this.buttonContainerLayout = this.createButtonHLayout();
		
		containerLayout.addMember(gridContainerLayout);
        containerLayout.addMember(this.buttonContainerLayout);
        
		this.addChild(containerLayout);
	}
	
	
	private VLayout createContainerLayout() {
		VLayout containerLayout = new VLayout();
		containerLayout.setHeight("90%");
		containerLayout.setWidth100();
		containerLayout.setMembersMargin(5);
		
		return containerLayout;
	}
	
	private VLayout createGridContainerLayout() {
		VLayout gridContainerLayout = new VLayout();
		gridContainerLayout.setWidth100();
		gridContainerLayout.setHeight100();
		
		return gridContainerLayout;
	}
	
	private HLayout createButtonHLayout(){
		HLayout buttonHLayout = new HLayout();
		buttonHLayout.setHeight("10%");
		buttonHLayout.setWidth100();
		buttonHLayout.setMembersMargin(5);
		
		
		final StandardButton buttonAddUser = new StandardButton();  
		buttonAddUser.setTitle("Add User");
		buttonAddUser.setShowRollOver(true);  
		buttonAddUser.setShowDown(true);  
		buttonAddUser.addClickHandler(new ClickHandler() {  
			@Override
            public void onClick(ClickEvent event) {
				
				Window paolWin = PopupWindow.getInstance("Add User", 350, 370);
				paolWin.addMember(createForm());
				paolWin.draw();
			}
        }); 
		
		final StandardButton buttonDeleteUser = new StandardButton();  
		buttonDeleteUser.setTitle("Delete User");
		buttonDeleteUser.setShowRollOver(true);  
		buttonDeleteUser.setShowDown(true);  
		buttonDeleteUser.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(ldapUserlistGrid.getSelectedRecord() == null) {
					
					SC.warn("No selected user.");
					
					return;
				}
				
				
				Record record = ldapUserlistGrid.getSelectedRecord();
				
        		
				
				
        		// get user related role
				Map<String,String> params = new HashMap<String, String>();
				params.put("_operationId", "fetchUserRelated");
				
				/*String user = "cn=" + record.getAttributeAsString("cn") + ",o=" + record.getAttributeAsString("o") + ",c=" + record.getAttributeAsString("c");
				params.put("user", user);*/
				params.put("uid", record.getAttributeAsString("uid"));
				
				PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/RoleEndpoint", DSRequestType.FETCH, params);
				
				RPCManager.sendRequest(dsRequest, new PADSCallback() {
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						Record[] records = Json2POJO.getGridRecords(response);
						
						// user is in WS role/user mapping
						if(records.length > 0) {
							
							SC.confirm("Delete selected user? User exists in WAS role/user mapping. It will be removed.", new BooleanCallback() {
								
								@Override
								public void execute(Boolean value) {
									
									if(value) {
										
										// rpc per cancellare il mapping sui ruoli
				        				
			        					//
			        					final LoadingWidget loadingWidget = new LoadingWidget();
			        					loadingWidget.draw();
			        				
			        					Record record = ldapUserlistGrid.getSelectedRecord();
			        					
			        					Map<String,String> params = new HashMap<String, String>();
			        					params.put("_operationId", "saveUserRoleMatching");
			        					// passa al server i dati per i settaggi
			        					/*String user = "cn=" + record.getAttributeAsString("cn") + ",o=" + record.getAttributeAsString("o") + ",c=" + record.getAttributeAsString("c");
			        					params.put("user", user);*/
			        					params.put("uid", record.getAttributeAsString("uid"));
			        					// niente ruoli --> l'utente scomparir� dalla mappatura
			        					params.put("roles", "");
			        					
			        					
			        					PARPCRequest rpcRequest = new PARPCRequest("servlet/endpoint/generic/ProcedureEndpoint", params);
			        					
			        					RPCManager.sendRequest(rpcRequest, new PARPCCallback() {
			        						
			        						@Override
			        						public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
			        							
			        							//
			        							loadingWidget.destroy();
			        							
			        							String responseBody = response.getHttpResponseText();
			        							JSONValue jsonValue = JSONParser.parseStrict(responseBody);
			        							JSONObject jsonObject = jsonValue.isObject();
			        							
			        							String message = jsonObject.get("message").isString().stringValue();
			        							
			        							
			        							if(response.getHttpResponseCode() == Response.SC_OK) {
			        								
			        								SC.say(message, new BooleanCallback() {

			        									@Override
			        									public void execute(Boolean value) {
			        										
			        							            // rpc per la remove
			        										Record record = ldapUserlistGrid.getSelectedRecord();
			        										
			        										Map<String,String> params = new HashMap<String, String>();
			        										
			        										String user = "cn=" + record.getAttributeAsString("cn") + ",o=" + record.getAttributeAsString("o") + ",c=" + record.getAttributeAsString("c");
			        										params.put("user", user);
			        						        		
			        						        		PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/LDAPUserEndpoint", DSRequestType.REMOVE, params);
			        						        		
			        						        		RPCManager.sendRequest(dsRequest, new PADSCallback() {
			        											
			        						        			@Override
			        						        			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
			        						        				
			        						        				//ldapUserlistGrid.fetchData();
			        						        				fetchLdapUserGrid();
			        					                		}
			        						                		
			        										});
			        									}
			        									
			        								});
			        							}
			        							else {
			        								
			        								SC.warn(message);
			        							}
			        						}
			        					});
										
										
									}
									
								}
							});
							
						}
						// user is NOT in WS role/user mapping
						else {
							
							SC.confirm("Delete selected user?", new BooleanCallback() {
						
								@Override
								public void execute(Boolean value) {
									
									if(value) {
										
										 // rpc per la remove
										Record record = ldapUserlistGrid.getSelectedRecord();
										
										Map<String,String> params = new HashMap<String, String>();
										
										String user = "cn=" + record.getAttributeAsString("cn") + ",o=" + record.getAttributeAsString("o") + ",c=" + record.getAttributeAsString("c");
										params.put("user", user);
						        		
						        		PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/LDAPUserEndpoint", DSRequestType.REMOVE, params);
						        		
						        		RPCManager.sendRequest(dsRequest, new PADSCallback() {
											
						        			@Override
						        			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						        				
						        				//ldapUserlistGrid.fetchData();
						        				fetchLdapUserGrid();
					                		}
						                		
										});
						        		
									}
									
					        		
								}
			        		
							});
			        		
						}
						
					}
				});
			}
		});
		
		//reset
		final StandardButton buttonSendNewPass = new StandardButton();  
		buttonSendNewPass.setTitle("Send New Password");
		buttonSendNewPass.setShowRollOver(true);  
		buttonSendNewPass.setShowDown(true);  
		buttonSendNewPass.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(ldapUserlistGrid.getSelectedRecord() == null) {
					
					SC.warn("No selected user.");
					
					return;
				}			
				
				Record record = ldapUserlistGrid.getSelectedRecord();
				if(record.getAttributeAsString("mail")==null || record.getAttributeAsString("mail").equalsIgnoreCase("")){
					SC.warn("Selected user doesn't have e-mail address");
						
					return;
				}
				
				SC.confirm("Do you want to send a new password to "+record.getAttributeAsString("cn")+" ?", new BooleanCallback() {
					
					@Override
					public void execute(Boolean value) {
						
						if(value) {
							
							 // rpc per la remove
							Record record = ldapUserlistGrid.getSelectedRecord();
							
							Map<String,String> params = new HashMap<String, String>();
							
							String user = "cn=" + record.getAttributeAsString("cn") + ",o=" + record.getAttributeAsString("o") + ",c=" + record.getAttributeAsString("c");
							params.put("user", user);

							params.put("_operationId", "sendNewPassword");
							
							PARPCRequest rpcRequest = new PARPCRequest("servlet/endpoint/generic/ProcedureEndpoint", params);
			        		
							RPCManager.sendRequest(rpcRequest, new PARPCCallback() {
								
			        			@Override
			        			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
			        				
			        				String responseBody = response.getHttpResponseText();
									JSONValue jsonValue = JSONParser.parseStrict(responseBody);
									JSONObject jsonObject = jsonValue.isObject();
									String message = jsonObject.get("message").isString().stringValue();
									
									if(response.getHttpResponseCode()!=Response.SC_OK){
										SC.warn(message);
									}else{
										SC.say(message);
									}
			        				fetchLdapUserGrid();
		                		}
			                		
							});	
							
							
						}		        		
					}
        		
				});
			}
		});
		//fine reset
		
		final StandardButton buttonSendReport = new StandardButton();  
		buttonSendReport.setTitle("Send Report");
		buttonSendReport.setShowRollOver(true);  
		buttonSendReport.setShowDown(true);  
		buttonSendReport.addClickHandler(new ClickHandler() {  
			@Override
            public void onClick(ClickEvent event) {
				
				//
				final LoadingWidget loadingWidget = new LoadingWidget();
				loadingWidget.draw();
				
				
				Map<String,String> params = new HashMap<String, String>();
				params.put("_operationId", "sendReport");
				
				PARPCRequest rpcRequest = new PARPCRequest("servlet/endpoint/generic/ProcedureEndpoint", params);
				
				RPCManager.sendRequest(rpcRequest, new PARPCCallback() {
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						//
						loadingWidget.destroy();
						
						
						String responseBody = response.getHttpResponseText();
						JSONValue jsonValue = JSONParser.parseStrict(responseBody);
						JSONObject jsonObject = jsonValue.isObject();
						
						String message = jsonObject.get("message").isString().stringValue();
						
						if(response.getHttpResponseCode() == Response.SC_OK) {
							
							SC.say(message);
						}
						else {
							
							SC.warn(message);
						}
					}
				});
			}
        });
		
		
		buttonHLayout.addMember(buttonAddUser);
		buttonHLayout.addMember(buttonDeleteUser);
		buttonHLayout.addMember(buttonSendNewPass);
		buttonHLayout.addMember(buttonSendReport);
		
		
		return buttonHLayout;
	}
	
	
	private ListGrid createLDAPUserListGrid() {
		
		ListGrid listGrid = new ListGrid();
		
	    listGrid.setWidth("70%");
	    listGrid.setHeight100();
	    
	    ListGridField sn = new ListGridField("sn");
	    sn.setWidth("25%");
	    ListGridField cn = new ListGridField("cn"); 
	    cn.setWidth("25%");
	    ListGridField uid = new ListGridField("uid");  
	    uid.setWidth("25%");
	    ListGridField o = new ListGridField("o"); 
	    o.setHidden(true);
	    ListGridField c = new ListGridField("c");  
	    c.setHidden(true);
	    ListGridField ou = new ListGridField("ou"); 
	    ou.setTitle("Company");
	    ou.setWidth("25%");
	    ListGridField mail = new ListGridField("mail");  
	    mail.setWidth("25%");
	    
	    listGrid.setFields(sn, cn, uid, o, c, ou, mail);
	    
	    listGrid.setSelectionType(SelectionStyle.SINGLE);
	    
	    
	    // first fetch
	    listGrid.fetchData();
	    
	    
	    return listGrid;
	}
	
	
	private ToolStripButton createRefreshButton(){
		ToolStripButton refreshButton = new ToolStripButton();  
		refreshButton.setID("refreshButton");
		refreshButton.setIcon("[SKIN]/actions/refresh.png");
		refreshButton.setPrompt("Refresh List");
		refreshButton.setTitle("Refresh");
		
		refreshButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				//ldapUserlistGrid.fetchData();
				fetchLdapUserGrid();
			}
		});
		
		return refreshButton;
	}
	
	
	private VLayout createForm() {
		
		VLayout containerLayout = new VLayout();
    	containerLayout.setHeight100();
    	containerLayout.setWidth100();
    	containerLayout.setAlign(Alignment.CENTER);
    	containerLayout.setMembersMargin(7);

    	HLayout buttonContainer = new HLayout();
    	buttonContainer.setHeight100();
    	buttonContainer.setWidth100();
    	buttonContainer.setAlign(Alignment.CENTER);
    	buttonContainer.setMembersMargin(5);
    	
		final DynamicForm form = new DynamicForm();
        form.setMargin(5);
        form.setNumCols(1);
        form.setHeight100();  
        form.setWidth100();  

        form.setLayoutAlign(VerticalAlignment.CENTER);  
        
        RegExpValidator regExpValidatorAdv = new RegExpValidator(Regex.REGEX_VALIDATOR_ADV);
        regExpValidatorAdv.setErrorMessage("Invalid characters are presents");
        RegExpValidator regExpValidatorBase = new RegExpValidator(Regex.REGEX_BASE_VALIDATOR);
        regExpValidatorBase.setErrorMessage("Invalid characters are presents");
        RegExpValidator emailValidator = new RegExpValidator(Regex.REGEX_EMAIL_VALIDATOR);  
        emailValidator.setErrorMessage("Invalid email address");  
        
        final TextItem snText = new TextItem("sn");  
        snText.setTitle("sn");        
        snText.setRequired(true);
        snText.setValidators(regExpValidatorAdv);
        
        final TextItem cnText = new TextItem("cn");  
        cnText.setTitle("cn"); 
        cnText.setRequired(true);
        cnText.setValidators(regExpValidatorAdv);
        
        final TextItem uidText = new TextItem("uid");  
        uidText.setTitle("uid"); 
        uidText.setRequired(true);
        uidText.setValidators(regExpValidatorBase);
        
        final TextItem oText = new TextItem("o");  
        oText.setTitle("o"); 
        oText.setRequired(true);
        oText.disable();
        oText.setCanEdit(false);
        
        final TextItem cText = new TextItem("c");  
        cText.setTitle("c"); 
        cText.setRequired(true);
        cText.disable();
        cText.setCanEdit(false);
        
        final SelectItem ouSelect = new SelectItem("ou");  
        ouSelect.setTitle("Company"); 
        ouSelect.setRequired(true);
        ouSelect.setType("enum"); 
       
        
        final TextItem mailText = new TextItem("mail");  
        mailText.setTitle("E-Mail"); 
        mailText.setRequired(true);
        mailText.setValidators(emailValidator);
        
        final PasswordItem pwd = new PasswordItem("pwd");
        pwd.setTitle("Password");
        pwd.setRequired(true);
        pwd.setValidators(regExpValidatorBase);
        
        PasswordItem confPwd = new PasswordItem("confPwd");
        confPwd.setTitle("Confirm Password");
        confPwd.setRequired(true);
        confPwd.setValidators(regExpValidatorBase);
        
        MatchesFieldValidator matchesValidator = new MatchesFieldValidator();  
        matchesValidator.setOtherField("pwd");  
        matchesValidator.setErrorMessage("Passwords do not match");          
        confPwd.setValidators(matchesValidator);  
        
        final SelectItem  roleSelectItem = new SelectItem ();
        roleSelectItem.setColSpan(4);
        roleSelectItem.setAlign(Alignment.LEFT);
        roleSelectItem.setTitle("<nobr>Select Role</nobr>");
        roleSelectItem.setType("comboBox"); 
        roleSelectItem.setMultiple(true);
        
        
        Map<String,String> params = new HashMap<String, String>();
		params.put("_operationId", "fetchAll");
		
		PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/RoleEndpoint", DSRequestType.FETCH, params);
		
		RPCManager.sendRequest(dsRequest, new PADSCallback() {
			@Override
			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				LinkedHashMap<String, String> valueMap = Json2POJO.getComboLinkedHashMap(response);
				
				roleSelectItem.setValueMap(valueMap);
			}
		});
		
		
		params = new HashMap<String, String>();
		params.put("_operationId", "fetch_O_C_OU");
		
		dsRequest = new PADSRequest("servlet/endpoint/data/LDAPUserEndpoint", DSRequestType.FETCH, params);
		
		RPCManager.sendRequest(dsRequest, new PADSCallback() {
			@Override
			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				Map<String, String> valueMap = Json2POJO.getMap(response);
				
				oText.setDefaultValue(valueMap.get("o")); 
				oText.setValue(valueMap.get("o"));
				cText.setDefaultValue(valueMap.get("c"));
				cText.setValue(valueMap.get("c"));
				ouSelect.setValueMap((String[])valueMap.get("ou").split(","));
				
				/*oText.disable();
				cText.disable();
				ouText.disable();*/
			}
		});
		
		
        form.setFields(snText, cnText, uidText, oText, cText, ouSelect, mailText, pwd, confPwd, roleSelectItem);
        
        
        final StandardButton saveButton = new StandardButton();
        saveButton.setTitle("Save");
        saveButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				
				if(!form.validate()){
					
					return;
				}
				
				
				Map<String,String> params = new HashMap<String, String>();
        		params.put("cn", cnText.getValueAsString());
        		params.put("sn", snText.getValueAsString());
        		params.put("uid", uidText.getValueAsString());
        		params.put("userpassword", pwd.getValueAsString());
        		params.put("mailAddress", mailText.getValueAsString());
        		params.put("ou", ouSelect.getValueAsString());
        		
        		
        		PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/LDAPUserEndpoint", DSRequestType.ADD, params);
        		
        		RPCManager.sendRequest(dsRequest, new PADSCallback() {
        			@Override
        			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
        				
        				// aggiorno griglia
        				//ldapUserlistGrid.fetchData();
        				fetchLdapUserGrid();
        				
        				// se sono stati specificati dei ruoli per il nuovo utente, lancio la procedura d'associazione
        				String[] roles = roleSelectItem.getValues();
        				
        				if(roles.length > 0) {
        					
        					//
        					final LoadingWidget loadingWidget = new LoadingWidget();
        					loadingWidget.draw();
        					
        					
        					Map<String,String> params = new HashMap<String, String>();
        					params.put("_operationId", "saveUserRoleMatching");
        					// passa al server i dati per i settaggi
        					/*String user = "cn=" + cnText.getValueAsString() + ",o=" + oText.getValueAsString() + ",c=" + cText.getValueAsString();
        					params.put("user", user);*/
        					params.put("uid", uidText.getValueAsString());
        					
        					String rolesString = new String();
        					for(String role : roles) {
        						
        						rolesString += role + "|";
        					}
        					rolesString = rolesString.substring(0, rolesString.length() - 1);
        					
        					params.put("roles", rolesString);
        					
        					
        					PARPCRequest rpcRequest = new PARPCRequest("servlet/endpoint/generic/ProcedureEndpoint", params);
        					
        					RPCManager.sendRequest(rpcRequest, new PARPCCallback() {
        						@Override
        						public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
        							
        							//
        							loadingWidget.destroy();
        							
        							
        							String responseBody = response.getHttpResponseText();
        							JSONValue jsonValue = JSONParser.parseStrict(responseBody);
        							JSONObject jsonObject = jsonValue.isObject();
        							
        							String message = jsonObject.get("message").isString().stringValue();
        							
        							
        							if(response.getHttpResponseCode() == Response.SC_OK) {
        								
        								SC.say(message);
        							}
        							else {
        								
        								SC.warn(message);
        							}
        							
        							saveButton.enable();
        						}
        					});
        					
                		}
        				form.reset();
        			}
        		});
				
			}
		});
        
        StandardButton cancelButton = new StandardButton();
        cancelButton.setTitle("Cancel");
        cancelButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				
				form.reset();
			}
		});
        
        buttonContainer.addMember(saveButton);
        buttonContainer.addMember(cancelButton);
        
        
        containerLayout.addMember(form);
        containerLayout.addMember(buttonContainer);
        
        return containerLayout;
	}
	
	private void fetchLdapUserGrid() {
		
		Map<String,String> params = new HashMap<String, String>();
		params.put("_operationId", "fetchAll");
		
		PADSRequest dsRequest = new PADSRequest("servlet/endpoint/data/LDAPUserEndpoint", DSRequestType.FETCH, params);

		RPCManager.sendRequest(dsRequest, new PADSCallback() {
			@Override
			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				Record[] records = Json2POJO.getGridRecords(response);
				
				ldapUserlistGrid.setData(records);
			}
		});
		
	}
	
	
}
