package it.ccg.portaladminweb.client;



import it.ccg.portaladminweb.client.rpc.PARPCCallback;
import it.ccg.portaladminweb.client.rpc.PARPCRequest;
import it.ccg.portaladminweb.client.security.UserData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.http.client.Response;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONValue;
import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window.Location;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;


public class Main implements EntryPoint {

	@Override
	public void onModuleLoad() {
		
		// Login check
		// If user does not login, server does not generate LTPA token
		if(Cookies.getCookie("LtpaToken2") == null) {
			
			Location.assign(Location.getPath() + "login.jsp");
			
			return;
		}
		
		// Expired session/LTPA token check
		Timer sessionExpiredCheckTimer = new Timer() {
			
			@Override
			public void run() {
				
				// Expired session check
				// If session is expired, server destroys the login generated LTPA token and FORWARDS to login page.
				// At this time (login page RPC), LTPA token does not exist.
				if(Cookies.getCookie("LtpaToken2") == null) {
					
					Location.assign(Location.getPath() + "login.jsp");
					
					return;
				}
				
				// Expired LTPA token check
				// If LTPA token is expired, WebSphere REDIRECTS to login page (through the "Location" response header) 
				// forces the client to set the WASReqURL cookie (through the "Set-cookie" response header)
				// source: http://www-01.ibm.com/support/docview.wss?uid=swg21422980
				if(Cookies.getCookie("WASReqURL") != null) {
					
					Location.assign(Location.getPath() + "login.jsp");
					
					return;
				}
				
				
				// Some debug
				/*Collection<String> cookies = Cookies.getCookieNames();
				
				String debug = new String();
				
				debug += "COOKIE" + "<br>";
				for(String cookieName : cookies) {
					
					String cookieValue = Cookies.getCookie(cookieName);
					String cookieValueOutput = new String();
					if(cookieValue.length() < 100) {
						
						cookieValueOutput = cookieValue;
					}
					else {
						int i=0;
						while(i < cookieValue.length()) {
							
							if((i % 100) == 0) {
								
								cookieValueOutput += "<br>";
							}
							
							cookieValueOutput += cookieValue.charAt(i);
								
							i++;
						}
						
					}
					
					debug += cookieName + ": " + cookieValueOutput + "<br>";
				}
				
				
				Document document = Document.get();
				
				debug += "<br>";
				debug += "LOCATION" + "<br>";
				
				debug += "url" + ": " + document.getURL() + "<br>";
				
				
				SC.say(debug);*/
				
			}
		};
		
		sessionExpiredCheckTimer.scheduleRepeating(5*1000);
		
		
		
		// get user info
		RPCRequest rpcRequest = new PARPCRequest("servlet/security/UserInfo", null);
		
		RPCManager.sendRequest(rpcRequest, new PARPCCallback() {
			
			@Override
			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				if(response.getHttpResponseCode() == Response.SC_OK) {
					
					@SuppressWarnings("deprecation")
					JSONValue jsonValue = JSONParser.parse(response.getAttributeAsString("httpResponseText"));
					
					JSONObject jsonObject = jsonValue.isObject();
					
					String cn = jsonObject.get("cn").isString().stringValue();
					
					String rolesString = jsonObject.get("roles").isString().stringValue();
					String[] rolesArray = rolesString.split("\\|");
					List<String> userRolesList = new ArrayList<String>();
					for(String role : rolesArray) {
						
						userRolesList.add(role);
					}
					
					
					UserData.setCurrentUserData(new UserData(cn, userRolesList));
				}
				else {
					
					SC.warn("Unable to load user info.", new BooleanCallback() {
						
						@Override
						public void execute(Boolean value) {
							
							Location.assign(Location.getPath() + "login.jsp");
							
							return;
						}
					});
					
					return;
				}
				
				
				// check if CCGPortal is correctly installed on WS
				Map<String,String> params = new HashMap<String, String>();
				params.put("_operationId", "checkInstalledApp");
				
				RPCRequest rpcRequest = new PARPCRequest("servlet/system/SystemInfo", params);
				
				RPCManager.sendRequest(rpcRequest, new PARPCCallback() {
					
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						@SuppressWarnings("deprecation")
						JSONValue jsonValue = JSONParser.parse(response.getAttributeAsString("httpResponseText"));
						
						JSONObject jsonObject = jsonValue.isObject();
						
						String installedAppCheck = jsonObject.get("installedAppCheck").isString().stringValue();
						
						if(!installedAppCheck.equalsIgnoreCase("0")) {
							
							SC.warn("CCGPortal not installed on WAS.", new BooleanCallback() {
								
								@Override
								public void execute(Boolean value) {
									
									Location.assign(Location.getPath() + "login.jsp");
									
									return;
								}
							});
							
							return;
						}
						
						
						// start
						MainLayout.getInstance().draw();
						
					}

				});
				
			}

		});
		
	}
	
	
}
