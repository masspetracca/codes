package it.ccg.portaladminweb.client;



import it.ccg.portaladminweb.client.rpc.PARPCCallback;
import it.ccg.portaladminweb.client.rpc.PARPCRequest;
import it.ccg.portaladminweb.client.rpcutil.Json2POJO;
import it.ccg.portaladminweb.client.security.UserData;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gwt.http.client.Response;
import com.google.gwt.user.client.Window.Location;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.LinkItem;
import com.smartgwt.client.widgets.form.fields.events.ClickEvent;
import com.smartgwt.client.widgets.form.fields.events.ClickHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.layout.VLayout;


public class HeaderUserSection extends Canvas {
	
	
	public HeaderUserSection() {
		
		super();
		
		this.setWidth("10%");
		
		
		DynamicForm dynamicForm = new DynamicForm();
		dynamicForm.setNumCols(1);
		dynamicForm.setItems(this.createAccountLink(), this.createPampUsersLink());
		
		dynamicForm.setTop(10);
		
		this.addChild(dynamicForm);
		
	}
	
	
	private LinkItem createAccountLink() {
		
		LinkItem accountLink = new LinkItem();
		
		accountLink.setShowTitle(false);
		
		accountLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(Window.getById("_AccountWindow") != null) {
					
					MainLayout.getMainLayout().removeChild(Window.getById("_AccountWindow"));
					
					Window.getById("_AccountWindow").destroy();
				}
				
				
				Window accountWindow = createAccountWindow();
				
				accountWindow.setLeft(MainLayout.getMainLayout().getWidth() - 200);
				MainLayout.getMainLayout().addChild(accountWindow);
				
			}
			
		});
		
		
		List<String> currentUserRolesList = UserData.getCurrentUserData().getUserRolesList();
		
		String rolesString = "";
		for(String role : currentUserRolesList) {
			rolesString += role + ", ";
		}
		rolesString = rolesString.substring(0, rolesString.length() - 2);
		
		//
		accountLink.setLinkTitle("<font color=\"005596\"><b>" + UserData.getCurrentUserData().getCn() + "</b> " + "(" + rolesString + ")"+"</font>");
		
		
		return accountLink;
	}
	
	
	private LinkItem createPampUsersLink() {
		
		LinkItem userLink = new LinkItem();
		
		userLink.setShowTitle(false);
		userLink.setLinkTitle("<font color=\"005596\">PAMP logged users</font>");
		
		userLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(Window.getById("_UsersWindow") != null) {
					
					MainLayout.getMainLayout().removeChild(Window.getById("_UsersWindow"));
					
					Window.getById("_UsersWindow").destroy();
				}
				
				
				Window usersWindow = createPampUsersWindow();
				
				usersWindow.setLeft(MainLayout.getMainLayout().getWidth() - 230);
				MainLayout.getMainLayout().addChild(usersWindow);
				
			}
			
		});
		
		
		return userLink;
	}
	
	
	

	private Window createAccountWindow() {
		
		final Window accountWindow = new Window();
		
		accountWindow.setID("_AccountWindow");
		accountWindow.setTop(45);
		
		accountWindow.setWidth(180);
		accountWindow.setHeight(110);
		
		accountWindow.setShowHeader(false);
		accountWindow.setShowEdges(false);
		accountWindow.setCanDragResize(false);
		accountWindow.setCanDragReposition(false);
		
		accountWindow.setShowShadow(true);  
		accountWindow.setShadowSoftness(10);  
		accountWindow.setShadowOffset(10);
		
		DynamicForm logoutLinkDynamicForm = new DynamicForm();
		logoutLinkDynamicForm.setItems(this.createLogoutLink());
		
		VLayout vLayout = new VLayout();
		vLayout.setWidth100();
		vLayout.setTop(22);
		
		vLayout.setMembers(logoutLinkDynamicForm);
		vLayout.setLayoutLeftMargin(5);
		
		accountWindow.addChild(vLayout);
		
		
		return accountWindow;
	}
	
	private LinkItem createLogoutLink() {
		
		LinkItem logoutLink = new LinkItem();
		
		logoutLink.setShowTitle(false);
		logoutLink.setLinkTitle("<font color=\"005596\">Logout</font>");
		
		logoutLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				RPCRequest rpcRequest = new RPCRequest();
				
				rpcRequest.setActionURL("servlet/security/Logout");
				
				RPCManager.sendRequest(rpcRequest, new PARPCCallback() {
					
					@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						// *** NOT WORKING, Location not found
						
						/*@SuppressWarnings("unchecked")
						Map<Object, Object> httpHeader = response.getHttpHeaders();
						
						Object location = httpHeader.get("Location");*/
						
						// TODO - remove
						//SC.say((String)location);
						
						
						//com.google.gwt.user.client.Window.Location.assign("/InfoProviderWEB/login.html");
						//com.google.gwt.user.client.Window.Location.assign((String)location);
						
						
						//com.google.gwt.user.client.Window.Location.reload();
						// ***
						
						
						// *** NOT WORKING, the url is the old request url, i.e. Logout sefvlet url
						
						/*String[] url = request.getActionURL().split("\\/");
						String resource = url[url.length - 1];
						
						SC.say((String)location);
						
						
						if(resource.equalsIgnoreCase("login.jsp")) {
							
							Location.assign(Location.getPath() + "login.jsp");
							
							return;
						}*/
						// ***
						
						
						// 
						if(response.getHttpResponseText() != null) {
							
							if(response.getHttpResponseText().contains("<form method=\"post\" action=\"j_security_check\">")) {
								
								Location.assign(Location.getPath() + "login.jsp");
								
								return;
							}
						}
						
					}
				});
				
			}
			
		});
		
		
		return logoutLink;
	}
	
	
	private Window createPampUsersWindow() {
		
		final Window usersWindow = new Window();
		
		usersWindow.setID("_UsersWindow");
		usersWindow.setTop(65);
		
		usersWindow.setWidth(210);
		usersWindow.setHeight(160);
		
		usersWindow.setShowHeader(false);
		usersWindow.setShowEdges(false);
		usersWindow.setCanDragResize(false);
		usersWindow.setCanDragReposition(false);
		
		usersWindow.setShowShadow(true);  
		usersWindow.setShadowSoftness(10);  
		usersWindow.setShadowOffset(10);
		
		
		final ListGrid userListGrid = new ListGrid();
		userListGrid.setWidth100();
		userListGrid.setHeight100();
		userListGrid.setShowHeader(false);
		userListGrid.setFields(new ListGridField("userName"));
		
		usersWindow.addChild(userListGrid);
		
		
		Map<String,String> params = new HashMap<String, String>();
		params.put("_operationId", "getLoggedUsers");
		
		RPCRequest rpcRequest = new PARPCRequest("servlet/system/SystemInfo", params);
		
		
		RPCManager.sendRequest(rpcRequest, new PARPCCallback() {
			
			@Override
			public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
				
				if(response.getHttpResponseCode() == Response.SC_OK) {
					
					Record[] records = Json2POJO.getGridRecords(response);
					
					userListGrid.setData(records);
				}
				else {
					
					SC.warn("Unable to load PAMP logged users.");
				}
				
			}

		});
		
		
		return usersWindow;
	}


}
