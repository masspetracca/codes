package it.ccg.irweb.server.servlet;

import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.system.SystemProperties;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.isomorphic.rpc.RPCManager;
import com.isomorphic.rpc.RPCResponse;


/**
 * Servlet implementation class LinearParameterSettingEndpoint
 */
public class LinearParameterSettingEndpoint extends GenericEndpoint {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = LoggerFactory.getLogger(LoggerFactory.USER_LOGGER);
	private Properties properties;
    /**
     * Default constructor. 
     */
    public LinearParameterSettingEndpoint() {
        // TODO Auto-generated constructor stub
    }

	/* (non-Javadoc)
	 * @see it.ccg.irweb.server.servlet.GenericEndpoint#fetch(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void fetch(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		logger.info(new StandardLogMessage("in LinearParameterSettingEndpoint.fetch"));
		userLogger.info(new StandardLogMessage("in LinearParameterSettingEndpoint.fetch"));
		try {
			this.properties = SystemProperties.getLinearProperties();
			logger.debug(new StandardLogMessage("loading properties"));
			Double slopeMarket = new Double(this.properties.getProperty("slope.Market"));
			Double offsetMarket = new Double(this.properties.getProperty("offset.Market"));
			Double slopeFinancial = new Double(this.properties.getProperty("slope.Financial"));
			Double offsetFinancial = new Double(this.properties.getProperty("offset.Financial"));
			Double constantFinancial = new Double(this.properties.getProperty("constant.financial"));
			logger.debug(new StandardLogMessage("properties loaded"));
			
			logger.debug(new StandardLogMessage("slopeMarket "+slopeMarket));
			logger.debug(new StandardLogMessage("offsetMarket "+offsetMarket));
			logger.debug(new StandardLogMessage("slopeFinancial "+slopeFinancial));
			logger.debug(new StandardLogMessage("offsetFinancial "+offsetFinancial));
			logger.debug(new StandardLogMessage("offsetFinancial "+offsetFinancial));
			logger.debug(new StandardLogMessage("constantFinancial "+constantFinancial));
			RPCManager rpc = null;		
			
			rpc = new RPCManager(request, response);
			
			RPCResponse rpcResponse = new RPCResponse();;
			
			// creo un hashmap per la risposta
			HashMap<String, Double> responseParams = new HashMap<String, Double>();
			logger.debug(new StandardLogMessage("creating resposne map"));
			responseParams.put("slopeMarket", slopeMarket);
			responseParams.put("offsetMarket", offsetMarket);
			responseParams.put("slopeFinancial", slopeFinancial);
			responseParams.put("offsetFinancial", offsetFinancial);
			responseParams.put("constantFinancial", constantFinancial);
			
			logger.debug(new StandardLogMessage("setting data to response"));
			rpcResponse.setData(responseParams);
			
			logger.info(new StandardLogMessage("sending response"));
			userLogger.info(new StandardLogMessage("sending response"));
			rpc.send(rpcResponse);
			
		} catch (NumberFormatException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			ExceptionUtil.logCompleteStackTrace(userLogger, e);
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			ExceptionUtil.logCompleteStackTrace(userLogger, e);
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}
		
	}

	/* (non-Javadoc)
	 * @see it.ccg.irweb.server.servlet.GenericEndpoint#add(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void add(HttpServletRequest request, HttpServletResponse response) {
		logger.info(new StandardLogMessage("in LinearParameterSettingEndpoint.add"));
		userLogger.info(new StandardLogMessage("in LinearParameterSettingEndpoint.add"));
		
		try {
			this.properties = SystemProperties.getLinearProperties();
		
			logger.debug(new StandardLogMessage("loading properties"));
			logger.debug(new StandardLogMessage(request.getParameter("slopeMarketStringValue")+" "+request.getParameter("offsetMarketStringValue")+" "+request.getParameter("slopeFinancialStringValue")+" "+request.getParameter("offsetFinalcialStringValue")));
			Double slopeMarket=null;
			Double offsetMarket=null;
			Double slopeFinancial=null;
			Double offsetFinancial=null;
			Double constantFinancial = null;
			
			if (request.getParameter("slopeMarketStringValue")!=null)
				slopeMarket= new Double(request.getParameter("slopeMarketStringValue"));
			if (request.getParameter("offsetMarketStringValue")!=null)
				offsetMarket = new Double(request.getParameter("offsetMarketStringValue"));
			if (request.getParameter("slopeFinancialStringValue")!=null)
				slopeFinancial = new Double(request.getParameter("slopeFinancialStringValue"));
			if (request.getParameter("offsetFinalcialStringValue")!=null)
				offsetFinancial = new Double(request.getParameter("offsetFinalcialStringValue"));
			if (request.getParameter("constantFinancial")!=null)
				constantFinancial = new Double(request.getParameter("constantFinancial"));
			
			if (request.getParameter("buttonName").equalsIgnoreCase("saveMarketButton")){
				if ((slopeMarket!=null && (new Double(this.properties.getProperty("slope.Market"))!= slopeMarket)) && (offsetMarket!=null && (new Double(this.properties.getProperty("offset.Market"))!= offsetMarket))){
					logger.info(new StandardLogMessage("storing market properties"));
					this.properties.put("slope.Market", slopeMarket.toString());
					this.properties.put("offset.Market", offsetMarket.toString());
					
					logger.debug(new StandardLogMessage("path "+SystemProperties.getLinearPropertiesFileAbsPath()));
					this.properties.store(new FileWriter(SystemProperties.getLinearPropertiesFileAbsPath()), null);
					
				}else{
					logger.info(new StandardLogMessage("data incomplete: slopeMarket "+slopeMarket+" offsetMarket "+offsetMarket));
					userLogger.info(new StandardLogMessage("data incomplete: slopeMarket "+slopeMarket+" offsetMarket "+offsetMarket));
					response.setStatus(HttpServletResponse.SC_BAD_REQUEST, "Imcoplete data");
				}
			}else if (request.getParameter("buttonName").equalsIgnoreCase("saveFinancialButton")){
				if ((slopeFinancial!=null && (new Double(this.properties.getProperty("slope.Financial"))!= slopeFinancial)) && 
					(offsetFinancial!=null && (new Double(this.properties.getProperty("offset.Financial"))!= offsetFinancial)) &&
					(constantFinancial!=null &&(new Double(this.properties.getProperty("constant.financial"))!= offsetFinancial))){
					logger.info(new StandardLogMessage("storing financial properties"));
					this.properties.put("slope.Financial", slopeFinancial.toString());
					this.properties.put("offset.Financial", offsetFinancial.toString());
					this.properties.put("constant.financial", constantFinancial.toString());
					
					logger.debug(new StandardLogMessage("path "+SystemProperties.getLinearPropertiesFileAbsPath()));
					this.properties.store(new FileWriter(SystemProperties.getLinearPropertiesFileAbsPath()), null);
					
				}else{
					logger.info(new StandardLogMessage("data incomplete: slopeFinancial "+slopeFinancial+" offsetFinancial "+offsetFinancial+" constantFinancial "+constantFinancial));
					userLogger.info(new StandardLogMessage("data incomplete: slopeFinancial "+slopeFinancial+" offsetFinancial "+offsetFinancial));
					response.setStatus(HttpServletResponse.SC_BAD_REQUEST, "Imcoplete data"); 
				}
			}
			else{
				logger.info(new StandardLogMessage("data incomplete: slopeFinancial "+slopeFinancial+" offsetFinancial "+offsetFinancial+" constantFinancial "+constantFinancial));
				userLogger.info(new StandardLogMessage("data incomplete: slopeFinancial "+slopeFinancial+" offsetFinancial "+offsetFinancial));
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST, "Imcoplete data"); 
			}
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			ExceptionUtil.logCompleteStackTrace(userLogger, e);
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

    
}
