package it.ccg.irweb.client.elements;

import it.ccg.irweb.client.ApprovedRatingCanvas;
import it.ccg.irweb.client.BankBalHistCanvas;
import it.ccg.irweb.client.BankExtRatingHistCanvas;
import it.ccg.irweb.client.BankIssuesHistCanvas;
import it.ccg.irweb.client.BankStaticDataCanvas;
import it.ccg.irweb.client.LinearParamSettingCanvas;
import it.ccg.irweb.client.LogCanvas;
import it.ccg.irweb.client.ParameterSelectionCanvas;
import it.ccg.irweb.client.RatingProposalCanvas;
import it.ccg.irweb.client.RatingTranscodeCanvas;
import it.ccg.irweb.client.RiskCommitteeCanvas;
import it.ccg.irweb.client.SchedulersCanvas;

import com.smartgwt.client.types.SortArrow;
import com.smartgwt.client.types.TreeModelType;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.PasswordItem;
import com.smartgwt.client.widgets.form.fields.events.KeyPressEvent;
import com.smartgwt.client.widgets.form.fields.events.KeyPressHandler;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.MenuItemIfFunction;
import com.smartgwt.client.widgets.menu.events.MenuItemClickEvent;
import com.smartgwt.client.widgets.tree.Tree;
import com.smartgwt.client.widgets.tree.TreeGrid;
import com.smartgwt.client.widgets.tree.TreeGridField;

public class SideNavTree extends TreeGrid {

	private String idSuffix = "";
	/*private String[] requestedRoles;
	private InternalRatingTreeNode[] navTreeData;*/
	private Tree tree;
	
	public SideNavTree() {
		
		this.setID("sidenavtree");

		setWidth100();
		setHeight100();
		setCustomIconProperty("icon");
		setAnimateFolderTime(100);
		setAnimateFolders(true);
		setAnimateFolderSpeed(1000);
		setShowSortArrow(SortArrow.CORNER);
		setShowAllRecords(true);
		setLoadDataOnDemand(false);
		setCanSort(false);
		setLeaveScrollbarGap(false);

		TreeGridField field = new TreeGridField();
		field.setCanFilter(true);
		field.setName("name");
		field.setTitle("<b>Internal rating</b>");
		setFields(field);

		tree = new Tree();
		tree.setModelType(TreeModelType.PARENT);
		tree.setNameProperty("name");
		tree.setOpenProperty("isOpen");
		tree.setIdField("id");
		tree.setParentIdField("parentId");
		tree.setRootValue("root");
		
		this.createTreeNode();
		
		setData(tree);
			
	}
	
	public InternalRatingTreeNode[] getShowcaseData() {
		return (InternalRatingTreeNode[])tree.getData();
	}
	
	private Menu createContextMenu() {
		Menu menu = new Menu();
		menu.setWidth(140);

		MenuItem consoleMenuItem = new MenuItem("Console...");
		
		consoleMenuItem.setEnableIfCondition(new MenuItemIfFunction() {
			public boolean execute(Canvas target, Menu menu, MenuItem item) {
			
				//Inserire qui eventuali condizioni
				//requestedRoles=new String[] {"admin"};
				/*if (Privileges.hasPrivileges(requestedRoles))
					return true;*/
				return false;
			}
		});
		
		consoleMenuItem.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			public void onClick(MenuItemClickEvent event) {

				final Window winModal = new Window();
				winModal.setWidth(360);
				winModal.setHeight(100);
				winModal.setTitle("");
				winModal.setShowMinimizeButton(false);
				winModal.setAlign(VerticalAlignment.CENTER);
				winModal.setIsModal(true);
				winModal.setShowModalMask(true);
				winModal.centerInPage();

				final DynamicForm form = new DynamicForm();
				final PasswordItem passwordItem = new PasswordItem();
				passwordItem.setTitle("Enter the password");
				passwordItem.setRequired(true);
				//StandardButton showConsole = new StandardButton("Show console");
				/*showConsole.addClickHandler(new ClickHandler() {

					@Override
					public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
						if (passwordItem.getValue() != null && passwordItem.getValue().toString().equals("pampteam")) {

							SC.showConsole();
							winModal.destroy();

						} else
							SC.say("Please enter a valid password");

					}
				});*/

				passwordItem.addKeyPressHandler(new KeyPressHandler() {
					public void onKeyPress(KeyPressEvent event) {
						if (event.getKeyName().equalsIgnoreCase("Enter")) {
							if (passwordItem.getValue() != null && passwordItem.getValue().toString().equals("pampteam")) {

								SC.showConsole();
								winModal.destroy();

							} else
								SC.say("Please enter a valid password");

						}
					}
				});

				winModal.addCloseClickHandler(new CloseClickHandler() {
					public void onCloseClick(CloseClickEvent event) {
						winModal.destroy();
					}
				});

				form.setFields(passwordItem);
				winModal.addItem(form);
				//winModal.addItem(showConsole);
				winModal.show();
			}
		});

		// Define context menu
		
		menu.setItems(consoleMenuItem);
		return menu;
	}
	
	private void createTreeNode(){
		
		InternalRatingTreeNode[] nodes = new InternalRatingTreeNode[]{
				new InternalRatingTreeNode("internaRating", "root", "Internal Rating",null),
				new InternalRatingTreeNode("bankStaticDataNode", "internaRating", "Bank static data",new BankStaticDataCanvas.Creator()),
				new InternalRatingTreeNode("bankBalanceHyst", "internaRating", "Bank balance history",new BankBalHistCanvas.Creator()),
				new InternalRatingTreeNode("bankIssuesHyst", "internaRating", "Bank issues history",new BankIssuesHistCanvas.Creator()),
				new InternalRatingTreeNode("bankExtRatHyst", "internaRating", "Bank external ratings history",new BankExtRatingHistCanvas.Creator()),
				new InternalRatingTreeNode("approvedRatingHyst", "internaRating", "Approved rating history",new ApprovedRatingCanvas.Creator()),
				new InternalRatingTreeNode("ratingTranscode", "internaRating", "Rating transcodes",new RatingTranscodeCanvas.Creator()),
				new InternalRatingTreeNode("riskCommittee", "internaRating", "Risk committee",new RiskCommitteeCanvas.Creator()),
				new InternalRatingTreeNode("parameterSelection", "internaRating", "Parameter selection",new ParameterSelectionCanvas.Creator()),
				new InternalRatingTreeNode("ratingProposal", "internaRating", "Rating proposals",new RatingProposalCanvas.Creator()),
				new InternalRatingTreeNode("linearRegretion", "internaRating", "Linear regression settings", new LinearParamSettingCanvas.Creator()),
				new InternalRatingTreeNode("scheduler", "internaRating", "Scheduler",new SchedulersCanvas.Creator()),
				new InternalRatingTreeNode("logViewer", "internaRating", "Log viewer",new LogCanvas.Creator())
		};
		
		tree.setData(nodes);
	}
}
