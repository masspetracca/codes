package it.ccg.irweb.server.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GenericEndpoint extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5847789231852946151L;

final protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		throw new ServletException("DataEndpoint servlet doesn\'t allow get requests.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	final protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.filterRequest(request, response);
	}
	
	
	final private void filterRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String _operationType = request.getParameter("_operationType");
		System.out.println("_operationType "+_operationType);
		if(_operationType == null) {
			
			throw new ServletException("Unable to process request. \'_operationType\' parameter not found.");
		}
		
		
		if(_operationType.equalsIgnoreCase("fetch")) {
			
			this.fetch(request, response);
		}
		else if(_operationType.equalsIgnoreCase("add")) {
			
			this.add(request, response);
		}
		else if(_operationType.equalsIgnoreCase("update")) {
			
			this.update(request, response);
		}
		else if(_operationType.equalsIgnoreCase("remove")) {
			
			this.remove(request, response);
		}
		else {
			
			throw new ServletException("Unable to process request. \'_operationType\' of type \'" + _operationType + "\' not valid.");
		}
	}
	
	
	protected void fetch(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	
	protected void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	
	protected void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void remove(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
}
