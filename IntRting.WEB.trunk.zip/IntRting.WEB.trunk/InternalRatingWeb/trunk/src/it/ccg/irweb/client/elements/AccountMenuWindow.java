package it.ccg.irweb.client.elements;

import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;


public class AccountMenuWindow extends Window {

public AccountMenuWindow(){
		
		/*super();
		this.setID("AccountMenuWindow");
		this.setShowHeader(false);
		this.setShowTitle(false);
		this.setHeaderStyle("formattedWindowHeader");
		this.setBorder("formattedWindowHeader"); 
		this.setShowShadow(true);  
        this.setShadowSoftness(10);  
        this.setShadowOffset(10);  
        this.setShowEdges(false);
        this.setBackgroundColor("FAFAFA");
		this.setBorder("1px solid #c0c0c0");
		this.setShowCloseButton(false);
		this.setWidth(180);
		this.setHeight(110);
		this.setCanDragReposition(false);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);
		this.setShowMinimizeButton(false);
		this.setMembersMargin(5);

		
		final Window w = this;*/
				
	
		
	
	}
/*	
	public static AccountMenuWindow windowCreator() {

		AccountMenuWindow mw = (AccountMenuWindow) Canvas.getById("AccountMenuWindow");
		if (mw != null) {
			mw.setVisible(true);
			mw.restore();
			mw.bringToFront();
			return mw;
		} else {
			return new AccountMenuWindow();

		}
	
		
	}*/
}
