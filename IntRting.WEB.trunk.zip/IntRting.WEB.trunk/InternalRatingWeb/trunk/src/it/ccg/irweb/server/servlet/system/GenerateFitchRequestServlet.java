package it.ccg.irweb.server.servlet.system;

import it.ccg.irejb.server.bean.ActiveBanksBeanLocal;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.system.SystemProperties;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class GenerateFitchRequestServlet
 */
public class GenerateFitchRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB
	private ActiveBanksBeanLocal activeBanksBean;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = LoggerFactory.getLogger(LoggerFactory.USER_LOGGER);
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GenerateFitchRequestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug(new StandardLogMessage("in GenerateFitchRequestServlet.doGet"));
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug(new StandardLogMessage("in GenerateFitchRequestServlet.doPost"));
		userLogger.info(new StandardLogMessage("in GenerateFitchRequestServlet.doPost"));
		try {
			File file = activeBanksBean.getActiveBanksFitchFile();
			response.setContentType("text/csv");		
			response.setHeader("Content-Disposition", "attachment; filename="+SystemProperties.getSystemProperty("fitch.file.name"));
			response.setContentLength((int)file.length());
			FileInputStream out = new FileInputStream(file);
			int appo = 0;
			while((appo = out.read())!=-1){
				response.getOutputStream().write(appo);
			}
			response.getOutputStream().flush();
		} catch (Exception e) {
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
			ExceptionUtil.logCompleteStackTrace(logger, e);
			ExceptionUtil.logCompleteStackTrace(userLogger, e);
		}
	}

}
