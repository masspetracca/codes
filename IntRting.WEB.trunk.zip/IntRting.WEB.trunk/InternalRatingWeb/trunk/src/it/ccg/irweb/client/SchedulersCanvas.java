package it.ccg.irweb.client;

import it.ccg.irweb.client.base.StandardCanvas;
import it.ccg.irweb.client.controls.StandardButton;
import it.ccg.irweb.client.elements.PopupWindow;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.google.gwt.http.client.Response;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.types.RowEndEditAction;
import com.smartgwt.client.types.TextMatchStyle;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.DateTimeItem;
import com.smartgwt.client.widgets.form.fields.RadioGroupItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.validator.RegExpValidator;
import com.smartgwt.client.widgets.grid.CellFormatter;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.SelectionChangedHandler;
import com.smartgwt.client.widgets.grid.events.SelectionEvent;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;

public class SchedulersCanvas extends StandardCanvas {

	DataSource timerDS;
	ListGrid schedulerGrid;
	Window createTimerWindow;
	
	@SuppressWarnings("deprecation")
	public SchedulersCanvas(){
		super();
		
		timerDS = DataSource.get("timer");

		topContainerLayout.addMember(spacerLayout);
		
		refreshButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				showData();
			}
		});
		
		topContainerLayout.addMember(refreshButton);
		//
		canvasContainerLayout.addMember(topContainerLayout);
		
		StandardButton startImmediatelyButton = new StandardButton("Start immediately");
		startImmediatelyButton.setPrompt("Start immediately a schedule");
		startImmediatelyButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				RPCRequest request = new DSRequest();
				request.setActionURL("servlet/endpoint/SchedulerEndpoint");
				request.setWillHandleError(true);
				
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("_operationType", "add");

				request.setParams(params);
				request.setHttpMethod("POST");
				RPCManager.sendRequest(request, new RPCCallback() 
				{
					@Override
					public void execute(RPCResponse response, Object rawData, RPCRequest request) {
						if (response.getHttpResponseCode() == Response.SC_OK){
							SC.say("Scheduler started", new BooleanCallback() {
								@Override
								public void execute(Boolean value) {
									createTimerWindow.destroy();
									showData();
								}
							});
						}else{
							SC.warn("Scheduler no started", new BooleanCallback() {
								@Override
								public void execute(Boolean value) {
									createTimerWindow.destroy();
									showData();
								}
							});
						}	
					}
				});
			}
		});
		
		StandardButton actScheduleButton = new StandardButton("Act. schedule");
		actScheduleButton.setPrompt("Activate new schedule");
		actScheduleButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
			
				createTimerWindow = PopupWindow.getInstance("New timer", 300, 280);
				createTimerWindow.addCloseClickHandler(new CloseClickHandler() {
					@Override
					public void onCloseClick(CloseClickEvent event) {
						showData();
					}
				});

				createTimerWindow.addMember(createTimerForm());
				createTimerWindow.draw();
				
			}
		});
		
		final StandardButton deActScheduleButton = new StandardButton("Deact. schedule");
		deActScheduleButton.setPrompt("Deactivate selected schedule");
		deActScheduleButton.setDisabled(true);
		deActScheduleButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if(schedulerGrid.getSelectedRecord()==null){
					SC.warn("No record selected");
					return;
				}else{
					RPCRequest request = new DSRequest();
 					request.setActionURL("servlet/endpoint/SchedulerEndpoint");
 					
 					Map<String, Object> params = new HashMap<String, Object>();
 					params.put("_operationType", "remove");
 					params.put("type",schedulerGrid.getSelectedRecord().getAttribute("type"));
 					
 					request.setParams(params);
 					request.setHttpMethod("POST");
 					RPCManager.sendRequest(request, new RPCCallback() {
						
						@Override
						public void execute(RPCResponse response, Object rawData, RPCRequest request) {
							if (response.getHttpResponseCode() == Response.SC_OK){
								SC.say("Scheduler deleted");
								showData();
								deActScheduleButton.setDisabled(true);
							}else{
								SC.warn("Scheduler no deleted");
							}	
						}
					});
				}
			}
		});
		
		ListGridField scheduledTypeField = new ListGridField("type");
		scheduledTypeField.setTitle("Schedule type");
		scheduledTypeField.setWidth("25%");
		Map<String,String> typeMap = new HashMap<String, String>();
		typeMap.put("dailyRun", "Daily run");
		typeMap.put("setUp","Market model setup");
		scheduledTypeField.setValueMap(typeMap);
		
		ListGridField intervalLGField = new ListGridField("interval");
		intervalLGField.setTitle("Interval");
		intervalLGField.setWidth("25%");
		intervalLGField.setCellFormatter(new CellFormatter() {
			
			@Override
			public String format(Object value, ListGridRecord record, int rowNum, int colNum) {
				
				String formattedValue = new String();
				
				if(value != null) {
					
					long intervalInMillis = Long.parseLong(value.toString());
					
					long days = intervalInMillis / (24*60*60*1000);
				    long hours = ((intervalInMillis - days * (24*60*60*1000)))/(60*60*1000);
				    long minutes = ((intervalInMillis - days * (24*60*60*1000) - hours * (60*60*1000)))/(60*1000);
				    
				    formattedValue = days + "d-" + hours + "h-" + minutes + "m";
				}
				
				return formattedValue;
			}
			
		});
		
		ListGridField userField = new ListGridField("user");
		userField.setTitle("User");
		userField.setWidth("25%");
		ListGridField dateField = new ListGridField("startDateTime");
		dateField.setTitle("Started date");
		dateField.setWidth("25%");
		dateField.setFilterEditorType(date); 
		dateField.setEditorType(dateEdit);
	
		schedulerGrid = new ListGrid();
		schedulerGrid.setWidth100();
		schedulerGrid.setFields(scheduledTypeField,dateField,intervalLGField,userField);
		schedulerGrid.setTitle("Schedules");
		schedulerGrid.setDataSource(timerDS);
		schedulerGrid.setShowDetailFields(true);
		schedulerGrid.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATE);
		schedulerGrid.setDatetimeFormatter(DateDisplayFormat.TOEUROPEANSHORTDATE);
		schedulerGrid.setShowFilterEditor(true);
		schedulerGrid.setDataPageSize(40);
		schedulerGrid.setModalEditing(true);
		schedulerGrid.setFilterOnKeypress(false);
		schedulerGrid.setListEndEditAction(RowEndEditAction.NEXT);
		schedulerGrid.setAutoSaveEdits(true);
		schedulerGrid.setAutoFetchData(true);
		schedulerGrid.setEditEvent(ListGridEditEvent.NONE);
		schedulerGrid.setAutoFetchTextMatchStyle(TextMatchStyle.SUBSTRING);
		schedulerGrid.addSelectionChangedHandler(new SelectionChangedHandler() {
			
			@Override
			public void onSelectionChanged(SelectionEvent event) {
				deActScheduleButton.setDisabled(false);
			}
		});
		
		canvasContainerLayout.addMember(schedulerGrid);
				
		bottomContainerLayout.addMember(startImmediatelyButton);
		bottomContainerLayout.addMember(actScheduleButton);
		bottomContainerLayout.addMember(deActScheduleButton);
		canvasContainerLayout.addMember(bottomContainerLayout);
		
		this.addChild(canvasContainerLayout);
	}
	
	public void showData(){
		schedulerGrid.invalidateCache();
		schedulerGrid.fetchData();
	}
	
	private VLayout createTimerForm() {

		final VLayout containerLayout = new VLayout();
    	containerLayout.setHeight100();
    	containerLayout.setWidth100();
    	containerLayout.setAlign(Alignment.CENTER);
    	containerLayout.setAlign(VerticalAlignment.TOP);  
    	containerLayout.setMembersMargin(7);

    	final HLayout topContainer = new HLayout();
    	topContainer.setHeight100();
    	topContainer.setWidth100();
    	topContainer.setAlign(Alignment.CENTER);
    	topContainer.setMembersMargin(5);

    	final HLayout buttonContainer = new HLayout();
    	buttonContainer.setHeight100();
    	buttonContainer.setWidth100();
    	buttonContainer.setAlign(Alignment.CENTER);
    	buttonContainer.setMembersMargin(5);

		final DynamicForm formTimer = new DynamicForm();
		formTimer.setNumCols(2);
		formTimer.setMargin(3);
		formTimer.setHeight100();  
		formTimer.setWidth100(); 

		formTimer.setLayoutAlign(VerticalAlignment.CENTER);  
		
		LinkedHashMap<String, String> radioValues = new LinkedHashMap<String, String>();
		radioValues.put("dailyRun","Daily run");
		radioValues.put("setUp","Market Model Setup");
		
		final RadioGroupItem calculationType = new RadioGroupItem();
		calculationType.setTitle("Calculation Type");
		calculationType.setName("type");
		calculationType.setValueMap(radioValues);
		calculationType.setRequired(true);
		
		final DateTimeItem startDateItem = new DateTimeItem();
		startDateItem.setName("startDateTime");
		startDateItem.setType("datetime");
		startDateItem.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATETIME);
		startDateItem.setRequired(true);
		startDateItem.setTitle("Start Date");
		
		// interval text item
        final TextItem intervalTextItem = new TextItem("interval");
        intervalTextItem.setRequired(true);
        intervalTextItem.setTitle("Interval");

        RegExpValidator regExpValidator = new RegExpValidator("^[0-9]*d-[0-9]*h-[0-9]*m$");
        regExpValidator.setErrorMessage("Interval value must match pattern \'Nd-Nh-Nm\'");
        intervalTextItem.setValidators(regExpValidator);
        intervalTextItem.setHint("<nobr>Nd-Nh-Nm</nobr>");
        
		formTimer.setItems(calculationType,startDateItem,intervalTextItem);
			
        final StandardButton saveRowButton = new StandardButton("Save");
        StandardButton cancelRowButton = new StandardButton("Cancel");
        
 		// Cancel row button click handler
 		cancelRowButton.addClickHandler(new ClickHandler() {
 			public void onClick(ClickEvent event) {
 				formTimer.reset();
 			}
 		});

 		// Save row button click handler
 		saveRowButton.addClickHandler(new ClickHandler() {
 			public void onClick(ClickEvent event) {
 				if (formTimer.validate()){
 					
 					/*Date startDateTime =  startDateItem.getValueAsDate();
 					long startDateTimeMillis = startDateTime.getTime();
 					*/
 					/*
 					DSRequest dsRequest = new DSRequest();
 					dsRequest.setWillHandleError(true);
 					Record record = formTimer.getValuesAsRecord();
 					
 					schedulerGrid.addData(record, new DSCallback() {
						
						@Override
						public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
							if (dsResponse.getHttpResponseCode() == Response.SC_OK){
								SC.say("Scheduler inserted", new BooleanCallback() {
									@Override
									public void execute(Boolean value) {
										createTimerWindow.destroy();
										showData();
									}
								});
							}else{
								SC.warn("Scheduler no inserted", new BooleanCallback() {
									@Override
									public void execute(Boolean value) {
										createTimerWindow.destroy();
										showData();
									}
								});
							}							
						}
					},dsRequest);*/
 					RPCRequest request = new RPCRequest();
 					request.setActionURL("servlet/endpoint/SchedulerEndpoint");
 					request.setWillHandleError(true);
 					
 					Map<String, Object> params = new HashMap<String, Object>();
 					params.put("_operationType", "add");
 					params.put("type",calculationType.getValueAsString());
 					params.put("startDateTimeMillis",startDateItem.getValueAsDate().getTime());

					String intervalString = intervalTextItem.getValueAsString();
					String[] components = intervalString.split("-");
					long daysInMillis = (long)(Long.parseLong((components[0].substring(0, components[0].length() - 1))))*24*60*60*1000;
					long hoursInMillis = (long)(Long.parseLong((components[1].substring(0, components[1].length() - 1))))*60*60*1000;
					long minutesInMillis = (long)(Long.parseLong((components[2].substring(0, components[2].length() - 1))))*60*1000;
					
					long totalMillis = daysInMillis + hoursInMillis + minutesInMillis;
					params.put("interval", totalMillis);
					
 					request.setParams(params);
 					request.setHttpMethod("POST");
 					RPCManager.sendRequest(request, new RPCCallback() {
						
						@Override
						public void execute(RPCResponse response, Object rawData, RPCRequest request) {
							if (response.getHttpResponseCode()== Response.SC_OK){
								SC.say("Scheduler inserted", new BooleanCallback() {
									@Override
									public void execute(Boolean value) {
										createTimerWindow.destroy();
										showData();
									}
								});
							}else{
								SC.warn("Scheduler no inserted", new BooleanCallback() {
									@Override
									public void execute(Boolean value) {
										createTimerWindow.destroy();
										showData();
									}
								});
							}	
						}
					});
 					
 				}else{
 					return;
 				}
 			}
 		});

        containerLayout.addMember(formTimer);
        buttonContainer.addMember(saveRowButton);
 		buttonContainer.addMember(cancelRowButton);
 		
 		containerLayout.addMember(buttonContainer);
 		
        return containerLayout;
	} 
	
	public static class Creator implements it.ccg.irweb.client.utils.Creator{
		
		public Canvas create(){
			return new SchedulersCanvas();
		}
	}
}
