package it.ccg.irweb.client.controls;

import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.widgets.IButton;

public class StandardButton extends IButton {
	
	final protected int BUTWIDTH=100; //Button width
	final protected int CTRHEIGHT=22; //Control height
	final protected int CTRMARGINS=15; //Control margins
	final protected boolean BUTSHOWDOWN=true; 
	final protected boolean BUTSHOWROLLOVER=true;

	public StandardButton(String title) {
		super(title);
		setWidth(BUTWIDTH);
		setHeight(CTRHEIGHT);
		setShowDown(BUTSHOWDOWN);
		setShowRollOver(BUTSHOWROLLOVER);
		setLayoutAlign(VerticalAlignment.CENTER);
	}
	
	public StandardButton() {
		super();
		setWidth(BUTWIDTH);
		setHeight(CTRHEIGHT);
		setShowDown(BUTSHOWDOWN);
		setShowRollOver(BUTSHOWROLLOVER);
		setLayoutAlign(VerticalAlignment.CENTER);
	}
}
