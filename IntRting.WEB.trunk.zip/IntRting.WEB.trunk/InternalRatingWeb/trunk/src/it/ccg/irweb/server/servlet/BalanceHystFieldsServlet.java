package it.ccg.irweb.server.servlet;

import it.ccg.irejb.server.bean.eao.RctVarsEAOLocal;
import it.ccg.irejb.server.bean.entity.RctVarsEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.isomorphic.rpc.RPCManager;
import com.isomorphic.rpc.RPCResponse;

/**
 * Servlet implementation class BalanceHystFieldsServlet
 */
public class BalanceHystFieldsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = LoggerFactory.getLogger(LoggerFactory.USER_LOGGER);
	
	@EJB
	private RctVarsEAOLocal rctVars;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BalanceHystFieldsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug(new StandardLogMessage("in BalanceHystFieldsServlet"));
		userLogger.info(new StandardLogMessage("in BalanceHystFieldsServlet"));
		try {
			logger.debug(new StandardLogMessage("retrieve rctVars by status"));
			List<RctVarsEntity> vars = this.rctVars.retrieveEveryRtcVar();
			logger.debug(new StandardLogMessage("rctVars retrieved"));
			List<Map<String,String>> mapVar= new ArrayList<Map<String,String>>();
			logger.debug(new StandardLogMessage(vars.size()+"variables retrieved"));
			
			logger.debug(new StandardLogMessage("convert"));
			for (RctVarsEntity var:vars){
				Map<String,String> appo = new HashMap<String,String>();
				appo.put("varId", var.getId().getVarid()+"");
				appo.put("status", var.getStatus());
				appo.put("varDesc", var.getVardesc());
				mapVar.add(appo);
			}
			logger.debug(new StandardLogMessage("send by response"));
			RPCManager rpc = null;		
			
			rpc = new RPCManager(request, response);
			
			
			RPCResponse rpcResponse = new RPCResponse();
			
			// creo un hashmap per la risposta
			HashMap<String, List<Map<String,String>>> responseParams = new HashMap<String, List<Map<String,String>>>();
		
			responseParams.put("mapVar", mapVar);
			
			rpcResponse.setData(responseParams);
			
			rpc.send(rpcResponse);
			logger.info(new StandardLogMessage("sended"));
			logger.info(new StandardLogMessage("retrun"));
			userLogger.info(new StandardLogMessage("retrun"));
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			ExceptionUtil.logCompleteStackTrace(userLogger, e);
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			ExceptionUtil.logCompleteStackTrace(userLogger, e);
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

}
