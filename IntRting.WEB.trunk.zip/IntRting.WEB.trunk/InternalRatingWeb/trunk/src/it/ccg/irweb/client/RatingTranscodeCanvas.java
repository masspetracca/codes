package it.ccg.irweb.client;

import it.ccg.irweb.client.base.StandardCanvas;
import it.ccg.irweb.client.controls.StandardButton;
import it.ccg.irweb.client.controls.StandardSelectItem;
import it.ccg.irweb.client.elements.PopupWindow;

import java.util.LinkedHashMap;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.data.SortSpecifier;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.types.OperatorId;
import com.smartgwt.client.types.RowEndEditAction;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.types.TextMatchStyle;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.PrintPreviewCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.PrintCanvas;
import com.smartgwt.client.widgets.PrintWindow;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.events.ChangeEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangeHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.events.FilterEditorSubmitEvent;
import com.smartgwt.client.widgets.grid.events.FilterEditorSubmitHandler;
import com.smartgwt.client.widgets.grid.events.SelectionChangedHandler;
import com.smartgwt.client.widgets.grid.events.SelectionEvent;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;

public class RatingTranscodeCanvas extends StandardCanvas{

	StandardButton newRatingTrans;
	StandardButton editRatingTrans;
	StandardButton deleteRatingTrans;
	private String selectedFilter="";
	DataSource trsCodeDS;
	ListGrid transCodes;
	Window newTransCodeWindow;
	Window editTransCodeWindows;
	
	public RatingTranscodeCanvas(){
		super();

		trsCodeDS = DataSource.get("rcttrscode");
		
		newRatingTrans = new StandardButton("New");
		deleteRatingTrans = new StandardButton("Delete");
		deleteRatingTrans.setDisabled(true);
		
		editRatingTrans = new StandardButton("Edit");
		editRatingTrans.setDisabled(true);
		
		ListGridField rankIdField = new ListGridField("RANKING");
		ListGridField providerField = new ListGridField("PROVIDER");
		ListGridField ratingCodeField = new ListGridField("RTGCODE");
		ratingCodeField.setTitle("Provider rating");
		ListGridField minRatingField = new ListGridField("MINRTG");
		ListGridField maxRatingField = new ListGridField("MAXRTG");
		
		filterSelect = new StandardSelectItem("Provider");
		filterSelect.setAllowEmptyValue(true);
		LinkedHashMap<String, String> filterMap = new LinkedHashMap<String, String>();
		filterMap.put("I", "Internal");
		filterMap.put("F", "Fitch");
		filterMap.put("M", "Moody's");
		filterMap.put("S", "S&P");
		filterSelect.setValueMap(filterMap);
		filterSelect.setAlign(Alignment.CENTER);
		topContainerLayout.addMember(filterSelect.inDynamicForm());
		//Change handler combo
		filterSelect.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent event) {
				selectedFilter = (String) event.getValue();
			}
		});
		
		// Show button click handler
		showButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				selectedFilter = filterSelect.getValueAsString();
				showData();
			}
		});
		
		topContainerLayout.addMember(showButton);
		//add space
		topContainerLayout.addMember(spacerLayout);
				
		refreshButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				showData();
			}
		});
		
		topContainerLayout.addMember(refreshButton);
		//
		canvasContainerLayout.addMember(topContainerLayout);
		
		transCodes = new ListGrid();
		transCodes.setWidth100();
		transCodes.setFields(providerField,ratingCodeField,minRatingField,maxRatingField,rankIdField);
		transCodes.setTitle("Rating transcode");
		transCodes.setDataSource(trsCodeDS);
		transCodes.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATE);
		transCodes.setShowFilterEditor(true);
		transCodes.setDataPageSize(40);
		transCodes.setListEndEditAction(RowEndEditAction.NEXT);
		transCodes.setAutoSaveEdits(true);
		transCodes.setAutoFetchData(true);
		transCodes.setEditEvent(ListGridEditEvent.NONE);
		transCodes.setAutoFetchTextMatchStyle(TextMatchStyle.SUBSTRING);
		transCodes.setCanGroupBy(false);
		transCodes.setCanFreezeFields(false);
		transCodes.setCanAutoFitFields(false);
		SortSpecifier rankingSpecifier = new SortSpecifier("RANKING", SortDirection.ASCENDING);
		transCodes.setInitialSort(rankingSpecifier);
		transCodes.addFilterEditorSubmitHandler(new FilterEditorSubmitHandler() {
			
			@Override
			public void onFilterEditorSubmit(FilterEditorSubmitEvent event) {
				selectedFilter = event.getCriteria().getAttributeAsString("PROVIDER");
				filterSelect.setValue(selectedFilter);
				filterSelect.redraw();
				//event.getCriteria().addCriteria("PROVIDER", selectedFilter);
			}
		});
		transCodes.addSelectionChangedHandler(new SelectionChangedHandler() {
			
			@Override
			public void onSelectionChanged(SelectionEvent event) {
				deleteRatingTrans.setDisabled(false);
				editRatingTrans.setDisabled(false);
			}
		});
		
		/*transCodes.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				transCodes.startEditing(event.getRecordNum(), event.getFieldNum(), true);
			}
		});*/
		
		transCodes.setWidth100();
		canvasContainerLayout.addMember(transCodes);
		
		//AGGIUNGO AZIONI AI BOTTONI
		newRatingTrans.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				newTransCodeWindow = PopupWindow.getInstance("New transcode", 600, 300);
				newTransCodeWindow.addCloseClickHandler(new CloseClickHandler() {
					@Override
					public void onCloseClick(CloseClickEvent event) {
						transCodes.fetchData();
					}
				});
				
				newTransCodeWindow.addMember(createNewTransCodeForm());
				newTransCodeWindow.draw();
			}
		});
		
		deleteRatingTrans.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if(transCodes.getSelectedRecord()== null){
					SC.say("No record selected");
					return;
				}else{
					transCodes.removeSelectedData();
					SC.warn("Record deleted");
				}
			}
		});	

		editRatingTrans.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if(transCodes.getSelectedRecord()== null){
					SC.say("No record selected");
					return;
				}else{
					editTransCodeWindows = PopupWindow.getInstance("Edit transcode", 600, 300);
					editTransCodeWindows.addCloseClickHandler(new CloseClickHandler() {
						@Override
						public void onCloseClick(CloseClickEvent event) {
							transCodes.fetchData();
						}
					});
					editTransCodeWindows.addMember(createEditTransCodeForm());
					editTransCodeWindows.draw();
				}
			}
		});
		
		exportData.addClickHandler(new ClickHandler() {	
			@Override
			public void onClick(ClickEvent event) {
				DSRequest request = new DSRequest();
				request.setExportFilename("Rating transcodes");
				request.setExportToClient(true);
				transCodes.exportData(request);
			}
		});
		
		printData.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				//Layout[] printLayout = new VLayout[]{canvasContainerLayout};
				
				Img logoImg = new Img("CCGlogo.gif", 255, 51);  	
				Label label = new Label();  
		        label.setHeight(30);  
		        label.setPadding(10); 
		        label.setContents("<b>Rating transcode</b>");
		        label.setAlign(Alignment.CENTER);  
		        label.setValign(VerticalAlignment.CENTER); 
		        
		        LayoutSpacer spacer = new LayoutSpacer();
		        spacer.setWidth(10); 
		        
				Canvas.showPrintPreview(new Object[] {logoImg,label,spacer,transCodes}, null, "Rating transcode", new PrintPreviewCallback() {
					
					@Override
					public void execute(PrintCanvas printCanvas, PrintWindow printWindow) {
												
					}
				});
				
			}
		});
		
		bottomContainerLayout.addMember(newRatingTrans);
		bottomContainerLayout.addMember(deleteRatingTrans);
		bottomContainerLayout.addMember(editRatingTrans);
		bottomContainerLayout.addMember(exportData);
		bottomContainerLayout.addMember(printData);
		
		canvasContainerLayout.addMember(bottomContainerLayout);
		
		this.addChild(canvasContainerLayout);
	}
	
	private VLayout createNewTransCodeForm() {
		
		VLayout containerLayout = new VLayout();
    	containerLayout.setHeight100();
    	containerLayout.setWidth100();
    	containerLayout.setAlign(Alignment.CENTER);
    	containerLayout.setMembersMargin(7);

    	HLayout buttonContainer = new HLayout();
    	buttonContainer.setHeight("20%");
    	buttonContainer.setWidth100();
    	buttonContainer.setAlign(Alignment.CENTER);
    	buttonContainer.setMembersMargin(5);
    	
		final DynamicForm form = new DynamicForm();
        form.setMargin(5);
        form.setHeight("80%");  
        form.setWidth100();  

        form.setLayoutAlign(VerticalAlignment.CENTER);  

        form.setNumCols(4);
        form.setHeight100();
        form.setDataSource(trsCodeDS);
        form.setShowDetailFields(true);
        form.getField("UPDDATE").setVisible(false);
        form.getField("UPDTYPE").setVisible(false);
        form.getField("UPDUSR").setVisible(false);
 
        final StandardButton saveRowButton = new StandardButton("Save");
        StandardButton cancelRowButton = new StandardButton("Cancel");
        
 		// Cancel row button click handler
 		cancelRowButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
 			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
 				form.clearValues();
 				saveRowButton.disable();
 			}
 		});

 		// Save row button click handler
 		saveRowButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
 			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
 				if (form.validate()){
 					AdvancedCriteria aC = new AdvancedCriteria();
 					aC.addCriteria("RTGCODE", OperatorId.EQUALS,((String)form.getField("RTGCODE").getValue()));
 					aC.addCriteria("PROVIDER",OperatorId.EQUALS, ((String)form.getField("PROVIDER").getValue()));
 					DataSource appoDs = transCodes.getDataSource();
 					appoDs.fetchData(aC, new DSCallback() {
						
						@Override
						public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
							Record[] result = dsResponse.getData();
							if(result.length>0){
								SC.warn("Already exsists data with this attributes");
								return;
							}else{
								form.getField("RTGCODE").setValue(((String)form.getField("RTGCODE").getValue()));
								transCodes.addData(form.getValuesAsRecord());
				 				transCodes.fetchData();
				 				form.reset();
				 				newTransCodeWindow.destroy();
							}
						}
					});
 				}else{
 					return;
 				}
 			}
 		});
        
        buttonContainer.addMember(saveRowButton);
        buttonContainer.addMember(cancelRowButton);
        
        containerLayout.addMember(form);
        containerLayout.addMember(buttonContainer);
        
        return containerLayout;
	}
	
	private VLayout createEditTransCodeForm() {
		
		VLayout containerLayout = new VLayout();
    	containerLayout.setHeight100();
    	containerLayout.setWidth100();
    	containerLayout.setAlign(Alignment.CENTER);
    	containerLayout.setMembersMargin(7);

    	HLayout buttonContainer = new HLayout();
    	buttonContainer.setHeight("20%");
    	buttonContainer.setWidth100();
    	buttonContainer.setAlign(Alignment.CENTER);
    	buttonContainer.setMembersMargin(5);
    	
		final DynamicForm form = new DynamicForm();
        form.setMargin(5);
        form.setHeight("80%");  
        form.setWidth100();  

        form.setLayoutAlign(VerticalAlignment.CENTER);  
        form.setNumCols(4);
        form.setHeight100();
        form.setDataSource(trsCodeDS);
        form.setShowDetailFields(true);
        form.getField("UPDDATE").setVisible(false);
        form.getField("RANKING").setCanEdit(false);
        form.getField("PROVIDER").setCanEdit(false);
        form.getField("UPDTYPE").setVisible(false);
        form.getField("UPDUSR").setVisible(false);
        form.editSelectedData(transCodes);
        
        final StandardButton saveRowButton = new StandardButton("Save");
        StandardButton cancelRowButton = new StandardButton("Cancel");
        
 		// Cancel row button click handler
 		cancelRowButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
 			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
 				form.clearValues();
 				
 			}
 		});

 		// Save row button click handler
 		saveRowButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
 			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
 				if (form.validate()){
 					AdvancedCriteria aC = new AdvancedCriteria();
 					aC.addCriteria("RTGCODE", OperatorId.EQUALS, ((String)form.getField("RTGCODE").getValue()).toUpperCase());
 					aC.addCriteria("PROVIDER", OperatorId.EQUALS, ((String)form.getField("PROVIDER").getValue()).toUpperCase());
 					aC.addCriteria("RANKING", OperatorId.NOT_EQUAL , form.getField("RANKING").getValue()+"");
 					DataSource appoDs = transCodes.getDataSource();
 					
 					appoDs.fetchData(aC, new DSCallback() {
 						
						@Override
						public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
							Record[] result = dsResponse.getData();
							if(result.length>0){
								SC.warn("Already exsists data with this attributes");
								return;
							}else{
								form.getField("RTGCODE").setValue(((String)form.getField("RTGCODE").getValue()).toUpperCase());
				 				transCodes.updateData(form.getValuesAsRecord());
				 				transCodes.fetchData();
				 				form.reset();
				 				editTransCodeWindows.destroy();
							}
 						}
					});
 					
 				}else{
 					return;
 				}
 			}
 		});
        
        buttonContainer.addMember(saveRowButton);
        buttonContainer.addMember(cancelRowButton);
        
        containerLayout.addMember(form);
        containerLayout.addMember(buttonContainer);
        
        return containerLayout;
	}
	
	public void showData(){
		if (selectedFilter != null && !selectedFilter.equalsIgnoreCase("")) {
			Criteria crit = new Criteria();
			crit.addCriteria("PROVIDER", selectedFilter);
			transCodes.invalidateCache();
			transCodes.fetchData(crit);
		} else {
			Criteria crit = new Criteria();
			crit.addCriteria("PROVIDER", "");
			transCodes.invalidateCache();
			transCodes.fetchData(crit);
		}
	}
	
	public static class Creator implements it.ccg.irweb.client.utils.Creator{
		
		private RatingTranscodeCanvas transCodeCanvas;
		
		public Canvas create(){
			if (this.transCodeCanvas==null){
				transCodeCanvas = new RatingTranscodeCanvas();
			}				
			return transCodeCanvas;
		}
	}
}
