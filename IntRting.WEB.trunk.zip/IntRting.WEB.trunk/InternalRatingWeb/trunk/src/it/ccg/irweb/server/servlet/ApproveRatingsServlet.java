package it.ccg.irweb.server.servlet;

import it.ccg.irejb.server.bean.ApproveRatingsLocal;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.io.IOException;

import javax.ejb.EJB;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class ApproveRatingsServlet
 */
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class ApproveRatingsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = LoggerFactory.getLogger(LoggerFactory.USER_LOGGER);
	
	@EJB
	private ApproveRatingsLocal approveRatings;
	
	/*@EJB
	private RctRatingEAOLocal rctRating;
	
	@EJB
	private RctRiskComEAOLocal rctRiskCom;*/
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApproveRatingsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug(new StandardLogMessage("in ApproveRatingsServlet"));
		userLogger.info(new StandardLogMessage("in ApproveRatingsServlet"));
		
		try {
			
			approveRatings.approve(request.getParameter("RCCODE"), request.getUserPrincipal().getName());
			
			//TODO aggiunto requires new
			/*List<RctRatingEntity> ratings= rctRating.retrieveRatingsByStatus("S");
			
			RctRiskComEntity comm = rctRiskCom.retrieveRiskCommitteeById(request.getParameter("RCCODE"));
			//List<RctRatingHEntity> ratingsHist = new ArrayList<RctRatingHEntity>();
			
			for (RctRatingEntity rat : ratings){
				RctRatingHEntity hist = new RctRatingHEntity();
				RctRatingHEntityPK pkHist = new RctRatingHEntityPK();
				logger.debug(new StandardLogMessage("coping pk from rat to hist"));
				//BeanUtils.copyProperties(pkHist, rat.getId());
				pkHist.setBankid(rat.getBankid());
				pkHist.setRatingdate(rat.getRatingdate());
				pkHist.setApprdate(new Timestamp(new Date().getTime()));
				hist.setId(pkHist);
				logger.debug(new StandardLogMessage("coping rat to hist"));
				//BeanUtils.copyProperties(hist, rat);
				//PropertyUtils.copyProperties(hist, rat);
				hist.copyRatingData(rat);
				logger.debug(new StandardLogMessage("setting approved data"));
				hist.setApprovedby(request.getUserPrincipal().getName());
				hist.setApprrtg(rat.getProprtg());
				hist.setRctriskcom(comm);
				
				logger.debug(new StandardLogMessage("setting upd data"));
				hist.setUpdusr(request.getUserPrincipal().getName());
				hist.setUpddate(new Timestamp(new Date().getTime()));
				hist.setUpdtype("C");
				logger.debug(new StandardLogMessage("inserting history"));
				userLogger.info(new StandardLogMessage("Inserting history"));
				rctRatingH.insertRatingHistory(hist);
				logger.debug(new StandardLogMessage("deleting rating"));
				userLogger.info(new StandardLogMessage("deleting rating"));
				rctRating.deleteRctRating(rat);
			}*/
			
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			ExceptionUtil.logCompleteStackTrace(userLogger, e);
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}
		
	}

}
