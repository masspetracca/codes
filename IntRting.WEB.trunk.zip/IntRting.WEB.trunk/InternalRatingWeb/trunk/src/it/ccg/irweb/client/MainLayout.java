package it.ccg.irweb.client;


import it.ccg.irweb.client.rpc.PostRPCRequest;

import java.util.HashMap;
import java.util.Map;

import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONValue;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.tab.TabSet;


public class MainLayout extends VLayout {
	
	private static MainLayout mainLayout; //	mainLayout
	private HLayout tabSetHLayout = new HLayout(); //		tabSetHLayout
	private HLayout headerHLayout = new HLayout();
	
	private Label envLabel;
	
	public static MainLayout createInstance() {
		
		mainLayout = new MainLayout();
		
		return mainLayout;
	}
	
	public MainLayout() {
		super();
		
		this.setWidth("99%");
		this.setHeight("99%");
		
		
		// header -----------------------------------------------------------------------
		
		this.headerHLayout.setHeight("10%");
		this.headerHLayout.setWidth100();
		this.headerHLayout.setLayoutTopMargin(new Integer(5));
		//this.headerHLayout.setShowResizeBar(true);
		this.headerHLayout.setAlign(VerticalAlignment.CENTER);
		
		// logo  
		Img logoImg = new Img("CCGlogo.gif", 255, 51);  	
		this.headerHLayout.addMember(logoImg, 0);
		
		//env
		Map<String,String> params = new HashMap<String, String>();
		params.put("_operationId", "getEnviroment");
		
		RPCRequest request = new PostRPCRequest("servlet/system/SystemInfo", params);
		RPCManager.sendRequest(request, new RPCCallback() {
			
			@Override
			public void execute(RPCResponse response, Object rawData, RPCRequest request) {
				
				String responseBody = response.getAttributeAsString("httpResponseText");
				JSONValue jsonValue = JSONParser.parseStrict(responseBody);
				JSONObject jsonObject = jsonValue.isObject();
				
				String env = jsonObject.get("environment").isString().stringValue();
				envLabel = new Label("<font color=\"005596\"><nobr> <b>" + env + " enviroment</b><nobr></font>");
				
				headerHLayout.addMember(envLabel, 1);
			}
		});
		
		
		
		// white space
		LayoutSpacer layoutSpacer = new LayoutSpacer();
		layoutSpacer.setHeight("10%");
		layoutSpacer.setWidth100();
		this.headerHLayout.addMember(layoutSpacer, 2);
		
		// user info
		this.headerHLayout.addMember(new HeaderUserSection(), 3);
		
		// header -------------------------------------------------------------------
		
		
		
		// tab set ----------------------------------------------------------------------
		TabSet tabSet = new TabSet(); 
			
		//        
        this.tabSetHLayout.addMember(tabSet);
        this.tabSetHLayout.setLayoutTopMargin(20);
        // tab set ----------------------------------------------------------------------
        
        this.addMember(this.headerHLayout);
		this.addMember(this.tabSetHLayout);
		
		this.setLeft("8");
		this.setTop("3");
		
		// ***************************************************************************
		
		
		
		//
		this.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(Window.getById("_AccountWindow") != null) {
					
					mainLayout.removeChild(Window.getById("_AccountWindow"));
					
					Window.getById("_AccountWindow").destroy();
				}
				
			}
		});
	}

	

	public static MainLayout getMainLayout() {
		return mainLayout;
	}
	
	
	
}

