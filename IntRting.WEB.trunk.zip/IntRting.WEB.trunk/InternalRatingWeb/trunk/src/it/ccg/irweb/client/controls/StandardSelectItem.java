package it.ccg.irweb.client.controls;

import com.smartgwt.client.types.TextMatchStyle;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.SelectItem;

public class StandardSelectItem extends SelectItem {

private DynamicForm dynamicForm;
	
	/**Standard Combobox for PAMP project
	 * @param title: Label of the control
	 */
	public StandardSelectItem(String title) {
		super();
		this.setTitle("<nobr>"+title+"</nobr>");
		this.setTextMatchStyle(TextMatchStyle.SUBSTRING);
		this.setWidth(200);
		this.setAutoFetchData(true);
	}
	/**
	 * @return Return a dynamicForm containing the ComboBox
	 */
	public DynamicForm inDynamicForm(){
		DynamicForm df=new DynamicForm();
		setDynamicForm(df);
		df.setItems(this);
		return(df);
	}
	
	public DynamicForm getDynamicForm() {
		return dynamicForm;
	}
	public void setDynamicForm(DynamicForm dynamicForm) {
		this.dynamicForm = dynamicForm;
	}
}
