package it.ccg.irweb.client.elements;

import it.ccg.irweb.client.utils.Creator;

import com.smartgwt.client.widgets.tree.TreeNode;

public class InternalRatingTreeNode extends TreeNode {

	private Creator treeNodeCreator;
	
	public InternalRatingTreeNode(String Id,String parentId, String name, Creator creatore){
		this.setAttribute("id", Id);
		this.setAttribute("parentId", parentId);
		this.setAttribute("name", name);
		
		if (parentId.equalsIgnoreCase("root")){
			this.setAttribute("isOpen", true);
		}else{
			this.setAttribute("isOpen", false);
		}
		
		if (creatore == null){
			this.setAttribute("enabled", false);
		}else{
			this.treeNodeCreator = creatore;
		}
	}
	
	public String getId(){
		return this.getAttribute("id");
	}
	
	public String getParentId(){
		return this.getAttribute("parentId");
	}
	
	public String getName(){
		return this.getAttribute("name");
	}
	
	public Creator getCreator(){
		return this.treeNodeCreator;
	}
}
