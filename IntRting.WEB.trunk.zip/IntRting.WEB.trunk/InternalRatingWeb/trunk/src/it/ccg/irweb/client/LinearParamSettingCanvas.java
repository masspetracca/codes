package it.ccg.irweb.client;

import it.ccg.irweb.client.base.StandardCanvas;
import it.ccg.irweb.client.controls.StandardButton;

import java.util.HashMap;
import java.util.Map;

import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.SpinnerItem;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;

public class LinearParamSettingCanvas extends StandardCanvas {

	DynamicForm marketForm;
	DynamicForm financialForm;
	
	private double slopeMarketValue;
	private double offsetMarketValue;
	private double constantFinancialValue;
	private double slopeFinancialValue;
	private double offsetFinalcialValue;
	
	public LinearParamSettingCanvas(){
		super();

		RPCRequest request = new RPCRequest();
		request.setActionURL("servlet/endpoint/LinearParameterSettingEndpoint");
		request.setHttpMethod("POST");
		Map<String,String> params = new HashMap<String,String>();
		params.put("_operationType", "fetch");
		
		LayoutSpacer lS = new LayoutSpacer();
		lS.setHeight(30);
		
		request.setParams(params);

		marketForm = new DynamicForm();
		marketForm.setGroupTitle("<b>Market model parameters</b>");
		marketForm.setIsGroup(true);
		marketForm.setNumCols(2);
		marketForm.setHeight(80);  
		marketForm.setWidth(300); 
		marketForm.setColWidths(60, "*");  
		marketForm.setPadding(5);  
        
		financialForm = new DynamicForm();
		financialForm.setGroupTitle("<b>Financial model parameters</b>");
		financialForm.setIsGroup(true);
		financialForm.setNumCols(2);
		financialForm.setColWidths(60, "*");  
		financialForm.setHeight(90);  
		financialForm.setWidth(300);
		financialForm.setPadding(5);
			
		//
		canvasContainerLayout.addMember(topContainerLayout);
		
		final StandardButton unlockMarketButton = new StandardButton("Unlock");
		unlockMarketButton.setPrompt("Unlock market parameters");
		
		final StandardButton saveMarketButton = new StandardButton("Save");
		saveMarketButton.setPrompt("Save market parameters");
		saveMarketButton.setVisible(false);
				
		final StandardButton cancelMarketButton = new StandardButton("Cancel");
		cancelMarketButton.setPrompt("Reset market parameters");
		cancelMarketButton.setDisabled(true);
		
		final SpinnerItem slopeMarketSpinner = new SpinnerItem("slopeMarket");
		slopeMarketSpinner.setTitle("Slope");
		slopeMarketSpinner.setValue(this.slopeMarketValue);
		slopeMarketSpinner.setRequired(true);
		slopeMarketSpinner.setStep(0.01);
		slopeMarketSpinner.setCanEdit(false);
		
		final SpinnerItem offsetMarketSpinner = new SpinnerItem("offsetMarket");
		offsetMarketSpinner.setTitle("Offset");
		offsetMarketSpinner.setValue(this.offsetMarketValue);
		offsetMarketSpinner.setRequired(true);
		offsetMarketSpinner.setStep(0.01);
		offsetMarketSpinner.setCanEdit(false);
		
		cancelMarketButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				RPCRequest request = new RPCRequest();
				request.setActionURL("servlet/endpoint/LinearParameterSettingEndpoint");
				request.setHttpMethod("POST");
				request.setWillHandleError(true);
				
				Map<String,String> params = new HashMap<String,String>();
				params.put("_operationType", "fetch");
				
				request.setParams(params);
				
				RPCManager.sendRequest(request, new RPCCallback() {
					public void execute(RPCResponse response, Object rawData, RPCRequest request) {
						
						HashMap<String, Float> respMap = (HashMap<String, Float>) response.getDataAsMap();

						slopeMarketSpinner.setValue(respMap.get("slopeMarket"));
						offsetMarketSpinner.setValue(respMap.get("offsetMarket"));
						slopeMarketSpinner.setCanEdit(false);
						offsetMarketSpinner.setCanEdit(false);

						unlockMarketButton.setVisible(true);
						saveMarketButton.setVisible(false);
						cancelMarketButton.setDisabled(true);
						
						reload();
					}
				});
			}
			
		});
		
		unlockMarketButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				slopeMarketSpinner.setCanEdit(true);
				offsetMarketSpinner.setCanEdit(true);
				
				unlockMarketButton.setVisible(false);
				saveMarketButton.setVisible(true);
				cancelMarketButton.setDisabled(false);
				
			}
		});

		saveMarketButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				SC.say(slopeMarketSpinner.getValueAsString()+" "+offsetMarketSpinner.getValueAsString(), new BooleanCallback() {
					
					@Override
					public void execute(Boolean value) {
						return;
						
					}
				});
				
				RPCRequest request = new RPCRequest();
				request.setActionURL("servlet/endpoint/LinearParameterSettingEndpoint");
				request.setHttpMethod("POST");
				request.setWillHandleError(true);
				
				Map<String,String> params = new HashMap<String,String>();
				params.put("_operationType", "add");
				params.put("slopeMarketStringValue",slopeMarketSpinner.getValueAsString());
				params.put("offsetMarketStringValue",offsetMarketSpinner.getValueAsString());
				params.put("buttonName","saveMarketButton");
				
				request.setParams(params);
				RPCManager.sendRequest(request, new RPCCallback() {
					
					@Override
					public void execute(RPCResponse response, Object rawData, RPCRequest request) {
						if (response.getStatus() == RPCResponse.STATUS_SUCCESS){
							slopeMarketSpinner.setCanEdit(false);
							offsetMarketSpinner.setCanEdit(false);

							unlockMarketButton.setVisible(true);
							saveMarketButton.setVisible(false);
							cancelMarketButton.setDisabled(true);
							SC.say("Parameters saved");
						}else{
							SC.warn("Error occurred");
						}
						
					}
				});
			}
		});
		
		final SpinnerItem slopeFinancialSpinner = new SpinnerItem("slopeFinalcial");
		slopeFinancialSpinner.setTitle("Slope");
		slopeFinancialSpinner.setValue(this.slopeFinancialValue);
		slopeFinancialSpinner.setRequired(true);
		slopeFinancialSpinner.setStep(0.01);
		slopeFinancialSpinner.setCanEdit(false);
		
		final SpinnerItem offsetFinalcialSpinner = new SpinnerItem("offsetFinalcial");
		offsetFinalcialSpinner.setTitle("Offset");
		offsetFinalcialSpinner.setValue(this.offsetFinalcialValue);
		offsetFinalcialSpinner.setRequired(true);
		offsetFinalcialSpinner.setStep(0.01);
		offsetFinalcialSpinner.setCanEdit(false);
		
		final SpinnerItem constantFinalcialSpinner = new SpinnerItem("constantFinancial");
		constantFinalcialSpinner.setTitle("Constant");
		constantFinalcialSpinner.setValue(this.constantFinancialValue);
		constantFinalcialSpinner.setRequired(true);
		constantFinalcialSpinner.setStep(0.01);
		constantFinalcialSpinner.setCanEdit(false);
		
		RPCManager.sendRequest(request, new RPCCallback() {
			public void execute(RPCResponse response, Object rawData, RPCRequest request) {
				
				HashMap<String, Float> respMap = (HashMap<String, Float>) response.getDataAsMap();

				slopeMarketSpinner.setValue(respMap.get("slopeMarket"));
				offsetMarketSpinner.setValue(respMap.get("offsetMarket"));
				slopeFinancialSpinner.setValue(respMap.get("slopeFinancial"));
				offsetFinalcialSpinner.setValue(respMap.get("offsetFinancial"));
				constantFinalcialSpinner.setValue(respMap.get("constantFinancial"));
				reload();
			}
		});
				
		
		marketForm.setFields(slopeMarketSpinner,offsetMarketSpinner);
		//canvasContainerLayout.addMember(linearLabel);
		
		canvasContainerLayout.addMember(marketForm);
		
		HLayout marketButtonContainer = new HLayout();
		marketButtonContainer.setMembersMargin(3);
		marketButtonContainer.setHeight(30);
		marketButtonContainer.addMember(saveMarketButton);
		marketButtonContainer.addMember(unlockMarketButton);
		marketButtonContainer.addMember(cancelMarketButton);
		marketButtonContainer.setAlign(Alignment.LEFT);
		
		canvasContainerLayout.addMember(marketButtonContainer);	
		
		canvasContainerLayout.addMember(lS);
		
		final StandardButton saveFinancialButton = new StandardButton("Save");
		saveFinancialButton.setPrompt("Save financial parameters");
		saveFinancialButton.setVisible(false);
		
		final StandardButton cancelFinancialButton = new StandardButton("Cancel");
		cancelFinancialButton.setPrompt("Reset financial parameters");
		cancelFinancialButton.setDisabled(true);
		
		final StandardButton unlockFinancialButton = new StandardButton("Unlock");
		unlockFinancialButton.setPrompt("Unlock financial parameters");
		unlockFinancialButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				slopeFinancialSpinner.setCanEdit(true);
				offsetFinalcialSpinner.setCanEdit(true);
				constantFinalcialSpinner.setCanEdit(true);
				
				unlockFinancialButton.setVisible(false);
				saveFinancialButton.setVisible(true);
				cancelFinancialButton.setDisabled(false);
				
			}
		});
		
		saveFinancialButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				RPCRequest request = new RPCRequest();
				request.setActionURL("servlet/endpoint/LinearParameterSettingEndpoint");
				request.setHttpMethod("POST");
				request.setWillHandleError(true);
				
				Map<String,String> params = new HashMap<String,String>();
				params.put("_operationType", "add");
				params.put("slopeFinancialStringValue",slopeFinancialSpinner.getValueAsString());
				params.put("offsetFinalcialStringValue",offsetFinalcialSpinner.getValueAsString());
				params.put("constantFinancial",constantFinalcialSpinner.getValueAsString());
				params.put("buttonName","saveFinancialButton");
				
				request.setParams(params);
				RPCManager.sendRequest(request, new RPCCallback() {
					
					@Override
					public void execute(RPCResponse response, Object rawData, RPCRequest request) {
						if (response.getStatus() == RPCResponse.STATUS_SUCCESS){
							slopeFinancialSpinner.setCanEdit(false);
							offsetFinalcialSpinner.setCanEdit(false);
							constantFinalcialSpinner.setCanEdit(false);
							
							unlockFinancialButton.setVisible(true);
							saveFinancialButton.setVisible(false);
							cancelFinancialButton.setDisabled(true);
							SC.say("Parameters saved");
						}else{
							SC.warn("Error occurred");
						}
						
					}
				});
			}
			
		});
		
		
		cancelFinancialButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				RPCRequest request = new RPCRequest();
				request.setActionURL("servlet/endpoint/LinearParameterSettingEndpoint");
				request.setHttpMethod("POST");
				request.setWillHandleError(true);
				
				Map<String,String> params = new HashMap<String,String>();
				params.put("_operationType", "fetch");
				
				request.setParams(params);
				
				RPCManager.sendRequest(request, new RPCCallback() {
					public void execute(RPCResponse response, Object rawData, RPCRequest request) {
						
						HashMap<String, Float> respMap = (HashMap<String, Float>) response.getDataAsMap();

						slopeFinancialSpinner.setValue(respMap.get("slopeFinancial"));
						offsetFinalcialSpinner.setValue(respMap.get("offsetFinancial"));
						constantFinalcialSpinner.setValue(respMap.get("constantFinancial"));
						slopeFinancialSpinner.setCanEdit(false);
						offsetFinalcialSpinner.setCanEdit(false);
						constantFinalcialSpinner.setCanEdit(false);
						
						unlockFinancialButton.setVisible(true);
						saveFinancialButton.setVisible(false);
						cancelFinancialButton.setDisabled(true);
						reload();
					}
				});
			}
			
		});

		financialForm.setFields(slopeFinancialSpinner,offsetFinalcialSpinner,constantFinalcialSpinner);
		Label financialParamLabel = new Label();
		financialParamLabel.setContents("Financial model linear regertion parameters");
		financialParamLabel.setAlign(Alignment.LEFT);
		
		//canvasContainerLayout.addMember(financialParamLabel);
		canvasContainerLayout.addMember(financialForm);
		
		HLayout financiaButtonContainer = new HLayout();
		financiaButtonContainer.setMembersMargin(3);
		financiaButtonContainer.setHeight(30);
		financiaButtonContainer.addMember(saveFinancialButton);
		financiaButtonContainer.addMember(unlockFinancialButton);
		financiaButtonContainer.addMember(cancelFinancialButton);
		financiaButtonContainer.setAlign(Alignment.LEFT);
		
		canvasContainerLayout.addMember(financiaButtonContainer);
		//canvasContainerLayout.addMember(bottomContainerLayout);

		
		
		this.addChild(canvasContainerLayout);
	}
	
	public void reload(){
		this.canvasContainerLayout.redraw();
		this.marketForm.redraw();
		this.financialForm.redraw();
		this.redraw();
	}
	
	public static class Creator implements it.ccg.irweb.client.utils.Creator{
		
		public Canvas create(){
			return new LinearParamSettingCanvas();
		}
	}
}
