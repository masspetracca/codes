package it.ccg.irweb.client.utils;

public class Regex {

		public static final String REGEX_VALIDATOR_ADV = "^[a-zA-Z0-9]+( *\\-*[a-zA-Z0-9\u00C0-\u00F6\u00F8-\u00FF]*)*$";
		public static final String REGEX_BASE_VALIDATOR = "^[a-zA-Z0-9]+( *\\-*[a-zA-Z0-9]*)*$";
		public static final String REGEX_EMAIL_VALIDATOR = "^([a-zA-Z0-9_.\\-+])+@(([a-zA-Z0-9\\-])+\\.)+[a-zA-Z0-9]{2,4}$";
		public static final String REGEX_PWD_VALIDATOR = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@_$%\\-&\\/])[^<>]{10,20}$";
		public static final String REGEX_PWD_BASE = "^[a-zA-Z0-9]+( *\\-*[a-zA-Z0-9]*[@_$%\\-&\\/\\!])*$$";
		
}
