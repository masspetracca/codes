package it.ccg.irweb.server.servlet.system;


import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.system.SystemProperties;
import it.ccg.irejb.server.util.ExceptionUtil;
/*import it.ccg.irweb.server.ldap.LDAPManager;
import it.ccg.irweb.server.ldap.LDAPUserDTO;*/

import java.io.IOException;
import java.io.PrintWriter;
import java.security.Principal;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
//import org.json.simple.JSONObject;


public class UserInfo extends HttpServlet {
	/*private static final long serialVersionUID = 1L;
	
	private static Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	
	private static String[] availableRoles = null;
	
	private PrintWriter outStream = null;
		
	
	*//**
     * @see HttpServlet#HttpServlet()
     *//*
    public UserInfo() {
        super();
    }
    
    
	
	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			availableRoles = SystemProperties.getSystemProperty("security.roles").split(",");
			
			Principal principal = request.getUserPrincipal();
			
			String cn = null;
			String rolesString = new String();
			
			// principal == null se ho disabilitato la sicurezza --> sono in modalit� sviluppo
			if(principal == null) {
				
				cn = "DEVELOPER";
				rolesString = "admin";
			}
			else {
				
				LDAPManager ldapManager = new LDAPManager();
				LDAPUserDTO ldapUserDTO = ldapManager.getUserByUID(principal.getName());
				
				cn = ldapUserDTO.getCn();
				
				for(String role : availableRoles) {
					if(request.isUserInRole(role)) {
						
						rolesString += role + "|";
					}
				}
				if(rolesString.length() > 0) {
					
					rolesString = rolesString.substring(0, rolesString.length() - 1);
				}
			}
			
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("cn", cn);
			jsonObject.put("roles", rolesString);
			
			String jsonString = "";//jsonObject.toJSONString();
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
			
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
	}
*/
}
