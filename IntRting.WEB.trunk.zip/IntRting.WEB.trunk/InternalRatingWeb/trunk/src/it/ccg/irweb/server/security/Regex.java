package it.ccg.irweb.server.security;

public class Regex {

	public static final String REG_EXP_ADV_VALIDATOR = "^[a-zA-Z0-9]+( *[a-zA-Z0-9\u00C0-\u00F6\u00F8-\u00FF]*)*$";
	public static final String REG_EXP_BASE_VALIDATOR = "^[a-zA-Z0-9]+( *[a-zA-Z0-9]*)*$";
	public static final String REG_EXP_EMAIL_VALIDATOR = "^([a-zA-Z0-9_.\\-+])+@(([a-zA-Z0-9\\-])+\\.)+[a-zA-Z0-9]{2,4}$";
	public static final String REG_EXP_PWD_VALIDATOR = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@_$%\\-&\\/])[^<>]{10,20}$";
	public static final String REG_EXP_DESC_VALIDATOR = "^[a-zA-Z0-9������������ \\t\\n\\x0B\\f\\r \\.\\;\\:\\=\\{\\}\\(\\)\\+\\-\\,\\'\\_]*$";
	public static final String REG_EXP_PHONE_NUM_VALIDATOR = "^[0-9\\.\\+]+";
	public static final String REG_EXP_LOG_VIEW_VALIDATOR = "^([0-1][0-9]|[2][0-3]):([0-5][0-9])$";
		
}
