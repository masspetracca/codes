import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class RootXsl {
public static void main(String[] args) throws Exception {
    String xmlFile = "root.xml";
    Scanner scanner = new Scanner(new File(xmlFile)).useDelimiter("\\Z");
    String xmlContent = scanner.next();
    xmlContent = xmlContent.trim().replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll("\n", "<br />").replaceAll(" ", "&nbsp;");
    PrintWriter out = new PrintWriter(xmlFile+".html");
    out.println("<html><body>" + xmlContent + "</body></html>");
    scanner.close();
    out.close();
	}
}