package it.ccg.test.collaudo.server.bus;



import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PopulateDb {
	
	//Table access keys
	private static String kDate = ""; 

	private static String Tab_col0 = "DATEID";
	private static String Tab_col1 = "CLASSNAME";
	private static String Tab_col2 = "PROG";
	private static String Tab_col3 = "BOOL";

	private static String TableName = PropertyFiles.getTabName1();

	private static String vcol3 = "";
	private static String vcol4 = "";
	private static String vcol5 = "";

	private static String sdate =null;
	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

//	private static String tabFreq ="";
	private int ctrIns;
//	private int ctrUpd;
 	private int returnCode = 0;
 	private static String sqlUpdate;
//	
//
//	private static Object rs;
	
	PreparedStatement st;
	private String sqlDelete;
	private int ctrDel;

	String className;
	int prog;
	String bool;

	public PopulateDb(String keyDate, String className, int prog, String bool) throws ClassNotFoundException, IOException, SQLException, IllegalAccessException, InstantiationException {
		
		
		//upate table
		       sqlUpdate= 
				"INSERT INTO "+TableName
				+"("
				+""+Tab_col0
				+", "+Tab_col1
				+", "+Tab_col2
				+", "+Tab_col3
				+") VALUES ("
				+"'"+keyDate+"'" 				
				+", '"+className+"'" 
				+", '"+prog+"'" 
				+", '"+bool+"'" 
				+")"
				;

	    System.out.println(sqlUpdate);		
		++ctrIns;
		//setting upd parameters
		TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 
		upd.setSqlUpdate(sqlUpdate);	
}




	



}


	
		
							
   

