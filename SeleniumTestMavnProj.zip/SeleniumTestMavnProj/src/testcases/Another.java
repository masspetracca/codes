package testcases;

import org.testng.annotations.Test;

public class Another {
	
	@Test
	public void secondTest() {
		
		System.out.println("Executing second Test");
	}

}
