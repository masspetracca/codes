package testcases;

import org.testng.annotations.Test;

public class Login {
	
	@Test
	public void thirdTest() {
		
		System.out.println("Executing the Third Test");
	}

}
