package testcases;

import org.testng.annotations.Test;

public class UserReg {
	
	@Test
	public void firstTest() {
		
		System.out.println("Executing First Test");
	}

}
