package com.jwt.ejb.business;

import javax.ejb.Stateless;

@Stateless
public class HelloBean implements Hello {

	public HelloBean() {
		 
    }
	
	@Override
	public String sayHello() {
		// TODO Auto-generated method stub
		return "Hello: Welcome Welcome to EJB";
	}

}
