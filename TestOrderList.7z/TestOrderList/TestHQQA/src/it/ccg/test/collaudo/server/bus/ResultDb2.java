package it.ccg.test.collaudo.server.bus;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class ResultDb2 {

		private static Object rs;
		private static PreparedStatement st;
		private static Object conn;
		private static String currdate;

		private static String sdate =null;
		private static String sTime ="";
		private static String sDate = "";
		static DateUtils day = new DateUtils();
	
		static String tableName = null;

		static String tab_0 = "KEYID";
	    static String tab_1 = "DATEID";
	    static String tab_2 = "PROGID";
	    String tab_3 = "OPENURL";
	    String tab_4 = "NODENAME";
	    String tab_5 = "NODETYPE";
	    String tab_6 = "CHILDNAME";
	    String tab_7 = "NODEACTION";
	    String tab_8 = "NODEVALUE";
	    String tab_9 = "NOTE";
		private static int imax =10000;
		private static String oldKEY;
		private static String iKEY;
		private static int fprimo = 0;
		private String str;
		private static String line;
		private static char semic = '|';
		private static String wSTATO;
		private static int indx;
		private static int inde;
		private static String lline;
		private static String ws1;
		private static String ws2;
		private static String ws3;
		private static int idx;
		//public static void main(String[] args) throws IOException {
		ResultDb2(int returnCode) throws IOException{ 
			System.out.println("Inizio esecuzione <ResultDb2>");
			
			sdate = day.now();
			 
			 String sdateaaaa = sdate.substring(0, 4);
			 String sdatemm =   sdate.substring(5, 7);
			 String sdategg = sdate.substring(8, 10);
			
		 	 String stimehh = sdate.substring(11, 13);
			 String stimemm = sdate.substring(14, 16);
			 String stimess = sdate.substring(17, 19);
			
			 sDate = (sdateaaaa+sdatemm+sdategg);
			 sTime = (stimehh+stimemm+stimess);
			 System.out.println("date:"+sDate);
			 System.out.println("time:"+sTime);
			 currdate = sDate+sTime;

			GetProperties();  
			ReadOutValues();			
			try {
				try {
					//Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
					Class.forName(PropertyFiles.getDbDriverTest()).newInstance();
				} catch (InstantiationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IllegalAccessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}	
				//String url = "jdbc:db2://127.0.0.1:50000/db2";
				String url = PropertyFiles.getDbConnStringTest();
				Properties props = new Properties();
				//props.setProperty("user"; "db2admin");
				props.setProperty("user", PropertyFiles.getDbUserTest());
				//props.setProperty("password"; "main");
				props.setProperty("password", PropertyFiles.getDbPasswordTest());
				try {
					Connection conn = DriverManager.getConnection(url, props);
						
					System.out.println("Inizio scansione JDBC");
					tableName = PropertyFiles.getTabName1();

					String stconn =
					"SELECT *  FROM " + tableName 
							//+ " WHERE " + tab_1 + " LIKE "+"'20150529165053%'"
							//+ " WHERE " + tab_1 
							+ " WHERE "+tab_1+" = (SELECT MAX(M."+tab_1+") FROM  " + tableName+" AS M)"
							+ " ORDER BY " + tab_1+","+tab_0+","+tab_2
					;
					System.out.println("stringa- test:"+stconn);
					st = conn
					.prepareStatement ("SELECT *  FROM " + tableName 
							//+ " WHERE " + tab_1 + " LIKE "+"'20150529165053%'"
							//+ " WHERE " + tab_1 
							+ " WHERE "+tab_1+" = (SELECT MAX(M."+tab_1+") FROM  " + tableName+" AS M)"
							+ " ORDER BY " + tab_1+","+tab_0+","+tab_2
					); 

					//TABLENAME
					rs = st.executeQuery();
				    //File outputFile = new File("dati/outDb2.txt");
					File outputFile = new File(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTDB2_FILE_OUTPUT()+".al"+currdate+".csv");
				    // System.out.println(outputFile.getAbsolutePath());
				    FileWriter writer = null;
				    
				    try {								
				    	boolean deleted = false;							
				    	if (outputFile.exists()) {							
				    		deleted = outputFile.delete();						
				    	}							
				    	System.out.println("rimosso file da: " + outputFile.getAbsolutePath() + "; " + deleted);							
				    	writer = new FileWriter(outputFile, false);							
				    								
				    								
				    								
				    								
				    } catch (IOException e1) {								
				    	System.out.println(e1.getMessage());							
				    	e1.printStackTrace();							
				    }	
				    int ind = 0;
					int i = 0;
					System.out.println(((ResultSet) rs).getRow());

					//writer.write(str+"\n");
						while (((ResultSet) rs).next()) {
						i++;
						line= " ";
			 			idx=0;
						System.out.println("Leggo: rec#" + i 
								+ ":   " 
								+ ((ResultSet) rs).getString(1) 
								+ " " + ((ResultSet) rs).getString(2)
								+ " " + ((ResultSet) rs).getInt(3)
								+ " " + ((ResultSet) rs).getString(4)
								+ " " + ((ResultSet) rs).getString(5)
								+ " " + ((ResultSet) rs).getString(6)
								+ " " + ((ResultSet) rs).getString(7)
								+ " " + ((ResultSet) rs).getString(8)
								+ " " + ((ResultSet) rs).getString(9)
								+ " " + ((ResultSet) rs).getString(10)
								+ " " + ((ResultSet) rs).getString(11)
								+ " " + ((ResultSet) rs).getString(12)
								+ " " + ((ResultSet) rs).getString(13)
								+ " " + ((ResultSet) rs).getString(14)
								+ " " + ((ResultSet) rs).getString(15)
								+ " " + ((ResultSet) rs).getString(16)
								+ " " + ((ResultSet) rs).getString(17)
								+ " " + ((ResultSet) rs).getString(18)
								+ " " + ((ResultSet) rs).getString(19)
								+ " " + ((ResultSet) rs).getString(20)
								+ " " + ((ResultSet) rs).getString(21)
								+ " " + ((ResultSet) rs).getString(22)
								+ " " + ((ResultSet) rs).getString(23)
								+ " " + ((ResultSet) rs).getString(24)
								+ " " + ((ResultSet) rs).getString(25)
								+ " " + ((ResultSet) rs).getString(26)
								+ " " + ((ResultSet) rs).getString(27)
								+ " " + ((ResultSet) rs).getString(28)
								+ " " + ((ResultSet) rs).getString(29)
								+ " " + ((ResultSet) rs).getString(30)
								+ " " + ((ResultSet) rs).getString(31)
								+ " " + ((ResultSet) rs).getString(32)
								+ " " + ((ResultSet) rs).getString(33)
								+ " " + ((ResultSet) rs).getString(34)
								+ " " + ((ResultSet) rs).getString(35)
								+ " " + ((ResultSet) rs).getString(36)
								+ " " + ((ResultSet) rs).getString(37)
								+ " " + ((ResultSet) rs).getString(38)
								+ " " + ((ResultSet) rs).getString(39)
								+ " " + ((ResultSet) rs).getString(40)
								+ " " + ((ResultSet) rs).getString(41)
								+ " " + ((ResultSet) rs).getString(42)
								+ " " + ((ResultSet) rs).getString(43)
								+ " " + ((ResultSet) rs).getString(44)
								+ " " + ((ResultSet) rs).getString(45)
								+ " " + ((ResultSet) rs).getString(46)
								+ " " + ((ResultSet) rs).getString(47)
								+ " " + ((ResultSet) rs).getString(48)
								+ " " + ((ResultSet) rs).getString(49)
								+ " " + ((ResultSet) rs).getString(50)
								+ " " + ((ResultSet) rs).getString(51)
								+ " " + ((ResultSet) rs).getString(52)
								+ " " + ((ResultSet) rs).getString(53)
								);
						iKEY = ((ResultSet) rs).getString(1);
						char quote = '"';

						if (fprimo  == 0) {
							fprimo++;
						    oldKEY = iKEY;
							ind++;
							indx=ind;
							indx++;
							indx++;
							indx++;
			    			 line = (
			    					 "@0;"+ind+";"
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
			    					 ); 
				    		 		 line += ";;;;" ;
					    		 	 line+=";";
					    		 	 line+=";";
					    		 	 line+=";";
									 line += ";";
								 writer.write(line+"\n");
								 ind++;
				    			 line = (
				    					 "@A;"+ind+";"
							    		 + ";" 
							    		 + ";" 
							    		 + ";" 
							    		 + ";" 
							    		 + ";" 
							    		 + ";" 
							    		 + ";" 
							    		 + ";" 
							    		 + ";" 
				    					 ); 
					    		 		 line += ";;;;" ;
						    		 	 line+=";=N"+indx;
						    		 	 line+=";=M"+indx;
						    		 	 line+=";=L"+indx;
										 line += ";";
									 writer.write(line+"\n");
									 ind++;
				    			 line = (
			    					 "@B;"+ind+";"+oldKEY 
							    	 + ";" 
									 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 ); 
									 line += ";" +ind;
						    		 line+=";Step;	Tipo;	Istruzioni"; 
						    		 line+="(text);	Dati di input";
						    		 line+="(Associated Data);	Risultati attesi";
						    		 line+="(Expected Result);	Nome file esterno";		
								 writer.write(line+"\n");
						}
			    		if (i==1) {
			    			 imax=10000;
			    		}							
					    if (iKEY.contentEquals(oldKEY) == false) {
							 while (i <= imax) {
								line= "@@";
								if (line.contains("@@")==false) {
									elabRiga(i, ind, quote);
									writer.write(line+"\n");
									ind++;
								}
						    	i++;
							 }
							 imax=i;
							 oldKEY = iKEY;
							 i=0;
							 ind++;
						     writer.write("@H"+ind+";"+oldKEY+"\n");

						     i=1;
						     ind++;
  							 indx=ind;
							 indx++;
							 indx++;
							 indx++;
			    			 line = (
			    					 "@D;"+";" + ind+";"
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
//						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 ); 
					    		 line += ";;;;" ;
				    		 	 line+=";=N"+indx;
				    		 	 line+=";=M"+indx;
								 line += ";";
				    		 	 line+=";=L"+indx;
								 writer.write(line+"\n");
								 ind++;
								 line = " ";
			    			 line = (
						    		 "@E;" + ind+";"
			    					 +oldKEY 
							    	 + ";" 
									 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 + ";" 
						    		 ); 
									 line += ";" +ind;
						    		 line+=";Step;	Tipo;	Istruzioni"; 
						    		 line+="(text);	Dati di input";
						    		 line+="(Associated Data);	Risultati attesi";
						    		 line+="(Expected Result);	Nome file esterno";		
									 writer.write(line+"\n");
					    }

						
						try {
							ind++;
							line = " ";
						    line = "@F;" + ind+";"+
						     (((ResultSet) rs).getString(1) 
										+ " " + ((ResultSet) rs).getString(2)
										+ " " + ((ResultSet) rs).getInt(3)
										+ " " + ((ResultSet) rs).getString(4)
										+ " " + ((ResultSet) rs).getString(5)
										+ " " + ((ResultSet) rs).getString(6)
										+ " " + ((ResultSet) rs).getString(7)
										+ " " + ((ResultSet) rs).getString(8)
										+ " " + ((ResultSet) rs).getString(9)
										+ " " + ((ResultSet) rs).getString(10)
										+ " " + ((ResultSet) rs).getString(11)
										+ " " + ((ResultSet) rs).getString(12)
										+ " " + ((ResultSet) rs).getString(13)
										+ " " + ((ResultSet) rs).getString(14)
										+ " " + ((ResultSet) rs).getString(15)
										+ " " + ((ResultSet) rs).getString(16)
										+ " " + ((ResultSet) rs).getString(17)
										+ " " + ((ResultSet) rs).getString(18)
										+ " " + ((ResultSet) rs).getString(19)
										+ " " + ((ResultSet) rs).getString(20)
										+ " " + ((ResultSet) rs).getString(21)
										+ " " + ((ResultSet) rs).getString(22)
										+ " " + ((ResultSet) rs).getString(23)
										+ " " + ((ResultSet) rs).getString(24)
										+ " " + ((ResultSet) rs).getString(25)
										+ " " + ((ResultSet) rs).getString(26)
										+ " " + ((ResultSet) rs).getString(27)
										+ " " + ((ResultSet) rs).getString(28)
										+ " " + ((ResultSet) rs).getString(29)
										+ " " + ((ResultSet) rs).getString(30)
										+ " " + ((ResultSet) rs).getString(31)
										+ " " + ((ResultSet) rs).getString(32)
										+ " " + ((ResultSet) rs).getString(33)
										+ " " + ((ResultSet) rs).getString(34)
										+ " " + ((ResultSet) rs).getString(35)
										+ " " + ((ResultSet) rs).getString(36)
										+ " " + ((ResultSet) rs).getString(37)
										+ " " + ((ResultSet) rs).getString(38)
										+ " " + ((ResultSet) rs).getString(39)
										+ " " + ((ResultSet) rs).getString(40)
										+ " " + ((ResultSet) rs).getString(41)
										+ " " + ((ResultSet) rs).getString(42)
										+ " " + ((ResultSet) rs).getString(43)
										+ " " + ((ResultSet) rs).getString(44)
										+ " " + ((ResultSet) rs).getString(45)
										+ " " + ((ResultSet) rs).getString(46)
										+ " " + ((ResultSet) rs).getString(47)
										+ " " + ((ResultSet) rs).getString(48)
										+ " " + ((ResultSet) rs).getString(49)
										+ " " + ((ResultSet) rs).getString(50)
										+ " " + ((ResultSet) rs).getString(51)
										+ " " + ((ResultSet) rs).getString(52)
										+ " " + ((ResultSet) rs).getString(53)
						    		 );
							 		 //ind++;
							 		 idx=0;
			    			 		 elabRiga(i, ind, quote);
			    			 		 if(idx==999999) {
			    			 			 System.out.println("idx:"+idx);
			    			 			 ind--;
			    			 		 }
			    			 		 else {
			    			 			 if (line.substring(0,2).contentEquals("   ") == true) {
				    			 			 System.out.println("riga vuota:"+ind);
				    			 			 ind--;
			    			 			 }

			    			 			 if (line.contains("@") == true) {
										     writer.write(line);
											 writer.write("\r\n");
											 line=" ";
			    			 			 }
			    			 		 }
									
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						try {
							writer.flush();
							writer.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						System.out.println("Fine scansione - righe lette: " + ind);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					finally {
						try {
							//if(rs != null) ((OutputStreamWriter) rs).close();
							if(st != null)st.close();
							if(conn != null) ((OutputStreamWriter) conn).close();
						} catch (SQLException e) {
							
						}
						
						
					}

				} catch (ClassNotFoundException e) {
					System.out.println("Driver non trovato !");
					e.printStackTrace();
				}
			}


		private static void ReadOutValues() throws IOException {
			BufferedReader in = new BufferedReader
  			//(new FileReader("dati/"+"FTPValues.txt"));
			(new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTVALUES_FILE_OUTPUT()));
			
			 String line = null;
				
			  //ciclo lettura 
			  while ((line = in.readLine()) != null) {
				  //System.out.println("riga trovata : " + line);
				  if (line.substring(0, 2).contentEquals(">>") == true) {
					  currdate = line.substring(20, 32);
					  //PropertyFiles.setCURRDATE(currdate);
					  //System.out.println("testo trovato currdate: " + currdate);
				  }
			  }
			  in.close();
		}

		private static void GetProperties() throws IOException {
			PropertyFiles pf = new PropertyFiles();
		}

		private static void elabRiga(int i, int ind, char quote) throws SQLException {
	   		 if (i==1 || i==2 || i==3 || i==4) {
	   			 ws1=((ResultSet) rs).getString(4);
	   			 ws2=((ResultSet) rs).getString(5);
	   			 ws3=((ResultSet) rs).getString(6);

	   			 if ((ws1.contentEquals(" ") == true) 
		   		 &&  (ws2.contentEquals(" ") == true) 
			   	 &&  (ws3.contentEquals(" ") == true)) {
	   				 i=999;
	   			 }
	   		 }
	   		 if (i==1) {
	    		 line += ";" +((ResultSet) rs).getString(1);
	    		 line += ";" +ind;
	    		 line+=";P"+";	Attivit� Preliminari e/o Precondizioni	"; 
	    		 line+=";"+"L'utente accede al browser, viene richiamata la form di cui ad URL indicata";
	    		 //**inde=ind-1;
	    		 inde=ind;
	    		 line+=";=F"+ind+";=P"+inde;
	   		 }
	   		 if (i==2) {
	    		 line += ";" + ((ResultSet) rs).getString(1);
	    		 line += ";" +ind;
//	    		 line+=";P"+";	Stato Base	"; 
	    		 line+=";P"+";	"; 
	    		 line+=";=L"+ind;
//	    		 line+=";=CONCATENATE(";
	    		 line+=";";
//	    		 line+=quote+"L'oggetto "+quote+semic+"G"+ind+semic+quote+" attende "+quote+semic +"H"+ind
//	    				 +semic+quote+", "+quote+semic +"I"+ind+")";
//			     line+=";Si attende la risposta dall'applicazione;;P;	1";
	    		 line+="";
			     line+=";;;;	";
		   		 }
	   		 if (i==3) {
	   			 wSTATO = " ";
	   			 lline= " ";
	   			 if (line.contains("Stato Base") == true) {
	   				 wSTATO = "Stato Base";
				     lline=(";Si attende la risposta dall'applicazione");
	   			 }
	   			 if (line.contains("Navigazione") == true) {
	   				 wSTATO = "Navigazione";
		    		 lline+=";=CONCATENATE(";
		    		 lline+=quote+"L'oggetto "+quote+semic+"G"+ind+semic+quote+" attende "+quote+semic +"H"+ind
		    				 +semic+quote+", "+quote+semic +"I"+ind+")";
	   			 }
	    		 line += ";" + ((ResultSet) rs).getString(1);
	    		 line += ";" +ind;
	    		 line+=";1;	"+wSTATO; 
	    		 line+=";=L"+ind;
			     line+=lline+";=CONCATENATE(";
			     line+=quote+"Viene selezionato l^oggetto "+quote+semic+"G"+ind+")";
			     line+=";;P;	1";
		 		  }
	   		 if (i==4) {
	   			 wSTATO = " ";
	   			 lline= " ";
	   			 if (line.contains("Stato Base") == true) {
	   				 wSTATO = "Stato Base";
				     lline=(";Si attende la risposta dall'applicazione");
	   			 }
	   			 if (line.contains("Navigazione") == true) {
	   				 wSTATO = "Navigazione";
		    		 lline+=";=CONCATENATE(";
		    		 lline+=quote+"L'oggetto "+quote+semic+"G"+ind+semic+quote+" attende "+quote+semic +"H"+ind
		    				 +semic+quote+", "+quote+semic +"I"+ind+")";
	   			 }
	    		 line += ";" + ((ResultSet) rs).getString(1);
	    		 line += ";" +ind;
	    		 line+=";1;"+wSTATO; 
	    		 line+=";=L"+ind;
			     line+=lline+";Si attende la risposta dall'applicazione;;P;	1";
	   		 }
	   		 if (i==5) {
	    		 line +=  ";" +oldKEY+";" + ind;
	    		 line+=";1;"+"Navigazione"; 
	    		 line+=";N.A.";
	    		 line+=";N.A.";
	    		 line+=";=P"+inde;
	   		 }
	   		 if (i==6) {
	    		 line +=  ";" +oldKEY+";" + ind;
	    		 line+=";2; Azione	"; 
	    		 line+=";"+";Riferimenti: file 000811_COL_basedati_1.0.xls	";
	    		 line+=";"+"L'applicazione attende la risposta dal sistema  (HTTP  - waiting for response)";
	   		 }
	   		 if (i==7) {
	    		 line +=  ";" +oldKEY+";" + ind;
	    		 line+=";3;	Navigazione;	"; 
			     line+=";=CONCATENATE(";
	    		 line+=quote+"Effettua la funzionalita^"+quote+semic+"M"+ind+")";
	    	}
	   		 if (i>165 && i<998) {
	   			 if (line.contains("@") == false) {
	   				 i=999;
	   			 }
	   			 else {
		    		 line +=  ";" +oldKEY+";" + ind;
		    		 line+=";R1;	Riciclo Script;	"; 
		    		 line+=";;";
		    		 i=999;
	   			 }
	    	}
	   		 if (i>166 && i<998) {
	    		 line +=  ";;" +oldKEY+";" + ind;
	    		 line+=";V;	Verifica Esterna;	N.A.; N.A.; N.A."; 
	    		 line+=";";
	    		 i=999;
	    	}
	   		 if (i==999999 || i==999998) {
	   			 idx=i;
	    	}
	   		 if (i>8 && i<999998) {
	   			 wSTATO = " ";
	   			 lline= " ";
	   			 if (line.contains("Stato Base") == true) {
	   				 wSTATO = "Stato Base";
				     lline=(";Si attende la risposta dall'applicazione");
		    		 line += ";" + ((ResultSet) rs).getString(1);
		    		 line += ";" +ind;
		    		 line+=";1;"+wSTATO; 
		    		 line+=";=L"+ind;
				     line+=lline+";Si attende la risposta dall'applicazione;;P;	1";

	   			 }
	   			 if (line.contains("Navigazione") == true) {
	   				 wSTATO = "Navigazione";
		    		 lline+=";=CONCATENATE(";
		    		 lline+=quote+"L'oggetto "+quote+semic+"G"+ind+semic+quote+" attende "+quote+semic +"H"+ind
		    				 +semic+quote+", "+quote+semic +"I"+ind+")";
		    		 line += ";" + ((ResultSet) rs).getString(1);
		    		 line += ";" +ind;
		    		 line+=";1;	"+wSTATO; 
		    		 line+=";=L"+ind;
				     line+=lline+";=CONCATENATE(";
				     line+=quote+"Viene selezionato l^oggetto "+quote+semic+"G"+ind+")";
				     line+=";;P;	1";

	   			 }
	   		 }
		}
}




