package cse360assign1;

import java.io.IOException;

public class MainTest {
	public static void main(String args[]) throws Exception {
		OrderIntList(); 	
	}


	private  static void OrderIntList() throws IOException {
		OrderedIntList oil = new OrderedIntList();
	
	}
}
