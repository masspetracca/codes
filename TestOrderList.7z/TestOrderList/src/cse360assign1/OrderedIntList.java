package cse360assign1;

import java.io.IOException;

public class OrderedIntList {
		private int[] a;  // array
		private int c; // counter

    	OrderedIntList() throws IOException{ 
    	System.out.println("Inizio <OrderedIntList> ");
			a = new int[10];
			insert(0);
			print();
		}
		
		public void insert (int v) {
			int j = 0;
			for (int i= 0; i<c;i++,j++)
			if(v<a[i]) break;
			for (int i = c-1; i>j; ) a[i] = a[i--];
			a[j]= v;
		}
		
		public void print () {
			for (int i = 1; i<c; i++) {
			if (i%5 ==0) System.out.println();
				System.out.print(a[i] + "\t");	}
		
		}
}
