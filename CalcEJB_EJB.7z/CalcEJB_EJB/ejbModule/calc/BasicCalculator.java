package calc;


public class BasicCalculator {

   public double addTwoNumbers(double first, double second) {
	return first + second;
   }
}