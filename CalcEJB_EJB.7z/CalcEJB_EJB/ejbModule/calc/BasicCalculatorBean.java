package calc;

import javax.ejb.Stateless;

/**
 * Bean implementation class for Enterprise Bean: BasicCalculator
 */
@Stateless
public class BasicCalculatorBean implements javax.ejb.SessionBean {
	/**
	 * 
	 */
	private static final long serialVersionUID = -143506297855236503L;
	private javax.ejb.SessionContext mySessionCtx;

	public javax.ejb.SessionContext getSessionContext() {
		return mySessionCtx;
	}
	public void setSessionContext(javax.ejb.SessionContext ctx) {
		mySessionCtx = ctx;
	}
	public void ejbCreate() throws javax.ejb.CreateException {
		System.out.println("BasicCalculatorBean - create ejb");
	}
	public void ejbActivate() {
	}
	public void ejbPassivate() {
	}
	public void ejbRemove() {
	}
	
	public double addTwoNumbers(double first, double second) {
		return first + second;
	}
	public double subtractTwoNumbers(double first, double second) {
		return first - second;
	}
}
