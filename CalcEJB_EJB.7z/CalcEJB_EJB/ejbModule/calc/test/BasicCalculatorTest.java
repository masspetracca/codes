package calc.test;

import calc.BasicCalculator;
import junit.framework.TestCase;


public class BasicCalculatorTest extends TestCase {

	BasicCalculator aBasicCalculator = null;
	//test variables settings
	int num1=0;
	int num2=0;

	/*
	 * Setup before each test case
	 */
	protected void setUp() throws Exception {
		super.setUp();
		aBasicCalculator = new BasicCalculator();
	}
	public void testSimpleAdditionNotSame() throws Exception {
		num1=2;
		num2=2;
		double result = aBasicCalculator.addTwoNumbers(num1, num2);
		assertNotSame("2+2 does not = 5", new Double(result), new Double(5));
	}

	public void testDesignedToFail() throws Exception {
		num1=2;
		num2=1;
		double result = aBasicCalculator.addTwoNumbers(num1, num2);
		assertTrue("1 + 1 = 3", result == 3);

	}
	
	public void testSimpleAddition() throws Exception {

		assertTrue("Calculator instance is not null", aBasicCalculator != null);

		num1=2;
		num2=2;
		double result = aBasicCalculator.addTwoNumbers(num1, num2);
		assertTrue("2+2=4", result == 4);

	}
	public void testEnded() throws Exception {
		assertTrue("Calculator instance is ended without errors", false);
	}
}