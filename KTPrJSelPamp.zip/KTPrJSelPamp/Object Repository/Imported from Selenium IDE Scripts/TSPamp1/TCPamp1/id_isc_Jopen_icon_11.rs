<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>id_isc_Jopen_icon_11</name>
   <tag></tag>
   <elementGuidId>f145b5d1-c8e5-4de9-9819-5664f991ae8e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[id='isc_Jopen_icon_11']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
