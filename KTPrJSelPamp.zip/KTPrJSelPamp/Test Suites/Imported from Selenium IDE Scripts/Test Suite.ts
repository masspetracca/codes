<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>0</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>cfa13801-92de-43dc-8333-bcc5df4e8d9f</testSuiteGuid>
   <testCaseLink>
      <guid>75c4d98b-02f5-4b87-9b9c-56a960f66b85</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/Test Suite/RU01-NUC01-T01</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7f675dce-f487-485e-8887-c54210b2712d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/Test Suite/RU01-NUC01-T02</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d6930ae2-2d14-4df2-89c8-a99dc40cde37</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/Test Suite/RU01-NUC01-T03</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
