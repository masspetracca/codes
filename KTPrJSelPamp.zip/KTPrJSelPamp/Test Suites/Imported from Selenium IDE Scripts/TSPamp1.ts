<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TSPamp1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-10-02T11:37:25</lastRun>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>0</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>334e17ae-3645-4e6d-b746-9a1adda7c03c</testSuiteGuid>
   <testCaseLink>
      <guid>3a01c0c3-b058-4f6e-a456-c3ab4a1a5a26</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/TSPamp1/TCPamp1</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
