import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('')

WebUI.navigateToUrl('https://10.0.10.230:10084/PampWeb/login.jsp')

WebUI.setText(findTestObject('Page_CCG Portal/input_Username_j_username'), 'mpetracca')
WebUI.setEncryptedText(findTestObject('Page_CCG Portal/input_Password_j_password'), 'e5oB0LaHE5FiGm7v1yiB7Q==')

WebUI.click(findTestObject('Page_CCG Portal/input_Password_submitLabel'))

WebUI.click(findTestObject('Page_CCG Portal/span_New MIC_isc_Jopen_icon_10'))

WebUI.click(findTestObject('Page_CCG Portal/td_XCOM Back Test Simulator'))

WebUI.doubleClick(findTestObject('Page_CCG Portal/span'))

WebUI.click(findTestObject('Page_CCG Portal/td_Breaches aggregated by clas'))

WebUI.click(findTestObject('Page_CCG Portal/div_0.50'))

WebUI.doubleClick(findTestObject('Page_CCG Portal/span'))

WebUI.click(findTestObject('Page_CCG Portal/div_0.50'))

WebUI.doubleClick(findTestObject('Page_CCG Portal/div_0.50'))

WebUI.click(findTestObject('Page_CCG Portal/img'))

WebUI.setText(findTestObject('Page_CCG Portal/input_GS(0-3M - Inf. R3_BTSIMH'), '0.1105')

WebUI.sendKeys(findTestObject('Page_CCG Portal/input_GS(0-3M - Inf. R3_BTSIMH'), Keys.chord(Keys.ENTER))

WebUI.click(findTestObject('Page_CCG Portal/td_GS(6M-1Y - Inf. R3'))

WebUI.click(findTestObject('Page_CCG Portal/td_GS(1Y-2Y - Inf. R3'))

WebUI.click(findTestObject('Page_CCG Portal/div_32'))

WebUI.click(findTestObject('Page_CCG Portal/div_31'))

WebUI.click(findTestObject('Page_CCG Portal/img_1'))

WebUI.click(findTestObject('Page_CCG Portal/div_Reset Sim.'))

WebUI.click(findTestObject('Page_CCG Portal/td_Print'))

WebUI.click(findTestObject('Page_CCG Portal/b_Nome Cognomes profile'))

WebUI.click(findTestObject('Page_CCG Portal/font_Logout'))

