package it.ccg.liste.freader.batch;

public class Names {
	int mem1;
	String name2;
	String name3;
	int sig4;
	String note5;

	public int getMem1() {
			return mem1;
	}
	public void setMem1(int mem1) {
		this.mem1 = mem1;
	}
	public String getName2() {
		return name2;
	}
	public void setName2(String name2) {
		this.name2 = name2;
	}
	public String getName3() {
		return name3;
	}
	public void setName3(String name3) {
		this.name3 = name3;
	}
	public int getSig4() {
		return sig4;
	}
	public void setSig4(int sig4) {
		this.sig4 = sig4;
	}
	public String getNote5() {
		return note5;
	}
	public void setNote5(String note5) {
		this.note5 = note5;
	}
		
}
