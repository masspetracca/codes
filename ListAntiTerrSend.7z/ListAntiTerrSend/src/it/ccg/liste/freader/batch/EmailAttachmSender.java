package it.ccg.liste.freader.batch;

import java.io.IOException;
import java.util.Date;import java.util.Properties; 
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart; 
public class EmailAttachmSender {     

	private String host; 
	private String port;
	private String subject;
	private String username;
	private String message;
	private String password;
	private String toAddress;
	private String[] attachFiles;
	public EmailAttachmSender(int returnCode) throws AddressException, MessagingException {
		init();

		sendEmailWithAttachments(host, port, username, password, toAddress, subject, message, attachFiles, returnCode);
	}
	public static void sendEmailWithAttachments(String host, String port,            
			String userName, final String password, String toAddress,            
			String subject, String message, String[] attachFiles, int return_code)            
				throws AddressException, MessagingException {        
		// sets SMTP server properties        
		Properties properties = new Properties();        
		properties.put("mail.smtp.host", host);        
		properties.put("mail.smtp.port", port);        
		properties.put("mail.smtp.auth", "true");        
		properties.put("mail.smtp.starttls.enable", "true");        
		userName = "masspetracca@gmail.com";        
		properties.put("mail.user", userName);  
		throw new NullPointerException("userName");     
	}
		
				/**     * Test sending e-mail with attachments     */    
				public static void main(String[] args) {        
					// SMTP info        
					String host = "smtp.gmail.com";        
					String port = "587";        
					String mailFrom = "massimo.petracca-ext@lseg.com";        
					String password = "Gerard_07";         
					// message info
					String mailTo = "masspetracca@gmail.com";        
					String subject = "New email with attachments";        
					String message = "I have some attachments for you.";         
					// attachments        
					String[] attachFiles = new String[1];        
					attachFiles[0] = "RHDSetup.log";        
					try {            
						sendEmailWithAttachments(host, port, mailFrom, password, mailTo,                
								subject, message, attachFiles, 1);            
						System.out.println("Email sent.");        
						} catch (Exception ex) {            
							System.out.println("Could not send email.");            
							ex.printStackTrace();        
							}    
					}
	
				private void init() {
					host = "smtp.gmail.com";        
					port = "587";        
					password = "Gerard_07";         
					// message info        
					toAddress = "masspetracca@gmail.com";        
					subject = "New email with attachments"; 
					// attachments        
					String[] attachFiles = new String[1];        
					attachFiles[0] = "RHDSetup.log";  
			}

	
}
