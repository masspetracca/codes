package it.ccg.liste.freader.batch;

import java.io.IOException;
import java.sql.SQLException;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

public class MainData {
	/**
	 * Main DataFile
	 * @throws IOException 
	 * @throws DocumentException 
	 */
	//public MainData(int returnCode) throws IOException, DocumentException {
		// TODO Auto-generated constructor stub
	
	  private static  int returnCode;
	
	  public static void main(String[] args) throws Exception {
		  System.out.println("Inizio esecuzione <MAIN DATA>");
		  //Send email + attachm
		  EmailAttachmSender(returnCode);
		  
		  if (returnCode != 0) {
			 System.out.println("Errore nella fase - verificare !");
		 }
		  System.out.println("Fine esecuzione <MAIN>");
	  }


	private static void EmailAttachmSender(int returnCode) throws IOException, SQLException, AddressException, MessagingException {
		EmailAttachmSender str = new EmailAttachmSender(returnCode);
	}



	private static void Errore() {
		// TODO Auto-generated method stub
		System.exit(1);
	}


	private static void LoadReq() {
		// TODO Auto-generated method stub
		
	}


	private static void GetProperties() throws IOException {
		PropertyFiles pf = new PropertyFiles();		
	}

}



