import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListImplementation {

	public static void main (String args[]) {
		List<Integer> a1 = new ArrayList<Integer>();
		a1.add(1);
		a1.add(2);
		a1.add(3);
		int i=(int)a1.get(0);
		
		Iterator it = a1.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
	}
}
