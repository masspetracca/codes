import java.io.OutputStream;

public class GenericExample {
	

	public static <T> int countOccurence(T[] list, T itemToCount) {
		int count=0;
		if (itemToCount == null) {
			for (T listItem: list)
				if (listItem == null)
					count++;			
		}
		else {
			for (T listItem: list)
				if (itemToCount.equals(listItem))
					count++;
		}
		return count;
	}
	public static void main (String args[]) {
		String wordList=("The big data cource");
		String word="the";
		System.out.println(wordList+" "+word);
		
	}
}
