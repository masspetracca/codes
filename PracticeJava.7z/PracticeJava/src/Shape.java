
public class Shape {
	int width, height;
	static String color;
	

	public static void putCol(String color) {
		System.out.println("Color:"+color);
	}

	
	public static void main(String[] args ) {
		putCol("blue");
	}
}
