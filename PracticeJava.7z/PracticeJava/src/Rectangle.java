
public abstract class Rectangle extends Shape {

	Rectangle(int w, int h) {
		this();
		width=w;
		height=h;
		color=this.color;
	}
	Rectangle() {
		System.out.println("Constructors....");
	}
	public void putCol() {
		System.out.println("Hello !");
	}
	abstract void draw();
	
}
