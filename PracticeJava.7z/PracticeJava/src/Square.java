
public class Square {
	int side;
	private static int numSquare;
	private static int area;
	
	public Square() {
		// TODO Auto-generated constructor stub
		
	}
	
	public Square(int s) {
		side=s;
		numSquare++;
	}

	public void calcArea() {
		area = 0;
		area=side*side;
				
	}
	
	public static void main (String[] args ) {
		Square s1 = new Square(5);
		System.out.println("numSquare:"+numSquare);
		//s1.side = 5;
		s1.calcArea();		
		System.out.println("area:"+area);
	}
}
