
public class HelloWorld {

	private static double marks;

	public static void main (String [] args) {
		System.out.println("Hello max");
		for (int i=0;i<5;i++) {
			System.out.println("Area is:+marks"+i);	
		}
		int rolling=5;
		
		int age=10;
		int side=5;
		
		double marks=56.5;
		
		int area=side*side;
		System.out.println("Area is:"+area);
		
		//Sez. 3 lett.9 ....
		if (marks>60)
			System.out.println("distinction");
		else
			System.out.println("no distinction");
	}
}
