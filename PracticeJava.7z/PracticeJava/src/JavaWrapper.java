
public class JavaWrapper {
	
	public static void main(String args[]) {
		Integer y=new Integer(20);
		y++;
		System.out.println(y);
	}

}
