
public class TextRectangle extends Shape {
	
	String myMessage;
	
	TextRectangle(int w, int h, String color, String message) {
		super();
		myMessage = new String(message);
	}

}
