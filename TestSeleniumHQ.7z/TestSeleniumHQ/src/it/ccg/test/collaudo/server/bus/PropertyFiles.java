/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package it.ccg.test.collaudo.server.bus;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Massimo
 * Gestisce le Properties del progetto batch
 */
public class PropertyFiles {
	  
    static String line;
  
	static private String ambiente = "";

	static private String tabName1 = "";
    static private String tabName2 = "";
    static private String tabName3 = "";
    
    static private String dbDriverTest = "";
    static private String dbUserTest ="";
    static private String dbPasswordTest ="";
    static private String dbConnStringTest ="";


    static private String dbDriverColl = "";
    static private String dbUserColl ="";
    static private String dbPasswordColl ="";
    static private String dbConnStringColl ="";

    static private String dbDriverProd = "";
    static private String dbUserProd ="";
    static private String dbPasswordProd ="";
    static private String dbConnStringProd ="";
    
    static private String dbNumeroTentativi ="0";
    static private String dbTimeout ="0";
    static private String dbServer ="";
    static private String dbPort ="";
    
    static private String CARTELLA_DATI = "";
    static private String CARTELLA_CONF = "";
    static private String OUTFPM_FILE_INPUT = "";
    static private String OUTFPM_FILE_INPUT_D = "";
    static private String OUTFIELDS_FILE_OUTPUT ="";
    static private String OUTVALUES_FILE_OUTPUT = "";
    static private String SQLCMD_FILE_OUTPUT = "";
    static private String OUTDB2_FILE_OUTPUT = "";
	static private String OUTREQFTP_FILE_OUTPUT = "";
	static private String OUTREQPROP_FILE_OUTPUT = "";
	static private String OUTPROP_FILE =  "";
	
	//per strutture
	static private String AREA =  "";
	static private String TIPO =  "";
	static private String FREQUENZA =  "";
	

    
	static private String TIME_DURANTE = "0";
	static private String TIME_CHIUSURA = "0";

    
    	public PropertyFiles() throws IOException{
    	  
    	  String FilePropertiesNode = "confPM/";
    	  String FileProperties = "CCGBatchProperties.xml";
		  BufferedReader in = 
				new BufferedReader(new FileReader(FilePropertiesNode+FileProperties));
			
			   
			while ((line = in.readLine()) != null) {
				  //System.out.println("properties letto: " + line);
				  //System.out.println(">> trovato: " + line.substring(0,2));
				  //System.out.println("substr.line: "+line.substring(0, 3));
				   if (line.substring(0, line.length()).contains("#00.") 
						  == true) {
					 ambiente = (line.substring(4, line.length()));
				   }
				   if (line.substring(0,  line.length()).contains("#01.") 
						  == true) {
					 tabName1 = (line.substring(4, line.length()));
				   }
				  if (line.substring(0,  line.length()).contains("#02.") 
						  == true) {
					  dbDriverTest = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#03.") 
						  == true) {
					  dbUserTest = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#04.") 
						  == true) {
					  dbPasswordTest = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#05.") 
						  == true) {
					  dbConnStringTest = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#06.") 
						  == true) {
					  dbDriverColl = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#07.") 
						  == true) {
					  dbUserColl = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#08.") 
						  == true) {
					  dbPasswordColl = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#09.") 
						  == true) {
					  dbConnStringColl = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#10.") 
						  == true) {
					  dbDriverProd = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#11.") 
						  == true) {
					  dbUserProd = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#12.") 
						  == true) {
					  dbPasswordProd = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#13.") 
						  == true) {
					  dbConnStringProd = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#14.") 
						  == true) {
					  dbNumeroTentativi = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#15.") 
						  == true) {
					  dbTimeout = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#16.") 
						  == true) {
					  dbServer = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#17.") 
						  == true) {
					  dbPort = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#18.") 
						  == true) {
					  CARTELLA_DATI = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#19.") 
						  == true) {
					  OUTFPM_FILE_INPUT = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#20.") 
						  == true) {
					  OUTFIELDS_FILE_OUTPUT = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#21.") 
						  == true) {
					  OUTVALUES_FILE_OUTPUT = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#22.") 
						  == true) {
					  SQLCMD_FILE_OUTPUT = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#23.") 
						  == true) {
					  OUTDB2_FILE_OUTPUT = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#24.") 
						  == true) {
					  CARTELLA_CONF = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#25.") 
						  == true) {
					  OUTFPM_FILE_INPUT_D = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#26.") 
						  == true) {
					  OUTREQFTP_FILE_OUTPUT = (line.substring(4, line.length()));
				  }
				  if (line.substring(0, line.length()).contains("#27.") 
						  == true) {
					  OUTPROP_FILE = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#28.") 
						  == true) {
					  TIME_DURANTE = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#29.") 
						  == true) {
					  TIME_CHIUSURA = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#30.") 
						  == true) {
					  tabName2 = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#31.") 
						  == true) {
					  AREA = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#32.") 
						  == true) {
					  FREQUENZA = (line.substring(4, line.length()));
				  }
				  if (line.substring(0,  line.length()).contains("#33.") 
						  == true) {
					  TIPO = (line.substring(4, line.length()));
				  }


				}
    	  }
		    public static String getAmbiente() {
				return ambiente;
			}
		
			public void setAmbiente(String ambiente) {
				this.ambiente = ambiente;
			}
    	    public static String getTabName1() {
    			return tabName1;
    		}

    		public void setTabName1(String tabName1) {
    			this.tabName1 = tabName1;
    		}

    		public static String getTabName2() {
    			return tabName2;
    		}

    		public void setTabName2(String tabName2) {
    			this.tabName2 = tabName2;
    		}

    		public String getTabName3() {
    			return tabName3;
    		}

    		public void setTabName3(String tabName3) {
    			this.tabName3 = tabName3;
    		}

    		public static String getDbDriverTest() {
    			return dbDriverTest;
    		}

    		public void setDbDriverTest(String dbDriverTest) {
    			this.dbDriverTest = dbDriverTest;
    		}

    		public static String getDbUserTest() {
    			return dbUserTest;
    		}

    		public void setDbUserTest(String dbUserTest) {
    			this.dbUserTest = dbUserTest;
    		}

    		public static String getDbPasswordTest() {
    			return dbPasswordTest;
    		}

    		public void setDbPasswordTest(String dbPasswordTest) {
    			this.dbPasswordTest = dbPasswordTest;
    		}

    		public static String getDbConnStringTest() {
    			return dbConnStringTest;
    		}

    		public void setDbConnStringTest(String dbConnStringTest) {
    			this.dbConnStringTest = dbConnStringTest;
    		}

    		public static String getDbDriverColl() {
    			return dbDriverColl;
    		}

    		public void setDbDriverColl(String dbDriverColl) {
    			this.dbDriverColl = dbDriverColl;
    		}

    		public static String getDbUserColl() {
    			return dbUserColl;
    		}

    		public void setDbUserColl(String dbUserColl) {
    			this.dbUserColl = dbUserColl;
    		}

    		public static String getDbPasswordColl() {
    			return dbPasswordColl;
    		}

    		public void setDbPasswordColl(String dbPasswordColl) {
    			this.dbPasswordColl = dbPasswordColl;
    		}

    		public static String getDbConnStringColl() {
    			return dbConnStringColl;
    		}

    		public void setDbConnStringColl(String dbConnStringColl) {
    			this.dbConnStringColl = dbConnStringColl;
    		}

    		public String getDbDriverProd() {
    			return dbDriverProd;
    		}

    		public void setDbDriverProd(String dbDriverProd) {
    			this.dbDriverProd = dbDriverProd;
    		}

    		public String getDbUserProd() {
    			return dbUserProd;
    		}

    		public void setDbUserProd(String dbUserProd) {
    			this.dbUserProd = dbUserProd;
    		}

    		public String getDbPasswordProd() {
    			return dbPasswordProd;
    		}

    		public void setDbPasswordProd(String dbPasswordProd) {
    			this.dbPasswordProd = dbPasswordProd;
    		}

    		public String getDbConnStringProd() {
    			return dbConnStringProd;
    		}

    		public void setDbConnStringProd(String dbConnStringProd) {
    			this.dbConnStringProd = dbConnStringProd;
    		}

    		public String getDbNumeroTentativi() {
    			return dbNumeroTentativi;
    		}

    		public void setDbNumeroTentativi(String dbNumeroTentativi) {
    			this.dbNumeroTentativi = dbNumeroTentativi;
    		}

    		public String getDbTimeout() {
    			return dbTimeout;
    		}

    		public void setDbTimeout(String dbTimeout) {
    			this.dbTimeout = dbTimeout;
    		}

    		public String getDbServer() {
    			return dbServer;
    		}

    		public void setDbServer(String dbServer) {
    			this.dbServer = dbServer;
    		}

    		public String getDbPort() {
    			return dbPort;
    		}

    		public void setDbPort(String dbPort) {
    			this.dbPort = dbPort;
    		}

    		public static String getCartellaDati() {
    			return CARTELLA_DATI;
    		}

    		public void setCartellaDati(String CARTELLA_DATI) {
    			this.CARTELLA_DATI = CARTELLA_DATI;
    		}

    		public static String getOUTFPM_FILE_INPUT() {
    			return OUTFPM_FILE_INPUT;
    		}

    		public void setOUTFPM_FILE_INPUT(String outFPM_file_input) {
    			this.OUTFPM_FILE_INPUT = outFPM_file_input;
    		}

    		public static String getOUTFIELDS_FILE_OUTPUT() {
    			return OUTFIELDS_FILE_OUTPUT;
    		}

    		public void setOUTFIELDS_FILE_OUTPUT(String outfields_file_output) {
    			OUTFIELDS_FILE_OUTPUT = outfields_file_output;
    		}

    		public static String getOUTVALUES_FILE_OUTPUT() {
    			return OUTVALUES_FILE_OUTPUT;
    		}

    		public void setOUTVALUES_FILE_OUTPUT(String outvalues_file_output) {
    			OUTVALUES_FILE_OUTPUT = outvalues_file_output;
    		}

    		public static String getSQLCMD_FILE_OUTPUT() {
    			return SQLCMD_FILE_OUTPUT;
    		}

    		public void setSQLCMD_FILE_OUTPUT(String sqlcmd_file_output) {
    			SQLCMD_FILE_OUTPUT = sqlcmd_file_output;
    		}
    		public static String getOUTDB2_FILE_OUTPUT() {
    			return OUTDB2_FILE_OUTPUT;
    		}
    		public static void setOUTDB2_FILE_OUTPUT(String outdb2_file_output) {
    			OUTDB2_FILE_OUTPUT = outdb2_file_output;
    		}
    		public static String getCartellaConf() {
    			return CARTELLA_CONF;
    		}

    		public void setCartellaConf(String CARTELLA_CONF) {
    			this.CARTELLA_CONF = CARTELLA_CONF;
    		}

    		public static String getOUTFPM_FILE_INPUT_D() {
    			return OUTFPM_FILE_INPUT_D;
    		}
    		
    		public void setOUTFPM_FILE_INPUT_D(String outFPM_file_input_D) {
    			this.OUTFPM_FILE_INPUT_D = outFPM_file_input_D;
    		}
    		public static String getOUTREQFTP_FILE_OUTPUT() {
    			return OUTREQFTP_FILE_OUTPUT;
    		}
    		public static void setOUTREQFTP_FILE_OUTPUT(String outreqftp_file_output) {
    			OUTREQFTP_FILE_OUTPUT = outreqftp_file_output;
    		}
    		public static String getOUTPROP_FILE() {
    			return OUTPROP_FILE;
    		}
    		public static void setOUTPROP_FILE(String outprop_file) {
    			OUTPROP_FILE = outprop_file;
    		}
    		public static String getAREA() {
    			return AREA;
    		}
    		public static void setAREA(String area) {
    			AREA = area;
    		}
    		public static String getFREQUENZA() {
    			return FREQUENZA;
    		}
    		public static void setFREQUENZA(String frequenza) {
    			FREQUENZA = frequenza;
    		}
    		public static String getTIPO() {
    			return TIPO;
    		}
    		public static void setTIPO(String tipo) {
    			TIPO = tipo;
    		}







}