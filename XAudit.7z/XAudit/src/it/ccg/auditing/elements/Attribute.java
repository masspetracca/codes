package it.ccg.auditing.elements;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="Attribute")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"name", "value"})
public class Attribute {
	@XmlAttribute(name="name")
	private String name;
	
	@XmlAttribute(name="value")
	private String value;
	
	public Attribute(){
		name="";
		value="";
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
	
}
