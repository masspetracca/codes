package it.ccg.auditing.elements;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="List")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"type","container","attribute","obj","conpoundAttribute"})
public class List {
	@XmlAttribute(name="type")
	private String type;
	@XmlElement(name="Container")
	private java.util.List<Container> container;
	@XmlElement(name="Attribute")
	private java.util.List<Attribute> attribute;
	@XmlElement(name="Obj")
	private java.util.List<Obj> obj;
	@XmlElement(name="ConpoundAttribute")
	private java.util.List<ConpoundAttribute> conpoundAttribute;
	
	public List(){
		type ="";
		container = new ArrayList<Container>();
		attribute = new ArrayList<Attribute>();
		obj = new ArrayList<Obj>();
		conpoundAttribute = new ArrayList<ConpoundAttribute>();
	}
	
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the container
	 */
	public java.util.List<Container> getContainer() {
		return container;
	}
	/**
	 * @param container the container to set
	 */
	public void setContainer(java.util.List<Container> container) {
		this.container = container;
	}
	/**
	 * @return the attribute
	 */
	public java.util.List<Attribute> getAttribute() {
		return attribute;
	}
	/**
	 * @param attribute the attribute to set
	 */
	public void setAttribute(java.util.List<Attribute> attribute) {
		this.attribute = attribute;
	}
	/**
	 * @return the obj
	 */
	public java.util.List<Obj> getObj() {
		return obj;
	}
	/**
	 * @param obj the obj to set
	 */
	public void setObj(java.util.List<Obj> obj) {
		this.obj = obj;
	}
	/**
	 * @return the conpoundAttribute
	 */
	public java.util.List<ConpoundAttribute> getConpoundAttribute() {
		return conpoundAttribute;
	}
	/**
	 * @param conpoundAttribute the conpoundAttribute to set
	 */
	public void setConpoundAttribute(
			java.util.List<ConpoundAttribute> conpoundAttribute) {
		this.conpoundAttribute = conpoundAttribute;
	}
}
