package it.ccg.infoprovider.server.bean.providermanager;


import it.ccg.infoprovider.server.bean.eao.InstrumentsEAOLocal;
import it.ccg.infoprovider.server.bean.entity.InstrumentsEntity;
import it.ccg.infoprovider.server.service.file.factory.ReutersNIR_XMLRequestFactory;
import it.ccg.infoprovider.server.service.ftp.FTPFactory;
import it.ccg.infoprovider.server.service.ftp.FTPServiceInterface;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class ReutersManagement
 */
@Stateless
public class ReutersManagerBean implements ReutersManagerBeanLocal {
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	
	private FTPServiceInterface ftpServiceInterface;
	
	
	@EJB
	private InstrumentsEAOLocal instrumentsEAOLocal;
	
	
	

    /**
     * Default constructor. 
     */
    public ReutersManagerBean() {
        // TODO Auto-generated constructor stub
    }
    
    
    @Override
	public void checkInstrumentsAlignment() throws Exception {
		
		// TODO Auto-generated method stub
		
	}
    
    @Override
    public void updateReutersRequest() throws Exception {

    	defaultLogger.debug(new StandardLogMessage("SYSTEM", "Updating Reuters request.."));
		
    	
		List<InstrumentsEntity> enabledInstrList = this.instrumentsEAOLocal.fetchEnabled("Reuters");
		List<InstrumentsEntity> oneShotInstrList = this.instrumentsEAOLocal.fetchOneShot("Reuters");
		List<InstrumentsEntity> instrList = new ArrayList<InstrumentsEntity>();
		instrList.addAll(enabledInstrList);
		instrList.addAll(oneShotInstrList);
		
		
		defaultLogger.debug(new StandardLogMessage("SYSTEM", "Instrument list size: " + instrList.size()));
		defaultLogger.debug(new StandardLogMessage("SYSTEM", "Instrument list details: " + instrList));
		
		
		ReutersNIR_XMLRequestFactory reutersXMLRequestFactory = new ReutersNIR_XMLRequestFactory();
		File file = reutersXMLRequestFactory.createRequestFile(instrList);
		
		this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.REUTERS_SERVICE);
		
		this.ftpServiceInterface.uploadRequestFile(file.getName(), new FileInputStream(file));
		
		
		defaultLogger.debug(new StandardLogMessage("SYSTEM", "Reuters request successfully updated."));
    	
    }
    
    

}
