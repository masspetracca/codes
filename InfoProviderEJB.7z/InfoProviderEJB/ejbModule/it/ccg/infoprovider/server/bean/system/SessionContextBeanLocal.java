package it.ccg.infoprovider.server.bean.system;


import javax.ejb.Local;
import javax.ejb.SessionContext;

@Local
public interface SessionContextBeanLocal {
	
	public SessionContext getSessionContext() throws Exception;
	
}
