package it.ccg.infoprovider.server.bean.system;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class SessionContextBean
 */
@Stateless
public class SessionContextBean implements SessionContextBeanLocal {
	
	
	@Resource
	private SessionContext sessionContext;
	

    /**
     * Default constructor. 
     */
    public SessionContextBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public SessionContext getSessionContext() throws Exception {
		
		return this.sessionContext;
	}

}
