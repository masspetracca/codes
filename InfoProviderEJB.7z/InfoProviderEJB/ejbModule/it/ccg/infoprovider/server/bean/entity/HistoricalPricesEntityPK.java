package it.ccg.infoprovider.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the IFPTHISPR database table.
 * 
 */
@Embeddable
public class HistoricalPricesEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="INSTR_ID", unique=true, nullable=false)
	private int instrumentId;

	@Column(unique=true, nullable=false)
	private int priceDate;
	
	@Column(unique=true, nullable=false)
	private int priceTime = 0;
	
    public HistoricalPricesEntityPK() {
    	
    }
    
	public int getInstrumentId() {
		return this.instrumentId;
	}
	public void setInstrumentId(int instrumentId) {
		this.instrumentId = instrumentId;
	}
	public int getPriceDate() {
		return this.priceDate;
	}
	public void setPriceDate(int priceDate) {
		this.priceDate = priceDate;
	}
	public int getPriceTime() {
		return this.priceTime;
	}
	public void setPriceTime(int priceTime) {
		this.priceTime = priceTime;
	}

	public boolean equals(Object other) {
		if (this.equals( other )) {
			return true;
		}
		if (!(other instanceof HistoricalPricesEntityPK)) {
			return false;
		}
		HistoricalPricesEntityPK castOther = (HistoricalPricesEntityPK)other;
		return 
			(this.instrumentId == castOther.instrumentId)
			&& (this.priceDate == castOther.priceDate)
			&& (this.priceTime == castOther.priceTime);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.instrumentId;
		hash = hash * prime + this.priceDate;
		hash = hash * prime + this.priceTime;
		
		return hash;
    }
}