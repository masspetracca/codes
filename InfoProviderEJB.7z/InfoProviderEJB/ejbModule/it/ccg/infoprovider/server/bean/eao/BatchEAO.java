package it.ccg.infoprovider.server.bean.eao;



import it.ccg.infoprovider.server.bean.entity.BatchEntity;
import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BatchEAO
 */
@SuppressWarnings("unchecked")
@Stateless(mappedName = "BatchEAO")
public class BatchEAO implements BatchEAOLocal {

	@PersistenceContext(unitName = "InfoProviderEJB", type = PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
	
	private String tableName = ((Table)(BatchEntity.class.getAnnotation(Table.class))).name();
	
	
    /**
     * Default constructor. 
     */
    public BatchEAO() {
    	this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	@Override
	public List<BatchEntity> fetch() throws Exception {
		
		Query query = em.createNamedQuery("getAllBatches");
		List<BatchEntity> batchesList = (List<BatchEntity>)query.getResultList();
		
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
		return batchesList;
	}

	@Override
	public BatchEntity findByPrimaryKey(int batchID) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
		
		return (BatchEntity)em.find(BatchEntity.class, batchID);
	}

	@Override
	public BatchEntity add(BatchEntity batchEntity) throws Exception {
		
		em.persist(batchEntity);
		
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Persisted data into \'" + this.tableName + "\'."));
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Data: " + batchEntity));
		
		return batchEntity;
	}
	

	@Override
	public void update(BatchEntity batchEntity) throws Exception {
		
		// TODO
	}

	@Override
	public void remove(BatchEntity batchEntity) throws Exception {
		
		BatchEntity temp = findByPrimaryKey(batchEntity.getBatchId());
		
		em.remove(temp);
		
		
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Deleted data into \'" + this.tableName + "\'."));
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Data: " + batchEntity));
		
	}



}
