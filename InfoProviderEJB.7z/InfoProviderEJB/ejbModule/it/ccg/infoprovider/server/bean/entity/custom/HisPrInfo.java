package it.ccg.infoprovider.server.bean.entity.custom;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Transient;


@Entity
public class HisPrInfo implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Transient
	private int instrumentId;
	@Transient
	private String instrumentName;
	@Transient
	private int minPriceDate;
	@Transient
	private int maxPriceDate;
	@Transient
	private long count;
	
	
	public HisPrInfo() {
		super();
	}
	
	
	public HisPrInfo(int instrumentId, String instrumentName, int minPriceDate, int maxPriceDate, long count) {
		this.instrumentId = instrumentId;
		this.instrumentName = instrumentName;
		this.minPriceDate = minPriceDate;
		this.maxPriceDate = maxPriceDate;
		this.count = count;
	}
	

	public int getInstrumentId() {
		return instrumentId;
	}


	public void setInstrumentId(int instrumentId) {
		this.instrumentId = instrumentId;
	}


	public String getInstrumentName() {
		return instrumentName;
	}


	public void setInstrumentName(String instrumentName) {
		this.instrumentName = instrumentName;
	}


	public int getMinPriceDate() {
		return minPriceDate;
	}


	public void setMinPriceDate(int minPriceDate) {
		this.minPriceDate = minPriceDate;
	}


	public int getMaxPriceDate() {
		return maxPriceDate;
	}


	public void setMaxPriceDate(int maxPriceDate) {
		this.maxPriceDate = maxPriceDate;
	}


	public long getCount() {
		return count;
	}


	public void setCount(long count) {
		this.count = count;
	}
	
	
	

}
