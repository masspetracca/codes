package it.ccg.infoprovider.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the IFPTIDGEN database table.
 * 
 */
@Entity
@Table(name="IFPTIDGEN")
public class IdGeneratorEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_NAME")
	private String idName;

	@Column(name="ID_VALUE")
	private int idValue;

    public IdGeneratorEntity() {
    }

	public String getIdName() {
		return this.idName;
	}

	public void setIdName(String idName) {
		this.idName = idName;
	}

	public int getIdValue() {
		return this.idValue;
	}

	public void setIdValue(int idValue) {
		this.idValue = idValue;
	}

}