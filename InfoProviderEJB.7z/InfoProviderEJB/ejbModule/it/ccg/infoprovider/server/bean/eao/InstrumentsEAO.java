package it.ccg.infoprovider.server.bean.eao;


import it.ccg.infoprovider.server.bean.entity.InstrumentsEntity;
import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class InstrumentsEAO
 */
@SuppressWarnings("unchecked")
@Stateless(mappedName = "InstrumentsEAO")
public class InstrumentsEAO implements InstrumentsEAOLocal {

	@PersistenceContext(unitName = "InfoProviderEJB", type = PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
	
	private String tableName = ((Table)(InstrumentsEntity.class.getAnnotation(Table.class))).name();

	/**
	 * Default constructor.
	 */
	public InstrumentsEAO() {
		this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public List<InstrumentsEntity> fetch() throws Exception {

		
		Query query = em.createNamedQuery("fetchAllInstruments");
		List<InstrumentsEntity>instrumentsList = (List<InstrumentsEntity>)query.getResultList();
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
		return instrumentsList;
	}
	

	@Override
	public List<InstrumentsEntity> fetchEnabled(String provider) throws Exception {
		
		
		Query query = em.createNamedQuery("fetchEnabledInstruments");
		query.setParameter("provider", provider);
		List<InstrumentsEntity>instrumentsList = (List<InstrumentsEntity>)query.getResultList();
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
		return instrumentsList;
	}
	
	@Override
	public List<InstrumentsEntity> fetchOneShot(String provider) throws Exception {

		
		Query query = em.createNamedQuery("fetchOneShotInstruments");
		query.setParameter("provider", provider);
		List<InstrumentsEntity>instrumentsList = (List<InstrumentsEntity>)query.getResultList();

		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
		return instrumentsList;
	}
	
	

	@Override
	public InstrumentsEntity findByPrimaryKey(int instrumentID) throws Exception {
		
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
		
		return (InstrumentsEntity)em.find(InstrumentsEntity.class, instrumentID);
	}
	
	
	@Override
	public InstrumentsEntity findByRICCode(String ricCode) throws Exception {
		
		
		Query query = em.createNamedQuery("getInstrumentByRicCode");
		query.setParameter("ricCode", ricCode);
		
		InstrumentsEntity instrEntity = null;
		List<InstrumentsEntity> list = (List<InstrumentsEntity>)query.getResultList();
		if(list.size() != 0) {
			instrEntity = list.get(0);
		}
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
			
		return instrEntity;
	}
	
	@Override
	public InstrumentsEntity findByBloombergCode(String bbgCode) throws Exception {
		
		
		Query query = em.createNamedQuery("getInstrumentByBloombergCode");
		query.setParameter("bbgCode", bbgCode);
			
		InstrumentsEntity instrEntity = null;
		List<InstrumentsEntity> list = (List<InstrumentsEntity>)query.getResultList();
		if(list.size() != 0) {
			instrEntity = list.get(0);
		}
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
			
		return instrEntity;
	}
	

	@Override
	public InstrumentsEntity add(InstrumentsEntity instrEntity) throws Exception {
		
		
		em.persist(instrEntity);
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Persisted data into \'" + this.tableName + "\'."));
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Data: " + instrEntity));
		
		
		return instrEntity;
	}

	@Override
	public void update(InstrumentsEntity ie) throws Exception {
		
		// TODO
	}

	@Override
	public void remove(InstrumentsEntity instrEntity) throws Exception {
		
		
		InstrumentsEntity temp = findByPrimaryKey(instrEntity.getInstrumentId());
		
		em.remove(temp);
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Deleted data into \'" + this.tableName + "\'."));
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Data: " + temp));
		
	}
	
	
	
}
