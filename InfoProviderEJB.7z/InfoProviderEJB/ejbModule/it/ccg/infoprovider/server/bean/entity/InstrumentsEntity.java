package it.ccg.infoprovider.server.bean.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TableGenerator;


/**
 * The persistent class for the IFPTINSTR database table.
 * 
 */
@Entity
@Table(name="IFPTINSTR")
@NamedQueries({
	@NamedQuery(name="fetchAllInstruments", query="SELECT instr FROM InstrumentsEntity instr"),
	@NamedQuery(name="fetchEnabledInstruments", query="SELECT instr FROM InstrumentsEntity instr WHERE instr.provider = :provider AND instr.status = 'E'"),
	@NamedQuery(name="fetchOneShotInstruments", query="SELECT instr FROM InstrumentsEntity instr WHERE instr.provider = :provider AND instr.status = 'O'"),
	@NamedQuery(name="getInstrumentByRicCode", query="SELECT instr FROM InstrumentsEntity instr WHERE instr.reutersIdentifierCode = :ricCode"),
	@NamedQuery(name="getInstrumentByBloombergCode", query="SELECT instr FROM InstrumentsEntity instr WHERE instr.bloombergCode = :bbgCode")
})
public class InstrumentsEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.TABLE, generator="ID_INSTR_TABLE_GENERATOR")
	@TableGenerator (name="ID_INSTR_TABLE_GENERATOR", table="IFPTIDGEN", pkColumnName="ID_NAME", valueColumnName="ID_VALUE", pkColumnValue="USER_SEQUENCE")
	@Column(name="INSTR_ID", unique=true, nullable=false)
	private int instrumentId;
	
	@Column(name="BLOOMBCODE", length=30)
	private String bloombergCode;
	
	@Column(length=30)
	private String classCode;

	@Column(length=3)
	private String currency;

	@Column(name="INSTRNAME", length=255)
	private String instrumentName;

	@Column(name="INSTRSTYPE", length=30)
	private String instrumentSubtype;

	@Column(name="INSTRTYPE", length=30)
	private String instrumentType;

	@Column(length=12)
	private String isinCode;

	@Column(length=30)
	private String marketCode;

	@Column(length=5000)
	private String note;

	@Column(name="RICCODE", length=30)
	private String reutersIdentifierCode;

	@Column(name="SGMCODE", length=30)
	private String segmentCode;

	@Column(nullable=false, length=1)
	private String status;

	@Column(name="PROVIDER", nullable=true, length=30)
	private String provider;
	
	@Column(name="DATATYPE", nullable=true, length=250)
	private String dataType;
	
	@Column(name="UPDDATE", nullable=false)
	private Timestamp updateDate = new Timestamp(new Date().getTime());

	@Column(name="UPDTYPE", nullable=false, length=1)
	private String updateType = "C";

	@Column(name="UPDUSR", nullable=false, length=30)
	private String updatingUser = "SYSTEM";

    public InstrumentsEntity() {
    }

	public int getInstrumentId() {
		return this.instrumentId;
	}

	public void setInstrumentId(int instrumentId) {
		this.instrumentId = instrumentId;
	}

	public String getBloombergCode() {
		return this.bloombergCode;
	}

	public void setBloombergCode(String bloombergCode) {
		this.bloombergCode = bloombergCode;
	}

	public String getClassCode() {
		return this.classCode;
	}

	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getInstrumentName() {
		return this.instrumentName;
	}

	public void setInstrumentName(String instrumentName) {
		this.instrumentName = instrumentName;
	}

	public String getInstrumentSubtype() {
		return this.instrumentSubtype;
	}

	public void setInstrumentSubtype(String instrumentSubtype) {
		this.instrumentSubtype = instrumentSubtype;
	}

	public String getInstrumentType() {
		return this.instrumentType;
	}

	public void setInstrumentType(String instrumentType) {
		this.instrumentType = instrumentType;
	}

	public String getIsinCode() {
		return this.isinCode;
	}

	public void setIsinCode(String isinCode) {
		this.isinCode = isinCode;
	}

	public String getMarketCode() {
		return this.marketCode;
	}

	public void setMarketCode(String marketCode) {
		this.marketCode = marketCode;
	}

	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getReutersIdentifierCode() {
		return this.reutersIdentifierCode;
	}

	public void setReutersIdentifierCode(String reutersIdentifierCode) {
		this.reutersIdentifierCode = reutersIdentifierCode;
	}

	public String getSegmentCode() {
		return this.segmentCode;
	}

	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateType() {
		return this.updateType;
	}

	public void setUpdateType(String updateType) {
		this.updateType = updateType;
	}

	public String getUpdatingUser() {
		return this.updatingUser;
	}

	public void setUpdatingUser(String updatingUser) {
		this.updatingUser = updatingUser;
	}

	@Override
	public String toString() {
		return "InstrumentsEntity [instrumentId=" + instrumentId
				+ ", currency=" + currency + ", instrumentName="
				+ instrumentName + ", updateDate=" + updateDate
				+ ", updateType=" + updateType + ", updatingUser="
				+ updatingUser + "]";
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

}