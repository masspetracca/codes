package it.ccg.infoprovider.server.bean.eao;



import it.ccg.infoprovider.server.bean.entity.FTPFileEntity;
import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class FTPFileEAO
 */
@SuppressWarnings("unchecked")
@Stateless(mappedName = "FTPFileEAO")
public class FTPFileEAO implements FTPFileEAOLocal {

	@PersistenceContext(unitName = "InfoProviderEJB", type = PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
	
	private String tableName = ((Table)(FTPFileEntity.class.getAnnotation(Table.class))).name();
	
    /**
     * Default constructor. 
     */
    public FTPFileEAO() {
    	this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		try {
			this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	@Override
	public List<FTPFileEntity> fetch() throws Exception {
		
		Query query = em.createNamedQuery("fetchAllFtpFiles");
		
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
		
		return (List<FTPFileEntity>)query.getResultList();
	}

	@Override
	public FTPFileEntity findByPrimaryKey(int fileId) throws Exception {
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
		
		return (FTPFileEntity) em.find(FTPFileEntity.class, fileId);
	}
	
	
	@Override
	public FTPFileEntity findByName(String fileName) throws Exception {
		
		Query query = em.createNamedQuery("fetchByName");
		query.setParameter("fileName", fileName);
		
		FTPFileEntity fileEntity = null;
		List<FTPFileEntity> list = (List<FTPFileEntity>)query.getResultList();
		if(list.size() != 0) {
			fileEntity = list.get(0);
		}
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Fetched data from \'" + this.tableName + "\'."));
		
		
		return fileEntity;
	}
	

	@Override
	public FTPFileEntity add(FTPFileEntity fileEntity) throws Exception {
		em.persist(fileEntity);
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Persisted data into \'" + this.tableName + "\'."));
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Data: " + fileEntity));
		
		
		return fileEntity;
	}


	@Override
	public void update(FTPFileEntity fileEntity) throws Exception {
		
		// TODO
	}

	@Override
	public void remove(FTPFileEntity fileEntity) throws Exception {
		
		FTPFileEntity temp = findByPrimaryKey(fileEntity.getFileId());
		
		em.remove(temp);
		
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Deleted data into \'" + this.tableName + "\'."));
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Data: " + fileEntity));
		
	}

}
