package it.ccg.infoprovider.server.util;

public class StandardLogMessage {
	
	private String user;
	private String message;
	
	public StandardLogMessage(String user, String message) {
		this.user = user;
		this.message = message;
	}
	
	
	@Override
	public String toString() {
		
		return "User: " + this.user + "|" + this.message;
	}

}
