package it.ccg.infoprovider.server.service.file.parser;


import it.ccg.infoprovider.server.service.file.template.BloombergResponseFileMapping;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BloombergResponseParser {
	
	
	private File dataFile = null;
	
	
	
	
	public BloombergResponseParser(File dataFile) {
		this.dataFile = dataFile;
	}
	
	
	public BloombergResponseFileMapping parse() {
		
		if(this.dataFile == null) {
			try {
				throw new Exception("BloombergResponseParser not initialized. You must call the \'public BloombergResponseParser(File dataFile)\' constructor before.");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return null;
		}
		
			
		// apro lo stream per leggere il file
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(dataFile));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		// marker at beginning of file
		try {
			br.mark((int)(dataFile.length() / 2));  // /2 because chat type is 16 bit in java
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		Map<String, String> header = getHeader(br);
		List<String> fields = getFields(br);
		Object timeStarted = getTimeStarted(br);
		List<Object[]> data = getData(br);
		Object timeFinished = getTimeFinished(br);
		
			
		/*while(!line.startsWith("END-OF-FILE")) {
			line = br.readLine();
		}*/
			
			
		try {
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		BloombergResponseFileMapping bloombergResponseFileMapping = new BloombergResponseFileMapping(header, fields, timeStarted, data, timeFinished);
		
		
		return bloombergResponseFileMapping;
	}
	
	
	
	private Map<String, String> getHeader(BufferedReader br) {
		
		Map<String, String> header = new HashMap<String, String>();
		
		// leggo riga per riga
		String line = null;
		try {
			
			// pointer at beginning of file
			br.reset();
			
			line = br.readLine();
			// 
			while(!line.equalsIgnoreCase("START-OF-FILE")) {
				line = br.readLine();
			}
			
			line = br.readLine(); // prima riga dell'header section
			while(!line.equalsIgnoreCase("START-OF-FIELDS")) {
				if(!isCommentOrEmptyLine(line)) {
					
					header.put((line.split("="))[0].trim(), (line.split("="))[1].trim());
				}
				
				line = br.readLine();
			}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return header;
	}
	
	private List<String> getFields(BufferedReader br) {
		
		List<String> fields = new ArrayList<String>();
		
		// leggo riga per riga
		String line = null;
		try {
			
			// pointer at beginning of file
			br.reset();
			

			line = br.readLine();
			// 
			while(!line.equalsIgnoreCase("START-OF-FIELDS")) {
				line = br.readLine();
			}
			
			line = br.readLine(); // prima riga della fields section
			while(!line.equalsIgnoreCase("END-OF-FIELDS")) {
				if(!isCommentOrEmptyLine(line)) {
					fields.add(line.trim());
				}
				
				line = br.readLine();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return fields;
	}
	
	private Object getTimeStarted(BufferedReader br) {
		
		Object timeStarted = null;
		
		String line = null;
		try {
			
			// pointer at beginning of file
			br.reset();
			
			line = br.readLine();
			while(!line.startsWith("TIMESTARTED")) {
				line = br.readLine();
			}
			//
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		timeStarted = line != null ? (line.split("="))[1].trim() : null;
		
		
		return timeStarted;
	}
	
	private List<Object[]> getData(BufferedReader br) {
		
		List<Object[]> data = new ArrayList<Object[]>();
		
		// leggo riga per riga
		String line = null;
		try {
			
			// pointer at beginning of file
			br.reset();
			
			line = br.readLine();
			while(!line.startsWith("START-OF-DATA")) {
				line = br.readLine();
			}
			
			line = br.readLine(); // prima riga della data section
			while(!line.startsWith("END-OF-DATA")) {
				if(!isCommentOrEmptyLine(line)) {
					
					Object[] temp = line.split("\\|");
					
					for(Object obj : temp) {
						obj = ((String)obj).trim();
					}
					
					data.add(temp);
				}
				
				line = br.readLine();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return data;
	}
	
	private Object getTimeFinished(BufferedReader br) {

		Object timeFinished = null;
		
		String line = null;
		try {
			line = br.readLine();
			
			while(!line.startsWith("TIMEFINISHED")) {
				line = br.readLine();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//
		timeFinished = line != null ? (line.split("="))[1].trim() : null;
		
		
		return timeFinished;
	}
	
	
	private boolean isCommentOrEmptyLine(String line) {
		
		return (line.startsWith("#")) || (line.trim().length() == 0);
	}
	
	
	
}
