package it.ccg.infoprovider.server.service.system;

import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

import sun.reflect.Reflection;

public class LocalBeanLookup {
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	
	public static Object lookup(String beanLocalInterfaceCompleteName) {
		String initialContextFactory = "com.ibm.websphere.naming.WsnInitialContextFactory";  
        String providerUrl = "corbaloc:iiop:localhost:2809";  
        
        Hashtable<String, String> environment = new Hashtable<String, String>();  
        environment.put(Context.INITIAL_CONTEXT_FACTORY, initialContextFactory);  
        environment.put(Context.PROVIDER_URL, providerUrl); 
        
        Object object = null;
        
        try {  
            Context ctx = new InitialContext(environment); 
            
            object = ctx.lookup("ejblocal:" + beanLocalInterfaceCompleteName);
            
            
            defaultLogger.debug(new StandardLogMessage("SYSTEM", "Caller class: \'" + Reflection.getCallerClass(2) + "\'  ##  Instance of \'" + beanLocalInterfaceCompleteName + "\' looked up."));
        } 
        catch(NamingException e) {  
        	defaultLogger.debug(new StandardLogMessage("SYSTEM", e.toString()));
        	defaultLogger.debug(new StandardLogMessage("SYSTEM", e.getMessage()));
            
            defaultLogger.debug(new StandardLogMessage("SYSTEM", "Unable to lookup an instance of \'" + beanLocalInterfaceCompleteName + "\'."));
        }
        
		
		return object;
	}

}
