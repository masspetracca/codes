package it.ccg.infoprovider.server.service.ftp;


import it.ccg.infoprovider.server.bean.system.SessionContextBeanLocal;
import it.ccg.infoprovider.server.service.system.LocalBeanLookup;
import it.ccg.infoprovider.server.service.system.SystemProperties;
import it.ccg.infoprovider.server.util.StandardLogMessage;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.log4j.Logger;


public class FTPServiceBloomberg implements FTPServiceInterface {
	
	private FTPClient ftpClient;
	
	private static Properties properties;
	
	private static final Logger defaultLogger = Logger.getLogger("it.ccg.infoprovider.server.defaultLogger");
	
	private SessionContextBeanLocal sessionContextBeanLocal;
	
	private String currentUser;
	
	
	private static final String URL = "bloombergServerUrl";
	private static final String USERNAME = "bloombergUserName";
	private static final String PASSWD = "bloombergPasswd";
	private static final String WORKING_DIR = "bloombergWorkingDir";
	

	public FTPServiceBloomberg() throws Exception {
		
		properties = SystemProperties.getProperties();
		
		this.ftpClient = new FTPClient();
		
		this.sessionContextBeanLocal = (SessionContextBeanLocal)LocalBeanLookup.lookup(SessionContextBeanLocal.class.getName());
		this.currentUser = this.sessionContextBeanLocal.getSessionContext().getCallerPrincipal().getName();
		
	}
	
	
	private void openConnection() throws Exception {
		
		this.ftpClient.connect(properties.getProperty(FTPServiceBloomberg.URL));
		
		if(this.ftpClient.isConnected()) {
			defaultLogger.debug("Connected to \'" + properties.getProperty(FTPServiceBloomberg.URL) + "\' ..");
			
			if(this.ftpClient.login(properties.getProperty(FTPServiceBloomberg.USERNAME), properties.getProperty(FTPServiceBloomberg.PASSWD))) {
				defaultLogger.debug(new StandardLogMessage(this.currentUser, "User \'" + properties.getProperty(FTPServiceBloomberg.USERNAME) + "\' logged in.."));
			}
			else {
				defaultLogger.error(new StandardLogMessage(this.currentUser, "Authentication of user \'" + properties.getProperty(FTPServiceBloomberg.USERNAME) + "\' failed."));
				
				throw new Exception(new StandardLogMessage(this.currentUser, "Authentication of user \'" + properties.getProperty(FTPServiceBloomberg.USERNAME) + "\' failed.").toString());
			}
		}
		else {
			defaultLogger.error(new StandardLogMessage(this.currentUser, "Connection to \'" + properties.getProperty(FTPServiceBloomberg.URL) + "\' failed."));
			
			throw new Exception("Connection to \'" + properties.getProperty(FTPServiceBloomberg.URL) + "\' failed.");
		}
	}
	
	
	private void closeConnection() throws Exception {
		this.ftpClient.logout();
		
		if(this.ftpClient.isConnected()) {
			this.ftpClient.disconnect();
		}
		
		if(this.ftpClient.isConnected()) {
			
			defaultLogger.warn(new StandardLogMessage(this.currentUser, "Unable to disconnect from \'" + properties.getProperty(FTPServiceBloomberg.URL) + "\'. Connection will be closed by server.."));
		}
		else {
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Disconnected from \'" + properties.getProperty(FTPServiceBloomberg.URL) + "\'."));
		}
	}
	
	
	@Override
	public FTPFile getResponseFileInfo(String fileName) throws Exception {
		
		if(!responseFileIsPresent(fileName)) {
			defaultLogger.error(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' not found."));
			
			throw new Exception(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' not found.").toString());
		}
		
		
		this.openConnection();
		
		this.changeWorkingDir(properties.getProperty(FTPServiceBloomberg.WORKING_DIR));
		
		FTPFile fileInfo = null;
		
		FTPFile[] fileList = this.ftpClient.listFiles();
		
		for(FTPFile file : fileList) {
			if(file.getName().equalsIgnoreCase(fileName)) {
				fileInfo = file;
				
				defaultLogger.debug(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' info successfully downloaded."));
				
				break;
			}
		}
		
		this.closeConnection();
		
		return fileInfo;
	}
	
	
	@Override
	public FTPFile[] getResponseFilesInfo() throws Exception {
		this.openConnection();
		
		this.changeWorkingDir(properties.getProperty(FTPServiceBloomberg.WORKING_DIR));
		
		FTPFile[] filesInfo = ftpClient.listFiles();
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Files info successfully downloaded."));
		
		this.closeConnection();
		
		return filesInfo;
	}
	
	
	@Override
	public void downloadResponseFile(String fileName, FileOutputStream outStream) throws Exception {
		
		if(!responseFileIsPresent(fileName)) {
			defaultLogger.error(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' not found."));
			
			throw new Exception(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' not found.").toString());
		}
		else {
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' found."));
		}
		
		this.downloadFile(fileName, outStream);
	}
	
	@Override
	public void downloadRequestFile(String fileName, FileOutputStream outStream) throws Exception {
		
		if(!requestFileIsPresent(fileName)) {
			defaultLogger.error(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' not found."));
			
			throw new Exception(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' not found.").toString());
		}
		else {
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' found."));
		}
		
		this.downloadFile(fileName, outStream);
	}
	
	
	@Override
	public void uploadRequestFile(String fileName, FileInputStream inputStream) throws Exception {
		this.openConnection();
		
		this.changeWorkingDir(properties.getProperty(FTPServiceBloomberg.WORKING_DIR));
		
		boolean result =  ftpClient.storeFile(fileName, inputStream);
		
		if(result) {
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' successfully uploaded."));
			
			this.closeConnection();
		}
		else {
			defaultLogger.error(new StandardLogMessage(this.currentUser, "Unable to upload file \'" + fileName + "\'."));
			
			this.closeConnection();
			
			throw new Exception(new StandardLogMessage(this.currentUser, "Unable to upload file \'" + fileName + "\'.").toString());
		}
	}
	
	
	@Override
	public boolean responseFileIsPresent(String fileName) throws Exception {
		this.openConnection();
		
		this.changeWorkingDir(properties.getProperty(FTPServiceBloomberg.WORKING_DIR));
		
		boolean result = false;
		
		FTPFile[] fileList = this.ftpClient.listFiles();
		
		for(FTPFile file : fileList) {
			if(file.getName().equalsIgnoreCase(fileName)) {
				result = true;
				
				break;
			}
		}
		
		this.closeConnection();
		
		return result;
	}
	
	@Override
	public boolean requestFileIsPresent(String fileName) throws Exception {
		this.openConnection();
		
		defaultLogger.debug(new StandardLogMessage(this.currentUser, "Searching file \'" + fileName + "\'.."));
		
		this.changeWorkingDir(properties.getProperty(FTPServiceBloomberg.WORKING_DIR));
		
		boolean result = false;
		
		FTPFile[] fileList = this.ftpClient.listFiles();
		
		for(FTPFile file : fileList) {
			if(file.getName().equalsIgnoreCase(fileName)) {
				result = true;
				
				break;
			}
		}
		
		this.closeConnection();
		
		return result;
	}
	
	
	
	private void downloadFile(String fileName, FileOutputStream outStream) throws Exception {
		
		this.openConnection();
		
		this.changeWorkingDir(properties.getProperty(FTPServiceBloomberg.WORKING_DIR));
		
		boolean result = ftpClient.retrieveFile(fileName, outStream);
		
		if(result) {
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "File \'" + fileName + "\' successfully downloaded."));
			
			this.closeConnection();
		}
		else {
			defaultLogger.error(new StandardLogMessage(this.currentUser, "Unable to download file \'" + fileName + "\'."));
			
			this.closeConnection();
			
			throw new Exception(new StandardLogMessage(this.currentUser, "Unable to download file \'" + fileName + "\'.").toString());
		}
		
	}
	
	
	private void changeWorkingDir(String workingDir) throws Exception {
		
		if(!this.ftpClient.changeWorkingDirectory(workingDir)){
			defaultLogger.error(new StandardLogMessage(this.currentUser, "Unable to change working directory."));
			
			this.closeConnection();
			
			throw new Exception(new StandardLogMessage(this.currentUser, "Unable to change working directory.").toString());
		}
		else {
			defaultLogger.debug(new StandardLogMessage(this.currentUser, "Working directory changed to \'"+ workingDir +"\'."));
		}
		
	}
	
	
}
