package it.ccg.irifpejb.smartgwt.server.dmi;

import it.ccg.irifpejb.server.system.LocalBeanLookup;

public class BankDmiEAOFactory {
	
	
	public BankDmiEAOFactory() {
		
	}
	
	
	
	public BankDmiEAOLocal create() throws Exception {

		BankDmiEAOLocal instrDmiEAOLocal = (BankDmiEAOLocal)LocalBeanLookup.lookup(BankDmiEAOLocal.class.getName());
		
		return instrDmiEAOLocal;
	}

}
