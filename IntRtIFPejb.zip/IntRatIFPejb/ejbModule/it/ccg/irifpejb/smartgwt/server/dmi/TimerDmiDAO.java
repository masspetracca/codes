package it.ccg.irifpejb.smartgwt.server.dmi;

import it.ccg.irifpejb.server.bean.JobDTO;
import it.ccg.irifpejb.server.bean.JobManagerBeanLocal;
import it.ccg.irifpejb.server.bean.TimerBeanLocal;
import it.ccg.irifpejb.server.bean.TimerDTO;
import it.ccg.irifpejb.server.logengine.LoggerFactory;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;
import com.isomorphic.util.ErrorMessage;



/**
 * Session Bean implementation class TimerManagerEAO
 */
@Stateless
public class TimerDmiDAO implements TimerDmiDAOLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@EJB
	private TimerBeanLocal timerBeanLocal;
	
	@EJB
	private JobManagerBeanLocal jobManagerBeanLocal;


    /**
     * Default constructor. 
     */
    public TimerDmiDAO() {
    	
    }
    
    
	@Override
	public DSResponse fetch(DSRequest dsRequest) throws Exception {
		
		DSResponse dsResponse = new DSResponse();
		
		
		List<TimerDTO> timerList = this.timerBeanLocal.getAllTimers();
		
		dsResponse.setData(timerList);
		
		
		return dsResponse;
	}

	
	@Override
	public Object add(DSRequest dsRequest) throws Exception {
		
		
		Object resultObject = null;
		
		@SuppressWarnings("unchecked")
		Map<String, Object> valueMap = dsRequest.getValues();
		
		TimerDTO tempTimerDTO = null;
		
		JobDTO jobDTO = this.getJobDTO(valueMap);
		
			
		if((Boolean)valueMap.get("isSingle")) {
			
			TimerDTO timerDTO = new TimerDTO((String)valueMap.get("name"), (Boolean)valueMap.get("isSingle"), (Date)valueMap.get("startDateTime"), (String)valueMap.get("provider"), jobDTO);
			
			tempTimerDTO = this.timerBeanLocal.createSingleActionTimer(timerDTO);
		}
		else {
			
			TimerDTO timerDTO = new TimerDTO((String)valueMap.get("name"), (Boolean)valueMap.get("isSingle"), (Date)valueMap.get("startDateTime"), (Long)valueMap.get("interval"), (String)valueMap.get("provider"), jobDTO);
			
			tempTimerDTO = this.timerBeanLocal.createTimer(timerDTO);
		}
		
		
		if(tempTimerDTO == null) {
			DSResponse dsResponse = new DSResponse();
			dsResponse.addError("name", new ErrorMessage("Timer \'" + (String)valueMap.get("name") + "\' already exists."));
			
			resultObject = dsResponse;
		}
		else {
			resultObject = tempTimerDTO;
		}
		
		
		return resultObject;
	}

	
	@Override
	public Object update(DSRequest dsRequest) throws Exception {
		
		throw new Exception("Method 'update' not implemented.");
	}

	
	@Override
	public Object remove(DSRequest dsRequest) throws Exception {
		
		@SuppressWarnings("unchecked")
		Map<String, Object> oldValueMap = dsRequest.getOldValues();
		
		String timerName = (String)oldValueMap.get("name");
		
		this.timerBeanLocal.deleteTimer(timerName);
		
		
		TimerDTO removedTimerDTO = new TimerDTO();
		removedTimerDTO.setName(timerName);
		
		
		return removedTimerDTO;
	}
	
	
	@Override
	public Object removeAll(DSRequest dsRequest) throws Exception {
		
		DSResponse dsResponse = new DSResponse();
		
		
		this.timerBeanLocal.deleteAllTimers();
		
		
		return dsResponse;
	}
	
	
	
	
	
	// **********************************************************************************
	// PRIVATE
	// **********************************************************************************
	
	
	private JobDTO getJobDTO(Map<String, Object> valueMap) throws Exception {
		
		String jobName = (String)valueMap.get("jobName");
		
		return this.jobManagerBeanLocal.getJobByName(jobName);
	}

	
}
