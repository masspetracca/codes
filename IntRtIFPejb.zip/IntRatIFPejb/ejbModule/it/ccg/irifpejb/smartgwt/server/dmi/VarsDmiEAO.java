package it.ccg.irifpejb.smartgwt.server.dmi;



import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.smartgwt.server.util.DmiEAOUtil;
import it.ccg.irifpejb.smartgwt.server.util.JpaQuery;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;



/**
 * Session Bean implementation class HisPrDmiCmtEAO
 */
@Stateless
public class VarsDmiEAO implements VarsDmiEAOLocal {
	
	@PersistenceContext(unitName="IntRatIFPejb", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	
    /**
     * Default constructor. 
     */
    public VarsDmiEAO() {
    	
    }
    
    
    @Override
	public DSResponse fetch(DSRequest dsRequest) throws Exception {
		
    	JpaQuery jpaQuery = new JpaQuery("SELECT new Vars(v.id.varid, v.vardesc)", "FROM it.ccg.irifpejb.server.bean.entity.VarsEntity v", "", "", "", "");
		
		
		JpaQuery filteredJpaQuery = DmiEAOUtil.getFilteredQuery(jpaQuery, dsRequest);
		
    	logger.info(new StandardLogMessage("query: " + filteredJpaQuery.toString()));
    	
    	
		return DmiEAOUtil.executeQuery(filteredJpaQuery, dsRequest, this.em);
	}
	
	
}
