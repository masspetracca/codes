package it.ccg.irifpejb.server.bean.business;


import it.ccg.irifpejb.server.bean.entity.VarHEntity;

import java.io.File;
import java.util.List;

import javax.ejb.Local;

@Local
public interface BaseBeanLocal {

	/*public void persistHistoricalData(List<HisPrEntity> hisPrEntityList) throws Exception;
	public void updateOneShotToDisable(List<HisPrEntity> hisPrEntityList) throws Exception;*/
	
	public void saveJobInfo(String provider, String batchDesc, List<VarHEntity> varHEntityList, String fileName, String fileAbsPath) throws Exception;
	
	public void deleteTempWorkingFolder(File tempWorkingFolder) throws Exception;
	
}
