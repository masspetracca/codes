package it.ccg.irifpejb.server.bean.eao;


import it.ccg.irifpejb.server.bean.entity.BankEntity;

import java.util.List;

import javax.ejb.Local;

@Local
public interface BankEAOLocal {

	public List<BankEntity> fetch() throws Exception;
	public BankEntity findByPrimaryKey(int instrumentID) throws Exception;
	public BankEntity findByFitchCode(String ficthCode) throws Exception;
	
	public void add(BankEntity be) throws Exception;
	public BankEntity update(BankEntity be) throws Exception;
	public void remove(BankEntity be) throws Exception;
	
}
