package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RCTTHRSHLD database table.
 * 
 */
@Embeddable
public class ThrshldEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=255)
	private int varid;

	@Column(unique=true, nullable=false, length=255)
	private String thrsholdid;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(unique=true, nullable=false)
	private java.util.Date thrshlddte;

    public ThrshldEntityPK() {
    }
	public int getVarid() {
		return this.varid;
	}
	public void setVarid(int varid) {
		this.varid = varid;
	}
	public String getThrsholdid() {
		return this.thrsholdid;
	}
	public void setThrsholdid(String thrsholdid) {
		this.thrsholdid = thrsholdid;
	}
	public java.util.Date getThrshlddte() {
		return this.thrshlddte;
	}
	public void setThrshlddte(java.util.Date thrshlddte) {
		this.thrshlddte = thrshlddte;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ThrshldEntityPK)) {
			return false;
		}
		ThrshldEntityPK castOther = (ThrshldEntityPK)other;
		return 
			this.varid ==(castOther.varid)
			&& this.thrsholdid.equals(castOther.thrsholdid)
			&& this.thrshlddte.equals(castOther.thrshlddte);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.varid;
		hash = hash * prime + this.thrsholdid.hashCode();
		hash = hash * prime + this.thrshlddte.hashCode();
		
		return hash;
    }
}