package it.ccg.irifpejb.server.bean.eao;

import it.ccg.irifpejb.server.bean.entity.VarsEntity;

import java.util.List;

public interface VarsEAOLocal {
	
	public List<VarsEntity> fetch() throws Exception;

}
