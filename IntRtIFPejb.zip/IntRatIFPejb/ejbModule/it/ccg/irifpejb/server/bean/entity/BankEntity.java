package it.ccg.irifpejb.server.bean.entity;

import it.ccg.irifpejb.server.security.SecurityEjb;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


/**
 * The persistent class for the RCTBANK database table.
 * 
 */
@Entity
@Table(name="PAMPTEST.RCTBANK")
@NamedQueries({
	
	@NamedQuery(name="getAllBanks", query="SELECT bank FROM BankEntity bank"),
	
	@NamedQuery(name="getBankByAbicode", query="SELECT bank FROM BankEntity bank WHERE bank.abicode= :abicode ORDER BY bank.bankname ASC"),
	@NamedQuery(name="getBankByFitchCode", query="SELECT bank FROM BankEntity bank WHERE bank.fitchcode= :fitchcode ORDER BY bank.bankname ASC"),
	@NamedQuery(name="getBankByBloombCode", query="SELECT bank FROM BankEntity bank WHERE bank.bloombcode= :bloombcode ORDER BY bank.bankname ASC"),
	@NamedQuery(name="getBankByName", query="SELECT bank FROM BankEntity bank WHERE bank.bankname like :bankname ORDER BY bank.bankname ASC"),
	@NamedQuery(name="getBankByStatus", query="SELECT bank FROM BankEntity bank WHERE bank.status = :status ORDER BY bank.bankname ASC")
})
public class BankEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private int bankid;

	@Column(nullable=false, length=255)
	private String bankname;
	
	@Column(length=20)
	private String abicode;

	@Column(length=20)
	private String bloombcode;

	@Column(length=30)
	private String country;

	@Column(nullable=false, length=1)
	private String ctp;

	@Column(length=20)
	private String fitchcode;

	@Column(length=10)
	private String parbnkblcd;

	@Column(length=10)
	private String parbnkname;

	@Column(length=10)
	private String parbnktick;

	@Column(nullable=false, length=1)
	private String participnt;

	@Column(nullable=false, length=1)
	private String status;

	@Column(nullable=false)
	private Timestamp upddate = new Timestamp(System.currentTimeMillis());

	@Column(nullable=false, length=1)
	private String updtype = "C";

	@Column(nullable=false, length=30)
	private String updusr = SecurityEjb.getCurrentUser();

	

	/*//bi-directional many-to-one association to RctIfpRtghEntity
	@OneToMany(mappedBy="rctbank")
	private Set<RctIfpRtgHEntity> rctifprtghs;

	//bi-directional one-to-one association to RctRatingEntity
	@OneToOne(mappedBy="rctbank")
	private RctRatingEntity rctrating;

	//bi-directional many-to-one association to RctRatingHEntity
	@OneToMany(mappedBy="rctbank")
	private Set<RctRatingHEntity> rctratinghs;*/

    public BankEntity() {
    }

	public int getBankid() {
		return this.bankid;
	}

	public void setBankid(int bankid) {
		this.bankid = bankid;
	}

	public String getAbicode() {
		return this.abicode;
	}

	public void setAbicode(String abicode) {
		this.abicode = abicode;
	}

	public String getBankname() {
		return this.bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getBloombcode() {
		return this.bloombcode;
	}

	public void setBloombcode(String bloombcode) {
		this.bloombcode = bloombcode;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCtp() {
		return this.ctp;
	}

	public void setCtp(String ctp) {
		this.ctp = ctp;
	}

	public String getFitchcode() {
		return this.fitchcode;
	}

	public void setFitchcode(String fitchcode) {
		this.fitchcode = fitchcode;
	}

	public String getParbnkblcd() {
		return this.parbnkblcd;
	}

	public void setParbnkblcd(String parbnkblcd) {
		this.parbnkblcd = parbnkblcd;
	}

	public String getParbnkname() {
		return this.parbnkname;
	}

	public void setParbnkname(String parbnkname) {
		this.parbnkname = parbnkname;
	}

	public String getParbnktick() {
		return this.parbnktick;
	}

	public void setParbnktick(String parbnktick) {
		this.parbnktick = parbnktick;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

	/*public Set<RctIfpRtgHEntity> getRctifprtghs() {
		return this.rctifprtghs;
	}

	public void setRctifprtghs(Set<RctIfpRtgHEntity> rctifprtghs) {
		this.rctifprtghs = rctifprtghs;
	}
	
	public RctRatingEntity getRctrating() {
		return this.rctrating;
	}

	public void setRctrating(RctRatingEntity rctrating) {
		this.rctrating = rctrating;
	}
	
	public Set<RctRatingHEntity> getRctratinghs() {
		return this.rctratinghs;
	}

	public void setRctratinghs(Set<RctRatingHEntity> rctratinghs) {
		this.rctratinghs = rctratinghs;
	}*/
	
	public String getParticipnt() {
		return participnt;
	}

	public void setParticipnt(String participnt) {
		this.participnt = participnt;
	}
	
}