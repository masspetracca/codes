package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the RCTTHRSHLD database table.
 * 
 */
@Entity
@Table(name="PAMPTEST.RCTTHRSHLD")
@NamedQueries({
	@NamedQuery(name="getThrshldByVarId", query="SELECT threshold FROM RctThrshldEntity threshold WHERE threshold.id.varid = :varid AND threshold.id.thrshlddte = (SELECT MAX(threshold.id.thrshlddte) FROM RctThrshldEntity threshold WHERE threshold.id.varid = :varid) ORDER BY threshold.thrshldop ASC"),
	@NamedQuery(name="getThrshldByThrshldDate", query="SELECT threshold FROM RctThrshldEntity threshold WHERE threshold.id.thrshlddte= :thrshlddte ORDER BY threshold.id.thrshlddte DESC"),
	@NamedQuery(name="getThrshldByThrshldId", query="SELECT threshold FROM RctThrshldEntity threshold WHERE threshold.id.thrsholdid = :thrsholdid ORDER BY threshold.id.thrshlddte DESC"),
})
public class ThrshldEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ThrshldEntityPK id;

	@Column(nullable=false)
	private double thrshldcoe;

	@Column(nullable=false, length=4)
	private String thrshldop;

	private double thrshldval;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;
	
	
	@ManyToOne
	private VarsEntity rctvar;
	

    public ThrshldEntity() {
    }

	public ThrshldEntityPK getId() {
		return this.id;
	}

	public void setId(ThrshldEntityPK id) {
		this.id = id;
	}
	
	public double getThrshldcoe() {
		return this.thrshldcoe;
	}

	public void setThrshldcoe(double thrshldcoe) {
		this.thrshldcoe = thrshldcoe;
	}

	public String getThrshldop() {
		return this.thrshldop;
	}

	public void setThrshldop(String thrshldop) {
		this.thrshldop = thrshldop;
	}

	public double getThrshldval() {
		return this.thrshldval;
	}

	public void setThrshldval(double thrshldval) {
		this.thrshldval = thrshldval;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}
	
	public VarsEntity getRctvar() {
		return rctvar;
	}
	
	public void setRctvar(VarsEntity rctvar) {
		this.rctvar = rctvar;
	}
	
}