package it.ccg.irifpejb.server.bean.eao;


import it.ccg.irifpejb.server.bean.entity.BankEntity;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class InstrumentsEAO
 */
@SuppressWarnings("unchecked")
@Stateless(mappedName = "InstrumentsEAO")
public class BankEAO implements BankEAOLocal {

	@PersistenceContext(unitName="IntRatIFPejb", type = PersistenceContextType.TRANSACTION)
	private EntityManager em;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Resource
	private SessionContext sessionContext;
	
	private String tableName = ((Table)(BankEntity.class.getAnnotation(Table.class))).name();

	/**
	 * Default constructor.
	 */
	public BankEAO() throws Exception {
		
	}
	
	
	@Override
	public List<BankEntity> fetch() throws Exception {
		
		Query query = this.em.createNamedQuery("getAllBanks");
		List<BankEntity>instrumentsList = (List<BankEntity>)query.getResultList();
		
		return instrumentsList;
	}
	
	
	@Override
	public BankEntity findByPrimaryKey(int bankID) throws Exception {
		
		return (BankEntity)this.em.find(BankEntity.class, bankID);
	}
	
	
	@Override
	public BankEntity findByFitchCode(String fitchcode) throws Exception {
		
		Query query = this.em.createNamedQuery("getBankByFitchCode");
		query.setParameter("fitchcode", fitchcode);
			
		BankEntity instrEntity = null;
		List<BankEntity> list = (List<BankEntity>)query.getResultList();
		if(list.size() != 0) {
			instrEntity = list.get(0);
		}
		
		
		return instrEntity;
	}
	

	@Override
	public void add(BankEntity instrEntity) throws Exception {
		
		// upd info
		instrEntity.setUpddate(new Timestamp(System.currentTimeMillis()));
		instrEntity.setUpdtype("C");
		instrEntity.setUpdusr(this.sessionContext.getCallerPrincipal().getName());
		
		this.em.persist(instrEntity);
		
		logger.info(new StandardLogMessage("Persisted data into \'" + this.tableName + "\'. " + instrEntity));
	}
	
	@Override
	public BankEntity update(BankEntity ie) throws Exception {
		
		BankEntity syncEntity = findByPrimaryKey(ie.getBankid());
		
		/*syncEntity.setBloombergCode(ie.getBloombergCode());
		syncEntity.setClassCode(ie.getClassCode());
		syncEntity.setCurrency(ie.getCurrency());
		syncEntity.setDataType(ie.getDataType());
		syncEntity.setInstrumentName(ie.getInstrumentName());
		syncEntity.setInstrumentSubtype(ie.getInstrumentSubtype());
		syncEntity.setInstrumentType(ie.getInstrumentType());
		syncEntity.setIsinCode(ie.getIsinCode());
		syncEntity.setMarketCode(ie.getMarketCode());
		syncEntity.setNote(ie.getNote());
		syncEntity.setProvider(ie.getProvider());
		syncEntity.setReutersIdentifierCode(ie.getReutersIdentifierCode());
		syncEntity.setSegmentCode(ie.getSegmentCode());
		syncEntity.setStatus(ie.getStatus());
		// upd info
		syncEntity.setUpdateDate(new Timestamp(System.currentTimeMillis()));
		syncEntity.setUpdateType("U");
		syncEntity.setUpdatingUser(this.sessionContext.getCallerPrincipal().getName());*/
		
		logger.info(new StandardLogMessage("Updated data into \'" + this.tableName + "\'. " + syncEntity));
		
		
		return syncEntity;
	}

	@Override
	public void remove(BankEntity instrEntity) throws Exception {
		
		BankEntity temp = findByPrimaryKey(instrEntity.getBankid());
		String tempToString = temp.toString();
		
		em.remove(temp);
		
		logger.info(new StandardLogMessage("Deleted data into \'" + this.tableName + "\'. " + tempToString));
	}
	
	
}
