package it.ccg.irifpejb.server.bean.eao;

public interface ThrshldEAOLocal {

}
