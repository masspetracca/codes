package it.ccg.irifpejb.server.bean.business;

import javax.ejb.Stateless;

/**
 * Session Bean implementation class BloombergManagerBean
 */
@Stateless
public class FitchManagerBean implements FitchManagerBeanLocal {
	
	public FitchManagerBean() {
		// TODO Auto-generated constructor stub
	}
	

	@Override
	public void checkReqAlign_BANK() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void alignReq_BANK() throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	

}
