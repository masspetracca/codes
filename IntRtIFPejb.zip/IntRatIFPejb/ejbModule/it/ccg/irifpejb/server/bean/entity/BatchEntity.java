package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the RCITBATCH database table.
 * 
 */
@Entity
@Table(name="RCITBATCH")
@NamedQueries({
	@NamedQuery(name="getAllBatches", query="SELECT batch FROM BatchEntity batch"),
	@NamedQuery(name="getLastBatchId", query="SELECT max(batch.batchId) FROM BatchEntity batch")
})
public class BatchEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.TABLE, generator="ID_BATCH_TABLE_GENERATOR")
	@TableGenerator (name="ID_BATCH_TABLE_GENERATOR", table="RCITIDGEN", pkColumnName="ID_NAME", pkColumnValue="USER_SEQUENCE", valueColumnName="ID_VALUE")
	@Column(name="BATCH_ID", unique=true, nullable=false)
	private int batchId;

	@Column(length=255)
	private String batchdesc;

	@Column(nullable=false, length=1)
	private String closemktdt;

	@Column(nullable=false, length=30)
	private String provider;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

    public BatchEntity() {
    }
    
    public BatchEntity(String provider, String batchdesc) {
    	this.provider = provider;
    	this.batchdesc = batchdesc;
    }

	public int getBatchId() {
		return this.batchId;
	}

	public void setBatchId(int batchId) {
		this.batchId = batchId;
	}

	public String getBatchdesc() {
		return this.batchdesc;
	}

	public void setBatchdesc(String batchdesc) {
		this.batchdesc = batchdesc;
	}

	public String getClosemktdt() {
		return this.closemktdt;
	}

	public void setClosemktdt(String closemktdt) {
		this.closemktdt = closemktdt;
	}

	public String getProvider() {
		return this.provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

}