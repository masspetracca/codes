package it.ccg.irifpejb.server.bean.business;

import it.ccg.irifpejb.server.bean.eao.BankEAOLocal;
import it.ccg.irifpejb.server.bean.eao.FileEAOLocal;
import it.ccg.irifpejb.server.bean.eao.VarHEAOLocal;
import it.ccg.irifpejb.server.bean.entity.BankEntity;
import it.ccg.irifpejb.server.bean.entity.VarHEntity;
import it.ccg.irifpejb.server.bean.entity.VarHEntityPK;
import it.ccg.irifpejb.server.exception.DuplicateKeyException;
import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.exception.FTPException;
import it.ccg.irifpejb.server.exception.NewDataNotAvailableException;
import it.ccg.irifpejb.server.file.parser.FitchResponseParser;
import it.ccg.irifpejb.server.file.template.FitchResponseTemplate;
import it.ccg.irifpejb.server.file.util.FitchResponseFTPFileComparator;
import it.ccg.irifpejb.server.file.util.ReutersResponseFTPFileComparator;
import it.ccg.irifpejb.server.ftp.FTPFactory;
import it.ccg.irifpejb.server.ftp.FTPServiceInterface;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.server.security.SecurityEjb;
import it.ccg.irifpejb.server.system.MailManager;
import it.ccg.irifpejb.server.system.SystemProperties;
import it.ccg.irifpejb.server.system.ZipManager;

import java.io.File;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BloombergBatchBean
 */
@Stateless
public class FitchBatchBean implements FitchBatchBeanLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	private static final Logger monitorLogger = LoggerFactory.getLogger(LoggerFactory.MONITOR_LOGGER);
	
	private static String TEMP_DIR_ABSOLUTE_PATH;
	
	private FTPServiceInterface ftpServiceInterface;
	
	@EJB
	private BankEAOLocal bankEAOLocal;
	
	@EJB
	private VarHEAOLocal varHEAOLocal;
	
	@EJB
	private FileEAOLocal fileEAOLocal;
	
	@EJB
	private BaseBeanLocal baseBeanLocal;
	
	
	public FitchBatchBean() throws Exception {
		
		try {
    		
    		TEMP_DIR_ABSOLUTE_PATH = SystemProperties.getProperty("user.install.root") +
    								 SystemProperties.getProperty("temp_dir_relative_path");
        	
    	}
    	catch(Exception e) {
    		
    		logger.warn(new StandardLogMessage("Exception into bean constructor. Exception: " + e));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
	}

	

	@Override
	public void bankBatch() throws Exception {
		
		String BATCH_DESC = "Bank variable synchronization";
		
		try {
			
			logger.info(new StandardLogMessage(BATCH_DESC + " started."));
			
			
			// TODO: 
    		//String RESPONSE_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_NIR_NAME).getResponseFileName();
			String RESPONSE_FILE_NAME = "20130823_1201.ibd.ref.usd.zip";
    		
			
			
			// create temporary folder and files to work
			// ***************************************************************************************************************
			/*String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			File tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			String tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + File.separator + RESPONSE_FILE_NAME;
			File tempFile = new File(tempFileAbsPath);
			if (!tempFile.createNewFile()) {
				
				throw new Exception("Unable to create temp file \'" + tempFileAbsPath + "\'.");
			}
			// ***************************************************************************************************************
			// get file from ftp and save it into TEMP_FILE_ABSOLUTE_PATH
			String fileName = this.getFileFromFTP(tempFileAbsPath);
			
			
			// it is a .zip file, extract it
			ZipManager.unZip(tempFileAbsPath, tempWorkingFolder.getCanonicalPath());*/
			
			
			String tempWorkingFolderName = "C:\\Users\\pcocchi\\Desktop\\fitch_file_folder";
			File tempWorkingFolder = new File(tempWorkingFolderName);
			
			// TODO:
			String dataFileAbsPath = tempWorkingFolder.getCanonicalPath() + File.separator;
			for(File file: tempWorkingFolder.listFiles()) {
				
				if(file.getName().endsWith(".fid")) {
					
					dataFileAbsPath += file.getName();
				}
			}
			
			String codesFileAbsPath = tempWorkingFolder.getCanonicalPath() + File.separator;
			for(File file: tempWorkingFolder.listFiles()) {
				
				if(file.getName().endsWith(".smt")) {
					
					codesFileAbsPath += file.getName();
				}
			}
			
			
			System.out.println("WARN - parsing");
			
			// parse file
			FitchResponseParser parser = new FitchResponseParser();
			FitchResponseTemplate fitchResponseTemplate = parser.parse(new File(dataFileAbsPath), new File(codesFileAbsPath));
			
			System.out.println("WARN - converting raw data to VarHEntity");
			
			
			// Conversion into Entity is heavy, it is implemented in round (one round --> 10000 Entity)
			//int round = 10000;
			
			//for() {
			
				List<VarHEntity> varHEntityList = this.convertRawData(fitchResponseTemplate);
				
				System.out.println("WARN - persisting");
				
				
				// persist data
				try {
					this.persistHistoricalData(varHEntityList);
				}
				catch(DuplicateKeyException e) {
					
					monitorLogger.warn(new StandardLogMessage(BATCH_DESC + " - Duplicate key values found in new data."));
				}
			
			//}
			
			// refresh varH view
			this.varHEAOLocal.refreshVarHView();
			
			
			// save information about executed batch
			// TODO: remove comment
			//this.baseBeanLocal.saveJobInfo("Fitch", "Bank data download", varHEntityList, fileName, tempFileAbsPath);
			
			
			// monitor info
			monitorLogger.info(new StandardLogMessage(BATCH_DESC + " successfully executed."));
			// default logger
			logger.info(new StandardLogMessage(BATCH_DESC + " successfully executed."));
			
			
			// delete tempWorkingFolder
			//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
			
		}
		catch(NewDataNotAvailableException e) {
			// monitor warning
			monitorLogger.warn(new StandardLogMessage(BATCH_DESC + " not completed. New data not available."));
			// default logger
			logger.warn(new StandardLogMessage(BATCH_DESC + " not completed. New data not available."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			throw new Exception(BATCH_DESC + " not completed. New data not available.");
		}
		catch(FTPException e) {
			
			// default logger
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// throw at caller
			// FTPEception is managed into caller class.
			throw e;
		}
		catch(Exception e) {
			// monitor error
			monitorLogger.error(new StandardLogMessage(BATCH_DESC + " failed."));
			// default logger
			logger.error(new StandardLogMessage(BATCH_DESC + " failed."));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// send notification mail
			MailManager mailManager = new MailManager();
			String message = BATCH_DESC + " failed.";
			mailManager.sendMail("InternalRating IFP System batch generic error", message, null);
			
			// throw at caller
			throw new Exception(BATCH_DESC + " failed.");
		}
		
		
	}
	
	
	// Getting file START ***************************************************************************************************************************************
	
    // get file from ftp and save it into tempFileAbsPath
    private String getFileFromFTP(String tempFileAbsPath) throws Exception {
    	
    	try {
	    	String fileName = null;
	    	
	    	// initialize ftpService
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.FITCH_SERVICE);
			
			// compute file name to download
			FTPFile[] fileArray = this.ftpServiceInterface.getResponseFilesInfo();
			fileName = this.getLastFileInfo(fileArray).getName();
			
			// controllo file gi� scaricato / dati gi� scaricati
			if(this.fileEAOLocal.findByName(fileName) != null) {
				
				logger.warn(new StandardLogMessage("File \'" + fileName + "\' already downloaded. New data not available."));
				
				throw new NewDataNotAvailableException("File \'" + fileName + "\' already downloaded. New data not available.");
			}
			
			// download file
			this.ftpServiceInterface.downloadResponseFile(fileName, new File(tempFileAbsPath));
	    	
			
			logger.info(new StandardLogMessage("File \'" + fileName + "\' successfully downloaded."));
			
			return fileName;
    	}
		catch(Exception e) {
			
			throw e;
		}
		
    }
    
    // Getting file END ***************************************************************************************************************************************
    
	
    // Parsing file START ***************************************************************************************************************************************
    
    // convert Reuters response data file (file data line format [ric, date, price])
    private List<VarHEntity> convertRawData(FitchResponseTemplate fitchResponseTemplate) throws Exception {
    	
    	try {
			
    		List<Object[]> data = fitchResponseTemplate.getData();
    		List<Object[]> codes = fitchResponseTemplate.getCodes();
    		
    		String accountingSystem;
    		String consolidated;
    		
    		String fitchNickname;
    		String agentCommonId;
    		
    		// get interested codes
    		// [FITCH_NICKNAME, FITCH_CODE]
    		Map<String, String> myCodes = new HashMap<String, String>();
    		for(Object[] line : codes) {
    			
    			accountingSystem = (String)line[20];
    			consolidated = (String)line[10];
    			
    			if(accountingSystem.contains("IFRS") && (consolidated.contains("Y"))) {
    				
    				fitchNickname = (String)line[7];
    				agentCommonId = (String)line[1];
    				
    				myCodes.put(fitchNickname, agentCommonId);
    			}
    		}
        	
    		
    		// get data
        	List<VarHEntity> list = new ArrayList<VarHEntity>();
    		
        	VarHEntity varHEntity;
			VarHEntityPK varHEntityPK;
			String fitchCode;
			BankEntity bankEntity;
        	
        	// for each bank
    		for(Object[] record : data) {
			// TODO: remove
        	// *****************************************
        	/*Object[] record;
        	for(int k=10; k<20; k++) {
        		
        		record = data.get(k);
        		
        		ArrayUtils.toString(record);*/
    		// *****************************************
        		
    			
    			
    			// if this is an interested line
    			if(myCodes.get((String)record[1]) != null) {
    				
    				// skip if not periodLength=12 && periodType=0
    				String periodLength = (String)record[3];
        			String periodType = (String)record[4];
        			if(!(periodLength.equalsIgnoreCase("12") && periodType.equalsIgnoreCase("0"))) {
        				
        				continue;
        			}
        			
        			
            		fitchCode = myCodes.get((String)record[1]);
    				bankEntity = this.bankEAOLocal.findByFitchCode(fitchCode);
    				
    				// 
    				String dateString = ((String)record[2]).substring(0, 10);
    				String[] comp = dateString.split("-");
    				GregorianCalendar gc = new GregorianCalendar(Integer.parseInt(comp[0]), Integer.parseInt(comp[1]) - 1, Integer.parseInt(comp[2]));
    				
    				// TODO: remove
    				//System.out.println("ERROR - " + (String)record[1] + ", " + fitchCode + ", " + dateString + ", " + gc.getTime() + ", " + new Date(gc.getTimeInMillis()));
    				
    				
    				
    				// for each variable
    				for(int i=3; i<record.length; i++) {
    					
    					// check corrupted data
    					/*if(record.length < 3) {
    						
    						logger.warn(new StandardLogMessage("Missing values in data file. Corrupted line: " + ArrayUtils.toString(record)));
    						
    						monitorLogger.warn(new StandardLogMessage("Missing values in data file. Corrupted line: " + ArrayUtils.toString(record)));
    						
    						
    						continue;
    					}*/
    					
    					varHEntity = new VarHEntity();
    					varHEntityPK = new VarHEntityPK();
    					
    					varHEntityPK.setBankid(bankEntity.getBankid());
    					varHEntityPK.setProvider("F");
    					varHEntityPK.setValuedate(gc.getTime());
    					
    					String valueString = (String)record[i];
    					if(!valueString.equalsIgnoreCase("")) {
    						
    						varHEntity.setVarvalue(new BigDecimal(valueString));
    					}
    					else {
							
    						varHEntity.setVarvalue(null);
						}
    					
    					varHEntityPK.setVarid(i - 2);
    					varHEntity.setId(varHEntityPK);
    					
    					
    					
    					
    					// *** IMPORTANT ***
    					// Check if the downloaded line matches with an instrument in my static data.
    					// IF NOT, it means i am downloading something useless and someone directly modified 
    					// Reuters request file on Reuters account folder;
    					// or i am testing some new instrument in a different environment!!!
    					/*if(instrEntity == null) {
    						
    						logger.error(new StandardLogMessage("Instrument having Reuters Code \'" + ricCode + "\' not fount in Static Data. Check StaticData/Reuters request alignment."));
    						monitorLogger.error(new StandardLogMessage("Instrument having Reuters Code \'" + ricCode + "\' not fount in Static Data. Check StaticData/Reuters request alignment."));
    						
    						continue;
    						//throw new Exception();
    					}*/
    					
    					
    					//System.out.println("DEBUG - " + varHEntity);
    					
    					
    					list.add(varHEntity);
    					
    				}
    				
					
				
    			}
				
			}
    		
    		logger.info(new StandardLogMessage("Parsing successfully completed."));
    		
    		
    		// TODO: remove
    		//System.out.println("WARN - list.size() = " + list.size());
    		

    		return list;
    	}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw new Exception("Cannot convert from raw data to VarHEntity.");
		}
		
	}
    
    // Parsing file END ***************************************************************************************************************************************
    
    
	private FTPFile getLastFileInfo(FTPFile[] fileArray) throws Exception {
		
		// file name format: yyyymmdd + other (for example: "20130823_1201.ibd.ref.usd.zip")
		
		Set<FTPFile> fileList = new TreeSet<FTPFile>(new FitchResponseFTPFileComparator());
		
		for(FTPFile file : fileArray) {
			
			String fileName = file.getName();
			
			// considero tutti i file con prefisso diverso da "FDS" (� la lista delle banche) e estensione .zip
			if(!fileName.startsWith("FDS") && fileName.endsWith(".zip")) {
				
				fileList.add(file);
			}
		}
		
		if(fileList.size() < 1) {
			
			throw new Exception("Data not available on Fitch server.");
		}
		
		// prendo il primo, la lista � ordinata in modo decrescente secondo la data
		return ((FTPFile)fileList.toArray()[0]);
	}
	
	
	
	// 
	public void persistHistoricalData(List<VarHEntity> entityList) throws Exception {
		
    	try {
    	
			boolean duplicateKeyFoundFlag = false;
				
	    	for(VarHEntity varHEntity : entityList) {
	    		
	    		// gestione chiave duplicata
	    		// *********************************************************************************************************************
	    		
	    		VarHEntity temp = this.varHEAOLocal.findByPrimaryKey(varHEntity.getId());
	    		
	    		// se il dato gi� esiste
				if(temp != null) {
					
					logger.warn(new StandardLogMessage(varHEntity + " already exists in RCTVARH. Skipping data."));
					
					duplicateKeyFoundFlag = true;
					
					// skip
					continue;
				}
	    		// *********************************************************************************************************************
	    		
				// scrivi dato
				this.varHEAOLocal.add(varHEntity);
			}
		    	
	    	
			if(duplicateKeyFoundFlag) {
				
				logger.warn(new StandardLogMessage("Persisting data successfully completed. Duplicate key values found in new data."));
				
				throw new DuplicateKeyException("Persisting data successfully completed. Duplicate key values found in new data.");
			}
			else {
				
				logger.info(new StandardLogMessage("Persisting data successfully completed."));
			}
			
    	}
    	catch(Exception e) {
    		
    		logger.error(new StandardLogMessage(e.toString()));
    		
			throw e;
		}
    }
	
	

}
