package it.ccg.irifpejb.server.bean.eao;

import it.ccg.irifpejb.server.bean.entity.FileEntity;

import java.util.List;

import javax.ejb.Local;

@Local
public interface FileEAOLocal {

	public List<FileEntity> fetch() throws Exception;
	public FileEntity findByPrimaryKey(int fileId) throws Exception;
	public FileEntity findByName(String fileName) throws Exception;
	public FileEntity add(FileEntity fileEntity) throws Exception;
	public void update(FileEntity fileEntity) throws Exception;
	public void remove(FileEntity fileEntity) throws Exception;
	
}
