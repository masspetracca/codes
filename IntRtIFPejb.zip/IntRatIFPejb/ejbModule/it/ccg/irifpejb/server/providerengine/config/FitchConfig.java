package it.ccg.irifpejb.server.providerengine.config;


public class FitchConfig {
	
	public static String name;
	public static String url;
	public static String userName;
	public static String password;
	public static String downloadDataDir;
	public static String uploadRequestDir;
	
}
