package it.ccg.irifpejb.server.providerengine;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="flow")
@XmlAccessorType(XmlAccessType.FIELD)
public class Flow {
	
	@XmlElement
	private String name;
	@XmlElement
	private String requestFileName;
	@XmlElement
	private String responseFileName;
	@XmlElement
	private String instrType;
	@XmlElement(name="job")
	private List<Job> jobList;

	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getRequestFileName() {
		return requestFileName;
	}

	public void setRequestFileName(String requestFileName) {
		this.requestFileName = requestFileName;
	}

	public String getResponseFileName() {
		return responseFileName;
	}

	public void setResponseFileName(String responseFileName) {
		this.responseFileName = responseFileName;
	}
	
	public List<Job> getJobList() {
		return jobList;
	}

	public void setJobList(List<Job> jobList) {
		this.jobList = jobList;
	}
	
	public String getInstrType() {
		return instrType;
	}
	
	public void setInstrType(String instrType) {
		this.instrType = instrType;
	}
	
	
	@Override
	public String toString() {
		
		String toString = "[name: " + this.name + 
						 ", requestFileName: " + this.requestFileName + 
						 ", responseFileName: " + this.responseFileName +
						 ", instrType: " + this.instrType +
						 ", jobList: [";

		if(this.jobList != null) {
				
			for(Job job : this.jobList) {
				
				toString += job.toString() + ", ";
			}
			
			toString = toString.substring(0, toString.length() - 2);
		}
		
		toString += "]]";

		
		return toString;
		//return "[requestFileName: " + this.requestFileName + ", responseFileName: " + this.responseFileName + "]";
	}
	
}
