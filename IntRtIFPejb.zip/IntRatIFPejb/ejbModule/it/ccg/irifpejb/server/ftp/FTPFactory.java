package it.ccg.irifpejb.server.ftp;



public class FTPFactory {
	
	final public static String FITCH_SERVICE = "fitch";
	final public static String REUTERS_SERVICE = "reuters";
	final public static String BLOOMBERG_SERVICE = "bloomberg";
	
	
	public static FTPServiceInterface getFTPService(String service) throws Exception {
		
		if(service.equals(FTPFactory.REUTERS_SERVICE)) {
			
			return new FTPServiceReuters();
		}
		else if(service.equals(FTPFactory.BLOOMBERG_SERVICE)) {
			
			return new FTPServiceBloomberg();
		}
		else if(service.equals(FTPFactory.FITCH_SERVICE)) {
			
			return new FTPServiceFitch();
		}
		else {
			
			throw new Exception("Unknown service: " + service);
		}
		
	}

	
}


