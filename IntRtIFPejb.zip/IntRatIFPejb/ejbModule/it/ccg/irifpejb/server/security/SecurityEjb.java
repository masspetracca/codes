package it.ccg.irifpejb.server.security;

import it.ccg.irifpejb.server.exception.ExceptionUtil;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Set;

import javax.security.auth.Subject;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import com.ibm.websphere.security.auth.WSSubject;
import com.ibm.websphere.security.cred.WSCredential;

/**
 * @author pcocchi
 *
 */
public class SecurityEjb {
	
	
	public static String getCurrentUser() /*throws Exception*/ {
		
		String currentUser = null;
		
		try {
			
			// Get current security subject
			Subject security_subject = WSSubject.getRunAsSubject();
			
			if(security_subject != null) {
				// Get all security credentials from the security subject
				Set<WSCredential> security_credentials = security_subject.getPublicCredentials(WSCredential.class);
				
				// Get the first credential
				WSCredential security_credential = (WSCredential)security_credentials.iterator().next();
				
				currentUser = (String)security_credential.getSecurityName();
				
				if(currentUser.equalsIgnoreCase("UNAUTHENTICATED")) {
					
					return "WAS";
				}
				
			}
			
		}
		catch (Exception e) {
			
			e.printStackTrace();
		}

		
		return currentUser;
	}
	
	
	public static String getCurrentLtpaToken() throws Exception {
		
		String ltpaToken = null;
		
		// Get current security subject
		Subject security_subject = WSSubject.getRunAsSubject();
		
		if(security_subject != null) {
			
			// Get all security credentials from the security subject
			Set<WSCredential> security_credentials = security_subject.getPublicCredentials(WSCredential.class);
			
			// Get the first credential
			WSCredential security_credential = (WSCredential)security_credentials.iterator().next();
			
			String user = (String)security_credential.getSecurityName();
			
			if(!user.equalsIgnoreCase("UNAUTHENTICATED")) {
				
				byte[] token = security_credential.getCredentialToken();
				
				if(token != null) {
					
					ltpaToken = new String(token);
				}
				
			}
			
		}
		
		
		return ltpaToken;
	}
	
	
	/* L'obiettivo � generare un oggetto che sia unico per operazione utente.
	 * */
	public static String getUniqueToken() throws Exception {
		
		String uniqueToken = new String();
		
		String ltpaToken = getCurrentLtpaToken();
		
		// token == null if the user is WAS
		if(ltpaToken == null) {
			
			uniqueToken = Long.toString(Thread.currentThread().getId()) + System.currentTimeMillis();
		}
		else {
			
			uniqueToken = ltpaToken + System.currentTimeMillis();
		}
		
		
		return getMD5(uniqueToken);
	}
	
	

	// input: String
	// output: string representation of MD5 message digest hexadecimal value
	public static String getMD5(String inputString) throws NoSuchAlgorithmException, UnsupportedEncodingException  {
		
		inputString = inputString.replaceAll("[^A-Za-z0-9]", "0");
		
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(inputString.getBytes("iso-8859-1"), 0, inputString.length());
		
		byte[] md5MD = md.digest();
		
		
		return convertToHex(md5MD);
	}
	
	// input: String
	// output: string representation of SHA-1 message digest hexadecimal value
	public static String getSHA1(String inputString) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		
		inputString = inputString.replaceAll("[^A-Za-z0-9]", "0");
		
		MessageDigest md = MessageDigest.getInstance("SHA-1");
		md.update(inputString.getBytes("iso-8859-1"), 0, inputString.length());
		
		byte[] sha1MD = md.digest();
		
		
		return convertToHex(sha1MD);
	} 
	
	
	public static String decodeBASE64(String input) throws Exception {
		
		String output = null;
		
		try {
			BASE64Decoder decoder = new BASE64Decoder();
			
			output = new String(decoder.decodeBuffer(input));
		}
		catch(IOException e) {
			
			e.printStackTrace();
			
			throw e;
		}
		
		
		return output;
	}
	
	
	public static String encodeBASE64(String input) throws Exception {
		
		String output = null;
		
		try {
			BASE64Encoder encoder = new BASE64Encoder();
			
			output = new String(encoder.encode(input.getBytes()));
		}
		catch(Exception e) {
			
			e.printStackTrace();
			
			throw e;
		}
		
		
		return output;
	}
	
	
	// input: byte[]
	// output: string representation of hexadecimal value
	private static String convertToHex(byte[] data) { 
		
		StringBuffer buf = new StringBuffer();
		
		for(int i = 0; i < data.length; i++) { 
			
			int halfbyte = (data[i] >>> 4) & 0x0F;
			int two_halfs = 0;
			
			do { 
				if ((0 <= halfbyte) && (halfbyte <= 9)) 
					buf.append((char) ('0' + halfbyte));
				else 
					buf.append((char) ('a' + (halfbyte - 10)));
				halfbyte = data[i] & 0x0F;
			}
			while(two_halfs++ < 1);
		}
		
		
		return buf.toString();
	} 
	
}
