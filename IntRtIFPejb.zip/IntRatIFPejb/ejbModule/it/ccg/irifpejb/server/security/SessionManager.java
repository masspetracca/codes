package it.ccg.irifpejb.server.security;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class SessionInfo
 */
@Stateless
@Local(SessionManagerLocal.class)
public class SessionManager implements SessionManagerLocal {
	
	// Map<user, sessionId>
	private static Map<String, String> loggedUsersMap = null;
	
	
	@Resource
	private SessionContext sessionContext;
	
	private String[] ROLES = {"admin"};


    /**
     * Default constructor. 
     */
    public SessionManager() {
    	
    	if(loggedUsersMap == null) {
    		
    		loggedUsersMap = new HashMap<String, String>();
    	}
    }

    
    
	@Override
	public void addLoggedUser(String userName, String sessionId) throws Exception {
		
		loggedUsersMap.put(userName, sessionId);
	}
	
	
	@Override
	public void removeLoggedUser(String userName) throws Exception {
		
		loggedUsersMap.remove(userName);
	}


	@Override
	public List<String> listLoggedUsers() throws Exception {
		
		List<String> loggedUsersList = new ArrayList<String>();
		
		Set<String> keySet = loggedUsersMap.keySet();
		for(String key : keySet) {
			
			loggedUsersList.add(key);
		}
		
		return loggedUsersList;
	}
    
    


	@Override
	public String getCurrentUser() throws Exception {
		
		String currentUser = this.sessionContext.getCallerPrincipal().getName();
			
		if(currentUser.equalsIgnoreCase("UNAUTHENTICATED")) {
			
			currentUser = "WAS";
		}
		
		return currentUser;
	}
    
	@Override
	public String getCurrentUserSessionId() throws Exception {
		
		String currentUser = this.sessionContext.getCallerPrincipal().getName();
		
		return loggedUsersMap.get(currentUser);
	}
    
	public List<String> getCurrentUserRoles() throws Exception {
		
		List<String> userRoles = new ArrayList<String>();
		
		for(String role : ROLES) {
			
			if(this.sessionContext.isCallerInRole(role)) {
				
				userRoles.add(role);
			}
		}
		
		return userRoles;
	}


    

}
