package it.ccg.irifpejb.server.file.factory;

public enum BBGRequestType {
	
	CURR_REQUEST,
	NIR_REQUEST;

}
