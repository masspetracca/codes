package it.ccg.irifpejb.server.file.util;

import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import java.util.Comparator;

import org.apache.commons.lang.UnhandledException;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.log4j.Logger;

public class ReutersResponseFTPFileComparator implements Comparator<FTPFile> {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	private String fileNamePrefix;
	
	public ReutersResponseFTPFileComparator(String fileNamePrefix) {
		
		this.fileNamePrefix = fileNamePrefix;
	}
	
	@Override
	public int compare(FTPFile ftp1, FTPFile ftp2) {
		
		String date2 = null;
		String date1 = null;
		
		try {
			logger.debug(new StandardLogMessage("Comparing \'" + ftp1.getName() + "\' to \'" + ftp2.getName()) + "\'.");
			
			date2 = ftp2.getName().substring(this.fileNamePrefix.length(), (ftp2.getName().length() - 4));
			date1 = ftp1.getName().substring(this.fileNamePrefix.length(), (ftp1.getName().length() - 4));
		}
		catch(Exception e) {
			
			throw new UnhandledException(e);
		}
		
		// i want a descending list, DATA2.compareTo(DATA1);
		return date2.compareTo(date1);
	}

}
