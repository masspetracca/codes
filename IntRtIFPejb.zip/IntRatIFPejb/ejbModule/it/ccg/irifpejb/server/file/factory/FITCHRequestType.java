package it.ccg.irifpejb.server.file.factory;

public enum FITCHRequestType {
	
	BANK_REQUEST;

}
