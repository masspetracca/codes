package it.ccg.irifpejb.server.exception;

public class DuplicateKeyException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DuplicateKeyException() {
		super();
	}
	
	public DuplicateKeyException(String msg) {
		super(msg);
	}
	
}
