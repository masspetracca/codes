package it.ccg.irifpejb.server.logengine;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class LogService {
	
	//private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.EJB_LOGGER);
	
	private static String LOG_FILE_DIR_ABSOLUTE_PATH;
	
	
    /**
     * Default constructor. 
     */
    public LogService(String logFileDirAbsPath) {
		
    	LOG_FILE_DIR_ABSOLUTE_PATH = logFileDirAbsPath;
    }
    

	
	public List<Map<String, String>> getLogsListByType(String logType) throws Exception {
		
		// leggi la directory dei log e ritorna la lista dei nomi
		List<Map<String, String>> list = new ArrayList<Map<String,String>>();
		
		File file = new File(LOG_FILE_DIR_ABSOLUTE_PATH);
		
		String[] fileArray = file.list();
		
		for(String fileName : fileArray) {
			if(fileName.startsWith(logType)) {
				Map<String, String> map = new HashMap<String, String>();
				map.put("logFileName", fileName);
				
				list.add(map);
			}
			
		}
		
		
		return list;
	}
	
	
	public List<LogLineDTO> getLog(String logFileName, Map<String, Object> filterParams) throws Exception {
		
		
		String dateTime = (String)filterParams.get("dateTime");
		
		Object[] type = null;
		if(filterParams.get("type") instanceof Object[]) {
			
			type = (Object[])filterParams.get("type");
		}
		// is String
		else if(filterParams.get("type") instanceof String) {
			
			type = new String[1];
			type[0] = (String)filterParams.get("type");
		}
		else {
			
			throw new Exception("Error parsing \'type\' criteria.");
		}
		
		String classMethod = (String)filterParams.get("classMethod");
		String user = (String)filterParams.get("user");
		String message = (String)filterParams.get("message");
		
		// ex filtering
		/*// *****
		CriteriaParser criteriaParser = new CriteriaParser();
		List<CriteriaDTO> criteriaDTOList = criteriaParser.parse(dsRequest);
		// *****
		
		for(CriteriaDTO criteriaDTO : criteriaDTOList) {
			if(criteriaDTO.getFieldName().equalsIgnoreCase("type")) {
				type = (String)criteriaDTO.getValue();
			}
			else if(criteriaDTO.getFieldName().equalsIgnoreCase("classMethod")) {
				classMethod = (String)criteriaDTO.getValue();
			}
			else if(criteriaDTO.getFieldName().equalsIgnoreCase("user")) {
				user = (String)criteriaDTO.getValue();
			}
			else if(criteriaDTO.getFieldName().equalsIgnoreCase("message")) {
				subMessage = (String)criteriaDTO.getValue();
			}
		}*/
		
		
		LogReader logReader = new LogReader(LOG_FILE_DIR_ABSOLUTE_PATH);
		
		List<LogLineDTO> log = this.reverseOrder(logReader.getLog(logFileName, dateTime, type, classMethod, user, message));
		
		
		// ex paging
		/*long totalRows = log.size();
        long startRow = (int)dsRequest.getStartRow();  
        long endRow = (int)dsRequest.getEndRow();
        endRow = Math.min(endRow, totalRows);
		
		log = log.subList((int)startRow, (int)endRow);
		
		
		dsResponse.setData(log);
		
		// Tell client what rows are being returned, and what's available
        dsResponse.setStartRow(startRow);
        dsResponse.setEndRow(endRow);  
        dsResponse.setTotalRows(totalRows);*/
        
		
		return log;
		
	}
    
    
	
	private List<LogLineDTO> reverseOrder(List<LogLineDTO> log) {
		
		List<LogLineDTO> reversed = new ArrayList<LogLineDTO>();
		
		for(int i=0; i<log.size(); i++) {
			
			reversed.add(i, log.get(log.size() - 1 - i));
		}
		
		
		return reversed;
	}
    


}
