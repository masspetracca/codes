DROP TABLE IF EXISTS job;

CREATE TABLE job (
	id int(11) NOT NULL auto_increment,
	typ varchar(100) NOT NULL,
	priority int(2),
	status varchar(100),
	returncode varchar(100),
	name varchar(100),
	parameters varchar(200),
	queue varchar(100),
	created_at datetime,
	created_user varchar(100),
	started_at datetime,
	ended_at datetime,
	PRIMARY KEY  (id)
);

