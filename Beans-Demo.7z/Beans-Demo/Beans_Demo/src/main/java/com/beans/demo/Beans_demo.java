package com.beans.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Beans_demo {

	public static void main(String[] args) {
		
		ApplicationContext ac = new ClassPathXmlApplicationContext("com/beans/config/beans.xml");
		
		User user = (User) ac.getBean("user");
		
		user.test();
		
		System.out.println("User id and name : "+user.getId() +" and "+ user.getName());
		
		/*
		Employee emp = (Employee) ac.getBean("emp");
		
		System.out.println("Employee id and name is "+emp.getEmp_id() +" and " + emp.getEmp_name());
		
		for(int i= 0 ; i<emp.getAll_employer().size() ; i++)
		{
			System.out.println(emp.getAll_employer().get(i));
		}
		*/
		
		Employee emp = user.getEmp();
		
		System.out.println("Employee id and name is "+emp.getEmp_id() +" and " + emp.getEmp_name());
		
		for(int i= 0 ; i<emp.getAll_employer().size() ; i++)
		{
			System.out.println(emp.getAll_employer().get(i));
		}
		
		((ClassPathXmlApplicationContext)ac).close();

	}

}
