package com.beans.demo;

import org.springframework.beans.factory.annotation.Autowired;



public class User {
	
	private int id;
	private String name;
	
	@Autowired
	private Employee emp;

	public User(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public Employee getEmp() {
		return emp;
	}



	public void setEmp(Employee emp) {
		this.emp = emp;
	}



	public void test()
	{
		System.out.println("test method has been called");
	}

	public void welcome()
	{
		System.out.println("WELCOME");
	}
	
	public void byebye()
	{
		System.out.println("BYE BYE");
	}
}
