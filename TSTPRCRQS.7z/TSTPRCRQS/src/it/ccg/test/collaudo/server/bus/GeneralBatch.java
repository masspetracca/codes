package it.ccg.test.collaudo.server.bus;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.math.BigDecimal;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.logging.Logger;

public class GeneralBatch {
	
	//chiavi di accesso per UPD
	String kGifDt;
	String kIDGifData;

	String nodeGFDescData;
	String nodeAmountData;
	
	String z3a = " ";
	String z3b = " ";
	String z3c = " ";
	String z3d = " ";
	String z3e = " ";
	String z3f = " ";

	
	private static String scenario;

	private static String Tab_col0 = "UATGIF_DT";
	private static String Tab_col1 = "UATGIF_ID";
	private static String Tab_col2 = "UATGIF_GFDESC";
	private static String Tab_col3 = "UATGIF_AMOUNT";
	private static String DEC_POINT = ".";
//	private static String Tab_col4 = "";
//	private static String Tab_col5 = "";
//
//	private static String Tab_col6 = "";
//	private static String Tab_col7 = "";
//	private static String Tab_col8 = "";
//	private static String Tab_col9 = "";
//	private static String Tab_col10 = "";
	private static String TableName = PropertyFiles.getTabName1();

//	private static String vcol3 = "";
//	private static String vcol4 = "";
//	private static String vcol5 = "";

	private static String sdate =null;
	private static String nomeTab;
	

	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

	private static String tabFreq ="";
	private int ctrIns;
	private int ctrUpd;
	private int returnCode = 0;
	
 	private static String sqlUpdate;

	
	FileWriter writer;

	String stl;
	String tok;
	//TestCollaudoQA testcollaudoqa;
	Logger userLog;
	int indx;
	private int ctr_read;

	private String s11;
	private String s12;
	private String s13;
	private String s14;
	private String z3h;
	private String z3g;
	private String z3i;
	private String z3l;
	private String s6x;

	private BigDecimal ctv;
	private String outScenario;
	private String out;
	private String outDCM;
	private BigDecimal CTV;
	private String ISIN;
	private String prt;


	
	//
	private String outCSACCNBR;
	private String outCSVALUE;
	private String outCSDATE;
	private String outCSCURR;
	private String outCSSTATUS;
	private String outCSFILENAME;
	//
	private BigDecimal divisor10;
	private String HDR;
	private String ftpUrl;


	public GeneralBatch(int returnCode) throws IOException, SQLException, IllegalAccessException, InstantiationException, ClassNotFoundException {

		Object rs;
		//String driver
		PropertyFiles pf;
		
		//String PreparedStatement
		PreparedStatement st;
		
		try {
			pf = new PropertyFiles();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PropertyFiles.getDbDriverTest();
		PropertyFiles.getTabName1();
		nomeTab=PropertyFiles.getTabName1();


		Class.forName(PropertyFiles.getDbDriverTest()).newInstance();
		//String url = "jdbc:db2://localhost:50000/DB2";
		String url = PropertyFiles.getDbConnStringTest();
		//String prop = ("user"+PropertyFiles.getDbUserTest()+"password"+PropertyFiles.getDbPasswordTest());
		
		Properties props = new Properties();
		//props.setProperty("user", "db2admin");
		props.setProperty("user", PropertyFiles.getDbUserTest());
		
		//props.setProperty("password", "main");
		props.setProperty("password", PropertyFiles.getDbPasswordTest());
		
		
		sdate = day.now();
		
		String sdateaaaa = sdate.substring(0, 4);
		String sdatemm =   sdate.substring(5, 7);
		String sdategg = sdate.substring(8, 10);
		
		String stimehh = sdate.substring(11, 13);
		String stimemm = sdate.substring(14, 16);
		String stimess = sdate.substring(17, 19);
		
		sDate = (sdateaaaa+sdatemm+sdategg);
		sTime = (stimehh+stimemm+stimess);
		System.out.println("date:"+sDate);
		System.out.println("time:"+sTime);
	
		
		
		System.out.println("Inizio <PopulateDb> popolamento tabelle DB2 via JDBC");
		//segnalazioni di test
		System.out.println("**************************************");
		System.out.println("**       Segnalazioni tecniche      **");
		System.out.println("**************************************");
		System.out.println("url per POPOLAMENTO di UAT/Austria: "+nomeTab+" "+url);
		System.out.println("drivers: "+PropertyFiles.getDbDriverTest());
		System.out.println("User Test: "+ PropertyFiles.getDbUserTest());
		System.out.println("Password Test: "+ PropertyFiles.getDbPasswordTest());
		System.out.println("**************************************");
		

		HDR = "GetProperties;"+ctr_read+";";
 		System.out.println(HDR);
 		GetProperties();
	   	
		HDR = "PrintOpen;"+ctr_read+";";
 		System.out.println(HDR);
	   	PrintOpen();
	   	
	   	//read FTP file 
	   	//readFTPFile();
	   	
	   	
		//create Connection
		Connection conn = DriverManager.getConnection(url, props);

    	BufferedReader in = new BufferedReader
        //(new FileReader("datiPM/Selenium_testOUT.txt"));
		(new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTVALUES_FILE_OUTPUT()));

    	
 	    TestCollaudoQAEAO pdb = new TestCollaudoQAEAO();
 		kGifDt ="";
 		kIDGifData="";

 		String nodeIDGifData= null;
 		String nodeGFDescData = null;
 		String nodeAmountData = null;

 		String x0=(";"+"RMKTID"+";");
 		
 		String x1x=("RDATE"+";");
		String x1y=("RTIME"+";");
		
 		String x1=("RISINCD"+";");
		String x1a=("RTYPE"+";");
		String x1b=("RPRICE"+";");
		String x1c=("RRCURR"+";");
		
		
   		HDR = "GeneralBatch;"+ctr_read+";";
		System.out.println(HDR);
		System.out.println(x0+x1x+x1y+x1+x1a+x1b+x1c);
   		String prt = (x0+x1x+x1y+x1+x1a+x1b+x1c);
   		printOUT(prt);

   		while ((stl = in.readLine()) != null) {
         	//System.out.println("readData: "+stl);
         	
        	ctr_read++;
    		//System.out.println("elab#"+stl.substring(0,1));
        		//--> CHECK TYPE
       		HDR = "GeneralBatch;"+ctr_read+";";
			System.out.println(HDR);
			if (! (stl.substring(0,1).contains("X"))) {
				in.readLine();
			}
			else {
				elabBS();
				}
         	}
   			printCLOSE(); 

//     	    tok=" ";
//    	    indx=0;
// 	        StringTokenizer f= new StringTokenizer(stl, ";");
//	        while(f.hasMoreTokens()) {
//	        	    indx++;
//	        	    if (indx == 1) {
//	        	    	tok = (String)f.nextElement();
//	        	    	kGifDt = tok;
//	        	    	pdb.setkGifID(kGifDt);
//	        	    }
//	        	    if (indx == 2) {
//	        	    	tok = (String)f.nextElement();
//	        	    	kIDGifData = tok;
//		        	    pdb.setkIDGifData(kIDGifData);
//	        	    }
//	        	    if (indx == 3) {
//	        	    	tok = (String)f.nextElement();
//	        	    	nodeGFDescData = tok;
//	        	    }
//	        	    if (indx == 4) {
//	        	    	tok = (String)f.nextElement();
//	        	    	nodeAmountData = tok;
//	        	    }
//	        	    if (indx > 4) {
//	        	    	 System.out.println("Fine anomala  ... "+(String)f.nextElement());
//	        	    	 System.exit(10);
//	        	    }
//			        //System.out.println("token:"+indx+"="+tok);
//			      
//	        }
//	        

	  	  
	  	  
//	        DeleteDb(kGifDt, kIDGifData);
//
//			TestCollaudoQAUPD deld = new TestCollaudoQAUPD(); 	        
//	        //System.out.println("String per DELETE:"+deld.getSqlUpdate());
//	    	st = conn.prepareStatement(deld.getSqlUpdate());
//    	    st.executeUpdate();
//
//    	    PopulateDb(kGifDt, kIDGifData, nodeGFDescData, nodeAmountData);
//	    	
//	
//			TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 	        
//	        //System.out.println("String per INSERT:"+upd.getSqlUpdate());
//	    	st = conn.prepareStatement(upd.getSqlUpdate());
//    	    st.executeUpdate();

		  
//	}

     in.close();
     System.out.println("Fine esecuzione ##End ...Read Data Test Collaudo QA");
 }





	private void printCLOSE() throws IOException {
   		HDR = "printCLOSE;"+ctr_read+";";
		System.out.println(HDR);
		writer.close();
	}

	private void PrintOpen() {
   		 HDR = "PrintOpen;"+ctr_read+";";
   		 System.out.println(HDR);
		 sdate = day.now();
		 
		 String sdateaaaa = sdate.substring(0, 4);
		 String sdatemm =   sdate.substring(5, 7);
		 String sdategg = sdate.substring(8, 10);
		
	 	 String stimehh = sdate.substring(11, 13);
		 String stimemm = sdate.substring(14, 16);
		 String stimess = sdate.substring(17, 19);
		
		 sDate = (sdateaaaa+sdatemm+sdategg);
		 sTime = (stimehh+stimemm+stimess);
		 System.out.println("date:"+sDate);
		 System.out.println("time:"+sTime);
		 sdate = sDate+sTime;

		 
	    //File outputFile = new File("dati/outDb2.txt");
		File outputFile = new File(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTDB2_FILE_OUTPUT()+".al"+sdate+".csv");
	    // System.out.println(outputFile.getAbsolutePath());
	    writer = null;
	    
	    try {								
	    	boolean deleted = false;							
	    	if (outputFile.exists()) {							
	    		deleted = outputFile.delete();						
	    	}							
	    	System.out.println("rimosso file da: " + outputFile.getAbsolutePath() + "; " + deleted);							
	    	writer = new FileWriter(outputFile, false);							
		    } catch (IOException e1) {								
	    	System.out.println(e1.getMessage());							
	    	e1.printStackTrace();							
	    }	
		
	}




	private void printOUT(String prtOUT) throws IOException {
		//System.out.println(prtOUT);

		String oLine= prtOUT;
		writer.write(oLine+"\n");
			
			
	}


	private void elabBS() throws IOException {
		
		/*
 		RMKTID  	CHARACTER(4) NOT NULL DEFAULT ' ',
 		RDATE   	NUMERIC(8,0) NOT NULL DEFAULT 0,
 		RTIME   	NUMERIC(8,0) NOT NULL DEFAULT 0,
 		RISINCD 	CHARACTER(12) NOT NULL DEFAULT ' ',
 		RTYPE   	CHARACTER(2) NOT NULL DEFAULT ' ',
 		RPRICE  	NUMERIC(23,7) NOT NULL DEFAULT 0,
 		RCURR   	CHARACTER(3) NOT NULL DEFAULT ' ',
*/ 
 		

		z3a = " ";
		z3b = " ";
		z3c = " ";
		z3d = " ";
		z3e = " ";
		z3f = " ";
		
 		HDR = "elabBS;"+ctr_read+";";
 		System.out.println(HDR);
 		
		String s=("#"+";");

		//RMKTID
		String s1=(stl.substring(0,4)+";");

		//RDATE
		String s2=(stl.substring(4,12)+";");

		//RTIME
		String s3=(stl.substring(12,20)+";");

		//RISINCD
		String s4=(stl.substring(20,32)+";");
		if (!stl.substring(20,33).contains(" "))
	    {
			z3c = "FAIL: ";
			z3d = "ISIN EXPECTED ERROR/RISINCD#"+stl.substring(20,33)+";";
		}

		//RTYPE
		String s6=(stl.substring(33,34)+";");

		//RPRICE
//		if (!stl.substring(35,47).contentEquals("0000000000000"))
//	    {
//			z3c = "FAIL: ";
//			z3d = "RPRICE EXPECTED ERROR/RPRICE#"+stl.substring(35,41)+";";
//		}

		String s7i=(stl.substring(35,41));
		String s7d=(DEC_POINT+stl.substring(41,47)+";");

		//RCURR
		String s8=(stl.substring(47,50)+";");


		
		
	
		System.out.println(s+s1+s2+s3+s4+s6+s7i+s7d+s8+z3a+z3b+z3c+z3d);
   		String prt = (s+s1+s2+s3+s4+s6+s7i+s7d+s8+z3a+z3b+z3c+z3d);
   		printOUT(prt);
	}



	private void DeleteDb(String kGifDt, String kIDGifData) throws IOException, SQLException, IllegalAccessException, InstantiationException, ClassNotFoundException {
		DeleteDb ddb = new it.ccg.test.collaudo.server.bus.DeleteDb(kGifDt, kIDGifData);
	}



	private void PopulateDb(String kGifDt, String kIDGifData, String nodeGFDescData, String nodeAmountData) throws ClassNotFoundException, IOException, SQLException, IllegalAccessException, InstantiationException {
		PopulateDb pdb = new PopulateDb(kGifDt, kIDGifData, nodeGFDescData, nodeAmountData);
	}
	
	
	private static void GetProperties() throws IOException {
		PropertyFiles pf = new PropertyFiles();
	}


	private void readFTPFile() throws IOException {
		ReadFTPFile RFTPF = new ReadFTPFile();
		
	}

	private void fileFilter() throws FileNotFoundException {
		FileFilter ffilt = new FileFilter();
		
	}


}


	
		
							
   


