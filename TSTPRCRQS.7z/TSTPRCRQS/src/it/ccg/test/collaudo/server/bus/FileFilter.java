package it.ccg.test.collaudo.server.bus;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilenameFilter;

public class FileFilter {
	 
	//public static void main(String a[]) throws FileNotFoundException{
	FileFilter() throws FileNotFoundException {
	File file = new File(PropertyFiles.getCartellaDati());
	BufferedReader in = new BufferedReader
	        (new FileReader("C:/Python27/TSTPRCRQS/datiPM/"));
			//(new FileReader(PropertyFiles.getCartellaDati()));

        String[] files = file.list(new FilenameFilter() {
             
            @Override
            public boolean accept(File dir, String name) {
                if(name.toLowerCase().endsWith(".dat")){
                    return true;
                } else {
                    return false;
                }
            }
        });
        for(String f:files){
            System.out.println(f);
        }
    }
}
