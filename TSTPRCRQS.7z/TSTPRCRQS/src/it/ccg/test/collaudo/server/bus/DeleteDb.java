package it.ccg.test.collaudo.server.bus;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteDb {
	//Table access keys
	private static String kArea = ""; 
	private static String kStato = ""; 
	private static String kFreq ="";
	private static String kTipo ="";

	private static String TableNameGIROFO = PropertyFiles.getTabName2();
	
	private static String TabGIROFO_col0 = "UATGIF_DT";
	private static String TabGIROFO_col1 = "UATGIF_ID";
	private static String TabGIROFO_col2 = "UATGIF_GFDESC";
	private static String TabGIROFO_col3 = "UATGIF_AMOUNT";
//	private static String Tab_col4 = "";
//	private static String Tab_col5 = "";
//
//	private static String Tab_col6 = "";
//	private static String Tab_col7 = "";
//	private static String Tab_col8 = "";
//	private static String Tab_col9 = "";
//	private static String Tab_col10 = "";
	
	private static String TabLIME_col0 = "UATLIME_DT";
	private static String TabLIME_col1 = "UATLIME_ID_LIME";
	private static String TabLIME_col2 = "UATLIME_ID_GIF";
	private static String TabLIME_col3 = "UATLIME_GFDESC";
	private static String TabLIME_col4 = "ATLIME_AMOUNT";

	private String TableNameLIME = PropertyFiles.getTabName1();


	private static String vcol3 = "";
	private static String vcol4 = "";
	private static String vcol5 = "";

	private static String sdate =null;
	private static String nomeTab;
	
	String kLimeDt;
	String kIDLime;
	String kIDGif;

	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

//	private static String tabFreq ="";
	private int ctrIns;
//	private int ctrUpd;
 	private int returnCode = 0;
 	private static String sqlUpdate;
//	
//
//	private static Object rs;
	
	PreparedStatement st;
	private String sqlDelete;
	private int ctrDel;
	public DeleteDb(String kGifDt, String kIDGifData) throws IOException, SQLException, IllegalAccessException, InstantiationException, ClassNotFoundException {
	
		//delete table
	     sqlDelete= 
	    	(
			"DELETE FROM "+TableNameGIROFO 
			+" WHERE "+TabGIROFO_col0+ "= '"+kGifDt.substring(0,kGifDt.length())+"'" 
			+" AND "+TabGIROFO_col1+ "= '"+kIDGifData.substring(0,kIDGifData.length())+"'" 
			);
	
		 System.out.println(sqlDelete);		
		 ++ctrDel;
		 
		//setting upd parameters
		TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 
		upd.setSqlUpdate(sqlDelete);	
	}
	public DeleteDb(String kLimeDt, String kIDLime, String kIDGif) {
		
		//delete table
	     sqlDelete= 
	    	(
			"DELETE FROM "+TableNameLIME 
			+" WHERE "+TabLIME_col0+ "= '"+kLimeDt.substring(0,kLimeDt.length())+"'" 
			+" AND "+TabLIME_col1+ "= '"+kIDLime.substring(0,kIDLime.length())+"'" 
			+" AND "+TabLIME_col2+ "= '"+kIDGif.substring(0,kIDGif.length())+"'" 
			);
	
		 System.out.println(sqlDelete);		
		 ++ctrDel;
		 
		//setting upd parameters
		TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 
		upd.setSqlUpdate(sqlDelete);	
	}



		
	

}
