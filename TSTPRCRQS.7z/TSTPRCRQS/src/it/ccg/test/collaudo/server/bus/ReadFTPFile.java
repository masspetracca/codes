package it.ccg.test.collaudo.server.bus;

public class ReadFTPFile {
	
	private static String ftpUrl;

	public static void main(String[] args) {
			
		//public ReadFTPFile(ftpUrl) throws IOException {			
		 String fUrl = "ftp:10.168.178.72:21/";
	     String host = "WWWCCG/TradeRepositoryResp/";
	     String user = "ccg_trs_prod";
	     String pass = "******";
	     String dirPath = "/projects/java";
	
	     ftpUrl = String.format(fUrl, user, pass, host, dirPath);
	}

}
