/* 
 * Licensed Materials - Property of IBM 
 * OSGi Applications Hello World Sample
 * � Copyright IBM Corporation 2010. All Rights Reserved 
 * U.S. Government Users Restricted Rights -  Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package helloworld;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class Activator implements BundleActivator {

	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext context) throws Exception {
		System.out.println("### " + context.getBundle().getSymbolicName() + " is starting ###");
	}

	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		System.out.println("### " + context.getBundle().getSymbolicName() + " is stopping ###");
	}
}
