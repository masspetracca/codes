package net.codejava; 
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bloomberglp.blpapi.examples.ContributionsPageExample;

public class DownloadFileServlet extends HttpServlet {     
	/**
	 * 
	 */
	private static final long serialVersionUID = 2766189108454142251L;

	protected void doGet(HttpServletRequest request,            
			HttpServletResponse response) 
		throws 		ServletException, IOException {        
			// obtains ServletContext        
			ServletContext context = getServletContext();   
			ContributionsMktdataExample();
			// gets MIME type of the file        
			// obtains response's output stream        
			OutputStream outStream = response.getOutputStream();                 
			byte[] buffer = new byte[4096];        
			int bytesRead = -1;                 
			outStream.close();          
			}

	private static void ContributionsMktdataExample() throws IOException {
		ContributionsPageExample cmktex = new ContributionsPageExample();
		
	}
		}