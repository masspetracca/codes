// client/tests/specs/controllers/StoryboardController.spec.js
it('should reset the form', function() {
    ctrl.editedStory = ctrl.currentStory = {assignee: '1'};

    ctrl.resetForm();

    expect(ctrl.currentStory).toBeNull();
    expect(ctrl.editedStory).toEqual({});
});