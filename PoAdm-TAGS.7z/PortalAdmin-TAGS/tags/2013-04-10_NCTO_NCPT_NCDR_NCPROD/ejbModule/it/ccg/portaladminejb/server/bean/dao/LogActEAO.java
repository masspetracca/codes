package it.ccg.portaladminejb.server.bean.dao;

import it.ccg.portaladminejb.server.dto.LogActEntity;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 * Session Bean implementation class LogactEAO
 */
@Stateless
@Local(LogActEAOLocal.class)
public class LogActEAO implements LogActEAOLocal {

    @PersistenceContext(unitName="PortalAdminEJB")
	private EntityManager manager;
    
    public LogActEAO() {
        // TODO Auto-generated constructor stub
    }
 
    @Override
    public List<LogActEntity> getAllJobs(){
    	
    	Query q  = manager.createNamedQuery("getAll");
    	List<LogActEntity> toReturn = (List<LogActEntity>)q.getResultList();
     	
    	return toReturn;
    }
}
