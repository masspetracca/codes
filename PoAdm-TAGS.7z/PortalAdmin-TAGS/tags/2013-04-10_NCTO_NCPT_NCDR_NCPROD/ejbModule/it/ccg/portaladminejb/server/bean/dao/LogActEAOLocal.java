package it.ccg.portaladminejb.server.bean.dao;

import it.ccg.portaladminejb.server.dto.LogActEntity;

import java.util.List;

public interface LogActEAOLocal {

	 public List<LogActEntity> getAllJobs();
}
