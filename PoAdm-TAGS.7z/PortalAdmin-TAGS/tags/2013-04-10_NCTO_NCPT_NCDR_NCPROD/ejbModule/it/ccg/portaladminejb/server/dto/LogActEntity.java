package it.ccg.portaladminejb.server.dto;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the PMPTLOGACT database table.
 * 
 */
@Entity
@Table(name="PMPTLOGACT")
@NamedQueries({
	@NamedQuery(name="getAll", query="select logact FROM LogActEntity logact")
})
public class LogActEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false)
	private int actid;

	@Column(nullable=false)
	private Timestamp actdate;

	@Column(length=500)
	private String actdesc;

	@Column(length=10000)
	private String note;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

    public LogActEntity() {
    }

	public int getActid() {
		return this.actid;
	}

	public void setActid(int actid) {
		this.actid = actid;
	}

	public Timestamp getActdate() {
		return this.actdate;
	}

	public void setActdate(Timestamp actdate) {
		this.actdate = actdate;
	}

	public String getActdesc() {
		return this.actdesc;
	}

	public void setActdesc(String actdesc) {
		this.actdesc = actdesc;
	}

	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

}