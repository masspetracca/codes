package it.ccg.portaladminejb.server.bean.dao;

import it.ccg.portaladminejb.server.dto.Role;
import it.ccg.portaladminejb.server.dto.WSUserDTO;

import java.util.List;
import java.util.Map;

public interface RoleBeanLocal {
	
	public List<Role> listRoles() throws Exception;
	public List<Role> listUserRelatedRoles(String user) throws Exception;
	public List<Role> listUserNotRelatedRoles(String user) throws Exception;
	
	public Map<WSUserDTO, List<Role>> getUserRoleMapping(List<WSUserDTO> userList) throws Exception;
	
	public void loadUserRoleMapping() throws Exception;

}
