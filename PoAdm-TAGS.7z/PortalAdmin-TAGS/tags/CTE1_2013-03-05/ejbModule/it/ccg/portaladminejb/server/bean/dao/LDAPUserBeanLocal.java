package it.ccg.portaladminejb.server.bean.dao;

import it.ccg.portaladminejb.server.dto.LDAPUserDTO;

import java.util.List;
import java.util.Map;

public interface LDAPUserBeanLocal {
	
	public List<LDAPUserDTO> listLDAPUsers() throws Exception;
	public LDAPUserDTO getLDAPUserByContextName(String userContextName) throws Exception;
	public LDAPUserDTO getLDAPUserByCN(String cn) throws Exception;
	public LDAPUserDTO getLDAPUserByUID(String uid) throws Exception;
	public Map<String, String> get_O_C_OU() throws Exception;
	
	public void addLDAPUser(LDAPUserDTO ldapUserDTO) throws Exception;
	
	public void removeLDAPUser(LDAPUserDTO ldapUserDTO) throws Exception;
	public void removeLDAPUser(String userContextName) throws Exception;
	
	public boolean exists(LDAPUserDTO ldapUserDTO) throws Exception;
	public boolean uidAlreadyInUse(LDAPUserDTO ldapUserDTO) throws Exception;

}
