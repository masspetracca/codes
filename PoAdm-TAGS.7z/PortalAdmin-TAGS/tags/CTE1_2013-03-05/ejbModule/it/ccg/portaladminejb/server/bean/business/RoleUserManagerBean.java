package it.ccg.portaladminejb.server.bean.business;

import it.ccg.portaladminejb.server.service.mBean.AppManagementMBean;

import java.util.Map;

import javax.ejb.Local;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class RoleUserManagerBean
 */
@Stateless
@Local(RoleUserManagerBeanLocal.class)
public class RoleUserManagerBean implements RoleUserManagerBeanLocal {

    /**
     * Default constructor. 
     */
    public RoleUserManagerBean() {
        // TODO Auto-generated constructor stub
    }
    
    
    
    @Override
	public void saveUserRoleMatching(Map<String, String[]> userRolesMap) throws Exception {
		
		AppManagementMBean appManagementMBean = new AppManagementMBean();
		
		appManagementMBean.saveUserRoleMatching(userRolesMap);
	}
	

	@Override
	public void saveRoleUserMatching(Map<String, String[]> roleUsersMap) throws Exception {
		
		AppManagementMBean appManagementMBean = new AppManagementMBean();
		
		appManagementMBean.saveRoleUserMatching(roleUsersMap);
		
	}

}
