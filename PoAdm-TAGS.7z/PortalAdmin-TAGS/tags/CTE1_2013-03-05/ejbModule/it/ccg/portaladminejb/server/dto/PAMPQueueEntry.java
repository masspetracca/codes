package it.ccg.portaladminejb.server.dto;

import java.sql.Timestamp;

public class PAMPQueueEntry {
	
	private String messageID;
	private Timestamp creationTime;
	private String jmsDestination;
	private String messageText;
	
	public PAMPQueueEntry(String messageID, Timestamp creationTime, String jmsDestination, String messageText) {
		
		this.messageID = messageID;
		this.creationTime = creationTime;
		this.jmsDestination = jmsDestination;
		this.messageText = messageText;
	}

	
	public String getMessageID() {
		return messageID;
	}


	public void setMessageID(String messageID) {
		this.messageID = messageID;
	}
	
	
	public Timestamp getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}

	public String getJmsDestination() {
		return jmsDestination;
	}

	public void setJmsDestination(String jmsDestination) {
		this.jmsDestination = jmsDestination;
	}

	public String getMessageText() {
		return messageText;
	}

	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}
	
	
	
	
	
}
