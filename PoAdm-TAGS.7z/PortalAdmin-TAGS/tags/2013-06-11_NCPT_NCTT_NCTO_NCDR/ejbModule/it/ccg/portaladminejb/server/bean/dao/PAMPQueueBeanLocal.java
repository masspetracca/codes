package it.ccg.portaladminejb.server.bean.dao;


public interface PAMPQueueBeanLocal {
	
	/*public List<PAMPQueueEntry> listQueueEntries() throws Exception;
	public void emptyQueue() throws Exception;*/
	
	public void addQueueEntry(String batchID, String user) throws Exception;
	
}
