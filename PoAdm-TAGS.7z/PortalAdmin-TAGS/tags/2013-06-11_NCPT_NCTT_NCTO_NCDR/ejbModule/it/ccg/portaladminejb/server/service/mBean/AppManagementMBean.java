package it.ccg.portaladminejb.server.service.mBean;

import it.ccg.portaladminejb.server.dto.Role;
import it.ccg.portaladminejb.server.dto.WSUserDTO;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;
import it.ccg.portaladminejb.server.system.SystemProperties;
import it.ccg.portaladminejb.server.util.ArrayUtil;
import it.ccg.portaladminejb.server.util.ExceptionUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import org.apache.log4j.Logger;

import com.ibm.websphere.management.AdminClient;
import com.ibm.websphere.management.exception.ConnectorException;
import com.ibm.ws.management.application.client.MapRolesToUsers;

@SuppressWarnings("unchecked")
public class AppManagementMBean {
	
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.EJB_LOGGER);
	

	private String appManagementQuery = "WebSphere:*,type=AppManagement";
	private ObjectName appManagementMBean;
	
	private AdminClient adminClient = null;
	
	
	private static String[][] taskData = null;
	
	
	
	
	public AppManagementMBean() throws Exception {
		
		try {
			this.adminClient = AdminClientManager.getAdminClient();
			
			ObjectName objectName = new ObjectName(appManagementQuery);
			
			Set<?> set = this.adminClient.queryNames(objectName, null);
			
			
			logger.debug(new StandardLogMessage("Connected to " + appManagementQuery));
			
			
			this.appManagementMBean = (ObjectName)set.iterator().next();
		}
		catch(MalformedObjectNameException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		catch(NullPointerException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		catch(ConnectorException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
		
	}
	
	
	
	// get roles methods ***********
	
	public List<String> getRoles() throws Exception {
		
		List<String> roleList = new ArrayList<String>();
		
		String[][] taskData = this.loadCurrentWSTaskData();
		
		for(int i=1; i<taskData.length; i++) {
		
			roleList.add(taskData[i][0]);
		}
		
		
		return roleList;
	}
	
	public List<String> getUserRelatedRoles(String user) throws Exception {
		
		List<String> roleList = new ArrayList<String>();
		
		String[][] taskData = this.loadCurrentWSTaskData();
		
		for(int i=1; i<taskData.length; i++) {
			
			String[] userArray = taskData[i][3].split("\\|");
			List<String> tempList = new ArrayList<String>();
			for(String u : userArray) {
				
				tempList.add(u.trim());
			}
			
			if(tempList.contains(user)) {
				
				roleList.add(taskData[i][0]);
			}
			
		}
		
		
		return roleList;
	}
	
	public List<String> getUserNotRelatedRoles(String user) throws Exception {
		
		List<String> roleList = new ArrayList<String>();
		
		
		String[][] taskData = this.loadCurrentWSTaskData();
		
		for(int i=1; i<taskData.length; i++) {
			
			String[] userArray = taskData[i][3].split("\\|");
			List<String> tempList = new ArrayList<String>();
			for(String u : userArray) {
				
				tempList.add(u.trim());
			}
			
			if(!tempList.contains(user)) {
				
				roleList.add(taskData[i][0]);
			}
			
		}
		
		
		return roleList;
	}
	
	
	public Map<WSUserDTO, List<Role>> getUserRoleMapping(List<WSUserDTO> userList) throws Exception {
		
		Map<WSUserDTO, List<Role>> userRoleMapping =  new HashMap<WSUserDTO, List<Role>>();
		
		List<Role> roleList = null;
		
		String[][] taskData = this.loadCurrentWSTaskData();
		
		for(WSUserDTO wsUserDTO : userList) {
			
			roleList = new ArrayList<Role>();
			
			for(int i=1; i<taskData.length; i++) {
				
				String[] userArray = taskData[i][3].split("\\|");
				List<String> tempUserList = new ArrayList<String>();
				for(String u : userArray) {
					
					tempUserList.add(u.trim());
				}
				
				if(tempUserList.contains(wsUserDTO.getUserContextName())) {
					
					roleList.add(new Role(taskData[i][0]));
				}
			}
			
			userRoleMapping.put(wsUserDTO, roleList);
		}
		
		
		return userRoleMapping;
	}
	
	
	
	// get users methods ***********
	
	public List<String> getRoleRelatedUsers(String role) throws Exception {
		
		List<String> userList = new ArrayList<String>();
		
		String[][] taskData = this.loadCurrentWSTaskData();
		
		for(int i=1; i<taskData.length; i++) {
			
			if(taskData[i][0].equalsIgnoreCase(role)) {
				
				String[] userArray = taskData[i][3].split("\\|");
				for(String u : userArray) {
					
					if(!u.equalsIgnoreCase("")) {

						userList.add(u.trim());
					}
				}
				
			}
		}
		
		
		return userList;
	}
	
	
	
	
	// input: Map<String, String[]> --> Map<user, relatedRoles>
	public void saveUserRoleMatching(Map<String, String[]> userRolesMap) throws Exception {
		
		try {
			String[][] taskData = this.getACopyOfCurrentWSTaskData();
			
			Set<String> userSet = userRolesMap.keySet();
			// i have one key
			String user = userSet.iterator().next();
			
			String[] newRoleArray = userRolesMap.get(user);
			List<String> newRoleList = new ArrayList<String>();
			for(String role : newRoleArray) {
				
				newRoleList.add(role);
			}
			
			
			System.out.println("Old task data settings: ");
			this.printTaskData(taskData);
			
			
			//
			//List<Integer> nullRoleIndexList = new ArrayList<Integer>();
			
			for(int i=1; i<taskData.length; i++) {
				
				// role 'remote' is mapped as 'null'
				//if(taskData[i][0] != null) {
					
					// se il ruolo corrente � tra i ruoli presenti nella lista
					if(newRoleList.contains(taskData[i][0])) {
						
						String oldUsersString = taskData[i][3];
						
						String[] oldUsersArray = oldUsersString.split("\\|");
						List<Object> oldUsersList = ArrayUtil.toList(oldUsersArray);
						
						String newUsersString = oldUsersString;
						// se non c'� lo aggiungo
						if(!oldUsersList.contains(user)) {
							
							if(newUsersString.length() == 0) {
								
								newUsersString += user;
							}
							else {
								
								newUsersString += "|" + user;
							}
						}
						
						taskData[i][3] = newUsersString;
					}
					// se il ruolo corrente NON � tra i ruoli presenti nella lista
					else {
						String oldUsersString = taskData[i][3];
						
						String[] oldUsersArray = oldUsersString.split("\\|");
						List<Object> oldUsersList = ArrayUtil.toList(oldUsersArray);
						
						// se c'� lo tolgo
						if(oldUsersList.contains(user)) {
							
							oldUsersList.remove(user);
						}
						
						String newUsersString = new String();
						for(Object u : oldUsersList) {
							
							newUsersString += u + "|";
						}
						if(newUsersString.length() > 0) {
							
							newUsersString = newUsersString.substring(0, newUsersString.length() - 1);
						}
						
						
						taskData[i][3] = newUsersString;
					}
					
				/*}
				// trace 'null' roles to remove them
				else {
					
					nullRoleIndexList.add(new Integer(i));
				}*/
				
			}
			
			// if i find a null role, i have to remove from task data (unless, i get a NullPointerException when invoke setApplicationInfo)
			/*if(nullRoleIndexList.size() > 0) {
				
				System.out.println("Removing \'null\' roles..");
				
				String[][] cleanTaskData = new String[taskData.length - nullRoleIndexList.size()][taskData[0].length];
				
				for(int r=0, rC=0; r<taskData.length - 1; r++) {
					
					if(taskData[r][0] != null) {
						
						for(int c=0; c<taskData[0].length; c++) {
							
							//System.out.println("cleanTaskData[" + rC + "][" + c + "] = taskData[" + r + "][" + c +"]");
							
							cleanTaskData[rC][c] = taskData[r][c];
						}
						
						rC++;
					}
					
				}
				
				
				taskData = cleanTaskData;
			}*/
			
			//
			System.out.println("New task data settings: ");
			this.printTaskData(taskData);
			
			
			
			// write new settings on WS embedded DB
			
			Vector<Object> appInfoVector = (Vector<Object>)this.getApplicationInfo();
			
			MapRolesToUsers mapRolesToUsers = (MapRolesToUsers)appInfoVector.get(4);
			mapRolesToUsers.setTaskData(taskData);
			
			appInfoVector.remove(4);
			appInfoVector.add(4, mapRolesToUsers);
			
			this.setApplicationInfo(appInfoVector);
			
			// only if setApplicationInfo executes, update taskData in memory
			this.setTaskData(taskData);
			
			
			logger.info(new StandardLogMessage("CCGPortal user/role matching configuration correctly updated."));
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
	}
	
	
	
	// input: Map<String, String[]> --> Map<role, relatedUsers>
	public void saveRoleUserMatching(Map<String, String[]> roleUsersMap) throws Exception {
		
		try {
			String[][] taskData = this.getACopyOfCurrentWSTaskData();
			
			System.out.println("Old task data settings: ");
			this.printTaskData(taskData);
			
			
			//
			//List<Integer> nullRoleIndexList = new ArrayList<Integer>();
			
			for(int i=1; i<taskData.length; i++) {
				
				// role 'remote' is mapped as 'null'
				//if(taskData[i][0] != null) {
				
					String[] usersArray = roleUsersMap.get(taskData[i][0]);
					
					// verr� eseguito una sola volta
					if(usersArray != null) {
						
						String newUsersString = new String();
						for(String user : usersArray) {
							
							newUsersString += user + "|";
						}
						newUsersString = newUsersString.substring(0, newUsersString.length() - 1);
						
						if(!newUsersString.equalsIgnoreCase("")) {
							
							taskData[i][3] = newUsersString;
						}
						else {
							
							taskData[i][3] = null;
						}
					}
				/*}
				// trace 'null' roles to remove them
				else {
					
					nullRoleIndexList.add(new Integer(i));
				}*/
			}
			
			
			// if i find a null role, i have to remove from task data (unless, i get a NullPointerException when invoke setApplicationInfo)
			/*if(nullRoleIndexList.size() > 0) {
				
				System.out.println("Removing \'null\' roles..");
				
				String[][] cleanTaskData = new String[taskData.length - nullRoleIndexList.size()][taskData[0].length];
				
				for(int r=0, rC=0; r<taskData.length - 1; r++) {
					
					if(taskData[r][0] != null) {
						
						for(int c=0; c<taskData[0].length; c++) {
							
							//System.out.println("cleanTaskData[" + rC + "][" + c + "] = taskData[" + r + "][" + c +"]");
							
							cleanTaskData[rC][c] = taskData[r][c];
						}
						
						rC++;
					}
					
				}
				
				
				taskData = cleanTaskData;
			}*/
			
			
			System.out.println("New task data settings: ");
			this.printTaskData(taskData);
			
			
			// write new settings on WS embedded DB
			
			Vector<Object> appInfoVector = (Vector<Object>)this.getApplicationInfo();
			
			MapRolesToUsers mapRolesToUsers = (MapRolesToUsers)appInfoVector.get(4);
			mapRolesToUsers.setTaskData(taskData);
			
			appInfoVector.remove(4);
			appInfoVector.add(4, mapRolesToUsers);
			
			this.setApplicationInfo(appInfoVector);
			
			// only if setApplicationInfo executes, update taskData in memory
			this.setTaskData(taskData);
			
			
			logger.info(new StandardLogMessage("CCGPortal user/role matching configuration correctly updated."));
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
	}
	
	
	public List<String> listInstalledApps() throws Exception {
		
		Vector<Object> appVector = (Vector<Object>)this.listApplications();
		
		List<String> appList = new ArrayList<String>();
		for(Object object : appVector) {
			
			appList.add((String)object);
		}
		
		
		return appList;
	}
	
	
	
	public String[][] loadCurrentWSTaskData() throws Exception {
		
		if(taskData == null) {
			
			this.setTaskData(((MapRolesToUsers)(((Vector<Object>)this.getApplicationInfo()).get(4))).getTaskData());
			
			logger.debug(new StandardLogMessage("Role/User mapping (TASKDATA) successfully loaded from " + appManagementQuery));
		}
		
		return taskData;
	}
	
	private String[][] getACopyOfCurrentWSTaskData() throws Exception {
		
		String[][] taskData = this.loadCurrentWSTaskData();
		
		
		String[][] copyTaskData = new String[taskData.length][taskData[0].length];
		
		for(int r=0; r<taskData.length; r++) {
			
			for(int c=0; c<taskData[0].length; c++) {
				
				copyTaskData[r][c] = taskData[r][c];
			}
		}
		
		return copyTaskData;
	}
	
	
	private Vector<?> getApplicationInfo() throws Exception {
		
		Object[] params = {SystemProperties.getProperty("app.name"), null, null};
		String[] signature = {"java.lang.String", "java.util.Hashtable", "java.lang.String"};
		
		return (Vector<?>)this.adminClient.invoke(this.appManagementMBean, "getApplicationInfo", params, signature);
	}
	
	private void setApplicationInfo(Vector<?> appInfo) throws Exception {
		
		Object[] params = {SystemProperties.getProperty("app.name"), null, null, appInfo};
		String[] signature = {"java.lang.String", "java.util.Hashtable", "java.lang.String", "java.util.Vector"};
		
		this.adminClient.invoke(this.appManagementMBean, "setApplicationInfo", params, signature);
	}
	
	/*private MapRolesToUsers getMapRolesToUsers() throws Exception {
		
		// get all app info
		
		System.out.println("before getApplicationInfo");
		
		Vector<Object> appInfoVector = (Vector<Object>)this.getApplicationInfo();
		
		System.out.println("after getApplicationInfo");
		
		// get app role/user info (the 4� in the list)
		return (MapRolesToUsers)appInfoVector.get(4);
	}*/
	
	
	
	
	
	private Vector<?> listApplications() throws Exception {
		
		Object[] params = {null, null};
		String[] signature = {"java.util.Hashtable", "java.lang.String"};
		
		return (Vector<?>)this.adminClient.invoke(this.appManagementMBean, "listApplications", params, signature);
	}



	public synchronized String[][] getTaskData() {
		
		return taskData;
	}



	private synchronized void setTaskData(String[][] inputTaskData) {
		
		taskData = inputTaskData;
	}
	
	
	
	private void printTaskData(String[][] taskData) {
		
		for(String[] line : taskData) {
			for(String lineElement : line) {
				
				System.out.print(lineElement + " || ");
			}
			
			System.out.println();
		}
	}
	
}
