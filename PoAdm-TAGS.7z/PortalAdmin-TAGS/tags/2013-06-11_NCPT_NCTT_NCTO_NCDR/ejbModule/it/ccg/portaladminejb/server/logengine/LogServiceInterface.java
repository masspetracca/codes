package it.ccg.portaladminejb.server.logengine;

import java.util.List;
import java.util.Map;

public interface LogServiceInterface {
	
	public List<Map<String, String>> getLogsListByType(String type) throws Exception;
	public List<LogLineDTO> getLog(String logFileName, Map<String, Object> filterParams) throws Exception;
	

}
