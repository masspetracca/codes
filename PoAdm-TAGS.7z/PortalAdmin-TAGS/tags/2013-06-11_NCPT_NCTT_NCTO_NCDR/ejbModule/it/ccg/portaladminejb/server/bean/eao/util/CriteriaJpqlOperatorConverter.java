package it.ccg.portaladminejb.server.bean.eao.util;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;


public class CriteriaJpqlOperatorConverter {
	
	
	private Map<String, String> map;
	
	private static final String METHOD = "method";
	
	private Logger logger = Logger.getLogger(this.getClass().getName());
	
	
	
	public CriteriaJpqlOperatorConverter() {
		
		this.map = new HashMap<String, String>();
		
		this.map.put("equals", "=");
		this.map.put("notEqual", "!=");
		this.map.put("iEquals", "");
		this.map.put("iNotEqual", "");
		this.map.put("greaterThan", ">");
		this.map.put("lessThan", "<");
		this.map.put("greaterOrEqual", ">=");
		this.map.put("lessOrEqual", "<=");
		this.map.put("contains", CriteriaJpqlOperatorConverter.METHOD);		// method
		this.map.put("startsWith", "");
		this.map.put("endsWith", "");
		this.map.put("iContains", CriteriaJpqlOperatorConverter.METHOD);		// method
		this.map.put("iStartsWith", "");
		this.map.put("iEndsWith", "");
		this.map.put("notContains", "");
		this.map.put("notStartsWith", "");
		this.map.put("notEndsWith", "");
		this.map.put("iNotContains", "");
		this.map.put("iNotStartsWith", "");
		this.map.put("iNotEndsWith", "");
		this.map.put("iBetweenInclusive", "");
		this.map.put("regexp", "");
		this.map.put("iregexp", "");
		this.map.put("isNull", "is null");
		this.map.put("notNull", "not null");
		this.map.put("inSet", "");
		this.map.put("notInSet", "");
		this.map.put("equalsField", "");
		this.map.put("notEqualField", "");
		this.map.put("greaterThanField", "");
		this.map.put("lessThanField", "");
		this.map.put("greaterOrEqualField", "");
		this.map.put("lessOrEqualField", "");
		this.map.put("containsField", "");
		this.map.put("startsWithField", "");
		this.map.put("endsWithField", "");
		this.map.put("and", "and");
		this.map.put("not", "");
		this.map.put("or", "");
		this.map.put("between", "");
		this.map.put("betweenInclusive", "");
		
	}
	
	
	public String convertToJPQL(String fieldCompleteName, String operator, String value) {
		
		String jpqlString = new String();
		
		if(!this.map.get(operator).equalsIgnoreCase(CriteriaJpqlOperatorConverter.METHOD)) {
			
			jpqlString = fieldCompleteName + " " + map.get(operator) + " " + value;
		}
		else {
			
			try {
				
				Method method = this.getClass().getMethod(operator, String.class, String.class);
				
				if(method == null) {
					logger.error("Cannot load method \'" + operator + "\'.");
					
					return jpqlString;
				}
				
				try {
					jpqlString = (String)method.invoke(this, fieldCompleteName, value);
				} 
				catch (IllegalArgumentException e) {
					logger.error(e.toString());
				} 
				catch (IllegalAccessException e) {
					logger.error(e.toString());
				} 
				catch (InvocationTargetException e) {
					logger.error(e.toString());
				}
				
			}
			catch (SecurityException e) {
				
				logger.error(e.toString());
			} 
			catch (NoSuchMethodException e) {
				logger.error(e.toString());
			}
			
			
		}
		
		
		return jpqlString;
	}
	
	
	
	
	
	// ***********************************
	// Generic method is named exactly as the operator, and has the value of criteria as input
	// ***********************************
	
	public String iContains(String fieldName, String value) {
		
		value = value.toUpperCase();
		
		return "UPPER(" + fieldName + ") LIKE \'%" + value + "%\'";
	}
	
	public String contains(String fieldName, String value) {
		
		return fieldName + " LIKE \'%" + value + "%\'";
	}
	
	
}



/*

"equals"	exactly equal to
"notEqual"	not equal to
"iEquals"	exactly equal to, if case is disregarded
"iNotEqual"	not equal to, if case is disregarded
"greaterThan"	Greater than
"lessThan"	Less than
"greaterOrEqual"	Greater than or equal to
"lessOrEqual"	Less than or equal to
"contains"	Contains as sub-string (match case)
"startsWith"	Starts with (match case)
"endsWith"	Ends with (match case)
"iContains"	Contains as sub-string (case insensitive)
"iStartsWith"	Starts with (case insensitive)
"iEndsWith"	Ends with (case insensitive)
"notContains"	Does not contain as sub-string (match case)
"notStartsWith"	Does not start with (match case)
"notEndsWith"	Does not end with (match case)
"iNotContains"	Does not contain as sub-string (case insensitive)
"iNotStartsWith"	Does not start with (case insensitive)
"iNotEndsWith"	Does not end with (case insensitive)
"iBetweenInclusive"	shortcut for "greaterOrEqual" + "and" + "lessOrEqual" (case insensitive)
"regexp"	Regular expression match
"iregexp"	Regular expression match (case insensitive)
"isNull"	value is null
"notNull"	value is non-null. Note empty string ("") is non-null
"inSet"	value is in a set of values. Specify criterion.value as an Array
"notInSet"	value is not in a set of values. Specify criterion.value as an Array
"equalsField"	matches another field (specify fieldName as criterion.value)
"notEqualField"	does not match another field (specify fieldName as criterion.value)
"greaterThanField"	Greater than another field (specify fieldName as criterion.value)
"lessThanField"	Less than another field (specify fieldName as criterion.value)
"greaterOrEqualField"	Greater than or equal to another field (specify fieldName as criterion.value)
"lessOrEqualField"	Less than or equal to another field (specify fieldName as criterion.value)
"containsField"	Contains as sub-string (match case) another field value (specify fieldName as criterion.value)
"startsWithField"	Starts with (match case) another field value (specify fieldName as criterion.value)
"endsWithField"	Ends with (match case) another field value (specify fieldName as criterion.value)
"and"	all subcriteria (criterion.criteria) are true
"not"	all subcriteria (criterion.criteria) are false
"or"	at least one subcriteria (criterion.criteria) is true
"between"	shortcut for "greaterThan" + "lessThan" + "and". Specify criterion.start and criterion.end
"betweenInclusive"	shortcut for "greaterOrEqual" + "lessOrEqual" + "and". Specify criterion.start and criterion.end

*/
