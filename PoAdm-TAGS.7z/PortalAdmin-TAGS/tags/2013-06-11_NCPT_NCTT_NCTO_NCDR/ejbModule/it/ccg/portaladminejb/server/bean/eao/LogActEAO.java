package it.ccg.portaladminejb.server.bean.eao;

import it.ccg.portaladminejb.server.bean.eao.util.Criteria;
import it.ccg.portaladminejb.server.bean.eao.util.CriteriaJpqlOperatorConverter;
import it.ccg.portaladminejb.server.bean.eao.util.JpaQuery;
import it.ccg.portaladminejb.server.bean.entity.LogActEntity;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class LogactEAO
 */
@Stateless
@Local(LogActEAOLocal.class)
public class LogActEAO implements LogActEAOLocal {
	
	private static Logger logger = PALoggerFactory.getLogger(PALoggerFactory.EJB_LOGGER);
	
    @PersistenceContext(unitName="PortalAdminEJB")
	private EntityManager em;
    
    
    public LogActEAO() {
        // TODO Auto-generated constructor stub
    }
 
    @Override
    public List<LogActEntity> fetch(List<Criteria> criteriaList, int startRow, int endRow) throws Exception {
		
    	JpaQuery jpaQuery = new JpaQuery("SELECT logAct", "FROM LogActEntity logAct", "WHERE 1=1", "", "", "ORDER BY logact.actdate desc");
    	
		CriteriaJpqlOperatorConverter criteriaConverter = new CriteriaJpqlOperatorConverter();
		
		// update query
		for(Criteria criteria : criteriaList) {
			
			jpaQuery.setWhereClause(jpaQuery.getWhereClause() + " AND " + criteriaConverter.convertToJPQL("logAct." + criteria.getFieldName(), criteria.getOperator(), (String)criteria.getValue()));
		}
		
    	Query query = this.em.createQuery(jpaQuery.toString());
    	// settings for paging
    	query.setFirstResult(startRow);
    	query.setMaxResults(endRow - startRow);
    	
    	logger.debug(new StandardLogMessage("Executing query: " + jpaQuery.toString()));
    	
		// execute query
		@SuppressWarnings("unchecked")
		List<LogActEntity> dataList = (List<LogActEntity>)query.getResultList();
     	
		
    	return dataList;
    }
    
    
    @Override
    public long fetchCount(List<Criteria> criteriaList) throws Exception {
		
    	JpaQuery jpaQuery = new JpaQuery("SELECT count(logAct)", "FROM LogActEntity logAct", "WHERE 1=1", "", "", "");
    	
		CriteriaJpqlOperatorConverter criteriaConverter = new CriteriaJpqlOperatorConverter();
		
		// update query
		for(Criteria criteriaDTO : criteriaList) {
			
			jpaQuery.setWhereClause(jpaQuery.getWhereClause() + " AND " + criteriaConverter.convertToJPQL("logAct." + criteriaDTO.getFieldName(), criteriaDTO.getOperator(), (String)criteriaDTO.getValue()));
		}
		
    	Query query = this.em.createQuery(jpaQuery.toString());
    	
    	logger.debug(new StandardLogMessage("Executing query: " + jpaQuery.toString()));
    	
		// execute query
		Object count = query.getSingleResult();
     	
		
    	return (Long)count;
	}
    
    
    
}
