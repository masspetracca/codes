package it.ccg.portaladminejb.server.bean.system;

import it.ccg.portaladminejb.server.bean.dao.RoleBeanLocal;
import it.ccg.portaladminejb.server.bean.dao.WSUserBeanLocal;
import it.ccg.portaladminejb.server.dto.LDAPUserDTO;
import it.ccg.portaladminejb.server.dto.Role;
import it.ccg.portaladminejb.server.dto.WSUserDTO;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;
import it.ccg.portaladminejb.server.service.ldap.LDAPManager;
import it.ccg.portaladminejb.server.system.SystemProperties;
import it.ccg.portaladminejb.server.util.ExceptionUtil;

import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.itextpdf.text.Element;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
@Stateless
public class PDFGenerator implements PDFGeneratorLocal {

	@EJB
	private RoleBeanLocal roleBeanLocal;
	
	@EJB
	private WSUserBeanLocal wsUserLocal;
	
	private static Logger logger = PALoggerFactory.getLogger(PALoggerFactory.WEB_LOGGER);
	
	private static Color ccgColor = new Color(0, 85, 150);
	private static Font titleFont = new Font(Font.HELVETICA,20, Font.BOLD,ccgColor);
	private static Font subTitleFont = new Font(Font.HELVETICA,18, Font.BOLD,ccgColor);
	private static Font subTitleColoredFont = new Font(Font.HELVETICA,11, Font.BOLD,ccgColor);
	private static Font tabTitleFont = new Font(Font.HELVETICA,11, Font.BOLD);
	private static Font contentFont = new Font(Font.HELVETICA,11);
	private static Font footerFont = new Font(Font.HELVETICA,8, Font.ITALIC);
	private Document doc;
	private PdfWriter writer;
	
	public PDFGenerator(){
		logger.debug(new StandardLogMessage("into PDFGenerator"));
		this.doc = new Document(PageSize.A4,20, 20, 40, 30);
		
		try {
			logger.debug(new StandardLogMessage("instantiation PdfWriter"));
			this.writer = PdfWriter.getInstance(this.doc, new FileOutputStream(SystemProperties.getProperty("user.install.root")+SystemProperties.getProperty("file.separator")+SystemProperties.getProperty("folder")));
		} catch (FileNotFoundException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (DocumentException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		}

	}
	
	public Document generatePdf(Map<LDAPUserDTO,List<Role>> map){
		logger.debug(new StandardLogMessage("into Document generatePdf(Map<WSUserDTO,List<Role>> map)"));
		
		//Phrase title = new Phrase("CCG - CCGPortal",footerFont);

		try {
			/*
			 * footer
			 */
			logger.debug(new StandardLogMessage("instantiating footer"));
			HeaderFooter footer = new HeaderFooter(new Phrase("Page ",footerFont),true);
			footer.setAlignment(Element.ALIGN_RIGHT);
			footer.setBorder(Rectangle.NO_BORDER);
			
			Image logo = Image.getInstance(IOUtils.toByteArray(this.getClass().getClassLoader().getResourceAsStream("/images/CCGlogo.gif")));
			logo.scalePercent(50);
			logo.setAlignment(Element.ALIGN_RIGHT);
			Chunk imageChunk = new Chunk(logo, 320, 0);
			
			/*
			 * header
			 */
			logger.debug(new StandardLogMessage("instantiating header"));
			HeaderFooter header = new HeaderFooter(new Phrase(imageChunk),false);
			header.setAlignment(Element.ALIGN_JUSTIFIED);
			header.setBorder(Rectangle.NO_BORDER);
			
			logger.debug(new StandardLogMessage("opening document and writer"));
			this.doc.open();
			this.doc.setHeader(header);
			this.doc.setFooter(footer);
			
			Image titleLogo = Image.getInstance(IOUtils.toByteArray(this.getClass().getClassLoader().getResourceAsStream("/images/CCGlogo.gif")));
					//"C:\\DeLauri\\workSpaceRAD\\PortalAdminWEB\\war\\CCGlogo.gif"
			titleLogo.scalePercent(100);
			titleLogo.setAlignment(Element.ALIGN_RIGHT);
			
			if (map.size()>0){
				logger.debug(new StandardLogMessage("map.size()>0"));
								
				PdfPTable table = new PdfPTable(4);
				logger.debug(new StandardLogMessage("creating header cells"));
	
				PdfPCell headerCell = new PdfPCell(new Phrase("User",tabTitleFont));
	
				Color c = new Color(189,210,226);
				headerCell.setBorderColor(Color.GRAY);
				headerCell.setBackgroundColor(c);
				headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
							
				table.addCell(headerCell);
				
				headerCell = new PdfPCell(new Phrase("E-Mail",tabTitleFont));
				headerCell.setBackgroundColor(c);
				headerCell.setBorderColor(Color.GRAY);
				headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(headerCell);
				
				headerCell = new PdfPCell(new Phrase("Company",tabTitleFont));
				headerCell.setBackgroundColor(c);
				headerCell.setBorderColor(Color.GRAY);
				headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(headerCell);
				
				headerCell = new PdfPCell(new Phrase("Assigned Roles",tabTitleFont));
				headerCell.setBackgroundColor(c);
				headerCell.setBorderColor(Color.GRAY);
				headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(headerCell);
				table.setHeaderRows(1);

				
				logger.debug(new StandardLogMessage("creating content cells"));
				logger.debug(new StandardLogMessage(map.size()+" elemets into map"));
				
				Set<LDAPUserDTO> keys = map.keySet();
				for(LDAPUserDTO s : keys){
					logger.debug(new StandardLogMessage("working "+s.getCn()+" entry"));
					PdfPCell cnCell = new PdfPCell(new Phrase(s.getCn() ,contentFont));
					cnCell.setBorderColor(Color.GRAY);
					PdfPCell ouCell = new PdfPCell(new Phrase(s.getOu() ,contentFont));
					ouCell.setBorderColor(Color.GRAY);
					PdfPCell mailCell = new PdfPCell(new Phrase(s.getMail() ,contentFont));
					mailCell.setBorderColor(Color.GRAY);
					
					List<Role> roles = map.get(s);
					String appoRoles = "";
					for (Role r : roles){
						if (!appoRoles.equalsIgnoreCase("")) 
							appoRoles+=", ";
						
						appoRoles+=r.getRole();
					}
					PdfPCell rolesCell = new PdfPCell(new Phrase(appoRoles,contentFont));
					rolesCell.setBorderColor(Color.GRAY);
					
					logger.debug(new StandardLogMessage("adding cells to table"));
					table.addCell(cnCell);
					table.addCell(mailCell);
					table.addCell(ouCell);
					table.addCell(rolesCell);
				}
				
				logger.debug(new StandardLogMessage("adding table to document"));
				
				logger.debug(new StandardLogMessage("creating paragraphs"));
				Paragraph tableTitle1row = new Paragraph("Active users on PAMP Web",titleFont);
				tableTitle1row.setAlignment(Element.ALIGN_CENTER);
				Paragraph tableTitle2row = new Paragraph("Front End",titleFont);
				tableTitle2row.setAlignment(Element.ALIGN_CENTER);
				Paragraph subTableTitle = new Paragraph(SystemProperties.getProperty("enviroment")+" Enviroment.",subTitleFont);
				subTableTitle.setAlignment(Element.ALIGN_CENTER);
				logger.debug(new StandardLogMessage("paragraphs created"));
				logger.debug(new StandardLogMessage("adding element to document"));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(titleLogo);
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(tableTitle1row);
				this.doc.add(tableTitle2row);
				this.doc.add(subTableTitle);
				logger.debug(new StandardLogMessage("creating date paragraph"));
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				Paragraph updatedDate = new Paragraph("Information updated on "+formatter.format(new Date()),subTitleColoredFont);
				updatedDate.setAlignment(Element.ALIGN_CENTER);
				logger.debug(new StandardLogMessage("data paragraph created"));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(new Paragraph(" "));
				this.doc.add(updatedDate);
				this.doc.newPage();
				this.doc.add(new Paragraph());
				this.doc.add(table);
				this.doc.add(Chunk.NEWLINE);
				this.doc.add(new Paragraph());
				logger.debug(new StandardLogMessage("element added to document"));
				
			}
		} catch (DocumentException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (MalformedURLException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		}finally{
			logger.debug(new StandardLogMessage("closing document and writer"));
			this.doc.close();
			this.writer.close();
		}
		logger.debug(new StandardLogMessage("document generated...return"));
		return this.doc;
	}
	
	public Map<LDAPUserDTO,List<Role>> populateMap(){
		logger.debug(new StandardLogMessage("into Map<LDAPUserDTO,List<Role>> populateMap()"));
		Map<WSUserDTO,List<Role>> appoMap = null;
		Map<LDAPUserDTO,List<Role>> toReturn = new HashMap<LDAPUserDTO, List<Role>>();
		try {
			logger.debug(new StandardLogMessage("calling wsUserLocal.listWSUsers()"));
			List<WSUserDTO> userList = this.wsUserLocal.listWSUsers();
			LDAPManager ldapManager = new LDAPManager();
			
			logger.debug(new StandardLogMessage("callig roleBeanLocal.getUserRoleMapping(userList)"));

			appoMap = this.roleBeanLocal.getUserRoleMapping(userList);
			logger.debug(new StandardLogMessage("casting result to Map<LDAPUserDTO,List<Role>>"));
			Set<WSUserDTO> keys = appoMap.keySet();
			for (WSUserDTO user : keys){
				LDAPUserDTO dto = ldapManager.getUserByContextName(user.getUserContextName());
				if(dto.getOu()==null || !dto.getOu().equalsIgnoreCase("CC&G")){
					toReturn.put(dto, this.convertRoles(appoMap.get(user)));
				}
			}

		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		}
		
		logger.debug(new StandardLogMessage("map complete... "+toReturn.size()+" records"));
		return toReturn;
	}
	
	private List<Role> convertRoles(List<Role> roles){
		
		for (Role r : roles){
			if(r.getRole().equalsIgnoreCase("user"))
				r.setRole("Risk Officer");
			if (r.getRole().equalsIgnoreCase("manager"))
				r.setRole("Manager");
			if (r.getRole().equalsIgnoreCase("visitor"))
				r.setRole("Visitor");
			if (r.getRole().equalsIgnoreCase("admin"))
				r.setRole("Admin");
			if (r.getRole().equalsIgnoreCase("causer"))
				r.setRole("Data Opeartor");
			if (r.getRole().equalsIgnoreCase("supervisor"))
				r.setRole("Supervisor");
		}
		return roles;	
	}
	public void cleanTemporaryFile(){
		logger.debug(new StandardLogMessage("into cleanTemporaryFile"));
		
		File f;
		try {
			f = new File(SystemProperties.getProperty("user.install.root")+SystemProperties.getProperty("file.separator")+SystemProperties.getProperty("folder"));
			logger.debug(new StandardLogMessage("deleting file"));
			f.delete();
			logger.debug(new StandardLogMessage("file deleted"));
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
		}
	}
}
