package it.ccg.portaladminejb.server.bean.eao;

import it.ccg.portaladminejb.server.entity.UserEntity;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

/**
 * Session Bean implementation class UserInfoEAO
 */
@Stateless
@Local(UserInfoEAOLocal.class)
public class UserInfoEAO implements UserInfoEAOLocal {
	
	
	@PersistenceContext(unitName="PortalAdminEJB", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	
    /**
     * Default constructor. 
     */
    public UserInfoEAO() {
        // TODO Auto-generated constructor stub
    }



	@Override
	public UserEntity findByPrimaryKey(String userName) throws Exception {
		
		UserEntity userEntity = (UserEntity)em.find(UserEntity.class, userName);
		
		return userEntity;
	}

}
