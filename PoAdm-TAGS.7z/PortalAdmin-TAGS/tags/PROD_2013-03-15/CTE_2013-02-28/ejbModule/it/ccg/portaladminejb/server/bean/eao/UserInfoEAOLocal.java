package it.ccg.portaladminejb.server.bean.eao;

import it.ccg.portaladminejb.server.entity.UserEntity;

import javax.ejb.Local;


@Local
public interface UserInfoEAOLocal {
	
	public UserEntity findByPrimaryKey(String userName) throws Exception;
	
}
