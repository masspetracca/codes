/**
 * 
 */


var ticker = new EventSource("Test");
ticker.onmessage = function(e) {
						var type = e.type;
						var data = e.data;
						
						alert("!!");
				   };