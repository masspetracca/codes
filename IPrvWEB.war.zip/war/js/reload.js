/**
 * 
 */



function reload() {
	
	var isFirstLoad = gup('isFirstLoad');
	
	alert(isFirstLoad);
	
	if(isFirstLoad == "true") {
		//window.location = "login.html?isFirstLoad=false";
		window.location = "index.html";
	}
	
}


function gup(paramName) {
	paramName = paramName.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
	var regexS = "[\\?&]"+ paramName +"=([^&#]*)";
	var regex = new RegExp(regexS);
	
	var results = regex.exec(window.location.href);
	if( results == null )
		return "";
	else
		return results[1];
}