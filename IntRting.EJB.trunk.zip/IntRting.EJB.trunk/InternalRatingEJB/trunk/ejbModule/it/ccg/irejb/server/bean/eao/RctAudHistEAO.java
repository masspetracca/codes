package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctAudHistEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.text.SimpleDateFormat;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RctAudHistEAO
 */
@Stateless
@Local(RctAudHistEAOLocal.class)
public class RctAudHistEAO implements RctAudHistEAOLocal {
	@PersistenceContext(unitName="InternalRatingEJB", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	
	@Resource
	private SessionContext sessionContext;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public RctAudHistEAO() {
        // TODO Auto-generated constructor stub
    }
    
    @Override
    public void insertAuditFlow(RctAudHistEntity entity) throws BackEndException{
    	try{
	    	ejbLogger.debug(new StandardLogMessage("in insertAuditFlow(RctAudHistEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctAudHistEntity identification data: date= "+ new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(entity.getId().getAudHisDat())+" application code= "+entity.getId().getApplCode()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	Query q = manager.createNativeQuery("INSERT INTO RCTAUDHIST(AUDHISDAT, APPLCODE, UPDUSER, UPDDATE, UPDTYPE, AUDHBLOB) "+
	    										"VALUES(now(), ?, '"+sessionContext.getCallerPrincipal().getName()+"', now(), 'C',?)");
	    	
	    	q.setParameter(1, entity.getId().getApplCode());
	    	q.setParameter(2, entity.getAudHBlob());

	    	q.executeUpdate();
	    		   	    	
    	}catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
    }
        
    public List<RctAudHistEntity> fetch() throws Exception {

    	String queryString ="SELECT AUDHISDAT, APPLCODE, UPDUSER, UPDDATE, UPDTYPE, AUDHBLOB FROM RCTAUDHIST";

		Query query = this.manager.createNativeQuery(queryString, RctAudHistEntity.class);
		List<RctAudHistEntity> auditList = (List<RctAudHistEntity>)query.getResultList();
		for (RctAudHistEntity entity : auditList){
			if(entity.getAudHBlob()!=null)
				System.out.println(new String(entity.getAudHBlob()));// entity.getAudHBlob().toString());
		}
		return auditList;
	}
}
