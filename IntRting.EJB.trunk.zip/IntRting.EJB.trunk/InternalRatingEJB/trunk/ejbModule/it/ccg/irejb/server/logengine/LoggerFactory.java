package it.ccg.irejb.server.logengine;

import org.apache.log4j.Logger;


public class LoggerFactory {
	
	public static final String EJB_LOGGER = "irejb.server.logger";
	public static final String WEB_LOGGER = "irweb.server.logger";
	public static final String USER_LOGGER = "irweb.server.user_logger";
	public static final String CALCULATION_LOGGER = "irweb.server.calculation_logger";
	
	
	public static Logger getLogger(String loggerType){
		
		Logger logger = null;
		
		
		if(loggerType.equalsIgnoreCase(EJB_LOGGER)) {
			
			logger =  Logger.getLogger(EJB_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(WEB_LOGGER)) {
			
			logger =  Logger.getLogger(WEB_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(USER_LOGGER)) {
			
			logger =  Logger.getLogger(USER_LOGGER);
		}
		else if(loggerType.equalsIgnoreCase(CALCULATION_LOGGER)) {
			
			logger =  Logger.getLogger(CALCULATION_LOGGER);
		}
		else {
			
			try {
				throw new Exception("loggerType \'" + loggerType + "\' not defined.");
			}
			catch (Exception e) {
				
				e.printStackTrace();
			}
			
		}
		
		
		return logger;
	}

}
