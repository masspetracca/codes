package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctIssFldEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RctIssFldEAO
 */
@Stateless
@Local(RctIssFldEAOLocal.class)
public class RctIssFldEAO implements RctIssFldEAOLocal {

	@PersistenceContext(unitName="InternalRatingEJB", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public RctIssFldEAO() {
        // TODO Auto-generated constructor stub
    }

	@SuppressWarnings("deprecation")
	@Override
	public void insertIssFld(RctIssFldEntity entity) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in insertIssFld(RctIssFldEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctIssuesEntity identification data: Reuters code = "+entity.getId().getRCode()+" value date "+entity.getId().getValueDate().getDate()+"/"+(entity.getId().getValueDate().getMonth()+1)+"/"+entity.getId().getValueDate().getYear()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
		
	}

	@SuppressWarnings("deprecation")
	@Override
	public void deleteIssFld(RctIssFldEntity entity) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteIssFld(RctIssFldEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctIssuesEntity identification data: Reuters code = "+entity.getId().getRCode()+" value date "+entity.getId().getValueDate().getDate()+"/"+(entity.getId().getValueDate().getMonth()+1)+"/"+entity.getId().getValueDate().getYear()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
	}

	@SuppressWarnings("deprecation")
	@Override
	public void updateIssFld(RctIssFldEntity entity) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateIssFld(RctIssFldEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctIssuesEntity identification data: Reuters code = "+entity.getId().getRCode()+" value date "+entity.getId().getValueDate().getDate()+"/"+(entity.getId().getValueDate().getMonth()+1)+"/"+entity.getId().getValueDate().getYear()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RctIssFldEntity> retrieveIssFldByRCode(String rCode) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctIssFldEntity> retrieveIssFldByRCode(String rCode)"));
	    	ejbLogger.debug(new StandardLogMessage("Retures code: "+rCode));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getIssFldByRCode");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("rCode", rCode);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctIssFldEntity> issues = (List<RctIssFldEntity>) q.getResultList();
			
	    	return issues;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RctIssFldEntity> retrieveLatestIssFld() throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctIssFldEntity> retrieveLatestIssFld()"));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getLatestIssFld");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));

	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctIssFldEntity> issues = (List<RctIssFldEntity>) q.getResultList();
			
	    	return issues;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}

}
