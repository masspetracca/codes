package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RCTTRSCODE database table.
 * 
 */
@Embeddable
public class RctTrscodeEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int ranking;

	@Column(unique=true, nullable=false, length=1)
	private String provider;

    public RctTrscodeEntityPK() {
    }
	public int getRanking() {
		return this.ranking;
	}
	public void setRanking(int ranking) {
		this.ranking = ranking;
	}
	public String getProvider() {
		return this.provider;
	}
	public void setProvider(String provider) {
		this.provider = provider;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RctTrscodeEntityPK)) {
			return false;
		}
		RctTrscodeEntityPK castOther = (RctTrscodeEntityPK)other;
		return 
			(this.ranking == castOther.ranking)
			&& this.provider.equals(castOther.provider);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.ranking;
		hash = hash * prime + this.provider.hashCode();
		
		return hash;
    }
}