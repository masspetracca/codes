package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.bean.entity.RctBankEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.io.File;
import java.util.List;

public interface ActiveBanksBeanLocal {

	 public List<RctBankEntity> getActiveBanksList() throws BackEndException;
	 public File getActiveBanksFitchFile() throws BackEndException;
}
