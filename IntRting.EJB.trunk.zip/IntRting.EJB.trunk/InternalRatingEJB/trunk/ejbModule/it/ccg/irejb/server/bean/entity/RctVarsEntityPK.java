package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RCTVARS database table.
 * 
 */
@Embeddable
public class RctVarsEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false, length=255)
	private int varid;

	@Column(unique=true, nullable=false, length=1)
	private String provider;

    public RctVarsEntityPK() {
    }
	public int getVarid() {
		return this.varid;
	}
	public void setVarid(int varid) {
		this.varid = varid;
	}
	public String getProvider() {
		return this.provider;
	}
	public void setProvider(String provider) {
		this.provider = provider;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RctVarsEntityPK)) {
			return false;
		}
		RctVarsEntityPK castOther = (RctVarsEntityPK)other;
		return 
			this.varid==castOther.varid
			&& this.provider.equals(castOther.provider);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.varid;
		hash = hash * prime + this.provider.hashCode();
		
		return hash;
    }
}