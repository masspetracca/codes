package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.exception.BackEndException;

public interface ImportsBeanLocal {

	public int insertBankCsvValue(String[][] dati,String user) throws BackEndException;
	public int insertThresholdCsvValue(String[][] dati,String user,int varId) throws BackEndException;
}
