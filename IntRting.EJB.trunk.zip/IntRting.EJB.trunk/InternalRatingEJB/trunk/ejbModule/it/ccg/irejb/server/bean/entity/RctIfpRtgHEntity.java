package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the RCTIFPRTGH database table.
 * 
 */
@Entity
//@Table(name="PAMPTEST.RCTIFPRTGH")
@Table(name="RCTIFPRTGH")
@NamedQueries({
	@NamedQuery(name="getRatingHByBankId", query="SELECT rating FROM RctIfpRtgHEntity rating WHERE rating.id.bankid = :bankid ORDER BY rating.id.lstupddate DESC"),
	@NamedQuery(name="getRatingByProvider", query="SELECT rating FROM RctIfpRtgHEntity rating WHERE rating.id.provider= :provider ORDER BY rating.id.lstupddate DESC"),
	@NamedQuery(name="getRatingByRtgType", query="SELECT rating FROM RctIfpRtgHEntity rating WHERE rating.id.rtgtype = :rtgtype ORDER BY rating.id.lstupddate DESC"),
})
public class RctIfpRtgHEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RctIfpRtgHEntityPK id;

	@Column(nullable=false, length=10)
	private String rtgcode;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

	//bi-directional many-to-one association to RctBankEntity
    @ManyToOne
	@JoinColumn(name="BANKID", nullable=false, insertable=false, updatable=false)
	private RctBankEntity rctbank;

    public RctIfpRtgHEntity() {
    }

	public RctIfpRtgHEntityPK getId() {
		return this.id;
	}

	public void setId(RctIfpRtgHEntityPK id) {
		this.id = id;
	}
	
	public String getRtgcode() {
		return this.rtgcode;
	}

	public void setRtgcode(String rtgcode) {
		this.rtgcode = rtgcode;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

	public RctBankEntity getRctbank() {
		return this.rctbank;
	}

	public void setRctbank(RctBankEntity rctbank) {
		this.rctbank = rctbank;
	}
	
}