package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.bean.entity.RctIssFldEntity;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.math3.analysis.function.Log;
import org.apache.commons.math3.stat.descriptive.moment.StandardDeviation;
import org.apache.log4j.Logger;

public class RatingClass {

	private double avgSpread=0;
	private double stdDeviation=0;
	private double minStdDev=0;
	private double maxStdDev=0;
	private double avgStdDev=0;
	private double lnAvgStdDev=0;
	private List<RctIssFldEntity> issues;
	
	private Logger calcLogger = Logger.getLogger(LoggerFactory.CALCULATION_LOGGER);
	
	private StandardDeviation stdDev;
	
	public RatingClass(){
		stdDev = new StandardDeviation();
		this.issues = new ArrayList<RctIssFldEntity>();
	}

	/**
	 * @return the avgSpread
	 */
	public double getAvgSpread() {
		if(avgSpread==0){
			this.avgCalculation();
		}
		return avgSpread;
	}

	/**
	 * @param avgSpread the avgSpread to set
	 */
	public void setAvgSpread(double avgSpread) {
		this.avgSpread = avgSpread;
	}

	/**
	 * @return the stdDeviation
	 */
	public double getStdDeviation() {
		if (stdDeviation == 0){
			this.standardDevCalculation();
		}
		return stdDeviation;
	}

	/**
	 * @param stdDeviation the stdDeviation to set
	 */
	public void setStdDeviation(double stdDeviation) {
		this.stdDeviation = stdDeviation;
	}

	/**
	 * @return the minStdDev
	 */
	public double getMinStdDev() {
		if (this.minStdDev==0){
			this.minStdDevCalculation();
		}
		return minStdDev;
	}

	/**
	 * @param minStdDev the minStdDev to set
	 */
	public void setMinStdDev(double minStdDev) {
		this.minStdDev = minStdDev;
	}

	/**
	 * @return the maxStdDev
	 */
	public double getMaxStdDev() {
		if(this.maxStdDev==0){
			this.maxStdDevCalculation();
		}
		return maxStdDev;
	}

	/**
	 * @param maxStdDev the maxStdDev to set
	 */
	public void setMaxStdDev(double maxStdDev) {
		this.maxStdDev = maxStdDev;
	}

	/**
	 * @return the avgStdDev
	 */
	public double getAvgStdDev() {
		if (this.avgStdDev==0){
			this.avgStdDevCalculation();
		}
		return avgStdDev;
	}

	/**
	 * @param avgStdDev the avgStdDev to set
	 */
	public void setAvgStdDev(double avgStdDev) {
		this.avgStdDev = avgStdDev;
	}

	/**
	 * @return the lnAvgStdDev
	 */
	public double getLnAvgStdDev() {
		if (lnAvgStdDev==0){
			this.lnAvgStdDevCalculation();
		}
		calcLogger.debug(new StandardLogMessage("ln(media*)= "+this.lnAvgStdDev));
		return lnAvgStdDev;
	}

	/**
	 * @param lnAvgStdDev the lnAvgStdDev to set
	 */
	public void setLnAvgStdDev(double lnAvgStdDev) {
		this.lnAvgStdDev = lnAvgStdDev;
	}

	/**
	 * @return the issuer
	 */
	public List<RctIssFldEntity> getIssuer() {
		return issues;
	}

	/**
	 * @param issuer the issuer to set
	 */
	public void setIssuer(ArrayList<RctIssFldEntity> issues) {
		this.issues = issues;
	}

	public void avgCalculation(){
		calcLogger.debug(new StandardLogMessage("in RatingClass.avgCalculation()"));
		double appo=0;
		for(RctIssFldEntity i: this.issues){
			appo+= i.getMtStOtrSpr().doubleValue();
		}
		this.avgSpread = appo/(double)this.issues.size();
		calcLogger.debug(new StandardLogMessage("avg value "+this.getAvgSpread()));
		calcLogger.debug(new StandardLogMessage("return"));
	}
	
	public void standardDevCalculation(){
		calcLogger.debug(new StandardLogMessage("in RatingClass.standardDevCalculation()"));
		double[] spread = new double[this.issues.size()];
		for(int i=0;i<this.issues.size();i++){
			spread[i]=this.issues.get(i).getMtStOtrSpr().doubleValue();
		}
		this.stdDeviation = this.stdDev.evaluate(spread);
		calcLogger.debug(new StandardLogMessage("standard deviation value "+this.getStdDeviation()));
		calcLogger.debug(new StandardLogMessage("return"));
	}
	
	public void minStdDevCalculation(){
		calcLogger.debug(new StandardLogMessage("in RatingClass.minStdDevCalculation()"));
		if (this.avgSpread==0){
			calcLogger.debug(new StandardLogMessage("avgSpread not available then go to calculation"));
			this.avgCalculation();
		}
		
		if (this.stdDeviation==0){
			calcLogger.debug(new StandardLogMessage("stdDeviation not available then go to calculation"));
			this.standardDevCalculation();
		}
		
		double appoMin = this.avgSpread -(2*this.stdDeviation);
		calcLogger.debug(new StandardLogMessage("appoMin = "+appoMin));
		if (appoMin<0.0001){
			this.minStdDev = 0.0001;
		}else{
			this.minStdDev = appoMin;
		}
		calcLogger.debug(new StandardLogMessage("Calculation completed. Result "+this.minStdDev));
		calcLogger.debug(new StandardLogMessage("return"));
	}
	
	public void maxStdDevCalculation(){
		calcLogger.debug(new StandardLogMessage("in RatingClass.maxStdDevCalculation()"));
		if (this.avgSpread==0){
			calcLogger.debug(new StandardLogMessage("avgSpread not available then go to calculation"));
			this.avgCalculation();
		}
		
		if (this.stdDeviation==0){
			calcLogger.debug(new StandardLogMessage("stdDeviation not available then go to calculation"));
			this.standardDevCalculation();
		}
		
		double appoMax = this.avgSpread +(2*this.stdDeviation);
		calcLogger.debug(new StandardLogMessage("appoMax = "+appoMax));
		if (appoMax<0.0001){
			this.maxStdDev = 0.0001;
		}else{
			this.maxStdDev = appoMax;
		}
		calcLogger.debug(new StandardLogMessage("Calculation completed. Result "+this.maxStdDev));
		calcLogger.debug(new StandardLogMessage("return"));
	}
	
	public void avgStdDevCalculation(){
		calcLogger.debug(new StandardLogMessage("in RatingClass.avgStdDevCalculation()"));
		double appoAvgStdDev=0.0;
		double divAvgStdDev=0;
		for(RctIssFldEntity  iss : this.issues){
			if(iss.getMtStOtrSpr().doubleValue()<this.getMaxStdDev() && iss.getMtStOtrSpr().doubleValue()> this.getMinStdDev()){
				appoAvgStdDev+=iss.getMtStOtrSpr().doubleValue();
				divAvgStdDev++;
			}
		}
		this.avgStdDev = appoAvgStdDev/divAvgStdDev;
		calcLogger.debug(new StandardLogMessage("media* "+this.avgStdDev));
		calcLogger.debug(new StandardLogMessage("return"));
	}
	
	public void lnAvgStdDevCalculation(){
		calcLogger.debug(new StandardLogMessage("in RatingClass.lnAvgStdDevCalculation"));
		Log logarithm = new Log();
		
		this.lnAvgStdDev = logarithm.value(this.getAvgStdDev());
		calcLogger.debug(new StandardLogMessage("Calculation completed. Result "+this.lnAvgStdDev));
		calcLogger.debug(new StandardLogMessage("return"));
	}
}
