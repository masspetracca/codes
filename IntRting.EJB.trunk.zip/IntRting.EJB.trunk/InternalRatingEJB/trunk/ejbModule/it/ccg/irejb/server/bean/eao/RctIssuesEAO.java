package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctIssuesEntity;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class RctIssuesEAO
 */
@Stateless
@Local(RctIssuesEAOLocal.class)
public class RctIssuesEAO implements RctIssuesEAOLocal {

	@PersistenceContext(unitName="InternalRatingEJB", type = PersistenceContextType.TRANSACTION)
	private EntityManager manager;
	
	private Logger ejbLogger = Logger.getLogger(LoggerFactory.EJB_LOGGER);
    /**
     * Default constructor. 
     */
    public RctIssuesEAO() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public void insertIssue(RctIssuesEntity entity) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in insertIssue(RctIssuesEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctIssuesEntity identification data: Reuters code = "+entity.getId().getRCode()+", ticker= "+entity.getId().getRTicker()));
	    	ejbLogger.debug(new StandardLogMessage("insert"));
	    	
	    	this.manager.persist(entity);
	    	this.manager.flush();
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
	}

	@SuppressWarnings("deprecation")
	@Override
	public void deleteIssue(RctIssuesEntity entity) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in deleteIssue(RctIssuesEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctIssuesEntity identification data: Reuters code = "+entity.getId().getRCode()+" ticker = "+entity.getId().getRTicker()+" value date "+entity.getId().getValueDate().getDate()+"/"+(entity.getId().getValueDate().getMonth()+1)+"/"+entity.getId().getValueDate().getYear()));
	    	ejbLogger.debug(new StandardLogMessage("delete"));
	    	this.manager.remove(entity);
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
	}

	@SuppressWarnings("deprecation")
	@Override
	public void updateIssue(RctIssuesEntity entity) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in updateIssue(RctIssuesEntity entity)"));
	    	ejbLogger.debug(new StandardLogMessage("RctIssuesEntity identification data: Reuters code = "+entity.getId().getRCode()+" ticker = "+entity.getId().getRTicker()+" value date "+entity.getId().getValueDate().getDate()+"/"+(entity.getId().getValueDate().getMonth()+1)+"/"+entity.getId().getValueDate().getYear()));
	    	ejbLogger.debug(new StandardLogMessage("update"));
	    	this.manager.merge(entity);
    	}catch(Exception e){
    		ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
    	}
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RctIssuesEntity> retrieveIssuesByRCode(String rCode) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctIssuesEntity> retrieveIssuesByRCode(String rCode)"));
	    	ejbLogger.debug(new StandardLogMessage("Retures code: "+rCode));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getIssuesByRCode");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("rCode", rCode);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctIssuesEntity> issues = (List<RctIssuesEntity>) q.getResultList();
			
	    	return issues;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RctIssuesEntity> retrieveIssuesByTicker(String rTicker)	throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctIssuesEntity> retrieveIssuesByTicker(String rTicker)"));
	    	ejbLogger.debug(new StandardLogMessage("Retures ticker: "+rTicker));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getIssuesByTicker");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("rTicker", rTicker);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctIssuesEntity> issues = (List<RctIssuesEntity>) q.getResultList();
			
	    	return issues;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RctIssuesEntity> retrieveLatestIssuesByTicker(String rTicker) throws BackEndException {
		try{
	    	ejbLogger.debug(new StandardLogMessage("in List<RctIssuesEntity> retrieveLatestIssuesByTicker(String rTicker)"));
	    	ejbLogger.debug(new StandardLogMessage("Retures ticker: "+rTicker));
	    	ejbLogger.debug(new StandardLogMessage("createNamedQuery"));
	    	Query q = this.manager.createNamedQuery("getLatestIssuesByTicker");
	    	ejbLogger.debug(new StandardLogMessage("populate named query"));
	    	q.setParameter("rTicker", rTicker);
	    	
	    	ejbLogger.debug(new StandardLogMessage("getResultList"));
			List<RctIssuesEntity> issues = (List<RctIssuesEntity>) q.getResultList();
			
	    	return issues;
	    }catch(Exception e){
	    	ExceptionUtil.logCompleteStackTrace(ejbLogger, e);
			throw new BackEndException(e);
		}
	}
}
