package it.ccg.irejb.server.bean;

import it.ccg.irejb.server.exception.BackEndException;

public interface ApproveRatingsLocal {
	public void approve(String rcCode, String user) throws BackEndException;
}
