package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctVarHEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

public interface RctVarHEAOLocal {

	public void insertRtcVarHistory(RctVarHEntity entity);
    public void deleteRtcVarHistory(RctVarHEntity entity);
    public void updateRtcVarHistory(RctVarHEntity entity);
    public RctVarHEntity retrieveRtcVarHistoryById(int varId,String provider,String valueDate) throws BackEndException;
	public List<RctVarHEntity> retrieveVarHhistByVarId(int varId);
	public List<RctVarHEntity> retrieveVarHhistByProvider(String provider);
	public List<RctVarHEntity> retrieveVarHhistByValueDate(String valueDate) throws BackEndException;
	public List<RctVarHEntity> retrieveVarHhistByVarIdFitchNName(int varId, String fitchNName);
	
}
