package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RCTVARH database table.
 * 
 */
@Embeddable
public class RctVarHEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
		private static final long serialVersionUID = 1L;

		@Column(unique=true, nullable=false)
		private int varid;

		@Column(unique=true, nullable=false, length=50)
		private String fitchnname;

		@Column(unique=true, nullable=false, length=1)
		private String provider;

	    @Temporal( TemporalType.TIMESTAMP)
		@Column(unique=true, nullable=false)
		private java.util.Date valuedate;

	    public RctVarHEntityPK() {
	    }
		public int getVarid() {
			return this.varid;
		}
		public void setVarid(int varid) {
			this.varid = varid;
		}
		public String getFitchnname() {
			return this.fitchnname;
		}
		public void setFitchnname(String fitchnname) {
			this.fitchnname = fitchnname;
		}
		public String getProvider() {
			return this.provider;
		}
		public void setProvider(String provider) {
			this.provider = provider;
		}
		public java.util.Date getValuedate() {
			return this.valuedate;
		}
		public void setValuedate(java.util.Date valuedate) {
			this.valuedate = valuedate;
		}

		public boolean equals(Object other) {
			if (this == other) {
				return true;
			}
			if (!(other instanceof RctVarHEntityPK)) {
				return false;
			}
			RctVarHEntityPK castOther = (RctVarHEntityPK)other;
			return 
				(this.varid == castOther.varid)
				&& this.fitchnname.equals(castOther.fitchnname)
				&& this.provider.equals(castOther.provider)
				&& this.valuedate.equals(castOther.valuedate);

	    }
	    
		public int hashCode() {
			final int prime = 31;
			int hash = 17;
			hash = hash * prime + this.varid;
			hash = hash * prime + this.fitchnname.hashCode();
			hash = hash * prime + this.provider.hashCode();
			hash = hash * prime + this.valuedate.hashCode();
			
			return hash;
	    }
	}