package it.ccg.irejb.server.bean.eao;

import it.ccg.irejb.server.bean.entity.RctIssuesEntity;
import it.ccg.irejb.server.exception.BackEndException;

import java.util.List;

public interface RctIssuesEAOLocal {

	public void insertIssue(RctIssuesEntity entity) throws BackEndException;
	public void deleteIssue(RctIssuesEntity entity) throws BackEndException;
	public void updateIssue(RctIssuesEntity entity) throws BackEndException;
	public List<RctIssuesEntity> retrieveIssuesByRCode(String rCode) throws BackEndException;
	public List<RctIssuesEntity> retrieveIssuesByTicker(String rTicker) throws BackEndException;
	public List<RctIssuesEntity> retrieveLatestIssuesByTicker(String rTicker) throws BackEndException;
	
}
