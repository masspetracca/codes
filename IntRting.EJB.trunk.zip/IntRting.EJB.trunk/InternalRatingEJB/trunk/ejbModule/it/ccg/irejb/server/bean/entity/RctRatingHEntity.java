package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the RCTRATINGH database table.
 * 
 */
@Entity
//@Table(name="PAMPTEST.RCTRATINGH")
@Table(name="RCTRATINGH")
@NamedQueries({
	@NamedQuery(name="getRatingHistByBankId", query="SELECT ratingHist FROM RctRatingHEntity ratingHist WHERE ratingHist.id.bankid = :bankid ORDER BY ratingHist.id.ratingdate DESC"),
	@NamedQuery(name="getRatingHistByRatingDate", query="SELECT ratingHist FROM RctRatingHEntity ratingHist WHERE ratingHist.id.ratingdate= :ratingdate ORDER BY ratingHist.id.ratingdate DESC"),
	@NamedQuery(name="getRatingHistByStatus", query="SELECT ratingHist FROM RctRatingHEntity ratingHist WHERE ratingHist.status = :status ORDER BY ratingHist.id.ratingdate DESC"),
})
public class RctRatingHEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RctRatingHEntityPK id;

	@Column(nullable=false, length=30)
	private String approvedby;

	@Column(nullable=false, precision=15, scale=8)
	private BigDecimal apprrtg;

	@Column(precision=15, scale=8)
	private BigDecimal balancertg;

	@Column(length=1000)
	private String comment;

	@Column(precision=15, scale=8)
	private BigDecimal externrtg;

	@Column(length=1000)
	private String note;

	@Column(precision=15, scale=8)
	private BigDecimal proprtg;

	@Column(precision=15, scale=8)
	private BigDecimal spreadrtg;

	@Column(length=1)
	private String status;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

	//bi-directional many-to-one association to RctBankEntity
    @ManyToOne
	@JoinColumn(name="BANKID", nullable=false, insertable=false, updatable=false)
	private RctBankEntity rctbank;

	//bi-directional many-to-one association to RctRiskComEntity
    @ManyToOne
	@JoinColumn(name="RCCOD", nullable=false)
	private RctRiskComEntity rctriskcom;

    public RctRatingHEntity() {
    }

	public RctRatingHEntityPK getId() {
		return this.id;
	}

	public void setId(RctRatingHEntityPK id) {
		this.id = id;
	}
	
	public String getApprovedby() {
		return this.approvedby;
	}

	public void setApprovedby(String approvedby) {
		this.approvedby = approvedby;
	}

	public BigDecimal getApprrtg() {
		return this.apprrtg;
	}

	public void setApprrtg(BigDecimal apprrtg) {
		this.apprrtg = apprrtg;
	}

	public BigDecimal getBalancertg() {
		return this.balancertg;
	}

	public void setBalancertg(BigDecimal balancertg) {
		this.balancertg = balancertg;
	}

	public String getComment() {
		return this.comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public BigDecimal getExternrtg() {
		return this.externrtg;
	}

	public void setExternrtg(BigDecimal externrtg) {
		this.externrtg = externrtg;
	}

	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public BigDecimal getProprtg() {
		return this.proprtg;
	}

	public void setProprtg(BigDecimal proprtg) {
		this.proprtg = proprtg;
	}

	public BigDecimal getSpreadrtg() {
		return this.spreadrtg;
	}

	public void setSpreadrtg(BigDecimal spreadrtg) {
		this.spreadrtg = spreadrtg;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

	public RctBankEntity getRctbank() {
		return this.rctbank;
	}

	public void setRctbank(RctBankEntity rctbank) {
		this.rctbank = rctbank;
	}
	
	public RctRiskComEntity getRctriskcom() {
		return this.rctriskcom;
	}

	public void setRctriskcom(RctRiskComEntity rctriskcom) {
		this.rctriskcom = rctriskcom;
	}
	
	public void copyRatingData(RctRatingEntity ent){
		this.setBalancertg(ent.getBalancertg());
		this.setComment(ent.getComment());
		this.setExternrtg(ent.getExternrtg());
		this.setNote(ent.getNote());
		this.setProprtg(ent.getProprtg());
		this.setSpreadrtg(ent.getSpreadrtg());
		this.setStatus(ent.getStatus());
	}
	
}