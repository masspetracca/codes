package it.ccg.irejb.server.bean.entity;

import java.io.Serializable;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the RCTTHRSHLD database table.
 * 
 */
@Entity
//@Table(name="PAMPTEST.RCTTHRSHLD")
@Table(name="RCTTHRSHLD")
@NamedQueries({
	@NamedQuery(name="getThrshldByVarId", query="SELECT threshold " +
			"									   FROM RctThrshldEntity threshold " +
			"									  WHERE threshold.varid = :varid " +
			"										AND threshold.thrshlddte = (SELECT MAX(threshold2.thrshlddte) " +
			"																	  FROM RctThrshldEntity threshold2 " +
			"																	 WHERE threshold2.varid = threshold.varid) " +
			"									  ORDER BY threshold.thrshldop ASC"),
	@NamedQuery(name="getThrshldByVarIdForCalc", query="SELECT threshold FROM RctThrshldEntity threshold WHERE threshold.varid = :varid AND threshold.thrshlddte = (SELECT MAX(threshold2.thrshlddte) FROM RctThrshldEntity threshold2 WHERE threshold2.varid = threshold.varid) ORDER BY threshold.THRSHLDVAL ASC"),
	@NamedQuery(name="getThrshldByThrshldDate", query="SELECT threshold FROM RctThrshldEntity threshold WHERE threshold.thrshlddte= :thrshlddte ORDER BY threshold.thrshlddte DESC"),
	@NamedQuery(name="getThrshldByThrshldId", query="SELECT threshold FROM RctThrshldEntity threshold WHERE threshold.thrsholdid = :thrsholdid ORDER BY threshold.thrshlddte DESC")
})
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class RctThrshldEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private int thrsholdid;

	@Column(nullable=false)
	private double thrshldcoe;

	@Temporal( TemporalType.TIMESTAMP)
	@Column(unique=true, nullable=false)
	private Timestamp thrshlddte;

	@Column(updatable=false, unique=true, nullable=false)
	private int varid;
	
	@Column(length=4)
	private String thrshldop;
	
	@Column
	private Double thrshldval;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

	/**
	 * @return the thrsholdid
	 */
	public int getThrsholdid() {
		return thrsholdid;
	}

	/**
	 * @return the varid
	 */
	public int getVarid() {
		return varid;
	}

	/**
	 * @param varid the varid to set
	 */
	public void setVarid(int varid) {
		this.varid = varid;
	}
	
	/**
	 * @param thrsholdid the thrsholdid to set
	 */
	public void setThrsholdid(int thrsholdid) {
		this.thrsholdid = thrsholdid;
	}

	/**
	 * @return the thrshldcoe
	 */
	public double getThrshldcoe() {
		return thrshldcoe;
	}

	/**
	 * @param thrshldcoe the thrshldcoe to set
	 */
	public void setThrshldcoe(double thrshldcoe) {
		this.thrshldcoe = thrshldcoe;
	}

	/**
	 * @return the thrshlddte
	 */
	public Timestamp getThrshlddte() {
		return thrshlddte;
	}

	/**
	 * @param thrshlddte the thrshlddte to set
	 */
	public void setThrshlddte(Timestamp thrshlddte) {
		this.thrshlddte = thrshlddte;
	}

	/**
	 * @return the thrshldop
	 */
	public String getThrshldop() {
		return thrshldop;
	}

	/**
	 * @param thrshldop the thrshldop to set
	 */
	public void setThrshldop(String thrshldop) {
		this.thrshldop = thrshldop;
	}

	/**
	 * @return the thrshldval
	 */
	public double getThrshldval() {
		return thrshldval;
	}

	/**
	 * @param thrshldval the thrshldval to set
	 */
	public void setThrshldval(double thrshldval) {
		this.thrshldval = new Double(thrshldval);
	}

	/**
	 * @return the upddate
	 */
	public Timestamp getUpddate() {
		return upddate;
	}

	/**
	 * @param upddate the upddate to set
	 */
	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	/**
	 * @return the updtype
	 */
	public String getUpdtype() {
		return updtype;
	}

	/**
	 * @param updtype the updtype to set
	 */
	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	/**
	 * @return the updusr
	 */
	public String getUpdusr() {
		return updusr;
	}

	/**
	 * @param updusr the updusr to set
	 */
	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}
	
	public void setThrshldvalString(String thrshldval){
		if (thrshldval!=null && !thrshldval.trim().equalsIgnoreCase(""))
			this.setThrshldval(Double.parseDouble(thrshldval));
	}
	
	public void setThrshldcoeString(String thrshldcoe){
		if (thrshldcoe!=null && !thrshldcoe.trim().equalsIgnoreCase(""))
			this.setThrshldcoe(Double.parseDouble(thrshldcoe));
	}
}