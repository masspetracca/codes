package it.ccg.qtejb.server.system;

import it.ccg.qtejb.server.logengine.LoggerFactory;
import it.ccg.qtejb.server.logengine.StandardLogMessage;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

public class SystemFilesConfig {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	public static void createSystemFiles() throws Exception {
		
		Properties properties = SystemProperties.getProperties();
		
		String LOG_DIR_ABSOLUTE_PATH = properties.getProperty("user.install.root") + 
									   properties.getProperty("log_dir_relative_path");
		
		String TEMP_DIR_ABSOLUTE_PATH = properties.getProperty("user.install.root") + 
		   						 		properties.getProperty("temp_dir_relative_path");
		
		String UPLOAD_DIR_ABSOLUTE_PATH = properties.getProperty("user.install.root") + 
	 									  properties.getProperty("temp_dir_relative_path") +
										  properties.getProperty("upload_dir_name");
		
		String INTERNAL_DIR_ABSOLUTE_PATH = properties.getProperty("user.install.root") + 
										    properties.getProperty("temp_dir_relative_path") +
										    properties.getProperty("internal_dir_name");

    	
		
		List<String> dirList = new ArrayList<String>();
		dirList.add(LOG_DIR_ABSOLUTE_PATH);
		dirList.add(TEMP_DIR_ABSOLUTE_PATH);
		dirList.add(UPLOAD_DIR_ABSOLUTE_PATH);
		dirList.add(INTERNAL_DIR_ABSOLUTE_PATH);
		
		
		for(String dirAbsPath : dirList) {
			
			File tempFile = new File(dirAbsPath);
			
			if(!tempFile.exists()) {
				
				tempFile.mkdir();
				
				
				logger.info(new StandardLogMessage("File (folder) \'" + tempFile.getAbsolutePath() + "\' successfully created."));
			}
			else {
				
				//logger.debug(new StandardLogMessage("File (folder) \'" + tempFile.getAbsolutePath() + "\' already exists."));
			}
			
		}
		
		
		logger.info(new StandardLogMessage("QualityTest system files successfully created: " + dirList));
    }

}
