package it.ccg.irweb.client;

/*import it.ccg.irweb.client.security.User;*/

import it.ccg.irweb.client.rpc.MyRPCCallback;
import it.ccg.irweb.client.rpc.MyRPCRequest;
import it.ccg.irweb.client.security.UserData;

import java.util.List;

import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.Hyperlink;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.LinkItem;
import com.smartgwt.client.widgets.form.fields.events.ClickEvent;
import com.smartgwt.client.widgets.form.fields.events.ClickHandler;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.tab.TabSet;


public class HeaderUserSection extends Canvas {
	
	
	public HeaderUserSection() {
		
		super();
		
		this.setWidth100();//("20%");
		
		DynamicForm dynamicForm = new DynamicForm();
		dynamicForm.setNumCols(1);
		dynamicForm.setItems(this.createAccountLink());
		dynamicForm.setWidth100();
		dynamicForm.setAlign(Alignment.LEFT);
		dynamicForm.setTop(10);
		
		this.addChild(dynamicForm);
		
	}
	
	
	private LinkItem createAccountLink() {
		
		LinkItem accountLink = new LinkItem();
		accountLink.setWidth("100%");
		accountLink.setAlign(Alignment.LEFT);
		accountLink.setShowTitle(false);
		
		accountLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if(Window.getById("_AccountWindow") != null) {
					
					MainLayout.getMainLayout().removeChild(Window.getById("_AccountWindow"));
					
					Window.getById("_AccountWindow").destroy();
				}
								
				Window accountWindow = createAccountWindow();
				
				accountWindow.setLeft(TabSet.getById("_mainTabSet").getWidth()); //MainLayout.getMainLayout().getWidth() - 90+"%");
				MainLayout.getMainLayout().addChild(accountWindow);
				
			}
			
		});
		
		
		List<String> currentUserRolesList = UserData.getCurrentUserData().getUserRolesList();
		
		String rolesString = "";
		for(String role : currentUserRolesList) {
			rolesString += role + ", ";
		}
		rolesString = rolesString.substring(0, rolesString.length() - 2);
		
		//
		accountLink.setLinkTitle("<font color=\"005596\"><b>" + UserData.getCurrentUserData().getCn() + "</b> " + "(" + rolesString + ")"+"</font>");
		accountLink.setAlign(Alignment.LEFT);
		
		return accountLink;
	}
	

	private Window createAccountWindow() {
		
		final Window accountWindow = new Window();
		
		accountWindow.setID("_AccountWindow");
		accountWindow.setTop(45);
				
		accountWindow.setWidth(180);
		accountWindow.setHeight(110);
		
		accountWindow.setShowHeader(false);
		accountWindow.setShowEdges(false);
		accountWindow.setCanDragResize(false);
		accountWindow.setCanDragReposition(false);
		
		accountWindow.setBackgroundColor("FAFAFA");
		accountWindow.setBorder("1px solid #c0c0c0");
		
		accountWindow.setShowShadow(true);  
		accountWindow.setShadowSoftness(10);  
		accountWindow.setShadowOffset(10);
		
		DynamicForm dynamicForm = new DynamicForm();
		dynamicForm.setNumCols(1);
		dynamicForm.setItems(this.createLogoutLink(), this.createSmartGwtConsoleLink()/*,this.createGenerateFitchRequestLink()*/,this.createReloadProperiesLink());
		
		VLayout vLayout = new VLayout();
		vLayout.setWidth100();
		vLayout.setTop(10);
	
		vLayout.setLayoutLeftMargin(5);
		
		VLayout vLayout2 = new VLayout();
		vLayout2.setWidth100();
		vLayout2.setTop(10);
		vLayout2.addMember(this.createGenerateFitchRequestLink());
		vLayout.setMembers(dynamicForm,vLayout2);
		
		accountWindow.addChild(vLayout);
		//accountWindow.addChild(this.createGenerateFitchRequestLink());
		//accountWindow.addMember(vLayout,1);
		//accountWindow.addMember(this.createGenerateFitchRequestLink(),2);
		
		return accountWindow;
	}
	
	public void redrawAccountWindow() {
		
		if(Window.getById("_AccountWindow") != null) {
			
			MainLayout.getMainLayout().removeChild(Window.getById("_AccountWindow"));
			
			Window.getById("_AccountWindow").destroy();
		}
		
		
		Window accountWindow = createAccountWindow();
		
		accountWindow.setLeft(TabSet.getById("_mainTabSet").getWidth());
		MainLayout.getMainLayout().addChild(accountWindow);
		
	}

	private LinkItem createLogoutLink() {
		
		LinkItem logoutLink = new LinkItem();
		
		logoutLink.setShowTitle(false);
		logoutLink.setLinkTitle("<font color=\"005596\">Logout</font>");
		
		logoutLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				MyRPCRequest rpcRequest = new MyRPCRequest("servlet/security/Logout", null);
				
				RPCManager.sendRequest(rpcRequest, new MyRPCCallback() {
					
					/*@Override
					public void executeImpl(RPCResponse response, java.lang.Object rawData, RPCRequest request) {
						
						@SuppressWarnings("unchecked")
						Map<Object, Object> httpHeader = response.getHttpHeaders();
						Object location = httpHeader.get("Location");
						
						Location.assign((String)location);
						
					}*/
					
				});
				
			}
			
		});
		
		
		return logoutLink;
	}
	
	private LinkItem createSmartGwtConsoleLink() {
		
		LinkItem linkItem = new LinkItem();
		
		linkItem.setShowTitle(false);
		
		linkItem.setLinkTitle("<font color=\"005596\">SmartGwt Console</font>");
		
		if(!UserData.getCurrentUserData().getUserRolesList().contains("admin")) {
			linkItem.setVisible(false);
			linkItem.setDisabled(true);
		}
		
		
		linkItem.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				SC.showConsole();
			}
			
		});
		
		
		return linkItem;
	}

	private Anchor createGenerateFitchRequestLink() {
		Anchor linkItem = new Anchor("<font color=\"005596\">Generate Fitch request file</font>",true,"servlet/admin/GenerateFitchRequestServlet");
		
		if(!UserData.getCurrentUserData().getUserRolesList().contains("admin")) {
			linkItem.setVisible(false);
		}
			
		return linkItem;
	}
	
	private LinkItem createReloadProperiesLink() {
		
		LinkItem linkItem = new LinkItem();
		
		linkItem.setShowTitle(false);
		
		linkItem.setLinkTitle("<font color=\"005596\">Reload system properties</font>");
		
		if(!UserData.getCurrentUserData().getUserRolesList().contains("admin")) {
			linkItem.setVisible(false);
			linkItem.setDisabled(true);
		}
		
		
		linkItem.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				MyRPCRequest request = new MyRPCRequest("servlet/admin/SystemPropertiesLoad", null);
				RPCManager.sendRequest(request, new MyRPCCallback() {
					
					@Override
					protected void onSuccess(RPCResponse response, Object rawData, RPCRequest request) {
						SC.say("Loading completed");
					}
					
					@Override
					protected void onError(RPCResponse response, Object rawData, RPCRequest request) {
						SC.warn("Unable to load properties.");
					}
				});
			}
		});
		
		return linkItem;
	}
	
}
