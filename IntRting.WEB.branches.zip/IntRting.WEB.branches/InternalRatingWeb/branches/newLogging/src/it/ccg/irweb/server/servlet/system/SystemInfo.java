package it.ccg.irweb.server.servlet.system;

import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.system.SystemProperties;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
//import org.json.simple.JSONObject;

/**
 * Servlet implementation class SystemInfo
 */
public class SystemInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
	private PrintWriter outStream;
	
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SystemInfo() {
        super();
    }
    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		throw new ServletException("SystemInfo servlet doesn\'t allow get requests.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String _operationId = request.getParameter("_operationId");
		
		if(_operationId == null) {
			
			throw new ServletException("Unable to process request. \'_operationId\' parameter not found.");
		}
		
		if(_operationId.equalsIgnoreCase("getEnviroment")) {
			
			this.getEnviroment(request, response);
		}
		else {
			
			throw new ServletException("Unable to process request. \'_operationId\' of type \'" + _operationId + "\' not valid.");
		}
		
	}
	
	
	

	@SuppressWarnings("unchecked")
	private void getEnviroment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// this is the response body
		String jsonString = null;
		
		try {
			Properties properties = SystemProperties.getSystemProperties();
			
			//JSONObject jsonObject = new JSONObject();			
			//jsonObject.put("environment", properties.getProperty("enviroment"));
			
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_OK);
			// return data to client
			this.outStream = response.getWriter();
			this.outStream.print(jsonString);
			
		}
		catch (Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// set response attributes
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
		
	}
}
