package it.ccg.irweb.client.utils;

import com.smartgwt.client.widgets.Canvas;

public interface Creator {

	Canvas create();
}
