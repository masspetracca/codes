package it.ccg.irweb.client;

import it.ccg.irweb.client.base.StandardCanvas;
import it.ccg.irweb.client.controls.StandardComboBox;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.SortSpecifier;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.ExportFormat;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.types.RowEndEditAction;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.types.TextMatchStyle;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.PrintPreviewCallback;
import com.smartgwt.client.util.PrintProperties;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.PrintCanvas;
import com.smartgwt.client.widgets.PrintWindow;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.fields.events.ChangeEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangeHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.events.FilterEditorSubmitEvent;
import com.smartgwt.client.widgets.grid.events.FilterEditorSubmitHandler;
import com.smartgwt.client.widgets.layout.LayoutSpacer;

public class BankBalHistCanvas extends StandardCanvas {

	private DataSource rctmVarhDS;
	private DataSource rctBankDS;
	private ListGrid banksBalanceHList;
	private String selectedFilter;
	private int bankId;
	List<Map<String,String>> mapVars;
	
	public BankBalHistCanvas(){
		super();
		this.rctmVarhDS = DataSource.get("rcmvarh");
		this.rctBankDS = DataSource.get("rctbank");
		
		//CREO IL TOP DEL CANVAS
		filterCombo = new StandardComboBox("Bank");
		filterCombo.setFilterLocally(true);
		filterCombo.setAllowEmptyValue(true);
		filterCombo.setOptionDataSource(this.rctBankDS);
		filterCombo.setValueField("BANKID");
		filterCombo.setDisplayField("BANKNAME");
		filterCombo.setSortField("BANKNAME");
		filterCombo.setAlign(Alignment.CENTER);
		
		topContainerLayout.addMember(filterCombo.inDynamicForm());
		//Change handler combo
		filterCombo.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent event) {
				if (event.getValue() != null){
					selectedFilter = (String) event.getValue().toString();
				}
				if (event.getValue() == null) selectedFilter = null;
			}
		});

		// Show button click handler
		showButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				showData();
			}
		});

		topContainerLayout.addMember(showButton);
		//add space
		topContainerLayout.addMember(spacerLayout);
				
		refreshButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				selectedFilter = null;
				filterCombo.clearValue();
				banksBalanceHList.clearCriteria();
				showData();
			}
		});
		
		topContainerLayout.addMember(refreshButton);
		//
		canvasContainerLayout.addMember(topContainerLayout);
		
		this.banksBalanceHList = new ListGrid();
		this.banksBalanceHList.setWidth100();
		this.banksBalanceHList.setTitle("Banks Balance History");
		this.banksBalanceHList.setShowDetailFields(true);
		this.banksBalanceHList.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATE);
		this.banksBalanceHList.setShowFilterEditor(true);
		this.banksBalanceHList.setDataPageSize(40);
		this.banksBalanceHList.setModalEditing(true);
		this.banksBalanceHList.setFilterOnKeypress(false);
		this.banksBalanceHList.setListEndEditAction(RowEndEditAction.NEXT);
		this.banksBalanceHList.setAutoSaveEdits(false);
		this.banksBalanceHList.setAutoFetchData(true);
		this.banksBalanceHList.setDataSource(rctmVarhDS);
		this.banksBalanceHList.setEditEvent(ListGridEditEvent.NONE);
		this.banksBalanceHList.setAutoFetchTextMatchStyle(TextMatchStyle.SUBSTRING);
		this.banksBalanceHList.setCanGroupBy(false);
		this.banksBalanceHList.setCanFreezeFields(false);
		this.banksBalanceHList.setCanAutoFitFields(false);
		SortSpecifier valuDateSpecifier = new SortSpecifier("VALUEDATE", SortDirection.DESCENDING);
		this.banksBalanceHList.setInitialSort(valuDateSpecifier);
		this.banksBalanceHList.addFilterEditorSubmitHandler(new FilterEditorSubmitHandler() {
			@Override
			public void onFilterEditorSubmit(FilterEditorSubmitEvent event) {
				try{
					if (event.getCriteria()!=null){
						Map critMap= event.getCriteria().getValues();
						if (critMap.containsKey("criteria")){
							String stringMap = critMap.get("criteria").toString();
							Map <String,String> map = new HashMap<String,String>();
							String[]appoStr = stringMap.split(",");
							for (String s: appoStr){
								String []appoMap = s.split("=");
								map.put(appoMap[0], appoMap[1]);
							}
							if(map.containsValue("BANKID")){
								Set<Entry<String, String>> s = map.entrySet();
								for (Entry snt : s){
									if(snt.getKey().toString().trim().equals("value")){
										selectedFilter =(String) snt.setValue(snt.getKey());
									}
								}
							}else{
								selectedFilter="";
							}
							filterCombo.setValue(selectedFilter);
							filterCombo.redraw();
						}
					}else{
						selectedFilter="";
						filterCombo.setValue(selectedFilter);
						filterCombo.redraw();
						banksBalanceHList.invalidateCache();
					}
				}catch(Exception e){
					SC.say(e.getMessage()+" asdas |||| "+event.isCancelled());
				}
			}
		});
				
		RPCRequest request = new RPCRequest();
		request.setActionURL("servlet/endpoint/BalanceHystFieldsServlet");
		request.setHttpMethod("POST");
		
		RPCManager.sendRequest(request, new RPCCallback() {

			@Override
			public void execute(RPCResponse response, Object rawData, RPCRequest request) {

				HashMap<String, List<Map<String,String>>> respMap = (HashMap<String, List<Map<String,String>>>) response.getDataAsMap();
					
				mapVars = (List<Map<String,String>>) respMap.get("mapVar");
	
					
				List<ListGridField> fields = new ArrayList<ListGridField>();
	
				ListGridField bankIdField = new ListGridField("BANKID");
				bankIdField.setOptionDataSource(rctBankDS);
				bankIdField.setValueField("BANKID");
				bankIdField.setDisplayField("BANKNAME");
				bankIdField.setTitle("Bank");
				bankIdField.setWidth("20%");
				bankIdField.setOptionOperationId("fetchFilter");
				fields.add(bankIdField);
				
				for(Map<String,String> v : mapVars){
					ListGridField f = new ListGridField("V"+v.get("varId"));
					f.setTitle(v.get("varDesc"));
					f.setWidth("10%");
					if(!(v.get("status") .equalsIgnoreCase("E"))){
						f.setHidden(true);
					}
					
					fields.add(f);					
				}
	
				ListGridField valueDateField = new ListGridField("VALUEDATE");
				valueDateField.setWidth("10%");
				valueDateField.setTitle("Value date");
				valueDateField.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATE);
				
				ListGridField periodLengthField = new ListGridField("PERIODLENG");
				periodLengthField.setWidth("8%");
				periodLengthField.setTitle("Period length");
				periodLengthField.setCellAlign(Alignment.RIGHT);
				
				ListGridField accountSysField = new ListGridField("ACCOUNTSYS");
				accountSysField.setWidth("10%");
				accountSysField.setTitle("Accounting system");
				
				ListGridField isConsolidField = new ListGridField("ISCONSOLID");
				isConsolidField.setWidth("8%");
				isConsolidField.setTitle("Consolidated");
				Map<String,String>isConsolidMap = new HashMap<String, String>();
				isConsolidMap.put("Y", "Yes");
				isConsolidMap.put("N", "No");
				isConsolidField.setValueMap(isConsolidMap);
				
				ListGridField perioTypeField = new ListGridField("PERIODTYPE");
				perioTypeField.setWidth("8%");
				perioTypeField.setTitle("Period type");
				Map<String,String>periodTypeMap = new HashMap<String, String>();
				periodTypeMap.put("0", "Year end");
				periodTypeMap.put("3", "1st quarter");
				periodTypeMap.put("6", "Interim/2nd quarter");
				periodTypeMap.put("9", "3rd quarter");
				periodTypeMap.put("12", "4th quarter");
				perioTypeField.setValueMap(periodTypeMap);
				
				fields.add(periodLengthField);
				fields.add(perioTypeField);
				fields.add(accountSysField);
				fields.add(isConsolidField);
				fields.add(valueDateField);
	
	
				ListGridField[] appo =  new ListGridField[fields.size()];
				for (int i =0; i<fields.size(); i++){
					appo[i]=fields.get(i);
				}
				 banksBalanceHList.setFields(appo);
				
				 relaod();
			}
			
		});
		/*Criteria startCriteria = new Criteria();
		startCriteria.addCriteria("BANKID", "");*/
		
		//banksBalanceHList.setInitialCriteria(startCriteria);
		
		canvasContainerLayout.addMember(banksBalanceHList);
		
		exportData.addClickHandler(new ClickHandler() {	
			@Override
			public void onClick(ClickEvent event) {
				DSRequest request = new DSRequest();
				request.setExportFilename("Bank balance history");
				request.setExportToClient(true);
				request.setExportValueFields(true);
				request.setExportAs(ExportFormat.OOXML);
				banksBalanceHList.exportClientData(request);
			}
		});
		
		printData.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				PrintProperties printProp = new PrintProperties();
				printProp.setAttribute("Orientation", "Landscape");
				
				Img logoImg = new Img("CCGlogo.gif", 255, 51);  	
				Label label = new Label();  
		        label.setHeight(30);  
		        label.setPadding(10); 
		        label.setContents("<b>Bank balance history</b>");
		        label.setAlign(Alignment.CENTER);  
		        label.setValign(VerticalAlignment.CENTER); 
		        
		        LayoutSpacer spacer = new LayoutSpacer();
		        spacer.setWidth(10); 
		        
				Canvas.showPrintPreview(new Object[] {logoImg,label,spacer,banksBalanceHList}, printProp, "Bank balance history", new PrintPreviewCallback() {
					
					@Override
					public void execute(PrintCanvas printCanvas, PrintWindow printWindow) {
												
					}
				});
			}
		});
		
		bottomContainerLayout.addMember(exportData);
		bottomContainerLayout.addMember(printData);
		canvasContainerLayout.addMember(bottomContainerLayout);
		
		this.addChild(canvasContainerLayout);
	}
	
	public void showData(){
		if (selectedFilter != null ) {
			this.bankId = Integer.parseInt(selectedFilter);
			Criteria crit = new Criteria();
			crit.addCriteria("BANKID", this.bankId);
			banksBalanceHList.fetchData(crit);
			banksBalanceHList.redraw();
		}else{
			banksBalanceHList.invalidateCache();
			banksBalanceHList.fetchData();
			banksBalanceHList.redraw();
		}
	}
	
	public void relaod(){
		this.redraw();
	}
	
	public static class Creator implements it.ccg.irweb.client.utils.Creator{
		
		public Canvas create(){
			return new BankBalHistCanvas();
		}
	}
}
