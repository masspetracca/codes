package it.ccg.irweb.client;

import it.ccg.irweb.client.controls.StandardButton;
import it.ccg.irweb.client.controls.StandardBarHLayout;
import it.ccg.irweb.server.security.Regex;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.LinkItem;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.validator.RegExpValidator;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.tab.TabSet;

public class ProfileWindow extends Window {
	DynamicForm nameform;
	TextItem nameItem;  
     DynamicForm surnameform;
	TextItem surnameItem;  
     DynamicForm emailform;
	TextItem emailItem;  
	 DynamicForm notifyform;
	SelectItem notifyItem;  
     DynamicForm usrdescform;
	TextItem usrdescItem;  
     DynamicForm phoneform;
	TextItem phoneItem;  
    	
	public ProfileWindow(final TabSet mainTabSet,String fullnameResult, final LinkItem accountLink){
		
		super();
		this.setID("ProfileWindow");
		this.setTitle(fullnameResult+ "'s profile");
		this.setWidth(310);
		this.setHeight(280);
		this.centerInPage();
		this.setCanDragReposition(true);
		this.setCanDragResize(true);
		this.setKeepInParentRect(true);
		this.setShowMinimizeButton(false);
		this.setAlign(VerticalAlignment.CENTER);
		this.setAlign(Alignment.CENTER);
		this.setIsModal(true);
		
		final Window w = this;
		
		//< > " ' % ; ) ( & + -
		
		//Nama Surname validator
		RegExpValidator regExpValidatorName = new RegExpValidator();  
		regExpValidatorName.setExpression(Regex.REG_EXP_ADV_VALIDATOR);  
		RegExpValidator regExpValidatorSurName = new RegExpValidator();  
		regExpValidatorSurName.setExpression(Regex.REG_EXP_ADV_VALIDATOR);  
		
		
		
		//Name
		nameform = new DynamicForm();
		nameform.setHeight100();
		nameform.setWidth("99%");
		nameform.setPadding(0);
		nameform.setAlign(Alignment.LEFT);
		
		nameItem = new TextItem();  
		nameItem.setRequired(true);
		nameItem.setValidateOnChange(true);
        nameItem.setTitle("Name");  
		nameItem.setValidators(regExpValidatorName);
        
		//Surname
		surnameform = new DynamicForm();
		surnameform.setHeight100();
		surnameform.setWidth("99%");
		surnameform.setPadding(0);
		surnameform.setAlign(Alignment.LEFT);
		
		surnameItem = new TextItem();  
		surnameItem.setRequired(true);
		surnameItem.setValidateOnChange(true);
		surnameItem.setValidators(regExpValidatorSurName);
        surnameItem.setTitle("Surname");  
		
		//Email
        RegExpValidator regExpValidatorEmail = new RegExpValidator();  
        regExpValidatorEmail.setExpression(Regex.REG_EXP_EMAIL_VALIDATOR);  
         
	    emailform = new DynamicForm();
		emailform.setHeight100();
		emailform.setWidth("99%");
		emailform.setPadding(0);
		emailform.setAlign(Alignment.LEFT);
		
		emailItem = new TextItem();  
		emailItem.setRequired(true);
		emailItem.setValidateOnChange(true);
		emailItem.setTitle("Email");  
		emailItem.setValidators(regExpValidatorEmail);
		
		//Notify
		notifyform = new DynamicForm();
		notifyform.setHeight100();
		notifyform.setWidth("99%");
		notifyform.setPadding(0);
		notifyform.setAlign(Alignment.LEFT);
		
		LinkedHashMap<String, String> valueMap = new LinkedHashMap<String, String>();  
		valueMap.put("T", "Enable");
        valueMap.put("F", "Disable"); 
        valueMap.put("E", "Error only");   
        notifyItem = new SelectItem();  
		notifyItem.setValueMap(valueMap);
        notifyItem.setRequired(true);
        notifyItem.setTitle("Notify");  
		
      //Usr Descriptin validator
		RegExpValidator regExpValidatorUsrDesc = new RegExpValidator();  
		regExpValidatorUsrDesc.setExpression(Regex.REG_EXP_DESC_VALIDATOR);  //"^[a-zA-Z0-9�������������\\.;:={}() +\\-,\\'\\_]*$"
        
		//USRdesc
		usrdescform = new DynamicForm();
		usrdescform.setHeight100();
		usrdescform.setWidth("99%");
		usrdescform.setPadding(0);
		usrdescform.setAlign(Alignment.LEFT);
		
		usrdescItem = new TextItem();  
		usrdescItem.setValidateOnChange(true);
		usrdescItem.setValidators(regExpValidatorUsrDesc);
        usrdescItem.setTitle("Description");  
		
        //
        RegExpValidator regExpValidatorPhone = new RegExpValidator();  
        regExpValidatorPhone.setExpression(Regex.REG_EXP_PHONE_NUM_VALIDATOR);  
        
		//Phone
        phoneform = new DynamicForm();
		phoneform.setHeight100();
		phoneform.setWidth("99%");
		phoneform.setPadding(0);
		phoneform.setAlign(Alignment.LEFT);
		
		phoneItem = new TextItem();  
		phoneItem.setValidateOnChange(true);
		phoneItem.setValidators(regExpValidatorPhone);
        phoneItem.setTitle("Phone number");  
        
        //Fetch iniziale
        showUserProfile();
		
		//Save button
		StandardButton saveButton=new StandardButton("Save");
		saveButton.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
				
				updateUserProfile(accountLink);
				
			}});
		//Cancel Button
		StandardButton cancelbButton = new StandardButton("Cancel");
		cancelbButton.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
				w.destroy();
			}});
		
		StandardBarHLayout bottomControlBar = new StandardBarHLayout();
		LayoutSpacer ls = new LayoutSpacer();
		bottomControlBar.setAlign(Alignment.CENTER);
		bottomControlBar.addMember(saveButton);
		bottomControlBar.addMember(cancelbButton);
		
		//Close click handler
		this.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {
				w.destroy();
			}
		});



        nameform.setFields(nameItem);
        surnameform.setFields(surnameItem);
        notifyform.setFields(notifyItem);
        emailform.setFields(emailItem);
        usrdescform.setFields(usrdescItem);
        phoneform.setFields(phoneItem);
        

        this.addItem(nameform);
        this.addItem(surnameform);
        this.addItem(notifyform);
        this.addItem(emailform);
        this.addItem(usrdescform);
        this.addItem(phoneform);
		this.addItem(ls);
		this.addItem(bottomControlBar);
		
		this.draw();
	
	}
	
	public void updateUserProfile(final LinkItem accountLink){
		
		if(!emailItem.validate() || !nameItem.validate() || !surnameItem.validate() 
				|| !usrdescItem.validate() || !phoneItem.validate()) {
			SC.say("Some fields contain invalid values.");
			return;
		}

		
		// Creazione della mappa dati per invio richiesta
		HashMap<String, String> params = new HashMap<String, String>();
		
		String name = "";
		String surname = "";
		String notify = "";
		String email = "";
		String usrdesc = "";
		String phone = "";
		
		if(nameItem.getValue()!=null){
			name = (String) nameItem.getValue();
		}
		if(surnameItem.getValue()!=null){
			surname = (String) surnameItem.getValue();
		}
		if(notifyItem.getValue()!=null){
			notify = (String) notifyItem.getValue();
		}
		if(emailItem.getValue()!=null){
			email = (String) emailItem.getValue();
		}
		if(usrdescItem.getValue()!=null){
			usrdesc = (String) usrdescItem.getValue();
		}
		if(phoneItem.getValue()!=null){
			phone = (String) phoneItem.getValue();
		}
		
		params.put("NAME", name);
		params.put("SURNAME", surname);
		params.put("EMAIL", email);
		params.put("NOTIFY", notify);
		params.put("USERDESC", usrdesc);
		params.put("PHONENUMB", phone);
		
		// Creazione della richiesta
		RPCRequest r = new RPCRequest();
		r.setActionURL("ccgportal/UserProfileUpdate");
		r.setParams(params);
		r.setPrompt("Elaboration in progress...");
		r.setShowPrompt(true);

		RPCManager.sendRequest(r, new RPCCallback() {
			public void execute(RPCResponse response, java.lang.Object rawData, RPCRequest request) {

				// Gestione della risposta
				Map<String, String> responseMap;
				responseMap = response.getAttributeAsMap("data");
				// Stampa la risposta
				if (responseMap.get("RESULT").equalsIgnoreCase("0")) {
					
					showUserProfile();
					accountLink.redraw();
					
					SC.say("User profile correctly updated.");
					
				} else {
					SC.warn("Error updating user details.");
				}
			}
		});
		
		
		
	}
	
	public void showUserProfile(){
		

		// Creazione della richiesta
		RPCRequest r = new RPCRequest();
		r.setActionURL("ccgportal/UserProfileLoad");
		r.setPrompt("Elaboration in progress...");
		r.setShowPrompt(true);

		RPCManager.sendRequest(r, new RPCCallback() {
			public void execute(RPCResponse response, java.lang.Object rawData, RPCRequest request) {

				// Gestione della risposta
				Map<String, String> responseMap;
				responseMap = response.getAttributeAsMap("data");
				// Stampa la risposta
				if (responseMap.get("RESULT").equalsIgnoreCase("0")) {
					
					String name = (String)responseMap.get("NAME");
					String surname = (String)responseMap.get("SURNAME");
					String email  = (String)responseMap.get("EMAIL");
					String notify = (String)responseMap.get("NOTIFY");
					String usrdesc = (String)responseMap.get("USERDESC");
					String phone = (String)responseMap.get("PHONENUMB");
					
					nameItem.setValue(name);
					surnameItem.setValue(surname);
					notifyItem.setValue(notify);
					emailItem.setValue(email);
					usrdescItem.setValue(usrdesc);
					phoneItem.setValue(phone);
					
				} else {
					SC.warn("Error showing user details.");
				}
			}
		});
		
	}
	
	public static ProfileWindow windowCreator(TabSet mainTabSet,String fullnameResult, LinkItem accountLink) {

		ProfileWindow mw = (ProfileWindow) Canvas.getById("ProfileWindow");
		if (mw != null) {
			mw.setVisible(true);
			mw.restore();
			mw.bringToFront();
			return mw;
		} else {
			return new ProfileWindow(mainTabSet,fullnameResult, accountLink);

		}
	
		
	}
}
