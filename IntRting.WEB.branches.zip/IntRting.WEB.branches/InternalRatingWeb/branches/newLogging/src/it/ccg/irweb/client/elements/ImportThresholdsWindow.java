package it.ccg.irweb.client.elements;

import it.ccg.irweb.client.controls.StandardButton;

import com.google.gwt.user.client.ui.FileUpload;
import com.google.gwt.user.client.ui.FormPanel;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.CheckboxItem;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;

public class ImportThresholdsWindow extends Window {
	StandardButton uploadButton = new StandardButton("Upload");
	
	public ImportThresholdsWindow(final ListGrid listGrid, String exampleFile,String varId) {
		final Window winModal = this;
		this.setWidth(480);
		this.setHeight(250);

		this.setTitle("Select a file to import...");
		this.setShowMinimizeButton(false);
		this.setIsModal(true);
		this.setShowModalMask(true);
		this.centerInPage();
		this.setCanDragReposition(true);  
		this.setCanDragResize(true);  
		this.setKeepInParentRect(true);


		String desc="Learn how to correctly format your input file with this <a href=\"templates/"+exampleFile+"\" target=\"_blank\">example</a>";

		Label label = new Label();  
		label.setPadding(5);
		label.setWrap(false);  
		label.setContents(desc);  
		 
		label.setContents(desc);  


		//Main Layout
		VLayout mainLayout = new VLayout();
		mainLayout.setMargin(15);
		mainLayout.setWidth("90%");
//		mainLayout.setAlign(Alignment.CENTER);

		//File Upload
		final FileUpload  fileUpload = new FileUpload();
		fileUpload.setName("fileUplad");
		fileUpload.setTitle("Upload file...");
		//		fileUpload.setHeight("50%");

		//Upload Form
		final FormPanel  importForm = new FormPanel();   
		importForm.setEncoding(FormPanel.ENCODING_MULTIPART);
		importForm.setMethod(FormPanel.METHOD_POST);		
		importForm.setAction("servlet/endpoint/ThresholdImporterServlet?VARID="+varId);
		importForm.add(fileUpload);		
		importForm.setHeight("30%");
		
		//Check Item
		final CheckboxItem checkItem = new CheckboxItem("checkItem","Overwrite existing data");
		checkItem.setDefaultValue(true);
		checkItem.setAlign(Alignment.LEFT);

		//Check form
		final DynamicForm checkForm = new DynamicForm();  
		checkForm.setItems(checkItem);
		checkForm.setNumCols(1);
		checkForm.setWidth(150);

		HLayout hlayout = new HLayout();
		hlayout.setWidth("90%");
		hlayout.setShowEdges(true);
		hlayout.setAlign(Alignment.CENTER);
		hlayout.addMember(label);

		LayoutSpacer ls = new LayoutSpacer();
		mainLayout.addMember(hlayout);
		mainLayout.addMember(ls);
		mainLayout.addMember(importForm);
		//mainLayout.addMember(checkForm);
		mainLayout.addMember(ls);
		mainLayout.addMember(uploadButton);
		
		this.addItem(mainLayout);
		this.draw();

		this.addCloseClickHandler(new CloseClickHandler() {
			public void onCloseClick(CloseClickEvent event) {
				winModal.destroy();
			}
		});


		uploadButton.addClickHandler(new ClickHandler() {

			public void onClick(ClickEvent event) {
				if(fileUpload.getFilename().equalsIgnoreCase("")){
					SC.warn("File required");
					return;
				}else{
					//RPCManager.startQueue();
					importForm.submit();
					SC.say("Importing stared,you can see results soon",new BooleanCallback() {
						
						@Override
						public void execute(Boolean value) {
							destroyImportWindow();	
							
						}
					});
				}
			}
		});
		
		

	}
	
	public void destroyImportWindow(){
		this.destroy();
	}

	public static ImportThresholdsWindow windowCreator(ListGrid listGrid, String exampleFile,String varId) {
		
		return new ImportThresholdsWindow(listGrid,exampleFile,varId);
	

	}
}
