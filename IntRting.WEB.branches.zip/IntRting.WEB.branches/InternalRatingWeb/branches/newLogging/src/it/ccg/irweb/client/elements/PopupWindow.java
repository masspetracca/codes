package it.ccg.irweb.client.elements;

import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.layout.VLayout;;

public class PopupWindow extends Window {

	VLayout mainVLayout;
	
	
	public static PopupWindow getInstance(String title, int width, int height) {
		final PopupWindow window = new PopupWindow(title, width, height);
		
		window.addCloseClickHandler(new CloseClickHandler() {
			
			@Override
			public void onCloseClick(CloseClickEvent event) {
				 
				window.destroy();
			}
		});
		
		return window;
	}
	
	public PopupWindow(String title, int width, int height) {
		
		this.setTitle(title);
		
		this.setWidth(width);
		this.setHeight(height);
		this.setAlign(Alignment.CENTER);
		
		this.setShowMinimizeButton(false);
		this.setIsModal(true);
		this.setShowModalMask(true);
		this.centerInPage();
		this.setCanDragReposition(true);  
		this.setCanDragResize(true);  
		this.setKeepInParentRect(true);
		
		
		this.mainVLayout = new VLayout();
		this.mainVLayout.setWidth100();
		this.mainVLayout.setHeight100();
		
		this.mainVLayout.setMargin(10);
		this.mainVLayout.setHeight(200);
		this.mainVLayout.setMembersMargin(20);
		
		 
		this.addItem(this.mainVLayout);
	}
	
	
	public void addMember(Canvas canvas) {
		
		this.mainVLayout.addMember(canvas);
	}
}
