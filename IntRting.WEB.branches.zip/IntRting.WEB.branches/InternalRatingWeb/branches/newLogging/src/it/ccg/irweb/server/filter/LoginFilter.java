package it.ccg.irweb.server.filter;

import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irweb.server.security.Regex;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

/**
 * Servlet Filter implementation class LoginFilter
 */
public class LoginFilter implements Filter {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	
    
	/**
     * Default constructor. 
     */
    public LoginFilter() {
    	
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		// Marks next HTTP request as just after re-login request
		// Look at ServletFilter for details
		SecurityFilter.setAfterlogin(true);
		
		
		// Check input parameters
		String j_username = request.getParameter("j_username");
		String j_password = request.getParameter("j_password");
		
		Pattern userPattern = Pattern.compile(Regex.REG_EXP_BASE_VALIDATOR);
		Matcher userMatcher = userPattern.matcher(j_username);
		
		Pattern passwordPattern = Pattern.compile(Regex.REG_EXP_BASE_VALIDATOR);
		Matcher passwordMatcher = passwordPattern.matcher(j_password);
		
		if(!userMatcher.matches() || !passwordMatcher.matches()) {
			
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("error.html");
			
			requestDispatcher.forward(request, response);
		}
		
		
		// initializing session
		HttpServletRequest httpServletRequest = (HttpServletRequest)request;
		HttpSession tempHttpSession = httpServletRequest.getSession(false);
		
		// Invalidate temporary login session
		// This is necessary to enter into SessionListener.sessionCreated() when creating the new session the first time will enter SecurityFilter.
		if(tempHttpSession != null) {
			
			String _id = tempHttpSession.getId();
			
			tempHttpSession.invalidate();
			
			logger.debug(new StandardLogMessage("Invalidated temp HttpSession - sessionId: " + _id));
		}
		
		
		// pass the request along the filter chain
		chain.doFilter(request, response);
		
		
		// The new session is created into SecurityFilter and not here in LoginFilter because, though one creates it here, 
		// the framework creates a new one at first execution of SecurityFilter. This double creations makes some problems 
		// in the session status check for expired sessions and concurrent logins.
		// Create new session
		/*HttpSession newHttpSession = ((HttpServletRequest)request).getSession(true);
		
		logger.debug(new StandardLogMessage("New HttpSession created. SessionId: " + newHttpSession.getId()));*/
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
