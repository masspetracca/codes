package it.ccg.irweb.client;

import it.ccg.irweb.client.base.StandardCanvas;
import it.ccg.irweb.client.controls.StandardComboBox;
import it.ccg.irweb.client.controls.StandardShowButton;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.Criterion;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.SortSpecifier;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.ExportFormat;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.types.TextMatchStyle;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.PrintPreviewCallback;
import com.smartgwt.client.util.PrintProperties;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.PrintCanvas;
import com.smartgwt.client.widgets.PrintWindow;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.fields.events.ChangeEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangeHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.events.FilterEditorSubmitEvent;
import com.smartgwt.client.widgets.grid.events.FilterEditorSubmitHandler;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;

public class ApprovedRatingCanvas extends StandardCanvas{

	private int bankId;
	private String selectedFilter;
	DataSource rctratingDS;
	DataSource rctbankDS;
	DataSource rCDS;
	ListGrid approvedRatings;
	
	public ApprovedRatingCanvas() {
		super();
		try{
		rctratingDS = DataSource.get("rctratingh");
		rctbankDS = DataSource.get("rctbank");
		//rCDS = DataSource.get("rctriskcom");
		
		filterCombo = new StandardComboBox("Bank");
		filterCombo.setOptionDataSource(rctbankDS);
		filterCombo.setValueField("BANKID");
		filterCombo.setDisplayField("BANKNAME");
		filterCombo.setSortField("BANKNAME");
		filterCombo.setFilterLocally(true);
		filterCombo.setAllowEmptyValue(true);
		filterCombo.setOptionOperationId("rctratingh_fetch");
		
		
		topContainerLayout.addMember(filterCombo.inDynamicForm());
		//Change handler combo
		filterCombo.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent event) {
				if (event.getValue() != null)
					selectedFilter = event.getValue().toString();
				if (event.getValue() == null) selectedFilter = null;
			}
		});
		
		//Show button
		final StandardShowButton showButton = new StandardShowButton();
		showButton.setAlign(Alignment.CENTER);
		// Show button click handler
		showButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				showData();
			}
		});
		
		//showButton.setTooltip(ClientMessages.ttpShowBtn());
		topContainerLayout.addMember(showButton);
		//add space
		topContainerLayout.addMember(spacerLayout);
		
		refreshButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				showData();
			}
		});
		
		topContainerLayout.addMember(refreshButton);
		//
		canvasContainerLayout.addMember(topContainerLayout);
		
		ListGridField bankField = new ListGridField("BANKID");
		bankField.setOptionDataSource(rctbankDS);
		bankField.setValueField("BANKID");
		bankField.setDisplayField("BANKNAME");
		bankField.setTitle("Bank");
		bankField.setOptionOperationId("fetchFilter");
		
		ListGridField ratingDateField = new ListGridField("RATINGDATE");
		ListGridField balanceRtgField = new ListGridField("BALANCERTG");
		ListGridField spreadRtgField = new ListGridField("SPREADRTG");
		ListGridField externalRtgField = new ListGridField("EXTERNRTG");
		ListGridField approvedRtgField = new ListGridField("APPRRTG");
		ListGridField approvedByRtgField = new ListGridField("APPROVEDBY");
		ListGridField approvedDateField = new ListGridField("APPRDATE");
		ListGridField statusField = new ListGridField("STATUS");
		ListGridField commentField = new ListGridField("COMMENT");
		ListGridField noteField = new ListGridField("NOTE");

		
		ListGridField riskCommitteeField = new ListGridField("RCCOD");
		
		//CREO LA TABELLA 
		approvedRatings = new ListGrid();
		approvedRatings.setWidth100();
		approvedRatings.setFields(bankField,ratingDateField,balanceRtgField,spreadRtgField,externalRtgField,approvedRtgField ,approvedByRtgField,statusField,approvedDateField,commentField,noteField,riskCommitteeField);
		approvedRatings.setTitle("Approved ratings history");
		approvedRatings.setDataSource(rctratingDS);
		approvedRatings.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATE);
		approvedRatings.setShowFilterEditor(true);
		approvedRatings.setDataPageSize(40);
		approvedRatings.setFilterOnKeypress(false);
		approvedRatings.setAutoSaveEdits(true);
		approvedRatings.setAutoFetchData(true);
		approvedRatings.setEditEvent(ListGridEditEvent.NONE);
		approvedRatings.setAutoFetchTextMatchStyle(TextMatchStyle.SUBSTRING);
		approvedRatings.setCanGroupBy(false);
		approvedRatings.setCanFreezeFields(false);
		approvedRatings.setCanAutoFitFields(false);
		SortSpecifier apprDateSpecifier = new SortSpecifier("APPRDATE", SortDirection.DESCENDING);
		approvedRatings.setInitialSort(apprDateSpecifier);
		approvedRatings.addFilterEditorSubmitHandler(new FilterEditorSubmitHandler() {
			@Override
			public void onFilterEditorSubmit(FilterEditorSubmitEvent event) {
				if(event.getCriteria()!=null){
					AdvancedCriteria m = event.getCriteria().asAdvancedCriteria();
					Criterion[] c = m.getCriteria();
					for (int i=0;i<c.length;i++){
						if (((Criterion)c[i]).getFieldName().equalsIgnoreCase("BANKID")){
							selectedFilter = ((Criterion)c[i]).getValueAsString();
						}
					}
					filterCombo.setValue(selectedFilter);
					filterCombo.redraw();
					//event.getCriteria().addCriteria("BANKID", selectedFilter);
				}else{
					selectedFilter = "";
					filterCombo.setValue(selectedFilter);
					filterCombo.redraw();
				}
			}
		});
		
		approvedRatings.setWidth100();
		
		//CREO IL CRITERIA PER IL PRIMO CARICAMENTO
		Criteria startCriteria = new Criteria();
		startCriteria.addCriteria("BANKID", "");
		
		approvedRatings.setInitialCriteria(startCriteria);
		
		canvasContainerLayout.addMember(approvedRatings);
		
		exportData.addClickHandler(new ClickHandler() {	
			@Override
			public void onClick(ClickEvent event) {
				DSRequest request = new DSRequest();
				request.setExportFilename("Approved ratings");
				request.setExportToClient(true);
				request.setExportValueFields(true);
				request.setExportAs(ExportFormat.OOXML);
				approvedRatings.exportClientData(request);
			}
		});
		
		printData.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				VLayout[] printLayout = new VLayout[]{canvasContainerLayout};
				PrintProperties printProp = new PrintProperties();
				printProp.setAttribute("Orientation", "Landscape");
				
				Img logoImg = new Img("CCGlogo.gif", 255, 51);  	
				Label label = new Label();  
		        label.setHeight(30);  
		        label.setPadding(10); 
		        label.setContents("<b>Approved ratings history</b>");
		        label.setAlign(Alignment.CENTER);  
		        label.setValign(VerticalAlignment.CENTER); 
		        
		        LayoutSpacer spacer = new LayoutSpacer();
		        spacer.setWidth(10);
				Canvas.showPrintPreview(new Object[] {logoImg,label,spacer,approvedRatings}, printProp, "Approved ratings history", new PrintPreviewCallback() {
					
					@Override
					public void execute(PrintCanvas printCanvas, PrintWindow printWindow) {
												
					}
				});
			}
		});

		bottomContainerLayout.addMember(exportData);
		bottomContainerLayout.addMember(printData);
		canvasContainerLayout.addMember(bottomContainerLayout);
		
		this.addChild(canvasContainerLayout);
		}catch(Exception e){
			SC.say(e.getMessage());
		}
	}
	
	public void showData(){
		if (selectedFilter != null ) {
			this.bankId = Integer.parseInt(selectedFilter);
			Criteria crit = new Criteria();
			crit.addCriteria("BANKID", this.bankId);
			approvedRatings.invalidateCache();
			approvedRatings.fetchData(crit);
		}else{
			Criteria crit = new Criteria();
			crit.addCriteria("BANKID", "");
			approvedRatings.invalidateCache();
			approvedRatings.fetchData(crit);
		}
	}
	
	public static class Creator implements it.ccg.irweb.client.utils.Creator{
		
		public Canvas create(){
			return new ApprovedRatingCanvas();
		}
	}
	
}
