package it.ccg.irweb.server.servlet;

import it.ccg.irejb.server.bean.CalculationBean;
import it.ccg.irejb.server.bean.TimerBeanLocal;
import it.ccg.irejb.server.exception.BackEndException;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.io.IOException;
import java.util.Date;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;


/**
 * Servlet implementation class SchedulerEndpoint
 */
public class SchedulerEndpoint extends GenericEndpoint {

	@EJB
	private TimerBeanLocal timer;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1351704556122916709L;

	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = LoggerFactory.getLogger(LoggerFactory.USER_LOGGER);
	
	/* (non-Javadoc)
	 * @see it.ccg.irweb.server.servlet.GenericEndpoint#fetch(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void fetch(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.fetch(request, response);
	}

	/* (non-Javadoc)
	 * @see it.ccg.irweb.server.servlet.GenericEndpoint#add(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@SuppressWarnings("deprecation")
	@Override
	protected void add(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		logger.debug(new StandardLogMessage("in SchedulerEndpoint.add"));
		try {
			logger.debug(new StandardLogMessage("creating standard scheduler"));
			String type = (String) request.getParameter("type");
			String interval = (String) request.getParameter("interval");
			
			if(timer.getTimer(type)==null){
				String startDateTimeString = request.getParameter("startDateTimeMillis");
				if (startDateTimeString!=null && !startDateTimeString.equalsIgnoreCase("")){			
					
					String user = (String) request.getAttribute("UPDUSR");
					if(user==null || user.equalsIgnoreCase("")){
						user = request.getUserPrincipal().getName();
					}
					
					CalculationBean bean=null;
					if (type.equalsIgnoreCase("setUp")){
						bean = new CalculationBean(CalculationBean.YEARSETUP, new Date(Long.parseLong(startDateTimeString)), Long.parseLong(interval) , user);
						userLogger.info(new StandardLogMessage("user: "+user+" is creating a "+type+" type's calculation startDateTime "+bean.getStartDateTime().getDate()+"/"+bean.getStartDateTime().getMonth()+1+"/"+bean.getStartDateTime().getYear()+" "+bean.getStartDateTime().getHours()+":"+bean.getStartDateTime().getMinutes()+":"+bean.getStartDateTime().getSeconds()+" interval: "+interval));
					}else if (type.equalsIgnoreCase("dailyRun")){
						bean = new CalculationBean(CalculationBean.DAILYRUN, new Date(Long.parseLong(startDateTimeString)), Long.parseLong(interval) , user);
						userLogger.info(new StandardLogMessage("user: "+user+" is creating a "+type+" type's calculation startDateTime "+bean.getStartDateTime().getDate()+"/"+bean.getStartDateTime().getMonth()+1+"/"+bean.getStartDateTime().getYear()+" "+bean.getStartDateTime().getHours()+":"+bean.getStartDateTime().getMinutes()+":"+bean.getStartDateTime().getSeconds()+" interval: "+interval));
					}else{
						logger.error("Errore during scheduler creation timer already present");
						response.sendError(HttpServletResponse.SC_BAD_REQUEST,"Timer with same type already present");
					}
					
					timer.createTimer(bean);
					userLogger.info(new StandardLogMessage("type's calculation "+type+" created"));
					logger.info(new StandardLogMessage("type's calculation "+type+" created"));
					response.setStatus(HttpServletResponse.SC_OK);
				}else{
					logger.debug(new StandardLogMessage("creating start immediatelly scheduler"));
					
					String user = (String) request.getAttribute("UPDUSR");
					if (user == null || user.equalsIgnoreCase("")){
						user = request.getUserPrincipal().getName();
					}

					CalculationBean bean = new CalculationBean(CalculationBean.DAILYRUNONESHOT , new Date(),user);
					userLogger.info(new StandardLogMessage("user: "+user+" is creating a start immediatelly type's calculation "+CalculationBean.DAILYRUNONESHOT+" startDateTime "+bean.getStartDateTime().getDate()+"/"+bean.getStartDateTime().getMonth()+1+"/"+bean.getStartDateTime().getYear()+" "+bean.getStartDateTime().getHours()+":"+bean.getStartDateTime().getMinutes()+":"+bean.getStartDateTime().getSeconds()));
					timer.createOneShotTimer(bean);
					userLogger.info(new StandardLogMessage("type's calculation "+type+" created"));
					logger.info(new StandardLogMessage("type's calculation "+type+" created"));
					response.setStatus(HttpServletResponse.SC_OK);
				}
			}else{
				logger.error("Errore during scheduler creation timer already present");
				response.sendError(HttpServletResponse.SC_BAD_REQUEST,"Timer with same type already present");
			}
			
		} catch (BackEndException e) {
			userLogger.error("Errore during scheduler creation");
			logger.error("Errore during scheduler creation "+e.getMessage());
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,e.getMessage());
		} 		
	}

	/* (non-Javadoc)
	 * @see it.ccg.irweb.server.servlet.GenericEndpoint#update(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void update(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.update(request, response);
	}

	/* (non-Javadoc)
	 * @see it.ccg.irweb.server.servlet.GenericEndpoint#remove(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void remove(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		logger.debug(new StandardLogMessage("in SchedulerEndpoint.remove"));
		try {
			String type = (String) request.getParameter("type");
						
			timer.deleteTimer(type);
			userLogger.info(new StandardLogMessage("type's calculation "+type+" deleted"));
			logger.info(new StandardLogMessage("type's calculation "+type+" deleted"));
			
			response.setStatus(HttpServletResponse.SC_OK);
			
		} catch (BackEndException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			ExceptionUtil.logCompleteStackTrace(userLogger, e);
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,e.getMessage());
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			ExceptionUtil.logCompleteStackTrace(userLogger, e);
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,e.getMessage());
		} 
	}

}
