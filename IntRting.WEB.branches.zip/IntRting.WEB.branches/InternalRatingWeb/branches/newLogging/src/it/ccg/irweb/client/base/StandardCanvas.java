package it.ccg.irweb.client.base;

import it.ccg.irweb.client.controls.StandardButton;
import it.ccg.irweb.client.controls.StandardComboBox;
import it.ccg.irweb.client.controls.StandardSelectItem;
import it.ccg.irweb.client.controls.StandardShowButton;

import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.form.fields.DateItem;
import com.smartgwt.client.widgets.form.fields.MiniDateRangeItem;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;

public class StandardCanvas extends Canvas {

	protected StandardButton exportData;
	protected StandardButton printData;
	protected StandardComboBox filterCombo;
	protected StandardSelectItem filterSelect;
	protected HLayout topContainerLayout; 
	protected HLayout bottomContainerLayout; 
	protected VLayout canvasContainerLayout;
	protected LayoutSpacer spacerLayout = new LayoutSpacer();
	protected MiniDateRangeItem date;
	protected DateItem datetimeEdit;
	protected DateItem dateEdit;
	protected ToolStripButton refreshButton;
	protected StandardShowButton showButton;
	
	public StandardCanvas(){
		
		date = new MiniDateRangeItem();
		//TODO Check automatic substitution
		date.setDateDisplayFormat(DateDisplayFormat.TOEUROPEANSHORTDATE);

		datetimeEdit = new DateItem();
		datetimeEdit.setDisplayFormat(DateDisplayFormat.TOEUROPEANSHORTDATETIME);

		dateEdit = new DateItem();
		dateEdit.setDisplayFormat(DateDisplayFormat.TOEUROPEANSHORTDATE);
		
		exportData = new StandardButton("Export");
		printData = new StandardButton("Print");

		canvasContainerLayout = new VLayout();
		canvasContainerLayout.setMembersMargin(5);
		canvasContainerLayout.setWidth100();
		canvasContainerLayout.setHeight100();
		
		showButton = new StandardShowButton();
		showButton.setAlign(Alignment.CENTER);
		
		spacerLayout.setWidth("70%");
		
		refreshButton = new ToolStripButton();
		refreshButton.setIcon("[SKIN]/actions/refresh.png");
		refreshButton.setTitle("Refresh");
		refreshButton.setPrompt("Refresh");
		refreshButton.setLayoutAlign(Alignment.LEFT);
		
		topContainerLayout = new HLayout(); 
		topContainerLayout.setMembersMargin(5);
		topContainerLayout.setWidth("99%");
		topContainerLayout.setHeight(30);
		topContainerLayout.setAlign(VerticalAlignment.TOP);
		topContainerLayout.setAlign(Alignment.RIGHT);
		
		bottomContainerLayout = new HLayout();
		bottomContainerLayout.setMembersMargin(5);
		bottomContainerLayout.setWidth("99%");
		bottomContainerLayout.setHeight(30);
	}
	
}
