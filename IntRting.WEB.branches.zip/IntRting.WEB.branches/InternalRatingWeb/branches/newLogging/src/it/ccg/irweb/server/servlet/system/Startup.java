package it.ccg.irweb.server.servlet.system;


import it.ccg.irejb.server.logengine.Log4jSetup;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.security.SessionManagerLocal;
import it.ccg.irejb.server.system.LocalBeanLookup;
import it.ccg.irejb.server.system.SystemProperties;

import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;


/**
 * Servlet implementation class Startup
 */
public class Startup extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger logger;
	
	private SessionManagerLocal sessionManagerLocal;
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Startup() {
    	super();
    	
    	try {
    		System.out.println("Loading InternalRating system environment..");
    		
    		// Load log4j properties
			Log4jSetup.loadLog4JProperties();
			logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
			
			// Load system properties
    		SystemProperties.loadSystemProperties();
			// Init session manager
    		this.sessionManagerLocal = (SessionManagerLocal)LocalBeanLookup.lookup(SessionManagerLocal.class.getCanonicalName());
			this.sessionManagerLocal.init();
			
			
			logger.debug(new StandardLogMessage("InternalRating system environment successfully loaded."));
    	}
    	catch(Exception e) {
    		System.out.println("Errore during loading InternalRating system environment.. "+e.getMessage());
    		e.printStackTrace();
		}
		
    }
    

}
