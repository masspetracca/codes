package it.ccg.irweb.client;

import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.tab.TabSet;

public interface PanelFactory {

	Canvas create(TabSet mainTabSet,String panelID);

    String getID();

    String getDescription();

	Canvas create(TabSet mainTabSet, String nodeID, int attributeAsInt, String attributeAsString);
}
