package it.ccg.irweb.client.controls;

import it.ccg.irweb.client.security.UserData;

public class StandardProfiledButton extends StandardButton {

	public StandardProfiledButton(){
		super();
		if(UserData.getCurrentUserData().getUserRolesList().contains("admin") || UserData.getCurrentUserData().getUserRolesList().contains("user")){
			this.setVisible(true);
			this.setDisabled(false);
		}else{
			this.setVisible(false);
			this.setDisabled(true);
		}
	}
	
	public StandardProfiledButton(String title){
		super(title);
		if(UserData.getCurrentUserData().getUserRolesList().contains("admin") || UserData.getCurrentUserData().getUserRolesList().contains("user")){
			this.setVisible(true);
			this.setDisabled(false);
		}else{
			this.setVisible(false);
			this.setDisabled(true);
		}
	}
}
