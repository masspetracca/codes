package it.ccg.irweb.client;

import it.ccg.irweb.client.base.StandardCanvas;
import it.ccg.irweb.client.controls.StandardButton;
import it.ccg.irweb.client.controls.StandardComboBox;
import it.ccg.irweb.client.elements.ImportThresholdsWindow;
import it.ccg.irweb.client.elements.PopupWindow;

import java.util.ArrayList;
import java.util.Date;

import com.google.gwt.user.client.ui.TextArea;
import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.data.RecordList;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.types.RowEndEditAction;
import com.smartgwt.client.types.TextMatchStyle;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.PrintPreviewCallback;
import com.smartgwt.client.util.PrintProperties;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.util.ValueCallback;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.PrintCanvas;
import com.smartgwt.client.widgets.PrintWindow;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.DateItem;
import com.smartgwt.client.widgets.form.fields.FormItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.fields.events.ChangeEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangeHandler;
import com.smartgwt.client.widgets.form.validator.RegExpValidator;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.FilterEditorSubmitEvent;
import com.smartgwt.client.widgets.grid.events.FilterEditorSubmitHandler;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;

public class ParameterSelectionCanvas extends StandardCanvas{
	
	private String selectedFilter;
	private int selectedThresholdFilter = 999999999;
	DataSource rctvarsDS;
	DataSource rctthrshldDS;
	ListGrid varsGrid;
	ListGrid thresholdGrid;
	StandardButton saveSelectedField;
	StandardButton editSelectedField;
	StandardButton showThresholdHistory;
	StandardButton newThreshold;
	StandardButton importData;
	HLayout gridContainer;
	Window editThresholdWindow;
	Window createThresholdWindow;
	Window thresholdHystWindow;
	RegExpValidator regExpValidatorDouble = new RegExpValidator("[\\-\\+]?[0-9]*\\.?[0-9]*$");
	
	//Window classNumWindow;
	
	public ParameterSelectionCanvas(){		
		super();
					
		regExpValidatorDouble.setErrorMessage("Only numbers are allowed");
		this.gridContainer = new HLayout();
		this.gridContainer.setMembersMargin(5);
		
		rctvarsDS = DataSource.get("rctvars") ;
		rctthrshldDS = DataSource.get("rctthrshld");
		
		saveSelectedField = new StandardButton("Save selected fields");
		saveSelectedField.setPrompt("Save selected fields");
		
		newThreshold = new  StandardButton("Create thresholds");
		newThreshold.setPrompt("Create thresholds for selected field");
		newThreshold.setDisabled(true);
		
		editSelectedField = new StandardButton("Edit thresholds");
		editSelectedField.setPrompt("Edit field paramenters");
		editSelectedField.setDisabled(true);
		
		showThresholdHistory = new StandardButton("Threshold history");
		showThresholdHistory.setPrompt("Show threshold history");
		showThresholdHistory.setDisabled(true);
		
		importData = new StandardButton("Import threshoulds");
		importData.setDisabled(true);
		
		exportData.setDisabled(true);
		
		filterCombo = new StandardComboBox("Parameter");
		filterCombo.setOptionDataSource(rctvarsDS);
		filterCombo.setValueField("VARID");
		filterCombo.setDisplayField("VARDESC");
		filterCombo.setSortField("VARDESC");
		filterCombo.setFilterLocally(true);
		filterCombo.setAllowEmptyValue(true);
		//filterCombo.setOptionOperationId("rctvars_fetch");
		
		filterCombo.addChangeHandler(new ChangeHandler() {
			
			@Override
			public void onChange(ChangeEvent event) {
				//SC.say(event.getValue().toString());
				if (event.getValue() != null)
					selectedFilter = event.getValue().toString();
				if (event.getValue() == null){
					selectedFilter = "";
					showData();
					selectedThresholdFilter= 999999999;
					showThresholdData();
				}
				
			}
		});
		
		topContainerLayout.addMember(filterCombo.inDynamicForm());
		//Change handler combo
		
		
		this.showButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				showData();
				if (selectedFilter!=null){
					
					try{
						selectedThresholdFilter=Integer.parseInt(selectedFilter);
					}catch(NumberFormatException e){
						selectedThresholdFilter=999999999;
					}
					showThresholdData();
				}
			}
		});
				
		this.topContainerLayout.addMember(showButton);
		//add space
		this.topContainerLayout.addMember(spacerLayout);
				
		this.refreshButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				showData();
				selectedThresholdFilter=999999999;
				showThresholdData();
			}
		});
		
		this.topContainerLayout.addMember(refreshButton);
		//
		this.canvasContainerLayout.addMember(topContainerLayout);
		
		ListGridField varIdField = new ListGridField("VARID");
		ListGridField varDescField = new ListGridField("VARDESC");
		varDescField.setTitle("Parameter name");
		ListGridField statusField = new ListGridField("STATUS");
		ListGridField dailyField = new ListGridField("DAILYRUN");
		ListGridField yearField = new ListGridField("YEARSETUP");
		ListGridField providerField = new ListGridField("PROVIDER");

		
		ListGridField thrshldvarIdField = new ListGridField("VARID");
		thrshldvarIdField.setOptionDataSource(rctvarsDS);
		thrshldvarIdField.setValueField("VARID");
		thrshldvarIdField.setDisplayField("VARDESC");
		thrshldvarIdField.setTitle("Threshold parameter");
		
		ListGridField thrshldIdField = new ListGridField("THRSHOLDID");
		ListGridField thrshldDteField = new ListGridField("THRSHLDDTE");
		ListGridField thrshldOpField = new ListGridField("THRSHLDOP");
		ListGridField thrshldValField = new ListGridField("THRSHLDVAL");
		ListGridField thrshldCoefField = new ListGridField("THRSHLDCOE");

		varsGrid = new ListGrid();
		varsGrid.setWidth("40%");
		varsGrid.setFields(varIdField,varDescField,providerField,statusField,dailyField,yearField);
		varsGrid.setTitle("Fields");
		varsGrid.setDataSource(rctvarsDS);
		varsGrid.setInitialCriteria(new Criteria("STATUS", "E"));
		varsGrid.setShowDetailFields(true);
		varsGrid.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATE);
		varsGrid.setShowFilterEditor(true);
		varsGrid.setDataPageSize(40);
		varsGrid.setModalEditing(true);
		varsGrid.setFilterOnKeypress(false);
		varsGrid.setListEndEditAction(RowEndEditAction.NEXT);
		varsGrid.setAutoSaveEdits(false);
		varsGrid.setCanEdit(true);
		varsGrid.setAutoFetchData(true);
		varsGrid.setEditEvent(ListGridEditEvent.NONE);
		varsGrid.setAutoFetchTextMatchStyle(TextMatchStyle.SUBSTRING);
		varsGrid.setCanGroupBy(false);
		varsGrid.setCanFreezeFields(false);
		varsGrid.setCanAutoFitFields(false);
		
		varsGrid.addRecordClickHandler(new RecordClickHandler() {
			@Override
			public void onRecordClick(RecordClickEvent event) {
				
				ListGridRecord rec = varsGrid.getSelectedRecord();
				selectedThresholdFilter = Integer.parseInt(rec.getAttribute("VARID"));
				showThresholdData();
				editSelectedField.setDisabled(false);
				importData.setDisabled(false);
				showThresholdHistory.setDisabled(false);
				newThreshold.setDisabled(false);
				exportData.setDisabled(false);
			}
		});
				
		varsGrid.addFilterEditorSubmitHandler(new FilterEditorSubmitHandler() {
			@Override
			public void onFilterEditorSubmit(FilterEditorSubmitEvent event) {
				selectedFilter = event.getCriteria().getAttributeAsString("VARDESC");
				selectedThresholdFilter=999999999;
				showThresholdData();
				filterCombo.setValue(selectedFilter);
				filterCombo.redraw();
				
				//event.getCriteria().addCriteria("VARDESC", selectedFilter);	
			}
		});
		
		varsGrid.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				varsGrid.startEditing(event.getRecordNum(), event.getFieldNum(), true);
			}
		});

		this.gridContainer.addMember(varsGrid);
		
		this.thresholdGrid = new ListGrid();
		this.thresholdGrid.setWidth("60%");
		this.thresholdGrid.setFields(thrshldvarIdField,thrshldIdField,thrshldValField,thrshldOpField,thrshldCoefField,thrshldDteField);
		this.thresholdGrid.setTitle("Field threshold");
		this.thresholdGrid.setShowDetailFields(true);
		this.thresholdGrid.setDataSource(rctthrshldDS);
		this.thresholdGrid.setFetchOperation("threshold_fetch");
		//his.threshold.setFetchOperation("last_thrshold_fetch");
		this.thresholdGrid.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATE);
		this.thresholdGrid.setShowFilterEditor(false);
		this.thresholdGrid.setDataPageSize(40);
		this.thresholdGrid.setModalEditing(true);
		this.thresholdGrid.setFilterOnKeypress(false);
		this.thresholdGrid.setListEndEditAction(RowEndEditAction.NEXT);
		this.thresholdGrid.setAutoSaveEdits(false);
		this.thresholdGrid.setAutoFetchData(false);
		this.thresholdGrid.setEditEvent(ListGridEditEvent.NONE);
		this.thresholdGrid.setCanGroupBy(false);
		this.thresholdGrid.setCanFreezeFields(false);
		this.thresholdGrid.setCanAutoFitFields(false);
		
		this.gridContainer.addMember(thresholdGrid);
		
		this.canvasContainerLayout.addMember(this.gridContainer);
		
		saveSelectedField.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				
					int indexes[] = varsGrid.getAllEditRows();
					boolean canProcede = true;
					String dailyRunValue="";
					String statusValue="";
					for (int i = 0;i<indexes.length;i++){
						dailyRunValue = (String) varsGrid.getEditValue(indexes[i], "DAILYRUN") ;//getRecord(indexes[i]).getAttributeAsString("DAILYRUN");
						statusValue = (String) varsGrid.getEditValue(indexes[i], "STATUS") ; //getRecord(indexes[i]).getAttributeAsString("STATUS");
						if (statusValue==null || statusValue.equalsIgnoreCase("")){
							statusValue = varsGrid.getRecord(indexes[i]).getAttributeAsString("STATUS");
						}
						if (dailyRunValue!=null && !dailyRunValue.equalsIgnoreCase("")){
							if(dailyRunValue.equalsIgnoreCase("t") && statusValue.equalsIgnoreCase("d")){
								canProcede=false;
							}
						}
					}
					if (!canProcede){
						SC.warn("Status must be \"Enabled\" if Daily run has \"True\" value");
						return;
					}else{
						varsGrid.saveAllEdits();
					}
			}
		});

		newThreshold.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				
				if(varsGrid.getSelectedRecord()== null){
					SC.say("No record selected");
					return;
				}else{
					SC.askforValue("Insert number of classes",new ValueCallback(){
						public void execute(String value) {
							if (value!=null){
								try {
									int classNum = Integer.parseInt(value);
									createThresholdWindow = PopupWindow.getInstance("New " /*parameter*/ +varsGrid.getSelectedRecord().getAttribute("VARDESC") +" threshold", 370, 280);
									createThresholdWindow.addCloseClickHandler(new CloseClickHandler() {
										@Override
										public void onCloseClick(CloseClickEvent event) {
											showThresholdData();
										}
									});
	
									createThresholdWindow.addMember(createThresholdForm(classNum,varsGrid.getSelectedRecord().getAttribute("VARID")));
									createThresholdWindow.draw();
								}catch(NumberFormatException e){
									SC.warn("Insert a numeric value");
									return;
								}
							}
						}
					});					
				}
			}
		});		
		
		editSelectedField.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				if(varsGrid.getSelectedRecord()== null){
					SC.say("No record selected");
					return;
				}else{
					editThresholdWindow = PopupWindow.getInstance("Edit " /*parameter*/ +varsGrid.getSelectedRecord().getAttribute("VARDESC")+ " threshold", 400, 320);
					editThresholdWindow.addCloseClickHandler(new CloseClickHandler() {
						@Override
						public void onCloseClick(CloseClickEvent event) {
							/*selectedThresholdFilter=varsGrid.getSelectedRecord().getAttribute("VARID");
							showThresholdData();*/
						}
					});
					editThresholdWindow.addMember(editThresholdForm());
					editThresholdWindow.draw();
				}
			}
		});
		
		showThresholdHistory.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				thresholdHystWindow = PopupWindow.getInstance("Threshold history", 400, 320);
				thresholdHystWindow.addCloseClickHandler(new CloseClickHandler() {
					@Override
					public void onCloseClick(CloseClickEvent event) {
						showThresholdData();
					}
				});
				
				thresholdHystWindow.addMember(thresholdHystForm());
				thresholdHystWindow.draw();
			}
		});
		
		this.exportData.addClickHandler(new ClickHandler() {	
			@Override
			public void onClick(ClickEvent event) {
				if (varsGrid.getSelectedRecords().length>1){
					SC.warn("Select just one row");
				}else{
					DSRequest request = new DSRequest();
					String name = varsGrid.getSelectedRecord().getAttribute("VARDESC");
					name = name.replace("/", "_");
					request.setExportFilename(name+" trhesholds");
					request.setExportToClient(true);
					request.setExportValueFields(true);
					thresholdGrid.exportClientData(request);
				}
			}
		});
		
		this.printData.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				PrintProperties printProp = new PrintProperties();
				printProp.setAttribute("Orientation", "Landscape");
				Img logoImg = new Img("CCGlogo.gif", 255, 51);  	
				Label label = new Label();  
		        label.setHeight(30);  
		        label.setPadding(10); 
		        label.setContents("<b>Threshold history</b>");
		        label.setAlign(Alignment.CENTER);  
		        label.setValign(VerticalAlignment.CENTER); 
		        
		        LayoutSpacer spacer = new LayoutSpacer();
		        spacer.setWidth(10);
		        
				Canvas.showPrintPreview(new Object[] {logoImg,label,spacer,varsGrid,spacer,thresholdGrid}, printProp, "Parameter selection", new PrintPreviewCallback() {
					
					@Override
					public void execute(PrintCanvas printCanvas, PrintWindow printWindow) {
												
					}
				});
			}
		});

		importData.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				ImportThresholdsWindow.windowCreator(thresholdGrid,"Thresholds.csv",varsGrid.getSelectedRecord().getAttributeAsString("VARID"));
			}
		});

		this.bottomContainerLayout.addMember(saveSelectedField);
		this.bottomContainerLayout.addMember(newThreshold);
		this.bottomContainerLayout.addMember(editSelectedField);
		this.bottomContainerLayout.addMember(showThresholdHistory);
		this.bottomContainerLayout.addMember(importData);
		this.bottomContainerLayout.addMember(exportData);
		this.bottomContainerLayout.addMember(printData);
		
		this.canvasContainerLayout.addMember(bottomContainerLayout);
		
		this.addChild(canvasContainerLayout);
	}

	public void showThresholdData(){
		Criteria crit = new Criteria();
		if (this.selectedThresholdFilter != 0 ) {
			crit.addCriteria("VARID", selectedThresholdFilter);
			thresholdGrid.filterData(crit);
		} else {
			crit.addCriteria("VARID", "9999999");
			thresholdGrid.filterData(crit);
			//thresholdGrid.redraw();
		}
	}
	
	public void showData(){
		Criteria crit = new Criteria();
		if (selectedFilter != null && !selectedFilter.equalsIgnoreCase("")) {
			crit.addCriteria("VARID", selectedFilter);
			varsGrid.invalidateCache();
			varsGrid.fetchData/*filterData*/(crit);
			//varsGrid.redraw();
		} else {
			crit.addCriteria("VARID", "");
			varsGrid.invalidateCache();
			varsGrid.fetchData/*filterData*/(crit);
			//varsGrid.redraw();
		}
	}
	
	private VLayout editThresholdForm() {
		
		RegExpValidator regExpValidatorDouble = new RegExpValidator("^([\\-\\+]?[0-9]*)\\.?[0-9]*$");
		regExpValidatorDouble.setErrorMessage("Only numbers are allowed");
		
		final VLayout containerLayout = new VLayout();
    	containerLayout.setHeight100();
    	containerLayout.setWidth100();
    	containerLayout.setAlign(Alignment.CENTER);
    	containerLayout.setMembersMargin(7);

    	final HLayout buttonContainer = new HLayout();
    	buttonContainer.setHeight100();
    	buttonContainer.setWidth100();
    	buttonContainer.setAlign(Alignment.CENTER);
    	buttonContainer.setMembersMargin(5);

		final DynamicForm formClass = new DynamicForm();
		formClass.setNumCols(2);
		formClass.setMargin(3);
		formClass.setHeight("100%");  
		formClass.setWidth100();
		
		final StandardButton saveRowButton = new StandardButton("Save");
        StandardButton cancelRowButton = new StandardButton("Cancel");
        
		RecordList list = thresholdGrid.getDataAsRecordList();
		final ArrayList<FormItem[]> fields = new ArrayList<FormItem[]>();
		int num=0;
		Record r;

		if (list.getLength()>0){
			while((r = list.get(num))!=null){
				FormItem[] items = new FormItem[6];
				//ListGridField thrshldvarIdField = new ListGridField("VARID");
				TextItem tVarId = new TextItem("varId"+(num+1));
				tVarId.setValue(r.getAttribute("VARID"));
				tVarId.setVisible(false);
				tVarId.setRequired(true);
				items[0] = tVarId;
				
				//ListGridField thrshldDteField = new ListGridField("THRSHLDDTE");
				DateItem dateIt = new DateItem("dt"+(num+1));
				dateIt.setValue(r.getAttribute("THRSHLDDTE"));
				dateIt.setVisible(false);
				dateIt.setRequired(true);
				items[1] = dateIt;
				
				//ListGridField thrshldCoefField = new ListGridField("THRSHLDCOE");
				TextItem tCoef = new TextItem("co"+(num+1),"<nobr>Class "+(num+1)+" coefficient</nobr>");
				tCoef.setValue(r.getAttribute("THRSHLDCOE"));
				tCoef.setRequired(true);
				tCoef.setValidators(regExpValidatorDouble);
				items[2] = tCoef;
				
				TextItem tID = new TextItem("id"+(num+1));
				tID.setValue(r.getAttribute("THRSHOLDID"));
				tID.setVisible(false);
				tID.setRequired(true);
				items[3] = tID ;
	
				//ListGridField thrshldValField = new ListGridField("THRSHLDVAL");
				TextItem tVal = new TextItem("th"+(num+1),"<nobr>Class "+(num+1)+" threshold</nobr>");
				tVal.setValue(r.getAttribute("THRSHLDVAL"));
				tVal.setVisible(true);
				tVal.setRequired(true);
				tVal.setValidators(regExpValidatorDouble);
				items[4] = tVal;
				
				//ListGridField thrshldOpField = new ListGridField("THRSHLDOP");
				TextItem tOp = new TextItem("op"+(num+1));
				tOp.setValue(r.getAttribute("THRSHLDOP"));
				tOp.setVisible(false);
				tOp.setRequired(true);
				items[5] = tOp;
				fields.add(items);
				num++;
			}
			
			FormItem[] items = new FormItem[(fields.size()*6)];
			int arrayId=0;
	        for (int z = 0; z<fields.size();z++){
	        	if (fields.get(z)[5].getValue().equals("NA")){
	        		fields.get(z)[2].setTitle("<nobr>Class \"NA\" coefficient</nobr>");
	        	}
	        	for(int y = 0; y<fields.get(z).length; y++){
	        		if(fields.get(z)[y].getValue()== null || fields.get(z)[y].getValue().equals("")){
	        			fields.get(z)[y].setVisible(false);
	        			fields.get(z)[y].setRequired(false);
	        		}
	        		items[arrayId]=fields.get(z)[y];
	        		arrayId++;
	        	}
	        	
	        }
		     
	        formClass.setFields(items);
	        
	 		// Cancel row button click handler
	 		cancelRowButton.addClickHandler(new ClickHandler() {
	 			public void onClick(ClickEvent event) {
	 				showThresholdData();
	 				editThresholdWindow.destroy();
	 			}
	 		});
	 		final int appoNum = num;
	 		// Save row button click handler
	 		saveRowButton.addClickHandler(new ClickHandler() {
	 			public void onClick(ClickEvent event) {
	 				String a="";
	 				try{
	 					
	 				if (formClass.validate()){
	 					a += "1 ";
	 					ListGridRecord[] records= thresholdGrid.getRecords();
	 					RPCManager.startQueue();
	 					a+="2 ";
	 					for (int i = 0;i<appoNum;i++){
	 						a+="3 for "+i;
	 						ListGridRecord r = records[i];
	 						//TextItem tCoef = new TextItem("co"+(num+1),"<nobr>Class "+(num+1)+" coefficient</nobr>");
	 						r.setAttribute("THRSHLDCOE", formClass.getItem("co"+(i+1)) ==null || formClass.getItem("co"+(i+1)).getValue()==""?"":formClass.getItem("co"+(i+1)).getValue());
	 						a+="4 for "+i;
	 						if(formClass.getItem("th"+(i+1)).getValue()!=null){
	 							r.setAttribute("THRSHLDVAL", formClass.getItem("th"+(i+1))==null || formClass.getItem("th"+(i+1)).getValue()==""?"":formClass.getItem("th"+(i+1)).getValue());
	 						}
	 						a+="5 for "+i;
	 						r.setAttribute("UPDTYPE", "U");
	 						r.setAttribute("THRSHLDOP", formClass.getItem("op"+(i+1)).getValue());
	 						a+="6 for "+i;
	 						thresholdGrid.updateData(r);
	 					}
	 					a+="7 ";
	 					RPCManager.sendQueue();
	 					showThresholdData();
	 					a+="8 ";
	 					thresholdGrid.invalidateCache();
						editThresholdWindow.destroy();
	 				}else{
	 					return;
	 				}
	 				}catch(Exception e){
	 					SC.say("dasd "+a+" -- "+e.getMessage());
	 				}
	 			}
	 		});
	 		
	 		containerLayout.addMember(formClass);
	 		buttonContainer.addMember(saveRowButton);
	 		buttonContainer.addMember(cancelRowButton);
	 		containerLayout.addMember(buttonContainer);
		}else{
			Label l = new Label("<b>Thresholds don't find</b>");
			l.setAlign(Alignment.CENTER);

			final StandardButton closeButton = new StandardButton("Close");
			closeButton.addClickHandler(new ClickHandler() {
				
				@Override
				public void onClick(ClickEvent event) {
					// TODO Auto-generated method stub
					editThresholdWindow.destroy();
				}
			});
			
			containerLayout.addMember(l);
			buttonContainer.addMember(closeButton);
			containerLayout.addMember(buttonContainer);
		}
        return containerLayout;
	} 
	
	private VLayout createThresholdForm(final int num,final String vardId) {
		
		final VLayout containerLayout = new VLayout();
    	containerLayout.setHeight100();
    	containerLayout.setWidth100();
    	containerLayout.setAlign(Alignment.CENTER);
    	containerLayout.setAlign(VerticalAlignment.TOP);  
    	containerLayout.setMembersMargin(7);

    	final HLayout topContainer = new HLayout();
    	topContainer.setHeight100();
    	topContainer.setWidth100();
    	topContainer.setAlign(Alignment.CENTER);
    	topContainer.setMembersMargin(5);

    	final HLayout buttonContainer = new HLayout();
    	buttonContainer.setHeight100();
    	buttonContainer.setWidth100();
    	buttonContainer.setAlign(Alignment.CENTER);
    	buttonContainer.setMembersMargin(5);

		final DynamicForm formClass = new DynamicForm();
		formClass.setNumCols(2);
		formClass.setMargin(3);
		formClass.setHeight("100%");  
		formClass.setWidth100(); 

		RegExpValidator regExpValidatorDouble = new RegExpValidator("^([\\-\\+]?[0-9]*)\\.?[0-9]*$");
		regExpValidatorDouble.setErrorMessage("Only numbers are allowed");
	        
		formClass.setLayoutAlign(VerticalAlignment.CENTER);  

		final ArrayList<TextItem> fields = new ArrayList<TextItem>();
		int y= 0;

		for (int i = 1;i<=num;i++){
			fields.add(new TextItem("th"+i,"<nobr>Class "+i+" threshold</nobr>" ));
			if (i==num){
				fields.get(y).setRequired(false);
				fields.get(y).setValidators(regExpValidatorDouble);
				fields.get(y).setVisible(false);
			}else{
				fields.get(y).setValidators(regExpValidatorDouble);
				fields.get(y).setRequired(true);
			}
			y++;
			fields.add(new TextItem("co"+i,"<nobr>Class "+i+" coefficient</nobr>"));
			fields.get(y).setRequired(true);
			fields.get(y).setValidators(regExpValidatorDouble);
			y++;
		}	

		final TextItem classesNATh = new TextItem("classNATh","Classes NA");
        classesNATh.setRequired(false);
        classesNATh.setVisible(false);
        TextItem classesNACo = new TextItem("classNACo","<nobr>Class \"NA\" coefficient</nobr>");
        classesNACo.setRequired(true);
        classesNACo.setValidators(regExpValidatorDouble);
        fields.add(classesNATh);
        fields.add(classesNACo);

        FormItem[] items = new FormItem[fields.size()];
        for (int z = 0; z<fields.size();z++){
        	items[z]=fields.get(z);
        }
        
 		formClass.setFields(items);
			
        final StandardButton saveRowButton = new StandardButton("Save");
        StandardButton cancelRowButton = new StandardButton("Cancel");
        
 		// Cancel row button click handler
 		cancelRowButton.addClickHandler(new ClickHandler() {
 			public void onClick(ClickEvent event) {
 				formClass.reset();
 			}
 		});

 		// Save row button click handler
 		saveRowButton.addClickHandler(new ClickHandler() {
 			public void onClick(ClickEvent event) {
 				
 				if (formClass.validate()){
 					Date d = new Date();
 					RPCManager.startQueue();
 					for (int i = 1;i<=num;i++){
 						Record r = new Record();
 						r.setAttribute("VARID", vardId);
 						r.setAttribute("THRSHLDDTE", d);
 						if (i==num){
 	 						r.setAttribute("THRSHLDOP", "else");
 	 						r.setAttribute("THRSHLDCOE", formClass.getItem("co"+i).getValue());
 	 					}else{
 							r.setAttribute("THRSHLDVAL", formClass.getItem("th"+i).getValue());
 	 						r.setAttribute("THRSHLDOP", "<");
 	 						r.setAttribute("THRSHLDCOE", formClass.getItem("co"+i).getValue());
 	 					}
 						thresholdGrid.addData(r);
 					}
 					Record r = new Record();
 					r.setAttribute("VARID", vardId);
 					r.setAttribute("THRSHLDDTE", d);
 					r.setAttribute("THRSHLDOP", "NA");
					r.setAttribute("THRSHLDCOE", formClass.getItem("classNACo").getValue());

					thresholdGrid.addData(r);
					selectedThresholdFilter = Integer.parseInt(vardId);
					RPCManager.sendQueue();
					showThresholdData();
					thresholdGrid.invalidateCache();
					createThresholdWindow.destroy();
 				}else{
 					return;
 				}
 				
 			}
 		});

        containerLayout.addMember(formClass);
        buttonContainer.addMember(saveRowButton);
 		buttonContainer.addMember(cancelRowButton);
 		
 		containerLayout.addMember(buttonContainer);
 		
        return containerLayout;
	} 

	private VLayout thresholdHystForm() {
		
		final VLayout containerLayout = new VLayout();
    	containerLayout.setHeight100();
    	containerLayout.setWidth100();
    	containerLayout.setAlign(Alignment.CENTER);
    	containerLayout.setMembersMargin(7);

    	StandardButton exportThrshld = new StandardButton("Export");
    	StandardButton printThrshld = new StandardButton("Print");
    	StandardButton closeButton = new StandardButton("Close");
    	
    	final HLayout buttonContainer = new HLayout();
    	buttonContainer.setHeight("10%");
    	buttonContainer.setWidth100();
    	buttonContainer.setAlign(Alignment.CENTER);
    	buttonContainer.setMembersMargin(5);
    	
    	ListGridField thrshldDteField = new ListGridField("THRSHLDDTE");
		thrshldDteField.setFilterEditorType(date); 
		thrshldDteField.setEditorType(dateEdit);

		ListGridField thrshldOpField = new ListGridField("THRSHLDOP");
		ListGridField thrshldValField = new ListGridField("THRSHLDVAL");
		ListGridField thrshldCoefField = new ListGridField("THRSHLDCOE");
    	
		final ListGrid thrshldHystGrid = new ListGrid();
		thrshldHystGrid.setWidth100();
		thrshldHystGrid.setHeight("90%");
		thrshldHystGrid.setFields(thrshldValField,thrshldOpField,thrshldCoefField,thrshldDteField);
		thrshldHystGrid.setTitle("Threshold hystory");
		thrshldHystGrid.setDataSource(rctthrshldDS);
		thrshldHystGrid.setFetchOperation("complete_threshold_fetch");
		thrshldHystGrid.setShowDetailFields(true);
		thrshldHystGrid.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATE);
		thrshldHystGrid.setShowFilterEditor(false);
		thrshldHystGrid.setDataPageSize(40);
		thrshldHystGrid.setModalEditing(true);
		thrshldHystGrid.setFilterOnKeypress(false);
		thrshldHystGrid.setListEndEditAction(RowEndEditAction.NEXT);
		thrshldHystGrid.setAutoSaveEdits(false);
		thrshldHystGrid.setAutoFetchData(true);
		thrshldHystGrid.setEditEvent(ListGridEditEvent.NONE);
		thrshldHystGrid.setAutoFetchTextMatchStyle(TextMatchStyle.SUBSTRING);
    	
		Criteria startCriteria = new Criteria();
		startCriteria.addCriteria("VARID", selectedThresholdFilter);
		
		thrshldHystGrid.setInitialCriteria(startCriteria);
		containerLayout.addMember(thrshldHystGrid);
    	
		exportThrshld.addClickHandler(new ClickHandler() {	
			@Override
			public void onClick(ClickEvent event) {
				DSRequest request = new DSRequest();
				String name = varsGrid.getSelectedRecord().getAttribute("VARDESC");
				name = name.replace("/", "_");
				request.setExportFilename(name+" trhesholds history");
				request.setExportToClient(true);
				thrshldHystGrid.exportData(request);
			}
		});
		
		printThrshld.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Img logoImg = new Img("CCGlogo.gif", 255, 51);  	
				Label label = new Label();  
		        label.setHeight(30);  
		        label.setPadding(10); 
		        label.setContents("<b>Threshold history</b>");
		        label.setAlign(Alignment.CENTER);  
		        label.setValign(VerticalAlignment.CENTER); 
		        
		        LayoutSpacer spacer = new LayoutSpacer();
		        spacer.setWidth(10);
		        
				Canvas.showPrintPreview(new Object[] {logoImg,label,spacer,thrshldHystGrid}, null, "Threshold history", new PrintPreviewCallback() {
					
					@Override
					public void execute(PrintCanvas printCanvas, PrintWindow printWindow) {
												
					}
				});
			}
		});
		
		closeButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				thresholdHystWindow.destroy();
			}
		});
		
		buttonContainer.addMember(exportThrshld);
		buttonContainer.addMember(printThrshld);
		buttonContainer.addMember(closeButton);
		
		containerLayout.addMember(buttonContainer);
        return containerLayout;
	} 

	public static class Creator implements it.ccg.irweb.client.utils.Creator{
		
		public Canvas create(){
			return new ParameterSelectionCanvas();
		}
	}
}
