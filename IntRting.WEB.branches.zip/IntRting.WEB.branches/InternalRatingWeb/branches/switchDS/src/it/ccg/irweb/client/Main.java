package it.ccg.irweb.client;

import it.ccg.irweb.client.elements.AccountMenuWindow;
import it.ccg.irweb.client.elements.ExplorerTreeNode;
import it.ccg.irweb.client.elements.InternalRatingTreeNode;
import it.ccg.irweb.client.elements.SideNavTree;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.History;
import com.google.gwt.user.client.HistoryListener;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCQueueCallback;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.SelectionStyle;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.events.ClickHandler;
import com.smartgwt.client.widgets.menu.events.MenuItemClickEvent;
import com.smartgwt.client.widgets.tab.Tab;
import com.smartgwt.client.widgets.tab.TabSet;
import com.smartgwt.client.widgets.tree.Tree;
import com.smartgwt.client.widgets.tree.TreeNode;
import com.smartgwt.client.widgets.tree.events.LeafClickEvent;
import com.smartgwt.client.widgets.tree.events.LeafClickHandler;


@SuppressWarnings("deprecation")
public class Main implements EntryPoint, HistoryListener {

	private TabSet mainTabSet;
	private SideNavTree sideNav;
	static HLayout headerHorLayout;
	static HLayout logoHorLayout;
	static LayoutSpacer spacerLayout = new LayoutSpacer();
	static HLayout accountHorLayout;
	static HLayout isWorkingHorLayout;
	static VLayout header2VertLayout;
	final static AccountMenuWindow accountWindow = new AccountMenuWindow(); 
	
	public void onModuleLoad() {
		
		
		final String initToken = History.getToken();
		logoHorLayout = new HLayout();
		logoHorLayout.setHeight(60);
		Img logo = new Img("CCGlogo.gif",237,51);
		logoHorLayout.addMember(logo);
		
		//header
		headerHorLayout = new HLayout();
		headerHorLayout.setHeight(60);
		headerHorLayout.setShowResizeBar(true);
				
		accountHorLayout = new HLayout();
		accountHorLayout.addMember(new HeaderUserSection());
		header2VertLayout = new VLayout();
		header2VertLayout.setWidth(100);
		header2VertLayout.setHeight(60);
		
		header2VertLayout.addMember(accountHorLayout);
		Menu consoleMen = new Menu();
		
		MenuItem consoleItem = new MenuItem("Console");
        consoleItem.addClickHandler(new ClickHandler() {
            public void onClick(MenuItemClickEvent event) {
            	
            	SC.showConsole();
                
            }
        });
        consoleMen.setItems(consoleItem);
		header2VertLayout.setContextMenu(consoleMen);
		headerHorLayout.addMember(logoHorLayout);
		spacerLayout.setWidth(100);

		headerHorLayout.addMember(spacerLayout);
		headerHorLayout.addMember(header2VertLayout);
		
		VLayout main = new VLayout() {
            protected void onInit() {
                super.onInit();
            	
                if (initToken.length() != 0) {
                    onHistoryChanged(initToken);
                }
            }
        };
		
        main.setWidth(1900);
        main.setHeight(910);
        main.setLayoutMargin(5);
        main.setStyleName("tabSetContainer");
        
        HLayout sideNavAndWALayout = new HLayout();
        sideNavAndWALayout.setWidth100();
        sideNavAndWALayout.setHeight100();
        sideNavAndWALayout.setResizeBarSize(5);
        VLayout sideNavLayout = new VLayout();
        sideNavLayout.setHeight100();
        sideNavLayout.setWidth(240);
        sideNavLayout.setShowResizeBar(true);
        //Tree menu
        sideNav = new SideNavTree();
        sideNav.setSelectionType(SelectionStyle.NONE);

        sideNav.addLeafClickHandler(new LeafClickHandler() {
			
			@Override
			public void onLeafClick(LeafClickEvent event) {
				TreeNode node = event.getLeaf();
            	showTab(node);
				
			}
		}) ;
        
        sideNavLayout.addMember(sideNav);
        sideNavAndWALayout.addMember(sideNavLayout);

        mainTabSet = new TabSet();
        mainTabSet.setWidth100();
        mainTabSet.setHeight100();
        
        Canvas mainTabSetCanvas = new Canvas();
        mainTabSetCanvas.setWidth100();
        mainTabSetCanvas.setHeight100();
        mainTabSetCanvas.setMargin(3);
        mainTabSetCanvas.addChild(mainTabSet);

        sideNavAndWALayout.addMember(mainTabSetCanvas);
        main.setResizeBarSize(5);
        main.addMember(headerHorLayout);
        main.addMember(sideNavAndWALayout);
        main.draw();
        
        /*final Menu contextMenu = createContextMenu();
        mainTabSet.addTabContextMenuHandler(new TabContextMenuHandler() {
			
			@Override
			public void onTabContextMenu(TabContextMenuEvent event) {
			if(event.getTab()!=null){ contextMenu.showContextMenu();}
				event.cancel();
			}
		});*/
        
        /*mainTabSet.addShowContextMenuHandler(new ShowContextMenuHandler() {
            public void onShowContextMenu(ShowContextMenuEvent event) {
                int selectedTab = mainTabSet.getSelectedTabNumber();
                if (selectedTab != 0) {
                    contextMenu.showContextMenu();
                }
                event.cancel();
            }
        });
        mainTabSet.addCloseClickHandler(new CloseClickHandler() {
			
			@Override
			public void onCloseClick(TabCloseClickEvent event) {
				if(event.getTab()!=null){ 
					contextMenu.showContextMenu();
					Tab t = event.getTab();
					t.getPane().destroy();
				}
			}
		});*/
        
        
        History.addHistoryListener(this);
	} 		
	
	private void openTab(TreeNode node) {

		boolean isExplorerTreeNode = node instanceof ExplorerTreeNode;
		if (isExplorerTreeNode) {
			ExplorerTreeNode explorerTreeNode = (ExplorerTreeNode) node;
			   
			PanelFactory factory = (PanelFactory) explorerTreeNode.getFactory();
			if (factory != null) {
				String panelID = factory.getID();
				Tab tab = null;
				if (panelID != null) {
					String tabID = panelID + "_tab";
					tab = mainTabSet.getTab(tabID);
				}
				if (tab == null) { 
					
					Canvas panel = factory.create(mainTabSet,explorerTreeNode.getNodeID());
					tab = new Tab();
					tab.setID(factory.getID() + "_tab");
					String sampleName = explorerTreeNode.getName();
					
					
					String icon = explorerTreeNode.getIcon();
					//                    if (icon == null) {
					//                        icon = "silk/plugin.png";
					//                    }
					String imgHTML = Canvas.imgHTML(icon);
					String ball = new String();
					   
					tab.setTitle("<span >" +ball+ imgHTML + "&nbsp;" + sampleName + "</span>");
					tab.setPane(panel);
					
					tab.setCanClose(true);
					mainTabSet.addTab(tab);
					mainTabSet.selectTab(tab);
					if (!SC.isIE()) {
						 if (mainTabSet.getNumTabs() == 10) {
						mainTabSet.removeTabs(new int[]{1});
						}
					}
					History.newItem(explorerTreeNode.getNodeID(), false);
				} else {
					mainTabSet.selectTab(tab);
				}
			}
		}
    }
	
	public void onHistoryChanged(final String historyToken) {
	//        	ogni volta che si fa il refresh della pagina e la history del browser � cambiata,
	//        	viene richiamata la initialize().
	
		RPCManager.startQueue();
		//Privileges.initialize();
		
		RPCManager.sendQueue(new RPCQueueCallback() {
			
			@Override
			public void execute(RPCResponse[] responses) {
				if (historyToken == null || historyToken.equals("")) {
					mainTabSet.selectTab(0);
				} else {
					
					InternalRatingTreeNode[] showcaseData = sideNav.getShowcaseData();
					for (InternalRatingTreeNode ratingTreeNode : showcaseData) {
						if (ratingTreeNode.getId().equals(historyToken)) {
							openTab(ratingTreeNode);
							sideNav.selectRecord(ratingTreeNode);
							Tree tree = sideNav.getData();
							TreeNode categoryNode = tree.getParent(ratingTreeNode);
							
							while (categoryNode != null && !"/".equals(tree.getName(categoryNode))) {
								tree.openFolder(categoryNode);
								categoryNode = tree.getParent(categoryNode);
							}
						}
					}
				}	
			}
		});
	}
	
	/*private Menu createContextMenu() {
        Menu menu = new Menu();
        menu.setWidth(140);

        MenuItemIfFunction enableCondition = new MenuItemIfFunction() {
            public boolean execute(Canvas target, Menu menu, MenuItem item) {
                int selectedTab = mainTabSet.getSelectedTabNumber();
                return selectedTab != 0;
            }
        };

        MenuItem closeItem = new MenuItem("<u>C</u>lose");
        closeItem.setEnableIfCondition(enableCondition);
        closeItem.setKeyTitle("Alt+C");
        KeyIdentifier closeKey = new KeyIdentifier();
        closeKey.setAltKey(true);
        closeKey.setKeyName("C");
        closeItem.setKeys(closeKey);
        closeItem.addClickHandler(new ClickHandler() {
            public void onClick(MenuItemClickEvent event) {
                int selectedTab = mainTabSet.getSelectedTabNumber();
                mainTabSet.removeTab(selectedTab);
                mainTabSet.selectTab(selectedTab - 1);
            }
        });

        MenuItem closeAllButCurrent = new MenuItem("Close All But Current");
        closeAllButCurrent.setEnableIfCondition(enableCondition);
        closeAllButCurrent.addClickHandler(new ClickHandler() {
            public void onClick(MenuItemClickEvent event) {
                int selected = mainTabSet.getSelectedTabNumber();
                Tab[] tabs = mainTabSet.getTabs();
                int[] tabsToRemove = new int[tabs.length - 2];
                int cnt = 0;
                for (int i = 1; i < tabs.length; i++) {
                    if (i != selected) {
                        tabsToRemove[cnt] = i;
                        cnt++;
                    }
                }
                mainTabSet.removeTabs(tabsToRemove);
            }
        });

        MenuItem closeAll = new MenuItem("Close All");
        closeAll.setEnableIfCondition(enableCondition);
        closeAll.addClickHandler(new ClickHandler() {
            public void onClick(MenuItemClickEvent event) {
                Tab[] tabs = mainTabSet.getTabs();
                int[] tabsToRemove = new int[tabs.length - 1];

                for (int i = 1; i < tabs.length; i++) {
                    tabsToRemove[i - 1] = i;
                }
                mainTabSet.removeTabs(tabsToRemove);
                mainTabSet.selectTab(0);
            }
        });

        menu.setItems(closeItem, closeAllButCurrent, closeAll);
        return menu;
    }*/
	
	 public static AccountMenuWindow accountWindow(){
		   return accountWindow;
	 }
	 
	 public void addTabToTabSet(Tab t){
		 this.mainTabSet.addTab(t);
		 this.mainTabSet.selectTab(t);
	 }
    		 
	private void showTab(TreeNode node) {
	
		boolean isInternalRatingTreeNode = node instanceof InternalRatingTreeNode;
		if (isInternalRatingTreeNode) {
			InternalRatingTreeNode internalRatingTreeNode = (InternalRatingTreeNode) node;
			
			Tab tab = new Tab();
			if(mainTabSet.getTab(internalRatingTreeNode.getId()+"_tab")!=null){
                tab = mainTabSet.getTab(internalRatingTreeNode.getId()+"_tab");
				mainTabSet.selectTab(tab);
            }else{
            	Canvas appoCanvas = internalRatingTreeNode.getCreator().create();
				tab.setID(internalRatingTreeNode.getId()+"_tab");
				tab.setPane(appoCanvas);
				tab.setTitle(internalRatingTreeNode.getName());
				tab.setCanClose(true);
				addTabToTabSet(tab);
            }
		}
	}
}
