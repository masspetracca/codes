package it.ccg.irweb.server.servlet;

import it.ccg.irejb.server.bean.ImportsBeanLocal;
import it.ccg.irejb.server.logengine.LoggerFactory;
import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.CSVReader;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;

/**
 * Servlet implementation class BankImporterEndpoint
 */
public class BankImporterServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6249508878111237857L;
	
	@EJB
	private ImportsBeanLocal banksImporter;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.WEB_LOGGER);
	private static final Logger userLogger = LoggerFactory.getLogger(LoggerFactory.USER_LOGGER);
	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)	throws ServletException, IOException {
		throw new ServletException("Unsupported method");
	}
	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
		logger.debug(new StandardLogMessage("in BankImporterServlet"));
		userLogger.info(new StandardLogMessage("in BankImporterServlet"));
		
		PrintWriter out = response.getWriter();
		
		if(ServletFileUpload.isMultipartContent(request)) {

            String currentdirectory= System.getProperty("user.install.root"); 
			
			// Create a factory for disk-based file items
			FileItemFactory factory = new DiskFileItemFactory();
            
            // Create a new file upload handler
            ServletFileUpload upload = new ServletFileUpload(factory);
            
            try {
            	
				// Parse the request
				List<FileItem> itemsList = upload.parseRequest(request);
				
				// Process the uploaded items
	            for (FileItem item : itemsList) {
	            	
	                // process only file upload - discard other form item types
	                if (item.isFormField()) {
	                	
	                	continue;
	                }
	                
	                String fileName = item.getName();
	                
	                // get only the file name not whole path
                    if(fileName != null) {
                        fileName = FilenameUtils.getName(fileName);
                    }

                    logger.debug(new StandardLogMessage("SERVER FILENAME: " + fileName + "*****************************"));
                    logger.debug(new StandardLogMessage("SERVER DIR: " + currentdirectory + "/temp/" + "*****************************"));
                    
                    File serverFile = new File(currentdirectory + "/temp/" , fileName);
                    
                    /*if(serverFile.exists()) {
                    	throw new IOException("File \'" + fileName + "\' already exists.");
                    }
                    else {*/
                    	
                    	serverFile.createNewFile();
                    	logger.debug(new StandardLogMessage("AFTER CREATE: " + fileName + "*****************************"));
                    	// scrivi il file spedito da client sul file serverFile
                    	item.write(serverFile);
                    	FileReader reader = new FileReader(serverFile);
                
                    	CSVReader bankReader = new CSVReader(reader);
                    	String[][] appoImport = bankReader.parse();
                    	
                    	System.out.println("first");
                    	int insertedBanks = banksImporter.insertBankCsvValue(appoImport,(String)request.getAttribute("UPDUSR"));
                    	if (appoImport.length==insertedBanks){
                    		logger.warn(new StandardLogMessage("Import completed"));
                    		userLogger.warn(new StandardLogMessage("Import completed"));
                    		response.setStatus(HttpServletResponse.SC_OK);
                    	}else{
                    		logger.warn(new StandardLogMessage("Error during importing"));
                    		userLogger.warn(new StandardLogMessage("Error during importing"));
                    		response.setStatus(HttpServletResponse.SC_PARTIAL_CONTENT, "Inserted "+insertedBanks+" banks");
                    	}
                    	serverFile.delete();
                        
                        response.flushBuffer();
                    }
	                    	
	            }
            
	        catch(Exception e) {	
	        	ExceptionUtil.logCompleteStackTrace(logger, e);
	        	ExceptionUtil.logCompleteStackTrace(userLogger, e);
	        }

		}
	}
	
	

}
