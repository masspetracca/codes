package it.ccg.irweb.client;

import it.ccg.irweb.client.base.StandardCanvas;
import it.ccg.irweb.client.controls.StandardButton;
import it.ccg.irweb.client.controls.StandardComboBox;
import it.ccg.irweb.client.controls.StandardProfiledButton;
import it.ccg.irweb.client.elements.PopupWindow;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.SortSpecifier;
import com.smartgwt.client.rpc.RPCCallback;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.rpc.RPCRequest;
import com.smartgwt.client.rpc.RPCResponse;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.types.RowEndEditAction;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.types.TextMatchStyle;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.PrintPreviewCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.PrintCanvas;
import com.smartgwt.client.widgets.PrintWindow;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.fields.events.ChangeEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangeHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.events.FilterEditorSubmitEvent;
import com.smartgwt.client.widgets.grid.events.FilterEditorSubmitHandler;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;

public class RatingProposalCanvas extends StandardCanvas{

	int bankId;
	DataSource rctratingDS;
	DataSource rctbankDS;
	private String selectedFilter;
	ListGrid ratingProposal;
	Window riskCommWindow;
	
	@SuppressWarnings("deprecation")
	public RatingProposalCanvas(){
		super();
		
		rctratingDS = DataSource.get("rctrating");
		rctbankDS = DataSource.get("rctbank");
		
		filterCombo = new StandardComboBox("Bank");
		filterCombo.setOptionDataSource(rctbankDS);
		filterCombo.setValueField("BANKID");
		filterCombo.setDisplayField("BANKNAME");
		filterCombo.setSortField("BANKNAME");
		filterCombo.setFilterLocally(true);
		filterCombo.setAllowEmptyValue(true);
		filterCombo.setOptionOperationId("rctratingh_fetch");
		
		
		topContainerLayout.addMember(filterCombo.inDynamicForm());
		//Change handler combo
		filterCombo.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent event) {
				if (event.getValue() != null)
					selectedFilter = event.getValue().toString();
				if (event.getValue() == null) selectedFilter = null;
			}
		});
		
		//Show button
		showButton.setAlign(Alignment.CENTER);
		// Show button click handler
		showButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				showData();
			}
		});
		
		//showButton.setTooltip(ClientMessages.ttpShowBtn());
		topContainerLayout.addMember(showButton);
		//add space
		topContainerLayout.addMember(spacerLayout);
		
		refreshButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				showData();
			}
		});
		
		topContainerLayout.addMember(refreshButton);
		//
		canvasContainerLayout.addMember(topContainerLayout);
				
		ListGridField bankField = new ListGridField("BANKID");
		bankField.setOptionDataSource(rctbankDS);
		bankField.setValueField("BANKID");
		bankField.setDisplayField("BANKNAME");
		bankField.setSortByDisplayField(true);
		bankField.setSortDirection(SortDirection.ASCENDING);
		bankField.setTitle("Bank");
		bankField.setWidth("10%");
		ListGridField ratingDateField = new ListGridField("RATINGDATE");
		ratingDateField.setFilterEditorType(date); 
		ratingDateField.setEditorType(dateEdit);
		ListGridField balanceRtgField = new ListGridField("BALANCERTG");
		ListGridField spreadRtgField = new ListGridField("SPREADRTG");
		ListGridField externalRtgField = new ListGridField("EXTERNRTG");
		ListGridField approvedRtgField = new ListGridField("PROPRTG");
		ListGridField statusField = new ListGridField("STATUS");
		ListGridField commentField = new ListGridField("COMMENT");
		ListGridField noteField = new ListGridField("NOTE");
		
		ratingProposal = new ListGrid();
		ratingProposal.setWidth100();
		ratingProposal.setFields(bankField,ratingDateField,balanceRtgField,spreadRtgField,externalRtgField,approvedRtgField ,statusField,commentField ,noteField);
		ratingProposal.setTitle("Rating proposals");
		ratingProposal.setDataSource(rctratingDS);
		ratingProposal.setShowDetailFields(true);
		ratingProposal.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATE);
		ratingProposal.setShowFilterEditor(true);
		ratingProposal.setDataPageSize(40);
		ratingProposal.setModalEditing(true);
		ratingProposal.setFilterOnKeypress(false);
		ratingProposal.setListEndEditAction(RowEndEditAction.NEXT);
		ratingProposal.setAutoSaveEdits(true);
		ratingProposal.setAutoFetchData(true);
		ratingProposal.setEditEvent(ListGridEditEvent.NONE);
		ratingProposal.setAutoFetchTextMatchStyle(TextMatchStyle.SUBSTRING);
		ratingProposal.setCanGroupBy(false);
		ratingProposal.setCanFreezeFields(false);
		ratingProposal.setCanAutoFitFields(false);
		SortSpecifier ratingDateSpecifier = new SortSpecifier("RATINGDATE", SortDirection.DESCENDING);
		ratingProposal.setInitialSort(ratingDateSpecifier);
		ratingProposal.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				ratingProposal.startEditing(event.getRecordNum(), event.getFieldNum(), true);
				
			}
		});
		
		ratingProposal.addFilterEditorSubmitHandler(new FilterEditorSubmitHandler() {
			@Override
			public void onFilterEditorSubmit(FilterEditorSubmitEvent event) {
				if (event.getCriteria()!=null){
					Map critMap= event.getCriteria().getValues();
					if (critMap.containsKey("criteria")){
						String stringMap = critMap.get("criteria").toString();
						Map <String,String> map = new HashMap<String,String>();
						String[]appoStr = stringMap.split(",");
						for (String s: appoStr){
							String []appoMap = s.split("=");
							map.put(appoMap[0], appoMap[1]);
						}
						if(map.containsValue("BANKID")){
							Set<Entry<String, String>> s = map.entrySet();
							for (Entry snt : s){
								if(snt.getKey().toString().trim().equals("value")){
									selectedFilter =(String) snt.setValue(snt.getKey());
								}
							}
						}else{
							selectedFilter="";
						}
						filterCombo.setValue(selectedFilter);
						filterCombo.redraw();
					}
					/*Map<String,Object> a = event.getCriteria().getValues();
					Set<String> appSet = a.keySet();
					String appo="";
					for(String d : appSet){
						appo+=" "+d+": "+a.get(d).toString();
					}
					SC.say("appo "+appo);
					selectedFilter = event.getCriteria().getAttributeAsString("BANKID");
					filterCombo.setValue(selectedFilter);
					filterCombo.redraw();
					//event.getCriteria().addCriteria("STATUS", selectedFilter);
*/				}else{
					selectedFilter = "";
					filterCombo.setValue(selectedFilter);
					filterCombo.redraw();
				}
			}
		});
		
				
		ratingProposal.setWidth100();
		
		Criteria startCriteria = new Criteria();
		startCriteria.addCriteria("BANKID", "");
		
		ratingProposal.setInitialCriteria(startCriteria);
		
		canvasContainerLayout.addMember(ratingProposal);
		
		exportData.addClickHandler(new ClickHandler() {	
			@Override
			public void onClick(ClickEvent event) {
				DSRequest request = new DSRequest();
				request.setExportFilename("Rating proposals");
				request.setExportToClient(true);
				request.setExportValueFields(true);
				ratingProposal.exportClientData(request);
			}
		});
		
		printData.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				Img logoImg = new Img("CCGlogo.gif", 255, 51);  	
				Label label = new Label();  
		        label.setHeight(30);  
		        label.setPadding(10); 
		        label.setContents("<b>Rating proposal</b>");
		        label.setAlign(Alignment.CENTER);  
		        label.setValign(VerticalAlignment.CENTER); 
		        
		        LayoutSpacer spacer = new LayoutSpacer();
		        spacer.setWidth(10); 
		        
				Canvas.showPrintPreview(new Object[] {logoImg,label,spacer,ratingProposal}, null, "Rating proposal", new PrintPreviewCallback() {
					
					@Override
					public void execute(PrintCanvas printCanvas, PrintWindow printWindow) {
												
					}
				});
			}
		});

		StandardProfiledButton approveButton = new StandardProfiledButton("Approve");
		approveButton.setPrompt("Approve all rating");
		approveButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				riskCommWindow = PopupWindow.getInstance("Select risk committee", 600, 300);
				riskCommWindow.addCloseClickHandler(new CloseClickHandler() {
					@Override
					public void onCloseClick(CloseClickEvent event) {
						ratingProposal.fetchData();
					}
				});
				riskCommWindow.addMember(createRiskCommitteeForm());
				riskCommWindow.draw();
				
				
				
			}
		});
		
		bottomContainerLayout.addMember(approveButton);
		bottomContainerLayout.addMember(exportData);
		bottomContainerLayout.addMember(printData);
		canvasContainerLayout.addMember(bottomContainerLayout);
		
		this.addChild(canvasContainerLayout);

	}
	
	
	public void showData(){
		if (selectedFilter != null ) {
			this.bankId = Integer.parseInt(selectedFilter);
			AdvancedCriteria crit = new AdvancedCriteria();
			crit.addCriteria("BANKID", this.bankId);
			ratingProposal.fetchData(crit);
			ratingProposal.redraw();
		}else{
			AdvancedCriteria crit = new AdvancedCriteria();
			crit.addCriteria("BANKID", "");
			ratingProposal.filterData(crit);
			ratingProposal.invalidateCache();
			ratingProposal.fetchData();
			ratingProposal.redraw();
		}
	}
	
	private VLayout createRiskCommitteeForm() {
		DataSource rCDS;
		final ListGrid riskCommittees;
		
		final StandardButton saveButton = new StandardButton("Save");
		saveButton.setDisabled(true);
	    
		StandardButton cancelButton = new StandardButton("Cancel");
	        
		VLayout containerLayout = new VLayout();
    	containerLayout.setHeight100();
    	containerLayout.setWidth100();
    	containerLayout.setAlign(Alignment.CENTER);
    	containerLayout.setMembersMargin(7);

    	HLayout buttonContainer = new HLayout();
    	buttonContainer.setHeight("10%");
    	buttonContainer.setWidth100();
    	buttonContainer.setAlign(Alignment.CENTER);
    	buttonContainer.setMembersMargin(5);
    	
    	ListGridField rcCodeField = new ListGridField("RCCODE");
		//rcCodeField.setTitle("Risck committee code");
		//rcCodeField.setHidden(true);
		ListGridField rdDescField = new ListGridField("RCDESC");
		//rdDescField.setTitle("Risck committee description");
		//rdDescField.setWidth(1220);
		ListGridField rcDateField = new ListGridField("RCDATE");
		//rcDateField.setTitle("Risck committee date");
		//rcDateField.setWidth(400);
		
		rCDS = DataSource.get("rctriskcom");
		//CREO LA TABELLA 
		riskCommittees = new ListGrid();
		riskCommittees.setWidth100();
		riskCommittees.setHeight("90%");
		riskCommittees.setFields(rcCodeField,rdDescField,rcDateField);
		riskCommittees.setTitle("Risk committee");
		riskCommittees.setDataSource(rCDS);
		riskCommittees.setShowDetailFields(true);
		riskCommittees.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATE);
		riskCommittees.setShowFilterEditor(true);
		riskCommittees.setDataPageSize(40);
		riskCommittees.setFilterOnKeypress(false);
		riskCommittees.setListEndEditAction(RowEndEditAction.NEXT);
		riskCommittees.setAutoSaveEdits(false);
		riskCommittees.setAutoFetchData(true);
		riskCommittees.setCanEdit(false);
		riskCommittees.setAutoFetchTextMatchStyle(TextMatchStyle.SUBSTRING);
		riskCommittees.setModalEditing(true);
		riskCommittees.setCanGroupBy(false);
		riskCommittees.setCanFreezeFields(false);
		riskCommittees.setCanAutoFitFields(false);
		riskCommittees.addRecordClickHandler(new RecordClickHandler() {
			
			@Override
			public void onRecordClick(RecordClickEvent event) {
				saveButton.setDisabled(false);
				
			}
		});
		
		containerLayout.addMember(riskCommittees);
        
 		// Cancel row button click handler
 		cancelButton.addClickHandler(new ClickHandler() {
 			public void onClick(ClickEvent event) {
 				ratingProposal.fetchData();
 				riskCommWindow.destroy();
 				
 			}
 		});

 		// Save row button click handler
 		saveButton.addClickHandler(new ClickHandler() {
 			public void onClick(ClickEvent event) {
 				String rcCode = riskCommittees.getSelectedRecord().getAttributeAsString("RCCODE");
 				
 				RPCRequest request = new RPCRequest();
				request.setActionURL("servlet/endpoint/ApproveRatingsServlet");
				request.setHttpMethod("POST");
				Map<String,String> params = new HashMap<String,String>();
				params.put("RCCODE", rcCode);
				
				request.setParams(params);
				
				RPCManager.sendRequest(request, new RPCCallback() {
					
					@Override
					public void execute(RPCResponse response, Object rawData, RPCRequest request) {
						if (response.getStatus() == RPCResponse.STATUS_SUCCESS){
							SC.say("Parameters saved", new BooleanCallback() {
								
								@Override
								public void execute(Boolean value) {
									showData();
									riskCommWindow.destroy();
								}
							});
						}else{
							SC.warn("Error occurred");
						}
					}
				});
 			}
 		});
        
        buttonContainer.addMember(saveButton);
        buttonContainer.addMember(cancelButton);

        containerLayout.addMember(buttonContainer);
        
        return containerLayout;
	}

	public static class Creator implements it.ccg.irweb.client.utils.Creator{
		
		public Canvas create(){
			return new RatingProposalCanvas();
		}
	}
}
