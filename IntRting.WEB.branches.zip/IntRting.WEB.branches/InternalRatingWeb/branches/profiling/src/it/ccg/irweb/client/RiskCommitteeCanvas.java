package it.ccg.irweb.client;

import it.ccg.irweb.client.base.StandardCanvas;
import it.ccg.irweb.client.controls.StandardButton;
import it.ccg.irweb.client.controls.StandardProfiledButton;
import it.ccg.irweb.client.elements.PopupWindow;

import java.util.Date;

import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.SortSpecifier;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.types.RowEndEditAction;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.types.TextMatchStyle;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.PrintPreviewCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.PrintCanvas;
import com.smartgwt.client.widgets.PrintWindow;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.validator.DateRangeValidator;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.events.SelectionChangedHandler;
import com.smartgwt.client.widgets.grid.events.SelectionEvent;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;

public class RiskCommitteeCanvas extends StandardCanvas {

	StandardProfiledButton newRc;
	StandardProfiledButton editRc;
	StandardProfiledButton deleteRc;
	DataSource rCDS;
	ListGrid riskCommittees;
	Window newRiskCommitteeWindow;
	Window editRiskCommitteeWindow;
	
	public RiskCommitteeCanvas(){
		super();
		
		newRc = new StandardProfiledButton("New");
		deleteRc = new StandardProfiledButton("Delete");
		deleteRc.setDisabled(true);
		
		editRc = new StandardProfiledButton("Edit");
		editRc.setDisabled(true);

		refreshButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				showData();
			}
		});
		
		topContainerLayout.addMember(refreshButton);
		//
		canvasContainerLayout.addMember(topContainerLayout);
	
		ListGridField rcCodeField = new ListGridField("RCCODE");
		ListGridField rdDescField = new ListGridField("RCDESC");
		ListGridField rcDateField = new ListGridField("RCDATE");
		
		rCDS = DataSource.get("rctriskcom");
		//CREO LA TABELLA 
		riskCommittees = new ListGrid();
		riskCommittees.setWidth100();
		riskCommittees.setFields(rcCodeField,rdDescField,rcDateField);
		riskCommittees.setTitle("Risk committee");
		riskCommittees.setDataSource(rCDS);
		riskCommittees.setShowDetailFields(true);
		riskCommittees.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATE);
		riskCommittees.setShowFilterEditor(true);
		riskCommittees.setDataPageSize(40);
		riskCommittees.setModalEditing(true);
		riskCommittees.setFilterOnKeypress(false);
		riskCommittees.setListEndEditAction(RowEndEditAction.NEXT);
		riskCommittees.setAutoSaveEdits(true);
		riskCommittees.setAutoFetchData(true);
		riskCommittees.setEditEvent(ListGridEditEvent.NONE);
		riskCommittees.setAutoFetchTextMatchStyle(TextMatchStyle.SUBSTRING);
		riskCommittees.setCanGroupBy(false);
		riskCommittees.setCanFreezeFields(false);
		riskCommittees.setCanAutoFitFields(false);

		SortSpecifier rcDateSpecifier = new SortSpecifier("RCDATE", SortDirection.DESCENDING);
		riskCommittees.setInitialSort(rcDateSpecifier);
		riskCommittees.addSelectionChangedHandler(new SelectionChangedHandler() {
			
			@Override
			public void onSelectionChanged(SelectionEvent event) {
				deleteRc.setDisabled(false);
				editRc.setDisabled(false);
			}
		});
		
		riskCommittees.setWidth100();
		canvasContainerLayout.addMember(riskCommittees);
		
		//AGGIUNGO AZIONI AI BOTTONI
		newRc.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				newRiskCommitteeWindow = PopupWindow.getInstance("New risk committee", 620, 200);
				newRiskCommitteeWindow.addCloseClickHandler(new CloseClickHandler() {
					@Override
					public void onCloseClick(CloseClickEvent event) {
						riskCommittees.fetchData();
					}
				});
				
				newRiskCommitteeWindow.addMember(createNewRCForm());
				newRiskCommitteeWindow.draw();
			}
		});
		
		deleteRc.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if(riskCommittees.getSelectedRecord()== null){
					SC.say("No record selected");
					return;
				}else{
					riskCommittees.removeSelectedData();
					SC.warn("Record deleted");
				}
				
			}
		});	

		editRc.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if(riskCommittees.getSelectedRecord()== null){
					SC.say("No record selected");
					return;
				}else{
					editRiskCommitteeWindow = PopupWindow.getInstance("Edit risk committee", 620, 200);
					editRiskCommitteeWindow.addCloseClickHandler(new CloseClickHandler() {
						@Override
						public void onCloseClick(CloseClickEvent event) {
							riskCommittees.fetchData();
						}
					});
					editRiskCommitteeWindow.addMember(createEditRCForm());
					editRiskCommitteeWindow.draw();
				}
				
			}
		});
		
		exportData.addClickHandler(new ClickHandler() {	
			@Override
			public void onClick(ClickEvent event) {
				DSRequest request = new DSRequest();
				request.setExportFilename("Risk committees");
				request.setExportToClient(true);
				riskCommittees.exportData(request);
			}
		});
		
		printData.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				Img logoImg = new Img("CCGlogo.gif", 255, 51);  	
				Label label = new Label();  
		        label.setHeight(30);  
		        label.setPadding(10); 
		        label.setContents("<b>Risk committee</b>");
		        label.setAlign(Alignment.CENTER);  
		        label.setValign(VerticalAlignment.CENTER); 
		        
		        LayoutSpacer spacer = new LayoutSpacer();
		        spacer.setWidth(10); 
		        
				Canvas.showPrintPreview(new Object[] {logoImg,label,spacer,riskCommittees}, null, "Risk committee", new PrintPreviewCallback() {
					
					@Override
					public void execute(PrintCanvas printCanvas, PrintWindow printWindow) {
												
					}
				});
				
			}
		});
		
		bottomContainerLayout.addMember(newRc);
		bottomContainerLayout.addMember(deleteRc);
		bottomContainerLayout.addMember(editRc);

		bottomContainerLayout.addMember(exportData);
		bottomContainerLayout.addMember(printData);
		canvasContainerLayout.addMember(bottomContainerLayout);
		
		this.addChild(canvasContainerLayout);
		
	}
	
	private VLayout createNewRCForm() {
		
		DateRangeValidator dateVal = new DateRangeValidator();
		Date min = new Date(new Date().getTime()-86400000);
		dateVal.setMin(min);
		dateVal.setAttribute("exclusive", true);
		dateVal.setErrorMessage("Date cannot be older than today");
		
		VLayout containerLayout = new VLayout();
    	containerLayout.setHeight100();
    	containerLayout.setWidth100();
    	containerLayout.setAlign(Alignment.CENTER);
    	containerLayout.setMembersMargin(7);

    	HLayout buttonContainer = new HLayout();
    	buttonContainer.setHeight100();
    	buttonContainer.setWidth100();
    	buttonContainer.setAlign(Alignment.CENTER);
    	buttonContainer.setMembersMargin(3);
    	
		final DynamicForm form = new DynamicForm();
        form.setMargin(3);
        form.setHeight100();  
        form.setWidth100();  

        form.setLayoutAlign(VerticalAlignment.CENTER);  

        form.setNumCols(4);
        form.setHeight100();
        form.setDataSource(rCDS);
        form.setShowDetailFields(true);
        form.getField("RCCODE").setVisible(false);
        form.getField("RCDATE").setValidators(dateVal) ;
        form.getField("UPDDATE").setVisible(false);
        form.getField("UPDTYPE").setVisible(false);
        form.getField("UPDUSR").setVisible(false);
        
        final StandardButton saveRowButton = new StandardButton("Save");
        StandardButton cancelRowButton = new StandardButton("Cancel");
        
 		// Cancel row button click handler
 		cancelRowButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
 			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
 				form.clearValues();
 				saveRowButton.disable();
 			}
 		});

 		// Save row button click handler
 		saveRowButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
 			public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
 				if (form.validate()){
	 				riskCommittees.addData(form.getValuesAsRecord());
	 				riskCommittees.fetchData();
	 				form.reset();
	 				newRiskCommitteeWindow.destroy();
 				}else{
 					return;
 				}
 			}
 		});
        
        buttonContainer.addMember(saveRowButton);
        buttonContainer.addMember(cancelRowButton);
        
        containerLayout.addMember(form);
        containerLayout.addMember(buttonContainer);
        
        return containerLayout;
	}
	
	private VLayout createEditRCForm() {
		
		DateRangeValidator dateVal = new DateRangeValidator();
		Date min = new Date(new Date().getTime()-86400000);
		dateVal.setMin(min);
		dateVal.setAttribute("exclusive", true);
		dateVal.setErrorMessage("Date cannot be older than today");
		
		VLayout containerLayout = new VLayout();
    	containerLayout.setHeight100();
    	containerLayout.setWidth100();
    	containerLayout.setAlign(Alignment.CENTER);
    	containerLayout.setMembersMargin(7);

    	HLayout buttonContainer = new HLayout();
    	buttonContainer.setHeight100();
    	buttonContainer.setWidth100();
    	buttonContainer.setAlign(Alignment.CENTER);
    	buttonContainer.setMembersMargin(5);
    	
		final DynamicForm form = new DynamicForm();
        form.setMargin(3);
        form.setHeight100();  
        form.setWidth100();  

        form.setLayoutAlign(VerticalAlignment.CENTER);  
        form.setNumCols(4);
        form.setHeight100();
        form.setDataSource(rCDS);
        form.setShowDetailFields(true);
        form.getField("RCDESC").setCanEdit(false);
        form.getField("RCCODE").setVisible(false);
        form.getField("RCDATE").setValidators(dateVal) ;
        form.getField("UPDDATE").setVisible(false);
        form.getField("UPDTYPE").setVisible(false);
        form.getField("UPDUSR").setVisible(false);
        form.editSelectedData(riskCommittees);
        
        final StandardButton saveRowButton = new StandardButton("Save");
        StandardButton cancelRowButton = new StandardButton("Cancel");
        
 		// Cancel row button click handler
 		cancelRowButton.addClickHandler(new ClickHandler() {
 			public void onClick(ClickEvent event) {
 				editRiskCommitteeWindow.destroy();
 				
 			}
 		});

 		// Save row button click handler
 		saveRowButton.addClickHandler(new ClickHandler() {
 			public void onClick(ClickEvent event) {
 				if (form.validate()){
	 				riskCommittees.updateData(form.getValuesAsRecord());
	 				riskCommittees.fetchData();
	 				form.reset();
	 				editRiskCommitteeWindow.destroy();
 				}else{
 					return;
 				}
 			}
 		});
        
        buttonContainer.addMember(saveRowButton);
        buttonContainer.addMember(cancelRowButton);
        
        containerLayout.addMember(form);
        containerLayout.addMember(buttonContainer);
        
        return containerLayout;
	}

	public void showData(){
		riskCommittees.invalidateCache();
		riskCommittees.fetchData();
	}
	
	public static class Creator implements it.ccg.irweb.client.utils.Creator{
		
		public Canvas create(){
			return new RiskCommitteeCanvas();
		}
	}
}
