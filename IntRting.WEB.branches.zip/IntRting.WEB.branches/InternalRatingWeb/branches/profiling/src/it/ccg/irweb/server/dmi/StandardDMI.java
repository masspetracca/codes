package it.ccg.irweb.server.dmi;

import it.ccg.irejb.server.logengine.StandardLogMessage;
import it.ccg.irejb.server.util.ExceptionUtil;

import java.sql.Timestamp;
import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;


public class StandardDMI {
	String user="unknown";
	private Logger log = Logger.getLogger(it.ccg.irweb.server.dmi.StandardDMI.class.getName());
	
	//Add operation
		public DSResponse add(DSRequest dsRequest, HttpServletRequest servletRequest, HttpServletResponse httpServletResponse)throws Exception   {
			
			DSResponse dsResponse = new DSResponse();
				
			try{
				user=servletRequest.getUserPrincipal().getName();
			}
			catch(Exception e){
				ExceptionUtil.logCompleteStackTrace(log, e);
				System.out.println("Authentication failed: getting System user");
			}

			String logMessage = "User: " + user + "| OperationType: "+ dsRequest.getOperationType() + "| OperationID: "+dsRequest.getOperationId()+ "| DataSource: " + dsRequest.getDataSourceName()+ "| NewValues: " + dsRequest.getValues();

			dsRequest.setFieldValue("UPDUSR", user);
			dsRequest.setFieldValue("UPDTYPE", "C");
			dsRequest.setFieldValue("UPDDATE", systemDate());

			try{
				dsResponse = dsRequest.execute();
				
				log.info(new StandardLogMessage(logMessage));
			}
			catch(Exception e){
				ExceptionUtil.logCompleteStackTrace(log, e);
				throw(e);
			}


			return dsResponse;

		}  

		//Update operation
		public DSResponse update(DSRequest dsRequest,HttpServletRequest servletRequest, HttpServletResponse httpServletResponse)throws Exception   {  
			
			DSResponse dsResponse = new DSResponse();
			 
			try{
				user=servletRequest.getUserPrincipal().getName();
			}
			catch(Exception e){
				ExceptionUtil.logCompleteStackTrace(log, e);
				System.out.println("Authentication failed: getting System user");
			}

			String logMessage = "User: " + user + "| OperationType: "+ dsRequest.getOperationType() + "| OperationID: "+dsRequest.getOperationId()+ "| DataSource: " + dsRequest.getDataSourceName()+ "| Criteria: " +dsRequest.getCriteria() + "| NewValues: " + dsRequest.getValues() + "| OldValues: " + dsRequest.getOldValues();

			dsRequest.setFieldValue("UPDUSR", user);
			dsRequest.setFieldValue("UPDDATE", systemDate());

			//Se si tratta di update
			if(dsRequest.getFieldValue("UPDTYPE")==null||!dsRequest.getFieldValue("UPDTYPE").equals("D")){
				dsRequest.setFieldValue("UPDTYPE", "U");
				try{
					dsResponse = dsRequest.execute();

					log.info(new StandardLogMessage(logMessage + "| Rows:" + dsResponse.getAffectedRows()));
				}
				catch(Exception e){
					ExceptionUtil.logCompleteStackTrace(log, e);
					throw(e);
				}
			}
			//se si tratta di un cancellazione
			else{
				try{
					dsResponse = dsRequest.execute();	
				}
				catch(Exception e){
					ExceptionUtil.logCompleteStackTrace(log, e);
					throw(e);
				}
			}
			
			
			return dsResponse;

		}  


		//Remove operation
		public DSResponse remove(DSRequest dsRequest,HttpServletRequest servletRequest, HttpServletResponse httpServletResponse)throws Exception   { 
			
			DSResponse dsResponse = new DSResponse();
			
			try{
				user=servletRequest.getUserPrincipal().getName();
			}
			catch(Exception e){
				ExceptionUtil.logCompleteStackTrace(log, e);
				System.out.println("Authentication failed: getting System user");
			}

			String logMessage = "User: " + user + "| OperationType: "+ dsRequest.getOperationType() + "| OperationID: "+dsRequest.getOperationId()+ "| DataSource: " + dsRequest.getDataSourceName()+ "| Criteria: " +dsRequest.getCriteria() + "| OldValues: " + dsRequest.getOldValues();

			try{
				dsResponse = dsRequest.execute();
				log.info(new StandardLogMessage(logMessage + "| Rows:" + dsResponse.getAffectedRows()));
			}
			catch(Exception e){
				ExceptionUtil.logCompleteStackTrace(log, e);
				throw(e);
			}

			

			return dsResponse;

		}

		//Get System date
		public Timestamp systemDate() {
			GregorianCalendar cal = new GregorianCalendar();
			Timestamp now = new Timestamp(cal.getTimeInMillis());
			return now;
		}
}
