package it.ccg.irweb.client;

import it.ccg.irweb.client.base.StandardCanvas;
import it.ccg.irweb.client.controls.StandardProfiledButton;
import it.ccg.irweb.client.controls.StandardButton;
import it.ccg.irweb.client.controls.StandardSelectItem;
import it.ccg.irweb.client.elements.ImportBanksWindow;
import it.ccg.irweb.client.elements.PopupWindow;

import java.util.LinkedHashMap;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.data.RecordList;
import com.smartgwt.client.data.SortSpecifier;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.types.OperatorId;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.PrintPreviewCallback;
import com.smartgwt.client.util.PrintProperties;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.PrintCanvas;
import com.smartgwt.client.widgets.PrintWindow;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.events.ChangeEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangeHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.events.FilterEditorSubmitEvent;
import com.smartgwt.client.widgets.grid.events.FilterEditorSubmitHandler;
import com.smartgwt.client.widgets.grid.events.SelectionChangedHandler;
import com.smartgwt.client.widgets.grid.events.SelectionEvent;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.LayoutSpacer;
import com.smartgwt.client.widgets.layout.VLayout;

public class BankStaticDataCanvas extends StandardCanvas {
	
	StandardProfiledButton newBank;
	StandardProfiledButton deleteBank;
	StandardProfiledButton editBank;
	StandardProfiledButton importData;
	private String selectedFilter = "E";
	DataSource rctbankDS;
	ListGrid staticBanks;
	Window editBankWindow;
	Window newBankWindow;
	
	public BankStaticDataCanvas(){
		super();
		
		newBank = new StandardProfiledButton("New");
		deleteBank = new StandardProfiledButton("Delete");
		deleteBank.setDisabled(true);
		
		editBank = new StandardProfiledButton("Edit");
		editBank.setDisabled(true);
		
		//CREO IL TOP DEL CANVAS
		filterSelect = new StandardSelectItem("Calculation");
		filterSelect.setDefaultToFirstOption(true);
		filterSelect.setAllowEmptyValue(true);
		LinkedHashMap<String, String> filterMap = new LinkedHashMap<String, String>();
		filterMap.put("E", "Enabled");
		filterMap.put("D", "Disabled");
		filterSelect.setValueMap(filterMap);
		filterSelect.setAlign(Alignment.CENTER);
		topContainerLayout.addMember(filterSelect.inDynamicForm());
		//Change handler combo
		filterSelect.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent event) {
				selectedFilter = (String) event.getValue();
			}
		});

		// Show button click handler
		showButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				selectedFilter = filterSelect.getValueAsString();
				showData();
			}
		});
		//showButton.setTooltip(ClientMessages.ttpShowBtn());
		topContainerLayout.addMember(showButton);
		//add space
		topContainerLayout.addMember(spacerLayout);
				
		refreshButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				showData();
			}
		});
		
		topContainerLayout.addMember(refreshButton);
		//
		canvasContainerLayout.addMember(topContainerLayout);

		ListGridField bankIdField = new ListGridField("BANKID");		
		ListGridField bankNameField = new ListGridField("BANKNAME");
		ListGridField abiCodeField = new ListGridField("ABICODE");		
		ListGridField bloomCodeField = new ListGridField("BLOOMBCODE");
		ListGridField fitchCodeField = new ListGridField("FITCHCODE");
		ListGridField reutersTickerField = new ListGridField("RTICKER");
		ListGridField calculationField = new ListGridField("STATUS");
		ListGridField counterpartyField = new ListGridField("CTP");
		ListGridField participantField = new ListGridField("PARTICIPNT");
		ListGridField countryField = new ListGridField("COUNTRY");
		ListGridField parBnkNameField = new ListGridField("PARBNKNAME");
		ListGridField parBnkBlCdField = new ListGridField("PARBNKBLCD");
		ListGridField parBnkTickField = new ListGridField("PARBNKTICK");
		
		rctbankDS = DataSource.get("rctbank");
		//CREO LA TABELLA 
		staticBanks = new ListGrid();
		staticBanks.setID("bankStaticData");
		staticBanks.setWidth100();
		staticBanks.setFields(bankIdField,bankNameField,abiCodeField,bloomCodeField,fitchCodeField,reutersTickerField,calculationField,counterpartyField ,participantField,countryField,parBnkNameField,parBnkBlCdField,parBnkTickField);
		staticBanks.setTitle("Banks Static Data");
		staticBanks.setDataSource(rctbankDS);
		staticBanks.setDateFormatter(DateDisplayFormat.TOEUROPEANSHORTDATE);
		staticBanks.setAutoFetchData(true);
		staticBanks.setDataPageSize(40);
		staticBanks.setEditEvent(ListGridEditEvent.NONE);
		staticBanks.setShowFilterEditor(true);
		staticBanks.setCanGroupBy(false);
		staticBanks.setCanFreezeFields(false);
		staticBanks.setCanAutoFitFields(false);
		SortSpecifier bankNameSpecifier = new SortSpecifier("BANKNAME", SortDirection.ASCENDING );
		staticBanks.setInitialSort(bankNameSpecifier);
		staticBanks.addFilterEditorSubmitHandler(new FilterEditorSubmitHandler() {
			
			@Override
			public void onFilterEditorSubmit(FilterEditorSubmitEvent event) {
				if (event.getCriteria()!=null){
					selectedFilter = event.getCriteria().getAttributeAsString("STATUS");
					filterSelect.setValue(selectedFilter);
					filterSelect.redraw();
					//event.getCriteria().addCriteria("STATUS", selectedFilter);
				}else{
					selectedFilter = "";
					filterSelect.setValue(selectedFilter);
					filterSelect.redraw();
				}
			}
		});
	
		staticBanks.addSelectionChangedHandler(new SelectionChangedHandler() {
			
			@Override
			public void onSelectionChanged(SelectionEvent event) {
				deleteBank.setDisabled(false);
				editBank.setDisabled(false);
			}
		});
				
		importData = new StandardProfiledButton("Import");
		importData.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				ImportBanksWindow.windowCreator(staticBanks,"BanksImport.csv");
			}
		});
		
		//CREO IL CRITERIA PER IL PRIMO CARICAMENTO
		Criteria startCriteria = new Criteria();
		startCriteria.addCriteria("STATUS", selectedFilter);
		
		staticBanks.setInitialCriteria(startCriteria);
		staticBanks.setWidth100();
		canvasContainerLayout.addMember(staticBanks);
		
		//AGGIUNGO AZIONI AI BOTTONI
		newBank.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				newBankWindow = PopupWindow.getInstance("New bank", 600, 300);
				newBankWindow.addCloseClickHandler(new CloseClickHandler() {
					@Override
					public void onCloseClick(CloseClickEvent event) {
						staticBanks.fetchData();
					}
				});
				
				newBankWindow.addMember(createNewBankForm());
				newBankWindow.draw();
			}
		});
		
		deleteBank.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if(staticBanks.getSelectedRecord()== null){
					SC.say("No record selected");
					return;
				}else{
					staticBanks.removeSelectedData();
					SC.warn("Record deleted");
				}
				
			}
		});	

		editBank.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if(staticBanks.getSelectedRecord()== null){
					SC.say("No record selected");
					return;
				}else{
					editBankWindow = PopupWindow.getInstance("Edit bank", 600, 300);
					editBankWindow.addCloseClickHandler(new CloseClickHandler() {
						@Override
						public void onCloseClick(CloseClickEvent event) {
							staticBanks.fetchData();
						}
					});
					editBankWindow.addMember(createEditBankForm());
					editBankWindow.draw();
				}
				
			}
		});
		
		exportData.addClickHandler(new ClickHandler() {	
			@Override
			public void onClick(ClickEvent event) {
				DSRequest request = new DSRequest();
				request.setExportFilename("Bank static data");
				request.setExportToClient(true);
				staticBanks.exportData(request);
			}
		});
		
		printData.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				PrintProperties printProp = new PrintProperties();
				printProp.setAttribute("Orientation", "Landscape");
				
				Img logoImg = new Img("CCGlogo.gif", 255, 51);  	
				Label label = new Label();  
		        label.setHeight(30);  
		        label.setPadding(10); 
		        label.setContents("<b>Bank static data</b>");
		        label.setAlign(Alignment.CENTER);  
		        label.setValign(VerticalAlignment.CENTER); 
		        
		        LayoutSpacer spacer = new LayoutSpacer();
		        spacer.setWidth(10); 
		        
				Canvas.showPrintPreview(new Object[] {logoImg,label,spacer,staticBanks}, printProp, "Bank static data", new PrintPreviewCallback() {
					
					@Override
					public void execute(PrintCanvas printCanvas, PrintWindow printWindow) {
												
					}
				});
				
			}
		});
		
		bottomContainerLayout.addMember(newBank);
		bottomContainerLayout.addMember(deleteBank);
		bottomContainerLayout.addMember(editBank);
		bottomContainerLayout.addMember(importData);
		bottomContainerLayout.addMember(exportData);
		bottomContainerLayout.addMember(printData);
		canvasContainerLayout.addMember(bottomContainerLayout);
		
		this.addChild(canvasContainerLayout);
	}
	
	private VLayout createNewBankForm() {
		
		
		VLayout containerLayout = new VLayout();
    	containerLayout.setHeight100();
    	containerLayout.setWidth100();
    	containerLayout.setAlign(Alignment.CENTER);
    	containerLayout.setMembersMargin(7);

    	HLayout buttonContainer = new HLayout();
    	buttonContainer.setHeight100();
    	buttonContainer.setWidth100();
    	buttonContainer.setAlign(Alignment.CENTER);
    	buttonContainer.setMembersMargin(5);

		final DynamicForm form = new DynamicForm();
        form.setMargin(5);
        form.setHeight100();  
        form.setWidth100();  

        form.setLayoutAlign(VerticalAlignment.CENTER);  
        try{
        form.setNumCols(4);
        form.setHeight100();
        form.setDataSource(rctbankDS);
        form.setShowDetailFields(true);
        form.getField("BANKID").setVisible(false);
        form.getField("UPDDATE").setVisible(false);
        form.getField("UPDTYPE").setVisible(false);
        form.getField("UPDUSR").setVisible(false);
        
        
		}catch(Exception e){
			SC.say(e.getMessage());
			return null;
		}
		final StandardButton saveRowButton = new StandardButton("Save");
        StandardButton cancelRowButton = new StandardButton("Cancel");
 		// Cancel row button click handler
 		cancelRowButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
 			public void onClick(ClickEvent event) {
 				form.clearValues();
 				saveRowButton.disable();
 			}
 		});

 		// Save row button click handler
 		saveRowButton.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
 			public void onClick(ClickEvent event) {
 				
 				if (form.validate()){
 					if (!(form.getField("BLOOMBCODE"). getValue()==null && form.getField("FITCHCODE").getValue()==null)){
		 				DataSource ds = staticBanks.getDataSource();
		 				Criteria c = new Criteria ();
		 				ds.fetchData(c, new DSCallback() {
							
							@Override
							public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
								RecordList result = dsResponse.getDataAsRecordList();
								Record nameRecord = result.find("BANKNAME", (String) form.getField("BANKNAME").getValue());
								boolean present = false;
								if (nameRecord==null){
									if (form.getField("BLOOMBCODE").getValue()!=null){
										Record bloomRecord = result.find("BLOOMBCODE", (String)form.getField("BLOOMBCODE").getValue());
										if (bloomRecord!=null){
											present = true;
										}
									}
									
									if (form.getField("FITCHCODE").getValue()!=null && !present){
										Record fitchRecord = result.find("FITCHCODE", (Integer)form.getField("FITCHCODE").getValue());
										if (fitchRecord!=null){
											present = true;
										}
									}
								}else{
									present = true;
								}
								
								if(present){
									SC.warn("Already exsists data with this attributes");
									return;
								}else{
									staticBanks.addData(form.getValuesAsRecord());
					 				//staticBanks.fetchData();
									showData();
					 				form.reset();
					 				newBankWindow.destroy();
								}
							}
						});
 					}else{
 						SC.warn("Bloomberg code or fitch code are required. Please insert one of them.");
 						return;
 					}
 					
 				}else{
 					return;
 				}
 			}
 		});
        
        buttonContainer.addMember(saveRowButton);
        buttonContainer.addMember(cancelRowButton);
        
        containerLayout.addMember(form);
        containerLayout.addMember(buttonContainer);
        
        return containerLayout;
		
	}
	
	private VLayout createEditBankForm() {
		
		VLayout containerLayout = new VLayout();
    	containerLayout.setHeight100();
    	containerLayout.setWidth100();
    	containerLayout.setAlign(Alignment.CENTER);
    	containerLayout.setMembersMargin(7);

    	HLayout buttonContainer = new HLayout();
    	buttonContainer.setHeight100();
    	buttonContainer.setWidth100();
    	buttonContainer.setAlign(Alignment.CENTER);
    	buttonContainer.setMembersMargin(5);
    	
		final DynamicForm form = new DynamicForm();
        form.setMargin(5);
        form.setHeight100();  
        form.setWidth100();  

        form.setLayoutAlign(VerticalAlignment.CENTER);  
        form.setNumCols(4);
        form.setHeight100();
        form.setDataSource(rctbankDS);
        form.setShowDetailFields(true);
        form.getField("BANKNAME").setCanEdit(false);
        form.getField("BANKID").setVisible(false);
        form.getField("UPDDATE").setVisible(false);
        form.getField("UPDTYPE").setVisible(false);
        form.getField("UPDUSR").setVisible(false);
        form.editSelectedData(staticBanks);
        
        final StandardButton saveRowButton = new StandardButton("Save");
        StandardButton cancelRowButton = new StandardButton("Cancel");
        
 		// Cancel row button click handler
 		cancelRowButton.addClickHandler(new ClickHandler() {
 			public void onClick(ClickEvent event) {
 				form.clearValues();
 				editBankWindow.destroy();
 			}
 		});

 		// Save row button click handler
 		saveRowButton.addClickHandler(new ClickHandler() {
 			public void onClick(ClickEvent event) {
 				if (form.validate()){
 					if (!(form.getField("BLOOMBCODE").getValue()==null && form.getField("FITCHCODE").getValue()==null)){
		 				DataSource ds = staticBanks.getDataSource();
		 				Criteria c = new Criteria ();
		 				ds.fetchData(c, new DSCallback() {

							@Override
							public void execute(DSResponse dsResponse, Object data, DSRequest dsRequest) {
								RecordList result = dsResponse.getDataAsRecordList();
								/*AdvancedCriteria bNAd = new AdvancedCriteria(OperatorId.AND);
								bNAd.addCriteria("BANKNAME", OperatorId.EQUALS, (Integer)form.getField("BANKNAME").getValue());
								bNAd.addCriteria("BANKID", OperatorId.NOT_EQUAL, (Integer)form.getField("BANKID").getValue());
								
								Record nameRecord = result.find(bNAd);*/
								boolean present = false;
								if (form.getField("BLOOMBCODE").getValue()!=null){
									AdvancedCriteria ad = new AdvancedCriteria(OperatorId.AND);
									ad.addCriteria("BLOOMBCODE", OperatorId.EQUALS, (String) form.getField("BLOOMBCODE").getValue());
									ad.addCriteria("BANKID", OperatorId.NOT_EQUAL, (Integer)form.getField("BANKID").getValue());

									Record bloomRecord = result.find(ad);
									if (bloomRecord!=null){
										present = true;
									}
								}
								
								if (form.getField("FITCHCODE").getValue()!=null && !present){
								
									AdvancedCriteria ad = new AdvancedCriteria(OperatorId.AND);
									ad.addCriteria("FITCHCODE", OperatorId.EQUALS, (Integer)form.getField("FITCHCODE").getValue());
									ad.addCriteria("BANKID", OperatorId.NOT_EQUAL, (Integer)form.getField("BANKID").getValue());
									
									Record fitchRecord = result.find(ad);
									if (fitchRecord!=null){
										present = true;
									}
								}
								
								if(present){
									SC.warn("Already exsists data with this attributes");
									return;
								}else{
									staticBanks.updateData(form.getValuesAsRecord());
					 				//staticBanks.fetchData();
									showData();
					 				
					 				form.reset();
					 				editBankWindow.destroy();
								}
							}
						});
 					}else{
 						SC.warn("Bloomberg code or fitch code are required. Please insert one of them.");
 						return;
 					}
 					
 				}else{
 					return;
 				}
 				/*--------------
 				if (form.validate()){
	 				staticBanks.updateData(form.getValuesAsRecord());
	 				staticBanks.fetchData();
	 				form.reset();
	 				editBankWindow.destroy();
 				}else{
 					return;
 				}*/
 			}
 		});
        
        buttonContainer.addMember(saveRowButton);
        buttonContainer.addMember(cancelRowButton);
        
        containerLayout.addMember(form);
        containerLayout.addMember(buttonContainer);
        
        return containerLayout;
	}

	public void showData(){
		if (selectedFilter != null && !selectedFilter.equalsIgnoreCase("")) {
			Criteria crit = new Criteria();
			crit.addCriteria("STATUS", selectedFilter);
			staticBanks.fetchData(crit);
		} else {
			Criteria crit = new Criteria();
			crit.addCriteria("STATUS", "");
			staticBanks.fetchData(crit);
		}
	}

	public static class Creator implements it.ccg.irweb.client.utils.Creator{
		
		public Canvas create(){
			return new BankStaticDataCanvas();
		}
	}
}

