/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd.dto;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.SimpleFormatter;

public class IfptBndDtDTO {
	
	//BLOOMCODE VARCHAR(12) CCSID 280,
	private String bloomcode;
	//BULLET CHAR(1) CCSID 280,
	private Boolean bullet;
	//CALL_TYP VARCHAR(180) CCSID 280,
	private String callType;
	//IS_CERTIF CHAR(1) CCSID 280 NOT NULL,
	private Boolean certificated;
	//CNTRY_RISK VARCHAR(4) CCSID 280,
	private String cntryOfRisk;
	//CPN DECIMAL(25,8),
	private BigDecimal cpn;
	//CPN_FREQ INTEGER(24) CCSID 280,
	private Integer cpnFreq;
	//CPN_TYP VARCHAR(24) CCSID 280,
	private String cpnTyp;
	//CRNCY VARCHAR(8) CCSID 280 NOT NULL,
	private String crncy;
	//DAY_TO_ST INTEGER,
	private Integer dayToSettle;
	//DES_NOTES VARCHAR(1120) CCSID 280,
	private String desNote;
	//DUAL_CRCY CHAR(1) CCSID 280 NOT NULL,
	private Boolean dualCrncy;
	//EXTENDIBLE CHAR(1) CCSID 280 NOT NULL,
	private Boolean extendible;
	//FINAL_MAT INTEGER NOT NULL,
	private Integer finalMaturity;
	//INF_LNK_IN CHAR(1) CCSID 280,
	private Boolean inflationLinkedIndicator;
	//ISINCODE VARCHAR(12) CCSID 280 NOT NULL,
	private String isinCode;
	//ISSUER VARCHAR(30) CCSID 280 NOT NULL,
	private String issuer;
	//ISSR_IND VARCHAR(30) CCSID 280,
	private String issuerIndustry;
	//LNK_BND_IN CHAR(1) CCSID 280,
	private Boolean linkedBondInd;
	//LNK_BNDINF VARCHAR(30) CCSID 280,
	private String linkedBondInfo;
	//MKTSECT VARCHAR(8) CCSID 280 NOT NULL,
	private String marketSectorDes;
	//MATURITY INTEGER NOT NULL,
	private Integer maturity;
	//REPFAC DECIMAL(25,8) NOT NULL,
	private BigDecimal mostRecentReportedFactor;
	//MTY_TYP VARCHAR(18) CCSID 280 NOT NULL,
	private String mtyTyp;
	//PAR_AMT DECIMAL(25,8),
	private BigDecimal parAmt;
	//PCT_PAR_QU CHAR(1) CCSID 280,
	private Boolean pctParQuoted;
	//IS_PERPET CHAR(1) CCSID 280 NOT NULL,
	private Boolean perpetual;
	//PR_RT_SINK CHAR(1) CCSID 280,
	private Boolean proRataSink;
	//PX_CLOSEDT INTEGER NOT NULL,
	private Integer pxCloseDt;
	//PX_LAST DECIMAL(25,8),
	private BigDecimal pxLast;
	//REDEM_CRNCY VARCHAR(8) CCSID 280 NOT NULL,
	private String redempCrncy;
	//REDEMP_VAL DECIMAL(25,8),
	private BigDecimal redempVal;
	//REQUESTID VARCHAR(40) CCSID 280 NOT NULL,
	private String requestId;
	//RESET_IDX VARCHAR(15) CCSID 280,
	private String resetIdx;
	//SEC_DES VARCHAR(30) CCSID 280 NOT NULL,
	private String securityDes;
	//SEC_FACT CHAR(1) CCSID 280 NOT NULL,
	private Boolean securityFactorable;
	//SINK_SC_TY VARCHAR(50) CCSID 280 NOT NULL,
	private String sinkScheduleAmtTyp;
	//ST_ACC_DT INTEGER NOT NULL,
	private Integer startAccDt;
	//STRUCT_NOT CHAR(1) CCSID 280 NOT NULL,
	private Boolean structuredNote;
	//UND_SEC_DE VARCHAR(30) CCSID 280,
	private String underlyingSecurityDes;
	//UPDDATE TIMESTAMP NOT NULL,
	private Timestamp updDate;
	//UPDTYPE CHAR(1) CCSID 280 NOT NULL DEFAULT 'C',
	private String updType;
	//UPDUSR VARCHAR(30) CCSID 280 NOT NULL DEFAULT 'SYSTEM'
	private String updUsr;
	
	private Boolean ttpbond;
	//flag and alert
	private Boolean tflcurdub;
	private Boolean tflcurliq;
	private Boolean tflcurneg;
	private Boolean tflgper;
	private Boolean tflgest;
	private Boolean tflamort;
	private Boolean tflgacct;
	private Boolean tflstruc;
	
	
	/**
	 * @return the ttpbond
	 */
	public Boolean getTtpbond() {
		return ttpbond;
	}
	/**
	 * @param ttpbond the ttpbond to set
	 */
	public void setTtpbond(Boolean ttpbond) {
		this.ttpbond = ttpbond;
	}
	/**
	 * @return the bloomcode
	 */
	public String getBloomcode() {
		return bloomcode;
	}
	/**
	 * @param bloomcode the bloomcode to set
	 */
	public void setBloomcode(String bloomcode) {
		this.bloomcode = bloomcode;
	}
	/**
	 * @return the bullet
	 */
	public Boolean getBullet() {
		return bullet;
	}
	/**
	 * @param bullet the bullet to set
	 */
	public void setBullet(Boolean bullet) {
		this.bullet = bullet;
	}
	/**
	 * @return the callType
	 */
	public String getCallType() {
		return callType;
	}
	/**
	 * @param callType the callType to set
	 */
	public void setCallType(String callType) {
		this.callType = callType;
	}
	/**
	 * @return the certificated
	 */
	public Boolean getCertificated() {
		return certificated;
	}
	/**
	 * @param certificated the certificated to set
	 */
	public void setCertificated(Boolean certificated) {
		this.certificated = certificated;
	}
	/**
	 * @return the cntryOfRisk
	 */
	public String getCntryOfRisk() {
		return cntryOfRisk;
	}
	/**
	 * @param cntryOfRisk the cntryOfRisk to set
	 */
	public void setCntryOfRisk(String cntryOfRisk) {
		this.cntryOfRisk = cntryOfRisk;
	}
	/**
	 * @return the cpn
	 */
	public BigDecimal getCpn() {
		return cpn;
	}
	/**
	 * @param cpn the cpn to set
	 */
	public void setCpn(BigDecimal cpn) {
		this.cpn = cpn;
	}
	/**
	 * @return the cpnFreq
	 */
	public Integer getCpnFreq() {
		return cpnFreq;
	}
	/**
	 * @param cpnFreq the cpnFreq to set
	 */
	public void setCpnFreq(Integer cpnFreq) {
		this.cpnFreq = cpnFreq;
	}
	/**
	 * @return the cpnTyp
	 */
	public String getCpnTyp() {
		return cpnTyp;
	}
	/**
	 * @param cpnTyp the cpnTyp to set
	 */
	public void setCpnTyp(String cpnTyp) {
		this.cpnTyp = cpnTyp;
	}
	/**
	 * @return the crncy
	 */
	public String getCrncy() {
		return crncy;
	}
	/**
	 * @param crncy the crncy to set
	 */
	public void setCrncy(String crncy) {
		this.crncy = crncy;
	}
	/**
	 * @return the dayToSettle
	 */
	public Integer getDayToSettle() {
		return dayToSettle;
	}
	/**
	 * @param dayToSettle the dayToSettle to set
	 */
	public void setDayToSettle(Integer dayToSettle) {
		this.dayToSettle = dayToSettle;
	}
	/**
	 * @return the desNote
	 */
	public String getDesNote() {
		return desNote;
	}
	/**
	 * @param desNote the desNote to set
	 */
	public void setDesNote(String desNote) {
		this.desNote = desNote;
	}
	/**
	 * @return the dualCrncy
	 */
	public Boolean getDualCrncy() {
		return dualCrncy;
	}
	/**
	 * @param dualCrncy the dualCrncy to set
	 */
	public void setDualCrncy(Boolean dualCrncy) {
		this.dualCrncy = dualCrncy;
	}
	/**
	 * @return the extendible
	 */
	public Boolean getExtendible() {
		return extendible;
	}
	/**
	 * @param extendible the extendible to set
	 */
	public void setExtendible(Boolean extendible) {
		this.extendible = extendible;
	}
	/**
	 * @return the finalMaturity
	 */
	public Integer getFinalMaturity() {
		return finalMaturity;
	}
	/**
	 * @param finalMaturity the finalMaturity to set
	 */
	public void setFinalMaturity(Integer finalMaturity) {
		this.finalMaturity = finalMaturity;
	}
	/**
	 * @return the inflationLinkedIndicator
	 */
	public Boolean getInflationLinkedIndicator() {
		return inflationLinkedIndicator;
	}
	/**
	 * @param inflationLinkedIndicator the inflationLinkedIndicator to set
	 */
	public void setInflationLinkedIndicator(Boolean inflationLinkedIndicator) {
		this.inflationLinkedIndicator = inflationLinkedIndicator;
	}
	/**
	 * @return the isinCode
	 */
	public String getIsinCode() {
		return isinCode;
	}
	/**
	 * @param isinCode the isinCode to set
	 */
	public void setIsinCode(String isinCode) {
		this.isinCode = isinCode;
	}
	/**
	 * @return the issuer
	 */
	public String getIssuer() {
		return issuer;
	}
	/**
	 * @param issuer the issuer to set
	 */
	public void setIssuer(String issuer) {
		this.issuer = issuer;
	}
	/**
	 * @return the issuerIndustry
	 */
	public String getIssuerIndustry() {
		return issuerIndustry;
	}
	/**
	 * @param issuerIndustry the issuerIndustry to set
	 */
	public void setIssuerIndustry(String issuerIndustry) {
		this.issuerIndustry = issuerIndustry;
	}
	/**
	 * @return the linkedBondInd
	 */
	public Boolean getLinkedBondInd() {
		return linkedBondInd;
	}
	/**
	 * @param linkedBondInd the linkedBondInd to set
	 */
	public void setLinkedBondInd(Boolean linkedBondInd) {
		this.linkedBondInd = linkedBondInd;
	}
	/**
	 * @return the linkedBondInfo
	 */
	public String getLinkedBondInfo() {
		return linkedBondInfo;
	}
	/**
	 * @param linkedBondInfo the linkedBondInfo to set
	 */
	public void setLinkedBondInfo(String linkedBondInfo) {
		this.linkedBondInfo = linkedBondInfo;
	}
	/**
	 * @return the marketSectorDes
	 */
	public String getMarketSectorDes() {
		return marketSectorDes;
	}
	/**
	 * @param marketSectorDes the marketSectorDes to set
	 */
	public void setMarketSectorDes(String marketSectorDes) {
		this.marketSectorDes = marketSectorDes;
	}
	/**
	 * @return the maturity
	 */
	public Integer getMaturity() {
		return maturity;
	}
	/**
	 * @param maturity the maturity to set
	 */
	public void setMaturity(Integer maturity) {
		this.maturity = maturity;
	}
	/**
	 * @return the mostRecentReportedFactor
	 */
	public BigDecimal getMostRecentReportedFactor() {
		return mostRecentReportedFactor;
	}
	/**
	 * @param mostRecentReportedFactor the mostRecentReportedFactor to set
	 */
	public void setMostRecentReportedFactor(BigDecimal mostRecentReportedFactor) {
		this.mostRecentReportedFactor = mostRecentReportedFactor;
	}
	/**
	 * @return the mtyTyp
	 */
	public String getMtyTyp() {
		return mtyTyp;
	}
	/**
	 * @param mtyTyp the mtyTyp to set
	 */
	public void setMtyTyp(String mtyTyp) {
		this.mtyTyp = mtyTyp;
	}
	/**
	 * @return the parAmt
	 */
	public BigDecimal getParAmt() {
		return parAmt;
	}
	/**
	 * @param parAmt the parAmt to set
	 */
	public void setParAmt(BigDecimal parAmt) {
		this.parAmt = parAmt;
	}
	/**
	 * @return the pctParQuoted
	 */
	public Boolean getPctParQuoted() {
		return pctParQuoted;
	}
	/**
	 * @param pctParQuoted the pctParQuoted to set
	 */
	public void setPctParQuoted(Boolean pctParQuoted) {
		this.pctParQuoted = pctParQuoted;
	}
	/**
	 * @return the perpetual
	 */
	public Boolean getPerpetual() {
		return perpetual;
	}
	/**
	 * @param perpetual the perpetual to set
	 */
	public void setPerpetual(Boolean perpetual) {
		this.perpetual = perpetual;
	}
	/**
	 * @return the proRataSink
	 */
	public Boolean getProRataSink() {
		return proRataSink;
	}
	/**
	 * @param proRataSink the proRataSink to set
	 */
	public void setProRataSink(Boolean proRataSink) {
		this.proRataSink = proRataSink;
	}
	/**
	 * @return the pxCloseDt
	 */
	public Integer getPxCloseDt() {
		return pxCloseDt;
	}
	/**
	 * @param pxCloseDt the pxCloseDt to set
	 */
	public void setPxCloseDt(Integer pxCloseDt) {
		this.pxCloseDt = pxCloseDt;
	}
	/**
	 * @return the pxLast
	 */
	public BigDecimal getPxLast() {
		return pxLast;
	}
	/**
	 * @param pxLast the pxLast to set
	 */
	public void setPxLast(BigDecimal pxLast) {
		this.pxLast = pxLast;
	}
	/**
	 * @return the redempCrncy
	 */
	public String getRedempCrncy() {
		return redempCrncy;
	}
	/**
	 * @param redempCrncy the redempCrncy to set
	 */
	public void setRedempCrncy(String redempCrncy) {
		this.redempCrncy = redempCrncy;
	}
	/**
	 * @return the redempVal
	 */
	public BigDecimal getRedempVal() {
		return redempVal;
	}
	/**
	 * @param redempVal the redempVal to set
	 */
	public void setRedempVal(BigDecimal redempVal) {
		this.redempVal = redempVal;
	}
	/**
	 * @return the requestId
	 */
	public String getRequestId() {
		return requestId;
	}
	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	/**
	 * @return the resetIdx
	 */
	public String getResetIdx() {
		return resetIdx;
	}
	/**
	 * @param resetIdx the resetIdx to set
	 */
	public void setResetIdx(String resetIdx) {
		this.resetIdx = resetIdx;
	}
	/**
	 * @return the securityDes
	 */
	public String getSecurityDes() {
		return securityDes;
	}
	/**
	 * @param securityDes the securityDes to set
	 */
	public void setSecurityDes(String securityDes) {
		this.securityDes = securityDes;
	}
	/**
	 * @return the securityFactorable
	 */
	public Boolean getSecurityFactorable() {
		return securityFactorable;
	}
	/**
	 * @param securityFactorable the securityFactorable to set
	 */
	public void setSecurityFactorable(Boolean securityFactorable) {
		this.securityFactorable = securityFactorable;
	}
	/**
	 * @return the sinkScheduleAmtTyp
	 */
	public String getSinkScheduleAmtTyp() {
		return sinkScheduleAmtTyp;
	}
	/**
	 * @param sinkScheduleAmtTyp the sinkScheduleAmtTyp to set
	 */
	public void setSinkScheduleAmtTyp(String sinkScheduleAmtTyp) {
		this.sinkScheduleAmtTyp = sinkScheduleAmtTyp;
	}
	/**
	 * @return the startAccDt
	 */
	public Integer getStartAccDt() {
		return startAccDt;
	}
	/**
	 * @param startAccDt the startAccDt to set
	 */
	public void setStartAccDt(Integer startAccDt) {
		this.startAccDt = startAccDt;
	}
	/**
	 * @return the structuredNote
	 */
	public Boolean getStructuredNote() {
		return structuredNote;
	}
	/**
	 * @param structuredNote the structuredNote to set
	 */
	public void setStructuredNote(Boolean structuredNote) {
		this.structuredNote = structuredNote;
	}
	/**
	 * @return the underlyingSecurityDes
	 */
	public String getUnderlyingSecurityDes() {
		return underlyingSecurityDes;
	}
	/**
	 * @param underlyingSecurityDes the underlyingSecurityDes to set
	 */
	public void setUnderlyingSecurityDes(String underlyingSecurityDes) {
		this.underlyingSecurityDes = underlyingSecurityDes;
	}
	/**
	 * @return the updDate
	 */
	public Timestamp getUpdDate() {
		return updDate;
	}
	/**
	 * @param updDate the updDate to set
	 */
	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}
	/**
	 * @return the updType
	 */
	public String getUpdType() {
		return updType;
	}
	/**
	 * @param updType the updType to set
	 */
	public void setUpdType(String updType) {
		this.updType = updType;
	}
	/**
	 * @return the tflcurdub
	 */
	public Boolean getTflcurdub() {
		return tflcurdub;
	}
	/**
	 * @param tflcurdub the tflcurdub to set
	 */
	public void setTflcurdub(Boolean tflcurdub) {
		this.tflcurdub = tflcurdub;
	}
	/**
	 * @return the tflcurliq
	 */
	public Boolean getTflcurliq() {
		return tflcurliq;
	}
	/**
	 * @param tflcurliq the tflcurliq to set
	 */
	public void setTflcurliq(Boolean tflcurliq) {
		this.tflcurliq = tflcurliq;
	}
	/**
	 * @return the tflcurneg
	 */
	public Boolean getTflcurneg() {
		return tflcurneg;
	}
	/**
	 * @param tflcurneg the tflcurneg to set
	 */
	public void setTflcurneg(Boolean tflcurneg) {
		this.tflcurneg = tflcurneg;
	}
	/**
	 * @return the tflgper
	 */
	public Boolean getTflgper() {
		return tflgper;
	}
	/**
	 * @param tflgper the tflgper to set
	 */
	public void setTflgper(Boolean tflgper) {
		this.tflgper = tflgper;
	}
	/**
	 * @return the tflgest
	 */
	public Boolean getTflgest() {
		return tflgest;
	}
	/**
	 * @param tflgest the tflgest to set
	 */
	public void setTflgest(Boolean tflgest) {
		this.tflgest = tflgest;
	}
	/**
	 * @return the tflamort
	 */
	public Boolean getTflamort() {
		return tflamort;
	}
	/**
	 * @param tflamort the tflamort to set
	 */
	public void setTflamort(Boolean tflamort) {
		this.tflamort = tflamort;
	}
	/**
	 * @return the tflgacct
	 */
	public Boolean getTflgacct() {
		return tflgacct;
	}
	/**
	 * @param tflgacct the tflgacct to set
	 */
	public void setTflgacct(Boolean tflgacct) {
		this.tflgacct = tflgacct;
	}
	/**
	 * @return the tflstruc
	 */
	public Boolean getTflstruc() {
		return tflstruc;
	}
	/**
	 * @param tflstruc the tflstruc to set
	 */
	public void setTflstruc(Boolean tflstruc) {
		this.tflstruc = tflstruc;
	}
	/**
	 * @return the updUsr
	 */
	public String getUpdUsr() {
		return updUsr;
	}
	/**
	 * @param updUsr the updUsr to set
	 */
	public void setUpdUsr(String updUsr) {
		this.updUsr = updUsr;
	}
	
	public void copyProperties(CsdFtp00fDTO dest){
		Date elabDt = new Date();
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		DateFormat tf = new SimpleDateFormat("HHmmss");
		
		dest.setTcodemi("");
		dest.setTcurrlq(this.redempCrncy);
		dest.setTcurrne(this.getCrncy());
		dest.setTdesc(this.getSecurityDes());
		dest.setTdesemi(this.getIssuer());
		
		dest.setTdtael(new BigDecimal(df.format(elabDt)));
		dest.setTdtaem(new BigDecimal(this.getStartAccDt()));
		dest.setTdtaexp(new BigDecimal(this.getMaturity()));
		dest.setTdtaexpu(new BigDecimal(this.getFinalMaturity()));
		dest.setTdtain(new BigDecimal(df.format(elabDt)));
		dest.setTexch(new BigDecimal(0));
		dest.setTflgel("");
		dest.setTinfbloo("N");
		dest.setTorael(new BigDecimal(tf.format(elabDt)));
		dest.setTpcert(this.getCertificated()?"Y":"N");
		dest.setTprog("");
		dest.setTpsemit(this.getCntryOfRisk());
		dest.setTscaext(this.getExtendible()?"Y":"N");
		dest.setTscaper(this.getPerpetual()?"Y":"N");
		
		dest.setTtpmat(this.getMtyTyp());
		dest.setTtpstr(this.getMarketSectorDes());
		dest.setTuser("");
		dest.setTuserin("");
		
		//flag and alert
		dest.setTtpbond(this.getTtpbond()?"Y":"N");
		dest.setTflcurdub(this.getTflcurdub()?"Y":"N");
		dest.setTflcurliq(this.getTflcurliq()?"Y":"N");
		dest.setTflcurneg(this.getTflcurneg()?"Y":"N");
		dest.setTflgper(this.getTflgper()?"Y":"N");
		dest.setTflgest(this.getTflgest()?"Y":"N");
		dest.setTflamort(this.getTflamort()?"Y":"N");
		dest.setTflgacct(this.getTflgacct()?"Y":"N");
		dest.setTflstruc(this.getTflstruc()?"Y":"N");
		
		
	}
}
