/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd.dto;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the CSDFTP00F database table.
 * 
 */
public class CsdFtp00fDTO {
	//from external env
	private String csdamort;
	private String csdcurse;
	private String csdcurtr;
	private BigDecimal csddata;
	private String csddescr;
	private BigDecimal csddtemi;
	private BigDecimal csddtneg;
	private BigDecimal csddtsca;
	private String csdesccp;
	private String csdesten;
	private BigDecimal csdfrequ;
	private String csdisin;
	private String csdmkt;
	private String csdnazio;
	private BigDecimal csdnextq;
	private BigDecimal csdora;
	private BigDecimal csdperce;
	private String csdperpe;
	private BigDecimal csdpoolf;
	private BigDecimal csdprog;
	private String csdrifiu;
	private String csdsettl;
	private String csdstrut;
	private String csdtela;
	private String csdtipo;
	private String csdtpstr;
	private String csdtsost;
	
	// from bloomberg
	private String tcodemi;
	private String tcurrlq;
	private String tcurrne;
	private String tdesc;
	private String tdesemi;
	private BigDecimal tdtablo;
	private BigDecimal tdtael;
	private BigDecimal tdtaem;
	private BigDecimal tdtaexp;
	private BigDecimal tdtaexpu;
	private BigDecimal tdtain;
	private BigDecimal texch;
	private String tflgel;
	private String tinfbloo;
	private BigDecimal torael;
	private String tpcert;
	private String tprog;
	private String tpsemit;
	private String tscaext;
	private String tscaper;
	private BigDecimal ttimeblo;
	private String ttpbond;
	private String ttpmat;
	private String ttpstr;
	private String tuser;
	private String tuserin;
	
	//flag and alert
	private String tflcurdub;
	private String tflcurliq;
	private String tflcurneg;
	private String tflgper;
	private String tflgest;
	private String tflamort;
	private String tflgacct;
	private String tflstruc;
	
	
    public CsdFtp00fDTO() {
    }

	public String getCsdamort() {
		return this.csdamort;
	}

	public void setCsdamort(String csdamort) {
		this.csdamort = csdamort;
	}

	public String getCsdcurse() {
		return this.csdcurse;
	}

	public void setCsdcurse(String csdcurse) {
		this.csdcurse = csdcurse;
	}

	public String getCsdcurtr() {
		return this.csdcurtr;
	}

	public void setCsdcurtr(String csdcurtr) {
		this.csdcurtr = csdcurtr;
	}

	public BigDecimal getCsddata() {
		return this.csddata;
	}

	public void setCsddata(BigDecimal csddata) {
		this.csddata = csddata;
	}

	public String getCsddescr() {
		return this.csddescr;
	}

	public void setCsddescr(String csddescr) {
		this.csddescr = csddescr;
	}

	public BigDecimal getCsddtemi() {
		return this.csddtemi;
	}

	public void setCsddtemi(BigDecimal csddtemi) {
		this.csddtemi = csddtemi;
	}

	public BigDecimal getCsddtneg() {
		return this.csddtneg;
	}

	public void setCsddtneg(BigDecimal csddtneg) {
		this.csddtneg = csddtneg;
	}

	public BigDecimal getCsddtsca() {
		return this.csddtsca;
	}

	public void setCsddtsca(BigDecimal csddtsca) {
		this.csddtsca = csddtsca;
	}

	public String getCsdesccp() {
		return this.csdesccp;
	}

	public void setCsdesccp(String csdesccp) {
		this.csdesccp = csdesccp;
	}

	public String getCsdesten() {
		return this.csdesten;
	}

	public void setCsdesten(String csdesten) {
		this.csdesten = csdesten;
	}

	public BigDecimal getCsdfrequ() {
		return this.csdfrequ;
	}

	public void setCsdfrequ(BigDecimal csdfrequ) {
		this.csdfrequ = csdfrequ;
	}

	public String getCsdisin() {
		return this.csdisin;
	}

	public void setCsdisin(String csdisin) {
		this.csdisin = csdisin;
	}

	public String getCsdmkt() {
		return this.csdmkt;
	}

	public void setCsdmkt(String csdmkt) {
		this.csdmkt = csdmkt;
	}

	public String getCsdnazio() {
		return this.csdnazio;
	}

	public void setCsdnazio(String csdnazio) {
		this.csdnazio = csdnazio;
	}

	public BigDecimal getCsdnextq() {
		return this.csdnextq;
	}

	public void setCsdnextq(BigDecimal csdnextq) {
		this.csdnextq = csdnextq;
	}

	public BigDecimal getCsdora() {
		return this.csdora;
	}

	public void setCsdora(BigDecimal csdora) {
		this.csdora = csdora;
	}

	public BigDecimal getCsdperce() {
		return this.csdperce;
	}

	public void setCsdperce(BigDecimal csdperce) {
		this.csdperce = csdperce;
	}

	public String getCsdperpe() {
		return this.csdperpe;
	}

	public void setCsdperpe(String csdperpe) {
		this.csdperpe = csdperpe;
	}

	public BigDecimal getCsdpoolf() {
		return this.csdpoolf;
	}

	public void setCsdpoolf(BigDecimal csdpoolf) {
		this.csdpoolf = csdpoolf;
	}

	public BigDecimal getCsdprog() {
		return this.csdprog;
	}

	public void setCsdprog(BigDecimal csdprog) {
		this.csdprog = csdprog;
	}

	public String getCsdrifiu() {
		return this.csdrifiu;
	}

	public void setCsdrifiu(String csdrifiu) {
		this.csdrifiu = csdrifiu;
	}

	public String getCsdsettl() {
		return this.csdsettl;
	}

	public void setCsdsettl(String csdsettl) {
		this.csdsettl = csdsettl;
	}

	public String getCsdstrut() {
		return this.csdstrut;
	}

	public void setCsdstrut(String csdstrut) {
		this.csdstrut = csdstrut;
	}

	public String getCsdtela() {
		return this.csdtela;
	}

	public void setCsdtela(String csdtela) {
		this.csdtela = csdtela;
	}

	public String getCsdtipo() {
		return this.csdtipo;
	}

	public void setCsdtipo(String csdtipo) {
		this.csdtipo = csdtipo;
	}

	public String getCsdtpstr() {
		return this.csdtpstr;
	}

	public void setCsdtpstr(String csdtpstr) {
		this.csdtpstr = csdtpstr;
	}

	public String getCsdtsost() {
		return this.csdtsost;
	}

	public void setCsdtsost(String csdtsost) {
		this.csdtsost = csdtsost;
	}

	public String getTcodemi() {
		return this.tcodemi;
	}

	public void setTcodemi(String tcodemi) {
		this.tcodemi = tcodemi;
	}

	public String getTcurrlq() {
		return this.tcurrlq;
	}

	public void setTcurrlq(String tcurrlq) {
		this.tcurrlq = tcurrlq;
	}

	public String getTcurrne() {
		return this.tcurrne;
	}

	public void setTcurrne(String tcurrne) {
		this.tcurrne = tcurrne;
	}

	public String getTdesc() {
		return this.tdesc;
	}

	public void setTdesc(String tdesc) {
		this.tdesc = tdesc;
	}

	public String getTdesemi() {
		return this.tdesemi;
	}

	public void setTdesemi(String tdesemi) {
		this.tdesemi = tdesemi;
	}

	public BigDecimal getTexch() {
		return this.texch;
	}

	public void setTexch(BigDecimal texch) {
		this.texch = texch;
	}

	public String getTflgel() {
		return this.tflgel;
	}

	public void setTflgel(String tflgel) {
		this.tflgel = tflgel;
	}

	public String getTinfbloo() {
		return this.tinfbloo;
	}

	public void setTinfbloo(String tinfbloo) {
		this.tinfbloo = tinfbloo;
	}

	public String getTpcert() {
		return this.tpcert;
	}

	public void setTpcert(String tpcert) {
		this.tpcert = tpcert;
	}

	public String getTprog() {
		return this.tprog;
	}

	public void setTprog(String tprog) {
		this.tprog = tprog;
	}

	public String getTpsemit() {
		return this.tpsemit;
	}

	public void setTpsemit(String tpsemit) {
		this.tpsemit = tpsemit;
	}

	public String getTscaper() {
		return this.tscaper;
	}

	public void setTscaper(String tscaper) {
		this.tscaper = tscaper;
	}

	/**
	 * @return the tdtablo
	 */
	public BigDecimal getTdtablo() {
		return tdtablo;
	}

	/**
	 * @return the tscaext
	 */
	public String getTscaext() {
		return tscaext;
	}

	/**
	 * @param tscaext the tscaext to set
	 */
	public void setTscaext(String tscaext) {
		this.tscaext = tscaext;
	}

	/**
	 * @param tdtablo the tdtablo to set
	 */
	public void setTdtablo(BigDecimal tdtablo) {
		this.tdtablo = tdtablo;
	}

	/**
	 * @return the tdtael
	 */
	public BigDecimal getTdtael() {
		return tdtael;
	}

	/**
	 * @param tdtael the tdtael to set
	 */
	public void setTdtael(BigDecimal tdtael) {
		this.tdtael = tdtael;
	}

	/**
	 * @return the tdtaem
	 */
	public BigDecimal getTdtaem() {
		return tdtaem;
	}

	/**
	 * @param tdtaem the tdtaem to set
	 */
	public void setTdtaem(BigDecimal tdtaem) {
		this.tdtaem = tdtaem;
	}

	/**
	 * @return the tdtaexp
	 */
	public BigDecimal getTdtaexp() {
		return tdtaexp;
	}

	/**
	 * @param tdtaexp the tdtaexp to set
	 */
	public void setTdtaexp(BigDecimal tdtaexp) {
		this.tdtaexp = tdtaexp;
	}

	/**
	 * @return the tdtaexpu
	 */
	public BigDecimal getTdtaexpu() {
		return tdtaexpu;
	}

	/**
	 * @param tdtaexpu the tdtaexpu to set
	 */
	public void setTdtaexpu(BigDecimal tdtaexpu) {
		this.tdtaexpu = tdtaexpu;
	}

	/**
	 * @return the tdtain
	 */
	public BigDecimal getTdtain() {
		return tdtain;
	}

	/**
	 * @param tdtain the tdtain to set
	 */
	public void setTdtain(BigDecimal tdtain) {
		this.tdtain = tdtain;
	}

	/**
	 * @return the torael
	 */
	public BigDecimal getTorael() {
		return torael;
	}

	/**
	 * @param torael the torael to set
	 */
	public void setTorael(BigDecimal torael) {
		this.torael = torael;
	}

	/**
	 * @return the ttimeblo
	 */
	public BigDecimal getTtimeblo() {
		return ttimeblo;
	}

	/**
	 * @param ttimeblo the ttimeblo to set
	 */
	public void setTtimeblo(BigDecimal ttimeblo) {
		this.ttimeblo = ttimeblo;
	}

	/**
	 * @return the tflcurdub
	 */
	public String getTflcurdub() {
		return tflcurdub;
	}

	/**
	 * @param tflcurdub the tflcurdub to set
	 */
	public void setTflcurdub(String tflcurdub) {
		this.tflcurdub = tflcurdub;
	}

	/**
	 * @return the tflcurliq
	 */
	public String getTflcurliq() {
		return tflcurliq;
	}

	/**
	 * @param tflcurliq the tflcurliq to set
	 */
	public void setTflcurliq(String tflcurliq) {
		this.tflcurliq = tflcurliq;
	}

	/**
	 * @return the tflcurneg
	 */
	public String getTflcurneg() {
		return tflcurneg;
	}

	/**
	 * @param tflcurneg the tflcurneg to set
	 */
	public void setTflcurneg(String tflcurneg) {
		this.tflcurneg = tflcurneg;
	}

	/**
	 * @return the tflgper
	 */
	public String getTflgper() {
		return tflgper;
	}

	/**
	 * @param tflgper the tflgper to set
	 */
	public void setTflgper(String tflgper) {
		this.tflgper = tflgper;
	}

	/**
	 * @return the tflgest
	 */
	public String getTflgest() {
		return tflgest;
	}

	/**
	 * @param tflgest the tflgest to set
	 */
	public void setTflgest(String tflgest) {
		this.tflgest = tflgest;
	}

	/**
	 * @return the tflamort
	 */
	public String getTflamort() {
		return tflamort;
	}

	/**
	 * @param tflamort the tflamort to set
	 */
	public void setTflamort(String tflamort) {
		this.tflamort = tflamort;
	}

	/**
	 * @return the tflgacct
	 */
	public String getTflgacct() {
		return tflgacct;
	}

	/**
	 * @param tflgacct the tflgacct to set
	 */
	public void setTflgacct(String tflgacct) {
		this.tflgacct = tflgacct;
	}

	/**
	 * @return the tflstruc
	 */
	public String getTflstruc() {
		return tflstruc;
	}

	/**
	 * @param tflstruc the tflstruc to set
	 */
	public void setTflstruc(String tflstruc) {
		this.tflstruc = tflstruc;
	}

	public String getTtpbond() {
		return this.ttpbond;
	}

	public void setTtpbond(String ttpbond) {
		this.ttpbond = ttpbond;
	}

	public String getTtpmat() {
		return this.ttpmat;
	}

	public void setTtpmat(String ttpmat) {
		this.ttpmat = ttpmat;
	}

	public String getTtpstr() {
		return this.ttpstr;
	}

	public void setTtpstr(String ttpstr) {
		this.ttpstr = ttpstr;
	}

	public String getTuser() {
		return this.tuser;
	}

	public void setTuser(String tuser) {
		this.tuser = tuser;
	}

	public String getTuserin() {
		return this.tuserin;
	}

	public void setTuserin(String tuserin) {
		this.tuserin = tuserin;
	}

}