/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd.dto;

import java.sql.Timestamp;

public class IfptBndRqIDTO {

	//ISINCODE VARCHAR(12) CCSID 280 NOT NULL,
	private String isinCode;
	//REQUESTID VARCHAR(40) CCSID 280 NOT NULL,
	private String requestId;
	//UPDDATE TIMESTAMP NOT NULL,
	private Timestamp updDate;
	//UPDTYPE CHAR(1) CCSID 280 NOT NULL DEFAULT 'C',
	private String updType;
	//UPDUSR VARCHAR(30) CCSID 280 NOT NULL DEFAULT 'SYSTEM'
	private String updUsr;
	
	/**
	 * @return the isinCode
	 */
	public String getIsinCode() {
		return isinCode;
	}
	/**
	 * @param isinCode the isinCode to set
	 */
	public void setIsinCode(String isinCode) {
		this.isinCode = isinCode;
	}
	/**
	 * @return the requestId
	 */
	public String getRequestId() {
		return requestId;
	}
	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	/**
	 * @return the updDate
	 */
	public Timestamp getUpdDate() {
		return updDate;
	}
	/**
	 * @param updDate the updDate to set
	 */
	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}
	/**
	 * @return the updType
	 */
	public String getUpdType() {
		return updType;
	}
	/**
	 * @param updType the updType to set
	 */
	public void setUpdType(String updType) {
		this.updType = updType;
	}
	/**
	 * @return the updUsr
	 */
	public String getUpdUsr() {
		return updUsr;
	}
	/**
	 * @param updUsr the updUsr to set
	 */
	public void setUpdUsr(String updUsr) {
		this.updUsr = updUsr;
	}
}
