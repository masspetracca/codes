/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd.dto;

import java.math.BigDecimal;
import java.util.Date;

public class CsdTiT00fDTO {

	private String tcodemi;
	private String tcurrlq;
	private String tcurrne;
	private String tdesc;
	private String tdesemi;
	private Date tdtablo;
	private Date tdtael;
	private Date tdtaem;
	private Date tdtaexp;
	private Date tdtaexpu;
	private Date tdtain;
	private BigDecimal texch;
	private String tflgel;
	private Boolean tflgins;
	private Boolean tinfbloo;
	private String tisin;
	private Date torael;
	private String tpcert;
	private String tpliq;
	private String tprog;
	private String tprov;
	private String tpsemit;
	private Boolean tscaext;
	private String tscaper;
	private String tstanbce;
	private Date ttimeblo;
	private String ttpbond;
	private String ttpmat;
	private String ttpstr;
	private String tuser;
	private String tuserin;
	
	//flag and alert
	private Boolean tflcurdub;
	private Boolean tflcurliq;
	private Boolean tflcurneg;
	private Boolean tflgper;
	private Boolean tflgest;
	private Boolean tflamort;
	private Boolean tflgacct;
	private Boolean tflstruc;
	
	
	/**
	 * @return the tcodemi
	 */
	public String getTcodemi() {
		return tcodemi;
	}
	/**
	 * @param tcodemi the tcodemi to set
	 */
	public void setTcodemi(String tcodemi) {
		this.tcodemi = tcodemi;
	}
	/**
	 * @return the tcurrlq
	 */
	public String getTcurrlq() {
		return tcurrlq;
	}
	/**
	 * @param tcurrlq the tcurrlq to set
	 */
	public void setTcurrlq(String tcurrlq) {
		this.tcurrlq = tcurrlq;
	}
	/**
	 * @return the tcurrne
	 */
	public String getTcurrne() {
		return tcurrne;
	}
	/**
	 * @param tcurrne the tcurrne to set
	 */
	public void setTcurrne(String tcurrne) {
		this.tcurrne = tcurrne;
	}
	/**
	 * @return the tdesc
	 */
	public String getTdesc() {
		return tdesc;
	}
	/**
	 * @param tdesc the tdesc to set
	 */
	public void setTdesc(String tdesc) {
		this.tdesc = tdesc;
	}
	/**
	 * @return the tdesemi
	 */
	public String getTdesemi() {
		return tdesemi;
	}
	/**
	 * @param tdesemi the tdesemi to set
	 */
	public void setTdesemi(String tdesemi) {
		this.tdesemi = tdesemi;
	}
	/**
	 * @return the tdtablo
	 */
	public Date getTdtablo() {
		return tdtablo;
	}
	/**
	 * @param tdtablo the tdtablo to set
	 */
	public void setTdtablo(Date tdtablo) {
		this.tdtablo = tdtablo;
	}
	/**
	 * @return the tdtael
	 */
	public Date getTdtael() {
		return tdtael;
	}
	/**
	 * @param tdtael the tdtael to set
	 */
	public void setTdtael(Date tdtael) {
		this.tdtael = tdtael;
	}
	/**
	 * @return the tdtaem
	 */
	public Date getTdtaem() {
		return tdtaem;
	}
	/**
	 * @param tdtaem the tdtaem to set
	 */
	public void setTdtaem(Date tdtaem) {
		this.tdtaem = tdtaem;
	}
	/**
	 * @return the tdtaexp
	 */
	public Date getTdtaexp() {
		return tdtaexp;
	}
	/**
	 * @param tdtaexp the tdtaexp to set
	 */
	public void setTdtaexp(Date tdtaexp) {
		this.tdtaexp = tdtaexp;
	}
	/**
	 * @return the tdtaexpu
	 */
	public Date getTdtaexpu() {
		return tdtaexpu;
	}
	/**
	 * @param tdtaexpu the tdtaexpu to set
	 */
	public void setTdtaexpu(Date tdtaexpu) {
		this.tdtaexpu = tdtaexpu;
	}
	/**
	 * @return the tdtain
	 */
	public Date getTdtain() {
		return tdtain;
	}
	/**
	 * @param tdtain the tdtain to set
	 */
	public void setTdtain(Date tdtain) {
		this.tdtain = tdtain;
	}
	/**
	 * @return the texch
	 */
	public BigDecimal getTexch() {
		return texch;
	}
	/**
	 * @param texch the texch to set
	 */
	public void setTexch(BigDecimal texch) {
		this.texch = texch;
	}
	/**
	 * @return the tflamort
	 */
	public Boolean getTflamort() {
		return tflamort;
	}
	/**
	 * @param tflamort the tflamort to set
	 */
	public void setTflamort(Boolean tflamort) {
		this.tflamort = tflamort;
	}
	/**
	 * @return the tflcurdub
	 */
	public Boolean getTflcurdub() {
		return tflcurdub;
	}
	/**
	 * @param tflcurdub the tflcurdub to set
	 */
	public void setTflcurdub(Boolean tflcurdub) {
		this.tflcurdub = tflcurdub;
	}
	/**
	 * @return the tflcurliq
	 */
	public Boolean getTflcurliq() {
		return tflcurliq;
	}
	/**
	 * @param tflcurliq the tflcurliq to set
	 */
	public void setTflcurliq(Boolean tflcurliq) {
		this.tflcurliq = tflcurliq;
	}
	/**
	 * @return the tflcurneg
	 */
	public Boolean getTflcurneg() {
		return tflcurneg;
	}
	/**
	 * @param tflcurneg the tflcurneg to set
	 */
	public void setTflcurneg(Boolean tflcurneg) {
		this.tflcurneg = tflcurneg;
	}
	/**
	 * @return the tflgacct
	 */
	public Boolean getTflgacct() {
		return tflgacct;
	}
	/**
	 * @param tflgacct the tflgacct to set
	 */
	public void setTflgacct(Boolean tflgacct) {
		this.tflgacct = tflgacct;
	}
	/**
	 * @return the tflgel
	 */
	public String getTflgel() {
		return tflgel;
	}
	/**
	 * @param tflgel the tflgel to set
	 */
	public void setTflgel(String tflgel) {
		this.tflgel = tflgel;
	}
	/**
	 * @return the tflgest
	 */
	public Boolean getTflgest() {
		return tflgest;
	}
	/**
	 * @param tflgest the tflgest to set
	 */
	public void setTflgest(Boolean tflgest) {
		this.tflgest = tflgest;
	}
	/**
	 * @return the tflgins
	 */
	public Boolean getTflgins() {
		return tflgins;
	}
	/**
	 * @param tflgins the tflgins to set
	 */
	public void setTflgins(Boolean tflgins) {
		this.tflgins = tflgins;
	}
	/**
	 * @return the tflgper
	 */
	public Boolean getTflgper() {
		return tflgper;
	}
	/**
	 * @param tflgper the tflgper to set
	 */
	public void setTflgper(Boolean tflgper) {
		this.tflgper = tflgper;
	}
	/**
	 * @return the tflstruc
	 */
	public Boolean getTflstruc() {
		return tflstruc;
	}
	/**
	 * @param tflstruc the tflstruc to set
	 */
	public void setTflstruc(Boolean tflstruc) {
		this.tflstruc = tflstruc;
	}
	/**
	 * @return the tinfbloo
	 */
	public Boolean getTinfbloo() {
		return tinfbloo;
	}
	/**
	 * @param tinfbloo the tinfbloo to set
	 */
	public void setTinfbloo(Boolean tinfbloo) {
		this.tinfbloo = tinfbloo;
	}
	/**
	 * @return the tisin
	 */
	public String getTisin() {
		return tisin;
	}
	/**
	 * @param tisin the tisin to set
	 */
	public void setTisin(String tisin) {
		this.tisin = tisin;
	}
	/**
	 * @return the torael
	 */
	public Date getTorael() {
		return torael;
	}
	/**
	 * @param torael the torael to set
	 */
	public void setTorael(Date torael) {
		this.torael = torael;
	}
	/**
	 * @return the tpcert
	 */
	public String getTpcert() {
		return tpcert;
	}
	/**
	 * @param tpcert the tpcert to set
	 */
	public void setTpcert(String tpcert) {
		this.tpcert = tpcert;
	}
	/**
	 * @return the tpliq
	 */
	public String getTpliq() {
		return tpliq;
	}
	/**
	 * @param tpliq the tpliq to set
	 */
	public void setTpliq(String tpliq) {
		this.tpliq = tpliq;
	}
	/**
	 * @return the tprog
	 */
	public String getTprog() {
		return tprog;
	}
	/**
	 * @param tprog the tprog to set
	 */
	public void setTprog(String tprog) {
		this.tprog = tprog;
	}
	/**
	 * @return the tprov
	 */
	public String getTprov() {
		return tprov;
	}
	/**
	 * @param tprov the tprov to set
	 */
	public void setTprov(String tprov) {
		this.tprov = tprov;
	}
	/**
	 * @return the tpsemit
	 */
	public String getTpsemit() {
		return tpsemit;
	}
	/**
	 * @param tpsemit the tpsemit to set
	 */
	public void setTpsemit(String tpsemit) {
		this.tpsemit = tpsemit;
	}
	/**
	 * @return the tscaext
	 */
	public Boolean getTscaext() {
		return tscaext;
	}
	/**
	 * @param tscaext the tscaext to set
	 */
	public void setTscaext(Boolean tscaext) {
		this.tscaext = tscaext;
	}
	/**
	 * @return the tscaper
	 */
	public String getTscaper() {
		return tscaper;
	}
	/**
	 * @param tscaper the tscaper to set
	 */
	public void setTscaper(String tscaper) {
		this.tscaper = tscaper;
	}
	/**
	 * @return the tstanbce
	 */
	public String getTstanbce() {
		return tstanbce;
	}
	/**
	 * @param tstanbce the tstanbce to set
	 */
	public void setTstanbce(String tstanbce) {
		this.tstanbce = tstanbce;
	}
	/**
	 * @return the ttimeblo
	 */
	public Date getTtimeblo() {
		return ttimeblo;
	}
	/**
	 * @param ttimeblo the ttimeblo to set
	 */
	public void setTtimeblo(Date ttimeblo) {
		this.ttimeblo = ttimeblo;
	}
	/**
	 * @return the ttpbond
	 */
	public String getTtpbond() {
		return ttpbond;
	}
	/**
	 * @param ttpbond the ttpbond to set
	 */
	public void setTtpbond(String ttpbond) {
		this.ttpbond = ttpbond;
	}
	/**
	 * @return the ttpmat
	 */
	public String getTtpmat() {
		return ttpmat;
	}
	/**
	 * @param ttpmat the ttpmat to set
	 */
	public void setTtpmat(String ttpmat) {
		this.ttpmat = ttpmat;
	}
	/**
	 * @return the ttpstr
	 */
	public String getTtpstr() {
		return ttpstr;
	}
	/**
	 * @param ttpstr the ttpstr to set
	 */
	public void setTtpstr(String ttpstr) {
		this.ttpstr = ttpstr;
	}
	/**
	 * @return the tuser
	 */
	public String getTuser() {
		return tuser;
	}
	/**
	 * @param tuser the tuser to set
	 */
	public void setTuser(String tuser) {
		this.tuser = tuser;
	}
	/**
	 * @return the tuserin
	 */
	public String getTuserin() {
		return tuserin;
	}
	/**
	 * @param tuserin the tuserin to set
	 */
	public void setTuserin(String tuserin) {
		this.tuserin = tuserin;
	}
}
