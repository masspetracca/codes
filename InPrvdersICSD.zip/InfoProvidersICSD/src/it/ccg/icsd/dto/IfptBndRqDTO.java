/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd.dto;

import java.sql.Timestamp;

public class IfptBndRqDTO {

	//RQDATE TIMESTAMP NOT NULL,
	private Timestamp reqDate;
	//REQUESTID VARCHAR(40) CCSID 280 NOT NULL,
	private String requestId;
	//REQSTATUS INTEGER NOT NULL,
	private Integer requestStatus;
	//RSDATE TIMESTAMP,
	private Timestamp respDate;
	//RESPONSEID VARCHAR(20) CCSID 280 NOT NULL,
	private String responseId;
	//RESPSTATUS INTEGER,
	private Integer responseStatus;
	//UPDDATE TIMESTAMP NOT NULL,
	private Timestamp updDate;
	//UPDTYPE CHAR(1) CCSID 280 NOT NULL DEFAULT 'C',
	private String updType;
	//UPDUSR VARCHAR(30) CCSID 280 NOT NULL DEFAULT 'SYSTEM'
	private String updUsr;
	
	/**
	 * @return the reqDate
	 */
	public Timestamp getReqDate() {
		return reqDate;
	}
	/**
	 * @param reqDate the reqDate to set
	 */
	public void setReqDate(Timestamp reqDate) {
		this.reqDate = reqDate;
	}
	/**
	 * @return the requestId
	 */
	public String getRequestId() {
		return requestId;
	}
	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	/**
	 * @return the requestStatus
	 */
	public Integer getRequestStatus() {
		return requestStatus;
	}
	/**
	 * @param requestStatus the requestStatus to set
	 */
	public void setRequestStatus(Integer requestStatus) {
		this.requestStatus = requestStatus;
	}
	/**
	 * @return the respDate
	 */
	public Timestamp getRespDate() {
		return respDate;
	}
	/**
	 * @param respDate the respDate to set
	 */
	public void setRespDate(Timestamp respDate) {
		this.respDate = respDate;
	}
	/**
	 * @return the responseId
	 */
	public String getResponseId() {
		return responseId;
	}
	/**
	 * @param responseId the responseId to set
	 */
	public void setResponseId(String responseId) {
		this.responseId = responseId;
	}
	/**
	 * @return the responseStatus
	 */
	public Integer getResponseStatus() {
		return responseStatus;
	}
	/**
	 * @param responseStatus the responseStatus to set
	 */
	public void setResponseStatus(Integer responseStatus) {
		this.responseStatus = responseStatus;
	}
	/**
	 * @return the updDate
	 */
	public Timestamp getUpdDate() {
		return updDate;
	}
	/**
	 * @param updDate the updDate to set
	 */
	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}
	/**
	 * @return the updType
	 */
	public String getUpdType() {
		return updType;
	}
	/**
	 * @param updType the updType to set
	 */
	public void setUpdType(String updType) {
		this.updType = updType;
	}
	/**
	 * @return the updUsr
	 */
	public String getUpdUsr() {
		return updUsr;
	}
	/**
	 * @param updUsr the updUsr to set
	 */
	public void setUpdUsr(String updUsr) {
		this.updUsr = updUsr;
	}
}
