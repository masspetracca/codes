/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd.dao;

import it.ccg.icsd.connection.RomaEnvConnector;
import it.ccg.icsd.dto.IfptBndRqIDTO;
import it.ccg.icsd.exception.SendBlockingException;
import it.ccg.icsd.exception.SendWarningException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

public class IfptBndRqIDAO {

	private static final Logger log = Logger.getLogger("it.ccg.icsd.dao.IfptBndRqIDAO");
	private Connection conn;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	public IfptBndRqIDAO() throws SendBlockingException {
		log.debug("in default constructor");
		try {
			RomaEnvConnector bdConnection = new RomaEnvConnector();
			log.debug("getting connection");
			conn = bdConnection.getConnection();
		} catch (SendBlockingException e) {
			log.error("SendBlockingException "+e.getCause().getMessage());
			throw e;
		}
	}
	
	/**
	 * 
	 * @param dto <code>IfptBndRqIDTO</code>
	 * @return <code>boolean</code>
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public boolean insertIfptBndRqI(IfptBndRqIDTO dto) throws SendWarningException, SendBlockingException{
		log.debug("in boolean insertIfptBndRqI(IfptBndRqIDTO dto) throws SendWarningException, SendBlockingException");
		
		String insertString = "INSERT INTO INFOP.IFPTBNDRQI(ISINCODE,REQUESTID,UPDDATE,UPDTYPE ,UPDUSR)"+ 
	   	  											   "VALUES(?,?,?,?,?)";
		log.debug("statement used "+insertString);
		boolean toReturn=false;
		log.debug("check data's consistency");
		if ((dto.getIsinCode()==null || dto.getIsinCode().equalsIgnoreCase(""))  || (dto.getRequestId()==null || dto.getRequestId().equalsIgnoreCase(""))){
			String field="";
			if (dto.getIsinCode()==null || dto.getIsinCode().equalsIgnoreCase(""))
				field+="ISINCODE ";
			
			if (dto.getRequestId()==null || dto.getRequestId().equalsIgnoreCase(""))
				field+="REQUESTID ";
			
			log.error("NoSuchFieldException: DATA INCOMPLETE "+field);
			throw new SendWarningException("DATA INCOMPLETE "+field);
		}
		log.debug("check ok");
		log.setter("statement used "+insertString);
		try {
			stmt = conn.prepareStatement(insertString);
			
			log.debug("statement instantiated start to popolate it");
			log.setter("set ISINCODE value "+dto.getIsinCode());
			stmt.setString(1, dto.getIsinCode());
			log.setter("set REQUESTID value "+dto.getRequestId());
			stmt.setString(2, dto.getRequestId());
			log.setter("set UPDDATE");
			stmt.setTimestamp(3, new Timestamp(new Date().getTime()));
			log.setter("set UPDTYPE value I");
			stmt.setString(4, "I");
			log.setter("set UPDUSR value SYSTEM");
			stmt.setString(5, "SYSTEM");
			
			log.debug("insert into INFOP.IFPTBNDRQI");
			toReturn = stmt.execute();
			
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * 
	 * @param dto <code>IfptBndRqIDTO</code>
	 * @return <code>List<IfptBndRqIDTO></code>
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public List<IfptBndRqIDTO> retrieveIfptBndRqIByISINCODE(IfptBndRqIDTO dto) throws SendWarningException, SendBlockingException{
		log.debug("in List<IfptBndRqIDTO> retrieveIfptBndRqIByISINCODE(IfptBndRqIDTO dto) throws SendWarningException, SendBlockingException");
		
		String retrieveString = " SELECT REQUESTID,"+
							           " UPDDATE,"+
							           " UPDTYPE,"+
							           " UPDUSR"+
							      " FROM INFOP.IFPTBNDRQI"+
							     " WHERE ISINCODE = ?";
		
		log.debug("statement used "+retrieveString);
		log.debug("check data's consistency");
		if (dto.getIsinCode()==null || dto.getIsinCode().equalsIgnoreCase("")){
			log.error("NoSuchFieldException: DATA INCOMPLETE ISINCODE");
			throw new SendWarningException("DATA INCOMPLETE ISINCODE");
		}
		log.debug("check ok");
		log.setter("statement used "+retrieveString);
		List<IfptBndRqIDTO> toReturn=null;
		try {
			stmt = conn.prepareStatement(retrieveString);
			log.setter("set ISINCODE value "+dto.getIsinCode());
			stmt.setString(1, dto.getIsinCode());
			
			log.debug("execute query");
			rs = stmt.executeQuery();
			log.debug("query executed...read data");
			toReturn= new ArrayList<IfptBndRqIDTO>();
			while (rs.next()){
				IfptBndRqIDTO appo = new IfptBndRqIDTO();
				appo.setIsinCode(dto.getIsinCode());
				log.setter("get REQUESTID value "+rs.getString(1));
				appo.setRequestId(rs.getString(1));
				log.setter("get UPDDATE");
				appo.setUpdDate(rs.getTimestamp(2));
				log.setter("get UPDTYPE value "+rs.getString(3));
				appo.setUpdType(rs.getString(3));
				log.setter("get UPDUSR value "+rs.getString(4));
				appo.setUpdUsr(rs.getString(4));
				toReturn.add(appo);
				log.setter("-----------------------------------------");
			}
			log.setter("###################################################");
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
				
			}
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * 
	 * @param dto <code>IfptBndRqIDTO</code>
	 * @return <code>List<IfptBndRqIDTO></code>
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public List<IfptBndRqIDTO> retrieveIfptBndRqIByRequestID(IfptBndRqIDTO dto) throws SendWarningException, SendBlockingException{
		log.debug("in List<IfptBndRqIDTO> retrieveIfptBndRqIByRequestID(IfptBndRqIDTO dto) throws SendWarningException, SendBlockingException");
		
		String retrieveString = " SELECT ISINCODE,"+
							           " UPDDATE,"+
							           " UPDTYPE,"+
							           " UPDUSR"+
							      " FROM INFOP.IFPTBNDRQI"+
							     " WHERE REQUESTID = ?";
		
		log.debug("statement used "+retrieveString);
		log.debug("check data's consistency");
		if (dto.getRequestId()==null || dto.getRequestId().equalsIgnoreCase("")){
			log.error("NoSuchFieldException: DATA INCOMPLETE REQUESTID");
			throw new SendWarningException("DATA INCOMPLETE REQUESTID");
		}
		log.debug("check ok");
		log.setter("statement used "+retrieveString);
		List<IfptBndRqIDTO> toReturn=null;
		try {
			stmt = conn.prepareStatement(retrieveString);
			log.setter("set REQUESTID value "+dto.getRequestId());
			stmt.setString(1, dto.getRequestId());
			
			log.debug("execute query");
			rs = stmt.executeQuery();
			log.debug("query executed...read data");
			toReturn= new ArrayList<IfptBndRqIDTO>();
			while (rs.next()){
				IfptBndRqIDTO appo = new IfptBndRqIDTO();
				appo.setRequestId(dto.getRequestId());
				log.setter("get ISINCODE value "+rs.getString(1));
				appo.setIsinCode(rs.getString(1));
				log.setter("get UPDDATE");
				appo.setUpdDate(rs.getTimestamp(2));
				log.setter("get UPDTYPE value "+rs.getString(3));
				appo.setUpdType(rs.getString(3));
				log.setter("get UPDUSR value "+rs.getString(4));
				appo.setUpdUsr(rs.getString(4));
				toReturn.add(appo);
				log.setter("-----------------------------------------");
			}
			log.setter("###################################################");
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
				
			}
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#finalize()
	 */
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		if (conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				log.warn("SQLException in close connection "+e.getMessage());
			}
		}
		super.finalize();
	}
}
