/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd.dao;

import it.ccg.icsd.connection.RomaEnvConnector;
import it.ccg.icsd.dto.CsdTiT00fDTO;
import it.ccg.icsd.exception.SendBlockingException;
import it.ccg.icsd.exception.SendWarningException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.log4j.Logger;

public class CsdTiT00fDAO {

	private static final Logger log = Logger.getLogger("it.ccg.icsd.dao.CsdTiT00fDAO");
	private Connection conn;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	private SimpleDateFormat dateFormat = new SimpleDateFormat ("yyyyMMdd");
	private SimpleDateFormat hourFormat = new SimpleDateFormat ("hhmmss");
	/**
	 * 
	 * @throws SendBlockingException
	 */
	public CsdTiT00fDAO() throws SendBlockingException{
		log.debug("in default constructor");
		try {
			RomaEnvConnector bdConnection = new RomaEnvConnector();
			log.debug("getting connection");
			conn = bdConnection.getConnection();
		} catch (SendBlockingException e) {
			log.error("SendBlockingException "+e.getCause().getMessage());
			throw e;
		}
	}
	
	/**
	 * Method that insert data into CSDTIT00F table
	 * @param <code>List<CsdTiT00fDTO></code>
	 * @return <code>boolean</code> - insert operation result
	 * @throws SendBlockingException
	 * @throws SendWarningException
	 */
	public boolean insertCsdTiT00f(List<CsdTiT00fDTO> list) throws SendBlockingException, SendWarningException{
		log.debug("in boolean insertCsdTiT00f(List<CsdTiT00fDTO> list) throws SendBlockingException, SendWarningException");
		
		String insertString = "INSERT INTO I400DTAEU.CSDTIT00F(TISIN, TDESC, TEXCH, TCURRNE, TCURRLQ, TPROV, TPLIQ, TPSEMIT, TDTAEM, TDESEMI, TCODEMI, TTPSTR, TPCERT, TTPBOND, TTPMAT, TSCAPER, TFLGPER, TDTAEXP, TDTAEXPU, TSCAEXT, TFLGEST, TFLGACCT, TFLCURNEG, TFLCURLIQ, TFLCURDUB, TFLSTRUC, TFLAMORT, TSTANBCE, TFLGEL, TDTAEL, TORAEL, TUSER, TPROG, TFLGINS, TDTAIN, TUSERIN, TINFBLOO, TDTABLO, TTIMEBLO) " +
				"										VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		log.debug("statement used "+insertString);
		boolean toReturn=false;
		
		log.debug("check data's consistency");
		for (CsdTiT00fDTO i : list){
			if ((i.getTisin()==null || i.getTisin().equalsIgnoreCase(""))){
				String field="";
				if (i.getTisin()==null || i.getTisin().equalsIgnoreCase(""))
					field+="ISINCODE ";
				
				log.error("NoSuchFieldException: DATA INCOMPLETE "+field);
				throw new SendWarningException("DATA INCOMPLETE "+field);
			}
		}
		log.debug("check ok");
		log.setter("statement used "+insertString);
		
		try {
			this.stmt = conn.prepareStatement(insertString);
		
			log.debug("statement instantiated start to popolate it");
			
			for (CsdTiT00fDTO i : list){
				//TISIN, 
				if (i.getTisin() == null){
					log.setter("set TISIN value null");
					stmt.setNull(1, Types.VARCHAR);
				}else{
					log.setter("set TISIN value "+i.getTisin());
					stmt.setString(1, i.getTisin());
				} 
				
				//TDESC, 
				if (i.getTdesc() == null){
					log.setter("set TDESC value null");
					stmt.setNull(2, Types.VARCHAR);
				}else{
					log.setter("set TDESC value "+i.getTdesc());
					stmt.setString(2, i.getTdesc());
				}
				
				//TEXCH,
				if (i.getTexch()==null){
					log.setter("set TEXCH value null");
					stmt.setNull(3, Types.DECIMAL);
				}else{
					log.setter("set TEXCH value "+i.getTexch());
					stmt.setBigDecimal(3, i.getTexch());
				}
				
				//TCURRNE,  
				if(i.getTcurrne()==null){
					log.setter("set TCURRNE value null");
					stmt.setNull(4, Types.VARCHAR);
				}else{
					log.setter("set TCURRNE value "+i.getTcurrne());
					stmt.setString(4, i.getTcurrne());
				}
				
				//TCURRLQ,
				if(i.getTcurrlq()==null){
					log.setter("set TCURRLQ value null");
					stmt.setNull(5, Types.VARCHAR);
				}else{
					log.setter("set TCURRLQ value "+i.getTcurrlq());
					stmt.setString(5, i.getTcurrlq());
				}
				
				//TPROV,
				if(i.getTprov()==null){
					log.setter("set TPROV value null");
					stmt.setNull(6, Types.VARCHAR);
				}else{
					log.setter("set TPROV value "+i.getTprov());
					stmt.setString(6, i.getTprov());
				}
				
				//TPLIQ,
				if(i.getTpliq()==null){
					log.setter("set TPLIQ value null");
					stmt.setNull(7, Types.VARCHAR);
				}else{
					log.setter("set TPLIQ value "+i.getTpliq());
					stmt.setString(7, i.getTpliq());
				}
				
				//TPSEMIT,
				if(i.getTpsemit() == null){
					log.setter("set TPSEMIT value null");
					stmt.setNull(8, Types.VARCHAR);
				}else{
					log.setter("set TPSEMIT value "+i.getTpsemit());
					stmt.setString(8, i.getTpsemit());
				}
				
				//TDTAEM,
				if(i.getTdtaem()== null){
					log.setter("set TDTAEM value null");
					stmt.setNull(9, Types.NUMERIC);
				}else{
					log.setter("set TDTAEM value "+i.getTdtaem());
					stmt.setInt(9, Integer.parseInt(dateFormat.format(i.getTdtaem())));
				}
				
				//TDESEMI,
				if(i.getTdesemi()==null){
					log.setter("set TDESEMI value null");
					stmt.setNull(10, Types.VARCHAR);
				}else{
					log.setter("set TDESEMI value "+i.getTdesemi());
					stmt.setString(10, i.getTdesemi());
				}
				
				//TCODEMI,  
				if(i.getTcodemi()== null){
					log.setter("set TCODEMI value null");
					stmt.setNull(11, Types.VARCHAR);
				}else{
					log.setter("set TCODEMI value "+i.getTcodemi());
					stmt.setString(11, i.getTcodemi());
				}
				
				//TTPSTR,
				if(i.getTtpstr() == null){
					log.setter("set TTPSTR value null");
					stmt.setNull(12, Types.VARCHAR);
				}else{
					log.setter("set TTPSTR value "+i.getTtpstr());
					stmt.setString(12, i.getTtpstr());
				}
				
				//TPCERT,  
				if(i.getTpcert() == null){
					log.setter("set TPCERT value null");
					stmt.setNull(13, Types.VARCHAR);
				}else{
					log.setter("set TPCERT value "+i.getTpcert());
					stmt.setString(13, i.getTpcert());
				}
				
				//TTPBOND,
				if(i.getTtpbond()== null){
					log.setter("set TTPBOND value null");
					stmt.setNull(14, Types.VARCHAR);
				}else{
					log.setter("set TTPBOND value "+i.getTtpbond());
					stmt.setString(14, i.getTtpbond());
				}
				
				//TTPMAT,  
				if(i.getTtpmat()==null){
					log.setter("set TTPMAT value null");
					stmt.setNull(15, Types.VARCHAR);
				}else{
					log.setter("set TTPMAT value "+i.getTtpmat());
					stmt.setString(15, i.getTtpmat());
				}
				
				//TSCAPER,
				if(i.getTscaper() == null){
					log.setter("set TSCAPER value null");
					stmt.setNull(16, Types.VARCHAR);
				}else{
					log.setter("set TSCAPER value "+i.getTscaper());
					stmt.setString(16, i.getTscaper());
				}
				
				//TFLGPER,
				if(i.getTflgper() == null){
					log.setter("set TFLGPER value null");
					stmt.setNull(17, Types.VARCHAR);
				}else{
					log.setter("set TFLGPER value "+i.getTflgper().booleanValue());
					stmt.setString(17, i.getTflgper().booleanValue()?"Y":"N");
				}
					
				//TDTAEXP,  
				if(i.getTdtaexp()==null){
					log.setter("set TDTAEXP value null");
					stmt.setNull(18, Types.NUMERIC);
				}else{
					log.setter("set TDTAEXP value "+i.getTdtaexp());
					stmt.setInt(18, Integer.parseInt(dateFormat.format(i.getTdtaexp())));
				}
				
				//TDTAEXPU,
				if(i.getTdtaexpu()==null){
					log.setter("set TDTAEXPU value null");
					stmt.setNull(19, Types.NUMERIC);
				}else{
					log.setter("set TDTAEXPU value "+i.getTdtaexpu());
					stmt.setInt(19, Integer.parseInt(dateFormat.format(i.getTdtaexpu())));
				}
				
				//TSCAEXT,  
				if(i.getTscaext()==null){
					log.setter("set TSCAEXT value null");
					stmt.setNull(20, Types.VARCHAR);
				}else{
					log.setter("set TSCAEXT value "+i.getTscaext().booleanValue());
					stmt.setString(20, i.getTscaext().booleanValue()?"Y":"N");
				}
				
				//TFLGEST, 
				if(i.getTflgest()== null){
					log.setter("set TFLGEST value null");
					stmt.setNull(21, Types.VARCHAR);
				}else{
					log.setter("set TFLGEST value "+i.getTflgest().booleanValue());
					stmt.setString(21, i.getTflgest().booleanValue()?"Y":"N");
				}
				
				//TFLGACCT,  
				if(i.getTflgacct()==null){
					log.setter("set TFLGACCT value null");
					stmt.setNull(22, Types.VARCHAR);
				}else{
					log.setter("set TFLGACCT value "+i.getTflgacct().booleanValue());
					stmt.setString(22, i.getTflgacct().booleanValue()?"Y":"N");
				}
				
				//TFLCURNEG,
				if(i.getTflcurneg() == null){
					log.setter("set TFLCURNEG value null");
					stmt.setNull(23, Types.VARCHAR);
				}else{
					log.setter("set TFLCURNEG value "+i.getTflcurneg().booleanValue());
					stmt.setString(23, i.getTflcurneg().booleanValue()?"Y":"N");
				}
				
				//TFLCURLIQ,
				if(i.getTflcurliq()==null){
					log.setter("set TFLCURLIQ value null");
					stmt.setNull(24, Types.VARCHAR);
				}else{
					log.setter("set TFLCURLIQ value "+i.getTflcurliq().booleanValue());
					stmt.setString(24, i.getTflcurliq().booleanValue()?"Y":"N");
				}
				
				//TFLCURDUB,
				if(i.getTflcurdub()==null){
					log.setter("set TFLCURDUB value null");
					stmt.setNull(25, Types.VARCHAR);
				}else{
					log.setter("set TFLCURDUB value "+i.getTflcurdub().booleanValue());
					stmt.setString(25, i.getTflcurdub().booleanValue()?"Y":"N");
				}
				
				//TFLSTRUC,
				if(i.getTflstruc()==null){
					log.setter("set TFLSTRUC value null");
					stmt.setNull(26, Types.VARCHAR);
				}else{
					log.setter("set TFLSTRUC value "+i.getTflstruc().booleanValue());
					stmt.setString(26, i.getTflstruc().booleanValue()?"Y":"N");
				}
				
				//TFLAMORT,
				if(i.getTflamort()==null){
					log.setter("set TFLAMORT value null");
					stmt.setNull(27, Types.VARCHAR);
				}else{
					log.setter("set TFLAMORT value "+i.getTflamort().booleanValue());
					stmt.setString(27, i.getTflamort().booleanValue()?"Y":"N");
				}
				
				//TSTANBCE,
				if(i.getTstanbce()==null){
					log.setter("set TSTANBCE value null");
					stmt.setNull(28, Types.VARCHAR);
				}else{
					log.setter("set TSTANBCE value "+i.getTstanbce());
					stmt.setString(28, i.getTstanbce());
				}
				
				//TFLGEL,
				if(i.getTflgel()==null){
					log.setter("set TFLGEL value null");
					stmt.setNull(29, Types.VARCHAR);
				}else{
					log.setter("set TFLGEL value "+i.getTflgel());
					stmt.setString(29, i.getTflgel());
				}
				
				//TDTAEL,
				if(i.getTdtael() == null){
					log.setter("set TDTAEL value null");
					stmt.setNull(30, Types.NUMERIC);
				}else{
					log.setter("set TDTAEL value "+i.getTdtael());
					stmt.setInt(30, Integer.parseInt(dateFormat.format(i.getTdtael())));
				}
				
				//TORAEL,
				if(i.getTorael()== null){
					log.setter("set TORAEL value null");
					stmt.setNull(31, Types.NUMERIC);
				}else{
					log.setter("set TORAEL value "+i.getTorael());
					stmt.setInt(31, Integer.parseInt(hourFormat.format(i.getTorael())));
				}
				
				//TUSER,
				if(i.getTuser() == null){
					log.setter("set TUSER value null");
					stmt.setNull(32, Types.VARCHAR);
				}else{
					log.setter("set TUSER value "+i.getTuser());
					stmt.setString(32, i.getTuser());
				}
				
				//TPROG,
				if(i.getTprog()==null){
					log.setter("set TPROG value null");
					stmt.setNull(33, Types.VARCHAR);
				}else{
					log.setter("set TPROG value "+i.getTprog());
					stmt.setString(33, i.getTprog());
				}
				
				//TFLGINS,
				if(i.getTflgins()==null){
					log.setter("set TFLGINS value null");
					stmt.setNull(34, Types.VARCHAR);
				}else{
					log.setter("set TFLGINS value "+i.getTflgins().booleanValue());
					stmt.setString(34, i.getTflgins().booleanValue()?"Y":"N");
				}
				
				//TDTAIN,  
				if(i.getTdtain()==null){
					log.setter("set TDTAIN value null");
					stmt.setNull(35, Types.NUMERIC);
				}else{
					log.setter("set TDTAIN value "+i.getTdtain());
					stmt.setInt(35, Integer.parseInt(dateFormat.format(i.getTdtain())));
				}
				
				//TUSERIN,
				if(i.getTuser()==null){
					log.setter("set TUSERIN value null");
					stmt.setNull(36, Types.VARCHAR);
				}else{
					log.setter("set TUSERIN value "+i.getTuser());
					stmt.setString(36, i.getTuser());
				}
				
				//TINFBLOO,
				if(i.getTinfbloo()==null){
					log.setter("set TINFBLOO value null");
					stmt.setNull(37, Types.VARCHAR);
				}else{
					log.setter("set TINFBLOO value "+i.getTinfbloo().booleanValue());
					stmt.setString(37, i.getTinfbloo().booleanValue()?"Y":"N");
				}
				
				//TDTABLO,  
				if(i.getTdtablo()==null){
					log.setter("set TDTABLO value null");
					stmt.setNull(38, Types.NUMERIC);
				}else{
					log.setter("set TDTABLO value "+i.getTdtablo());
					stmt.setInt(38, Integer.parseInt(dateFormat.format(i.getTdtablo())));
				}
				
				//TTIMEBLO
				if(i.getTtimeblo()==null){
					log.setter("set TTIMEBLO value null");
					stmt.setNull(39, Types.NUMERIC);
				}else{
					log.setter("set TTIMEBLO value "+i.getTtimeblo());
					stmt.setInt(39, Integer.parseInt(hourFormat.format(i.getTtimeblo())));
				}
				
				log.debug("insert into I400DTAEU.CSDTIT00F");
				toReturn=stmt.execute();
			}
			
			
		
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if (stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * Method that update CSDTIT00F table setting:
	 * "flag" fields with result; 
	 * TFINFBLOO to "N"; 
	 * TDTADLO and TTIMEBLO to Bloomberg Request date 
	 * @param <code>List<CsdTiT00fDTO></code> 
	 * @return <code>boolean</code> - update operation result
	 * @throws SendBlockingException
	 * @throws SendWarningException
	 */
	public boolean updateCsdTiT00fResult(List<CsdTiT00fDTO> list) throws SendBlockingException, SendWarningException{
		log.debug("in boolean updateCsdTiT00fResult(List<CsdTiT00fDTO> list) throws SendBlockingException, SendWarningException");
		String updateString = "UPDATE I400DTAEU.CSDTIT00F SET TFLGPER=?, " + //1
															 "TFLGEST=?, " + //2
															 "TFLGACCT=?, " +//3
															 "TFLSTRUC=?, " +//4
															 "TFLAMORT=?, " +//5
															 "TDTAEL=?, " +  //6
															 "TORAEL=?, " +  //7
															 "TINFBLOO=?, " +//8
															 "TDTABLO=?, " + //9
															 "TTIMEBLO=? " + //10
													   "WHERE TISIN= ?";     //11
				
		log.debug("statement used "+updateString);
		boolean toReturn=false;
		log.debug("check data's consistency");
		for (CsdTiT00fDTO i : list){
			if (i.getTisin() ==null || i.getTisin().equalsIgnoreCase("")){
				String field="";
				if (i.getTisin()==null || i.getTisin().equalsIgnoreCase(""))
					field+="ISINCODE ";
				
				if (i.getTflgper()==null)
					field+="TFLGPER ";
				
				if (i.getTflgest()==null)
					field+="TFLGEST ";
				
				if (i.getTflgacct()==null)
					field+="TFLGACCT ";
				
				if (i.getTflstruc()==null)
					field+="TFLSTRUC ";
				
				if (i.getTflamort()==null)
					field+="TFLAMORT ";
				
				if(i.getTinfbloo()==null)
					field+="TINFBLOO ";
					
				if(i.getTdtael() == null)
					field+="TORAEL ";	
				
				log.error("NoSuchFieldException: DATA INCOMPLETE "+field);
				throw new SendBlockingException("DATA INCOMPLETE "+field);
			}
		}
		log.debug("check ok");
		log.setter("statement used "+updateString);
		try {
			this.stmt = conn.prepareStatement(updateString);
			
			log.debug("statement instantiated start to popolate it");
			for (CsdTiT00fDTO i : list){
				//TFLGPER=?, " + //1
				stmt.setString(1,i.getTflgper().booleanValue()?"Y":"N");
				//TFLGEST=?, " + //2
				stmt.setString(2,i.getTflgest().booleanValue()?"Y":"N");
				//TFLGACCT=?, " +//3
				stmt.setString(3,i.getTflgacct().booleanValue()?"Y":"N");
				//TFLSTRUC=?, " +//4
				stmt.setString(4,i.getTflstruc().booleanValue()?"Y":"N");
				//TFLAMORT=?, " +//5
				stmt.setString(5,i.getTflamort().booleanValue()?"Y":"N");
				//TDTAEL=?, " +//6
				stmt.setInt(6, Integer.parseInt(this.dateFormat.format(i.getTdtael())));
				//TORAEL=?, " +//7
				stmt.setInt(7, Integer.parseInt(this.hourFormat.format(i.getTorael())));
				//TINFBLOO=?, " +//8
				stmt.setString(8,"Y");
				//TDTABLO=?, " + //9
				stmt.setInt(9,Integer.parseInt(this.dateFormat.format(i.getTdtablo())));
				//TTIMEBLO=? " + //10
				stmt.setInt(10,Integer.parseInt(this.hourFormat.format(i.getTtimeblo())));
				//TISIN= ?";     //11
				stmt.setString(11, i.getTisin());
				
				log.debug("update into I400DTAEU.CSDTIT00F");
				toReturn=stmt.execute();
			}
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if (stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * Method that retrieve every records from CSDTIT00F table that have TISIN field = CsdTiT00fDTO's TISIN variable
	 * @param <code>CsdTiT00fDTO</code>
	 * @return <code>List<CsdTiT00fDTO></code>
	 * @throws SendBlockingException
	 * @throws SendWarningException
	 */
	public List<CsdTiT00fDTO> retrieveCsdTiT00fByISINCODE(CsdTiT00fDTO dto) throws SendBlockingException, SendWarningException{
		log.debug("in List<CsdTiT00fDTO> retrieveCsdTiT00fByISINCODE(CsdTiT00fDTO dto) throws SendBlockingException, SendWarningException");
		String retrieveString = "SELECT TISIN, " +	 //1
									   "TDESC, " +	 //2
									   "TEXCH, " +	 //3
									   "TCURRNE, " + //4
									   "TCURRLQ, " + //5
									   "TPROV, " +	 //6
									   "TPLIQ, " +	 //7
									   "TPSEMIT, " + //8
									   "TDTAEM, " +	 //9
									   "TDESEMI, " + //10
									   "TCODEMI, " + //11 
									   "TTPSTR, " +	 //12
									   "TPCERT, " +	 //13
									   "TTPBOND, " + //14
									   "TTPMAT, " +	 //15
									   "TSCAPER, " + //16
									   "TFLGPER, " + //17
									   "TDTAEXP, " + //18
									   "TDTAEXPU, " +//19
									   "TSCAEXT, " + //20
									   "TFLGEST, " + //21
									   "TFLGACCT, " +//22
									   "TFLCURNEG, " +//23
									   "TFLCURLIQ, " +//24
									   "TFLCURDUB, " +//25
									   "TFLSTRUC, " +//26
									   "TFLAMORT, " +//27
									   "TSTANBCE, " +//28
									   "TFLGEL, " +	 //29
									   "TDTAEL, " +	 //30
									   "TORAEL, " +	 //31
									   "TUSER, " +	 //32
									   "TPROG, " +	 //33
									   "TFLGINS, " + //34
									   "TDTAIN, " +	 //35
									   "TUSERIN, " + //36
									   "TINFBLOO, " +//37
									   "TDTABLO, " + //38
									   "TTIMEBLO " + //39
								  "FROM I400DTAEU.CSDTIT00F "+
							     "WHERE TISIN = ?";  
		
		log.debug("statement used "+retrieveString);
		log.debug("check data's consistency");
		if (dto.getTisin()==null || dto.getTisin().equalsIgnoreCase("")){
			log.error("NoSuchFieldException: DATA INCOMPLETE ISINCODE");
			throw new SendWarningException("DATA INCOMPLETE ISINCODE");
		}
		log.debug("check ok");
		log.setter("statement used "+retrieveString);
		List<CsdTiT00fDTO> toReturn=null;
		try {
			stmt = conn.prepareStatement(retrieveString);
			log.setter("set TISIN value "+dto.getTisin());
			stmt.setString(1, dto.getTisin());
			
			log.debug("execute query");
			this.rs = stmt.executeQuery();
			log.debug("query executed...read data");
			toReturn= new ArrayList<CsdTiT00fDTO>();
			while(rs.next()){
				CsdTiT00fDTO appo = new CsdTiT00fDTO();
				//TISIN, " +	 //1
				appo.setTisin(dto.getTisin());
				//TDESC, " +	 //2
				appo.setTdesc(rs.getString(2));
				//TEXCH, " +	 //3
				appo.setTexch(rs.getBigDecimal(3));
				//TCURRNE, " + //4
				appo.setTcurrne(rs.getString(4));
				//TCURRLQ, " + //5
				appo.setTcurrlq(rs.getString(5));
				//TPROV, " +	 //6
				appo.setTprov(rs.getString(6));
				//TPLIQ, " +	 //7
				appo.setTpliq(rs.getString(7));
				//TPSEMIT, " + //8
				appo.setTpsemit(rs.getString(8));
				//TDTAEM, " +	 //9
				String appoStrTdtaem = rs.getString(9);
				GregorianCalendar appoTdtaem = new GregorianCalendar(Integer.parseInt(appoStrTdtaem.substring(0,4)),Integer.parseInt(appoStrTdtaem.substring(4,2)),Integer.parseInt(appoStrTdtaem.substring(6,2)));
				appo.setTdtaem(appoTdtaem.getTime());
				//TDESEMI, " + //10
				appo.setTdesemi(rs.getString(10));
				//TCODEMI, " + //11 
				appo.setTcodemi(rs.getString(11));
				//TTPSTR, " +	 //12
				appo.setTtpstr(rs.getString(12));
				//TPCERT, " +	 //13
				appo.setTtpstr(rs.getString(13));
				//TTPBOND, " + //14
				appo.setTtpbond(rs.getString(14));
				//TTPMAT, " +	 //15
				appo.setTtpmat(rs.getString(15));
				//TSCAPER, " + //16
				appo.setTscaper(rs.getString(16));
				//TFLGPER, " + //17
				appo.setTflgper(rs.getBoolean(17));
				//TDTAEXP, " + //18
				String appoStrTdtaexp = rs.getString(18);
				GregorianCalendar appoDtTdtaexp = new GregorianCalendar(Integer.parseInt(appoStrTdtaexp.substring(0,4)),Integer.parseInt(appoStrTdtaexp.substring(4,2)),Integer.parseInt(appoStrTdtaexp.substring(6,2)));
				appo.setTdtaexp(appoDtTdtaexp.getTime());
				//TDTAEXPU, " +//19
				String appoStrTdtaexpu = rs.getString(19);
				GregorianCalendar appoDtTdtaexpu = new GregorianCalendar(Integer.parseInt(appoStrTdtaexpu.substring(0,4)),Integer.parseInt(appoStrTdtaexpu.substring(4,2)),Integer.parseInt(appoStrTdtaexpu.substring(6,2)));
				appo.setTdtaexpu(appoDtTdtaexpu.getTime());
				//TSCAEXT, " + //20
				String appoTscaext = rs.getString(20);
				appo.setTscaext(appoTscaext.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLGEST, " + //21
				String appoTflgest = rs.getString(21);
				appo.setTflgest(appoTflgest.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLGACCT, " +//22
				String appoTflgacct = rs.getString(22);
				appo.setTflgacct(appoTflgacct.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLCURNEG, " +//23
				String appoTflcurneg = rs.getString(23);
				appo.setTflcurneg(appoTflcurneg.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLCURLIQ, " +//24
				String appoTflcurliq = rs.getString(24);
				appo.setTflcurliq(appoTflcurliq.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLCURDUB, " +//25
				String appoTflcurdub = rs.getString(25);
				appo.setTflcurdub(appoTflcurdub.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLSTRUC, " +//26
				String appoTflstruc = rs.getString(26);
				appo.setTflstruc(appoTflstruc.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLAMORT, " +//27
				String appoTflamort = rs.getString(27);
				appo.setTflamort(appoTflamort.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TSTANBCE, " +//28
				appo.setTstanbce(rs.getString(28));
				//TFLGEL, " +	 //29
				appo.setTflgel(rs.getString(29));
				//TDTAEL, " +	 //30
				String appoStrTdtael = rs.getString(30);
				GregorianCalendar appoDtTdtael = new GregorianCalendar(Integer.parseInt(appoStrTdtael.substring(0,4)),Integer.parseInt(appoStrTdtael.substring(4,2)),Integer.parseInt(appoStrTdtael.substring(6,2)));
				appo.setTdtael(appoDtTdtael.getTime());
				//TORAEL, " +	 //31
				String appoStrTorael = rs.getString(31);
				GregorianCalendar appoDtTorael = new GregorianCalendar(Integer.parseInt(appoStrTorael.substring(0,4)),Integer.parseInt(appoStrTorael.substring(4,2)),Integer.parseInt(appoStrTorael.substring(6,2)),Integer.parseInt(appoStrTorael.substring(0,2)),Integer.parseInt(appoStrTorael.substring(2,2)),Integer.parseInt(appoStrTorael.substring(4,2)));
				appo.setTorael(appoDtTorael.getTime());
				//TUSER, " +	 //32
				appo.setTuser(rs.getString(32));
				//TPROG, " +	 //33
				appo.setTprog(rs.getString(33));
				//TFLGINS, " + //34
				String appoTflgins = rs.getString(34);
				appo.setTflgins(appoTflgins.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TDTAIN, " +	 //35
				String appoStrTdtain = rs.getString(35);
				GregorianCalendar appoDtTdtain = new GregorianCalendar(Integer.parseInt(appoStrTdtain.substring(0,4)),Integer.parseInt(appoStrTdtain.substring(4,2)),Integer.parseInt(appoStrTdtain.substring(6,2)));
				appo.setTdtain(appoDtTdtain.getTime());
				//TUSERIN, " + //36
				appo.setTuserin(rs.getString(36));
				//TINFBLOO, " +//37
				String appoTinfbloo = rs.getString(37);
				appo.setTinfbloo(appoTinfbloo.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TDTABLO, " + //38
				String appoStrTdtablo = rs.getString(38);
				GregorianCalendar appoDtTdtablo = new GregorianCalendar(Integer.parseInt(appoStrTdtablo.substring(0,4)),Integer.parseInt(appoStrTdtablo.substring(4,2)),Integer.parseInt(appoStrTdtablo.substring(6,2)));
				appo.setTdtablo(appoDtTdtablo.getTime());
				//TTIMEBLO " + //39
				String appoStrTtimeblo = rs.getString(39);
				GregorianCalendar appoDtTtimeblo = new GregorianCalendar(Integer.parseInt(appoStrTdtablo.substring(0,4)),Integer.parseInt(appoStrTdtablo.substring(4,2)),Integer.parseInt(appoStrTdtablo.substring(6,2)),Integer.parseInt(appoStrTtimeblo.substring(0,2)),Integer.parseInt(appoStrTtimeblo.substring(2,2)),Integer.parseInt(appoStrTtimeblo.substring(4,2)));
				appo.setTtimeblo(appoDtTtimeblo.getTime());
				toReturn.add(appo);
				log.setter("-----------------------------------------");
			}
			log.setter("###################################################");
		
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * Method that retrieve every records from CSDTIT00F table that have TINFBLOO = 'N'
	 * @return <code>List<CsdTiT00fDTO></code>
	 * @throws SendBlockingException
	 * @throws SendWarningException
	 */
	public List<CsdTiT00fDTO> retrieveCsdTiT00fToCheck() throws SendBlockingException, SendWarningException{
		String retrieveString = "SELECT TISIN, " +	 //1
							    "TDESC, " +	 //2
							    "TEXCH, " +	 //3
							    "TCURRNE, " + //4
							    "TCURRLQ, " + //5
							    "TPROV, " +	 //6
							    "TPLIQ, " +	 //7
							    "TPSEMIT, " + //8
							    "TDTAEM, " +	 //9
							    "TDESEMI, " + //10
							    "TCODEMI, " + //11 
							    "TTPSTR, " +	 //12
							    "TPCERT, " +	 //13
							    "TTPBOND, " + //14
							    "TTPMAT, " +	 //15
							    "TSCAPER, " + //16
							    "TFLGPER, " + //17
							    "TDTAEXP, " + //18
							    "TDTAEXPU, " +//19
							    "TSCAEXT, " + //20
							    "TFLGEST, " + //21
							    "TFLGACCT, " +//22
							    "TFLCURNEG, " +//23
							    "TFLCURLIQ, " +//24
							    "TFLCURDUB, " +//25
							    "TFLSTRUC, " +//26
							    "TFLAMORT, " +//27
							    "TSTANBCE, " +//28
							    "TFLGEL, " +	 //29
							    "TDTAEL, " +	 //30
							    "TORAEL, " +	 //31
							    "TUSER, " +	 //32
							    "TPROG, " +	 //33
							    "TFLGINS, " + //34
							    "TDTAIN, " +	 //35
							    "TUSERIN, " + //36
							    "TINFBLOO, " +//37
							    "TDTABLO, " + //38
							    "TTIMEBLO " + //39
						  "FROM I400DTAEU.CSDTIT00F "+
					     "WHERE TINFBLOO = 'N'";  
		
		log.debug("statement used "+retrieveString);
		
		log.setter("statement used "+retrieveString);
		List<CsdTiT00fDTO> toReturn=null;
		try {
			stmt = conn.prepareStatement(retrieveString);
			
			log.debug("execute query");
			this.rs = stmt.executeQuery();
			log.debug("query executed...read data");
			toReturn= new ArrayList<CsdTiT00fDTO>();
			while(rs.next()){
				CsdTiT00fDTO appo = new CsdTiT00fDTO();
				//TISIN, " +	 //1
				appo.setTisin(rs.getString(1));
				//TDESC, " +	 //2
				appo.setTdesc(rs.getString(2));
				//TEXCH, " +	 //3
				appo.setTexch(rs.getBigDecimal(3));
				//TCURRNE, " + //4
				appo.setTcurrne(rs.getString(4));
				//TCURRLQ, " + //5
				appo.setTcurrlq(rs.getString(5));
				//TPROV, " +	 //6
				appo.setTprov(rs.getString(6));
				//TPLIQ, " +	 //7
				appo.setTpliq(rs.getString(7));
				//TPSEMIT, " + //8
				appo.setTpsemit(rs.getString(8));
				//TDTAEM, " +	 //9
				String appoStrTdtaem = rs.getString(9);
				GregorianCalendar appoTdtaem = new GregorianCalendar(Integer.parseInt(appoStrTdtaem.substring(0,4)),Integer.parseInt(appoStrTdtaem.substring(4,2)),Integer.parseInt(appoStrTdtaem.substring(6,2)));
				appo.setTdtaem(appoTdtaem.getTime());
				//TDESEMI, " + //10
				appo.setTdesemi(rs.getString(10));
				//TCODEMI, " + //11 
				appo.setTcodemi(rs.getString(11));
				//TTPSTR, " +	 //12
				appo.setTtpstr(rs.getString(12));
				//TPCERT, " +	 //13
				appo.setTtpstr(rs.getString(13));
				//TTPBOND, " + //14
				appo.setTtpbond(rs.getString(14));
				//TTPMAT, " +	 //15
				appo.setTtpmat(rs.getString(15));
				//TSCAPER, " + //16
				appo.setTscaper(rs.getString(16));
				//TFLGPER, " + //17
				appo.setTflgper(rs.getBoolean(17));
				//TDTAEXP, " + //18
				String appoStrTdtaexp = rs.getString(18);
				GregorianCalendar appoDtTdtaexp = new GregorianCalendar(Integer.parseInt(appoStrTdtaexp.substring(0,4)),Integer.parseInt(appoStrTdtaexp.substring(4,2)),Integer.parseInt(appoStrTdtaexp.substring(6,2)));
				appo.setTdtaexp(appoDtTdtaexp.getTime());
				//TDTAEXPU, " +//19
				String appoStrTdtaexpu = rs.getString(19);
				GregorianCalendar appoDtTdtaexpu = new GregorianCalendar(Integer.parseInt(appoStrTdtaexpu.substring(0,4)),Integer.parseInt(appoStrTdtaexpu.substring(4,2)),Integer.parseInt(appoStrTdtaexpu.substring(6,2)));
				appo.setTdtaexpu(appoDtTdtaexpu.getTime());
				//TSCAEXT, " + //20
				String appoTscaext = rs.getString(20);
				appo.setTscaext(appoTscaext.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLGEST, " + //21
				String appoTflgest = rs.getString(21);
				appo.setTflgest(appoTflgest.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLGACCT, " +//22
				String appoTflgacct = rs.getString(22);
				appo.setTflgacct(appoTflgacct.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLCURNEG, " +//23
				String appoTflcurneg = rs.getString(23);
				appo.setTflcurneg(appoTflcurneg.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLCURLIQ, " +//24
				String appoTflcurliq = rs.getString(24);
				appo.setTflcurliq(appoTflcurliq.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLCURDUB, " +//25
				String appoTflcurdub = rs.getString(25);
				appo.setTflcurdub(appoTflcurdub.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLSTRUC, " +//26
				String appoTflstruc = rs.getString(26);
				appo.setTflstruc(appoTflstruc.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TFLAMORT, " +//27
				String appoTflamort = rs.getString(27);
				appo.setTflamort(appoTflamort.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TSTANBCE, " +//28
				appo.setTstanbce(rs.getString(28));
				//TFLGEL, " +	 //29
				appo.setTflgel(rs.getString(29));
				//TDTAEL, " +	 //30
				String appoStrTdtael = rs.getString(30);
				GregorianCalendar appoDtTdtael = new GregorianCalendar(Integer.parseInt(appoStrTdtael.substring(0,4)),Integer.parseInt(appoStrTdtael.substring(4,2)),Integer.parseInt(appoStrTdtael.substring(6,2)));
				appo.setTdtael(appoDtTdtael.getTime());
				//TORAEL, " +	 //31
				String appoStrTorael = rs.getString(31);
				GregorianCalendar appoDtTorael = new GregorianCalendar(Integer.parseInt(appoStrTorael.substring(0,4)),Integer.parseInt(appoStrTorael.substring(4,2)),Integer.parseInt(appoStrTorael.substring(6,2)),Integer.parseInt(appoStrTorael.substring(0,2)),Integer.parseInt(appoStrTorael.substring(2,2)),Integer.parseInt(appoStrTorael.substring(4,2)));
				appo.setTorael(appoDtTorael.getTime());
				//TUSER, " +	 //32
				appo.setTuser(rs.getString(32));
				//TPROG, " +	 //33
				appo.setTprog(rs.getString(33));
				//TFLGINS, " + //34
				String appoTflgins = rs.getString(34);
				appo.setTflgins(appoTflgins.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TDTAIN, " +	 //35
				String appoStrTdtain = rs.getString(35);
				GregorianCalendar appoDtTdtain = new GregorianCalendar(Integer.parseInt(appoStrTdtain.substring(0,4)),Integer.parseInt(appoStrTdtain.substring(4,2)),Integer.parseInt(appoStrTdtain.substring(6,2)));
				appo.setTdtain(appoDtTdtain.getTime());
				//TUSERIN, " + //36
				appo.setTuserin(rs.getString(36));
				//TINFBLOO, " +//37
				String appoTinfbloo = rs.getString(37);
				appo.setTinfbloo(appoTinfbloo.equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				//TDTABLO, " + //38
				String appoStrTdtablo = rs.getString(38);
				GregorianCalendar appoDtTdtablo = new GregorianCalendar(Integer.parseInt(appoStrTdtablo.substring(0,4)),Integer.parseInt(appoStrTdtablo.substring(4,2)),Integer.parseInt(appoStrTdtablo.substring(6,2)));
				appo.setTdtablo(appoDtTdtablo.getTime());
				//TTIMEBLO " + //39
				String appoStrTtimeblo = rs.getString(39);
				GregorianCalendar appoDtTtimeblo = new GregorianCalendar(Integer.parseInt(appoStrTdtablo.substring(0,4)),Integer.parseInt(appoStrTdtablo.substring(4,2)),Integer.parseInt(appoStrTdtablo.substring(6,2)),Integer.parseInt(appoStrTtimeblo.substring(0,2)),Integer.parseInt(appoStrTtimeblo.substring(2,2)),Integer.parseInt(appoStrTtimeblo.substring(4,2)));
				appo.setTtimeblo(appoDtTtimeblo.getTime());
				toReturn.add(appo);
				log.setter("-----------------------------------------");
			}
			log.setter("###################################################");
		
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
}
