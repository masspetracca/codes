/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd.dao;

import it.ccg.icsd.connection.MilanoEnvConnector;
import it.ccg.icsd.dto.CsdDtB00fDTO;
import it.ccg.icsd.exception.SendBlockingException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

public class CsdDtB00fDAO {

	private static final Logger log = Logger.getLogger("it.ccg.icsd.dao.CsdDtB00fDAO");
	private Connection conn;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	public CsdDtB00fDAO() throws SendBlockingException{
		log.debug("in default constructor");
		try {
			MilanoEnvConnector bdConnection = new MilanoEnvConnector();
			log.debug("getting connection");
			conn = bdConnection.getConnection();
		} catch (SendBlockingException e) {
			log.error("SendBlockingException "+e.getCause().getMessage());
			throw e;
		}
	}
	
	/**
	 * 
	 * @return <code>ArrayList<CsdDtB00fDTO></code>
	 * @throws SendBlockingException
	 */
	public ArrayList<CsdDtB00fDTO> getDenominationValueCensus() throws SendBlockingException{
		log.debug("in ArrayList<CsdDtB00fDTO> getDenominationValueCensus()");
		String selectDenominationValue = "SELECT SIMBOLO FROM CCG_CGIT.CSDDTB00F WHERE TIPOTAB='VDE' AND FLACCET = 'Y'";
		
		ArrayList<CsdDtB00fDTO> toReturn;
		try {
			stmt = conn.prepareStatement(selectDenominationValue);
			log.debug("execute query");
			this.rs = stmt.executeQuery();
			log.debug("query executed...read data");
			toReturn= new ArrayList<CsdDtB00fDTO>();
			while(rs.next()){
				CsdDtB00fDTO appo = new CsdDtB00fDTO();
				appo.setSymbol(rs.getString(1));
				toReturn.add(appo);
			}
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}
				
		return toReturn;
	}
	
	/**
	 * 
	 * @return <code>ArrayList<CsdDtB00fDTO></code>
	 * @throws SendBlockingException
	 */
	public ArrayList<CsdDtB00fDTO> getSettlmentValueCensus() throws SendBlockingException{
		log.debug("in ArrayList<CsdDtB00fDTO> getDenominationValueCensus()");
		String selectDenominationValue = "SELECT SIMBOLO FROM CCG_CGIT.CSDDTB00F WHERE TIPOTAB='VSE' AND FLACCET = 'Y'";
		
		ArrayList<CsdDtB00fDTO> toReturn;
		try {
			stmt = conn.prepareStatement(selectDenominationValue);
			log.debug("execute query");
			this.rs = stmt.executeQuery();
			log.debug("query executed...read data");
			toReturn= new ArrayList<CsdDtB00fDTO>();
			while(rs.next()){
				CsdDtB00fDTO appo = new CsdDtB00fDTO();
				appo.setSymbol(rs.getString(1));
				toReturn.add(appo);
			}
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}
				
		return toReturn;
	}
}
