/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd.dao;

import it.ccg.icsd.connection.RomaEnvConnector;
import it.ccg.icsd.dto.IfptBndDtHDTO;
import it.ccg.icsd.exception.SendBlockingException;
import it.ccg.icsd.exception.SendWarningException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

public class IfptBndDtHDAO {

	private static final Logger log = Logger.getLogger("it.ccg.icsd.dao.IfptBndDtHDAO");
	private Connection conn;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	public IfptBndDtHDAO() throws SendBlockingException {
		log.debug("in default constructor");
		log.debug("getting connection");
		try {
			RomaEnvConnector bdConnection = new RomaEnvConnector();
			conn = bdConnection.getConnection();
		} catch (SendBlockingException e) {
			log.error("SendBlockingException "+e.getMessage());
			throw e;
		}
	}
	
	/**
	 * 
	 * @param list <code>boolean</code>
	 * @return <code>List<IfptBndDtHDTO></code> 
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public boolean insertIfptDndDtH(List<IfptBndDtHDTO> list) throws SendWarningException, SendBlockingException{
		log.debug("in boolean insertIfptDndDtH(List<IfptBndDtHDTO> list) throws SendWarningException, SendBlockingException");
		
		String insertString = "INSERT INTO INFOP.IFPTBNDDTH(ISINCODE,REQUESTID,BLOOMCODE,SEC_DES,ST_ACC_DT,MATURITY,FINAL_MAT,MKTSECT,IS_CERTIF,ISSR_IND ,ISSUER ,CRNCY ,REDEM_CRNCY ,DUAL_CRCY,DAY_TO_ST,MTY_TYP,IS_PERPET,EXTENDIBLE,BULLET,CALL_TYP,STRUCT_NOT,LNK_BND_IN,LNK_BNDINF,CPN_TYP,CPN,CPN_FREQ,RESET_IDX,UND_SEC_DE,DES_NOTES,CNTRY_RISK,REDEMP_VAL,PCT_PAR_QU ,PR_RT_SINK ,SINK_SC_TY ,REPFAC,SEC_FACT,INF_LNK_IN ,PAR_AMT,PX_LAST,PX_CLOSEDT,TFLCURDUB, TFLCURLIQ, TFLCURNEG, TFLGPER, TFLGEST, TFLAMORT, TFLGACCT, TFLSTRUC, UPDDATE,UPDTYPE ,UPDUSR,TTPBOND)"+ 
												   	  "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		log.debug("statement used "+insertString);
		boolean toReturn=false;
		log.debug("check data's consistency");
		List<IfptBndDtHDTO> correctData = new ArrayList<IfptBndDtHDTO>();
		for (IfptBndDtHDTO i : list){
			if ((i.getIsinCode()==null || i.getIsinCode().equalsIgnoreCase(""))  || (i.getRequestId()==null || i.getRequestId().equalsIgnoreCase(""))){
				String field="";
				if (i.getIsinCode()==null || i.getIsinCode().equalsIgnoreCase(""))
					field+="ISINCODE ";
				
				if (i.getRequestId()==null || i.getRequestId().equalsIgnoreCase(""))
					field+="REQUESTID ";
				
				log.error("NoSuchFieldException: DATA INCOMPLETE "+field);
			}
			else{
				correctData.add(i);
			}
		}
		log.debug("check ok");
		try {
			this.stmt = conn.prepareStatement(insertString);
			
			log.debug("statement instantiated start to popolate it");
			for (IfptBndDtHDTO i : correctData){
				if (i.getIsinCode()== null){
					log.setter("set ISINCODE value null");
					stmt.setNull(1, Types.VARCHAR);
				}else{
					log.setter("set ISINCODE value "+i.getIsinCode());
					stmt.setString(1, i.getIsinCode());
				}
				
				if (i.getRequestId()== null){
					log.setter("set REQUESTID value null");
					stmt.setNull(2, Types.VARCHAR);
				}else{
					log.setter("set REQUESTID value "+i.getRequestId());
					stmt.setString(2, i.getRequestId());
				}
			
				if (i.getBloomcode()== null){
					log.setter("set BLOOMCODE value null");
					stmt.setNull(3, Types.VARCHAR);
				}else{
					log.setter("set BLOOMCODE value "+i.getBloomcode());
					stmt.setString(3, i.getBloomcode());
				}
				
				if (i.getSecurityDes()== null){
					log.setter("set SEC_DES value null");
					stmt.setNull(4, Types.VARCHAR);
				}else{
					log.setter("set SEC_DES value "+i.getSecurityDes());
					stmt.setString(4, i.getSecurityDes());
				}
				
				if (i.getStartAccDt()== null){
					log.setter("set ST_ACC_DT value null");
					stmt.setNull(5, Types.INTEGER);
				}else{
					log.setter("set ST_ACC_DT value "+i.getStartAccDt());
					stmt.setInt(5, i.getStartAccDt());
				}
								
				if (i.getMaturity()== null){
					log.setter("set MATURITY value null");
					stmt.setNull(6, Types.INTEGER);
				}else{
					log.setter("set MATURITY value "+i.getMaturity());
					stmt.setInt(6, i.getMaturity());
				}

				if (i.getFinalMaturity()== null){
					log.setter("set FINAL_MAT value null");
					stmt.setNull(7, Types.INTEGER);
				}else{
					log.setter("set FINAL_MAT value "+i.getFinalMaturity());
					stmt.setInt(7, i.getFinalMaturity());
				}

				if (i.getMarketSectorDes()== null){
					log.setter("set MKTSECT value null");
					stmt.setNull(8, Types.VARCHAR);
				}else{
					log.setter("set MKTSECT value "+i.getMarketSectorDes());
					stmt.setString(8, i.getMarketSectorDes());
				}
				
				if (i.getCertificated()== null){
					log.setter("set IS_CERTIF value null");
					stmt.setNull(9, Types.CHAR);
				}else{
					log.setter("set IS_CERTIF value "+i.getCertificated().booleanValue());
					stmt.setString(9, i.getCertificated().booleanValue()?"Y":"N");
				}
				
				if (i.getIssuerIndustry()== null){
					log.setter("set ISSR_IND value null");
					stmt.setNull(10, Types.VARCHAR);
				}else{
					log.setter("set ISSR_IND value "+i.getIssuerIndustry());
					stmt.setString(10, i.getIssuerIndustry());
				}
				
				if (i.getIssuer()== null){
					log.setter("set ISSUER value null");
					stmt.setNull(11, Types.VARCHAR);
				}else{
					log.setter("set ISSUER value "+i.getIssuer());
					stmt.setString(11, i.getIssuer());
				}
				
				if (i.getCrncy()== null){
					log.setter("set CRNCY value null");
					stmt.setNull(12, Types.VARCHAR);
				}else{
					log.setter("set CRNCY value "+i.getCrncy());
					stmt.setString(12, i.getCrncy());
				}
				
				if (i.getRedempCrncy()== null){
					log.setter("set REDEM_CRNCY value null");
					stmt.setNull(13, Types.VARCHAR);
				}else{
					log.setter("set REDEM_CRNCY value "+i.getRedempCrncy());
					stmt.setString(13, i.getRedempCrncy());
				}
				
				if (i.getDualCrncy()== null){
					log.setter("set DUAL_CRCY value null");
					stmt.setNull(14, Types.CHAR);
				}else{
					log.setter("set DUAL_CRCY value "+i.getDualCrncy().booleanValue());
					stmt.setString(14, i.getDualCrncy().booleanValue()?"Y":"N");
				}
				
				if (i.getDayToSettle()== null){
					log.setter("set DAY_TO_ST value null");
					stmt.setNull(15, Types.INTEGER);
				}else{
					log.setter("set DAY_TO_ST value "+i.getDayToSettle());
					stmt.setInt(15, i.getDayToSettle().intValue());
				}
				
				if (i.getMtyTyp()== null){
					log.setter("set MTY_TYP value null");
					stmt.setNull(16, Types.VARCHAR);
				}else{
					log.setter("set MTY_TYP value "+i.getMtyTyp());
					stmt.setString(16, i.getMtyTyp());
				}

				if (i.getPerpetual()== null){
					log.setter("set IS_PERPET value null");
					stmt.setNull(17, Types.CHAR);
				}else{
					log.setter("set IS_PERPET value "+i.getPerpetual().booleanValue());
					stmt.setString(17, i.getPerpetual().booleanValue()?"Y":"N");
				}
				
				if (i.getExtendible()== null){
					log.setter("set EXTENDIBLE value null");
					stmt.setNull(18, Types.CHAR);
				}else{
					log.setter("set EXTENDIBLE value "+i.getExtendible().booleanValue());
					stmt.setString(18, i.getExtendible().booleanValue()?"Y":"N");
				}
				
				if (i.getBullet()== null){
					log.setter("set BULLET value null");
					stmt.setNull(19, Types.CHAR);
				}else{
					log.setter("set BULLET value "+i.getBullet().booleanValue());
					stmt.setString(19, i.getBullet().booleanValue()?"Y":"N");
				}

				if (i.getCallType()== null){
					log.setter("set CALL_TYP value null");
					stmt.setNull(20, Types.VARCHAR);
				}else{
					log.setter("set CALL_TYP value "+i.getCallType());
					stmt.setString(20, i.getCallType());
				}

				if (i.getStructuredNote()== null){
					log.setter("set STRUCT_NOT value null");
					stmt.setNull(21, Types.CHAR);
				}else{
					log.setter("set STRUCT_NOT value "+i.getStructuredNote().booleanValue());
					stmt.setString(21, i.getStructuredNote().booleanValue()?"Y":"N");
				}

				if (i.getLinkedBondInd()== null){
					log.setter("set LNK_BND_IN value null");
					stmt.setNull(22, Types.CHAR);
				}else{
					log.setter("set LNK_BND_IN value "+i.getLinkedBondInd().booleanValue());
					stmt.setString(22, i.getLinkedBondInd().booleanValue()?"Y":"N");
				}

				if (i.getLinkedBondInfo()== null){
					log.setter("set LNK_BNDINF value null");
					stmt.setNull(23, Types.VARCHAR);
				}else{
					log.setter("set LNK_BNDINF value "+i.getLinkedBondInfo());
					stmt.setString(23, i.getLinkedBondInfo());
				}


				if (i.getCpnTyp()== null){
					log.setter("set CPN_TYP value null");
					stmt.setNull(24, Types.VARCHAR);
				}else{
					log.setter("set CPN_TYP value "+i.getCpnTyp());
					stmt.setString(24, i.getCpnTyp());
				}

				if (i.getCpnTyp()== null){
					log.setter("set CPN value null");
					stmt.setNull(25, Types.DECIMAL);
				}else{
					log.setter("set CPN value "+i.getCpnTyp());
					stmt.setBigDecimal(25, i.getCpn());
				}

				if (i.getCpnFreq()== null){
					log.setter("set CPN_FREQ value null");
					stmt.setNull(26, Types.INTEGER);
				}else{
					log.setter("set CPN_FREQ value "+i.getCpnFreq());
					stmt.setInt(26, i.getCpnFreq().intValue());
				}

				if (i.getResetIdx()== null){
					log.setter("set RESET_IDX value null");
					stmt.setNull(27, Types.VARCHAR);
				}else{
					log.setter("set RESET_IDX value "+i.getResetIdx());
					stmt.setString(27, i.getResetIdx());
				}

				if (i.getUnderlyingSecurityDes()== null){
					log.setter("set UND_SEC_DE value null");
					stmt.setNull(28, Types.VARCHAR);
				}else{
					log.setter("set UND_SEC_DE value "+i.getResetIdx());
					stmt.setString(28, i.getUnderlyingSecurityDes());
				}

				if (i.getDesNote()== null){
					log.setter("set DES_NOTES value null");
					stmt.setNull(29, Types.VARCHAR);
				}else{
					log.setter("set DES_NOTES value "+i.getDesNote());
					stmt.setString(29, i.getDesNote());
				}
				
				if (i.getCntryOfRisk()== null){
					log.setter("set CNTRY_RISK value null");
					stmt.setNull(30, Types.VARCHAR);
				}else{
					log.setter("set CNTRY_RISK value "+i.getCntryOfRisk());
					stmt.setString(30, i.getCntryOfRisk());
				}
		
				if (i.getRedempVal()== null){
					log.setter("set REDEMP_VAL value null");
					stmt.setNull(31, Types.DECIMAL);
				}else{
					log.setter("set REDEMP_VAL value "+i.getRedempVal());
					stmt.setBigDecimal(31, i.getRedempVal());
				}

				if (i.getPctParQuoted()== null){
					log.setter("set PCT_PAR_QU value null");
					stmt.setNull(32, Types.CHAR);
				}else{
					log.setter("set PCT_PAR_QU value "+i.getPctParQuoted().booleanValue());
					stmt.setString(32, i.getPctParQuoted().booleanValue()?"Y":"N");
				}

				if (i.getProRataSink()== null){
					log.setter("set PR_RT_SINK value null");
					stmt.setNull(33, Types.CHAR);
				}else{
					log.setter("set PR_RT_SINK value "+i.getProRataSink().booleanValue());
					stmt.setString(33, i.getProRataSink().booleanValue()?"Y":"N");
				}

				if (i.getSinkScheduleAmtTyp()== null){
					log.setter("set SINK_SC_TY value null");
					stmt.setNull(34, Types.VARCHAR);
				}else{
					log.setter("set SINK_SC_TY value "+i.getSinkScheduleAmtTyp());
					stmt.setString(34, i.getSinkScheduleAmtTyp());
				}

				if (i.getMostRecentReportedFactor()== null){
					log.setter("set REPFAC value null");
					stmt.setNull(35, Types.DECIMAL);
				}else{
					log.setter("set REPFAC value "+i.getMostRecentReportedFactor());
					stmt.setBigDecimal(35, i.getMostRecentReportedFactor());
				}

				if (i.getMostRecentReportedFactor()== null){
					log.setter("set SEC_FACT value null");
					stmt.setNull(36, Types.CHAR);
				}else{
					log.setter("set SEC_FACT value "+i.getSecurityFactorable().booleanValue());
					stmt.setString(36, i.getSecurityFactorable().booleanValue()?"Y":"N");
				}

				if (i.getInflationLinkedIndicator()== null){
					log.setter("set INF_LNK_IN value null");
					stmt.setNull(37, Types.CHAR);
				}else{
					log.setter("set INF_LNK_IN value "+i.getInflationLinkedIndicator().booleanValue());
					stmt.setString(37, i.getInflationLinkedIndicator().booleanValue()?"Y":"N");
				}

				if (i.getParAmt()== null){
					log.setter("set PAR_AMT value null");
					stmt.setNull(38, Types.DECIMAL);
				}else{
					log.setter("set PAR_AMT value "+i.getParAmt());
					stmt.setBigDecimal(38, i.getParAmt());
				}

				if (i.getPxLast()== null){
					log.setter("set PX_LAST value null");
					stmt.setNull(39, Types.DECIMAL);
				}else{
					log.setter("set PX_LAST value "+i.getPxLast());
					stmt.setBigDecimal(39, i.getPxLast());
				}

				if (i.getPxCloseDt()== null){
					log.setter("set PX_CLOSEDT value null");
					stmt.setNull(40, Types.INTEGER);
				}else{
					log.setter("set PX_CLOSEDT value "+i.getPxCloseDt().intValue());
					stmt.setInt(40, i.getPxCloseDt().intValue());
				}

				//TFLCURDUB, 
				if (i.getTflcurdub()== null){
					log.setter("set TFLCURDUB value null");
					stmt.setNull(41, Types.CHAR);
				}else{
					log.setter("set TFLCURDUB value "+i.getTflcurdub().booleanValue());
					stmt.setString(41, i.getTflcurdub().booleanValue()?"Y":"N");
				}
				//TFLCURLIQ, 
				if (i.getTflcurliq()== null){
					log.setter("set TFLCURLIQ value null");
					stmt.setNull(42, Types.CHAR);
				}else{
					log.setter("set TFLCURLIQ value "+i.getTflcurliq().booleanValue());
					stmt.setString(42, i.getTflcurliq().booleanValue()?"Y":"N");
				}
				//TFLCURNEG, 
				if (i.getTflcurneg()== null){
					log.setter("set TFLCURNEG value null");
					stmt.setNull(43, Types.CHAR);
				}else{
					log.setter("set TFLCURNEG value "+i.getTflcurneg().booleanValue());
					stmt.setString(43, i.getTflcurneg().booleanValue()?"Y":"N");
				}
				//TFLGPER, 
				if (i.getTflgper()== null){
					log.setter("set TFLGPER value null");
					stmt.setNull(44, Types.CHAR);
				}else{
					log.setter("set TFLGPER value "+i.getTflgper().booleanValue());
					stmt.setString(44, i.getTflgper().booleanValue()?"Y":"N");
				}
				//TFLGEST, 
				if (i.getTflgest()== null){
					log.setter("set TFLGEST value null");
					stmt.setNull(45, Types.CHAR);
				}else{
					log.setter("set TFLGEST value "+i.getTflgest().booleanValue());
					stmt.setString(45, i.getTflgest().booleanValue()?"Y":"N");
				}
				//TFLAMORT,
				if (i.getTflamort()== null){
					log.setter("set TFLAMORT value null");
					stmt.setNull(46, Types.CHAR);
				}else{
					log.setter("set TFLAMORT value "+i.getTflamort().booleanValue());
					stmt.setString(46, i.getTflamort().booleanValue()?"Y":"N");
				}
				//TFLGACCT, 
				if (i.getTflgacct()== null){
					log.setter("set TFLAMORT value null");
					stmt.setNull(47, Types.CHAR);
				}else{
					log.setter("set TFLAMORT value "+i.getTflgacct().booleanValue());
					stmt.setString(47, i.getTflgacct().booleanValue()?"Y":"N");
				}
				//TFLSTRUC, 
				if (i.getTflstruc()== null){
					log.setter("set TFLSTRUC value null");
					stmt.setNull(48, Types.CHAR);
				}else{
					log.setter("set TFLSTRUC value "+i.getTflstruc().booleanValue());
					stmt.setString(48, i.getTflstruc().booleanValue()?"Y":"N");
				}
				
				log.setter("set UPDDATE");
				stmt.setTimestamp(49, new Timestamp(new Date().getTime()));
				log.setter("set UPDTYPE value I");
				stmt.setString(50, "I");
				log.setter("set UPDUSR value "+i.getUpdUsr());
				stmt.setString(51, i.getUpdUsr());
				//TTPBOND
				if (i.getTtpbond()== null){
					log.setter("set TTPBOND value null");
					stmt.setNull(52, Types.CHAR);
				}else{
					log.setter("set TTPBOND value "+i.getTtpbond().booleanValue());
					stmt.setString(52, i.getTtpbond().booleanValue()?"Y":"N");
				}
				log.debug("insert into INFOP.IFPTBNDDTH");
				toReturn=stmt.execute();
			}
			
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if (stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * 
	 * @param list <code>boolean</code>
	 * @return <code>List<IfptBndDtHDTO></code> 
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public boolean updateIfptDndDt(List<IfptBndDtHDTO> list) throws SendWarningException, SendBlockingException{
		log.debug("in boolean updateIfptDndDt(List<IfptBndDtHDTO> list) throws SendWarningException, SendBlockingException");
		String updateString = "UPDATE INFOP.IFPTBNDDTH SET BLOOMCODE = ?, " + //1
														"SEC_DES=?, "+ //2
														"ST_ACC_DT=?, "+ //3
														"MATURITY= ?, "+ //4
														"FINAL_MAT=?, "+ //5
														"MKTSECT=?, "+ //6
														"IS_CERTIF=?, "+ //7
														"ISSR_IND=? , "+ //8
														"ISSUER=? , "+ //9
														"CRNCY=? , "+ //10
														"REDEM_CRNCY=? , "+ //11
														"DUAL_CRCY=?, "+ //12
														"DAY_TO_ST=?, "+ //13
														"MTY_TYP=?, "+ //14
														"IS_PERPET=?, "+ //15
														"EXTENDIBLE=?, "+ //16
														"BULLET=?, "+ //17
														"CALL_TYP=?, "+ //18
														"STRUCT_NOT=?, "+ //19
														"LNK_BND_IN=?, "+ //20
														"LNK_BNDINF=?, "+ //21
														"CPN_TYP=?, "+ //22
														"CPN=?, "+ //23
														"CPN_FREQ=?, "+ //24
														"RESET_IDX=?, "+ //25
														"UND_SEC_DE=?, "+ //26
														"DES_NOTES=?, "+ //27
														"CNTRY_RISK=?, "+ //28
														"REDEMP_VAL=?, "+ //29
														"PCT_PAR_QU=? , "+ //30
														"PR_RT_SINK=? , "+ //31
														"SINK_SC_TY =?, "+ //32
														"REPFAC=?, "+ //33
														"SEC_FACT=?, "+ //34
														"INF_LNK_IN =?, "+ //35
														"PAR_AMT=?, "+ //36
														"PX_LAST=?, "+ //37
														"PX_CLOSEDT=?, "+ //38
														"TFLCURDUB=?, "+//39
														"TFLCURLIQ=?, "+//40
														"TFLCURNEG=?, "+//41
														"TFLGPER=?, "+//42
														"TFLGEST=?, "+//43
														"TFLAMORT=?, "+//44
														"TFLGACCT=?, "+//45
														"TFLSTRUC=?, "+//46
														"UPDDATE=?, "+ //47
														"UPDTYPE=? , "+ //48
														"UPDUSR=?,"+  //49
														"TTPBOND=?"+ //50
												   "WHERE ISINCODE = ? " + //51
												   	 "AND REQUESTID =?"; //52
		log.debug("statement used "+updateString);
		boolean toReturn=false;
		log.debug("check data's consistency");
		for (IfptBndDtHDTO i : list){
			if ((i.getIsinCode()==null || i.getIsinCode().equalsIgnoreCase(""))  || (i.getRequestId()==null || i.getRequestId().equalsIgnoreCase(""))){
				String field="";
				if (i.getIsinCode()==null || i.getIsinCode().equalsIgnoreCase(""))
					field+="ISINCODE ";
				
				if (i.getRequestId()==null || i.getRequestId().equalsIgnoreCase(""))
					field+="REQUESTID ";
				
				log.error("NoSuchFieldException: DATA INCOMPLETE "+field);
				throw new SendWarningException("DATA INCOMPLETE "+field);
			}
		}
		log.debug("check ok");
		try {
			this.stmt = conn.prepareStatement(updateString);
			
			log.debug("statement instantiated start to popolate it");
			for (IfptBndDtHDTO i : list){
				if (i.getBloomcode()== null){
					log.setter("set BLOOMCODE value null");
					stmt.setNull(1, Types.VARCHAR);
				}else{
					log.setter("set BLOOMCODE value "+i.getBloomcode());
					stmt.setString(1, i.getBloomcode());
				}

				if (i.getSecurityDes()== null){
					log.setter("set SEC_DES value null");
					stmt.setNull(2, Types.VARCHAR);
				}else{
					log.setter("set SEC_DES value "+i.getSecurityDes());
					stmt.setString(2, i.getSecurityDes());
				}

				if (i.getStartAccDt()== null){
					log.setter("set ST_ACC_DT value null");
					stmt.setNull(3, Types.INTEGER);
				}else{
					log.setter("set ST_ACC_DT value "+i.getStartAccDt());
					stmt.setInt(3, i.getStartAccDt());
				}
				
				if (i.getMaturity()== null){
					log.setter("set MATURITY value null");
					stmt.setNull(4, Types.INTEGER);
				}else{
					log.setter("set MATURITY value "+i.getMaturity());
					stmt.setInt(4, i.getMaturity());
				}

				if (i.getFinalMaturity()== null){
					log.setter("set FINAL_MAT value null");
					stmt.setNull(5, Types.INTEGER);
				}else{
					log.setter("set FINAL_MAT value "+i.getFinalMaturity());
					stmt.setInt(5, i.getFinalMaturity());
				}

				if (i.getMarketSectorDes()== null){
					log.setter("set MKTSECT value null");
					stmt.setNull(6, Types.VARCHAR);
				}else{
					log.setter("set MKTSECT value "+i.getMarketSectorDes());
					stmt.setString(6, i.getMarketSectorDes());
				}

				if (i.getCertificated()== null){
					log.setter("set IS_CERTIF value null");
					stmt.setNull(7, Types.CHAR);
				}else{
					log.setter("set IS_CERTIF value "+i.getCertificated().booleanValue());
					stmt.setString(7, i.getCertificated().booleanValue()?"Y":"N");
				}

				if (i.getIssuerIndustry()== null){
					log.setter("set ISSR_IND value null");
					stmt.setNull(8, Types.VARCHAR);
				}else{
					log.setter("set ISSR_IND value "+i.getIssuerIndustry());
					stmt.setString(8, i.getIssuerIndustry());
				}

				if (i.getIssuer()== null){
					log.setter("set ISSUER value null");
					stmt.setNull(9, Types.VARCHAR);
				}else{
					log.setter("set ISSUER value "+i.getIssuer());
					stmt.setString(9, i.getIssuer());
				}

				if (i.getCrncy()== null){
					log.setter("set CRNCY value null");
					stmt.setNull(10, Types.VARCHAR);
				}else{
					log.setter("set CRNCY value "+i.getCrncy());
					stmt.setString(10, i.getCrncy());
				}

				if (i.getRedempCrncy()== null){
					log.setter("set REDEM_CRNCY value null");
					stmt.setNull(11, Types.VARCHAR);
				}else{
					log.setter("set REDEM_CRNCY value "+i.getRedempCrncy());
					stmt.setString(11, i.getRedempCrncy());
				}

				if (i.getDualCrncy()== null){
					log.setter("set DUAL_CRCY value null");
					stmt.setNull(12, Types.CHAR);
				}else{
					log.setter("set DUAL_CRCY value "+i.getDualCrncy().booleanValue());
					stmt.setString(12, i.getDualCrncy().booleanValue()?"Y":"N");
				}

				if (i.getDayToSettle()== null){
					log.setter("set DAY_TO_ST value null");
					stmt.setNull(13, Types.INTEGER);
				}else{
					log.setter("set DAY_TO_ST value "+i.getDayToSettle());
					stmt.setInt(13, i.getDayToSettle().intValue());
				}

				if (i.getMtyTyp()== null){
					log.setter("set MTY_TYP value null");
					stmt.setNull(14, Types.VARCHAR);
				}else{
					log.setter("set MTY_TYP value "+i.getMtyTyp());
					stmt.setString(14, i.getMtyTyp());
				}

				if (i.getPerpetual()== null){
					log.setter("set IS_PERPET value null");
					stmt.setNull(15, Types.CHAR);
				}else{
					log.setter("set IS_PERPET value "+i.getPerpetual().booleanValue());
					stmt.setString(15, i.getPerpetual().booleanValue()?"Y":"N");
				}

				if (i.getExtendible()== null){
					log.setter("set EXTENDIBLE value null");
					stmt.setNull(16, Types.CHAR);
				}else{
					log.setter("set EXTENDIBLE value "+i.getExtendible().booleanValue());
					stmt.setString(16, i.getExtendible().booleanValue()?"Y":"N");
				}

				if (i.getBullet()== null){
					log.setter("set BULLET value null");
					stmt.setNull(17, Types.CHAR);
				}else{
					log.setter("set BULLET value "+i.getBullet().booleanValue());
					stmt.setString(17, i.getBullet().booleanValue()?"Y":"N");
				}

				if (i.getCallType()== null){
					log.setter("set CALL_TYP value null");
					stmt.setNull(18, Types.VARCHAR);
				}else{
					log.setter("set CALL_TYP value "+i.getCallType());
					stmt.setString(18, i.getCallType());
				}

				if (i.getStructuredNote()== null){
					log.setter("set STRUCT_NOT value null");
					stmt.setNull(19, Types.CHAR);
				}else{
					log.setter("set STRUCT_NOT value "+i.getStructuredNote().booleanValue());
					stmt.setString(19, i.getStructuredNote().booleanValue()?"Y":"N");
				}

				if (i.getLinkedBondInd()== null){
					log.setter("set LNK_BND_IN value null");
					stmt.setNull(20, Types.CHAR);
				}else{
					log.setter("set LNK_BND_IN value "+i.getLinkedBondInd().booleanValue());
					stmt.setString(20, i.getLinkedBondInd().booleanValue()?"Y":"N");
				}

				if (i.getLinkedBondInfo()== null){
					log.setter("set LNK_BNDINF value null");
					stmt.setNull(21, Types.VARCHAR);
				}else{
					log.setter("set LNK_BNDINF value "+i.getLinkedBondInfo());
					stmt.setString(21, i.getLinkedBondInfo());
				}

				if (i.getCpnTyp()== null){
					log.setter("set CPN_TYP value null");
					stmt.setNull(22, Types.VARCHAR);
				}else{
					log.setter("set CPN_TYP value "+i.getCpnTyp());
					stmt.setString(22, i.getCpnTyp());
				}

				if (i.getCpnTyp()== null){
					log.setter("set CPN value null");
					stmt.setNull(23, Types.DECIMAL);
				}else{
					log.setter("set CPN value "+i.getCpnTyp());
					stmt.setBigDecimal(23, i.getCpn());
				}

				if (i.getCpnFreq()== null){
					log.setter("set CPN_FREQ value null");
					stmt.setNull(24, Types.INTEGER);
				}else{
					log.setter("set CPN_FREQ value "+i.getCpnFreq());
					stmt.setInt(24, i.getCpnFreq().intValue());
				}

				if (i.getResetIdx()== null){
					log.setter("set RESET_IDX value null");
					stmt.setNull(25, Types.VARCHAR);
				}else{
					log.setter("set RESET_IDX value "+i.getResetIdx());
					stmt.setString(25, i.getResetIdx());
				}

				if (i.getUnderlyingSecurityDes()== null){
					log.setter("set UND_SEC_DE value null");
					stmt.setNull(26, Types.VARCHAR);
				}else{
					log.setter("set UND_SEC_DE value "+i.getResetIdx());
					stmt.setString(26, i.getUnderlyingSecurityDes());
				}

				if (i.getDesNote()== null){
					log.setter("set DES_NOTES value null");
					stmt.setNull(27, Types.VARCHAR);
				}else{
					log.setter("set DES_NOTES value "+i.getResetIdx());
					stmt.setString(27, i.getDesNote());
				}

				if (i.getCntryOfRisk()== null){
					log.setter("set CNTRY_RISK value null");
					stmt.setNull(28, Types.VARCHAR);
				}else{
					log.setter("set CNTRY_RISK value "+i.getResetIdx());
					stmt.setString(28, i.getCntryOfRisk());
				}

				if (i.getRedempVal()== null){
					log.setter("set REDEMP_VAL value null");
					stmt.setNull(29, Types.DECIMAL);
				}else{
					log.setter("set REDEMP_VAL value "+i.getRedempVal());
					stmt.setBigDecimal(29, i.getRedempVal());
				}

				if (i.getPctParQuoted()== null){
					log.setter("set PCT_PAR_QU value null");
					stmt.setNull(30, Types.CHAR);
				}else{
					log.setter("set PCT_PAR_QU value "+i.getPctParQuoted().booleanValue());
					stmt.setString(30, i.getPctParQuoted().booleanValue()?"Y":"N");
				}

				if (i.getProRataSink()== null){
					log.setter("set PR_RT_SINK value null");
					stmt.setNull(31, Types.CHAR);
				}else{
					log.setter("set PR_RT_SINK value "+i.getProRataSink().booleanValue());
					stmt.setString(31, i.getProRataSink().booleanValue()?"Y":"N");
				}

				if (i.getSinkScheduleAmtTyp()== null){
					log.setter("set SINK_SC_TY value null");
					stmt.setNull(32, Types.VARCHAR);
				}else{
					log.setter("set SINK_SC_TY value "+i.getSinkScheduleAmtTyp());
					stmt.setString(32, i.getSinkScheduleAmtTyp());
				}

				if (i.getMostRecentReportedFactor()== null){
					log.setter("set REPFAC value null");
					stmt.setNull(33, Types.DECIMAL);
				}else{
					log.setter("set REPFAC value "+i.getMostRecentReportedFactor());
					stmt.setBigDecimal(33, i.getMostRecentReportedFactor());
				}

				if (i.getMostRecentReportedFactor()== null){
					log.setter("set SEC_FACT value null");
					stmt.setNull(34, Types.CHAR);
				}else{
					log.setter("set SEC_FACT value "+i.getSecurityFactorable().booleanValue());
					stmt.setString(34, i.getSecurityFactorable().booleanValue()?"Y":"N");
				}

				if (i.getInflationLinkedIndicator()== null){
					log.setter("set INF_LNK_IN value null");
					stmt.setNull(35, Types.CHAR);
				}else{
					log.setter("set INF_LNK_IN value "+i.getInflationLinkedIndicator().booleanValue());
					stmt.setString(35, i.getInflationLinkedIndicator().booleanValue()?"Y":"N");
				}

				if (i.getParAmt()== null){
					log.setter("set PAR_AMT value null");
					stmt.setNull(36, Types.DECIMAL);
				}else{
					log.setter("set PAR_AMT value "+i.getParAmt());
					stmt.setBigDecimal(36, i.getParAmt());
				}

				if (i.getPxLast()== null){
					log.setter("set PX_LAST value null");
					stmt.setNull(37, Types.DECIMAL);
				}else{
					log.setter("set PX_LAST value "+i.getPxLast());
					stmt.setBigDecimal(37, i.getPxLast());
				}

				if (i.getPxCloseDt()== null){
					log.setter("set PX_CLOSEDT value null");
					stmt.setNull(38, Types.INTEGER);
				}else{
					log.setter("set PX_CLOSEDT value "+i.getPxCloseDt().intValue());
					stmt.setInt(38, i.getPxCloseDt().intValue());
				}
				
				//"TFLCURDUB=?, "+//39
				if (i.getTflcurdub()== null){
					log.setter("set TFLCURDUB value null");
					stmt.setNull(39, Types.CHAR);
				}else{
					log.setter("set TFLCURDUB value "+i.getTflcurdub().booleanValue());
					stmt.setString(39, i.getTflcurdub().booleanValue()?"Y":"N");
				}
				//"TFLCURLIQ=?, "+//40
				if (i.getTflcurliq()== null){
					log.setter("set TFLCURLIQ value null");
					stmt.setNull(40, Types.CHAR);
				}else{
					log.setter("set TFLCURLIQ value "+i.getTflcurliq().booleanValue());
					stmt.setString(40, i.getTflcurliq().booleanValue()?"Y":"N");
				}
				//"TFLCURNEG=?, "+//41
				if (i.getTflcurneg()== null){
					log.setter("set TFLCURNEG value null");
					stmt.setNull(41, Types.CHAR);
				}else{
					log.setter("set TFLCURNEG value "+i.getTflcurneg().booleanValue());
					stmt.setString(41, i.getTflcurneg().booleanValue()?"Y":"N");
				}
				//"TFLGPER=?, "+//42
				if (i.getTflgper()== null){
					log.setter("set TFLGPER value null");
					stmt.setNull(42, Types.CHAR);
				}else{
					log.setter("set TFLGPER value "+i.getTflgper().booleanValue());
					stmt.setString(42, i.getTflgper().booleanValue()?"Y":"N");
				}
				//"TFLGEST=?, "+//43
				if (i.getTflgest()== null){
					log.setter("set TFLGEST value null");
					stmt.setNull(43, Types.CHAR);
				}else{
					log.setter("set TFLGEST value "+i.getTflgest().booleanValue());
					stmt.setString(43, i.getTflgest().booleanValue()?"Y":"N");
				}
				//"TFLAMORT=?, "+//44
				if (i.getTflamort()== null){
					log.setter("set TFLAMORT value null");
					stmt.setNull(44, Types.CHAR);
				}else{
					log.setter("set TFLAMORT value "+i.getTflamort().booleanValue());
					stmt.setString(44, i.getTflamort().booleanValue()?"Y":"N");
				}
				//"TFLGACCT=?, "+//45
				if (i.getTflgacct()== null){
					log.setter("set TFLGACCT value null");
					stmt.setNull(45, Types.CHAR);
				}else{
					log.setter("set TFLGACCT value "+i.getTflgacct().booleanValue());
					stmt.setString(45, i.getTflgacct().booleanValue()?"Y":"N");
				}
				//"TFLSTRUC=?, "+//46
				if (i.getTflstruc()== null){
					log.setter("set TFLSTRUC value null");
					stmt.setNull(46, Types.CHAR);
				}else{
					log.setter("set TFLSTRUC value "+i.getTflstruc().booleanValue());
					stmt.setString(46, i.getTflstruc().booleanValue()?"Y":"N");
				}
				
				log.setter("set UPDDATE");
				stmt.setTimestamp(47, new Timestamp(new Date().getTime()));
				log.setter("set UPDTYPE value U");
				stmt.setString(48, "U");
				log.setter("set UPDUSR value "+i.getUpdUsr());
				stmt.setString(49, i.getUpdUsr());

				if (i.getTtpbond()== null){
					log.setter("set TTPBOND value null");
					stmt.setNull(50, Types.CHAR);
				}else{
					log.setter("set TTPBOND value "+i.getTtpbond().booleanValue());
					stmt.setString(50, i.getTtpbond().booleanValue()?"Y":"N");
				}
				
				//where clause
				log.setter("set ISINCODE value "+i.getIsinCode());
				stmt.setString(51, i.getIsinCode());
				log.setter("set REQUESTID value "+i.getRequestId());
				stmt.setString(52, i.getRequestId());
				
				log.debug("update into INFOP.IFPTBNDDTH");
				toReturn=stmt.execute();
			}
			
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if (stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * 
	 * @param dto <code>boolean</code>
	 * @return <code>IfptBndDtHDTO</code>
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public boolean insertIfptDndDt(IfptBndDtHDTO dto) throws SendWarningException, SendBlockingException{
		log.debug("in boolean insertIfptDndDt(IfptBndDtHDTO dto) throws SendWarningException, SendBlockingException");
		
		String insertString = "INSERT INTO INFOP.IFPTBNDDTH(ISINCODE,REQUESTID,BLOOMCODE,SEC_DES,ST_ACC_DT,MATURITY,FINAL_MAT,MKTSECT,IS_CERTIF,ISSR_IND ,ISSUER ,CRNCY ,REDEM_CRNCY ,DUAL_CRCY,DAY_TO_ST,MTY_TYP,IS_PERPET,EXTENDIBLE,BULLET,CALL_TYP,STRUCT_NOT,LNK_BND_IN,LNK_BNDINF,CPN_TYP,CPN,CPN_FREQ,RESET_IDX,UND_SEC_DE,DES_NOTES,CNTRY_RISK,REDEMP_VAL,PCT_PAR_QU ,PR_RT_SINK ,SINK_SC_TY ,REPFAC,SEC_FACT,INF_LNK_IN ,PAR_AMT,PX_LAST,PX_CLOSEDT,TFLCURDUB, TFLCURLIQ, FLCURNEG, TFLGPER, TFLGEST, TFLAMORT, TFLGACCT, TFLSTRUC, UPDDATE,UPDTYPE ,UPDUSR,TTPBOND)"+ 
			   	  "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		log.debug("statement used "+insertString);
		boolean toReturn=false;
		log.debug("check data's consistency");
		if ((dto.getIsinCode()==null || dto.getIsinCode().equalsIgnoreCase(""))  || (dto.getRequestId()==null || dto.getRequestId().equalsIgnoreCase(""))){
			String field="";
			if (dto.getIsinCode()==null || dto.getIsinCode().equalsIgnoreCase(""))
				field+="ISINCODE ";
			
			if (dto.getRequestId()==null || dto.getRequestId().equalsIgnoreCase(""))
				field+="REQUESTID ";
			
			log.error("NoSuchFieldException: DATA INCOMPLETE "+field);
			throw new SendWarningException("DATA INCOMPLETE "+field);
		}
		log.debug("check ok");
		try {
			this.stmt = conn.prepareStatement(insertString);
			
			log.debug("statement instantiated start to popolate it");
			if (dto.getIsinCode()== null){
				log.setter("set ISINCODE value null");
				stmt.setNull(1, Types.VARCHAR);
			}else{
				log.setter("set ISINCODE value "+dto.getIsinCode());
				stmt.setString(1, dto.getIsinCode());
			}
			
			if (dto.getRequestId()== null){
				log.setter("set REQUESTID value null");
				stmt.setNull(2, Types.VARCHAR);
			}else{
				log.setter("set REQUESTID value "+dto.getRequestId());
				stmt.setString(2, dto.getRequestId());
			}
		
			if (dto.getBloomcode()== null){
				log.setter("set BLOOMCODE value null");
				stmt.setNull(3, Types.VARCHAR);
			}else{
				log.setter("set BLOOMCODE value "+dto.getBloomcode());
				stmt.setString(3, dto.getBloomcode());
			}
			
			if (dto.getSecurityDes()== null){
				log.setter("set SEC_DES value null");
				stmt.setNull(4, Types.VARCHAR);
			}else{
				log.setter("set SEC_DES value "+dto.getSecurityDes());
				stmt.setString(4, dto.getSecurityDes());
			}
			
			if (dto.getStartAccDt()== null){
				log.setter("set ST_ACC_DT value null");
				stmt.setNull(5, Types.INTEGER);
			}else{
				log.setter("set ST_ACC_DT value "+dto.getStartAccDt());
				stmt.setInt(5, dto.getStartAccDt());
			}
							
			if (dto.getMaturity()== null){
				log.setter("set MATURITY value null");
				stmt.setNull(6, Types.INTEGER);
			}else{
				log.setter("set MATURITY value "+dto.getMaturity());
				stmt.setInt(6, dto.getMaturity());
			}

			if (dto.getFinalMaturity()== null){
				log.setter("set FINAL_MAT value null");
				stmt.setNull(7, Types.INTEGER);
			}else{
				log.setter("set FINAL_MAT value "+dto.getFinalMaturity());
				stmt.setInt(7, dto.getFinalMaturity());
			}

			if (dto.getMarketSectorDes()== null){
				log.setter("set MKTSECT value null");
				stmt.setNull(8, Types.VARCHAR);
			}else{
				log.setter("set MKTSECT value "+dto.getMarketSectorDes());
				stmt.setString(8, dto.getMarketSectorDes());
			}
			
			if (dto.getCertificated()== null){
				log.setter("set IS_CERTIF value null");
				stmt.setNull(9, Types.CHAR);
			}else{
				log.setter("set IS_CERTIF value "+dto.getCertificated().booleanValue());
				stmt.setString(9, dto.getCertificated().booleanValue()?"Y":"N");
			}
			
			if (dto.getIssuerIndustry()== null){
				log.setter("set ISSR_IND value null");
				stmt.setNull(10, Types.VARCHAR);
			}else{
				log.setter("set ISSR_IND value "+dto.getIssuerIndustry());
				stmt.setString(10, dto.getIssuerIndustry());
			}
			
			if (dto.getIssuer()== null){
				log.setter("set ISSUER value null");
				stmt.setNull(11, Types.VARCHAR);
			}else{
				log.setter("set ISSUER value "+dto.getIssuer());
				stmt.setString(11, dto.getIssuer());
			}
			
			if (dto.getCrncy()== null){
				log.setter("set CRNCY value null");
				stmt.setNull(12, Types.VARCHAR);
			}else{
				log.setter("set CRNCY value "+dto.getCrncy());
				stmt.setString(12, dto.getCrncy());
			}
			
			if (dto.getRedempCrncy()== null){
				log.setter("set REDEM_CRNCY value null");
				stmt.setNull(13, Types.VARCHAR);
			}else{
				log.setter("set REDEM_CRNCY value "+dto.getRedempCrncy());
				stmt.setString(13, dto.getRedempCrncy());
			}
			
			if (dto.getDualCrncy()== null){
				log.setter("set DUAL_CRCY value null");
				stmt.setNull(14, Types.CHAR);
			}else{
				log.setter("set DUAL_CRCY value "+dto.getDualCrncy().booleanValue());
				stmt.setString(14, dto.getDualCrncy().booleanValue()?"Y":"N");
			}
			
			if (dto.getDayToSettle()== null){
				log.setter("set DAY_TO_ST value null");
				stmt.setNull(15, Types.INTEGER);
			}else{
				log.setter("set DAY_TO_ST value "+dto.getDayToSettle());
				stmt.setInt(15, dto.getDayToSettle().intValue());
			}
			
			if (dto.getMtyTyp()== null){
				log.setter("set MTY_TYP value null");
				stmt.setNull(16, Types.VARCHAR);
			}else{
				log.setter("set MTY_TYP value "+dto.getMtyTyp());
				stmt.setString(16, dto.getMtyTyp());
			}

			if (dto.getPerpetual()== null){
				log.setter("set IS_PERPET value null");
				stmt.setNull(17, Types.CHAR);
			}else{
				log.setter("set IS_PERPET value "+dto.getPerpetual().booleanValue());
				stmt.setString(17, dto.getPerpetual().booleanValue()?"Y":"N");
			}
			
			if (dto.getExtendible()== null){
				log.setter("set EXTENDIBLE value null");
				stmt.setNull(18, Types.CHAR);
			}else{
				log.setter("set EXTENDIBLE value "+dto.getExtendible().booleanValue());
				stmt.setString(18, dto.getExtendible().booleanValue()?"Y":"N");
			}
			
			if (dto.getBullet()== null){
				log.setter("set BULLET value null");
				stmt.setNull(19, Types.CHAR);
			}else{
				log.setter("set BULLET value "+dto.getBullet().booleanValue());
				stmt.setString(19, dto.getBullet().booleanValue()?"Y":"N");
			}

			if (dto.getCallType()== null){
				log.setter("set CALL_TYP value null");
				stmt.setNull(20, Types.VARCHAR);
			}else{
				log.setter("set CALL_TYP value "+dto.getCallType());
				stmt.setString(20, dto.getCallType());
			}

			if (dto.getStructuredNote()== null){
				log.setter("set STRUCT_NOT value null");
				stmt.setNull(21, Types.CHAR);
			}else{
				log.setter("set STRUCT_NOT value "+dto.getStructuredNote().booleanValue());
				stmt.setString(21, dto.getStructuredNote().booleanValue()?"Y":"N");
			}

			if (dto.getLinkedBondInd()== null){
				log.setter("set LNK_BND_IN value null");
				stmt.setNull(22, Types.CHAR);
			}else{
				log.setter("set LNK_BND_IN value "+dto.getLinkedBondInd().booleanValue());
				stmt.setString(22, dto.getLinkedBondInd().booleanValue()?"Y":"N");
			}

			if (dto.getLinkedBondInfo()== null){
				log.setter("set LNK_BNDINF value null");
				stmt.setNull(23, Types.VARCHAR);
			}else{
				log.setter("set LNK_BNDINF value "+dto.getLinkedBondInfo());
				stmt.setString(23, dto.getLinkedBondInfo());
			}


			if (dto.getCpnTyp()== null){
				log.setter("set CPN_TYP value null");
				stmt.setNull(24, Types.VARCHAR);
			}else{
				log.setter("set CPN_TYP value "+dto.getCpnTyp());
				stmt.setString(24, dto.getCpnTyp());
			}

			if (dto.getCpnTyp()== null){
				log.setter("set CPN value null");
				stmt.setNull(25, Types.DECIMAL);
			}else{
				log.setter("set CPN value "+dto.getCpnTyp());
				stmt.setBigDecimal(25, dto.getCpn());
			}

			if (dto.getCpnFreq()== null){
				log.setter("set CPN_FREQ value null");
				stmt.setNull(26, Types.INTEGER);
			}else{
				log.setter("set CPN_FREQ value "+dto.getCpnFreq());
				stmt.setInt(26, dto.getCpnFreq().intValue());
			}

			if (dto.getResetIdx()== null){
				log.setter("set RESET_IDX value null");
				stmt.setNull(27, Types.VARCHAR);
			}else{
				log.setter("set RESET_IDX value "+dto.getResetIdx());
				stmt.setString(27, dto.getResetIdx());
			}

			if (dto.getUnderlyingSecurityDes()== null){
				log.setter("set UND_SEC_DE value null");
				stmt.setNull(28, Types.VARCHAR);
			}else{
				log.setter("set UND_SEC_DE value "+dto.getResetIdx());
				stmt.setString(28, dto.getUnderlyingSecurityDes());
			}

			if (dto.getDesNote()== null){
				log.setter("set DES_NOTES value null");
				stmt.setNull(29, Types.VARCHAR);
			}else{
				log.setter("set DES_NOTES value "+dto.getDesNote());
				stmt.setString(29, dto.getDesNote());
			}
			
			if (dto.getCntryOfRisk()== null){
				log.setter("set CNTRY_RISK value null");
				stmt.setNull(30, Types.VARCHAR);
			}else{
				log.setter("set CNTRY_RISK value "+dto.getCntryOfRisk());
				stmt.setString(30, dto.getCntryOfRisk());
			}
	
			if (dto.getRedempVal()== null){
				log.setter("set REDEMP_VAL value null");
				stmt.setNull(31, Types.DECIMAL);
			}else{
				log.setter("set REDEMP_VAL value "+dto.getRedempVal());
				stmt.setBigDecimal(31, dto.getRedempVal());
			}

			if (dto.getPctParQuoted()== null){
				log.setter("set PCT_PAR_QU value null");
				stmt.setNull(32, Types.CHAR);
			}else{
				log.setter("set PCT_PAR_QU value "+dto.getPctParQuoted().booleanValue());
				stmt.setString(32, dto.getPctParQuoted().booleanValue()?"Y":"N");
			}

			if (dto.getProRataSink()== null){
				log.setter("set PR_RT_SINK value null");
				stmt.setNull(33, Types.CHAR);
			}else{
				log.setter("set PR_RT_SINK value "+dto.getProRataSink().booleanValue());
				stmt.setString(33, dto.getProRataSink().booleanValue()?"Y":"N");
			}

			if (dto.getSinkScheduleAmtTyp()== null){
				log.setter("set SINK_SC_TY value null");
				stmt.setNull(34, Types.VARCHAR);
			}else{
				log.setter("set SINK_SC_TY value "+dto.getSinkScheduleAmtTyp());
				stmt.setString(34, dto.getSinkScheduleAmtTyp());
			}

			if (dto.getMostRecentReportedFactor()== null){
				log.setter("set REPFAC value null");
				stmt.setNull(35, Types.DECIMAL);
			}else{
				log.setter("set REPFAC value "+dto.getMostRecentReportedFactor());
				stmt.setBigDecimal(35, dto.getMostRecentReportedFactor());
			}

			if (dto.getMostRecentReportedFactor()== null){
				log.setter("set SEC_FACT value null");
				stmt.setNull(36, Types.CHAR);
			}else{
				log.setter("set SEC_FACT value "+dto.getSecurityFactorable().booleanValue());
				stmt.setString(36, dto.getSecurityFactorable().booleanValue()?"Y":"N");
			}

			if (dto.getInflationLinkedIndicator()== null){
				log.setter("set INF_LNK_IN value null");
				stmt.setNull(37, Types.CHAR);
			}else{
				log.setter("set INF_LNK_IN value "+dto.getInflationLinkedIndicator().booleanValue());
				stmt.setString(37, dto.getInflationLinkedIndicator().booleanValue()?"Y":"N");
			}

			if (dto.getParAmt()== null){
				log.setter("set PAR_AMT value null");
				stmt.setNull(38, Types.DECIMAL);
			}else{
				log.setter("set PAR_AMT value "+dto.getParAmt());
				stmt.setBigDecimal(38, dto.getParAmt());
			}

			if (dto.getPxLast()== null){
				log.setter("set PX_LAST value null");
				stmt.setNull(39, Types.DECIMAL);
			}else{
				log.setter("set PX_LAST value "+dto.getPxLast());
				stmt.setBigDecimal(39, dto.getPxLast());
			}

			if (dto.getPxCloseDt()== null){
				log.setter("set PX_CLOSEDT value null");
				stmt.setNull(40, Types.INTEGER);
			}else{
				log.setter("set PX_CLOSEDT value "+dto.getPxCloseDt().intValue());
				stmt.setInt(40, dto.getPxCloseDt().intValue());
			}

			//TFLCURDUB, 
			if (dto.getTflcurdub()== null){
				log.setter("set TFLCURDUB value null");
				stmt.setNull(41, Types.CHAR);
			}else{
				log.setter("set TFLCURDUB value "+dto.getTflcurdub().booleanValue());
				stmt.setString(41, dto.getTflcurdub().booleanValue()?"Y":"N");
			}
			//TFLCURLIQ, 
			if (dto.getTflcurliq()== null){
				log.setter("set TFLCURLIQ value null");
				stmt.setNull(42, Types.CHAR);
			}else{
				log.setter("set TFLCURLIQ value "+dto.getTflcurliq().booleanValue());
				stmt.setString(42, dto.getTflcurliq().booleanValue()?"Y":"N");
			}
			//TFLCURNEG, 
			if (dto.getTflcurneg()== null){
				log.setter("set TFLCURNEG value null");
				stmt.setNull(43, Types.CHAR);
			}else{
				log.setter("set TFLCURNEG value "+dto.getTflcurneg().booleanValue());
				stmt.setString(43, dto.getTflcurneg().booleanValue()?"Y":"N");
			}
			//TFLGPER, 
			if (dto.getTflgper()== null){
				log.setter("set TFLGPER value null");
				stmt.setNull(44, Types.CHAR);
			}else{
				log.setter("set TFLGPER value "+dto.getTflgper().booleanValue());
				stmt.setString(44, dto.getTflgper().booleanValue()?"Y":"N");
			}
			//TFLGEST, 
			if (dto.getTflgest()== null){
				log.setter("set TFLGEST value null");
				stmt.setNull(45, Types.CHAR);
			}else{
				log.setter("set TFLGEST value "+dto.getTflgest().booleanValue());
				stmt.setString(45, dto.getTflgest().booleanValue()?"Y":"N");
			}
			//TFLAMORT,
			if (dto.getTflamort()== null){
				log.setter("set TFLAMORT value null");
				stmt.setNull(46, Types.CHAR);
			}else{
				log.setter("set TFLAMORT value "+dto.getTflamort().booleanValue());
				stmt.setString(46, dto.getTflamort().booleanValue()?"Y":"N");
			}
			//TFLGACCT, 
			if (dto.getTflgacct()== null){
				log.setter("set TFLAMORT value null");
				stmt.setNull(47, Types.CHAR);
			}else{
				log.setter("set TFLAMORT value "+dto.getTflgacct().booleanValue());
				stmt.setString(47, dto.getTflgacct().booleanValue()?"Y":"N");
			}
			//TFLSTRUC, 
			if (dto.getTflstruc()== null){
				log.setter("set TFLSTRUC value null");
				stmt.setNull(48, Types.CHAR);
			}else{
				log.setter("set TFLSTRUC value "+dto.getTflstruc().booleanValue());
				stmt.setString(48, dto.getTflstruc().booleanValue()?"Y":"N");
			}
			
			log.setter("set UPDDATE");
			stmt.setTimestamp(49, new Timestamp(new Date().getTime()));
			log.setter("set UPDTYPE value I");
			stmt.setString(50, "I");
			log.setter("set UPDUSR value "+dto.getUpdUsr());
			stmt.setString(51, dto.getUpdUsr());
			if (dto.getTtpbond() == null){
				log.setter("set TTPBOND value null");
				stmt.setNull(52, Types.CHAR);
			}else{
				log.setter("set TTPBOND value "+dto.getTtpbond().booleanValue());
				stmt.setString(52, dto.getTtpbond().booleanValue()?"Y":"N");
			}
			log.debug("insert into INFOP.IFPTBNDDTH");
			toReturn=stmt.execute();

			
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if (stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * 
	 * @param dto <code>boolean</code>
	 * @return <code>IfptBndDtHDTO</code>
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public boolean updateIfptDndDt(IfptBndDtHDTO dto) throws SendWarningException, SendBlockingException{
		log.debug("in boolean updateIfptDndDt(IfptBndDtHDTO dto) throws SendWarningException, SendBlockingException");
		String updateString = "UPDATE INFOP.IFPTBNDDTH SET BLOOMCODE = ?, " + //1
															"SEC_DES=?, "+ //2
															"ST_ACC_DT=?, "+ //3
															"MATURITY= ?, "+ //4
															"FINAL_MAT=?, "+ //5
															"MKTSECT=?, "+ //6
															"IS_CERTIF=?, "+ //7
															"ISSR_IND=? , "+ //8
															"ISSUER=? , "+ //9
															"CRNCY=? , "+ //10
															"REDEM_CRNCY=? , "+ //11
															"DUAL_CRCY=?, "+ //12
															"DAY_TO_ST=?, "+ //13
															"MTY_TYP=?, "+ //14
															"IS_PERPET=?, "+ //15
															"EXTENDIBLE=?, "+ //16
															"BULLET=?, "+ //17
															"CALL_TYP=?, "+ //18
															"STRUCT_NOT=?, "+ //19
															"LNK_BND_IN=?, "+ //20
															"LNK_BNDINF=?, "+ //21
															"CPN_TYP=?, "+ //22
															"CPN=?, "+ //23
															"CPN_FREQ=?, "+ //24
															"RESET_IDX=?, "+ //25
															"UND_SEC_DE=?, "+ //26
															"DES_NOTES=?, "+ //27
															"CNTRY_RISK=?, "+ //28
															"REDEMP_VAL=?, "+ //29
															"PCT_PAR_QU=? , "+ //30
															"PR_RT_SINK=? , "+ //31
															"SINK_SC_TY =?, "+ //32
															"REPFAC=?, "+ //33
															"SEC_FACT=?, "+ //34
															"INF_LNK_IN =?, "+ //35
															"PAR_AMT=?, "+ //36
															"PX_LAST=?, "+ //37
															"PX_CLOSEDT=?, "+ //38
															"TFLCURDUB=?, "+//39
															"TFLCURLIQ=?, "+//40
															"TFLCURNEG=?, "+//41
															"TFLGPER=?, "+//42
															"TFLGEST=?, "+//43
															"TFLAMORT=?, "+//44
															"TFLGACCT=?, "+//45
															"TFLSTRUC=?, "+//46
															"UPDDATE=?, "+ //47
															"UPDTYPE=? , "+ //48
															"UPDUSR=?,"+  //49
															"TTPBOND=?"+ //50
													   "WHERE ISINCODE = ? " + //51
													   	 "AND REQUESTID =?"; //52
		log.debug("statement used "+updateString);
		boolean toReturn=false;
		log.debug("check data's consistency");
		if ((dto.getIsinCode()==null || dto.getIsinCode().equalsIgnoreCase(""))  || (dto.getRequestId()==null || dto.getRequestId().equalsIgnoreCase(""))){
			String field="";
			if (dto.getIsinCode()==null || dto.getIsinCode().equalsIgnoreCase(""))
				field+="ISINCODE ";
			
			if (dto.getRequestId()==null || dto.getRequestId().equalsIgnoreCase(""))
				field+="REQUESTID ";
			
			log.error("NoSuchFieldException: DATA INCOMPLETE "+field);
			throw new SendWarningException("DATA INCOMPLETE "+field);
		}

		log.debug("check ok");
		log.setter("statement used "+updateString);
		try {
			this.stmt = conn.prepareStatement(updateString);
			
			log.debug("statement instantiated start to popolate it");
			if (dto.getBloomcode()== null){
				log.setter("set BLOOMCODE value null");
				stmt.setNull(1, Types.VARCHAR);
			}else{
				log.setter("set BLOOMCODE value "+dto.getBloomcode());
				stmt.setString(1, dto.getBloomcode());
			}

			if (dto.getSecurityDes()== null){
				log.setter("set SEC_DES value null");
				stmt.setNull(2, Types.VARCHAR);
			}else{
				log.setter("set SEC_DES value "+dto.getSecurityDes());
				stmt.setString(2, dto.getSecurityDes());
			}

			if (dto.getStartAccDt()== null){
				log.setter("set ST_ACC_DT value null");
				stmt.setNull(3, Types.INTEGER);
			}else{
				log.setter("set ST_ACC_DT value "+dto.getStartAccDt());
				stmt.setInt(3, dto.getStartAccDt());
			}
			
			if (dto.getMaturity()== null){
				log.setter("set MATURITY value null");
				stmt.setNull(4, Types.INTEGER);
			}else{
				log.setter("set MATURITY value "+dto.getMaturity());
				stmt.setInt(4, dto.getMaturity());
			}

			if (dto.getFinalMaturity()== null){
				log.setter("set FINAL_MAT value null");
				stmt.setNull(5, Types.INTEGER);
			}else{
				log.setter("set FINAL_MAT value "+dto.getFinalMaturity());
				stmt.setInt(5, dto.getFinalMaturity());
			}

			if (dto.getMarketSectorDes()== null){
				log.setter("set MKTSECT value null");
				stmt.setNull(6, Types.VARCHAR);
			}else{
				log.setter("set MKTSECT value "+dto.getMarketSectorDes());
				stmt.setString(6, dto.getMarketSectorDes());
			}

			if (dto.getCertificated()== null){
				log.setter("set IS_CERTIF value null");
				stmt.setNull(7, Types.CHAR);
			}else{
				log.setter("set IS_CERTIF value "+dto.getCertificated().booleanValue());
				stmt.setString(7, dto.getCertificated().booleanValue()?"Y":"N");
			}

			if (dto.getIssuerIndustry()== null){
				log.setter("set ISSR_IND value null");
				stmt.setNull(8, Types.VARCHAR);
			}else{
				log.setter("set ISSR_IND value "+dto.getIssuerIndustry());
				stmt.setString(8, dto.getIssuerIndustry());
			}

			if (dto.getIssuer()== null){
				log.setter("set ISSUER value null");
				stmt.setNull(9, Types.VARCHAR);
			}else{
				log.setter("set ISSUER value "+dto.getIssuer());
				stmt.setString(9, dto.getIssuer());
			}

			if (dto.getCrncy()== null){
				log.setter("set CRNCY value null");
				stmt.setNull(10, Types.VARCHAR);
			}else{
				log.setter("set CRNCY value "+dto.getCrncy());
				stmt.setString(10, dto.getCrncy());
			}

			if (dto.getRedempCrncy()== null){
				log.setter("set REDEM_CRNCY value null");
				stmt.setNull(11, Types.VARCHAR);
			}else{
				log.setter("set REDEM_CRNCY value "+dto.getRedempCrncy());
				stmt.setString(11, dto.getRedempCrncy());
			}

			if (dto.getDualCrncy()== null){
				log.setter("set DUAL_CRCY value null");
				stmt.setNull(12, Types.CHAR);
			}else{
				log.setter("set DUAL_CRCY value "+dto.getDualCrncy().booleanValue());
				stmt.setString(12, dto.getDualCrncy().booleanValue()?"Y":"N");
			}

			if (dto.getDayToSettle()== null){
				log.setter("set DAY_TO_ST value null");
				stmt.setNull(13, Types.INTEGER);
			}else{
				log.setter("set DAY_TO_ST value "+dto.getDayToSettle());
				stmt.setInt(13, dto.getDayToSettle().intValue());
			}

			if (dto.getMtyTyp()== null){
				log.setter("set MTY_TYP value null");
				stmt.setNull(14, Types.VARCHAR);
			}else{
				log.setter("set MTY_TYP value "+dto.getMtyTyp());
				stmt.setString(14, dto.getMtyTyp());
			}

			if (dto.getPerpetual()== null){
				log.setter("set IS_PERPET value null");
				stmt.setNull(15, Types.CHAR);
			}else{
				log.setter("set IS_PERPET value "+dto.getPerpetual().booleanValue());
				stmt.setString(15, dto.getPerpetual().booleanValue()?"Y":"N");
			}

			if (dto.getExtendible()== null){
				log.setter("set EXTENDIBLE value null");
				stmt.setNull(16, Types.CHAR);
			}else{
				log.setter("set EXTENDIBLE value "+dto.getExtendible().booleanValue());
				stmt.setString(16, dto.getExtendible().booleanValue()?"Y":"N");
			}

			if (dto.getBullet()== null){
				log.setter("set BULLET value null");
				stmt.setNull(17, Types.CHAR);
			}else{
				log.setter("set BULLET value "+dto.getBullet().booleanValue());
				stmt.setString(17, dto.getBullet().booleanValue()?"Y":"N");
			}

			if (dto.getCallType()== null){
				log.setter("set CALL_TYP value null");
				stmt.setNull(18, Types.VARCHAR);
			}else{
				log.setter("set CALL_TYP value "+dto.getCallType());
				stmt.setString(18, dto.getCallType());
			}

			if (dto.getStructuredNote()== null){
				log.setter("set STRUCT_NOT value null");
				stmt.setNull(19, Types.CHAR);
			}else{
				log.setter("set STRUCT_NOT value "+dto.getStructuredNote().booleanValue());
				stmt.setString(19, dto.getStructuredNote().booleanValue()?"Y":"N");
			}

			if (dto.getLinkedBondInd()== null){
				log.setter("set LNK_BND_IN value null");
				stmt.setNull(20, Types.CHAR);
			}else{
				log.setter("set LNK_BND_IN value "+dto.getLinkedBondInd().booleanValue());
				stmt.setString(20, dto.getLinkedBondInd().booleanValue()?"Y":"N");
			}

			if (dto.getLinkedBondInfo()== null){
				log.setter("set LNK_BNDINF value null");
				stmt.setNull(21, Types.VARCHAR);
			}else{
				log.setter("set LNK_BNDINF value "+dto.getLinkedBondInfo());
				stmt.setString(21, dto.getLinkedBondInfo());
			}

			if (dto.getCpnTyp()== null){
				log.setter("set CPN_TYP value null");
				stmt.setNull(22, Types.VARCHAR);
			}else{
				log.setter("set CPN_TYP value "+dto.getCpnTyp());
				stmt.setString(22, dto.getCpnTyp());
			}

			if (dto.getCpnTyp()== null){
				log.setter("set CPN value null");
				stmt.setNull(23, Types.DECIMAL);
			}else{
				log.setter("set CPN value "+dto.getCpnTyp());
				stmt.setBigDecimal(23, dto.getCpn());
			}

			if (dto.getCpnFreq()== null){
				log.setter("set CPN_FREQ value null");
				stmt.setNull(24, Types.INTEGER);
			}else{
				log.setter("set CPN_FREQ value "+dto.getCpnFreq());
				stmt.setInt(24, dto.getCpnFreq().intValue());
			}

			if (dto.getResetIdx()== null){
				log.setter("set RESET_IDX value null");
				stmt.setNull(25, Types.VARCHAR);
			}else{
				log.setter("set RESET_IDX value "+dto.getResetIdx());
				stmt.setString(25, dto.getResetIdx());
			}

			if (dto.getUnderlyingSecurityDes()== null){
				log.setter("set UND_SEC_DE value null");
				stmt.setNull(26, Types.VARCHAR);
			}else{
				log.setter("set UND_SEC_DE value "+dto.getResetIdx());
				stmt.setString(26, dto.getUnderlyingSecurityDes());
			}

			if (dto.getDesNote()== null){
				log.setter("set DES_NOTES value null");
				stmt.setNull(27, Types.VARCHAR);
			}else{
				log.setter("set DES_NOTES value "+dto.getResetIdx());
				stmt.setString(27, dto.getDesNote());
			}

			if (dto.getCntryOfRisk()== null){
				log.setter("set CNTRY_RISK value null");
				stmt.setNull(28, Types.VARCHAR);
			}else{
				log.setter("set CNTRY_RISK value "+dto.getResetIdx());
				stmt.setString(28, dto.getCntryOfRisk());
			}

			if (dto.getRedempVal()== null){
				log.setter("set REDEMP_VAL value null");
				stmt.setNull(29, Types.DECIMAL);
			}else{
				log.setter("set REDEMP_VAL value "+dto.getRedempVal());
				stmt.setBigDecimal(29, dto.getRedempVal());
			}

			if (dto.getPctParQuoted()== null){
				log.setter("set PCT_PAR_QU value null");
				stmt.setNull(30, Types.CHAR);
			}else{
				log.setter("set PCT_PAR_QU value "+dto.getPctParQuoted().booleanValue());
				stmt.setString(30, dto.getPctParQuoted().booleanValue()?"Y":"N");
			}

			if (dto.getProRataSink()== null){
				log.setter("set PR_RT_SINK value null");
				stmt.setNull(31, Types.CHAR);
			}else{
				log.setter("set PR_RT_SINK value "+dto.getProRataSink().booleanValue());
				stmt.setString(31, dto.getProRataSink().booleanValue()?"Y":"N");
			}

			if (dto.getSinkScheduleAmtTyp()== null){
				log.setter("set SINK_SC_TY value null");
				stmt.setNull(32, Types.VARCHAR);
			}else{
				log.setter("set SINK_SC_TY value "+dto.getSinkScheduleAmtTyp());
				stmt.setString(32, dto.getSinkScheduleAmtTyp());
			}

			if (dto.getMostRecentReportedFactor()== null){
				log.setter("set REPFAC value null");
				stmt.setNull(33, Types.DECIMAL);
			}else{
				log.setter("set REPFAC value "+dto.getMostRecentReportedFactor());
				stmt.setBigDecimal(33, dto.getMostRecentReportedFactor());
			}

			if (dto.getMostRecentReportedFactor()== null){
				log.setter("set SEC_FACT value null");
				stmt.setNull(34, Types.CHAR);
			}else{
				log.setter("set SEC_FACT value "+dto.getSecurityFactorable().booleanValue());
				stmt.setString(34, dto.getSecurityFactorable().booleanValue()?"Y":"N");
			}

			if (dto.getInflationLinkedIndicator()== null){
				log.setter("set INF_LNK_IN value null");
				stmt.setNull(35, Types.CHAR);
			}else{
				log.setter("set INF_LNK_IN value "+dto.getInflationLinkedIndicator().booleanValue());
				stmt.setString(35, dto.getInflationLinkedIndicator().booleanValue()?"Y":"N");
			}

			if (dto.getParAmt()== null){
				log.setter("set PAR_AMT value null");
				stmt.setNull(36, Types.DECIMAL);
			}else{
				log.setter("set PAR_AMT value "+dto.getParAmt());
				stmt.setBigDecimal(36, dto.getParAmt());
			}

			if (dto.getPxLast()== null){
				log.setter("set PX_LAST value null");
				stmt.setNull(37, Types.DECIMAL);
			}else{
				log.setter("set PX_LAST value "+dto.getPxLast());
				stmt.setBigDecimal(37, dto.getPxLast());
			}

			if (dto.getPxCloseDt()== null){
				log.setter("set PX_CLOSEDT value null");
				stmt.setNull(38, Types.INTEGER);
			}else{
				log.setter("set PX_CLOSEDT value "+dto.getPxCloseDt().intValue());
				stmt.setInt(38, dto.getPxCloseDt().intValue());
			}
			
			//"TFLCURDUB=?, "+//39
			if (dto.getTflcurdub()== null){
				log.setter("set TFLCURDUB value null");
				stmt.setNull(39, Types.CHAR);
			}else{
				log.setter("set TFLCURDUB value "+dto.getTflcurdub().booleanValue());
				stmt.setString(39, dto.getTflcurdub().booleanValue()?"Y":"N");
			}
			//"TFLCURLIQ=?, "+//40
			if (dto.getTflcurliq()== null){
				log.setter("set TFLCURLIQ value null");
				stmt.setNull(40, Types.CHAR);
			}else{
				log.setter("set TFLCURLIQ value "+dto.getTflcurliq().booleanValue());
				stmt.setString(40, dto.getTflcurliq().booleanValue()?"Y":"N");
			}
			//"TFLCURNEG=?, "+//41
			if (dto.getTflcurneg()== null){
				log.setter("set TFLCURNEG value null");
				stmt.setNull(41, Types.CHAR);
			}else{
				log.setter("set TFLCURNEG value "+dto.getTflcurneg().booleanValue());
				stmt.setString(41, dto.getTflcurneg().booleanValue()?"Y":"N");
			}
			//"TFLGPER=?, "+//42
			if (dto.getTflgper()== null){
				log.setter("set TFLGPER value null");
				stmt.setNull(42, Types.CHAR);
			}else{
				log.setter("set TFLGPER value "+dto.getTflgper().booleanValue());
				stmt.setString(42, dto.getTflgper().booleanValue()?"Y":"N");
			}
			//"TFLGEST=?, "+//43
			if (dto.getTflgest()== null){
				log.setter("set TFLGEST value null");
				stmt.setNull(43, Types.CHAR);
			}else{
				log.setter("set TFLGEST value "+dto.getTflgest().booleanValue());
				stmt.setString(43, dto.getTflgest().booleanValue()?"Y":"N");
			}
			//"TFLAMORT=?, "+//44
			if (dto.getTflamort()== null){
				log.setter("set TFLAMORT value null");
				stmt.setNull(44, Types.CHAR);
			}else{
				log.setter("set TFLAMORT value "+dto.getTflamort().booleanValue());
				stmt.setString(44, dto.getTflamort().booleanValue()?"Y":"N");
			}
			//"TFLGACCT=?, "+//45
			if (dto.getTflgacct()== null){
				log.setter("set TFLGACCT value null");
				stmt.setNull(45, Types.CHAR);
			}else{
				log.setter("set TFLGACCT value "+dto.getTflgacct().booleanValue());
				stmt.setString(45, dto.getTflgacct().booleanValue()?"Y":"N");
			}
			//"TFLSTRUC=?, "+//46
			if (dto.getTflstruc()== null){
				log.setter("set TFLSTRUC value null");
				stmt.setNull(46, Types.CHAR);
			}else{
				log.setter("set TFLSTRUC value "+dto.getTflstruc().booleanValue());
				stmt.setString(46, dto.getTflstruc().booleanValue()?"Y":"N");
			}
			
			log.setter("set UPDDATE");
			stmt.setTimestamp(47, new Timestamp(new Date().getTime()));
			log.setter("set UPDTYPE value U");
			stmt.setString(48, "U");
			log.setter("set UPDUSR value "+dto.getUpdUsr());
			stmt.setString(49, dto.getUpdUsr());
			if (dto.getTtpbond()== null){
				log.setter("set TTPBOND value null");
				stmt.setNull(50, Types.CHAR);
			}else{
				log.setter("set TTPBOND value "+dto.getTtpbond().booleanValue());
				stmt.setString(50, dto.getTtpbond().booleanValue()?"Y":"N");
			}
			//where clause
			log.setter("set ISINCODE value "+dto.getIsinCode());
			stmt.setString(51, dto.getIsinCode());
			log.setter("set REQUESTID value "+dto.getRequestId());
			stmt.setString(52, dto.getRequestId());
			
			log.debug("update into INFOP.IFPTBNDDTH");
			toReturn=stmt.execute();
			
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if (stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * 
	 * @param dto <code>IfptBndDtHDTO</code>
	 * @return <code>List<IfptBndDtHDTO></code> 
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public List<IfptBndDtHDTO> retrieveIfptBndDtByISINCODE(IfptBndDtHDTO dto) throws SendWarningException, SendBlockingException{
		log.debug("in List<IfptBndDtHDTO> retrieveIfptBndDtByISINCODE(IfptBndDtHDTO dto) throws SendWarningException, SendBlockingException");
		String retrieveString = "SELECT REQUESTID,"+ //1
										" BLOOMCODE,"+//2
										" SEC_DES,"+//3
										" ST_ACC_DT,"+//4
										" MATURITY,"+//5
										" FINAL_MAT,"+//6
										" MKTSECT,"+//7
										" IS_CERTIF,"+//8
										" ISSR_IND,"+//9
										" ISSUER,"+//10
										" CRNCY,"+//11
										" REDEM_CRNCY,"+//12
										" DUAL_CRCY,"+//13
										" DAY_TO_ST,"+//14
										" MTY_TYP,"+//15
										" IS_PERPET,"+//16
										" EXTENDIBLE,"+//17
										" BULLET,"+//18
										" CALL_TYP,"+//19
										" STRUCT_NOT,"+//20
										" LNK_BND_IN,"+//21
										" LNK_BNDINF,"+//22
										" CPN_TYP,"+//23
										" CPN,"+//24
										" CPN_FREQ,"+//25
										" RESET_IDX,"+//26
										" UND_SEC_DE,"+//27
										" DES_NOTES,"+//28
										" CNTRY_RISK,"+//29
										" REDEMP_VAL,"+//30
										" PCT_PAR_QU,"+//31
										" PR_RT_SINK,"+//32
										" SINK_SC_TY,"+//33
										" REPFAC,"+//34
										" SEC_FACT,"+//35
										" INF_LNK_IN,"+//36
										" PAR_AMT,"+//37
										" PX_LAST,"+//38
										" PX_CLOSEDT,"+//39
										" TFLCURDUB, "+//40
										" TFLCURLIQ,"+//41
										" TFLCURNEG,"+//42
										" TFLGPER,"+//43
										" TFLGEST,"+//44
										" TFLAMORT,"+//45
										" TFLGACCT,"+//46
										" TFLSTRUC,"+//47
										" UPDDATE,"+//48
										" UPDTYPE,"+//49
										" UPDUSR,"+//50
										" TTPBOND"+//51
							     " FROM INFOP.IFPTBNDDTH "+
							    " WHERE ISINCODE = ?";
		
		log.debug("statement used "+retrieveString);
		log.debug("check data's consistency");
		if (dto.getIsinCode()==null || dto.getIsinCode().equalsIgnoreCase("")){
			log.error("NoSuchFieldException: DATA INCOMPLETE ISINCODE");
			throw new SendWarningException("DATA INCOMPLETE ISINCODE");
		}
		log.debug("check ok");
		log.setter("statement used "+retrieveString);
		List<IfptBndDtHDTO> toReturn=null;
		try {
			stmt = conn.prepareStatement(retrieveString);
			log.debug("set ISINCODE value "+dto.getIsinCode());
			stmt.setString(1, dto.getIsinCode());
			
			log.debug("execute query");
			this.rs = stmt.executeQuery();
			log.debug("query executed...read data");
			toReturn= new ArrayList<IfptBndDtHDTO>();
			while(rs.next()){
				IfptBndDtHDTO appo = new IfptBndDtHDTO();
				appo.setIsinCode(dto.getIsinCode());
				log.setter("get REQUESTID value "+rs.getString(1));
				appo.setRequestId(rs.getString(1));
				log.setter("get BLOOMCODE value "+rs.getString(2));
				appo.setBloomcode(rs.getString(2));
				log.setter("get SEC_DES value "+rs.getString(3));
				appo.setSecurityDes(rs.getString(3));
				log.setter("get ST_ACC_DT value "+rs.getInt(4));
				appo.setStartAccDt(new Integer(rs.getInt(4)));
				log.setter("get MATURITY value "+rs.getInt(5));
				appo.setMaturity(new Integer(rs.getInt(5)));
				log.setter("get FINAL_MAT value "+rs.getInt(6));
				appo.setFinalMaturity(new Integer(rs.getInt(6)));
				log.setter("get MKTSECT value "+rs.getString(7));
				appo.setMarketSectorDes(rs.getString(7));
				log.setter("get IS_CERTIF value "+rs.getString(8));
				if(rs.getString(8)!=null && !rs.getString(8).equalsIgnoreCase("")){
					appo.setCertificated(rs.getString(8).equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				}else{
					appo.setCertificated(null);
				}
				log.setter("get ISSR_IND value "+rs.getString(9));
				appo.setIssuerIndustry(rs.getString(9));
				log.setter("get ISSUER value "+rs.getString(10));
				appo.setIssuer(rs.getString(10));
				log.setter("get CRNCY value "+rs.getString(11));
				appo.setCrncy(rs.getString(11));
				log.setter("get REDEM_CRNCY value "+rs.getString(12));
				appo.setRedempCrncy(rs.getString(12));
				log.setter("get DUAL_CRCY value "+rs.getString(13));
				if(rs.getString(13)!=null && !rs.getString(13).equalsIgnoreCase("")){
					appo.setDualCrncy(rs.getString(13).equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				}else{
					appo.setDualCrncy(null);
				}
				log.setter("get DAY_TO_ST value "+rs.getInt(14));
				appo.setDayToSettle(new Integer(rs.getInt(14)));
				log.setter("get MTY_TYP value "+rs.getString(15));
				appo.setMtyTyp(rs.getString(15));
				log.setter("get IS_PERPET value "+rs.getString(16));
				if(rs.getString(16)!=null && !rs.getString(16).equalsIgnoreCase("")){
					appo.setPerpetual(rs.getString(16).equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				}else{
					appo.setPerpetual(null);
				}
				log.setter("get EXTENDIBLE value "+rs.getString(17));
				if(rs.getString(17)!=null && !rs.getString(17).equalsIgnoreCase("")){
					appo.setExtendible(rs.getString(17).equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				}else{
					appo.setExtendible(null);
				}
				log.setter("get BULLET value "+rs.getString(18));
				if(rs.getString(18)!=null && !rs.getString(18).equalsIgnoreCase("")){
					appo.setBullet(rs.getString(18).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setBullet(null);
				}
				log.setter("get CALL_TYP value "+rs.getString(19));
				appo.setCallType(rs.getString(19));
				log.setter("get STRUCT_NOT value "+rs.getString(20));
				if(rs.getString(20)!=null && !rs.getString(20).equalsIgnoreCase("")){
					appo.setStructuredNote(rs.getString(20).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setStructuredNote(null);
				}
				log.setter("get LNK_BND_IN value "+rs.getString(21));
				if(rs.getString(21)!=null && !rs.getString(21).equalsIgnoreCase("")){
					appo.setLinkedBondInd(rs.getString(21).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setLinkedBondInd(null);
				}
				log.setter("get LNK_BNDINF value "+rs.getString(22));
				appo.setLinkedBondInfo(rs.getString(22));
				log.setter("get CPN_TYP value "+rs.getString(23));
				appo.setCpnTyp(rs.getString(23));
				log.setter("get CPN value "+rs.getBigDecimal(24));
				appo.setCpn(rs.getBigDecimal(24));
				log.setter("get CPN_FREQ value "+rs.getInt(25));
				appo.setCpnFreq(new Integer(rs.getInt(25)));
				log.setter("get RESET_IDX value "+rs.getString(26));
				appo.setResetIdx(rs.getString(26));
				log.setter("get UND_SEC_DE value "+rs.getString(27));
				appo.setUnderlyingSecurityDes(rs.getString(27));
				log.setter("get DES_NOTES value "+rs.getString(28));
				appo.setDesNote(rs.getString(28));
				log.setter("get CNTRY_RISK value "+rs.getString(29));
				appo.setCntryOfRisk(rs.getString(29));
				log.setter("get REDEMP_VAL value "+rs.getBigDecimal(30));
				appo.setRedempVal(rs.getBigDecimal(30));
				log.setter("get PCT_PAR_QU value "+rs.getString(31));
				if(rs.getString(31)!=null && !rs.getString(31).equalsIgnoreCase("")){
					appo.setPctParQuoted(rs.getString(31).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setPctParQuoted(null);
				}
				log.setter("get PR_RT_SINK value "+rs.getString(32));
				if(rs.getString(32)!=null && !rs.getString(32).equalsIgnoreCase("")){
					appo.setProRataSink(rs.getString(32).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setProRataSink(null);
				}
				log.setter("get SINK_SC_TY value "+rs.getString(33));
				appo.setSinkScheduleAmtTyp(rs.getString(33));
				log.setter("get REPFAC value "+rs.getBigDecimal(34));
				appo.setMostRecentReportedFactor(rs.getBigDecimal(34));
				log.setter("get SEC_FACT value "+rs.getString(35));
				if(rs.getString(35)!=null && !rs.getString(35).equalsIgnoreCase("")){
					appo.setSecurityFactorable(rs.getString(35).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setSecurityFactorable(null);
				}
				log.setter("get INF_LNK_IN value "+rs.getString(36));
				if(rs.getString(36)!=null && !rs.getString(36).equalsIgnoreCase("")){
					appo.setInflationLinkedIndicator(rs.getString(36).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setInflationLinkedIndicator(null);
				}
				log.setter("get PAR_AMT value "+rs.getBigDecimal(37));
				appo.setParAmt(rs.getBigDecimal(37));
				log.setter("get PX_LAST value "+rs.getBigDecimal(38));
				appo.setPxLast(rs.getBigDecimal(38));
				log.setter("get PX_CLOSEDT value "+rs.getInt(39));
				appo.setPxCloseDt(rs.getInt(39));
				log.setter("get TFLCURDUB value "+rs.getString(40));
				if(rs.getString(40)!=null && !rs.getString(40).equalsIgnoreCase("")){
					appo.setTflcurdub(rs.getString(40).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflcurdub(null);
				}
				log.setter("get TFLCURLIQ value "+rs.getString(41));
				if(rs.getString(41)!=null && !rs.getString(41).equalsIgnoreCase("")){
					appo.setTflcurliq(rs.getString(41).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflcurliq(null);
				}
				log.setter("get TFLCURNEG value "+rs.getString(42));
				if(rs.getString(42)!=null && !rs.getString(42).equalsIgnoreCase("")){
					appo.setTflcurneg(rs.getString(42).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflcurneg(null);
				}
				log.setter("get TFLGPER value "+rs.getString(43));
				if(rs.getString(43)!=null && !rs.getString(43).equalsIgnoreCase("")){
					appo.setTflgper(rs.getString(43).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflgper(null);
				}
				log.setter("get TFLGEST value "+rs.getString(44));
				if(rs.getString(44)!=null && !rs.getString(44).equalsIgnoreCase("")){
					appo.setTflgest(rs.getString(44).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflgest(null);
				}
				log.setter("get TFLAMORT value "+rs.getString(45));
				if(rs.getString(45)!=null && !rs.getString(45).equalsIgnoreCase("")){
					appo.setTflamort(rs.getString(45).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflamort(null);
				}
				log.setter("get TFLGACCT value "+rs.getString(46));
				if(rs.getString(46)!=null && !rs.getString(46).equalsIgnoreCase("")){
					appo.setTflgacct(rs.getString(46).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflgacct(null);
				}
				log.setter("get TFLSTRUC value "+rs.getString(47));
				if(rs.getString(47)!=null && !rs.getString(47).equalsIgnoreCase("")){
					appo.setTflstruc(rs.getString(47).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflstruc(null);
				}
				log.setter("get UPDDATE");
				appo.setUpdDate(rs.getTimestamp(48));
				log.setter("get UPDTYPE value "+rs.getString(49));
				appo.setUpdType(rs.getString(49));
				log.setter("get UPDUSR value "+rs.getString(50));
				appo.setUpdUsr(rs.getString(50));
				log.setter("get TTPBOND value "+rs.getString(51));
				if(rs.getString(51)!=null && !rs.getString(51).equalsIgnoreCase("")){
					appo.setTtpbond(rs.getString(51).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTtpbond(null);
				}
				toReturn.add(appo);
				log.debug("-----------------------------------------");
			}
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * 
	 * @param dto <code>IfptBndDtHDTO</code>
	 * @return <code>List<IfptBndDtHDTO></code>
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public List<IfptBndDtHDTO> retrieveIfptBndDtByRequestId(IfptBndDtHDTO dto) throws SendWarningException, SendBlockingException{
		log.debug("in List<IfptBndDtHDTO> retrieveIfptBndDtByRequestId(IfptBndDtHDTO dto) throws SendWarningException, SendBlockingException");
		String retrieveString = "SELECT ISINCODE,"+ //1
										" BLOOMCODE,"+//2
										" SEC_DES,"+//3
										" ST_ACC_DT,"+//4
										" MATURITY,"+//5
										" FINAL_MAT,"+//6
										" MKTSECT,"+//7
										" IS_CERTIF,"+//8
										" ISSR_IND,"+//9
										" ISSUER,"+//10
										" CRNCY,"+//11
										" REDEM_CRNCY,"+//12
										" DUAL_CRCY,"+//13
										" DAY_TO_ST,"+//14
										" MTY_TYP,"+//15
										" IS_PERPET,"+//16
										" EXTENDIBLE,"+//17
										" BULLET,"+//18
										" CALL_TYP,"+//19
										" STRUCT_NOT,"+//20
										" LNK_BND_IN,"+//21
										" LNK_BNDINF,"+//22
										" CPN_TYP,"+//23
										" CPN,"+//24
										" CPN_FREQ,"+//25
										" RESET_IDX,"+//26
										" UND_SEC_DE,"+//27
										" DES_NOTES,"+//28
										" CNTRY_RISK,"+//29
										" REDEMP_VAL,"+//30
										" PCT_PAR_QU,"+//31
										" PR_RT_SINK,"+//32
										" SINK_SC_TY,"+//33
										" REPFAC,"+//34
										" SEC_FACT,"+//35
										" INF_LNK_IN,"+//36
										" PAR_AMT,"+//37
										" PX_LAST,"+//38
										" PX_CLOSEDT,"+//39
										" TFLCURDUB, "+//40
										" TFLCURLIQ, "+//41
										" TFLCURNEG,"+//42
										" TFLGPER,"+//43
										" TFLGEST, "+//44
										" TFLAMORT,"+//45
										" TFLGACCT,"+//46
										" TFLSTRUC,"+//47
										" UPDDATE,"+//48
										" UPDTYPE,"+//49
										" UPDUSR,"+//50
										" TTPBOND "+//51
							     " FROM INFOP.IFPTBNDDTH "+
							    " WHERE REQUESTID = ?";
		
		log.debug("statement used "+retrieveString);
		log.debug("check data's consistency");
		if (dto.getRequestId()!=null || dto.getRequestId().equalsIgnoreCase("")){
			log.error("NoSuchFieldException: Data incomplete REQUESTID");
			throw new SendWarningException("Data incomplete REQUESTID");
		}
		log.debug("check ok");
		log.setter("statement used "+retrieveString);
		List<IfptBndDtHDTO> toReturn=null;
		try {
			stmt = conn.prepareStatement(retrieveString);
			log.debug("set REQUESTID value "+dto.getRequestId());
			stmt.setString(1, dto.getRequestId());
			
			log.debug("execute query");
			this.rs = stmt.executeQuery();
			log.debug("query executed...read data");
			toReturn= new ArrayList<IfptBndDtHDTO>();
			while(rs.next()){
				IfptBndDtHDTO appo = new IfptBndDtHDTO();
				appo.setRequestId(dto.getRequestId());
				log.setter("get ISINCODE value "+rs.getString(1));
				appo.setIsinCode(rs.getString(1));
				log.setter("get BLOOMCODE value "+rs.getString(2));
				appo.setBloomcode(rs.getString(2));
				log.setter("get SEC_DES value "+rs.getString(3));
				appo.setSecurityDes(rs.getString(3));
				log.setter("get ST_ACC_DT value "+rs.getInt(4));
				appo.setStartAccDt(new Integer(rs.getInt(4)));
				log.setter("get MATURITY value "+rs.getInt(5));
				appo.setMaturity(new Integer(rs.getInt(5)));
				log.setter("get FINAL_MAT value "+rs.getInt(6));
				appo.setFinalMaturity(new Integer(rs.getInt(6)));
				log.setter("get MKTSECT value "+rs.getString(7));
				appo.setMarketSectorDes(rs.getString(7));
				log.setter("get IS_CERTIF value "+rs.getString(8));
				if(rs.getString(8)!=null && !rs.getString(8).equalsIgnoreCase("")){
					appo.setCertificated(rs.getString(8).equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				}else{
					appo.setCertificated(null);
				}
				log.setter("get ISSR_IND value "+rs.getString(9));
				appo.setIssuerIndustry(rs.getString(9));
				log.setter("get ISSUER value "+rs.getString(10));
				appo.setIssuer(rs.getString(10));
				log.setter("get CRNCY value "+rs.getString(11));
				appo.setCrncy(rs.getString(11));
				log.setter("get REDEM_CRNCY value "+rs.getString(12));
				appo.setRedempCrncy(rs.getString(12));
				log.setter("get DUAL_CRCY value "+rs.getString(13));
				if(rs.getString(13)!=null && !rs.getString(13).equalsIgnoreCase("")){
					appo.setDualCrncy(rs.getString(13).equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				}else{
					appo.setDualCrncy(null);
				}
				log.setter("get DAY_TO_ST value "+rs.getInt(14));
				appo.setDayToSettle(new Integer(rs.getInt(14)));
				log.setter("get MTY_TYP value "+rs.getString(15));
				appo.setMtyTyp(rs.getString(15));
				log.setter("get IS_PERPET value "+rs.getString(16));
				if(rs.getString(16)!=null && !rs.getString(16).equalsIgnoreCase("")){
					appo.setPerpetual(rs.getString(16).equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				}else{
					appo.setPerpetual(null);
				}
				log.setter("get EXTENDIBLE value "+rs.getString(17));
				if(rs.getString(17)!=null && !rs.getString(17).equalsIgnoreCase("")){
					appo.setExtendible(rs.getString(17).equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				}else{
					appo.setExtendible(null);
				}
				log.setter("get BULLET value "+rs.getString(18));
				if(rs.getString(18)!=null && !rs.getString(18).equalsIgnoreCase("")){
					appo.setBullet(rs.getString(18).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setBullet(null);
				}
				log.setter("get CALL_TYP value "+rs.getString(19));
				appo.setCallType(rs.getString(19));
				log.setter("get STRUCT_NOT value "+rs.getString(20));
				if(rs.getString(20)!=null && !rs.getString(20).equalsIgnoreCase("")){
					appo.setStructuredNote(rs.getString(20).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setStructuredNote(null);
				}
				log.setter("get LNK_BND_IN value "+rs.getString(21));
				if(rs.getString(21)!=null && !rs.getString(21).equalsIgnoreCase("")){
					appo.setLinkedBondInd(rs.getString(21).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setLinkedBondInd(null);
				}
				log.setter("get LNK_BNDINF value "+rs.getString(22));
				appo.setLinkedBondInfo(rs.getString(22));
				log.setter("get CPN_TYP value "+rs.getString(23));
				appo.setCpnTyp(rs.getString(23));
				log.setter("get CPN value "+rs.getBigDecimal(24));
				appo.setCpn(rs.getBigDecimal(24));
				log.setter("get CPN_FREQ value "+rs.getInt(25));
				appo.setCpnFreq(new Integer(rs.getInt(25)));
				log.setter("get RESET_IDX value "+rs.getString(26));
				appo.setResetIdx(rs.getString(26));
				log.setter("get UND_SEC_DE value "+rs.getString(27));
				appo.setUnderlyingSecurityDes(rs.getString(27));
				log.setter("get DES_NOTES value "+rs.getString(28));
				appo.setDesNote(rs.getString(28));
				log.setter("get CNTRY_RISK value "+rs.getString(29));
				appo.setCntryOfRisk(rs.getString(29));
				log.setter("get REDEMP_VAL value "+rs.getBigDecimal(30));
				appo.setRedempVal(rs.getBigDecimal(30));
				log.setter("get PCT_PAR_QU value "+rs.getString(31));
				if(rs.getString(31)!=null && !rs.getString(31).equalsIgnoreCase("")){
					appo.setPctParQuoted(rs.getString(31).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setPctParQuoted(null);
				}
				log.setter("get PR_RT_SINK value "+rs.getString(32));
				if(rs.getString(32)!=null && !rs.getString(32).equalsIgnoreCase("")){
					appo.setProRataSink(rs.getString(32).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setProRataSink(null);
				}
				log.setter("get SINK_SC_TY value "+rs.getString(33));
				appo.setSinkScheduleAmtTyp(rs.getString(33));
				log.setter("get REPFAC value "+rs.getBigDecimal(34));
				appo.setMostRecentReportedFactor(rs.getBigDecimal(34));
				log.setter("get SEC_FACT value "+rs.getString(35));
				if(rs.getString(35)!=null && !rs.getString(35).equalsIgnoreCase("")){
					appo.setSecurityFactorable(rs.getString(35).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setSecurityFactorable(null);
				}
				log.setter("get INF_LNK_IN value "+rs.getString(36));
				if(rs.getString(36)!=null && !rs.getString(36).equalsIgnoreCase("")){
					appo.setInflationLinkedIndicator(rs.getString(36).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setInflationLinkedIndicator(null);
				}
				log.setter("get PAR_AMT value "+rs.getBigDecimal(37));
				appo.setParAmt(rs.getBigDecimal(37));
				log.setter("get PX_LAST value "+rs.getBigDecimal(38));
				appo.setPxLast(rs.getBigDecimal(38));
				log.setter("get PX_CLOSEDT value "+rs.getInt(39));
				appo.setPxCloseDt(rs.getInt(39));
				log.setter("get TFLCURDUB value "+rs.getString(40));
				if(rs.getString(40)!=null && !rs.getString(40).equalsIgnoreCase("")){
					appo.setTflcurdub(rs.getString(40).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflcurdub(null);
				}
				log.setter("get TFLCURLIQ value "+rs.getString(41));
				if(rs.getString(41)!=null && !rs.getString(41).equalsIgnoreCase("")){
					appo.setTflcurliq(rs.getString(41).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflcurliq(null);
				}
				log.setter("get TFLCURNEG value "+rs.getString(42));
				if(rs.getString(42)!=null && !rs.getString(42).equalsIgnoreCase("")){
					appo.setTflcurneg(rs.getString(42).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflcurneg(null);
				}
				log.setter("get TFLGPER value "+rs.getString(43));
				if(rs.getString(43)!=null && !rs.getString(43).equalsIgnoreCase("")){
					appo.setTflgper(rs.getString(43).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflgper(null);
				}
				log.setter("get TFLGEST value "+rs.getString(44));
				if(rs.getString(44)!=null && !rs.getString(44).equalsIgnoreCase("")){
					appo.setTflgest(rs.getString(44).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflgest(null);
				}
				log.setter("get TFLAMORT value "+rs.getString(45));
				if(rs.getString(45)!=null && !rs.getString(45).equalsIgnoreCase("")){
					appo.setTflamort(rs.getString(45).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflamort(null);
				}
				log.setter("get TFLGACCT value "+rs.getString(46));
				if(rs.getString(46)!=null && !rs.getString(46).equalsIgnoreCase("")){
					appo.setTflgacct(rs.getString(46).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflgacct(null);
				}
				log.setter("get TFLSTRUC value "+rs.getString(47));
				if(rs.getString(47)!=null && !rs.getString(47).equalsIgnoreCase("")){
					appo.setTflstruc(rs.getString(47).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflstruc(null);
				}
				log.setter("get UPDDATE");
				appo.setUpdDate(rs.getTimestamp(48));
				log.setter("get UPDTYPE value "+rs.getString(49));
				appo.setUpdType(rs.getString(49));
				log.setter("get UPDUSR value "+rs.getString(50));
				appo.setUpdUsr(rs.getString(50));
				log.setter("get TTPBOND value "+rs.getString(51));
				if(rs.getString(51)!=null && !rs.getString(51).equalsIgnoreCase("")){
					appo.setTtpbond(rs.getString(51).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTtpbond(null);
				}
				toReturn.add(appo);
				log.setter("-----------------------------------------");
			}
			log.setter("###################################################");
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * 
	 * @param dto <code>IfptBndDtHDTO</code>
	 * @return <code>List<IfptBndDtHDTO></code> 
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public List<IfptBndDtHDTO> retrieveIfptBndDtByBloomCode(IfptBndDtHDTO dto) throws SendWarningException, SendBlockingException{
		log.debug("in List<IfptBndDtHDTO> retrieveIfptBndDtByBloomCode(IfptBndDtHDTO dto) throws SendWarningException, SendBlockingException");
		String retrieveString = "SELECT ISINCODE,"+ //1
										" REQUESTID,"+//2
										" SEC_DES,"+//3
										" ST_ACC_DT,"+//4
										" MATURITY,"+//5
										" FINAL_MAT,"+//6
										" MKTSECT,"+//7
										" IS_CERTIF,"+//8
										" ISSR_IND,"+//9
										" ISSUER,"+//10
										" CRNCY,"+//11
										" REDEM_CRNCY,"+//12
										" DUAL_CRCY,"+//13
										" DAY_TO_ST,"+//14
										" MTY_TYP,"+//15
										" IS_PERPET,"+//16
										" EXTENDIBLE,"+//17
										" BULLET,"+//18
										" CALL_TYP,"+//19
										" STRUCT_NOT,"+//20
										" LNK_BND_IN,"+//21
										" LNK_BNDINF,"+//22
										" CPN_TYP,"+//23
										" CPN,"+//24
										" CPN_FREQ,"+//25
										" RESET_IDX,"+//26
										" UND_SEC_DE,"+//27
										" DES_NOTES,"+//28
										" CNTRY_RISK,"+//29
										" REDEMP_VAL,"+//30
										" PCT_PAR_QU,"+//31
										" PR_RT_SINK,"+//32
										" SINK_SC_TY,"+//33
										" REPFAC,"+//34
										" SEC_FACT,"+//35
										" INF_LNK_IN,"+//36
										" PAR_AMT,"+//37
										" PX_LAST,"+//38
										" PX_CLOSEDT,"+//39
										" TFLCURDUB,"+//40
										" TFLCURLIQ,"+//41
										" TFLCURNEG,"+//42
										" TFLGPER,"+//43
										" TFLGEST,"+//44
										" TFLAMORT,"+//45
										" TFLGACCT,"+//46
										" TFLSTRUC,"+//47
										" UPDDATE,"+//48
										" UPDTYPE,"+//49
										" UPDUSR,"+//50
										" TTPBOND"+//51
							     " FROM INFOP.IFPTBNDDTH "+
							    " WHERE BLOOMCODE = ?";
		
		log.debug("statement used "+retrieveString);
		log.debug("check data's consistency");
		if (dto.getBloomcode()!=null || dto.getBloomcode().equalsIgnoreCase("")){
			log.error("NoSuchFieldException: Data incomplete BLOOMCODE");
			throw new SendWarningException("Data incomplete BLOOMCODE");
		}
		log.debug("check ok");
		log.setter("statement used "+retrieveString);
		List<IfptBndDtHDTO> toReturn=null;
		try {
			stmt = conn.prepareStatement(retrieveString);
			log.debug("set BLOOMCODE value "+dto.getBloomcode());
			stmt.setString(1, dto.getBloomcode());
			
			log.debug("execute query");
			this.rs = stmt.executeQuery();
			log.debug("query executed...read data");
			toReturn= new ArrayList<IfptBndDtHDTO>();
			while(rs.next()){
				IfptBndDtHDTO appo = new IfptBndDtHDTO();
				appo.setRequestId(dto.getRequestId());
				log.setter("get ISINCODE value "+rs.getString(1));
				appo.setIsinCode(rs.getString(1));
				log.setter("get REQUESTID value "+rs.getString(2));
				appo.setRequestId(rs.getString(2));
				log.setter("get SEC_DES value "+rs.getString(3));
				appo.setSecurityDes(rs.getString(3));
				log.setter("get ST_ACC_DT value "+rs.getInt(4));
				appo.setStartAccDt(new Integer(rs.getInt(4)));
				log.setter("get MATURITY value "+rs.getInt(5));
				appo.setMaturity(new Integer(rs.getInt(5)));
				log.setter("get FINAL_MAT value "+rs.getInt(6));
				appo.setFinalMaturity(new Integer(rs.getInt(6)));
				log.setter("get MKTSECT value "+rs.getString(7));
				appo.setMarketSectorDes(rs.getString(7));
				log.setter("get IS_CERTIF value "+rs.getString(8));
				if(rs.getString(8)!=null && !rs.getString(8).equalsIgnoreCase("")){
					appo.setCertificated(rs.getString(8).equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				}else{
					appo.setCertificated(null);
				}
				log.setter("get ISSR_IND value "+rs.getString(9));
				appo.setIssuerIndustry(rs.getString(9));
				log.setter("get ISSUER value "+rs.getString(10));
				appo.setIssuer(rs.getString(10));
				log.setter("get CRNCY value "+rs.getString(11));
				appo.setCrncy(rs.getString(11));
				log.setter("get REDEM_CRNCY value "+rs.getString(12));
				appo.setRedempCrncy(rs.getString(12));
				log.setter("get DUAL_CRCY value "+rs.getString(13));
				if(rs.getString(13)!=null && !rs.getString(13).equalsIgnoreCase("")){
					appo.setDualCrncy(rs.getString(13).equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				}else{
					appo.setDualCrncy(null);
				}
				log.setter("get DAY_TO_ST value "+rs.getInt(14));
				appo.setDayToSettle(new Integer(rs.getInt(14)));
				log.setter("get MTY_TYP value "+rs.getString(15));
				appo.setMtyTyp(rs.getString(15));
				log.setter("get IS_PERPET value "+rs.getString(16));
				if(rs.getString(16)!=null && !rs.getString(16).equalsIgnoreCase("")){
					appo.setPerpetual(rs.getString(16).equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				}else{
					appo.setPerpetual(null);
				}
				log.setter("get EXTENDIBLE value "+rs.getString(17));
				if(rs.getString(17)!=null && !rs.getString(17).equalsIgnoreCase("")){
					appo.setExtendible(rs.getString(17).equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
				}else{
					appo.setExtendible(null);
				}
				log.setter("get BULLET value "+rs.getString(18));
				if(rs.getString(18)!=null && !rs.getString(18).equalsIgnoreCase("")){
					appo.setBullet(rs.getString(18).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setBullet(null);
				}
				log.setter("get CALL_TYP value "+rs.getString(19));
				appo.setCallType(rs.getString(19));
				log.setter("get STRUCT_NOT value "+rs.getString(20));
				if(rs.getString(20)!=null && !rs.getString(20).equalsIgnoreCase("")){
					appo.setStructuredNote(rs.getString(20).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setStructuredNote(null);
				}
				log.setter("get LNK_BND_IN value "+rs.getString(21));
				if(rs.getString(21)!=null && !rs.getString(21).equalsIgnoreCase("")){
					appo.setLinkedBondInd(rs.getString(21).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setLinkedBondInd(null);
				}
				log.setter("get LNK_BNDINF value "+rs.getString(22));
				appo.setLinkedBondInfo(rs.getString(22));
				log.setter("get CPN_TYP value "+rs.getString(23));
				appo.setCpnTyp(rs.getString(23));
				log.setter("get CPN value "+rs.getBigDecimal(24));
				appo.setCpn(rs.getBigDecimal(24));
				log.setter("get CPN_FREQ value "+rs.getInt(25));
				appo.setCpnFreq(new Integer(rs.getInt(25)));
				log.setter("get RESET_IDX value "+rs.getString(26));
				appo.setResetIdx(rs.getString(26));
				log.setter("get UND_SEC_DE value "+rs.getString(27));
				appo.setUnderlyingSecurityDes(rs.getString(27));
				log.setter("get DES_NOTES value "+rs.getString(28));
				appo.setDesNote(rs.getString(28));
				log.setter("get CNTRY_RISK value "+rs.getString(29));
				appo.setCntryOfRisk(rs.getString(29));
				log.setter("get REDEMP_VAL value "+rs.getBigDecimal(30));
				appo.setRedempVal(rs.getBigDecimal(30));
				log.setter("get PCT_PAR_QU value "+rs.getString(31));
				if(rs.getString(31)!=null && !rs.getString(31).equalsIgnoreCase("")){
					appo.setPctParQuoted(rs.getString(31).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setPctParQuoted(null);
				}
				log.setter("get PR_RT_SINK value "+rs.getString(32));
				if(rs.getString(32)!=null && !rs.getString(32).equalsIgnoreCase("")){
					appo.setProRataSink(rs.getString(32).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setProRataSink(null);
				}
				log.setter("get SINK_SC_TY value "+rs.getString(33));
				appo.setSinkScheduleAmtTyp(rs.getString(33));
				log.setter("get REPFAC value "+rs.getBigDecimal(34));
				appo.setMostRecentReportedFactor(rs.getBigDecimal(34));
				log.setter("get SEC_FACT value "+rs.getString(35));
				if(rs.getString(35)!=null && !rs.getString(35).equalsIgnoreCase("")){
					appo.setSecurityFactorable(rs.getString(35).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setSecurityFactorable(null);
				}
				log.setter("get INF_LNK_IN value "+rs.getString(36));
				if(rs.getString(36)!=null && !rs.getString(36).equalsIgnoreCase("")){
					appo.setInflationLinkedIndicator(rs.getString(36).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setInflationLinkedIndicator(null);
				}
				log.setter("get PAR_AMT value "+rs.getBigDecimal(37));
				appo.setParAmt(rs.getBigDecimal(37));
				log.setter("get PX_LAST value "+rs.getBigDecimal(38));
				appo.setPxLast(rs.getBigDecimal(38));
				log.setter("get PX_CLOSEDT value "+rs.getInt(39));
				appo.setPxCloseDt(rs.getInt(39));
				log.setter("get TFLCURDUB value "+rs.getString(40));
				if(rs.getString(40)!=null && !rs.getString(40).equalsIgnoreCase("")){
					appo.setTflcurdub(rs.getString(40).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflcurdub(null);
				}
				log.setter("get TFLCURLIQ value "+rs.getString(41));
				if(rs.getString(41)!=null && !rs.getString(41).equalsIgnoreCase("")){
					appo.setTflcurliq(rs.getString(41).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflcurliq(null);
				}
				log.setter("get TFLCURNEG value "+rs.getString(42));
				if(rs.getString(42)!=null && !rs.getString(42).equalsIgnoreCase("")){
					appo.setTflcurneg(rs.getString(42).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflcurneg(null);
				}
				log.setter("get TFLGPER value "+rs.getString(43));
				if(rs.getString(43)!=null && !rs.getString(43).equalsIgnoreCase("")){
					appo.setTflgper(rs.getString(43).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflgper(null);
				}
				log.setter("get TFLGEST value "+rs.getString(44));
				if(rs.getString(44)!=null && !rs.getString(44).equalsIgnoreCase("")){
					appo.setTflgest(rs.getString(44).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflgest(null);
				}
				log.setter("get TFLAMORT value "+rs.getString(45));
				if(rs.getString(45)!=null && !rs.getString(45).equalsIgnoreCase("")){
					appo.setTflamort(rs.getString(45).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflamort(null);
				}
				log.setter("get TFLGACCT value "+rs.getString(46));
				if(rs.getString(46)!=null && !rs.getString(46).equalsIgnoreCase("")){
					appo.setTflgacct(rs.getString(46).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflgacct(null);
				}
				log.setter("get TFLSTRUC value "+rs.getString(47));
				if(rs.getString(47)!=null && !rs.getString(47).equalsIgnoreCase("")){
					appo.setTflstruc(rs.getString(47).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTflstruc(null);
				}
				log.setter("get UPDDATE");
				appo.setUpdDate(rs.getTimestamp(49));
				log.setter("get UPDTYPE value "+rs.getString(49));
				appo.setUpdType(rs.getString(49));
				log.setter("get UPDUSR value "+rs.getString(50));
				appo.setUpdUsr(rs.getString(50));
				log.setter("get TTPBOND value "+rs.getString(51));
				if(rs.getString(51)!=null && !rs.getString(51).equalsIgnoreCase("")){
					appo.setTtpbond(rs.getString(51).equalsIgnoreCase("Y")?new Boolean(true):new Boolean (false));
				}else{
					appo.setTtpbond(null);
				}
				toReturn.add(appo);
				log.setter("-----------------------------------------");
			}
			log.setter("###################################################");
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#finalize()
	 */
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		if (conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				log.warn("SQLException in close connection "+e.getMessage());
			}
		}
		super.finalize();
	}
}
