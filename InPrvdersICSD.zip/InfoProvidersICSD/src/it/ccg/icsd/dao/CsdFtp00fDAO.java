/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd.dao;

import it.ccg.icsd.connection.MilanoEnvConnector;
import it.ccg.icsd.dto.CsdFtp00fDTO;
import it.ccg.icsd.exception.SendBlockingException;
import it.ccg.icsd.exception.SendWarningException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class CsdFtp00fDAO {

	private static final Logger log = Logger.getLogger("it.ccg.icsd.dao.CsdFtp00fDAO");
	private Connection conn;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	private SimpleDateFormat dateFormat = new SimpleDateFormat ("yyyyMMdd");
	//private SimpleDateFormat hourFormat = new SimpleDateFormat ("hhmmss");
	
	public CsdFtp00fDAO() throws SendBlockingException{
		log.debug("in default constructor");
		try {
			MilanoEnvConnector bdConnection = new MilanoEnvConnector();
			log.debug("getting connection");
			conn = bdConnection.getConnection();
		} catch (SendBlockingException e) {
			log.error("SendBlockingException "+e.getCause().getMessage());
			throw e;
		}
	}
	
	/////
	 // Method that insert data into CSDTIT00F table
	 // @param <code>List<CsdTiT00fDTO></code>
	 // @return <code>boolean</code> - insert operation result
	 // @throws SendBlockingException
	 // @throws SendWarningException
	 ///
	public boolean insertCsdFtp00f(List<CsdFtp00fDTO> list) throws SendBlockingException, SendWarningException{
		log.debug("in boolean insertCsdFtp00f(List<CsdFtp00fDTO> list) throws SendBlockingException, SendWarningException");
		
		String insertString = "INSERT INTO CCG_CGIT.CSDFTP00F(CSDDATA, CSDORA, CSDTELA, CSDMKT, CSDTIPO, CSDPROG, CSDISIN, CSDDESCR, CSDSETTL, CSDCURTR, CSDCURSE, CSDNAZIO, CSDDTNEG, CSDDTEMI, CSDDTSCA, CSDESTEN, CSDPERPE, CSDSTRUT, CSDTSOST, CSDTPSTR, CSDAMORT, CSDNEXTQ, CSDFREQU, CSDPERCE, CSDPOOLF, CSDESCCP, CSDRIFIU, TDESC, TEXCH, TCURRNE, TCURRLQ, TPSEMIT, TDTAEM, TDESEMI, TCODEMI, TTPSTR, TPCERT, TTPBOND, TTPMAT, TSCAPER, TFLGPER, TDTAEXP, TDTAEXPU, TSCAEXT, TFLGEST, TFLGACCT, TFLCURNEG, TFLCURLIQ, TFLCURDUB, TFLSTRUC, TFLAMORT, TFLGEL, TDTAEL, TORAEL, TUSER, TPROG, TDTAIN, TUSERIN, TINFBLOO, TDTABLO, TTIMEBLO)" 
                                                     +" VALUES(?      , ?     , ?      , ?     , ?      , ?      , ?      , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?       , ?    , ?    , ?      , ?      , ?  	   , ?     , ?      , ?      , ?     , ?     , ?      , ?     , ?      , ?      , ?      , ?       , ?      , ?      , ?       , ?        , ?        , ?        , ?       , ?       , ?     , ?     , ?     , ?    , ?    , ?     , ?      , ?       , ?      , ?       )";
		log.debug("statement used "+insertString);
		boolean toReturn=false;
		
		log.debug("check data's consistency");
		for (CsdFtp00fDTO i : list){
			if ((i.getCsdisin()==null || i.getCsdisin().equalsIgnoreCase(""))){
				String field="";
				if (i.getCsdisin()==null || i.getCsdisin().equalsIgnoreCase(""))
					field+="ISINCODE ";
				
				log.error("NoSuchFieldException: DATA INCOMPLETE "+field);
				throw new SendWarningException("DATA INCOMPLETE "+field);
			}
		}
		log.debug("check ok");
		log.setter("statement used "+insertString);
		
		try {
			this.stmt = conn.prepareStatement(insertString);
		
			log.debug("statement instantiated start to popolate it");
			for (CsdFtp00fDTO i : list){
				
				 // CSDDATA, 
				if(i.getCsddata()== null){
					log.setter("set TDTAEM value null");
					stmt.setNull(9, Types.NUMERIC);
				}else{
					log.setter("set TDTAEM value "+i.getTdtaem());
					stmt.setInt(9, Integer.parseInt(dateFormat.format(i.getTdtaem())));
				}
				 // CSDORA, 
				 // CSDTELA, 
				 // CSDMKT, 
				 // CSDTIPO, 
				 // CSDPROG, 
				 // CSDISIN, 
				 // CSDDESCR, 
				 // CSDSETTL, 
				 // CSDCURTR, 
				 // CSDCURSE, 
				 // CSDNAZIO, 
				 // CSDDTNEG, 
				 // CSDDTEMI, 
				 // CSDDTSCA, 
				 // CSDESTEN, 
				 // CSDPERPE, 
				 // CSDSTRUT, 
				 // CSDTSOST, 
				 // CSDTPSTR, 
				 // CSDAMORT, 
				 // CSDNEXTQ, 
				 // CSDFREQU, 
				 // CSDPERCE, 
				 // CSDPOOLF, 
				 // CSDESCCP, 
				 // CSDRIFIU, 
				 // TDESC, 
				 // TEXCH, 
				 // TCURRNE, 
				 // TCURRLQ, 
				 // TPSEMIT, 
				 // TDTAEM, 
				 // TDESEMI, 
				 // TCODEMI, 
				 // TTPSTR, 
				 // TPCERT, 
				 // TTPBOND, 
				 // TTPMAT, 
				 // TSCAPER, 
				 // TFLGPER, 
				 // TDTAEXP, 
				 // TDTAEXPU, 
				 // TSCAEXT, 
				 // TFLGEST, 
				 // TFLGACCT, 
				 // TFLCURNEG, 
				 // TFLCURLIQ, 
				 // TFLCURDUB, 
				 // TFLSTRUC, 
				 // TFLAMORT, 
				 // TFLGEL, 
				 // TDTAEL, 
				 // TORAEL, 
				 // TUSER, 
				 // TPROG, 
				 // TDTAIN, 
				 // TUSERIN, 
				 // TINFBLOO, 
				 // TDTABLO, 
				 // TTIMEBLO
				 //
			}
		
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if (stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * Method that retrieve every records from CSDTIT00F table that have TINFBLOO = 'N'
	 * @return <code>List<CsdTiT00fDTO></code>
	 * @throws SendBlockingException
	 * @throws SendWarningException
	 */
	public List<CsdFtp00fDTO> retrieveCsdFtp00FToCheck() throws SendBlockingException, SendWarningException{
		String retrieveString = "SELECT CSDDATA, "+
								 	"   CSDORA, "+
									"	CSDTELA, "+
									"	CSDMKT, "+
									"	CSDTIPO, "+
									"	CSDPROG, "+
									"	CSDISIN, "+
									"	CSDDESCR, "+
									"	CSDSETTL, "+
									"	CSDCURTR, "+
									"	CSDCURSE, "+
									"	CSDNAZIO, "+
									"	CSDDTNEG, "+
									"	CSDDTEMI, "+
									"	CSDDTSCA, "+
									"	CSDESTEN, "+
									"	CSDPERPE, "+
									"	CSDSTRUT, "+
									"	CSDTSOST, "+
									"	CSDTPSTR, "+
									"	CSDAMORT, "+
									"	CSDNEXTQ, "+
									"	CSDFREQU, "+
									"	CSDPERCE, "+
									"	CSDPOOLF, "+
									"	CSDESCCP, "+
									"	CSDRIFIU, "+
									"	TDESC, "+
									"	TEXCH, "+
									"	TCURRNE, "+
									"	TCURRLQ, "+
									"	TPSEMIT, "+
									"	TDTAEM, "+
									"	TDESEMI, "+
									"	TCODEMI, "+
									"	TTPSTR, "+
									"	TPCERT, "+
									"	TTPBOND, "+
									"	TTPMAT, "+
									"	TSCAPER, "+
									"	TFLGPER, "+
									"	TDTAEXP, "+
									"	TDTAEXPU, "+
									"	TSCAEXT, "+
									"	TFLGEST, "+
									"	TFLGACCT, "+
									"	TFLCURNEG, "+
									"	TFLCURLIQ, "+
									"	TFLCURDUB, "+
									"	TFLSTRUC, "+
									"	TFLAMORT, "+
									"	TFLGEL, "+
									"	TDTAEL, "+
									"	TORAEL, "+
									"	TUSER, "+
									"	TPROG, "+
									"	TDTAIN, "+
									"	TUSERIN, "+
									"	TDTABLO, "+
									"	TTIMEBLO "+
							"	   FROM CCG_CGIT.CSDFTP00F"+
							"	  WHERE TINFBLOO = 'N'" +
							"		AND CSDTELA = 2";  
		
		log.debug("statement used "+retrieveString);
		
		log.setter("statement used "+retrieveString);
		List<CsdFtp00fDTO> toReturn=null;
		try {
			stmt = conn.prepareStatement(retrieveString);
			
			log.debug("execute query");
			this.rs = stmt.executeQuery();
			log.debug("query executed...read data");
			toReturn= new ArrayList<CsdFtp00fDTO>();
			while(rs.next()){
				CsdFtp00fDTO appo = new CsdFtp00fDTO();
				//   CSDDATA, 1
				appo.setCsddata(rs.getBigDecimal(1));
			 	//   CSDORA, "+2
				appo.setCsdora(rs.getBigDecimal(2));
				//	CSDTELA, "+3
				appo.setCsdtela(rs.getString(3));
				//	CSDMKT, "+4
				appo.setCsdmkt(rs.getString(4));
				//	CSDTIPO, "+5
				appo.setCsdtipo(rs.getString(5));
				//	CSDPROG, "+6
				appo.setCsdprog(rs.getBigDecimal(6));
				//	CSDISIN, "+7
				appo.setCsdisin(rs.getString(7));
				//	CSDDESCR, "+8
				appo.setCsddescr(rs.getString(8));
				//	CSDSETTL, "+9
				appo.setCsdsettl(rs.getString(9));
				//	CSDCURTR, "+10
				appo.setCsdsettl(rs.getString(10));
				//	CSDCURSE, "+11
				appo.setCsdcurse(rs.getString(11));
				//	CSDNAZIO, "+12
				appo.setCsdnazio(rs.getString(12));
				//	CSDDTNEG, "+13
				appo.setCsddtneg(rs.getBigDecimal(13));
				//	CSDDTEMI, "+14
				appo.setCsddtemi(rs.getBigDecimal(14));
				//	CSDDTSCA, "+15
				appo.setCsddtsca(rs.getBigDecimal(15));
				//	CSDESTEN, "+16
				appo.setCsdesten(rs.getString(16));
				//	CSDPERPE, "+17
				appo.setCsdperpe(rs.getString(17));
				//	CSDSTRUT, "+18
				appo.setCsdstrut(rs.getString(18));
				//	CSDTSOST, "+19
				appo.setCsdtsost(rs.getString(19));
				//	CSDTPSTR, "+20
				appo.setCsdtpstr(rs.getString(20));
				//	CSDAMORT, "+21
				appo.setCsdamort(rs.getString(21));
				//	CSDNEXTQ, "+22
				appo.setCsdnextq(rs.getBigDecimal(22));
				//	CSDFREQU, "+23
				appo.setCsdfrequ(rs.getBigDecimal(23));
				//	CSDPERCE, "+24
				appo.setCsdperce(rs.getBigDecimal(24));
				//	CSDPOOLF, "+25
				appo.setCsdpoolf(rs.getBigDecimal(25));
				//	CSDESCCP, "+26
				appo.setCsdesccp(rs.getString(26));
				//	CSDRIFIU, "+27
				appo.setCsdrifiu(rs.getString(27));
				//	TDESC, "+28
				appo.setTdesc(rs.getString(28));
				//	TEXCH, "+29
				appo.setTexch(rs.getBigDecimal(29));
				//	TCURRNE, "+30
				appo.setTcurrne(rs.getString(30));
				//	TCURRLQ, "+31
				appo.setTcurrlq(rs.getString(31));
				//	TPSEMIT, "+32
				appo.setTpsemit(rs.getString(32));
				//	TDTAEM, "+33
				appo.setTdtaem(rs.getBigDecimal(33));
				//	TDESEMI, "+34
				appo.setTdesemi(rs.getString(34));
				//	TCODEMI, "+35
				appo.setTcodemi(rs.getString(35));
				//	TTPSTR, "+36
				appo.setTtpstr(rs.getString(36));
				//	TPCERT, "+37
				appo.setTpcert(rs.getString(37));
				//	TTPBOND, "+38
				appo.setTtpbond(rs.getString(38));
				//	TTPMAT, "+39
				appo.setTtpmat(rs.getString(39));
				//	TSCAPER, "+40
				appo.setTscaper(rs.getString(40));
				//	TFLGPER, "+41
				appo.setTflgper(rs.getString(41));
				//	TDTAEXP, "+42
				appo.setTdtaexp(rs.getBigDecimal(42));
				//	TDTAEXPU, "+43
				appo.setTdtaexpu(rs.getBigDecimal(43));
				//	TSCAEXT, "+44
				appo.setTscaext(rs.getString(44));
				//	TFLGEST, "+45
				appo.setTflgest(rs.getString(45));
				//	TFLGACCT, "+46
				appo.setTflgacct(rs.getString(46));
				//	TFLCURNEG, "+47
				appo.setTflcurneg(rs.getString(47));
				//	TFLCURLIQ, "+48
				appo.setTflcurliq(rs.getString(48));
				//	TFLCURDUB, "+49
				appo.setTflcurdub(rs.getString(49));
				//	TFLSTRUC, "+50
				appo.setTflstruc(rs.getString(50));
				//	TFLAMORT, "+51
				appo.setTflamort(rs.getString(51));
				//	TFLGEL, "+52
				appo.setTflgel(rs.getString(52));
				//	TDTAEL, "+53
				appo.setTdtael(rs.getBigDecimal(53));
				//	TORAEL, "+54
				appo.setTorael(rs.getBigDecimal(54));
				//	TUSER, "+55
				appo.setTuser(rs.getString(55));
				//	TPROG, "+56
				appo.setTprog(rs.getString(56));
				//	TDTAIN, "+57
				appo.setTdtain(rs.getBigDecimal(57));
				//	TUSERIN, "+58
				appo.setTuserin(rs.getString(58));
				//	TDTABLO, "+59
				appo.setTdtablo(rs.getBigDecimal(59));
				//	TTIMEBLO" 60
				appo.setTtimeblo(rs.getBigDecimal(60));
				appo.setTinfbloo("N");
				toReturn.add(appo);
				log.setter("-----------------------------------------");
			}
			log.setter("###################################################");
		
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * Method that update CSDTIT00F table setting:
	 * "flag" fields with result; 
	 * TFINFBLOO to "N"; 
	 * TDTADLO and TTIMEBLO to Bloomberg Request date 
	 * @param <code>List<CsdTiT00fDTO></code> 
	 * @return <code>boolean</code> - update operation result
	 * @throws SendBlockingException
	 * @throws SendWarningException
	 */
	public boolean updateCsdFtp00fDTOResult(List<CsdFtp00fDTO> list) throws SendBlockingException, SendWarningException{
		log.debug("in boolean updateCsdFtp00fDTOResult(List<CsdFtp00fDTO> list) throws SendBlockingException, SendWarningException");
		String updateString = "UPDATE CCG_CGIT.CSDFTP00F " +
							  "   SET TDESC=?, " +
							  " 	  TEXCH=?, " +
							  " 	TCURRNE=?, " +
							  " TCURRLQ=?, " +
							  " TPSEMIT=?, " +
							  " TDTAEM=?, " +
							  " TDESEMI=?, " +
							  " TCODEMI=?, " +
							  " TTPSTR=?, " +
							  " TPCERT=?, " +
							  " TTPBOND=?, " +
							  " TTPMAT=?, " +
							  " TSCAPER=?, " +
							  " TFLGPER=?, " +
							  " TDTAEXP=?, " +
							  " TDTAEXPU=?, " +
							  " TSCAEXT=?, " +
							  " TFLGEST=?, " +
							  " TFLGACCT=?, " +
							  " TFLCURNEG=?, " +
							  " TFLCURLIQ=?, " +
							  " TFLCURDUB=?, " +
							  " TFLSTRUC=?, " +
							  " TFLAMORT=?, " +
							  " TFLGEL=?, " +
							  " TDTAEL=?, " +
							  " TORAEL=?, " +
							  " TUSER=?, " +
							  " TPROG=?, " +
							  " TDTAIN=?, " +
							  " TUSERIN=?, " +
							  " TINFBLOO=?, " +
							  " TDTABLO=?, " +
							  " TTIMEBLO=?  " +
							  " WHERE CSDISIN = ?" +
							  " AND CSDTELA = 2";    
				
		log.debug("statement used "+updateString);
		boolean toReturn=false;
		log.debug("check data's consistency");
		for (CsdFtp00fDTO i : list){
			if (i.getCsdisin() ==null || i.getCsdisin().equalsIgnoreCase("")){
				String field="";
				if (i.getCsdisin()==null || i.getCsdisin().equalsIgnoreCase(""))
					field+="ISINCODE ";
				
				if (i.getTflgper()==null)
					field+="TFLGPER ";
				
				if (i.getTflgest()==null)
					field+="TFLGEST ";
				
				if (i.getTflgacct()==null)
					field+="TFLGACCT ";
				
				if (i.getTflstruc()==null)
					field+="TFLSTRUC ";
				
				if (i.getTflamort()==null)
					field+="TFLAMORT ";
				
				if(i.getTinfbloo()==null)
					field+="TINFBLOO ";
					
				if(i.getTdtael() == null)
					field+="TORAEL ";	
				
				log.error("NoSuchFieldException: DATA INCOMPLETE "+field);
				throw new SendBlockingException("DATA INCOMPLETE "+field);
			}
		}
		log.debug("check ok");
		log.setter("statement used "+updateString);
		try {
			this.stmt = conn.prepareStatement(updateString);
			
			log.debug("statement instantiated start to popolate it");
			for (CsdFtp00fDTO i : list){
			  // TDESC=?, " private String tdesc; + 1
				stmt.setString(1, i.getTdesc());
			  // TEXCH=?, " private BigDecimal texch;+2
				stmt.setBigDecimal(2, i.getTexch());
			  // TCURRNE=?, " private String tcurrne;+3
				stmt.setString(3, i.getTcurrne());
			  // TCURRLQ=?, " private String tcurrlq;+4
				stmt.setString(4, i.getTcurrlq());
			  // TPSEMIT=?, " private String tpsemit;+5
				stmt.setString(5, i.getTpsemit());
			  // TDTAEM=?, " private BigDecimal tdtaem;+6
				stmt.setBigDecimal(6, i.getTdtaem());
			  // TDESEMI=?, " private String tdesemi;+7
				stmt.setString(7, i.getTdesemi());
			  // TCODEMI=?, " private String tcodemi;+8
				stmt.setString(8, i.getTcodemi());
			  // TTPSTR=?, " private String ttpstr;+9
				stmt.setString(9, i.getTtpstr());
			  // TPCERT=?, " private String tpcert;+10
				stmt.setString(10, i.getTpcert());
			  // TTPBOND=?, " private String ttpbond;+11
				stmt.setString(11, i.getTtpbond());
			  // TTPMAT=?, " private String ttpmat;+12
				stmt.setString(12, i.getTtpmat());
			  // TSCAPER=?, " private String tscaper;+13
				stmt.setString(13, i.getTscaper());
			  // TFLGPER=?, " private String tflgper;+14
				stmt.setString(14, i.getTflgper());
			  // TDTAEXP=?, " private BigDecimal tdtaexp;+15
				stmt.setBigDecimal(15, i.getTdtaexp());
			  // TDTAEXPU=?, " private BigDecimal tdtaexpu;+16
				stmt.setBigDecimal(16, i.getTdtaexpu());
			  // TSCAEXT=?, " private String tscaext;+17
				stmt.setString(17, i.getTscaext());
			  // TFLGEST=?, " private String tflgest;+18
				stmt.setString(18, i.getTflgest());
			  // TFLGACCT=?, " private String tflgacct;+19
				stmt.setString(19, i.getTflgacct());
			  // TFLCURNEG=?, " private String tflcurneg;+20
				stmt.setString(20, i.getTflcurneg());
			  // TFLCURLIQ=?, " private String tflcurliq;+21
				stmt.setString(21, i.getTflcurliq());
				// TFLCURDUB=?, " private String tflcurdub;+22
				stmt.setString(22, i.getTflcurdub());
			  // TFLSTRUC=?, " private String tflstruc;+23
				stmt.setString(23, i.getTflstruc());
			  // TFLAMORT=?, " private String tflamort;+24
				stmt.setString(24, i.getTflamort());
			  // TFLGEL=?, " private String tflgel;+25
				stmt.setString(25, i.getTflgel());
			  // TDTAEL=?, " private BigDecimal tdtael;+26
				stmt.setBigDecimal(26, i.getTdtael());
			  // TORAEL=?, " private BigDecimal torael;+27
				stmt.setBigDecimal(27, i.getTorael());
			  // TUSER=?, " private String tuser;+28
				stmt.setString(28, i.getTuser());
			  // TPROG=?, " private String tprog;+29
				stmt.setString(29, i.getTprog());
			  // TDTAIN=?, " private BigDecimal tdtain;+30
				stmt.setBigDecimal(30, i.getTdtain());
			  // TUSERIN=?, " private String tuserin;+31
				stmt.setString(31, i.getTuserin());
			  // TINFBLOO=?, " private String tinfbloo;+32
				stmt.setString(32, i.getTinfbloo());
			  // TDTABLO=?, " private BigDecimal tdtablo;+33
				stmt.setBigDecimal(33, i.getTdtablo());
			  // TTIMEBLO=?  " private BigDecimal ttimeblo;+34
				stmt.setBigDecimal(34, i.getTtimeblo());
			  // WHERE CSDISIN = ?private String csdisin;";  35
				log.setter("CSDISIN "+i.getTtimeblo());
				stmt.setString(35, i.getCsdisin());
				
				log.debug("update into CCG_CGIT.CSDFTP00F");
				toReturn=stmt.execute();
			}
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if (stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
}
