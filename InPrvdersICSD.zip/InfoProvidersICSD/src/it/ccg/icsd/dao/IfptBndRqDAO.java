/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd.dao;

import it.ccg.icsd.connection.RomaEnvConnector;
import it.ccg.icsd.dto.IfptBndRqDTO;
import it.ccg.icsd.exception.SendBlockingException;
import it.ccg.icsd.exception.SendWarningException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

public class IfptBndRqDAO {

	private static final Logger log = Logger.getLogger("it.ccg.icsd.dao.IfptBndRqDAO");
	private Connection conn;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	public IfptBndRqDAO() throws SendBlockingException {
		log.debug("in default constructor");
		try {
			RomaEnvConnector bdConnection = new RomaEnvConnector();
			log.debug("getting connection");
			conn = bdConnection.getConnection();
		} catch (SendBlockingException e) {
			log.error("SendBlockingException "+e.getCause().getMessage());
			throw e;
		}
	}
	
	/**
	 * 
	 * @param list <code>List<IfptBndRqDTO></code>
	 * @return <code>boolean</code>
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public boolean insertIfptBndRq(List<IfptBndRqDTO> list) throws SendWarningException, SendBlockingException{
		log.debug("in boolean insertIfptBndRq(List<IfptBndRqDTO> list) throws SendWarningException, SendBlockingException");
				
		String insertString = "INSERT INTO INFOP.IFPTBNDRQ (REQUESTID,REQSTATUS,RESPONSEID,RESPSTATUS,RQDATE,RSDATE,UPDDATE,UPDTYPE,UPDUSR)"+
                									  "VALUES (?,?,?,?,?,?,?,?,?)";
		log.debug("statement used "+insertString);
		boolean toReturn=false;
		log.debug("check data's consistency");
		for (IfptBndRqDTO i : list){
			if (i.getRequestId()==null || i.getRequestId().equalsIgnoreCase("")){
				log.error("NoSuchFieldException: DATA INCOMPLETE REQUESTID");
				throw new SendWarningException("DATA INCOMPLETE REQUESTID");
			}
		}
		log.debug("check ok");
		log.setter("statement used "+insertString);
		try {
			this.stmt = conn.prepareStatement(insertString);
			
			log.debug("statement instantiated, start to popolate it");
			for (IfptBndRqDTO i : list){
				log.setter("set REQUESTID value "+i.getRequestId());
				stmt.setString(1, i.getRequestId());
				log.setter("set REQSTATUS value "+i.getRequestStatus());
				stmt.setInt(2, i.getResponseStatus());
				
				if(i.getResponseId()==null){
					log.setter("set RESPONSEID value null");
					stmt.setNull(3, Types.VARCHAR);
				}else{
					log.setter("set RESPONSEID value "+i.getResponseId());
					stmt.setString(3, i.getResponseId());
				}
				
				if(i.getResponseStatus()==null){
					log.setter("set RESPSTATUS value null");
					stmt.setNull(4, Types.INTEGER);
				}else{
					log.setter("set RESPSTATUS value "+i.getResponseStatus());
					stmt.setInt(4, i.getResponseStatus());
				}

				if(i.getReqDate()==null){
					log.setter("set RQDATE value null");
					stmt.setNull(5, Types.TIMESTAMP);
				}else{
					log.setter("set RQDATE value "+i.getReqDate());
					stmt.setTimestamp(5, i.getReqDate());
				}

				if(i.getRespDate()==null){
					log.setter("set RSDATE value null");
					stmt.setNull(6, Types.TIMESTAMP);
				}else{
					log.setter("set RSDATE value "+i.getRespDate());
					stmt.setTimestamp(6, i.getRespDate());
				}

				log.setter("set UPDDATE");
				stmt.setTimestamp(7, new Timestamp(new Date().getTime()));
				log.setter("set UPDTYPE value I");
				stmt.setString(6, "I");
				log.setter("set UPDUSR value SYSTEM");
				stmt.setString(6, "SYSTEM");
				
				log.debug("insert into INFOP.IFPTBNDRQ");
				toReturn=stmt.execute();
			}
			
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if (stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * 
	 * @param dto <code>IfptBndRqDTO</code>
	 * @return <code>boolean</code>
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public boolean insertIfptBndRq(IfptBndRqDTO dto) throws SendWarningException, SendBlockingException{
		log.debug("in boolean insertIfptBndRq(IfptBndRqDTO dto) throws SendWarningException, SendBlockingException");
				
		String insertString = "INSERT INTO INFOP.IFPTBNDRQ (REQUESTID,REQSTATUS,RESPONSEID,RESPSTATUS,RQDATE,RSDATE,UPDDATE,UPDTYPE,UPDUSR)"+
                									  "VALUES (?,?,?,?,?,?,?,?,?)";
		log.debug("statement used "+insertString);
		boolean toReturn=false;
		log.debug("check data's consistency");
		if (dto.getRequestId()==null || dto.getRequestId().equalsIgnoreCase("")){
			log.error("NoSuchFieldException: DATA INCOMPLETE REQUESTID");
			throw new SendWarningException("DATA INCOMPLETE REQUESTID");
		}
		log.debug("check ok");
		log.setter("statement used "+insertString);
		try {
			this.stmt = conn.prepareStatement(insertString);
			
			log.debug("statement instantiated start to popolate it");
			log.setter("set REQUESTID value "+dto.getRequestId());
			stmt.setString(1, dto.getRequestId());
			log.setter("set REQSTATUS value "+dto.getRequestStatus().intValue());
			try{
				stmt.setInt(2, dto.getResponseStatus().intValue());
			}catch(NullPointerException e){
				log.error("NullPointerException REQSTATUS "+e.getMessage());
				stmt.setNull(2, Types.INTEGER);
			}
			if(dto.getResponseId()==null){
				log.setter("set RESPONSEID value null");
				stmt.setNull(3, Types.VARCHAR);
			}else{
				log.setter("set RESPONSEID value "+dto.getResponseId());
				stmt.setString(3, dto.getResponseId());
			}
			
			if(dto.getResponseStatus()==null){
				log.setter("set RESPSTATUS value null");
				stmt.setNull(4, Types.INTEGER);
			}else{
				log.setter("set RESPSTATUS value "+dto.getResponseStatus());
				stmt.setInt(4, dto.getResponseStatus());
			}

			if(dto.getReqDate()==null){
				log.setter("set RQDATE value null");
				stmt.setNull(5, Types.TIMESTAMP);
			}else{
				log.setter("set RQDATE value "+dto.getReqDate());
				stmt.setTimestamp(5, dto.getReqDate());
			}

			if(dto.getRespDate()==null){
				log.setter("set RSDATE value null");
				stmt.setNull(6, Types.TIMESTAMP);
			}else{
				log.setter("set RSDATE value "+dto.getRespDate());
				stmt.setTimestamp(6, dto.getRespDate());
			}
			log.setter("set UPDDATE");
			stmt.setTimestamp(7, new Timestamp(new Date().getTime()));
			log.setter("set UPDTYPE value I");
			stmt.setString(8, "I");
			log.setter("set UPDUSR value SYSTEM");
			stmt.setString(9, "SYSTEM");
			
			log.debug("insert into INFOP.IFPTBNDRQ");
			toReturn=stmt.execute();
			
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if (stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * 
	 * @param dto <code>IfptBndRqDTO</code>
	 * @return <code>List<IfptBndRqDTO></code>
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public List<IfptBndRqDTO> retrieveIfptBndRqByRequestId(IfptBndRqDTO dto) throws SendWarningException, SendBlockingException{
		log.debug("in List<IfptBndRqDTO> retrieveIfptBndRqByRequestId(IfptBndRqDTO dto) throws SendWarningException, SendBlockingException");
		
		String retrieveString = "SELECT REQSTATUS,"+
						              " RESPONSEID,"+
						              " RESPSTATUS,"+
						              " RQDATE,"+
						              " RSDATE,"+
						              " UPDDATE,"+
						              " UPDTYPE,"+
						              " UPDUSR"+
						         " FROM INFOP.IFPTBNDRQ"+ 
						        " WHERE REQUESTID = ?";
		
		log.debug("statement used "+retrieveString);
		log.debug("check data's consistency");
		if (dto.getRequestId()==null || dto.getRequestId().equalsIgnoreCase("")){
			log.error("NoSuchFieldException: DATA INCOMPLETE REQUESTID");
			throw new SendWarningException("DATA INCOMPLETE REQUESTID");
		}
		log.debug("check ok");
		log.setter("statement used "+retrieveString);
		List<IfptBndRqDTO> toReturn=null;
		try {
			stmt = conn.prepareStatement(retrieveString);
			
			log.setter("set REQUESTID value "+dto.getRequestId());
			stmt.setString(1, dto.getRequestId());
			
			log.debug("execute query");
			rs = stmt.executeQuery();
			log.debug("query executed...read data");
			toReturn = new ArrayList<IfptBndRqDTO>();
			while (rs.next()){
				IfptBndRqDTO appo = new IfptBndRqDTO();
				appo.setRequestId(dto.getRequestId());
				log.setter("set REQSTATUS values "+rs.getInt(1));
				appo.setRequestStatus(rs.getInt(1));
				log.setter("set RESPONSEID value "+rs.getString(2));
				appo.setResponseId(rs.getString(2));
				log.setter("set RESPSTATUS value "+rs.getInt(3));
				appo.setResponseStatus(rs.getInt(3));
				log.setter("set RQDATE");
				appo.setReqDate(rs.getTimestamp(4));
				log.setter("set RSDATE");
				appo.setRespDate(rs.getTimestamp(5));
				log.setter("set UPDDATE");
				appo.setUpdDate(rs.getTimestamp(6));
				log.setter("set UPDTYPE value "+rs.getString(7));
				appo.setUpdType(rs.getString(7));
				log.setter("set UPDUSR value "+rs.getString(8));
				appo.setUpdUsr(rs.getString(8));
				toReturn.add(appo);
				log.setter("-----------------------------------------");
			}
			log.setter("###################################################");
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;	
	}
	
	/**
	 * 
	 * @param dto <code>IfptBndRqDTO</code>
	 * @return <code>List<IfptBndRqDTO></code>
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public List<IfptBndRqDTO> retrieveIfptBndRqByResponseId(IfptBndRqDTO dto) throws SendWarningException, SendBlockingException{
		log.debug("in List<IfptBndRqDTO> retrieveIfptBndRqByResponseId(IfptBndRqDTO dto) throws SendWarningException, SendBlockingException");
		
		String retrieveString = "SELECT REQUESTID," +
									  " REQSTATUS,"+
						              " RESPSTATUS,"+
						              " RQDATE,"+
						              " RSDATE,"+
						              " UPDDATE,"+
						              " UPDTYPE,"+
						              " UPDUSR"+
						         " FROM INFOP.IFPTBNDRQ"+ 
						        " WHERE RESPONSEID = ?";
		
		log.debug("statement used "+retrieveString);
		log.debug("check data's consistency");
		if (dto.getResponseId()==null || dto.getResponseId().equalsIgnoreCase("")){
			log.error("NoSuchFieldException: DATA INCOMPLETE RESPONSEID");
			throw new SendWarningException("DATA INCOMPLETE RESPONSEID");
		}
		log.debug("check ok");
		log.setter("statement used "+retrieveString);
		List<IfptBndRqDTO> toReturn=null;
		try {
			stmt = conn.prepareStatement(retrieveString);
			
			log.setter("set RESPONSEID value "+dto.getRequestId());
			stmt.setString(1, dto.getRequestId());
			
			log.debug("execute query");
			rs = stmt.executeQuery();
			log.debug("query executed...read data");
			toReturn = new ArrayList<IfptBndRqDTO>();
			while (rs.next()){
				IfptBndRqDTO appo = new IfptBndRqDTO();
				appo.setRequestId(dto.getRequestId());
				log.setter("set REQUESTID values "+rs.getString(1));
				appo.setRequestId(rs.getString(1));
				log.setter("set REQSTATUS value "+rs.getInt(2));
				appo.setRequestStatus(rs.getInt(2));
				log.setter("set RESPSTATUS value "+rs.getInt(3));
				appo.setResponseStatus(rs.getInt(3));
				log.setter("set RQDATE");
				appo.setReqDate(rs.getTimestamp(4));
				log.setter("set RSDATE");
				appo.setRespDate(rs.getTimestamp(5));
				log.setter("set UPDDATE");
				appo.setUpdDate(rs.getTimestamp(6));
				log.setter("set UPDTYPE value "+rs.getString(7));
				appo.setUpdType(rs.getString(7));
				log.setter("set UPDUSR value "+rs.getString(8));
				appo.setUpdUsr(rs.getString(8));
				toReturn.add(appo);
				log.setter("-----------------------------------------");
			}
			log.setter("###################################################");
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
				
			}
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;	
	}
	
	/**
	 * 
	 * @param list <code>List<IfptBndRqDTO></code>
	 * @return <code>boolean</code>
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public boolean updateIfptBndRq(List<IfptBndRqDTO> list) throws SendWarningException, SendBlockingException{
		log.debug("in boolean updateIfptBndRq(List<IfptBndRqDTO> list) throws SendWarningException, SendBlockingException");
				
		String updateString = "UPDATE INFOP.IFPTBNDRQ SET REQSTATUS =?," +
														   " RESPONSEID =?," +
														   " RESPSTATUS=?," +
														   " RQDATE=?," +
														   " RSDATE=?," +
														   " UPDDATE=?," +
														   " UPDTYPE=?," +
														   " UPDUSR=?"+
                									 " WHERE REQUESTID =?";
		log.debug("statement used "+updateString);
		boolean toReturn=false;
		log.debug("check data's consistency");
		for (IfptBndRqDTO i : list){
			if (i.getRequestId()==null || i.getRequestId().equalsIgnoreCase("")){
				log.error("NoSuchFieldException: DATA INCOMPLETE REQUESTID");
				throw new SendWarningException("DATA INCOMPLETE REQUESTID");
			}
		}
		log.debug("check ok");
		log.setter("statement used "+updateString);
		try {
			this.stmt = conn.prepareStatement(updateString);
			
			log.debug("statement instantiated start to popolate it");
			for (IfptBndRqDTO i : list){
				log.setter("set REQSTATUS value "+i.getRequestStatus());
				stmt.setInt(1, i.getResponseStatus());
				log.setter("set RESPONSEID value "+i.getResponseId());
				stmt.setString(2, i.getResponseId());
				log.setter("set RESPSTATUS value "+i.getResponseStatus());
				stmt.setInt(3, i.getResponseStatus());
				log.setter("set RQDATE value "+i.getReqDate());
				stmt.setTimestamp(4, i.getReqDate());
				log.setter("set RSDATE value "+i.getRespDate());
				stmt.setTimestamp(5, i.getRespDate());
				log.setter("set UPDDATE");
				stmt.setTimestamp(6, new Timestamp(new Date().getTime()));
				log.setter("set UPDTYPE value U");
				stmt.setString(7, "U");
				log.setter("set UPDUSR value SYSTEM");
				stmt.setString(8, "SYSTEM");
				
				//where clause
				log.setter("set REQUESTID value "+i.getRequestId());
				stmt.setString(9, i.getRequestId());
				
				log.debug("update INFOP.IFPTBNDRQ");
				toReturn=stmt.execute();
			}
			
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if (stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/**
	 * 
	 * @param dto <code>IfptBndRqDTO</code
	 * @return <code>boolean</code>
	 * @throws SendWarningException 
	 * @throws SendBlockingException 
	 */
	public boolean updateIfptBndRq(IfptBndRqDTO dto) throws SendWarningException, SendBlockingException{
		log.debug("in boolean updateIfptBndRq(IfptBndRqDTO dto) throws SendWarningException, SendBlockingException");
				
		String updateString = "UPDATE INFOP.IFPTBNDRQ SET REQSTATUS =?," +
														   " RESPONSEID =?," +
														   " RESPSTATUS=?," +
														   " RQDATE=?," +
														   " RSDATE=?," +
														   " UPDDATE=?," +
														   " UPDTYPE=?," +
														   " UPDUSR=?"+
													 " WHERE REQUESTID =?";
		log.debug("statement used "+updateString);
		boolean toReturn=false;
		log.debug("check data's consistency");
		if (dto.getRequestId()==null || dto.getRequestId().equalsIgnoreCase("")){
			log.error("NoSuchFieldException: DATA INCOMPLETE REQUESTID");
			throw new SendWarningException("DATA INCOMPLETE REQUESTID");
		}
		log.debug("check ok");
		log.setter("statement used "+updateString);
		try {
			this.stmt = conn.prepareStatement(updateString);
			
			log.debug("statement instantiated start to popolate it");
			log.setter("set REQSTATUS value "+dto.getRequestStatus());
			stmt.setInt(1, dto.getResponseStatus());
			log.setter("set RESPONSEID value "+dto.getResponseId());
			stmt.setString(2, dto.getResponseId());
			log.setter("set RESPSTATUS value "+dto.getResponseStatus());
			stmt.setInt(3, dto.getResponseStatus());
			log.setter("set RQDATE value "+dto.getReqDate());
			stmt.setTimestamp(4, dto.getReqDate());
			log.setter("set RSDATE value "+dto.getRespDate());
			stmt.setTimestamp(5, dto.getRespDate());
			log.setter("set UPDDATE");
			stmt.setTimestamp(6, new Timestamp(new Date().getTime()));
			log.setter("set UPDTYPE value U");
			stmt.setString(7, "U");
			log.setter("set UPDUSR value SYSTEM");
			stmt.setString(8, "SYSTEM");
			
			//where clause
			log.setter("set REQUESTID value "+dto.getRequestId());
			stmt.setString(9, dto.getRequestId());
			
			log.debug("update INFOP.IFPTBNDRQ");
			toReturn=stmt.execute();
			
		} catch (SQLException e) {
			log.error("SQLException "+e.getMessage());
			throw new SendBlockingException(e);
		}finally{
			if (stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					log.warn("SQLException in close preparedStatement"+e.getMessage());
				}
			}
		}
		return toReturn;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#finalize()
	 */
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		if (conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				log.warn("SQLException in close connection "+e.getMessage());
			}
		}
		super.finalize();
	}
}
