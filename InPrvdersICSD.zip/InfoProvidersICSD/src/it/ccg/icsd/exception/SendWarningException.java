/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd.exception;

public class SendWarningException extends Exception {
	private String isinCode;
	
	public SendWarningException(String message, Throwable cause,boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public SendWarningException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SendWarningException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SendWarningException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	private String field;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SendWarningException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SendWarningException(String isinCode, String field, Throwable cause) {
		super(isinCode+" "+field, cause);
		this.field=field;
		this.isinCode=isinCode;
	}

	public SendWarningException(String isinCode, String field) {
		super(isinCode+" "+field);
		this.field=field;
		this.isinCode=isinCode;
	}

	/**
	 * @return the isinCode
	 */
	public String getIsinCode() {
		return isinCode;
	}

	/**
	 * @return the field
	 */
	public String getField() {
		return field;
	}	
}
