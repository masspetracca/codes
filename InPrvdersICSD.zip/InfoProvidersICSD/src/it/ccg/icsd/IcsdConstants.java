/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class IcsdConstants {
	
	private static final Logger log = Logger.getLogger("it.ccg.icsd.IcsdConstants");
	public static final int SUCCESS = 0;
	public static final int DATA_NOT_AVAILABLE = 100;

	public static final Properties prop;
	
	static{
		log.debug("in static block");
		prop = new Properties();
		try {
			log.debug("load properties");
			prop.load(new FileInputStream("/ICSD/ICSD.props"));
		} catch (FileNotFoundException e) {
			log.error("Error during execution FileNotFoundException "+e.getMessage());
			System.out.println("FileNotFoundException "+e.getMessage());
			System.exit(1);
		} catch (IOException e) {
			log.error("Error during execution IOException "+e.getMessage());
			System.out.println("IOException "+e.getMessage());
			System.exit(1);
		}
	}
}
