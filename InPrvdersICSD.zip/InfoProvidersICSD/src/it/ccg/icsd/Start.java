/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd;
import it.ccg.icsd.dao.CsdFtp00fDAO;
import it.ccg.icsd.dao.IfptBndDtDAO;
import it.ccg.icsd.dao.IfptBndDtHDAO;
import it.ccg.icsd.dao.IfptBndRqDAO;
import it.ccg.icsd.dto.CsdFtp00fDTO;
import it.ccg.icsd.dto.IfptBndDtDTO;
import it.ccg.icsd.dto.IfptBndDtHDTO;
import it.ccg.icsd.dto.IfptBndRqDTO;
import it.ccg.icsd.exception.BloomberException;
import it.ccg.icsd.exception.BloombergResponseException;
import it.ccg.icsd.exception.SendBlockingException;
import it.ccg.icsd.exception.SendWarningException;
import it.ccg.icsd.sender.EmailSender;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;

public class Start {
	
	private static final Logger log = Logger.getLogger("Start");
	private static EmailSender sender;
		
	
	public static void main(String[] args) {
		log.info("start of execution");
		int callCounter=0;

		try {

			sender = new EmailSender();
			List<String> isinToRetrieve = new ArrayList<String>();
			BloombergDataRetriever bond = null;
			
			IfptBndDtDAO dtDao = new IfptBndDtDAO();
			IfptBndDtHDAO dtHDao = new IfptBndDtHDAO();
			log.debug("call table to retrieve isin enabled");
			/*
			 * call table to retrieve isin enabled
			 */
			CsdFtp00fDAO csdFtpDato = new CsdFtp00fDAO();
			List<CsdFtp00fDTO>  listCsdFtp = csdFtpDato.retrieveCsdFtp00FToCheck();
			for (CsdFtp00fDTO s : listCsdFtp){
				isinToRetrieve.add(s.getCsdisin());
			}
			
			if (isinToRetrieve.size()==0){
				log.info("THERE ISN'T DATA TO RETRIEVE FROM BLOOMBERG WS");
				System.exit(0);
			}
			log.debug("there is "+isinToRetrieve.size()+" isin to retrieve");
			
			//get data from bloomberg
		    bond = new BloombergDataRetriever();
			
			List<IfptBndDtHDTO> instrsData = null;
			try{
				instrsData = bond.getData(isinToRetrieve);
			}catch(BloombergResponseException bREx){
				
				if(callCounter<Integer.parseInt(IcsdConstants.prop.getProperty("max.call.counter"))){
					callCounter++;
					log.debug("put thread in sleep for 1 minute");
					Thread.sleep(Long.parseLong(IcsdConstants.prop.getProperty("sleep.time")));
					log.debug("recall BloombergDataRetriever");
					try {
						instrsData = bond.getData(isinToRetrieve);
					} catch (BloombergResponseException e) {
						log.error("BloombergResponseException in catch BloombergResponseException "+bREx.getMessage());
						sender.sendErrorMail(new SendBlockingException("Response error from Bloomberg WS"));
					}
				}else{
					sender.sendErrorMail(new SendBlockingException("Response error from Bloomberg WS"));
				}
			}	
						
			//preparing date for cache table
			List<IfptBndDtDTO> cacheInstr = new ArrayList<IfptBndDtDTO>(); 
			IfptBndRqDAO RqDao = new IfptBndRqDAO(); 
			for (IfptBndDtHDTO dtHDTO : instrsData){
				IfptBndDtDTO dtDTO = new IfptBndDtDTO();
				PropertyUtils.copyProperties(dtDTO, dtHDTO);
				
				//compute data retrieved
				SecurableFieldCheck fieldCheck = new SecurableFieldCheck(dtDTO);
				fieldCheck.checkField();
				PropertyUtils.copyProperties(dtHDTO, dtDTO);
				cacheInstr.add(dtDTO);
			}
			
			//preparing data for result table
			for (IfptBndDtDTO dtDTO : cacheInstr){
				//copy computation result to List<CsdTiT00fDTO>
				for(CsdFtp00fDTO csdFtpDto : listCsdFtp){
					if (csdFtpDto.getCsdisin().equalsIgnoreCase(dtDTO.getIsinCode())){
						//retrieve bloomberg request date 
						IfptBndRqDTO appoDto = new IfptBndRqDTO();
						appoDto.setRequestId(dtDTO.getRequestId());
						List<IfptBndRqDTO> lista = RqDao.retrieveIfptBndRqByRequestId(appoDto);
						dtDTO.copyProperties(csdFtpDto);
						//PropertyUtils.copyProperties(csdFtpDto, dtDTO);
						Timestamp timeReq = lista.get(0).getReqDate();
						DateFormat df = new SimpleDateFormat("yyyyMMdd");
						DateFormat tf = new SimpleDateFormat("HHmmss");
						Date d = new Date(timeReq.getTime());
						csdFtpDto.setTinfbloo("Y");
						csdFtpDto.setTdtablo(new BigDecimal(df.format(d))) ;
						csdFtpDto.setTtimeblo(new BigDecimal(tf.format(d)));
					}
				}
			}
			
			//insert data in history table
			dtHDao.insertIfptDndDtH(instrsData);
			//update cache table
			dtDao.updateDataIntoIfptDndDt(cacheInstr);
			
			//PROVA
			for (CsdFtp00fDTO appo : listCsdFtp){
				appo.setTinfbloo("Y");
			}
			//update result table
			csdFtpDato.updateCsdFtp00fDTOResult(listCsdFtp);
			
		} catch (SendBlockingException e) {
			log.error("SendBlockingException "+e.getMessage());
			try {
				sender.sendErrorMail(e);
			} catch (MessagingException e1) {
				log.error("MessagingException "+e1.getMessage());
				System.out.println("MessagingException "+e1.getMessage());
				System.exit(1);
			}
			log.error("SendBlockingException "+e.getMessage());
			System.out.println("SendBlockingException "+e.getMessage());
			System.exit(1);
		} catch (SendWarningException e) {
			log.error("Error during execution SendWarningException "+e.getMessage());
			try {
				sender.sendWarningMailToResponsible(e);
			} catch (MessagingException e1) {
				log.error("Error during execution MessagingException "+e1.getMessage());
				System.out.println("MessagingException "+e1.getMessage());
				System.exit(1);
			}
			log.error("SendWarningException "+e.getMessage());
			System.out.println("SendWarningException "+e.getMessage());
			System.exit(1);
		} catch (IllegalAccessException e) {
			log.error("Error during execution IllegalAccessException "+e.getMessage());
			System.out.println("IllegalAccessException "+e.getMessage());
			System.exit(1);
		} catch (InvocationTargetException e) {
			log.error("Error during execution InvocationTargetException "+e.getMessage());
			System.out.println("InvocationTargetException "+e.getMessage());
			System.exit(1);
		} catch (NoSuchMethodException e) {
			log.error("Error during execution NoSuchMethodException "+e.getMessage());
			System.out.println("NoSuchMethodException "+e.getMessage());
			System.exit(1);
		} catch (NumberFormatException e) {
			log.error("Error during execution NumberFormatException "+e.getMessage());
			System.out.println("NumberFormatException "+e.getMessage());
			System.exit(1);
		} catch (InterruptedException e) {
			log.error("Error during execution InterruptedException "+e.getMessage());
			System.out.println("InterruptedException "+e.getMessage());
			System.exit(1);
		} catch (MessagingException e) {
			log.error("Error during execution MessagingException "+e.getMessage());
			System.out.println("MessagingException "+e.getMessage());
			System.exit(1);
		} catch (BloomberException e) {
			log.error("Error during execution BloomberException "+e.getMessage());
			System.out.println("BloomberException "+e.getMessage());
			System.exit(1);
		}
		log.info("everything gone");
	}
}
