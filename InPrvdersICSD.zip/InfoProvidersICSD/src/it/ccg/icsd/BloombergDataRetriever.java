/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd;

import it.ccg.icsd.dao.IfptBndRqDAO;
import it.ccg.icsd.dao.IfptBndRqIDAO;
import it.ccg.icsd.dto.IfptBndDtHDTO;
import it.ccg.icsd.dto.IfptBndRqDTO;
import it.ccg.icsd.dto.IfptBndRqIDTO;
import it.ccg.icsd.exception.BloomberException;
import it.ccg.icsd.exception.BloombergResponseException;
import it.ccg.icsd.exception.SendBlockingException;
import it.ccg.icsd.exception.SendWarningException;
import it.ccg.icsd.sender.EmailSender;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.xml.ws.Holder;

import org.apache.log4j.Logger;

import com.bloomberg.services.datalicense.dlws.ps._20071001.DateFormat;
import com.bloomberg.services.datalicense.dlws.ps._20071001.DiffFlag;
import com.bloomberg.services.datalicense.dlws.ps._20071001.Fields;
import com.bloomberg.services.datalicense.dlws.ps._20071001.GetDataHeaders;
import com.bloomberg.services.datalicense.dlws.ps._20071001.Instrument;
import com.bloomberg.services.datalicense.dlws.ps._20071001.InstrumentData;
import com.bloomberg.services.datalicense.dlws.ps._20071001.InstrumentType;
import com.bloomberg.services.datalicense.dlws.ps._20071001.Instruments;
import com.bloomberg.services.datalicense.dlws.ps._20071001.PerSecurityWS;
import com.bloomberg.services.datalicense.dlws.ps._20071001.PerSecurityWS_Service;
import com.bloomberg.services.datalicense.dlws.ps._20071001.ProgramFlag;
import com.bloomberg.services.datalicense.dlws.ps._20071001.ResponseStatus;
import com.bloomberg.services.datalicense.dlws.ps._20071001.RetrieveGetDataRequest;
import com.bloomberg.services.datalicense.dlws.ps._20071001.RetrieveGetDataResponse;

public class BloombergDataRetriever {
	private static final Logger log = Logger.getLogger("it.ccg.icsd.init.BloombergDataRetriever") ;
	private GetDataHeaders headers;
	private Fields fields;
	private Instruments instrs;
	private Holder<ResponseStatus> requestStatus;
	private Holder<String> requestId;
	private Holder<String> responseId;
	private EmailSender sender;
	
	/**
	 * 
	 * @throws SendBlockingException
	 */
	public BloombergDataRetriever() throws SendBlockingException{
		log.debug("in default constructor");
			
		log.debug("set properties for use pkcs12 certificate");
		log.debug("keyStore property " + IcsdConstants.prop.getProperty("keyStorePath"));
		System.setProperty("javax.net.ssl.keyStore",IcsdConstants.prop.getProperty("keyStorePath"));
		System.setProperty("javax.net.ssl.keyStorePassword", IcsdConstants.prop.getProperty("keyStorePassword"));
		log.debug("keyStoreType property "+IcsdConstants.prop.getProperty("keyStoreType"));
		System.setProperty("javax.net.ssl.keyStoreType", IcsdConstants.prop.getProperty("keyStoreType"));
		
		fields = new Fields();
		instrs = new Instruments();
		requestStatus = new Holder<ResponseStatus>();
		requestId = new Holder<String>();
		responseId = new Holder<String>();
		sender = new EmailSender();
	}
	
	/**
	 * Method that create a request with every ISIN in "instruments" list for retrieve information from Bloomberg WS. 
	 * @param <code>List<String></code>
	 * @return <code>List<IfptBndDtHDTO></code>
	 * @throws SendBlockingException
	 * @throws BloomberException
	 * @throws SendWarningException
	 * @throws BloombergResponseException
	 * @throws MessagingException
	 */
	public List<IfptBndDtHDTO> getData(List<String> instruments) throws SendBlockingException, BloomberException, SendWarningException, BloombergResponseException, MessagingException{
		log.debug("in List<IfptBndDtHDTO> getData(String[] instruments) throws BloomberException, InterruptedException");
		
		IfptBndRqDTO rqDTO = new IfptBndRqDTO();
		IfptBndRqIDTO rqIDTO = new IfptBndRqIDTO();
		IfptBndRqDAO rqDAO = new IfptBndRqDAO();;
		IfptBndRqIDAO rqiDAO = new IfptBndRqIDAO();;
		
		PerSecurityWS ws = new PerSecurityWS_Service().getPerSecurityWSPort();
		log.debug("istantiate and popolate GetDataHeaders");
		headers = new GetDataHeaders();
		headers.setClosingvalues(true);
		headers.setDateformat(DateFormat.YYYYMMDD);
		headers.setProgramflag(ProgramFlag.ONESHOT);
		headers.setSecmaster(true);
		headers.setDerived(true);
		headers.setEstimates(true);
		headers.setFundamentals(true);
		headers.setHistorical(true);
		headers.setQuotecomposite(true);
		headers.setQuotecompositehist(true);
		headers.setCreditrisk(true);
		headers.setVolSurface(true);
		headers.setBvalbeta(true);
		headers.setCreditrisk(true);
		headers.setDiffflag(DiffFlag.YES);
		headers.setExclusivePricingSrc(true);
		headers.setPricing(true);
		
		log.debug("popolate Fields variable");
		//zero based
		fields.getField().add("SECURITY_DES");//1
		fields.getField().add("START_ACC_DT");//2
		fields.getField().add("MATURITY");//3
		fields.getField().add("FINAL_MATURITY");//4
		fields.getField().add("MARKET_SECTOR_DES");//5
		fields.getField().add("IS_CERTIFICATE");//6
		fields.getField().add("ISSUER_INDUSTRY");//7
		fields.getField().add("ISSUER");//8
		fields.getField().add("CRNCY");//9
		fields.getField().add("REDEMP_CRNCY");//10
		fields.getField().add("DUAL_CRNCY");//11
		fields.getField().add("DAYS_TO_SETTLE");//12
		fields.getField().add("MTY_TYP");//13
		fields.getField().add("IS_PERPETUAL");//14
		fields.getField().add("EXTENDIBLE");//15
		fields.getField().add("BULLET");//16
		fields.getField().add("STRUCTURED_NOTE");//17
		fields.getField().add("LINKED_BONDS_IND");//18
		fields.getField().add("CPN_TYP");//19
		fields.getField().add("CPN_FREQ");//20
		fields.getField().add("CPN");//21
		fields.getField().add("RESET_IDX");//22
		fields.getField().add("UNDERLYING_SECURITY_DES");//23
		fields.getField().add("DES_NOTES");//24
		fields.getField().add("CNTRY_OF_RISK");//25
		fields.getField().add("REDEMP_VAL");//26
		fields.getField().add("PCT_PAR_QUOTED");//27
		fields.getField().add("PRO_RATA_SINK");//28
		/*
		 * rdelauri 08/05/2014
		 * elimino la richiesta di questo campo dato che in seguito alla mail del 05/05/2014 di Spallarossa
		 * risulta inutilizzabile
		 */
		//fields.getField().add("SINK_SCHEDULE_AMT_TYP");//29
		/*
		 * rdelauri fine modifica
		 */
		fields.getField().add("MOST_RECENT_REPORTED_FACTOR");//29
		fields.getField().add("SECURITY_FACTORABLE");//30
		fields.getField().add("INFLATION_LINKED_INDICATOR");//31
		fields.getField().add("PAR_AMT");//32
		fields.getField().add("PX_LAST");//33
		fields.getField().add("ID_ISIN");//34
		fields.getField().add("CALL_TYP");//35
		fields.getField().add("PX_CLOSE_DT");//36
		fields.getField().add("ID_BB");//37
		
		log.debug("popolate Instruments variable");
		for (String s : instruments){
			Instrument instr = new Instrument();
			instr.setId(s);
			instr.setType(InstrumentType.ISIN);
			instrs.getInstrument().add(instr);
		}
		
		log.debug("call WS method");
		rqDTO.setReqDate(new Timestamp(new Date().getTime()));
		ws.submitGetDataRequest(headers, null, fields, instrs, requestStatus, requestId, responseId);
		log.debug("requestStatusCode: "+requestStatus.value.getDescription());
		
		if(requestStatus.value.getCode()!= IcsdConstants.SUCCESS){
			log.debug("error during submitGetDataRequest throw BloombergException");
			throw new BloomberException(requestStatus.value.getDescription());
		}
		
		/*
		 * save request details
		 */
		log.debug("save request details");
		rqDTO.setRequestId(requestId.value);
		rqDTO.setRequestStatus(requestStatus.value.getCode());
		rqDAO.insertIfptBndRq(rqDTO);
		
		log.debug("request details saved");
		log.debug("save request-instruments details");
		for (String s : instruments){
			rqIDTO.setIsinCode(s);
			rqIDTO.setRequestId(requestId.value);
			rqiDAO.insertIfptBndRqI(rqIDTO);
		}
		log.debug("request-instruments details saved");
		
		log.debug("retrieve data response");
		RetrieveGetDataRequest retrieveReq = new RetrieveGetDataRequest();
		retrieveReq.setResponseId(responseId.value);
		RetrieveGetDataResponse response = ws.retrieveGetDataResponse(retrieveReq);

		while(response.getStatusCode().getCode()==IcsdConstants.DATA_NOT_AVAILABLE){
			log.debug("data not yet available...put in sleep main thread");
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				log.error("InterruptedException "+e.getMessage());
				throw new SendBlockingException(e);
			}
			response = ws.retrieveGetDataResponse(retrieveReq);
		}
		log.debug("responseStatusCode: "+response.getStatusCode().getDescription());
		if (response.getStatusCode().getCode()!= IcsdConstants.SUCCESS){
			log.debug("error during retrieveGetDataResponse ");
			throw new BloombergResponseException(response.getStatusCode().getDescription());
		}
		/*
		 * update request details with response data
		 */
		log.debug("save response details");
		rqDTO.setResponseId(responseId.value);
		rqDTO.setResponseStatus(response.getStatusCode().getCode());
		rqDTO.setRespDate(new Timestamp(new Date().getTime()));
		rqDAO.updateIfptBndRq(rqDTO);
		
		
		log.debug("create IfptBndDtHDto's List");
		List <IfptBndDtHDTO> listToReturn = new ArrayList <IfptBndDtHDTO>();
		List <SendWarningException> warnings = new ArrayList<SendWarningException>();
		for (InstrumentData i : response.getInstrumentDatas().getInstrumentData()){
			IfptBndDtHDTO dtoAppo = new IfptBndDtHDTO();
			log.setter("set Request ID");
			dtoAppo.setRequestId(requestId.value);
			//fields.getField().add("ID_ISIN");//35
			log.setter("set INSTR_ID "+i.getData().get(33).getValue());
			dtoAppo.setIsinCode(i.getData().get(33).getValue());
			//fields.getField().add("SECURITY_DES");//1 *
			log.setter("set SECURITY_DES "+i.getData().get(0).getValue());
			if (i.getData().get(0).getValue()==null || i.getData().get(0).getValue().equalsIgnoreCase("")){
				log.error("SECURITY_DES NOT AVAILABLE "+i.getData().get(33).getValue());
				//throw new NoSuchFieldException("SECURITY_DES NOT AVAILABLE");
			}
			dtoAppo.setSecurityDes(i.getData().get(0).getValue());
			
			//fields.getField().add("START_ACC_DT");//2 *
			log.setter("set START_ACC_DT "+i.getData().get(1).getValue());
			try{
				dtoAppo.setStartAccDt(Integer.parseInt(i.getData().get(1).getValue()));
			}catch(NumberFormatException e){
				log.error("START_ACC_DT NOT AVAILABLE "+i.getData().get(33).getValue());
				//throw new NoSuchFieldException("START_ACC_DT NOT AVAILABLE");
				/*
				 * 
				 */
				dtoAppo.setStartAccDt(new Integer(0));
			}
			
			//fields.getField().add("MATURITY");//3 *
			log.setter("set MATURITY "+i.getData().get(2).getValue());
			try{
				dtoAppo.setMaturity(new Integer(i.getData().get(2).getValue()));
			}catch(NumberFormatException e){
				log.error("MATURITY NOT AVAILABLE "+i.getData().get(33).getValue());
				warnings.add(new SendWarningException("MATURITY NOT AVAILABLE FOR ISIN "+i.getData().get(33).getValue()));
				//valore per far scattare l'alert
				dtoAppo.setMaturity(0);
			}
			
			//fields.getField().add("FINAL_MATURITY");//4 *
			log.setter("set FINAL_MATURITY "+i.getData().get(3).getValue());
			try{
				dtoAppo.setFinalMaturity(new Integer(i.getData().get(3).getValue()));
			}catch(NumberFormatException e){
				log.error("FINAL_MATURITY NOT AVAILABLE "+i.getData().get(33).getValue());
				warnings.add(new SendWarningException("FINAL_MATURITY NOT AVAILABLE FOR ISIN "+i.getData().get(33).getValue()));
				//valore per far scattare l'alert
				dtoAppo.setFinalMaturity(1);
			}
			
			//fields.getField().add("MARKET_SECTOR_DES");//5 *
			log.setter("set MARKET_SECTOR_DES "+i.getData().get(4).getValue());
			if (i.getData().get(4).getValue()==null || i.getData().get(4).getValue().equalsIgnoreCase("")){
				log.error("MARKET_SECTOR_DES NOT AVAILABLE "+i.getData().get(33).getValue());
				warnings.add(new SendWarningException("MARKET_SECTOR_DES NOT AVAILABLE FOR ISIN "+i.getData().get(33).getValue()));
				//valore per far scattare l'alert
				dtoAppo.setMarketSectorDes("");
			}else{
				dtoAppo.setMarketSectorDes(i.getData().get(4).getValue());
			}
			
			//fields.getField().add("IS_CERTIFICATE");//6 *
			log.setter("set IS_CERTIFICATE "+i.getData().get(5).getValue());
			if (i.getData().get(5).getValue()==null || i.getData().get(5).getValue().equalsIgnoreCase("") || (!i.getData().get(5).getValue().equalsIgnoreCase("y") && !i.getData().get(5).getValue().equalsIgnoreCase("n"))){
				log.error("IS_CERTIFICATE NOT AVAILABLE "+i.getData().get(33).getValue());
				warnings.add(new SendWarningException("IS_CERTIFICATE NOT AVAILABLE FOR ISIN "+i.getData().get(33).getValue()));
				//valore per far scattare l'alert
				dtoAppo.setCertificated(true);
			}else{
				dtoAppo.setCertificated(i.getData().get(5).getValue().equalsIgnoreCase("Y")?true:false);
			}
			
			//fields.getField().add("ISSUER_INDUSTRY");//7 
			log.setter("set ISSUER_INDUSTRY "+i.getData().get(6).getValue());
			dtoAppo.setIssuerIndustry(i.getData().get(6).getValue());
			
			//fields.getField().add("ISSUER");//8 *
			log.setter("set ISSUER "+i.getData().get(7).getValue());
			if (i.getData().get(7).getValue()==null || i.getData().get(7).getValue().equalsIgnoreCase("")){
				log.error("ISSUER NOT AVAILABLE "+i.getData().get(33).getValue());
			}
			dtoAppo.setIssuer(i.getData().get(7).getValue());
			
			//fields.getField().add("CRNCY");//9 *
			log.setter("set CRNCY "+i.getData().get(8).getValue());
			if (i.getData().get(8).getValue()==null || i.getData().get(8).getValue().equalsIgnoreCase("")){
				log.error("CRNCY NOT AVAILABLE "+i.getData().get(33).getValue());
				warnings.add(new SendWarningException("CRNCY NOT AVAILABLE FOR ISIN "+i.getData().get(33).getValue()));
				//valore per far scattare l'alert
				dtoAppo.setCrncy("ZZZ");
			}else{
				dtoAppo.setCrncy(i.getData().get(8).getValue());
			}
			
			//fields.getField().add("REDEMP_CRNCY");//10 *
			log.setter("set REDEMP_CRNCY "+i.getData().get(9).getValue());
			if (i.getData().get(9).getValue()==null || i.getData().get(9).getValue().equalsIgnoreCase("")){
				log.error("REDEMP_CRNCY NOT AVAILABLE "+i.getData().get(33).getValue());
				warnings.add(new SendWarningException("REDEMP_CRNCY NOT AVAILABLE FOR ISIN "+i.getData().get(33).getValue()));
				//valore per far scattare l'alert
				dtoAppo.setRedempCrncy("ZZZ");
			}else{
				dtoAppo.setRedempCrncy(i.getData().get(9).getValue());
			}
			
			//fields.getField().add("DUAL_CRNCY");//11 *
			log.setter("set DUAL_CRNCY "+i.getData().get(10).getValue());
			if (i.getData().get(10).getValue()==null || i.getData().get(10).getValue().equalsIgnoreCase("") || (!i.getData().get(10).getValue().equalsIgnoreCase("y") && !i.getData().get(10).getValue().equalsIgnoreCase("n"))){
				log.error("DUAL_CRNCY NOT AVAILABLE "+i.getData().get(33).getValue());
				warnings.add(new SendWarningException("DUAL_CRNCY NOT AVAILABLE FOR ISIN "+i.getData().get(33).getValue()));
				//valore per far scattare l'alert
				dtoAppo.setDualCrncy(true);
			}else{
				dtoAppo.setDualCrncy(i.getData().get(10).getValue().equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
			}
			
			
			//fields.getField().add("DAYS_TO_SETTLE");//12
			log.setter("set DAYS_TO_SETTLE "+i.getData().get(11).getValue());
			try{
				dtoAppo.setDayToSettle(new Integer(i.getData().get(11).getValue()));
			}catch(NumberFormatException e){
				log.warn("NumberFormatException - DAYS_TO_SETTLE hasn't number value");
				dtoAppo.setDayToSettle(null);
			}
						
			//fields.getField().add("MTY_TYP");//13 *
			log.setter("set MTY_TYP "+i.getData().get(12).getValue());
			if (i.getData().get(12).getValue()==null || i.getData().get(12).getValue().equalsIgnoreCase("")){
				log.error("MTY_TYP NOT AVAILABLE "+i.getData().get(33).getValue());
				warnings.add(new SendWarningException("MTY_TYP NOT AVAILABLE FOR ISIN "+i.getData().get(33).getValue()));
				//valore per far scattare l'alert
				dtoAppo.setMtyTyp("PERPETUAL");
			}else{
				dtoAppo.setMtyTyp(i.getData().get(12).getValue());
			}
			
			
			//fields.getField().add("IS_PERPETUAL");//14*
			log.setter("set IS_PERPETUAL "+i.getData().get(13).getValue());
			if (i.getData().get(13).getValue()==null || i.getData().get(13).getValue().equalsIgnoreCase("") || (!i.getData().get(13).getValue().equalsIgnoreCase("y") && !i.getData().get(13).getValue().equalsIgnoreCase("n"))){
				log.error("IS_PERPETUAL NOT AVAILABLE "+i.getData().get(33).getValue());
				warnings.add(new SendWarningException("IS_PERPETUAL NOT AVAILABLE FOR ISIN "+i.getData().get(33).getValue()));
				//valore per far scattare l'alert
				dtoAppo.setPerpetual(true);
			}else{
				dtoAppo.setPerpetual(i.getData().get(13).getValue().equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
			}
			
			//fields.getField().add("EXTENDIBLE");//15 *
			log.setter("set EXTENDIBLE "+i.getData().get(14).getValue());
			if (i.getData().get(14).getValue()==null || i.getData().get(14).getValue().equalsIgnoreCase("") || (!i.getData().get(14).getValue().equalsIgnoreCase("y") && !i.getData().get(14).getValue().equalsIgnoreCase("n"))){
				log.error("EXTENDIBLE NOT AVAILABLE "+i.getData().get(33).getValue());
				warnings.add(new SendWarningException("EXTENDIBLE NOT AVAILABLE FOR ISIN "+i.getData().get(33).getValue()));
				//valore per far scattare l'alert
				dtoAppo.setExtendible(true);
			}else{
				dtoAppo.setExtendible(i.getData().get(14).getValue().equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
			}
			
			//fields.getField().add("BULLET");//16 
			log.setter("set BULLET "+i.getData().get(15).getValue());
			if (i.getData().get(15).getValue() == null || i.getData().get(15).getValue().equalsIgnoreCase(""))
			{
				dtoAppo.setBullet(null);
			}else{
				dtoAppo.setBullet(i.getData().get(15).getValue().equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
			}
			
			
			//fields.getField().add("STRUCTURED_NOTE");//17 *
			log.setter("set STRUCTURED_NOTE "+i.getData().get(16).getValue());
			if (i.getData().get(16).getValue()==null || i.getData().get(16).getValue().equalsIgnoreCase("") || (!i.getData().get(16).getValue().equalsIgnoreCase("y") && !i.getData().get(16).getValue().equalsIgnoreCase("n"))){
				log.error("STRUCTURED_NOTE NOT AVAILABLE "+i.getData().get(33).getValue());
				warnings.add(new SendWarningException("STRUCTURED_NOTE NOT AVAILABLE FOR ISIN "+i.getData().get(33).getValue()));
				//valore per far scattare l'alert
				dtoAppo.setStructuredNote(true);
			}else{
				dtoAppo.setStructuredNote(i.getData().get(16).getValue().equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
			}
			
			//fields.getField().add("LINKED_BONDS_IND");//18 
			log.setter("set LINKED_BONDS_IND "+i.getData().get(17).getValue());
			if (i.getData().get(17).getValue() == null || i.getData().get(17).getValue().equalsIgnoreCase(""))
			{
				dtoAppo.setLinkedBondInd(null);
			}else{
				dtoAppo.setLinkedBondInd(i.getData().get(17).getValue().equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
			}
			
			//fields.getField().add("CPN_TYP");//19
			log.setter("set CPN_TYP "+i.getData().get(18).getValue());
			dtoAppo.setCpnTyp(i.getData().get(18).getValue());
			
			//fields.getField().add("CPN_FREQ");//20
			log.setter("set CPN_FREQ "+i.getData().get(19).getValue());
			try {
				dtoAppo.setCpnFreq(Integer.parseInt(i.getData().get(19).getValue()));
			}catch(NumberFormatException e){
				log.warn("NumberFormatException - CPN_FREQ hasn't number value");
				dtoAppo.setCpnFreq(null);
			}
			

			//fields.getField().add("CPN");//21
			log.setter("set CPN "+i.getData().get(20).getValue());
			try {
				dtoAppo.setCpn(new BigDecimal(i.getData().get(20).getValue()));
			}catch(NumberFormatException e){
				log.warn("NumberFormatException - CPN hasn't number value");
				dtoAppo.setCpn(null);
			}
			
			//fields.getField().add("RESET_IDX");//22
			log.setter("set RESET_IDX "+i.getData().get(21).getValue());
			dtoAppo.setResetIdx(i.getData().get(21).getValue());
			
			//fields.getField().add("UNDERLYING_SECURITY_DES");//23
			log.setter("set UNDERLYING_SECURITY_DES "+i.getData().get(22).getValue());
			dtoAppo.setUnderlyingSecurityDes(i.getData().get(22).getValue());
			
			//fields.getField().add("DES_NOTES");//24
			log.setter("set DES_NOTES "+i.getData().get(23).getValue());
			dtoAppo.setDesNote(i.getData().get(23).getValue());
			
			//fields.getField().add("CNTRY_OF_RISK");//25
			log.setter("set CNTRY_OF_RISK "+i.getData().get(24).getValue());
			dtoAppo.setCntryOfRisk(i.getData().get(24).getValue());
			
			//fields.getField().add("REDEMP_VAL");//26
			log.setter("set REDEMP_VAL "+i.getData().get(25).getValue());
			try {
				dtoAppo.setRedempVal(new BigDecimal(i.getData().get(25).getValue()));
			}catch(NumberFormatException e){
				log.warn("NumberFormatException - REDEMP_VAL hasn't number value");
				dtoAppo.setRedempVal(null);
			}

			//fields.getField().add("PCT_PAR_QUOTED");//27
			log.setter("set PCT_PAR_QUOTED "+i.getData().get(26).getValue());
			if (i.getData().get(26).getValue() == null || i.getData().get(26).getValue().equalsIgnoreCase(""))
			{
				dtoAppo.setPctParQuoted(null);
			}else{
				dtoAppo.setPctParQuoted(i.getData().get(26).getValue().equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
			}
			
			//fields.getField().add("PRO_RATA_SINK");//28
			log.setter("set PRO_RATA_SINK "+i.getData().get(27).getValue());
			if (i.getData().get(27).getValue() == null || i.getData().get(27).getValue().equalsIgnoreCase(""))
			{
				dtoAppo.setProRataSink(null);
			}else{			
				dtoAppo.setProRataSink(i.getData().get(27).getValue().equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
			}

			/*
			 * rdelauri 08/05/2014
			 * elimino la popolazione di questo campo, impostandolo al valore di default dato che in seguito alla mail del 05/05/2014 di Spallarossa
			 * risulta inutilizzabile
			 */
			//fields.getField().add("SINK_SCHEDULE_AMT_TYP");//29 *
			/*log.setter("set SINK_SCHEDULE_AMT_TYP "+i.getData().get(28).getValue());
			if (i.getData().get(28).getValue()==null || i.getData().get(28).getValue().equalsIgnoreCase("")){
				log.error("SINK_SCHEDULE_AMT_TYP NOT AVAILABLE "+i.getData().get(34).getValue());
				warnings.add(new SendWarningException("SINK_SCHEDULE_AMT_TYP NOT AVAILABLE FOR ISIN "+i.getData().get(34).getValue()));
				//valore per far scattare l'alert
				dtoAppo.setSinkScheduleAmtTyp("PERCENT");
			}else{
				dtoAppo.setSinkScheduleAmtTyp(i.getData().get(28).getValue());
			}*/
			dtoAppo.setSinkScheduleAmtTyp("PERCENT");
			/*
			 * rdelauri fine modifica
			 */
			
			//fields.getField().add("MOST_RECENT_REPORTED_FACTOR");//29 *
			try{
				dtoAppo.setMostRecentReportedFactor(new BigDecimal(i.getData().get(28).getValue()));
			}catch(NumberFormatException e){
				log.error("MOST_RECENT_REPORTED_FACTOR NOT AVAILABLE "+i.getData().get(33).getValue());
				warnings.add(new SendWarningException("MOST_RECENT_REPORTED_FACTOR NOT AVAILABLE FOR ISIN "+i.getData().get(33).getValue()));
				//valore per far scattare l'alert
				dtoAppo.setMostRecentReportedFactor(new BigDecimal(0));
			}
			
			//fields.getField().add("SECURITY_FACTORABLE");//30 *
			log.setter("set SECURITY_FACTORABLE "+i.getData().get(29).getValue());
			if (i.getData().get(29).getValue()==null || i.getData().get(29).getValue().equalsIgnoreCase("") || (!i.getData().get(29).getValue().equalsIgnoreCase("y") && !i.getData().get(29).getValue().equalsIgnoreCase("n"))){
				log.error("SECURITY_FACTORABLE NOT AVAILABLE "+i.getData().get(33).getValue());
				//throw new NoSuchFieldException("SECURITY_FACTORABLE NOT AVAILABLE");
			}
			dtoAppo.setSecurityFactorable(i.getData().get(29).getValue().equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
			
			//fields.getField().add("INFLATION_LINKED_INDICATOR");//31 
			log.setter("set INFLATION_LINKED_INDICATOR "+i.getData().get(30).getValue());
			if (i.getData().get(30).getValue() == null || i.getData().get(30).getValue().equalsIgnoreCase(""))
			{
				dtoAppo.setInflationLinkedIndicator(null);
			}else{			
				dtoAppo.setInflationLinkedIndicator(i.getData().get(30).getValue().equalsIgnoreCase("Y")?new Boolean(true):new Boolean(false));
			}
		
			//fields.getField().add("PAR_AMT");//32
			log.setter("set PAR_AMT "+i.getData().get(31).getValue());
			try {
				dtoAppo.setParAmt(new BigDecimal(i.getData().get(31).getValue()));
			}catch(NumberFormatException e){
				log.warn("NumberFormatException - PAR_AMT hasn't number value");
				dtoAppo.setParAmt(null);
			}
			
			//fields.getField().add("PX_LAST");//33
			log.setter("set PX_LAST "+i.getData().get(32).getValue());
			try{
				dtoAppo.setPxLast(new BigDecimal(i.getData().get(32).getValue()));
			}catch(NumberFormatException e){
				log.error("PX_LAST NOT AVAILABLE "+i.getData().get(33).getValue());
				dtoAppo.setPxLast(new BigDecimal(0.00));
			}
			
			//fields.getField().add("CALL_TYP");//35 
			log.setter("set CALL_TYP "+i.getData().get(34).getValue());
			dtoAppo.setCallType(i.getData().get(34).getValue());
			
			//fields.getField().add("PX_CLOSEDT");//36 *
			log.setter("set PX_CLOSE_DT "+i.getData().get(35).getValue());
			try {
				dtoAppo.setPxCloseDt(new Integer(i.getData().get(35).getValue()));
			}catch(NumberFormatException e){
				log.warn("NumberFormatException - PX_CLOSE_DT hasn't number value");
				dtoAppo.setPxCloseDt(null);
			}
			
			//fields.getField().add("ID_BB");//37
			log.setter("set ID_BB "+i.getData().get(36).getValue());
			dtoAppo.setBloomcode(i.getData().get(36).getValue());
			
			/*
			 * 
			 */
			dtoAppo.setUpdUsr("SYSTEM");
			dtoAppo.setUpdType("C");
			dtoAppo.setUpdDate(new Timestamp(new Date().getTime()));
			
			listToReturn.add(dtoAppo);
		}
		try{
			if (warnings.size()>0){
				EmailSender sender = new EmailSender();
				sender.sendWarningMailToResponsible(warnings);
			}
		}catch(Exception e){
			log.error(e.getMessage());
		}
		log.debug("return List with data from response");
		return listToReturn;
	}
}