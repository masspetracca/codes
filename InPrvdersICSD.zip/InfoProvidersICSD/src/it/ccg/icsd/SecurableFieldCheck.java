/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd;

import it.ccg.icsd.dao.CsdDtB00fDAO;
import it.ccg.icsd.dto.CsdDtB00fDTO;
import it.ccg.icsd.dto.IfptBndDtDTO;
import it.ccg.icsd.exception.SendBlockingException;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.apache.log4j.Logger;

public class SecurableFieldCheck {

	private IfptBndDtDTO dto;
	private static final Logger log = Logger.getLogger("it.ccg.icsd.SecurableFieldCheck");
	
	public SecurableFieldCheck(IfptBndDtDTO dto){
		this.dto = dto;
	}
	
	/**
	 * If test passed then dto variable setted to false
	 * @return <code>boolean</code> false if test passed, true if there is an alert to notify
	 */
	public boolean bondTitleTestPassed(){
		log.debug("in boolean titleBondTest()");
		
		log.debug("this.dto.getMarketSectorDes().equalsIgnoreCase(\"govt\") = "+this.dto.getMarketSectorDes().equalsIgnoreCase("govt"));
		if (this.dto.getMarketSectorDes().equalsIgnoreCase("govt")){
			log.debug("return true");
			this.dto.setTtpbond(true);
			return true;
		}else{
			log.debug("this.dto.getMarketSectorDes().equalsIgnoreCase(\"corp\") = "+this.dto.getMarketSectorDes().equalsIgnoreCase("corp"));
			if (this.dto.getMarketSectorDes().equalsIgnoreCase("corp")){
				log.debug("return "+!this.dto.getCertificated().booleanValue());
				this.dto.setTtpbond(!this.dto.getCertificated());
				return !this.dto.getCertificated();
			}else{
				log.debug("return false");
				this.dto.setTtpbond(false);
				return false;
			}
		}
	}
	
	/**
	 * If test passed then dto variable setted to false
	 */
	public void perpetualTestPassed(){
		log.debug("in boolean perpetualTest()");
		
		log.debug("this.dto.getMtyTyp().equalsIgnoreCase(\"perpetual\") = "+this.dto.getMtyTyp().equalsIgnoreCase("perpetual"));
		if(this.dto.getMtyTyp().equalsIgnoreCase("perpetual")){
			log.debug("return true");
			this.dto.setTflgper(true);
		}else {
			log.debug("this.dto.getPerpetual() = "+this.dto.getPerpetual());
			if(this.dto.getPerpetual()){
				log.debug("return true");
				this.dto.setTflgper(true);
			}else{
				//maturity format yyyymmdd
				String maturityString = this.dto.getMaturity().toString();
				log.debug("maturity value: (yyyymmdd)"+maturityString);
				log.debug("year substring maturity value: (yyyy)"+maturityString.substring(0,4));
				log.debug("mounth substring maturity value: (mm)"+maturityString.substring(4,6));
				log.debug("day substring maturity value: (dd)"+maturityString.substring(6,8));
				
				GregorianCalendar maturityCal = new GregorianCalendar(Integer.parseInt(maturityString.substring(0,4)),Integer.parseInt(maturityString.substring(4,6)),Integer.parseInt(maturityString.substring(6,8))); 
				GregorianCalendar todayCal = new GregorianCalendar();

				maturityCal.roll(Calendar.DAY_OF_YEAR, -todayCal.get(Calendar.DAY_OF_YEAR));
				log.debug("subtraction result : "+maturityCal.get(Calendar.DAY_OF_YEAR));
			
				if ((maturityCal.get(Calendar.DAY_OF_YEAR))/365 < 50){
					log.debug("return false");
					this.dto.setTflgper(false);
				}else{
					log.debug("return true");
					this.dto.setTflgper(true);
				}
			}
		}				
	}
	
	/**
	 * If test passed then dto variable setted to false
	 */
	public void extendibleTestPassed(){
		log.debug("in boolean extendibleTest()");
		
		log.debug("this.dto.getMaturity().equals(this.dto.getFinalMaturity()) = "+this.dto.getMaturity().equals(this.dto.getFinalMaturity()));
		if (this.dto.getMaturity().equals(this.dto.getFinalMaturity())){
			log.debug("this.dto.getExtendible() : "+this.dto.getExtendible().booleanValue());
			if(this.dto.getExtendible()){
				log.debug("return true");
				this.dto.setTflgest(true);
			}else{
				log.debug("return false");
				this.dto.setTflgest(false);
			}
		}else{
			log.debug("return true");
			this.dto.setTflgest(true);
		}
	}
	
	/**
	 * If test passed then dto variable setted to false
	 * @throws SendBlockingException
	 */
	public void denominationValueCensusTestPassed() throws SendBlockingException{
		log.debug("in boolean denominationValueCensusTest() throws SendBlockingException");
		
		CsdDtB00fDAO dao = new CsdDtB00fDAO();
		ArrayList<CsdDtB00fDTO> list = dao.getDenominationValueCensus();
		
		log.debug("list.contains(this.dto.getCrncy()) : "+list.contains(this.dto.getCrncy()));
		if(list.contains(this.dto.getCrncy())){
			log.debug("return false");
			this.dto.setTflcurneg(false);
		}else{
			log.debug("return true");
			this.dto.setTflcurneg(true);
		}
	}
	
	/**
	 * 
	 * If test passed then dto variable setted to false
	 * @throws SendBlockingException
	 */
	public void settlmentdenominationValueCensusTestPassed() throws SendBlockingException{
		log.debug("in boolean SettlmentdenominationValueCensusTest() throws SendBlockingException");
		
		CsdDtB00fDAO dao = new CsdDtB00fDAO();
		ArrayList<CsdDtB00fDTO> list = dao.getSettlmentValueCensus();
		
		log.debug("list.contains(this.dto.getCrncy()) : "+list.contains(this.dto.getCrncy()));
		if(list.contains(this.dto.getCrncy())){
			log.debug("return false");
			this.dto.setTflcurliq(false);
		}else{
			log.debug("return true");
			this.dto.setTflcurliq(true);
		}
	}

	/**
	 * If test passed then dto variable setted to false
	 */
	public void divergenceDenominationSettlemenCurrencyTestPassed(){
		log.debug("in boolean divergenceDenominationSettlemenCurrencyTestPassed()");
		
		log.debug("this.dto.getCrncy().equalsIgnoreCase(this.dto.getRedempCrncy()) result "+this.dto.getCrncy().equalsIgnoreCase(this.dto.getRedempCrncy()));
		if (this.dto.getCrncy().equalsIgnoreCase(this.dto.getRedempCrncy())){
			log.debug("this.dto.getDualCrncy() : "+this.dto.getDualCrncy());
			if (this.dto.getDualCrncy()){
				log.debug("return true");
				this.dto.setTflcurdub(true);
			}else{
				log.debug("return false");
				this.dto.setTflcurdub(false);
			}
		}else{
			log.debug("(this.dto.getCrncy().equalsIgnoreCase(\"ITL\") && this.dto.getRedempCrncy().equalsIgnoreCase(\"EUR\")) || " +
					  "(this.dto.getCrncy().equalsIgnoreCase(\"DEM\") && this.dto.getRedempCrncy().equalsIgnoreCase(\"EUR\")) || " +
					  "(this.dto.getCrncy().equalsIgnoreCase(\"BRL\") && this.dto.getRedempCrncy().equalsIgnoreCase(\"USD\")) result "+ ((this.dto.getCrncy().equalsIgnoreCase("ITL") && this.dto.getRedempCrncy().equalsIgnoreCase("EUR")) ||
																																		(this.dto.getCrncy().equalsIgnoreCase("DEM") && this.dto.getRedempCrncy().equalsIgnoreCase("EUR")) ||
																																		(this.dto.getCrncy().equalsIgnoreCase("BRL") && this.dto.getRedempCrncy().equalsIgnoreCase("USD"))));
			if ((this.dto.getCrncy().equalsIgnoreCase("ITL") && this.dto.getRedempCrncy().equalsIgnoreCase("EUR")) ||
				(this.dto.getCrncy().equalsIgnoreCase("DEM") && this.dto.getRedempCrncy().equalsIgnoreCase("EUR")) ||
				(this.dto.getCrncy().equalsIgnoreCase("BRL") && this.dto.getRedempCrncy().equalsIgnoreCase("USD"))){
				log.debug("return false");
				this.dto.setTflcurdub(false);
			}else{
				log.debug("return true");
				this.dto.setTflcurdub(true);
			}
		}
	}
	
	/**
	 * If test passed then dto variable setted to false
	 */
	public void structuredBondTestPassed(){
		log.debug("in boolean structuredBondTestPassed()");
		
		log.debug("return this.dto.getStructuredNote() result "+this.dto.getStructuredNote());
		log.debug("return "+this.dto.getStructuredNote());
		this.dto.setTflstruc(this.dto.getStructuredNote());
	}
	
	/**
	 *
	 * If test passed then dto variable setted to false
	 */
	public void amortizedBondTestPassed(){
		log.debug("in boolean amortizedBondTestPassed()");
		
		log.debug("this.dto.getMostRecentReportedFactor().compareTo(new BigDecimal(1)) result "+this.dto.getMostRecentReportedFactor().compareTo(new BigDecimal(1)));
		if(this.dto.getMostRecentReportedFactor().compareTo(new BigDecimal(1)) < 0 ){
			log.debug("return true");
			this.dto.setTflamort(true);
		}else if(this.dto.getMostRecentReportedFactor().compareTo(new BigDecimal(1)) == 0){
			log.debug("this.dto.getSinkScheduleAmtTyp().equalsIgnoreCase(\"percent\") || this.dto.getSinkScheduleAmtTyp().equalsIgnoreCase(\"cash\") result "+ (this.dto.getSinkScheduleAmtTyp().equalsIgnoreCase("percent") || this.dto.getSinkScheduleAmtTyp().equalsIgnoreCase("cash")));	
			if(this.dto.getSinkScheduleAmtTyp().equalsIgnoreCase("percent") || this.dto.getSinkScheduleAmtTyp().equalsIgnoreCase("cash")){
				log.debug("result true");
				this.dto.setTflamort(true);
			}else{
				log.debug("return false");
				this.dto.setTflamort(false);
			}
		}else{
			log.debug("return true");
			this.dto.setTflamort(true);
		}
	}
	
	/**
	 * If test passed then dto variable setted to false
	 */
	public void acceptableBond(){
		log.debug("in void acceptableBond()");
		this.perpetualTestPassed();
		this.extendibleTestPassed();
		log.debug("return "+(this.bondTitleTestPassed() && !this.dto.getTflgper() && !this.dto.getTflgest()));
		this.dto.setTflgacct(this.bondTitleTestPassed() && !this.dto.getTflgper() && !this.dto.getTflgest());
	}
	
	/**
	 * Method that do all checks on <code>IfptBndDtDTO</code> instance variable
	 * @throws SendBlockingException
	 */
	public void checkField() throws SendBlockingException{
		this.denominationValueCensusTestPassed();
		this.settlmentdenominationValueCensusTestPassed();
		this.divergenceDenominationSettlemenCurrencyTestPassed();
		this.structuredBondTestPassed();
		this.amortizedBondTestPassed();
		this.acceptableBond();
	}
}
