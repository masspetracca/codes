/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.icsd.connection;

import it.ccg.icsd.IcsdConstants;
import it.ccg.icsd.exception.SendBlockingException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class MilanoEnvConnector {
	private static final Logger log = Logger.getLogger("it.ccg.icsd.connection.Connection");
	private java.sql.Connection conn;
	
	public MilanoEnvConnector() throws SendBlockingException{
		log.debug("in default constructor");
		try {
			Class.forName("com.ibm.as400.access.AS400JDBCDriver");
		} catch (ClassNotFoundException e) {
			log.error("ClassNotFoundException "+e.getMessage());
			throw new SendBlockingException(e);
		}
	}
	
	/**
	 * 
	 * @return <code>Connection</code>
	 * @throws SendBlockingException
	 */
	public Connection getConnection() throws SendBlockingException {
		log.debug("in Connection getConnection() throws SendBlockingException");
		if (this.conn != null){
			log.debug("connection already instantiate then return conn");
			return this.conn;
		}else{
			log.debug("connection no instantiated");
			try {
				log.debug("instantiate conn variable");
				this.conn = DriverManager.getConnection(IcsdConstants.prop.getProperty("milano.DB.url"),IcsdConstants.prop.getProperty("milano.DB.user"),IcsdConstants.prop.getProperty("milano.DB.pass"));
			} catch (SQLException e) {
				log.error("SQLException "+e.getMessage());
				throw new SendBlockingException(e);
			}
			log.debug("return conn");
			return this.conn;
		}
	}
	
	/**
	 * 
	 */
	public void closeConnection(){
		log.debug("in closeConnection()");
		if (this.conn !=null){
			try {
				log.debug("closing connection");
				this.conn.close();
			} catch (SQLException e) {
				log.warn("SQLException "+e.getMessage());
			}
		}
	}
}
