/*******************************************************************************
 * Copyright (c) 2014 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package it.ccg.iscd.sender;

import it.ccg.icsd.IcsdConstants;
import it.ccg.icsd.exception.SendBlockingException;
import it.ccg.icsd.exception.SendWarningException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

public class EmailSender {

	private static final Logger log = Logger.getLogger("it.ccg.iscd.sender.EmailSender");
	private Properties mailProps;
	private Session mailSession;
	private Transport transport;
	private MimeMessage warningMessage;
	private MimeMessage errorMessage;
	
	public EmailSender() throws SendBlockingException {
		
		log.debug("in default constructor");
		try {
					
			mailProps = new Properties();
			log.debug("set transport protocol");
			mailProps.setProperty("mail.transport.protocol", "smtp");
			log.debug("set mail host");
			mailProps.setProperty("mail.host", IcsdConstants.prop.getProperty("mail.smtp.host"));
			log.debug("instantiate mailSession instance variable");
			mailSession = Session.getDefaultInstance(mailProps, null);
			log.debug("instantiate transport instance variable");
		    transport = mailSession.getTransport();
		    
		    log.debug("instantiate warning message instance variable");
		    warningMessage = new MimeMessage(mailSession);
		    String[] warningRecipientTo = IcsdConstants.prop.getProperty("mail.warning.recipient.to").split(",");
		    for (String warningTo : warningRecipientTo)
		    	warningMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(warningTo));
		    
		    String[] warningRecipientCc = IcsdConstants.prop.getProperty("mail.warning.recipient.cc").split(",");
		    for (String warningWc : warningRecipientCc)
		    	warningMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(warningWc));
		    
		    log.debug("instantiate error message instance variable");
		    errorMessage = new MimeMessage(mailSession);
		    String[] errorRecipientTo = IcsdConstants.prop.getProperty("mail.error.recipient.to").split(",");
		    for (String errorTo : errorRecipientTo)
		    	errorMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(errorTo));
		    
		    String[] errorRecipientCc = IcsdConstants.prop.getProperty("mail.error.recipient.cc").split(",");
		    for (String errorCc : errorRecipientCc)
		    	errorMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(errorCc));
	    
		} catch (AddressException e) {
			log.error("AddressException "+e.getMessage());
			throw new SendBlockingException(e);
		} catch (MessagingException e) {
			log.error("MessagingException "+e.getMessage());
			throw new SendBlockingException(e);
		}
	    log.debug("exit");
	}

	/**
	 * 
	 * @param isinCode <code>String</code>
	 * @param field <code>String</code>
	 * @throws MessagingException
	 */
	public void sendWarningMailToResponsible(SendWarningException wEX) throws MessagingException{
		log.debug("in void sendWarningMailToResponsible(SendWarningException wEX) throws MessagingException");
	    try {
	    	warningMessage.setFrom(new InternetAddress(IcsdConstants.prop.getProperty("mail.sender")));
	    	warningMessage.setSubject("WARNING! - Request failed");
	    	if ((wEX.getIsinCode()!=null && !wEX.getIsinCode().equalsIgnoreCase("")) || (wEX.getField()!=null && !wEX.getField().equalsIgnoreCase("")))
	    		warningMessage.setContent("The request that contain isin code = "+wEX.getIsinCode()+" was aborted because field "+wEX.getField()+" has a null value", "text/plain");
	    	else 
	    		warningMessage.setContent("The request was aborted. The error is: "+wEX.getMessage(), "text/plain");
	    		
			transport.connect();
		    transport.send(warningMessage);
		    transport.close();
		} catch (AddressException e) {
			log.error("AddressException "+e.getMessage());
			throw e;
		} catch (MessagingException e) {
			log.error("MessagingException "+e.getMessage());
			throw e;
		}
	}
	
	/**
	 * 
	 * @param error <code>String</code>
	 * @throws MessagingException
	 */
	public void sendErrorMail(SendBlockingException bEX) throws MessagingException{
		log.debug("in void sendErrorMail(SendBlockingException bEX) throws MessagingException");
	    try {
	    	errorMessage.setFrom(new InternetAddress(IcsdConstants.prop.getProperty("mail.sender")));
	  	    errorMessage.setSubject("InfoProvider - ERROR!");
	  	    errorMessage.setContent("Request incomplete -- error: "+bEX.getMessage(), "text/plain");
		    
			transport.connect();
		    transport.send(errorMessage);
		    transport.close();
		} catch (AddressException e) {
			log.error("AddressException "+e.getMessage());
			throw e;
		} catch (MessagingException e) {
			log.error("MessagingException "+e.getMessage());
			throw e;
		}
	}
    
    
    
}
