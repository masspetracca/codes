
TITLE: 
Single - Responsive Free HTML5 template

AUTHOR:
DESIGNED & DEVELOPED by FREEHTML5.co
http://freehtml5.co/
http://twitter.com/fh5co
http://facebook.com/fh5co


CREDITS:

Bootstrap
http://getbootstrap.com/

Unsplash for Photos
http://unsplash.com/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

Modernizr
http://modernizr.com/

Google Fonts
https://www.google.com/fonts/

Icomoon Entypo
https://icomoon.io/app/
http://www.entypo.com/

Respond JS
https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt


