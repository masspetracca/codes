package animale;

public class AnimaleIMP implements Animale {

	private String cibo_preferito, ordine, genere, specie;

	public AnimaleIMP(String o, String g, String s, String c) {
		ordine = o;
		genere = g;
		specie = s;
		cibo_preferito = c;
	}

	public String getOrdine() {
		return ordine;
	}

	public String getGenere() {
		return genere;
	}

	public String getSpecie() {
		return specie;
	}

	public String getCiboPreferito() {
		return cibo_preferito;
	}
}
