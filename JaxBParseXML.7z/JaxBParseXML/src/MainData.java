

import java.io.IOException;

public class MainData {
	/**
	 * Estrattore file .dat con esclusione delle label.
	 */
	  
	
	  public static void main(String[] args) throws Exception {
		  int returnCode = 0;
		  System.out.println("Inizio esecuzione <MAIN>");
		//Filtra e carica i files *.out
		  GetFiles();

		  if (returnCode != 0) {
			 System.out.println("Errore nella fase  <DataFile> - verificare !");	 
		  }
		  System.out.println("Fine esecuzione <MAIN>");
	  }


	private static void TestLogX2Csv() throws IOException {
		TestLogX2Csv tlog = new TestLogX2Csv();
		
	}


	private static void Errore() {
		// TODO Auto-generated method stub
		
	}


	private static void LoadReq() {
		// TODO Auto-generated method stub
		
	}


	private static void GetFiles() throws IOException {
		GetFiles gf = new GetFiles(); 		
	}


}



