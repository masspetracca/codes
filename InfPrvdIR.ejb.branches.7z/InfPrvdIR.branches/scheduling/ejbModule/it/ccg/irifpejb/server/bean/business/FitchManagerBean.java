package it.ccg.irifpejb.server.bean.business;

import it.ccg.irifpejb.server.bean.eao.BankEAOLocal;
import it.ccg.irifpejb.server.bean.entity.BankEntity;
import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.exception.FTPException;
import it.ccg.irifpejb.server.file.factory.FITCHRequestType;
import it.ccg.irifpejb.server.file.parser.FitchCSVGenerator;
import it.ccg.irifpejb.server.ftp.FTPFactory;
import it.ccg.irifpejb.server.ftp.FTPServiceInterface;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.server.providerengine.ProviderEngine;
import it.ccg.irifpejb.server.security.SecurityEjb;
import it.ccg.irifpejb.server.system.SystemProperties;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BloombergManagerBean
 */
@Stateless
@Local(FitchManagerBeanLocal.class)
public class FitchManagerBean implements FitchManagerBeanLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	private static final Logger monitorLogger = LoggerFactory.getLogger(LoggerFactory.MONITOR_LOGGER);
	
	private static String TEMP_DIR_ABSOLUTE_PATH;
	private static String PROVIDER_NAME;
	private static String FLOW_BANK_NAME;
	private static String PATH_SEPARATOR;
	private static String UPLOADING_BANK_REQUEST_FILE_NAME;
	
	private FTPServiceInterface ftpServiceInterface; 
	
	@EJB
	private BankEAOLocal bnkEAOLocal;
	
	@EJB
	private BaseBeanLocal baseBeanLocal;
	
	
	public FitchManagerBean() throws Exception {
		try {
    		
    		TEMP_DIR_ABSOLUTE_PATH = SystemProperties.getProperty("user.install.root") +
    								 SystemProperties.getProperty("temp_dir_relative_path");
    		
    		PATH_SEPARATOR = SystemProperties.getProperty("file.separator");
    		
    		// provider engine IDs from properties file
        	PROVIDER_NAME = SystemProperties.getProperty("provider.fitch.name");
        	
    	}
    	catch(Exception e) {
    		
    		logger.warn(new StandardLogMessage("Exception into bean constructor. Exception: " + e));
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
	}
	

	@Override
	public void checkReqAlign_BANK() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void alignReq_BANK() throws Exception {
		String tempFileAbsPath;
		File tempWorkingFolder=null;
		try {
			String BATCH_DESC = "Fitch BANK request Alignment";
	
			logger.info(new StandardLogMessage(BATCH_DESC + " started."));
			
			// TODO:
			FLOW_BANK_NAME = SystemProperties.getProperty("provider.fitch.flow.bank.name");
			
			UPLOADING_BANK_REQUEST_FILE_NAME = ProviderEngine.getProviderConfig().getProviderByName(PROVIDER_NAME).getFlowByName(FLOW_BANK_NAME).getRequestFileName();
			
			List<BankEntity> enabledBank = bnkEAOLocal.retrieveBankByStatus("E");
			logger.info(new StandardLogMessage("Bank list size: " + enabledBank.size()));
			logger.info(new StandardLogMessage("Bank list details: " + enabledBank));
			
			// create temporary folder and files to work
			String tempWorkingFolderName = SecurityEjb.getUniqueToken();
			tempWorkingFolder = new File(TEMP_DIR_ABSOLUTE_PATH + tempWorkingFolderName);
			if(!tempWorkingFolder.mkdir()) {
				
				throw new Exception("Unable to create temp folder \'" + tempWorkingFolder + "\'.");
			}
			
			tempFileAbsPath = tempWorkingFolder.getCanonicalPath() + PATH_SEPARATOR + UPLOADING_BANK_REQUEST_FILE_NAME;
			
			File fileToSaveInto = new File(tempFileAbsPath);
			fileToSaveInto.createNewFile();
			
			FitchCSVGenerator csvGenerator = new FitchCSVGenerator();
			csvGenerator.createRequestFile(FITCHRequestType.BANK_REQUEST,fileToSaveInto,enabledBank) ;//getFitchCsvFile(enabledBank, outputFile);
			
			this.ftpServiceInterface = FTPFactory.getFTPService(FTPFactory.FITCH_SERVICE);
			this.ftpServiceInterface.uploadRequestFile(UPLOADING_BANK_REQUEST_FILE_NAME, fileToSaveInto);
			
			monitorLogger.info(new StandardLogMessage("Fitch BANK request successfully aligned."));
			logger.info(new StandardLogMessage("Fitch BANK request successfully aligned."));
			
			
			// delete tempWorkingFolder
			//this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
		} catch (IOException e) {
			throw e;
		} catch (FTPException e) {
			throw e;
		} catch (Exception e) {
			throw e;
		}finally{
			if (tempWorkingFolder != null ){
				try {
					this.baseBeanLocal.deleteTempWorkingFolder(tempWorkingFolder);
				} catch (Exception e) {
					logger.warn(e.getMessage());
				}
			}
		}
	}
	
	

}
