package it.ccg.irifpejb.server.file.factory;

public enum BBGRequestType {
	
	BANK_REQUEST;

}
