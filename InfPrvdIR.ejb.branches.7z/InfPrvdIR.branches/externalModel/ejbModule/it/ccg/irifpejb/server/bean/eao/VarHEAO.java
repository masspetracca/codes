package it.ccg.irifpejb.server.bean.eao;

import it.ccg.irifpejb.server.bean.entity.VarHEntity;
import it.ccg.irifpejb.server.bean.entity.VarHEntityPK;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import java.util.List;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class VarHEAO
 */
@Stateless
@Local(VarHEAOLocal.class)
public class VarHEAO implements VarHEAOLocal {
	
	@PersistenceContext(unitName="IntRatIFPejb", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Resource
	private SessionContext sessionContext;
	
	
	private String tableName = ((Table)(VarHEntity.class.getAnnotation(Table.class))).name();
	

    /**
     * Default constructor. 
     */
    public VarHEAO() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public List<VarHEntity> fetch() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public VarHEntity findByPrimaryKey(VarHEntityPK pK) throws Exception {
		
		return (VarHEntity)this.em.find(VarHEntity.class, pK);
	}

	@Override
	public List<VarHEntity> fetchLastDateHisPr(List<Integer> instrIDs)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getInstrMinPriceDate(int instrId) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void add(VarHEntity entity) throws Exception {
		
		// set current user
		entity.setUpdusr(this.sessionContext.getCallerPrincipal().getName());
		// set updtype
		entity.setUpdtype("C");
		
		em.persist(entity);
		
		logger.info(new StandardLogMessage("Persisted data into \'" + this.tableName + "\'. " + entity));
		
		
		/*Query query = em.createNamedQuery("refreshVarHView");
		query.executeUpdate();
		
		logger.info(new StandardLogMessage("PAMPTEST.RCTMVARH successfully refreshed."));*/
		
	}
	
	@Override
	public void refreshVarHView() throws Exception {
		
		Query query = em.createNamedQuery("refreshVarHView");
		query.executeUpdate();
		
		logger.info(new StandardLogMessage("RCMVARH successfully refreshed."));
		
	}
	

	@Override
	public void update(VarHEntity ie) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remove(VarHEntity ie) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
