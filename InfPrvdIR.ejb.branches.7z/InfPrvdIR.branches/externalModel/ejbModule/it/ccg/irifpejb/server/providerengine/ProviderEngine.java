package it.ccg.irifpejb.server.providerengine;

import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.server.providerengine.config.FitchConfig;
import it.ccg.irifpejb.server.system.SystemProperties;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

public class ProviderEngine {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	private static final String PROPERTIES_FILE_ABS_PATH = System.getProperty("user.install.root") + 
	   																		  "/properties/IntRatIFP.provider-config.xml";
	
	private static ProviderConfig providerConfig;

	
	public static void load() throws Exception {
		 
		File file = new File(PROPERTIES_FILE_ABS_PATH);
		JAXBContext jaxbContext = JAXBContext.newInstance(ProviderConfig.class);
		
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		providerConfig = (ProviderConfig)jaxbUnmarshaller.unmarshal(file);
		
		
		logger.info(new StandardLogMessage("Loaded providers info: " + providerConfig));
		
		
		// TODO
		// validation
		/*SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		Schema schema = sf.newSchema(new File("myschema.xsd"));
		jaxbUnmarshaller.setSchema(schema);*/
		
		
		//
		// TODO
    	// controlla che i job dichiarati nel file descrittore siano
    	// implementati nell'applicazione
		
		
		// setup FitchConfig, ReutersConfig and BloombergConfig classes
		// TODO remove this code
		/*String fitchProviderName = SystemProperties.getProperty("provider.fitch.name");
		FitchConfig.name = fitchProviderName;
		FitchConfig.url = ProviderEngine.getProviderConfig().getProviderByName(fitchProviderName).getUrl();
		FitchConfig.userName = ProviderEngine.getProviderConfig().getProviderByName(fitchProviderName).getUserName();
		FitchConfig.password = ProviderEngine.getProviderConfig().getProviderByName(fitchProviderName).getPassword();
		FitchConfig.downloadDataDir = ProviderEngine.getProviderConfig().getProviderByName(fitchProviderName).getDownloadDataDir();
		FitchConfig.uploadRequestDir = ProviderEngine.getProviderConfig().getProviderByName(fitchProviderName).getUploadRequestDir();*/
		///////////////////
		
	}
	
	
	public static ProviderConfig getProviderConfig() {
		return providerConfig;
	}
	

}
