package it.ccg.irifpejb.server.file.parser;



import it.ccg.irifpejb.server.file.template.BloombergRequestTemplate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BloombergRequestParser {
	
	
	public BloombergRequestParser() throws Exception {
		
	}
	
	
	public BloombergRequestTemplate parse(File file) throws Exception {
		
		if(!file.exists()) {
			
			throw new Exception("File \'" + file.getAbsolutePath() + "\' not exists.");
		}
		
			
		// apro lo stream per leggere il file
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(file));
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		// marker at beginning of file
		try {
			br.mark((int)(file.length() / 2));  // /2 because char type is 16 bit in Java
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		Map<String, String> header = this.getHeader(br);
		List<String> fields = this.getFields(br);
		List<String> securities = this.getSecurities(br);
		
			
		/*while(!line.startsWith("END-OF-FILE")) {
			line = br.readLine();
		}*/
			
			
		try {
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		BloombergRequestTemplate bloombergRequestTemplate = new BloombergRequestTemplate(header, fields, securities);
		
		
		return bloombergRequestTemplate;
	}
	
	
	private Map<String, String> getHeader(BufferedReader br) {
		
		Map<String, String> header = new HashMap<String, String>();
		
		// leggo riga per riga
		String line = null;
		try {
			
			// pointer at beginning of file
			br.reset();
			
			line = br.readLine();
			// 
			while(!line.equalsIgnoreCase("START-OF-FILE")) {
				line = br.readLine();
			}
			
			line = br.readLine(); // prima riga dell'header section
			while(!line.equalsIgnoreCase("START-OF-FIELDS")) {
				if(!isCommentOrEmptyLine(line)) {
					
					header.put((line.split("="))[0].trim(), (line.split("="))[1].trim());
				}
				
				line = br.readLine();
			}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return header;
	}
	
	private List<String> getFields(BufferedReader br) {
		
		List<String> fields = new ArrayList<String>();
		
		// leggo riga per riga
		String line = null;
		try {
			
			// pointer at beginning of file
			br.reset();
			

			line = br.readLine();
			// 
			while(!line.equalsIgnoreCase("START-OF-FIELDS")) {
				line = br.readLine();
			}
			
			line = br.readLine(); // prima riga della fields section
			while(!line.equalsIgnoreCase("END-OF-FIELDS")) {
				if(!isCommentOrEmptyLine(line)) {
					fields.add(line.trim());
				}
				
				line = br.readLine();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return fields;
	}
	
	
	private List<String> getSecurities(BufferedReader br) {
		
		List<String> securitiesList = new ArrayList<String>();
		
		// leggo riga per riga
		String line = null;
		try {
			
			// pointer at beginning of file
			br.reset();
			
			line = br.readLine();
			while(!line.startsWith("START-OF-DATA")) {
				line = br.readLine();
			}
			
			line = br.readLine(); // prima riga della data section
			while(!line.startsWith("END-OF-DATA")) {
				if(!isCommentOrEmptyLine(line)) {
					
					securitiesList.add(line.trim().substring(0, ((String)line).trim().indexOf(" Equity")));
				}
				
				line = br.readLine();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return securitiesList;
	}
	
	
	
	private boolean isCommentOrEmptyLine(String line) {
		
		return (line.startsWith("#")) || (line.trim().length() == 0);
	}
	
	
	
}
