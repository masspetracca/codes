package it.ccg.irifpejb.server.bean.eao;

import it.ccg.irifpejb.server.bean.entity.VarHEntity;
import it.ccg.irifpejb.server.bean.entity.VarHEntityPK;

import java.util.List;

public interface VarHEAOLocal {
	
	public List<VarHEntity> fetch() throws Exception;
	public VarHEntity findByPrimaryKey(VarHEntityPK pK) throws Exception;
	
	public List<VarHEntity> fetchLastDateHisPr(List<Integer> instrIDs) throws Exception;
	
	public int getInstrMinPriceDate(int instrId) throws Exception;
	
	public void add(VarHEntity ie) throws Exception;
	public void refreshVarHView() throws Exception;
	
	public void update(VarHEntity ie) throws Exception;
	public void remove(VarHEntity ie) throws Exception;

}
