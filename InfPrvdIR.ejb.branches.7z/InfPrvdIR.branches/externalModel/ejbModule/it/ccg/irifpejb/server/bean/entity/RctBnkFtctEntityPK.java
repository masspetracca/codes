package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RCTBNKFTCT database table.
 * 
 */
@Embeddable
public class RctBnkFtctEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private int fitchCode;

	@Column(unique=true, nullable=false, length=50)
	private String fitchNName;

    public RctBnkFtctEntityPK() {
    }
	public int getFitchCode() {
		return this.fitchCode;
	}
	public void setFitchCode(int fitchCode) {
		this.fitchCode = fitchCode;
	}
	public String getFitchNName() {
		return this.fitchNName;
	}
	public void setFitchNName(String fitchNName) {
		this.fitchNName = fitchNName;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RctBnkFtctEntityPK)) {
			return false;
		}
		RctBnkFtctEntityPK castOther = (RctBnkFtctEntityPK)other;
		return 
			(this.fitchCode == castOther.fitchCode)
			&& this.fitchNName.equals(castOther.fitchNName);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.fitchCode;
		hash = hash * prime + this.fitchNName.hashCode();
		
		return hash;
    }
}