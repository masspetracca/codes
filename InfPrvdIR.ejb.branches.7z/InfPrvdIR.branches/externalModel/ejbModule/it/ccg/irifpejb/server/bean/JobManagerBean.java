package it.ccg.irifpejb.server.bean;


import it.ccg.irifpejb.server.exception.ExceptionUtil;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.providerengine.Flow;
import it.ccg.irifpejb.server.providerengine.Job;
import it.ccg.irifpejb.server.providerengine.Provider;
import it.ccg.irifpejb.server.providerengine.ProviderEngine;
import it.ccg.irifpejb.server.system.LocalBeanLookup;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;

import org.apache.log4j.Logger;


/**
 * Session Bean implementation class JobManagerBean
 */
@Stateless
public class JobManagerBean implements JobManagerBeanLocal {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
    /**
     * Default constructor. 
     */
    public JobManagerBean() {
    	
    }
    
    
	@Override
	public List<ProviderDTO> getProviderList() throws Exception {
		
		List<ProviderDTO> providerList = new ArrayList<ProviderDTO>();
		
		
		List<Provider> pList = ProviderEngine.getProviderConfig().getProviderList();
		
		for(Provider p : pList) {
			
			providerList.add(new ProviderDTO(p.getName(), null, p.getName()));
		}
		
		// TODO
		// Deve essere gestita in qualche modo la presenza di batch non strettamente 
		// legati ai provider, come ad esempio in questo caso la copia di dati dal 
		// datasource INFOP a datasource esterni.
		providerList.add(new ProviderDTO("RM", null, "RM"));
		
		
		return providerList;
	}
	
    

	@Override
	public List<JobDTO> getJobListByProviderName(String providerName) throws Exception {
		
		List<JobDTO> jobList = new ArrayList<JobDTO>();
		
		List<Provider> providerList = ProviderEngine.getProviderConfig().getProviderList();
		
		for(Provider p : providerList) {
			
			// prendo tutti i job di un dato provider
			if(p.getName().equalsIgnoreCase(providerName)) {
				
				List<Flow> flowList = p.getFlowList();
				
				// per ogni flusso
				for(Flow flow : flowList) {
					
					List<Job> jList = flow.getJobList();
					
					for(Job j : jList) {
						
						jobList.add(new JobDTO(j.getName(), j.getMethodName(), Class.forName(j.getMethodClass()), j.getDescription()));
					}
				}
				
			}
			
		}
		
		
		return jobList;
	}
	
	
	@Override
	public JobDTO getJobByName(String jobName) throws Exception {
		
		JobDTO jobDTO = null;
		
		List<Provider> tempList = ProviderEngine.getProviderConfig().getProviderList();
		
		_1: for(Provider p : tempList) {
			
			List<Flow> flowList = p.getFlowList();
			
			// per ogni flusso
			for(Flow flow : flowList) {
				
				List<Job> jList = flow.getJobList();
				
				for(Job j : jList) {
					
					if(j.getName().equalsIgnoreCase(jobName)) {
						
						jobDTO = new JobDTO(j.getName(), j.getMethodName(), Class.forName(j.getMethodClass()), j.getDescription());
					
						break _1;
					}
					
				}
				
			}
			
		}
		
		
		return jobDTO;
	}
	
	
	@Override
	public JobDTO getJobByJobMethodNClass(String method, Class<?> _class) throws Exception {
		
		JobDTO jobDTO = null;
		
		List<Provider> tempList = ProviderEngine.getProviderConfig().getProviderList();
		
		_1: for(Provider p : tempList) {
			
			List<Flow> flowList = p.getFlowList();
			
			// per ogni flusso
			for(Flow flow : flowList) {
				
				List<Job> jList = flow.getJobList();
				
				for(Job j : jList) {
					
					if(j.getMethodName().equalsIgnoreCase(method) && j.getMethodClass().equalsIgnoreCase(_class.getCanonicalName())) {
						
						jobDTO = new JobDTO(j.getName(), j.getMethodName(), Class.forName(j.getMethodClass()), j.getDescription());
					
						break _1;
					}
					
				}
				
			}
			
		}
		
		
		return jobDTO;
	}
	
	
	@Override
	public void executeJob(JobDTO jobDTO) throws Exception {
		
		try {
			String methodName = jobDTO.getMethodName();
			Class<?> methodClass = jobDTO.getMethodClass();
			
			Method method = methodClass.getMethod(methodName, (Class<?>[])null);
			
			// class is an EJB interface
			Object classInstance = LocalBeanLookup.lookup(methodClass.getCanonicalName());
			
			method.invoke(classInstance, (Object[])null);
		}
		catch(Exception e) {
			// *** IMPORTANT ***
			// At this point, whatever exception type results as InvocationTargetException with no message.
			// For error details, it is necessary to log at job method level.
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			// I directly started the batch, i throw the exception to JobExecute servlet.
			throw e;
		}
		
	}
	

}
