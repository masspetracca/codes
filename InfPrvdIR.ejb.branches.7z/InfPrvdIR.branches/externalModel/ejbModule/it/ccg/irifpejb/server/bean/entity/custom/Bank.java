package it.ccg.irifpejb.server.bean.entity.custom;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Transient;

/**
 * Entity implementation class for Entity: Bank
 *
 */
@Entity

public class Bank implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Transient
	private int bankId;

	@Transient
	private String abiCode;

	@Transient
	private String bankName;

	@Transient
	private String bloombCode;

	@Transient
	private String country;

	@Transient
	private String ctp;

	@Transient
	private String fitchCode;

	@Transient
	private String parBnkBlCd;

	@Transient
	private String parBnkName;

	@Transient
	private String parBnkTick;

	@Transient
	private String participnt;

	@Transient
	private String rTicker;

	@Transient
	private String status;
	
	public Bank() {
		super();
	}
	
	public Bank(int bankId,String abiCode,String bankName,String bloombCode,String country,String ctp,String fitchCode,String parBnkBlCd,String parBnkName,String parBnkTick,String participnt,String rTicker,String status) {
		this.bankId=bankId;
		this.abiCode=abiCode;
		this.bankName=bankName;
		this.bloombCode=bloombCode;
		this.country=country;
		this.ctp=ctp;
		this.fitchCode=fitchCode;
		this.parBnkBlCd=parBnkBlCd;
		this.parBnkName=parBnkName;
		this.parBnkTick=parBnkTick;
		this.participnt=participnt;
		this.rTicker=rTicker;
		this.status=status;
	}

	/**
	 * @return the bankId
	 */
	public int getBankId() {
		return bankId;
	}

	/**
	 * @param bankId the bankId to set
	 */
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}

	/**
	 * @return the abiCode
	 */
	public String getAbiCode() {
		return abiCode;
	}

	/**
	 * @param abiCode the abiCode to set
	 */
	public void setAbiCode(String abiCode) {
		this.abiCode = abiCode;
	}

	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * @return the bloombCode
	 */
	public String getBloombCode() {
		return bloombCode;
	}

	/**
	 * @param bloombCode the bloombCode to set
	 */
	public void setBloombCode(String bloombCode) {
		this.bloombCode = bloombCode;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the ctp
	 */
	public String getCtp() {
		return ctp;
	}

	/**
	 * @param ctp the ctp to set
	 */
	public void setCtp(String ctp) {
		this.ctp = ctp;
	}

	/**
	 * @return the fitchCode
	 */
	public String getFitchCode() {
		return fitchCode;
	}

	/**
	 * @param fitchCode the fitchCode to set
	 */
	public void setFitchCode(String fitchCode) {
		this.fitchCode = fitchCode;
	}

	/**
	 * @return the parBnkBlCd
	 */
	public String getParBnkBlCd() {
		return parBnkBlCd;
	}

	/**
	 * @param parBnkBlCd the parBnkBlCd to set
	 */
	public void setParBnkBlCd(String parBnkBlCd) {
		this.parBnkBlCd = parBnkBlCd;
	}

	/**
	 * @return the parBnkName
	 */
	public String getParBnkName() {
		return parBnkName;
	}

	/**
	 * @param parBnkName the parBnkName to set
	 */
	public void setParBnkName(String parBnkName) {
		this.parBnkName = parBnkName;
	}

	/**
	 * @return the parBnkTick
	 */
	public String getParBnkTick() {
		return parBnkTick;
	}

	/**
	 * @param parBnkTick the parBnkTick to set
	 */
	public void setParBnkTick(String parBnkTick) {
		this.parBnkTick = parBnkTick;
	}

	/**
	 * @return the participnt
	 */
	public String getParticipnt() {
		return participnt;
	}

	/**
	 * @param participnt the participnt to set
	 */
	public void setParticipnt(String participnt) {
		this.participnt = participnt;
	}

	/**
	 * @return the rTicker
	 */
	public String getrTicker() {
		return rTicker;
	}

	/**
	 * @param rTicker the rTicker to set
	 */
	public void setrTicker(String rTicker) {
		this.rTicker = rTicker;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
   
}
