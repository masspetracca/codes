package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the RCITHISRTG database table.
 * 
 */
@Entity
@Table(name="RCTHISRTG")
@NamedQueries({
@NamedQuery(name="fetchLastDateHisRtg", query="SELECT hisRtg " +
		   "FROM RctHisRtgEntity hisRtg " +
		   "WHERE hisPr.bankId IN (:bankIDsList) AND " + 
	   										"hisRtg.id.rtgDate = (" + 
					   										"SELECT MAX(hisPrTemp.id.rtgDate) " + 
					   										"FROM RctHisRtgEntity hisRtg2 " + 
					   										"WHERE hisRtg2.id.bloombCode = hisRtg.id.bloombCode" + 
	   													")")
})
public class RctHisRtgEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RctHisRtgEntityPK id;

	@Column(nullable=false)
	private int bankId;

	@Column(length=10)
	private String fitchRtg;

	private int ftcTrscRtg;

	private int mdsTrscRtg;

	@Column(length=10)
	private String moodRtg;

	@Column(length=10)
	private String spRtg;

	private int spTrscRtg;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=30)
	private String updUsr;

    public RctHisRtgEntity() {
    }

	public RctHisRtgEntityPK getId() {
		return this.id;
	}

	public void setId(RctHisRtgEntityPK id) {
		this.id = id;
	}
	
	public int getBankId() {
		return this.bankId;
	}

	public void setBankId(int bankId) {
		this.bankId = bankId;
	}

	public String getFitchRtg() {
		return this.fitchRtg;
	}

	public void setFitchRtg(String fitchRtg) {
		this.fitchRtg = fitchRtg;
	}

	public int getFtcTrscRtg() {
		return this.ftcTrscRtg;
	}

	public void setFtcTrscRtg(int ftcTrscRtg) {
		this.ftcTrscRtg = ftcTrscRtg;
	}

	public int getMdsTrscRtg() {
		return this.mdsTrscRtg;
	}

	public void setMdsTrscRtg(int mdsTrscRtg) {
		this.mdsTrscRtg = mdsTrscRtg;
	}

	public String getMoodRtg() {
		return this.moodRtg;
	}

	public void setMoodRtg(String moodRtg) {
		this.moodRtg = moodRtg;
	}

	public String getSpRtg() {
		return this.spRtg;
	}

	public void setSpRtg(String spRtg) {
		this.spRtg = spRtg;
	}

	public int getSpTrscRtg() {
		return this.spTrscRtg;
	}

	public void setSpTrscRtg(int spTrscRtg) {
		this.spTrscRtg = spTrscRtg;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUsr() {
		return this.updUsr;
	}

	public void setUpdUsr(String updUsr) {
		this.updUsr = updUsr;
	}

}