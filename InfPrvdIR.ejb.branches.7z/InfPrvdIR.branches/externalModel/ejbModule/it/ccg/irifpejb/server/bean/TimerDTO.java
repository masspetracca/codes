package it.ccg.irifpejb.server.bean;


import java.io.Serializable;
import java.util.Date;


public class TimerDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4532042410246488052L;
	
	
	private String name;
	private boolean isSingle;
	private Date startDateTime;
	private long interval;
	private String provider;
	private JobDTO jobDTO;
	
	
	public TimerDTO() {
		
	}
	
	public TimerDTO(String name, boolean isSingle, Date startDateTime, long interval, String provider, JobDTO jobDTO) {
		this.name = name;
		this.isSingle = isSingle;
		this.startDateTime = startDateTime;
		this.interval = interval;
		this.provider = provider;
		this.jobDTO = jobDTO;
	}
	
	public TimerDTO(String name, boolean isSingle, Date startDateTime, String provider, JobDTO jobDTO) {
		this.name = name;
		this.isSingle = isSingle;
		this.startDateTime = startDateTime;
		this.provider = provider;
		this.jobDTO = jobDTO;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isSingle() {
		return isSingle;
	}

	public void setSingle(boolean isSingle) {
		this.isSingle = isSingle;
	}

	public Date getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(Date startDateTime) {
		this.startDateTime = startDateTime;
	}

	public long getInterval() {
		return interval;
	}

	public void setInterval(long interval) {
		this.interval = interval;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public JobDTO getJobDTO() {
		return jobDTO;
	}

	public void setJobDTO(JobDTO jobDTO) {
		this.jobDTO = jobDTO;
	}

	
	

}
