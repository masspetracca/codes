package it.ccg.irifpejb.smartgwt.server.dmi;

import it.ccg.irifpejb.server.system.LocalBeanLookup;

public class HistoricalRatingDmiEAOFactory {

	public HistoricalRatingDmiEAOFactory() {
		
	}
	
	public HistoricalRatingDmiEAOLocal create() throws Exception {

		HistoricalRatingDmiEAOLocal hitsRtgDmiEAOLocal = (HistoricalRatingDmiEAOLocal)LocalBeanLookup.lookup(HistoricalRatingDmiEAOLocal.class.getName());
		
		return hitsRtgDmiEAOLocal;
	}
}
