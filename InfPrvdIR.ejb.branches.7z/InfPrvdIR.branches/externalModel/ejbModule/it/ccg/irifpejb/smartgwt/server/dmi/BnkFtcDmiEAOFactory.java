package it.ccg.irifpejb.smartgwt.server.dmi;

import it.ccg.irifpejb.server.system.LocalBeanLookup;

public class BnkFtcDmiEAOFactory {
	
	
	public BnkFtcDmiEAOFactory() {
		
	}
	
	public BnkFtcDmiEAOLocal create() throws Exception {

		BnkFtcDmiEAOLocal bnkFtcDmiEAOLocal = (BnkFtcDmiEAOLocal)LocalBeanLookup.lookup(BnkFtcDmiEAOLocal.class.getName());
		
		return bnkFtcDmiEAOLocal;
	}

}
