package it.ccg.irifpejb.smartgwt.server.dmi;



import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.smartgwt.server.util.DmiEAOUtil;
import it.ccg.irifpejb.smartgwt.server.util.JpaQuery;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;



/**
 * Session Bean implementation class HisPrDmiCmtEAO
 */
@Stateless
public class VarHDmiEAO implements VarHDmiEAOLocal {
	
	@PersistenceContext(unitName="IntRatIFPejb", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	
    /**
     * Default constructor. 
     */
    public VarHDmiEAO() {
    	
    }
    
    
    /*@Override
	public DSResponse fetchInfo(DSRequest dsRequest) throws Exception {
		
    	JpaQuery jpaQuery = new JpaQuery("SELECT new VarHInfo(v.id.bankid, v.id.varid)", "FROM it.ccg.irifpejb.server.bean.entity.VarHEntity v", "", "", "", "");
		
		
		JpaQuery filteredJpaQuery = DmiEAOUtil.getFilteredQuery(jpaQuery, dsRequest);
		
    	logger.info(new StandardLogMessage("query: " + filteredJpaQuery.toString()));
    	
    	
		return DmiEAOUtil.executeQuery(filteredJpaQuery, dsRequest, this.em);
	}*/
	
	
	@Override
	public DSResponse fetchHis(DSRequest dsRequest) throws Exception {
		
		// This query is always executed with condition "WHERE varh.id.varid = bankid".
		// The instrId value is from client criteria.
		//SELECT new VarHHis(varh.id.valuedate, varh.varvalue)", "FROM it.ccg.irifpejb.server.bean.entity.VarHEntity varh", "", "", "", "ORDER BY varh.id.valuedate DESC
		JpaQuery jpaQuery = new JpaQuery("SELECT new VarHHis(varh.id.valuedate, varh.varvalue)", "FROM it.ccg.irifpejb.server.bean.entity.VarHEntity varh", "", "", "", "ORDER BY varh.id.valuedate DESC");
		
		JpaQuery filteredJpaQuery = DmiEAOUtil.getFilteredQuery(jpaQuery, dsRequest);
		
    	logger.info(new StandardLogMessage("query: " + filteredJpaQuery.toString()));
    	
		return DmiEAOUtil.executeQuery(filteredJpaQuery, dsRequest, this.em);
	}
	
	
}
