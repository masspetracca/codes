package it.ccg.irifpejb.smartgwt.server.dmi;



import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;
import it.ccg.irifpejb.smartgwt.server.util.DmiEAOUtil;
import it.ccg.irifpejb.smartgwt.server.util.JpaQuery;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.apache.log4j.Logger;

import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;



/**
 * Session Bean implementation class HisPrDmiCmtEAO
 */
@Stateless
public class BnkFtcDmiEAO implements BnkFtcDmiEAOLocal {
	
	@PersistenceContext(unitName="IntRatIFPejb", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	
	
    /**
     * Default constructor. 
     */
    public BnkFtcDmiEAO() {
    	
    }
    
    
    @Override
	public DSResponse fetch(DSRequest dsRequest) throws Exception {
		
    	JpaQuery jpaQuery = new JpaQuery("SELECT new BnkFitch(f.id.fitchcode, f.id.fitchnname, f.isconsolid, f.accountsys, f.latestper)", "FROM it.ccg.irifpejb.server.bean.entity.BnkFtcTEntity f", "", "", "", "ORDER BY f.latestper DESC");
    	
		JpaQuery filteredJpaQuery = DmiEAOUtil.getFilteredQuery(jpaQuery, dsRequest);
		
    	logger.info(new StandardLogMessage("query: " + filteredJpaQuery.toString()));
    	
		return DmiEAOUtil.executeQuery(filteredJpaQuery, dsRequest, this.em);
	}
	
	
}
