package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;


/**
 * The primary key class for the RCTBNKFTCT database table.
 * 
 */
@Embeddable
public class BnkFtcTEntityPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private int fitchcode;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=50)
	private String fitchnname;

    public BnkFtcTEntityPK() {
    }
	public int getFitchcode() {
		return this.fitchcode;
	}
	public void setFitchcode(int fitchcode) {
		this.fitchcode = fitchcode;
	}
	public String getFitchnname() {
		return this.fitchnname;
	}
	public void setFitchnname(String fitchnname) {
		this.fitchnname = fitchnname;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof BnkFtcTEntityPK)) {
			return false;
		}
		BnkFtcTEntityPK castOther = (BnkFtcTEntityPK)other;
		return 
			(this.fitchcode == castOther.fitchcode)
			&& this.fitchnname.equals(castOther.fitchnname);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.fitchcode;
		hash = hash * prime + this.fitchnname.hashCode();
		
		return hash;
    }
}