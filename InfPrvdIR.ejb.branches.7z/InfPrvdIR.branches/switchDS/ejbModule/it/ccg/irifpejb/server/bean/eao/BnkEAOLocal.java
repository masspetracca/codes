package it.ccg.irifpejb.server.bean.eao;

import it.ccg.irifpejb.server.bean.entity.BnkFtcTEntity;

public interface BnkEAOLocal {
	
	public BnkFtcTEntity findByPrimaryKey(String fitchnickname,int fitchcode) throws Exception;
	
	public void add(BnkFtcTEntity e) throws Exception;

}
