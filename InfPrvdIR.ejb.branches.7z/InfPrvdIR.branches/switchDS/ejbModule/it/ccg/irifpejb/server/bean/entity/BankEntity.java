package it.ccg.irifpejb.server.bean.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the RCTBANK database table.
 * 
 */
@Entity
@Table(name="RCTBANK")
@NamedQueries({
	@NamedQuery(name="getBankByAbicode", query="SELECT bank FROM RctBankEntity bank WHERE bank.abiCode= :abicode ORDER BY bank.bankName ASC"),
	@NamedQuery(name="getBankByFitchCode", query="SELECT bank FROM RctBankEntity bank WHERE bank.fitchCode= :fitchcode ORDER BY bank.bankName ASC"),
	@NamedQuery(name="getBankByBloombCode", query="SELECT bank FROM RctBankEntity bank WHERE bank.bloombCode= :bloombcode ORDER BY bank.bankName ASC"),
	@NamedQuery(name="getBankByName", query="SELECT bank FROM RctBankEntity bank WHERE bank.bankName like :bankname ORDER BY bank.bankName ASC"),
	@NamedQuery(name="getBankByStatus", query="SELECT bank FROM RctBankEntity bank WHERE bank.status = :status ORDER BY bank.bankName ASC")
})
public class BankEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false)
	private int bankId;

	@Column(length=20)
	private String abiCode;

	@Column(nullable=false, length=255)
	private String bankName;

	@Column(unique=true, length=20)
	private String bloombCode;

	@Column(length=30)
	private String country;

	@Column(nullable=false, length=1)
	private String ctp;

	@Column(unique=true, length=20)
	private String fitchCode;

	@Column(length=10)
	private String parBnkBlCd;

	@Column(length=10)
	private String parBnkName;

	@Column(length=10)
	private String parBnkTick;

	@Column(nullable=false, length=1)
	private String participnt;

	@Column(name="RTICKER", length=20)
	private String rTicker;

	@Column(nullable=false, length=1)
	private String status;

	@Column(nullable=false)
	private Timestamp updDate;

	@Column(nullable=false, length=1)
	private String updType;

	@Column(nullable=false, length=30)
	private String updUsr;

    public BankEntity() {
    }

	public int getBankId() {
		return this.bankId;
	}

	public void setBankId(int bankId) {
		this.bankId = bankId;
	}

	public String getAbiCode() {
		return this.abiCode;
	}

	public void setAbiCode(String abiCode) {
		this.abiCode = abiCode;
	}

	public String getBankName() {
		return this.bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBloombCode() {
		return this.bloombCode;
	}

	public void setBloombCode(String bloombCode) {
		this.bloombCode = bloombCode;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCtp() {
		return this.ctp;
	}

	public void setCtp(String ctp) {
		this.ctp = ctp;
	}

	public String getFitchCode() {
		return this.fitchCode;
	}

	public void setFitchCode(String fitchCode) {
		this.fitchCode = fitchCode;
	}

	public String getParBnkBlCd() {
		return this.parBnkBlCd;
	}

	public void setParBnkBlCd(String parBnkBlCd) {
		this.parBnkBlCd = parBnkBlCd;
	}

	public String getParBnkName() {
		return this.parBnkName;
	}

	public void setParBnkName(String parBnkName) {
		this.parBnkName = parBnkName;
	}

	public String getParBnkTick() {
		return this.parBnkTick;
	}

	public void setParBnkTick(String parBnkTick) {
		this.parBnkTick = parBnkTick;
	}

	public String getParticipnt() {
		return this.participnt;
	}

	public void setParticipnt(String participnt) {
		this.participnt = participnt;
	}

	public String getRTicker() {
		return this.rTicker;
	}

	public void setRTicker(String rTicker) {
		this.rTicker = rTicker;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdType() {
		return this.updType;
	}

	public void setUpdType(String updType) {
		this.updType = updType;
	}

	public String getUpdUsr() {
		return this.updUsr;
	}

	public void setUpdUsr(String updUsr) {
		this.updUsr = updUsr;
	}
}