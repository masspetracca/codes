package it.ccg.irifpejb.server.bean.eao;

import it.ccg.irifpejb.server.bean.entity.BnkFtcTEntity;
import it.ccg.irifpejb.server.bean.entity.BnkFtcTEntityPK;
import it.ccg.irifpejb.server.logengine.LoggerFactory;
import it.ccg.irifpejb.server.logengine.StandardLogMessage;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Table;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class BnkEAO
 */
@Stateless
@Local(BnkEAOLocal.class)
public class BnkEAO implements BnkEAOLocal {
	
	
	@PersistenceContext(unitName="IntRatIFPejb", type=PersistenceContextType.TRANSACTION)
    private EntityManager em;
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerFactory.EJB_LOGGER);
	
	@Resource
	private SessionContext sessionContext;
	
	
	private String tableName = ((Table)(BnkFtcTEntity.class.getAnnotation(Table.class))).name();
	
    /**
     * Default constructor. 
     */
    public BnkEAO() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public BnkFtcTEntity findByPrimaryKey(String fitchnickname,int fitchcode) throws Exception {
		
		BnkFtcTEntityPK pk = new BnkFtcTEntityPK();
		pk.setFitchcode(fitchcode);
		pk.setFitchnname(fitchnickname);
		
		return (BnkFtcTEntity)this.em.find(BnkFtcTEntity.class, pk);
	}

	@Override
	public void add(BnkFtcTEntity e) throws Exception {
		
		// set current user
		e.setUpdusr(this.sessionContext.getCallerPrincipal().getName());
		// set updtype
		e.setUpdtype("C");
		
		em.persist(e);
		
		logger.info(new StandardLogMessage("Persisted data into \'" + this.tableName + "\'. " + e));
		
	}

}
