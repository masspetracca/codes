package it.ccg.irifpejb.server.bean.entity;

import it.ccg.irifpejb.server.bean.entity.BnkFtcTEntityPK;
import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * The persistent class for the RCTBNKFTCT database table.
 * 
 */
@Entity
@Table(name="RCTBNKFTCT")
public class BnkFtcTEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private BnkFtcTEntityPK id;

	@Column(nullable=false, length=200)
	private String accountsys;

	@Column(nullable=false, length=1)
	private String isconsolid;

	@Column(nullable=false)
	private Timestamp latestper;

	@Column(nullable=false)
	private Timestamp upddate = new Timestamp(System.currentTimeMillis());

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

    public BnkFtcTEntity() {
    }

	public BnkFtcTEntityPK getId() {
		return this.id;
	}

	public void setId(BnkFtcTEntityPK id) {
		this.id = id;
	}
	
	public String getAccountsys() {
		return this.accountsys;
	}

	public void setAccountsys(String accountsys) {
		this.accountsys = accountsys;
	}

	public String getIsconsolid() {
		return this.isconsolid;
	}

	public void setIsconsolid(String isconsolid) {
		this.isconsolid = isconsolid;
	}

	public Timestamp getLatestper() {
		return this.latestper;
	}

	public void setLatestper(Timestamp latestper) {
		this.latestper = latestper;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}
}