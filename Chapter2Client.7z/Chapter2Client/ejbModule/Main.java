
import java.rmi.RemoteException;

import by.iba.rad257.ejb.SayHello;
import by.iba.rad257.ejb.SayHelloHome;

import com.ibm.etools.service.locator.ServiceLocatorManager;

public class Main {
    private final static String STATIC_SayHelloHome_REF_NAME = "ejb/SayHello";

    private final static Class STATIC_SayHelloHome_CLASS = SayHelloHome.class;

    public static void main(String[] args) {
        Main main = new Main();
        System.out.println(main.getGreeting("Massimo"));
    }

    public String getGreeting(String name) {
        String aString = "";
        SayHello aSayHello = createSayHello();
        try {
            aString = aSayHello.greet(name);
        } catch (RemoteException ex) {
            ex.printStackTrace();
        }
        return aString;
    }

    protected SayHello createSayHello() {
        SayHelloHome aSayHelloHome = (SayHelloHome) ServiceLocatorManager.getRemoteHome(STATIC_SayHelloHome_REF_NAME, STATIC_SayHelloHome_CLASS);
        try {
            if (aSayHelloHome != null)
                return aSayHelloHome.create();
        } catch (javax.ejb.CreateException ce) {
            ce.printStackTrace();
        } catch (RemoteException re) {
            re.printStackTrace();
        }
        return null;
    }
}