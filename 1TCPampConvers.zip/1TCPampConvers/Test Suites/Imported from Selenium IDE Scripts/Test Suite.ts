<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>0</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>f23e36d0-89f1-452e-bc28-0c3840b5255f</testSuiteGuid>
   <testCaseLink>
      <guid>3e23cf40-8a98-489b-8f98-c4701ec4a5e6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/Test Suite/RU12-NUC01-T01</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
