
public class MethodCalling {
	public static void main (String[] args) {
		MethodCalling m = new MethodCalling();
		m.go();
//		m.go1();
//		m.go2();
//		
	}

	private void go2() {
		System.out.println("Inside Go2 Method");
		
	}

	private void go1() {
		System.out.println("Inside Go1 Method");
		go2();
	}

	private void go() {
		System.out.println("Inside Go Method");
		go1();
	}
}
