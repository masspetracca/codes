
public class Calculator {
	private static int result;
	private static int num2 ;
	private static int num1;

	public static int getSum(int num1, int num2) {
		result = num1 + num2;
		System.out.println("Result g.s.-->"+result);
		return result; 
	}
	
	public static int getMult(int num1, int num2) {
		result = num1 * num2;
		System.out.println("Result g.m.-->"+result);
		return result; 
	}

	public static void main(String args[]) {
		getSum(result);
		System.out.println("getSum-->"+result);
		getMult(result);
		System.out.println("getMult-->"+result);
	}

	private static void getSum(int result) {
		getSum(num1, num2);
	}

	private static void getMult(int result) {
		getMult(num1, num2);
	}
}
