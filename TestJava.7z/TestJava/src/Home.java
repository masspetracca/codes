
public class Home {
	
	int i = 123;
	
	public void go() {
		i  = 356;
		int j = 456;
	}
	public void show() {
		i = 7438;
	}

}
