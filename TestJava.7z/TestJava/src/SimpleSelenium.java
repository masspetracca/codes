import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SimpleSelenium {
    private static int rowsmax = 4;
	WebDriver driver = null;
    static String url = "http://www.google.com";

	public static void main(String args[]){
		System.out.println("---------------------------------");

		SimpleSelenium driver = new SimpleSelenium();
	    driver.openBrowser();
	    driver.getPage();
	    driver.quitPage();
		String xp_part = "xpath=//html/body/div[1]/div[3]/table/tbody/tr[";
	    driver.getText(xp_part);
		String xp_mid = "]/td[";
	    driver.getText(xp_mid);
		String xp_end = "]";
	    driver.getText(xp_end);

		
		for(int rows=2;rows<=rowsmax ;rows++) {
			System.out.println(driver.getText(xp_part+xp_mid+xp_end));			
		}

	}
	
	private char[] getText(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	private void openBrowser() {
	    driver = new FirefoxDriver();
	
	}
	
	private void quitPage() {
	    driver.quit();
	
	}
	
	private void getPage() {
	    driver.get(url);
	
	
	}
}