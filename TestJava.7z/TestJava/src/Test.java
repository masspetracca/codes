
public class Test {
	
	public static void main (String[] args) {
		Test t = new Test();
		System.out.println("Test-prima: "+t);
		System.out.println(34<=78);
		System.out.println(34==34);
		
		t=null;
		System.out.println("Test-dopo: "+t);
		System.out.println(34>78);
		System.out.println(34==78);
	}

}
