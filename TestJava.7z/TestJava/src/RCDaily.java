import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.thoughtworks.selenium.DefaultSelenium;
import com.thoughtworks.selenium.Selenium;

public class RCDaily {

	
//	private static char[] text;

	private static String text = "prova Selenium";

	public static void main(String[] args) throws InterruptedException {
		Selenium sel = new DefaultSelenium("localhost", 4444, "*firefox", "https://10.0.10.230:10044/PampWeb/index.html");
		sel.start();
		sel.open("/");
		sel.windowMaximize();
		sel.windowFocus();
		System.out.println(sel.getTitle());
		sel.type("", "raman@wayautomation.com");
		sel.type("//*[@id='Passwd']","selenium");
		Thread.sleep(1000);
		System.out.println(text );
//		
//		System.setProperty("webdriver.Firefox.driver", "*.firefox");
//		FirefoxDriver driver = new FirefoxDriver();
//		driver.get("https://google.com");
//		System.out.println(driver.getTitle());
//		driver.close();
		
	}
}
