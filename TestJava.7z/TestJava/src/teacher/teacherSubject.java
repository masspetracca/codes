package teacher;

public class teacherSubject {
	public String subject;
	
	public static void main(String args[]) {
		teacherLogin teacher = new teacherLogin();
		teacher.testTeacherLogin();
		teacher.name = "Raman";
		
	}
	
}
