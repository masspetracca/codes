package teacher;

public class teacherLogin {
	String name;
	
	public void testTeacherLogin() {
		
	}
}
