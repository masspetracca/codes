
public class LearnMethods {
	static int i;
	static String s;
	static String si;
	static String ss;
	private static String a;
	private static float f;
	private static boolean b;
	private static char c;
	private static int k;	
	
	public static String display() {
		si=">>inside display method, #";
		i=9999;
		ss=i+si;
		return (si+i);
		
	}
	
	public static String displays() {
		s=">>inside displays method";
		return s;
	}

	public static int displayi(int k, String a, char c, float f, boolean b) {
		k= 10;
		int j=100;
		s=">>inside displayi method";
		return j+k;
		
		
	}
	public static void main(String args[]) {
		displayi(k,a,c,f,b);
		System.out.println(si+i);
		display();
		System.out.println(si+i);
		displays();
		System.out.println(s);
		LearnMethods learn1 = new LearnMethods();
		learn1.display();
		
		LearnMethods learn2 = new LearnMethods();
		learn2.display();
		
		Home h = new Home();
		h.i++;
		System.out.println(h.i);	

		Calculator calcs = new Calculator();
		calcs.getSum(10,4);

		Calculator calcm = new Calculator();
		calcm.getMult(2,4);
	}
}
