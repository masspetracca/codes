
public class LearningArrays {
	private static int i;

	public static void main(String[] args) {
		int emp1 = 5000;
		int emp2 = 5000;
		
		int emp10 = 1000;
		int imax =2;
		
		int[] salary;
		salary = new int[10];
		
		String month[] = {
				"Jan", "Feb", "Mar"};
		while (i<=imax) {
			System.out.println(month[i]);
			i++;
		}
	}
}
