import java.io.File;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.Select;



public class TestDropDown {
	
	private static final File browserAppPath = null;

	
	public static void main(String[] args) {

		WebDriver wd = new FirefoxDriver( new FirefoxBinary(browserAppPath), new FirefoxProfile());
		
		File browserAppPath = null;
		browserAppPath = new File("C:/Program Files/Mozilla Firefox/firefox.exe");

		
		//WebDriver wd = new FirefoxDriver();
		wd.get("https://www.wikipedia.org/");
		Select sel = new Select(wd.findElement(By.xpath("*//[@id='searchLanguage']")));
		sel.selectByVisibleText("Eesti");
		sel.selectByValue("hi");
		
		List <WebElement> options = sel.getOptions();	
		System.out.println(options.size());
		
		for (int i=0; i<options.size(); i++) {
			System.out.println(options.get(i).getAttribute("lang"));
		}
		
		System.out.println("Total links are: "+options.size());
	}
	
}
