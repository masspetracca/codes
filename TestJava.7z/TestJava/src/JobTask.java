
public class JobTask{

	public void startTask() {
		System.out.println("startTask");
	}

	public void stopTask() {
		System.out.println("stopTask");
	}

}
