package core;

public class WhileLoop {

//	private static int k;

	public static void main(String[] args) {
		int i = 1;
		
		while (i<=10) {
			
//			if (i>=5) {
//				break;
//			}
			
//			for (int j=0; j<4; i++) {
//				do {
//					System.out.println("i-->"+i+" j-->"+j);
//				} while (k<5);
			System.out.println(i);
			i++;
//			}
		}
	}
}
