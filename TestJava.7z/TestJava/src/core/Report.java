package core;

public class Report {	
	
	String title = "original";	

}