package core;

public class Node {
	int value;
	Node nextNodeRef;
	
	public Node(int value) {
		this.value = value;
	}
}
