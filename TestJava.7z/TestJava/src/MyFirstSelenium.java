import com.thoughtworks.selenium.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


//Sess. 4, lez. 28
public class MyFirstSelenium extends SeleneseTestBase {
    @Before
    public void setUp() throws Exception {
        selenium = new DefaultSelenium("localhost", 4444, "*firefox", "http://www.borsaitaliana.it/homepage/homepage.htm");
        selenium.start();
        selenium.open("/");
        selenium.windowMaximize();
        selenium.windowFocus();
        
    }

    @Test
    public void testUntitled() throws Exception {
        selenium.open("/friend_circle/admin/login");
        selenium.type("id=username", "admin");
        selenium.type("id=pass", "admin");
        selenium.click("id=submit");
        selenium.waitForPageToLoad("30000");
    }

    @After
    public void tearDown() throws Exception {
        selenium.stop();
    }
}