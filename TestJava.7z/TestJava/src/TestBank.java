
public class TestBank {
	
	public static void main (String args[]) {
			Bank b1 = new Bank();
			b1.name = "HSBC";
			b1.accountbalance=1000;
			b1.interestgained(500);
			System.out.println(b1.accountbalance);
			
			Members mb = new Members();
			mb.add="1801 south avenue, california";
			mb.name="J. Daniels";
			
			b1.mem=mb;
			
			System.out.println("b1.mem.add#"+b1.mem.add);
			System.out.println("b1.mem.name#"+b1.mem.name);

			Bank b2 = new Bank();
			b2.name = "HSBC";
			b2.accountbalance=2000;
			b2.interestgained(800);
			System.out.println(b2.accountbalance);
			
			b2.mem=mb;
			
			System.out.println("b2.mem.add#"+b2.mem.add);
			System.out.println("b2.mem.name#"+b2.mem.name);
			
			JobTask jt = new JobTask();
			jt.startTask();
			
			jt.stopTask();
			
		}
	
}
