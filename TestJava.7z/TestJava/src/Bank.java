
public class Bank {

	public String name;
	public int accountbalance;
	
	public Members mem;
	public void interestgained(int i) {
		return;
	}

}
