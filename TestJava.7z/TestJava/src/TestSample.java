import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Parameters;

public class TestSample {

	@Parameters("browser")	
	public void testLogin() throws MalformedURLException {
		DesiredCapabilities cap = DesiredCapabilities.firefox();
		cap.setBrowserName("firefox");
		cap.setPlatform(Platform.ANY);
		
		RemoteWebDriver drv = RemoteWebDriver(new URL("http://localhost:4444/wb/hub"),cap);
		drv.get("http://gmail.com");
		drv.findElement(By.id("Email")).sendKeys("masspetracca@gmail.com");
		drv.findElement(By.id("Passwd")).sendKeys("passwd");
	}

	private RemoteWebDriver RemoteWebDriver(URL url, DesiredCapabilities cap) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
