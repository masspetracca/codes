import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Cadencie {

	static WebDriver driver;
	
	public static void main(String[] args) {
		LoginCad();
	}
	public static void LoginCad(){
	
	    //System.setProperty("webdriver.firefox.bin", "C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
	
	    System.setProperty("webdriver.gecko.driver", "C:\\Program Files (x86)\\Mozilla Firefox\\geckodriver.exe");
	
	    driver = new FirefoxDriver();
	
	    driver.get("http://172.16.1.133:8090/CADENCIE/servlet/app");
	
	    try {
	
	        Thread.sleep(1000);
	
	    } catch(InterruptedException e){
	
	        e.printStackTrace();
	
	    }
	
	    /*	    Utilities.switchToWindow("Cadencie - User Logon [LOGON]", driver);
	
	    try{
	
	        Thread.sleep(2000);
	
	    } catch(InterruptedException e){
	
	        e.printStackTrace();
	
	    }*/
	
	    driver.findElement(By.id("idBANK")).clear();
	    driver.findElement(By.id("idBANK")).sendKeys("48");
	
	    driver.findElement(By.id("idEMPLOYEE")).clear();
	    driver.findElement(By.id("idEMPLOYEE")).sendKeys("200003");
	
	    driver.findElement(By.id("idPASSWORD")).clear();
	    driver.findElement(By.id("idPASSWORD")).sendKeys("Cadencie1");
	
	    driver.findElement(By.id("maintLOGON")).click();
	
	    driver.findElement(By.id("idPASSWORD")).clear();
	    driver.findElement(By.id("idPASSWORD")).sendKeys("Cadencie1");
	
	    driver.findElement(By.id("maint")).click();
		}
}