
public class Members {

	public String add;
	public String name;

}
