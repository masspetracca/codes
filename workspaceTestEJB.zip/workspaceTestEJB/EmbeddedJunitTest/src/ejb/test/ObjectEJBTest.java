package ejb.test;



import junit.framework.TestCase;
import ejb.test.ObjectEJBTest;
import ejbi.ObjectEJBI;


public class ObjectEJBTest   extends TestCase{
		//test variables settings
		int num1=0;
		int num2=0;
		String stringTest="";
		Object objectTest = null;
	
		/*
		 * Setup before each test case
		 */
		ObjectEJBI aObjectEJBI = null;
		private int timerType;
		private int timer;

		protected void setUp() throws Exception {
			super.setUp();
			aObjectEJBI = new ObjectEJBI();
		}

//		@Test
//		public void testParms()  {
//			num1=10;
//			num2=20;
//			double result = aObjectEJBI.testNumParms(num1, num2);
//			assertTrue("Testing settings Parms completed", false );
//		}
		public void testAdditionSum() throws Exception {
			assertTrue("ObjectEJB instance is not null", aObjectEJBI != null);
//
//			num1=2;
//			num2=2;
			double result = aObjectEJBI.testNumParms(num1, num2);
			assertTrue("2+2=4", result == 4);

		}
		
		public void testStringParms() throws Exception {
//			stringTest="OK";
			String result = aObjectEJBI.testStringParms(stringTest);
			assertTrue("caratteri non = 'OK'", result == "OK"); //valore atteso = OK
		}
		
		public void testObjectParms() throws Exception {
//			objectTest = " {1,2}";
			Object result = aObjectEJBI.testObjectParms(objectTest);
			assertTrue("risultato non = valorizzato", result != null); //valore atteso NOT null
		}

		public void testTimer() throws Exception {
//			timer = 12000;
			double  result = aObjectEJBI.createTimer(timer);
			assertTrue("Timer testTimer() non = valorizzato", result != 0); //valore atteso NOT zero
		}
		public void testOneShotTimer() throws Exception {
//			timer = 12000;
			double result = aObjectEJBI.createOneShotTimer(timer);
			assertTrue("Timer testOneShotTimer() non = valorizzato", result != 0); //valore atteso NOT zero
		}
		public void testTimerType() throws Exception {
//			timerType = 2000;
			double result = aObjectEJBI.getTimer(timerType);
			assertTrue("Timer testTimerType() non = valorizzato", result != 0); //valore atteso NOT zero
		}
		public void testTimerOut() throws Exception {
//			timer = 2000;
			double result = aObjectEJBI.getTimer(timer);
			assertTrue("Timer testTimerOut() non = valorizzato", result == 0); //valore atteso zero
		}
		public void testDeleteTimer() throws Exception {
//			timerType = 0;
			double result = aObjectEJBI.deleteTimer(timerType);
			assertTrue("Timer testDeleteTimer() non = valorizzato", result == 0); //valore atteso zero
		}
		public void testDeleteAllTimer() throws Exception {
//			timer = 0;
			double result = aObjectEJBI.deleteAllTimers(timer);
			assertTrue("Timer testDeleteAllTimers() non = valorizzati", result == 0); //valore atteso zero
		}
		
		public void testEnded()  {
			assertTrue("Test instance is ended without errors", false);
		}
	
}