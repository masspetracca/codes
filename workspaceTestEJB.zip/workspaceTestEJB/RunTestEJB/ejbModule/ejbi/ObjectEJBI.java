package ejbi;



public class ObjectEJBI {
   
	public double testNumParms(double first, double second) {
		return (first + second); 
	}

	public String testStringParms(String stringTest) {
		return (stringTest); 
	}

	public Object testObjectParms(Object objectTest) {
		return (objectTest); 
	}
	
	 public double createTimer(double timer) {
			return timer;
	 }
	public double getTimer(double timer) {
		return (timer); 
	}
	 public double createOneShotTimer(double timer) {
			return timer;
	   }	
	 public double getTimerType(double timerType) {
		return timerType;
	   }
	 public double getTimeout(double timer) {
		return timer;
	 }
	 public double deleteTimer(double timerType) {
		return (timerType); 
	}
	 public double deleteAllTimers(double timer) {
		 return timer;
	 }

}