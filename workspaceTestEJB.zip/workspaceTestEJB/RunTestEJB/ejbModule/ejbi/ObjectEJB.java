package ejbi;


/**
 * Interface for Enterprise Bean generico: ObjectEJB
 */
public class ObjectEJB {

	public double createTimer(double timer) {
	 	 return timer;
	}
	public double createOneShotTimer(double timer) {
		return timer;
	}	
	public double getTimer(double timerType) {
		return (timerType); 
	}
	public double getTimeout(double timer) {
		return (timer); 
	}
	public double deleteTimer(double timerType) {
		return (timerType); 
	}
	public double deleteAllTimers(double timer) {
		return (timer); 
	}

	}
