package sahoo.hybridapp.example2.service;

import javax.persistence.*;

@Entity
@Table(name="USERNAME")
public class User implements java.io.Serializable {
  /**
	 * 
	 */
	private static final long serialVersionUID = -8660869787730028640L;

@Id
  private String name;

  @Basic
  private String password;

  public User() {} 
  
  public User(final String name, final String password) {
    this.name = name;
    this.password = password;
  }
  
  /*package*/ boolean match(final String password) {
    return this.password.equals(password);
  }
}
