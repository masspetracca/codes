package sahoo.hybridapp.example2.service;

public interface UserAuthService {

}
