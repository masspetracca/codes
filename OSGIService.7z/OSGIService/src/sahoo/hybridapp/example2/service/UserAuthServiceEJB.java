package sahoo.hybridapp.example2.service;


import javax.ejb.Stateless;
import javax.persistence.PersistenceContext;
import javax.persistence.EntityManager;


@Stateless
public class UserAuthServiceEJB implements UserAuthService
{
    @PersistenceContext
    private EntityManager em;

    public boolean login(String name, String password)
    {
        System.out.println("UserAuthServiceEJBuser: logging in " + name);
        if (name == null || password == null) return false;
        User u = em.find(User.class, name);
        return (u!=null && u.match(password));
    }

    public boolean register(String name, String password)
    {
        System.out.println("UserAuthServiceEJB: registering " + name);
        User u = new User(name, password); 
        em.persist(u);
        return true;
    }
}
