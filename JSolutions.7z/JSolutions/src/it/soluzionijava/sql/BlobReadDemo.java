
package it.soluzionijava.sql;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BlobReadDemo {
	private static String url = "jdbc:as400://10.0.10.230:446/PAMPUSE2";

	private static String username = "pampuse2";

	private static String password = "ndapc1pfc";

	public static void main(String[] args) throws Exception {
		Connection conn = null;
		try {
			Class.forName("com.ibm.as400.access.AS400JDBCDriver");
			conn = DriverManager.getConnection(url, username, password);

			String sql = "SELECT * FROM TCTUPLF -- TCTSRCFLH where downloadid = 491";
			PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSet resultSet = stmt.executeQuery();
			while (resultSet.next()) {
				String name = resultSet.getString(3);
				System.out.println(">>" + name);

				File image = new File("H:\\java.pdf");
				FileOutputStream fos = new FileOutputStream(image);

				byte[] buffer = new byte[256];

				//
				// Get the binary stream of our BLOB data
				//
				InputStream is = resultSet.getBinaryStream(3);
				while (is.read(buffer) > 0) {
					fos.write(buffer);
				}

				fos.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		}
	}
}
