package com.hellokoding.account.repository;

import com.hellokoding.account.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository <User, Long> { //extends JpaRepository<User, Long> {
    com.hellokoding.account.model.User findByUsername(String username);

	void save(User user);
}
