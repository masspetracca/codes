package com.gannon.TaskEvaluation.shared;

import java.io.Serializable;

import javax.jdo.annotations.Extension;
import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

@PersistenceCapable
public class Contact implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@PrimaryKey
    @Persistent(valueStrategy = IdGeneratorStrategy.IDENTITY)
	@Extension(vendorName = "datanucleus", key = "gae.encoded-pk", value = "true")
	private String objId;  
	
	public String objectId() {
		return objId;
	}

	// Each Member has a Name
	@Persistent
	private String firstName;	
	
	@Persistent
	private String lastName;	

	// Each Member has a Name
	@Persistent
	private String email;	

	public Contact(){}
	
	public Contact(String fName, String lName, String sEmail) {
		this.firstName = fName;
		this.lastName = lName;
		this.email = sEmail;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setFirstName(String fName) {
		this.firstName = fName;
	}
	
	public void setLastName(String lName) {
		this.lastName = lName;
	}
	
	public String getEmail() {
		return email;
	}

	public void setMemberEmail(String memberEmail) {
		this.email = memberEmail;
	}
}
