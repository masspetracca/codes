package com.gannon.TaskEvaluation.shared;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jdo.annotations.Extension;
import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;


// This class represents each of the Task in the system
@PersistenceCapable
public class Task implements Serializable{
	
	///// Attributes of Task.
    
	private static final long serialVersionUID = 1L;	
	
	@PrimaryKey
    @Persistent(valueStrategy = IdGeneratorStrategy.IDENTITY)
	@Extension(vendorName = "datanucleus", key = "gae.encoded-pk", value = "true")
	protected String objId;  
	
	public String objectId() {
		return objId;
	}

	// Each Task has a Name.
	@Persistent
	private String taskName;
	
	// Each Task has Description.
	@Persistent
	private String taskDescription;	
	
	// Each Task has Description.
	@Persistent
	private String taskCreator;	

	// Each Task is authored by one or many members. This is list of there obj ids.
	@Persistent
	private List<String> taskAuthors = new ArrayList<String>();
	
	// Each Task is evaluated by one or many members. This is list of there Email ids.
	@Persistent
	private List<String> taskEvaluators = new ArrayList<String>();
	
	// Date of creation for this Task.
	@Persistent
	private Date creationDate;	

	// Last day of completion.
	@Persistent
	private Date completionDate;
	
	// Flag indicating whether this is a Public or a Private Task.
	@Persistent
	private java.lang.Boolean publicTask;
	
	// Template used to evaluate this task.
	@Persistent
	private String myTemplate;
	
	// Boolean to indicate whether the Template can be changed for this task.
	// In other words has some one already evaluated this task.
	@Persistent
	private Boolean isTemplateEditable;
	
	// Boolean to indicate whether the Template can be changed for this task.
	// In other words has some one already evaluated this task.
	@Persistent
	private Boolean areAllEvaluationsComplete;
	
	////////////////////////////////////////////////////////////////////////////

	public Task(){}
	
	public Task(String aTaskName) {
		taskName = aTaskName;
		this.creationDate = new Date();
		this.completionDate = new Date();
		this.isTemplateEditable = true;
		this.areAllEvaluationsComplete = false;
	}
	
	////////////////////////////////////////////////////////////////////////////

	public String getMyTemplate() {
		return myTemplate;
	}

	public void setMyTemplate(String myTemplate) {
		this.myTemplate = myTemplate;
	}

	public String getTaskName() {
		return taskName;
	}
	
	public List<String> getTaskAuthors() {
		return taskAuthors;
	}

	public String getTaskDescription() {
		return taskDescription;
	}
	
	public void setTaskName(String aTaskName) {
		this.taskName = aTaskName;
	}

	public void setTaskAuthors(List<String> taskAuthors) {
		this.taskAuthors = taskAuthors;
	}
	
	public void addAuthor(String authKey) {
		taskAuthors.add(authKey);
	}
	
	public void removeAuthor(String authKey){
		taskAuthors.remove(authKey);
	}

	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	
	public List<String> getTaskEvaluators() {
		return taskEvaluators;
	}

	public void setTaskEvaluators(List<String> taskEvaluators) {
		this.taskEvaluators = taskEvaluators;
	}
	
	public void addEvaluator(String aMemEmail) {
		taskEvaluators.add(aMemEmail);
	}
	
	public void removeEvaluator(String aMemEmail){
		taskEvaluators.remove(aMemEmail);
	}
	
	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getCompletionDate() {
		return completionDate;
	}

	public void setCompletionDate(Date completionDate) {
		this.completionDate = completionDate;
	}

	public java.lang.Boolean isPublicTask() {
		return publicTask;
	}

	public void setPublicTask(java.lang.Boolean publicTask) {
		this.publicTask = publicTask;
	}	

	public String getTaskCreator() {
		return taskCreator;
	}

	public void setTaskCreator(String taskCreator) {
		this.taskCreator = taskCreator;
	}

	public Boolean isTemplateEditable() {
		return isTemplateEditable;
	}

	public void setIsTemplateEditable(Boolean aIsTemplateEditable) {
		this.isTemplateEditable = aIsTemplateEditable;
	}

	public Boolean areAllEvaluationsComplete() {
		return areAllEvaluationsComplete;
	}

	public void setAllEvaluationsComplete(Boolean aAreAllEvaluationsComplete) {
		this.areAllEvaluationsComplete = aAreAllEvaluationsComplete;
	}

}
