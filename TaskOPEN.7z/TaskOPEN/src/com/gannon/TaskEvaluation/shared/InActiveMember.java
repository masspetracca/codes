package com.gannon.TaskEvaluation.shared;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.jdo.annotations.Extension;
import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

@PersistenceCapable
public class InActiveMember implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@PrimaryKey
    @Persistent(valueStrategy = IdGeneratorStrategy.IDENTITY)
	@Extension(vendorName = "datanucleus", key = "gae.encoded-pk", value = "true")
	private String objId;  
	
	public String objectId() {
		return objId;
	}	

	// Each Member has a Name
	@Persistent
	private String email;	
	
	@Persistent(defaultFetchGroup = "true")
	private List<String> evalTasks = new ArrayList<String>();

	public InActiveMember(){}
	
	public InActiveMember(String aEmail, List<String> aEvalTasks) {
		this.email = aEmail;
		this.evalTasks = aEvalTasks;
	}
	
	public InActiveMember(String aEmail) {
		this.email = aEmail;
	}
	
	public String getEmail() {
		return email;
	}

	public void setMemberEmail(String memberEmail) {
		this.email = memberEmail;
	}
	
	public void setEvalTasks(List<String> aEvalTasks) {
		evalTasks = aEvalTasks;
	}
	
	public List<String> getEvalTasks() {
		return evalTasks;
	}	
	
	public void addToEvalTasks(String taskKey) {
		evalTasks.add(taskKey);
	}
	
	public void removeFromEvalTasks(String taskKey) {
		evalTasks.remove(taskKey);
	}
}
