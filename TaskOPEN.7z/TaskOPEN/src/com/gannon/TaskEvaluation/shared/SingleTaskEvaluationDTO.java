package com.gannon.TaskEvaluation.shared;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SingleTaskEvaluationDTO implements Serializable{
	
	///// Attributes of Grade Result.
	private static final long serialVersionUID = 1L;
	
	// Each Evaluation result has criterion.
	private String criteria;
	
	// Each Evaluation result has a weightage values.
	private Integer wieghtage;	
	
	// Each Evaluation result has criterion.
	private String description;

	// Each Evaluation result has a grade values.
	private Double gradeValue;
	
	// Each Evaluation result has comments.
	private String comment;

	public SingleTaskEvaluationDTO() {
		this.criteria = "";
		this.wieghtage = 0;
		this.gradeValue = 0.0;
		this.comment = "";
		this.description = "";
	}
	
	public SingleTaskEvaluationDTO(String aCriteria, Integer aWieghtage, String aDescription) {
		this.criteria = aCriteria;
		this.wieghtage = aWieghtage;
		this.description = aDescription;
		this.gradeValue = 0.0;
		this.comment = "";
	}
	
	public SingleTaskEvaluationDTO(String aCriteria, Integer aWieghtage,
			Double aGradeValue, String aComment) {
		this.criteria = aCriteria;
		this.wieghtage = aWieghtage;
		this.gradeValue = aGradeValue;
		this.comment = aComment;
	}

	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	
	public Integer getWieghtage() {
		return wieghtage;
	}
	
	public void setWieghtage(Integer wieghtage) {
		this.wieghtage = wieghtage;
	}

	public Double getGradeValue() {
		return gradeValue;
	}

	public void setGradeValue(Double gradeValue) {
		this.gradeValue = gradeValue;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}	
	
	public String getDescription() {
		return description;
	}
	
	// This method returns the list of dto objs for the given template, used in display for cell table.
	public static List<SingleTaskEvaluationDTO> getSingleEvalDTOsForTemplate(Template aTemplate){		
		List<SingleTaskEvaluationDTO> returnList = new ArrayList<SingleTaskEvaluationDTO>();		
		for(int i = 0;i<aTemplate.getCriteria().size();++i) {
			returnList.add(new SingleTaskEvaluationDTO(aTemplate.getCriteria().get(i),
												   aTemplate.getWeightage().get(i),
												   aTemplate.getCriteriaDescription().get(i).getValue()));
		}		
		return returnList;
	}

	public static List<SingleTaskEvaluationDTO> getSingleEvalDTOs(
			SingleTaskEvaluation result) {
		
		List<SingleTaskEvaluationDTO> returnList = new ArrayList<SingleTaskEvaluationDTO>();		
		for(int i = 0;i<result.getCriteria().size();++i) {
			returnList.add(new SingleTaskEvaluationDTO(result.getCriteria().get(i),
												   	   result.getWeightages().get(i),
												   	   result.getGradeValues().get(i),
												   	   result.getComments().get(i)));
		}		
		return returnList;
	}

}
