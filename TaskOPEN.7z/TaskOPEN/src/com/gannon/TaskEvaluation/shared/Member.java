package com.gannon.TaskEvaluation.shared;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.jdo.annotations.Extension;
import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;
import javax.jdo.annotations.Unique;




// This represents each Member in the system.
@PersistenceCapable
public class Member implements Serializable {
	
	///// Attributes of Member.

	private static final long serialVersionUID = 1L;
	
	@PrimaryKey
    @Persistent(valueStrategy = IdGeneratorStrategy.IDENTITY)
	@Extension(vendorName = "datanucleus", key = "gae.encoded-pk", value = "true")
	private String objId;  
	
	public String objectId() {
		return objId;
	}

	// Each Member has a Name
	@Persistent
	private String memberFName;	
	
	@Persistent
	private String memberLName;	

	// Each Member has a Name
	@Persistent
	@Unique(name="MEMBEREMAIL_IDX")
	private String memberEmail;	
	
	// Each Member has a Name
	@Persistent
	private String memberPassword;	

	// Each Member has one or many tasksAuthored.
	@Persistent
	private List<String> tasksAuthored = new ArrayList<String>();
	
	// Each Member has one or many EvalTasks.
	@Persistent(defaultFetchGroup = "true")
	private List<String> evalTasks = new ArrayList<String>();	
	
	// Each Member has one or many EvalTasks.
	@Persistent(defaultFetchGroup = "true")
	private List<String> submittedEvalTasks = new ArrayList<String>();
	
	// Each Member has one or many tasksAuthored.
	@Persistent
	private List<String> tasksCreated = new ArrayList<String>();	
	
	// Each Member has one or many Evaluation Templates.
	@Persistent
	private List<String> evalTemplates = new ArrayList<String>();
	
	// Each Member has Address book.
	@Persistent
	private List<String> memberContacts = new ArrayList<String>();	
	
	@Persistent
	Boolean isGoogleLogin;
	

	public Boolean getIsGoogleLogin() {
		return isGoogleLogin;
	}

	public void setIsGoogleLogin(Boolean isGoogleLogin) {
		this.isGoogleLogin = isGoogleLogin;
	}

	public Member(){}
	
	public Member(String fName, String lName, String sEmail) {
		memberFName = fName;
		memberLName = lName;
		memberEmail = sEmail;
		isGoogleLogin = false;
	}
	
	public List<String> getMemberContacts() {
		return memberContacts;
	}

	public void setMemberContacts(List<String> memberContacts) {
		this.memberContacts = memberContacts;
	}
	
	public void addToMemberContacts(String memberKey) {
		memberContacts.add(memberKey);
	}
	
	public void removeFromMemberContacts(String memberKey) {
		memberContacts.remove(memberKey);
	}
	
	/**
	 * @return the memberName
	 */
	public String getMemberFirstName() {
		return memberFName;
	}
	
	public String getMemberLastName() {
		return memberLName;
	}
	
	public String getMemberFullName() {
		return memberFName+" "+memberLName;
	}

	/**
	 * @param memberName the memberName to set
	 */
	public void setMemberFirstName(String fName) {
		this.memberFName = fName;
	}
	
	public void setMemberLastName(String lName) {
		this.memberLName = lName;
	}
	/**
	 * @return the sectionName
	 */
	public List<String> getTasksAuthored() {
		return tasksAuthored;
	}		
	
	public void addToTasksAuthored(String taskKey) {
		tasksAuthored.add(taskKey);
	}
	
	public void removeFromTasksAuthored(String taskKey) {
		tasksAuthored.remove(taskKey);
	}
	
	/**
	 * EvalTasks
	 */
	public List<String> getEvalTasks() {
		return evalTasks;
	}

	public void setEvalTasks(List<String> evalTasks) {
		this.evalTasks = evalTasks;
	}	
	
	public void addToEvalTasks(String taskKey) {
		evalTasks.add(taskKey);
	}
	
	public void removeFromEvalTasks(String taskKey) {
		evalTasks.remove(taskKey);
	}
	
	/**
	 * Submitted Eval Tasks
	 */
	public List<String> getSubmittedEvalTasks() {
		return submittedEvalTasks;
	}

	public void setSubmittedEvalTasks(List<String> aSubmittedEvalTasks) {
		this.submittedEvalTasks = aSubmittedEvalTasks;
	}	
	
	public void addToSubmittedEvalTasks(String taskKey) {
		submittedEvalTasks.add(taskKey);
	}
	
	public void removeFromSubmittedEvalTasks(String taskKey) {
		submittedEvalTasks.remove(taskKey);
	}
	
	/**
	 * @return the memberEmail
	 */
	public String getMemberEmail() {
		return memberEmail;
	}

	/**
	 * @param memberEmail the memberEmail to set
	 */
	public void setMemberEmail(String memberEmail) {
		this.memberEmail = memberEmail;
	}
	

	public List<String> getTasksCreated() {
		return tasksCreated;
	}

	public void setTasksCreated(List<String> tasksCreated) {
		this.tasksCreated = tasksCreated;
	}
	
	public void addToTasksCreated(String taskKey) {
		tasksCreated.add(taskKey);
	}
	
	public void removeFromTasksCreated(String taskKey) {
		tasksCreated.remove(taskKey);
	}

	public void setTasksAuthored(List<String> tasksAuthored) {
		this.tasksAuthored = tasksAuthored;
	}

	public String getMemberPassword() {
		return memberPassword;
	}

	public void setMemberPassword(String memberPassword) {
		this.memberPassword = memberPassword;
	}

	public List<String> getEvalTemplates() {
		return evalTemplates;
	}

	public void setEvalTemplates(List<String> evalTemplates) {
		this.evalTemplates = evalTemplates;
	}
	
	public void addToEvalTemplates(String templateKey) {
		evalTemplates.add(templateKey);
	}
	
	public void removeFromEvalTemplates(String templateKey) {
		evalTemplates.remove(templateKey);
	}

}
