package com.gannon.TaskEvaluation.shared;

import java.io.Serializable;
import java.util.Date;

public class EvaluationTaskDTO implements Serializable{
	
	///// Attributes of Grade Result.
	private static final long serialVersionUID = 1L;
	
	// Each Evaluation result has criterion.
	private String taskId;
	
	// Each Evaluation result has a weightage values.
	private String taskName;	

	// Each Evaluation result has criterion.
	private String templateId;
		
	// Each Evaluation result has a grade values.
	private Boolean isEvaluated;
	
	// Each Evaluation result has comments.
	private Date evaluationDate;

	private String taskPerformer;
	
	public EvaluationTaskDTO() {
		// Do not use this constructor..
	}
	
	public EvaluationTaskDTO(String aTaskId, String aTaskName, String aTemplateId, Boolean aIsEvaluated, Date aEvalDate, String aTaskPerformer) {
		this.taskId = aTaskId;
		this.taskName = aTaskName;
		this.isEvaluated = aIsEvaluated;
		this.evaluationDate = aEvalDate;
		this.templateId = aTemplateId;
		this.taskPerformer = aTaskPerformer;
	}
	
	public String getTask() {
		return taskId;
	}
	public String getTaskName() {
		return taskName;
	}
	public String getTemplateId() {
		return templateId;
	}
	public Boolean isTaskEvaluated() {
		return isEvaluated;
	}
	public Date getEvaluationDate() {
		return evaluationDate;
	}

	public String getTaskPerformer() {
		return taskPerformer;
	}

	public void setTaskPerformer(String taskPerformer) {
		this.taskPerformer = taskPerformer;
	}

}
