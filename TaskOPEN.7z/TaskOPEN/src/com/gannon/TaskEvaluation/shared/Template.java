package com.gannon.TaskEvaluation.shared;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.jdo.annotations.Extension;
import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

import com.google.appengine.api.datastore.Text;

@PersistenceCapable
public class Template implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@PrimaryKey
    @Persistent(valueStrategy = IdGeneratorStrategy.IDENTITY)
	@Extension(vendorName = "datanucleus", key = "gae.encoded-pk", value = "true")
	protected String objId;  
	
	public String objectId() {
		return objId;
	}
	
	@Persistent
	private String templateName;
	
	@Persistent
	private String templateMemberId;	

	// This is the set of Criteria on which we evaluate.
	@Persistent
	private List<String> criteria = new ArrayList<String>();

	// Weightage corresponding to the Criteria, there should be a One to One mapping
	// always, later try to move it to a HashMap.
	@Persistent
	private List<Integer> wieghtage = new ArrayList<Integer>();	

	// Criteria corresponding to the Criteria, there should be a One to One mapping
	// always, later try to move it to a HashMap.
	@Persistent
	private List<Text> criteriaDescription  = new ArrayList<Text>();
	
	// Flag indicating whether this is a Public or a Private Task.
	@Persistent
	private java.lang.Boolean publicTemplate;

	public Template(){}
	
	public Template(String tempName) {
		templateName = tempName; 
	}
	
	/**
	 * @return the criteriaDescription
	 */
	public List<Text> getCriteriaDescription() {
		return criteriaDescription;
	}	

	public java.lang.Boolean getPublicTemplate() {
		return publicTemplate;
	}

	public void setCriteriaDescription(List<Text> criteriaDescription) {
		this.criteriaDescription = criteriaDescription;
	}
	
	public void addCriteriaDescription(Text val) {
		criteriaDescription.add(val);
	}
	
	public void removeCriteriaDescription(int index){
		criteriaDescription.remove(index);
	}
	
	public void replaceCriteriaDescription(int index, Text description){
		criteriaDescription.set(index,description);
	}
	/**
	 * @return the templateName
	 */
	public String getTemplateName() {
		return templateName;
	}
	
	/**
	 * @return the templateName
	 */
	public void setTemplateName(String tName) {
		templateName = tName;
	}


	
	/**
	 * @return the weightage
	 */
	public List<Integer> getWeightage() {
		return wieghtage;
	}

	/**
	 * @param weightage the weightage to set
	 */
	public void setWeightage(List<Integer> weightage) {
		this.wieghtage = weightage;
	}
	
	public void addWeightage(Integer val) {
		wieghtage.add(val);
	}
	
	public void removeWeightage(int index){
		wieghtage.remove(index);
	}
	
	public void replaceWeightage(int index, int weigh){
		wieghtage.set(index,weigh);
	}
	
	/**
	 * @return the criteria
	 */
	public List<String> getCriteria() {
		return criteria;
	}

	/**
	 * @param criteria the criteria to set
	 */
	public void setCriteria(List<String> criteria) {
		this.criteria = criteria;
	}
	
	public void addCriteria(String val) {
		criteria.add(val);
	}
	
	public void removeCriteria(int index){
		criteria.remove(index);
	}
	
	public void replaceCriteria(int index, String crit){
		criteria.set(index,crit);
	}

	/**
	 * @return the templateMemberId
	 */
	public String getTemplateMemberId() {
		return templateMemberId;
	}

	/**
	 * @param templateMemberId the templateMemberId to set
	 */
	public void setTemplateMemberId(String templateMemberId) {
		this.templateMemberId = templateMemberId;
	}
	
	public java.lang.Boolean isPublicTemplate() {
		return publicTemplate;
	}

	public void setPublicTemplate(java.lang.Boolean publicTemplate) {
		this.publicTemplate = publicTemplate;
	}
	

}
