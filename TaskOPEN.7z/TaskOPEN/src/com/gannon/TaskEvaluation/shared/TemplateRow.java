package com.gannon.TaskEvaluation.shared;

import java.util.ArrayList;
import java.util.List;

import com.gannon.TaskEvaluation.client.forms.TemplateForm;  


public class TemplateRow {
	
	// Attributes need to be 
	private String criteria;
	private String description;
	private int weightage;
	
	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String aCriteria) {
		this.criteria = aCriteria;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String aDescription) {
		this.description = aDescription;
	}

	public int getWeightage() {
		return weightage;
	}
    
	public void setWeightage(int aWeightage) {
		this.weightage = aWeightage;
	}

    public TemplateRow(String crit, String desc, int weigh) {
    	this.criteria = crit;
    	this.description = desc;
    	this.weightage = weigh;
    }
    
    public TemplateRow() {   
    	this.criteria = TemplateForm.DEFAULT_CRITERIA;
    	this.description = TemplateForm.DEFAULT_DESCRIPTION;
    	this.weightage = 0;
    }
    
    public static List<TemplateRow> getAllTemplateRowsForTemplate(Template aTemplate){
    	List<TemplateRow> myTempRows = new ArrayList<TemplateRow>();
    	
    	for(int i = 0; i<aTemplate.getCriteria().size();i++){
    		String crit = aTemplate.getCriteria().get(i);
    		String critDesc = aTemplate.getCriteriaDescription().get(i).getValue();
    		int weigh = aTemplate.getWeightage().get(i);
    		
    		myTempRows.add(new TemplateRow(crit, critDesc, weigh));
    	}
    	return myTempRows;
    }
    
}
