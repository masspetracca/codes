package com.gannon.TaskEvaluation.shared;

import java.io.Serializable;
public class LoginInfo implements Serializable {
	
	// Shared class used to save info about Members using social login like the Google Account login.
	
	private static final long serialVersionUID = 1L;
	
	private String emailAddress;
	private String firstName;
	private String lastName;
	private String pictureUrl;
	
	private String memberId;

	
	public String getEmailAddress() {
		return emailAddress;
	}
	
	public void setEmailAddress(final String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(final String nickname) {
		this.firstName = nickname;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(final String aLastname) {
		this.lastName = aLastname;
	}
	
	public void setPictureUrl(final String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}
	
	public String getPictureUrl() {
		return pictureUrl;
	}

	public String memberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
}
// TODO #12:> end
