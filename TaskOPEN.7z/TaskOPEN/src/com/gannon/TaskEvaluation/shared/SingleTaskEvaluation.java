package com.gannon.TaskEvaluation.shared;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.jdo.annotations.Extension;
import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;


// This class represents each grading result for a student for a project.
@PersistenceCapable
public class SingleTaskEvaluation implements Serializable{
	
	///// Attributes of Single Evaluation.

	private static final long serialVersionUID = 1L;
	
	@PrimaryKey
    @Persistent(valueStrategy = IdGeneratorStrategy.IDENTITY)
	@Extension(vendorName = "datanucleus", key = "gae.encoded-pk", value = "true")
	protected String objId;  
	
	public String objectId() {
		return objId;
	}
	
	// Each Evaluation result is submitted by a Member.
	@Persistent
	private String memberId;	
	
	// Submitted Member emailId.
	@Persistent
	private String memberEmailId;

	// Each Evaluation result belongs to a Task.
	@Persistent
	private String taskId;
	
	// Each Evaluation result has criterion.
	@Persistent
	private List<String> criteria = new ArrayList<String>();
	
	// Each Evaluation result has a weightage values.
	@Persistent
	private List<Integer> wieghtage = new ArrayList<Integer>();	

	// Each Evaluation result has a grade values.
	@Persistent
	private List<Double> gradeValues = new ArrayList<Double>();
	
	// Each Evaluation result has comments.
	@Persistent
	private List<String> comments = new ArrayList<String>();
	
	public SingleTaskEvaluation(){}

	/**
	 * Member
	 */
	public String getMemberSubmitted() {
		return memberId;
	}

	public void setMemberSubmitted(String aMember) {
		this.memberId = aMember;
	}
	

	public String getMemberEmailId() {
		return memberEmailId;
	}

	public void setMemberEmailId(String memberEmailId) {
		this.memberEmailId = memberEmailId;
	}

	
	/**
	 * Task
	 */
	public String getTask() {
		return taskId;
	}

	public void setTask(String aTask) {
		this.taskId = aTask;
	}
	

	/**
	 * Criteria
	 */
	public List<String> getCriteria() {
		return criteria;
	}
	
	public void setCriteria(List<String> criteria) {
		this.criteria = criteria;
	}
	
	public void addCriteria(String val) {
		criteria.add(val);
	}
	
	public void removeCriteria(int index){
		criteria.remove(index);
	}

	/**
	 * weightage
	 */
	public List<Integer> getWeightages() {
		return wieghtage;
	}
	
	public void setWeightages(List<Integer> weightage) {
		this.wieghtage = weightage;
	}
	
	public void addWeightage(Integer val) {
		wieghtage.add(val);
	}
	
	public void removeWeightage(int index){
		wieghtage.remove(index);
	}
	
	/**
	 * Grades
	 */	
	public List<Double> getGradeValues() {
		return gradeValues;
	}
	
	public void setGradeValues(List<Double> gradeValues) {
		this.gradeValues = gradeValues;
	}
	
	public void addGradeValue(Double val) {
		gradeValues.add(val);
	}
	
	public void removeGradeValue(int index){
		gradeValues.remove(index);
	}

	/**
	 * Comments
	 */
	public List<String> getComments() {
		return comments;
	}
	
	public void setComments(List<String> comments) {
		this.comments = comments;
	}
	
	public void addComment(String val) {
		comments.add(val);
	}
	
	public void removeComment(int index){
		comments.remove(index);
	}
	
}
