package com.gannon.TaskEvaluation.server;

import java.util.Date;
import java.util.List;

import com.gannon.TaskEvaluation.client.TaskService;
import com.gannon.TaskEvaluation.shared.Task;
import com.gannon.TaskEvaluation.shared.Template;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * The server side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class TaskServiceImpl extends RemoteServiceServlet implements
TaskService {

	@Override
	public String createTask(String aTaskCreator, String aTaskName,
			String aTaskDescription, List<String> aTaskAuthors,
			List<String> aTaskEvaluators, Date aCreationDate,
			Date aCompletionDate, Boolean aPublicTask, String aTemplate) {
		
		return TaskJdoUtil.createTask(aTaskCreator, aTaskName, aTaskDescription, aTaskAuthors,
				aTaskEvaluators, aCreationDate, aCompletionDate, aPublicTask, aTemplate);
	}

	@Override
	public void editTask(String aTaskId, String aTaskName,
			String aTaskDescription, List<String> aTaskAuthors,
			List<String> aTaskEvaluators, Date aCreationDate,
			Date aCompletionDate, Boolean aPublicTask, String aTemplate) {
		
		TaskJdoUtil.editTask(aTaskId, aTaskName, aTaskDescription, aTaskAuthors, aTaskEvaluators,
				aCreationDate, aCompletionDate, aPublicTask, aTemplate);
	}

	@Override
	public void deleteTask(String aTaskId) {
		TaskJdoUtil.deleteTask(aTaskId);		
	}

	@Override
	public List<Task> returnAllPublicTasks() {
		return TaskJdoUtil.returnAllPublicTasks();
	}

	@Override
	public Template getTemplateForTask(String aTaskId) {
		return TaskJdoUtil.getTemplateForTask(aTaskId);
	}

}
;