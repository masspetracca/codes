package com.gannon.TaskEvaluation.server;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Transaction;

import com.gannon.TaskEvaluation.server.PMF;
import com.gannon.TaskEvaluation.shared.BCrypt;
import com.gannon.TaskEvaluation.shared.Contact;
import com.gannon.TaskEvaluation.shared.EvaluationTaskDTO;
import com.gannon.TaskEvaluation.shared.InActiveMember;
import com.gannon.TaskEvaluation.shared.Member;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluation;
import com.gannon.TaskEvaluation.shared.Task;
import com.gannon.TaskEvaluation.shared.Template;

public class MemberJdoUtil {	
	
	// A static class to define comparator for the completion dates of a Task,
	// this is used in sorting the Tasks and displaying for the user.
	public static class DateComparator implements Comparator<Task> {
	    public int compare(Task o1, Task o2) {
	        return o1.getCompletionDate().compareTo(o2.getCompletionDate());
	    }
	}
	
	// Check if the given login credentials are correct, if correct returns the
	// Object id of the member, else returns empty string.
	@SuppressWarnings("unchecked")
	public static Member isMember(String aMemberEmail, String aMemberPwd) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		javax.jdo.Query q = pm.newQuery(Member.class);
		q.setFilter("memberEmail == userEmailAdd");
		q.declareParameters("String userEmailAdd");

		try {
		  List<Member> results = (List<Member>) q.execute(aMemberEmail);
		  if (!results.isEmpty()) {
		    for (Member p : results) {
		    	String hashedPwd = p.getMemberPassword();
		    	if (BCrypt.checkpw(aMemberPwd, hashedPwd)){
		    		return pm.detachCopy(p);
		    	}
		    	//if(p.getMemberPassword().equals(aMemberPwd)){
		    		//return pm.detachCopy(p);
		    	//}
		    	break;
		    }
		  } 
		} finally {
		  q.closeAll();
		}
		return null;
	}	
	
	// This should be called when creating a new Task in the system.
	@SuppressWarnings("unchecked")
	public static String createMember(String afName, String alName, String aMemberEmail, String aMemberPassword ) {
		
		String myMemberId = "";
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			// Create a new Task Instance.
			tx.begin(); 
			
			// Check whether there is already an existing member with same email.
			javax.jdo.Query q = pm.newQuery(Member.class);
			q.setFilter("memberEmail == userEmailAdd");
			q.declareParameters("String userEmailAdd");			
			List<Member> results = (List<Member>) q.execute(aMemberEmail);
			
			if (results.isEmpty()) {
				// No member with same email id found, can add the user into db.
				Member myMember = new Member(afName, alName, aMemberEmail);				
				String hashedPwd = BCrypt.hashpw(aMemberPassword, BCrypt.gensalt());
				myMember.setMemberPassword(hashedPwd);	
				
				// Check whether any Inactive members are present
				// Add evaluation task for inactive member.
				javax.jdo.Query q1 = pm.newQuery(InActiveMember.class);
				q1.setFilter("email == userEmailAdd");
				q1.declareParameters("String userEmailAdd");
				
				List<InActiveMember> results1 = (List<InActiveMember>) q1.execute(aMemberEmail);
				if (!results1.isEmpty()) {
					myMember.setEvalTasks(results1.get(0).getEvalTasks());
					// delete the inactive member object, since he is now active.
					pm.deletePersistent(results1.get(0));
				}
				pm.makePersistent(myMember);
				tx.commit(); // Commit the PM transaction
				
				myMemberId = myMember.objectId();	
				
			 }
			
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}	
			pm.close();
		}
		return myMemberId;
	}
	
	// This should be called when editing existing Member First name and Last name in the system.
	public static void editMemberDetails(String aMemberId, String afName, String alName) {		
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();		
			Member myMember = pm.getObjectById(Member.class, aMemberId);				
			myMember.setMemberFirstName(afName);
			myMember.setMemberLastName(alName);			
			pm.makePersistent(myMember);
			tx.commit(); // Commit the PM transaction				
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}	
			pm.close();
		}
	}
	
	// This should be called when editing existing Member First name and Last name in the system.
	public static Boolean editMemberPassword(String aMemberId, String aCurrentPassword, String aNewPassword) {		
		Boolean returnValue = false;
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();		
			Member myMember = pm.getObjectById(Member.class, aMemberId);
			String hashedPwd = myMember.getMemberPassword();
	    	if ( (BCrypt.checkpw(aCurrentPassword, hashedPwd))	&& !myMember.getIsGoogleLogin() )   		
			{
				returnValue = true;
				String newHashedPwd = BCrypt.hashpw(aNewPassword, BCrypt.gensalt());
				myMember.setMemberPassword(newHashedPwd);
			}		
			pm.makePersistent(myMember);
			tx.commit(); // Commit the PM transaction				
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}	
			pm.close();
		}
		
		return returnValue;
	}
	
	// This should be called when deleting existing Member in the system.
	@SuppressWarnings("unchecked")
	public static Boolean deleteMember(String aMemberId, String aPassword) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			Member myMember = pm.getObjectById(Member.class, aMemberId);
			String hashedPwd = myMember.getMemberPassword();
	    	if (! BCrypt.checkpw(aPassword, hashedPwd) ){
				// Passwords do not match.
	    		if (myMember.getIsGoogleLogin()) {
	    			// delete the Google account holder without password required.
	    		}
	    		else {
	    			return false;
	    		}
			}

			// First remove all the Tasks created by this user.
			for (String temp : myMember.getTasksCreated()) {
				TaskJdoUtil.deleteTask(temp);
			}

			// Remove all the Contacts created by this user.
			for (String temp : myMember.getMemberContacts()) {
				ContactJdoUtil.deleteContact(aMemberId, temp);
			}
			
			// Remove all the Templates created by this user.
			for (String temp : myMember.getEvalTemplates()) {
				TemplateJdoUtil.deleteTemplate(temp);
			}
			
			// If this member was assigned some eval tasks, create an Inactive member object and
			// assign him them, so that if user decides to reactivate the account he will get the
			// Eval tasks (and Tasks will not be containing zero evaluators).
			if(myMember.getEvalTasks().size() > 0) {	
				tx.begin();
				InActiveMember inMem = new InActiveMember(myMember.getMemberEmail());				
				for (String temp : myMember.getEvalTasks()) {
					//Task myTask = pm.getObjectById(Task.class,temp);
					//myTask.removeEvaluator(myMember.getMemberEmail());					
					inMem.addToEvalTasks(temp);
				}
				pm.makePersistent(inMem);
				tx.commit();
			}
			
			// Delete any evaluations he made.
			tx.begin();
			for (String temp : myMember.getSubmittedEvalTasks()) {
				
				javax.jdo.Query q = pm.newQuery(SingleTaskEvaluation.class);
				q.setFilter("taskId == taskkey && memberId == memberkey" );
				q.declareParameters("String taskkey, String memberkey");

				List<SingleTaskEvaluation> results = (List<SingleTaskEvaluation>) q.execute(temp, aMemberId);
				if(results.size()>0){
					pm.deletePersistent(results.get(0));
				}
			}
			tx.commit();
		
			// Delete the Member object itself
			tx.begin();
			pm.deletePersistent(myMember);
			tx.commit(); 
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}	
			pm.close();
		}
		
		return true;
	}
	
	public static List<Task> getEvaluationTasksForMember(String aMemberId) {
		List<Task> results = new ArrayList<Task>();
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Member myMember = pm.detachCopy(pm.getObjectById(Member.class, aMemberId));
		
		for( String myTasks : myMember.getEvalTasks()) {
			results.add(pm.detachCopy(pm.getObjectById(Task.class, myTasks)));
		}	
		return results;
	}
	
	public static List<Task> getAllAuthoredTasksForMember(String aMemberId) {
		List<Task> results = new ArrayList<Task>();
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Member myMember = pm.detachCopy(pm.getObjectById(Member.class, aMemberId));
		
		for( String myTasks : myMember.getTasksAuthored()) {
			results.add(pm.detachCopy(pm.getObjectById(Task.class, myTasks)));
		}	
		return results;
	}
	
	public static List<Task> getAllCreatedTasksForMember(String aMemberId) {
		List<Task> results = new ArrayList<Task>();
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Member myMember = pm.detachCopy(pm.getObjectById(Member.class, aMemberId));
		
		for( String myTaskId : myMember.getTasksCreated()) {
			Task myTask = pm.detachCopy(pm.getObjectById(Task.class, myTaskId));
			List<SingleTaskEvaluation> evals = EvaluationJdoUtil.getEvaluationsOfMyTask(myTaskId);
			if( (evals != null) && (evals.size() > 0) )
			{
				myTask.setIsTemplateEditable(false);
				if(evals.size() == myTask.getTaskEvaluators().size()){
					myTask.setAllEvaluationsComplete(true);
				}
			}			
			results.add(myTask);
		}	
		
		// Now Sort the Tasks according to their completion dates.
		if(results.size() > 0){
			Collections.sort(results, new DateComparator());
		}
		
		return results;
	}
	
	public static List<Template> getAllTemplatesForMember(String aMemberId) {
		List<Template> results = new ArrayList<Template>();
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Member myMember = pm.detachCopy(pm.getObjectById(Member.class, aMemberId));
		
		for( String myTemplates : myMember.getEvalTemplates()) {
			results.add(pm.detachCopy(pm.getObjectById(Template.class, myTemplates)));
		}	
		return results;
	}
	

	public static List<Contact> getAllContactsForMember(String aMemberId) {
		List<Contact> results = new ArrayList<Contact>();
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Member myMember = pm.detachCopy(pm.getObjectById(Member.class, aMemberId));
		
		for( String myContact : myMember.getMemberContacts()) {
			results.add(pm.detachCopy(pm.getObjectById(Contact.class, myContact)));
		}	
		return results;
	}
	

	// returns both eval and submitted tasks.
	public static List<EvaluationTaskDTO> getAllEvalTasksForMember(String aMemberId) {
		List<EvaluationTaskDTO> results = new ArrayList<EvaluationTaskDTO>();
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Member myMember = pm.detachCopy(pm.getObjectById(Member.class, aMemberId));
		
		for( String myTasks : myMember.getEvalTasks()) {
			Task myTask = pm.detachCopy(pm.getObjectById(Task.class, myTasks));
			results.add(new EvaluationTaskDTO(myTask.objectId(), myTask.getTaskName(),myTask.getMyTemplate(),
											  false, myTask.getCompletionDate(), myTask.getTaskAuthors().get(0)));
		}
		
		for( String myTasks : myMember.getSubmittedEvalTasks()) {
			Task myTask = pm.detachCopy(pm.getObjectById(Task.class, myTasks));
			results.add(new EvaluationTaskDTO(myTask.objectId(), myTask.getTaskName(),myTask.getMyTemplate(),
											  true, myTask.getCompletionDate(), myTask.getTaskAuthors().get(0)));
		}
		return results;
	}

}
