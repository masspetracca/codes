package com.gannon.TaskEvaluation.server;

import javax.jdo.PersistenceManager;
import javax.jdo.Transaction;

import com.gannon.TaskEvaluation.shared.Contact;
import com.gannon.TaskEvaluation.shared.Member;

public class ContactJdoUtil {
	
	public static Boolean createContact(String aMemId, String aEmail, String aFirstName,
			String aLastName) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();
			
			// First check whether this contact is already present for this Member.
			Member myMember = pm.getObjectById(Member.class, aMemId);
			for(String conId: myMember.getMemberContacts() ) {
				Contact myContact = pm.getObjectById(Contact.class, conId);
				if(myContact.getEmail().equalsIgnoreCase(aEmail)) {
					// Contact already present for the user.
					return false;
				}
			}
			
			// Contact does not exists for this user, create new....
			// When creating a contact the first name can be empty.
			String fname = aFirstName;
			String lname = aLastName;
			if(aFirstName.isEmpty()) {
				String[] parts = aEmail.split("@");
				fname = parts[0];
				lname = "";
			}

			Contact myContact = new Contact(fname, lname, aEmail);
			pm.makePersistent(myContact);
			tx.commit(); 
				
			myMember.addToMemberContacts(myContact.objectId());
			
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}	
			pm.close();
		}
	
		return true;
	}
	
	public static void editContact(String aContactId, String aFirstName,
								   String aLastName) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();
			Contact myContact = pm.getObjectById(Contact.class, aContactId);	
			myContact.setFirstName(aFirstName);
			myContact.setLastName(aLastName);
			pm.makePersistent(myContact);
			tx.commit();
			
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}	
			pm.close();
		}
		
	}
	
	public static void deleteContact(String aMemId, String aContactId) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {			
			tx.begin();
			
			Contact myContact = pm.getObjectById(Contact.class, aContactId);
			Member myMember = pm.getObjectById(Member.class, aMemId);
			
			myMember.removeFromMemberContacts(aContactId);
			
			pm.deletePersistent(myContact);
			
			tx.commit();
			
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}	
			pm.close();
		}
		
	}
}
