package com.gannon.TaskEvaluation.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonToken;

import com.gannon.TaskEvaluation.client.GoogleLoginService;
import com.gannon.TaskEvaluation.shared.LoginInfo;
import com.gannon.TaskEvaluation.shared.Member;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

@SuppressWarnings("serial")
public class GoogleLoginServiceImpl extends RemoteServiceServlet implements GoogleLoginService{
	
	private static Logger log = Logger.getLogger(GoogleLoginServiceImpl.class.getCanonicalName());

	@Override
	public Member loginDetails(final String token) {
		String url = "https://www.googleapis.com/oauth2/v1/userinfo?alt=json&access_token=" + token;
		final StringBuffer r = new StringBuffer();
		
		try {
			final URL u = new URL(url);
			final URLConnection uc = u.openConnection();
			final int end = 1000;
			InputStreamReader isr = null;
			BufferedReader br = null;
			try {
				isr = new InputStreamReader(uc.getInputStream());
				br = new BufferedReader(isr);
				final int chk = 0;
				while ((url = br.readLine()) != null) {
					if ((chk >= 0) && ((chk < end))) {
						r.append(url).append('\n');
					}
				}
			} 
			catch (final java.net.ConnectException cex) {
				r.append(cex.getMessage());
			} 
			catch (final Exception ex) {
				log.log(Level.SEVERE, ex.getMessage());
			} 
			finally {
				try {
					br.close();
				} 
				catch (final Exception ex) {
					log.log(Level.SEVERE, ex.getMessage());
				}
			}
		} 
		catch (final Exception e) {
			log.log(Level.SEVERE, e.getMessage());
		}
		
		final LoginInfo loginInfo = new LoginInfo();
		
		try {
			final JsonFactory f = new JsonFactory();
			JsonParser jp;
			jp = f.createJsonParser(r.toString());
			jp.nextToken();
			
			while (jp.nextToken() != JsonToken.END_OBJECT) {
				final String fieldname = jp.getCurrentName();
				jp.nextToken();
				
				if ("picture".equals(fieldname)) {
					loginInfo.setPictureUrl(jp.getText());
				} 
				else if ("name".equals(fieldname)) {
					loginInfo.setFirstName(jp.getText());								
				} 
				else if ("email".equals(fieldname)) {
					loginInfo.setEmailAddress(jp.getText());
				}
			}
		} 
		catch (final JsonParseException e) {
			log.log(Level.SEVERE, e.getMessage());
		} 
		catch (final IOException e) {
			log.log(Level.SEVERE, e.getMessage());
		}
		
		// Create new or Retrieve existing Member object from our db.
		Member myMember = GoogleLoginJdoUtil.loggedInGoogleAccount(loginInfo);
		
		loginInfo.setMemberId(myMember.objectId());
		
		return myMember;
	}

}
