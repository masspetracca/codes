package com.gannon.TaskEvaluation.server;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Transaction;

import com.gannon.TaskEvaluation.shared.Contact;
import com.gannon.TaskEvaluation.shared.InActiveMember;
import com.gannon.TaskEvaluation.shared.Member;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluation;
import com.gannon.TaskEvaluation.shared.Task;
import com.gannon.TaskEvaluation.shared.Template;
import com.gannon.TaskEvaluation.server.PMF;

// Utility Class which contains all the jdo utility methods for Entity Task
// Since any modification to this Entity(Task) involves modifying many other entities, i have divided each 
// method into multiple smaller transactions, since Data store only allows a maximum of Five entities in a 
// cross group transaction.
// Ashwin think of doing the same with all other Entity utils, for future safety.
public class TaskJdoUtil {
	
	public static Transaction begin() {
	      final Transaction tx = PMF.get().getPersistenceManager().currentTransaction();
	      tx.begin();
	      return tx;
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////
	// This should be called when creating a new Task in the system.
	@SuppressWarnings("unchecked")
	public static String createTask(String aTaskCreator, String aTaskName,
			String aTaskDescription, List<String> aTaskAuthors, List<String> aTaskEvaluators,
			Date aCreationDate, Date aCompletionDate, Boolean aPublicTask, String aTemplate ) {
		
		String myTaskId = "";
		PersistenceManager pm = PMF.get().getPersistenceManager();
		try {
			
			final Transaction txA = begin();
			// Create a new Task Instance.
			Task myTask = new Task(aTaskName);
			myTask.setTaskDescription(aTaskDescription);
			myTask.setTaskCreator(aTaskCreator);
			myTask.setTaskAuthors(aTaskAuthors);
			myTask.setTaskEvaluators(aTaskEvaluators);
			myTask.setCreationDate(aCreationDate);
			myTask.setCompletionDate(aCompletionDate);
			myTask.setPublicTask(aPublicTask);
			myTask.setMyTemplate(aTemplate);			
			pm.makePersistent(myTask);
			txA.commit();
			
			myTaskId = myTask.objectId();
			
			// Now update all the relationships.
			Member myCreator = pm.getObjectById(Member.class,aTaskCreator);
			myCreator.addToTasksCreated(myTaskId);

			//// Go Through the Task Evaluators List
			for (String temp : aTaskEvaluators) {
				
				final Transaction txB = begin();
				
				// Add evaluation task for evaluators.
				javax.jdo.Query q = pm.newQuery(Member.class);
				q.setFilter("memberEmail == userEmailAdd");
				q.declareParameters("String userEmailAdd");
				
				List<Member> results = (List<Member>) q.execute(temp);
				if (!results.isEmpty()) {
					results.get(0).addToEvalTasks(myTaskId);
				}
				else {
					// Add evaluation task for inactive member.
					javax.jdo.Query q1 = pm.newQuery(InActiveMember.class);
					q1.setFilter("email == userEmailAdd");
					q1.declareParameters("String userEmailAdd");
					
					List<InActiveMember> results1 = (List<InActiveMember>) q1.execute(temp);
					if (results1.isEmpty()) {
						InActiveMember inMem = new InActiveMember(temp);
						inMem.addToEvalTasks(myTaskId);
						pm.makePersistent(inMem);
					}
					else{
						results1.get(0).addToEvalTasks(myTaskId);
					}
				}
				txB.commit();
				
				// Add contacts for the task creator.
				boolean foundCon = false;
				for (String con : myCreator.getMemberContacts()) {
					Contact myContact = pm.getObjectById(Contact.class, con);
					if(temp.equalsIgnoreCase(myContact.getEmail())) {
						foundCon = true;
					}
				}
				
				if(!foundCon){
					final Transaction txC = begin();
					Contact newCon = null;
					if(!results.isEmpty()) {
						 newCon = new Contact(results.get(0).getMemberFirstName(),
								 			  results.get(0).getMemberLastName(),
								 			  results.get(0).getMemberEmail());
					}
					else {
						// Get first name from email.
						String[] parts = temp.split("@");						
						newCon = new Contact(parts[0],"",temp);
					}
					pm.makePersistent(newCon);
					myCreator.addToMemberContacts(newCon.objectId());
					txC.commit();	
				}				
			
			}
			
		//// Go Through the Task Performers List -- only one currently.
		// TODO : ASH, add contact for the task performer/author also.
		}
		catch(Exception e){
			
		}
		finally {	
			pm.close();
		}
		return myTaskId;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////
	// EDIT TASK
	// This should be called when editing existing Task in the system.
	@SuppressWarnings("unchecked")
	public static void editTask(String aTaskId, String aTaskName,
			String aTaskDescription, List<String> aTaskAuthors, List<String> aTaskEvaluators,
			Date aCreationDate, Date aCompletionDate, Boolean aPublicTask, String aTemplate ) {
	
	PersistenceManager pm = PMF.get().getPersistenceManager();
	try {
		final Transaction txA = begin();
		Task myTask = pm.getObjectById(Task.class, aTaskId);	
		
		// Get the old task evaluators before updating to the new one.
		List<String> oldTaskEvaluators = myTask.getTaskEvaluators();
		
		myTask.setTaskDescription(aTaskDescription);
		myTask.setTaskName(aTaskName);
		myTask.setTaskAuthors(aTaskAuthors);
		myTask.setTaskEvaluators(aTaskEvaluators);
		myTask.setCreationDate(aCreationDate);
		myTask.setCompletionDate(aCompletionDate);
		myTask.setPublicTask(aPublicTask);
		myTask.setMyTemplate(aTemplate);			
		pm.makePersistent(myTask);
		txA.commit(); // Commit the transaction		
	
	
		// Get the intersection of old and new evaluators the intersection evaluators need not change
		// anything.
		List<String> listIntersection = new ArrayList<String>(oldTaskEvaluators);
		listIntersection.retainAll(aTaskEvaluators);
		
		// Now for old task evaluators who got unassigned, remove this task.
		for (String temp : oldTaskEvaluators) {
			// Check if this member is in the intersection.
			if( listIntersection.contains(temp) ) {
				// No need to change, continue with the next member.
				continue;
			}
	
			javax.jdo.Query q = pm.newQuery(Member.class);
			q.setFilter("memberEmail == userEmailAdd");
			q.declareParameters("String userEmailAdd");
			
			List<Member> results = (List<Member>) q.execute(temp);
			final Transaction txB = begin();
			if (!results.isEmpty()) {
				// Member is a Active member in the system.
				// Check if this member already evaluated this task.
				if(results.get(0).getEvalTasks().contains(aTaskId)){
					// Member did not evaluate this task yet.
					results.get(0).removeFromEvalTasks(aTaskId);
				}
				else if(results.get(0).getSubmittedEvalTasks().contains(aTaskId)){
					// Member already evaluated this task.
					javax.jdo.Query nq = pm.newQuery(SingleTaskEvaluation.class);
					nq.setFilter("taskId == taskkey && memberId == memberkey" );
					nq.declareParameters("String taskkey, String memberkey");
				
					List<SingleTaskEvaluation> nqresults = (List<SingleTaskEvaluation>) nq.execute(aTaskId, results.get(0).objectId());
					if(nqresults.size()>0){
						pm.deletePersistent(nqresults.get(0));
					}
					// Remove the single association obj also.
					results.get(0).removeFromSubmittedEvalTasks(aTaskId);
				}
			}
			else {
				// Remove evaluation task for inactive member.
				javax.jdo.Query q1 = pm.newQuery(InActiveMember.class);
				q1.setFilter("email == userEmailAdd");
				q1.declareParameters("String userEmailAdd");
			
				List<InActiveMember> results1 = (List<InActiveMember>) q1.execute(temp);
				if (!results1.isEmpty()) {
					results1.get(0).removeFromEvalTasks(aTaskId);
			
					if(results1.get(0).getEvalTasks().size() == 0){
						// This In Active member has no eval tasks assigned, remove obj.
						pm.deletePersistent(results1.get(0));
					}
				}
			}
			txB.commit();
		}
	

	
		// Now for new Task evaluators who got assigned, add this as Eval task.
		for (String temp : aTaskEvaluators) {
			// Check if this member is in the intersection.
			if( listIntersection.contains(temp) ) {
				// No need to change, continue with the next member.
				continue;
			}
	
			javax.jdo.Query q = pm.newQuery(Member.class);
			q.setFilter("memberEmail == userEmailAdd");
			q.declareParameters("String userEmailAdd");
		
			List<Member> results = (List<Member>) q.execute(temp);
			final Transaction txC = begin();
			if (!results.isEmpty()) {
				results.get(0).addToEvalTasks(aTaskId);
			}
			else {
				// Add evaluation task for inactive member.
				javax.jdo.Query q1 = pm.newQuery(InActiveMember.class);
				q1.setFilter("email == userEmailAdd");
				q1.declareParameters("String userEmailAdd");
		
				List<InActiveMember> results1 = (List<InActiveMember>) q1.execute(temp);
				if (results1.isEmpty()) {
					InActiveMember inMem = new InActiveMember(temp);
					inMem.addToEvalTasks(aTaskId);
					pm.makePersistent(inMem);
				}
				else{
					results1.get(0).addToEvalTasks(aTaskId);
				}
			}		
			txC.commit();
		
			// Add to contacts for the task creator.
			boolean foundCon = false;
			Member myCreator = pm.getObjectById(Member.class, myTask.getTaskCreator());
			for (String con : myCreator.getMemberContacts()) {
				Contact myContact = pm.getObjectById(Contact.class, con);
				if(temp.equalsIgnoreCase(myContact.getEmail())) {
					foundCon = true;
				}
			}
		
			if(!foundCon){
				final Transaction txD = begin();
				Contact newCon = null;
				if(!results.isEmpty()) {
					newCon = new Contact(results.get(0).getMemberFirstName(),
							results.get(0).getMemberLastName(),
							results.get(0).getMemberEmail());
				}
				else {
					// Get first name from email.
					String[] parts = temp.split("@");	
					newCon = new Contact(parts[0],"",temp);
				}
				pm.makePersistent(newCon);
				myCreator.addToMemberContacts(newCon.objectId());
				txD.commit();
			}
		
		
		}
	
	} finally {			
		pm.close();
		}
	}

	/////////////////////////////////////////////////////////////////////////////////////////////
	// DELETE TASK
	// This should be called when deleting existing Task in the system.
	@SuppressWarnings("unchecked")
	public static void deleteTask(String aTaskId) {
		
		PersistenceManager pm = PMF.get().getPersistenceManager();
		try {
						
			// Get the task obj to be deleted.
			Task myTask = pm.getObjectById(Task.class, aTaskId);

			// For Members remove this task as to be evaluated/is submitted.
			List<String> taskEvaluators = myTask.getTaskEvaluators();			
			for (String temp : taskEvaluators) {
				javax.jdo.Query q = pm.newQuery(Member.class);
				q.setFilter("memberEmail == userEmailAdd");
				q.declareParameters("String userEmailAdd");
				
				List<Member> results = (List<Member>) q.execute(temp);

				final Transaction txA = begin();
				if (!results.isEmpty()) {
					// Check if this member already evaluated this task.
					if(results.get(0).getEvalTasks().contains(aTaskId)){
						// Member did not evaluate this task yet.
						results.get(0).removeFromEvalTasks(aTaskId);
					}
					else if(results.get(0).getSubmittedEvalTasks().contains(aTaskId)){
						// Member already evaluated this task.
						results.get(0).removeFromSubmittedEvalTasks(aTaskId);
					}
				}
				else {
					// Remove evaluation task for inactive member.
					javax.jdo.Query q1 = pm.newQuery(InActiveMember.class);
					q1.setFilter("email == userEmailAdd");
					q1.declareParameters("String userEmailAdd");
					
					List<InActiveMember> results1 = (List<InActiveMember>) q1.execute(temp);
					if (!results1.isEmpty()) {
						results1.get(0).removeFromEvalTasks(aTaskId);
						
						if(results1.get(0).getEvalTasks().size() == 0){
							// This In Active member has no eval tasks assigned, remove obj.
							pm.deletePersistent(results1.get(0));
						}
					}
				}
				txA.commit();
			}
			

			final Transaction txB = begin();			
			// Remove if any evaluations already done for this task.
			javax.jdo.Query q2 = pm.newQuery(SingleTaskEvaluation.class);
			q2.setFilter("taskId == taskkey");
			q2.declareParameters("String taskkey");

			List<SingleTaskEvaluation> results1 = (List<SingleTaskEvaluation>) q2.execute(aTaskId);
		    for (SingleTaskEvaluation stp : results1) {
		    	pm.deletePersistent(stp);
		    }		    
		    txB.commit();

			final Transaction txC = begin();			
			// Finally for this member remove as Task created.
			Member myCreator = pm.getObjectById(Member.class,myTask.getTaskCreator());
			myCreator.removeFromTasksCreated(aTaskId);
			
			// Delete the task itself.
			pm.deletePersistent(myTask);
			txC.commit(); 
			
		} finally {				
			pm.close();
		}		
	}

	/////////////////////////////////////////////////////////////////////////////////////////////
	@SuppressWarnings("unchecked")
	public static List<Task> returnAllPublicTasks() {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		List<Task> tempList = new ArrayList<Task>(), results = null;
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin(); // Start the PM transaction		
			String query = "select from " + Task.class.getName();
			results = (List<Task>)pm.newQuery(query).execute(); 
			tempList = new ArrayList<Task>();
			for (Task obj : results) {
				if(obj.isPublicTask()){
					tempList.add(pm.detachCopy(obj));
				}
			}
			tx.commit(); // Commit the PM transaction
			return tempList;
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}
			pm.close();
		}
	}

	/////////////////////////////////////////////////////////////////////////////////////////////
	public static Template getTemplateForTask(String aTaskId) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Task myTask = pm.detachCopy(pm.getObjectById(Task.class, aTaskId));
		return pm.detachCopy(pm.getObjectById(Template.class, myTask.getMyTemplate()));
	}	
}
