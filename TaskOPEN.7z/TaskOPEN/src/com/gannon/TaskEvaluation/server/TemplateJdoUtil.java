package com.gannon.TaskEvaluation.server;

import java.util.ArrayList;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Transaction;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Text;
import com.gannon.TaskEvaluation.shared.Member;
import com.gannon.TaskEvaluation.shared.Task;
import com.gannon.TaskEvaluation.shared.Template;

public class TemplateJdoUtil {
	
	@SuppressWarnings("unchecked")
	public static List<Template> returnAllPublicTemplates() {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		List<Template> tempList = new ArrayList<Template>(), results = null;
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin(); // Start the PM transaction		
			String query = "select from " + Template.class.getName();
			results = (List<Template>)pm.newQuery(query).execute(); 
			tempList = new ArrayList<Template>();
			for (Template obj : results) {
				if(obj.isPublicTemplate()){
					tempList.add(pm.detachCopy(obj));
				}
			}
			tx.commit(); // Commit the PM transaction
			return tempList;
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}
			pm.close();
		}
	}

	public static Template createTemplate(String name, String aMemberId, List<String> crit,
			List<Integer> weigh, List<String> criteriaDescription, Boolean publicTemplate) {
		
		List<Text> newCriteriaDescription = new ArrayList<Text>();
		for (String temp : criteriaDescription) {
				newCriteriaDescription.add(new Text(temp));
		}
		
		Template t1 = null;	
		String tempid = null;
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();
			Template t2 = new Template(name);
			t2.setTemplateMemberId(aMemberId);
			t2.setCriteria(crit);
			t2.setWeightage(weigh);
			t2.setCriteriaDescription(newCriteriaDescription);
			t2.setPublicTemplate(publicTemplate);
			pm.makePersistent(t2);
			
			tempid = t2.objectId();
			
			Member myMember = pm.getObjectById(Member.class, aMemberId);	
			myMember.addToEvalTemplates(tempid);
			t1 = pm.detachCopy(pm.getObjectById(Template.class, tempid));
			//t1 = pm.detachCopy(t2);
			tx.commit();
			
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}	
			pm.close();
		}
		
		return t1;
	}
	
	public static Template editTemplate(String aTemplateId, String name,
			List<String> crit, List<Integer> weigh,
			List<String> criteriaDescription, Boolean publicTemplate) {
		
		List<Text> newCriteriaDescription = new ArrayList<Text>();
		for (String temp : criteriaDescription) {
				newCriteriaDescription.add(new Text(temp));
		}
		
		Template t1 = null;	
		String tempid = null;
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();
			Template t2 = pm.getObjectById(Template.class, aTemplateId);
			t2.setTemplateName(name);
			t2.setCriteria(crit);
			t2.setWeightage(weigh);
			t2.setCriteriaDescription(newCriteriaDescription);
			t2.setPublicTemplate(publicTemplate);
			pm.makePersistent(t2);
			
			tempid = t2.objectId();

			t1 = pm.detachCopy(pm.getObjectById(Template.class, tempid));
			tx.commit();
			
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}	
			pm.close();
		}
		
		return t1;
	}
	
	// This should be called when deleting an existing Template in the system.
	// This returns false if an existing Task is using this template, true if it deletes
	// the template.
	@SuppressWarnings("unchecked")
	public static Boolean deleteTemplate(String aTemplateId) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		javax.jdo.Query q = pm.newQuery(Task.class);
		
		try {
			tx.begin();
			Template myTemplate = pm.getObjectById(Template.class, aTemplateId);			
			
			
			q.setFilter("myTemplate == templateAdd");
			q.declareParameters(Key.class.getName() + " templateAdd");
			
		    List<Task> results = (List<Task>) q.execute(aTemplateId);
		    if (!results.isEmpty()) {
		    	// There are existing tasks using this template cannot be deleted.
		    	tx.commit();
		    	return false;
		    }
		    
		    Member myMember = pm.getObjectById(Member.class, myTemplate.getTemplateMemberId());
		    myMember.removeFromEvalTemplates(aTemplateId);
			
			pm.deletePersistent(myTemplate);
			tx.commit(); 
		} finally {
			if (tx.isActive()) {
				q.closeAll();
				tx.rollback(); // Error occurred so rollback the PM transaction
			}	
			pm.close();
		}	
		return true;
	}

	public static void removeTemplateRow(String templateKey, Integer rowNum) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();		
			Template myTemp = pm.getObjectById(Template.class,templateKey);	
			
			myTemp.removeCriteria(rowNum);
			myTemp.removeWeightage(rowNum);
			myTemp.removeCriteriaDescription(rowNum);

			pm.makePersistent(myTemp);
			tx.commit(); // Commit the PM transaction		
	    } finally {
	    	if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}
	        pm.close();
	    }

	}

	public static void addTemplateRow(String templateKey, String crit,
			Integer weigh, String description) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();		
			Template myTemp = pm.getObjectById(Template.class,templateKey);	
			
			myTemp.addCriteria(crit);
			myTemp.addWeightage(weigh);
			myTemp.addCriteriaDescription(new Text(description));

			pm.makePersistent(myTemp);
			tx.commit(); // Commit the PM transaction		
	    } finally {
	    	if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}
	        pm.close();
	    }
	}

	public static void editTemplateRow(String templateKey, Integer rowNum,
			String crit, Integer weigh, String description) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();		
			Template myTemp = pm.getObjectById(Template.class,templateKey);	
			
			myTemp.replaceCriteria(rowNum, crit);
			myTemp.replaceWeightage(rowNum, weigh);
			myTemp.replaceCriteriaDescription(rowNum, new Text(description));

			pm.makePersistent(myTemp);
			tx.commit(); // Commit the PM transaction		
	    } finally {
	    	if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}
	        pm.close();
	    }		
	}

	public static Template getTemplateById(String aTemplateId) {
		Template t1 = null;
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();		
			t1 = pm.detachCopy(pm.getObjectById(Template.class, aTemplateId));
			tx.commit(); // Commit the PM transaction		
	    } finally {
	    	if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}
	        pm.close();
	    }
		
		return t1;
	}

	

}
