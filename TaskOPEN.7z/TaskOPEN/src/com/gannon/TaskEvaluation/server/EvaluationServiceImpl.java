package com.gannon.TaskEvaluation.server;

import java.util.List;

import com.gannon.TaskEvaluation.client.EvaluationService;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluation;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluationDTO;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * The server side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class EvaluationServiceImpl extends RemoteServiceServlet implements
EvaluationService {

	@Override
	public List<SingleTaskEvaluation> getEvaluationsOfMyTask(String aTaskId) {
		return EvaluationJdoUtil.getEvaluationsOfMyTask(aTaskId);
	}

	@Override
	public SingleTaskEvaluation saveSingleEvaluation(String aTaskId, String aMemberId,
			List<SingleTaskEvaluationDTO> aEvalDTOs) {
		return EvaluationJdoUtil.saveSingleEvaluation(aTaskId, aMemberId, aEvalDTOs);
		
	}

	@Override
	public SingleTaskEvaluation getSingleTaskEvaluation(String aMemberId,
			String aTaskId) {
		// TODO Auto-generated method stub
		return EvaluationJdoUtil.getSingleTaskEvaluation(aMemberId, aTaskId);
	}

	@Override
	public String sendEmail(String from, List<String> to,
			String subject, String message) {
		// TODO Auto-generated method stub
		return EvaluationJdoUtil.sendEmail(from, to, subject, message);
	}

}
