package com.gannon.TaskEvaluation.server;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.jdo.PersistenceManager;
import javax.jdo.Transaction;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.gannon.TaskEvaluation.shared.Member;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluation;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluationDTO;

public class EvaluationJdoUtil{

	@SuppressWarnings("unchecked")
	public static List<SingleTaskEvaluation> getEvaluationsOfMyTask(String aTaskId) {
		List<SingleTaskEvaluation> returnEvals = new ArrayList<SingleTaskEvaluation>();
		PersistenceManager pm = PMF.get().getPersistenceManager();
		javax.jdo.Query q = pm.newQuery(SingleTaskEvaluation.class);
		q.setFilter("taskId == taskkey");
		q.declareParameters("String taskkey");

		try {
		  List<SingleTaskEvaluation> results = (List<SingleTaskEvaluation>) q.execute(aTaskId);
		  if (!results.isEmpty()) {
		    for (SingleTaskEvaluation p : results) {
		    	returnEvals.add(pm.detachCopy(p));
		    }
		  } else {
		  }
		} finally {
		  q.closeAll();
		}
		return returnEvals;
	}

	public static SingleTaskEvaluation saveSingleEvaluation(String aTaskId, String aMemberId,
			List<SingleTaskEvaluationDTO> aEvalDTOs) {
		SingleTaskEvaluation s1 = null;	
		String seid = null;
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			Member myMember = pm.getObjectById(Member.class, aMemberId);	
			
			tx.begin();			
			SingleTaskEvaluation s2 = new SingleTaskEvaluation();
			s2.setMemberSubmitted(aMemberId);
			s2.setMemberEmailId(myMember.getMemberEmail());
			s2.setTask(aTaskId);
			for(SingleTaskEvaluationDTO temp: aEvalDTOs){
				s2.addCriteria(temp.getCriteria());
				s2.addWeightage(temp.getWieghtage());
				s2.addGradeValue(temp.getGradeValue());
				s2.addComment(temp.getComment());
			}			
			pm.makePersistent(s2);
			
			seid = s2.objectId();
	
			// For this member change the state of the eval task to submitted.
			myMember.removeFromEvalTasks(aTaskId);
			myMember.addToSubmittedEvalTasks(aTaskId);
			
			s1 = pm.detachCopy(pm.getObjectById(SingleTaskEvaluation.class, seid));
			tx.commit();
			
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}	
			pm.close();
		}		
		return s1;		
	}
	
	// For the given member and task this method returns any evaluated task.
	@SuppressWarnings("unchecked")
	public static SingleTaskEvaluation getSingleTaskEvaluation(String aMemberId, String aTaskId){
		SingleTaskEvaluation ste = null;
		
		PersistenceManager pm = PMF.get().getPersistenceManager();
		javax.jdo.Query q = pm.newQuery(SingleTaskEvaluation.class);
		q.setFilter("taskId == taskkey && memberId == memberkey" );
		q.declareParameters("String taskkey, String memberkey");

		try {
		  List<SingleTaskEvaluation> results = (List<SingleTaskEvaluation>) q.execute(aTaskId, aMemberId);
		  if (!results.isEmpty()) {
		    for (SingleTaskEvaluation p : results) {
		    	ste = pm.detachCopy(p);
		    }
		  } else {
		  }
		} finally {
		  q.closeAll();
		}
		
		return ste;
	}

	// Send Email
	public static String sendEmail(String from, List<String> to, 
			String subject, String message) {
		String output=null;
        Properties props = new Properties();
        Session session = Session.getDefaultInstance(props, null);

        try {
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress("taskevaluationsystem@gmail.com",
            		"Task Evaluation Admin"));
            for(String temp: to){
            	msg.addRecipient(Message.RecipientType.TO,
                             new InternetAddress(temp, "Member"));
            }
            msg.setSubject(subject);
            //msg.setText(message);
            msg.setContent(message, "text/html;charset=UTF-8");
            Transport.send(msg);

        } catch (Exception e) {
            output=e.toString();                
        }   
        return output;
	}

}
