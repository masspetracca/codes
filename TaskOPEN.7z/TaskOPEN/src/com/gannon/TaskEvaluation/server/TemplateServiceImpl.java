package com.gannon.TaskEvaluation.server;

import java.util.List;

import com.gannon.TaskEvaluation.client.TemplateService;
import com.gannon.TaskEvaluation.shared.Template;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * The server side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class TemplateServiceImpl extends RemoteServiceServlet implements
TemplateService {

	@Override
	public List<Template> returnAllPublicTemplates() {
		return TemplateJdoUtil.returnAllPublicTemplates();
	}

	@Override
	public Template createTemplate(String name, String aMemberId,
			List<String> crit, List<Integer> weigh,
			List<String> criteriaDescription, Boolean publicTemplate) {
		return TemplateJdoUtil.createTemplate(name, aMemberId, crit, weigh, criteriaDescription, publicTemplate);
	}

	@Override
	public Boolean deleteTemplate(String aTemplateId) {
		return TemplateJdoUtil.deleteTemplate(aTemplateId);
	}

	@Override
	public void removeTemplateRow(String templateKey, Integer rowNum) {
		TemplateJdoUtil.removeTemplateRow(templateKey, rowNum);
	}

	@Override
	public void addTemplateRow(String templateKey, String crit, Integer weigh,
			String description) {
		TemplateJdoUtil.addTemplateRow(templateKey, crit, weigh, description);
	}

	@Override
	public void editTemplateRow(String templateKey, Integer rowNum,
			String crit, Integer weigh, String description) {
		TemplateJdoUtil.editTemplateRow(templateKey, rowNum, crit, weigh, description);
		
	}

	@Override
	public Template editTemplate(String aTemplateId, String name,
			List<String> crit, List<Integer> weigh,
			List<String> criteriaDescription, Boolean publicTemplate) {
		// TODO Auto-generated method stub
		return TemplateJdoUtil.editTemplate(aTemplateId, name, crit, weigh, criteriaDescription, publicTemplate);
	}

	@Override
	public Template getTemplateById(String aTemplateId) {
		// TODO Auto-generated method stub
		return TemplateJdoUtil.getTemplateById(aTemplateId);
	}

}
