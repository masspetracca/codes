package com.gannon.TaskEvaluation.server;

import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Transaction;

import com.gannon.TaskEvaluation.shared.InActiveMember;
import com.gannon.TaskEvaluation.shared.LoginInfo;
import com.gannon.TaskEvaluation.shared.Member;

public class GoogleLoginJdoUtil {
	
	public static Transaction begin() {
	      final Transaction tx = PMF.get().getPersistenceManager().currentTransaction();
	      tx.begin();
	      return tx;
	}
	
	public static Member loggedInGoogleAccount( LoginInfo aLoginInfo ) {
		
		Member myMember = null;		
		PersistenceManager pm = PMF.get().getPersistenceManager();
		
		try {			
			
			javax.jdo.Query q = pm.newQuery(Member.class);
			q.setFilter("memberEmail == userEmailAdd");
			q.declareParameters("String userEmailAdd");

			try {
			@SuppressWarnings("unchecked")
			List<Member> results = (List<Member>) q.execute(aLoginInfo.getEmailAddress());
			  
			  if (!results.isEmpty()) {
			    for (Member p : results) {			    	
			    	myMember = pm.detachCopy(p);
			    	break;
			    }
			  }
			  
			  if( myMember == null) {
				  	final Transaction txA = begin();
				  	
				    Member tempMyMember = new Member(aLoginInfo.getFirstName(), "", aLoginInfo.getEmailAddress());
				    tempMyMember.setIsGoogleLogin(true);	
					
					// Check whether any Inactive members are present
					// Add evaluation task for inactive member.
					javax.jdo.Query q1 = pm.newQuery(InActiveMember.class);
					q1.setFilter("email == userEmailAdd");
					q1.declareParameters("String userEmailAdd");
					
					@SuppressWarnings("unchecked")
					List<InActiveMember> results1 = (List<InActiveMember>) q1.execute(aLoginInfo.getEmailAddress());
					if (!results1.isEmpty()) {
						tempMyMember.setEvalTasks(results1.get(0).getEvalTasks());
						// delete the inactive member object, since he is now active.
						pm.deletePersistent(results1.get(0));
					}
					
					pm.makePersistent(tempMyMember);
					txA.commit();
					
					myMember = pm.detachCopy(tempMyMember);
			  }
			  
			} 
			finally {
			  q.closeAll();
			}			

		}
		catch(Exception e){
			
		}
		finally {	
			pm.close();
		}
		
		return myMember;
	}

}
