package com.gannon.TaskEvaluation.server;


public class MyJdoUtil {
	
	/*public static void persistMyObj(Object myObj) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		// Persist new Objects.
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin(); // Start the PM transaction
			pm.makePersistent(myObj);
			tx.commit(); // Commit the PM transaction
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}	
			pm.close();
		}
	}
	
	public static void deleteMyObj(Object myObj) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		// Delete Persistant Objects.
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin(); // Start the PM transaction
			pm.deletePersistent(myObj);
			tx.commit(); // Commit the PM transaction
		} finally {
			if (tx.isActive()) {
				tx.rollback(); // Error occurred so rollback the PM transaction
			}	
			pm.close();
		}
	}*/

}
