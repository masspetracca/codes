package com.gannon.TaskEvaluation.server;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.gannon.TaskEvaluation.client.ContactService;

@SuppressWarnings("serial")
public class ContactServiceImpl extends RemoteServiceServlet implements
ContactService {

	@Override
	public void editContact(String aContactId,
			String aFirstName, String aLastName) {
		ContactJdoUtil.editContact(aContactId, aFirstName, aLastName);		
	}

	@Override
	public void deleteContact(String aMemId, String aContactId) {
		ContactJdoUtil.deleteContact(aMemId, aContactId);		
	}

	@Override
	public Boolean createContact(String aMemId, String aEmail, String aFirstName,
			String aLastName) {
		return ContactJdoUtil.createContact(aMemId, aEmail, aFirstName, aLastName);
	}

}
