package com.gannon.TaskEvaluation.server;

import java.util.List;

import com.gannon.TaskEvaluation.client.MemberService;
import com.gannon.TaskEvaluation.shared.Contact;
import com.gannon.TaskEvaluation.shared.EvaluationTaskDTO;
import com.gannon.TaskEvaluation.shared.Member;
import com.gannon.TaskEvaluation.shared.Task;
import com.gannon.TaskEvaluation.shared.Template;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * The server side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class MemberServiceImpl extends RemoteServiceServlet implements
MemberService {

	@Override
	public Member isMember(String aMemberEmail, String aMemberPwd) {
		return MemberJdoUtil.isMember(aMemberEmail, aMemberPwd);
	}

	@Override
	public String createMember( String afName, String alName, String aMemberEmail,
			String aMemberPassword) {
		return MemberJdoUtil.createMember( afName, alName, aMemberEmail, aMemberPassword);
	}

	@Override
	public void editMemberDetails(String aMemberId,  String afName, String alName) {
		MemberJdoUtil.editMemberDetails(aMemberId, afName, alName);		
	}

	@Override
	public Boolean deleteMember(String aMemberId, String aPassword) {
		return MemberJdoUtil.deleteMember(aMemberId, aPassword);		
	}

	@Override
	public List<Task> getEvaluationTasksForMember(String aMemberId) {
		return MemberJdoUtil.getEvaluationTasksForMember(aMemberId);
	}

	@Override
	public List<Task> getAllAuthoredTasksForMember(String aMemberId) {
		return MemberJdoUtil.getAllAuthoredTasksForMember(aMemberId);
	}

	@Override
	public List<Task> getAllCreatedTasksForMember(String aMemberId) {
		return MemberJdoUtil.getAllCreatedTasksForMember(aMemberId);
	}

	@Override
	public List<Template> getAllTemplatesForMember(String aMemberId) {
		return MemberJdoUtil.getAllTemplatesForMember(aMemberId);
	}

	@Override
	public List<Contact> getAllContactsForMember(String aMemberId) {
		return MemberJdoUtil.getAllContactsForMember(aMemberId);
	}

	@Override
	public List<EvaluationTaskDTO> getAllEvalTasksForMember(String aMemberId) {
		return  MemberJdoUtil.getAllEvalTasksForMember(aMemberId);
	}

	@Override
	public Boolean editMemberPassword(String aMemberId,
			String aCurrentPassword, String aNewPassword) {
		return  MemberJdoUtil.editMemberPassword(aMemberId,
				aCurrentPassword, aNewPassword);
	}

}
