package com.gannon.TaskEvaluation.client;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluation;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluationDTO;

@RemoteServiceRelativePath("evaluation")
public interface EvaluationService extends RemoteService {
	
	List<SingleTaskEvaluation> getEvaluationsOfMyTask(String aTaskId);
	
	SingleTaskEvaluation saveSingleEvaluation(String aTaskId, String aMemberId,
			List<SingleTaskEvaluationDTO> aEvalDTOs);
	
	SingleTaskEvaluation getSingleTaskEvaluation(String aMemberId, String aTaskId);
	
	String sendEmail(String from, List<String> to, String subject, String message);
	
}