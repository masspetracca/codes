package com.gannon.TaskEvaluation.client;

import java.util.List;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.gannon.TaskEvaluation.shared.Contact;
import com.gannon.TaskEvaluation.shared.EvaluationTaskDTO;
import com.gannon.TaskEvaluation.shared.Member;
import com.gannon.TaskEvaluation.shared.Task;
import com.gannon.TaskEvaluation.shared.Template;

public interface MemberServiceAsync {

	void isMember(String aMemberEmail, String aMemberPwd,
			AsyncCallback<Member> callback);

	void createMember( String afName, String alName, String aMemberEmail,
			String aMemberPassword, AsyncCallback<String> callback);

	void editMemberDetails(String aMemberId, String afName, String alName, AsyncCallback<Void> callback);

	void deleteMember(String aMemberId, String aPassword, AsyncCallback<Boolean> callback);

	void getEvaluationTasksForMember(String aMemberId,
			AsyncCallback<List<Task>> callback);

	void getAllAuthoredTasksForMember(String aMemberId,
			AsyncCallback<List<Task>> callback);

	void getAllCreatedTasksForMember(String aMemberId,
			AsyncCallback<List<Task>> callback);

	void getAllTemplatesForMember(String aMemberId,
			AsyncCallback<List<Template>> callback);

	void getAllContactsForMember(String aMemberId,
			AsyncCallback<List<Contact>> callback);

	void getAllEvalTasksForMember(String aMemberId,
			AsyncCallback<List<EvaluationTaskDTO>> callback);

	void editMemberPassword(String aMemberId, String aCurrentPassword,
			String aNewPassword, AsyncCallback<Boolean> callback);

}
