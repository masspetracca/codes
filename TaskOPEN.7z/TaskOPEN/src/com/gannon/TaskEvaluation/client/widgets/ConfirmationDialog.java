package com.gannon.TaskEvaluation.client.widgets;

import com.google.gwt.core.client.Scheduler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PopupPanel;
import com.gannon.TaskEvaluation.client.suggest.PopUpCallBackInterface;

public class ConfirmationDialog extends PopupPanel {

	private final HorizontalPanel lp = new HorizontalPanel();
	private final DockPanel dp = new DockPanel();
	private final FlexTable verticalTable = new FlexTable();
	private Image warningImage = new Image("/images/warning_blue.png");
	private Image errorImage = new Image("/images/warning_red.png");

	private FlexTable flexImage = new FlexTable();	

	public ConfirmationDialog() {
		super();
		this.setStyleName("myPopUpDialog");
		verticalTable.insertRow(0);
		verticalTable.insertRow(1);
		verticalTable.insertRow(2);
		verticalTable.insertRow(3);
		lp.setSize("100%", "100%");
		lp.add(verticalTable);
		dp.add(lp, DockPanel.EAST);
		dp.setSpacing(15);
		setGlassEnabled(true);
		flexImage.insertRow(0);
		dp.add(flexImage, DockPanel.WEST);
		this.add(dp);
	}

	public ConfirmationDialog(Image img) {
		this();
		setImage(img);
	}

	private void setImage(Image img) {
		img.setSize("35px", "35px");
		flexImage.setWidget(0, 0, img);
	}

	private void setMessageHeader(String text) {
		Label lbHeader = new Label();
		lbHeader.setText(text);
		
		lbHeader.getElement().getStyle().setProperty("fontFamily", "arial");
		lbHeader.getElement().getStyle().setProperty("fontSize", "2.5em");
		//DOM.setStyleAttribute(lbHeader.getElement(), "fontFamily", "arial");
		//DOM.setStyleAttribute(lbHeader.getElement(), "fontSize", "2.5em");
		verticalTable.setWidget(0, 0, lbHeader);
	}

	private void setMessage(String text) {
		Label lbMessage = new HTML(text.replace("\n", "<br />"));//new Label();
		
		lbMessage.getElement().getStyle().setProperty("fontFamily", "arial");
		lbMessage.getElement().getStyle().setProperty("fontSize", "1.2em");
		//DOM.setStyleAttribute(lbMessage.getElement(), "fontFamily", "arial");
		//DOM.setStyleAttribute(lbMessage.getElement(), "fontSize", "1.2em");
		verticalTable.setWidget(2, 0, lbMessage);

	}

	/**
	 * Width and Height in CSS units
	 */
	public void setSize(String width, String height) {
		lp.setSize(width, height);
	}

	public void confirmCancel(String messageHeader, String message,
			final PopUpCallBackInterface cb) {

		setMessageHeader(messageHeader);
		setMessage(message);
		setImage(warningImage);
		HorizontalPanel hpButtonPanel = new HorizontalPanel();
		
		final Button conBtn = new Button("Yes");
		final Button cancelBtn = new Button("No");
		
		hpButtonPanel.add(conBtn);
		hpButtonPanel.setSpacing(15);
		hpButtonPanel.add(cancelBtn);

		verticalTable.setWidget(3, 0, hpButtonPanel);
		verticalTable.getFlexCellFormatter().setHorizontalAlignment(3, 0,
				HasHorizontalAlignment.ALIGN_RIGHT);
		conBtn.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				cb.confirmCancel(true);
				hide();
			}
		});

		cancelBtn.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				cb.confirmCancel(false);
				hide();
			}
		});

		center();
		show();
		Scheduler.get().scheduleFinally(new Scheduler.ScheduledCommand() {
			@Override
			public void execute() {
				cancelBtn.setFocus(true);
			}
		});

	}

	public void confirm(String messageHeader, String message, Boolean isError, final PopUpCallBackInterface cb) {
		setMessageHeader(messageHeader);
		setMessage(message);
		if(isError){
			setImage(errorImage);
		}
		else {
			setImage(warningImage);
		}

		HorizontalPanel hpButtonPanel = new HorizontalPanel();
		
		final Button conBtn = new Button("Ok");
		
		hpButtonPanel.add(conBtn);
		hpButtonPanel.setSpacing(15);

		verticalTable.setWidget(3, 0, hpButtonPanel);
		verticalTable.getFlexCellFormatter().setHorizontalAlignment(3, 0,
				HasHorizontalAlignment.ALIGN_RIGHT);
		conBtn.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				cb.confirm();
				hide();
			}
		});

		center();
		show();
		Scheduler.get().scheduleFinally(new Scheduler.ScheduledCommand() {
			@Override
			public void execute() {
				conBtn.setFocus(true);
			}
		});
		
	}
}


