package com.gannon.TaskEvaluation.client.widgets;

import com.google.gwt.cell.client.EditTextCell;
import com.google.gwt.cell.client.ValueUpdater;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.dom.client.KeyCodes;

public class MyEditNumberCell extends EditTextCell{
	

	
	@Override
	public void onBrowserEvent(Context context, Element parent,
            				   String value, NativeEvent event,
                               ValueUpdater<String> valueUpdater) {
		
		super.onBrowserEvent(context, parent, value, event, valueUpdater);
        boolean isEditing = isEditing(context, parent, value);		

        if(isEditing){
            if(event!=null){
            	if( (event.getKeyCode() == KeyCodes.KEY_TAB) || 
            		(event.getKeyCode() != KeyCodes.KEY_BACKSPACE) ){
            		// Allow tabout and backspace
            	}
            	else {
            	
	            	try
	            	{
	            	   Integer.parseInt(value);
	            	}
	            	catch (NumberFormatException nfe)
	            	{
	            		value = "0";
	            		event.preventDefault();
	            	}
            	}
            }
        }
    }

}
