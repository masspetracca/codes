package com.gannon.TaskEvaluation.client.widgets;

/**
 * Initial concept of this widget is based on:
 * http://raibledesigns.com/rd/entry/creating_a_facebook_style_autocomplete
 * 
 * To make this return a DTO that allows you to grab multiple values, see
 * the following tutorials:
 * http://eggsylife.co.uk/2008/08/25/gwt-suggestbox-backed-by-dto-model/
 * http://altuginplainenglish.blogspot.in/2010/06/gwt-suggestbox-filled-with-any-object.html
 *
 */

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.event.dom.client.BlurEvent;
import com.google.gwt.event.dom.client.BlurHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyDownHandler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.SuggestBox;
import com.google.gwt.user.client.ui.SuggestOracle;
import com.google.gwt.user.client.ui.TextBox;
import com.gannon.TaskEvaluation.client.events.AcrossFormEvent;
import com.gannon.TaskEvaluation.client.events.handlers.AcrossFormEventHandler;
import com.gannon.TaskEvaluation.client.suggest.ContactMultiWordSuggestion;
import com.gannon.TaskEvaluation.client.suggest.ContactNameSuggestOracle;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.shared.Contact;

public class InputListWidget extends Composite {
    List<String> itemsSelected = new ArrayList<String>();
    private Image userImg = new Image("/images/user.png");
    private TextBox itemBox = null;
    private BulletList list = null;

    public InputListWidget() {
        FlowPanel panel = new FlowPanel();
        initWidget(panel);
        panel.setStyleName("mySuggestionPanel"); 
        
        list = new BulletList();
        list.setStyleName("token-input-list-facebook");
        
        // Add the contacts icon to the widget.
        userImg.setSize("20px", "20px");
        final ListItem imgItem = new ListItem();
        imgItem.setStyleName("token-input-input-token-facebook");
        imgItem.add(userImg);
        list.add(imgItem);
        
        // Add text box to the widget.
        final ListItem item = new ListItem();
        item.setStyleName("token-input-input-token-facebook");
        itemBox = new TextBox();        
        itemBox.setStyleName("suggestTextBox");
        
        // Add suggest oracle to the textbox
        final ContactNameSuggestOracle oracle = new ContactNameSuggestOracle();
        final SuggestBox box = new SuggestBox(oracle, itemBox);
        box.getElement().setId("suggestion_box");
        item.add(box);
        list.add(item);

        // this needs to be on the itemBox rather than box, or backspace will get executed twice
        itemBox.addKeyDownHandler(new KeyDownHandler() {
            public void onKeyDown(KeyDownEvent event) {
                if ((event.getNativeKeyCode() == KeyCodes.KEY_ENTER) || 
                	(event.getNativeKeyCode() == 32) || //Space
                	(event.getNativeKeyCode() == 59)) {  // Semicolon
                	// Now detect all the email ids....
                	
                    // only allow manual entries with @ signs (assumed email addresses)
                    if ( (itemBox.getValue().contains("@")) &&
                         (itemBox.getValue().contains(".")) ) {	
                    	// Contains atleast one @ and . chars
                        //deselectItem(itemBox, list);
                    	handleTextChangeEvent();
                    }
                    else {
                    	itemBox.setValue("");
                    }
                }
                // handle backspace
                if (event.getNativeKeyCode() == KeyCodes.KEY_BACKSPACE) {
                    if ( ("".equals(itemBox.getValue().trim())) && (itemsSelected.size()>0) ){
                    	try {
	                        ListItem li = (ListItem) list.getWidget(list.getWidgetCount() - 2);
	                        Paragraph p = (Paragraph) li.getWidget(0);
	                        if (itemsSelected.contains(p.getText())) {
	                            itemsSelected.remove(p.getText());
	                            //GWT.log("Removing selected item '" + p.getText() + "'", null);
	                            //GWT.log("Remaining: " + itemsSelected, null);
	                        }
	                        list.remove(li);
	                        itemBox.setFocus(true);
                    	}
                    	catch(Exception e) {
                    		// There are still some exceptions when we use backspace after copy-paste
                    		// Need to debug that.
                    		itemsSelected.clear();
                    		itemBox.setValue("");
                    	}
                    }
                }
            }
        });
        
        // If the itemBox loses focus try to de-select the item.
        itemBox.addBlurHandler(new BlurHandler() {			
			@Override
			public void onBlur(BlurEvent event) {
				if ( (itemBox.getValue().contains("@")) &&
                      (itemBox.getValue().contains(".")) ){
					//deselectItem(itemBox, list);	
					handleTextChangeEvent();
				}
			}
		});

        // Add handler if user selects the suggestion.
        box.addSelectionHandler(new SelectionHandler<SuggestOracle.Suggestion>() {
            public void onSelection(@SuppressWarnings("rawtypes") SelectionEvent selectionEvent) {
                deselectItem(itemBox, list);
            }
        });

        panel.add(list);

        panel.getElement().setAttribute("onclick", "document.getElementById('suggestion_box').focus()");
        box.setFocus(true);
        /* Div structure after a few elements have been added:
            <ul class="token-input-list-facebook">
                <li class="token-input-token-facebook">
                    <p>What's New Scooby-Doo?</p>
                    <span class="token-input-delete-token-facebook">x</span>
                </li>
                <li class="token-input-token-facebook">
                    <p>Fear Factor</p>
                    <span class="token-input-delete-token-facebook">x</span>
                 </li>
                 <li class="token-input-input-token-facebook">
                     <input type="text" style="outline-color: -moz-use-text-color; outline-style: none; outline-width: medium;"/>
                 </li>
            </ul>
         */
        
        // Get all contacts for this member.
        ServerUtility.myMemberRpcService.getAllContactsForMember(NavigationUtility.sessionMemId, new AsyncCallback<List<Contact>>() {			
			@Override
			public void onSuccess(List<Contact> result) {
				for ( Contact con : result )
			    {
					oracle.add(new ContactMultiWordSuggestion(con) );
			    }				
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}
		});
 
        // Handle Reload contacts event from different forms.
        NavigationUtility.EVENT_BUS.addHandler(AcrossFormEvent.TYPE, new AcrossFormEventHandler(){
            public void onEvent(AcrossFormEvent event) {
            	switch (event.getActionType()) {
                case RELOAD_CONTACTS:
                	ServerUtility.myMemberRpcService.getAllContactsForMember(NavigationUtility.sessionMemId, new AsyncCallback<List<Contact>>() {			
            			@Override
            			public void onSuccess(List<Contact> result) {
        					oracle.clear();
            				for ( Contact con : result )
            			    {
            					oracle.add(new ContactMultiWordSuggestion(con) );
            			    }				
            			}
            			
            			@Override
            			public void onFailure(Throwable caught) {
            				// TODO Auto-generated method stub				
            			}
            		});
                	break;
                default:
                	break;
            	}
            }
        });

    } // End constructor
    
    private void handleTextChangeEvent() {
    	// This method handles user key down events for de-selection, de-selection happens based
    	// on user key press character is either semicolon, space, Enter press OR itemBox loses focus.
    	// This method is also written to handle cases were user has copy pasted email-id's and clicked
    	// space or enter.
    	String copyTxt = itemBox.getValue();
   
    	// Check if ; is the separator
    	String[] temp = copyTxt.split(";");    	
    	if( temp.length == 1 ) {
    		// Nope, check if space is the separator
    		temp = copyTxt.split("\\s+");
    	}
    	
    	if(temp.length > 1) {
    		itemBox.setValue("");
    		for(int i=0;i<temp.length;++i){
    			if ( (temp[i].contains("@")) &&
                     (temp[i].contains(".")) ){
	    			itemBox.setValue(temp[i]);
	        		deselectItem(itemBox, list);
    			}
    		}    
    	}
    	else {
    		// No separator so single email id only    		
    		// Get the number @ chars in the pasted string
    		int count = copyTxt.length() - copyTxt.replace("@", "").length();
    		if(count == 1){
    			// Only one
    			deselectItem(itemBox, list);
    		}
    		else{
    			// More than one ..Invalid format ...
    			itemBox.setValue("");
    		}
    	}
    }

    private void deselectItem(final TextBox itemBox, final BulletList list) {
        if (itemBox.getValue() != null && !"".equals(itemBox.getValue().trim())) {
            /** Change to the following structure:
             * <li class="token-input-token-facebook">
             * <p>What's New Scooby-Doo?</p>
             * <span class="token-input-delete-token-facebook">x</span>
             * </li>
             */

            final ListItem displayItem = new ListItem();
            displayItem.setStyleName("token-input-token-facebook");
            Paragraph p = new Paragraph(itemBox.getValue());

            displayItem.addClickHandler(new ClickHandler() {
                public void onClick(ClickEvent clickEvent) {
                    displayItem.addStyleName("token-input-selected-token-facebook");
                }
            });

            /** TODO: Figure out how to select item and allow deleting with backspace key
            displayItem.addKeyDownHandler(new KeyDownHandler() {
                public void onKeyDown(KeyDownEvent event) {
                    if (event.getNativeKeyCode() == KeyCodes.KEY_BACKSPACE) {
                        removeListItem(displayItem, list);
                    }
                }
            });
            displayItem.addBlurHandler(new BlurHandler() {
                public void onBlur(BlurEvent blurEvent) {
                    displayItem.removeStyleName("token-input-selected-token-facebook");
                }
            });
            */

            Span span = new Span("x");
            span.addClickHandler(new ClickHandler() {
                public void onClick(ClickEvent clickEvent) {
                    removeListItem(displayItem, list);
                }
            });

            displayItem.add(p);
            displayItem.add(span);
            // hold the original value of the item selected

            //GWT.log("Adding selected item '" + itemBox.getValue() + "'", null);
            itemsSelected.add(itemBox.getValue().trim());
            //GWT.log("Total: " + itemsSelected, null);

            list.insert(displayItem, list.getWidgetCount() - 1);
            itemBox.setValue("");
            itemBox.setFocus(true);
        }
    }
 
    public void populateItems(List<String> aItems) {
    	for(String item: aItems){
    		itemBox.setValue(item);
    		deselectItem(itemBox, list);
    	}
    }
  
    // Clear the Widget.
    public void clear() {
    	itemsSelected.clear();
    	
    	String tagToRemove;
		int num = list.getWidgetCount();
		for (int i=num-1; i>0; i--) { // Leave the 0th item => Img item
			tagToRemove = ((ListItem)list.getWidget(i)).getText();
			if (list.getWidget(i).getElement().getInnerHTML().contains("<span>x</span>")) {
				itemsSelected.remove(tagToRemove.substring(0, tagToRemove.length()-1));
				list.remove(list.getWidget(i));
			}
		}

    	itemBox.setValue("");
    	itemBox.setFocus(true);    		
    }

    private void removeListItem(ListItem displayItem, BulletList list) {
        //GWT.log("Removing: " + displayItem.getWidget(0).getElement().getInnerHTML(), null);
        itemsSelected.remove(displayItem.getWidget(0).getElement().getInnerHTML());
        list.remove(displayItem);
    }
    
    public List<String> getSelectedItems() {
    	return itemsSelected;
    }
    
}


