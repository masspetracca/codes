package com.gannon.TaskEvaluation.client.widgets;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.OpenEvent;
import com.google.gwt.event.logical.shared.OpenHandler;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.DisclosurePanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gannon.TaskEvaluation.client.events.AcrossFormEvent;
import com.gannon.TaskEvaluation.client.events.PreLoginEvent;
import com.gannon.TaskEvaluation.client.events.handlers.AcrossFormEventHandler;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.PreLoginActions;

public class UserStatus extends VerticalPanel{
	
	Anchor signout = new Anchor("Signout");
	Label lblHeader = null;
	Image arrowImg = new Image("images/ArrowDown.png");
	
	HorizontalPanel h1 = new HorizontalPanel();
	
	public UserStatus() {
		arrowImg.setSize("20px", "20px");
		lblHeader = new Label(NavigationUtility.sessionFirstName+" "+NavigationUtility.sessionLastName);
		signout.setStyleName("myUserStatusSignoutLabel");
		lblHeader.setStyleName("myUserStatusHeaderLabel");

		h1.add(lblHeader);
		h1.add(arrowImg);
		final DisclosurePanel panel = new DisclosurePanel();
		panel.setHeader(h1);
		
		panel.addOpenHandler( new OpenHandler<DisclosurePanel>() {			
			@Override
			public void onOpen(OpenEvent<DisclosurePanel> event) {
				panel.clear();
				panel.add(signout );
				
			}		
		});
		 
		// Handle the User name modified event.
		NavigationUtility.EVENT_BUS.addHandler(AcrossFormEvent.TYPE, new AcrossFormEventHandler(){
		    public void onEvent(AcrossFormEvent event) {
		    	switch (event.getActionType()) {
		        case MEMBER_NAME_CHANGE:
		        	lblHeader.setText(NavigationUtility.sessionFirstName+" "+NavigationUtility.sessionLastName);
		        	break;
		        default:
		        	break;
		    	}
		    }
		});
		 
		signout.addClickHandler( new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				// Clear Session values.
				NavigationUtility.sessionFirstName="";
				NavigationUtility.sessionLastName="";
				NavigationUtility.sessionMemId="";
				NavigationUtility.sessionEmail="";				
				NavigationUtility.isGoogleLogin = false;

				NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.SIGN_OUT));
			}
		});
		
		panel.setWidth("100%");
		this.add(panel);
	}

}
