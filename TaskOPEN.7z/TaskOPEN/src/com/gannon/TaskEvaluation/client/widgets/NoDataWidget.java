package com.gannon.TaskEvaluation.client.widgets;

import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;

// Widget which shows when no data is present in the cell table.
public class NoDataWidget extends VerticalPanel{
	
	private Label noDataLbl = new Label("No Data Available");
	
	public NoDataWidget(String aNoDataText) {
		this.setStyleName("noDataWidget");
		this.setSize("100%", "100%");
		this.setHorizontalAlignment(ALIGN_CENTER);
		noDataLbl.setText(aNoDataText);
		this.add(noDataLbl);
	}
	
	public void setNoDataText(String aNoDataText){
		noDataLbl.setText(aNoDataText);
	}

}
