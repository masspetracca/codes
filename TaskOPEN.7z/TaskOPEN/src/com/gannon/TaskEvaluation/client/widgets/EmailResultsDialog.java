package com.gannon.TaskEvaluation.client.widgets;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.Scheduler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.gannon.TaskEvaluation.client.suggest.EmailCallBackInterface;

public class EmailResultsDialog extends PopupPanel {

	private final HorizontalPanel lp = new HorizontalPanel();
	private final DockPanel dp = new DockPanel();
	private final FlexTable verticalTable = new FlexTable();
	private Image emailImage = new Image("/images/email.png");
	private FlexTable flexImage = new FlexTable();
	
	private Label subLbl = new Label("Subject");
	private TextBox subTxtBx = new TextBox();
	private HorizontalPanel subPnl = new HorizontalPanel();
	
	private Label toLbl = new Label("To: ");
	private InputListWidget toEmails = new InputListWidget();
	private HorizontalPanel toPnl = new HorizontalPanel();

	public EmailResultsDialog() {
		super();
		this.setStyleName("myPopUpDialog");
		verticalTable.insertRow(0);
		verticalTable.insertRow(1);
		verticalTable.insertRow(2);
		verticalTable.insertRow(3);
		lp.setSize("100%", "100%");
		lp.add(verticalTable);
		dp.add(lp, DockPanel.EAST);
		dp.setSpacing(15);
		setGlassEnabled(true);
		flexImage.insertRow(0);
		dp.add(flexImage, DockPanel.WEST);
		this.add(dp);
		
		subPnl.setSpacing(10);
		subPnl.add(subLbl);
		subPnl.add(subTxtBx);
		
		toPnl.setSpacing(10);
		toPnl.add(toLbl);
		toPnl.add(toEmails);
	}

	public EmailResultsDialog(Image img) {
		this();
		setImage(img);
	}

	private void setImage(Image img) {
		img.setSize("35px", "35px");
		flexImage.setWidget(0, 0, img);
	}

	private void setMessageHeader(String text) {
		Label lbHeader = new Label();
		lbHeader.setText(text);
		
		lbHeader.getElement().getStyle().setProperty("fontFamily", "arial");
		lbHeader.getElement().getStyle().setProperty("fontSize", "2.5em");
		//DOM.setStyleAttribute(lbHeader.getElement(), "fontFamily", "arial");
		//DOM.setStyleAttribute(lbHeader.getElement(), "fontSize", "2.5em");
		verticalTable.setWidget(0, 0, lbHeader);
	}

	private void setMessage(String text) {		
		subTxtBx.setValue(text);		
		verticalTable.setWidget(1, 0, subPnl);
	}

	/**
	 * Width and Height in CSS units
	 */
	public void setSize(String width, String height) {
		lp.setSize(width, height);
	}

	public void showEmailDialog( String sub, String aTaskPerformer,
			final EmailCallBackInterface cb) {
		
		List<String> items = new ArrayList<String>();
		items.add(aTaskPerformer);
		toEmails.populateItems(items);
		
		setMessageHeader("Email");
		verticalTable.setWidget(2, 0, toPnl);
		setMessage(sub);
		setImage(emailImage);
		HorizontalPanel hpButtonPanel = new HorizontalPanel();
		
		final Button conBtn = new Button("Send");
		final Button cancelBtn = new Button("Cancel");
		
		hpButtonPanel.add(conBtn);
		hpButtonPanel.setSpacing(15);
		hpButtonPanel.add(cancelBtn);

		verticalTable.setWidget(3, 0, hpButtonPanel);
		verticalTable.getFlexCellFormatter().setHorizontalAlignment(3, 0,
												HasHorizontalAlignment.ALIGN_RIGHT);		
		conBtn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if( toEmails.getSelectedItems().size() > 0 ){
					cb.confirmCancel(true, toEmails.getSelectedItems(), subTxtBx.getValue());
					hide();
				}
			}
		});

		cancelBtn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				cb.confirmCancel(false, null, "");
				hide();
			}
		});

		center();
		show();
		Scheduler.get().scheduleFinally(new Scheduler.ScheduledCommand() {
			@Override
			public void execute() {
				cancelBtn.setFocus(true);
			}
		});

	}

	
}


