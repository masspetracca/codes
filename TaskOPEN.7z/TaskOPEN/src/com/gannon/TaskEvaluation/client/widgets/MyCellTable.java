package com.gannon.TaskEvaluation.client.widgets;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.view.client.ProvidesKey;

public class MyCellTable<T> extends CellTable<T>{
	
	public interface TableRes extends CellTable.Resources {
		@Source({CellTable.Style.DEFAULT_CSS, "../css/CellTable.css"})
		TableStyle cellTableStyle();
		 
		interface TableStyle extends CellTable.Style {}
		}

	private static CellTable.Resources tableRes = GWT.create(TableRes.class);

	//// Constructors with setting the resource file of the base.	
	public MyCellTable()
	{
		// Set the page size to 10 and the style resource.
		super(10, tableRes);
		init();
	}
	
	public MyCellTable(int aPageSize)
	{
		// Set the display length to aDisplayLength and the resource.
		super(aPageSize, tableRes);
		init();
	}
	
	public MyCellTable(int aPageSize, Resources aMyResource)
	{
		// Set the display length to aDisplayLength and the resource.
		super(aPageSize, aMyResource);
		init();
	}
	
	public MyCellTable(int aPageSize, ProvidesKey<T> pk)
	{
		// Set the display length to aDisplayLength and the resource.
		super(aPageSize, tableRes, pk);
		init();
	}
	/////////////////////////////////////////////////////////////////
	
	public void init()
	{
		// Default width is 100%, users can change the width of their cell widgets.
		setWidth("100%");
		//setHeight("80%");
	    //setWidth("auto", true); // this will take the available width
		
		// No need of Key board selection.
		this.setKeyboardSelectionPolicy(KeyboardSelectionPolicy.DISABLED);		
	}
}
