package com.gannon.TaskEvaluation.client.widgets;

import com.google.gwt.user.client.ui.Image;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.user.client.ui.Anchor;
//import com.google.gwt.user.client.DOM;

public class ImageAnchor extends Anchor {
	
	private Image img = new Image();

    public ImageAnchor() {
    }

    public void setResource(ImageResource imageResource) {
    	img.setResource(imageResource);
    	this.getElement().appendChild(img.getElement());
        /*DOM.insertBefore(getElement(), img.getElement(), DOM
                .getFirstChild(getElement()));*/
    }
    
    public void setImg(String url)
    {
    	img.setUrl(url);
    	this.getElement().appendChild(img.getElement());
        /*DOM.insertBefore(getElement(), img.getElement(), DOM
                .getFirstChild(getElement()));*/
    }
    
    public void setStyle(String styleClassName)
    {
    	img.setStyleName("styleClassName");
    }
}
