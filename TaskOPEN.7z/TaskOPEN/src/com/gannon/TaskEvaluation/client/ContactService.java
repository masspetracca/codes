package com.gannon.TaskEvaluation.client;


import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("contact")
public interface ContactService extends RemoteService {
	
	Boolean createContact(String aMemId, String aEmail, String aFirstName, String aLastName);
	
	void editContact(String aContactId, String aFirstName, String aLastName);
	
	void deleteContact(String aMemId, String aContactId);
	
}