package com.gannon.TaskEvaluation.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface ContactServiceAsync {

	void editContact(String aContactId, String aFirstName,
			String aLastName, AsyncCallback<Void> callback);

	void deleteContact(String aMemId, String aContactId,
			AsyncCallback<Void> callback);

	void createContact(String aMemId, String aEmail, String aFirstName,
			String aLastName, AsyncCallback<Boolean> callback);

}
