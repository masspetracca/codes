
package com.gannon.TaskEvaluation.client;

import java.util.Date;
import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.gannon.TaskEvaluation.shared.Task;
import com.gannon.TaskEvaluation.shared.Template;

/**
 * The client side stub for the RPC service.
 */
@RemoteServiceRelativePath("task")
public interface TaskService extends RemoteService {
	
	String createTask(String aTaskCreator, String aTaskName,
			String aTaskDescription, List<String> aTaskAuthors, List<String> aTaskEvaluators,
			Date aCreationDate, Date aCompletionDate, Boolean aPublicTask, String aTemplate );
	
	void editTask(String aTaskId, String aTaskName,
			String aTaskDescription, List<String> aTaskAuthors, List<String> aTaskEvaluators,
			Date aCreationDate, Date aCompletionDate, Boolean aPublicTask, String aTemplate );
	
	void deleteTask(String aTaskId);
	
	List<Task> returnAllPublicTasks();
	
	Template getTemplateForTask(String aTaskId);
	
}
