package com.gannon.TaskEvaluation.client.events;

import com.google.gwt.event.shared.GwtEvent;
import com.gannon.TaskEvaluation.client.events.handlers.PreLoginEventHandler;
import com.gannon.TaskEvaluation.client.utils.PreLoginActions;

// The object of this class will be sent through the event bus when PingEvent is fired
public class PreLoginEvent extends GwtEvent<PreLoginEventHandler>{
 
    public static Type<PreLoginEventHandler> TYPE = new Type<PreLoginEventHandler>();
     
    // This is the only data that we intend to pass right now in the event object
    private PreLoginActions action;
     
    public PreLoginEvent(PreLoginActions aActionType){
        this.action = aActionType;
    }
     
    public PreLoginActions getActionType(){
        return this.action;
    } 
 
    @Override
    public com.google.gwt.event.shared.GwtEvent.Type<PreLoginEventHandler> getAssociatedType() {
        return TYPE;
    }

	@Override
	protected void dispatch(PreLoginEventHandler handler) {
		handler.onEvent(this);		
	}
 
}
