package com.gannon.TaskEvaluation.client.events;

import com.google.gwt.event.shared.GwtEvent;
import com.gannon.TaskEvaluation.client.events.handlers.AcrossFormEventHandler;
import com.gannon.TaskEvaluation.client.utils.AcrossFormActionTypes;

// The object of this class will be sent through the event bus when PingEvent is fired
public class AcrossFormEvent extends GwtEvent<AcrossFormEventHandler>{
 
    public static Type<AcrossFormEventHandler> TYPE = new Type<AcrossFormEventHandler>();
     
    // This is the only data that we intend to pass right now in the event object
    private AcrossFormActionTypes action;
     
    public AcrossFormEvent(AcrossFormActionTypes aActionType){
        this.action = aActionType;
    }
     
    public AcrossFormActionTypes getActionType(){
        return this.action;
    } 
 
    @Override
    public com.google.gwt.event.shared.GwtEvent.Type<AcrossFormEventHandler> getAssociatedType() {
        return TYPE;
    }

	@Override
	protected void dispatch(AcrossFormEventHandler handler) {
		handler.onEvent(this);		
	}
 
}
