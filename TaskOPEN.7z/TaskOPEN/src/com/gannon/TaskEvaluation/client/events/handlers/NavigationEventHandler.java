package com.gannon.TaskEvaluation.client.events.handlers;

import com.google.gwt.event.shared.EventHandler;
import com.gannon.TaskEvaluation.client.events.NavigationEvent;

public interface NavigationEventHandler extends EventHandler {
	    void onEvent(NavigationEvent event);
}
