package com.gannon.TaskEvaluation.client.events;

import com.google.gwt.event.shared.GwtEvent;
import com.gannon.TaskEvaluation.client.events.handlers.NavigationEventHandler;
import com.gannon.TaskEvaluation.client.utils.ActionTypes;
import com.gannon.TaskEvaluation.shared.Task;

// The object of this class will be sent through the event bus when PingEvent is fired
public class NavigationEvent extends GwtEvent<NavigationEventHandler>{
 
    public static Type<NavigationEventHandler> TYPE = new Type<NavigationEventHandler>();
     
    // This is the only data that we intend to pass right now in the event object
    private ActionTypes action;
    
    private Task myTask;
     
    public NavigationEvent(ActionTypes aActionType){
        this.action = aActionType;
    }
     
    public NavigationEvent(ActionTypes aActionType, Task aTask){
        this.action = aActionType;
        this.myTask = aTask;
    }
    
    public ActionTypes getActionType(){
        return this.action;
    } 
    
    public Task getTask(){
        return this.myTask;
    }
 
    @Override
    public com.google.gwt.event.shared.GwtEvent.Type<NavigationEventHandler> getAssociatedType() {
        return TYPE;
    }

	@Override
	protected void dispatch(NavigationEventHandler handler) {
		handler.onEvent(this);		
	}
}
