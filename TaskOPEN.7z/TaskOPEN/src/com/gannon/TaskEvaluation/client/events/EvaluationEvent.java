package com.gannon.TaskEvaluation.client.events;

import com.google.gwt.event.shared.GwtEvent;
import com.gannon.TaskEvaluation.client.events.handlers.EvaluationEventHandler;
import com.gannon.TaskEvaluation.client.utils.EvaluationActionTypes;

// The object of this class will be sent through the event bus when PingEvent is fired
public class EvaluationEvent extends GwtEvent<EvaluationEventHandler>{
 
    public static Type<EvaluationEventHandler> TYPE = new Type<EvaluationEventHandler>();
     
    // This is the only data that we intend to pass right now in the event object
    private EvaluationActionTypes action;
     
    public EvaluationEvent(EvaluationActionTypes aActionType){
        this.action = aActionType;
    }
     
    public EvaluationActionTypes getActionType(){
        return this.action;
    } 
 
    @Override
    public com.google.gwt.event.shared.GwtEvent.Type<EvaluationEventHandler> getAssociatedType() {
        return TYPE;
    }

	@Override
	protected void dispatch(EvaluationEventHandler handler) {
		handler.onEvent(this);		
	}
 
}
