package com.gannon.TaskEvaluation.client.events.handlers;

import com.google.gwt.event.shared.EventHandler;
import com.gannon.TaskEvaluation.client.events.EvaluationEvent;

public interface EvaluationEventHandler extends EventHandler {
	    void onEvent(EvaluationEvent event);
}
