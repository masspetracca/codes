package com.gannon.TaskEvaluation.client.events.handlers;

import com.google.gwt.event.shared.EventHandler;
import com.gannon.TaskEvaluation.client.events.PreLoginEvent;

public interface PreLoginEventHandler extends EventHandler {
	    void onEvent(PreLoginEvent event);
}
