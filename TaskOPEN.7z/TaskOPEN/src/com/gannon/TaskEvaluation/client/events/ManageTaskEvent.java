package com.gannon.TaskEvaluation.client.events;

import com.google.gwt.event.shared.GwtEvent;
import com.gannon.TaskEvaluation.client.events.handlers.ManageTaskEventHandler;
import com.gannon.TaskEvaluation.client.utils.ManageTaskActionTypes;

// The object of this class will be sent through the event bus when PingEvent is fired
public class ManageTaskEvent extends GwtEvent<ManageTaskEventHandler>{
 
    public static Type<ManageTaskEventHandler> TYPE = new Type<ManageTaskEventHandler>();
     
    // This is the only data that we intend to pass right now in the event object
    private ManageTaskActionTypes action;
     
    public ManageTaskEvent(ManageTaskActionTypes aActionType){
        this.action = aActionType;
    }
     
    public ManageTaskActionTypes getActionType(){
        return this.action;
    } 
 
    @Override
    public com.google.gwt.event.shared.GwtEvent.Type<ManageTaskEventHandler> getAssociatedType() {
        return TYPE;
    }

	@Override
	protected void dispatch(ManageTaskEventHandler handler) {
		handler.onEvent(this);		
	}
 
}
