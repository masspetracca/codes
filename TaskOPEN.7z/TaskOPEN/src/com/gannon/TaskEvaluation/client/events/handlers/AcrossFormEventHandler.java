package com.gannon.TaskEvaluation.client.events.handlers;

import com.google.gwt.event.shared.EventHandler;
import com.gannon.TaskEvaluation.client.events.AcrossFormEvent;

public interface AcrossFormEventHandler extends EventHandler {
	    void onEvent(AcrossFormEvent event);
}
