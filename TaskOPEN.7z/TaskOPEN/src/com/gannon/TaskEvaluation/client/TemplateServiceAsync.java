package com.gannon.TaskEvaluation.client;

import java.util.List;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.gannon.TaskEvaluation.shared.Template;

public interface TemplateServiceAsync {

	void returnAllPublicTemplates(AsyncCallback<List<Template>> callback);

	void createTemplate(String name, String aMemberId, List<String> crit,
			List<Integer> weigh, List<String> criteriaDescription,
			Boolean publicTemplate, AsyncCallback<Template> callback);

	void deleteTemplate(String aTemplateId, AsyncCallback<Boolean> callback);

	void removeTemplateRow(String templateKey, Integer rowNum,
			AsyncCallback<Void> callback);

	void addTemplateRow(String templateKey, String crit, Integer weigh,
			String description, AsyncCallback<Void> callback);

	void editTemplateRow(String templateKey, Integer rowNum, String crit,
			Integer weigh, String description, AsyncCallback<Void> callback);

	void editTemplate(String aTemplateId, String name, List<String> crit,
			List<Integer> weigh, List<String> criteriaDescription,
			Boolean publicTemplate, AsyncCallback<Template> callback);

	void getTemplateById(String aTemplateId, AsyncCallback<Template> callback);

}
