package com.gannon.TaskEvaluation.client;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.gannon.TaskEvaluation.shared.Contact;
import com.gannon.TaskEvaluation.shared.EvaluationTaskDTO;
import com.gannon.TaskEvaluation.shared.Member;
import com.gannon.TaskEvaluation.shared.Task;
import com.gannon.TaskEvaluation.shared.Template;

@RemoteServiceRelativePath("member")
public interface MemberService extends RemoteService {
	
	Member isMember(String aMemberEmail, String aMemberPwd);
	
	String createMember( String afName, String alName, String aMemberEmail, String aMemberPassword );
	
	void editMemberDetails(String aMemberId, String afName, String alName);
	
	Boolean editMemberPassword(String aMemberId, String aCurrentPassword, String aNewPassword);
	
	Boolean deleteMember(String aMemberId, String aPassword);
	
	List<Task> getEvaluationTasksForMember(String aMemberId);
	
	List<Task> getAllAuthoredTasksForMember(String aMemberId);
	
	List<Task> getAllCreatedTasksForMember(String aMemberId);
	
	List<Template> getAllTemplatesForMember(String aMemberId);
	
	List<Contact> getAllContactsForMember(String aMemberId);
	
	List<EvaluationTaskDTO> getAllEvalTasksForMember(String aMemberId);
	
}