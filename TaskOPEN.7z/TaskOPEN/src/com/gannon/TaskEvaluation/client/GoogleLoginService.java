package com.gannon.TaskEvaluation.client;

import com.gannon.TaskEvaluation.shared.Member;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("googlelogin")
public interface GoogleLoginService extends RemoteService {
	Member loginDetails(String token);
}
