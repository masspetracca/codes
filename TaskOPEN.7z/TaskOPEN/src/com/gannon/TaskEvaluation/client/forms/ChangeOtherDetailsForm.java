package com.gannon.TaskEvaluation.client.forms;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gannon.TaskEvaluation.client.events.AcrossFormEvent;
import com.gannon.TaskEvaluation.client.suggest.PopUpCallBackInterface;
import com.gannon.TaskEvaluation.client.utils.AcrossFormActionTypes;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.client.widgets.ConfirmationDialog;
import com.gannon.TaskEvaluation.client.widgets.MyTextBox;

public class ChangeOtherDetailsForm  extends VerticalPanel implements PopUpCallBackInterface{
	
	private Label firstNameLbl;
    private Label lastNameLbl;
    private MyTextBox firstNameBox;
    private MyTextBox lastNameBox;
    private Button saveBtn;
    
    FlexTable form = new FlexTable();
	
	public ChangeOtherDetailsForm() {
		firstNameLbl = new Label("FIRST NAME");
	    lastNameLbl = new Label("LAST NAME");
	    firstNameBox = new MyTextBox();
	    firstNameBox.setText(NavigationUtility.sessionFirstName);
	    lastNameBox = new MyTextBox();
	    lastNameBox.setText(NavigationUtility.sessionLastName);
	    
		firstNameLbl.setStyleName("myPreLoginLabel");
	    lastNameLbl.setStyleName("myPreLoginLabel");
	    firstNameBox.setStyleName("myPreLoginTextBox");
	    lastNameBox.setStyleName("myPreLoginTextBox");
	    
	    form.setWidget(0, 0, firstNameLbl);
	    form.setWidget(0, 1, lastNameLbl);
	    form.setWidget(1, 0, firstNameBox);
	    form.setWidget(1, 1, lastNameBox);
	    
	    saveBtn = new Button("Save");
	    
	    form.setWidget(3, 0, saveBtn);

	    this.setWidth("100%");
	    this.add(form);
	    
	    saveBtn.addClickHandler( new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				validateAndSave();
			}
		});
	}
	
	public void validateAndSave() {
		String errorMsgs="";
		
		if( firstNameBox.getText().trim().length() < 2  ) {
			errorMsgs+="First Name should be atleast 2 characters";
			errorMsgs = "<font color='red'>" + errorMsgs + "</font>";
			ConfirmationDialog cnf = new ConfirmationDialog();
			cnf.confirm("Correct the following errors:", errorMsgs, true, this);
			return;			
		}
		
		saveBtn.setEnabled(false);
		ServerUtility.myMemberRpcService.editMemberDetails(NavigationUtility.sessionMemId, firstNameBox.getText(),
				lastNameBox.getText(), new AsyncCallback<Void>() {					
			@Override
			public void onSuccess(Void result) {
				saveBtn.setEnabled(true);
				showEditSuccessDialog();
				NavigationUtility.sessionFirstName = firstNameBox.getText();
				NavigationUtility.sessionLastName = lastNameBox.getText();
				NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.MEMBER_NAME_CHANGE));
			}
			
			@Override
			public void onFailure(Throwable caught) {		
			}
		});
	}
	
	public void showEditSuccessDialog() {
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirm("SUCCESS", "Your Name is successfully changed in the system", false, this);
	}

	@Override
	public void confirmCancel(Boolean aConfirm) {
		firstNameBox.setText(NavigationUtility.sessionFirstName);
		lastNameBox.setText(NavigationUtility.sessionLastName);		
	}

	@Override
	public void confirm() {
		firstNameBox.setText(NavigationUtility.sessionFirstName);
		lastNameBox.setText(NavigationUtility.sessionLastName);			
	}
}
