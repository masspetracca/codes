package com.gannon.TaskEvaluation.client.forms;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.History;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gannon.TaskEvaluation.client.events.PreLoginEvent;
import com.gannon.TaskEvaluation.client.suggest.PopUpCallBackInterface;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.PreLoginActions;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.client.widgets.ConfirmationDialog;
import com.gannon.TaskEvaluation.client.widgets.MyTextBox;

public class DeleteUserForm extends VerticalPanel implements PopUpCallBackInterface{
	
	private Label passwordLbl;
    private MyTextBox passwordBox;;
    private Button deleteBtn;
    
    private FlexTable form = new FlexTable();
	
	public DeleteUserForm(){
		this.setSpacing(30);
		passwordLbl = new Label("ENTER PASSWORD");
		passwordBox = new MyTextBox();
	    
	    passwordLbl.setStyleName("myPreLoginLabel");
	    passwordBox.setStyleName("myPreLoginTextBox");
	    passwordBox.getElement().setAttribute("type", "password");
	    
	    form.setWidget(0, 0, passwordLbl);
	    form.setWidget(1, 0, passwordBox);
	    
	    deleteBtn = new Button("DELETE");
	    
	    form.setWidget(3,0,deleteBtn);

	    this.setWidth("100%");
	    this.add(form);
	    
	    deleteBtn.addClickHandler( new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				validateAndDelete();
			}
		});
	}
	
	public void validateAndDelete() {
		String errorMsgs="";
		
		if(NavigationUtility.isGoogleLogin) {
			// Currently we will allow the google account login to delete
			// without password check.
		}
		else if( passwordBox.getText().trim().length() < 3 ) {
			errorMsgs+="Password should be atleast 3 characters";			
		}
		
		if(!errorMsgs.trim().isEmpty()) {
			errorMsgs = "<font color='red'>" + errorMsgs + "</font>";
			ConfirmationDialog cnf = new ConfirmationDialog();
			cnf.confirm("Correct the following errors:", errorMsgs, true, this);
			return;
		}
		
		deleteBtn.setEnabled(false);
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirmCancel("DELETE confirmation", "Are you sure?", this);		
	}

	public void showDeleteSuccessDialog() {
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirm("Deletion Success", "It was nice working with you", false, this);
	}
	
	public void showFailureDialog() {
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirm("ERROR", "Your Current Password does not match with the system", true, this);
	}
	
	@Override
	public void confirmCancel(Boolean aConfirm) {
		if(aConfirm) {
			ServerUtility.myMemberRpcService.deleteMember(NavigationUtility.sessionMemId,passwordBox.getText().trim(),
												new AsyncCallback<Boolean>() {
				@Override
				public void onFailure(Throwable caught) {
					// TODO Auto-generated method stub
				}

				@Override
				public void onSuccess(Boolean result) {
					deleteBtn.setEnabled(true);
					if(result){
						showDeleteSuccessDialog();
						
						// Clear Session values.
						NavigationUtility.sessionFirstName="";
						NavigationUtility.sessionLastName="";
						NavigationUtility.sessionMemId="";
						NavigationUtility.sessionEmail="";
						History.newItem("");
						
						NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.SIGN_OUT));
					}
					else {
						showFailureDialog();
					}
				}
			});
		}
	}

	@Override
	public void confirm() {
		passwordBox.setText("");		
	}

}
