package com.gannon.TaskEvaluation.client.forms;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
//import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gannon.TaskEvaluation.client.suggest.EmailCallBackInterface;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.client.widgets.EmailResultsDialog;
//import com.task.TaskEvaluationSystem.client.widgets.Print;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluation;
import com.gannon.TaskEvaluation.shared.Task;

public class MyTaskEvaluationsForm extends VerticalPanel  implements EmailCallBackInterface{
	
	Label loadingLbl = new Label("No Evaluations yet...");	
	private VerticalPanel myPnl = new VerticalPanel();
	
	private Button print = new Button("Print");
	private Button emailBtn = new Button("Submit / Email");
	private HorizontalPanel btnPnl = new HorizontalPanel();
	
	private List<SingleTaskEvaluation> steList = new ArrayList<SingleTaskEvaluation>();
	private String taskName = "";
	private String taskPerformer = "";
	
	public MyTaskEvaluationsForm(){
		this.setStyleName("MyTaskEvaluationsForm");
		
		int cwid = Window.getClientWidth()-212; // 200 is the Navigation-Form width.		
		this.setWidth((Integer.toString(cwid)+"px"));
		
		loadingLbl.setWidth("700px");
		myPnl.add(loadingLbl);
		this.add(myPnl);
		
		print.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				//Print.it(myPnl);				
				if(steList.size() > 0){
					buildAndPrintPage();
				}
			}
		});
		
		emailBtn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				showEmailDialog();
			}
		});
		
		btnPnl.setSpacing(20);
		btnPnl.setHorizontalAlignment(ALIGN_RIGHT);
		emailBtn.setWidth("150px");
		btnPnl.add(emailBtn);
		btnPnl.add(print);
	}
	
	public void showEmailDialog() {
		EmailResultsDialog erd = new EmailResultsDialog();
		erd.showEmailDialog(taskName + " results", taskPerformer, this);
	}

	public void populateTask(Task aSelectedTask) {
		taskName = aSelectedTask.getTaskName();
		taskPerformer = aSelectedTask.getTaskAuthors().get(0);
		
		ServerUtility.myEvaluationRpcService.getEvaluationsOfMyTask(aSelectedTask.objectId(), new AsyncCallback<List<SingleTaskEvaluation>>() {
			
			@Override
			public void onSuccess(List<SingleTaskEvaluation> result) {
				steList = result;
				myPnl.clear();
				if(result.size() > 0){
					myPnl.setSpacing(5);
					myPnl.add(btnPnl);
					myPnl.setCellHorizontalAlignment(btnPnl, ALIGN_RIGHT);
					for(SingleTaskEvaluation temp: result){
						
						Label memSubLbl = new Label("Submitted By :"+temp.getMemberEmailId());
						memSubLbl.setStyleName("myTasksFormTaskPerformerLbl");
						myPnl.add(memSubLbl);
						
						SingleEvaluatedTaskForm setf = new SingleEvaluatedTaskForm();
						setf.populateForm(temp);						
						myPnl.add(setf);
					}
				}
				else{
					myPnl.add(loadingLbl);
				}
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}
		});
		
	}
	
	// I have decided to show Print in new page, so not using the open source "Print" class in the widgets
	// Writing full html and showing in the new page, only thing is we need to write one more css file.
	public void buildAndPrintPage(){
	    printHTMLString(buildPrintOrEmailPage());
	}
	
	// Use inline styling for generating the page, since Email doesn't render otherwise.
	public String buildPrintOrEmailPage() {
		SafeHtmlBuilder b = new SafeHtmlBuilder();
		b.appendHtmlConstant("<!DOCTYPE html><html><body>");
		
		b.appendHtmlConstant("<h2 style='font-family:verdana;'>"+taskName+" - Evaluation results !!</h2>");

		int mainCount=0;
	    for (SingleTaskEvaluation ste: steList) {
	    	
	    	b.appendHtmlConstant("<h3 style='font-family:verdana;'>"+String.valueOf(++mainCount)+")</h3>");
	    	
	    	b.appendHtmlConstant("<table style=\"font-family:'Trebuchet MS', Arial, Helvetica, sans-serif; width:100%;"+
	    			             " border-collapse:collapse; border:1px solid; margin-top: 25px; padding-top: 20px;\"> ");
	    	
	    	b.appendHtmlConstant("<tr style=\"border: 1px solid black; font-size:1.1em; text-align:left; padding-top:5px;"+
	    			             " padding-bottom:4px; background-color:#A7C942;color:#ffffff;\" "+
	    			             "><th>Criteria</th><th>Weightage</th><th>Scores</th>"+
		            		     "<th>Comments</th></tr>");
	    	
	    	for(int count=0; count<ste.getCriteria().size(); ++count ){	
	    		
	    		if( count%2 == 0 ) {
	    			b.appendHtmlConstant("<tr style=\"border: 1px solid black; color:#000000; background-color:#EAF2D3; \"> ");
	    		}
	    		else {
	    			b.appendHtmlConstant("<tr style=\"border: 1px solid black; color:#000000; background-color:#ECECEC; \"> ");
	    		}
	    		
		        b.appendHtmlConstant("<td style=\"border: 1px solid black ;\">");
		        b.appendEscaped(ste.getCriteria().get(count));
		        b.appendHtmlConstant("</td>");
	
		        b.appendHtmlConstant("<td style=\"border: 1px solid black ;\">");
		        b.appendEscaped(ste.getWeightages().get(count).toString());
		        b.appendHtmlConstant("</td>");
	
		        b.appendHtmlConstant("<td style=\"border: 1px solid black ;\">");
		        b.appendEscaped(ste.getGradeValues().get(count).toString());
		        b.appendHtmlConstant("</td>");
	
		        b.appendHtmlConstant("<td style=\"border: 1px solid black ;\">");
		        b.appendEscaped(ste.getComments().get(count));
		        b.appendHtmlConstant("</td>");
	
		        b.appendHtmlConstant("</tr>");
	    	}
	    	
		    b.appendHtmlConstant("</table>");
		    //b.appendHtmlConstant("<hr style=\"border-style:inset;\">");
	    }

	    b.appendHtmlConstant("</body></html>");

	   return b.toSafeHtml().asString();
	}
	
	//
	public static native void printHTMLString(String htmlString)/*-{
	    var win = $wnd.open("_blank", "Print", "");
	    win.document.open("text/html", "replace");
	    win.document.write(htmlString);
	    win.document.close();
	    win.focus();
	    win.print();
	}-*/;

	@Override
	public void confirmCancel(Boolean aConfirm, List<String> aToEmails,
			String aSub) {
		if(aConfirm) {
			ServerUtility.myEvaluationRpcService.sendEmail("", aToEmails, aSub, buildPrintOrEmailPage(), new AsyncCallback<String>() {
				@Override
				public void onFailure(Throwable caught) {			
				}

				@Override
				public void onSuccess(String result) {
				}
			});
		}
	}

}
