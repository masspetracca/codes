package com.gannon.TaskEvaluation.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.DeckPanel;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.ResizeComposite;
//import com.gannon.TaskEvaluation.client.forms.ContactsForm;
import com.gannon.TaskEvaluation.client.forms.CreateTaskForm;
//import com.gannon.TaskEvaluation.client.forms.EvaluateForm;
//import com.gannon.TaskEvaluation.client.forms.SettingsForm;
import com.gannon.TaskEvaluation.client.forms.TasksForm;
//import com.gannon.TaskEvaluation.client.forms.TemplateForm;
import com.gannon.TaskEvaluation.client.events.NavigationEvent;
import com.gannon.TaskEvaluation.client.events.handlers.NavigationEventHandler;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;

public class CenterPanel extends ResizeComposite{

	private static CenterPanelUiBinder uiBinder = GWT
			.create(CenterPanelUiBinder.class);

	interface CenterPanelUiBinder extends UiBinder<DockLayoutPanel, CenterPanel> {
	}

	@UiField DeckPanel deck;

	@UiField TasksForm taskForm;  	    // 0
	@UiField CreateTaskForm ctfBody;    // 1
	@UiField ManageTaskForm mtfBody;    // 2
	@UiField ContactsForm conForm;      // 3
	@UiField TemplateForm tempForm;     // 4	
	@UiField EvaluateForm evalForm;     // 5
	@UiField SettingsForm setForm;      // 6
	@UiField FinishedTasksForm finishedTaskForm;    // 7
	@UiField FinishedTasks fTaskForm;    // 8

	public CenterPanel() {
		initWidget(uiBinder.createAndBindUi(this));
		deck.showWidget(0); // We are by default showing Tasks-Form on login and refresh.
		
		NavigationUtility.EVENT_BUS.addHandler(NavigationEvent.TYPE, new NavigationEventHandler(){
            public void onEvent(NavigationEvent event) {
            	switch (event.getActionType()) {
                case TASKS:
                		deck.showWidget(0);
                        break;
                case CREATE_TASK:
                		ctfBody.clearForm();
                		deck.showWidget(1);
                		break;
                case MANAGE_TASK:
                		mtfBody.populateForm(event.getTask());
            			deck.showWidget(2);
            			break;
                case CONTACTS:
                		deck.showWidget(3);
                        break;
                case FINISHED_TASKS:
            		deck.showWidget(7);
                    break;
                case F_TASKS:
                	fTaskForm.populateForm(event.getTask());
            		deck.showWidget(8);
                    break;
                case TEMPLATES:
                		deck.showWidget(4);
                		break;
                case EVALUATION:
                		deck.showWidget(5);
                		break;
                case SETTINGS:
                		deck.showWidget(6);
            			break;
            	}
            }
        });
	}

}
