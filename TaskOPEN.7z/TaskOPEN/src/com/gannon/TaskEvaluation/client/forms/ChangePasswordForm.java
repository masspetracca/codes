package com.gannon.TaskEvaluation.client.forms;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gannon.TaskEvaluation.client.suggest.PopUpCallBackInterface;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.client.widgets.ConfirmationDialog;
import com.gannon.TaskEvaluation.client.widgets.MyTextBox;

public class ChangePasswordForm extends VerticalPanel implements PopUpCallBackInterface{
	
	private Label currentPasswordLbl;
    private MyTextBox currentPasswordBox;
    private Label newPasswordLbl;
    private MyTextBox newPasswordBox;
    private Button saveBtn;
    
    private FlexTable form = new FlexTable();
	
	public ChangePasswordForm(){
		currentPasswordLbl = new Label("ENTER CURRENT PASSWORD");
		newPasswordLbl = new Label("ENTER NEW PASSWORD");
	    currentPasswordBox = new MyTextBox();
	    newPasswordBox = new MyTextBox();
	    
	    currentPasswordLbl.setStyleName("myPreLoginLabel");
	    newPasswordLbl.setStyleName("myPreLoginLabel");
	    currentPasswordBox.setStyleName("myPreLoginTextBox");
	    currentPasswordBox.getElement().setAttribute("type", "password");
	    newPasswordBox.setStyleName("myPreLoginTextBox");
	    newPasswordBox.getElement().setAttribute("type", "password");
	    
	    form.setWidget(0, 0, currentPasswordLbl);
	    form.setWidget(0, 1, newPasswordLbl);
	    form.setWidget(1, 0, currentPasswordBox);
	    form.setWidget(1, 1, newPasswordBox);
	    
	    saveBtn = new Button("Save");
	    
	    form.setWidget(3,0,saveBtn);

	    this.setWidth("100%");
	    this.add(form);
	    
	    saveBtn.addClickHandler( new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				validateAndSave();
			}
		});
	}
	
	public void validateAndSave() {
		String errorMsgs="";
		
		if(NavigationUtility.isGoogleLogin) {
			errorMsgs+="Please use your google account to Login !!!";
		}
		else {
			if( (currentPasswordBox.getText().trim().length() < 3) ||
				(newPasswordBox.getText().trim().length() < 3) ) {
				errorMsgs+="Password should be atleast 3 characters";			
			}
			
			if(currentPasswordBox.getText().trim().equalsIgnoreCase(newPasswordBox.getText().trim())){
				if(!errorMsgs.trim().isEmpty()) {
					errorMsgs+="<br>";
				}
				errorMsgs+="Current and New Passwords should be different";
			}
		}
		
		if(!errorMsgs.trim().isEmpty()) {
			errorMsgs = "<font color='red'>" + errorMsgs + "</font>";
			ConfirmationDialog cnf = new ConfirmationDialog();
			cnf.confirm("Correct the following errors:", errorMsgs, true, this);
			return;
		}
		
		saveBtn.setEnabled(false);
		ServerUtility.myMemberRpcService.editMemberPassword(NavigationUtility.sessionMemId, currentPasswordBox.getText(),
				newPasswordBox.getText(), new AsyncCallback<Boolean>() {					
			@Override
			public void onSuccess(Boolean result) {
				saveBtn.setEnabled(true);
				if( result){
					showEditSuccessDialog();
				}
				else {
					showFailureDialog();
				}				
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}
		});
	}

	public void showEditSuccessDialog() {
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirm("SUCCESS", "Your Password is successfully changed in the system", false, this);
	}
	
	public void showFailureDialog() {
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirm("ERROR", "Your Current Password does not match with the system", true, this);
	}
	
	@Override
	public void confirmCancel(Boolean aConfirm) {
		// Nothing to do		
	}

	@Override
	public void confirm() {
		currentPasswordBox.setText("");
		newPasswordBox.setText("");		
	}

}
