package com.gannon.TaskEvaluation.client.forms;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.cell.client.FieldUpdater;
import com.google.gwt.cell.client.TextInputCell;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.SimplePager;
import com.google.gwt.user.cellview.client.TextColumn;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.AsyncDataProvider;
import com.google.gwt.view.client.HasData;
import com.gannon.TaskEvaluation.client.events.EvaluationEvent;
import com.gannon.TaskEvaluation.client.suggest.PopUpCallBackInterface;
import com.gannon.TaskEvaluation.client.utils.EvaluationActionTypes;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.client.widgets.ConfirmationDialog;
import com.gannon.TaskEvaluation.client.widgets.MyCellTable;
import com.gannon.TaskEvaluation.client.widgets.MyImageButtonCell;
import com.gannon.TaskEvaluation.client.widgets.TextAreaInputCell;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluation;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluationDTO;
import com.gannon.TaskEvaluation.shared.Template;


public class EvaluateTaskForm extends VerticalPanel implements PopUpCallBackInterface{
	
	private MyCellTable<SingleTaskEvaluationDTO> table = new MyCellTable<SingleTaskEvaluationDTO>();
	
	// Create a pager for the celltable to add pagination.
	private SimplePager pager = new SimplePager() {
    	@Override
    	public boolean hasNextPage() {
    		if(this.getPage()<(this.getPageCount()-1)) {
    			return true;
    		}
    		return false;
    	}
    };
	
    private Button submitButton = new Button("Submit");
    private Button cancelButton = new Button("Cancel");
    private HorizontalPanel butHor = new HorizontalPanel();
    
    private Anchor closeLink = new Anchor();
    private Image closeImage = new Image("/images/close.png");
    
    private Label taskNameLbl = new Label("Task Name :");
    private HorizontalPanel hdr2 = new HorizontalPanel();
    
	private Label taskPerformerLbl = new Label("Task Performer : ");
    private Label taskPerformerVal = new Label("");
	private HorizontalPanel hdr3 = new HorizontalPanel();

    // The list of rows in this form
    private List<SingleTaskEvaluationDTO> list = new ArrayList<SingleTaskEvaluationDTO>();
    
    private String myTemplateId="";
    private String myTaskId="";
	
	public EvaluateTaskForm( ) {		
		// Use this to set any additional styles.
		this.setStyleName("myEvaluateTaskForm");	
		
		closeImage.setSize("25px", "25px");
		closeLink.getElement().appendChild(closeImage.getElement());
		closeLink.getElement().getStyle().setProperty("cursor", "pointer");
	
		hdr2.setStyleName("myEvaluteTaskFormHeader2");
		hdr2.setWidth("100%");
		hdr2.setVerticalAlignment(ALIGN_TOP);		
		hdr2.setHorizontalAlignment(ALIGN_LEFT);
		hdr2.add(taskNameLbl);
		hdr2.setHorizontalAlignment(ALIGN_RIGHT);
		hdr2.add(closeLink);		

		this.setWidth("100%");
		this.setVerticalAlignment(ALIGN_TOP);
		
		//this.setHorizontalAlignment(ALIGN_RIGHT);
	    this.add(hdr2);
		
		taskPerformerLbl.setStyleName("myTasksFormTaskPerformerLbl");
		taskPerformerVal.setStyleName("myTasksFormTaskPerformerLbl");
		hdr3.add(taskPerformerLbl);
		hdr3.add(taskPerformerVal);
		this.add(hdr3);
	    
	    // Add a text column to show Criteria.
        TextColumn<SingleTaskEvaluationDTO> criteriaColumn = new TextColumn<SingleTaskEvaluationDTO>() {
           @Override
           public String getValue(SingleTaskEvaluationDTO object) {
              return object.getCriteria();
           }
        };
	    table.addColumn(criteriaColumn, "Criteria");
	    table.setColumnWidth(criteriaColumn, 18.0, Unit.EM);
	    
	    // Add a text column to show the Weightage.
	    TextColumn<SingleTaskEvaluationDTO> weightageColumn = new TextColumn<SingleTaskEvaluationDTO>() {
	    	@Override
	    	public String getValue(SingleTaskEvaluationDTO object) {
	    		return Integer.toString(object.getWieghtage());
	    	}
	    };
	    table.addColumn(weightageColumn, "Weightage");
	    table.setColumnWidth(weightageColumn, 8.0, Unit.EM);
	    
	    //Description popup column
	    final Column<SingleTaskEvaluationDTO, String> descCol = new Column<SingleTaskEvaluationDTO, String>(new MyImageButtonCell()) {
	        @Override
	        public String getValue(SingleTaskEvaluationDTO row) {
	            return "/images/more.png";
	        }
	    };
	    descCol.setFieldUpdater(new FieldUpdater<SingleTaskEvaluationDTO, String>()
	    {
	        @Override
	        public void update(final int index, final SingleTaskEvaluationDTO c, String value) 
	        {
	        	showDescriptionPopUp(c);
	        }
	    });
	    table.addColumn(descCol, " ");
	    table.setColumnWidth(descCol, 3.0, Unit.EM);
	    descCol.setCellStyleNames("myDescriptionImageButtonCell");
	    
	    // Allow user to evaluations.
	    Column<SingleTaskEvaluationDTO, String> evalColumn = new Column<SingleTaskEvaluationDTO, String>(new TextInputCell()) {
			@Override
			public String getValue(SingleTaskEvaluationDTO object) {
				return Double.toString(object.getGradeValue());
			}
	    };
	    evalColumn.setFieldUpdater(new FieldUpdater<SingleTaskEvaluationDTO, String>() {
	    	@Override
	        public void update(final int index, final SingleTaskEvaluationDTO c, String value) 
	        {
	    		try
            	{
            	   list.get(index).setGradeValue(Double.parseDouble(value));
            	}
            	catch (NumberFormatException nfe)
            	{
            		// This is set to fail validation.
            		list.get(index).setGradeValue(-1.0);
            	}
	    		
	        }
	    });
	    table.addColumn(evalColumn, "Scores/10");
	    table.setColumnWidth(evalColumn, 5.0, Unit.EM);
	    
	    // Add a text column to show the Description.
	    Column<SingleTaskEvaluationDTO, String> commentsColumn = new Column<SingleTaskEvaluationDTO, String>(new TextAreaInputCell()) {
			@Override
			public String getValue(SingleTaskEvaluationDTO object) {
				return object.getComment();
			}
	    };
	    commentsColumn.setFieldUpdater(new FieldUpdater<SingleTaskEvaluationDTO, String>() {
	    	@Override
	        public void update(final int index, final SingleTaskEvaluationDTO c, String value) 
	        {
	    		list.get(index).setComment(value);
	        }
	    });	    
	    table.addColumn(commentsColumn, "Comments");
	    table.setColumnWidth(commentsColumn, 30.0, Unit.EM);
  
	    ////// Define Asynchronous Data provider.
	    AsyncDataProvider<SingleTaskEvaluationDTO> provider = new AsyncDataProvider<SingleTaskEvaluationDTO>() {
			@Override
			protected void onRangeChanged(HasData<SingleTaskEvaluationDTO> display) {
		        final int start = display.getVisibleRange().getStart();
			    final int end = start + display.getVisibleRange().getLength();

				int newEnd = end >= list.size() ? list.size() : end;
				List<SingleTaskEvaluationDTO> sub = list.subList(start, newEnd);
		        updateRowCount(list.size(), false);
		        updateRowData(start, sub);		
			}
	    };
	    provider.addDataDisplay(table);
	    table.setRowCount(0, true);//ASH to remove loading indicator.
	    
	    pager = new SimplePager() {
	    	@Override
	    	public boolean hasNextPage() {
	    		if(this.getPage()<(this.getPageCount()-1)) {
	    			return true;
	    		}
	    		return false;
	    	}
	    };
		    
	    // Add table display to pager.
	    pager.setDisplay(table);
	    pager.setStyleName("myPager");
	    
	    pager.setPageSize(5);

	    this.setHorizontalAlignment(ALIGN_LEFT);
	    this.add(table); 		
	    this.setHorizontalAlignment(ALIGN_CENTER);     
	    this.add(pager);
		butHor.add(submitButton);
        butHor.add(cancelButton);
        butHor.setSpacing(30);
        
		this.add(butHor);
		
		closeLink.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				NavigationUtility.EVENT_BUS.fireEvent(new EvaluationEvent(EvaluationActionTypes.EVAL_CLOSE));				
			}
		});
		
		cancelButton.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				NavigationUtility.EVENT_BUS.fireEvent(new EvaluationEvent(EvaluationActionTypes.EVAL_CANCEL));				
			}
		});
		
		submitButton.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				submitEvaluation();				
			}
		});
	}
	
	protected void showDescriptionPopUp(SingleTaskEvaluationDTO c) {
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirm("Description", c.getDescription(), false, this);		
	}

	public void populateForm(String aTemplateId, String aTaskId, String aTaskName, String aTaskPerformer){
		myTemplateId=aTemplateId;
	    myTaskId=aTaskId;
	    taskNameLbl.setText("Task Name : "+aTaskName);
	    taskPerformerVal.setText(aTaskPerformer);
		
		ServerUtility.myTemplateRpcService.getTemplateById(myTemplateId, new AsyncCallback<Template>() {			
			@Override
			public void onSuccess(Template result) {
				list = SingleTaskEvaluationDTO.getSingleEvalDTOsForTemplate(result);
				table.setVisibleRangeAndClearData(table.getVisibleRange(), true);				
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}
		});
		
	}
	
	public void submitEvaluation(){
		String errorMsgs="";
    	
    	for(SingleTaskEvaluationDTO temp : list) {
    		if((temp.getGradeValue() < 0) || (temp.getGradeValue() > 10)){ 
    			errorMsgs+="Grade value should be between 0 to 10";
    			break;
    		}
    	}
    	
    	if(!errorMsgs.trim().isEmpty()){
    		ConfirmationDialog cnf = new ConfirmationDialog();
			cnf.confirm("Error", errorMsgs, true, this);
    	}
    	else{    	
			ConfirmationDialog cnf = new ConfirmationDialog();
			cnf.confirmCancel("Submit Confirmation", "Are you sure to submit this?", this);
    	}
	}

	@Override
	public void confirmCancel(Boolean aConfirm) {
		if(aConfirm){
			ServerUtility.myEvaluationRpcService.saveSingleEvaluation(myTaskId, NavigationUtility.sessionMemId, list, new AsyncCallback<SingleTaskEvaluation>() {				
				@Override
				public void onFailure(Throwable caught) {
					// TODO Auto-generated method stub					
				}
		
				@Override
				public void onSuccess(SingleTaskEvaluation result) {
					NavigationUtility.EVENT_BUS.fireEvent(new EvaluationEvent(EvaluationActionTypes.EVAL_SUBMIT));						
				}
			});
		}		
	}

	@Override
	public void confirm() {
		// Nothing to do.		
	}


}
