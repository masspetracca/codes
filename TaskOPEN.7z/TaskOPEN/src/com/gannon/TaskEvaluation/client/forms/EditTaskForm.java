package com.gannon.TaskEvaluation.client.forms;

import com.gannon.TaskEvaluation.client.suggest.PopUpCallBackInterface;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.ResizeComposite;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.datepicker.client.DatePicker;
import com.gannon.TaskEvaluation.client.events.AcrossFormEvent;
import com.gannon.TaskEvaluation.client.events.ManageTaskEvent;
import com.gannon.TaskEvaluation.client.events.NavigationEvent;
import com.gannon.TaskEvaluation.client.utils.AcrossFormActionTypes;
import com.gannon.TaskEvaluation.client.utils.ActionTypes;
import com.gannon.TaskEvaluation.client.utils.ManageTaskActionTypes;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.client.widgets.ConfirmationDialog;
import com.gannon.TaskEvaluation.client.widgets.InputListWidget;
import com.gannon.TaskEvaluation.shared.Task;
import com.gannon.TaskEvaluation.shared.Template;

public class EditTaskForm extends ResizeComposite implements PopUpCallBackInterface {

	private static EditTaskFormUiBinder uiBinder = GWT
			.create(EditTaskFormUiBinder.class);

	interface EditTaskFormUiBinder extends UiBinder<DockLayoutPanel, EditTaskForm> {
	}
	
	@UiField FlexTable myFlexTbl;
	
	
	private Label taskPerformerLbl = new Label("Task Performer");
	private Label taskPerformerVal = new Label("");

	private Label taskNameLbl = new Label("Task Name:");
	private TextBox taskNameBox = new TextBox();
	
	private Label taskDescLbl = new Label("Task Description:");
	private TextArea taskDescArea = new TextArea();
	
	//private Label taskAuthorsLbl = new Label("Authors:");
	//private InputListWidget taskAuthorsBox = new InputListWidget();
	
	private Label taskEvaluatorsLbl = new Label("Assign to:");
	private InputListWidget taskEvaluatorsBox = new InputListWidget();
	
	private Label taskCompletionDateLbl = new Label("Completion Date and Time:");
	private DatePicker taskDateTime = new DatePicker();
	private Label emptyTimeLbl = new Label("");
	private HorizontalPanel timeDateHor = new HorizontalPanel();

	
	private Label chooseTemplateLbl = new Label("Choose Template:");
	private ListBox templateList = new ListBox();
	
    private Button saveButton = new Button("Save");
    private Button cancelButton = new Button("Cancel");
    private HorizontalPanel butHor = new HorizontalPanel();

    private Anchor deleteLink = new Anchor();
    private Image deleteImage = new Image("/images/trash.png");

    // The selected task in the TasksForm
    private Task selectedTask = null;

	public EditTaskForm() {
		initWidget(uiBinder.createAndBindUi(this));

		int cwid = Window.getClientWidth()-230; // 200 is the Navigation-Form width.		
		this.setWidth((Integer.toString(cwid)+"px"));
		this.setHeight("1000px");	
			
		deleteLink.getElement().appendChild(deleteImage.getElement());
		deleteLink.setTitle("Delete this Task");
		deleteLink.getElement().getStyle().setProperty("cursor", "pointer");
		myFlexTbl.setWidget(0, 2, deleteLink);
	    
		taskPerformerLbl.setStyleName("myTasksFormTaskPerformerLbl");
		taskPerformerVal.setStyleName("myTasksFormTaskPerformerLbl");
		myFlexTbl.setWidget(1, 0, taskPerformerLbl);
		myFlexTbl.setWidget(1, 1, taskPerformerVal);
		myFlexTbl.setWidget(2, 0, taskNameLbl);
		myFlexTbl.setWidget(2, 1, taskNameBox);
		//this.setWidget(1, 0, taskAuthorsLbl);
		//this.setWidget(1, 1, taskAuthorsBox);
		myFlexTbl.setWidget(3, 0, taskDescLbl);
		myFlexTbl.setWidget(3, 1, taskDescArea);
		
		myFlexTbl.setWidget(4, 0, taskEvaluatorsLbl);
		myFlexTbl.setWidget(4, 1, taskEvaluatorsBox);
		myFlexTbl.setWidget(5, 0, taskCompletionDateLbl);
		
		timeDateHor.add(taskDateTime);
		timeDateHor.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
		// This is done to add a 30px gap between datepicker and timepicker, we could have done it
		// with margin-left in css, but unnecessary style class added.
		emptyTimeLbl.setWidth("30px");		
		timeDateHor.add(emptyTimeLbl);
		myFlexTbl.setWidget(5, 1, timeDateHor);
		
		myFlexTbl.setWidget(6, 0, chooseTemplateLbl);
		myFlexTbl.setWidget(6, 1, templateList);
		
		butHor.add(saveButton);
        butHor.add(cancelButton);
        butHor.setSpacing(30);
        
        myFlexTbl.setWidget(8, 1, butHor);
		
		templateList.clear();
		templateList.addItem("Select a Template");
		for(Template temp: TasksForm.myTemplates){
			templateList.addItem(temp.getTemplateName(), temp.objectId());
		}		
		
		deleteLink.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				deleteClicked();						
			}
		});
		
		cancelButton.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				clearForm();
				NavigationUtility.EVENT_BUS.fireEvent(new ManageTaskEvent(ManageTaskActionTypes.CANCEL));
				NavigationUtility.EVENT_BUS.fireEvent(new NavigationEvent(ActionTypes.TASKS));	// Show Tasks-Form.
			}
		});
		
		saveButton.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				validateAndSubmit();				
			}
		});
	}





    public void populateTask(Task aTask) {
		taskNameBox.setText(aTask.getTaskName());
		taskDescArea.setText(aTask.getTaskDescription());
		taskEvaluatorsBox.clear();
		taskEvaluatorsBox.populateItems(aTask.getTaskEvaluators());
		
		String templateId  = aTask.getMyTemplate();

		int indexToFind = 0; // ASH later change it to -1
		for (int i=1; i<templateList.getItemCount(); i++) {
		    if (templateList.getValue(i).equals(templateId)) {
		        indexToFind = i;
		        break;
		    }
		}
		templateList.setItemSelected(indexToFind, true);
		
		if(!aTask.isTemplateEditable()){
			templateList.setEnabled(false);
		}
		else {
			templateList.setEnabled(true);
		}
		
		if( aTask.areAllEvaluationsComplete() ){
			saveButton.setEnabled(false);
			cancelButton.setText("Close");
		}
		else{
			saveButton.setEnabled(true);
			cancelButton.setText("Cancel");
		}
		
		taskDateTime.setValue(aTask.getCompletionDate());
		
		if( aTask.getTaskAuthors().size() > 0) {
			taskPerformerVal.setText(aTask.getTaskAuthors().get(0));
		}
		
		selectedTask = aTask;
	}
	
	public void clearForm() {
		taskNameBox.setText("");
		taskDescArea.setText("");
		taskEvaluatorsBox.clear();
		//publicTaskCheck.setValue(false);
		templateList.setItemSelected(0, false);
		taskDateTime.setValue(new Date());
	}
	
	public void populateTemplates() {
		templateList.clear();
		templateList.addItem("Select a Template");
		for(Template temp: TasksForm.myTemplates){
			templateList.addItem(temp.getTemplateName(), temp.objectId());
		}
	}
	
	public void validateAndSubmit(){
		String errorMsgs="";
		
		String taskName = taskNameBox.getText();
		if(taskName.trim().isEmpty()){
			errorMsgs+="Task Name, cannot be empty";
		}
		
		String taskDescription = taskDescArea.getText();
		if(taskDescription.trim().isEmpty()){
			if(!errorMsgs.isEmpty()){
				errorMsgs+="<br>";
			}
			errorMsgs+="Task Description, cannot be empty";
		}
		
		boolean isPublicTask = false;//publicTaskCheck.getValue();
		
		// Eliminate duplicates from eval emails.
		List<String> taskEvaluators = taskEvaluatorsBox.getSelectedItems();
		Set<String> set = new HashSet<String>();
		set.addAll(taskEvaluators);
		taskEvaluators.clear();
		taskEvaluators.addAll(set);
		if( (taskEvaluators.size() == 0) ){
			if(!errorMsgs.isEmpty()){
				errorMsgs+="<br>";
			}
			errorMsgs+="Task Evaluators, cannot be empty";
		}
		else if(taskEvaluators.contains(NavigationUtility.sessionEmail)) {
			if(!errorMsgs.isEmpty()){
				errorMsgs+="<br>";
			}
			errorMsgs+="Task Evaluator, cannot be member who created the task";
		}

		// If user doesn't submit a Date, take today's date.
		Date creationDate = new Date();
		Date completionDate;
		if( (taskDateTime.getValue() == null) || 
			(creationDate.after(taskDateTime.getValue())) ) {
			completionDate = new Date();
		}
		else {
			completionDate = taskDateTime.getValue();
		}
		
		int templateIndex = templateList.getSelectedIndex();
		String template= "";
		if(templateIndex > 0) {
			template = templateList.getValue(templateIndex);
		}
		else{
			if(!errorMsgs.isEmpty()){
				errorMsgs+="<br>";
			}
			errorMsgs+="Please select a Template";
		}		
		
		List<String> taskAuthors =  new ArrayList<String>();
		
		if(!errorMsgs.trim().isEmpty()){
			errorMsgs = "<font color='red'>" + errorMsgs + "</font>";
			ConfirmationDialog cnf = new ConfirmationDialog();
			cnf.confirm("Correct the following Errors", errorMsgs, true, this);
			return;
		}
		
		// All Validations have passed, call server.
		ServerUtility.myTaskRpcService.editTask(selectedTask.objectId(), taskName, taskDescription,
				taskAuthors, taskEvaluators, creationDate, completionDate, isPublicTask,
				template, new AsyncCallback<Void>() {					
			@Override
			public void onSuccess(Void result) {
				clearForm();
				NavigationUtility.EVENT_BUS.fireEvent(new ManageTaskEvent(ManageTaskActionTypes.SAVE));	
				NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.RELOAD_CONTACTS));
				NavigationUtility.EVENT_BUS.fireEvent(new NavigationEvent(ActionTypes.TASKS));	// Show Tasks-Form.
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub							
			}
		});
	}
	
	public void deleteClicked(){
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirmCancel("Delete Confirmation", "Are are sure?", this);
	}

	@Override
	public void confirmCancel(Boolean aConfirm) {
		if(aConfirm){
			ServerUtility.myTaskRpcService.deleteTask(selectedTask.objectId(), new AsyncCallback<Void>() {
				@Override
				public void onSuccess(Void result) {
					clearForm();
					NavigationUtility.EVENT_BUS.fireEvent(new ManageTaskEvent(ManageTaskActionTypes.DELETE));	
					NavigationUtility.EVENT_BUS.fireEvent(new NavigationEvent(ActionTypes.TASKS));	// Show Tasks-Form.
				}
				
				@Override
				public void onFailure(Throwable caught) {
					// TODO Auto-generated method stub						
				}					
			});
		}		
	}

	@Override
	public void confirm() {
		// Nothing to do.		
	}

}

