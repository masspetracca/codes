package com.gannon.TaskEvaluation.client.forms;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.datepicker.client.DatePicker;
import com.gannon.TaskEvaluation.client.events.AcrossFormEvent;
import com.gannon.TaskEvaluation.client.events.ManageTaskEvent;
import com.gannon.TaskEvaluation.client.events.NavigationEvent;
import com.gannon.TaskEvaluation.client.events.handlers.AcrossFormEventHandler;
import com.gannon.TaskEvaluation.client.forms.TasksForm;
import com.gannon.TaskEvaluation.client.suggest.PopUpCallBackInterface;
import com.gannon.TaskEvaluation.client.utils.AcrossFormActionTypes;
import com.gannon.TaskEvaluation.client.utils.ActionTypes;
import com.gannon.TaskEvaluation.client.utils.ManageTaskActionTypes;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.client.widgets.ConfirmationDialog;
import com.gannon.TaskEvaluation.client.widgets.InputListWidget;
import com.gannon.TaskEvaluation.shared.Template;

public class CreateTaskForm extends ResizeComposite implements PopUpCallBackInterface {

	private static CreateTaskFormUiBinder uiBinder = GWT
			.create(CreateTaskFormUiBinder.class);

	interface CreateTaskFormUiBinder extends UiBinder<DockLayoutPanel, CreateTaskForm> {
	}

	private Label createTaskLbl = new Label("Create a Task");
	
	private Label taskPerformerLbl = new Label("Task Performer");
	private Label taskPerformerVal = new Label("");

	private Label taskNameLbl = new Label("Task Name:");
	private TextBox taskNameBox = new TextBox();
	
	private Label taskDescLbl = new Label("Task Description:");
	private TextArea taskDescArea = new TextArea();
	
	private Label taskEvaluatorsLbl = new Label("Evaluator:");
	private InputListWidget taskEvaluatorsBox = new InputListWidget();
	
	private Label performerLbl = new Label("Performer:");
	private InputListWidget performerBox = new InputListWidget();
	
	private Label taskCompletionDateLbl = new Label("Completion Date and Time:");
	private DatePicker taskDateTime = new DatePicker();
	private Label emptyTimeLbl = new Label("");
	private HorizontalPanel timeDateHor = new HorizontalPanel();
	
	private Label chooseTemplateLbl = new Label("Choose Template:");
	private ListBox templateList = new ListBox();
	
    private Button createButton = new Button("Publish");
    private Button cancelButton = new Button("Cancel");
    private HorizontalPanel butHor = new HorizontalPanel();
    
    @UiField FlexTable myFlexTbl;
	
	public CreateTaskForm() {		
		
		initWidget(uiBinder.createAndBindUi(this));
		
		createTaskLbl.setStyleName("myTasksFormCreateTaskLbl");
		
		taskPerformerVal.setText(TasksForm.taskPerformer);

		myFlexTbl.setWidget(0, 0, createTaskLbl);
		
		//taskPerformerLbl.getElement().getStyle().setProperty("padding-bottom", "5px");
		taskPerformerLbl.setStyleName("myTasksFormTaskPerformerLbl");
		taskPerformerVal.setStyleName("myTasksFormTaskPerformerLbl");
		myFlexTbl.setWidget(1, 0, taskPerformerLbl);
		myFlexTbl.setWidget(1, 1, taskPerformerVal);
		myFlexTbl.setWidget(2, 0, taskNameLbl);
		myFlexTbl.setWidget(2, 1, taskNameBox);
		myFlexTbl.setWidget(3, 0, taskDescLbl);
		myFlexTbl.setWidget(3, 1, taskDescArea);
		
		myFlexTbl.setWidget(4, 0, taskEvaluatorsLbl);
		myFlexTbl.setWidget(4, 1, taskEvaluatorsBox);
		
		myFlexTbl.setWidget(5, 0, performerLbl);
		myFlexTbl.setWidget(5, 1, performerBox);
		
		
		myFlexTbl.setWidget(6, 0, taskCompletionDateLbl);
		
		timeDateHor.add(taskDateTime);
		timeDateHor.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
		// This is done to add a 30px gap between datepicker and timepicker, we could have done it
		// with margin-left in css, but unnecessary style class added.
		emptyTimeLbl.setWidth("30px");		
		timeDateHor.add(emptyTimeLbl);
		myFlexTbl.setWidget(6, 1, timeDateHor);

		myFlexTbl.setWidget(7, 0, chooseTemplateLbl);
		templateList.setWidth("150px");
		myFlexTbl.setWidget(7, 1, templateList);
		
		butHor.add(createButton);
        butHor.add(cancelButton);
        butHor.setSpacing(30);
        
        myFlexTbl.setWidget(8, 1, butHor);
		
		templateList.clear();
		templateList.addItem("Select a Template");
		for(Template temp: TasksForm.myTemplates){
			templateList.addItem(temp.getTemplateName(), temp.objectId());
		}
		
		cancelButton.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				clearForm();
				NavigationUtility.EVENT_BUS.fireEvent(new NavigationEvent(ActionTypes.TASKS));	// Show Tasks-Form. 			
			}
		});
		
		createButton.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				validateAndSubmit();				
			}
		});
		
		NavigationUtility.EVENT_BUS.addHandler(AcrossFormEvent.TYPE, new AcrossFormEventHandler(){
            public void onEvent(AcrossFormEvent event) {
            	switch (event.getActionType()) {
                case TEMPLATES_MODIFIED_TASKFORM:
                	populateTemplates();
                	break;
                default:
                	break;
            	}
            }
        });

	}
	
	public void clearForm() {
		taskNameBox.setText("");
		taskDescArea.setText("");
		taskEvaluatorsBox.clear();
		performerBox.clear();
		taskDateTime.setValue(new Date());
		
		templateList.clear();
		templateList.addItem("Select a Template");
		for(Template temp: TasksForm.myTemplates){
			templateList.addItem(temp.getTemplateName(), temp.objectId());
		}
		templateList.setItemSelected(0, false);
		
		taskPerformerVal.setText(TasksForm.taskPerformer);
	}
	
	public void populateTemplates() {
		templateList.clear();
		templateList.addItem("Select a Template");
		for(Template temp: TasksForm.myTemplates){
			templateList.addItem(temp.getTemplateName(), temp.objectId());
		}
	}
	
	public void validateAndSubmit(){
		String errorMsgs="";

		String taskCreator = NavigationUtility.sessionMemId;
		
		String taskName = taskNameBox.getText();
		if(taskName.trim().isEmpty()){
			errorMsgs+="Task Name, cannot be empty";
		}
		
		String taskDescription = taskDescArea.getText();
		if(taskDescription.trim().isEmpty()){
			if(!errorMsgs.isEmpty()){
				errorMsgs+="<br>";
			}
			errorMsgs+="Task Description, cannot be empty";
		}
		
		
		
		// Eliminate duplicates from eval emails.
		List<String> taskEvaluators = taskEvaluatorsBox.getSelectedItems();
		Set<String> set = new HashSet<String>();
		set.addAll(taskEvaluators);
		taskEvaluators.clear();
		taskEvaluators.addAll(set);
		if( (taskEvaluators.size() == 0)){
			if(!errorMsgs.isEmpty()){
				errorMsgs+="<br>";
			}
			errorMsgs+="Task Evaluators, cannot be empty";			
		}	
		else if(taskEvaluators.contains(NavigationUtility.sessionEmail)) {
			if(!errorMsgs.isEmpty()){
				errorMsgs+="<br>";
			}
			errorMsgs+="Task Evaluator, cannot be member who created the task";
		}
		
		
		// Eliminate duplicates from eval emails.
		List<String> performers = performerBox.getSelectedItems();
		Set<String> set2 = new HashSet<String>();
		set2.addAll(performers);
		performers.clear();
		performers.addAll(set2);
		if( (performers.size() == 0)){
			if(!errorMsgs.isEmpty()){
				errorMsgs+="<br>";
			}
			errorMsgs+="performers, cannot be empty";			
		}	
		else if(performers.contains(NavigationUtility.sessionEmail)) {
			if(!errorMsgs.isEmpty()){
				errorMsgs+="<br>";
			}
			errorMsgs+="Performers, cannot be member who created the task";
		}
		
		

		// If user doesn't submit a Date, take today's date.
		Date creationDate = new Date();
		Date completionDate;
		if( (taskDateTime.getValue() == null) || 
			(creationDate.after(taskDateTime.getValue())) ) {
			completionDate = new Date();
		}
		else {
			completionDate = taskDateTime.getValue();
		}
		
		int templateIndex = templateList.getSelectedIndex();
		String template= "";
		if(templateIndex > 0) {
			template = templateList.getValue(templateIndex);
		}
		else{
			if(!errorMsgs.isEmpty()){
				errorMsgs+="<br>";
			}
			errorMsgs+="Please select a Template";
		}		
		
		List<String> taskAuthors =  new ArrayList<String>();
		taskAuthors.add(TasksForm.taskPerformer);
		
		if(!errorMsgs.trim().isEmpty()){
			// Validation Failed !!!
			errorMsgs = "<font color='red'>" + errorMsgs + "</font>";
			ConfirmationDialog cnf = new ConfirmationDialog();
			cnf.confirm("Correct the following Errors", errorMsgs, true, this);
			return;
		}

		// Validation passed, call server to create the task.
		ServerUtility.myTaskRpcService.createTask(taskCreator, taskName, taskDescription,
				taskAuthors, taskEvaluators, creationDate, completionDate, false,
				template,
				new AsyncCallback<String>() {
				
			@Override
			public void onSuccess(String result) {
				clearForm();
				NavigationUtility.EVENT_BUS.fireEvent(new ManageTaskEvent(ManageTaskActionTypes.CREATE_SAVE));
				NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.RELOAD_CONTACTS));
				NavigationUtility.EVENT_BUS.fireEvent(new NavigationEvent(ActionTypes.TASKS));	// Show Tasks-Form.
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}
		});
	}

	@Override
	public void confirmCancel(Boolean aConfirm) {
		// Nothing to do.		
	}

	@Override
	public void confirm() {
		// Nothing to do.		
	}

}
