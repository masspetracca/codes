package com.gannon.TaskEvaluation.client.forms;

import java.util.List;

import com.google.gwt.cell.client.EditTextCell;
import com.google.gwt.cell.client.FieldUpdater;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.SimplePager;
import com.google.gwt.user.cellview.client.TextColumn;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.AsyncDataProvider;
import com.google.gwt.view.client.HasData;
import com.gannon.TaskEvaluation.client.events.AcrossFormEvent;
import com.gannon.TaskEvaluation.client.events.handlers.AcrossFormEventHandler;
import com.gannon.TaskEvaluation.client.suggest.PopUpCallBackInterface;
import com.gannon.TaskEvaluation.client.utils.AcrossFormActionTypes;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.client.widgets.ConfirmationDialog;
import com.gannon.TaskEvaluation.client.widgets.MyCellTable;
import com.gannon.TaskEvaluation.client.widgets.MyImageButtonCell;
import com.gannon.TaskEvaluation.client.widgets.NoDataWidget;
import com.gannon.TaskEvaluation.shared.Contact;

public class ContactsForm extends ResizeComposite implements PopUpCallBackInterface {

	private static ContactsFormUiBinder uiBinder = GWT
			.create(ContactsFormUiBinder.class);

	interface ContactsFormUiBinder extends UiBinder<DockLayoutPanel, ContactsForm> {
	}
	
	private Label emailLbl = new Label("Enter Email ID");
	private TextBox emailBox = new TextBox();
	private Label emptySelectLbl = new Label("");
	private Button addContact = new Button("Add New Contact");
	private HorizontalPanel acHor = new HorizontalPanel();
	
	// Create a Celltable.
	private MyCellTable<Contact> table = new MyCellTable<Contact>();
	
	// Create a pager for the celltable to add pagination.
	private SimplePager pager = null;//new SimplePager();
	
	// Widget which shows when no data is present in the cell table.
	NoDataWidget ndw = new NoDataWidget("No Contacts found, Create a new Contact");

	@UiField FlexTable ftable;
	private VerticalPanel myPnl = new VerticalPanel();

	public ContactsForm() {
		initWidget(uiBinder.createAndBindUi(this));
		
		// Use this to set any additional styles.
		//this.setStyleName("myCreateTemplatePanel");

		// All the widgets must be to the top of the page.
		myPnl.setVerticalAlignment(HasVerticalAlignment.ALIGN_TOP);
	
		acHor.setStyleName("myCreateTemplateHeaderPanel");
		acHor.add(emailLbl);
		emailBox.setWidth("150px");
		acHor.add(emailBox);
		emptySelectLbl.setWidth("30px");
		acHor.add(emptySelectLbl);
		addContact.setWidth("150px");
		acHor.add(addContact);
		myPnl.add(acHor);
		
		// Add Criteria column.
		Column<Contact, String> fNameColumn = new Column<Contact, String>(new EditTextCell()) {
				@Override
				public String getValue(Contact object) {
					return object.getFirstName();
				}
		};
		fNameColumn.setFieldUpdater(new FieldUpdater<Contact, String>() {
			 @Override
		        public void update(final int index, final Contact c, String value) 
		        {
				 	if(!value.trim().isEmpty()) {
					 	ServerUtility.myContactRpcService.editContact(c.objectId(), value, c.getLastName(), new AsyncCallback<Void>() {
	
							@Override
							public void onFailure(Throwable caught) {
								// TODO Auto-generated method stub								
							}
	
							@Override
							public void onSuccess(Void result) {
								NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.RELOAD_CONTACTS));	
								table.setVisibleRangeAndClearData(table.getVisibleRange(), true);							
							}
						});
				 	}
				 	else {
				 		table.setVisibleRangeAndClearData(table.getVisibleRange(), true);
				 		showFirstEmptyDialog();
				 	}
		        }
		});
	    table.addColumn(fNameColumn, "First Name");
	    table.setColumnWidth(fNameColumn, 16.0, Unit.EM);

	    // Add a text column to show the Description.
	    Column<Contact, String> lNameColumn = new Column<Contact, String>(new EditTextCell()) {
			@Override
			public String getValue(Contact object) {
				return object.getLastName();
			}
	    };
	    lNameColumn.setFieldUpdater(new FieldUpdater<Contact, String>() {
	    	@Override
	        public void update(final int index, final Contact c, String value) 
	        {
	    		ServerUtility.myContactRpcService.editContact(c.objectId(), c.getFirstName(),value, new AsyncCallback<Void>() {

					@Override
					public void onFailure(Throwable caught) {
						// TODO Auto-generated method stub						
					}

					@Override
					public void onSuccess(Void result) {
						NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.RELOAD_CONTACTS));	
						table.setVisibleRangeAndClearData(table.getVisibleRange(), true);						
					}
				});
	        }
	    });	    
	    table.addColumn(lNameColumn, "Last Name");
	    table.setColumnWidth(lNameColumn, 16.0, Unit.EM);
	    
	    TextColumn<Contact> emailColumn = new TextColumn<Contact>() {
	           @Override
	           public String getValue(Contact object) {
	        	   return object.getEmail();
	           }
	        };
	    table.addColumn(emailColumn, "Email");
	    table.setColumnWidth(emailColumn, 30.0, Unit.EM);
	    
	    //delete button column
	    final Column<Contact, String> delete = new Column<Contact, String>(new MyImageButtonCell()) {
	        @Override
	        public String getValue(Contact row) {
	            return "/images/trash.png";
	        }
	    };
	    delete.setFieldUpdater(new FieldUpdater<Contact, String>()
	    {
	        @Override
	        public void update(final int index, final Contact c, String value) 
	        {
	        	ServerUtility.myContactRpcService.deleteContact(NavigationUtility.sessionMemId, c.objectId(), new AsyncCallback<Void>() {
	        		
					@Override
					public void onSuccess(Void result) {
						NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.RELOAD_CONTACTS));	
						table.setVisibleRangeAndClearData(table.getVisibleRange(), true);						
					}
					@Override
					public void onFailure(Throwable caught) {
						// TODO Auto-generated method stub						
					}
				});
	        }
	    });
	    table.addColumn(delete, "");
	    table.setColumnWidth(delete, 5.0, Unit.EM);
	    
	    AsyncDataProvider<Contact> provider = new AsyncDataProvider<Contact>() {
			@Override
			protected void onRangeChanged(HasData<Contact> display) {
				final int start = display.getVisibleRange().getStart();
		        final int end = start + display.getVisibleRange().getLength();

		        ServerUtility.myMemberRpcService.getAllContactsForMember(NavigationUtility.sessionMemId, new AsyncCallback<List<Contact>>() {
					@Override
					public void onSuccess(List<Contact> result) {
						int newEnd = end >= result.size() ? result.size() : end;
						List<Contact> sub = result.subList(start, newEnd);
				        updateRowCount(result.size(), false);
				        updateRowData(start, sub);
						//updateRowData(start, result);	
				        
				        if(result.size() == 0){
				        	ndw.setNoDataText("No Contacts found, Create a new Contact");
				        	table.setLoadingIndicator(ndw);
				        }
					}
					
					@Override
					public void onFailure(Throwable caught) {
						// TODO Auto-generated method stub						
					}
				});	
				
			}
	      };
	      provider.addDataDisplay(table);
	    
	      pager = new SimplePager() {
		    	@Override
		    	public boolean hasNextPage() {
		    		if(this.getPage()<(this.getPageCount()-1)) {
		    			return true;
		    		}
		    		return false;
		    	}
		    };
		    
	    // Add table display to pager.
	    pager.setDisplay(table);
	    pager.setStyleName("myPager");

	    myPnl.setVerticalAlignment(HasVerticalAlignment.ALIGN_TOP);
	    // this adds border between different widgets of the panel.
	    //this.setBorderWidth(1); 
	    myPnl.add(table);
	    myPnl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);      
	    myPnl.add(pager);
	    
	    addContact.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				validateAndCreateContact();
			}
		});

	    // Handle the Task modified event, here we are interested only in updating any new contacts
	    // created.
	    NavigationUtility.EVENT_BUS.addHandler(AcrossFormEvent.TYPE, new AcrossFormEventHandler(){
            public void onEvent(AcrossFormEvent event) {
            	switch (event.getActionType()) {
                case TASK_MODIFIED:
                	table.setVisibleRangeAndClearData(table.getVisibleRange(), true);
                	break;
                default:
                	break;
            	}
            }
        });

		int cwid = Window.getClientWidth()-202; // 200 is the Navigation-Form width.
		myPnl.setWidth((Integer.toString(cwid)+"px"));		
		ftable.setWidget(0, 0, myPnl);
	}
	
	public void validateAndCreateContact(){
		String errorMsgs="";
		
		String email = emailBox.getText();
		emailBox.setText("");
		if(!email.contains("@") || !email.contains(".")) {
			errorMsgs += "Invalid Email ID";
		}
		else if(email.equalsIgnoreCase(NavigationUtility.sessionEmail)) {
			errorMsgs += "Cannot add self as a Contact";
		}
		
		if(!errorMsgs.trim().isEmpty()){
			// Validation Failed !!!
			errorMsgs = "<font color='red'>" + errorMsgs + "</font>";
			ConfirmationDialog cnf = new ConfirmationDialog();
			cnf.confirm("Error", errorMsgs, true, this);
			return;
		}
		
		// Validation succeeded
		ServerUtility.myContactRpcService.createContact(NavigationUtility.sessionMemId, email, "", "", new AsyncCallback<Boolean>() {
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub							
			}

			@Override
			public void onSuccess(Boolean result) {
				if(result){
					table.setVisibleRangeAndClearData(table.getVisibleRange(), true);	
				}
				else {
					showContactAlreadyExistsDialog();
				}
			}
		});
	}
	
	public void showContactAlreadyExistsDialog() {
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirm("Error", "Contact already exists", true, this);
	}
	
	public void showFirstEmptyDialog(){
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirm("Error", "First Name, cannot be empty", true, this);
	}

	@Override
	public void confirmCancel(Boolean aConfirm) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void confirm() {
		// TODO Auto-generated method stub
		
	}

	
}
