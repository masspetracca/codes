package com.gannon.TaskEvaluation.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.TabPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gannon.TaskEvaluation.client.events.AcrossFormEvent;
import com.gannon.TaskEvaluation.client.events.handlers.AcrossFormEventHandler;
import com.gannon.TaskEvaluation.client.forms.MyTaskEvaluationsForm;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.shared.Task;

public class FinishedTasks extends ResizeComposite{

	private static FinishedTasksFormUiBinder uiBinder = GWT
			.create(FinishedTasksFormUiBinder.class);

	interface FinishedTasksFormUiBinder extends UiBinder<DockLayoutPanel, FinishedTasks> {
	}
	
	TabPanel myTabPanel = new TabPanel();
	
	private MyTaskEvaluationsForm tef = new MyTaskEvaluationsForm();
	
	@UiField FlexTable ftable;
	
	VerticalPanel myPnl = new VerticalPanel();

	public FinishedTasks() {
		initWidget(uiBinder.createAndBindUi(this));
		this.setStyleName("myManageTaskForm");

		myTabPanel.add(tef, "Evaluations");
		myTabPanel.selectTab(0);
		
		myPnl.add(myTabPanel);
		int cwid = Window.getClientWidth()-202; // 200 is the Navigation-Form width.
		myPnl.setWidth((Integer.toString(cwid)+"px"));
		ftable.setWidget(0,0,myPnl);
		
		NavigationUtility.EVENT_BUS.addHandler(AcrossFormEvent.TYPE, new AcrossFormEventHandler(){
            public void onEvent(AcrossFormEvent event) {
            	switch (event.getActionType()) {
                case TEMPLATES_MODIFIED_TASKFORM:
                	populateTemplates();
                	break;
                default:
                	break;
            	}
            }
        });
	}

	public void populateForm(Task aSelectedTask){
		tef.populateTask(aSelectedTask);
		
		myTabPanel.selectTab(0);
	}
	
	public void populateTemplates() {

	}

}
