package com.gannon.TaskEvaluation.client.forms;

import java.util.ArrayList;
import java.util.List;

import com.gannon.TaskEvaluation.client.suggest.PopUpCallBackInterface;
import com.google.gwt.cell.client.EditTextCell;
import com.google.gwt.cell.client.FieldUpdater;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.SimplePager;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.AsyncDataProvider;
import com.google.gwt.view.client.HasData;
import com.gannon.TaskEvaluation.client.widgets.MyCellTable;
import com.gannon.TaskEvaluation.client.widgets.NoDataWidget;
import com.gannon.TaskEvaluation.shared.Template;
import com.gannon.TaskEvaluation.shared.TemplateRow;
import com.gannon.TaskEvaluation.client.events.AcrossFormEvent;
import com.gannon.TaskEvaluation.client.utils.AcrossFormActionTypes;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.client.widgets.ConfirmationDialog;
import com.gannon.TaskEvaluation.client.widgets.MyEditNumberCell;
import com.gannon.TaskEvaluation.client.widgets.MyImageButtonCell;
import com.gannon.TaskEvaluation.client.widgets.TextAreaEditCell;

public class TemplateForm extends ResizeComposite implements PopUpCallBackInterface {

	private static TemplateFormUiBinder uiBinder = GWT
			.create(TemplateFormUiBinder.class);

	interface TemplateFormUiBinder extends UiBinder<DockLayoutPanel, TemplateForm> {
	}
	
	public static String DEFAULT_CRITERIA = "Click to enter Criteria";
	public static String DEFAULT_DESCRIPTION = "Click to describe about criteria";
	public static Integer DEFAULT_WEIGHTAGE = -1;
	
	private Button createNew = new Button("Create New Template");
	private Label myTemplatesLbl = new Label("My Templates:");
	private ListBox templateListBox = new ListBox();
	private HorizontalPanel csHor = new HorizontalPanel();
	
	// Create a Celltable.
	private MyCellTable<TemplateRow> table = new MyCellTable<TemplateRow>();
	private List<TemplateRow> list = new ArrayList<TemplateRow>();
	List<Template> myTemplates = new ArrayList<Template>();
	private int selectedTemplate = 0;
	
	// Create a pager for the celltable to add pagination.
	private SimplePager pager = null;//new SimplePager();

	// Create New Template
	private Label saveAsLabel = new Label("Save as:");
	private TextBox saveAsBox = new TextBox();
	private Button saveNewButton = new Button("Create");
	private Button cancelNewButton = new Button("Cancel");
	private HorizontalPanel butNewHor = new HorizontalPanel();	
	private FlexTable createNewForm = new FlexTable();
	
	// Edit Existing Template
	private Label nameLabel = new Label("Name:");
	private TextBox nameBox = new TextBox();
	private Button saveButton = new Button("Save");
	private Button cancelButton = new Button("Cancel");
	private Button deleteButton = new Button("Delete");
	private HorizontalPanel butHor = new HorizontalPanel();	
	private FlexTable editForm = new FlexTable();

	// Widget which shows when no data is present in the cell table.
	NoDataWidget ndw = new NoDataWidget("Select/Create a Template");
	
	VerticalPanel myMainPnl = new VerticalPanel();
	@UiField FlexTable ftable;

	public TemplateForm() {
		initWidget(uiBinder.createAndBindUi(this));

		// All the widgets must be to the top of the page.
		myMainPnl.setVerticalAlignment(HasVerticalAlignment.ALIGN_TOP);

		csHor.setStyleName("myCreateTemplateHeaderPanel");
		csHor.setHeight("100%");
		csHor.setWidth("100%");
		csHor.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);
		csHor.add(myTemplatesLbl);
		templateListBox.setWidth("150px");
		templateListBox.addItem("Select a Template");
		csHor.add(templateListBox);
		
		csHor.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		createNew.setWidth("170px");
		createNew.setHeight("34px");
		createNew.setStyleName("myGreenBtn");
		csHor.add(createNew);
		
		csHor.setCellWidth(myTemplatesLbl, "12%");
		csHor.setCellWidth(templateListBox, "13%");
		csHor.setCellWidth(createNew, "75%");
		
		myMainPnl.add(csHor);

		///////// Define Cell table columns
		// Add Criteria column.
		Column<TemplateRow, String> critColumn = new Column<TemplateRow, String>(new EditTextCell()) {
				@Override
				public String getValue(TemplateRow object) {
					return object.getCriteria();
				}
		};
		critColumn.setFieldUpdater(new FieldUpdater<TemplateRow, String>() {
			 @Override
		        public void update(final int index, final TemplateRow c, String value) 
		        {
				 	if(!value.isEmpty()){
				 		list.get(index).setCriteria(value);
		        	}
	    			else{
	    				list.get(index).setCriteria(DEFAULT_CRITERIA);
	    			}
		        }
		});
	    table.addColumn(critColumn, "Criteria");
	    table.setColumnWidth(critColumn, 16.0, Unit.EM);

	    // Add a text column to show the Description.
	    Column<TemplateRow, String> descColumn = new Column<TemplateRow, String>(new TextAreaEditCell()) {
			@Override
			public String getValue(TemplateRow object) {
				return object.getDescription();
			}
	    };
	    descColumn.setFieldUpdater(new FieldUpdater<TemplateRow, String>() {
	    	@Override
	        public void update(final int index, final TemplateRow c, String value) 
	        {
	    		if(!value.isEmpty()){
	    			list.get(index).setDescription(value);
	    		}
	    		else{
	    			list.get(index).setDescription(DEFAULT_DESCRIPTION);
	    		}
	        }
	    });	    
	    table.addColumn(descColumn, "Description");
	    table.setColumnWidth(descColumn, 40.0, Unit.EM);
	    
	    // Add a text column to show the Weightage.
	    Column<TemplateRow, String> weighColumn = new Column<TemplateRow, String>(new MyEditNumberCell()) {
			@Override
			public String getValue(TemplateRow object) {
				return Integer.toString(object.getWeightage());
			}
	    };
	    weighColumn.setFieldUpdater(new FieldUpdater<TemplateRow, String>() {
	    	@Override
	        public void update(final int index, final TemplateRow c, String value) 
	        {
	    		try
            	{
   	    		   list.get(index).setWeightage(Integer.parseInt(value));
            	}
            	catch (NumberFormatException nfe)
            	{
            		list.get(index).setWeightage(DEFAULT_WEIGHTAGE);
            	}
	        }
	    });
	    table.addColumn(weighColumn, "Weightage % (1-100)");
	    table.setColumnWidth(weighColumn, 10.0, Unit.EM);
	    
	    //delete button column
	    final Column<TemplateRow, String> delete = new Column<TemplateRow, String>(new MyImageButtonCell()) {
	        @Override
	        public String getValue(TemplateRow row) {
	            return "/images/trash.png";
	        }
	    };
	    delete.setFieldUpdater(new FieldUpdater<TemplateRow, String>()
	    {
	        @Override
	        public void update(final int index, final TemplateRow c, String value) 
	        {
	        	if(list.size()>1){
	        		list.remove(c);
	        		table.setVisibleRangeAndClearData(table.getVisibleRange(), true);
	        	}
	        	else{
	        		showLastRowCannotBeDeletedDialog();
	        	}
	        }
	    });
	    table.addColumn(delete, "");
	    table.setColumnWidth(delete, 5.0, Unit.EM);
	    
	    //add button column
	    final Column<TemplateRow, String> add = new Column<TemplateRow, String>(new MyImageButtonCell()) {
	        @Override
	        public String getValue(TemplateRow row) {
	            return "/images/add.png";
	        }
	    };
	    add.setFieldUpdater(new FieldUpdater<TemplateRow, String>()
	    {
	        @Override
	        public void update(final int index, final TemplateRow c, String value) 
	        {
	        	TemplateRow tr = new TemplateRow();
				list.add(index+1, tr);
				
				table.setVisibleRangeAndClearData(table.getVisibleRange(), true);
	        }
	    });
	    table.addColumn(add, "");

	    ////// Define Asynchronous Data provider.
	    AsyncDataProvider<TemplateRow> provider = new AsyncDataProvider<TemplateRow>() {
			@Override
			protected void onRangeChanged(HasData<TemplateRow> display) {
				
		        final int start = display.getVisibleRange().getStart();
			    final int end = start + display.getVisibleRange().getLength();

				int newEnd = end >= list.size() ? list.size() : end;
				List<TemplateRow> sub = list.subList(start, newEnd);
		        updateRowCount(list.size(), false);
		        updateRowData(start, sub);	
		        
			    if(list.size() == 0) {
					table.setLoadingIndicator(ndw);
			    }
			}
	    };
	    provider.addDataDisplay(table);
	    //table.setRowCount(0, true);//ASH to remove loading indicator.

	    pager = new SimplePager() {
	    	@Override
	    	public boolean hasNextPage() {
	    		if(this.getPage()<(this.getPageCount()-1)) {
	    			return true;
	    		}
	    		return false;
	    	}
	    };
	    
	    // Add table display to pager.
	    pager.setDisplay(table);
	    pager.setStyleName("myPager");
	    pager.setPageSize(6);

	    myMainPnl.setVerticalAlignment(HasVerticalAlignment.ALIGN_TOP);
	    // this adds border between different widgets of the panel.
	    //this.setBorderWidth(1); 
	    myMainPnl.add(table);
	    myMainPnl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);      
	    myMainPnl.add(pager);
	    

	    // Create New Template
	    createNewForm.setStyleName("myCreateTaskForm");
		
	    createNewForm.setWidget(0, 0, saveAsLabel);
	    createNewForm.setWidget(0, 1, saveAsBox);
		
		butNewHor.add(saveNewButton);
        butNewHor.add(cancelNewButton);
        butNewHor.setSpacing(30);
        
        createNewForm.setWidget(1, 1, butNewHor);
    
        myMainPnl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);  
        createNewForm.setVisible(false);
        myMainPnl.add(createNewForm);
        
        // Edit template    	
    	editForm.setStyleName("myCreateTaskForm");
		
    	editForm.setWidget(0, 0, nameLabel);
    	editForm.setWidget(0, 1, nameBox);
		
    	butHor.add(saveButton);
    	butHor.add(cancelButton);
    	butHor.setSpacing(30);
        
    	editForm.setWidget(1, 1, butHor);
    	
    	deleteButton.setStyleName("myRedButton");
    	deleteButton.setSize("100px", "32px");
    	editForm.setWidget(1, 2, deleteButton);
    
    	myMainPnl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);  
        editForm.setVisible(false);
        myMainPnl.add(editForm);
        
        createNew.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				createNewForm.setVisible(true);	
				editForm.setVisible(false);	
				createNew.setEnabled(false);
				templateListBox.setItemSelected(0, true);
				templateListBox.setEnabled(false);
				saveAsBox.setText("");
				
				// Start a new Template
				list.clear();
				TemplateRow tr = new TemplateRow();
				list.add(tr);
				
				table.setVisibleRangeAndClearData(table.getVisibleRange(), true);
			}
		});
        
        cancelNewButton.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				createNewForm.setVisible(false);	
				createNew.setEnabled(true);
				templateListBox.setEnabled(true);
				templateListBox.setItemSelected(0, true);
				list.clear();
				table.setVisibleRangeAndClearData(table.getVisibleRange(), true);
			}
		});
        
		saveNewButton.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {				
				validateAndCreateTemplate();				
			}
		});
		
		cancelButton.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				editForm.setVisible(false);	
				createNew.setEnabled(true);
				templateListBox.setEnabled(true);
				templateListBox.setItemSelected(0, true);
				list.clear();
				createNew.setVisible(true);
				
				ndw.setNoDataText("Select a Template from the List");
				table.setVisibleRangeAndClearData(table.getVisibleRange(), true);
				//table.setRowCount(0, true);
			}
		});
        
		saveButton.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {					
				validateAndSaveChanges();				
			}
		});
		
		deleteButton.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				deleteClicked();							
			}
		});
        
		ServerUtility.myMemberRpcService.getAllTemplatesForMember(NavigationUtility.sessionMemId, new AsyncCallback<List<Template>>() {
			@Override
			public void onSuccess(List<Template> result) {
				myTemplates = result;
				templateListBox.clear();
				templateListBox.addItem("Select a Template");
				for(Template temp: result){
					templateListBox.addItem(temp.getTemplateName(), temp.objectId());
				}
				
				if(result.size() == 0){
					ndw.setNoDataText("No Templates found, Create a new Template");
					table.setVisibleRangeAndClearData(table.getVisibleRange(), true);
				}
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub						
			}
		});
		
		templateListBox.addChangeHandler(new ChangeHandler() {			
			@Override
			public void onChange(ChangeEvent event) {
				createNewForm.setVisible(false);
				if(templateListBox.getSelectedIndex() > 0) {
					selectedTemplate = templateListBox.getSelectedIndex() - 1;				
					list = TemplateRow.getAllTemplateRowsForTemplate(myTemplates.get(selectedTemplate));	
					editForm.setVisible(true);	
					nameBox.setText(myTemplates.get(selectedTemplate).getTemplateName());
					
					createNew.setVisible(false);
					table.setVisibleRangeAndClearData(table.getVisibleRange(), true);
				}
				else {
					list.clear();
					editForm.setVisible(false);					
					createNew.setVisible(true);
					
					ndw.setNoDataText("Select a Template from the List");
					//table.setRowCount(0, true);					
					table.setVisibleRangeAndClearData(table.getVisibleRange(), true);
				}
			}
		});
		
		int cwid = Window.getClientWidth()-202; // 200 is the Navigation-Form width.
		myMainPnl.setWidth((Integer.toString(cwid)+"px"));
		ftable.setWidget(0, 0, myMainPnl);

	}

	public void deleteClicked(){
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirmCancel("Delete Confirmation", "Are are sure?", this);
	}

	@Override
	public void confirmCancel(Boolean aConfirm) {
		deleteButton.setEnabled(false);
		if(aConfirm){
			ServerUtility.myTemplateRpcService.deleteTemplate(templateListBox.getValue(selectedTemplate+1), new AsyncCallback<Boolean>() {

				@Override
				public void onFailure(Throwable caught) {
					// TODO Auto-generated method stub					
				}

				@Override
				public void onSuccess(Boolean result) {
					deleteButton.setEnabled(true);
					if(result) {
						editForm.setVisible(false);	
						createNew.setEnabled(true);
						templateListBox.setEnabled(true);	
						myTemplates.remove(selectedTemplate);
						templateListBox.removeItem(selectedTemplate+1);
						templateListBox.setItemSelected(0, true);
						list.clear();
						createNew.setVisible(true);
						if(myTemplates.size() > 0){
							ndw.setNoDataText("Select a Template from the List");
						}
						else{
							ndw.setNoDataText("No Templates found, Create a new Template");
						}
						table.setVisibleRangeAndClearData(table.getVisibleRange(), true);
						
						NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.RELOAD_TEMPLATES));
					}
					else {
						showTemplateInUseDialog();
					}
				}
			});		
		}	
		else{
			deleteButton.setEnabled(true);
		}
	}
	
	public void showTemplateInUseDialog(){
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirm("Error", "Cannot delete this Template it used by other Tasks", true, this);
	}
	
	public void showLastRowCannotBeDeletedDialog(){
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirm("Cannot not delete", "Template cannot have Zero rows", true, this);
	}
	
	public void validateAndSaveChanges(){		
		String errorMsgs="";
		
		String templateName = nameBox.getText();
		if(templateName.trim().isEmpty()){
			errorMsgs+="Template Name, cannot be empty";
		}
		
		List<String> crit = new ArrayList<String>();
    	List<String> desc = new ArrayList<String>();
    	List<Integer> weigh = new ArrayList<Integer>();
    	boolean critErrorSet=false;
    	boolean descErrorSet=false;
    	boolean weighErrorSet=false;
    	
    	for(TemplateRow temp : list) {
    		if( (temp.getCriteria().isEmpty()|| (temp.getCriteria().equalsIgnoreCase(DEFAULT_CRITERIA))) &&
    				!critErrorSet){
    			if(!errorMsgs.isEmpty()){
    				errorMsgs+="<br>";
    			}
    			errorMsgs+="Please enter Criteria Name";
    			critErrorSet = true;
    		}
    		crit.add(temp.getCriteria());
    		
    		if( (temp.getDescription().isEmpty() || (temp.getDescription().equalsIgnoreCase(DEFAULT_DESCRIPTION))) &&
    				!descErrorSet){
    			if(!errorMsgs.isEmpty()){
    				errorMsgs+="<br>";
    			}
    			errorMsgs+="Please enter Criteria Description";
    			descErrorSet = true;
    		}
    		desc.add(temp.getDescription());
    		
    		if( ((temp.getWeightage() < 1) || (temp.getWeightage() > 100)) && !weighErrorSet){    		
    			if(!errorMsgs.isEmpty()){
    				errorMsgs+="<br>";
    			}
    			errorMsgs+="Weightage value should be between 1 to 100";
    			weighErrorSet = true;
    		}
    		
    		weigh.add(temp.getWeightage());
    	} // End For loop.
    	
    	if(!errorMsgs.trim().isEmpty()){
			errorMsgs = "<font color='red'>" + errorMsgs + "</font>";
			ConfirmationDialog cnf = new ConfirmationDialog();
			cnf.confirm("Correct the following Errors", errorMsgs, true, this);
			return;
		}    	

    	// Validation Successful save the Template.
		editForm.setVisible(false);	
		createNew.setEnabled(true);
		templateListBox.setEnabled(true);
    	
		ServerUtility.myTemplateRpcService.editTemplate(myTemplates.get(selectedTemplate).objectId(),templateName, crit, weigh, desc, false, new AsyncCallback<Template>() {

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}

			@Override
			public void onSuccess(Template result) {
				myTemplates.set(selectedTemplate, result);
				templateListBox.setItemText(selectedTemplate+1, result.getTemplateName());
				
				templateListBox.setItemSelected(0, true);
				list.clear();
				table.setVisibleRangeAndClearData(table.getVisibleRange(), true);
				createNew.setVisible(true);
				
				NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.RELOAD_TEMPLATES));
			}
		});
	}

	@Override
	public void confirm() {
		// Nothing to do		
	}
	
	public void validateAndCreateTemplate(){		
		String errorMsgs="";
		
		String templateName = saveAsBox.getText();
		if(templateName.trim().isEmpty()){
			errorMsgs+="Template Name, cannot be empty";
		}
		
		List<String> crit = new ArrayList<String>();
    	List<String> desc = new ArrayList<String>();
    	List<Integer> weigh = new ArrayList<Integer>();
    	boolean critErrorSet=false;
    	boolean descErrorSet=false;
    	boolean weighErrorSet=false;
    	
    	for(TemplateRow temp : list) {
    		if( (temp.getCriteria().isEmpty()|| (temp.getCriteria().equalsIgnoreCase(DEFAULT_CRITERIA))) &&
    				!critErrorSet){
    			if(!errorMsgs.isEmpty()){
    				errorMsgs+="<br>";
    			}
    			errorMsgs+="Please enter Criteria Name";
    			critErrorSet = true;
    		}
    		crit.add(temp.getCriteria());
    		
    		if( (temp.getDescription().isEmpty() || (temp.getDescription().equalsIgnoreCase(DEFAULT_DESCRIPTION))) &&
    				!descErrorSet){
    			if(!errorMsgs.isEmpty()){
    				errorMsgs+="<br>";
    			}
    			errorMsgs+="Please enter Criteria Description";
    			descErrorSet = true;
    		}
    		desc.add(temp.getDescription());
    		
    		if( (temp.getWeightage() > 100) && !weighErrorSet){    		
    			if(!errorMsgs.isEmpty()){
    				errorMsgs+="<br>";
    			}
    			errorMsgs+="Weightage value should be less than 100";
    			weighErrorSet = true;
    		}
    		
    		weigh.add(temp.getWeightage());
    	} // End For loop.
    	
    	if(!errorMsgs.trim().isEmpty()){
			errorMsgs = "<font color='red'>" + errorMsgs + "</font>";
			ConfirmationDialog cnf = new ConfirmationDialog();
			cnf.confirm("Correct the following Errors", errorMsgs, true, this);
			return;
		}    	

    	// Validation Successful create the Template.
    	createNewForm.setVisible(false);	
		createNew.setEnabled(true);
		templateListBox.setEnabled(true);	
    	
		ServerUtility.myTemplateRpcService.createTemplate(templateName, NavigationUtility.sessionMemId, crit, weigh, desc, false, new AsyncCallback<Template>() {

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}

			@Override
			public void onSuccess(Template result) {
				myTemplates.add(result);
				templateListBox.addItem(result.getTemplateName(), result.objectId());
				
				list.clear();
				ndw.setNoDataText("Select a Template from the List");
				table.setVisibleRangeAndClearData(table.getVisibleRange(), true);

				NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.RELOAD_TEMPLATES));
			}
		});
	}

}
