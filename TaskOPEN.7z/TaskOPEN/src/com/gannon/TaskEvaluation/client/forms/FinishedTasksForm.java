package com.gannon.TaskEvaluation.client.forms;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.gwt.cell.client.DateCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.i18n.client.DateTimeFormat.PredefinedFormat;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.SimplePager;
import com.google.gwt.user.cellview.client.TextColumn;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.AsyncDataProvider;
import com.google.gwt.view.client.HasData;
import com.google.gwt.view.client.SelectionChangeEvent;
import com.google.gwt.view.client.SingleSelectionModel;
import com.gannon.TaskEvaluation.client.suggest.EmailCallBackInterface;
import com.gannon.TaskEvaluation.client.suggest.PopUpCallBackInterface;
import com.gannon.TaskEvaluation.shared.Template;
import com.gannon.TaskEvaluation.client.events.NavigationEvent;
import com.gannon.TaskEvaluation.client.utils.ActionTypes;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.widgets.ConfirmationDialog;
import com.gannon.TaskEvaluation.client.widgets.MyCellTable;
import com.gannon.TaskEvaluation.client.widgets.NoDataWidget;
import com.gannon.TaskEvaluation.client.widgets.TaskAuthorEmailDialog;
import com.gannon.TaskEvaluation.shared.Task;
//import com.gannon.TaskEvaluation.client.utils.FadeAnimation;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.client.widgets.MyImageButtonCell;
import com.gannon.TaskEvaluation.client.events.AcrossFormEvent;
import com.gannon.TaskEvaluation.client.events.ManageTaskEvent;
import com.gannon.TaskEvaluation.client.events.handlers.ManageTaskEventHandler;
import com.gannon.TaskEvaluation.client.utils.AcrossFormActionTypes;
import com.gannon.TaskEvaluation.client.events.handlers.AcrossFormEventHandler;
//import com.gannon.TaskEvaluation.client.forms.ManageTaskForm;

public class FinishedTasksForm extends ResizeComposite implements PopUpCallBackInterface, EmailCallBackInterface {

	private static FinishedTasksFormUiBinder uiBinder = GWT
			.create(FinishedTasksFormUiBinder.class);

	interface FinishedTasksFormUiBinder extends UiBinder<DockLayoutPanel, FinishedTasksForm> {
	}
	
	private Label myTasksLbl = new Label("My Tasks");

	private HorizontalPanel headerPanel = new HorizontalPanel();

	//private ManageTaskForm mtf = new ManageTaskForm();
	
	// Create a Celltable.
	@UiField FlexTable ftable;
	private MyCellTable<Task> table = new MyCellTable<Task>();
	
	// Create a pager for the celltable to add pagination.
	private SimplePager pager = new SimplePager() {
    	@Override
    	public boolean hasNextPage() {
    		if(this.getPage()<(this.getPageCount()-1)) {
    			return true;
    		}
    		return false;
    	}
    };
	
	// A panel for task table and pager.
	private VerticalPanel tablePanel = new VerticalPanel();
	
	public static List<Template> myTemplates = new ArrayList<Template>();
	
	public static String taskPerformer="";
		
	// Widget which shows when no data is present in the cell table.
	NoDataWidget ndw = new NoDataWidget("No Tasks found, Create a new Task");

	public FinishedTasksForm() {
		initWidget(uiBinder.createAndBindUi(this));
		//mtf.setVisible(false);

	    tablePanel.setVerticalAlignment(HasVerticalAlignment.ALIGN_TOP);
	    
		headerPanel.setStyleName("myTasksFormHeaderPanel");
		headerPanel.setWidth("100%");
		headerPanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);
		myTasksLbl.setStyleName("myTasksFormMyTasksLbl");
		headerPanel.add(myTasksLbl);
		headerPanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);

		tablePanel.add(headerPanel);
		
		// Define Cell table columns
		//task icon column
	    final Column<Task, String> taskIcon = new Column<Task, String>(new MyImageButtonCell()) {
	        @Override
	        public String getValue(Task row) {
	        	Date today = new Date();
	        	if(row.areAllEvaluationsComplete()){
	        		return "/images/taskRow.png";
	        	}	        	
	        	else if(row.getCompletionDate().after(today)){
        			return "/images/taskRowGreen.png";
        		}
        		else{
        			return "/images/taskRowRed.png";
        		}
	        }
	    };
	    table.addColumn(taskIcon);
	    table.setColumnWidth(taskIcon, 2.2, Unit.EM);
		
		// Add a text column to show the address.
        TextColumn<Task> taskNameColumn = new TextColumn<Task>() {
           @Override
           public String getValue(Task object) {
              return object.getTaskName();
           }
        };
	    table.addColumn(taskNameColumn);
	    table.setColumnWidth(taskNameColumn, 16.0, Unit.EM);
	    
	    // Add a date column to show the Completion time.
	    DateTimeFormat format = DateTimeFormat.getFormat(PredefinedFormat.DATE_MEDIUM);
	    DateCell dateCell = new DateCell(format);
	    Column<Task, Date> dateColumn = new Column<Task, Date>(dateCell) {
	      @Override
	      public Date getValue(Task object) {
	        return object.getCompletionDate();
	      }
	    };
	    table.addColumn(dateColumn);

	    // Add Asynchronous data provider.
	    final AsyncDataProvider<Task> provider = new AsyncDataProvider<Task>() {
			@Override
			protected void onRangeChanged(HasData<Task> display) {
				final int start = display.getVisibleRange().getStart();
		        final int end = start + display.getVisibleRange().getLength();

		        ServerUtility.myMemberRpcService.getAllCreatedTasksForMember(NavigationUtility.sessionMemId,new AsyncCallback<List<Task>>() {
					@Override
					public void onSuccess(List<Task> result) {
						int newEnd = end >= result.size() ? result.size() : end;
						List<Task> sub = result.subList(start, newEnd);
				        updateRowCount(result.size(), false);
				        updateRowData(start, sub);
						//updateRowData(start, result);	
				        
				        if(result.size() == 0){
				        	ndw.setNoDataText("No Tasks found");
				        	table.setLoadingIndicator(ndw);
				        }
					}
					
					@Override
					public void onFailure(Throwable caught) {
						// TODO Auto-generated method stub						
					}
				});				
			}
	    };
	    provider.addDataDisplay(table); 
	      
	    // Add a selection model to handle user selection.
	    final SingleSelectionModel<Task> selectionModel = new SingleSelectionModel<Task>();
	    table.setSelectionModel(selectionModel);
	    selectionModel.addSelectionChangeHandler(
	    new SelectionChangeEvent.Handler() {
	       public void onSelectionChange(SelectionChangeEvent event) {
	          Task selected = selectionModel.getSelectedObject();
	          if (selected != null) {	
	        	  //mtf.populateForm(selected);	        	  

	        	  // Fade Animation.
	        	  //mtf.getElement().getStyle().setOpacity(0);
	        	  //mtf.setVisible(true);
	        	  //FadeAnimation fadeAnimation = new FadeAnimation (mtf, 1.0);
	        	  //fadeAnimation.fade(1200);
	        	// Fire the navigation event to do further action.	
	  	    	NavigationUtility.EVENT_BUS.fireEvent(new NavigationEvent(ActionTypes.F_TASKS, selected));
	  	    	selectionModel.setSelected(selectionModel.getSelectedObject(), false);
	          }
	       }
	    });
	    
	    pager = new SimplePager() {
	    	@Override
	    	public boolean hasNextPage() {
	    		if(this.getPage()<(this.getPageCount()-1)) {
	    			return true;
	    		}
	    		return false;
	    	}
	    };
	    
	    // Add table display to pager.
	    pager.setDisplay(table);
	    pager.setStyleName("myPager");
	    pager.setPageSize(10);
	    
	    // this adds border between different widgets of the panel.
	    table.setWidth("100%", true);
	    table.setHeight("100%");
	    tablePanel.add(table);
	    tablePanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);      
	    tablePanel.add(pager);
	    
	    //tablePanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT); 
	    //tablePanel.add(mtf);

	   
	    // Some Magic code to make the widget display proper, find a better way ASH
	    int cwid = Window.getClientWidth()-212; // 212 is the Navigation-Form width.
	    tablePanel.setWidth((Integer.toString(cwid)+"px"));		    
	    ftable.setWidget(0, 0,tablePanel);
	    table.getElement().getStyle().setProperty("border", "0");
	    table.getElement().getStyle().setProperty("borderBottom", "1px solid #6f7277");
	    
	    // Add event handler for events from the Manage Task Form.
	    NavigationUtility.EVENT_BUS.addHandler(ManageTaskEvent.TYPE, new ManageTaskEventHandler(){
            public void onEvent(ManageTaskEvent event) {
            	switch (event.getActionType()) {
                case SAVE:
                	selectionModel.setSelected(selectionModel.getSelectedObject(), false);
                	//mtf.setVisible(false);
                	table.setVisibleRangeAndClearData(table.getVisibleRange(), true); 
                	NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.TASK_MODIFIED));
                    break;
                case CANCEL:
                	selectionModel.setSelected(selectionModel.getSelectedObject(), false);
                	//mtf.setVisible(false);
                    break;
                case DELETE:
                	selectionModel.setSelected(selectionModel.getSelectedObject(), false);
                	//mtf.setVisible(false);
                	table.setVisibleRangeAndClearData(table.getVisibleRange(), true); 
                	NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.TASK_MODIFIED));
                    break;
                case CLOSE:
                	selectionModel.setSelected(selectionModel.getSelectedObject(), false);
                	//mtf.setVisible(false);  
                	break;
                case CREATE_CANCEL:
                	//mtf.setVisible(false);
                	//tblFormPanel.setVisible(true);    			    
    			    //createPanel.setVisible(false);
    			    //createNewTaskBtn.setVisible(true);
    			    //myTasksLbl.setText("My Tasks");
    			    break;
                case CREATE_SAVE:
                	//mtf.setVisible(false);
                	//tblFormPanel.setVisible(true);    			    
    			    //createPanel.setVisible(false);
    			    //createNewTaskBtn.setVisible(true);
    			    //myTasksLbl.setText("My Tasks");
    			    table.setVisibleRangeAndClearData(table.getVisibleRange(), true); 
    			    NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.TASK_MODIFIED));
    			    break;
            	}
            }
        });
	    
	    ServerUtility.myMemberRpcService.getAllTemplatesForMember(NavigationUtility.sessionMemId, new AsyncCallback<List<Template>>() {
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}

			@Override
			public void onSuccess(List<Template> result) {
				myTemplates = result;	
				NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.TEMPLATES_MODIFIED_TASKFORM));
				//mtf.populateTemplates();
			}
		});
	    
	    NavigationUtility.EVENT_BUS.addHandler(AcrossFormEvent.TYPE, new AcrossFormEventHandler(){
            public void onEvent(AcrossFormEvent event) {
            	switch (event.getActionType()) {
                case RELOAD_TEMPLATES:
                	ServerUtility.myMemberRpcService.getAllTemplatesForMember(NavigationUtility.sessionMemId, new AsyncCallback<List<Template>>() {
            			@Override
            			public void onFailure(Throwable caught) {
            				// TODO Auto-generated method stub            				
            			}
            			@Override
            			public void onSuccess(List<Template> result) {
            				myTemplates = result;            				
            				NavigationUtility.EVENT_BUS.fireEvent(new AcrossFormEvent(AcrossFormActionTypes.TEMPLATES_MODIFIED_TASKFORM));
            				//mtf.populateTemplates();
            			}
            		});
                	break;
                default:
                	break;
            	}
            }
        });
	    
	   
		
	}


	void createNewTaskClicked(){
		if(myTemplates.size() == 0) {
			ConfirmationDialog cnf = new ConfirmationDialog();
			cnf.confirm("No Templates Found", "Please create a Template before creating Task", false, this);
		}
		else {
			TaskAuthorEmailDialog erd = new TaskAuthorEmailDialog();
			erd.showEmailDialog("", this);
		}
	}


	@Override
	public void confirmCancel(Boolean aConfirm) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void confirm() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void confirmCancel(Boolean aConfirm, List<String> aToEmails,
			String aSub) {
		if( aConfirm ) {
			taskPerformer = aToEmails.get(0);
			// Fire the navigation event to do further action.	
	    	NavigationUtility.EVENT_BUS.fireEvent(new NavigationEvent(ActionTypes.CREATE_TASK));
		}
	}

}
