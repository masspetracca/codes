package com.gannon.TaskEvaluation.client.forms;

import java.util.Date;
import java.util.List;

import com.google.gwt.cell.client.DateCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.i18n.client.DateTimeFormat.PredefinedFormat;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.SimplePager;
import com.google.gwt.user.cellview.client.TextColumn;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.AsyncDataProvider;
import com.google.gwt.view.client.HasData;
import com.google.gwt.view.client.SelectionChangeEvent;
import com.google.gwt.view.client.SingleSelectionModel;
import com.gannon.TaskEvaluation.client.events.EvaluationEvent;
import com.gannon.TaskEvaluation.client.events.handlers.EvaluationEventHandler;
import com.gannon.TaskEvaluation.client.forms.EvaluateTaskForm;
import com.gannon.TaskEvaluation.client.forms.SubmittedTaskForm;
import com.gannon.TaskEvaluation.client.utils.FadeAnimation;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.client.widgets.MyCellTable;
import com.gannon.TaskEvaluation.client.widgets.MyImageButtonCell;
import com.gannon.TaskEvaluation.client.widgets.NoDataWidget;
import com.gannon.TaskEvaluation.shared.EvaluationTaskDTO;

public class EvaluateForm extends ResizeComposite {

	private static EvaluateFormUiBinder uiBinder = GWT
			.create(EvaluateFormUiBinder.class);

	interface EvaluateFormUiBinder extends UiBinder<DockLayoutPanel, EvaluateForm> {
	}
	
	private Label myTasksLbl = new Label("My Evaluation Tasks");
	private HorizontalPanel headerPanel = new HorizontalPanel();
	
	// A panel for tabelPanel and manage task form.
	private HorizontalPanel tblFormPanel = new HorizontalPanel();
	private EvaluateTaskForm etf = new EvaluateTaskForm();
	private SubmittedTaskForm edtf = new SubmittedTaskForm();
		
	// Create a Celltable.
	private MyCellTable<EvaluationTaskDTO> table = new MyCellTable<EvaluationTaskDTO>();
		
	// Create a pager for the celltable to add pagination.
	private SimplePager pager = null;//new SimplePager();
	
	// A panel for task table and pager.
	private VerticalPanel tablePanel = new VerticalPanel();
	
	// Widget which shows when no data is present in the cell table.
	NoDataWidget ndw = new NoDataWidget("No Evaluation Tasks assigned yet");
	
	VerticalPanel myMainPnl = new VerticalPanel();
	@UiField FlexTable ftable;

	public EvaluateForm() {
		initWidget(uiBinder.createAndBindUi(this));
		this.setStyleName("myCreateTemplatePanel"); // reusing the create template style.

		// All the widgets must be to the top of the page.
		myMainPnl.setVerticalAlignment(HasVerticalAlignment.ALIGN_TOP);
	
		headerPanel.setStyleName("myTasksFormHeaderPanel");
		headerPanel.setWidth("100%");
		headerPanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);
		myTasksLbl.setStyleName("myTasksFormMyTasksLbl");
		headerPanel.add(myTasksLbl);
		myMainPnl.add(headerPanel);	

		// Define Cell table columns
		// Task icon column
	    final Column<EvaluationTaskDTO, String> taskIcon = new Column<EvaluationTaskDTO, String>(new MyImageButtonCell()) {
	        @Override
	        public String getValue(EvaluationTaskDTO row) {	        	
	        	if(!row.isTaskEvaluated()){
	        		Date today = new Date();
	        		if(row.getEvaluationDate().after(today)){
	        			return "/images/taskRowGreen.png";
	        		}
	        		else {
	        			return "/images/taskRowRed.png";
	        		}
	        	}
	        	else{
	        		return "/images/taskRow.png";
	        	}
	        }
	    };
	    table.addColumn(taskIcon, "");
		
		// Add a text column to show the address.
        TextColumn<EvaluationTaskDTO> taskNameColumn = new TextColumn<EvaluationTaskDTO>() {
           @Override
           public String getValue(EvaluationTaskDTO object) {
              return object.getTaskName();
           }
        };
	    table.addColumn(taskNameColumn, "Tasks");
	    table.setColumnWidth(taskNameColumn, 16.0, Unit.EM);
	    
	    // Add a date column to show the Completion time.
	    DateTimeFormat format = DateTimeFormat.getFormat(PredefinedFormat.DATE_MEDIUM);
	    DateCell dateCell = new DateCell(format);
	    Column<EvaluationTaskDTO, Date> dateColumn = new Column<EvaluationTaskDTO, Date>(dateCell) {
	      @Override
	      public Date getValue(EvaluationTaskDTO object) {
	        return object.getEvaluationDate();
	      }
	    };
	    table.addColumn(dateColumn, "");

	    // Add Asynchronous data provider.
	    final AsyncDataProvider<EvaluationTaskDTO> provider = new AsyncDataProvider<EvaluationTaskDTO>() {
			@Override
			protected void onRangeChanged(HasData<EvaluationTaskDTO> display) {
				final int start = display.getVisibleRange().getStart();
		        final int end = start + display.getVisibleRange().getLength();

		        ServerUtility.myMemberRpcService.getAllEvalTasksForMember(NavigationUtility.sessionMemId,new AsyncCallback<List<EvaluationTaskDTO>>() {
					@Override
					public void onSuccess(List<EvaluationTaskDTO> result) {
						int newEnd = end >= result.size() ? result.size() : end;
						List<EvaluationTaskDTO> sub = result.subList(start, newEnd);
				        updateRowCount(result.size(), false);
				        updateRowData(start, sub);
						//updateRowData(start, result);	
					    if(result.size() == 0){
							table.setLoadingIndicator(ndw);
						}
					}
					
					@Override
					public void onFailure(Throwable caught) {
						// TODO Auto-generated method stub						
					}
				});			
			}
	    };
	    provider.addDataDisplay(table); 
	    table.setRowCount(0, true);
	      
	    // Add a selection model to handle user selection.
	    final SingleSelectionModel<EvaluationTaskDTO> selectionModel = new SingleSelectionModel<EvaluationTaskDTO>();
	    table.setSelectionModel(selectionModel);
	    selectionModel.addSelectionChangeHandler(
	    new SelectionChangeEvent.Handler() {
	       public void onSelectionChange(SelectionChangeEvent event) {
	    	   EvaluationTaskDTO selected = selectionModel.getSelectedObject();
	          if (selected != null) {	
	        	  
	        	  if(!selected.isTaskEvaluated()) {
		        	  etf.populateForm(selected.getTemplateId(), selected.getTask(),selected.getTaskName(), selected.getTaskPerformer());        	  
	
		        	  // Fade Animation.
		        	  etf.getElement().getStyle().setOpacity(0);
		        	  tablePanel.setVisible(false);
		        	  edtf.setVisible(false);
		        	  etf.setVisible(true);
		        	  FadeAnimation fadeAnimation = new FadeAnimation (etf, 1.0);
		        	  fadeAnimation.fade(1200);
	        	  }
	        	  else{
	        		  edtf.populateForm(selected.getTask(),selected.getTaskName(), selected.getTaskPerformer());        	  
	        			
		        	  // Fade Animation.
		        	  edtf.getElement().getStyle().setOpacity(0);
		        	  tablePanel.setVisible(false);
		        	  etf.setVisible(false);
		        	  edtf.setVisible(true);
		        	  FadeAnimation fadeAnimation = new FadeAnimation (edtf, 1.0);
		        	  fadeAnimation.fade(1200);
	        	  }
	          }
	       }
	    });
	    
	    pager = new SimplePager() {
	    	@Override
	    	public boolean hasNextPage() {
	    		if(this.getPage()<(this.getPageCount()-1)) {
	    			return true;
	    		}
	    		return false;
	    	}
	    };
	    
	    // Add table display to pager.
	    pager.setDisplay(table);
	    pager.setStyleName("myPager");

	    tablePanel.setVerticalAlignment(HasVerticalAlignment.ALIGN_TOP); 
	    tablePanel.add(table);
	    tablePanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);      
	    tablePanel.add(pager);

		tblFormPanel.setWidth("100%");	   
	    tblFormPanel.add(tablePanel);
	    tblFormPanel.add(etf);
	    tblFormPanel.add(edtf);
	    myMainPnl.add(tblFormPanel);

	    etf.setVisible(false);
	    edtf.setVisible(false);

	    // Add event handler for events from the Evaluate Task Form.
	    NavigationUtility.EVENT_BUS.addHandler(EvaluationEvent.TYPE, new EvaluationEventHandler(){
            public void onEvent(EvaluationEvent event) {
            	switch (event.getActionType()) {
                case EVAL_SUBMIT:
                	selectionModel.setSelected(selectionModel.getSelectedObject(), false);
                	etf.setVisible(false);
                	edtf.setVisible(false);
  	        	    tablePanel.setVisible(true);
                	table.setVisibleRangeAndClearData(table.getVisibleRange(), true); 
                    break;
                case EVAL_CANCEL:
                	selectionModel.setSelected(selectionModel.getSelectedObject(), false);
                	etf.setVisible(false);
                	edtf.setVisible(false);
  	        	    tablePanel.setVisible(true);
                    break;
                case EVAL_CLOSE:
                	selectionModel.setSelected(selectionModel.getSelectedObject(), false);
                	etf.setVisible(false);  
                	edtf.setVisible(false);
  	        	    tablePanel.setVisible(true);
                	break;
            	}
            }
        });
	    
	    int cwid = Window.getClientWidth()-202; // 200 is the Navigation-Form width.
	    myMainPnl.setWidth((Integer.toString(cwid)+"px"));
	    ftable.setWidget(0, 0, myMainPnl);
		
	}
}
