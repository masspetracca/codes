package com.gannon.TaskEvaluation.client.forms;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gannon.TaskEvaluation.client.events.EvaluationEvent;
import com.gannon.TaskEvaluation.client.utils.EvaluationActionTypes;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluation;


public class SubmittedTaskForm extends VerticalPanel{
	
    private Anchor closeLink = new Anchor();
    private Image closeImage = new Image("/images/close.png");

    private Label taskNameLbl = new Label("Task Name :");
    private HorizontalPanel hdr2 = new HorizontalPanel();	
    
	private Label taskPerformerLbl = new Label("Task Performer : ");
    private Label taskPerformerVal = new Label("");
	private HorizontalPanel hdr3 = new HorizontalPanel();
    
	private SingleEvaluatedTaskForm setf = new SingleEvaluatedTaskForm();
	
	public SubmittedTaskForm() {		
		// Use this to set any additional styles.
		this.setStyleName("myEvaluateTaskForm");		
		
		closeImage.setSize("25px", "25px");
		closeLink.getElement().appendChild(closeImage.getElement());
		closeLink.getElement().getStyle().setProperty("cursor", "pointer");

		hdr2.setStyleName("myEvaluteTaskFormHeader2");
		hdr2.setWidth("100%");
		hdr2.setVerticalAlignment(ALIGN_TOP);		
		hdr2.setHorizontalAlignment(ALIGN_LEFT);
		hdr2.add(taskNameLbl);
		hdr2.setHorizontalAlignment(ALIGN_RIGHT);
		hdr2.add(closeLink);
		
		this.setWidth("100%");
		this.setVerticalAlignment(ALIGN_TOP);
		
		this.add(hdr2);
		
		taskPerformerLbl.setStyleName("myTasksFormTaskPerformerLbl");
		taskPerformerVal.setStyleName("myTasksFormTaskPerformerLbl");
		hdr3.add(taskPerformerLbl);
		hdr3.add(taskPerformerVal);
		this.add(hdr3);
		
		this.add(setf);
		
		closeLink.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				NavigationUtility.EVENT_BUS.fireEvent(new EvaluationEvent(EvaluationActionTypes.EVAL_CLOSE));				
			}
		});
	}
	
	public void populateForm(String aTaskId, String aTaskName, String aTaskPerformer){
		taskNameLbl.setText("Task Name :"+aTaskName);
		taskPerformerVal.setText(aTaskPerformer);
	    
	    ServerUtility.myEvaluationRpcService.getSingleTaskEvaluation(NavigationUtility.sessionMemId, aTaskId, new AsyncCallback<SingleTaskEvaluation>() {
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}

			@Override
			public void onSuccess(SingleTaskEvaluation result) {				
				setf.populateForm(result);
			}
		});
	}

}
