package com.gannon.TaskEvaluation.client.forms;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.cell.client.FieldUpdater;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.user.cellview.client.SimplePager;
import com.google.gwt.user.cellview.client.TextColumn;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.AsyncDataProvider;
import com.google.gwt.view.client.HasData;
import com.gannon.TaskEvaluation.client.widgets.MyCellTable;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluation;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluationDTO;


public class SingleEvaluatedTaskForm extends VerticalPanel{
	
	private MyCellTable<SingleTaskEvaluationDTO> table = new MyCellTable<SingleTaskEvaluationDTO>();
	
	// Create a pager for the celltable to add pagination.
	private SimplePager pager = null;
	
	List<SingleTaskEvaluationDTO> list = new ArrayList<SingleTaskEvaluationDTO>();
	
	public SingleEvaluatedTaskForm( ) {		
		
		this.setWidth("100%");
		this.setVerticalAlignment(ALIGN_TOP);
	    
	    // Add a text column to show Criteria.
        TextColumn<SingleTaskEvaluationDTO> criteriaColumn = new TextColumn<SingleTaskEvaluationDTO>() {
           @Override
           public String getValue(SingleTaskEvaluationDTO object) {
              return object.getCriteria();
           }
        };
	    table.addColumn(criteriaColumn, "Criteria");
	    table.setColumnWidth(criteriaColumn, 14.0, Unit.EM);
	    
	    // Add a text column to show the Weightage.
	    TextColumn<SingleTaskEvaluationDTO> weightageColumn = new TextColumn<SingleTaskEvaluationDTO>() {
	    	@Override
	    	public String getValue(SingleTaskEvaluationDTO object) {
	    		return Integer.toString(object.getWieghtage());
	    	}
	    };
	    table.addColumn(weightageColumn, "Weightage");
	    table.setColumnWidth(weightageColumn, 5.0, Unit.EM);
	    
	    // Allow user to evaluations.
	    TextColumn<SingleTaskEvaluationDTO> evalColumn = new TextColumn<SingleTaskEvaluationDTO>() {
	    	@Override
	    	public String getValue(SingleTaskEvaluationDTO object) {
	    		return Double.toString(object.getGradeValue());
	    	}
	    };
	    table.addColumn(evalColumn, "Scores/10");
	    table.setColumnWidth(evalColumn, 5.0, Unit.EM);
	    
	    // Add a text column to show the Description.
	    TextColumn<SingleTaskEvaluationDTO> commentsColumn = new TextColumn<SingleTaskEvaluationDTO>() {
	    	@Override
	    	public String getValue(SingleTaskEvaluationDTO object) {
	    		return object.getComment();
	    	}
	    };
	    commentsColumn.setFieldUpdater(new FieldUpdater<SingleTaskEvaluationDTO, String>() {
	    	@Override
	        public void update(final int index, final SingleTaskEvaluationDTO c, String value) 
	        {
	    		list.get(index).setComment(value);
	        }
	    });	    
	    table.addColumn(commentsColumn, "Comments");
	    table.setColumnWidth(commentsColumn, 30.6, Unit.EM);

	    ////// Define Asynchronous Data provider.
	    AsyncDataProvider<SingleTaskEvaluationDTO> provider = new AsyncDataProvider<SingleTaskEvaluationDTO>() {
			@Override
			protected void onRangeChanged(HasData<SingleTaskEvaluationDTO> display) {
		        final int start = display.getVisibleRange().getStart();
			    final int end = start + display.getVisibleRange().getLength();

				int newEnd = end >= list.size() ? list.size() : end;
				List<SingleTaskEvaluationDTO> sub = list.subList(start, newEnd);
		        updateRowCount(list.size(), false);
		        updateRowData(start, sub);		
			}
	    };
	    provider.addDataDisplay(table);
	    
	    pager = new SimplePager() {
	    	@Override
	    	public boolean hasNextPage() {
	    		if(this.getPage()<(this.getPageCount()-1)) {
	    			return true;
	    		}
	    		return false;
	    	}
	    };
	    //ASH keep loading indicator, because it is guarantee that data is present.
	    //table.setRowCount(0, true);
		    
	    // Add table display to pager.
	    pager.setDisplay(table);
	    pager.setStyleName("myPager");
	    pager.getElement().getStyle().setProperty("paddingBottom", "15px");
	    
	    pager.setPageSize(5); // Display 5 items at a time

	    this.setHorizontalAlignment(ALIGN_LEFT);
	    this.add(table); 		
	    this.setHorizontalAlignment(ALIGN_CENTER);     
	    this.add(pager);

	}
	
	public void populateForm(SingleTaskEvaluation result){
		list = SingleTaskEvaluationDTO.getSingleEvalDTOs(result);
		table.setVisibleRangeAndClearData(table.getVisibleRange(), true);
	}
	
}
