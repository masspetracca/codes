package com.gannon.TaskEvaluation.client.forms;

import java.util.Arrays;
import java.util.List;

import com.google.gwt.cell.client.AbstractCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.safehtml.shared.SafeHtmlUtils;
import com.google.gwt.user.cellview.client.CellList;
import com.google.gwt.user.cellview.client.CellList.Style;
import com.google.gwt.user.cellview.client.HasKeyboardSelectionPolicy.KeyboardSelectionPolicy;
import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.History;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.SelectionChangeEvent;
import com.google.gwt.view.client.SingleSelectionModel;
import com.gannon.TaskEvaluation.client.events.NavigationEvent;
import com.gannon.TaskEvaluation.client.utils.ActionTypes;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;

public class Navigation extends VerticalPanel{
	
	// A panel to keep the Actions label and icon.
	HorizontalPanel actionPanel = new HorizontalPanel();
	HorizontalPanel actionPanel2 = new HorizontalPanel();
	HorizontalPanel actionPanel3 = new HorizontalPanel();

	// Define Actions class, each action has a string, icon and Action type.
	private static class Actions {
	      private Label name = new Label();
	      private Image img = new Image();
	      private ActionTypes action;
	     
	      

	      public Actions(String aName, String aUrl, ActionTypes aAction) {
	         this.name.setText(aName);
	         this.name.setStyleName("myActionTypeLabel");
	         this.img.setUrl(aUrl);
	         this.img.setStyleName("myActionsTypeIcon");
	         this.action = aAction;
	      }
	  
	      
	      
	      public String ActionName(){
	    	  return name.getText();
	      }
	}
	
	private static class ActionCell extends AbstractCell<Actions> {
		@Override
		public void render(com.google.gwt.cell.client.Cell.Context context,
				Actions value, SafeHtmlBuilder sb) {
			if (value != null) {
				sb.appendHtmlConstant("<div class='myNavigationActionCell'>");
				sb.appendHtmlConstant("<table width='100%'>");
			    sb.appendHtmlConstant("<tr><td rowspan='1'>");
				SafeHtml nameHtml = SafeHtmlUtils.fromTrustedString(value.name.toString());
				sb.append(nameHtml);
	            //sb.appendEscaped(value.name);
				sb.appendHtmlConstant("</td><td align='right'>");
	            SafeHtml imgHtml = SafeHtmlUtils.fromTrustedString(value.img.toString());
	            sb.append(imgHtml);
	            sb.appendHtmlConstant("</td></tr>");
	            sb.appendHtmlConstant("</table>");
	            sb.appendHtmlConstant("</div>");


	         }			
		}
	}
	
	private static class ActionCell2 extends AbstractCell<Actions> {
		@Override
		public void render(com.google.gwt.cell.client.Cell.Context context,
				Actions value, SafeHtmlBuilder sb) {
			if (value != null) {
				sb.appendHtmlConstant("<div class='myNavigationActionCell'>");
				sb.appendHtmlConstant("<table width='100%'>");
			    sb.appendHtmlConstant("<tr><td rowspan='1'>");
				SafeHtml nameHtml = SafeHtmlUtils.fromTrustedString(value.name.toString());
				sb.append(nameHtml);
	            //sb.appendEscaped(value.name);
				sb.appendHtmlConstant("</td><td align='right'>");
	            SafeHtml imgHtml = SafeHtmlUtils.fromTrustedString(value.img.toString());
	            sb.append(imgHtml);
	            sb.appendHtmlConstant("</td></tr>");
	            sb.appendHtmlConstant("</table>");
	            sb.appendHtmlConstant("</div>");

	         }			
		}
	}
	
	private static class ActionCell3 extends AbstractCell<Actions> {
		@Override
		public void render(com.google.gwt.cell.client.Cell.Context context,
				Actions value, SafeHtmlBuilder sb) {
			if (value != null) {
				sb.appendHtmlConstant("<div class='myNavigationActionCell'>");
				sb.appendHtmlConstant("<table width='100%'>");
			    sb.appendHtmlConstant("<tr><td rowspan='1'>");
				SafeHtml nameHtml = SafeHtmlUtils.fromTrustedString(value.name.toString());
				sb.append(nameHtml);
	            //sb.appendEscaped(value.name);
				sb.appendHtmlConstant("</td><td align='right'>");
	            SafeHtml imgHtml = SafeHtmlUtils.fromTrustedString(value.img.toString());
	            sb.append(imgHtml);
	            sb.appendHtmlConstant("</td></tr>");
	            sb.appendHtmlConstant("</table>");
	            sb.appendHtmlConstant("</div>");

	         }			
		}
	}
	
	
	
	
	private static final List<Actions> ACTIONS = Arrays.asList(
		      new Actions("Waiting Tasks", "images/tasks.png", ActionTypes.EVALUATION),
		      new Actions("Finished Tasks", "images/Contacts.png", ActionTypes.FINISHED_TASKS) );

	 List<Actions> ACTIONS2 = Arrays.asList(
		      new Actions("Reports", "images/tasks.png", ActionTypes.TASKS) );
	
	 List<Actions> ACTIONS3 = Arrays.asList(
		      new Actions("Create Task", "images/tasks.png", ActionTypes.CREATE_TASK),
		      new Actions("Manage Task", "images/tasks.png", ActionTypes.TASKS),
		      new Actions("Create Template", "images/tasks.png", ActionTypes.TEMPLATES),
		      new Actions("Task Report", "images/tasks.png", ActionTypes.FINISHED_TASKS)
			 );
	
	
	// Navigation pane mainly consists of a CellList, whose default css we have to override.
	interface MyCellListResources extends CellList.Resources {
	    @Source({"../css/CellList.css"})
	    @Override
	    public Style cellListStyle();
	  }
	
	CellList<Actions> cellList = new CellList<Actions>(new ActionCell(),
						GWT.<MyCellListResources> create(MyCellListResources.class));
	
	CellList<Actions> cellList2 = new CellList<Actions>(new ActionCell2(),
			GWT.<MyCellListResources> create(MyCellListResources.class));
	
	CellList<Actions> cellList3 = new CellList<Actions>(new ActionCell3(),
			GWT.<MyCellListResources> create(MyCellListResources.class));
	
	
	
	public Navigation() {
		this.setStyleName("myNavigationPanel");

		////////////////////////////////////////////////////////////////////////////
		// Keep the Actions Label and it's Icon
		actionPanel.setStyleName("myNavigationActionPanel");
		Label actionsLbl = new Label("Evaluator");
		actionsLbl.setStyleName("myActionLabel");
		actionPanel.add(actionsLbl);
		actionPanel.setCellHorizontalAlignment(actionsLbl, ALIGN_CENTER);
		
		this.add(actionPanel);
		////////////////////////////////////////////////////////////////////////////

		////////////////////////////////////////////////////////////////////////////
		// Now add the Cell list.		
		// Do not want the user to select using Keyboard.
	    cellList.setKeyboardSelectionPolicy(KeyboardSelectionPolicy.DISABLED);

	    // Define Cell list click/selection handler
	    final SingleSelectionModel<Actions> selectionModel = new SingleSelectionModel<Actions>();
	    cellList.setSelectionModel(selectionModel);
	    selectionModel.addSelectionChangeHandler(new SelectionChangeEvent.Handler() {
	      public void onSelectionChange(SelectionChangeEvent event) {
	        Actions selected = selectionModel.getSelectedObject();
	        if (selected != null) {
	        	// Fire the navigation event to do further action.	
	        	NavigationUtility.EVENT_BUS.fireEvent(new NavigationEvent(selected.action));
	        	
	        	// Add history support, this calls the value change handler for the history.
	        	History.newItem("pageIndex" + selected.ActionName());
	        }
	      }
	    });
	    cellList2.setKeyboardSelectionPolicy(KeyboardSelectionPolicy.DISABLED);
	    cellList3.setKeyboardSelectionPolicy(KeyboardSelectionPolicy.DISABLED);
	    cellList2.setSelectionModel(selectionModel);
	    cellList3.setSelectionModel(selectionModel);
	    
	    // Default selected will be tasks form, so update history and select it.
	    History.newItem("pageIndex" + "Waiting Tasks");
	    selectionModel.setSelected(ACTIONS.get(0), true);
	    
	    History.addValueChangeHandler(new ValueChangeHandler<String>() {
			@Override
			public void onValueChange(ValueChangeEvent<String> event) {
				String historyToken = event.getValue();
	            // parse the history token, it should at-least have pageIndex	
				
				if( (historyToken.length() > 9) && (historyToken.substring(0, 9).equals("pageIndex")) ) { 				
		            try {		     
		                  String tabIndexToken = historyToken.substring(9);

		                  ActionTypes historyAction = ActionTypes.EVALUATION;
		                  if(tabIndexToken.equalsIgnoreCase("Waiting Tasks")){
		                	  historyAction = ActionTypes.EVALUATION;
		                	  selectionModel.setSelected(ACTIONS.get(0), true);
		                  }
		                  else if(tabIndexToken.equalsIgnoreCase("Finished Tasks")){
		                	  historyAction = ActionTypes.FINISHED_TASKS;
		                	  selectionModel.setSelected(ACTIONS.get(1), true);
		                  }
		                  else if(tabIndexToken.equalsIgnoreCase("Reports")){
		                	  historyAction = ActionTypes.FINISHED_TASKS;
		                	  selectionModel.setSelected(ACTIONS2.get(0), true);
		                  }
		                  else if(tabIndexToken.equalsIgnoreCase("Create Task")){
		                	  historyAction = ActionTypes.CREATE_TASK;
		                	  selectionModel.setSelected(ACTIONS3.get(0), true);
		                	  
		                  }
		                  else if(tabIndexToken.equalsIgnoreCase("Create Template")){
		                	  historyAction = ActionTypes.TEMPLATES;
		                	  selectionModel.setSelected(ACTIONS3.get(2), true);
		                  }
		                  else if(tabIndexToken.equalsIgnoreCase("Manage Task")){
		                	  historyAction = ActionTypes.TASKS;
		                	  selectionModel.setSelected(ACTIONS3.get(1), true);
		                  }
		                  else if(tabIndexToken.equalsIgnoreCase("Task Report")){
		                	  historyAction = ActionTypes.FINISHED_TASKS;
		                	  selectionModel.setSelected(ACTIONS3.get(3), true);
		                  }
		                  else {// if(tabIndexToken.equalsIgnoreCase("Settings")){
		                	  historyAction = ActionTypes.EVALUATION;
		                	  selectionModel.setSelected(ACTIONS.get(0), true);
		                  }
		                  
		                  NavigationUtility.EVENT_BUS.fireEvent(new NavigationEvent(historyAction));
		            } catch (IndexOutOfBoundsException e) { }
				}
				
			}
	    });
	 
	    // Add cookies on Browser refresh....
	    Window.addWindowClosingHandler(new Window.ClosingHandler() {
	        public void onWindowClosing(Window.ClosingEvent closingEvent) {
				if ("".equals(History.getToken())) {
					// Some how there is no history let it take back to home page.
					// Effectively we have logged off this user.
				}
				else {					
					Cookies.setCookie("UID", NavigationUtility.sessionMemId);
					Cookies.setCookie("FNAME", NavigationUtility.sessionFirstName);
					Cookies.setCookie("LNAME", NavigationUtility.sessionLastName);
					Cookies.setCookie("EMAIL", NavigationUtility.sessionEmail);
					Cookies.setCookie("GOOGLELOGIN", String.valueOf(NavigationUtility.isGoogleLogin));
				}
	        }
	    });
	    
	    cellList.setRowCount(ACTIONS.size(), true);

	    // Push the data into the widget.
	    cellList.setRowData(0, ACTIONS);

	    // Add it to the panel.
	    this.add(cellList);

	 
	   
	    
	    actionPanel2.setStyleName("myNavigationActionPanel");
	    Label actionsLbl2 = new Label("Performer");
		actionsLbl2.setStyleName("myActionLabel");
		
		actionPanel2.add(actionsLbl2);
		actionPanel2.setCellHorizontalAlignment(actionsLbl2, ALIGN_CENTER);
		this.add(actionPanel2);
		
	
		 cellList2.setRowCount(ACTIONS2.size(), true);

		    // Push the data into the widget.
		    cellList2.setRowData(0, ACTIONS2);

		    // Add it to the panel.
		    this.add(cellList2);
		    
		    actionPanel3.setStyleName("myNavigationActionPanel");
		    Label actionsLbl3 = new Label("Manager");
			actionsLbl3.setStyleName("myActionLabel");
			
			actionPanel3.add(actionsLbl3);
			actionPanel3.setCellHorizontalAlignment(actionsLbl3, ALIGN_CENTER);
			this.add(actionPanel3);
			
		
			 
			 cellList3.setRowCount(ACTIONS3.size(), true);

			    // Push the data into the widget.
			    cellList3.setRowData(0, ACTIONS3);

			    // Add it to the panel.
			    this.add(cellList3);

	}
	
	

}
