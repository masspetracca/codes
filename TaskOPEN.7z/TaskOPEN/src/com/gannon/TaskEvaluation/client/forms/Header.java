package com.gannon.TaskEvaluation.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.Widget;
import com.gannon.TaskEvaluation.client.widgets.UserStatus;

public class Header extends ResizeComposite{

	private static HeaderUiBinder uiBinder = GWT.create(HeaderUiBinder.class);

	interface HeaderUiBinder extends UiBinder<Widget, Header> {
	}

	public Header() {
		initWidget(uiBinder.createAndBindUi(this));
	}

	@UiField Label l1;
	@UiField UserStatus us;
}

/*
 HorizontalPanel mainPanel = new HorizontalPanel();
	
	VerticalPanel p1 = new VerticalPanel();
	VerticalPanel p2 = new VerticalPanel();
	
	Label l1 = new Label("Task Evaluation");
	private UserStatus us = new UserStatus();
	
	public Header() {
		initWidget(mainPanel);		
		this.setStyleName("myTempHeader");
		
		mainPanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);
		
		p1.setStyleName("myTempHeaderPan1");	
		p1.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		p1.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);

		p2.setStyleName("myTempHeaderPan2");
		p2.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		p2.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);

		l1.setStyleName("myTaskEvaluationLbl");
		p1.add(l1);
		p2.add(us);
	
		mainPanel.add(p1);
		mainPanel.add(p2);		
	}
	
*/
