package com.gannon.TaskEvaluation.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.gannon.TaskEvaluation.client.forms.CenterPanel;
import com.gannon.TaskEvaluation.client.forms.Header;
import com.gannon.TaskEvaluation.client.forms.Navigation;

public class MainLayout extends ResizeComposite{

	private static MainLayoutUiBinder uiBinder = GWT
			.create(MainLayoutUiBinder.class);

	interface MainLayoutUiBinder extends UiBinder<DockLayoutPanel, MainLayout> {
	}

	public MainLayout() {
		initWidget(uiBinder.createAndBindUi(this));
	}
	
	@UiField Header hdr;
	@UiField Navigation nav;
	@UiField CenterPanel body;

}
