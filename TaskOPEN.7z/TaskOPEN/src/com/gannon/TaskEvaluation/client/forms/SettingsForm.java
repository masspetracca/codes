package com.gannon.TaskEvaluation.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.StackPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;
import com.gannon.TaskEvaluation.client.forms.ChangeOtherDetailsForm;
import com.gannon.TaskEvaluation.client.forms.ChangePasswordForm;
import com.gannon.TaskEvaluation.client.forms.DeleteUserForm;

public class SettingsForm extends ResizeComposite{

	private static SettingsFormUiBinder uiBinder = GWT
			.create(SettingsFormUiBinder.class);

	interface SettingsFormUiBinder extends UiBinder<Widget, SettingsForm> {
	}
	
	private Label myHeaderLbl = new Label("Change Account Settings");
	private HorizontalPanel headerPanel = new HorizontalPanel();
	private StackPanel p = new StackPanel();
	private ChangePasswordForm cpf = new ChangePasswordForm();
	private ChangeOtherDetailsForm codf = new ChangeOtherDetailsForm();
	private DeleteUserForm duf = new DeleteUserForm();


	@UiField FlexTable ftable;
	private VerticalPanel myPnl = new VerticalPanel();
	
	public SettingsForm() {
		initWidget(uiBinder.createAndBindUi(this));
		
		// All the widgets must be to the top of the page.
		myPnl.setVerticalAlignment(HasVerticalAlignment.ALIGN_TOP);
			
		headerPanel.setStyleName("myTasksFormHeaderPanel");
		headerPanel.setWidth("100%");
		headerPanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);
		myHeaderLbl.setStyleName("myTasksFormMyTasksLbl");
		headerPanel.add(myHeaderLbl);
		
		myPnl.add(headerPanel);
		
		p.setWidth("100%");
		
		p.add(codf, "Change User Name");
		p.add(cpf, "Change Password");
		p.add(duf, "Delete My Account");
		
		myPnl.add(p);
		
		int cwid = Window.getClientWidth()-202; // 200 is the Navigation-Form width.
		myPnl.setWidth((Integer.toString(cwid)+"px"));
		ftable.setWidget(0, 0, myPnl);
	}

}
