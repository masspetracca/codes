package com.gannon.TaskEvaluation.client;

import com.gannon.TaskEvaluation.shared.Member;
import com.google.gwt.user.client.rpc.AsyncCallback;

public interface GoogleLoginServiceAsync {
	void loginDetails(String token, AsyncCallback<Member> asyncCallback);
}
