package com.gannon.TaskEvaluation.client;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.gannon.TaskEvaluation.shared.Template;

@RemoteServiceRelativePath("template")
public interface TemplateService extends RemoteService {
	
	List<Template> returnAllPublicTemplates();
	
	Template createTemplate(String name, String aMemberId, List<String> crit,
			List<Integer> weigh, List<String> criteriaDescription, Boolean publicTemplate);
	
	Template editTemplate(String aTemplateId, String name, List<String> crit,
			List<Integer> weigh, List<String> criteriaDescription, Boolean publicTemplate);
	
	Boolean deleteTemplate(String aTemplateId);
	
	void removeTemplateRow(String templateKey, Integer rowNum);
	
	void addTemplateRow(String templateKey, String crit,
			Integer weigh, String description);
	
	void editTemplateRow(String templateKey, Integer rowNum,
			String crit, Integer weigh, String description);
	
	Template getTemplateById(String aTemplateId);
	
}