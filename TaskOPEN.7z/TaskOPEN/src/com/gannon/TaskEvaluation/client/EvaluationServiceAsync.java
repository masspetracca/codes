package com.gannon.TaskEvaluation.client;

import java.util.List;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluation;
import com.gannon.TaskEvaluation.shared.SingleTaskEvaluationDTO;

public interface EvaluationServiceAsync {

	void getEvaluationsOfMyTask(String aTaskId,
			AsyncCallback<List<SingleTaskEvaluation>> callback);

	void saveSingleEvaluation(String aTaskId, String aMemberId,
			List<SingleTaskEvaluationDTO> aEvalDTOs,
			AsyncCallback<SingleTaskEvaluation> callback);

	void getSingleTaskEvaluation(String aMemberId, String aTaskId,
			AsyncCallback<SingleTaskEvaluation> callback);

	void sendEmail(String from, List<String> to, String subject,
			String message, AsyncCallback<String> callback);

}
