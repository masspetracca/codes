package com.gannon.TaskEvaluation.client.prelogin;

import com.gannon.TaskEvaluation.client.events.PreLoginEvent;
import com.gannon.TaskEvaluation.client.events.handlers.PreLoginEventHandler;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.PreLoginActions;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.client.utils.TextBoxValidator;
import com.gannon.TaskEvaluation.client.utils.TextBoxValidator.TextFieldType;
import com.gannon.TaskEvaluation.client.widgets.ConfirmationDialog;
import com.gannon.TaskEvaluation.client.widgets.MyTextBox;
import com.google.api.gwt.oauth2.client.Auth;
import com.google.api.gwt.oauth2.client.AuthRequest;
import com.google.gwt.core.client.Callback;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyDownHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.FocusPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.Widget;
import com.gannon.TaskEvaluation.client.suggest.PopUpCallBackInterface;
import com.gannon.TaskEvaluation.shared.Member;

public class LoginForm extends ResizeComposite implements PopUpCallBackInterface{

	private static LoginFormUiBinder uiBinder = GWT
			.create(LoginFormUiBinder.class);

	interface LoginFormUiBinder extends UiBinder<Widget, LoginForm> {
	}
	
	@UiField Image taskEvalSystemImg;
	@UiField Label signInLbl;
    @UiField Label loginLbl;
    
    private Label emailLbl;
    private Label passwordLbl;
    private MyTextBox emailBox;
    private MyTextBox passwordBox;
    private Button loginBtn;
    private Anchor forgotPassLink;
    
    private FocusPanel focForm;
    @UiField FlexTable form;
    
    @UiField Image googleLoginImg;
    
    @UiField Label needAccountLbl; 
    @UiField Anchor registerLink;
    
    //
    // Google Account Login Support constants
    //
    private static final Auth AUTH = Auth.get();
	private static final String GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/auth";
	private static final String GOOGLE_CLIENT_ID = "37128548832-nv8tnj2t3jk8iovoe77brq3tfaffnbju.apps.googleusercontent.com";
	private static final String PLUS_ME_SCOPE = "https://www.googleapis.com/auth/userinfo.email";
	//

	public LoginForm() {
		initWidget(uiBinder.createAndBindUi(this));
		
		emailLbl = new Label("EMAIL ADDRESS");
	    passwordLbl = new Label("PASSWORD");
	    emailBox = new MyTextBox();
	    passwordBox = new MyTextBox();
	    emailLbl.setStyleName("myPreLoginLabel");
	    passwordLbl.setStyleName("myPreLoginLabel");
	    emailBox.setStyleName("myPreLoginTextBox");
	    passwordBox.setStyleName("myPreLoginTextBox");
	    passwordBox.getElement().setAttribute("type", "password");
	    
	    loginBtn = new Button("Login");
	    loginBtn.setSize("100px", "35px");
	    loginBtn.setStyleName("myLoginFormLoginBtn");
	    
	    forgotPassLink = new Anchor("Forgot password?");
	    
	    focForm = new FocusPanel(this);
	    focForm.addKeyDownHandler(new KeyDownHandler() {
		       @Override
		       public void onKeyDown(KeyDownEvent event) {
		    	   if(event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {
		    		   loginBtn.click();
			       }
		       }
		});
	    
	    loginBtn.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				validateAndLogin();				
			}
	    });
	    
	    loginBtn.setFocus(true);
	    
	    initFlexTable();
	    
	    // Handle Pre-Login Navigation events, Pre-Login means before the Member is logged in.
	    NavigationUtility.EVENT_BUS.addHandler(PreLoginEvent.TYPE, new PreLoginEventHandler(){
            public void onEvent(PreLoginEvent event) {
            	switch (event.getActionType()) {
                case GOOGLE_LOGIN_CLICKED:
                		addGoogleAuthHelper();
                        break;
				default:
					break;
            	}
            }
        });	    

	}
	
	public void clearForm() {
		loginBtn.setEnabled(true);
		googleLoginImg.getElement().getStyle().setProperty("cursor", "pointer");
		loginBtn.getElement().getStyle().setProperty("cursor", "pointer");
	}
    
    
    @UiHandler("taskEvalSystemImg")
    public void onTaskEvalSystemImgClick(ClickEvent event) {
		NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.PRE_HOME));				
	}
    
    @UiHandler("registerLink")
	public void onRegisterLinkClick(ClickEvent event) {
		NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.PRE_REGISTER));				
	}

    public void initFlexTable()
    {
    	form.setWidget(0, 0, emailLbl);
	    form.setWidget(1, 0, emailBox);
	    form.getFlexCellFormatter().setColSpan(1, 0, 2);
	    form.setWidget(2, 0, passwordLbl);
	    form.setWidget(3, 0, passwordBox);
	    form.getFlexCellFormatter().setColSpan(3, 0, 2);
	    form.setWidget(4, 0, loginBtn);
	    form.setWidget(4, 1, forgotPassLink);	    
    }
    
    public void validateAndLogin() {
		String errorMsgs="";
		
		TextBoxValidator val = new TextBoxValidator(TextFieldType.EMAIL);
		emailBox.addValidator(val);
		if( !emailBox.validate() ) {
			errorMsgs+="Please Enter a Valid Email ID";
		}
			
		TextBoxValidator pVal = new TextBoxValidator(emailBox.getText(),TextFieldType.LOGIN_PASSWORD);
		passwordBox.addValidator(pVal);
		if( !passwordBox.validate() ) {
			if(!errorMsgs.isEmpty()){
				errorMsgs+="<br>";
			}
			errorMsgs+="Please Enter a Valid Password";
		}
		
		if(!errorMsgs.trim().isEmpty()){
			errorMsgs = "<font color='red'>" + errorMsgs + "</font>";
			ConfirmationDialog cnf = new ConfirmationDialog();
			cnf.confirm("Error", errorMsgs,true , this);
			return;
		}
		
		// Client Side validation successful, do server validation.
		loginBtn.setEnabled(false);
		ServerUtility.myMemberRpcService.isMember(emailBox.getText(), passwordBox.getText(), 
			new AsyncCallback<Member>() {
				
			@Override
			public void onSuccess(Member result) {
				//loginBtn.setEnabled(true);
				if( result != null) {
					NavigationUtility.sessionMemId = result.objectId();
					NavigationUtility.sessionFirstName = result.getMemberFirstName();
					NavigationUtility.sessionLastName = result.getMemberLastName();
					NavigationUtility.sessionEmail = result.getMemberEmail();
					NavigationUtility.isGoogleLogin = false;
					NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.LOGIN_SUCCESS));
				}
				else {
					showLoginErrorDialog();
				}
			}
			
			@Override
			public void onFailure(Throwable caught) {
				loginBtn.setEnabled(true);				
			}
		});
	}
	
	public void showLoginErrorDialog(){
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirm("Login Error", "Invalid Email or Password", true, this);
	}

	@Override
	public void confirmCancel(Boolean aConfirm) {
		loginBtn.setEnabled(true);		
	}

	@Override
	public void confirm() {
		loginBtn.setEnabled(true);		
	}  
	
	//
	//// GOOGLE ACCOUNT LOGIN
	//
	@UiHandler("googleLoginImg")
    public void onGoogleLoginImgClick(ClickEvent event) {
		// Change cursor property to wait on the buttons, so user cannot click them.
		googleLoginImg.getElement().getStyle().setProperty("cursor", "wait");
		loginBtn.getElement().getStyle().setProperty("cursor", "wait");
		
		// Start Google Authentication.
		addGoogleAuthHelper();
	}	
	
	private void addGoogleAuthHelper() {
		final AuthRequest req = new AuthRequest(GOOGLE_AUTH_URL, GOOGLE_CLIENT_ID).withScopes(PLUS_ME_SCOPE);
		
		AUTH.login(req, new Callback<String, Throwable>() {
			@Override
			public void onSuccess(final String token) {
				if (!token.isEmpty()) {
					ServerUtility.myGoogleLoginRpcService.loginDetails(token, new AsyncCallback<Member>() {
						@Override
						public void onFailure(final Throwable caught) {
							GWT.log("loginDetails -> onFailure");
						}
						
						@Override
						public void onSuccess(final Member result) {
							NavigationUtility.sessionMemId = result.objectId();
							NavigationUtility.sessionEmail = result.getMemberEmail();
							NavigationUtility.isGoogleLogin = true;
							if (result.getMemberFirstName() != null && !result.getMemberFirstName().isEmpty()) {
								NavigationUtility.sessionFirstName = result.getMemberFirstName();
								NavigationUtility.sessionLastName = result.getMemberLastName();
							}
							else {
								// Sometimes google account holders might not set their display names yet.
								NavigationUtility.sessionFirstName = result.getMemberEmail();
								NavigationUtility.sessionLastName = "";
							}
							
							NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.LOGIN_SUCCESS));
						}
					});
				}
			}
			@Override
			public void onFailure(final Throwable caught) {
				GWT.log("Error -> loginDetails\n" + caught.getMessage());
			}
		});
	}
	
    
}

