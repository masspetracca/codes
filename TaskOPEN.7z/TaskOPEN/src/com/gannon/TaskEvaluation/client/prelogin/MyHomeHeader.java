package com.gannon.TaskEvaluation.client.prelogin;

import com.gannon.TaskEvaluation.client.widgets.ImageAnchor;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.user.client.ui.Anchor;
import com.gannon.TaskEvaluation.client.events.PreLoginEvent;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.PreLoginActions;

public class MyHomeHeader extends Composite {

	private static MyHomeHeaderUiBinder uiBinder = GWT
			.create(MyHomeHeaderUiBinder.class);

	interface MyHomeHeaderUiBinder extends UiBinder<Widget, MyHomeHeader> {
	}

	public MyHomeHeader() {
		initWidget(uiBinder.createAndBindUi(this));
	}

	@UiField ImageAnchor taskEvalSystemLink;    
	@UiField Anchor homeLink;
	@UiField Anchor supportLink;
	@UiField Anchor loginLink;
	@UiField Anchor registerLink;

	@UiHandler("supportLink")
	void onsupportClick(ClickEvent event) {
		NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.PRE_SUPPORT));				
	}

	@UiHandler("loginLink")
	void onloginClick(ClickEvent event) {
		NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.PRE_LOGIN));				
	}

	@UiHandler("registerLink")
	void onregisterClick(ClickEvent event) {
		NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.PRE_REGISTER));				
	}

}

