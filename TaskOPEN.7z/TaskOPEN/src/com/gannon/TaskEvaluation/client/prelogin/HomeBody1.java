package com.gannon.TaskEvaluation.client.prelogin;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;
import com.gannon.TaskEvaluation.client.events.PreLoginEvent;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.PreLoginActions;

public class HomeBody1 extends Composite{

	private static HomeBody1UiBinder uiBinder = GWT
			.create(HomeBody1UiBinder.class);

	interface HomeBody1UiBinder extends UiBinder<Widget, HomeBody1> {
	}

	public HomeBody1() {
		initWidget(uiBinder.createAndBindUi(this));
		
		createIcon = new Image("/images/home_create.png");
		createLbl = new Label("Create a Task");
		createLbl.setStyleName("myHomeBodyLbl");
		
		assignIcon = new Image("/images/home_assign.png");
		assignLbl = new Label("Assign Task to Members");
		assignLbl.setStyleName("myHomeBodyLbl");
		
		evaluateIcon = new Image("/images/home_evaluate.png");
		evaluateLbl = new Label("Evaluate a Task");
		evaluateLbl.setStyleName("myHomeBodyLbl");
		
		templateIcon = new Image("/images/home_template.png");
		templateLbl = new Label("Create Evaluation Templates");
		templateLbl.setStyleName("myHomeBodyLbl");
		
		initTable();
	}
	
	@UiField Label sloganLbl;
	@UiField Label punchLineLbl;
	
	@UiField FlexTable myTable;
	
	@UiField Button loginBtn;
	@UiField Button registerBtn;
	
	private Image createIcon;
	private Label createLbl;
	private Image assignIcon;
	private Label assignLbl;
	private Image evaluateIcon;
	private Label evaluateLbl;
	private Image templateIcon;
	private Label templateLbl;

	@UiHandler("loginBtn")
	public void onLoginClick(ClickEvent event) {
		NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.PRE_LOGIN));				
	}

	@UiHandler("registerBtn")
	public void onRegisterClick(ClickEvent event) {
		NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.PRE_REGISTER));				
	}

	public void initTable()
	{
		myTable.setWidget(0, 0, createIcon);
		myTable.setWidget(0, 1, createLbl);		
		
		myTable.setWidget(1, 0, assignIcon);
		myTable.setWidget(1, 1, assignLbl);		
		
		myTable.setWidget(2, 0, evaluateIcon);
		myTable.setWidget(2, 1, evaluateLbl);		
		
		myTable.setWidget(3, 0, templateIcon);
		myTable.setWidget(3, 1, templateLbl);
	}

}
