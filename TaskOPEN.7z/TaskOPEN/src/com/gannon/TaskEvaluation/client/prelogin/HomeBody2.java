package com.gannon.TaskEvaluation.client.prelogin;

import com.gannon.TaskEvaluation.client.events.PreLoginEvent;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.PreLoginActions;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;

public class HomeBody2 extends Composite{

	private static HomeBody2UiBinder uiBinder = GWT
			.create(HomeBody2UiBinder.class);

	interface HomeBody2UiBinder extends UiBinder<Widget, HomeBody2> {
	}	
	
	@UiField FlexTable myTable;	

	@UiField Label sloganLbl;
	
	private Image createIcon;
	private Label createLbl;
	
	@UiField Image conImg;
	
	@UiField Button loginBtn;
	@UiField Button registerBtn;

	public HomeBody2() {
		initWidget(uiBinder.createAndBindUi(this));
		
		createIcon = new Image("/images/home_contacts.png");
		createLbl = new Label("Add or Remove Contacts");
		createLbl.setStyleName("myHomeBodyLbl");
		
		initTable();
	}

	public void initTable()
	{
		myTable.setWidget(0, 0, createIcon);
		myTable.setWidget(0, 1, createLbl);
	}
	
	@UiHandler("loginBtn")
	public void onLoginClick(ClickEvent event) {
		NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.PRE_LOGIN));				
	}
	
	@UiHandler("registerBtn")
	public void onRegisterClick(ClickEvent event) {
		NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.PRE_REGISTER));				
	}

}
