package com.gannon.TaskEvaluation.client.prelogin;

import com.gannon.TaskEvaluation.client.utils.FadeAnimation;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.ResizeComposite;

public class MyHomeSlideShow extends ResizeComposite {

	private static MyHomeSlideShowUiBinder uiBinder = GWT
			.create(MyHomeSlideShowUiBinder.class);

	interface MyHomeSlideShowUiBinder extends UiBinder<DockLayoutPanel, MyHomeSlideShow> {
	}

	public enum HomeBodyTypes {
    	HB1,
    	HB2
    }
	
	public MyHomeSlideShow() {
		initWidget(uiBinder.createAndBindUi(this));
		this.setStyleName("myHomeSlideShow");
	
		// This is the first time this page is opened remove hb2, so only hb1 is displayed.
	  	hb2.removeFromParent();
		element = HomeBodyTypes.HB1;

	}

	@UiField Image leftLink;
	@UiField Image rightLink;
	@UiField HomeBody1 hb1;
	@UiField HomeBody2 hb2;
	
	HomeBodyTypes element;

	@UiHandler("leftLink")
	void onLeftLinkClick(ClickEvent e) {
		
		switch (element) {
        case HB1:
        	FadeAnimation fadeAnimation = new FadeAnimation (hb2, 1.0);
        	fadeAnimation.fade(1200);
        	// Ashwin run() method seems to work, but no gradual change in opacity look into this later.
      	  	//fadeAnimation.run(400);
      	  	
      	  	HorizontalPanel parent = (HorizontalPanel) hb1.getParent();
      	  	hb1.removeFromParent();
    	  	parent.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
    	  	parent.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
      	  	parent.insert(hb2, 1);
    		element = HomeBodyTypes.HB2;
            break;
        case HB2:
        	FadeAnimation fadeAnimation1 = new FadeAnimation (hb1, 1.0);
      	  	fadeAnimation1.fade(1200);
      	  	
      	  	HorizontalPanel parent1 = (HorizontalPanel) hb2.getParent();
      	  	hb2.removeFromParent();
    	  	parent1.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
    	  	parent1.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
      	  	parent1.insert(hb1, 1);	
    		element = HomeBodyTypes.HB1;
            break;
        
    	}
	}
	
	@UiHandler("rightLink")
	void onRightLinkClick(ClickEvent e) {
		switch (element) {
        case HB1:    	
        	FadeAnimation fadeAnimation = new FadeAnimation (hb2, 1.0);
      	  	fadeAnimation.fade(1200);
      	  	
      	  	HorizontalPanel parent = (HorizontalPanel) hb1.getParent();
      	  	hb1.removeFromParent();
    	  	parent.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
    	  	parent.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
      	  	parent.insert(hb2, 1);
    		element = HomeBodyTypes.HB2;
            break;
        case HB2:
        	FadeAnimation fadeAnimation1 = new FadeAnimation (hb1, 1.0);
      	  	fadeAnimation1.fade(1200);
      	  	
      	  	HorizontalPanel parent1 = (HorizontalPanel) hb2.getParent();
    	  	hb2.removeFromParent();
    	  	parent1.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
    	  	parent1.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
    	  	parent1.insert(hb1, 1);	
    		element = HomeBodyTypes.HB1;
            break;        
    	}
	}

}