package com.gannon.TaskEvaluation.client.prelogin;

import com.gannon.TaskEvaluation.client.events.PreLoginEvent;
import com.gannon.TaskEvaluation.client.suggest.PopUpCallBackInterface;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;
import com.gannon.TaskEvaluation.client.utils.PreLoginActions;
import com.gannon.TaskEvaluation.client.utils.ServerUtility;
import com.gannon.TaskEvaluation.client.utils.TextBoxValidator;
import com.gannon.TaskEvaluation.client.utils.TextBoxValidator.TextFieldType;
import com.gannon.TaskEvaluation.client.widgets.ConfirmationDialog;
import com.gannon.TaskEvaluation.client.widgets.MyTextBox;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.Widget;

public class RegistrationForm extends ResizeComposite implements PopUpCallBackInterface{

	private static RegistrationFormUiBinder uiBinder = GWT
			.create(RegistrationFormUiBinder.class);

	interface RegistrationFormUiBinder extends
			UiBinder<Widget, RegistrationForm> {
	}

	public RegistrationForm() {
		initWidget(uiBinder.createAndBindUi(this));
		
		firstNameLbl = new Label("FIRST NAME");
	    lastNameLbl = new Label("LAST NAME");
	    emailLbl = new Label("EMAIL ADDRESS");
	    passwordLbl = new Label("PASSWORD");
	    firstNameBox = new MyTextBox();
	    lastNameBox = new MyTextBox();
	    emailBox = new MyTextBox();
	    passwordBox = new MyTextBox();
	    firstNameLbl.setStyleName("myPreLoginLabel");
	    lastNameLbl.setStyleName("myPreLoginLabel");
	    emailLbl.setStyleName("myPreLoginLabel");
	    passwordLbl.setStyleName("myPreLoginLabel");
	    firstNameBox.setStyleName("myPreLoginTextBox");
	    lastNameBox.setStyleName("myPreLoginTextBox");
	    emailBox.setStyleName("myPreLoginTextBox");
	    passwordBox.setStyleName("myPreLoginTextBox");
	    passwordBox.getElement().setAttribute("type", "password");
	    
	    continueBtn = new Button("Sign Up");
	    continueBtn.setSize("100px", "35px");
	    continueBtn.setStyleName("myRegistrationFormConBtn");
	    continueBtn.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {					
				validateAndRegister();			
			}
	    });
	    
	    initFlexTable();
	}
	
	@UiField Image taskEvalSystemImg;
	@UiField Label createFreeLbl;
	@UiField Image googleLoginImg;
    
    private Label firstNameLbl;
    private Label lastNameLbl;
    private Label emailLbl;
    private Label passwordLbl;
    private MyTextBox firstNameBox;
    private MyTextBox lastNameBox;
    private MyTextBox emailBox;
    private MyTextBox passwordBox;
    private Button continueBtn;
    @UiField FlexTable form;
    
    public void initFlexTable()
    {    	
    	form.setWidget(0, 0, firstNameLbl);
	    form.setWidget(0, 1, lastNameLbl);
	    form.setWidget(1, 0, firstNameBox);
	    form.setWidget(1, 1, lastNameBox);
	    form.setWidget(2, 0, emailLbl);
	    form.setWidget(2, 1, passwordLbl);
	    form.setWidget(3, 0, emailBox);
	    form.setWidget(3, 1, passwordBox);
	    form.setWidget(4, 0, continueBtn);	    
    }

    @UiHandler("taskEvalSystemImg")
    public void onTaskEvalSystemImgClick(ClickEvent event) {
		NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.PRE_HOME));				
	}
    
    @UiHandler("googleLoginImg")
    public void onGoogleLoginImgClick(ClickEvent event) {
    	// Let LoginForm handle this...
    	googleLoginImg.getElement().getStyle().setProperty("cursor", "wait");
    	NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.GOOGLE_LOGIN_CLICKED));				
	}

	@Override
	public void confirmCancel(Boolean aConfirm) {
		continueBtn.setEnabled(true);		
	}

	@Override
	public void confirm() {
		continueBtn.setEnabled(true);		
	}
	
	public void validateAndRegister(){
		String errorMsgs="";
		
		// First check Email.
		TextBoxValidator val = new TextBoxValidator(TextFieldType.EMAIL);
		emailBox.addValidator(val);
		if( !emailBox.validate() ) {
			errorMsgs+="Please Enter a Valid Email ID";
		}
		
		TextBoxValidator pVal = new TextBoxValidator(emailBox.getText(), TextFieldType.REG_PASSWORD);
		passwordBox.addValidator(pVal);
		firstNameBox.addValidator(pVal);
		lastNameBox.addValidator(pVal);
		
		if( !firstNameBox.validate()  || !lastNameBox.validate() || !passwordBox.validate() ) {
			if(!errorMsgs.isEmpty()){
				errorMsgs+="<br>";
			}
			errorMsgs+="Password, First Name and Last Name should be atleast 3 characters";
		}

		if(!errorMsgs.trim().isEmpty()){
			errorMsgs = "<font color='red'>" + errorMsgs + "</font>";
			ConfirmationDialog cnf = new ConfirmationDialog();
			cnf.confirm("Correct the following errors:", errorMsgs, true, this);
			return;
		}
		
		continueBtn.setEnabled(false);
		
		// Call server to add user into db.
		ServerUtility.myMemberRpcService.createMember(firstNameBox.getText(),
			lastNameBox.getText(), emailBox.getText(), passwordBox.getText(),
			new AsyncCallback<String>() {
					
				@Override
				public void onSuccess(String result) {
					continueBtn.setEnabled(true);					
					if(!result.isEmpty()) {
						showSuccessDialog();							
						// Take the user back to Login page.
						NavigationUtility.EVENT_BUS.fireEvent(new PreLoginEvent(PreLoginActions.PRE_LOGIN));
					}
					else {
						showUserAlreadyExistsDialog();
					}
				}
				
				@Override
				public void onFailure(Throwable caught) {
					Window.alert("Exception, Please Close and Reload the website");								
				}
		});
	}
	
	public void showSuccessDialog(){
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirm("Success !!!", "Please Login with your Email Id", false, this);
	}
	
	public void showUserAlreadyExistsDialog(){
		ConfirmationDialog cnf = new ConfirmationDialog();
		cnf.confirm("Error", "User with same Email Id already exists", true, this);
	}
	
	public void clearForm() {
		firstNameBox.setText("");
	    lastNameBox.setText("");
	    emailBox.setText("");
	    passwordBox.setText("");
	    googleLoginImg.getElement().getStyle().setProperty("cursor", "pointer");
	}
}
