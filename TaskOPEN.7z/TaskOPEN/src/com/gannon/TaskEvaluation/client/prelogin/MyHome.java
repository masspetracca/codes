package com.gannon.TaskEvaluation.client.prelogin;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.DockLayoutPanel;

public class MyHome extends Composite{

	private static MyHomeUiBinder uiBinder = GWT.create(MyHomeUiBinder.class);

	interface MyHomeUiBinder extends UiBinder<DockLayoutPanel, MyHome> {
	}

	@UiField MyHomeHeader header;
	@UiField MyHomeSlideShow slideShow;

	public MyHome() {
		initWidget(uiBinder.createAndBindUi(this));
	}
	
}
