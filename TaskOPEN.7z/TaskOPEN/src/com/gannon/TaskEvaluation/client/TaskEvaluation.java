package com.gannon.TaskEvaluation.client;

import com.gannon.TaskEvaluation.client.prelogin.LoginForm;
import com.gannon.TaskEvaluation.client.prelogin.MyHome;
import com.gannon.TaskEvaluation.client.prelogin.RegistrationForm;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.History;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.RootLayoutPanel;
import com.gannon.TaskEvaluation.client.events.PreLoginEvent;
import com.gannon.TaskEvaluation.client.events.handlers.PreLoginEventHandler;
import com.gannon.TaskEvaluation.client.forms.MainLayout;
import com.gannon.TaskEvaluation.client.utils.NavigationUtility;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class TaskEvaluation implements EntryPoint {
	
	private static TaskEvaluationUiBinder uiBinder = GWT.create(TaskEvaluationUiBinder.class);

	interface TaskEvaluationUiBinder extends UiBinder<DockLayoutPanel, TaskEvaluation> {
	}
	
	private DockLayoutPanel outer;

	// PRE LOGIN
	private MyHome home = new MyHome();
	private LoginForm logForm = new LoginForm();
	private RegistrationForm regForm = new RegistrationForm();
	
	// POST LOGIN
	private MainLayout ml;
	
	public void onModuleLoad() {
		
		// Create the UI defined in TaskEvaluation.ui.xml.
	    outer = uiBinder.createAndBindUi(this);

	    // Get rid of scrollbars, and clear out the window's built-in margin,
	    // because we want to take advantage of the entire client area.
	    Window.enableScrolling(false);
	    Window.setMargin("0px");
	    
	    // Redirect taskevaluation.appspot.com to www.taskevaluation.appspot.com
	    // for the oauth2 callback to work for any user entry.
	    /*String url = GWT.getHostPageBaseURL();
	    if ( !url.contains("www.") ) {
	    	url.replace("http://", "http://www.");
	    	Window.Location.replace(url);
	    }*/
	    
	    boolean loadHomePage = true;
		
		if(! History.getToken().isEmpty() )
		{
			// History is not empty, so there was session going on.
			// Try to session values from cookies.
			try
			{
				NavigationUtility.sessionMemId = Cookies.getCookie("UID");
				NavigationUtility.sessionFirstName = Cookies.getCookie("FNAME");
				NavigationUtility.sessionLastName = Cookies.getCookie("LNAME");
				NavigationUtility.sessionEmail = Cookies.getCookie("EMAIL");
				NavigationUtility.isGoogleLogin = Boolean.valueOf(Cookies.getCookie("GOOGLELOGIN"));
				
				if(!NavigationUtility.sessionMemId.isEmpty()) {
					loadHomePage = false;
				}
			}
			catch(Exception e){
				// Exception getting Cookie info, load home page....
				History.newItem("");
			}
		}
		
		if( loadHomePage) {
			// Use this if using Layout Panel
			outer.add(home);
		}
		else {
			ml = new MainLayout();
			outer.add(ml);
		}
	    
	    // Add the outer panel to the RootLayoutPanel, so that it will be
	    // displayed.
	    RootLayoutPanel root = RootLayoutPanel.get();
	    root.add(outer);
	    
	    
	    // Handle Pre-Login Navigation events, Pre-Login means before the Member is logged in.
	    NavigationUtility.EVENT_BUS.addHandler(PreLoginEvent.TYPE, new PreLoginEventHandler(){
            public void onEvent(PreLoginEvent event) {
            	switch (event.getActionType()) {
                case PRE_HOME:
                		preLoginHomeClicked();
                        break;
                case PRE_SUPPORT:
                		preLoginSupportClicked();
                        break;
                case PRE_LOGIN:
                		preLoginLoginClicked();
                		break;
                case PRE_REGISTER:
                		preLoginRegisterClicked();
                		break;
                case LOGIN_SUCCESS:
                		loginSuccess();
                		break;
                case SIGN_OUT:
                		signOut();
                		break;
				default:
					break;
            	}
            }
        });  
	    
	}
	
	public void preLoginHomeClicked() {
		RootLayoutPanel.get().remove(0);
		RootLayoutPanel.get().add(home);
	}
	
	public void preLoginSupportClicked() {
		Window.alert("Contact: ashwinkumarg_6@yahoo.co.in for any queries");
	}

	public void preLoginLoginClicked() {
		RootLayoutPanel.get().remove(0);
		logForm.clearForm();
		RootLayoutPanel.get().add(logForm);
	}

	public void preLoginRegisterClicked() {
		RootLayoutPanel.get().remove(0);
		regForm.clearForm();
		RootLayoutPanel.get().add(regForm);
	}
	
	public void loginSuccess() {
		RootLayoutPanel.get().remove(0);
		ml = new MainLayout();
		RootLayoutPanel.get().add(ml);
	}
	
	public void signOut() {
		RootLayoutPanel.get().remove(0); // It should destroy the MainLayout obj.(confirm)
		RootLayoutPanel.get().add(home);
		
		History.newItem("");
	}
}
