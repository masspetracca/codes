package com.gannon.TaskEvaluation.client;

import java.util.Date;
import java.util.List;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.gannon.TaskEvaluation.shared.Task;
import com.gannon.TaskEvaluation.shared.Template;

/**
 * The async counterpart of <code>GreetingService</code>.
 */
public interface TaskServiceAsync {

	void createTask(String aTaskCreator, String aTaskName,
			String aTaskDescription, List<String> aTaskAuthors,
			List<String> aTaskEvaluators, Date aCreationDate,
			Date aCompletionDate, Boolean aPublicTask, String aTemplate,
			AsyncCallback<String> callback);

	void editTask(String aTaskId, String aTaskName, String aTaskDescription,
			List<String> aTaskAuthors, List<String> aTaskEvaluators,
			Date aCreationDate, Date aCompletionDate, Boolean aPublicTask,
			String aTemplate, AsyncCallback<Void> callback);

	void deleteTask(String aTaskId, AsyncCallback<Void> callback);

	void returnAllPublicTasks(AsyncCallback<List<Task>> callback);

	void getTemplateForTask(String aTaskId, AsyncCallback<Template> callback);
	
}
