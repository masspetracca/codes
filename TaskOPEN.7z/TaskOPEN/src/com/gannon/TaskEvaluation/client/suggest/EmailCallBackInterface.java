package com.gannon.TaskEvaluation.client.suggest;

import java.util.List;

public interface EmailCallBackInterface {
	
	void confirmCancel(Boolean aConfirm, List<String> aToEmails, String aSub);

}
