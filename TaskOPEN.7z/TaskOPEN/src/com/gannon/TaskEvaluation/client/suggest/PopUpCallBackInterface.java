package com.gannon.TaskEvaluation.client.suggest;

public interface PopUpCallBackInterface {
	
	void confirmCancel(Boolean aConfirm);
	
	void confirm();

}
