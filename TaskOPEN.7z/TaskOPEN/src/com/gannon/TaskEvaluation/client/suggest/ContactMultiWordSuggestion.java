package com.gannon.TaskEvaluation.client.suggest;

import com.google.gwt.user.client.ui.MultiWordSuggestOracle.MultiWordSuggestion;
import com.gannon.TaskEvaluation.shared.Contact;

public class ContactMultiWordSuggestion extends MultiWordSuggestion
{
    private Contact contactDTO = null;
 
    public ContactMultiWordSuggestion(Contact user)
    {	
	    super( user.getEmail(), user.getFirstName()+ ","+ " "+user.getLastName() ); 
        this.contactDTO = user;
    }
 
    public Contact getPersonDTO()
    {
        return contactDTO;
    }
}