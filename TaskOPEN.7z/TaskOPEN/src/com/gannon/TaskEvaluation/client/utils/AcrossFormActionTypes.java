package com.gannon.TaskEvaluation.client.utils;

// These are the events that can be originated from the Manage Task Form.
public enum AcrossFormActionTypes {
	RELOAD_TEMPLATES,
	RELOAD_CONTACTS,
	TASK_MODIFIED, // this is used when the task is modified and the contactform need to reload the contacts.
	TEMPLATES_MODIFIED_TASKFORM,
	MEMBER_NAME_CHANGE
}
