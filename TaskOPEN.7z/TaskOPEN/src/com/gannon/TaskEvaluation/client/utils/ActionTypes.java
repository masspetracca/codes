package com.gannon.TaskEvaluation.client.utils;

// These are the actions available for the user, a Cell list is built upon them and displayed 
// to the user.
public enum ActionTypes {
	TASKS,
	CREATE_TASK,
	MANAGE_TASK,
	CONTACTS,
	TEMPLATES,
	EVALUATION,
	SETTINGS,
	FINISHED_TASKS,
	WAITING_TASKS,
	REPORT,
	TASK_REPORT,
	F_TASKS
}
