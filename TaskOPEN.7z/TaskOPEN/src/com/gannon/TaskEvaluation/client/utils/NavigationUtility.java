package com.gannon.TaskEvaluation.client.utils;

import com.google.gwt.core.shared.GWT;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.event.shared.SimpleEventBus;

public class NavigationUtility {	
	
	public static String sessionMemId;
	
	public static String sessionFirstName;
	
	public static String sessionLastName;
	
	public static String sessionEmail;
	
	public static boolean isGoogleLogin;
	
	// This is the Event bus used in our custom event handling.
	public static EventBus EVENT_BUS = GWT.create(SimpleEventBus.class);

}
