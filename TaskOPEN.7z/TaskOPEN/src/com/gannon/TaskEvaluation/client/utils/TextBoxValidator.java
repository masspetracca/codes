package com.gannon.TaskEvaluation.client.utils;

public class TextBoxValidator extends Validator {
	
	public enum TextFieldType{
		LOGIN_PASSWORD,
		REG_TEXT,
		REG_PASSWORD,
		EMAIL
	}
	
	public String userId;
	public TextFieldType tft;
	
	public TextBoxValidator(TextFieldType aTft) {
		userId = "none";
		tft = aTft;
	}
	
	public TextBoxValidator(String aUserId, TextFieldType aTft) {
		userId = aUserId;
		tft = aTft;
	}

	 public boolean validate(String value) {
		 errorMessage = "";
		 
		 switch(tft) {
		 case EMAIL:
			 if (!value.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
			        errorMessage = "Enter valid email Id";
			        return false;
			 } 
			 break;
		 case REG_TEXT:
		 case REG_PASSWORD:
			 if( value.length() < 3) {
				 errorMessage = "Enter valid Input";
			     return false;
			 }
			 break;
		 case LOGIN_PASSWORD:
			 if( value.length() < 3) {
				 errorMessage = "Enter valid Input";
			     return false;
			 }
			 else {
				 // Add a server call to verify the UserId and Pwd later.
			 }
			 break;
		 }
		 
		 return true;		     
	}

	public String getErrorMessage() {
	    return errorMessage;
	 }
	}