package com.gannon.TaskEvaluation.client.utils;

// These are the events that can be originated from the Manage Task Form.
public enum ManageTaskActionTypes {
	SAVE,
	CANCEL,
	DELETE,
	CLOSE,
	CREATE_SAVE,
	CREATE_CANCEL
}
