package com.gannon.TaskEvaluation.client.utils;

import java.math.BigDecimal;

import com.google.gwt.animation.client.Animation;
import com.google.gwt.user.client.ui.Widget;

public class FadeAnimation  extends Animation {
	private Widget myElement;        
    private double opacityIncrement;
    private double targetOpacity;
    private double baseOpacity;
    
    public FadeAnimation(Widget elem, double aTargetOpacity) {
        this.myElement = elem;
        this.targetOpacity = aTargetOpacity;
    }
    @Override
    protected void onUpdate(double progress) {
    	myElement.getElement().getStyle().setOpacity(baseOpacity + progress * opacityIncrement);
    }
    
    @Override
    protected void onStart() {
    	myElement.getElement().getStyle().setOpacity(0);
    }
    
    @Override
    protected void onComplete() {
    	super.onComplete();
    	myElement.getElement().getStyle().setOpacity(targetOpacity);
    }
    
    public void fade(int aDuration) {
		if(targetOpacity > 1.0) {
			targetOpacity = 1.0;
		}
		if(targetOpacity < 0.0) {
			targetOpacity = 0.0;
		}
		String opacityStr = myElement.getElement().getStyle().getOpacity();
		try {
			baseOpacity = new BigDecimal(opacityStr).doubleValue();
			opacityIncrement = targetOpacity - baseOpacity;
			run(aDuration);
		} catch(NumberFormatException e) {
			   // set opacity directly
		    onComplete();
		}
	}

}