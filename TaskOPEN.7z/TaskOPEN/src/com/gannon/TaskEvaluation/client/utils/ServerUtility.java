package com.gannon.TaskEvaluation.client.utils;

import com.google.gwt.core.client.GWT;
import com.gannon.TaskEvaluation.client.ContactService;
import com.gannon.TaskEvaluation.client.ContactServiceAsync;
import com.gannon.TaskEvaluation.client.EvaluationService;
import com.gannon.TaskEvaluation.client.GoogleLoginService;
import com.gannon.TaskEvaluation.client.GoogleLoginServiceAsync;
import com.gannon.TaskEvaluation.client.MemberService;
import com.gannon.TaskEvaluation.client.TaskService;
import com.gannon.TaskEvaluation.client.TemplateService;
import com.gannon.TaskEvaluation.client.EvaluationServiceAsync;
import com.gannon.TaskEvaluation.client.MemberServiceAsync;
import com.gannon.TaskEvaluation.client.TaskServiceAsync;
import com.gannon.TaskEvaluation.client.TemplateServiceAsync;

public class ServerUtility {
	
	// Define RPCs
		public final static MemberServiceAsync myMemberRpcService = GWT.create(MemberService.class);
		public final static EvaluationServiceAsync myEvaluationRpcService = GWT.create(EvaluationService.class);
		public final static TemplateServiceAsync myTemplateRpcService = GWT.create(TemplateService.class);
		public final static TaskServiceAsync myTaskRpcService = GWT.create(TaskService.class);
		public final static ContactServiceAsync myContactRpcService = GWT.create(ContactService.class);
		public final static GoogleLoginServiceAsync myGoogleLoginRpcService = GWT.create(GoogleLoginService.class);
}
