package com.gannon.TaskEvaluation.client.utils;

public enum EvaluationActionTypes {
	EVAL_SUBMIT,
	EVAL_CANCEL,
	EVAL_CLOSE
}
