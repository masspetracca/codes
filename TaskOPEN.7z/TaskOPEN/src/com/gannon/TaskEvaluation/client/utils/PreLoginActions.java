package com.gannon.TaskEvaluation.client.utils;

public enum PreLoginActions {
	PRE_HOME,
	PRE_SUPPORT,
	PRE_LOGIN,
	PRE_REGISTER,
	LOGIN_SUCCESS,
	SIGN_OUT,
	GOOGLE_LOGIN_CLICKED,
	GOOGLE_LOGOUT_CLICKED
}
