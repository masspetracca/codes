package SendMail;

public class TestSendMail {
	public static void main(String[] args) {
		SendMail();
		
	}

	private static void SendMail() {
		SendEmail sm = new SendEmail();
		
	}
}
