
	package SendMail;
	
	public class SendEmail {

		public SendEmail () {
		
		String server="smtp.gmail.com";
		String from = "vaffaproject@gmail.com";
		String password = "Selenium@123";
		String[] to ={"seleniumcoaching@gmail.com","trainer@way2automation.com"};
		String subject = "Extent Project Report";
		
		String messageBody ="TestMessage";
		String attachmentPath="c:\\screenshot\\2017_10_3_14_49_9.jpg";
		String attachmentName="error.jpg";
		
		
		
		//SQL DATABASE DETAILS	
		String driver="net.sourceforge.jtds.jdbc.Driver"; 
		String dbConnectionUrl="jdbc:jtds:sqlserver://192.101.44.22;DatabaseName=monitor_eval"; 
		String dbUserName="sa"; 
		String dbPassword="$ql$!!1"; 
		
		
		//MYSQL DATABASE DETAILS
		String mysqldriver="com.mysql.jdbc.Driver";
		String mysqluserName = "root";
		String mysqlpassword = "selenium";
		String mysqlurl = "jdbc:mysql://localhost:3306/acs";	
		}
}
