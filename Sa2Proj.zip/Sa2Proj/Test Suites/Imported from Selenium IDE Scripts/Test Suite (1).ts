<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite (1)</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>0</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>43eb58be-7cd1-455a-9921-c48c83985df8</testSuiteGuid>
   <testCaseLink>
      <guid>7f594a45-14bb-4426-a3e5-b63c368bdb58</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/Test Suite (1)/RU01-NUC01-T01</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b95b7563-4cd3-4226-8776-34fc9d07c487</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/Test Suite (1)/RU01-NUC01-T02</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a1486513-31a6-4583-8fd4-5b7e8ebf047b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/Test Suite (1)/RU01-NUC01-T03</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
