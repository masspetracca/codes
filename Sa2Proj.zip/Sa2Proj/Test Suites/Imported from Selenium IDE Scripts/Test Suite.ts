<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-11-15T17:14:13</lastRun>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>0</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>f1bddbce-d2de-4092-ab28-b32a62f1557f</testSuiteGuid>
   <testCaseLink>
      <guid>fdee2e80-0a36-4fc6-b263-e3ba236ee174</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/Test Suite/RU01-NUC01-T01</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6ff11157-eb2f-4072-8f75-e6cfc1c34697</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/Test Suite/RU01-NUC01-T02</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>dcd36b77-ecc6-4f7b-a1b7-aaceff2d197e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Imported from Selenium IDE Scripts/Test Suite/RU01-NUC01-T03</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
