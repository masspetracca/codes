package it.dzone.selenium3.test.login;

import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class TestLogin {
private WebDriver driver;
@Before
public void setUp() {
driver = new FirefoxDriver();
}
@After
public void tearDown() {
driver.quit();
}
@Test
public void succeeded() {
driver.get("https://10.0.10.230:10044/LiqPortalWEB/index.html");
driver.findElement(By.id("username")).
sendKeys("qauser");
driver.findElement(By.id("password")).
sendKeys("qauser");
driver.findElement(By.cssSelector("button")).click();
assertTrue("success message not present",
driver.findElement(
By.cssSelector(".flash.success")
).isDisplayed());
}
}