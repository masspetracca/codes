package it.ccg.calculator.main.testing;

public interface IWebDriver {

}
