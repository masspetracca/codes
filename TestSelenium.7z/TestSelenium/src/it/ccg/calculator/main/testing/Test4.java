package it.ccg.calculator.main.testing;

import static org.junit.Assert.*;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

public class Test4 extends junit.framework.TestCase {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  private String parmKEY;
  private String parmATT;

  @Before
  public void setUp() throws Exception {
    //System.setProperty("webdriver.firefox.driver", "C:/workspaceSPARX/TestSelenium/Firefox/firefox.exe");
	
    driver = new FirefoxDriver();
    baseUrl = "https://www.google.it/?gws_rd=ssl";
    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
  }

  @Test
  public void test4() throws Exception {
    driver.get("https://www.google.it/?gws_rd=ssl&sc_selenium=true#q=wall+street+italia");
    driver.findElement(By.linkText("Economia")).click();
//    driver.findElement(By.xpath("//h2")).click();
 //   driver.findElement(By.xpath("//div[2]/div/div[2]/div[2]/a/div[2]/h2")).click();
//    driver.findElement(By.xpath("//div[3]/div[2]/a/h2")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
//    driver.findElement(By.id("s")).clear();
    driver.findElement(By.id("s")).sendKeys("borsa italiana");
    //parametrizz. KEY
    parmKEY="borsa italiana";
    parmATT="borsa italiana ";
    //assert
    assertEquals("ASSERT-EQ",parmKEY,parmATT);

//    driver.findElement(By.xpath("//input[@value='Cerca']")).click();
//    driver.findElement(By.xpath("//div[2]/div[2]/a/h2")).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
