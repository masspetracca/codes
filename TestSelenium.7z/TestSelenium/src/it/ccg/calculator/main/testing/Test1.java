package it.ccg.calculator.main.testing;

import java.util.concurrent.TimeUnit;
import junit.framework.TestCase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test1 extends TestCase {
	private WebDriver driver;
    private String baseUrl;
	private String param2;
	private String param1;
	
	@Before
          public final void setUp() throws Exception {
              // Download chromedriver (http://code.google.com/p/chromedriver/downloads/list)
              System.setProperty("webdriver.chrome.driver", "chromedriver/chromedriver.exe");
              driver = new ChromeDriver();
              baseUrl = "https://accounts.google.com";
              driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
          }

          @Test
          public final void test() throws Exception {
        	  // launch the firefox browser and open the application url
             driver.get(baseUrl + "/");
             // maximize the browser window
             driver.manage().window().maximize();
         	 param2="masspetracca2";
             System.out.println("Name:"+driver.getTitle()+"-op1:"+param2);
             
             // enter a valid username in the email textbox
             WebElement username = driver.findElement(By.id("Email"));
             username.clear();
             param1="masspetracca";
             username.sendKeys(param1);
             assertEquals("STOP-1",param1,param2);

               driver.get(baseUrl + "/");
          }

          @After
          public final void tearDown() throws Exception {
              driver.quit();
          }
}