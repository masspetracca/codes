package it.ccg.calculator.main.testing;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

@SuppressWarnings("deprecation")
public class Test6 {
	private Selenium selenium;

	@Before
	public void setUp() throws Exception {
		WebDriver driver = new FirefoxDriver();
		String baseUrl = "https://10.0.10.230:10084/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}

	@Test
	public void testP() throws Exception {
		System.out.println("");
		selenium.open("/LiqPortalWEB/");
		// selenium.waitForElementClickable("scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]");
		selenium.click("scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/maximizeButton/");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/maximizeButton/");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon=\"showDateRange\"]");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon=\"showDateRange\"]");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon=\"chooserIcon\"]");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||index=0||Class=DateRangeItem]/dateRangeForm/item[name=fromField||title=From||index=0||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon=\"chooserIcon\"]");
		// selenium.waitForElementClickable("scLocator=//autoID[Class=DateChooser||index=17||length=20||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Nov 30 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Wed||3]", "/* Date Chooser and filter */");
		selenium.click("scLocator=//autoID[Class=DateChooser||index=17||length=20||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Nov 30 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Wed||3]");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon=\"chooserIcon\"]");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/rangeForm/item[name=dt_ref||title=dt_ref||value=[object Object]||index=0||Class=DateRangeItem]/dateRangeForm/item[name=toField||title=To||index=1||Class=RelativeDateItem]/editor/item[name=iconPlaceholder||title=iconPlaceholder||index=2||Class=StaticTextItem]/[icon=\"chooserIcon\"]");
		// selenium.waitForElementClickable("scLocator=//autoID[Class=DateChooser||index=23||length=26||classIndex=1||classLength=2]/nextMonthButton/");
		selenium.click("scLocator=//autoID[Class=DateChooser||index=23||length=26||classIndex=1||classLength=2]/nextMonthButton/");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/");
		selenium.click("scLocator=//autoID[Class=DateChooser||index=23||length=26||classIndex=1||classLength=2]/nextMonthButton/");
		selenium.click("scLocator=//autoID[Class=DateChooser||index=17||length=20||classIndex=0||classLength=1]/dateGrid/body/row[Wed=Wed Nov 30 2016 12:00:00 GMT+0100 (W. Europe Standard Time)||4]/col[fieldName=Wed||3]");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element");
		// selenium.waitForElementReadyForKeyPresses("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element");
		//selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element", "${KEY_TAB}");
		// selenium.blur("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon=\"showDateRange\"]");
		selenium.focus("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon=\"showDateRange\"]");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon=\"showDateRange\"]");
		//selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon=\"showDateRange\"]", "${KEY_TAB}");
		// selenium.blur("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||index=2||Class=MiniDateRangeItem]/[icon=\"showDateRange\"]");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||index=3||Class=FloatItem]/element", "/* List Grid filterEditor, editRow Cash Amount - true */");
		selenium.focus("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||index=3||Class=FloatItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||index=3||Class=FloatItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||index=3||Class=FloatItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E10||index=3||Class=FloatItem]/element", "/* List Grid filterEditor, editRow Cash Amount > 10 */");
		selenium.type("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E10||index=3||Class=FloatItem]/element", ">10");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E10||index=3||Class=FloatItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E10||index=3||Class=FloatItem]/element");
		// selenium.waitForElementReadyForKeyPresses("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.6200000||index=3||Class=FloatItem]/element");
		//selenium.sendKeys("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.6200000||index=3||Class=FloatItem]/element", "${KEY_ENTER}");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.6200000||index=3||Class=FloatItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.6200000||index=3||Class=FloatItem]/element");
		// selenium.waitForElementReadyForKeyPresses("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.62||index=3||Class=FloatItem]/element");
		//selenium.sendKeys("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.62||index=3||Class=FloatItem]/element", "${KEY_LEFT}");
		// selenium.waitForElementReadyForKeyPresses("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.62||index=3||Class=FloatItem]/element");
		//selenium.sendKeys("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.62||index=3||Class=FloatItem]/element", "${KEY_LEFT}");
		// selenium.waitForElementReadyForKeyPresses("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.62||index=3||Class=FloatItem]/element");
		//selenium.sendKeys("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E64327327.62||index=3||Class=FloatItem]/element", "${KEY_LEFT}");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E643273270000.62||index=3||Class=FloatItem]/element");
		selenium.type("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E643273270000.62||index=3||Class=FloatItem]/element", ">643273270000.62");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C643||index=3||Class=FloatItem]/element", "/* List Grid filterEditor, editRow Cash Amount - less than */");
		selenium.type("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C643||index=3||Class=FloatItem]/element", "<643");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C643||index=3||Class=FloatItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C643||index=3||Class=FloatItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C643||index=3||Class=FloatItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C643||index=3||Class=FloatItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430||index=3||Class=FloatItem]/element");
		selenium.type("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430||index=3||Class=FloatItem]/element", "<6430");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430||index=3||Class=FloatItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430||index=3||Class=FloatItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430000||index=3||Class=FloatItem]/element");
		selenium.type("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430000||index=3||Class=FloatItem]/element", "<6430000");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/body/");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/body/");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430000||index=3||Class=FloatItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3C6430000||index=3||Class=FloatItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E100||index=3||Class=FloatItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E100||index=3||Class=FloatItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E100||index=3||Class=FloatItem]/element", "/* List Grid filterEditor, editRow Cash Amount - greater than */");
		selenium.type("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E100||index=3||Class=FloatItem]/element", ">100");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E100||index=3||Class=FloatItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E100||index=3||Class=FloatItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E1000||index=3||Class=FloatItem]/element");
		selenium.type("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E1000||index=3||Class=FloatItem]/element", ">1000");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E1000||index=3||Class=FloatItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||value=%3E1000||index=3||Class=FloatItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||index=3||Class=FloatItem]/element");
		selenium.type("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=cash_amount||title=Cash%20amount||index=3||Class=FloatItem]/element", "");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||value=EOD||index=1||Class=TextItem]/element");
		selenium.type("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||value=EOD||index=1||Class=TextItem]/element", "EOD");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/okButton/");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/cancelButton/");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=dt_ref||title=Date%20ref.||value=[object Object]||index=2||Class=MiniDateRangeItem]/rangeDialog/cancelButton/");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||index=1||Class=TextItem]/element");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||value=Auto||index=1||Class=TextItem]/element");
		selenium.type("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/editRowForm/item[name=item_name||title=Item%20name||value=Auto||index=1||Class=TextItem]/element", "Auto");
		// selenium.waitForElementClickable("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		selenium.click("scLocator=//Portlet[ID=\"liquidity_items_tab_2\"]/item[0][Class=\"ListGrid\"]/filterEditor/actionButton/icon");
		// selenium.waitForElementClickable("scLocator=//autoID[Class=Window||index=386||length=388||classIndex=0||classLength=1||roleIndex=2||roleLength=3||title=Select%20Fields%20to%20export...||scRole=dialog]/item[0][Class=\"HLayout\"]/member[Class=VStack||index=2||length=5||classIndex=0||classLength=1]/member[Class=ImgButton||index=2||length=4||classIndex=2||classLength=4||roleIndex=2||roleLength=4||scRole=button||name=main]/");
		selenium.click("scLocator=//autoID[Class=Window||index=386||length=388||classIndex=0||classLength=1||roleIndex=2||roleLength=3||title=Select%20Fields%20to%20export...||scRole=dialog]/item[0][Class=\"HLayout\"]/member[Class=VStack||index=2||length=5||classIndex=0||classLength=1]/member[Class=ImgButton||index=2||length=4||classIndex=2||classLength=4||roleIndex=2||roleLength=4||scRole=button||name=main]/");
		// selenium.waitForElementClickable("scLocator=//autoID[Class=Window||index=386||length=388||classIndex=0||classLength=1||roleIndex=2||roleLength=3||title=Select%20Fields%20to%20export...||scRole=dialog]/item[3][Class=\"HLayout\"]/member[Class=Button||index=0||length=2||classIndex=0||classLength=2||roleIndex=0||roleLength=2||title=Export||scRole=button]/");
		selenium.click("scLocator=//autoID[Class=Window||index=386||length=388||classIndex=0||classLength=1||roleIndex=2||roleLength=3||title=Select%20Fields%20to%20export...||scRole=dialog]/item[3][Class=\"HLayout\"]/member[Class=Button||index=0||length=2||classIndex=0||classLength=2||roleIndex=0||roleLength=2||title=Export||scRole=button]/");
	}

	@After
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
