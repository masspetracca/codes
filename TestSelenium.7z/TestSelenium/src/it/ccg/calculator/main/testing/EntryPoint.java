package it.ccg.calculator.main.testing;

import org.openqa.selenium.chrome.ChromeDriver;


public class EntryPoint {
	public static void main(String[] args) { 
		ChromeDriver driver = new ChromeDriver();
		String url0="http://testing.todorvachev.com";
		driver.navigate().to(url0);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Interrupted Exception:"+e.getStackTrace());
		}
		driver.quit(); 
	}
}