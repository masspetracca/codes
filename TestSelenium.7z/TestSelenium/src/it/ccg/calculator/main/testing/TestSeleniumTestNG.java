package it.ccg.calculator.main.testing;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestSeleniumTestNG {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @BeforeClass(alwaysRun = true)
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "https://10.0.10.230:10044";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testProvaTestNG() throws Exception {
    driver.get(baseUrl + "/LiqPortalWEB/");
    // ERROR: Caught exception [unknown command [waitForElementClickable]]
    // ERROR: Caught exception [Error: unknown strategy [sclocator] for locator [scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]]]
    // ERROR: Caught exception [unknown command [waitForElementClickable]]
    // ERROR: Caught exception [Error: unknown strategy [sclocator] for locator [scLocator=//Portlet[ID="refdata_countrytab_2"]/maximizeButton/]]
    // ERROR: Caught exception [unknown command [waitForElementClickable]]
    // ERROR: Caught exception [Error: unknown strategy [sclocator] for locator [scLocator=//Portlet[ID="refdata_countrytab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_name||title=Country%20name||index=2||Class=TextItem]/element]]
    // ERROR: Caught exception [unknown command [waitForElementClickable]]
    // ERROR: Caught exception [Error: unknown strategy [sclocator] for locator [scLocator=//Portlet[ID="refdata_countrytab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_name||title=Country%20name||value=Guinea||index=2||Class=TextItem]/element]]
    // ERROR: Caught exception [unknown command [waitForElementClickable]]
    // ERROR: Caught exception [Error: unknown strategy [sclocator] for locator [scLocator=//Portlet[ID="refdata_countrytab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon]]
    try {
      assertTrue(isElementPresent(By.name("country_name$148l")));
    } catch (Error e) {
      //verificationErrors.append(e.toString());
    }
    // Warning: verifyTextNotPresent may require manual changes
    try {
      assertFalse(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*name=country_name\\$148l[\\s\\S]*$"));
    } catch (Error e) {
      //verificationErrors.append(e.toString());
    }
  }

  @AfterClass(alwaysRun = true)
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
