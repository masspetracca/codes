package it.ccg.calculator.main.testing;


import java.util.concurrent.TimeUnit;

//import org.junit.After;
//import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//
import it.ccg.calculator.main.TestOperators;

public class TestSelenium4 extends junit.framework.TestCase {
	private WebDriver driver;
	
    private String baseUrl;
	private String param2;
	private String param1;

	private int oper1;
//
	private int oper2;
	
	//Before
	//   public void setUp() throws Exception {
	//        // Download chromedriver (http://code.google.com/p/chromedriver/downloads/list)
	//    }

	@Test
         public  void test() throws Exception {
			   //Before
//			System.out.println("START.test m. sum1");
//			oper1 = 2000;
//			oper2 = 2000;
//			//oper1 = 0;
//			//oper2 = 0;
//	        double  result = TestOperators.addOper(oper1+oper2);
//			assertEquals("STOP-1",oper1,oper2);
//			System.out.println("END.test m. sum-1: " + result);
//			//valore atteso NOT zero
			//QUI
        	System.setProperty("webdriver.chrome.driver", "c:/workspace/jdbcdrivers/chromedriver/chromedriver.exe");
        	
	        driver = new ChromeDriver();
	        baseUrl = "https://accounts.google.com";
	        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        	  // launch the firefox browser and open the application url
             driver.get(baseUrl + "/");
             // maximize the browser window
             driver.manage().window().maximize();
         	 param2="masspetracca";
             System.out.println("Name:"+driver.getTitle()+"-op1:"+param2);
             
             // enter a valid username in the email textbox
             WebElement username = driver.findElement(By.id("Email"));
             username.clear();
             param1="masspetracca";
             username.sendKeys(param1);
             assertEquals("STOP-1",param1,param2);
             //driver.get(baseUrl + "/");
       	
             //After
             driver.quit();
	        //QUI
          }

        //After
//          public void tearDown() throws Exception {
//          }


}