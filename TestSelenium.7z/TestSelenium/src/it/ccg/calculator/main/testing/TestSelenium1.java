package it.ccg.calculator.main.testing;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

public class TestSelenium1 {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  private WebDriverBackedSelenium selenium;

  @Before
  public void setUp() throws Exception {
//    driver = new FirefoxDriver();
//    baseUrl = "https://10.0.10.173:9443/CCAM/";
//    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

    //driver.get(baseUrl + "/CCAM/");
	System.setProperty("webdriver.chrome.driver", "c:/workspace/jdbcdrivers/chromedriver/chromedriver.exe");
    driver = new ChromeDriver();
    baseUrl = "https://accounts.google.com";
    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    
    selenium = new WebDriverBackedSelenium(driver, "http://10.0.10.173:9080/CCAM/?sc_selenium=true");
  }

  @Test
  public void testProva() throws Exception {
	  //selenium.open("/CCAM/");
		//selenium.type("name=j_username", "visitor");
		//selenium.type("name=j_password", "visitor1");
		//selenium.click("name=login");
		//selenium.waitForPageToLoad("30000");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Bank%20static%20data||1]/col[fieldName=name||0]");
		selenium.click("scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]");
	  
	// ERROR: Caught exception [unknown command [waitForElementClickable]]
    // ERROR: Caught exception [Error: unknown strategy [sclocator] for locator [scLocator=//Menu[level=1]/body/row[3]/col[fieldName=title||0]]]
    // ERROR: Caught exception [unknown command [waitForElementClickable]]
    // ERROR: Caught exception [Error: unknown strategy [sclocator] for locator [scLocator=//Portlet[ID="refdata_countrytab_2"]/maximizeButton/]]
    // ERROR: Caught exception [unknown command [waitForElementClickable]]
    // ERROR: Caught exception [Error: unknown strategy [sclocator] for locator [scLocator=//Portlet[ID="refdata_countrytab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_name||title=Country%20name||index=2||Class=TextItem]/element]]
    // ERROR: Caught exception [unknown command [waitForElementClickable]]
    // ERROR: Caught exception [Error: unknown strategy [sclocator] for locator [scLocator=//Portlet[ID="refdata_countrytab_2"]/item[0][Class="ListGrid"]/filterEditor/editRowForm/item[name=country_name||title=Country%20name||value=Guinea||index=2||Class=TextItem]/element]]
    // ERROR: Caught exception [unknown command [waitForElementClickable]]
    // ERROR: Caught exception [Error: unknown strategy [sclocator] for locator [scLocator=//Portlet[ID="refdata_countrytab_2"]/item[0][Class="ListGrid"]/filterEditor/actionButton/icon]]
    try {
      assertTrue(isElementPresent(By.name("country_name$148l")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    // Warning: verifyTextNotPresent may require manual changes
    try {
      assertFalse(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*name=country_name\\$148l[\\s\\S]*$"));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
