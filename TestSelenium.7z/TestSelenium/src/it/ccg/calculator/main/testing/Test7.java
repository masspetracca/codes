package it.ccg.calculator.main.testing;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

//import statements omitted for brevity

public class Test7 {

 private WebDriver driver;


 private Login login;




 @Before
 public void setUp() {
     driver = new FirefoxDriver();
     login = new Login(driver);

 }

 @After
 public void tearDown() {

     driver.quit();

 }


 @Test
 public void succeeded() {

     login.with("tomsmith", "SuperSecretPassword!");

     assertTrue("success message not present",

             login.successMessagePresent());
 }




}

