package ccg.ftrr.freader.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;

public class GetFiles {
	    private static String Lline = null;
		private static int ctrRead;
		//instance
		int lString = 10;
		String [] nameRF = new String[lString];

		/**
	     * @param args the command line arguments
	     * @throws IOException 
	     */
		
	    public //public static void main(String[] args) throws IOException {
	    	GetFiles() throws IOException{ 
	    	System.out.println("Inizio <File Filter>  *.txt");

			//Vengono prelevati gli attributi del progetto
			GetProperties();
			
	    	File parentDir = new File(PropertyFiles.getCartellaDati());
	        FilenameFilter txtFilter = new FileFilter();
	        File[] listaFileInput = null;
	        if(parentDir.isDirectory()) {
	        	listaFileInput = parentDir.listFiles(txtFilter);
	        }
	        //System.out.println("Errore directory");
	        FileReader reader = null;
	        //String Uline = null;
	        //File outputFile = new File(PropertyFiles.getCartellaDati()+PropertyFiles.getSQLCMD_FILE_OUTPUT());
	        File currFile = null;
	        BufferedReader in = null;
	        //FileWriter writer = null;
	        String line = null;
	        try{
	            //imposta il writer per il file di output
	            //writer = new FileWriter(outputFile);
	            if (listaFileInput!=null && listaFileInput.length == 0) {
	            	System.out.println("Attenzione: nessun file da elaborare !");
	            	System.exit(1);
	            }
	            //itera sulla lista di file
	            for(int i=0;i< listaFileInput.length; i++){
	                currFile = listaFileInput[i];
	                System.out.println("Sto elaborando il file: " + currFile.getName());
	                reader = new FileReader(currFile);
	                in = new BufferedReader(reader);
	                int ictr = 0;
	                ctrRead = 0;
	                String Sline = null;
             	    Refobj refObj = new Refobj();
	                
	                while ((line = in.readLine()) != null) {
	                	if (ictr == 0) {
	                		if (Lline == line) {
	                		   Sline = line;
	                 		}
	                	}  
	                	   ctrRead = ctrRead + 1;
	                	   System.out.println("riga: " + ctrRead + " " + line);
			 		 	    //writer.write(line+"\r\n");
	                	   nameRF[ctrRead] = line;
	                	   
	                	   //RNF01NUC01T01 rf01 = new RNF01NUC01T01();
	                }
             	   refObj.setRefObj(nameRF);
 
	                System.out.println("Ho finito di elaborare il file: " + currFile.getName());
//	                if (Sline != Uline) {
//	       		 		System.out.println("---ultima riga: " + Uline);
//	                    Lline = Uline;
//	                    Uline = null;
//	                    
//	                }
	            }
	        }catch(IOException ioEx){
	            System.out.println(ioEx.getMessage());
	            ioEx.printStackTrace();
	        }finally{
	            try{
	                if(in!= null) in.close();
	                //if(writer!= null) writer.close();
	            }catch(IOException ioEx){
	                System.out.println(ioEx.getMessage());
	                ioEx.printStackTrace();
	            }
	        }
	        
	    }

		private static void GetProperties() throws IOException {
			PropertyFiles pf = new PropertyFiles();
			
		}
	    
	}