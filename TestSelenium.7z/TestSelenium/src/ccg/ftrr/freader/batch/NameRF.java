package ccg.ftrr.freader.batch;

public class NameRF {

}
