package ccg.ftrr.freader.batch;

public class Refobj {

	String[] refObj = null;

	public String[] getRefobj() {
		return refObj;	}


	public void setRefObj(String[] nameRF) {
		this.refObj = nameRF;
	}
	
}
