package com.p1.selenium.ir.run1;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.thoughtworks.selenium.Selenium;

public class p1 {

	WebDriver driver;
	Selenium selenium;

	@Before
	public void startSelenium() {
		    System.setProperty("webdriver.FirefoxDriver.driver", "C:/mpetracc/workspaceSPARX/TestSelenium/Firefox/firefox.exe");
		    driver = new FirefoxDriver();
			WebDriver driver = new FirefoxDriver();
	/*
			System.setProperty("webdriver.chrome.driver", "c:/workspace/jdbcdrivers/chromedriver/chromedriver.exe");
		    driver = new ChromeDriver();
	*/
		    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			String baseUrl = "https://10.0.10.230:10162/";
			selenium = new com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium(driver, baseUrl);
	}

	@After
	public void stopSelenium() {
		driver.close();
	}

	@Test
	public void testP1() {
		selenium.open("/InternalRatingWeb/login.jsp?sc_selenium=true");
		selenium.type("name=j_username", "iruser");
		selenium.type("name=j_password", "iruser");
		selenium.click("name=login");
		selenium.waitForPageToLoad("30000");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Bank%20static%20data||1]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Bank%20static%20data||1]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//autoID[Class=VLayout||index=0||length=2||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=2||classIndex=1||classLength=2]/member[Class=Canvas||index=1||length=2||classIndex=0||classLength=1]/child[Class=TabSet||index=0||length=1||classIndex=0||classLength=1]/paneContainer/member[Class=Canvas||index=0||length=1||classIndex=0||classLength=1]/child[Class=VLayout||index=0||length=1||classIndex=0||classLength=1]/member[Class=HLayout||index=0||length=3||classIndex=0||classLength=2]/member[Class=IButton||index=1||length=4||classIndex=0||classLength=1||roleIndex=0||roleLength=2||title=Show||scRole=button]/");
		selenium.click("scLocator=//autoID[Class=VLayout||index=0||length=2||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=2||classIndex=1||classLength=2]/member[Class=Canvas||index=1||length=2||classIndex=0||classLength=1]/child[Class=TabSet||index=0||length=1||classIndex=0||classLength=1]/paneContainer/member[Class=Canvas||index=0||length=1||classIndex=0||classLength=1]/child[Class=VLayout||index=0||length=1||classIndex=0||classLength=1]/member[Class=HLayout||index=0||length=3||classIndex=0||classLength=2]/member[Class=IButton||index=1||length=4||classIndex=0||classLength=1||roleIndex=0||roleLength=2||title=Show||scRole=button]/");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Bank%20static%20data||1]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Bank%20static%20data||1]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//autoID[Class=VLayout||index=0||length=2||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=2||classIndex=1||classLength=2]/member[Class=Canvas||index=1||length=2||classIndex=0||classLength=1]/child[Class=TabSet||index=0||length=1||classIndex=0||classLength=1]/paneContainer/member[Class=Canvas||index=0||length=1||classIndex=0||classLength=1]/child[Class=VLayout||index=0||length=1||classIndex=0||classLength=1]/member[Class=HLayout||index=2||length=3||classIndex=1||classLength=2]/member[Class=IButton||index=4||length=6||classIndex=4||classLength=6||roleIndex=4||roleLength=6||title=Export||scRole=button]/");
		selenium.click("scLocator=//autoID[Class=VLayout||index=0||length=2||classIndex=0||classLength=1]/member[Class=HLayout||index=1||length=2||classIndex=1||classLength=2]/member[Class=Canvas||index=1||length=2||classIndex=0||classLength=1]/child[Class=TabSet||index=0||length=1||classIndex=0||classLength=1]/paneContainer/member[Class=Canvas||index=0||length=1||classIndex=0||classLength=1]/child[Class=VLayout||index=0||length=1||classIndex=0||classLength=1]/member[Class=HLayout||index=2||length=3||classIndex=1||classLength=2]/member[Class=IButton||index=4||length=6||classIndex=4||classLength=6||roleIndex=4||roleLength=6||title=Export||scRole=button]/");
	}

}
