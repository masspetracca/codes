package com.easy;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;


public class TestAA extends junit.framework.TestCase {
	  	private String baseUrl;
	  	private boolean acceptNextAlert = true;
	  	private WebDriverBackedSelenium selenium;
	    private ChromeDriver wd;
	    
	    @Before
	    public void setUp() throws Exception {
//	      driver = new FirefoxDriver();
//	      baseUrl = "https://10.0.10.173:9443/CCAM/";
//	      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	      //driver.get(baseUrl + "/CCAM/");
	    	
	      System.setProperty("webdriver.chrome.driver", "c:/workspace/jdbcdrivers/chromedriver/chromedriver.exe");
	      wd = new ChromeDriver();
	      baseUrl = "https://accounts.google.com";
	      wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	      
	      selenium = new WebDriverBackedSelenium(wd, "http://10.0.10.173:9080/CCAM/?sc_selenium=true");
	    }

	    
	    @Test
	    public void junit() {
	        wd.findElement(By.xpath("//table[@id='isc_16table']//nobr[.='Limits']")).click();
	        wd.findElement(By.xpath("//table[@id='isc_16table']//td[.='Liquidity items']")).click();
	    }
	    
	    @After
	    public void tearDown() {
	        wd.quit();
	    }
	    
	    public boolean isAlertPresent(FirefoxDriver wd) {
	        try {
	            wd.switchTo().alert();
	            return true;
	        } catch (NoAlertPresentException e) {
	            return false;
	        }
	    }
	
}
