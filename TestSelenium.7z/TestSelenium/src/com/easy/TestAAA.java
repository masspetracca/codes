package com.easy;

	import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.firefox.FirefoxDriver;

	public class TestAAA {
	    public static void main(String[] args) throws Exception {
	        FirefoxDriver wd;
	        wd = new FirefoxDriver();
	        wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	        wd.get("http://10.0.10.173:9080/CCAM/?sc_selenium=true");
	        wd.findElement(By.xpath("//table[@id='isc_16table']//nobr[.='Limits']")).click();
	        wd.findElement(By.xpath("//table[@id='isc_16table']//td[.='Liquidity items']")).click();
	        wd.quit();
	    }
	    
	    public static boolean isAlertPresent(FirefoxDriver wd) {
	        try {
	            wd.switchTo().alert();
	            return true;
	        } catch (NoAlertPresentException e) {
	            return false;
	        }
	    }

}
