package com.example.tests;


import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import junit.framework.TestCase;

public class UntitledTestCase extends TestCase  {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.driver", "Firefox/firefox.exe");
    driver = new FirefoxDriver();
    baseUrl = "https://www.katalon.com/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testUntitledTestCase() throws Exception {
    driver.get("https://10.0.10.230:10044/VarPortalWEB/login.jsp");
    driver.findElement(By.id("Username")).clear();
    driver.findElement(By.id("Username")).sendKeys("mpetracc");
    driver.findElement(By.id("Password")).clear();
    driver.findElement(By.id("Password")).sendKeys(".mpetrac02");
    driver.findElement(By.id("submitLabel")).click();
    driver.findElement(By.xpath("//table[@id='isc_3Dtable']/tbody[2]/tr/td/div/span")).click();
    driver.findElement(By.xpath("//table[@id='isc_3Dtable']/tbody[2]/tr[2]/td/div/span")).click();
    driver.findElement(By.xpath("//table[@id='isc_3Dtable']/tbody[2]/tr/td/div/span")).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
