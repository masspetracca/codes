package com.example.tests;

import java.util.Map;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumTestPage {
    private Map<String, String> data;
    private WebDriver driver;
    private int timeout = 15;

    @FindBy(id = "isc_LinkItem_5$20j")
    @CacheLookup
    private WebElement logout;

    @FindBy(id = "isc_LinkItem_4$20j")
    @CacheLookup
    private WebElement manageProfile;

    @FindBy(id = "isc_LinkItem_6$20j")
    
    @CacheLookup
    private WebElement nomeCognomesProfileRiskOfficer;

    private final String pageLoadedText = "";

    private final String pageUrl = "/PampWeb/index.html";

    public SeleniumTestPage() {
    }

    
    public SeleniumTestPage(WebDriver driver) {
        this();
        this.driver = driver;
    }

    public SeleniumTestPage(WebDriver driver, Map<String, String> data) {
        this(driver);
        this.data = data;
    }

    public SeleniumTestPage(WebDriver driver, Map<String, String> data, int timeout) {
        this(driver, data);
        this.timeout = timeout;
    }

    /**
     * Click on Logout Link.
     *
     * @return the SeleniumTestPage class instance.
     */

    @Test
    public SeleniumTestPage clickLogoutLink() {
        logout.click();
        return this;
    }

    /**
     * Click on Manage Profile Link.
     *
     * @return the SeleniumTestPage class instance.
     */
    public SeleniumTestPage clickManageProfileLink() {
        manageProfile.click();
        return this;
    }

    /**
     * Click on Nome Cognomes Profile Risk Officer Link.
     *
     * @return the SeleniumTestPage class instance.
     */
    public SeleniumTestPage clickNomeCognomesProfileRiskOfficerLink() {
        nomeCognomesProfileRiskOfficer.click();
        return this;
    }

    /**
     * Verify that the page loaded completely.
     *
     * @return the SeleniumTestPage class instance.
     */
    public SeleniumTestPage verifyPageLoaded() {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return d.getPageSource().contains(pageLoadedText);
            }
        });
        return this;
    }

    /**
     * Verify that current page URL matches the expected URL.
     *
     * @return the SeleniumTestPage class instance.
     */
    public SeleniumTestPage verifyPageUrl() {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return d.getCurrentUrl().contains(pageUrl);
            }
        });
        return this;
    }
}