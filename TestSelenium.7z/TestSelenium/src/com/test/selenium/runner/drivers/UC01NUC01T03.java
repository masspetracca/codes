package com.test.selenium.runner.drivers;

import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

import org.openqa.selenium.*;
import org.openqa.selenium.htmlunit.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.ie.*;
import org.junit.*;
import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

public class UC01NUC01T03 {

	WebDriver driver;
	Selenium selenium;

	@Before
	public void startSelenium() {
	    //System.setProperty("webdriver.FirefoxDriver.driver", "C:/workspaceSPARX/TestSelenium/Firefox/firefox.exe");
	    //driver = new FirefoxDriver();
		//WebDriver driver = new FirefoxDriver();
	    System.setProperty("webdriver.chrome.driver", "c:/workspace/jdbcdrivers/chromedriver/chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String baseUrl = "https://10.0.10.230:10162/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}

	@After
	public void stopSelenium() {
		selenium.close();
	}

	@Test
	public void testUC01NUC01T03() {
		selenium.open("/PampWeb/login.jsp");
		selenium.type("Username", "qauser");
		selenium.type("Password", "qauser");
		selenium.click("id=submitLabel");
		selenium.waitForPageToLoad("35000");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/editRowForm/item[name=STDEVPMUL||title=St.%20dev.%20coef.||value=1||index=1||Class=FloatItem]/element");
		selenium.selectWindow("name=1461944388731");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/editRowForm/item[name=STDEVPMUL||title=St.%20dev.%20coef.||value=1||index=1||Class=FloatItem]/element", "1");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/editRowForm/item[name=STDEVNMUL||title=St.%20dev.%20coef.||value=1||index=4||Class=FloatItem]/element");
		selenium.selectWindow("name=1461944388731");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/editRowForm/item[name=STDEVNMUL||title=St.%20dev.%20coef.||value=1||index=4||Class=FloatItem]/element", "1");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/editRowForm/item[name=STDEVPMUL||title=St.%20dev.%20coef.||value=4||index=1||Class=FloatItem]/element");
		selenium.selectWindow("name=1461944388731");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/editRowForm/item[name=STDEVPMUL||title=St.%20dev.%20coef.||value=4||index=1||Class=FloatItem]/element", "4");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/editRowForm/item[name=STDEVNMUL||title=St.%20dev.%20coef.||value=4||index=4||Class=FloatItem]/element");
		selenium.selectWindow("name=1461944388731");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/editRowForm/item[name=STDEVNMUL||title=St.%20dev.%20coef.||value=4||index=4||Class=FloatItem]/element", "4");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.secondClick("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/editRowForm/item[name=STDEVPMUL||title=St.%20dev.%20coef.||value=5||index=1||Class=FloatItem]/element");
		selenium.selectWindow("name=1461944388731");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/editRowForm/item[name=STDEVPMUL||title=St.%20dev.%20coef.||value=5||index=1||Class=FloatItem]/element", "5");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/editRowForm/item[name=STDEVNMUL||title=St.%20dev.%20coef.||value=5||index=4||Class=FloatItem]/element");
		selenium.selectWindow("name=1461944388731");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/editRowForm/item[name=STDEVNMUL||title=St.%20dev.%20coef.||value=5||index=4||Class=FloatItem]/element", "5");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/body/");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/body/");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//DynamicForm[ID=\"isc_DynamicForm_31\"]/item[name=isc_StandardSelectItem_4||title=%3Cnobr%3EFilter%3C%24fs%24nobr%3E||value=B||index=0||Class=SelectItem]/[icon=\"picker\"]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//DynamicForm[ID=\"isc_DynamicForm_31\"]/item[name=isc_StandardSelectItem_4||title=%3Cnobr%3EFilter%3C%24fs%24nobr%3E||value=B||index=0||Class=SelectItem]/[icon=\"picker\"]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//DynamicForm[ID=\"isc_DynamicForm_22\"]/item[name=isc_StandardSelectItem_2||title=%3Cnobr%3EFilter%3C%24fs%24nobr%3E||value=14||index=0||Class=SelectItem]/[icon=\"picker\"]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//DynamicForm[ID=\"isc_DynamicForm_22\"]/item[name=isc_StandardSelectItem_2||title=%3Cnobr%3EFilter%3C%24fs%24nobr%3E||value=14||index=0||Class=SelectItem]/[icon=\"picker\"]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/filterEditor/editRowForm/item[name=SCENARIO||title=Scenario||index=2||Class=SelectItem]/[icon=\"picker\"]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/filterEditor/editRowForm/item[name=SCENARIO||title=Scenario||index=2||Class=SelectItem]/[icon=\"picker\"]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/filterEditor/editRowForm/item[name=INSTRID||title=Instrument%20ID||index=3||Class=ComboBoxItem]/[icon=\"picker\"]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/filterEditor/editRowForm/item[name=INSTRID||title=Instrument%20ID||index=3||Class=ComboBoxItem]/[icon=\"picker\"]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/filterEditor/editRowForm/item[name=INSTRID||title=Instrument%20ID||value=15416||index=3||Class=ComboBoxItem]/element");
		selenium.selectWindow("name=1461944388731");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/filterEditor/editRowForm/item[name=INSTRID||title=Instrument%20ID||value=15416||index=3||Class=ComboBoxItem]/element", "15416");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.selectWindow("name=1461944388731");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.waitForPageToLoad("35000");
	}

}
