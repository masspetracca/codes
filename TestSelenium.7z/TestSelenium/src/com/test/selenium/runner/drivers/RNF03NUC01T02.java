package com.test.selenium.runner.drivers;

import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

import org.openqa.selenium.*;
import org.openqa.selenium.htmlunit.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.ie.*;
import org.junit.*;
import static org.junit.Assert.*;

public class RNF03NUC01T02 {

	WebDriver driver;
	Selenium selenium;

	@Before
	public void startSelenium() {
		driver = new FirefoxDriver();
		selenium = new WebDriverBackedSelenium(driver, "https://10.0.10.230:10162/");
	}

	@After
	public void stopSelenium() {
		selenium.close();
	}

	@Test
	public void testRNF03NUC01T02() {
		selenium.open("/PampWeb/login.jsp");
		selenium.type("Username", "qaapprover");
		selenium.type("Password", "qaapprover");
		selenium.click("id=submitLabel");
		selenium.waitForPageToLoad("35000");
		selenium.selectWindow("null");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Reverse%20Stress%20Test||13]/col[fieldName=name||0]/open");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Reverse%20Stress%20Test||13]/col[fieldName=name||0]/open");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Settings||20]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Settings||20]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
	}

}
