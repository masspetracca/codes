package com.test.selenium.runner.drivers;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import ccg.ftrr.freader.batch.GetFiles;
import ccg.ftrr.freader.batch.PropertyFiles;
import ccg.ftrr.freader.batch.Refobj;

public class RNFMain {
	
	@Before
	public void initialize() throws IOException {
	 String[] line;

	  int returnCode = 0;
	  System.out.println("Inizio esecuzione <MAIN>");
	//Filtra e carica i files *.out
	  GetFiles();
	  int lString = 10;
	  Refobj refObj = new Refobj();
	  //String [] nameRF = null ;
	  //= new String[lString];
	  //refObj.setRefObj(nameRF);
	  
	  while (refObj.getRefobj() != null) { 
		  for (int i=0;i<= 10;i++) {
			  line = refObj.getRefobj(); 
			 System.out.println("Line/obj:"+line);
		  }
	  }
	  if (returnCode != 0) {
		 System.out.println("Errore nella fase  <DataFile> - verificare !");
	  }
	  System.out.println("Fine esecuzione <MAIN>");
	}
	
	
	RNF01NUC01T01 rf01 = new RNF01NUC01T01();

	@Before
	public void Rnf01Start() throws Exception {
		rf01.startSelenium(); 
	}
	

	@Test
	public void Rnf01() throws Exception {
		rf01.testRNF01NUC01T01();
	}
	
	@After
	public void Rnf01End() throws Exception {
		rf01.tearDown(); 
	}


	//
	RNF01NUC01T02 rf02 = new RNF01NUC01T02();
	@Before
	public void Rnf02Start() throws Exception {
		rf02.startSelenium(); 
	}
	@Test
	public void Rnf02() throws Exception {
		rf02.testRNF01NUC01T02();
	}
	@After
	public void Rnf02End() throws Exception {
		rf02.stopSelenium(); 
	}
	//
	//
	RNF01NUC01T03 rf03 = new RNF01NUC01T03();
	@Before
	public void Rnf03Start() throws Exception {
		rf03.startSelenium(); 
	}
	@Test
	public void Rnf03() throws Exception {
		rf03.testRNF01NUC01T03();
	}
	@After
	public void Rnf03End() throws Exception {
		rf02.stopSelenium(); 
	}
	
	private static void Errore() {
		// TODO Auto-generated method stub
		
	}
	


	private static void LoadReq() {
		// TODO Auto-generated method stub
		
	}


	private void GetFiles() throws IOException {
		GetFiles gf = new GetFiles(); 		
	}
	private void GetProperties() throws IOException {
		PropertyFiles pf = new PropertyFiles();		
	}

}
