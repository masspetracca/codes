package com.test.selenium.runner.drivers;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

public class RNF01NUC01T01prova {

	WebDriver driver;
	Selenium selenium;

	@Before
	public void startSelenium() {
	    System.setProperty("webdriver.FirefoxDriver.driver", "C:/workspaceSPARX/TestSelenium/Firefox/firefox.exe");
	    driver = new FirefoxDriver();
		WebDriver driver = new FirefoxDriver();
/*
		System.setProperty("webdriver.chrome.driver", "c:/workspace/jdbcdrivers/chromedriver/chromedriver.exe");
	    driver = new ChromeDriver();
*/
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String baseUrl = "https://10.0.10.230:10162/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}

	@After
	public void stopSelenium() {
		selenium.close(); //
	}

	@Test
	public void testRNF01NUC01T01prova() {
		selenium.open("/PampWeb/login.jsp");
		String ps = "prova store ---";
		System.out.println(ps);
		//selenium.getText(ps); //
		selenium.type("Username", "mpetracca");
		selenium.type("Password", "Petracca1");
		selenium.click("id=submitLabel");
		selenium.waitForPageToLoad("35000");
		selenium.selectWindow("null");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Reverse%20Stress%20Test||13]/col[fieldName=name||0]/open");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Reverse%20Stress%20Test||13]/col[fieldName=name||0]/open");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Settings||20]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Settings||20]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=STDEVPMUL||title=St.%20dev.%20coef.||value=1||index=1||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=STDEVPMUL||title=St.%20dev.%20coef.||value=1||index=1||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=MARPMUL||title=Margin%20coef.||value=1||index=2||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=MARPMUL||title=Margin%20coef.||value=1||index=2||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=EXTPMUL||title=Extr.%20var.%20coef.||value=1||index=3||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=EXTPMUL||title=Extr.%20var.%20coef.||value=1||index=3||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=STDEVNMUL||title=St.%20dev.%20coef.||value=1||index=4||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=STDEVNMUL||title=St.%20dev.%20coef.||value=1||index=4||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=MARNMUL||title=Margin%20coef.||value=1||index=5||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=MARNMUL||title=Margin%20coef.||value=1||index=5||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=EXTNMUL||title=Extr.%20var.%20coef.||value=1||index=6||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=EXTNMUL||title=Extr.%20var.%20coef.||value=1||index=6||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=PARINC||title=Increase||value=1||index=7||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=PARINC||title=Increase||value=1||index=7||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=PARDEC||title=Decrease||value=1||index=8||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=PARDEC||title=Decrease||value=1||index=8||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Settings||20]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Settings||20]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
	}

}
