package com.test.selenium.runner.drivers;

import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

import org.openqa.selenium.*;
import org.openqa.selenium.htmlunit.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.ie.*;
import org.junit.*;
import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

public class RNF01NUC01T04 {

	WebDriver driver;
	Selenium selenium;


	@Before
	public void startSelenium() {
	    //System.setProperty("webdriver.FirefoxDriver.driver", "C:/workspaceSPARX/TestSelenium/Firefox/firefox.exe");
	    //driver = new FirefoxDriver();
		//WebDriver driver = new FirefoxDriver();
	    System.setProperty("webdriver.chrome.driver", "c:/workspace/jdbcdrivers/chromedriver/chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String baseUrl = "https://10.0.10.230:10162/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}
	@After
	public void stopSelenium() {
		selenium.close();
	}

	@Test
	public void testRNF01NUC01T04() {
		selenium.open("/PampWeb/login.jsp");
		selenium.type("Username", "mpetracca");
		selenium.type("Password", "Petracca1");
		selenium.click("id=submitLabel");
		selenium.waitForPageToLoad("35000");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Reverse%20Stress%20Test||13]/col[fieldName=name||0]/open");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Reverse%20Stress%20Test||13]/col[fieldName=name||0]/open");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//DynamicForm[ID=\"isc_DynamicForm_8\"]/item[name=isc_StandardSelectItem_0||title=%3Cnobr%3EFilter%3C%24fs%24nobr%3E||index=0||Class=SelectItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//DynamicForm[ID=\"isc_DynamicForm_8\"]/item[name=isc_StandardSelectItem_0||title=%3Cnobr%3EFilter%3C%24fs%24nobr%3E||index=0||Class=SelectItem]/[icon=\"picker\"]");
		// selenium.waitForElementClickable("scLocator=//HLayout[ID=\"isc_HLayout_3\"]/");
		selenium.click("scLocator=//HLayout[ID=\"isc_HLayout_3\"]/");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Settings||20]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Settings||20]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//IButton[ID=\"isc_StandardButton_4\"]/");
		selenium.click("scLocator=//IButton[ID=\"isc_StandardButton_4\"]/");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/body/");
		selenium.click("scLocator=//ListGrid[ID=\"isc_StandardListGrid_1\"]/body/");
		// selenium.waitForElementClickable("scLocator=//DynamicForm[ID=\"isc_DynamicForm_11\"]/item[name=isc_StandardSelectItem_1||title=%3Cnobr%3E%3Cnobr%3ESettings%20applied%20to%20the%20following%20instrument%20type%3C%24fs%24nobr%3E%3C%24fs%24nobr%3E||value=EF||index=0||Class=SelectItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//DynamicForm[ID=\"isc_DynamicForm_11\"]/item[name=isc_StandardSelectItem_1||title=%3Cnobr%3E%3Cnobr%3ESettings%20applied%20to%20the%20following%20instrument%20type%3C%24fs%24nobr%3E%3C%24fs%24nobr%3E||value=EF||index=0||Class=SelectItem]/[icon=\"picker\"]");
	}

}
