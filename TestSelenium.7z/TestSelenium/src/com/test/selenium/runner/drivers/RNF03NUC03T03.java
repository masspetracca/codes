package com.test.selenium.runner.drivers;

import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

import org.openqa.selenium.*;
import org.openqa.selenium.htmlunit.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.ie.*;
import org.junit.*;
import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

public class RNF03NUC03T03 {

	WebDriver driver;
	Selenium selenium;

	@Before
	public void startSelenium() {
	    //System.setProperty("webdriver.FirefoxDriver.driver", "C:/workspaceSPARX/TestSelenium/Firefox/firefox.exe");
	    //driver = new FirefoxDriver();
		//WebDriver driver = new FirefoxDriver();
	    System.setProperty("webdriver.chrome.driver", "c:/workspace/jdbcdrivers/chromedriver/chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String baseUrl = "https://10.0.10.230:10162/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}

	@After
	public void stopSelenium() {
		selenium.close();
	}

	@Test
	public void testRNF03NUC03T03() {
		selenium.open("/PampWeb/login.jsp");
		selenium.type("id=Username", "qaaprover");
		selenium.type("id=Password", "qaaprover");
		selenium.click("id=submitLabel");
		selenium.waitForPageToLoad("35000");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Reverse%20Stress%20Test||13]/col[fieldName=name||0]/open");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Reverse%20Stress%20Test||13]/col[fieldName=name||0]/open");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//DynamicForm[ID=\"isc_DynamicForm_8\"]/item[name=isc_StandardSelectItem_0||title=%3Cnobr%3EFilter%3C%24fs%24nobr%3E||index=0||Class=SelectItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//DynamicForm[ID=\"isc_DynamicForm_8\"]/item[name=isc_StandardSelectItem_0||title=%3Cnobr%3EFilter%3C%24fs%24nobr%3E||index=0||Class=SelectItem]/[icon=\"picker\"]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//Window[ID=\"ReverseTestRegister\"]/body/");
		selenium.click("scLocator=//Window[ID=\"ReverseTestRegister\"]/body/");
		// selenium.secondClick("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//DynamicForm[ID=\"isc_PopUpTextAreaItem_0$21t\"]/item[name=textArea||title=textArea||value=Reverse%20stress%20test%20manually%20executed%20on%202016-04-29%20%280%20iteration%29%20-%20test%20QA%2029%24fs%2404%24fs%242016%2011%3A06%0A%0A||index=0||Class=TextAreaItem]/element");
		selenium.type("scLocator=//DynamicForm[ID=\"isc_PopUpTextAreaItem_0$21t\"]/item[name=textArea||title=textArea||value=Reverse%20stress%20test%20manually%20executed%20on%202016-04-29%20%280%20iteration%29%20-%20test%20QA%2029%24fs%2404%24fs%242016%2011%3A06%0A%0A||index=0||Class=TextAreaItem]/element", "Reverse stress test manually executed on 2016-04-29 (0 iteration) - test QA 29/04/2016 11:06");
		// selenium.waitForElementClickable("scLocator=//Window[ID=\"ReverseTestRegister\"]/item[0][Class=\"ListGrid\"]/body/");
		selenium.click("scLocator=//Window[ID=\"ReverseTestRegister\"]/item[0][Class=\"ListGrid\"]/body/");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.secondClick("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//Window[ID=\"ReverseTestRegister\"]/item[0][Class=\"ListGrid\"]/editRowForm/item[name=DIVISCODE||title=Division||value=L||index=4||Class=SelectItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//Window[ID=\"ReverseTestRegister\"]/item[0][Class=\"ListGrid\"]/editRowForm/item[name=DIVISCODE||title=Division||value=L||index=4||Class=SelectItem]/[icon=\"picker\"]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//Window[ID=\"ReverseTestRegister\"]/item[0][Class=\"ListGrid\"]/editRowForm/item[name=DIVISCODE||title=Division||value=M||index=4||Class=SelectItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//Window[ID=\"ReverseTestRegister\"]/item[0][Class=\"ListGrid\"]/editRowForm/item[name=DIVISCODE||title=Division||value=M||index=4||Class=SelectItem]/[icon=\"picker\"]");
		// selenium.waitForElementClickable("scLocator=//Window[ID=\"ReverseTestRegister\"]/item[0][Class=\"ListGrid\"]/editRowForm/item[name=DIVISCODE||title=Division||value=M||index=4||Class=SelectItem]/pickList/body/row[DIVISCODE=L||4]/col[fieldName=DIVISCODE||0]");
		selenium.click("scLocator=//Window[ID=\"ReverseTestRegister\"]/item[0][Class=\"ListGrid\"]/editRowForm/item[name=DIVISCODE||title=Division||value=M||index=4||Class=SelectItem]/pickList/body/row[DIVISCODE=L||4]/col[fieldName=DIVISCODE||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
	}

}
