package com.test.selenium.runner.run1.drivers;

import com.thoughtworks.selenium.Selenium;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import static org.apache.commons.lang3.StringUtils.join;

public class RNF03NUC01T01 {
	private WebDriver driver;
	private Selenium selenium;
	
	@Before
	public void setUp() throws Exception {
	    //System.setProperty("webdriver.FirefoxDriver.driver", "C:/workspaceSPARX/TestSelenium/Firefox/firefox.exe");
	    //driver = new FirefoxDriver();
		//WebDriver driver = new FirefoxDriver();
	    System.setProperty("webdriver.chrome.driver", "c:/workspace/jdbcdrivers/chromedriver/chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String baseUrl = "https://10.0.10.230:10162/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}

	@Test
	public void testRNF03NUC01T01() throws Exception {
		selenium.open("/PampWeb/index.html");
		selenium.type("Username", "qaapprover");
		selenium.type("Password", "qaapprover");
		selenium.click("id=submitLabel");
		selenium.waitForPageToLoad("35000");
		selenium.selectWindow("null");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Reverse%20Stress%20Test||13]/col[fieldName=name||0]/open");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Reverse%20Stress%20Test||13]/col[fieldName=name||0]/open");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Settings||20]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Settings||20]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=STDEVPMUL||title=St.%20dev.%20coef.||value=1||index=1||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=STDEVPMUL||title=St.%20dev.%20coef.||value=1||index=1||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=MARPMUL||title=Margin%20coef.||value=1||index=2||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=MARPMUL||title=Margin%20coef.||value=1||index=2||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=EXTPMUL||title=Extr.%20var.%20coef.||value=1||index=3||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=EXTPMUL||title=Extr.%20var.%20coef.||value=1||index=3||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=STDEVNMUL||title=St.%20dev.%20coef.||value=1||index=4||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=STDEVNMUL||title=St.%20dev.%20coef.||value=1||index=4||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=MARNMUL||title=Margin%20coef.||value=1||index=5||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=MARNMUL||title=Margin%20coef.||value=1||index=5||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=EXTNMUL||title=Extr.%20var.%20coef.||value=1||index=6||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=EXTNMUL||title=Extr.%20var.%20coef.||value=1||index=6||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=PARINC||title=Increase||value=1||index=7||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=PARINC||title=Increase||value=1||index=7||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=PARDEC||title=Decrease||value=1||index=8||Class=FloatItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_StandardListGrid_0\"]/editRowForm/item[name=PARDEC||title=Decrease||value=1||index=8||Class=FloatItem]/element", "1");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Settings||20]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Settings||20]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=R.S.T.%20Elec.%20Scenario%20Statistics||17]/col[fieldName=name||0]");
	}

	@After
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
