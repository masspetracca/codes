package com.test.selenium.runner.run1.drivers;

import com.thoughtworks.selenium.Selenium;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import static org.apache.commons.lang3.StringUtils.join;

public class RNF03NUC02T01 {
	private WebDriver driver;
	private Selenium selenium;
	
	
	@Before
	public void setUp() throws Exception {
	    //System.setProperty("webdriver.FirefoxDriver.driver", "C:/workspaceSPARX/TestSelenium/Firefox/firefox.exe");
	    //driver = new FirefoxDriver();
		//WebDriver driver = new FirefoxDriver();
	    System.setProperty("webdriver.chrome.driver", "c:/workspace/jdbcdrivers/chromedriver/chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String baseUrl = "https://10.0.10.230:10162/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);	}

	@Test
	public void testRNF03NUC02T01() throws Exception {
		selenium.open("/PampWeb/index.html");
		selenium.type("Username", "qaapprover");
		selenium.type("Password", "qaapprover");
		selenium.click("id=submitLabel");
		selenium.waitForPageToLoad("35000");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=BATCHID||title=Job%24fs%24Batch||index=2||Class=ComboBoxItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=BATCHID||title=Job%24fs%24Batch||index=2||Class=ComboBoxItem]/[icon=\"picker\"]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.dragAndDrop("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]", "-4,+231");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=ATTMKTDATE||title=Only%20market%20dates||index=3||Class=SelectItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=ATTMKTDATE||title=Only%20market%20dates||index=3||Class=SelectItem]/[icon=\"picker\"]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=FREQUENCY||title=Frequency||index=4||Class=SelectItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=FREQUENCY||title=Frequency||index=4||Class=SelectItem]/[icon=\"picker\"]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=FIXEDTIME||title=Sched.%20date%24fs%24time||index=5||Class=DateItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=FIXEDTIME||title=Sched.%20date%24fs%24time||index=5||Class=DateItem]/[icon=\"picker\"]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=PRCNAME||title=Schedule%20name||value=TestBatchRStressTest1||index=0||Class=TextItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=PRCNAME||title=Schedule%20name||value=TestBatchRStressTest1||index=0||Class=TextItem]/element", "TestBatchRStressTest1");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=PRCNAME||title=Schedule%20name||value=RevStressTest1||index=0||Class=TextItem]/element");
		selenium.type("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=PRCNAME||title=Schedule%20name||value=RevStressTest1||index=0||Class=TextItem]/element", "RevStressTest1");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=BATCHID||title=Job%24fs%24Batch||index=2||Class=ComboBoxItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=BATCHID||title=Job%24fs%24Batch||index=2||Class=ComboBoxItem]/[icon=\"picker\"]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.dragAndDrop("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]", "-6,+227");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=ATTMKTDATE||title=Only%20market%20dates||index=3||Class=SelectItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=ATTMKTDATE||title=Only%20market%20dates||index=3||Class=SelectItem]/[icon=\"picker\"]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=FREQUENCY||title=Frequency||index=4||Class=SelectItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=FREQUENCY||title=Frequency||index=4||Class=SelectItem]/[icon=\"picker\"]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=FIXEDTIME||title=Sched.%20date%24fs%24time||index=5||Class=DateItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=FIXEDTIME||title=Sched.%20date%24fs%24time||index=5||Class=DateItem]/[icon=\"picker\"]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.secondClick("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=FIXEDTIME||title=Sched.%20date%24fs%24time||value=Thu Apr 21 2016 00:00:00 GMT+0200 (W. Europe Standard Time)||index=5||Class=DateItem]/[icon=\"picker\"]");
		selenium.click("scLocator=//ListGrid[ID=\"isc_GenSchedulerPanel_3_0\"]/editRowForm/item[name=FIXEDTIME||title=Sched.%20date%24fs%24time||value=Thu Apr 21 2016 00:00:00 GMT+0200 (W. Europe Standard Time)||index=5||Class=DateItem]/[icon=\"picker\"]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		// selenium.waitForElementClickable("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
		selenium.click("scLocator=//TreeGrid[ID=\"sidenavtree\"]/body/row[name=Scheduler||18]/col[fieldName=name||0]");
	}

	@After
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
