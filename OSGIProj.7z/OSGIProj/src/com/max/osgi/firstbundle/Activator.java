package com.max.osgi.firstbundle;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

import com.max.osgi.firstbundle.internal.MyThread;

public class Activator implements BundleActivator {
  private MyThread myThread;

  public void start(BundleContext context) throws Exception {
    System.out.println("Starting com.max.osgi.firstbundle");
    myThread = new MyThread();
    myThread.start();
  }

  
  public void stop(BundleContext context) throws Exception {
    System.out.println("Stopping com.max.osgi.firstbundle");
    myThread.stopThread();
    myThread.join();
  }

} 
