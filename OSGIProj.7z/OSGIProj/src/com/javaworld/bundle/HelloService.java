package com.javaworld.bundle;

public interface HelloService {
    public String sayHello();
}