package com.javaworld.bundle;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
/*
 * If your bundle needs to be notified at the time 
 * of bundle startup or shutdown then you should create a class implementing 
 * the BundleActivator interface (deve avere costruttori pubblici)
 * Follow these rules when creating the class:
 * Class.newInstance()
 * 
 */
public class Activator implements BundleActivator {
    public void start(BundleContext context) throws Exception {
        System.out.println("Hello Daniele");
    }
    public void stop(BundleContext context) throws Exception {
        System.out.println("Goodbye Daniele");
    }
}