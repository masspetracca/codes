package com.javaworld.sample;

import org.osgi.framework.Bundle;
import org.osgi.framework.ServiceFactory;
import org.osgi.framework.ServiceRegistration;

import com.javaworld.bundle.HelloService;
/*
 *    - getService(): The OSGi framework invokes this method the first time the specified bundle requests a service object using the BundleContext.getService(ServiceReference) method. 
 *     In Listing 9, we use this method to create a different object of HelloServiceImpl for every bundle, and we return that object. 
 *     The OSGi framework caches the value returned (unless it is null), and will return the same service object on any future calls to BundleContext.getService() 
 *    from the same bundle.
 *    - ungetService():  The OSGi container invokes this method when a service has been released by a bundle. 
 *    The service object may then be destroyed. In Listing 9, we use this method to reduce the usageCount of the service and print the number of clients for the service.
 *    Change HelloServiceActivator.java and modify the start() method of your activator so that it will register objects of ServiceFactory instead of HelloService, as shown in Listing 10: 
 */
public class HelloServiceFactory implements ServiceFactory{
    private int usageCounter = 0;
    public Object getService(Bundle bundle, ServiceRegistration registration) {
        System.out.println("Create object of HelloService for " + bundle.getSymbolicName());
        usageCounter++;
        System.out.println("Number of bundles using service " + usageCounter);
        HelloService helloService = new HelloServiceImpl();
        return helloService;
    }
    public void ungetService(Bundle bundle, ServiceRegistration registration, Object service) {
        System.out.println("Release object of HelloService for " + bundle.getSymbolicName());
        usageCounter--;
        System.out.println("Number of bundles using service " + usageCounter);
    }
}