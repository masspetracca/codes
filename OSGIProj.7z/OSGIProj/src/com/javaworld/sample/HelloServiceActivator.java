package com.javaworld.sample;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

import com.javaworld.bundle.HelloService;
/*
 * source bundle should use the BundleContext.registerService()
 * create a String array of interface names and pass it as your first argument.
 * In the sample code we want to export the service under the name of 
 * HelloService interface.
 * We are exporting objects of the HelloServiceImpl class as the service.
 * HelloService bundle is ready to export objects of the HelloServiceImpl class. 
 * When the OSGi container starts the HelloService bundle it will pass control to HelloServiceActivator.java, which will register an object of HelloServiceImpl as a service. 
 * The next step is to create the service consumer.
 */
public class HelloServiceActivator implements BundleActivator  {
    ServiceRegistration helloServiceRegistration;
    public void start(BundleContext context) throws Exception {
        HelloService helloService = new HelloServiceImpl();
        helloServiceRegistration =context.registerService(HelloService.class.getName(), helloService, null);
    }
    public void stop(BundleContext context) throws Exception {
        helloServiceRegistration.unregister();
    }
}