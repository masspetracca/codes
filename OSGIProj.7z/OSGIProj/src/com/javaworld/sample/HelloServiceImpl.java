package com.javaworld.sample;

import com.javaworld.bundle.HelloService;

public class HelloServiceImpl implements HelloService{
    public String sayHello() {
        System.out.println("Inside HelloServiceImple.sayHello()");
        return "Say Hello";
    }
}