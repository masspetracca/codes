package com.javaworld.sample;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import com.javaworld.bundle.HelloService;

/*
 * The BundleContext.getServiceReference() method returns a 
 * ServiceReference object for a service registered under the HelloService interface
 *  clicking Run --> Run Simply make sure that both the HelloWorld and HelloService bundles are checked in as plugins. 
 *  When you start the HelloService bundle, you will see the message "Inside HelloServiceImple.sayHello()" printed from the HelloServiceImpl.sayHello() method.
 */
public class Activator implements BundleActivator {
    ServiceReference helloServiceReference;
    public void start(BundleContext context) throws Exception {
        System.out.println("Hello World!!");
        helloServiceReference= context.getServiceReference(HelloService.class.getName());
        HelloService helloService =(HelloService)context.getService(helloServiceReference);
        System.out.println(helloService.sayHello());

    }
    public void stop(BundleContext context) throws Exception {
        System.out.println("Goodbye World!!");
        context.ungetService(helloServiceReference);
    }
}