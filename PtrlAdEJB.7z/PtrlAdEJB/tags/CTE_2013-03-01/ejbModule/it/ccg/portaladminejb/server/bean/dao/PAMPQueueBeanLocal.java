package it.ccg.portaladminejb.server.bean.dao;

import it.ccg.portaladminejb.server.dto.PAMPQueueEntry;

import java.util.List;

public interface PAMPQueueBeanLocal {
	
	public List<PAMPQueueEntry> listQueueEntries() throws Exception;
	public void emptyQueue() throws Exception;
	
	public void addQueueEntry() throws Exception;
	
	
}
