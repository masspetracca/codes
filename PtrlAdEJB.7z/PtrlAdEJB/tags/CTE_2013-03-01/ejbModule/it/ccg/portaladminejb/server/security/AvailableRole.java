package it.ccg.portaladminejb.server.security;

public class AvailableRole {
	
	public static final String USER = "user";
	public static final String ADMIN = "admin";

}
