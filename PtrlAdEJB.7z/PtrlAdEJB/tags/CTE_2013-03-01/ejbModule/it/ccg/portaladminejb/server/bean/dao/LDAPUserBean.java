package it.ccg.portaladminejb.server.bean.dao;

import java.util.List;
import java.util.Map;

import it.ccg.portaladminejb.server.dto.LDAPUserDTO;
import it.ccg.portaladminejb.server.service.ldap.LDAPManager;

import javax.ejb.Local;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class User
 */
@Stateless
@Local(LDAPUserBeanLocal.class)
public class LDAPUserBean implements LDAPUserBeanLocal {
	
	
    /**
     * Default constructor. 
     */
    public LDAPUserBean() {
        // TODO Auto-generated constructor stub
    }
    
    
    
	@Override
	public List<LDAPUserDTO> listLDAPUsers() throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		List<LDAPUserDTO> list = manager.listUsers();
		
		
		return list;
	}
	
	
	@Override
	public LDAPUserDTO getLDAPUserByContextName(String userContextName) throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		LDAPUserDTO user = manager.getUserByContextName(userContextName);
		
		
		return user;
	}
	
	
	@Override
	public LDAPUserDTO getLDAPUserByCN(String cn) throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		LDAPUserDTO user = manager.getUserByCN(cn);
		
		
		return user;
	}
	
	@Override
	public LDAPUserDTO getLDAPUserByUID(String uid) throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		LDAPUserDTO user = manager.getUserByUID(uid);
		
		
		return user;
	}
	
	
	@Override
	public Map<String, String> get_O_C_OU() throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		
		return manager.get_O_C_OU();
	}
	
	
	@Override
	public void addLDAPUser(LDAPUserDTO ldapUserDTO) throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		manager.addUser(ldapUserDTO);
	}
	
	
	
	@Override
	public void removeLDAPUser(LDAPUserDTO ldapUserDTO) throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		manager.removeUser(ldapUserDTO);
	}
	
	@Override
	public void removeLDAPUser(String userContextName) throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		manager.removeUser(userContextName);
	}



	@Override
	public boolean exists(LDAPUserDTO ldapUserDTO) throws Exception {
		
		
		return this.listLDAPUsers().contains(ldapUserDTO);
	}
	
	
	@Override
	public boolean uidAlreadyInUse(LDAPUserDTO ldapUserDTO) throws Exception {
		
		boolean result = false;
		
		List<LDAPUserDTO> list = this.listLDAPUsers();
		for(LDAPUserDTO user : list) {
			
			if(user.getUid().equalsIgnoreCase(ldapUserDTO.getUid())) {
				
				result = true;
				
				break;
			}
		}
		
		
		return result;
	}

	

}
