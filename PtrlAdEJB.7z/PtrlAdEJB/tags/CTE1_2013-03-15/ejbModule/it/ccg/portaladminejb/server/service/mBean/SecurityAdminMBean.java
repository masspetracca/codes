package it.ccg.portaladminejb.server.service.mBean;

import it.ccg.portaladminejb.server.dto.LDAPUserDTO;
import it.ccg.portaladminejb.server.dto.WSUserDTO;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;
import it.ccg.portaladminejb.server.service.ldap.LDAPManager;
import it.ccg.portaladminejb.server.util.ExceptionUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import org.apache.log4j.Logger;

import com.ibm.websphere.management.AdminClient;
import com.ibm.websphere.management.exception.ConnectorException;
import com.ibm.websphere.security.Result;

public class SecurityAdminMBean {
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.EJB_LOGGER);
	
	
	private String securityAdminQuery = "WebSphere:*,type=SecurityAdmin";
	private ObjectName securityAdminMBean;
	
	private AdminClient adminClient = null;
	
	public SecurityAdminMBean() throws Exception {
		
		try {
			this.adminClient = AdminClientManager.getAdminClient();
			
			ObjectName objectName = new ObjectName(securityAdminQuery);
			
			Set<?> set = this.adminClient.queryNames(objectName, null);
			
			
			logger.info(new StandardLogMessage("Connected to " + securityAdminQuery));
			
			
			this.securityAdminMBean = (ObjectName)set.iterator().next();
		}
		catch(MalformedObjectNameException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		catch(NullPointerException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		catch(ConnectorException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		catch(Exception e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
	}
	
	
	public List<WSUserDTO> getUsers() throws Exception {
		
		Object[] params = {"*", new Integer(0), null};
		String[] signature = {"java.lang.String", "java.lang.Integer", "java.util.Properties"};
		
		Result result = (Result)adminClient.invoke(this.securityAdminMBean, "getUsers", params, signature);
		
		@SuppressWarnings("unchecked")
		List<String> userContextNameList = (List<String>)result.getList();
		
		LDAPManager ldapManager = new LDAPManager();
		
		List<WSUserDTO> userList = new ArrayList<WSUserDTO>();
		
		LDAPUserDTO ldapUserDTO = null;
		
		for(String userContextName : userContextNameList) {
			
			ldapUserDTO = ldapManager.getUserByContextName(userContextName);
			
			userList.add(new WSUserDTO(ldapUserDTO.getCn(), ldapUserDTO.getO(), ldapUserDTO.getC(), ldapUserDTO.getUid()));
		}
		
		
		return userList;
	}
	
	
	
}
