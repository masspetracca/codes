package it.ccg.portaladminejb.server.service.ldap;

import it.ccg.portaladminejb.server.dto.LDAPUserDTO;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;
import it.ccg.portaladminejb.server.security.Security;
import it.ccg.portaladminejb.server.system.SystemProperties;
import it.ccg.portaladminejb.server.util.ExceptionUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.ldap.InitialLdapContext;

import org.apache.log4j.Logger;

public class LDAPManager {
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.EJB_LOGGER);
	
	private Hashtable<String, String> env;
	private InitialLdapContext ctx;
	
	private String o;
	private String c;
	private String ou;
	
	
	
	public LDAPManager() throws Exception {
		
		this.env = new Hashtable<String, String>();
		this.env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		this.env.put(Context.PROVIDER_URL, "ldap://" + SystemProperties.getProperty("ldap.address") + ":" + SystemProperties.getProperty("ldap.port"));
		this.env.put(Context.SECURITY_AUTHENTICATION, "simple");
		this.env.put(Context.SECURITY_PRINCIPAL, SystemProperties.getProperty("ldap.user"));
		this.env.put(Context.SECURITY_CREDENTIALS, Security.decodeBASE64(SystemProperties.getProperty("ldap.password")));
		
		this.o = SystemProperties.getProperty("ldap.user_set.o");
		this.c = SystemProperties.getProperty("ldap.user_set.c");
		this.ou = SystemProperties.getProperty("ldap.user_set.ou");
	}
	
	
	public List<LDAPUserDTO> listUsers() throws Exception {
		
		List<LDAPUserDTO> userList = new ArrayList<LDAPUserDTO>();
		
		try {
			this.connect();
			
			NamingEnumeration<NameClassPair> namingEnumeration = this.ctx.list("o=" + this.o + ",c=" + this.c);
			
			LDAPUserDTO ldapUserDTO = null;
			
			while(namingEnumeration.hasMore()) {
				
			    NameClassPair ncp = namingEnumeration.next();
			    
			    Attributes attributes = ctx.getAttributes(ncp.getNameInNamespace());
			    
			    String cn = attributes.get("cn") != null ? (String)attributes.get("cn").get() : null;
			    String sn = attributes.get("sn") != null ? (String)attributes.get("sn").get() : null;
			    String uid = attributes.get("uid") != null ? (String)attributes.get("uid").get() : null;
			    
			    String mail = attributes.get("mail") != null ? (String)attributes.get("mail").get() : null;
			    String ou = attributes.get("ou") != null ? (String)attributes.get("ou").get() : null;
			    
			    // non vedo o e c come attributi
			    //String o = attributes.get("o") != null ? (String)attributes.get("o").get() : null;
			    //String c = attributes.get("c") != null ? (String)attributes.get("c").get() : null;
			    
			    // non ritorno mai la password
			    //String userpassword = attributes.get("userpassword") != null ? (String)attributes.get("userpassword").get() : null;
			    
			    
			    ldapUserDTO = new LDAPUserDTO(cn, sn, uid, this.o, this.c, null, mail, ou);
			    
			    userList.add(ldapUserDTO);
			}
			
		} 
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
		
		return userList;
	}
	
	
	public LDAPUserDTO getUserByContextName(String userContextName) throws Exception {
		
		LDAPUserDTO ldapUserDTO = null;
		
		try {
			this.connect();
			
			Attributes attributes = this.ctx.getAttributes(userContextName);
			
			String cn = attributes.get("cn") != null ? (String)attributes.get("cn").get() : null;
		    String sn = attributes.get("sn") != null ? (String)attributes.get("sn").get() : null;
		    String uid = attributes.get("uid") != null ? (String)attributes.get("uid").get() : null;
		    
		    String mail = attributes.get("mail") != null ? (String)attributes.get("mail").get() : null;
		    String ou = attributes.get("ou") != null ? (((String)attributes.get("ou").get()).equalsIgnoreCase("") ? null : (String)attributes.get("ou").get()) : null;
			

		    // non vedo o e c come attributi
		    //String o = attributes.get("o") != null ? (String)attributes.get("o").get() : null;
		    //String c = attributes.get("c") != null ? (String)attributes.get("c").get() : null;
		    
		    // non ritorno mai la password
		    //String userpassword = attributes.get("userpassword") != null ? (String)attributes.get("userpassword").get() : null;
		    
		    
		    ldapUserDTO = new LDAPUserDTO(cn, sn, uid, this.o, this.c, null, mail, ou);
		    
		}
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
		
		return ldapUserDTO;
	}
	
	
	public LDAPUserDTO getUserByCN(String cn) throws Exception {
		
		LDAPUserDTO ldapUserDTO = null;
		
		try {
			this.connect();
			
			Attributes attributes = this.ctx.getAttributes("cn=" + cn + ",o=" + this.o + ",c=" + this.c);
			
			//String cn = attributes.get("cn") != null ? (String)attributes.get("cn").get() : null;
		    String sn = attributes.get("sn") != null ? (String)attributes.get("sn").get() : null;
		    String uid = attributes.get("uid") != null ? (String)attributes.get("uid").get() : null;
		    
		    String mail = attributes.get("mail") != null ? (String)attributes.get("mail").get() : null;
		    String ou = attributes.get("ou") != null ? (String)attributes.get("ou").get() : null;
			

		    // non vedo o e c come attributi
		    //String o = attributes.get("o") != null ? (String)attributes.get("o").get() : null;
		    //String c = attributes.get("c") != null ? (String)attributes.get("c").get() : null;
		    
		    // non ritorno mai la password
		    //String userpassword = attributes.get("userpassword") != null ? (String)attributes.get("userpassword").get() : null;
		    
		    
		    ldapUserDTO = new LDAPUserDTO(cn, sn, uid, this.o, this.c, null, mail, ou);
			
		} 
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
		
		return ldapUserDTO;
	}
	
	
	public LDAPUserDTO getUserByUID(String uid) throws Exception {
		
		LDAPUserDTO ldapUserDTO = null;
		
		try {
			
			List<LDAPUserDTO> list = this.listUsers();
			
			for(LDAPUserDTO user : list) {
				
				if(user.getUid() != null) {
					
					if(user.getUid().equalsIgnoreCase(uid)) {
						
						ldapUserDTO = user;
						
						break;
					}
				}
				else {
					
					logger.warn("User has no uid. " + user);
				}
				
			}
			
		} 
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
		
		return ldapUserDTO;
	}
	
	
	public Map<String, String> get_O_C_OU() throws Exception {
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("o", this.o);
		map.put("c", this.c);
		map.put("ou", this.ou);
		
		
		return map;
	}
	
	
	public void addUser(LDAPUserDTO ldapUserDTO) throws Exception {
		
		try {
			this.connect();
			
			BasicAttribute cn = new BasicAttribute("cn", ldapUserDTO.getCn());  
			BasicAttribute sn = new BasicAttribute("sn", ldapUserDTO.getSn());
			BasicAttribute uid = new BasicAttribute("uid", ldapUserDTO.getUid());
			BasicAttribute pwd = new BasicAttribute("userpassword",ldapUserDTO.getUserpassword());
			BasicAttribute mail = new BasicAttribute("mail", ldapUserDTO.getMail());
			
			BasicAttribute ou = new BasicAttribute("ou", ldapUserDTO.getOu());
			
			BasicAttribute objClass = new BasicAttribute("objectclass", "inetOrgPerson");
			objClass.add("ePerson");
			
	        // build the entry  
	        Attributes attributes = new BasicAttributes(); 
	        attributes.put(cn);  
	        attributes.put(sn);
	        attributes.put(uid);
	        attributes.put(pwd);
	        attributes.put(mail);
	        attributes.put(ou);
	        
	        attributes.put(objClass); 
	        
	        this.ctx.createSubcontext("cn=" + ldapUserDTO.getCn() + ",o=" + ldapUserDTO.getO() + ",c=" + ldapUserDTO.getC(), attributes);
	        
	        
	        logger.info(new StandardLogMessage("Added new user: " + ldapUserDTO.toString()));
		} 
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
	}
	
	
	public void removeUser(LDAPUserDTO ldapUserDTO) throws Exception {
		
		try {
			this.connect();
			
	        this.ctx.destroySubcontext("cn=" + ldapUserDTO.getCn() + ",o=" + ldapUserDTO.getO() + ",c=" + ldapUserDTO.getC());
	        
	        
	        logger.info(new StandardLogMessage("Removed user: " + ldapUserDTO.toString()));
		} 
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
	}
	
	// 
	public void removeUser(String userContextName) throws Exception {
		
		try {
			this.connect();
			
	        this.ctx.destroySubcontext(userContextName);
	        
	        
	        logger.info(new StandardLogMessage("Removed user: " + userContextName));
		} 
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		} 
		finally {
			
			this.disconnect();
		}
		
	}
	
	
	
	private void connect() throws Exception {
		
		try {
			this.ctx = new InitialLdapContext(this.env, null);
		}
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
		logger.info(new StandardLogMessage("User \'" + this.env.get(Context.SECURITY_PRINCIPAL) + "\' connected to \'" + this.env.get(Context.PROVIDER_URL) + "\'"));
	}
	
	
	private void disconnect() throws Exception {
		
		try {
			this.ctx.close();
		}
		catch(NamingException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		
		logger.info(new StandardLogMessage("Disconnected from \'" + this.env.get(Context.PROVIDER_URL) + "\'"));
	}
	
	
	
}
