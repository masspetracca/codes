package it.ccg.portaladminejb.manager;

import it.ccg.portaladminejb.mBean.SecurityAdminMBean;

import java.util.Properties;

import javax.management.InstanceNotFoundException;
import javax.management.IntrospectionException;
import javax.management.MalformedObjectNameException;
import javax.management.ReflectionException;

import com.ibm.websphere.management.AdminClient;
import com.ibm.websphere.management.AdminClientFactory;
import com.ibm.websphere.management.exception.ConnectorException;

public class MBeanManager {

	private AdminClient adminClient;
	
	public MBeanManager(){
		try {
			adminClient = AdminClientFactory.createAdminClient(getConnectionProperties());
			
		} catch (ConnectorException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	public String printSecurityAdminMBeanInfo() throws InstanceNotFoundException, IntrospectionException, MalformedObjectNameException, ReflectionException, ConnectorException, NullPointerException{
		String toReturn=null;
		toReturn = new SecurityAdminMBean(adminClient).toString(adminClient);
		return toReturn;
	}
	
	private static Properties getConnectionProperties() {
		
		Properties properties = new Properties();
		
		properties.setProperty(AdminClient.CONNECTOR_TYPE, AdminClient.CONNECTOR_TYPE_SOAP);
		properties.setProperty(AdminClient.CONNECTOR_HOST, "localhost");
		properties.setProperty(AdminClient.CONNECTOR_PORT, "8880");
		
		/*properties.setProperty(AdminClient.USERNAME, "admin");
		properties.setProperty(AdminClient.PASSWORD, "admin");*/
		
		
		// security
		/*properties.setProperty(AdminClient.CONNECTOR_SECURITY_ENABLED, "true");
		properties.setProperty("javax.net.ssl.trustStore", "C:/Program Files (x86)/IBM/SDP/runtimes/base_v7/profiles/AppSrv01/etc/trust.p12");
		properties.setProperty("javax.net.ssl.keyStore", "C:/Program Files (x86)/IBM/SDP/runtimes/base_v7/profiles/AppSrv01/etc/key.p12");
		properties.setProperty("javax.net.ssl.trustStorePassword", "password");
		properties.setProperty("javax.net.ssl.keyStorePassword", "password");*/
		
		return properties;
	}
}
