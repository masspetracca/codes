package it.ccg.portaladminejb.mBean;

import javax.management.InstanceNotFoundException;
import javax.management.IntrospectionException;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.MBeanOperationInfo;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;

import com.ibm.websphere.management.AdminClient;
import com.ibm.websphere.management.exception.ConnectorException;
import com.ibm.websphere.security.Result;

public class SecurityAdminMBean {
	
	private String securityAdminQuery = "WebSphere:*,type=SecurityAdmin";
	private ObjectName mBean;
	
	public SecurityAdminMBean(AdminClient adminClient) throws MalformedObjectNameException, NullPointerException, ConnectorException{
		mBean = new ObjectName(securityAdminQuery);
		
		mBean = (ObjectName)adminClient.queryNames(mBean, null).iterator().next();
	}
	
	public ObjectName getMBeanObjectName(AdminClient adminClient) throws MalformedObjectNameException, NullPointerException, ConnectorException{
		return this.mBean; 
	}
	
	public Result getUsers(AdminClient adminClient) throws InstanceNotFoundException, MBeanException, ReflectionException, ConnectorException{
		
		Object[] params = {"*", new Integer(20), null};
		String[] signature = {"java.lang.String", "java.lang.Integer", "java.util.Properties"};
		
		Result result = (Result)adminClient.invoke(this.mBean, "getUsers", params, signature);
		
		return result;
	}
	
	public Result getGroups(AdminClient adminClient) throws InstanceNotFoundException, MBeanException, ReflectionException, ConnectorException{
		Object[] params = {"*", new Integer(20), null};
		String[] signature = {"java.lang.String", "java.lang.Integer", "java.util.Properties"};
		
		Result result = (Result)adminClient.invoke(this.mBean, "getGroups", params, signature);
		
		return result;
	}
	
	public String getRealm(AdminClient adminClient) throws InstanceNotFoundException, MBeanException, ReflectionException, ConnectorException{
		
		Object[] params = {null};
		String[] signature = {"java.util.Properties"};
		
		String result = (String) adminClient.invoke(this.mBean, "getRealm", params, signature);
		
		return result;
	}

	public String toString(AdminClient adminClient) throws InstanceNotFoundException, IntrospectionException, ReflectionException, ConnectorException {
		
		String toReturn="";
		MBeanInfo mBeanInfo = adminClient.getMBeanInfo(mBean);
		
		toReturn += "Attributes: ";
		
		MBeanAttributeInfo[] mBeanAttributeInfoArray =  mBeanInfo.getAttributes();
		for(MBeanAttributeInfo attributeInfo : mBeanAttributeInfoArray) {
			
			toReturn += ("name: " + attributeInfo.getName() + ", isWritable: " + attributeInfo.isWritable() +" \n");
		}
		
		toReturn +="\n";
		
		toReturn +="Operations: ";
		
		MBeanOperationInfo[] mBeanOperationInfoArray =  mBeanInfo.getOperations();
		for(MBeanOperationInfo operationInfo : mBeanOperationInfoArray) {
			
			toReturn +=("name: " + operationInfo.getName() + ", description: " + operationInfo.getDescription()+"\n");
		}
		
		return toReturn;
	}
	
	
}
