package it.ccg.portaladminejb.manager;

import it.ccg.portaladminejb.dto.LDAPUserEntity;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.ldap.InitialLdapContext;

public class LDapManage {

	private Hashtable env = new Hashtable();
	private String user = null;
	private String password = null;
	private String provider_url = null;
	//private DirContext ctx;
	private InitialLdapContext ctx;
	
	public LDapManage(String username, String password, String providerUrl, String port){
		this.user = "pampadmin"; //username
		this.password = "pampadmin"; //password
		this.provider_url = "10.0.10.240:389"; //providerUrl+":"+port
		prepareConnection();
	}	
	
	private void prepareConnection(){
		env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, "ldap://"+provider_url);
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, "CN="+user);
		env.put(Context.SECURITY_CREDENTIALS, password);
	}
	
	public void connect() throws NamingException{
		//ctx = new InitialDirContext(env);
		ctx = new InitialLdapContext(env, null);
		System.out.println("connesso");
	}
	
	public static void main(String[] args) throws NamingException{
		LDapManage manager = new LDapManage(null, null, null, null);
		manager.addUser(new LDAPUserEntity("prova6", "prova6", "prova6", "ccg", "pamp", "prova6"));
	}
	
	public void disconnect() throws NamingException{
		ctx.close();
		System.out.println("diconnesso");
	}
	
	public void explore(LDAPUserEntity user){
		try {
			this.connect();
			NamingEnumeration<NameClassPair> enumer = ctx.list("o="+user.getO()+",c="+user.getC());
			while(enumer.hasMore()){
				NameClassPair name = enumer.next();
				System.out.println(name.getClassName()+" "+name.getNameInNamespace());
			}
		} catch (NamingException e) {
			System.out.println("NamingException "+e.getMessage());
			e.printStackTrace();
		}finally{
			try {
				this.disconnect();
			} catch (NamingException e) {
				System.out.println("NamingException "+e.getMessage());
				e.printStackTrace();
			}
		}
	}
	
	public void addUser(LDAPUserEntity user){
		try {
			this.connect();
			
			BasicAttribute cn = new BasicAttribute("cn", user.getCn());  
			BasicAttribute sn = new BasicAttribute("sn", user.getSn());
			BasicAttribute uid = new BasicAttribute("uid", user.getUid());
			BasicAttribute pwd = new BasicAttribute("userpassword",user.getUserpassword());
			BasicAttribute objClass = new BasicAttribute("objectclass", "inetOrgPerson");
			objClass.add("ePerson");
			
			
					
	        // build the entry  
	        Attributes attributes = new BasicAttributes(); 
	        attributes.put(cn);  
	        attributes.put(sn);
	        attributes.put(uid);
	        attributes.put(pwd);
	        attributes.put(objClass); 
	        
	        
	        ctx.createSubcontext("cn=" + user.getCn() + ",o=" + user.getO() + ",c=" + user.getC(), attributes);
	        
	        
	        ctx.close();
	        
	        System.out.println( "AddUser: added entry cn="+user.getCn());  
		} catch (NamingException e) {
			System.out.println("NamingException "+e.getMessage());
			e.printStackTrace();
		}finally{
			try {
				this.disconnect();
			} catch (NamingException e) {
				System.out.println("NamingException "+e.getMessage());
				e.printStackTrace();
			}
		}
	}
}
