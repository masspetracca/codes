package it.ccg.portaladminejb.mBean;

import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import com.ibm.websphere.management.AdminClient;
import com.ibm.websphere.management.exception.ConnectorException;

public class ServerMBean {
	
	private String serverQuery = "WebSphere:type=Server,*";
	private ObjectName mBean;
	
	public ObjectName getMBeanObjectName(AdminClient adminClient) throws MalformedObjectNameException, NullPointerException, ConnectorException{
		mBean = new ObjectName(serverQuery);
		
		mBean = (ObjectName)adminClient.queryNames(mBean, null).iterator().next();
		return mBean; 
	}

}
