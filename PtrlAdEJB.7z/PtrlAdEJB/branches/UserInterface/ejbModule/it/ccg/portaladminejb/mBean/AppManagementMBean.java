package it.ccg.portaladminejb.mBean;

import java.util.Vector;

import javax.management.InstanceNotFoundException;
import javax.management.IntrospectionException;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.MBeanOperationInfo;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;

import com.ibm.websphere.management.AdminClient;
import com.ibm.websphere.management.exception.ConnectorException;
import com.ibm.websphere.security.Result;

public class AppManagementMBean {

	private String appManagementQuery = "WebSphere:*,type=AppManagement";;
	private ObjectName mBean;
	
	public AppManagementMBean(AdminClient adminClient) throws MalformedObjectNameException, NullPointerException, ConnectorException{
		mBean = new ObjectName(appManagementQuery);
		
		mBean = (ObjectName)adminClient.queryNames(mBean, null).iterator().next();
	}
	
	public ObjectName getMBeanObjectName(AdminClient adminClient) throws MalformedObjectNameException, NullPointerException, ConnectorException{
		return this.mBean; 
	}
	
	public MBeanInfo getMBeanInfo(AdminClient adminClient) throws InstanceNotFoundException, IntrospectionException, ReflectionException, ConnectorException {
		MBeanInfo mBeanInfo = adminClient.getMBeanInfo(this.mBean);
		
		return mBeanInfo;
	}
	
	public Result getMapsRoleToGroups(AdminClient adminClient) throws InstanceNotFoundException, MBeanException, ReflectionException, ConnectorException{
		Object[] params = {"*", new Integer(20), null};
		String[] signature = {"java.lang.String", "java.lang.Integer", "java.util.Properties"};
		
		Result result = (Result)adminClient.invoke(this.mBean, "getGroups", params, signature);
		
		return result;
	}
	
	public String getRealm(AdminClient adminClient) throws InstanceNotFoundException, MBeanException, ReflectionException, ConnectorException{
		
		Object[] params = {null};
		String[] signature = {"java.util.Properties"};
		
		String result = (String) adminClient.invoke(this.mBean, "getRealm", params, signature);
		
		return result;
	}

	public String toString(AdminClient adminClient) throws InstanceNotFoundException, IntrospectionException, ReflectionException, ConnectorException {
		
		String toReturn="";
		MBeanInfo mBeanInfo = adminClient.getMBeanInfo(mBean);
		

		toReturn+="Attributes: ";
		
		MBeanAttributeInfo[] mBeanAttributeInfoArray =  mBeanInfo.getAttributes();
		for(MBeanAttributeInfo attributeInfo : mBeanAttributeInfoArray) {
			
			toReturn+=("name: " + attributeInfo.getName() + ", isWritable: " + attributeInfo.isWritable()+"\n");
		}
		
		toReturn +="\n";
		
		toReturn +="Operations: ";
		
		MBeanOperationInfo[] mBeanOperationInfoArray =  mBeanInfo.getOperations();
		for(MBeanOperationInfo operationInfo : mBeanOperationInfoArray) {
			
			toReturn +=("name: " + operationInfo.getName() + ", return type: " + operationInfo.getReturnType() + ", description: " + operationInfo.getDescription()+"\n");
		}
						
		return toReturn;
	}
	
	public Vector<?> getApplicationInfo(AdminClient adminClient) throws Exception {
		
		Object[] params = {"InfoProvidersEar", null, null};
		String[] signature = {"java.lang.String", "java.util.Hashtable", "java.lang.String"};
		
		return (Vector<?>)adminClient.invoke(mBean, "getApplicationInfo", params, signature);
	}
	
	public Vector<?> setApplicationInfo(AdminClient adminClient,Vector<?> appInfo) throws Exception {
		
		Object[] params = {"InfoProvidersEar", null, null, appInfo};
		String[] signature = {"java.lang.String", "java.util.Hashtable", "java.lang.String", "java.util.Vector"};
		
		return (Vector<?>)adminClient.invoke(mBean, "setApplicationInfo", params, signature);
	}
}
