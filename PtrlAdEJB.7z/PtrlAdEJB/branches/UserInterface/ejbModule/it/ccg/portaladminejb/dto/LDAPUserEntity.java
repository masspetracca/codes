package it.ccg.portaladminejb.dto;

public class LDAPUserEntity {

	private String cn;
	private String sn;
	private String uid;
	private String o;
	private String c;
	private String userpassword;
	
	public LDAPUserEntity(){
		this.cn=null;
		this.sn=null;
		this.uid=null;
		this.o=null;
		this.c=null;
		this.userpassword=null;
	}
	
	
	public LDAPUserEntity(String cn, String sn, String uid, String o, String c, String userpassword){
		this.cn=cn;
		this.sn=sn;
		this.uid=uid;
		this.o=o;
		this.c=c;
		this.userpassword=userpassword;
	}
	

	/**
	 * @return the cn
	 */
	public String getCn() {
		return cn;
	}

	/**
	 * @param cn the cn to set
	 */
	public void setCn(String cn) {
		this.cn = cn;
	}

	/**
	 * @return the sn
	 */
	public String getSn() {
		return sn;
	}

	/**
	 * @param sn the sn to set
	 */
	public void setSn(String sn) {
		this.sn = sn;
	}

	/**
	 * @return the uid
	 */
	public String getUid() {
		return uid;
	}

	/**
	 * @param uid the uid to set
	 */
	public void setUid(String uid) {
		this.uid = uid;
	}

	/**
	 * @return the o
	 */
	public String getO() {
		return o;
	}

	/**
	 * @param o the o to set
	 */
	public void setO(String o) {
		this.o = o;
	}

	/**
	 * @return the c
	 */
	public String getC() {
		return c;
	}

	/**
	 * @param c the c to set
	 */
	public void setC(String c) {
		this.c = c;
	}

	/**
	 * @return the userpassword
	 */
	public String getUserpassword() {
		return userpassword;
	}

	/**
	 * @param userpassword the userpassword to set
	 */
	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}
}
