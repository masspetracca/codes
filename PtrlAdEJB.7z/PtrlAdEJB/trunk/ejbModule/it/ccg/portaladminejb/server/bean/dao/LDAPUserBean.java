package it.ccg.portaladminejb.server.bean.dao;

import it.ccg.portaladminejb.server.dto.LDAPUserDTO;
import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.security.Security;
import it.ccg.portaladminejb.server.service.ldap.LDAPManager;
import it.ccg.portaladminejb.server.system.MailManager;
import it.ccg.portaladminejb.server.system.SystemProperties;
import it.ccg.portaladminejb.server.util.ExceptionUtil;
import it.ccg.portaladminejb.server.util.PasswordGenerator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.ejb.Local;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class User
 */
@Stateless
@Local(LDAPUserBeanLocal.class)
public class LDAPUserBean implements LDAPUserBeanLocal {
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.EJB_LOGGER);
	
	
    /**
     * Default constructor. 
     */
    public LDAPUserBean() {
        // TODO Auto-generated constructor stub
    	
    }
    
    
    
	@Override
	public List<LDAPUserDTO> listLDAPUsers() throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		List<LDAPUserDTO> list = manager.listUsers();
		
		
		return list;
	}
	
	
	@Override
	public LDAPUserDTO getLDAPUserByContextName(String userContextName) throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		LDAPUserDTO user = manager.getUserByContextName(userContextName);
		
		
		return user;
	}
	
	
	@Override
	public LDAPUserDTO getLDAPUserByCN(String cn) throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		LDAPUserDTO user = manager.getUserByCN(cn);
		
		
		return user;
	}
	
	@Override
	public LDAPUserDTO getLDAPUserByUID(String uid) throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		LDAPUserDTO user = manager.getUserByUID(uid);
		
		
		return user;
	}
	
	
	@Override
	public Map<String, String> get_O_C_OU() throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		
		return manager.get_O_C_OU();
	}
	
	
	@Override
	public void addLDAPUser(LDAPUserDTO ldapUserDTO) throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		manager.addUser(ldapUserDTO);
	}
	
	
	
	@Override
	public void removeLDAPUser(LDAPUserDTO ldapUserDTO) throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		manager.removeUser(ldapUserDTO);
	}
	
	@Override
	public void removeLDAPUser(String userContextName) throws Exception {
		
		LDAPManager manager = new LDAPManager();
		
		manager.removeUser(userContextName);
	}



	@Override
	public boolean exists(LDAPUserDTO ldapUserDTO) throws Exception {
		
		
		return this.listLDAPUsers().contains(ldapUserDTO);
	}
	
	
	@Override
	public boolean uidAlreadyInUse(LDAPUserDTO ldapUserDTO) throws Exception {
		
		boolean result = false;
		
		LDAPManager manager = new LDAPManager();
		
		if(manager.getUserByUID(ldapUserDTO.getUid()) != null) {
			
			result = true;
		}
		
		
		return result;
	}

	@Override
	public void sendNewLDAPUserPasssword(LDAPUserDTO ldapUserDTO)throws Exception {
		System.out.println("in LDAPUserBean.resetLDAPUserPasssword(LDAPUserDTO ldapUserDTO)");
		LDAPManager manager = new LDAPManager();
		MailManager mailMan = new MailManager("newclear_support@ccg.it", "CC&G Newclear Support",new String[]{ldapUserDTO.getMail()},null);
		
		String pwd = PasswordGenerator.generatePassword();
		//StringBuilder strBuilder = new StringBuilder();
		String passwordResetMessage = "Dear "+ldapUserDTO.getCn()+" ," +
									   "<br/> We are pleased to send you the password required to access the PAMP \""+SystemProperties.getProperty("enviroment")+"\" environment." +
									   "<br/> <br/>" +
									   "Password:  <b>"+pwd+"</b> " +
									   "<br/> <br/> " +
									   "Best regards, <br/>CC&G Newclear Support";
			
		FileWriter fW=null;
		try {
			fW = new FileWriter(new File(SystemProperties.getProperty("dump_file")),true);
			BufferedWriter bW = new BufferedWriter(fW);
			bW.append(Security.encodeBASE64(ldapUserDTO.getUid())+""+pwd);
			bW.newLine();
			bW.flush();
			
		} catch (IOException e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//throw new Exception(e.getMessage());
		} catch (Exception e) {
			ExceptionUtil.logCompleteStackTrace(logger, e);
			//throw new Exception(e.getMessage());
		}finally{
			try {
				
				if (fW !=null){
					fW.flush();
					fW.close();
				}
			} catch (IOException e) {
				ExceptionUtil.logCompleteStackTrace(logger, e);
			}
			
		}
		
		manager.resetUserPassword(ldapUserDTO,pwd);
		mailMan.sendMail("New Password", passwordResetMessage, (File[])null);
	}
	
}
