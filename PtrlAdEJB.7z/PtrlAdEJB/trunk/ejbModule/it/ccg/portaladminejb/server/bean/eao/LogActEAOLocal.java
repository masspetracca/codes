package it.ccg.portaladminejb.server.bean.eao;

import it.ccg.portaladminejb.server.bean.eao.util.Criteria;
import it.ccg.portaladminejb.server.bean.entity.LogActEntity;

import java.util.List;

public interface LogActEAOLocal {

	 public List<LogActEntity> fetch(List<Criteria> criteriaList, int startRow, int endRow) throws Exception;
	 public long fetchCount(List<Criteria> criteriaList) throws Exception;
}
