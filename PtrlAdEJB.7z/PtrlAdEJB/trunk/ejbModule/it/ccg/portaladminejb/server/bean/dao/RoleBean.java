package it.ccg.portaladminejb.server.bean.dao;

import it.ccg.portaladminejb.server.dto.Role;
import it.ccg.portaladminejb.server.dto.WSUserDTO;
import it.ccg.portaladminejb.server.service.mBean.AppManagementMBean;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ejb.Local;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class RoleUser
 */
@Stateless
@Local(RoleBeanLocal.class)
public class RoleBean implements RoleBeanLocal {

    /**
     * Default constructor. 
     */
    public RoleBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public List<Role> listRoles() throws Exception {
		
		AppManagementMBean appManagementMBean = new AppManagementMBean();
		
		List<String> rawList = appManagementMBean.getRoles();
		List<Role> roleList = new ArrayList<Role>();
		for(String role : rawList) {
			
			roleList.add(new Role(role));
		}
		
		return roleList;
	}
	
	
	@Override
	public List<Role> listUserRelatedRoles(String user) throws Exception {
		
		AppManagementMBean appManagementMBean = new AppManagementMBean();
		
		List<String> rawList = appManagementMBean.getUserRelatedRoles(user);
		List<Role> roleList = new ArrayList<Role>();
		for(String role : rawList) {
			
			roleList.add(new Role(role));
		}
		
		
		return roleList;
	}
	
	
	@Override
	public List<Role> listUserNotRelatedRoles(String user) throws Exception {
		
		AppManagementMBean appManagementMBean = new AppManagementMBean();
		
		List<String> rawList = appManagementMBean.getUserNotRelatedRoles(user);
		List<Role> roleList = new ArrayList<Role>();
		for(String role : rawList) {
			
			roleList.add(new Role(role));
		}
		
		
		return roleList;
	}

	@Override
	public Map<WSUserDTO, List<Role>> getUserRoleMapping(List<WSUserDTO> userList) throws Exception {
		
		AppManagementMBean appManagementMBean = new AppManagementMBean();
		
		Map<WSUserDTO, List<Role>> userRoleMapping = appManagementMBean.getUserRoleMapping(userList);
		
		
		return userRoleMapping;
	}
	
	
	@Override
	public void loadUserRoleMapping() throws Exception {
		
		AppManagementMBean appManagementMBean = new AppManagementMBean();
		
		appManagementMBean.loadCurrentWSTaskData();
	}
	

}
