package it.ccg.portaladminejb.server.dto;

public class WSUserDTO {
	
	private String cn;
	private String o;
	private String c;
	private String uid;
	
	
	public WSUserDTO(String cn, String o, String c, String uid) throws Exception {
		
		if(cn == null || o == null ||c == null ||uid == null) {
			
			throw new Exception("WSUserDTO(String cn, String o, String c, String uid). All fields must be not null.");
		}
		
		this.cn = cn;
		this.o = o;
		this.c = c;
		this.uid = uid;
	}
	
	/*public WSUserDTO(String userContextName) throws Exception {
		
		String[] tempArray = userContextName.split(",");
		
		if(tempArray.length != 3) {
			
			throw new Exception("User context name not well formed. " + userContextName);
		}
		
		
	}*/

	

	public String getCn() {
		return cn;
	}

	public void setCn(String cn) {
		this.cn = cn;
	}


	public String getO() {
		return o;
	}


	public void setO(String o) {
		this.o = o;
	}


	public String getC() {
		return c;
	}


	public void setC(String c) {
		this.c = c;
	}


	public String getUid() {
		return uid;
	}


	public void setUid(String uid) {
		this.uid = uid;
	}


	@Override
	public boolean equals(Object o) {
		
		if(!(o instanceof WSUserDTO)) {
			
			return super.equals(o);
		}
		
		return this.uid.equalsIgnoreCase(((WSUserDTO)o).getUid());
	}

	@Override
	public String toString() {
		
		return "[cn: " + this.cn + ", o: " + this.o + ", c: " + this.c + ", uid: " + this.uid + "]";
	}
	
	
	public String getUserContextName() {
		
		return "cn=" + this.cn + ",o=" + this.o + ",c=" + this.c;
	}
	
}
