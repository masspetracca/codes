package it.ccg.portaladminejb.server.service.mBean;

import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;
import it.ccg.portaladminejb.server.security.Security;
import it.ccg.portaladminejb.server.system.SystemProperties;

import java.util.Properties;

import org.apache.log4j.Logger;

import com.ibm.websphere.management.AdminClient;
import com.ibm.websphere.management.AdminClientFactory;

public class AdminClientManager {
	
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.EJB_LOGGER);
	

	public static AdminClient getAdminClient() throws Exception {
		
		Properties properties = new Properties();
		
		properties.setProperty(AdminClient.CONNECTOR_TYPE, AdminClient.CONNECTOR_TYPE_SOAP);
		properties.setProperty(AdminClient.CONNECTOR_HOST, SystemProperties.getProperty("soap.address"));
		properties.setProperty(AdminClient.CONNECTOR_PORT, SystemProperties.getProperty("soap.port"));
		properties.setProperty(AdminClient.USERNAME, SystemProperties.getProperty("soap.user"));
		properties.setProperty(AdminClient.PASSWORD, Security.decodeBASE64(SystemProperties.getProperty("soap.password")));
		
		AdminClient adminClient = AdminClientFactory.createAdminClient(properties);
		
		logger.debug(new StandardLogMessage("AdminClient for WAS soap connection successfully created."));
		
		
		return adminClient;
	}
	
	
	
}
