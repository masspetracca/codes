package it.ccg.portaladminejb.server.bean.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the PMPTBATCH database table.
 * 
 */
@Entity
@Table(name="PMPTBATCH")
@NamedQueries({
	@NamedQuery(name="getAllJobs", query="SELECT batch FROM BatchEntity batch ORDER BY batch.batchname ASC")
})
public class BatchEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false)
	private int batchid;

	@Column(nullable=false, length=255)
	private String batchcat;

	@Column(nullable=false, length=255)
	private String batchname;

	@Column(length=1)
	private String diviscode;

	@Column(length=1)
	private String env;

	@Column(nullable=false)
	private int running;

	@Column(length=1)
	private String status;

	@Column(nullable=false)
	private Timestamp upddate;

	@Column(nullable=false, length=1)
	private String updtype;

	@Column(nullable=false, length=30)
	private String updusr;

    public BatchEntity() {
    }

	public int getBatchid() {
		return this.batchid;
	}

	public void setBatchid(int batchid) {
		this.batchid = batchid;
	}

	public String getBatchcat() {
		return this.batchcat;
	}

	public void setBatchcat(String batchcat) {
		this.batchcat = batchcat;
	}

	public String getBatchname() {
		return this.batchname;
	}

	public void setBatchname(String batchname) {
		this.batchname = batchname;
	}

	public String getDiviscode() {
		return this.diviscode;
	}

	public void setDiviscode(String diviscode) {
		this.diviscode = diviscode;
	}

	public String getEnv() {
		return this.env;
	}

	public void setEnv(String env) {
		this.env = env;
	}

	public int getRunning() {
		return this.running;
	}

	public void setRunning(int running) {
		this.running = running;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Timestamp upddate) {
		this.upddate = upddate;
	}

	public String getUpdtype() {
		return this.updtype;
	}

	public void setUpdtype(String updtype) {
		this.updtype = updtype;
	}

	public String getUpdusr() {
		return this.updusr;
	}

	public void setUpdusr(String updusr) {
		this.updusr = updusr;
	}

}