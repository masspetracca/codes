package it.ccg.portaladminejb.server.bean.dao;

import it.ccg.portaladminejb.server.logengine.PALoggerFactory;
import it.ccg.portaladminejb.server.logengine.StandardLogMessage;
import it.ccg.portaladminejb.server.util.ExceptionUtil;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

/**
 * Session Bean implementation class PAMPQueue
 */
@Stateless
@Local(PAMPQueueBeanLocal.class)
public class PAMPQueueBean implements PAMPQueueBeanLocal {
	
	private static final Logger logger = PALoggerFactory.getLogger(PALoggerFactory.EJB_LOGGER);
	
	
	
	@Resource(name="jms/MDBStarterCF")
	private QueueConnectionFactory queueConnectionFactory;
	
	@Resource(name="jms/MDBStarter")
	private Queue queue;
	
    /**
     * Default constructor. 
     */
    public PAMPQueueBean() {
        // TODO Auto-generated constructor stub
    }
    
    

	/*@Override
	public List<PAMPQueueEntry> listQueueEntries() throws Exception {
		
		List<PAMPQueueEntry> queueEntryList = new ArrayList<PAMPQueueEntry>();
		
		Connection connection = null;
		Session session = null;
		QueueBrowser queueBrowser = null;
		
		try {
			
			connection = this.queueConnectionFactory.createConnection();
			connection.start();
			
			session = (Session)connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			
			queueBrowser = session.createBrowser(this.queue);
			
			Enumeration<?> messageEnumeration = queueBrowser.getEnumeration();
			
			PAMPQueueEntry pampQueueEntry = null;
			while(messageEnumeration.hasMoreElements()) {
				
				JmsTextMessageImpl message = (JmsTextMessageImpl)messageEnumeration.nextElement();
				
				pampQueueEntry = new PAMPQueueEntry(message.getJMSMessageID().split(":")[1], 
												    new Timestamp(message.getJMSTimestamp()), 
												    ((Queue)message.getJMSDestination()).getQueueName(), 
												    message.getText());
				
				queueEntryList.add(pampQueueEntry);
			}
			
		}
		catch(JMSException e) {

			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		finally {
			
			if(queueBrowser != null) {
				
				queueBrowser.close();
			}
			if(session != null) {
				
				session.close();
			}
			if(connection != null) {
				
				connection.close();
			}
		}
		
		
		return queueEntryList;
	}
	
	
	
	
	
	
	
	@Override
	public void emptyQueue() throws Exception {
		
		Connection connection = null;
		Session session = null;
		MessageConsumer messageConsumer = null;
		
		try {
			connection = this.queueConnectionFactory.createConnection();
			connection.start();
			
			session = (Session)connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			
			messageConsumer = session.createConsumer(this.queue);
			
			Message message = null;
			while((message = messageConsumer.receiveNoWait()) != null){
				
				logger.debug(new StandardLogMessage("Message [" + message.getJMSMessageID() + ", content:" + ((TextMessage)message).getText() + "] removed from queue."));
			}
			
		}
		catch(JMSException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		finally {
			
			if(messageConsumer != null) {
				
				messageConsumer.close();
			}
			if(session != null) {
				
				session.close();
			}
			if(connection != null) {
				
				connection.close();
			}
		}
		
	}*/
	

	@Override
	public void addQueueEntry(String batchID, String user) throws Exception {
		
		Connection connection = null;
		Session session = null;
		MessageProducer messageProducer = null;
		
		try {
			connection = this.queueConnectionFactory.createConnection();
			connection.start();
			
			session = (Session)connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			
			messageProducer = session.createProducer(queue);
			
			TextMessage textMessage = session.createTextMessage();
			textMessage.setText(batchID);
			textMessage.setStringProperty("user", user);
			
			messageProducer.send(textMessage);
			
			logger.info(new StandardLogMessage("Message [" + textMessage.getJMSMessageID() + ", content:" + textMessage.getText() + "] added to queue."));
			
		}
		catch(JMSException e) {
			
			ExceptionUtil.logCompleteStackTrace(logger, e);
			
			throw e;
		}
		finally {
			
			if(messageProducer != null) {
				
				messageProducer.close();
			}
			if(session != null) {
				
				session.close();
			}
			if(connection != null) {
				
				connection.close();
			}
		}
		
	}
	
	

}
