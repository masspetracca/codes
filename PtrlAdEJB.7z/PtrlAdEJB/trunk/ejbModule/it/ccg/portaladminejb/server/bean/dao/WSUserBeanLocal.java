package it.ccg.portaladminejb.server.bean.dao;

import it.ccg.portaladminejb.server.dto.WSUserDTO;

import java.util.List;

public interface WSUserBeanLocal {
	
	public List<WSUserDTO> listWSUsers() throws Exception;
	public List<WSUserDTO> listRoleRelatedUsers(String role) throws Exception;
	public List<WSUserDTO> listRoleNotRelatedUsers(String role) throws Exception;

}
