package it.ccg.portaladminejb.server.bean.eao;

import it.ccg.portaladminejb.server.bean.entity.BatchEntity;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 * Session Bean implementation class PmptBatchEAO
 */
@Stateless
@Local(BatchEAOLocal.class)
public class BatchEAO implements BatchEAOLocal {

	@PersistenceContext(unitName="PortalAdminEJB")
	private EntityManager manager;
    /**
     * Default constructor. 
     */
    public BatchEAO() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public List<BatchEntity> getAllJobs(){
    	
    	Query q  = manager.createNamedQuery("getAllJobs");
    	@SuppressWarnings("unchecked")
		List<BatchEntity> toReturn = (List<BatchEntity>)q.getResultList();
     	
    	return toReturn;
    }
    
}
