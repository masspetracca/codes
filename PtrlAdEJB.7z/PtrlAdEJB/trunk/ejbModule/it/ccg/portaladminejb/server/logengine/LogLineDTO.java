package it.ccg.portaladminejb.server.logengine;


public class LogLineDTO {
	
	private String dateTime = new String();
	private String type = new String();
	private String classMethod = new String();
	private String user = new String();
	private String message = new String();
	
	
	
	public LogLineDTO() {
		
	}
	
	public LogLineDTO(String dateTime, String type, String classMethod, String user, String message) {
		this.dateTime = dateTime;
		this.type = type;
		this.classMethod = classMethod;
		this.user = user;
		this.message = message;
	}
	
	
	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getClassMethod() {
		return classMethod;
	}

	public void setClassMethod(String classMethod) {
		this.classMethod = classMethod;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
