package it.ccg.portaladminejb.server.bean.system;

import it.ccg.portaladminejb.server.service.mBean.AppManagementMBean;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class SystemInfoBean
 */
@Stateless
@Local(SystemInfoBeanLocal.class)
public class SystemInfoBean implements SystemInfoBeanLocal {

    /**
     * Default constructor. 
     */
    public SystemInfoBean() {
        // TODO Auto-generated constructor stub
    }
    
    

	@Override
	public List<String> listInstalledApps() throws Exception {
		
		AppManagementMBean appManagementMBean = new AppManagementMBean();
		
		return appManagementMBean.listInstalledApps();
	}

}
