INSERT INTO PAMPQA.QA_ACTIVITY_TASKS(QAA_ACTIVITY, QAA_DT, QAA_TIME, QAA_TASK, QAA_DETT, QAA_CRT_USR, QAA_UPD_USR)
  VALUES('Quality Assurance Tasks ', 'mar 2 apr 2019', '08:30 - 09:30 ', 'Pamp CCPA 0.1A', 'Test Automations, impl per configurazione multibrowser, esecuzione test cases e test di non regressione', 'Petracca', 'Petracca ')
GO
INSERT INTO PAMPQA.QA_ACTIVITY_TASKS(QAA_ACTIVITY, QAA_DT, QAA_TIME, QAA_TASK, QAA_DETT, QAA_CRT_USR, QAA_UPD_USR)
  VALUES('Quality Assurance Tasks ', 'ven 5 apr 2019', '08:30 - 09:30 ', 'Pamp CCPA 0.1A', 'Test Reporting', 'Petracca', 'Petracca')
GO
INSERT INTO PAMPQA.QA_ACTIVITY_TASKS(QAA_ACTIVITY, QAA_DT, QAA_TIME, QAA_TASK, QAA_DETT, QAA_CRT_USR, QAA_UPD_USR)
  VALUES('Quality Assurance Tasks ', 'gio 4 apr 2019', '08:30 - 09:30 ', 'Pamp CCPA 0.1A', 'Test Reporting e parsing del log di esecuzione dei tests', 'Petracca', 'Petracca ')
GO
INSERT INTO PAMPQA.QA_ACTIVITY_TASKS(QAA_ACTIVITY, QAA_DT, QAA_TIME, QAA_TASK, QAA_DETT, QAA_CRT_USR, QAA_UPD_USR)
  VALUES('Quality Assurance Tasks ', 'gio 4 apr 2019', '08:30 - 09:30 ', 'Pamp CCPA 0.1A', 'Test Reporting e parsing del log di esecuzione dei tests', 'Petracca', 'Petracca')
GO
INSERT INTO PAMPQA.QA_ACTIVITY_TASKS(QAA_ACTIVITY, QAA_DT, QAA_TIME, QAA_TASK, QAA_DETT, QAA_CRT_USR, QAA_UPD_USR)
  VALUES('Quality Assurance Tasks ', 'mer 3 apr 2019', '08:30 - 09:30 ', 'Pamp CCPA 0.1A', 'Test Automations, impl per configurazione multibrowser, esecuzione test cases e test di non regressione', 'Petracca', 'Petracca')
GO
INSERT INTO PAMPQA.QA_ACTIVITY_TASKS(QAA_ACTIVITY, QAA_DT, QAA_TIME, QAA_TASK, QAA_DETT, QAA_CRT_USR, QAA_UPD_USR)
  VALUES('Quality Assurance Tasks ', 'gio 2 mag 2019', '08:30 - 09:30 ', 'Lime 2.03', 'Test Reporting 1^ run ticket dei defect su Mantis e parsing dei log', 'Petracca', 'Petracca')
GO
INSERT INTO PAMPQA.QA_ACTIVITY_TASKS(QAA_ACTIVITY, QAA_DT, QAA_TIME, QAA_TASK, QAA_DETT, QAA_CRT_USR, QAA_UPD_USR)
  VALUES('Quality Assurance Tasks ', 'ven 3 mag 2019', '08:30 - 09:30 ', 'Lime 2.03', 'Test Reporting 1^ run ticket dei defect su Mantis, pubblicazione su QA Portal', 'Petracca', 'Petracca')
GO
INSERT INTO PAMPQA.QA_ACTIVITY_TASKS(QAA_ACTIVITY, QAA_DT, QAA_TIME, QAA_TASK, QAA_DETT, QAA_CRT_USR, QAA_UPD_USR)
  VALUES('Quality Assurance Tasks', 'lun 6 mag 2019', '08:30 - 09:30', 'Lime 2.03', 'Test Reporting 1^ run, pubblicazione in QA Portal, ticket di chiusura su Mantis, tests reports', 'Petracca', 'Petracca')
GO
INSERT INTO PAMPQA.QA_ACTIVITY_TASKS(QAA_ACTIVITY, QAA_DT, QAA_TIME, QAA_TASK, QAA_DETT, QAA_CRT_USR, QAA_UPD_USR)
  VALUES('Quality Assurance Tasks', 'mar 7 mag 2019', '08:30 - 09:30', 'Lime 2.03', 'Test Reporting 1^ run, pubblicazione in QA Portal, ticket di chiusura su Mantis, tests reports', 'Petracca', 'Petracca')
GO
INSERT INTO PAMPQA.QA_ACTIVITY_TASKS(QAA_ACTIVITY, QAA_DT, QAA_TIME, QAA_TASK, QAA_DETT, QAA_CRT_USR, QAA_UPD_USR)
  VALUES('Quality Assurance Tasks', 'mer 8 mag 2019', '08:30 - 09:30', 'QA_Portal 0.1', 'Migrazione/Prototipo versioning con uso di link dinamici (svn/git)', 'Petracca', 'Petracca')
GO
INSERT INTO PAMPQA.QA_ACTIVITY_TASKS(QAA_ACTIVITY, QAA_DT, QAA_TIME, QAA_TASK, QAA_DETT, QAA_CRT_USR, QAA_UPD_USR)
  VALUES('Quality Assurance Tasks', 'gio 9 mag 2019', '08:30 - 09:30', 'QA_Portal 0.1', 'Migrazione/Prototipo versioning con uso di link dinamici (svn/git)', 'Petracca', 'Petracca')
GO
INSERT INTO PAMPQA.QA_ACTIVITY_TASKS(QAA_ACTIVITY, QAA_DT, QAA_TIME, QAA_TASK, QAA_DETT, QAA_CRT_USR, QAA_UPD_USR)
  VALUES('Quality Assurance Tasks', 'ven 10 mag 2019', '08:30 - 09:30', 'QA_Portal 0.1', 'Migrazione/Prototipo versioning con uso di link dinamici (svn/git)', 'Petracca', 'Petracca')
GO
