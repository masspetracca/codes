package com.fasterxml.jackson.databind.JsonNode;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.json.XML;

public class Json2XML {

	/**
	 * @param args
	 * @throws JSONException 
	 */
	public static void main(String[] args) throws JSONException {
		// TODO Auto-generated method stub
		String jsonString="{\"name\":\"Virat\",\"sport\":\"cricket\",\"age\":25,\"id\":121,\"lastScores\":[77,72,23,57,54,36,74,17]}";
		System.out.println(new Json2XML().json2XML(jsonString));
	}

	private JSONTokener ojsonString;
	
	public String json2XML(String jsonString) throws JSONException{
		JSONObject json = new JSONObject(ojsonString);
		String xml = XML.toString(json);
		return xml;
	}
}