package it.rubrica.business;

import javax.ejb.Remote;

@Remote
public interface RubricaRemote extends Rubrica {

}
