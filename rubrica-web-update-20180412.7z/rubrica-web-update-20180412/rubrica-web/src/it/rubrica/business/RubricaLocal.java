package it.rubrica.business;

import javax.ejb.Local;

@Local
public interface RubricaLocal extends Rubrica {

}
