package it.ccg.auditing;

import it.ccg.auditing.elements.Container;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class Auditor {

	private String file;
	private JAXBContext jaxbContext;
	private Marshaller jaxbMarshaller;
	private Unmarshaller jaxbUnMarshaller;
	
	/**
	 * 
	 * @throws JAXBException
	 */
	public Auditor() throws JAXBException{
		
		try {
			jaxbContext = JAXBContext.newInstance(Container.class);
		
			jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbUnMarshaller = jaxbContext.createUnmarshaller();
		} catch (JAXBException e) {
			throw e;
		}
		
	}
	
	/**
	 * 
	 * @param container
	 * @return
	 * @throws JAXBException
	 */
	public ByteArrayOutputStream marshal(Container container) throws JAXBException{
		try {
			ByteArrayOutputStream oS = new ByteArrayOutputStream();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
			jaxbMarshaller.marshal(container, oS);
			
			return oS;
		} catch (JAXBException e) {
			throw e;
		}
	}
	
	/**
	 * 
	 * @param bAIS
	 * @return
	 * @throws JAXBException
	 */
	public Container unmarshal(ByteArrayInputStream bAIS) throws JAXBException{
		try {
			
			Container container = (Container) jaxbUnMarshaller.unmarshal(bAIS);//  marshal(container, oS);
			
			return container;
		} catch (JAXBException e) {
			throw e;
		}
	}
	/**
	 * @return the file
	 */
	public String getFile() {
		return file;
	}

	/**
	 * @param nFILE the file to set
	 */
	public void setFile(String nFILE) {
		this.file = nFILE;
	}

	/**
	 * @return the jaxbContext
	 */
	public JAXBContext getJaxbContext() {
		return jaxbContext;
	}

	/**
	 * @param jaxbContext the jaxbContext to set
	 */
	public void setJaxbContext(JAXBContext jaxbContext) {
		this.jaxbContext = jaxbContext;
	}

	/**
	 * @return the jaxbMarshaller
	 */
	public Marshaller getJaxbMarshaller() {
		return jaxbMarshaller;
	}

	/**
	 * @param jaxbMarshaller the jaxbMarshaller to set
	 */
	public void setJaxbMarshaller(Marshaller jaxbMarshaller) {
		this.jaxbMarshaller = jaxbMarshaller;
	}
	
}
