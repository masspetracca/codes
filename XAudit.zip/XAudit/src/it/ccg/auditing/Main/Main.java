package it.ccg.auditing.Main;

import it.ccg.auditing.Auditor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Iterator;

import javax.xml.bind.JAXBException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;


public class Main {


private static File nameFILE;
private static String wCONTAINER;
private static String wATTRIBUTE;
static String nFILE;

private static String s2;
private static String s1;

public static void main (String [ ] args) throws JAXBException, FileNotFoundException, DocumentException { 

	s1 = "PIPPO";
	s2 = "TAPPO";
	HammingDistance(s1, s2);
	
  nFILE = "test.xml";
  //read File
   BufferedReader in = new BufferedReader
				(new FileReader("test.xml"));
   
   Auditor audit = new Auditor();  
   audit.setFile(nFILE);
   System.out.println("audit: " + audit.toString()); 
   
   audit.getJaxbMarshaller();
   
	SAXReader reader = new SAXReader();
	Document document = reader.read(in);
	Element root = document.getRootElement();
	System.out.println("Root Element: "+root.getName());


	
	
  for ( Iterator i = root.elementIterator(); i.hasNext(); ) {
      Element row = (Element) i.next();

      Iterator itr = row.elementIterator();
      while(itr.hasNext()){

       	Element child = (Element) itr.next();

            //navigazione nodi 
            System.out.println("Element Name:"+child.getQualifiedName() );
            System.out.println("Element Value:"+child.getText());
            
            //Attribute check 
            if (child.getQualifiedName().contains("Container") == true) {
            	  for ( Iterator ix = child.elementIterator(); ix.hasNext(); ) {
			              //navigazione nodo attribute
			              System.out.println("<Attribute>"+child.getQualifiedName() );
			          	  wCONTAINER=("CONTAINER: "+child.getText().substring(1, 15));
			          	  wATTRIBUTE=("ATTRIBUTE: "+child.getText().substring(1, 15));
            	      }
            	  }
            }
      }
  	}

	private static void HammingDistance(String s1, String s2) {
		// TODO Auto-generated method stub
		HammingDistance HammingDistance = new HammingDistance(s2, s2);
		}

}
            	      


            	  
            
      
  


 
