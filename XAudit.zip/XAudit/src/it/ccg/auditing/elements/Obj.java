package it.ccg.auditing.elements;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="Obj")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"type","conpoundAttribute","attributeList","list"})
public class Obj {
	
	@XmlAttribute(name="type")
	private String type;
	
	@XmlElement(name="ConpoundAttribute")
	private List<ConpoundAttribute> conpoundAttribute;
	
	@XmlElement(name="Attribute")
	private List<Attribute> attributeList;
	
	@XmlElement(name="List")
	private List<it.ccg.auditing.elements.List> list;

	public Obj(){
		type= "";
		attributeList = new ArrayList<Attribute>();
		conpoundAttribute = new ArrayList<ConpoundAttribute>();
		list = new ArrayList<it.ccg.auditing.elements.List>();
	}
	/**
	 * @return the attributeList
	 */
	public List<Attribute> getAttributeList() {
		return attributeList;
	}

	/**
	 * @param attributeList the attributeList to set
	 */
	public void setAttributeList(List<Attribute> attributeList) {
		this.attributeList = attributeList;
	}
	
	/**
	 * @return the conpoundAttribute
	 */
	public List<ConpoundAttribute> getConpoundAttribute() {
		return conpoundAttribute;
	}
	/**
	 * @param conpoundAttribute the conpoundAttribute to set
	 */
	public void setConpoundAttribute(List<ConpoundAttribute> conpoundAttribute) {
		this.conpoundAttribute = conpoundAttribute;
	}
	/**
	 * @return the list
	 */
	public List<it.ccg.auditing.elements.List> getList() {
		return list;
	}

	/**
	 * @param list the list to set
	 */
	public void setList(List<it.ccg.auditing.elements.List> list) {
		this.list = list;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}	
}
