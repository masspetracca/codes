package it.ccg.auditing.elements;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="ConpoundAttribute")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"name", "id", "value","selectedAttributeList"})
public class ConpoundAttribute {
	@XmlAttribute(name="name")
	private String name;
	@XmlAttribute(name="id")
	private String id;
	@XmlAttribute(name="value")
	private String value;
	@XmlElement(name="SelectedAttribute")
	private List<SelectedAttribute> selectedAttributeList;
	
	public ConpoundAttribute(){
		name="";
		id="";
		value="";
		selectedAttributeList = new ArrayList<SelectedAttribute>();
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the selectedAttributeList
	 */
	public List<SelectedAttribute> getSelectedAttributeList() {
		return selectedAttributeList;
	}

	/**
	 * @param selectedAttributeList the selectedAttributeList to set
	 */
	public void setSelectedAttributeList(
			List<SelectedAttribute> selectedAttributeList) {
		this.selectedAttributeList = selectedAttributeList;
	}
}
