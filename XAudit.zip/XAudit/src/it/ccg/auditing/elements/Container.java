package it.ccg.auditing.elements;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="Container")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"type", "id", "value","attribute","list","obj","conpoundAttribute"})
public class Container {
	
	@XmlAttribute(name="type")
	private String type;
	@XmlAttribute(name="id")
	private String id;
	@XmlAttribute(name="value")
	private String value;
	
	@XmlElement(name="Attribute")	
	private List<Attribute> attribute;
	
	@XmlElement(name="List")
	private it.ccg.auditing.elements.List list;
	
	@XmlElement(name="Obj")	
	private List<Obj> obj;
	
	@XmlElement(name="ConpoundAttribute")
	private List<ConpoundAttribute> conpoundAttribute;

	public Container(){
		type="";
		id="";
		value="";
		obj = new ArrayList<Obj>();
		attribute = new ArrayList<Attribute>();
		conpoundAttribute = new ArrayList<ConpoundAttribute>();
	}
	
	/**
	 * @return the list
	 */
	public it.ccg.auditing.elements.List getList() {
		return list;
	}

	/**
	 * @param list the list to set
	 */
	public void setList(it.ccg.auditing.elements.List list) {
		this.list = list;
	}
	
	
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the obj
	 */
	public List<Obj> getObj() {
		return obj;
	}

	/**
	 * @param obj the obj to set
	 */
	public void setObj(List<Obj> obj) {
		this.obj = obj;
	}

	/**
	 * @return the attribute
	 */
	public List<Attribute> getAttribute() {
		return attribute;
	}

	/**
	 * @param attribute the attribute to set
	 */
	public void setAttribute(List<Attribute> attribute) {
		this.attribute = attribute;
	}

	/**
	 * @return the conpoundAttribute
	 */
	public List<ConpoundAttribute> getConpoundAttribute() {
		return conpoundAttribute;
	}

	/**
	 * @param conpoundAttribute the conpoundAttribute to set
	 */
	public void setConpoundAttribute(List<ConpoundAttribute> conpoundAttribute) {
		this.conpoundAttribute = conpoundAttribute;
	}
}
