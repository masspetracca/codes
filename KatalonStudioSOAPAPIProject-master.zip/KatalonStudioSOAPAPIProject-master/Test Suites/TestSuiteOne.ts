<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuiteOne</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-11-06T15:49:45</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>35f4f15d-428e-4787-acb0-6bd4b1046eb4</testSuiteGuid>
</TestSuiteEntity>
