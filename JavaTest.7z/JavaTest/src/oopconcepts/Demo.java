package oopconcepts;

public class Demo {

	public void toString(Object a2) {
		// TODO Auto-generated method stub
		System.out.println(a2);
	}

}
