package it.ccg.test.collaudo.server.bus;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteDb {
	//Table access keys
	private static String kDate = ""; 
	private static String kStato = ""; 
	private static String kFreq ="";
	private static String kTipo ="";

	private static String Tab_col0 = "DATEID";
	private static String Tab_col1 = "INFO";
	private static String Tab_col2 = "CLASSNAME";
	private static String Tab_col3 = "QUEUENAME";
	private static String Tab_col4 = "SYSTEMMSG";
	
	private static String TableName = PropertyFiles.getTabName1();

	private static String vcol3 = "";
	private static String vcol4 = "";
	private static String vcol5 = "";

	private static String sdate =null;
	private static String nomeTab;
	

	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

//	private static String tabFreq ="";
	private int ctrIns;
//	private int ctrUpd;
 	private int returnCode = 0;
 	private static String sqlUpdate;
//	
//
//	private static Object rs;
	
	PreparedStatement st;
	private String sqlDelete;
	private int ctrDel;
	public DeleteDb(String keyDate) throws IOException, SQLException, IllegalAccessException, InstantiationException, ClassNotFoundException {
	
		//delete table
	     sqlDelete= 
	    	(
			"DELETE FROM "+TableName 
			+" WHERE "+Tab_col0+ "= '"+keyDate+"'" 
			);
	
		 System.out.println(sqlDelete);		
		 ++ctrDel;
		 
		//setting upd parameters
		TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 
		upd.setSqlUpdate(sqlDelete);	
	}



		
	

}
