package it.ccg.test.collaudo.server.bus;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.logging.Logger;

public class GeneralBatch {
	
	//chiavi di accesso per UPD
	private static String kDateId = ""; 

	private static String Tab_col0 = "DATEID";
	private static String Tab_col1 = "INFO";
	private static String Tab_col2 = "CLASSNAME";
	private static String Tab_col3 = "QUEUENAME";
	private static String Tab_col4 = "SYSTEMMSG";
	
	private static String TableName = "PMPTLOQA";

	private static String vcol3 = "";
	private static String vcol4 = "";
	private static String vcol5 = "";

	private static String sdate =null;
	private static String nomeTab;
	

	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

	private static String tabFreq ="";
	private int ctrIns;
	private int ctrUpd;
	private int returnCode = 0;
	
 	private static String sqlUpdate;


	String stl;
	String tok;
	//PMPTLOQA testcollaudologqa;
	Logger userLog;
	int indx;
	String keyDate;

	String info;
	String queueName;
	String systemMsg;
	String className;

	
	

	public GeneralBatch(int returnCode) throws IOException, SQLException, IllegalAccessException, InstantiationException, ClassNotFoundException {

		Object rs;
		//String driver
		PropertyFiles pf;
		
		//String PreparedStatement
		PreparedStatement st;
		
		try {
			pf = new PropertyFiles();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PropertyFiles.getDbDriverTest();
		PropertyFiles.getTabName1();
		nomeTab=PropertyFiles.getTabName1();


		Class.forName(PropertyFiles.getDbDriverTest()).newInstance();
		//String url = "jdbc:db2://localhost:50000/DB2";
		String url = PropertyFiles.getDbConnStringTest();
		//String prop = ("user"+PropertyFiles.getDbUserTest()+"password"+PropertyFiles.getDbPasswordTest());
		
		Properties props = new Properties();
		//props.setProperty("user", "db2admin");
		props.setProperty("user", PropertyFiles.getDbUserTest());
		
		//props.setProperty("password", "main");
		props.setProperty("password", PropertyFiles.getDbPasswordTest());
		
		
		sdate = day.now();
		
		String sdateaaaa = sdate.substring(0, 4);
		String sdatemm =   sdate.substring(5, 7);
		String sdategg = sdate.substring(8, 10);
		
		String stimehh = sdate.substring(11, 13);
		String stimemm = sdate.substring(14, 16);
		String stimess = sdate.substring(17, 19);
		
		sDate = (sdateaaaa+sdatemm+sdategg);
		sTime = (stimehh+stimemm+stimess);
		System.out.println("date:"+sDate);
		System.out.println("time:"+sTime);
	
		
		
		System.out.println("Inizio <PopulateDb> popolamento tabelle DB2 via JDBC");
		//segnalazioni di test
		System.out.println("**************************************");
		System.out.println("**       Segnalazioni tecniche      **");
		System.out.println("**************************************");
		System.out.println("url per POPOLAMENTO di : "+nomeTab+" "+url);
		System.out.println("drivers: "+PropertyFiles.getDbDriverTest());
		System.out.println("User Test: "+ PropertyFiles.getDbUserTest());
		System.out.println("Password Test: "+ PropertyFiles.getDbPasswordTest());
		System.out.println("**************************************");
		

	   	GetProperties();
 
		//create Connection
		Connection conn = DriverManager.getConnection(url, props);

    	BufferedReader in = new BufferedReader
        //(new FileReader("datiPM/test_logOUT.txt"));
		(new FileReader(PropertyFiles.getCartellaDati()+PropertyFiles.getOUTFPM_FILE_INPUT()));

    	String keyDateID;

    	String className;
    	int prog;
    	String bool;

    	
 	    TestCollaudoQAEAO pdb = new TestCollaudoQAEAO();
 	    keyDate = " ";
 		className= " ";
 		prog=0;
 		bool= " ";

 
        while ((stl = in.readLine()) != null) {
         	System.out.println("readData: "+stl);
         	String newStr = stl.replace("'", "");
         	stl=newStr;


     	    tok=" ";
    	    indx=0;
 	        StringTokenizer f= new StringTokenizer(stl, ";");
	        while(f.hasMoreTokens()) {
	        	    indx++;
	        	    if (indx == 1) {
	        	    	tok = (String)f.nextElement();
	        	    	keyDate = tok;
	        	    	pdb.setKeyDate(keyDate);
	        	    }
	        	    if (indx == 2) {
	        	    	tok = (String)f.nextElement();
	        	    	info = tok;	        	    	
	        	    	pdb.setClassName(info);
	        	    }
	        	    if (indx == 3) {
	        	    	tok = (String)f.nextElement();
	        	    	className = tok;	        	    	
	        	    	pdb.setClassName(className);
	        	    }
	        	    if (indx == 4) {
	        	    	tok = (String)f.nextElement();
	        	    	queueName = tok;
	        	    	pdb.setQueueName(queueName);
	        	    }
	        	    if (indx == 5) {
	        	    	tok = (String)f.nextElement();
	        	    	systemMsg = tok;	        	    	
	        	    	pdb.setSystemMsg(systemMsg);
	        	    }
	        	    if (indx > 5) {
	        	    	 System.out.println("Fine anomala  ... "+(String)f.nextElement());
	        	    	 System.exit(10);
	        	    }
			        System.out.println("token:"+indx+"="+tok);
			      
	        }
	        DeleteDb(keyDate);

			TestCollaudoQAUPD deld = new TestCollaudoQAUPD(); 	        
	        //System.out.println("String per DELETE:"+deld.getSqlUpdate());
	    	st = conn.prepareStatement(deld.getSqlUpdate());
    	    st.executeUpdate();

    	    PopulateDb(keyDate, info, queueName, className, systemMsg);


			TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 	        
	        //System.out.println("String per INSERT:"+upd.getSqlUpdate());
	    	st = conn.prepareStatement(upd.getSqlUpdate());
    	    st.executeUpdate();

	}

     in.close();
     System.out.println("Fine esecuzione ##End ...Read Data Test Collaudo QA");
 }




	private void DeleteDb(String keyDate) throws IOException, SQLException, IllegalAccessException, InstantiationException, ClassNotFoundException {
		DeleteDb ddb = new DeleteDb(keyDate);
	}




	private void PopulateDb(String keyDate, String info, String className, String queueName, String systemMsg) throws ClassNotFoundException, IOException, SQLException, IllegalAccessException, InstantiationException {
		PopulateDb pdb = new PopulateDb(keyDate, info, className, queueName, systemMsg);
	}
	
	
	private static void GetProperties() throws IOException {
		PropertyFiles pf = new PropertyFiles();
	}

 

}


	
		
							
   


