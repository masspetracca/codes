package it.ccg.test.collaudo.server.bus;

public class TestCollaudoQAEAO {

	public TestCollaudoQAEAO(int returnCode) {
		// TODO Auto-generated constructor stub
	}
	public TestCollaudoQAEAO() {
		// TODO Auto-generated constructor stub
	}


	public String getKeyDate() {
		return keyDate;
	}
	public void setKeyDate(String keyDate) {
		this.keyDate = keyDate;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getQueueName() {
		return queueName;
	}
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	public String getSystemMsg() {
		return systemMsg;
	}
	public void setSystemMsg(String systemMsg) {
		this.systemMsg = systemMsg;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}


	public String keyDate;
	public String info;
	public String queueName;
	public String systemMsg;
	public String className;

}
