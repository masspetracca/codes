package it.ccg.test.collaudo.server.bus;



import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PopulateDb {
	
	//Table access keys
	private static String kDate = ""; 

	private static String Tab_col0 = "DATEID";
	private static String Tab_col1 = "INFO";
	private static String Tab_col2 = "CLASSNAME";
	private static String Tab_col3 = "QUEUENAME";
	private static String Tab_col4 = "SYSTEMMSG";

	private static String TableName = PropertyFiles.getTabName1();

	private static String vcol3 = "";
	private static String vcol4 = "";
	private static String vcol5 = "";

	private static String sdate =null;
	private static String sTime ="";
	private static String sDate = "";
	static DateUtils day = new DateUtils();

//	private static String tabFreq ="";
	private int ctrIns;
//	private int ctrUpd;
 	private int returnCode = 0;
 	private static String sqlUpdate;
//	
//
//	private static Object rs;
	
	PreparedStatement st;
	private String sqlDelete;
	private int ctrDel;


	public PopulateDb(String keyDate, String info, String queueName, String systemMsg, String className) throws ClassNotFoundException, IOException, SQLException, IllegalAccessException, InstantiationException {
		
		
		//upate table
		       sqlUpdate= 
				"INSERT INTO "+TableName
				+"("
				+""+Tab_col0
				+", "+Tab_col1
				+", "+Tab_col2
				+", "+Tab_col3
				+", "+Tab_col4
				+") VALUES ("
				+"'"+keyDate+"'" 				
				+", '"+info+"'" 
				+", '"+className+"'" 
				+", '"+queueName+"'" 
				+", '"+systemMsg+"'" 
				+")"
				;

	    System.out.println(sqlUpdate);		
		++ctrIns;
		//setting upd parameters
		TestCollaudoQAUPD upd = new TestCollaudoQAUPD(); 
		upd.setSqlUpdate(sqlUpdate);	
}




	



}


	
		
							
   

